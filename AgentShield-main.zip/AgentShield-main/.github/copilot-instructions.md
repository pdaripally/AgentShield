# Agent Shield — Copilot Instructions

## Project Overview

Agent Shield is an **open specification with reference implementations** for runtime security controls on AI agents. It enforces guardrails via a declarative `.guardrails.yaml` contract through **5 validation stages** (Input → State → Tool execution → Post-tool → Output). The runtime is framework-agnostic and the same contract enforces across LangChain, AutoGen, Semantic Kernel, OpenAI Agents SDK, CrewAI, Anthropic Agents SDK, MCP servers, HTTP gateways, and Kubernetes sidecars.

The spec (`spec/SPECIFICATION.md`) is the source of truth. SDK behavior that diverges from the spec is a bug.

## Repository Structure

- `spec/SPECIFICATION.md` — Canonical spec (v2.0.0-alpha, the unified-resolver / unified-guard-policy model). All SDK behavior must match this.
- `spec/expressions/LANGUAGE.md` — Normative expression-language spec.
- `spec/schema/guardrails.schema.json` — JSON Schema for `.guardrails.yaml`.
- `sdk/rust/agent_shield_core/` — Reference Rust core. Other Rust crates and Python / Node / .NET wrap this.
- `sdk/python/agent_shield/`, `sdk/node/`, `sdk/dotnet/src/AgentShield/` — language surfaces.
- `examples/` — Demo agents (bank-manager, sensitive-documents, …) with guardrails YAML, MCP servers, demo scripts.
- `tests/cases/` — Cross-language test contracts. Every spec-defined behavior gets a case here.
- `tests/fixtures/` — Shared YAML fixtures.

## SDK ↔ Rust core boundary

The Rust core (`sdk/rust/agent_shield_core/`) is the canonical implementation. Every other SDK is a **thin wrapper** over it.

**Rule**: any logic that could live in the Rust core MUST live in the Rust core, surfaced through FFI / PyO3 / napi-rs / P/Invoke. SDKs translate shapes; they don't reimplement behavior.

What belongs in core:
- Loader (`.guardrails.yaml` parsing, schema validation, extends-chain merging)
- Expression-language tokenizer / parser / AST / evaluator
- Variable lifetime tracker (status transitions, source attribution)
- Event bus (closed-namespace parsing, latching, lifetime expiry)
- Resolver runtime (cycle detection, retry counting, fallback / on_error / on_allow)
- Guard-policy engine (per-stage runners, applies_to, evaluate_when / allowed_when / active_if, redaction-span application)
- Verdict-handling dispatch (`dispatch_stage_verdict`, `dispatch_tool_verdict`, ShieldMode, block-message formatting, pending_resolution shape)
- Wire-shape canonicalization (any byte-stable JSON the spec defines)
- Cross-language test contracts (canonical fixtures, parity inputs)

What belongs in SDKs:
- Idiomatic API surface (camelCase JS, snake_case Python, PascalCase .NET, builder ergonomics)
- Framework-specific adapter glue (LangChain tool wrappers, OpenAI tool-call dispatch, Anthropic streaming, etc.)
- JSON marshaling at the FFI boundary
- **The async state machine that calls Stage 1 → execute → Stage 5** — see "What MUST stay in SDKs" below
- Optional peer-dep loading

### What MUST stay in SDKs (settled — do not re-litigate)

The async wiring around `await execute()` cannot move into core. This boundary is already settled and documented at `sdk/rust/agent_shield_core/src/shield_primitives.rs:1-13`. New audits keep flagging the LOC in `_orchestration.py` / `_shield.py` / `shield.ts` / `Shield.cs` and proposing to "collapse it into core" — that proposal is wrong and has been rejected. Reasons:

1. **Host async runtimes cannot be driven from Rust through FFI** without imposing one specific event loop on the customer (asyncio vs FastAPI / Tornado / Trio; Node's event loop; .NET's `SynchronizationContext`). That would destroy the framework-agnostic claim.
2. **Ambient session propagation across `await` is a host-runtime feature**: Python's `contextvars`, Node's `AsyncLocalStorage`, .NET's `AsyncLocal<T>`. No FFI equivalent exists; replicating it would leak set/get calls into every customer await boundary.
3. **Tool execution callbacks cross FFI the wrong direction.** Driving them from Rust would mean Rust → pyo3/napi-rs → host → back into Rust for *every* tool call, adding double-marshaling latency in exchange for code whose decisions are already byte-equivalent (they delegate to `dispatch_stage_verdict` / `dispatch_tool_verdict`).

Concretely, the following lives — and stays — per-SDK:

- The `guarded_turn` / `guarded_tool` / `runStreamed` async state machine (begin_turn → validate_input → await execute → validate_output → end_turn) — host-runtime-bound.
- Ambient-session abstraction (`current_session` ContextVar / `AsyncLocalStorage` / `AsyncLocal<T>`).
- The `try/except` (`try/catch`) around `await execute()` that drives the Stage 4 error path.
- Framework-specific shape translation: tool extraction, LLM response reshaping, agent-result projection, streaming-chunk format.
- `inspect.signature` / reflection used to decide whether to pass Stage-3 effective_params to the customer's `execute` callable.

A useful rule of thumb when auditing: **if removing the code would force Rust to own a Python/JS/.NET async event loop, the code belongs in the SDK.** If removing the code would only require an extra FFI call returning a pure-data decision, it belongs in core.

**When you find duplication**: move it to core. Recent examples — block-message formatting, stage / tool verdict dispatch, lifetime parsing all started as per-SDK reimplementations and were collapsed into `agent_shield_core` once we caught the drift. New duplication should be caught at review time.

But: do not confuse **lines-of-async-glue** with **duplicated decisions**. A 1,000-LOC `shield.ts` whose every verdict call goes through `dispatchStageVerdict`/`dispatchToolVerdict`/`formatBlockMessage` is *not* duplicating core; it's hosting the async state machine. The same applies to `_orchestration.py` and managed-side `Shield.cs`. Verify by grepping for the canonical FFI calls before assuming duplication.

**When extending the runtime**: add the behavior in core first, write the cross-language test in `tests/cases/`, then thread the SDK surfaces through. SDK-first features always ship drift.

## Integration ergonomics

Agent Shield only matters if customers actually adopt it. Every change should make integration easier, not harder.

**Bias toward fewer lines of customer code.** Three-line drop-in is the goal:

```python
shield = Shield.from_yaml(".guardrails.yaml").with_langchain().build()
guarded = shield.guard(agent)              # full-coverage Pattern A
result  = await guarded.ainvoke(input)
```

If a customer needs more than this for a common use case, the friction is a bug — surface it, don't paper over it.

**Sensible defaults > flags.** The default behavior must match the spec's security posture (fail-closed, no auto-resolution outside `evaluate_when` / `allowed_when`, etc.). Don't ship safety as opt-in. If a customer needs to flip something, the YAML should drive it, not the SDK call.

**Per-framework helpers wrap the loop.** Adapters expose `runAnthropicAgent`, `protectOpenaiTools`, `createLangchainAgent`, etc., so customers don't stage-by-stage gate manually. The base `shield.run(fn)` and `shield.protectTool(name, params, fn)` cover the framework-agnostic case in one call each.

**Per-ecosystem adapter shapes are correct, not technical debt.** Same conceptual model (Patterns A/B/C) anchored across all four SDKs; **implementation shape matches each ecosystem's idiomatic middleware surface**, not a forced uniform API. Don't try to make Rust look like Python or vice versa — the ecosystems' middleware surfaces genuinely differ, and forcing parity makes integrations *less* idiomatic.

| Ecosystem | Pattern A native shape | Why this shape |
|---|---|---|
| Python | `shield.guard(agent)` via bundle dispatch; OAI Agents SDK also wants a native `@input_guardrail` object | Frameworks expose agent objects (LangChain Runnable, OAI Agent, Anthropic Agents) that map to a single wrapper; OAI SDK has its own decorator-style guardrail contract |
| Node | `shield.guard(agent)` via bundle dispatch; module-augmentation side-effect import registers the bundle | Same agent-object pattern as Python; JS module-augmentation is the idiomatic registration surface |
| Rust | `shield.run(thunk)` (Pattern C) + `shield.protect_tool(...)` primitives; `agent_shield_rig` ships `GuardedRigTool` (Pattern B wrap-up-front) | No production agent framework with an "agent object" to wrap; `rig` owns the loop via `rig::Agent` + `PromptHook`, and its `ToolCallHookAction` lacks `Replace { args }` so hook-based arg mutation is impossible — wrap-tools-up-front is the *only* full-coverage path |
| .NET | `GuardedChatClient : DelegatingChatClient` for Microsoft.Extensions.AI (`UseAgentShield()`); `AgentShieldFilter : IAutoFunctionInvocationFilter` for Semantic Kernel; `AgentShieldMiddleware : IMiddleware` for AutoGen | Each .NET framework uses a *different* native middleware contract; meeting each framework's contract IS the canonical .NET shape — best-in-class structured middleware story of any ecosystem |

**Rule**: when a parity gap appears, first ask "is this an ecosystem-specific idiom, or a real coverage gap?" If the missing API doesn't have an idiomatic home in the target ecosystem, don't force it — document the asymmetry with `intentional_asymmetry: true` + `asymmetry_reason: "..."` in `tests/parity/shield_canonical_api.json`. If the same Pattern A/B/C *coverage* is missing in any SDK, that's a real bug; fix it via the ecosystem-native shape.

**Keep `.guardrails.yaml` portable across frameworks.** A YAML file written for LangChain MUST enforce identically on OpenAI Agents, Anthropic, MCP, AutoGen, etc. Framework-specific tweaks belong in the SDK adapter, not in the YAML. When a behavior can't be expressed portably, fix the spec; don't add a per-framework escape hatch.

**Surface unergonomic spec / API issues, don't accept them.** When integration feels awkward — verbose YAML, a workflow that needs three config blocks for one intent, an SDK call sequence that's easy to get wrong — flag it. Open a spec issue. Propose a primitive that collapses the friction. The spec is still pre-1.0; small ergonomic improvements landed now save large adoption costs later. Examples: `kind: human` becoming a thin shim over `kind: tool` (one resolver kind, one wire shape, one mental model), `Shield.from_yaml` accepting both a single path and an extends-chain transparently.

**Think the use case through end-to-end before changing surface.** What does the customer's first 10 minutes look like? Their first error? Their first production deploy? An API that's elegant in isolation but requires reading three sections of the spec to use isn't elegant.

## Guardrails YAML

- Snake_case throughout — no exceptions. Compatibility key is `agent_shield_version` (snake_case).
- Four primitives: **variables**, **predicates**, **events / lifetimes**, **resolvers**. Every gating decision flows through `guard_policies[]` applied at one of the five stages.
- Variables carry a metadata envelope (`@status`, `@set_at`, `@expires_at`, `@source_kind`, `@set_by`). States are `unset` / `resolved` / `denied`. A `null` value with `@status: resolved` is **not** the same as `unset`.
- Resolvers come in five kinds: `tool`, `human`, `delegate`, `expression`, `agent`. All return `{decision, value, set_variables, reason}` where `decision ∈ {allow, deny, cancelled}`.
- Events live on a **closed namespace** — `session.* | turn.* | request.* | tool.* | endpoint.* | agent.* | variable.* | guard_policy.* | approval.* | incident.<name>`. Anything else is a load-time error.
- Lifetimes: `per_call`, `per_turn`, `per_session`, `per_request`, `for: '<duration>'`, `until_event: '<event>'`.
- `applies_to.tools: ["*"]` matches **every** tool, including listed ones — there is no "unlisted-only" mode (§12.3).
- Composable configs via `extends:` are additive-only. Same-name `guard_policies` merge additively; `active_if` is effectively immutable across the chain; `allowed_when:` AND-composes (bypasses tighten).

## Expression Language

The expression language used in `evaluate_when[].expression`, `allowed_when:`, `active_if:`, and predicate bodies is a Rego-inspired predicate language deliberately scoped for single-line YAML. Normative reference: `spec/expressions/LANGUAGE.md`.

### Design invariants
- **Lowercase keywords only**: `and`, `or`, `not`, `in`. UPPERCASE is a parse error.
- **Strict typing, no implicit coercion**: type mismatches return `null` / `false`, never silently convert.
- **Fail-closed null**: missing variables → `null` → `false` in boolean context. Security invariant — must be preserved across all parser changes.
- **No Rego structural patterns**: no `package`, `import`, `some`, `every`, comprehensions, `with`, incremental rules, `default`. Module-level concerns don't apply.
- **Auto-resolution boundary**: only `evaluate_when[].expression` and `allowed_when:` may auto-trigger an `on_demand_by:` resolver. `active_if`, predicate bodies, and metadata reads (`var@status`, etc.) never auto-resolve.

### Operator precedence (highest → lowest)
1. `()`, function calls, `.` dot access, `[]` indexing
2. unary `-`
3. `*`, `/`, `%`
4. `+`, `-`
5. `==`, `!=`, `<`, `>`, `<=`, `>=`, `in`
6. `not`
7. `and` / `;`
8. `or`
9. ternary `? :`
10. `:=`

### Type system
- Types: `string`, `number`, `boolean`, `array`, `object`, `datetime`, `duration`, `null`.
- Cross-type comparisons return `false` (not error).
- `null` propagates through arithmetic (`null + 5 → null`).
- Boolean coercion: `null` / `false` / `0` / `""` / `[]` / `{}` → `false`; everything else → `true`.
- Status sugar: `defined(var)`, `unset(var)`, `denied(var)`, `present(var)` — see spec §7.4.
- Read-only namespaces (never auto-resolve): `tool.*`, `endpoint.*`, `agent.*`, `context.*`, `result.*` — spec §7.6.

### Built-ins
Function names match Rego: `contains()`, `startswith()`, `endswith()`, `regex.match()`, `is_string()`, `is_number()`, `count()`, `count_where()`, `all()`, `any()`, `lower()`, `upper()`, `object.get()`, `time.now()`, `time.clock()`, `time.duration()`, `event.fired()`, `abs()`, etc. Full registry in spec §7.3.

### Key files
- `spec/SPECIFICATION.md` §7 (expressions), §9 (variables), §10 (events / lifetimes), §11 (resolvers), §12 (guard policies), §13 (resources)
- `spec/expressions/LANGUAGE.md` — normative reference
- `sdk/rust/agent_shield_core/src/expressions/` — reference parser / evaluator
- `sdk/rust/agent_shield_core/src/` — reference runtime (event bus, lifetime engine, resolver runtime, guard-policy engine, observability)
