# LiteLLM Proxy integration

Agent Shield ships an out-of-process integration for
[LiteLLM Proxy](https://docs.litellm.ai/docs/simple_proxy) — the
OpenAI-compatible gateway many teams use to centralise LLM access.
This page covers the integration shape, the threat model, what each
validation stage gates when traffic flows through the proxy, the
streaming behaviour, and the explicit out-of-scope items.

## Install

```bash
pip install agent-shield[litellm-proxy]
```

## Register

LiteLLM Proxy's `--config` plugin loader resolves dotted paths against
the config directory only. It does not fall back to importlib for
installed packages, so the integration cannot be referenced directly
as `agent_shield.integrations.litellm_proxy.AgentShieldLiteLLMGuardrail`
from a stock `litellm_config.yaml`. The fix is a one-line shim file
that lives next to the config and re-exports the integration's public
surface.

Drop this file alongside `litellm_config.yaml`:

```python
# /etc/litellm/agent_shield_guardrail.py
from agent_shield.integrations.litellm_proxy import (
    AgentShieldLiteLLMGuardrail,
    agentshield_guardrail,
)
```

Then pick one of two registration paths in `litellm_config.yaml`.

**Native `guardrails:` block (recommended)** — gives operators
per-route `mode:` selectors and the proxy's built-in guardrail
metrics surface:

```yaml
guardrails:
  - guardrail_name: agent_shield
    litellm_params:
      guardrail: agent_shield_guardrail.AgentShieldLiteLLMGuardrail
      mode: ["pre_call", "post_call"]
      guardrails_path: /etc/agent-shield/guardrails.yaml
      default_on: true
```

**Callbacks list** — simpler, uses LiteLLM's general callback path:

```yaml
litellm_settings:
  callbacks:
    - agent_shield_guardrail.agentshield_guardrail
```

The callbacks path reads its `.guardrails.yaml` from the
`AGENT_SHIELD_LITELLM_GUARDRAILS_PATH` environment variable.

The shim filename is arbitrary; whatever you name it
(`agent_shield_guardrail.py`, `shield.py`, etc.) becomes the dotted
prefix in the config. Both paths use the same loader internally;
neither one bypasses the file-based resolution.

## Stage coverage

LiteLLM Proxy sees only OpenAI-Chat-style request/response shapes and
never executes tools itself, so the stages it can gate are:

| Stage              | LiteLLM hook                                    | Source data                                                 | On block                                                                                                 | On mutate                                                                                                |
|--------------------|-------------------------------------------------|-------------------------------------------------------------|----------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------|
| **1 — Input**      | `async_pre_call_hook`                           | last `role=user` message text                               | HTTP 400 with the canonical `[GUARDRAIL ACTION] reason` body                                             | n/a (Stage 1 has no mutation surface in the current SDKs)                                                |
| **2/3 — Tool call**| `async_post_call_success_hook` / iterator hook  | each `tool_calls[*]` on the assistant response              | drop **all** `tool_calls`, replace `content` with the block string, set `finish_reason="stop"`           | rewrite `tool_calls[i].function.arguments` with `outcome.params` and forward the (mutated) response      |
| **4 — Tool output**| `async_pre_call_hook` (next request)            | trailing `role=tool` messages in the request                | `replace` (default) — overwrite the tool message `content` with the block string; or `raise` HTTP 400    | overwrite the tool message `content` with `outcome.result`                                               |
| **5 — Output**     | `async_post_call_success_hook` / iterator hook  | final assistant `content` (only when no `tool_calls`)       | rewrite the response into a single assistant block message with `finish_reason="stop"`                   | rewrite `content` with the canonical post-Stage-5 string (redact / append / prepend)                     |

All five stages enforce against the *same* `.guardrails.yaml` you use
in other integrations. Verdict-handling decisions (block / proceed /
proceed-with-mutation, block-message formatting) are delegated to
`agent_shield._native` — the same core dispatchers every other SDK
shares, so blocking behaviour is byte-equivalent between the in-process
SDK and the proxy.

## Turn lifecycle

A single agent turn often spans multiple LiteLLM HTTP requests:

```
user → [proxy ▶ Stage 1] → upstream
                 ↓ assistant.tool_calls
        [proxy ▶ Stage 2/3]
                 ↓
tool   → [proxy ▶ Stage 4] → upstream
                 ↓ assistant.content
        [proxy ▶ Stage 5] (turn ends)
```

The guardrail opens one Agent Shield turn on the first request whose
last message is `role=user`, keeps it open across the
assistant-with-`tool_calls` / `role=tool` cycle, and closes it on the
final assistant response (the one with `content` and no `tool_calls`).
A new `role=user` message before an open turn has closed is treated as
a fresh turn (the previous one is force-closed) so per-turn lifetimes
behave consistently with the in-process SDK.

## Session correlation

Per-session state (variables, lifetimes, latched events, state
machines) only carries across requests when the caller threads a
stable session id. The guardrail resolves it per request in this
order:

1. `data["metadata"]["agent_shield_session_id"]` — explicit opt-in
2. `data["litellm_session_id"]` — LiteLLM-native
3. `data["user"]` — OpenAI-compatible field
4. fresh UUID — no cross-request continuity

Sessions are cached in a bounded LRU
(`AGENT_SHIELD_LITELLM_SESSION_CACHE_SIZE`, default 512) with an idle
TTL (`AGENT_SHIELD_LITELLM_SESSION_TTL_SECONDS`, default 1800 s).
Concurrent requests for the *same* session id are serialised on a
per-session `asyncio.Lock` so the underlying Agent Shield state
machine never sees interleaved hook invocations.

## Streaming

v1 is **buffer mode**:

1. The guardrail drains the upstream `ModelResponseStream` iterator,
   concatenating `delta.content` and reassembling chunked
   `tool_calls.function.arguments` strings keyed by their `index`
   (per the OpenAI streaming spec — argument strings arrive split
   across many chunks).
2. After EOF, Stages 2/3 (on the assembled tool calls) and Stage 5
   (on the assembled content) run against the complete output.
3. **Allow** → the captured chunks are replayed in order.
4. **Block** or **mutate** → a single replacement chunk is emitted
   carrying the block / mutated string in `delta.content`, with
   `finish_reason = "stop"`. The proxy owns SSE framing — the
   guardrail never writes raw `[DONE]`.

Trade-off: TTFT goes from first-token to full-response. Buffer mode is
the only mode in which Stage 5 (which needs a complete output) can
produce a meaningful verdict. Inline-gate streaming is a v2 follow-up.

## Threat model

**Mitigated by this integration:**

- **PII / jailbreak input** — Stage 1 short-circuits before any
  upstream call; useful credits / latency are saved and no sensitive
  content leaves the boundary.
- **Tool-call abuse** — even when a downstream agent trusts the LLM's
  tool selection, the proxy can drop a forbidden `tool_calls[]` and
  substitute a refusal message; clients see the substituted assistant
  reply, not the forbidden call.
- **Tool-output exfiltration** — Stage 4 inspects each `role=tool`
  reply the client sends back to the LLM and can block / redact before
  the upstream model sees the leaked content.
- **Sensitive content in final responses** — Stage 5 redacts or
  rewrites final assistant content before it reaches the client.
- **Conversation-history injection** — a client cannot stuff a
  fabricated `assistant.tool_calls` + `role=tool` exchange into the
  messages array to slip unvalidated tool content past Stage 4. The
  proxy fail-closes any `role=tool` message whose `tool_call_id` it
  did not Stage-4-validate on a prior request for the same session.
  Legitimate multi-turn history (where the same proxy validated the
  tool exchange when it originally arrived) passes through because
  Stage 4 records the validated id in
  `_Entry.validated_tool_call_ids` for the lifetime of the session.

**Not mitigated by this integration:**

- **Tools the agent invokes locally without going through the proxy.**
  The proxy only sees what flows through it. For full coverage, also
  use the in-process SDK adapter for whichever framework your agent
  runs on.
- **Client-side state poisoning.** Clients can replay altered prior
  assistant messages on subsequent requests. Use stable session ids
  and treat the guardrail's audit log as the source of truth for what
  the LLM actually emitted.

## Out of scope for v1 (explicitly)

- **Multi-choice responses (`n > 1`).** The guardrail validates only
  `choices[0]` of the response (both non-streaming and streaming
  paths). Requests with `n > 1` are fail-closed-rejected at the
  `pre_call` hook with an HTTP 400 carrying a clear reason. Per-choice
  validation is a v2 follow-up.
- **Assistant-prefilled / system-only requests.** The guardrail only
  enforces requests that end with a `role=user` message (a new turn)
  or a trailing `role=tool` block (a turn continuation). Requests
  whose trailing message is `role=assistant`, `role=system`, or any
  other terminal role are fail-closed-rejected at the hook with an
  HTTP 400. Neither Stage 1 nor Stage 4 has a defined enforcement
  point for those shapes, so silently forwarding them would create
  a coverage gap. Workflows that need prefill should run the
  validators via the in-process Python SDK adapters instead.
- **Human-approval / pending-resolution flows.** A LiteLLM Proxy
  callback runs synchronously inside the HTTP request/response cycle
  and has no native way to suspend and resume. Any verdict carrying
  `pending_resolution` is mapped to a fail-closed block carrying the
  resolver's `reason`. If your YAML uses `kind: human` resolvers (or
  any other resolver that can't complete inline), run them via the
  in-process SDK adapters instead.
- **Inline-gate streaming.** v1 is buffer-mode only. Token-by-token
  Stage-5 enforcement is a v2 follow-up.
- **LiteLLM-as-a-library integrations for other framework adapters.**
  Tracked separately (issue #8).

## Configuration reference

Environment variables read by the lazy
`agentshield_guardrail` singleton:

| Var                                              | Default          | Purpose                                                                                |
|--------------------------------------------------|------------------|----------------------------------------------------------------------------------------|
| `AGENT_SHIELD_LITELLM_GUARDRAILS_PATH`           | *(required)*     | Path to the `.guardrails.yaml` the guardrail enforces                                  |
| `AGENT_SHIELD_LITELLM_SESSION_CACHE_SIZE`        | `512`            | LRU cap for cached sessions                                                            |
| `AGENT_SHIELD_LITELLM_SESSION_TTL_SECONDS`       | `1800`           | Idle TTL for cached sessions (seconds). `0` disables TTL eviction                      |
| `AGENT_SHIELD_LITELLM_STAGE4_ON_BLOCK`           | `replace`        | `replace` — overwrite tool message content with the block string; `raise` — HTTP 400   |
| `AGENT_SHIELD_LITELLM_GUARDRAIL_NAME`            | `agent_shield`   | Identifier shown in LiteLLM Proxy logs and metrics                                     |

When using the explicit `guardrails:` block in `litellm_config.yaml`,
the same parameters can be set under `litellm_params:` per-guardrail
without env vars — see the example.

## Reference

- LiteLLM Proxy guardrails docs: https://docs.litellm.ai/docs/proxy/guardrails
- Source: `sdk/python/agent_shield/integrations/litellm_proxy/`
- Tests: `tests/e2e/run_litellm_proxy.py`
- Spec: [`spec/SPECIFICATION.md`](../../spec/SPECIFICATION.md)
