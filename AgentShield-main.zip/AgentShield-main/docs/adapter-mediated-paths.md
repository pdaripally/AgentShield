﻿# Adapter Mediated Paths

This document is the human-readable mediated-path matrix for Agent Shield adapters. It complements `tests/parity/capability_canonical.json`, which is the machine-checked capability matrix. A path listed as **mediated** is routed through Agent Shield before the host framework executes or emits the guarded operation. A path listed as **unsupported** or **outside scope** MUST NOT be treated as protected by Agent Shield.

Coverage levels:

- **Full**: the adapter mediates the path for the supported framework versions when the documented integration pattern is used.
- **Partial**: the adapter mediates only some paths or requires a specific pattern. The notes identify what remains unsupported.
- **Unsupported**: the adapter does not mediate this path. Hosts must use another integration mode, such as explicit SDK calls or a framework hook with full coverage.

## Universal Integration Rules

- All governed tool calls, endpoint calls, and sub-agent invocations must flow through the documented adapter or SDK wrapper path before execution.
- Hosts must not keep parallel unguarded tool functions registered for the same governed action.
- Unknown framework tool-call shapes, callback orders, or streaming modes must fail closed or be documented as unsupported before execution.
- Validate-only APIs are not sufficient for consequential actions unless the host executes the exact canonical invocation that was validated.

## Matrix

| Adapter | Implemented SDKs | Input | State | Tool Authorization | Tool Execution | Tool Output | Output | Streaming | Mediated paths | Unsupported / bypass paths |
|---|---|---:|---:|---:|---:|---:|---:|---:|---|---|
| `langchain` | Python, Node, Rust | Full | Full | Full | Full | Full | Full | Partial | Wrapped/instrumented LangChain tool invocation and final output paths exposed by the adapter. | Direct calls to original tools, custom callbacks not installed through the adapter, and framework streaming chunks beyond documented partial coverage. |
| `openai_agents` | Python, Node, Rust, .NET | Full | Full/Partial by SDK | Full/Partial by SDK | Full/Partial by SDK | Full/Partial by SDK | Full | Partial/Unsupported by SDK | Adapter-owned OpenAI agent loop or documented wrapped tool dispatch path. | Direct OpenAI SDK calls, manually executed tool calls outside the adapter, and unsupported streaming modes. |
| `anthropic_agents` | Python, Node, Rust, .NET | Full | Full | Full | Full | Full | Full | Partial | Adapter-mediated Anthropic tool-use loop and guarded output path. | Direct Anthropic SDK tool execution and unwrapped streaming consumers. |
| `semantic_kernel` | Python, .NET | Full | Full | Full | Full | Full | Full | Full/Unsupported by SDK | Semantic Kernel function invocation filters or documented adapter-owned execution path. | Direct kernel function calls that bypass filters; Python streaming is unsupported per capability overrides. |
| `autogen` | Python, .NET | Full | Partial | Partial | Partial | Partial | Full | Unsupported | Documented AutoGen guarded agent/tool hooks. | Tool paths not exposed through AutoGen hooks and all streaming output paths. |
| `crewai` | Python | Full | Full | Full | Full | Full | Full | Unsupported | CrewAI adapter-wrapped tools and agent output path. | Direct tool calls and unsupported streaming chunks. |
| `rig` | Rust | Full | Partial/Full by pattern | Partial/Full by pattern | Partial/Full by pattern | Partial/Full by pattern | Full | Partial | Rig adapter hooks; full coverage requires the documented wrap-tools-up-front pattern. | Hook-only partial coverage paths and direct tool execution. |
| `microsoft.extensions.ai` | .NET | Full | Partial | Partial | Partial | Partial | Full | Full | Documented .NET middleware/filter path. | Direct service calls and streaming output paths. |
| `mcp` | Python, Node, .NET | Unsupported | Full | Full | Full | Full | Unsupported | Unsupported | In-process MCP server tool-call paths wrapped via the `MCPShield` SDK helpers (`shield_server` / `protect_server` / `protectTools` / `ProtectTool` / `ProtectToolOutput`). | MCP servers reachable directly by the agent or host outside the wrapped tool registry. |

## Adapter Review Checklist

For every adapter release, reviewers should verify:

- The adapter capability report still matches `tests/parity/capability_canonical.json`.
- The adapter tests cover each path marked Full or Partial.
- Unsupported paths fail closed or are impossible to call through the guarded API.
- Documentation names the exact framework versions tested.
- Streaming behavior is described as buffering, validated chunking, or unsupported.
- The adapter exposes the canonical invocation hash or equivalent decision binding where tool execution is mediated.
