# Pluggable Moderation Providers

Agent Shield ships **bundled moderation classifier providers** — external
content-classification services exposed through the YAML configuration
contract. Build the SDK with the appropriate Cargo feature, declare the
provider in `configurations[]`, and the runtime auto-wires the
implementation. No per-user HTTP code.

## Supported providers

| Provider              | `provider:` value(s)                                   | Cargo feature        | Service                             |
| --------------------- | ------------------------------------------------------ | -------------------- | ----------------------------------- |
| OpenAI Moderation     | `openai_moderation`                                    | `openai-moderation`  | OpenAI `/v1/moderations`            |
| Azure Content Safety  | `aacs`, `azure_content_safety`, `microsoft.azure.content_safety` | `aacs`               | Azure AI Content Safety             |
| Google Perspective    | `perspective`                                          | `perspective`        | Jigsaw / Google toxicity analysis   |
| Lakera Guard          | `lakera_guard`, `lakera`                               | `lakera-guard`       | Prompt-injection & content safety   |
| Llama Guard           | `llama_guard`                                          | `llama-guard`        | Meta Llama Guard (self-hosted)      |
| Custom HTTP           | *(omit provider, supply `endpoint:`)*                  | `http`               | Any §11.12.4-shaped HTTP endpoint   |

All bundled providers live under
`sdk/rust/agent_shield_core/src/classifiers/`. They share a common
fail-closed contract: any HTTP error, malformed body, missing
decision field, or unrecognized response shape surfaces as
`Err(reason)` from the `ClassifierCaller` trait, which the
GuardPolicyEngine folds into a `BLOCK` verdict per §11.12.4 ¶3.

## Quick start (Rust)

```toml
[dependencies]
agent_shield_core = { git = "https://github.com/microsoft/AgentShield", tag = "v<version>", features = ["lakera-guard"] }
```

```yaml
# .guardrails.yaml
configurations:
  - id: "lakera"
    type: classifier
    provider: "lakera_guard"
    api_key_env: "LAKERA_GUARD_API_KEY"
    category_thresholds:
      prompt_injection: 0.8
      jailbreak: 0.7

input_validation:
  guard_policies:
    - name: "lakera_input"
      evaluate_when:
        - classifier:
            configuration: "lakera"
          reason: "Lakera Guard flagged the user input."
      action: "block"
```

```bash
export LAKERA_GUARD_API_KEY=...
# Build the runtime; the auto-wire path detects the LLM and classifier
# configurations and installs HTTP-backed providers automatically.
```

## Quick start (Python / Node / .NET)

The bundled providers live in the core. The Python wheel
(`maturin develop --features lakera-guard,openai-moderation`), the
Node native module (build the napi crate with the same feature
flags), and the .NET native lib (build `agent_shield_core` with the
features and copy the resulting `libagent_shield_core.so` /
`agent_shield_core.dll` into your runtime) all pick up the same
provider catalog. No per-language HTTP plumbing.

## Per-category thresholds

`category_thresholds:` maps category names to their fail thresholds
(0.0 – 1.0 for score-based providers, 0/2/4/6 normalized to 0.0/0.33/0.66/1.0
for AACS severities). When the map is non-empty:

* Only listed categories are monitored.
* Unlisted high scores cannot trigger the verdict via the global
  `threshold:` field.
* The §11.12.4 verdict surfaces the highest-scoring listed category
  as `label`.

When `category_thresholds:` is empty / unset:

* The provider's native flagging signal forces a deny independent
  of the threshold.
* The maximum category score is compared to the global `threshold:`.

## Writing your own provider

If your service isn't in the bundled list, leave `provider:` unset
and supply an explicit `endpoint:` returning a §11.12.4 envelope —
the generic HTTP path in `DefaultDelegateDispatcher::dispatch_classifier`
handles that case. For deeper control, implement
`agent_shield_core::guard_policy_runtime::ClassifierCaller` directly
and register it on `RuntimeBuilder::register_classifier_caller`. The
host-supplied implementation always takes precedence over the
auto-wired bundled providers.

## Spec references

* §6.2 — `configurations[]` routing matrix
* §11.12.4 — classifier verdict envelope
* §12.5.1 / §12.9 — `evaluate_when[].classifier:` detection
* `docs/security-model.md` — fail-closed guarantees
