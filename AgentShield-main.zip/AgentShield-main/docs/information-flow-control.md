# Information Flow Control: Design

The companion document `information-flow-control-proof.md` states
what is guaranteed. This document states how it is configured.

## 1. Overview

Agent Shield supports Information Flow Control (IFC): a runtime
mechanism that tracks how data moves between tools and refuses to
admit egress from a session whose accumulated exposure exceeds the
target sink's clearance. The mechanism complements the declarative
guard-policy system with a mathematically provable security
guarantee against the data-exfiltration attack class (§3).

When configured, the runtime maintains a single running exposure
per session, raises it on every recorded read of a tagged source,
and denies any egress to a sink whose declared clearance is
incompatible with the current exposure. The protection is
systematic: authors do not write per-pair deny rules. It falls
out of the declared resource labels.

If no `ifc:` block is declared, IFC is disabled and the runtime
behaves identically to a configuration without IFC support. To opt
in, declare a tag universe and label resources (§4).

## 2. Table of Contents

1. Overview
2. Table of Contents
3. Threat Model
4. The Primitive
5. Why this primitive
6. Mathematical equivalence
7. Audience and clearance: two separate fields
8. Independent compartments
9. Hierarchies as derived shapes
10. YAML sugar
11. Implementation
12. Defaults
13. Host capabilities
14. Closed tag universe and load-time validation
15. Composability
16. Stage hooks
17. Declassification
18. Worked example
19. Out of scope
20. Honest scope
21. References

## 3. Threat Model

IFC defends against the class of attacks in which data from a
trusted, sensitive, or restricted source flows through the agent
to an unauthorized destination. Examples:

- An untrusted email contains a prompt injection that causes the
  agent to leak the user's contacts via a malicious URL in a Teams
  message.
- A coding agent reads a private GitHub repository, then is
  tricked into posting the contents as a comment on a public
  issue.
- A document agent reads a confidential customer record, then is
  asked to summarize it via an external API call that logs the
  input.
- A bank-assistant agent reads a customer's account balance and
  is induced to send it to an attacker-controlled email address.

Pattern matching, classifiers, and LLM-based validators catch
many of these heuristically. A sufficiently novel rephrasing
evades them. IFC catches them deterministically by tracking what
kinds of data have been read and refusing to write to incompatible
destinations. The protection is enforced by the runtime at every
gated boundary. The author does not need to predict every
(sensitive_source, leaky_sink) pair.

The accompanying proof states this guarantee formally as
coarse-grained noninterference (CGNI) under an explicit-flow
attacker model. See the proof's §3 for the property and §4.6 for
the ten side conditions (TC-1 through TC-10) on which the
guarantee depends.

## 4. The Primitive

A closed tag universe `T` declared once at config-load time. Three
policy functions over tag sets:

- `λ : Source → 2^T`. The tags carried by data returned from a
  source.
- `μ : Sink → 2^T`. The tags a sink will accept in its arguments.
- `ν : Sink → 2^T`. The clearance an observer must hold to see the
  sink's effects (distinct from `μ`; see §7). Read directionally:
  `ν = ∅` means no clearance required (publicly observable).
  `ν = T` means top clearance required (fully restricted).
  External email is `ν = ∅`. An internal-only audit log is
  `ν = T`.

The runtime keeps one running exposure per scope: a tag set that
grows by union and is checked by subset.

```yaml
ifc:
  tags: [pii, financial, source_code, internal]
  user_input_tags: []                    # confidentiality-irrelevant by default
  user_output_clearance: []              # fail-closed at the user boundary
  default_clearance: []                  # fail-closed for tool/endpoint/agent sinks
  default_audience: []                   # fail-closed for confidentiality
  scope: per_session
  strict: true

resources:
  tools:
    - name: read_customer_balance
      tags: [pii, financial]
      audience: ["*"]
      clearance: []
    - name: send_email_external
      clearance: []
      audience: []
    - name: read_repo_source
      tags: [source_code, internal]
      audience: [source_code, internal]
    - name: write_audit_log
      clearance: [pii, financial, source_code, internal]
      audience: [pii, financial, source_code, internal]
```

Runtime data: `exposure: BitSet<|T|>`. Read = `exposure |= source.tags`.
Egress = `exposure.is_subset(&sink.clearance)`. Both operations are
O(1) on a fixed-width bitset.

## 5. Why this primitive

The project owner's algebraic argument: the map from read-sequences
to `L` is a monoid homomorphism that factors through the
commutative-idempotent quotient. The free commutative-idempotent
monoid on a generating set `T` is `(2^T, ∪, ∅)`. This is the most
expressive carrier compatible with commutative-idempotent reads.

The algebra does not force the powerset choice. Any chosen
join-semilattice is a quotient (homomorphic image) of `2^T`. The
claim is that picking anything narrower (a linear chain, a custom
poset) gives strictly less expressiveness, and is recoverable as
a quotient if needed (§9).

A linear chain like `[public, internal, secret]` with rank
arithmetic is such a quotient: it embeds tag sets as ranks but
cannot represent incomparable tag pairs. PII and source-code are
independent dimensions. Forcing them onto a total order
(`pii < source_code` or `source_code < pii`) is a fake ordering
authors will get wrong.

## 6. Mathematical equivalence

The structure `(2^T, ⊆, ∪, ∅, T)` is a complete distributive
lattice and in particular a bounded join-semilattice. The proof
obligations from the companion document are stated against an
arbitrary join-semilattice `L` and instantiated here at `L = 2^T`.
The proof is directly applicable. Nothing in it depends on `L`
being a chain.

| Operation | Lattice | Tag-set | Bitset op |
|-----------|---------|---------|-----------|
| order     | `ℓ₁ ⊑ ℓ₂` | `ℓ₁ ⊆ ℓ₂` | `(a & !b) == 0` |
| join      | `ℓ₁ ⊔ ℓ₂` | `ℓ₁ ∪ ℓ₂` | `a \| b` |
| bottom    | `⊥`     | `∅`     | `0` |
| top       | `⊤`     | `T`     | `(1 << \|T\|) - 1` |

Every theorem in the proof transfers. The symbols `⊑`, `⊔`, `⊥`,
`⊤` are mechanical aliases for `⊆`, `∪`, `∅`, `T`.

## 7. Audience and clearance: two separate fields

A sink (or a source: every resource is potentially both) has two
orthogonal properties that authors often conflate.

- `μ(k)`: what data `k` will accept in its arguments.
- `ν(k)`: who can see `k`'s effects (and, for sources, who can see
  the return value).

External email is the canonical example. A deployment may decide
email internals are tagged-data-aware and accept `[pii, financial]`
(`μ = {pii, financial}`), but the email itself, once sent, is
visible to anyone reading it (`ν = ∅`). A sink that accepts high
data but broadcasts to a low audience is exactly the leak the
lattice prevents.

The runtime enforces two compatibility checks at config-load time
(proof TC-8, TC-9):

1. `μ(k) ⊆ ν(k)`. A sink cannot accept data tagged at a level its
   audience is not cleared to see.
2. `λ(s) ⊆ ν(s)`. A source cannot return data (or have observable
   side-effects) tagged at a level its audience is not cleared to
   see. If a source has side-effects observable at a lower
   audience than its return value (a tool whose call is logged to
   a public journal but whose return value is high), authors must
   split it into two resources or use the broader `ν(s)`.

Where `ν` is omitted the runtime defaults to `∅` (publicly
observable; the conservative default). Most resources will need
either an explicit `audience:` declaration or `clearance: []` and
`tags: []` (i.e. they handle only public data).

The user output channel is hard-coded to `ν(user_output) = ∅`: the
user is the most permissive audience for confidentiality purposes.

The security guarantees treat the LLM and every tool as a fixed
nondeterministic transducer for the duration of the analysis (proof
TC-10). Real deployments using a remote LLM with continuous model
updates do not satisfy this strictly. The property holds at any
given moment of fixed model state. Deployments requiring the formal
guarantee against drift must pin model versions.

## 8. Independent compartments

`pii` and `source_code` are unrelated tags. Reading a `[pii]`-tagged
source raises exposure to `{pii}`, which is properly incomparable
to a `[source_code]`-cleared sink: `{pii} ⊆ {source_code}` is
false, and `{source_code} ⊆ {pii}` is also false. A linear chain
cannot express this without falsely ordering one above the other.

### Worked example A: diagonal flow

```
read(read_customer_balance)              ⇒  exposure = {pii, financial}
egress(write_audit_log)
  with clearance = [pii, financial, source_code, internal]
                                         ⇒  {pii,financial} ⊆ {pii,financial,…}  ✓ admitted
egress(send_email_external)
  with clearance = []                    ⇒  {pii,financial} ⊆ ∅                  ✗ denied
```

### Worked example B: incomparable sinks

```
read(read_repo_source)                   ⇒  exposure = {source_code, internal}
egress(send_to_pii_compliant_archiver)
  with clearance = [pii, financial]      ⇒  {source_code,internal} ⊆ {pii,financial}  ✗ denied
```

The source-code is not PII-cleared. The lattice correctly rejects
because the tag sets are incomparable.

## 9. Hierarchies as derived shapes

A linear chain `[public, internal, secret]` is recovered by
declaring two tags and using the prefix-closure convention:

```yaml
ifc:
  tags: [internal, secret]
resources:
  tools:
    - name: t_internal
      tags: [internal]
      audience: [internal]
    - name: t_secret
      tags: [internal, secret]
      audience: [internal, secret]
    - name: external_sink
      clearance: []
      audience: []
    - name: internal_sink
      clearance: [internal]
      audience: [internal]
    - name: secret_sink
      clearance: [internal, secret]
      audience: [internal, secret]
```

This recovers `public ⊑ internal ⊑ secret` exactly:
`∅ ⊆ {internal} ⊆ {internal, secret}`. Authors who want more
structured hierarchies declare named profiles (§10).

## 10. YAML sugar

Supported:

- `clearance: ["*"]`, `audience: ["*"]`, `tags: ["*"]`. Explicit
  overrides meaning `= T`. Useful for trusted internal logging
  sinks. These are not defaults. Per-resource opt-in only.
- Named profiles. `ifc.profiles: { secret_profile: [pii, financial, source_code, internal] }`.
  Resource entries can then write `clearance: secret_profile` and
  the loader expands to the tag set. Purely syntactic. Profiles
  must reference declared tags.

The schema does not accept `forbidden_tags` as a primary
primitive. Specifying sinks by what they reject fails open when a
new tag is introduced and old sinks aren't updated to forbid it.
Clearance (allowed-tag-set) fails closed under the same drift: a
sink that declares `clearance: [pii]` will reject any future
`financial` tag without the author touching the file.

## 11. Implementation

```rust
pub struct TagSet(u64);    // up to 64 tags; expand to a small Vec<u64> beyond that

impl TagSet {
    pub fn is_subset(self, other: TagSet) -> bool {
        (self.0 & !other.0) == 0
    }
    pub fn union(self, other: TagSet) -> TagSet {
        TagSet(self.0 | other.0)
    }
    pub const EMPTY: TagSet = TagSet(0);
}
```

Storage on the session is `Mutex<TagSet>`. Read raises by `|=`.
Egress check is `is_subset`. All operations are O(1).

Resource fields:

```rust
pub struct ToolResource {
    pub name: String,
    pub tags: TagSet,           // λ(this)
    pub clearance: TagSet,      // μ(this)
    pub audience: TagSet,       // ν(this)
    // ... existing fields ...
}
```

## 12. Defaults

| Field | Default | Rationale |
|-------|---------|-----------|
| `ifc.tags` | required | The closed universe must be enumerated. |
| `ifc.user_input_tags` | `∅` | User input is confidentiality-irrelevant by default. Integrity is a separate concern (§19). |
| `ifc.user_output_clearance` | `∅` | The user is the most general audience; only public data leaves to the user. |
| `ifc.default_clearance` | `∅` | Every sink must explicitly opt into accepting tagged data. |
| `ifc.default_audience` | `∅` | Every sink is treated as publicly observable unless tightened. Conservative for confidentiality (TC-8 and TC-9 then bite hard, forcing explicit declarations). |
| `ifc.scope` | `per_session` | Only `per_session` is safe without host capability declaration; see §13. |
| `ifc.strict` | `true` | Omitted `tags:` on a resource is a load-time error. Set to `false` to demote to a warning. |
| `ifc.unsafe_default_clearance_top` | `false` | Setting `ifc.default_clearance: ["*"]` is rejected at config-load time unless this flag is also set. |
| resource `tags` | `∅` if explicit; in `strict` mode, omitted is a load-time error | Sources are fail-open by default value (otherwise everything is sensitive and nothing flows), but `strict` mode forces authors to declare an explicit `tags:` on every resource so silent IFC bypass via "I forgot" is impossible. |
| resource `clearance` | `ifc.default_clearance` (= `∅`) | Inherits the global fail-closed default. |
| resource `audience` | `ifc.default_audience` (= `∅`) | Conservative: sink is publicly observable unless tightened. |

The `tags: ∅` default for sources is the only fail-open path in
the system, and even it is gated by `strict` mode. Production
guidance: keep `strict: true`, declare `tags:` explicitly on every
resource (even `tags: []` for known-public sources), declare
`audience:` explicitly on every sink that should not be public.
The strict-mode discipline makes "I forgot to label" impossible at
config-load time.

## 13. Host capabilities

Some scope choices depend on the host's actual capabilities, which
the runtime cannot verify directly. Hosts declare capabilities at
runtime build time.

| Capability | Required for | Semantics |
|------------|--------------|-----------|
| `supports_context_reset` | `ifc.scope: per_turn` and `ifc.scope: per_request` | Host genuinely tears down the LLM context at the boundary (fresh chat-completion thread, clean message history derived only from low data). Hosts that retain memory across turns (LangChain memory, AutoGen group chats, conversation IDs that persist across the SDK boundary) MUST NOT set this. |

Configurations that require an unset capability are rejected at
config-load time with a precise error.

## 14. Closed tag universe and load-time validation

`ifc.tags` is exhaustively enumerated at config-load time. Every
reference to a tag name in a `tags:`, `clearance:`, or `audience:`
field is resolved against this set. Unknown names are load-time
errors with precise paths. This eliminates an entire category of
typo-driven silent-IFC-bypass bugs.

A configuration that uses `tags:`, `clearance:`, or `audience:`
anywhere without declaring an `ifc:` block is also a load-time
error. Missing `ifc:` is treated as "IFC disabled" (the trivial
1-element lattice; every check no-ops). Disabled IFC plus tag
references is unambiguous misconfig.

## 15. Composability

In an `extends:` chain, only one file may declare `ifc:`. The
trusted base for `λ`, `μ`, and `ν` must be unambiguous. The
runtime cannot reason about a label set that silently changes
between the base and the leaf config. Multi-declaration is a
load-time error.

`tags:`, `clearance:`, and `audience:` on resources are additive
across the chain under existing resource-merge rules. Same-name
resources merge last-wins per field. A resource introduced in a
later file participates in IFC just like one declared in the file
that owns the `ifc:` block.

## 16. Stage hooks

| Stage | Hook | IFC effect |
|-------|------|------------|
| 1. input | `validate_input` | on admit: `exposure |= ifc.user_input_tags` |
| 2. state | `validate_state` | (no IFC effect) |
| 3. tool exec | `validate_tool_call` / `validate_endpoint_call` / `validate_agent_call` | `exposure ⊆ μ(target)` check before policy work; deny with `<ifc>` policy verdict on fail |
| 4. post-tool | `record_tool_success` / `record_endpoint_success` / `record_agent_success` | on admit: `exposure |= λ(target)` |
| 5. output | `validate_output` | `exposure ⊆ μ(user_output)` check before policy work; deny on fail |

Plus scope-boundary resets (proof TC-3):

| Boundary | Behaviour |
|----------|-----------|
| `end_turn` (and `ifc.scope == per_turn`, host advertises `supports_context_reset`) | `exposure = ∅` |
| `end_request` (and `ifc.scope == per_request`, host advertises `supports_context_reset`) | `exposure = ∅` |
| `close` / session disposal (and `ifc.scope == per_session`) | `exposure = ∅` |

## 17. Declassification

A guard policy may invoke a registered declassifier via a
`declassify_to:` action verb at a named lifecycle boundary:

```yaml
state_validation:
  guard_policies:
    - name: end_of_turn_summary_release
      active_if: "true"
      evaluate_when:
        - expression: "not event.fired('turn.end')"
          on_allow:
            action: declassify_to
            via: pii_summarizer       # named, registered declassifier
            label: []                 # ℓ′: target exposure after declassification
```

The runtime enforces:

1. `via` references a registered declassifier (TC-5).
2. `label` (the target `ℓ′`) satisfies `ℓ′ ⊆ E` at the moment of
   invocation (the structural pre-condition).
3. Invocation is at a named lifecycle boundary. No ad-hoc
   declassification from arbitrary expressions.
4. Every invocation emits an `ifc.declassified` audit event.

The runtime does not verify the release contract `ρ_δ` of the
declassifier or the operational context-replacement discipline
(TC-5 in the proof). Both are the designer's proof obligation per
declassifier:

1. **Release function correctness.** `ρ_δ` must depend only on
   the designer-authorised projection of its input at the target
   level. The deployment is responsible for proving this property
   of each registered declassifier.
2. **Context replacement.** Declassification lowers `E`, but the
   runtime cannot directly remove the original high values from
   the LLM's context. The registered declassifier must
   operationally replace or remove the high portion of context
   (typically by host-supplied context rewriting, e.g., the LLM's
   message history is rewritten so the secret value is replaced
   by the redacted summary). Without this, the high content
   remains in context and subsequent low-observable egresses may
   leak it even though the gate passes.

Composition of declassifiers is an auditable concern (proof
§4.5.4). Chains may compose into laundering attacks if the
registered set is not carefully reviewed. A deployment seeking
formal anti-laundering should constrain its registered set so
that no two declassifiers can chain without the composite being
explicitly registered with its own release contract.

The conservative return-label and internal-derivation rules
(proof §2.5) mean that once exposure rises into "high" territory,
subsequent admissibility checks become more conservative.
Authors may need to declassify earlier and more often than they
expect. This is the price of coarse current-label IFC.

## 18. Worked example

A complete configuration with three tags, five resources, and a
declassification policy lives at
[`examples/policies/ifc-email-assistant.yaml`](../examples/policies/ifc-email-assistant.yaml).
See its `README.md` for the YAML, three full traces (allowed flow,
denied flow, declassified flow), and the side-conditions the
example assumes.

A second case: a coding agent reading a private GitHub repository
and being tricked into posting the contents as a comment on a
public issue. Label `read_private_repo` with
`tags: [source_code, internal]` and `post_public_issue_comment`
with `clearance: []` and `audience: []`. The flow
`{source_code, internal} ⊆ ∅` denies the comment automatically.
The author did not write a specific rule for the GitHub leak.

## 19. Out of scope

The following are deliberately not part of v1.

- **Integrity labels.** Confidentiality only.
  Prompt-injection-as-integrity-attack (the agent reads
  attacker-controlled text and is tricked into deleting records)
  is not addressed by this lattice. Use guard policies,
  classifiers, predicates. Adding integrity labels is genuine
  future work and is achievable.
- **Per-variable taint.** The proof labels sources and sinks, not
  values. Adding per-value taint reintroduces the
  bound-argument-substitution attack class the project owner
  ruled out.
- **Static analysis of guard expressions.** This is a runtime
  monitor.
- **Principal hierarchies.** The DLM-style decentralised model is
  out of scope for v1.
- **Termination-insensitive noninterference (TINI).** The proof
  states possibilistic CGNI, not TINI. Reasoning about LLM
  termination behaviour requires modelling internals that the
  opaque-LLM threat model excludes. Not achievable in this
  setting.
- **Probabilistic noninterference.** The proof uses possibilistic
  NI. Attackers with statistical models of LLM sampling
  distributions may infer more than a single-trace attacker. Not
  achievable in this setting.
- **Side channels.** Timing, retry behaviour, blocked-attempt
  observation. Not achievable in any deployment that talks to
  remote LLM or tool APIs.
- **Implicit flows through the LLM.** Training-time leakage,
  learned associations, control-flow channels through the LLM.
  Not achievable without changing the threat model.
- **Declassifier-composition safety.** Theorem 2 holds for the
  registered set as given. Composition is an audit concern.
  Achievable as future work via constrained declassifier sets.

Of these, two (integrity labels, declassifier-composition safety)
are achievable as v2 work. The remaining four (TINI, probabilistic
NI, side channels, implicit flows) are fundamental limits of
running IFC over an opaque LLM that talks to external APIs.

## 20. Honest scope

This design implements coarse dynamic no-write-down IFC for
mediated agent effects. It is provably sound for the explicit-flow,
mediated-effect, low-observer attacker model under the side
conditions enumerated in `information-flow-control-proof.md` §4.6.
It is not full TINI. It is not a substitute for the existing
guard-policy machinery for integrity concerns. It relies on the
host honouring the wrapped-surface contract (TC-2) and the host
capability declaration for sub-session scope resets (TC-3).

When configured per the production guidance (`default_clearance: []`,
`default_audience: []`, `scope: per_session`, `strict: true`,
registered declassifiers only at named lifecycle boundaries,
`audience` labels declared on observable sinks), it gives a
defensible runtime IFC guarantee for an agent runtime with an
opaque LLM core.

## 21. References

### In this repository

- [`information-flow-control-proof.md`](./information-flow-control-proof.md):
  the formal compliance proof against coarse-grained
  noninterference, including the ten side conditions on which the
  runtime guarantee depends.
- [`examples/policies/ifc-email-assistant.yaml`](../examples/policies/ifc-email-assistant.yaml):
  worked configuration with three tags, five resources, a
  declassification policy, and three full execution traces.
- [`spec/schema/guardrails.schema.json`](../spec/schema/guardrails.schema.json):
  the canonical JSON Schema for the `ifc:` block and the `tags`,
  `clearance`, `audience` resource fields.
- [`sdk/rust/agent_shield_core/src/ifc.rs`](../sdk/rust/agent_shield_core/src/ifc.rs):
  reference implementation (`TagSet`, `TagUniverse`, `IfcSpec`,
  `CompiledIfc`, `ScopePolicy`).
- [`sdk/rust/agent_shield_core/tests/ifc_runtime.rs`](../sdk/rust/agent_shield_core/tests/ifc_runtime.rs):
  runtime behaviour tests covering each TC.

### Literature

- Stefan, Russo, Mitchell, Mazières (2011). *Flexible dynamic
  information flow control in Haskell.* The closest model: a
  current label tracked dynamically against a join-semilattice.
  Agent Shield diverges by labelling sources and sinks rather
  than values.
- Myers and Liskov (2000). *Protecting privacy using the
  decentralized label model.* Confidentiality-only restriction
  with a single principal hierarchy is the special case Agent
  Shield's tag-set carrier instantiates.
- Sabelfeld and Myers (2003). *Language-based information-flow
  security.* The general framework Agent Shield's possibilistic
  noninterference and delimited-release declassification
  semantics follow.
- Sutherland (1986). The original possibilistic-noninterference
  formulation, adopted in §2.6 of the proof.
