# AGENTS.md — Agent Guidelines for Agent Shield

## Repository Overview

Agent Shield is an open specification and reference implementation for securing agentic AI systems. The current spec is **v2.0.0-alpha** (the unified-resolver / unified-guard-policy model); the SDKs are at version **0.13.0**.

## Architecture

```
spec/                ← Specification documents (SPECIFICATION.md, expressions/LANGUAGE.md, schema/)
sdk/                 ← SDK implementations (rust, python, node, dotnet)
examples/            ← Example integrations and demo agents
deploy/              ← Deployment configurations (docker, kubernetes)
docs/                ← Documentation (migration guide, asset images)
tests/               ← Cross-language fixtures and integration tests
```

## Key vocabulary

When reasoning about this codebase, use the vocabulary:

- **variable** (not "attribute") — typed runtime state with metadata envelope.
- **predicate** — named, side-effect-free expression.
- **resolver** — the unified gate; five kinds (`tool`, `human`, `delegate`, `expression`, `agent`); returns `{decision, value, set_variables, reason}`.
- **`HumanResolver`** (not "approval handler").
- **`guard_policies[]`** (not `policies[]`, not state-specific shapes) — the unified per-stage schema.
- **`evaluate_when[].expression`** is the resolution site (along with `allowed_when:`); `active_if` is non-resolving.
- **closed event namespace** — `session.* | turn.* | request.* | tool.* | endpoint.* | agent.* | variable.* | guard_policy.* | approval.* | incident.<name>`. Anything else is a load-time error.

## Agent Permissions

- **May modify**: `sdk/`, `examples/`, `docs/`, `tests/`
- **May not modify**: `spec/` (specification changes require formal review process)
- **Requires human approval**: changes to the specification, security-critical SDK code

## Safety Rules

- Never hardcode secrets or credentials.
- Never auto-commit — all changes require human review.
- Never modify files outside the defined scope.
- Specification changes follow the project's RFC process.
- Security-sensitive code requires additional review.
- Preserve the **fail-closed null semantics** of the expression language. Missing variables → `null` → `false` in boolean context. This is a security invariant.

## Build & Test

Check README.md and QUICKSTART.md for current build and test commands. Cross-language integration fixtures live in `tests/fixtures/smoke/`.

## SDK ↔ Rust core boundary (settled)

The canonical statement of this boundary is in `.github/copilot-instructions.md` under "SDK ↔ Rust core boundary". Two points are important enough to call out here too, because past audits have repeatedly mis-flagged them:

1. **Verdict-handling decisions (block-message formatting, stage/tool verdict dispatch, `OnBlockPolicy`) live in core** and are exposed via FFI as `shield_format_block_message`, `shield_dispatch_stage_verdict`, `shield_dispatch_tool_verdict`. The SDKs *only* call these — they do not reimplement them. Verify by `grep`ping the SDK file for those symbols before claiming duplication.

2. **The async state machine that calls Stage 1 → execute → Stage 5 stays in the SDK.** This is documented at `sdk/rust/agent_shield_core/src/shield_primitives.rs:1-13`. Reason: driving a host language's async runtime from Rust through FFI forces one event-loop choice on every customer and breaks the framework-agnostic claim. Ambient-session propagation across `await` (Python `contextvars`, Node `AsyncLocalStorage`, .NET `AsyncLocal<T>`) is also a host-runtime feature with no FFI equivalent.

If an audit proposes "move SDK orchestration into the Rust core," read `shield_primitives.rs:1-13` first and check whether the proposal would require Rust to own the host's event loop. If yes, the proposal is wrong.
