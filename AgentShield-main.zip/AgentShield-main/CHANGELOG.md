# Changelog

All notable changes to Agent Shield are documented in this file.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/) once
the v1.0.0 spec freezes. While the spec is at `1.0.0-draft` and the SDKs
are pre-1.0, breaking changes may land in any release; each is called out
explicitly in the **Breaking changes** section below.

## [Unreleased]

### Breaking changes

- **Section 16.0 mandatory invocation binding.** The optional
  `tool_call_id` parameter on `validate_tool_call`, `validate_endpoint_call`,
  `validate_agent_call`, and `validate_tool_output` is now **required**
  across every conforming SDK surface and the underlying Rust core /
  FFI. The previous `*_with_id` siblings have been removed; the short
  names now own the contract. Adapters MUST mint a stable
  per-invocation id (UUID, atomic counter, or framework-supplied
  handle) and thread it through the matching Stage 3 → Stage 4 pair.
  This closes a fail-open path where an unbound Stage 3 admit could
  pair with an unbound Stage 4 validation against a different
  canonical invocation. Callers using positional `validate_*` /
  `protect_tool` / `protectTool` / `ProtectTool` / `ProtectToolOutput`
  arguments must update their call sites; the id is now positional
  before the trailing keyword-only / options argument.

- **Python proxy surface removed.** The non-functional `agent_shield.proxy`
  package, the `[proxy]` extras, the `agent-shield-proxy` console
  script, the `deploy/docker/Dockerfile.proxy` image, and the K8s
  sidecar walkthrough in `deploy/README.md` and `docs/security-model.md`
  have been deleted. v1.0 conformance is in-process only; out-of-process
  deployment shapes (sidecars, gateways, supervising proxies) remain
  a future extension and are explicitly outside the v1.0 surface.

### Notes

- This file was added so the `Changelog` URL declared in
  `sdk/python/pyproject.toml` resolves on PyPI.

