"""Validation gate — routes through the Rust core via the Python facade.

Every entry point eagerly accesses ``CompiledPolicy._native_handle``
so the loader actually runs. Without that touch, ``compile()`` only
constructs a wrapper and validation is silently skipped.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

from agent_shield.config import GuardrailsConfig


class ValidationError(RuntimeError):
    """Raised when a proposed scaffold fails spec validation."""


def _force_compile(cfg: GuardrailsConfig) -> None:
    compiled = cfg.compile()
    _ = compiled._native_handle  # noqa: SLF001 — eager trigger


def validate_standalone(data: Dict[str, Any]) -> None:
    try:
        _force_compile(GuardrailsConfig.from_dict(data))
    except Exception as exc:
        raise ValidationError(str(exc)) from exc


def validate_with_parent(parent_path: Path, child_dict: Dict[str, Any]) -> None:
    """Validate a child against an on-disk parent via the extends chain.

    ``child_dict`` MUST NOT carry ``extends:`` — string/value loaders
    reject it; only path-based loads resolve extends.
    """
    if "extends" in child_dict:
        raise ValidationError(
            "child dict passed to validate_with_parent must not carry an "
            "`extends:` key; that's resolved on disk via the parent path."
        )
    try:
        parent = GuardrailsConfig.load(str(parent_path))
        _force_compile(parent.extend(child_dict))
    except Exception as exc:
        raise ValidationError(str(exc)) from exc


def validate_on_disk(path: Path) -> None:
    try:
        _force_compile(GuardrailsConfig.load(str(path)))
    except Exception as exc:
        raise ValidationError(str(exc)) from exc


def parent_tool_names(parent_path: Optional[Path]) -> List[str]:
    """Best-effort extraction of every tool name declared (transitively)
    by the parent's ``extends`` chain.

    The Python facade's ``CompiledPolicy.yaml_strings`` only carries
    the *direct* file text for path-based loads, not the resolved
    extends chain (the merge happens in the Rust core). So we walk
    the chain ourselves at the YAML level, starting from
    ``parent_path`` and following every ``extends:`` entry relative
    to its declaring file. Visited paths are tracked to make a
    cyclic chain a no-op rather than a hang.

    Compiles ``parent_path`` first as a fail-fast — if the parent
    chain is broken, surface that before any LLM tokens are spent.
    The collected names are advisory (the LLM is told to avoid
    redeclaring them); the loader still has the final say at compile
    time.
    """
    if parent_path is None:
        return []
    try:
        cfg = GuardrailsConfig.load(str(parent_path))
        compiled = cfg.compile()
        _ = compiled._native_handle  # noqa: SLF001 — eager validation
    except Exception as exc:
        raise ValidationError(
            f"could not load parent file {parent_path}: {exc}"
        ) from exc

    import yaml as _yaml

    names: List[str] = []
    visited: set[Path] = set()
    queue: List[Path] = [parent_path.resolve()]

    while queue:
        current = queue.pop(0)
        if current in visited or not current.exists():
            continue
        visited.add(current)
        try:
            doc = _yaml.safe_load(current.read_text(encoding="utf-8"))
        except (_yaml.YAMLError, OSError):
            continue
        if not isinstance(doc, dict):
            continue

        resources = doc.get("resources")
        if isinstance(resources, dict):
            tools = resources.get("tools")
            if isinstance(tools, list):
                for entry in tools:
                    if isinstance(entry, dict):
                        name = entry.get("name")
                        if isinstance(name, str) and name and name not in names:
                            names.append(name)

        # Extends paths are spec-defined as relative to the file
        # declaring them (§3.2). Anchor recursion at current.parent.
        extends = doc.get("extends")
        if isinstance(extends, list):
            for raw in extends:
                if not isinstance(raw, str) or not raw:
                    continue
                ref = (current.parent / raw).resolve()
                if ref not in visited:
                    queue.append(ref)

    return names


__all__ = [
    "ValidationError",
    "parent_tool_names",
    "validate_on_disk",
    "validate_standalone",
    "validate_with_parent",
]
