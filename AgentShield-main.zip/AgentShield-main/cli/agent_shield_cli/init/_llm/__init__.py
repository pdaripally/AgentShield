"""LLM provider abstraction for ``agent-shield init``.

The interface is intentionally minimal:

    caller.chat(messages: list[dict]) -> str

where ``messages`` is the OpenAI-style ``[{role, content}, ...]`` shape.
The CLI never streams partial assistant content — it needs a complete
JSON action object per turn before it can dispatch.

Provider modules (``_openai``, ``_anthropic``) implement this protocol
and soft-import their respective client libs so the CLI can give a
clean error message when a library is missing.
"""
from __future__ import annotations

from ._base import LlmCaller, LlmError, build_caller

__all__ = ["LlmCaller", "LlmError", "build_caller"]
