"""OpenAI provider for the design agent.

Uses the official ``openai`` client (already an optional extra in
``pyproject.toml``). The caller blocks until the full assistant turn
is returned — the orchestrator parses one complete JSON action per turn.
"""
from __future__ import annotations

import os
from typing import Dict, List, Optional

from ._base import LlmError


class OpenAiCaller:
    """OpenAI chat-completion caller."""

    name = "openai"

    def __init__(self, *, model: str, api_key: Optional[str] = None) -> None:
        try:
            from openai import OpenAI  # type: ignore[import-not-found]
        except ImportError as exc:  # pragma: no cover - install-time error path
            raise LlmError(
                "the `openai` Python package is required for "
                "`--provider openai`. Install with `pip install agent-shield[openai]` "
                "or `pip install openai`."
            ) from exc

        key = api_key or os.environ.get("OPENAI_API_KEY")
        if not key:
            raise LlmError(
                "OpenAI provider selected but no API key found. Set "
                "OPENAI_API_KEY in the environment or pass --api-key."
            )
        self.model = model
        self._client = OpenAI(api_key=key)

    def chat(self, messages: List[Dict[str, str]]) -> str:
        try:
            response = self._client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=0.2,
                # JSON-mode keeps the LLM output parseable. The design
                # agent's contract is "one JSON object per turn"; this
                # is the cheapest way to enforce it server-side.
                response_format={"type": "json_object"},
            )
        except Exception as exc:
            raise LlmError(f"OpenAI request failed: {exc}") from exc

        try:
            return response.choices[0].message.content or ""
        except (IndexError, AttributeError) as exc:
            raise LlmError(f"OpenAI response had no content: {exc}") from exc


__all__ = ["OpenAiCaller"]
