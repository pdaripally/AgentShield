"""Azure OpenAI provider for the design agent.

Uses the ``AzureOpenAI`` client from the openai library. Azure
deployments differ from public OpenAI in two ways the CLI cares
about:

- The endpoint is per-resource, not ``api.openai.com``.
- The ``model`` parameter in the API call is the *deployment name*,
  not the underlying model name. The CLI keeps the
  ``--model`` flag's surface the same — users pass their deployment.
"""
from __future__ import annotations

import os
from typing import Dict, List, Optional

from ._base import LlmError


class AzureOpenAiCaller:
    """Azure OpenAI chat-completion caller."""

    name = "azure-openai"

    def __init__(self, *, model: str, api_key: Optional[str] = None) -> None:
        try:
            from openai import AzureOpenAI  # type: ignore[import-not-found]
        except ImportError as exc:  # pragma: no cover
            raise LlmError(
                "the `openai` Python package is required for "
                "`--provider azure`. Install with `pip install openai`."
            ) from exc

        key = api_key or os.environ.get("AZURE_OPENAI_API_KEY")
        endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
        api_version = (
            os.environ.get("AZURE_OPENAI_API_VERSION")
            or "2024-12-01-preview"
        )
        if not key:
            raise LlmError(
                "Azure provider selected but no API key found. Set "
                "AZURE_OPENAI_API_KEY or pass --api-key."
            )
        if not endpoint:
            raise LlmError(
                "Azure provider selected but AZURE_OPENAI_ENDPOINT is unset."
            )
        self.model = model  # this is the *deployment* name on Azure
        self._client = AzureOpenAI(
            api_key=key,
            azure_endpoint=endpoint,
            api_version=api_version,
        )

    def chat(self, messages: List[Dict[str, str]]) -> str:
        try:
            response = self._client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=0.2,
                response_format={"type": "json_object"},
            )
        except Exception as exc:
            raise LlmError(f"Azure OpenAI request failed: {exc}") from exc

        try:
            return response.choices[0].message.content or ""
        except (IndexError, AttributeError) as exc:
            raise LlmError(f"Azure OpenAI response had no content: {exc}") from exc


__all__ = ["AzureOpenAiCaller"]
