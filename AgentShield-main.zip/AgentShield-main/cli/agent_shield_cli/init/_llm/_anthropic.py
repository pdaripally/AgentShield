"""Anthropic provider for the design agent.

Uses the official ``anthropic`` client (already an optional extra in
``pyproject.toml``). Translates the OpenAI-style ``messages`` shape
into Anthropic's split ``system`` + ``messages`` API and returns the
assistant's full text reply.
"""
from __future__ import annotations

import os
from typing import Dict, List, Optional

from ._base import LlmError


class AnthropicCaller:
    """Anthropic Messages API caller."""

    name = "anthropic"

    def __init__(self, *, model: str, api_key: Optional[str] = None) -> None:
        try:
            from anthropic import Anthropic  # type: ignore[import-not-found]
        except ImportError as exc:  # pragma: no cover
            raise LlmError(
                "the `anthropic` Python package is required for "
                "`--provider anthropic`. Install with "
                "`pip install agent-shield[anthropic]` or `pip install anthropic`."
            ) from exc

        key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not key:
            raise LlmError(
                "Anthropic provider selected but no API key found. Set "
                "ANTHROPIC_API_KEY in the environment or pass --api-key."
            )
        self.model = model
        self._client = Anthropic(api_key=key)

    def chat(self, messages: List[Dict[str, str]]) -> str:
        # Anthropic separates the system prompt; concatenate any
        # system-role entries from the front of `messages`.
        system_parts: List[str] = []
        rest: List[Dict[str, str]] = []
        for entry in messages:
            if entry.get("role") == "system":
                system_parts.append(entry.get("content", ""))
            else:
                rest.append(entry)
        system_prompt = "\n\n".join(p for p in system_parts if p)

        try:
            response = self._client.messages.create(
                model=self.model,
                system=system_prompt or None,
                messages=rest,
                max_tokens=4096,
                temperature=0.2,
            )
        except Exception as exc:
            raise LlmError(f"Anthropic request failed: {exc}") from exc

        try:
            # Anthropic returns a list of content blocks; we only use text.
            chunks = [
                block.text
                for block in response.content
                if getattr(block, "type", None) == "text"
            ]
            return "".join(chunks)
        except (IndexError, AttributeError) as exc:
            raise LlmError(f"Anthropic response had no text: {exc}") from exc


__all__ = ["AnthropicCaller"]
