"""LLM caller protocol + provider factory."""
from __future__ import annotations

from typing import Dict, List, Protocol


class LlmError(RuntimeError):
    """Raised when the LLM call fails (network, auth, quota, malformed response)."""


class LlmCaller(Protocol):
    """Minimal blocking chat-completion interface."""

    name: str  # provider label, e.g. "openai" / "anthropic" / "mock"
    model: str

    def chat(self, messages: List[Dict[str, str]]) -> str:
        """Send ``messages`` and return the assistant's complete text reply.

        ``messages`` follows the OpenAI shape: a list of
        ``{"role": "system" | "user" | "assistant", "content": str}``.
        Providers may adapt as needed; the orchestrator treats the
        return value as opaque text and parses it for JSON actions.
        """
        ...


def build_caller(*, provider: str, model: str, api_key: str | None = None) -> LlmCaller:
    """Construct a caller for the given provider.

    Raises ``LlmError`` with a clear message when the provider library
    is missing or credentials are absent.
    """
    if provider == "openai":
        from ._openai import OpenAiCaller

        return OpenAiCaller(model=model, api_key=api_key)
    if provider == "anthropic":
        from ._anthropic import AnthropicCaller

        return AnthropicCaller(model=model, api_key=api_key)
    if provider == "azure":
        from ._azure import AzureOpenAiCaller

        return AzureOpenAiCaller(model=model, api_key=api_key)
    raise LlmError(f"unsupported provider: {provider!r}")


__all__ = ["LlmCaller", "LlmError", "build_caller"]
