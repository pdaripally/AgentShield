"""Shared data classes used by the source parsers."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List


class SourceParseError(ValueError):
    """Raised when a tool-source file is malformed or unrecognised."""


@dataclass(frozen=True)
class ToolEntry:
    """One tool's identity, as collected from a source file."""

    name: str
    description: str = ""
    source_label: str = ""           # "mcp" | "openai_function" | "anthropic_tool"
    input_schema: dict | None = None # raw JSON Schema if available


@dataclass
class ParsedMcp:
    """Result of parsing one MCP source file."""

    tools: List[ToolEntry] = field(default_factory=list)
    servers: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)


__all__ = ["ParsedMcp", "SourceParseError", "ToolEntry"]
