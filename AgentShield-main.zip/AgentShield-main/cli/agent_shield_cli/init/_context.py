"""Build the system prompt that primes the design LLM.

Bundles:
  - the full v2 spec (`spec/SPECIFICATION.md`)
  - the JSON schema (`spec/schema/guardrails.schema.json`)
  - the expression-language reference (`spec/expressions/LANGUAGE.md`)
  - two curated example configs (banking + document-DLP)
  - the user's parsed tool list, free-text description, and parent file

The spec is the source of truth — every reasoning step the LLM takes
should ground in it. Total context is ~80–120 KB; trivially fits in
modern frontier models.
"""
from __future__ import annotations

from dataclasses import dataclass
from importlib.resources import files as _resource_files
from pathlib import Path
from typing import Any, List, Optional

from ._sources import LoadedSources, ToolEntry


# Located relative to the repo root. The CLI is shipped with the
# Python package; the spec lives at ``<repo>/spec`` when installed
# from source. We resolve the path by walking up from this file.

_THIS_DIR = Path(__file__).resolve().parent


def _get_spec_root() -> Any:
    """Return a root from which ``spec/`` and ``examples/`` can be read.

    Priority:
    1. Bundled package data (``_data/`` sub-package) — works in wheel
       and editable installs alike.
    2. Walking up the filesystem — legacy fallback for in-repo runs
       where the package is not fully installed.

    Returns a ``Traversable`` (from ``importlib.resources.files``) or
    a :class:`pathlib.Path`.  Both support the ``/`` operator and
    ``read_text()``.
    """
    try:
        data_root = _resource_files("agent_shield_cli.init._data")
        # Probe to confirm the files are actually present (they will be
        # missing if someone removed the _data sub-package by accident).
        data_root.joinpath("spec").joinpath("SPECIFICATION.md").read_text(
            encoding="utf-8"
        )
        return data_root
    except Exception:
        pass

    # Fallback: walk up from this file (source/editable install without
    # the _data package, or running directly from the repo checkout).
    cur = _THIS_DIR
    for _ in range(8):
        if (cur / "spec" / "SPECIFICATION.md").exists():
            return cur
        cur = cur.parent
    raise FileNotFoundError(
        "Could not locate the AgentShield spec files. "
        "`agent-shield init` bundles the spec with the Python package; "
        "if you are seeing this message, the installation may be "
        "corrupted. Try reinstalling: `pip install --force-reinstall "
        "'agent-shield-cli[openai]'`."
    )


def _read(path: Any) -> str:
    return path.read_text(encoding="utf-8")


_CONTENT_FILTER_SUBSTITUTIONS: tuple[tuple[str, str], ...] = (
    # The literal regex used in the document-DLP example — Azure
    # Content Safety's prompt-shield "jailbreak" detector matches it
    # verbatim.
    (
        "ignore.*(?:previous|all|prior).*(?:instructions|rules|guidelines)",
        "<INPUT_ATTACK_REGEX — generate your own pattern appropriate for the deployment>",
    ),
    # Terminology that names the attack. Azure flags prompts that
    # *discuss* prompt-injection / jailbreak even when the prompt is
    # security-tooling documentation. Replacing the words preserves
    # the spec's meaning (we're designing detection for them) without
    # tripping prompt-side content shields. Case-preserving variants
    # listed explicitly so the substitution is verbatim and reversible
    # by a reader.
    ("jailbreak", "input-attack"),
    ("Jailbreak", "Input-attack"),
    ("JAILBREAK", "INPUT_ATTACK"),
    ("Jailbreaks", "Input-attacks"),
    ("prompt injection", "untrusted-input attack"),
    ("Prompt injection", "Untrusted-input attack"),
    ("indirect prompt injection", "indirect untrusted-input attack"),
    ("Indirect prompt injection", "Indirect untrusted-input attack"),
)


def _sanitize_for_content_filters(text: str) -> str:
    """Apply every content-filter substitution to ``text``.

    Production note: Azure OpenAI deployments with default prompt
    shields will reject any prompt that contains literal attack
    strings or even the words ``jailbreak`` / ``prompt injection``.
    Since this CLI ships the AgentShield spec — which legitimately
    describes those concepts as the threats it defends against — we
    rewrite that vocabulary in every piece of embedded content
    (examples, spec, expression-language reference) before stuffing
    into the system prompt. The LLM still understands the intent
    (the substitute terms are unambiguous), and the YAML it produces
    is structurally identical — the orchestrator validates the
    *shape*, not the labels.

    Users on Azure can also reduce friction by lowering the
    content-filter severity on their deployment; this sanitization
    is the conservative-default that keeps the CLI working out of
    the box.
    """
    out = text
    for needle, replacement in _CONTENT_FILTER_SUBSTITUTIONS:
        out = out.replace(needle, replacement)
    return out


@dataclass
class DesignContext:
    """Inputs that shape the system prompt for one design session."""

    tools: List[ToolEntry]
    description: str
    parent_path: Optional[Path]
    parent_tool_names: List[str]
    source_notes: List[str]
    mcp_servers: List[str]

    @classmethod
    def from_inputs(
        cls,
        *,
        sources: LoadedSources,
        description: str,
        parent_path: Optional[Path],
        parent_tool_names: List[str],
    ) -> "DesignContext":
        return cls(
            tools=sources.tools,
            description=description,
            parent_path=parent_path,
            parent_tool_names=parent_tool_names,
            source_notes=sources.notes,
            mcp_servers=sources.mcp_servers,
        )


_HOUSE_STYLE = """\
# House style and minimal-valid skeleton

The spec below is large. To save you re-deriving the structural shape
on every turn, here is a compact reference: a minimal valid file plus
single-snippet illustrations of every pattern you are likely to need.
The full grammar is in the JSON Schema and the spec text after this
section. Do not copy these examples verbatim into your output - they
are illustrative skeletons, not templates.

## Minimal valid `.guardrails.yaml`

```yaml
metadata:
  name: my-agent
  version: 0.1.0
  agent_shield_version: '2.0'   # MUST be quoted - it is a string, not a float
objective:
  goal:
    - "One stated purpose."
  forbidden:
    - "One explicitly disallowed action."
```

## Resources (identity-only catalogue; spec section 13)

```yaml
resources:
  tools:
    - name: read_account
      description: "Read account info."
      permission: read_only       # read_only | read_write | execute | destructive
      protocol: openai_function   # mcp | openai_function | anthropic_tool
    - name: transfer_funds
      permission: destructive     # use destructive for irreversible side effects
      protocol: openai_function
```

## Variables (spec section 9, section 10)

Push form: the variable is populated when a named tool succeeds.

```yaml
variables:
  - name: account_sensitivity
    type: string
    populated_by:
      - kind: tool
        name: read_account
        expression: "@result.account_sensitivity"
```

Pull form: the resolver fires when a gate references the variable
while it is unset. Used for approvals.

```yaml
variables:
  - name: transfer_authorized
    type: boolean
    on_demand_by:
      kind: human
      prompt: "Transfer authorization required. Approve?"
    lifetime: per_call
```

Asymmetric lifetime: an "allow" applies once; a "deny" sticks until
session end. This is the right shape for cautious approvals.

```yaml
variables:
  - name: send_email_authorized
    type: boolean
    on_demand_by:
      kind: human
      prompt: "Approve sending non-public data?"
    lifetime:
      allow: per_call
      deny:
        until_event:
          - session.end
```

Accumulating variables (max for sensitivity tiers, union for tag sets):

```yaml
variables:
  - name: data_sensitivity
    type: string
    update: "max(@current, @incoming)"
    populated_by:
      - kind: tool
        name: read_document
        expression: "@result.data_sensitivity"
  - name: data_jurisdictions
    type: array
    update: "union(@current, @incoming)"
```

## Predicates (named expressions; spec section 8)

```yaml
predicates:
  is_sensitive_account: "account_sensitivity in ['vip', 'high_net_worth']"
  needs_manager_review: "fraud_score >= 50"
```

## Stage 2: state_validation (spec section 15)

`applies_to:` is REQUIRED on every Stage 2 policy. Expressions only.

```yaml
state_validation:
  guard_policies:
    - name: transfer_gate
      applies_to:
        tools: ["transfer_funds"]
      evaluate_when:
        - expression: "not is_sensitive_account or transfer_authorized == true"
          reason: "Sensitive account transfers require approval."
        - expression: "fraud_score < 75"
          reason: "Fraud score exceeds threshold."
```

## Stage 1: input_validation (spec section 14)

```yaml
input_validation:
  guard_policies:
    - name: input_attack_filter
      evaluate_when:
        - pattern: "<INPUT_ATTACK_REGEX - write your own>"
          reason: "Possible input attack detected."
```

## Stage 3: tool_execution_validation (spec section 16)

Pattern detection, no LLM required:

```yaml
tool_execution_validation:
  guard_policies:
    - name: secret_scrub
      action: redact
      replacement: "[SECRET REDACTED]"
      evaluate_when:
        - patterns:
            - "\\\\b(?:sk|pk|api|key)[-_][A-Za-z0-9]{20,}\\\\b"
          reason: "Possible secret in tool arguments."
```

LLM detection (requires a configurations[] entry with a real prompt
file; do not invent prompt file paths):

```yaml
tool_execution_validation:
  guard_policies:
    - name: task_adherence
      evaluate_when:
        - llm:
            prompt: "task_adherence.md"   # must exist on disk
          reason: "Proposed call deviates from objective."
```

## Stage 4: post_tool_validation (spec section 17)

Action enum: block | redact | warn only. No append/prepend.

```yaml
post_tool_validation:
  guard_policies:
    - name: pii_redact
      action: redact
      replacement: "[PII REDACTED]"
      evaluate_when:
        - patterns:
            - "\\\\b\\\\d{3}-\\\\d{2}-\\\\d{4}\\\\b"   # SSN
          reason: "PII detected in tool result."
```

## Stage 5: output_validation (spec section 18)

Same action enum. No applies_to (the response is not tied to a tool).

```yaml
output_validation:
  guard_policies:
    - name: pii_output
      action: redact
      replacement: "[REDACTED]"
      evaluate_when:
        - patterns:
            - "\\\\b\\\\d{3}-\\\\d{2}-\\\\d{4}\\\\b"
          reason: "PII detected in agent response."
```

## Composition (spec section 3.2)

```yaml
extends:
  - "base.guardrails.yaml"
```

Same-name `guard_policies` concatenate across the chain; tools, predicates,
variables merge by name (first declaration wins on name, additive on
contents per spec rules).

## A few shape gotchas the spec calls out explicitly

- `agent_shield_version` is a STRING. Always quote: `'2.0'`, never `2.0`.
- Every `evaluate_when[]` entry needs a `reason:` string.
- Stage 2 policies MUST declare `applies_to:` with at least one of
  `tools` / `agents` / `endpoints` non-empty.
- Top-level YAML keys are exactly: `extends`, `metadata`, `objective`,
  `configurations`, `predicates`, `variables`, `resources`,
  `input_validation`, `state_validation`, `tool_execution_validation`,
  `post_tool_validation`, `output_validation`, `ifc`. Nothing else.
- `summary:` is a sibling JSON field of `yaml:` inside your `done`
  action - not a top-level YAML key in the file you emit.
- Snake_case throughout. The schema rejects camelCase.
- `applies_to.tools: ["*"]` matches every tool, listed or unlisted.
- Tool `protocol:` should follow the `source:` you were given in the
  tool list (`mcp`, `openai_function`, `anthropic_tool`).
"""


_ACTION_CONTRACT = """\
# Output contract

You speak to a Python orchestrator. **Every turn you emit one JSON
object** with one of three shapes:

    {"action": "ask",     "question": "<one focused question for the user>"}

    {"action": "propose", "yaml": "<a YAML snippet — either a complete
                                    .guardrails.yaml file, or a child
                                    file with `extends:` if the user
                                    provided a parent>",
                          "explanation": "<2-4 sentence rationale citing
                                          the spec sections you used>"}

    {"action": "done",    "yaml": "<the final, complete .guardrails.yaml>",
                          "summary": "<what the user should review or
                                       tighten before shipping>"}

Rules:
- **No prose outside the JSON.** The orchestrator parses your reply
  with `json.loads()`. Anything else aborts the run.
- **One action per turn.** Pick the highest-leverage next step.
- **Ask before assuming.** When the tool list or description is
  ambiguous (sensitivity, approval thresholds, what data flows where,
  what counts as "destructive"), `ask` rather than guess.
- **Propose increments early.** Don't wait until you've asked everything
  before showing structure — propose a partial config after you have
  enough to write `metadata`, `objective`, and `resources.tools`, then
  iterate.
- **Always emit a valid YAML body in `yaml`.** Snake_case keys (the
  spec is strict). All `evaluate_when[]` entries need a `reason:`. All
  Stage-2 policies need `applies_to:` with at least one of
  `tools`/`agents`/`endpoints`. The orchestrator runs your proposal
  through the Rust loader before accepting it.
- **Self-correct on errors.** If the orchestrator replies with a
  `validation_error` message, fix the exact issue it cites and emit a
  new `propose`. You have a small retry budget per propose (3); after
  that, the orchestrator will surface the error to the user.
- **`extends:`** — if a parent file was supplied, your final `done`
  YAML MUST start with `extends: [<parent path>]` and MUST NOT
  redeclare tools that already exist in the parent (the orchestrator
  lists them under "Existing parent tools" below).
- **Forbidden actions in the `objective` block** should be specific to
  this agent's domain, not generic ("don't exfiltrate data" is too
  weak). Tie them to the actual tools and data classes the user
  described.
- **Stage 2 is where the real policy lives.** Don't skip it. Identify
  the variables that gate sensitive operations (sensitivity tier,
  approval bit, amount thresholds) and write `state_validation`
  policies that reference them. Use `on_demand_by:` (human, delegate,
  or tool) for approvals.
- **Stage 4 / Stage 5 DLP** patterns belong on data classes the user
  actually handles, not a generic SSN/credit-card grab-bag.
- **`protocol:` follows `source:` on every tool.** When emitting a
  `resources.tools[]` entry, set `protocol:` to match the `source:`
  field shown in "Tools available to the agent" above:
  `openai_function`, `anthropic_tool`, or `mcp`. Do not default to
  `mcp` if the tool came from elsewhere.
- **Do not invent file references.** Stage 3 `llm:` policies require
  a `prompt:` file that exists on disk. The user has not supplied
  any prompt files in this session. So: prefer regex / pattern /
  expression detection at Stage 3 by default, and if you want to
  scaffold an LLM-based Stage 3 policy, emit it COMMENTED OUT in
  the YAML with a `# TODO: provide a prompt file at <suggested-name>.md`
  note. Same rule for `prompt:` paths anywhere else (resolvers,
  classifier descriptions).
- **Self-check before `done`.** Before emitting the `done` action,
  walk your YAML once and verify:
  1. Every variable you declared is referenced somewhere (in a
     predicate, in an `evaluate_when` expression, as the
     `populated_by`/`on_demand_by`/`reset_by` target of another
     element, or as the target of a `set_variables` from a resolver).
     If a variable is declared but unused, REMOVE it.
  2. Conversely: if your gate references `@tool.params.X` directly,
     do not also declare a redundant variable for the same concept.
     Pick one — either declare a variable populated from
     `@tool.params.X` and reference the variable, or reference
     `@tool.params.X` directly without the variable. Don't do both.
  3. Every predicate name used in `evaluate_when` is declared in
     `predicates:`.
  4. Every tool name in `applies_to.tools[]` is declared in
     `resources.tools[]` (or is `"*"`).
  5. `populated_by` is the PUSH form (value flows into the variable
     when the named tool succeeds). `on_demand_by` is the PULL form
     (the named resolver fires when a gate references the variable
     while it is unset). They are different mechanisms — do not use
     the same tool name for both on the same variable unless you
     have specifically designed that round-trip.
"""


def _tool_block(tools: List[ToolEntry]) -> str:
    if not tools:
        return "(no tool definitions supplied — ask the user what tools the agent uses)"
    lines = []
    for t in tools:
        line = f"- name: {t.name}"
        if t.description:
            line += f"\n  description: {t.description}"
        if t.source_label:
            line += f"\n  source: {t.source_label}"
        params = _summarize_schema(t.input_schema)
        if params:
            line += f"\n  params: {params}"
        lines.append(line)
    return "\n".join(lines)


def _summarize_schema(schema: dict | None) -> str:
    """Render a one-line summary of a tool's JSON-Schema parameters.

    Only the top level of ``properties`` is inspected, which is the
    structurally-load-bearing part for ``@tool.params.X`` references in
    Stage-2 / Stage-3 expressions. Nested object schemas are summarised
    as ``object`` to keep the prompt compact (the LLM does not need
    full leaf types to write gates; it needs to know what parameter
    names exist).

    Returns ``""`` when the schema is missing, empty, or has no
    declared properties — callers omit the ``params:`` line in that
    case.
    """
    if not isinstance(schema, dict):
        return ""
    properties = schema.get("properties")
    if not isinstance(properties, dict) or not properties:
        return ""
    required = set()
    raw_required = schema.get("required")
    if isinstance(raw_required, list):
        required = {r for r in raw_required if isinstance(r, str)}
    parts: List[str] = []
    for name, prop in properties.items():
        if not isinstance(name, str):
            continue
        prop_type = ""
        if isinstance(prop, dict):
            t = prop.get("type")
            if isinstance(t, str):
                prop_type = t
            elif isinstance(t, list):
                prop_type = "|".join(str(x) for x in t)
        marker = "*" if name in required else ""
        parts.append(f"{name}{marker}: {prop_type or 'any'}")
    return "{" + ", ".join(parts) + "}"


def build_system_prompt(ctx: DesignContext) -> str:
    """Assemble the full system prompt."""
    root = _get_spec_root()
    spec_text = _sanitize_for_content_filters(
        _read(root / "spec" / "SPECIFICATION.md")
    )
    schema_text = _read(root / "spec" / "schema" / "guardrails.schema.json")
    expr_text = _sanitize_for_content_filters(
        _read(root / "spec" / "expressions" / "LANGUAGE.md")
    )

    # Sanitize user-supplied **prose** (description, tool/source/server
    # **descriptions**, notes) but NOT user-supplied **identifiers**
    # (tool names, parent tool names, parameter names). Identifiers are
    # exact tokens that must round-trip through the LLM into the
    # generated YAML byte-for-byte; rewriting them would break the
    # reference between the generated config and the real runtime tool
    # registry. If a user genuinely has a tool named e.g.
    # ``jailbreak_detector``, an Azure deployment with strict prompt
    # shields may reject the prompt; in that case the recommendation
    # is to lower the content-filter severity on that deployment.
    safe_description = _sanitize_for_content_filters(ctx.description or "")
    safe_tools = [
        ToolEntry(
            name=t.name,  # identifier — preserved verbatim
            description=_sanitize_for_content_filters(t.description),
            source_label=t.source_label,
            input_schema=t.input_schema,  # property names preserved verbatim
        )
        for t in ctx.tools
    ]
    safe_notes = [_sanitize_for_content_filters(n) for n in ctx.source_notes]
    safe_servers = [_sanitize_for_content_filters(s) for s in ctx.mcp_servers]
    safe_parent_tool_names = list(ctx.parent_tool_names)  # identifiers — preserved

    parent_block = (
        f"A parent file was supplied at `{ctx.parent_path}`. Your final "
        f"output MUST `extends: [<relative path to that file>]` and MUST "
        f"NOT redeclare any of these existing tools:\n"
        + "\n".join(f"  - {n}" for n in safe_parent_tool_names)
        if ctx.parent_path
        else "No parent file. Generate a complete standalone `.guardrails.yaml`."
    )

    mcp_servers_note = (
        "MCP servers detected (informational; not tool names):\n"
        + "\n".join(f"  - {s}" for s in safe_servers)
        if safe_servers
        else ""
    )

    source_notes_block = (
        "Source-parser notes:\n" + "\n".join(f"  - {n}" for n in safe_notes)
        if safe_notes
        else ""
    )

    return f"""\
You are **Agent Shield's policy designer**. Your job: produce a
working, schema-valid `.guardrails.yaml` for the user's specific
agent by reading the spec below, asking targeted clarifying
questions, and proposing config increments that the orchestrator
will validate against the Rust loader.

You are NOT a chatbot. You are NOT to write prose. You speak only
through the JSON action protocol in the "Output contract" section.

The user's agent
================

Description (from `--describe`):
    {safe_description or "(empty — start by asking the user what the agent does)"}

Tools available to the agent:
{_tool_block(safe_tools)}

{parent_block}

{mcp_servers_note}

{source_notes_block}

{_ACTION_CONTRACT}

{_HOUSE_STYLE}

# JSON Schema (authoritative grammar)

```json
{schema_text}
```

# Expression language reference

```
{expr_text}
```

# Full specification

```
{spec_text}
```
"""


__all__ = ["DesignContext", "build_system_prompt"]
