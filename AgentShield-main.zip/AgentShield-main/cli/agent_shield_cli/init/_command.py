"""``agent-shield init`` — CLI orchestrator.

Wires together:

  arg parsing → source loading → context building → LLM caller →
  design loop → emit & write
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path
from typing import List, Optional

from ._context import DesignContext, build_system_prompt
from ._design_agent import DesignResult, run_design_loop
from ._emit import emit_yaml
from ._llm import LlmError, build_caller
from ._sources import SourceParseError, load_tools
from ._validate import (
    ValidationError,
    parent_tool_names,
    validate_on_disk,
)


def add_init_parser(subparsers: argparse._SubParsersAction) -> argparse.ArgumentParser:
    p = subparsers.add_parser(
        "init",
        help="Design a `.guardrails.yaml` with an LLM-driven conversation.",
        description=(
            "Agentic `.guardrails.yaml` designer. Primes an LLM with the v2 "
            "spec, schema, and curated examples; the model asks clarifying "
            "questions and proposes config increments validated against the "
            "Rust loader before being written."
        ),
    )
    p.add_argument(
        "--output",
        "-o",
        type=Path,
        default=Path(".guardrails.yaml"),
        help="Output path (default: ./.guardrails.yaml).",
    )
    p.add_argument(
        "--describe",
        default="",
        help=(
            "1-2 sentence description of the agent (role, data classes "
            "handled, deployment surface). Primes the LLM."
        ),
    )

    # ── tool sources ────────────────────────────────────────────────
    p.add_argument(
        "--mcp",
        action="append",
        default=[],
        type=Path,
        metavar="PATH",
        help="MCP source file (tools/list JSON or allowlist YAML). Repeatable.",
    )
    p.add_argument(
        "--openai-tools", type=Path, metavar="PATH",
        help="OpenAI function-call JSON file.",
    )
    p.add_argument(
        "--anthropic-tools", type=Path, metavar="PATH",
        help="Anthropic tool JSON file.",
    )
    p.add_argument(
        "--from",
        dest="from_path",
        type=Path,
        metavar="PATH",
        help=(
            "Extend an existing `.guardrails.yaml` — the output starts "
            "with `extends: [<this file>]` and only adds new tools / "
            "policies. The parent file is never modified."
        ),
    )

    # ── LLM provider ────────────────────────────────────────────────
    p.add_argument(
        "--provider",
        choices=("openai", "anthropic", "azure"),
        required=False,
        help="LLM provider (also reads $AGENT_SHIELD_PROVIDER).",
    )
    p.add_argument(
        "--model",
        required=False,
        help="Provider-specific model name (also reads $AGENT_SHIELD_MODEL).",
    )
    p.add_argument(
        "--api-key",
        default=None,
        help=(
            "API key override "
            "(default: $OPENAI_API_KEY / $ANTHROPIC_API_KEY / $AZURE_OPENAI_API_KEY)."
        ),
    )

    # ── interaction control ────────────────────────────────────────
    p.add_argument(
        "--non-interactive",
        action="store_true",
        help=(
            "Run without user turns: the LLM gets one shot with --describe + "
            "tools, must emit `done` directly. Requires --describe."
        ),
    )
    p.add_argument(
        "--max-turns",
        type=int,
        default=30,
        help="Hard cap on assistant turns (default: 30).",
    )
    p.add_argument(
        "--force",
        action="store_true",
        help="Overwrite the output file if it exists.",
    )
    p.add_argument(
        "--dry-run",
        action="store_true",
        help="Print the final YAML to stdout instead of writing.",
    )
    return p


def run_init(args: argparse.Namespace) -> int:
    # ── resolve provider config ────────────────────────────────────
    provider = args.provider or os.environ.get("AGENT_SHIELD_PROVIDER")
    model = args.model or os.environ.get("AGENT_SHIELD_MODEL")
    if not provider or not model:
        print(
            "error: --provider and --model are required (or set "
            "AGENT_SHIELD_PROVIDER / AGENT_SHIELD_MODEL).",
            file=sys.stderr,
        )
        return 2

    if args.non_interactive and not args.describe:
        print(
            "error: --non-interactive requires --describe to give the LLM "
            "enough context to proceed without questions.",
            file=sys.stderr,
        )
        return 2

    out_path: Path = args.output
    parent_path: Optional[Path] = args.from_path

    # ── same-file UX guard ─────────────────────────────────────────
    if parent_path is not None:
        try:
            same = out_path.resolve() == parent_path.resolve()
        except OSError:
            same = False
        if same:
            print(
                "error: --from and --output resolve to the same path "
                "(would create an extends self-cycle). Choose a different "
                "--output.",
                file=sys.stderr,
            )
            return 2
        if not parent_path.exists():
            print(f"error: --from path not found: {parent_path}", file=sys.stderr)
            return 1

    if os.path.lexists(out_path) and not args.force and not args.dry_run:
        print(
            f"error: {out_path} already exists. Pass --force to overwrite, "
            f"or --dry-run to preview.",
            file=sys.stderr,
        )
        return 1

    # Preflight the output parent so we never spend LLM tokens on a
    # run that can't write its result. --dry-run does not write, so
    # this check is skipped in that mode.
    if not args.dry_run:
        try:
            out_path.parent.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            print(
                f"error: cannot create output directory {out_path.parent}: "
                f"{exc}",
                file=sys.stderr,
            )
            return 1

    # ── parse sources ──────────────────────────────────────────────
    try:
        sources = load_tools(
            mcp_paths=list(args.mcp or []),
            openai_path=args.openai_tools,
            anthropic_path=args.anthropic_tools,
        )
    except SourceParseError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    # ── parent introspection (force-compile to catch a broken parent
    #    upfront, before the LLM bills any tokens) ──────────────────
    existing_tool_names: List[str] = []
    if parent_path is not None:
        try:
            existing_tool_names = parent_tool_names(parent_path)
        except ValidationError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 1

    # ── build context ──────────────────────────────────────────────
    try:
        ctx = DesignContext.from_inputs(
            sources=sources,
            description=args.describe,
            parent_path=parent_path,
            parent_tool_names=existing_tool_names,
        )
        system_prompt = build_system_prompt(ctx)
    except FileNotFoundError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    # ── construct caller ──────────────────────────────────────────
    try:
        caller = build_caller(provider=provider, model=model, api_key=args.api_key)
    except LlmError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    # ── banner ────────────────────────────────────────────────────
    print(
        f"agent-shield init — {provider} / {model}\n"
        f"  tools: {len(sources.tools)} | "
        f"parent: {parent_path or '(none)'} | "
        f"output: {out_path}{' (dry-run)' if args.dry_run else ''}",
        file=sys.stderr,
    )
    if sources.notes:
        for note in sources.notes:
            print(f"  ⓘ {note}", file=sys.stderr)

    # ── design loop ───────────────────────────────────────────────
    result = run_design_loop(
        caller=caller,
        system_prompt=system_prompt,
        parent_path=parent_path,
        non_interactive=args.non_interactive,
        max_turns=args.max_turns,
    )
    if result.aborted or result.final_yaml is None:
        print(f"\n✗ aborted: {result.abort_reason}", file=sys.stderr)
        return 1

    # ── re-write extends to a path relative to the on-disk output,
    #    if --from was used. The design agent injects an absolute path
    #    so validation works regardless of cwd; we make the final
    #    on-disk reference portable. ──────────────────────────────
    if parent_path is not None and isinstance(result.final_data, dict):
        rel = _relative_for_extends(parent_path, out_path)
        result.final_data["extends"] = [rel]

    # ── re-emit through the comment-aware emitter (for spec-section
    #    headers + round-trip safety) ───────────────────────────────
    try:
        text = emit_yaml(
            result.final_data,
            header_notes=[f"Designed with {provider}/{model}."],
        )
    except RuntimeError as exc:
        print(f"error: emitter failed: {exc}", file=sys.stderr)
        return 1

    if args.dry_run:
        sys.stdout.write(text)
    else:
        # Atomic write: stage the candidate next to the destination,
        # validate it on disk, only swap into place if it compiles.
        # This protects an existing target file (the common --force
        # case) from being clobbered by an LLM-produced YAML that
        # fails the post-write smoke check.
        #
        # The staging path is created with exclusive flags
        # (O_CREAT | O_EXCL) under a unique name so we never overwrite
        # a sibling that happens to share the staging suffix, and
        # concurrent invocations targeting the same --output do not
        # race for the same temp path.
        import tempfile

        try:
            fd, staging_str = tempfile.mkstemp(
                prefix=f".{out_path.name}.",
                suffix=".agent-shield-init.tmp",
                dir=str(out_path.parent),
            )
            staging = Path(staging_str)
        except OSError as exc:
            print(
                f"error: could not create staging file in {out_path.parent}: {exc}",
                file=sys.stderr,
            )
            return 1

        try:
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    f.write(text)
            except OSError as exc:
                print(f"error: could not write staging file: {exc}", file=sys.stderr)
                return 1

            # mkstemp defaults to 0o600; we want the generated file to
            # have ordinary readable permissions (so build / deploy
            # processes that previously read .guardrails.yaml still
            # can). If the destination already exists, preserve its
            # mode on overwrite. Otherwise use 0o644, which matches
            # what `open(path, "w").write(...)` would produce on the
            # default POSIX umask of 022 (the previous CLI behaviour).
            # We intentionally do NOT read+restore the process umask
            # to compute this — umask is process-global, and toggling
            # it would race against any concurrent file creation in
            # the same process (which happens if a caller embeds
            # agent_shield_cli.main in a larger Python service).
            try:
                if out_path.exists() and not out_path.is_symlink():
                    target_mode = out_path.stat().st_mode & 0o7777
                else:
                    target_mode = 0o644
                os.chmod(staging, target_mode)
            except OSError:
                # Best-effort: some filesystems (e.g. FAT on Windows)
                # ignore chmod. Don't fail the run over permission
                # metadata.
                pass

            try:
                validate_on_disk(staging)
            except ValidationError as exc:
                print(
                    "error: post-write validation failed (final config did "
                    f"not compile on disk):\n  ↳ {exc}",
                    file=sys.stderr,
                )
                return 1

            # Recheck no-clobber just before the swap. The initial
            # check at the top of run_init can be minutes old by the
            # time the LLM conversation finishes; another process
            # could have created the file in between. With --force the
            # user has opted into overwrite; without it, we refuse.
            if not args.force and os.path.lexists(out_path):
                print(
                    f"error: {out_path} appeared during the design "
                    "conversation. Re-run with --force if you intend to "
                    "overwrite, or choose a different --output.",
                    file=sys.stderr,
                )
                return 1

            # os.replace is atomic on POSIX and Windows; replaces target
            # only if validation passed, preserving the prior file bytes
            # up to this point.
            os.replace(staging, out_path)
        finally:
            # In any error path that left the staging file behind, drop
            # it so we don't accumulate cruft on repeated invocations.
            if staging.exists():
                try:
                    staging.unlink()
                except OSError:
                    pass

        print(f"\n✔ wrote {out_path} ({result.turns} turn(s))", file=sys.stderr)
        print(
            "  Next: review the inline comments, refine objective.forbidden "
            "for your specific risks, and run your test suite against the "
            "new file.",
            file=sys.stderr,
        )
    return 0


__all__ = ["add_init_parser", "run_init"]


def _relative_for_extends(parent: Path, child: Path) -> str:
    """Path string for the child's ``extends:`` entry.

    Resolves both sides, expresses the parent relative to the child's
    directory, and forces forward slashes for portability. Falls back
    to an absolute path on Windows cross-drive ``ValueError``.
    """
    child_dir = child.parent.resolve()
    parent_abs = parent.resolve()
    try:
        rel = os.path.relpath(parent_abs, start=child_dir)
    except ValueError:
        rel = str(parent_abs)
    return rel.replace(os.sep, "/")
