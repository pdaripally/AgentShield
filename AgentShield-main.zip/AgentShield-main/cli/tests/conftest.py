"""Shared fixtures + a mock LLM caller for the init test suite."""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Sequence

import pytest
import yaml


@pytest.fixture
def openai_tools_json(tmp_path: Path) -> Path:
    p = tmp_path / "openai-tools.json"
    p.write_text(
        json.dumps(
            [
                {
                    "type": "function",
                    "function": {
                        "name": "get_customer",
                        "description": "Read a customer profile",
                        "parameters": {},
                    },
                },
                {
                    "type": "function",
                    "function": {
                        "name": "refund_order",
                        "description": "Issue a refund",
                        "parameters": {},
                    },
                },
            ]
        ),
        encoding="utf-8",
    )
    return p


@pytest.fixture
def mcp_manifest_json(tmp_path: Path) -> Path:
    p = tmp_path / "mcp-tools.json"
    p.write_text(
        json.dumps(
            {
                "tools": [
                    {"name": "search_db", "description": "Query the DB", "inputSchema": {}},
                ]
            }
        ),
        encoding="utf-8",
    )
    return p


@pytest.fixture
def anthropic_tools_json(tmp_path: Path) -> Path:
    p = tmp_path / "anthropic-tools.json"
    p.write_text(
        json.dumps(
            [{"name": "list_files", "description": "List files", "input_schema": {}}]
        ),
        encoding="utf-8",
    )
    return p


@pytest.fixture
def mcp_allowlist_yaml(tmp_path: Path) -> Path:
    p = tmp_path / "mcp-allowlist.yaml"
    p.write_text(
        yaml.safe_dump({"enforcement": "warn", "known": ["github"]}),
        encoding="utf-8",
    )
    return p


# ─────────────────────── mock LLM caller ──────────────────────────


@dataclass
class MockLlmCaller:
    """An LlmCaller that replays a fixed script of assistant responses.

    Each call to ``chat`` returns the next entry from ``script``. A
    transcript of ``(messages, response)`` pairs is kept so tests can
    assert what the agent saw.
    """

    script: List[str]
    name: str = "mock"
    model: str = "mock-1"
    transcript: List[Dict[str, object]] = field(default_factory=list)
    cursor: int = 0

    def chat(self, messages: Sequence[Dict[str, str]]) -> str:
        if self.cursor >= len(self.script):
            raise AssertionError(
                f"mock LLM ran out of scripted responses (turn {self.cursor + 1}); "
                f"the agent kept asking. Last messages: "
                f"{[m.get('role') for m in messages[-3:]]}"
            )
        response = self.script[self.cursor]
        self.cursor += 1
        # Capture only the most recent user/system content so the
        # transcript stays readable in test failures.
        last_user_content = next(
            (m.get("content") for m in reversed(messages) if m.get("role") == "user"),
            None,
        )
        self.transcript.append(
            {
                "n_messages": len(messages),
                "last_role": messages[-1].get("role") if messages else None,
                "last_user_content": last_user_content,
                "response": response,
            }
        )
        return response


def make_action(action: str, **fields) -> str:
    """Convenience: build a JSON-encoded action for the mock script."""
    payload = {"action": action, **fields}
    return json.dumps(payload)


@pytest.fixture
def make_action_fn():
    return make_action
