"""Context-building tests — verify the system prompt embeds everything."""
from __future__ import annotations

from pathlib import Path

from agent_shield_cli.init._context import DesignContext, build_system_prompt
from agent_shield_cli.init._sources import LoadedSources, ToolEntry


def _ctx(**kw) -> DesignContext:
    defaults = dict(
        sources=LoadedSources(
            tools=[
                ToolEntry(name="refund_order", description="Issue a refund",
                          source_label="openai_function"),
                ToolEntry(name="get_customer", description="Read customer",
                          source_label="openai_function"),
            ]
        ),
        description="Bank support agent",
        parent_path=None,
        parent_tool_names=[],
    )
    defaults.update(kw)
    return DesignContext.from_inputs(**defaults)


def test_system_prompt_embeds_spec_and_schema() -> None:
    prompt = build_system_prompt(_ctx())
    # Spec sections must be reachable
    assert "## 12. Guard policies" in prompt
    assert "## 9. Events and lifetimes" in prompt
    # Schema must be embedded
    assert "guardrails.schema.json" in prompt
    assert '"$schema"' in prompt
    # Expression-language reference must be embedded
    assert "## Operator precedence" in prompt or "Operator precedence" in prompt


def test_system_prompt_embeds_house_style() -> None:
    """The prompt should ship a compact inline house-style reference
    (minimal valid skeleton plus pattern snippets). We do NOT bundle
    full example configs — duplicating the canonical examples into
    package data was rejected as too ugly and unnecessary."""
    prompt = build_system_prompt(_ctx())
    # House-style block is present
    assert "House style and minimal-valid skeleton" in prompt
    # Schema-shape gotchas the spec calls out explicitly
    assert "Always quote: `'2.0'`" in prompt
    assert "applies_to" in prompt
    # Pattern snippets are present
    assert "populated_by" in prompt
    assert "on_demand_by" in prompt


def test_system_prompt_embeds_user_tools_and_description() -> None:
    prompt = build_system_prompt(_ctx())
    assert "Bank support agent" in prompt
    assert "refund_order" in prompt
    assert "Issue a refund" in prompt


def test_system_prompt_carries_action_contract() -> None:
    prompt = build_system_prompt(_ctx())
    assert "Output contract" in prompt
    for token in ('"action": "ask"', '"action": "propose"', '"action": "done"'):
        assert token in prompt


def test_system_prompt_lists_parent_tools_when_extending(tmp_path: Path) -> None:
    parent = tmp_path / "parent.yaml"
    parent.write_text("metadata: {name: p, version: '0.1.0', agent_shield_version: '2.0'}\n"
                      "objective: {goal: [h]}\n", encoding="utf-8")
    prompt = build_system_prompt(
        _ctx(parent_path=parent, parent_tool_names=["pre_existing_tool"])
    )
    assert "pre_existing_tool" in prompt
    assert "extends" in prompt
