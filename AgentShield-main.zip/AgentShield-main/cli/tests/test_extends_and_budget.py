"""Regression tests for two bugs caught by GPT-5.5 diff review.

1. The LLM could omit `extends:` from its `done` YAML when `--from`
   was supplied; the post-write file silently lost the parent chain.
   Fix: the design loop now injects a canonical `extends: [<parent>]`
   into the final data before emit + re-validates.

2. `--max-turns` only counted main-loop iterations, ignoring the
   chat calls inside the self-correct loop and the `done`-retry path.
   Fix: every chat call now goes through `_Session.chat`, which
   enforces the budget.
"""
from __future__ import annotations

from pathlib import Path

import yaml

from agent_shield_cli.init._design_agent import run_design_loop
from agent_shield.config import GuardrailsConfig
from .conftest import MockLlmCaller, make_action


_VALID_CHILD_NO_EXTENDS = yaml.safe_dump(
    {
        "metadata": {"name": "c", "version": "0.1.0", "agent_shield_version": "2.0"},
        "objective": {"goal": ["help"]},
    }
)


def _make_parent(tmp_path: Path) -> Path:
    p = tmp_path / "parent.yaml"
    p.write_text(
        yaml.safe_dump(
            {
                "metadata": {
                    "name": "p", "version": "0.1.0", "agent_shield_version": "2.0",
                },
                "objective": {"goal": ["help"]},
                "input_validation": {
                    "guard_policies": [
                        {
                            "name": "parent_jb",
                            "evaluate_when": [
                                {"pattern": "evil", "reason": "parent guard"}
                            ],
                        }
                    ]
                },
            }
        ),
        encoding="utf-8",
    )
    return p


def test_extends_is_injected_when_parent_present(tmp_path: Path) -> None:
    """LLM emits a child WITHOUT `extends:` — the loop must inject one
    referencing the parent so the on-disk file actually layers."""
    parent = _make_parent(tmp_path)
    caller = MockLlmCaller(
        script=[make_action("done", yaml=_VALID_CHILD_NO_EXTENDS, summary="ok")]
    )
    result = run_design_loop(
        caller=caller,
        system_prompt="<system>",
        parent_path=parent,
        non_interactive=True,
    )
    assert result.final_data is not None
    extends = result.final_data.get("extends")
    assert isinstance(extends, list) and len(extends) == 1
    # canonical absolute path was injected
    assert Path(extends[0]).resolve() == parent.resolve()


def test_extends_overrides_bad_model_extends(tmp_path: Path) -> None:
    """If the LLM emits a wrong `extends:`, we replace it."""
    parent = _make_parent(tmp_path)
    bad_extends_yaml = yaml.safe_dump(
        {
            "extends": ["/some/wrong/path.yaml"],
            "metadata": {"name": "c", "version": "0.1.0", "agent_shield_version": "2.0"},
            "objective": {"goal": ["help"]},
        }
    )
    caller = MockLlmCaller(
        script=[make_action("done", yaml=bad_extends_yaml, summary="ok")]
    )
    result = run_design_loop(
        caller=caller,
        system_prompt="<system>",
        parent_path=parent,
        non_interactive=True,
    )
    assert result.final_data is not None
    extends = result.final_data["extends"]
    assert len(extends) == 1
    # canonical injection replaced the wrong path
    assert Path(extends[0]).resolve() == parent.resolve()


def test_max_turns_caps_self_correct_loop() -> None:
    """Three invalid proposals should not exceed `--max-turns=1`.

    Without the bugfix, each invalid propose triggered an extra
    in-handler chat call (3 retries × 2 = 6 LLM calls inside one
    "turn"). With the fix, the budget cuts off after the first call.
    """
    _INVALID_YAML = yaml.safe_dump(
        {
            "metadata": {
                "name": "p", "version": "0.1.0", "agent_shield_version": "2.0",
            },
            "objective": {"goal": ["help"]},
            "state_validation": {
                "guard_policies": [{"name": "bad", "reason": "missing applies_to"}]
            },
        }
    )
    caller = MockLlmCaller(
        script=[
            make_action("propose", yaml=_INVALID_YAML, explanation="bad"),
            make_action("propose", yaml=_INVALID_YAML, explanation="bad"),
            make_action("propose", yaml=_INVALID_YAML, explanation="bad"),
        ]
    )
    result = run_design_loop(
        caller=caller,
        system_prompt="<system>",
        max_turns=1,
        non_interactive=True,
    )
    assert result.aborted
    # turn budget was respected — exactly 1 call was made
    assert caller.cursor == 1
    assert "max_turns" in result.abort_reason


def test_post_write_layered_config_compiles(tmp_path: Path) -> None:
    """End-to-end: parent + injected extends + child body all compile via
    the on-disk loader after writing."""
    from agent_shield_cli.init._emit import emit_yaml

    parent = _make_parent(tmp_path)
    caller = MockLlmCaller(
        script=[make_action("done", yaml=_VALID_CHILD_NO_EXTENDS, summary="ok")]
    )
    result = run_design_loop(
        caller=caller,
        system_prompt="<system>",
        parent_path=parent,
        non_interactive=True,
    )
    assert result.final_data is not None

    # Mimic the orchestrator's rel-path rewrite, then emit + write.
    import os

    rel = os.path.relpath(parent.resolve(), start=tmp_path.resolve()).replace(
        os.sep, "/"
    )
    result.final_data["extends"] = [rel]
    out = tmp_path / "child.yaml"
    out.write_text(emit_yaml(result.final_data), encoding="utf-8")

    compiled = GuardrailsConfig.load(str(out)).compile()
    _ = compiled._native_handle
    # The on-disk file references the parent — compile resolves the
    # extends chain via the Rust loader. A broken extends would raise
    # above. Parent body content is merged in core, not surfaced
    # through the Python facade's `yaml_strings` (which is the layered
    # source texts, not the merged result), so we verify behaviorally
    # by re-reading the child and confirming the chain anchor.
    child_text = out.read_text(encoding="utf-8")
    assert "extends:" in child_text
    assert "parent.yaml" in child_text
