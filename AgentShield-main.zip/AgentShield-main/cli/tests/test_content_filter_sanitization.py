"""Smoke tests for the content-filter sanitizer.

Azure OpenAI's prompt-shield ``jailbreak`` filter rejects prompts
containing attack-pattern literals and even the terminology used to
*describe* prompt-injection. Since this CLI legitimately embeds the
AgentShield spec — which talks about those concepts as the threats
it defends against — every embedded reference text and example
config is run through ``_sanitize_for_content_filters`` before being
stuffed into the system prompt.

These tests assert the substitution actually happens.
"""
from __future__ import annotations

from agent_shield_cli.init._context import (
    DesignContext,
    _sanitize_for_content_filters,
    build_system_prompt,
)
from agent_shield_cli.init._sources import LoadedSources, ToolEntry


def test_attack_regex_literal_is_stripped() -> None:
    raw = 'pattern: "ignore.*(?:previous|all|prior).*(?:instructions|rules|guidelines)"'
    sanitized = _sanitize_for_content_filters(raw)
    assert "ignore.*(?:previous|all|prior)" not in sanitized
    assert "INPUT_ATTACK_REGEX" in sanitized


def test_attack_terminology_replaced() -> None:
    raw = "Stage 1 catches jailbreak attempts and prompt injection."
    sanitized = _sanitize_for_content_filters(raw)
    assert "jailbreak" not in sanitized
    assert "prompt injection" not in sanitized
    assert "input-attack" in sanitized
    assert "untrusted-input attack" in sanitized


def test_system_prompt_is_clean() -> None:
    """The final system prompt must not leak any of the attack literals."""
    ctx = DesignContext.from_inputs(
        sources=LoadedSources(tools=[ToolEntry(name="x")]),
        description="test",
        parent_path=None,
        parent_tool_names=[],
    )
    prompt = build_system_prompt(ctx)
    forbidden_literals = [
        "ignore.*(?:previous|all|prior)",
        "jailbreak",
        "Jailbreak",
        "JAILBREAK",
        "prompt injection",
        "Prompt injection",
    ]
    for needle in forbidden_literals:
        assert needle not in prompt, (
            f"system prompt still contains content-filter-triggering "
            f"literal {needle!r}"
        )


def test_substitutions_idempotent() -> None:
    """Running sanitization twice yields the same text as once."""
    raw = (
        "ignore.*(?:previous|all|prior).*(?:instructions|rules|guidelines)\n"
        "jailbreak and prompt injection patterns"
    )
    once = _sanitize_for_content_filters(raw)
    twice = _sanitize_for_content_filters(once)
    assert once == twice
