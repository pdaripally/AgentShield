"""Source-parser unit tests (no LLM involvement)."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from agent_shield_cli.init._sources import (
    SourceParseError,
    load_anthropic_tools,
    load_mcp,
    load_openai_tools,
    load_tools,
)


def test_mcp_manifest_parses(mcp_manifest_json: Path) -> None:
    parsed = load_mcp(mcp_manifest_json)
    assert [t.name for t in parsed.tools] == ["search_db"]
    assert parsed.tools[0].source_label == "mcp"


def test_mcp_allowlist_parses_as_servers(mcp_allowlist_yaml: Path) -> None:
    parsed = load_mcp(mcp_allowlist_yaml)
    assert parsed.tools == []
    assert parsed.servers == ["github"]
    assert parsed.notes  # carries an informational note


def test_openai_tools_modern_shape(openai_tools_json: Path) -> None:
    tools = load_openai_tools(openai_tools_json)
    names = {t.name for t in tools}
    assert names == {"get_customer", "refund_order"}
    assert all(t.source_label == "openai_function" for t in tools)


def test_openai_tools_legacy_functions_shape(tmp_path: Path) -> None:
    p = tmp_path / "legacy.json"
    p.write_text(json.dumps({"functions": [{"name": "x", "description": "y"}]}))
    tools = load_openai_tools(p)
    assert tools[0].name == "x"


def test_anthropic_tools_bare_array(anthropic_tools_json: Path) -> None:
    tools = load_anthropic_tools(anthropic_tools_json)
    assert tools[0].name == "list_files"
    assert tools[0].source_label == "anthropic_tool"


def test_load_tools_dedups_first_wins(
    mcp_manifest_json: Path, openai_tools_json: Path, tmp_path: Path
) -> None:
    dup = tmp_path / "dup.json"
    dup.write_text(
        json.dumps([{"type": "function", "function": {"name": "search_db"}}])
    )
    result = load_tools(
        mcp_paths=[mcp_manifest_json],
        openai_path=dup,
        anthropic_path=None,
    )
    names = [t.name for t in result.tools]
    # search_db came from MCP first; the OpenAI duplicate is dropped.
    assert names == ["search_db"]
    assert any("duplicate" in n for n in result.notes)


def test_invalid_json_raises(tmp_path: Path) -> None:
    p = tmp_path / "bad.json"
    p.write_text("not json")
    with pytest.raises(SourceParseError):
        load_openai_tools(p)


def test_missing_name_raises(tmp_path: Path) -> None:
    p = tmp_path / "bad.json"
    p.write_text(json.dumps([{"description": "no name"}]))
    with pytest.raises(SourceParseError):
        load_openai_tools(p)
