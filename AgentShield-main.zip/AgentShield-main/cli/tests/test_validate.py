"""Validation-gate regression tests.

The validator MUST eagerly trigger the Rust loader by touching
``CompiledPolicy._native_handle`` — without that, ``compile()``
returns a wrapper and validation is silently skipped.
"""
from __future__ import annotations

from pathlib import Path

import pytest
import yaml

from agent_shield_cli.init._validate import (
    ValidationError,
    parent_tool_names,
    validate_on_disk,
    validate_standalone,
    validate_with_parent,
)


_MINIMAL = {
    "metadata": {"name": "p", "version": "0.1.0", "agent_shield_version": "2.0"},
    "objective": {"goal": ["help"]},
}


def test_validate_standalone_catches_invalid_scaffold() -> None:
    bad = {
        **_MINIMAL,
        # §15: state-validation policy requires applies_to.
        "state_validation": {
            "guard_policies": [{"name": "bad", "reason": "missing applies_to"}]
        },
    }
    with pytest.raises(ValidationError):
        validate_standalone(bad)


def test_validate_standalone_accepts_minimal() -> None:
    validate_standalone(_MINIMAL)


def test_validate_with_parent_rejects_bad_child(tmp_path: Path) -> None:
    parent = tmp_path / "parent.yaml"
    parent.write_text(yaml.safe_dump(_MINIMAL), encoding="utf-8")
    bad_child = {
        "state_validation": {
            "guard_policies": [{"name": "bad", "reason": "missing applies_to"}]
        }
    }
    with pytest.raises(ValidationError):
        validate_with_parent(parent, bad_child)


def test_validate_with_parent_rejects_extends_in_child(tmp_path: Path) -> None:
    parent = tmp_path / "parent.yaml"
    parent.write_text(yaml.safe_dump(_MINIMAL), encoding="utf-8")
    with pytest.raises(ValidationError):
        validate_with_parent(parent, {"extends": ["foo.yaml"]})


def test_validate_on_disk_rejects_bad_file(tmp_path: Path) -> None:
    p = tmp_path / "broken.yaml"
    p.write_text(
        yaml.safe_dump({**_MINIMAL, "unknown_top_level_key": 1}),
        encoding="utf-8",
    )
    with pytest.raises(ValidationError):
        validate_on_disk(p)


def test_parent_tool_names_extracts_from_extends_chain(tmp_path: Path) -> None:
    p = tmp_path / "with-tools.yaml"
    p.write_text(
        yaml.safe_dump(
            {
                **_MINIMAL,
                "resources": {"tools": [{"name": "t1"}, {"name": "t2"}]},
            }
        ),
        encoding="utf-8",
    )
    names = parent_tool_names(p)
    assert set(names) == {"t1", "t2"}


def test_parent_tool_names_raises_on_broken_parent(tmp_path: Path) -> None:
    p = tmp_path / "broken.yaml"
    p.write_text(
        yaml.safe_dump({**_MINIMAL, "unknown_top_level_key": 1}),
        encoding="utf-8",
    )
    with pytest.raises(ValidationError):
        parent_tool_names(p)
