"""End-to-end ``agent-shield init`` smoke tests.

Use ``unittest.mock`` to replace the real LLM caller with a scripted
mock, then drive the CLI through ``agent_shield_cli.main``.
"""
from __future__ import annotations

from pathlib import Path
from unittest import mock

import yaml

from agent_shield_cli import main
from agent_shield.config import GuardrailsConfig
from .conftest import MockLlmCaller, make_action


_VALID_YAML = yaml.safe_dump(
    {
        "metadata": {"name": "demo", "version": "0.1.0", "agent_shield_version": "2.0"},
        "objective": {"goal": ["help"]},
        "resources": {
            "tools": [
                {"name": "get_customer", "permission": "read_only"},
                {"name": "refund_order", "permission": "destructive"},
            ]
        },
        "input_validation": {
            "guard_policies": [
                {
                    "name": "jailbreak",
                    "evaluate_when": [
                        {"pattern": "ignore.*instructions", "reason": "jb"}
                    ],
                }
            ]
        },
    }
)


def _patch_builder(script):
    """Patch the LLM factory to return a MockLlmCaller with the given script."""
    return mock.patch(
        "agent_shield_cli.init._command.build_caller",
        return_value=MockLlmCaller(script=script),
    )


def test_cli_non_interactive_writes_validated_yaml(
    tmp_path: Path, openai_tools_json: Path
) -> None:
    out = tmp_path / ".guardrails.yaml"
    with _patch_builder(
        [make_action("done", yaml=_VALID_YAML, summary="ok")]
    ):
        rc = main(
            [
                "init",
                "--provider", "openai",
                "--model", "gpt-5",
                "--api-key", "test-key",  # bypass env requirement (still used by mock)
                "--describe", "Customer support bot.",
                "--openai-tools", str(openai_tools_json),
                "--output", str(out),
                "--non-interactive",
            ]
        )
    assert rc == 0
    assert out.exists()

    # Loads and compiles through the Rust core.
    compiled = GuardrailsConfig.load(str(out)).compile()
    _ = compiled._native_handle


def test_cli_requires_provider_and_model(tmp_path: Path) -> None:
    rc = main(["init", "--non-interactive", "--describe", "x", "--output",
               str(tmp_path / "x.yaml")])
    assert rc == 2


def test_cli_non_interactive_requires_describe(tmp_path: Path) -> None:
    rc = main(
        [
            "init",
            "--provider", "openai",
            "--model", "gpt-5",
            "--non-interactive",
            "--output", str(tmp_path / "x.yaml"),
        ]
    )
    assert rc == 2


def test_cli_dry_run_does_not_write(
    tmp_path: Path, capsys, openai_tools_json: Path
) -> None:
    out = tmp_path / ".guardrails.yaml"
    with _patch_builder(
        [make_action("done", yaml=_VALID_YAML, summary="ok")]
    ):
        rc = main(
            [
                "init",
                "--provider", "openai",
                "--model", "gpt-5",
                "--api-key", "test-key",
                "--describe", "x",
                "--openai-tools", str(openai_tools_json),
                "--output", str(out),
                "--non-interactive",
                "--dry-run",
            ]
        )
    assert rc == 0
    assert not out.exists()
    captured = capsys.readouterr()
    assert "metadata:" in captured.out


def test_cli_refuses_overwrite_without_force(
    tmp_path: Path, openai_tools_json: Path
) -> None:
    out = tmp_path / ".guardrails.yaml"
    out.write_text("existing: yes\n", encoding="utf-8")

    # No mock needed — we should fail before any LLM call.
    rc = main(
        [
            "init",
            "--provider", "openai",
            "--model", "gpt-5",
            "--api-key", "test-key",
            "--describe", "x",
            "--openai-tools", str(openai_tools_json),
            "--output", str(out),
            "--non-interactive",
        ]
    )
    assert rc != 0
    assert out.read_text(encoding="utf-8") == "existing: yes\n"


def test_cli_from_path_rejects_self_cycle(
    tmp_path: Path, openai_tools_json: Path
) -> None:
    parent = tmp_path / "policy.yaml"
    parent.write_text(
        yaml.safe_dump(
            {
                "metadata": {
                    "name": "p", "version": "0.1.0", "agent_shield_version": "2.0",
                },
                "objective": {"goal": ["h"]},
            }
        ),
        encoding="utf-8",
    )
    rc = main(
        [
            "init",
            "--provider", "openai",
            "--model", "gpt-5",
            "--api-key", "test-key",
            "--describe", "x",
            "--openai-tools", str(openai_tools_json),
            "--from", str(parent),
            "--output", str(parent),
            "--non-interactive",
        ]
    )
    assert rc == 2


def test_cli_propagates_llm_error(tmp_path: Path, openai_tools_json: Path) -> None:
    """If the LLM provider library is missing, the CLI surfaces a clean error."""
    from agent_shield_cli.init._llm import LlmError

    with mock.patch(
        "agent_shield_cli.init._command.build_caller",
        side_effect=LlmError("the `openai` package is required"),
    ):
        rc = main(
            [
                "init",
                "--provider", "openai",
                "--model", "gpt-5",
                "--describe", "x",
                "--openai-tools", str(openai_tools_json),
                "--output", str(tmp_path / "x.yaml"),
                "--non-interactive",
            ]
        )
    assert rc == 1
