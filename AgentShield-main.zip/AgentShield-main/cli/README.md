# `agent-shield-cli`

CLI tooling for [Agent Shield](https://github.com/microsoft/AgentShield).

Today ships:

- **`agent-shield init`** — an LLM-driven conversational
  `.guardrails.yaml` designer that primes a frontier LLM with the
  Agent Shield v2 spec and an inline house-style skeleton, then
  walks you through producing a working schema-valid policy
  tailored to your specific agent.

## Install

```bash
pip install "agent-shield-cli[openai]"      # or [anthropic], [azure]
```

This pulls in the `agent-shield` runtime SDK as a dependency (the
CLI uses the SDK's validator to gate every YAML proposal through
the same Rust loader that compiles policies at runtime, so what
ships from `agent-shield init` is guaranteed to load in your
runtime).

## Usage

See [`docs/getting-started/init.md`](https://github.com/microsoft/AgentShield/blob/main/docs/getting-started/init.md)
for the full walkthrough.

```bash
export OPENAI_API_KEY=sk-...

agent-shield init \
  --provider openai \
  --model gpt-5 \
  --openai-tools tools.json \
  --describe "Customer support bot. Refunds up to \$500, profile lookups, email replies."
```

## Layout

- `agent_shield_cli/` — Python package, entry point
- `agent_shield_cli/init/` — the `init` subcommand
- `agent_shield_cli/init/_data/` — bundled spec, schema, and
  expression-language reference (git-ignored, materialised at
  install time by `cli/_build_backend.py` from canonical
  `<repo>/spec/`)
- `_build_backend.py` — custom PEP 517 build backend that wraps
  setuptools to copy canonical spec content into `_data/` before
  the wheel/sdist is built
- `tests/` — pytest suite, mocked LLM caller, no live API calls

## Relationship to `agent-shield`

This package is **separate** from the runtime SDK (`agent-shield`).
Customers who only want runtime enforcement install `agent-shield`
and never see the CLI. Customers who want to design policies install
`agent-shield-cli`, which transitively brings in `agent-shield` for
the validator surface.

That separation keeps the runtime SDK install footprint small and
avoids comingling design-time tooling with the hot path.
