# Contributing to Agent Shield

Thank you for your interest in contributing to Agent Shield! This document covers how to get started, development workflows, and guidelines for contributions.

## Getting Started

### Prerequisites

- **Rust** (stable, latest) — the core engine
- **Python 3.11+** — Python SDK and demos
- **Node.js 18+** — Node.js SDK
- **.NET 8.0** — .NET SDK
- **maturin** — Python/Rust build tool (`pip install maturin`)

### Clone and Build

```bash
git clone https://github.com/microsoft/AgentShield.git
cd AgentShield

# Rust core
cd sdk/rust/agent_shield_core
cargo build
cargo test

# Python SDK
cd sdk/python
pip install -e ".[all]"
python -m pytest tests/ -v

# Node.js SDK
cd sdk/node
npm install
npm run build:all
npm test

# .NET SDK
cd sdk/dotnet
dotnet build
dotnet test
```

## Architecture

All validation logic lives in the **Rust core** (`sdk/rust/agent_shield_core/`). The Python, Node.js, and .NET SDKs are thin wrappers over the Rust engine. If you're fixing validation behavior, fix it in Rust — not in an SDK wrapper.

The **spec** (`spec/SPECIFICATION.md`) is the source of truth. SDK behavior that diverges from the spec is a bug.

## Development Workflow

1. **Create a branch** from `main`
2. **Make your changes** — keep them focused on a single concern
3. **Run tests** for the SDKs you changed (see commands above)
4. **Run cross-language integration tests** to ensure all SDKs agree:
   ```bash
   cd sdk/python && pytest tests/test_integration_cases.py
   cd sdk/node && node --test __tests__/integration_cases.test.mjs
   cd sdk/rust/agent_shield_core && cargo test --test integration_cases
   cd sdk/dotnet && dotnet test
   ```
5. **Open a pull request** against `main`

## Guidelines

### Code

- **Rust**: run `cargo clippy` and `cargo fmt` before committing
- **Python**: follow existing patterns; async-first for callbacks
- **Node.js**: TypeScript strict mode; run `npm run build:wrapper` to verify types
- **YAML conventions**: all keys are `snake_case`

### Guardrails YAML Changes

- Any change to the YAML format must be reflected in `spec/SPECIFICATION.md` first
- Update `spec/schema/guardrails.schema.json` if adding new fields
- Add cross-language test cases in `tests/cases/` for new behavior

### Commits

- Use [Conventional Commits](https://www.conventionalcommits.org/) (`feat:`, `fix:`, `chore:`, `docs:`)
- Keep commits focused and atomic

### Tests

- Add tests for any new behavior
- Cross-language test cases (`tests/cases/*.cases.yaml`) ensure all SDKs behave identically
- The Rust core has unit tests in each module plus integration tests

## Reporting Issues

Open an issue on GitHub with:
- What you expected to happen
- What actually happened
- Steps to reproduce
- Which SDK and version you're using

## Contributor License Agreement

Most contributions require you to agree to a Contributor License Agreement (CLA)
declaring that you have the right to, and actually do, grant us the rights to use
your contribution. For details, visit <https://cla.opensource.microsoft.com>.

When you submit a pull request, a CLA bot will automatically determine whether you
need to provide a CLA and decorate the PR appropriately (e.g., status check, comment).
Simply follow the instructions provided by the bot. You will only need to do this once
across all repos using our CLA.

## Code of Conduct

This project has adopted the [Microsoft Open Source Code of Conduct](https://opensource.microsoft.com/codeofconduct/).
For more information see the [Code of Conduct FAQ](https://opensource.microsoft.com/codeofconduct/faq/) or
contact [opencode@microsoft.com](mailto:opencode@microsoft.com) with any additional questions or comments.

## License

By contributing, you agree that your contributions will be licensed under the [MIT License](LICENSE).
