using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using Xunit;

namespace AgentShield.Tests;

/// <summary>
/// Cross-language Shield/ShieldBuilder method-parity test for the .NET SDK.
///
/// Asserts every canonical method declared with <c>must_exist_in: [..., "dotnet", ...]</c>
/// in <c>tests/parity/shield_canonical_api.json</c> is present on the live
/// <see cref="Shield"/> and <see cref="ShieldBuilder"/> classes under the .NET alias.
/// Treats public properties as accessors and public extension methods (e.g.
/// <c>WithOpenAI</c> from AgentShield.OpenAI) as part of the surface so the
/// canonical can pin them too.
///
/// See <c>tests/parity/README.md</c> for the cross-language story.
/// </summary>
public class ShieldApiParityTests
{
    private const string Lang = "dotnet";
    private static readonly string RepoRoot = FindRepoRoot();
    private static readonly string CanonicalPath =
        Path.Combine(RepoRoot, "tests", "parity", "shield_canonical_api.json");

    private static string FindRepoRoot()
    {
        var dir = AppContext.BaseDirectory;
        while (dir is not null && !Directory.Exists(Path.Combine(dir, ".git")))
            dir = Path.GetDirectoryName(dir);
        return dir ?? throw new InvalidOperationException("repo root not found");
    }

    private static JsonDocument LoadCanonical()
    {
        var raw = File.ReadAllText(CanonicalPath);
        return JsonDocument.Parse(raw);
    }

    /// <summary>
    /// Public surface of <paramref name="cls"/>: instance methods (declared
    /// or inherited from <see cref="object"/>'s public set), instance
    /// properties, and public static methods/properties. Includes public
    /// extension methods discovered on every loaded adapter assembly so the
    /// canonical can also pin <c>WithOpenAI</c>, <c>WithAnthropic</c>, etc.
    /// </summary>
    private static HashSet<string> PublicMembers(Type cls, IEnumerable<Assembly> extensionAssemblies)
    {
        var members = new HashSet<string>(StringComparer.Ordinal);

        // Instance + static methods declared on the class (public, not
        // inherited from object). Property accessors (get_/set_/op_) are
        // skipped — properties are surfaced via PropertyInfo below.
        const BindingFlags flags =
            BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.DeclaredOnly;
        foreach (var m in cls.GetMethods(flags))
        {
            if (m.IsSpecialName) continue;
            members.Add(m.Name);
        }
        foreach (var p in cls.GetProperties(flags))
        {
            members.Add(p.Name);
        }
        // Inherited public properties (e.g. from base classes that aren't
        // System.Object) — skip object's own surface.
        foreach (var p in cls.GetProperties(BindingFlags.Instance | BindingFlags.Public))
        {
            if (p.DeclaringType == typeof(object)) continue;
            members.Add(p.Name);
        }

        // Extension methods that target this type. An extension method is a
        // public static method on a public static class with [Extension] on
        // the method, whose first parameter type is `this <cls>`.
        foreach (var asm in extensionAssemblies)
        {
            Type[] types;
            try { types = asm.GetTypes(); }
            catch (ReflectionTypeLoadException ex) { types = ex.Types.Where(t => t != null).Cast<Type>().ToArray(); }
            foreach (var t in types)
            {
                if (!t.IsSealed || !t.IsAbstract) continue; // static class
                foreach (var m in t.GetMethods(BindingFlags.Public | BindingFlags.Static))
                {
                    if (!m.IsDefined(typeof(System.Runtime.CompilerServices.ExtensionAttribute), false))
                        continue;
                    var ps = m.GetParameters();
                    if (ps.Length == 0) continue;
                    if (ps[0].ParameterType.IsAssignableFrom(cls))
                    {
                        members.Add(m.Name);
                    }
                }
            }
        }

        return members;
    }

    private static IEnumerable<Assembly> AdapterAssemblies()
    {
        // Touch each adapter type so its assembly is loaded. We use the
        // public ShieldExtensions class in each one as a guaranteed entry
        // point. Returning the assembly list lets the extension-method walk
        // discover With<Framework>().
        yield return typeof(Shield).Assembly; // self
        yield return typeof(global::AgentShield.OpenAI.ShieldExtensions).Assembly;
        yield return typeof(global::AgentShield.Anthropic.ShieldExtensions).Assembly;
        yield return typeof(global::AgentShield.SemanticKernel.ShieldExtensions).Assembly;
        yield return typeof(global::AgentShield.AutoGen.ShieldExtensions).Assembly;
        yield return typeof(global::AgentShield.AI.ShieldExtensions).Assembly;
        yield return typeof(global::AgentShield.MCP.MCPShield).Assembly;
    }

    [Fact]
    public void Shield_HasEveryCanonicalMethodUnderItsDotnetAlias()
    {
        using var canonical = LoadCanonical();
        var members = PublicMembers(typeof(Shield), AdapterAssemblies());
        var missing = new List<(string canonical, string alias)>();
        foreach (var entry in canonical.RootElement.GetProperty("shield_methods").EnumerateArray())
        {
            if (!Includes(entry.GetProperty("must_exist_in"), Lang)) continue;
            var alias = entry.GetProperty("aliases").GetProperty(Lang).GetString()!;
            if (!members.Contains(alias))
            {
                missing.Add((entry.GetProperty("name").GetString()!, alias));
            }
        }
        Assert.True(
            missing.Count == 0,
            $"Shield is missing {missing.Count} canonical method(s) under their .NET aliases: " +
            string.Join(", ", missing.Select(m => $"{m.canonical}->{m.alias}")) +
            ". Either add the method to sdk/dotnet/src/AgentShield/Shield.cs (or expose it via " +
            "an extension method on AgentShield.*) or remove 'dotnet' from `must_exist_in` in " +
            "tests/parity/shield_canonical_api.json (and document the drift in `drift_catalog`).");
    }

    [Fact]
    public void ShieldBuilder_HasEveryCanonicalMethodUnderItsDotnetAlias()
    {
        using var canonical = LoadCanonical();
        var members = PublicMembers(typeof(ShieldBuilder), AdapterAssemblies());
        var missing = new List<(string canonical, string alias)>();
        foreach (var entry in canonical.RootElement.GetProperty("shield_builder_methods").EnumerateArray())
        {
            if (!Includes(entry.GetProperty("must_exist_in"), Lang)) continue;
            var alias = entry.GetProperty("aliases").GetProperty(Lang).GetString()!;
            if (!members.Contains(alias))
            {
                missing.Add((entry.GetProperty("name").GetString()!, alias));
            }
        }
        Assert.True(
            missing.Count == 0,
            $"ShieldBuilder is missing {missing.Count} canonical method(s) under their .NET aliases: " +
            string.Join(", ", missing.Select(m => $"{m.canonical}->{m.alias}")) +
            ". Either add the method to sdk/dotnet/src/AgentShield/ShieldBuilder.cs (or expose " +
            "it via an extension method) or remove 'dotnet' from `must_exist_in` in " +
            "tests/parity/shield_canonical_api.json.");
    }

    [Fact]
    public void NoUndeclaredDotnetExtensionsOnShieldOrBuilder()
    {
        using var canonical = LoadCanonical();
        var canonicalShield = new HashSet<string>(StringComparer.Ordinal);
        foreach (var entry in canonical.RootElement.GetProperty("shield_methods").EnumerateArray())
        {
            if (entry.GetProperty("aliases").TryGetProperty(Lang, out var alias))
                canonicalShield.Add(alias.GetString()!);
        }
        var canonicalBuilder = new HashSet<string>(StringComparer.Ordinal);
        foreach (var entry in canonical.RootElement.GetProperty("shield_builder_methods").EnumerateArray())
        {
            if (entry.GetProperty("aliases").TryGetProperty(Lang, out var alias))
                canonicalBuilder.Add(alias.GetString()!);
        }
        var declaredExtensions = canonical.RootElement
            .GetProperty("language_specific_extensions")
            .GetProperty(Lang);
        var extShield = declaredExtensions.GetProperty("shield")
            .EnumerateArray().Select(v => v.GetString()!).ToHashSet();
        var extBuilder = declaredExtensions.GetProperty("shield_builder")
            .EnumerateArray().Select(v => v.GetString()!).ToHashSet();

        var asms = AdapterAssemblies().ToList();
        var shieldActual = PublicMembers(typeof(Shield), asms);
        var builderActual = PublicMembers(typeof(ShieldBuilder), asms);

        var undeclaredShield = shieldActual
            .Where(n => !canonicalShield.Contains(n) && !extShield.Contains(n))
            .OrderBy(s => s).ToList();
        var undeclaredBuilder = builderActual
            .Where(n => !canonicalBuilder.Contains(n) && !extBuilder.Contains(n))
            .OrderBy(s => s).ToList();

        var msgParts = new List<string>();
        if (undeclaredShield.Count > 0)
            msgParts.Add($"Shield has {undeclaredShield.Count} undeclared public method(s): [{string.Join(", ", undeclaredShield)}]");
        if (undeclaredBuilder.Count > 0)
            msgParts.Add($"ShieldBuilder has {undeclaredBuilder.Count} undeclared public method(s): [{string.Join(", ", undeclaredBuilder)}]");

        Assert.True(
            msgParts.Count == 0,
            "Undeclared public surface in .NET — every public method must be either in " +
            "`shield_methods`/`shield_builder_methods` (cross-language canonical) or in " +
            "`language_specific_extensions.dotnet` (.NET-only) in " +
            "tests/parity/shield_canonical_api.json. Found:\n  - " + string.Join("\n  - ", msgParts));
    }

    private static bool Includes(JsonElement arr, string value)
    {
        foreach (var v in arr.EnumerateArray())
            if (v.GetString() == value) return true;
        return false;
    }
}
