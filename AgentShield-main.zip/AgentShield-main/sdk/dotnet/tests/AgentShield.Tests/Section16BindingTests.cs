using System;
using System.IO;
using System.Text.Json;
using Xunit;

using AgentShield;

namespace AgentShield.Tests;

/// <summary>
/// Cross-SDK parity tests for spec §16.0 invocation-bound verdict
/// semantics.
///
/// The Rust core already exercises every §16.0 corner case in
/// <c>sdk/rust/agent_shield_core/tests/runtime.rs</c> (see the
/// <c>stage4_*</c> tests). This file verifies that the **.NET SDK
/// surface** preserves the same semantics — i.e.
/// <c>InvocationHash</c> / <c>PostValidationInvocationHash</c> cross
/// the P/Invoke boundary correctly and the <c>toolCallId</c> parameter
/// on <see cref="GuardrailsSession.ValidateToolCall"/> /
/// <see cref="GuardrailsSession.ValidateToolOutput"/> actually drives
/// the §16.0 binding cache.
///
/// Mirror suites:
/// <list type="bullet">
///   <item>sdk/python/tests/test_section_16_binding.py</item>
///   <item>sdk/node/__tests__/section_16_binding.test.ts</item>
/// </list>
/// </summary>
public class Section16BindingTests
{
    private const string FixtureYaml = """
metadata:
  name: "section-16-binding-parity"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test §16.0 invocation binding"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "send_email"
      description: "Send an email."
      permission: "execute"
post_tool_validation:
  guard_policies:
    - name: "result_recipient_must_match_call_recipient"
      evaluate_when:
        - expression: '@tool.params.recipient == @result.matched_recipient'
          reason: "§16.0: Stage 4 bound to the wrong invocation."
""";

    private static GuardrailsSession NewSession(GuardrailsRuntime rt)
    {
        var s = rt.NewSession();
        s.BeginTurn();
        return s;
    }

    private static GuardrailsRuntime BuildRuntime()
    {
        using var b = RuntimeBuilder.FromYamlStrings(new[] { FixtureYaml });
        return b.Build();
    }

    private static JsonElement Json(string raw) =>
        JsonDocument.Parse(raw).RootElement.Clone();

    // ─────────────────────────────────────────────────────────────────
    // Scenario 1: Stage 3 + Stage 4 with matching id surfaces non-null
    // invocation_hash / post_validation_invocation_hash.
    // ─────────────────────────────────────────────────────────────────

    [Fact]
    public void Stage3ThenStage4WithMatchingIdSurfacesHashes()
    {
        using var rt = BuildRuntime();
        using var s = NewSession(rt);

        var (callVerdict, _) = s.ValidateToolCall(
            "send_email",
            Json("""{"recipient":"alice@example.com","body":"hi"}"""),
            "call_alice_1");
        Assert.True(callVerdict.Allowed, "§16.0: Stage 3 should pass — no Stage-3 policies");

        var (outVerdict, _) = s.ValidateToolOutput(
            "send_email",
            Json("""{"matched_recipient":"alice@example.com","sent":true}"""),
            "call_alice_1");
        Assert.True(outVerdict.Allowed,
            $"§16.0: Stage 4 must bind to the recorded Stage-3 invocation; verdict was {outVerdict}");
        Assert.False(string.IsNullOrEmpty(outVerdict.InvocationHash),
            "§16.0: Stage 4 must surface InvocationHash when bound");
        Assert.False(string.IsNullOrEmpty(outVerdict.PostValidationInvocationHash),
            "§16.0: Stage 4 must surface PostValidationInvocationHash");
    }

    // ─────────────────────────────────────────────────────────────────
    // Scenario 2: parallel same-name calls with distinct ids each bind
    // to their own Stage-3 invocation; the two invocation_hashes MUST
    // differ.
    // ─────────────────────────────────────────────────────────────────

    [Fact]
    public void ParallelSameNameDistinctIdsBindIndependently()
    {
        using var rt = BuildRuntime();
        using var s = NewSession(rt);

        var (vCallA, _) = s.ValidateToolCall(
            "send_email",
            Json("""{"recipient":"alice@example.com","body":"hi alice"}"""),
            "call_alice_1");
        Assert.True(vCallA.Allowed);

        var (vCallB, _) = s.ValidateToolCall(
            "send_email",
            Json("""{"recipient":"bob@example.com","body":"hi bob"}"""),
            "call_bob_2");
        Assert.True(vCallB.Allowed);

        // Stage 4 in OPPOSITE order: bob first, alice second.
        var (vOutB, _) = s.ValidateToolOutput(
            "send_email",
            Json("""{"matched_recipient":"bob@example.com","sent":true}"""),
            "call_bob_2");
        Assert.True(vOutB.Allowed,
            $"§16.0: bob Stage 4 must bind to call_bob_2 invocation; verdict was {vOutB}");

        var (vOutA, _) = s.ValidateToolOutput(
            "send_email",
            Json("""{"matched_recipient":"alice@example.com","sent":true}"""),
            "call_alice_1");
        Assert.True(vOutA.Allowed,
            $"§16.0: alice Stage 4 must bind to call_alice_1 invocation; verdict was {vOutA}");

        var hashA = vOutA.InvocationHash;
        var hashB = vOutB.InvocationHash;
        Assert.False(string.IsNullOrEmpty(hashA));
        Assert.False(string.IsNullOrEmpty(hashB));
        Assert.NotEqual(hashA, hashB);
    }

    // ─────────────────────────────────────────────────────────────────
    // Scenario 3: Stage 4 with a tool_call_id that never had a Stage 3
    // entry MUST fail closed; the deny verdict MUST NOT advertise an
    // invocation_hash.
    // ─────────────────────────────────────────────────────────────────

    [Fact]
    public void Stage4WithUnknownIdFailsClosed()
    {
        using var rt = BuildRuntime();
        using var s = NewSession(rt);

        var (verdict, _) = s.ValidateToolOutput(
            "send_email",
            Json("""{"matched_recipient":"alice@example.com","sent":true}"""),
            "never_validated_call_id");

        Assert.False(verdict.Allowed,
            $"§16.0: Stage 4 with unknown tool_call_id must fail closed; verdict was {verdict}");
        Assert.Equal("<binding>", verdict.Policy);
        Assert.True(string.IsNullOrEmpty(verdict.InvocationHash),
            "§16.0: fail-closed binding verdict must not advertise an InvocationHash");
    }

    // ─────────────────────────────────────────────────────────────────
    // Scenario 4: Stage 4 with a DIFFERENT explicit id than the Stage 3
    // admit MUST fail closed — there is no synthetic fallback path when
    // the binding key does not match.
    // ─────────────────────────────────────────────────────────────────

    [Fact]
    public void Stage4WithMismatchedExplicitIdFailsClosed()
    {
        using var rt = BuildRuntime();
        using var s = NewSession(rt);

        s.ValidateToolCall(
            "send_email",
            Json("""{"recipient":"alice@example.com","body":"hi"}"""),
            "call_alice_1");

        var (verdict, _) = s.ValidateToolOutput(
            "send_email",
            Json("""{"matched_recipient":"alice@example.com","sent":true}"""),
            "call_alice_2");

        Assert.False(verdict.Allowed,
            $"§16.0: Stage 4 with mismatched tool_call_id must fail closed; verdict was {verdict}");
        Assert.Equal("<binding>", verdict.Policy);
        Assert.True(string.IsNullOrEmpty(verdict.InvocationHash));
        Assert.True(string.IsNullOrEmpty(verdict.PostValidationInvocationHash));
    }
}
