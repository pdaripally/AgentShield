using System;
using System.Collections.Generic;
using System.Text.Json;
using Xunit;

namespace AgentShield.Tests;

/// <summary>
/// Tests for <see cref="ConfigurationLlmCaller.Create"/> — cross-SDK
/// parity helper. Mirrors the Python
/// <c>test_configuration_dispatcher.py</c>, the Node
/// <c>configuration_caller.test.ts</c>, and the Rust unit tests in
/// <c>runtime/configuration_caller.rs</c>.
/// </summary>
public class ConfigurationLlmCallerTests
{
    private sealed class RecordingCaller : ILlmCaller
    {
        private readonly string _label;
        public List<string> Prompts { get; } = new();

        public RecordingCaller(string label) { _label = label; }

        public LlmResponse Call(LlmRequest request)
        {
            Prompts.Add(request.Prompt);
            return new LlmResponse("allow", Reason: $"{_label}:{request.Prompt}");
        }
    }

    private static LlmRequest Req(string? configurationId, string prompt)
        => new(configurationId, prompt, prompt, default(JsonElement));

    [Fact]
    public void ExactMatch_RoutesToRegisteredCaller()
    {
        var input = new RecordingCaller("input");
        var tool = new RecordingCaller("tool");

        var dispatcher = ConfigurationLlmCaller.Create(new Dictionary<string, ILlmCaller>
        {
            ["input_llm"] = input,
            ["tool_execution_llm"] = tool,
        });

        Assert.Equal("input:hello", dispatcher.Call(Req("input_llm", "hello")).Reason);
        Assert.Equal("tool:calc", dispatcher.Call(Req("tool_execution_llm", "calc")).Reason);
        Assert.Equal(new[] { "hello" }, input.Prompts);
        Assert.Equal(new[] { "calc" }, tool.Prompts);
    }

    [Fact]
    public void SubstringMatch_DoesNotRoute()
    {
        // 'my_input_check' contains 'input' — exact match only.
        var input = new RecordingCaller("input");
        var fallback = new RecordingCaller("default");

        var dispatcher = ConfigurationLlmCaller.Create(
            new Dictionary<string, ILlmCaller> { ["input_llm"] = input },
            fallback);

        Assert.Equal("default:hello", dispatcher.Call(Req("my_input_check", "hello")).Reason);
        Assert.Empty(input.Prompts);
        Assert.Equal(new[] { "hello" }, fallback.Prompts);
    }

    [Fact]
    public void Default_UsedForUnknownId()
    {
        var fallback = new RecordingCaller("default");
        var dispatcher = ConfigurationLlmCaller.Create(
            new Dictionary<string, ILlmCaller>(), fallback);

        Assert.Equal("default:x", dispatcher.Call(Req("never_registered", "x")).Reason);
    }

    [Fact]
    public void Default_UsedWhenConfigurationIdIsNull()
    {
        var fallback = new RecordingCaller("default");
        var dispatcher = ConfigurationLlmCaller.Create(
            new Dictionary<string, ILlmCaller> { ["input_llm"] = new RecordingCaller("input") },
            fallback);

        Assert.Equal("default:x", dispatcher.Call(Req(null, "x")).Reason);
    }

    [Fact]
    public void NoDefault_UnknownId_Throws()
    {
        var dispatcher = ConfigurationLlmCaller.Create(new Dictionary<string, ILlmCaller>
        {
            ["input_llm"] = new RecordingCaller("input"),
        });

        var ex = Assert.Throws<InvalidOperationException>(
            () => dispatcher.Call(Req("unknown_id", "x")));
        Assert.Contains("no LLM caller registered", ex.Message);
        Assert.Contains("'input_llm'", ex.Message);
        Assert.Contains("'unknown_id'", ex.Message);
        Assert.Contains("no default provided", ex.Message);
    }

    [Fact]
    public void NoDefault_NullId_ErrorRepresentsAsLiteralNull()
    {
        // Cross-SDK parity: Python/Node/Rust render the missing id as
        // either a quoted string or the literal `null`. The .NET helper
        // must match — bare unquoted text would diverge.
        var dispatcher = ConfigurationLlmCaller.Create(
            new Dictionary<string, ILlmCaller>());
        var ex = Assert.Throws<InvalidOperationException>(
            () => dispatcher.Call(Req(null, "x")));
        Assert.Contains("configurationId=null", ex.Message);
    }

    [Fact]
    public void Dispatcher_TakesDefensiveCopy()
    {
        var caller = new RecordingCaller("a");
        var callers = new Dictionary<string, ILlmCaller> { ["a"] = caller };
        var dispatcher = ConfigurationLlmCaller.Create(callers);
        // Mutate the source — dispatcher must still route.
        callers.Clear();
        Assert.Equal("a:x", dispatcher.Call(Req("a", "x")).Reason);
    }

    [Fact]
    public void Create_NullCallers_Throws()
    {
        Assert.Throws<ArgumentNullException>(
            () => ConfigurationLlmCaller.Create(null!));
    }
}
