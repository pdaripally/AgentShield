using System;
using System.IO;
using Xunit;

namespace AgentShield.Tests;

/// <summary>
/// Tests for <see cref="Shield.WithFreshSession"/>, the functional
/// sibling of <see cref="Shield.WithSession"/> that satisfies the
/// post-build immutability contract documented in
/// <c>spec/SPECIFICATION.md</c>.
///
/// Mirrors the Rust <c>with_fresh_session.rs</c> integration test,
/// the Node <c>__tests__/with_fresh_session.test.ts</c> suite, and
/// the Python <c>tests/test_with_fresh_session.py</c> suite. All four
/// SDKs expose the same shape so customers can move between language
/// runtimes without re-learning the lifecycle.
/// </summary>
public class WithFreshSessionTests
{
    private readonly string _fixturePath;

    public WithFreshSessionTests()
    {
        _fixturePath = FindTestFixture();
    }

    private static string FindTestFixture()
    {
        var dir = AppContext.BaseDirectory;
        while (dir != null && !File.Exists(Path.Combine(dir, "tests", "fixtures", "test-guardrails.yaml")))
            dir = Directory.GetParent(dir)?.FullName;
        if (dir == null)
            throw new FileNotFoundException("Could not locate tests/fixtures/test-guardrails.yaml");
        return Path.Combine(dir, "tests", "fixtures", "test-guardrails.yaml");
    }

    [Fact]
    public void WithFreshSession_ReturnsNewShield()
    {
        using var original = Shield.FromYaml(_fixturePath).Build();
        using var forked = original.WithFreshSession();

        // (1) Different Shield instances.
        Assert.NotSame(original, forked);

        // (3) Different Session instances (forked has a fresh one).
        Assert.NotSame(original.Session, forked.Session);

        // (4) Both Shields share the same underlying runtime — forking
        // must be cheap and never rebuild the policy graph.
        Assert.Same(original.Runtime, forked.Runtime);
    }

    [Fact]
    public void WithFreshSession_DoesNotMutateOriginal()
    {
        using var original = Shield.FromYaml(_fixturePath).Build();
        var originalSessionRef = original.Session;

        using var forked = original.WithFreshSession();

        // (2) Original.Session is still the SAME instance — no in-place
        // swap. Customers holding an `original` reference see no change.
        Assert.Same(originalSessionRef, original.Session);
    }

    [Fact]
    public void WithFreshSession_PreservesShieldConfig()
    {
        using var original = Shield.FromYaml(_fixturePath)
            .WithMode(ShieldMode.Monitor)
            .Build();
        using var forked = original.WithFreshSession();

        // Config (mode, on-block, capability, bundle) carries over —
        // the only thing that changes is the session.
        Assert.Equal(original.Mode, forked.Mode);
        Assert.Same(original.Capabilities, forked.Capabilities);
        Assert.Equal(original.Bundle, forked.Bundle);
    }

    [Fact]
    public void WithFreshSession_OriginalSurvivesForkDispose()
    {
        using var original = Shield.FromYaml(_fixturePath).Build();
        var originalSession = original.Session;

        var forked = original.WithFreshSession();
        forked.Dispose();

        // Disposing the fork must NOT dispose the runtime (only the
        // original owns it). Using `original` afterwards must still
        // work — its session is alive and its runtime is alive.
        Assert.Same(originalSession, original.Session);
        // Session reference is still readable and matches what we had.
        Assert.NotNull(original.Runtime);
    }

    [Fact]
    public void WithFreshSession_ThrowsAfterDispose()
    {
        var shield = Shield.FromYaml(_fixturePath).Build();
        shield.Dispose();

        Assert.Throws<GuardrailsDisposedException>(() => shield.WithFreshSession());
    }
}
