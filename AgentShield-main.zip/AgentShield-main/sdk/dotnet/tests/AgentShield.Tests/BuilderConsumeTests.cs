using System;
using System.IO;

using Xunit;

namespace AgentShield.Tests;

/// <summary>
/// Verifies that <see cref="ShieldBuilder"/> consumes itself on a successful
/// <see cref="ShieldBuilder.Build"/> call. After the first <c>Build()</c>
/// every subsequent call (including <c>With*</c> registrations) must throw
/// <see cref="InvalidOperationException"/> with a clear, actionable message.
/// </summary>
public class BuilderConsumeTests
{
    private const string ExpectedMessage =
        "ShieldBuilder.Build() can only be called once. " +
        "Call Shield.FromYaml(...) again to create a new builder.";

    private static string FixturePath()
    {
        var dir = AppContext.BaseDirectory;
        while (dir != null && !File.Exists(Path.Combine(dir, "tests", "fixtures", "test-guardrails.yaml")))
            dir = Directory.GetParent(dir)?.FullName;
        if (dir == null)
            throw new FileNotFoundException("Could not locate tests/fixtures/test-guardrails.yaml");
        return Path.Combine(dir, "tests", "fixtures", "test-guardrails.yaml");
    }

    [Fact]
    public void FirstBuildReturnsWorkingShield()
    {
        using var shield = Shield.FromYaml(FixturePath()).Build();
        Assert.NotNull(shield);
        Assert.NotNull(shield.Capabilities);
    }

    [Fact]
    public void SecondBuildThrowsInvalidOperationException()
    {
        var builder = Shield.FromYaml(FixturePath());
        using var first = builder.Build();

        var ex = Assert.Throws<InvalidOperationException>(() => builder.Build());
        Assert.Equal(ExpectedMessage, ex.Message);
    }

    [Fact]
    public void WithMethodAfterBuildThrowsInvalidOperationException()
    {
        var builder = Shield.FromYaml(FixturePath());
        using var first = builder.Build();

        var ex = Assert.Throws<InvalidOperationException>(() => builder.WithMode(ShieldMode.Monitor));
        Assert.Equal(ExpectedMessage, ex.Message);
    }

    [Fact]
    public void WithOnBlockAfterBuildThrowsInvalidOperationException()
    {
        var builder = Shield.FromYaml(FixturePath());
        using var first = builder.Build();

        var ex = Assert.Throws<InvalidOperationException>(
            () => builder.WithOnBlock(OnBlockPolicy.Raise));
        Assert.Equal(ExpectedMessage, ex.Message);
    }

    [Fact]
    public void FreshFromYamlAfterBuildProducesIndependentBuilder()
    {
        // First build consumes its own builder.
        using var first = Shield.FromYaml(FixturePath()).Build();

        // A fresh FromYaml() must always produce a buildable, independent
        // builder. This documents the customer-facing escape hatch.
        using var second = Shield.FromYaml(FixturePath()).WithMode(ShieldMode.Monitor).Build();
        Assert.NotNull(second);
    }
}
