using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using Xunit;

namespace AgentShield.Tests;

/// <summary>
/// Cross-language CapabilityReport conformance test for the .NET SDK.
///
/// For every adapter the canonical matrix says .NET implements, this test
/// reads the live <see cref="CapabilityReport"/> exposed by the adapter's
/// static class and asserts it matches
/// <c>applyOverrides(canonical, "dotnet")</c> from
/// <c>tests/parity/capability_canonical.json</c>.
///
/// Adding a <c>language_overrides.dotnet</c> entry documents accepted
/// divergence; removing one forces the .NET adapter to align.
/// </summary>
public class CapabilityParityTests
{
    private const string Lang = "dotnet";
    private static readonly string RepoRoot = FindRepoRoot();
    private static readonly string CanonicalPath =
        Path.Combine(RepoRoot, "tests", "parity", "capability_canonical.json");

    private static readonly string[] StageFields =
    {
        "input_validation",
        "state_validation",
        "tool_authorization",
        "tool_execution_validation",
        "tool_output_validation",
        "output_validation",
        "streaming_output",
    };

    private static string FindRepoRoot()
    {
        var dir = AppContext.BaseDirectory;
        while (dir is not null && !Directory.Exists(Path.Combine(dir, ".git")))
            dir = Path.GetDirectoryName(dir);
        return dir ?? throw new InvalidOperationException("repo root not found");
    }

    private static JsonDocument LoadCanonical()
    {
        var raw = File.ReadAllText(CanonicalPath);
        return JsonDocument.Parse(raw);
    }

    private static string LevelToString(CoverageLevel level) => level switch
    {
        CoverageLevel.Full => "full",
        CoverageLevel.Partial => "partial",
        CoverageLevel.Unsupported => "unsupported",
        _ => throw new InvalidOperationException($"unknown CoverageLevel {level}"),
    };

    private static IDictionary<string, string> ReportToDict(CapabilityReport report)
    {
        return new Dictionary<string, string>
        {
            ["framework"] = report.Framework,
            ["input_validation"] = LevelToString(report.InputValidation),
            ["state_validation"] = LevelToString(report.StateValidation),
            ["tool_authorization"] = LevelToString(report.ToolAuthorization),
            ["tool_execution_validation"] = LevelToString(report.ToolExecutionValidation),
            ["tool_output_validation"] = LevelToString(report.ToolOutputValidation),
            ["output_validation"] = LevelToString(report.OutputValidation),
            ["streaming_output"] = LevelToString(report.StreamingOutput),
        };
    }

    private static IDictionary<string, string> ExpectedFor(JsonDocument canonical, string fw)
    {
        var entry = canonical.RootElement.GetProperty("frameworks").GetProperty(fw);
        var canonicalClaim = entry.GetProperty("canonical");
        var dict = new Dictionary<string, string>
        {
            ["framework"] = canonicalClaim.GetProperty("framework").GetString()!,
        };
        foreach (var stage in StageFields)
        {
            if (canonicalClaim.TryGetProperty(stage, out var v))
                dict[stage] = v.GetString()!;
        }
        if (entry.TryGetProperty("language_overrides", out var overrides) &&
            overrides.TryGetProperty(Lang, out var langOverrides))
        {
            foreach (var prop in langOverrides.EnumerateObject())
            {
                if (prop.Name.StartsWith("$")) continue;
                if (prop.Value.ValueKind == JsonValueKind.String)
                    dict[prop.Name] = prop.Value.GetString()!;
            }
        }
        return dict;
    }

    private static void AssertMatches(
        string framework,
        IDictionary<string, string> expected,
        CapabilityReport actual)
    {
        var actualDict = ReportToDict(actual);
        Assert.True(
            expected["framework"] == actualDict["framework"],
            $"[{framework}] framework name drift: actual={actualDict["framework"]} " +
            $"expected={expected["framework"]}. Either update the .NET adapter or move " +
            $"this divergence into language_overrides.{Lang} in tests/parity/capability_canonical.json.");

        var diffs = new List<string>();
        foreach (var stage in StageFields)
        {
            var exp = expected.TryGetValue(stage, out var e) ? e : null;
            var act = actualDict.TryGetValue(stage, out var a) ? a : null;
            if (exp != act)
                diffs.Add($"  {stage}: actual={act} expected={exp}");
        }
        Assert.True(
            diffs.Count == 0,
            $"[{framework}] capability drift between .NET and the canonical matrix:\n" +
            string.Join("\n", diffs) +
            $"\nTo accept this divergence, add the field to " +
            $"`frameworks.{framework}.language_overrides.{Lang}` in " +
            "tests/parity/capability_canonical.json.");
    }

    [Fact]
    public void OpenAIAgents_Capability_MatchesCanonical()
    {
        using var canonical = LoadCanonical();
        AssertMatches(
            "openai_agents",
            ExpectedFor(canonical, "openai_agents"),
            global::AgentShield.OpenAI.ShieldExtensions.CapabilityReport);
    }

    [Fact]
    public void Anthropic_Capability_MatchesCanonical()
    {
        using var canonical = LoadCanonical();
        AssertMatches(
            "anthropic_agents",
            ExpectedFor(canonical, "anthropic_agents"),
            global::AgentShield.Anthropic.ShieldExtensions.CapabilityReport);
    }

    [Fact]
    public void SemanticKernel_Capability_MatchesCanonical()
    {
        using var canonical = LoadCanonical();
        AssertMatches(
            "semantic_kernel",
            ExpectedFor(canonical, "semantic_kernel"),
            global::AgentShield.SemanticKernel.ShieldExtensions.CapabilityReport);
    }

    [Fact]
    public void AutoGen_Capability_MatchesCanonical()
    {
        using var canonical = LoadCanonical();
        AssertMatches(
            "autogen",
            ExpectedFor(canonical, "autogen"),
            global::AgentShield.AutoGen.ShieldExtensions.CapabilityReport);
    }

    [Fact]
    public void MicrosoftExtensionsAi_Capability_MatchesCanonical()
    {
        using var canonical = LoadCanonical();
        AssertMatches(
            "microsoft.extensions.ai",
            ExpectedFor(canonical, "microsoft.extensions.ai"),
            global::AgentShield.AI.ShieldExtensions.CapabilityReport);
    }

    [Fact]
    public void Mcp_Capability_MatchesCanonical()
    {
        using var canonical = LoadCanonical();
        // MCP exposes its CapabilityReport via instance property; build a
        // throwaway MCPShield to read it.
        var mcpShield = global::AgentShield.MCP.MCPShield
            .FromYaml(Path.Combine(RepoRoot, "tests", "fixtures", "smoke", "minimal.guardrails.yaml"))
            .Build();
        AssertMatches("mcp", ExpectedFor(canonical, "mcp"), mcpShield.Capabilities);
    }

    [Fact]
    public void EveryDotnetFrameworkInCanonical_HasATest()
    {
        using var canonical = LoadCanonical();
        var declared = new List<string>();
        foreach (var prop in canonical.RootElement.GetProperty("frameworks").EnumerateObject())
        {
            var implementedIn = prop.Value.GetProperty("implemented_in");
            if (implementedIn.EnumerateArray().Any(v => v.GetString() == Lang))
                declared.Add(prop.Name);
        }
        declared.Sort(StringComparer.Ordinal);

        var expectedTests = new[]
        {
            "anthropic_agents",
            "autogen",
            "mcp",
            "microsoft.extensions.ai",
            "openai_agents",
            "semantic_kernel",
        };
        Assert.Equal(expectedTests.OrderBy(s => s, StringComparer.Ordinal),
                     declared);
    }
}
