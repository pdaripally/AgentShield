using System;
using System.Collections.Generic;
using System.IO;
using AgentShield;
using Xunit;

namespace AgentShield.Tests;

public class GuardrailsConfigTests
{
    private static readonly string MinimalFixture = Path.Combine(
        FindRepoRoot(),
        "tests", "fixtures", "smoke", "minimal.guardrails.yaml");

    private static string FindRepoRoot()
    {
        var dir = AppContext.BaseDirectory;
        while (dir is not null && !Directory.Exists(Path.Combine(dir, ".git")))
        {
            dir = Path.GetDirectoryName(dir);
        }
        return dir ?? throw new InvalidOperationException("repo root not found");
    }

    // ── Constructors ─────────────────────────────────────────────

    [Fact]
    public void Load_FromPath()
    {
        var cfg = GuardrailsConfig.Load(MinimalFixture);
        Assert.Equal(1, cfg.Count);
    }

    [Fact]
    public void FromString_RawYaml()
    {
        var text = File.ReadAllText(MinimalFixture);
        var cfg = GuardrailsConfig.FromString(text);
        Assert.Equal(1, cfg.Count);
    }

    [Fact]
    public void FromObject_Dictionary()
    {
        var cfg = GuardrailsConfig.FromObject(new Dictionary<string, object?>
        {
            ["metadata"] = new Dictionary<string, object?>
            {
                ["name"] = "x",
                ["version"] = "0.1.0",
            },
        });
        Assert.Equal(1, cfg.Count);
    }

    [Fact]
    public void Compose_ChainsMultipleSources()
    {
        var cfg = GuardrailsConfig.Compose(
            MinimalFixture,
            new Dictionary<string, object?>
            {
                ["metadata"] = new Dictionary<string, object?>
                {
                    ["description"] = "overlay",
                },
            });
        Assert.Equal(2, cfg.Count);
    }

    [Fact]
    public void Compose_EmptyThrows()
    {
        Assert.Throws<ArgumentException>(() => GuardrailsConfig.Compose());
    }

    // ── Fluent extension ─────────────────────────────────────────

    [Fact]
    public void Extend_ReturnsNewInstance()
    {
        var a = GuardrailsConfig.Load(MinimalFixture);
        var b = a.Extend(new Dictionary<string, object?>
        {
            ["metadata"] = new Dictionary<string, object?>
            {
                ["description"] = "leaf",
            },
        });
        Assert.Equal(1, a.Count);
        Assert.Equal(2, b.Count);
    }

    [Fact]
    public void WithOverrides_AppendsDictLayer()
    {
        var cfg = GuardrailsConfig.Load(MinimalFixture)
            .WithOverrides(new Dictionary<string, object?>
            {
                ["metadata"] = new Dictionary<string, object?>
                {
                    ["description"] = "monitoring",
                },
            });
        Assert.Equal(2, cfg.Count);
    }

    [Fact]
    public void WithPolicyPack_DictionaryPath()
    {
        var cfg = GuardrailsConfig.Load(MinimalFixture)
            .WithPolicyPack(new Dictionary<string, object?>
            {
                ["metadata"] = new Dictionary<string, object?>
                {
                    ["description"] = "tenant pack",
                },
            });
        Assert.Equal(2, cfg.Count);
    }

    // ── Compilation ──────────────────────────────────────────────

    [Fact]
    public void Compile_YieldsYamlStringsAndSha256()
    {
        var compiled = GuardrailsConfig.Load(MinimalFixture).Compile();
        Assert.Single(compiled.YamlStrings);
        Assert.Contains("smoke-minimal", compiled.YamlStrings[0]);
        Assert.Equal(64, compiled.Digest.Length);
        Assert.Matches("^[0-9a-f]+$", compiled.Digest);
        Assert.Equal(compiled.Digest, compiled.Hash);
    }

    [Fact]
    public void Compile_DeterministicForSameContent()
    {
        var a = GuardrailsConfig.Load(MinimalFixture).Compile();
        var b = GuardrailsConfig.Load(MinimalFixture).Compile();
        Assert.Equal(a, b);
        Assert.Equal(a.Digest, b.Digest);
        Assert.Equal(a.GetHashCode(), b.GetHashCode());
    }

    [Fact]
    public void Compile_DiffersWhenLayersChange()
    {
        var a = GuardrailsConfig.Load(MinimalFixture).Compile();
        var b = GuardrailsConfig.Load(MinimalFixture)
            .WithOverrides(new Dictionary<string, object?>
            {
                ["metadata"] = new Dictionary<string, object?>
                {
                    ["description"] = "different",
                },
            })
            .Compile();
        Assert.NotEqual(a, b);
        Assert.NotEqual(a.Digest, b.Digest);
    }

    // ── RuntimeBuilder.FromConfig ─────────────────────────────────

    [Fact]
    public void FromConfig_AcceptsCompiledPolicy()
    {
        var compiled = GuardrailsConfig.Load(MinimalFixture).Compile();
        using var rt = RuntimeBuilder.FromConfig(compiled).Build();
        Assert.NotNull(rt);
    }

    [Fact]
    public void FromConfig_AcceptsGuardrailsConfig()
    {
        var cfg = GuardrailsConfig.Load(MinimalFixture);
        using var rt = RuntimeBuilder.FromConfig(cfg).Build();
        Assert.NotNull(rt);
    }

    [Fact]
    public void FromYamlStrings_RoundTrips()
    {
        var text = File.ReadAllText(MinimalFixture);
        using var rt = RuntimeBuilder.FromYamlStrings(new[] { text }).Build();
        Assert.NotNull(rt);
    }

    [Fact]
    public void CompiledPolicy_CacheableByDigest()
    {
        var a = GuardrailsConfig.Load(MinimalFixture).Compile();
        var b = GuardrailsConfig.Load(MinimalFixture).Compile();
        var cache = new Dictionary<string, string>();
        cache[a.Digest] = "runtime-A";
        Assert.Equal("runtime-A", cache[b.Digest]);
    }
}

public class CapabilityReportTests
{
    [Fact]
    public void DefaultsAllStagesToFull()
    {
        var rep = new CapabilityReport("test");
        Assert.True(rep.IsFullCoverage());
    }

    [Fact]
    public void HonoursPerStageOverrides()
    {
        var rep = new CapabilityReport(
            "test",
            streamingOutput: CoverageLevel.Unsupported);
        Assert.False(rep.IsFullCoverage());
        Assert.Equal(CoverageLevel.Unsupported, rep.StreamingOutput);
    }

    [Fact]
    public void NotesAreCarriedThrough()
    {
        var rep = new CapabilityReport(
            "test",
            notes: new[] { "caveat 1", "caveat 2" });
        Assert.Equal(2, rep.Notes.Count);
        Assert.Contains("caveat 1", rep.Notes);
    }
}

public class AgentShieldBlockedExceptionTests
{
    [Fact]
    public void CarriesVerdictAndMessage()
    {
        var exc = new AgentShieldBlockedException(null, "blocked");
        Assert.Equal("blocked", exc.Message);
        Assert.Null(exc.Verdict);
        Assert.IsAssignableFrom<Exception>(exc);
    }
}
