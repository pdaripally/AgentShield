using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using NJsonSchema;
using Xunit;

namespace AgentShield.Tests;

/// <summary>
/// Cross-language wire-shape golden fixture conformance for the .NET SDK.
///
/// Mirrors <c>sdk/python/tests/test_wire_fixtures.py</c> and
/// <c>sdk/node/__tests__/wire_fixtures.test.ts</c>. All three suites
/// run against the same fixtures under <c>tests/fixtures/wire/</c>
/// and the same schemas under <c>spec/schemas/wire/</c>.
/// </summary>
public class WireFixtureTests
{
    private static readonly string RepoRoot = FindRepoRoot();
    private static readonly string SchemasDir =
        Path.Combine(RepoRoot, "spec", "schemas", "wire");
    private static readonly string FixturesDir =
        Path.Combine(RepoRoot, "tests", "fixtures", "wire");

    private static string FindRepoRoot()
    {
        var dir = AppContext.BaseDirectory;
        while (dir is not null && !Directory.Exists(Path.Combine(dir, ".git")))
            dir = Path.GetDirectoryName(dir);
        return dir ?? throw new InvalidOperationException("repo root not found");
    }

    public static IEnumerable<object[]> AllFixtures()
    {
        foreach (var shapeDir in Directory.EnumerateDirectories(FixturesDir).OrderBy(d => d))
        {
            var shape = Path.GetFileName(shapeDir);
            var schemaPath = Path.Combine(SchemasDir, $"{shape}.schema.json");
            if (!File.Exists(schemaPath))
            {
                throw new FileNotFoundException(
                    $"No schema for fixture shape {shape}: {schemaPath}");
            }
            foreach (var fixture in Directory.EnumerateFiles(shapeDir, "*.json").OrderBy(f => f))
            {
                yield return new object[] { shape, fixture, schemaPath };
            }
        }
    }

    [Theory]
    [MemberData(nameof(AllFixtures))]
    public void Fixture_IsJsonObject(string shape, string fixturePath, string schemaPath)
    {
        var json = File.ReadAllText(fixturePath);
        using var doc = JsonDocument.Parse(json);
        Assert.Equal(JsonValueKind.Object, doc.RootElement.ValueKind);
    }

    [Theory]
    [MemberData(nameof(AllFixtures))]
    public void Fixture_ValidatesAgainstSchema(string shape, string fixturePath, string schemaPath)
    {
        var schema = JsonSchema.FromFileAsync(schemaPath).GetAwaiter().GetResult();
        var fixture = File.ReadAllText(fixturePath);
        var errors = schema.Validate(fixture);
        Assert.True(
            errors.Count == 0,
            $"{shape}/{Path.GetFileName(fixturePath)}: " +
            string.Join("; ", errors.Select(e => $"{e.Path}: {e.Kind}")));
    }

    [Theory]
    [MemberData(nameof(AllFixtures))]
    public void Fixture_RoundTripsThroughJson(string shape, string fixturePath, string schemaPath)
    {
        var schema = JsonSchema.FromFileAsync(schemaPath).GetAwaiter().GetResult();
        using var doc = JsonDocument.Parse(File.ReadAllText(fixturePath));

        var reserialised = JsonSerializer.Serialize(
            doc.RootElement,
            new JsonSerializerOptions { WriteIndented = false });

        var errors = schema.Validate(reserialised);
        Assert.True(
            errors.Count == 0,
            $"Round-trip {shape}/{Path.GetFileName(fixturePath)}: " +
            string.Join("; ", errors.Select(e => $"{e.Path}: {e.Kind}")));
    }

    [Theory]
    [MemberData(nameof(AllFixtures))]
    public void Fixture_UsesSnakeCase(string shape, string fixturePath, string schemaPath)
    {
        using var doc = JsonDocument.Parse(File.ReadAllText(fixturePath));
        foreach (var key in AllKeys(doc.RootElement))
        {
            Assert.False(
                key.Any(char.IsUpper),
                $"Key '{key}' in {fixturePath} has uppercase characters " +
                "(canonical wire format is snake_case)");
        }
    }

    private static IEnumerable<string> AllKeys(JsonElement element)
    {
        if (element.ValueKind == JsonValueKind.Object)
        {
            foreach (var prop in element.EnumerateObject())
            {
                yield return prop.Name;
                foreach (var child in AllKeys(prop.Value))
                    yield return child;
            }
        }
        else if (element.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in element.EnumerateArray())
                foreach (var child in AllKeys(item))
                    yield return child;
        }
    }

    [Fact]
    public void EverySchemaHasAtLeastOneFixture()
    {
        foreach (var schema in Directory.EnumerateFiles(SchemasDir, "*.schema.json"))
        {
            var shape = Path.GetFileNameWithoutExtension(schema)
                .Replace(".schema", "");
            var dir = Path.Combine(FixturesDir, shape);
            Assert.True(Directory.Exists(dir),
                $"Schema {Path.GetFileName(schema)} has no fixtures dir");
            var files = Directory.GetFiles(dir, "*.json");
            Assert.True(files.Length > 0,
                $"Schema {Path.GetFileName(schema)} has no fixtures in {dir}");
        }
    }

    [Fact]
    public void NoOrphanFixtureDirectories()
    {
        foreach (var dir in Directory.EnumerateDirectories(FixturesDir))
        {
            var shape = Path.GetFileName(dir);
            var schemaPath = Path.Combine(SchemasDir, $"{shape}.schema.json");
            Assert.True(File.Exists(schemaPath),
                $"Fixture directory {shape} has no matching schema");
        }
    }
}
