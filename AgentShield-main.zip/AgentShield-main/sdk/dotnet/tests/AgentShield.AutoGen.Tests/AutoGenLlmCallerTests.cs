using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

using AutoGen.Core;
using Xunit;

using AgentShield;

namespace AgentShield.AutoGen.Tests;

/// <summary>
/// Asserts that <c>.guardrails.yaml</c> <c>configurations[]</c>
/// entries actually drive the Stage 1/3 LLM-judge invocation on .NET
/// / AutoGen — i.e. that a
/// <c>configurations: [{id: stage1-judge, type: llm, max_tokens: 256}]</c>
/// entry is not silently dropped when routed through
/// <see cref="AutoGenLlmCaller"/>. Mirrors the
/// <see cref="AgentShield.AI.Tests.LlmCallerTests"/> shape on the
/// Microsoft.Extensions.AI adapter and the
/// <c>SKLlmCallerTests</c> shape on the Semantic Kernel adapter.
///
/// <para>
/// Unlike SK / MEAI, AutoGen .NET binds the model at agent
/// construction time — <see cref="GenerateReplyOptions"/> has no
/// model-override field. The cfg <c>model:</c> is therefore NOT
/// asserted here; only <c>max_tokens</c> and <c>temperature</c>
/// (which AutoGen's reply API does accept) are.
/// </para>
/// </summary>
public class AutoGenLlmCallerTests
{
    // ───────────────────────────────────────────────────────────────────
    // AutoGenLlmCaller — cfg passthrough via GenerateReplyOptions

    [Fact]
    public void Caller_ForwardsMaxTokens_FromYamlConfiguration()
    {
        using var rt = GuardrailsRuntime.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"));

        var recorder = new RecordingAgent(JsonAllow());
        var caller = new AutoGenLlmCaller(recorder);
        caller.Bind(rt);

        var ctx = JsonDocument.Parse("{}").RootElement;
        caller.Call(new LlmRequest("stage1-judge", "is the input safe?", "", ctx));
        caller.Call(new LlmRequest("stage3-judge", "is the tool call safe?", "", ctx));

        Assert.Equal(2, recorder.Calls.Count);
        // stage1-judge declares max_tokens: 256 in YAML.
        Assert.Equal(256, recorder.Calls[0].Options?.MaxToken);
        // stage3-judge has no max_tokens in YAML, no temperature in
        // metadata => no options envelope needed.
        Assert.Null(recorder.Calls[1].Options);
    }

    [Fact]
    public void Caller_ForwardsTemperature_FromCfgMetadata()
    {
        using var rt = GuardrailsRuntime.FromYaml(FindFixture("autogen-llm-caller-test.guardrails.yaml"));

        var recorder = new RecordingAgent(JsonAllow());
        var caller = new AutoGenLlmCaller(recorder);
        caller.Bind(rt);

        var ctx = JsonDocument.Parse("{}").RootElement;
        caller.Call(new LlmRequest("temperature-judge", "judge", "", ctx));

        Assert.Single(recorder.Calls);
        Assert.NotNull(recorder.Calls[0].Options);
        Assert.Equal(0.3f, recorder.Calls[0].Options!.Temperature);
    }

    [Fact]
    public void Caller_FallsBackToAgentDefaults_WhenNoMatchingConfiguration()
    {
        using var rt = GuardrailsRuntime.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"));

        var recorder = new RecordingAgent(JsonAllow());
        var caller = new AutoGenLlmCaller(recorder);
        caller.Bind(rt);

        var ctx = JsonDocument.Parse("{}").RootElement;
        // ConfigurationId null => no lookup.
        caller.Call(new LlmRequest(null, "judge", "", ctx));
        // ConfigurationId references a non-existent entry => lookup misses.
        caller.Call(new LlmRequest("not-in-yaml", "judge", "", ctx));

        Assert.Equal(2, recorder.Calls.Count);
        // No cfg => no options sent => agent uses construction-time defaults.
        Assert.Null(recorder.Calls[0].Options);
        Assert.Null(recorder.Calls[1].Options);
    }

    [Fact]
    public void Caller_ParsesJsonBlockVerdict()
    {
        using var rt = GuardrailsRuntime.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"));

        var recorder = new RecordingAgent(JsonBlock("policy violation"));
        var caller = new AutoGenLlmCaller(recorder);
        caller.Bind(rt);

        var resp = caller.Call(new LlmRequest("stage1-judge", "input?", "",
            JsonDocument.Parse("{}").RootElement));

        Assert.Equal("block", resp.Decision);
        Assert.Equal("policy violation", resp.Reason);
    }

    // ───────────────────────────────────────────────────────────────────
    // End-to-end: Stage 1 + Stage 3 invocations routed through the
    // ShieldBuilder.WithAutoGenLlmJudge fluent extension.

    [Fact]
    public void Stage1_RoutesThroughAutoGenJudgeAgent()
    {
        var recorder = new RecordingAgent(JsonAllow());
        using var shield = Shield.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"))
            .WithAutoGenLlmJudge(recorder)
            .Build();

        var verdict = shield.Session.ValidateInput("hello");

        Assert.True(verdict.Allowed);
        Assert.Single(recorder.Calls);
        Assert.Equal(256, recorder.Calls[0].Options?.MaxToken);
    }

    [Fact]
    public void Stage3_RoutesThroughAutoGenJudgeAgent()
    {
        var recorder = new RecordingAgent(JsonAllow());
        using var shield = Shield.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"))
            .WithAutoGenLlmJudge(recorder)
            .Build();

        var args = JsonDocument.Parse("{\"x\":1}").RootElement;
        var (verdict, _) = shield.Session.ValidateToolCall("safe_tool", args, "call_1");

        Assert.True(verdict.Allowed);
        // stage3-judge has no max_tokens in YAML — the cfg doesn't
        // forward an options envelope. We just assert the agent was
        // invoked at least once for Stage 3.
        Assert.NotEmpty(recorder.Calls);
    }

    [Fact]
    public void WithAutoGenLlmJudge_NullArgs_Throws()
    {
        using var rt = GuardrailsRuntime.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"));
        var builder = Shield.FromRuntime(rt);
        Assert.Throws<ArgumentNullException>(() => ((ShieldBuilder?)null)!.WithAutoGenLlmJudge(
            new RecordingAgent(JsonAllow())));
        Assert.Throws<ArgumentNullException>(() => builder.WithAutoGenLlmJudge(null!));
    }

    // ───────────────────────────────────────────────────────────────────
    // Helpers

    private static string JsonAllow() => "{\"decision\":\"allow\",\"confidence\":1.0}";

    private static string JsonBlock(string reason)
        => $"{{\"decision\":\"block\",\"confidence\":1.0,\"reason\":\"{reason}\"}}";

    private static string FindFixture(string name)
    {
        var dir = AppContext.BaseDirectory;
        while (dir != null)
        {
            var candidate = Path.Combine(dir, "tests", "fixtures", name);
            if (File.Exists(candidate)) return candidate;
            if (File.Exists(Path.Combine(dir, "AgentShield.sln")))
            {
                var path = Path.Combine(dir, "tests", "fixtures", name);
                if (File.Exists(path)) return path;
            }
            dir = Directory.GetParent(dir)?.FullName;
        }
        throw new FileNotFoundException($"Test fixture not found: {name}");
    }

    /// <summary>
    /// Minimal <see cref="IAgent"/> that records the
    /// <see cref="GenerateReplyOptions"/> it was invoked with so
    /// tests can inspect <see cref="GenerateReplyOptions.MaxToken"/>
    /// / <see cref="GenerateReplyOptions.Temperature"/>. Returns a
    /// constant JSON-verdict response wrapped in a
    /// <see cref="TextMessage"/>.
    /// </summary>
    private sealed class RecordingAgent : IAgent
    {
        private readonly string _response;
        public List<RecordedCall> Calls { get; } = new();

        public RecordingAgent(string response)
        {
            _response = response;
        }

        public string Name => "recording-judge";

        public Task<IMessage> GenerateReplyAsync(
            IEnumerable<IMessage> messages,
            GenerateReplyOptions? options = null,
            CancellationToken cancellationToken = default)
        {
            Calls.Add(new RecordedCall(options));
            IMessage reply = new TextMessage(Role.Assistant, _response, Name);
            return Task.FromResult(reply);
        }
    }

    private sealed record RecordedCall(GenerateReplyOptions? Options);
}
