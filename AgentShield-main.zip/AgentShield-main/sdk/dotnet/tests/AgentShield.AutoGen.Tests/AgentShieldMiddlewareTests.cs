using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using AutoGen.Core;
using Moq;
using Xunit;

using AgentShield;

namespace AgentShield.AutoGen.Tests;

/// <summary>
/// Boundary tests for <see cref="AgentShieldMiddleware"/> and
/// <see cref="ToolProtection"/>. Drives the AutoGen middleware
/// shape with a mocked <see cref="IAgent"/> against the canonical
/// minimal smoke fixture.
/// </summary>
public class AgentShieldMiddlewareTests : IDisposable
{
    private readonly GuardrailsRuntime _runtime;

    public AgentShieldMiddlewareTests()
    {
        _runtime = GuardrailsRuntime.FromYaml(MinimalFixture);
    }

    public void Dispose() => _runtime.Dispose();

    private static string SmokeFixturesDir
    {
        get
        {
            var dir = AppContext.BaseDirectory;
            while (dir != null && !Directory.Exists(Path.Combine(dir, "tests", "fixtures", "smoke")))
            {
                dir = Directory.GetParent(dir)?.FullName;
            }
            if (dir == null)
                throw new DirectoryNotFoundException("Could not locate tests/fixtures/smoke");
            return Path.Combine(dir, "tests", "fixtures", "smoke");
        }
    }

    private static string MinimalFixture =>
        Path.Combine(SmokeFixturesDir, "minimal.guardrails.yaml");

    private static JsonElement Parse(string json) =>
        JsonDocument.Parse(json).RootElement.Clone();

    // ── Construction ────────────────────────────────────────────

    [Fact]
    public void Middleware_NullRuntime_Throws()
    {
        Assert.Throws<ArgumentNullException>(() => new AgentShieldMiddleware(null!));
    }

    [Fact]
    public void Middleware_Constructs_AndExposesName()
    {
        var middleware = new AgentShieldMiddleware(_runtime);
        Assert.Equal("AgentShield", middleware.Name);
    }

    // ── InvokeAsync (Stage 1 + Stage 5) ─────────────────────────

    [Fact]
    public async Task InvokeAsync_BenignInput_PassesThroughToAgent()
    {
        var middleware = new AgentShieldMiddleware(_runtime);
        var agentResponse = new TextMessage(Role.Assistant, "Hello!", "TestAgent");

        var mockAgent = new Mock<IAgent>();
        mockAgent.Setup(a => a.Name).Returns("TestAgent");
        mockAgent
            .Setup(a => a.GenerateReplyAsync(
                It.IsAny<IEnumerable<IMessage>>(),
                It.IsAny<GenerateReplyOptions?>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(agentResponse);

        var messages = new IMessage[]
        {
            new TextMessage(Role.User, "Hello, how are you?", "User"),
        };
        var context = new MiddlewareContext(messages, null);

        var result = await middleware.InvokeAsync(context, mockAgent.Object);

        Assert.Equal("Hello!", result.GetContent());
        mockAgent.Verify(a => a.GenerateReplyAsync(
            It.IsAny<IEnumerable<IMessage>>(),
            It.IsAny<GenerateReplyOptions?>(),
            It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task InvokeAsync_NoUserMessage_StillInvokesAgent()
    {
        var middleware = new AgentShieldMiddleware(_runtime);
        var agentResponse = new TextMessage(Role.Assistant, "ok", "TestAgent");

        var mockAgent = new Mock<IAgent>();
        mockAgent.Setup(a => a.Name).Returns("TestAgent");
        mockAgent
            .Setup(a => a.GenerateReplyAsync(
                It.IsAny<IEnumerable<IMessage>>(),
                It.IsAny<GenerateReplyOptions?>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(agentResponse);

        var messages = new IMessage[]
        {
            new TextMessage(Role.System, "system prompt", "system"),
        };
        var context = new MiddlewareContext(messages, null);

        var result = await middleware.InvokeAsync(context, mockAgent.Object);

        Assert.Equal("ok", result.GetContent());
    }

    [Fact]
    public async Task InvokeAsync_EmptyAssistantOutput_PassesThrough()
    {
        var middleware = new AgentShieldMiddleware(_runtime);
        var agentResponse = new TextMessage(Role.Assistant, "", "TestAgent");

        var mockAgent = new Mock<IAgent>();
        mockAgent.Setup(a => a.Name).Returns("TestAgent");
        mockAgent
            .Setup(a => a.GenerateReplyAsync(
                It.IsAny<IEnumerable<IMessage>>(),
                It.IsAny<GenerateReplyOptions?>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(agentResponse);

        var messages = new IMessage[]
        {
            new TextMessage(Role.User, "ping", "User"),
        };
        var context = new MiddlewareContext(messages, null);

        var result = await middleware.InvokeAsync(context, mockAgent.Object);

        // Empty content → middleware returns the underlying reply unchanged.
        Assert.Equal("", result.GetContent());
    }

    // ── Stage 2/3 (tool execution) ──────────────────────────────

    /// <summary>
    /// Build an inline runtime that has a Stage 2/3 BLOCK policy
    /// targeted at <c>blocked_tool</c>. Used to drive
    /// "tool call → Stage 2/3 block".
    /// </summary>
    private static GuardrailsRuntime BuildToolBlockRuntime() =>
        RuntimeBuilder.FromYamlStrings(new[] { """
            metadata:
              name: "autogen-stage23-block"
              version: "0.1.0"
              agent_shield_version: "2.0"
            objective:
              goal:
                - "Block a specific tool name."
            resources:
              tools:
                - name: "safe_tool"
                  description: "An allowed tool."
                  permission: "read_only"
                - name: "blocked_tool"
                  description: "A forbidden tool."
                  permission: "read_only"
            tool_execution_validation:
              guard_policies:
                - name: "block_blocked_tool"
                  applies_to:
                    tools: ["blocked_tool"]
                  action: "block"
                  evaluate_when:
                    - expression: "false"
                      reason: "Tool is blocked by policy"
            """ }).Build();

    [Fact]
    public async Task InvokeAsync_ToolCall_Stage2Or3Block_ShortCircuitsToResult()
    {
        using var runtime = BuildToolBlockRuntime();
        var middleware = new AgentShieldMiddleware(runtime);

        var toolCall = new ToolCallMessage(
            new[] { new ToolCall("blocked_tool", "{\"x\":1}") { ToolCallId = "tc_1" } },
            "TestAgent");

        var mockAgent = new Mock<IAgent>();
        mockAgent.Setup(a => a.Name).Returns("TestAgent");
        mockAgent
            .Setup(a => a.GenerateReplyAsync(
                It.IsAny<IEnumerable<IMessage>>(),
                It.IsAny<GenerateReplyOptions?>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(toolCall);

        var context = new MiddlewareContext(
            new IMessage[] { new TextMessage(Role.User, "go", "User") }, null);

        var result = await middleware.InvokeAsync(context, mockAgent.Object);

        // Reply was short-circuited: consumer sees a ToolCallResultMessage
        // (so downstream FunctionCallMiddleware will treat it as "already
        // executed") carrying the block reason.
        var resultMsg = Assert.IsType<ToolCallResultMessage>(result);
        Assert.Single(resultMsg.ToolCalls);
        Assert.Equal("blocked_tool", resultMsg.ToolCalls[0].FunctionName);
        Assert.Equal("tc_1", resultMsg.ToolCalls[0].ToolCallId);
        Assert.NotNull(resultMsg.ToolCalls[0].Result);
        Assert.Contains("[Blocked by Agent Shield]", resultMsg.ToolCalls[0].Result!);
        Assert.Contains("blocked_tool", resultMsg.ToolCalls[0].Result!);
    }

    /// <summary>
    /// Build an inline runtime with a Stage 2/3 REDACT policy that
    /// strips SSNs from tool params for <c>safe_tool</c>. Drives
    /// "tool call → Stage 3 mutation → raw tool receives mutated params".
    /// </summary>
    private static GuardrailsRuntime BuildToolRedactRuntime() =>
        RuntimeBuilder.FromYamlStrings(new[] { """
            metadata:
              name: "autogen-stage3-redact"
              version: "0.1.0"
              agent_shield_version: "2.0"
            objective:
              goal:
                - "Strip SSNs from tool params."
            resources:
              tools:
                - name: "safe_tool"
                  description: "Tool whose args may contain SSN."
                  permission: "read_only"
            tool_execution_validation:
              guard_policies:
                - name: "redact_args_ssn"
                  applies_to:
                    tools: ["safe_tool"]
                  action: "redact"
                  replacement: "[REDACTED]"
                  evaluate_when:
                    - patterns:
                        - "\\b\\d{3}-\\d{2}-\\d{4}\\b"
                      reason: "SSN in tool arg"
            """ }).Build();

    [Fact]
    public async Task InvokeAsync_ToolCall_Stage3Mutation_PropagatesMutatedArgs()
    {
        using var runtime = BuildToolRedactRuntime();
        var middleware = new AgentShieldMiddleware(runtime);

        var rawArgs = "{\"note\":\"SSN is 123-45-6789\"}";
        var toolCall = new ToolCallMessage(
            new[] { new ToolCall("safe_tool", rawArgs) { ToolCallId = "tc_99" } },
            "TestAgent");

        var mockAgent = new Mock<IAgent>();
        mockAgent.Setup(a => a.Name).Returns("TestAgent");
        mockAgent
            .Setup(a => a.GenerateReplyAsync(
                It.IsAny<IEnumerable<IMessage>>(),
                It.IsAny<GenerateReplyOptions?>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(toolCall);

        var context = new MiddlewareContext(
            new IMessage[] { new TextMessage(Role.User, "call safe_tool", "User") }, null);

        var result = await middleware.InvokeAsync(context, mockAgent.Object);

        // Reply remains a ToolCallMessage so downstream FunctionCallMiddleware
        // can still execute, but its FunctionArguments are the post-Stage-3
        // mutated form — the raw tool will see the redacted params.
        var passed = Assert.IsType<ToolCallMessage>(result);
        Assert.Single(passed.ToolCalls);
        Assert.Equal("tc_99", passed.ToolCalls[0].ToolCallId);
        Assert.DoesNotContain("123-45-6789", passed.ToolCalls[0].FunctionArguments);
        Assert.Contains("[REDACTED]", passed.ToolCalls[0].FunctionArguments);
    }

    // ── Stage 4 (post-tool) ─────────────────────────────────────

    /// <summary>
    /// Inline runtime with a Stage 4 redact policy that strips SSNs
    /// from tool *output*. Drives "tool result → Stage 4 redaction".
    /// </summary>
    private static GuardrailsRuntime BuildPostToolRedactRuntime() =>
        RuntimeBuilder.FromYamlStrings(new[] { """
            metadata:
              name: "autogen-stage4-redact"
              version: "0.1.0"
              agent_shield_version: "2.0"
            objective:
              goal:
                - "Strip SSNs from tool results."
            resources:
              tools:
                - name: "safe_tool"
                  description: "Tool whose result may contain SSN."
                  permission: "read_only"
            post_tool_validation:
              guard_policies:
                - name: "redact_output_ssn"
                  action: "redact"
                  replacement: "[REDACTED]"
                  evaluate_when:
                    - patterns:
                        - "\\b\\d{3}-\\d{2}-\\d{4}\\b"
                      reason: "SSN in tool result"
            """ }).Build();

    [Fact]
    public async Task InvokeAsync_ToolResult_Stage4Redact_RedactsResultText()
    {
        using var runtime = BuildPostToolRedactRuntime();
        var middleware = new AgentShieldMiddleware(runtime);

        // §16.0 — Stage 4 binds to the Stage 3 admit. The middleware
        // walks a ToolCallAggregateMessage as call-then-result, so a
        // single aggregate exercises the prebind + redact pair under
        // one tool_call_id.
        var callMsg = new ToolCallMessage(
            new[]
            {
                new ToolCall("safe_tool", "{}") { ToolCallId = "tc_42" },
            },
            "TestAgent");
        var resultMsg = new ToolCallResultMessage(
            new[]
            {
                new ToolCall("safe_tool", "{}", "the SSN is 123-45-6789, take note")
                { ToolCallId = "tc_42" },
            },
            "TestAgent");
        var aggregate = new ToolCallAggregateMessage(callMsg, resultMsg, "TestAgent");

        var mockAgent = new Mock<IAgent>();
        mockAgent.Setup(a => a.Name).Returns("TestAgent");
        mockAgent
            .Setup(a => a.GenerateReplyAsync(
                It.IsAny<IEnumerable<IMessage>>(),
                It.IsAny<GenerateReplyOptions?>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(aggregate);

        var context = new MiddlewareContext(
            new IMessage[] { new TextMessage(Role.User, "show data", "User") }, null);

        var guarded = await middleware.InvokeAsync(context, mockAgent.Object);

        var guardedAgg = Assert.IsType<ToolCallAggregateMessage>(guarded);
        var redacted = Assert.IsType<ToolCallResultMessage>(guardedAgg.Message2);
        Assert.Single(redacted.ToolCalls);
        Assert.Equal("tc_42", redacted.ToolCalls[0].ToolCallId);
        Assert.NotNull(redacted.ToolCalls[0].Result);
        Assert.DoesNotContain("123-45-6789", redacted.ToolCalls[0].Result!);
        Assert.Contains("[REDACTED]", redacted.ToolCalls[0].Result!);
    }

    // ── Tool failure → RecordToolFailure ────────────────────────

    [Fact]
    public async Task InvokeAsync_ToolExecutionThrows_RecordsFailureAndRethrows()
    {
        // When the inbound context ends in a ToolCallMessage (meaning
        // the inner pipeline is about to execute the call), an
        // exception thrown by the inner agent is treated as a
        // tool-execution failure. The middleware MUST:
        //   1. Call RecordToolFailure for each inbound tool name
        //      (best-effort, no throw allowed to escape).
        //   2. Rethrow the original exception so the framework still
        //      sees the failure.
        using var runtime = BuildToolRedactRuntime();
        var middleware = new AgentShieldMiddleware(runtime);

        var inboundCall = new ToolCallMessage(
            new[] { new ToolCall("safe_tool", "{\"x\":1}") { ToolCallId = "tc_err" } },
            "User");

        var mockAgent = new Mock<IAgent>();
        mockAgent.Setup(a => a.Name).Returns("TestAgent");
        mockAgent
            .Setup(a => a.GenerateReplyAsync(
                It.IsAny<IEnumerable<IMessage>>(),
                It.IsAny<GenerateReplyOptions?>(),
                It.IsAny<CancellationToken>()))
            .ThrowsAsync(new InvalidOperationException("boom in safe_tool"));

        var context = new MiddlewareContext(new IMessage[] { inboundCall }, null);

        var ex = await Assert.ThrowsAsync<InvalidOperationException>(
            () => middleware.InvokeAsync(context, mockAgent.Object));
        Assert.Equal("boom in safe_tool", ex.Message);
        // RecordToolFailure is best-effort — the side effect is logged
        // through the runtime's observability hook. We rely on the
        // *invocation itself* not throwing (which would have surfaced
        // here as a different exception) to assert the call happened.
    }
}

/// <summary>
/// Boundary tests for the <see cref="ToolProtection"/> static helpers
/// — the host-driven Stage 2/3 + Stage 4 entry points that wrap an
/// existing session.
/// </summary>
public class ToolProtectionTests : IDisposable
{
    private readonly GuardrailsRuntime _runtime;

    public ToolProtectionTests()
    {
        _runtime = GuardrailsRuntime.FromYaml(MinimalFixture);
    }

    public void Dispose() => _runtime.Dispose();

    private static string SmokeFixturesDir
    {
        get
        {
            var dir = AppContext.BaseDirectory;
            while (dir != null && !Directory.Exists(Path.Combine(dir, "tests", "fixtures", "smoke")))
            {
                dir = Directory.GetParent(dir)?.FullName;
            }
            if (dir == null)
                throw new DirectoryNotFoundException("Could not locate tests/fixtures/smoke");
            return Path.Combine(dir, "tests", "fixtures", "smoke");
        }
    }

    private static string MinimalFixture =>
        Path.Combine(SmokeFixturesDir, "minimal.guardrails.yaml");

    private static JsonElement Parse(string json) =>
        JsonDocument.Parse(json).RootElement.Clone();

    [Fact]
    public void GuardToolCall_Authorized_AllowsAndReturnsParameters()
    {
        using var session = _runtime.NewSession();
        session.SetVariable("authorized", Parse("true"));

        var mutated = ToolProtection.GuardToolCall(session, "echo", Parse("{\"msg\":\"hi\"}"));

        Assert.Equal("hi", mutated.GetProperty("msg").GetString());
    }

    [Fact]
    public void GuardToolCall_Unauthorized_ThrowsBlocked()
    {
        using var session = _runtime.NewSession();

        var ex = Assert.Throws<GuardrailsException>(
            () => ToolProtection.GuardToolCall(session, "echo", Parse("{\"msg\":\"hi\"}")));

        Assert.Contains("echo", ex.Message);
        Assert.Contains("blocked", ex.Message, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void GuardToolCall_PreservesScalarTypes()
    {
        using var session = _runtime.NewSession();
        session.SetVariable("authorized", Parse("true"));

        var mutated = ToolProtection.GuardToolCall(
            session, "echo", Parse("{\"msg\":\"x\",\"n\":7,\"flag\":true}"));

        Assert.Equal("x", mutated.GetProperty("msg").GetString());
        Assert.Equal(7, mutated.GetProperty("n").GetInt32());
        Assert.True(mutated.GetProperty("flag").GetBoolean());
    }

    [Fact]
    public void GuardToolOutput_BenignResult_PassesThrough()
    {
        using var session = _runtime.NewSession();
        session.SetVariable("authorized", Parse("true"));

        // §16.0 — Stage 4 MUST bind back to the same canonical
        // invocation Stage 3 admitted, so the caller threads the SAME
        // toolCallId through both helpers.
        var id = Guid.NewGuid().ToString("N");
        ToolProtection.GuardToolCall(session, "echo", Parse("{\"msg\":\"hi\"}"), id);

        var result = Parse("{\"echoed\":\"hi\"}");
        var mutated = ToolProtection.GuardToolOutput(session, "echo", result, id);

        Assert.Equal("hi", mutated.GetProperty("echoed").GetString());
    }

    [Fact]
    public void GuardToolOutput_NullSession_Throws()
    {
        // The static helper deref's `session` immediately — null in
        // means a NullReferenceException, which proves we don't try
        // to silently allow a missing session.
        Assert.ThrowsAny<Exception>(() =>
            ToolProtection.GuardToolOutput(null!, "echo", Parse("{}")));
    }
}
