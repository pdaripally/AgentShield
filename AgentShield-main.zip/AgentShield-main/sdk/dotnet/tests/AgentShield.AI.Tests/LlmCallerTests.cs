using System.Collections.Concurrent;
using System.Runtime.CompilerServices;
using System.Text.Json;

using Microsoft.Extensions.AI;
using Xunit;

using AgentShield;

namespace AgentShield.AI.Tests;

/// <summary>
/// Asserts that <c>.guardrails.yaml</c> <c>configurations[]</c>
/// entries actually drive which model the Stage 1/3 LLM judge calls
/// on .NET — i.e. that a <c>configurations: [{id: stage1-judge,
/// type: llm, model: gpt-4o}]</c> entry is not silently overridden
/// by a hard-coded fallback when routed through
/// <see cref="MEAILlmCaller"/>. Mirrors the
/// <c>test_oai_agents_llm_caller_model.py</c> Python parity test.
/// </summary>
public class LlmCallerTests
{
    // ───────────────────────────────────────────────────────────────────
    // Runtime.LlmConfiguration accessor

    [Fact]
    public void LlmConfiguration_ReturnsYamlFields_ForKnownId()
    {
        using var rt = GuardrailsRuntime.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"));

        var cfg = rt.LlmConfiguration("stage1-judge");

        Assert.NotNull(cfg);
        Assert.Equal("stage1-judge", cfg!.Id);
        Assert.Equal("llm", cfg.Type);
        Assert.Equal("gpt-4o", cfg.Model);
        Assert.Equal("openai.chat", cfg.Provider);
        Assert.Equal((uint)256, cfg.MaxTokens);
    }

    [Fact]
    public void LlmConfiguration_ReturnsModel_ForAzureEntry()
    {
        using var rt = GuardrailsRuntime.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"));

        var cfg = rt.LlmConfiguration("azure-judge");

        Assert.NotNull(cfg);
        Assert.Equal("azure-judge", cfg!.Id);
        // On Azure OpenAI, `model:` is the deployment name (the
        // string the provider SDK accepts as the model identifier).
        Assert.Equal("my-azure-deployment", cfg.Model);
        Assert.Equal("azure_openai", cfg.Provider);
    }

    [Fact]
    public void LlmConfiguration_ReturnsNull_ForUnknownId()
    {
        using var rt = GuardrailsRuntime.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"));

        Assert.Null(rt.LlmConfiguration("does-not-exist"));
    }

    // ───────────────────────────────────────────────────────────────────
    // MEAILlmCaller — model selection from configurations[]

    [Fact]
    public void Caller_UsesYamlModel_ForEachConfigurationId()
    {
        using var rt = GuardrailsRuntime.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"));

        var recorder = new RecordingChatClient(JsonAllow());
        var caller = new MEAILlmCaller(recorder);
        caller.Bind(rt);

        var ctx = JsonDocument.Parse("{}").RootElement;
        caller.Call(new LlmRequest("stage1-judge", "is the input safe?", "", ctx));
        caller.Call(new LlmRequest("stage3-judge", "is the tool call safe?", "", ctx));

        Assert.Equal(2, recorder.Calls.Count);
        Assert.Equal("gpt-4o", recorder.Calls[0].ModelId);
        Assert.Equal(256, recorder.Calls[0].MaxOutputTokens);
        Assert.Equal("gpt-4o-mini-with-context", recorder.Calls[1].ModelId);
        // stage3-judge has no max_tokens in YAML => must NOT be set.
        Assert.Null(recorder.Calls[1].MaxOutputTokens);
    }

    [Fact]
    public void Caller_UsesYamlModel_ForAzureProvider()
    {
        using var rt = GuardrailsRuntime.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"));

        var recorder = new RecordingChatClient(JsonAllow());
        var caller = new MEAILlmCaller(recorder);
        caller.Bind(rt);

        caller.Call(new LlmRequest("azure-judge", "judge", "", JsonDocument.Parse("{}").RootElement));

        Assert.Single(recorder.Calls);
        // On Azure OpenAI, `model:` is the deployment name — the
        // provider SDK takes the string verbatim. The adapter does
        // not translate or synthesize based on `provider:`.
        Assert.Equal("my-azure-deployment", recorder.Calls[0].ModelId);
    }

    [Fact]
    public void Caller_RaisesConfigurationMissingModelError_WhenNoMatchingConfiguration()
    {
        using var rt = GuardrailsRuntime.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"));

        var recorder = new RecordingChatClient(JsonAllow());
        var caller = new MEAILlmCaller(recorder);
        caller.Bind(rt);

        var ctx = JsonDocument.Parse("{}").RootElement;
        // ConfigurationId is null => no lookup → typed error (a security
        // library MUST NOT pick a model on the customer's behalf).
        var ex1 = Assert.Throws<ConfigurationMissingModelException>(() =>
            caller.Call(new LlmRequest(null, "judge", "", ctx)));
        Assert.Null(ex1.ConfigurationId);

        // ConfigurationId references a non-existent entry => lookup
        // misses → same typed error.
        var ex2 = Assert.Throws<ConfigurationMissingModelException>(() =>
            caller.Call(new LlmRequest("not-in-yaml", "judge", "", ctx)));
        Assert.Equal("not-in-yaml", ex2.ConfigurationId);

        Assert.Empty(recorder.Calls);
    }

    // ───────────────────────────────────────────────────────────────────
    // End-to-end: Stage 1 + Stage 3 invocations routed through the
    // ShieldBuilder.WithLlmJudge fluent extension.

    [Fact]
    public void Stage1_RoutesThroughConfiguredJudgeModel()
    {
        var recorder = new RecordingChatClient(JsonAllow());
        using var shield = Shield.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"))
            .WithLlmJudge(recorder)
            .Build();

        var verdict = shield.Session.ValidateInput("hello");

        Assert.True(verdict.Allowed);
        Assert.Single(recorder.Calls);
        Assert.Equal("gpt-4o", recorder.Calls[0].ModelId);
        Assert.Equal(256, recorder.Calls[0].MaxOutputTokens);
    }

    [Fact]
    public void Stage3_RoutesThroughConfiguredJudgeModel()
    {
        var recorder = new RecordingChatClient(JsonAllow());
        using var shield = Shield.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"))
            .WithLlmJudge(recorder)
            .Build();

        var args = JsonDocument.Parse("{\"x\":1}").RootElement;
        var (verdict, _) = shield.Session.ValidateToolCall("safe_tool", args, "call_1");

        Assert.True(verdict.Allowed);
        // Stage 3 is the LLM-judge stage that consults `stage3-judge`.
        // The recorder must have captured at least one call against the
        // stage3-judge model — the engine may emit additional state-stage
        // calls but the stage3 model id must appear.
        Assert.Contains(recorder.Calls, c => c.ModelId == "gpt-4o-mini-with-context");
    }

    [Fact]
    public void Stage1_BlockedByLlmJudge_WhenJudgeReturnsBlock()
    {
        var recorder = new RecordingChatClient(JsonBlock("policy violation"));
        using var shield = Shield.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"))
            .WithLlmJudge(recorder)
            .Build();

        var verdict = shield.Session.ValidateInput("malicious input");

        Assert.False(verdict.Allowed);
        Assert.NotEmpty(recorder.Calls);
        Assert.Equal("gpt-4o", recorder.Calls[0].ModelId);
    }

    // ───────────────────────────────────────────────────────────────────
    // Helpers

    private static string JsonAllow() => "{\"decision\":\"allow\",\"confidence\":1.0}";

    private static string JsonBlock(string reason)
        => $"{{\"decision\":\"block\",\"confidence\":1.0,\"reason\":\"{reason}\"}}";

    private static string FindFixture(string name)
    {
        var dir = AppContext.BaseDirectory;
        while (dir != null)
        {
            var candidate = Path.Combine(dir, "tests", "fixtures", name);
            if (File.Exists(candidate)) return candidate;
            if (File.Exists(Path.Combine(dir, "AgentShield.sln")))
            {
                var path = Path.Combine(dir, "tests", "fixtures", name);
                if (File.Exists(path)) return path;
            }
            dir = Directory.GetParent(dir)?.FullName;
        }
        throw new FileNotFoundException($"Test fixture not found: {name}");
    }

    /// <summary>
    /// Minimal <see cref="IChatClient"/> that records the
    /// <see cref="ChatOptions"/> it was invoked with so tests can
    /// inspect <see cref="ChatOptions.ModelId"/> /
    /// <see cref="ChatOptions.MaxOutputTokens"/>. Returns a constant
    /// JSON-verdict response.
    /// </summary>
    private sealed class RecordingChatClient : IChatClient
    {
        private readonly string _response;
        public List<RecordedCall> Calls { get; } = new();

        public RecordingChatClient(string response)
        {
            _response = response;
        }

        public ChatClientMetadata Metadata => new("recording");

        public Task<ChatResponse> GetResponseAsync(
            IEnumerable<ChatMessage> messages,
            ChatOptions? options = null,
            CancellationToken cancellationToken = default)
        {
            Calls.Add(new RecordedCall(options?.ModelId, options?.MaxOutputTokens));
            var resp = new ChatResponse(new ChatMessage(ChatRole.Assistant, _response));
            return Task.FromResult(resp);
        }

        public async IAsyncEnumerable<ChatResponseUpdate> GetStreamingResponseAsync(
            IEnumerable<ChatMessage> messages,
            ChatOptions? options = null,
            [EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            Calls.Add(new RecordedCall(options?.ModelId, options?.MaxOutputTokens));
            yield return new ChatResponseUpdate
            {
                Role = ChatRole.Assistant,
                Contents = new[] { (AIContent)new TextContent(_response) },
            };
            await Task.CompletedTask;
        }

        public object? GetService(Type serviceType, object? serviceKey = null) => null;

        public void Dispose() { }
    }

    private sealed record RecordedCall(string? ModelId, int? MaxOutputTokens);
}
