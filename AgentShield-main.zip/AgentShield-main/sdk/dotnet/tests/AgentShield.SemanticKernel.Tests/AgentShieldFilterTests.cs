using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;
using Xunit;

using AgentShield;

namespace AgentShield.SemanticKernel.Tests;

/// <summary>
/// Boundary tests for <see cref="AgentShieldFilter"/>. Drives the
/// Semantic Kernel auto-function-invocation filter shape against the
/// minimal smoke fixture.
/// </summary>
public class AgentShieldFilterTests : IDisposable
{
    private readonly GuardrailsRuntime _runtime;

    public AgentShieldFilterTests()
    {
        _runtime = GuardrailsRuntime.FromYaml(MinimalFixture);
    }

    public void Dispose() => _runtime.Dispose();

    private static string SmokeFixturesDir
    {
        get
        {
            var dir = AppContext.BaseDirectory;
            while (dir != null && !Directory.Exists(Path.Combine(dir, "tests", "fixtures", "smoke")))
            {
                dir = Directory.GetParent(dir)?.FullName;
            }
            if (dir == null)
                throw new DirectoryNotFoundException("Could not locate tests/fixtures/smoke");
            return Path.Combine(dir, "tests", "fixtures", "smoke");
        }
    }

    private static string MinimalFixture =>
        Path.Combine(SmokeFixturesDir, "minimal.guardrails.yaml");

    private static JsonElement Parse(string json) =>
        JsonDocument.Parse(json).RootElement.Clone();

    private static AutoFunctionInvocationContext CreateContext(
        KernelFunction function,
        KernelArguments? arguments = null)
    {
        var kernel = Kernel.CreateBuilder().Build();
        var result = new FunctionResult(function, "initial");
        var chatHistory = new ChatHistory();
        var msg = new ChatMessageContent(AuthorRole.Assistant, "test");
        return new AutoFunctionInvocationContext(kernel, function, result, chatHistory, msg)
        {
            Arguments = arguments ?? new KernelArguments(),
        };
    }

    // ── Construction ────────────────────────────────────────────

    [Fact]
    public void Filter_NullRuntime_Throws()
    {
        Assert.Throws<ArgumentNullException>(() => new AgentShieldFilter(null!));
    }

    [Fact]
    public void Filter_Constructs_AndImplementsInterface()
    {
        var filter = new AgentShieldFilter(_runtime);
        Assert.IsAssignableFrom<IAutoFunctionInvocationFilter>(filter);
    }

    [Fact]
    public void Filter_CurrentSession_RoundTrips()
    {
        var filter = new AgentShieldFilter(_runtime);
        Assert.Null(filter.CurrentSession);

        using var session = _runtime.NewSession();
        filter.CurrentSession = session;
        Assert.Same(session, filter.CurrentSession);

        filter.CurrentSession = null;
        Assert.Null(filter.CurrentSession);
    }

    // ── Stage 2/3: tool-call gating ─────────────────────────────

    [Fact]
    public async Task BlockedToolCall_SetsResultAndTerminates()
    {
        var filter = new AgentShieldFilter(_runtime);
        // No CurrentSession set → filter spawns its own; the minimal
        // fixture blocks `echo` until `authorized == true`. The
        // owned-session path can't pre-set variables, so the call
        // must block.
        var function = KernelFunctionFactory.CreateFromMethod(() => "result", "echo");
        var context = CreateContext(function);

        var nextCalled = false;
        await filter.OnAutoFunctionInvocationAsync(context, _ =>
        {
            nextCalled = true;
            return Task.CompletedTask;
        });

        Assert.False(nextCalled, "next() must not be called when the tool is blocked");
        Assert.True(context.Terminate, "filter must terminate the invocation chain on block");
        Assert.Contains("[Blocked by Agent Shield]", context.Result?.ToString());
    }

    [Fact]
    public async Task AllowedToolCall_PassesThroughToNext()
    {
        var filter = new AgentShieldFilter(_runtime);
        using var session = _runtime.NewSession();
        session.SetVariable("authorized", Parse("true"));
        filter.CurrentSession = session;

        var function = KernelFunctionFactory.CreateFromMethod(() => "result", "echo");
        var context = CreateContext(function);

        var nextCalled = false;
        await filter.OnAutoFunctionInvocationAsync(context, ctx =>
        {
            nextCalled = true;
            ctx.Result = new FunctionResult(ctx.Function, "echoed-payload");
            return Task.CompletedTask;
        });

        Assert.True(nextCalled, "next() must run for allowed tools");
        Assert.False(context.Terminate, "context.Terminate stays false on the happy path");
        // The function returned a string; Stage 4 may serialize it.
        // We don't assert the exact representation, only that the
        // returned content survived.
        var rendered = context.Result?.ToString() ?? "";
        Assert.Contains("echoed-payload", rendered);
    }

    [Fact]
    public async Task ToolCallWithArguments_PassesParametersThrough()
    {
        var filter = new AgentShieldFilter(_runtime);
        using var session = _runtime.NewSession();
        session.SetVariable("authorized", Parse("true"));
        filter.CurrentSession = session;

        var function = KernelFunctionFactory.CreateFromMethod(() => "ok", "echo");
        var args = new KernelArguments { { "msg", "hi" }, { "n", 7 } };
        var context = CreateContext(function, args);

        var nextCalled = false;
        await filter.OnAutoFunctionInvocationAsync(context, ctx =>
        {
            nextCalled = true;
            ctx.Result = new FunctionResult(ctx.Function, "ok");
            return Task.CompletedTask;
        });

        Assert.True(nextCalled, "echo is allowed once `authorized == true`");
    }

    [Fact]
    public async Task UnknownTool_AllowedByCatchAllAbsence()
    {
        // The minimal fixture only declares the `echo` tool. An
        // unlisted tool has no matching guard policies and so the
        // gate allows it through (the fixture has no wildcard DLP
        // policy). This is a coverage point for the filter's no-policy
        // path.
        var filter = new AgentShieldFilter(_runtime);

        var function = KernelFunctionFactory.CreateFromMethod(() => "x", "unlisted_tool");
        var context = CreateContext(function);

        var nextCalled = false;
        await filter.OnAutoFunctionInvocationAsync(context, ctx =>
        {
            nextCalled = true;
            ctx.Result = new FunctionResult(ctx.Function, "x");
            return Task.CompletedTask;
        });

        Assert.True(nextCalled);
        Assert.False(context.Terminate);
    }

    // ── BLOCKED message format ──────────────────────────────────

    [Fact]
    public async Task BlockedMessage_UsesCanonicalPrefix()
    {
        // The .NET adapters consolidated the blocked-prefix wording in
        // the post-hard-cut baseline. Verify the prefix is
        // "[Blocked by Agent Shield]" exactly so cross-language
        // assertions stay stable.
        var filter = new AgentShieldFilter(_runtime);
        var function = KernelFunctionFactory.CreateFromMethod(() => "x", "echo");
        var context = CreateContext(function);

        await filter.OnAutoFunctionInvocationAsync(context, _ => Task.CompletedTask);

        var rendered = context.Result?.ToString() ?? "";
        Assert.StartsWith("[Blocked by Agent Shield]", rendered);
    }

    // ── Owned vs borrowed session ───────────────────────────────

    [Fact]
    public async Task FilterDisposesOwnedSession_DoesNotDisposeBorrowed()
    {
        var filter = new AgentShieldFilter(_runtime);
        using var session = _runtime.NewSession();
        session.SetVariable("authorized", Parse("true"));
        filter.CurrentSession = session;

        var function = KernelFunctionFactory.CreateFromMethod(() => "ok", "echo");
        var context = CreateContext(function);

        await filter.OnAutoFunctionInvocationAsync(context, ctx =>
        {
            ctx.Result = new FunctionResult(ctx.Function, "ok");
            return Task.CompletedTask;
        });

        // The borrowed session must still be usable afterwards. If the
        // filter mistakenly disposed it, this read would throw.
        var status = session.ReadVariable("authorized");
        Assert.NotNull(status);
        Assert.Equal(VariableStatus.Resolved, status!.Status);
    }
}
