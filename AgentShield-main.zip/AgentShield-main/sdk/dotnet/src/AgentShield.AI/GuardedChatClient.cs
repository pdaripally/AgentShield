using System;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.AI;

using AgentShield;

namespace AgentShield.AI;

/// <summary>
/// Chat-client decorator that routes through the
/// <see cref="GuardrailsSession"/> API (Stage 1 input + Stage 5 output).
///
/// <para>
/// Each call opens a per-request <see cref="GuardrailsSession"/>,
/// brackets it with <see cref="GuardrailsSession.BeginRequest"/> /
/// <see cref="GuardrailsSession.EndRequest"/>, and disposes after.
/// </para>
///
/// <para>
/// Streaming uses <see cref="GuardrailsSession.StreamingSession"/> for
/// per-chunk Stage 5 validation. See
/// <see cref="GetStreamingResponseAsync"/> for the chosen semantic.
/// </para>
/// </summary>
public sealed class GuardedChatClient : DelegatingChatClient
{
    private readonly GuardrailsRuntime _runtime;

    public GuardedChatClient(IChatClient innerClient, GuardrailsRuntime runtime)
        : base(innerClient)
    {
        _runtime = runtime ?? throw new ArgumentNullException(nameof(runtime));
    }

    public override async Task<ChatResponse> GetResponseAsync(
        IEnumerable<ChatMessage> messages,
        ChatOptions? options = null,
        CancellationToken cancellationToken = default)
    {
        var messageList = messages as System.Collections.Generic.IReadOnlyList<ChatMessage>
            ?? messages.ToList();

        using var session = _runtime.NewSession();
        session.BeginRequest();
        try
        {
            var (blocked, userText) = ValidateInput(session, messageList);
            if (blocked != null)
                return new ChatResponse(new ChatMessage(ChatRole.Assistant, blocked));

            var response = await base.GetResponseAsync(messageList, options, cancellationToken)
                .ConfigureAwait(false);

            var responseText = response.Text ?? "";
            if (string.IsNullOrEmpty(responseText)) return response;

            var (verdict, redacted) = session.ValidateOutput(responseText);
            if (!verdict.Allowed)
            {
                return new ChatResponse(new ChatMessage(ChatRole.Assistant,
                    $"[Blocked by Agent Shield] {verdict.Reason ?? "policy violation"}"))
                {
                    ResponseId = response.ResponseId,
                    ModelId = response.ModelId,
                    Usage = response.Usage,
                };
            }
            if (redacted != responseText)
            {
                var redactedMessages = response.Messages.ToList();
                var lastIdx = redactedMessages.FindLastIndex(m => m.Role == ChatRole.Assistant);
                if (lastIdx >= 0)
                    redactedMessages[lastIdx] = new ChatMessage(ChatRole.Assistant, redacted);
                else
                    redactedMessages.Add(new ChatMessage(ChatRole.Assistant, redacted));
                return new ChatResponse(redactedMessages)
                {
                    ResponseId = response.ResponseId,
                    ModelId = response.ModelId,
                    Usage = response.Usage,
                };
            }
            return response;
        }
        finally
        {
            session.EndRequest();
        }
    }

    /// <summary>
    /// Streaming Stage 1 + Stage 5 enforcement.
    ///
    /// <para>
    /// The validator's configured mode (see <see cref="StreamingMode"/>)
    /// drives emission scheduling:
    /// </para>
    /// <list type="bullet">
    ///   <item><description>
    ///     <see cref="StreamingMode.OnComplete"/> — every text-bearing
    ///     upstream chunk is pushed through the guard but NOT yielded
    ///     to the consumer. Metadata-only chunks (no text) pass
    ///     through immediately. After the upstream stream completes
    ///     the guard's <c>Finish()</c> drives a single terminal
    ///     emission: the validated/redacted full text, or one
    ///     <c>[GUARDRAIL BLOCK]</c> chunk if Stage 5 blocked the
    ///     buffer.
    ///   </description></item>
    ///   <item><description>
    ///     <see cref="StreamingMode.PerChunk"/> /
    ///     <see cref="StreamingMode.Windowed"/> — the engine returns
    ///     <c>pushed.Payload</c> as the authoritative safe-to-emit
    ///     slice (an overlap-respecting suffix of the buffer, NOT the
    ///     raw upstream chunk). The host emits that payload when
    ///     non-empty and skips when empty (engine is still holding
    ///     back overlap bytes). On <c>Stop</c> the host emits a
    ///     terminal <c>[GUARDRAIL BLOCK]</c> chunk and breaks the
    ///     loop. This mirrors the OnComplete payload-respect fix
    ///     (<c>fix-streaming-mode-respect</c>) and prevents windowed
    ///     validators that produce payload-altered Pass actions from
    ///     being silently bypassed.
    ///   </description></item>
    /// </list>
    /// </summary>
    public override async IAsyncEnumerable<ChatResponseUpdate> GetStreamingResponseAsync(
        IEnumerable<ChatMessage> messages,
        ChatOptions? options = null,
        [EnumeratorCancellation] CancellationToken cancellationToken = default)
    {
        var messageList = messages as System.Collections.Generic.IReadOnlyList<ChatMessage>
            ?? messages.ToList();

        using var session = _runtime.NewSession();
        session.BeginRequest();
        try
        {
            var (blocked, _) = ValidateInput(session, messageList);
            if (blocked != null)
            {
                yield return new ChatResponseUpdate
                {
                    Role = ChatRole.Assistant,
                    Contents = new[] { (AIContent)new TextContent(blocked) },
                };
                yield break;
            }

            using var guard = session.StreamingSession(StreamingStage.Output);
            var bufferMode = guard.Mode == StreamingMode.OnComplete;
            var stopped = false;
            // Held back in OnComplete so we can attach the final
            // validated text to the last upstream chunk's metadata.
            ChatResponseUpdate? lastBufferedChunk = null;
            // Last upstream chunk seen with text content — used to
            // carry response/model id onto payload-bearing emissions
            // in per_chunk / windowed modes.
            ChatResponseUpdate? lastTextChunk = null;

            await foreach (var chunk in base.GetStreamingResponseAsync(messageList, options, cancellationToken)
                .ConfigureAwait(false))
            {
                if (chunk is null) continue;
                var chunkText = chunk.Text ?? string.Empty;

                // Metadata-only chunks (no text) are not security-relevant
                // — pass them through in real time even in OnComplete so
                // consumers see token usage, finish reason, role, etc.
                // promptly.
                if (chunkText.Length == 0)
                {
                    yield return chunk;
                    continue;
                }

                var pushed = guard.Push(chunkText);

                if (pushed.Action == StreamAction.Stop)
                {
                    yield return new ChatResponseUpdate
                    {
                        Role = ChatRole.Assistant,
                        Contents = new[]
                        {
                            (AIContent)new TextContent(
                                $"[GUARDRAIL BLOCK] {pushed.Reason ?? "blocked by policy"}"),
                        },
                    };
                    stopped = true;
                    break;
                }

                if (bufferMode)
                {
                    // OnComplete: do NOT yield text-bearing chunks; the
                    // engine returns Pass(empty) for every push and the
                    // final validated payload arrives at Finish() below.
                    // Remember the last upstream chunk so we can carry
                    // its metadata onto the terminal emission.
                    lastBufferedChunk = chunk;
                    continue;
                }

                // per_chunk / windowed: emit pushed.Payload (the engine's
                // safe-to-emit slice) when non-empty. Empty payload means
                // "buffered for overlap — emit nothing yet". Both Pass
                // and Replace actions follow the same rule here; the
                // distinction is irrelevant to the consumer once the
                // engine's payload is the authoritative source of text.
                lastTextChunk = chunk;
                if (!string.IsNullOrEmpty(pushed.Payload))
                {
                    yield return new ChatResponseUpdate
                    {
                        Role = chunk.Role ?? ChatRole.Assistant,
                        Contents = new[] { (AIContent)new TextContent(pushed.Payload) },
                        ResponseId = chunk.ResponseId,
                        ModelId = chunk.ModelId,
                    };
                }
            }

            if (!stopped)
            {
                var tail = guard.Finish();
                if (tail.Action == StreamAction.Stop)
                {
                    yield return new ChatResponseUpdate
                    {
                        Role = ChatRole.Assistant,
                        Contents = new[]
                        {
                            (AIContent)new TextContent(
                                $"[GUARDRAIL BLOCK] {tail.Reason ?? "blocked by policy"}"),
                        },
                    };
                }
                else if (bufferMode)
                {
                    // OnComplete: emit ONE final chunk carrying the
                    // validated text. The engine returns Pass(full_text)
                    // if no redaction fired, or Replace(redacted_text)
                    // if it did — either way the payload is the safe
                    // textual content to surface.
                    var finalText = tail.Payload;
                    if (finalText.Length > 0)
                    {
                        var role = lastBufferedChunk?.Role ?? ChatRole.Assistant;
                        yield return new ChatResponseUpdate
                        {
                            Role = role,
                            Contents = new[] { (AIContent)new TextContent(finalText) },
                            ResponseId = lastBufferedChunk?.ResponseId,
                            ModelId = lastBufferedChunk?.ModelId,
                        };
                    }
                }
                else if (!string.IsNullOrEmpty(tail.Payload))
                {
                    // per_chunk / windowed tail: the engine flushes the
                    // held-back overlap (Pass) OR the final redacted
                    // text (Replace) here. Both must reach the consumer
                    // — emitting only on Replace (the prior behaviour)
                    // dropped the overlap tail in windowed mode.
                    var role = lastTextChunk?.Role ?? ChatRole.Assistant;
                    yield return new ChatResponseUpdate
                    {
                        Role = role,
                        Contents = new[] { (AIContent)new TextContent(tail.Payload) },
                        ResponseId = lastTextChunk?.ResponseId,
                        ModelId = lastTextChunk?.ModelId,
                    };
                }
            }
        }
        finally
        {
            session.EndRequest();
        }
    }

    private static (string? Blocked, string UserText) ValidateInput(
        GuardrailsSession session,
        System.Collections.Generic.IReadOnlyList<ChatMessage> messages)
    {
        var lastUser = messages.LastOrDefault(m => m.Role == ChatRole.User);
        var text = lastUser?.Text ?? "";
        if (string.IsNullOrEmpty(text)) return (null, "");
        var verdict = session.ValidateInput(text);
        if (!verdict.Allowed)
            return ($"[Blocked by Agent Shield] {verdict.Reason ?? "policy violation"}", text);
        return (null, text);
    }
}
