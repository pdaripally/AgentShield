using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.AI;

using AgentShield;

namespace AgentShield.AI;

/// <summary>
/// Microsoft.Extensions.AI <see cref="ILlmCaller"/> adapter that routes
/// guard-policy LLM-judge invocations through an
/// <see cref="IChatClient"/> while honouring the <c>configurations[]</c>
/// block in <c>.guardrails.yaml</c> (spec §6).
///
/// <para>
/// On each call this adapter:
/// </para>
/// <list type="number">
///   <item><description>
///     Looks up the configuration entry on the runtime via
///     <see cref="GuardrailsRuntime.LlmConfiguration(string)"/> using
///     the <see cref="LlmRequest.ConfigurationId"/> the runtime
///     supplied.
///   </description></item>
///   <item><description>
///     Picks the model identifier from the resolved entry —
///     <see cref="LlmConfiguration.Model"/>, passed verbatim to the
///     provider SDK (a model name for direct OpenAI, a deployment
///     name for Azure OpenAI). When the resolved entry has no
///     <c>Model</c> (or no entry matches), the adapter throws
///     <see cref="ConfigurationMissingModelException"/> rather than
///     silently picking a model on the customer's behalf.
///   </description></item>
///   <item><description>
///     Builds a <see cref="ChatOptions"/> with
///     <see cref="ChatOptions.ModelId"/> set accordingly (and
///     <see cref="ChatOptions.MaxOutputTokens"/> when the YAML
///     supplies <c>max_tokens</c>) and forwards the prompt as a
///     single user message to the inner <see cref="IChatClient"/>.
///   </description></item>
///   <item><description>
///     Parses the chat response as the
///     <see cref="LlmResponse"/> JSON wire shape (decision / reason /
///     categories / bool_flags). Free-form text that doesn't parse
///     falls back to <see cref="LlmResponse.Allow"/> with the raw
///     text in <see cref="LlmResponse.Reason"/> — the
///     guard-policy engine then applies its own decision rules to
///     the verdict it receives.
///   </description></item>
/// </list>
///
/// <para>
/// Mirrors the Python <c>openai_agents</c> /
/// <c>anthropic_agents</c> / <c>autogen</c> adapter LLM-caller
/// factories and the Node <c>LlmCallerFactory.makeCaller</c> shape
/// so the same <c>.guardrails.yaml</c> drives identical model
/// selection across all four SDKs.
/// </para>
/// </summary>
public sealed class MEAILlmCaller : ILlmCaller
{
    private readonly IChatClient _chatClient;
    private GuardrailsRuntime? _runtime;

    public MEAILlmCaller(IChatClient chatClient)
    {
        _chatClient = chatClient ?? throw new ArgumentNullException(nameof(chatClient));
    }

    /// <summary>
    /// Bind the caller to a <see cref="GuardrailsRuntime"/> so it can
    /// look up <c>configurations[]</c> entries by id at call time.
    /// Invoked by the <see cref="ShieldExtensions.WithLlmJudge"/>
    /// post-build hook. Mirrors the Python
    /// <c>_ConfigurationResolverHolder.bind</c> pattern.
    /// </summary>
    public void Bind(GuardrailsRuntime runtime)
    {
        _runtime = runtime ?? throw new ArgumentNullException(nameof(runtime));
    }

    public LlmResponse Call(LlmRequest request)
    {
        LlmConfiguration? cfg = null;
        if (_runtime != null && !string.IsNullOrEmpty(request.ConfigurationId))
        {
            try
            {
                cfg = _runtime.LlmConfiguration(request.ConfigurationId);
            }
            catch
            {
                // Resolver lookup must never break the LLM caller with an
                // internal error — surface the missing-model condition
                // directly so SREs see a load-time-shaped message rather
                // than a transport failure.
                cfg = null;
            }
        }

        if (cfg == null || string.IsNullOrEmpty(cfg.Model))
        {
            // A security library MUST NOT pick a model on the
            // customer's behalf. The schema rejects entries missing
            // `model:` at load time; this throw fires only when an
            // out-of-band configuration source bypasses validation.
            //
            // §6.2 — `cfg.Model` is the identifier passed verbatim to
            // the provider SDK (a model name for direct OpenAI, a
            // deployment name for Azure OpenAI). The adapter does not
            // synthesize or translate it.
            throw new ConfigurationMissingModelException(request.ConfigurationId);
        }

        var options = new ChatOptions
        {
            ModelId = cfg.Model!,
        };
        if (cfg.MaxTokens.HasValue) options.MaxOutputTokens = (int)cfg.MaxTokens.Value;

        var messages = new[] { new ChatMessage(ChatRole.User, request.Prompt) };

        // The Rust core invokes ILlmCaller.Call synchronously — bridge
        // through to the async chat client with GetAwaiter().GetResult().
        // Matches the sync_client.chat.completions.create(...) pattern
        // in the Python adapter and the napi-rs sync-blocking call in
        // the Node adapter.
        var response = _chatClient.GetResponseAsync(messages, options)
            .ConfigureAwait(false)
            .GetAwaiter()
            .GetResult();

        var text = response?.Text ?? string.Empty;
        return ParseResponse(text);
    }

    private static LlmResponse ParseResponse(string text)
    {
        if (string.IsNullOrWhiteSpace(text))
        {
            return LlmResponse.Allow(reason: "");
        }

        // The judge LLM is expected to return a JSON verdict matching
        // the LlmResponse wire shape. If parsing fails, treat the
        // text as a free-form rationale and default to allow — the
        // guard-policy engine still gets the reason via the envelope.
        try
        {
            using var doc = JsonDocument.Parse(text);
            if (doc.RootElement.ValueKind != JsonValueKind.Object)
            {
                return LlmResponse.Allow(reason: text);
            }

            var root = doc.RootElement;
            string decision = "allow";
            if (root.TryGetProperty("decision", out var decisionEl) && decisionEl.ValueKind == JsonValueKind.String)
            {
                decision = decisionEl.GetString() ?? "allow";
            }

            double confidence = 1.0;
            if (root.TryGetProperty("confidence", out var confidenceEl) && confidenceEl.ValueKind == JsonValueKind.Number)
            {
                confidence = confidenceEl.GetDouble();
            }

            string? reason = null;
            if (root.TryGetProperty("reason", out var reasonEl) && reasonEl.ValueKind == JsonValueKind.String)
            {
                reason = reasonEl.GetString();
            }

            List<string>? categories = null;
            if (root.TryGetProperty("categories", out var catsEl) && catsEl.ValueKind == JsonValueKind.Array)
            {
                categories = new List<string>();
                foreach (var c in catsEl.EnumerateArray())
                {
                    if (c.ValueKind == JsonValueKind.String)
                        categories.Add(c.GetString() ?? "");
                }
            }

            Dictionary<string, bool>? boolFlags = null;
            if (root.TryGetProperty("bool_flags", out var flagsEl) && flagsEl.ValueKind == JsonValueKind.Object)
            {
                boolFlags = new Dictionary<string, bool>();
                foreach (var kv in flagsEl.EnumerateObject())
                {
                    if (kv.Value.ValueKind == JsonValueKind.True || kv.Value.ValueKind == JsonValueKind.False)
                        boolFlags[kv.Name] = kv.Value.GetBoolean();
                }
            }

            return new LlmResponse(decision, confidence, reason, categories, boolFlags);
        }
        catch (JsonException)
        {
            return LlmResponse.Allow(reason: text);
        }
    }
}
