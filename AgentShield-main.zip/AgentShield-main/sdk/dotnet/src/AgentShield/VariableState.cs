using System;
using System.Text.Json;

namespace AgentShield;

/// <summary>
/// Read-only snapshot of a variable's state as cached by the runtime.
/// Maps to <c>VariableState</c> in the Rust core (spec §11.3).
/// </summary>
public sealed record VariableState(
    JsonElement Value,
    VariableStatus Status,
    DateTimeOffset SetAt,
    DateTimeOffset? ExpiresAt,
    string? DenyReason,
    string? SourceKind,
    string? SetBy)
{
    internal static VariableState? FromJson(string? json)
    {
        if (string.IsNullOrEmpty(json)) return null;
        return JsonSerializer.Deserialize<VariableState>(json, AgentShieldJsonOptions.Default);
    }
}

