using System;
using System.Collections.Generic;
using System.Text.Json;

namespace AgentShield;

/// <summary>
/// Fluent builder for <see cref="Shield"/>. Mirrors the Python
/// <c>ShieldBuilder</c> surface and the Node <c>ShieldBuilder</c> chain
/// so the customer-facing ergonomics stay identical across SDKs.
///
/// <para>
/// Construct via <see cref="Shield.FromYaml(string)"/>,
/// <see cref="Shield.FromYaml(IReadOnlyList{string})"/>, or
/// <see cref="Shield.FromRuntime"/>; chain <c>WithLlm</c>,
/// <c>WithAgentResolver</c>, <c>WithExtractor</c>, etc.; finish with
/// <see cref="Build"/>.
/// </para>
/// </summary>
public sealed class ShieldBuilder
{
    private const string ConsumedMessage =
        "ShieldBuilder.Build() can only be called once. " +
        "Call Shield.FromYaml(...) again to create a new builder.";

    private readonly RuntimeBuilder? _runtimeBuilder;
    private readonly GuardrailsRuntime? _runtime;
    private readonly bool _ownsRuntime;
    private bool _consumed;

    private ILlmCaller? _llmCaller;
    private IClassifierCaller? _classifierCaller;
    private readonly Dictionary<string, IExtractor> _extractors = new();
    private IAgentResolver? _agentResolver;
    private IDelegateDispatcher? _delegateDispatcher;
    private readonly List<IObservabilityProvider> _observabilityProviders = new();
    private ShieldMode _mode = ShieldMode.Enforce;
    private OnBlockPolicy _onBlock = OnBlockPolicy.ReturnBlocked;
    private Func<StageVerdict?, string, object?>? _onBlockCallback;
    private CapabilityReport _capabilities = new("custom");
    private FrameworkBundle? _bundle;
    private readonly List<Action<GuardrailsRuntime>> _postBuildHooks = new();

    internal ShieldBuilder(RuntimeBuilder runtimeBuilder)
    {
        _runtimeBuilder = runtimeBuilder ?? throw new ArgumentNullException(nameof(runtimeBuilder));
        _ownsRuntime = true;
    }

    internal ShieldBuilder(GuardrailsRuntime runtime, bool ownsRuntime = false)
    {
        _runtime = runtime ?? throw new ArgumentNullException(nameof(runtime));
        _ownsRuntime = ownsRuntime;
    }

    private void ThrowIfConsumed()
    {
        if (_consumed) throw new InvalidOperationException(ConsumedMessage);
    }

    /// <summary>Register the LLM caller used by guard policies.</summary>
    public ShieldBuilder WithLlm(ILlmCaller caller)
    {
        ThrowIfConsumed();
        _llmCaller = caller ?? throw new ArgumentNullException(nameof(caller));
        return this;
    }

    /// <summary>Register a classifier caller (returns score + threshold).</summary>
    public ShieldBuilder WithClassifier(IClassifierCaller caller)
    {
        ThrowIfConsumed();
        _classifierCaller = caller ?? throw new ArgumentNullException(nameof(caller));
        return this;
    }

    /// <summary>Register a value extractor by name.</summary>
    public ShieldBuilder WithExtractor(string name, IExtractor extractor)
    {
        ThrowIfConsumed();
        if (string.IsNullOrEmpty(name)) throw new ArgumentException("name is required", nameof(name));
        if (extractor == null) throw new ArgumentNullException(nameof(extractor));
        _extractors[name] = extractor;
        return this;
    }

    /// <summary>Register the agent-resolver callback.</summary>
    public ShieldBuilder WithAgentResolver(IAgentResolver resolver)
    {
        ThrowIfConsumed();
        _agentResolver = resolver ?? throw new ArgumentNullException(nameof(resolver));
        return this;
    }

    /// <summary>Register the delegate dispatcher.</summary>
    public ShieldBuilder WithDelegateDispatcher(IDelegateDispatcher dispatcher)
    {
        ThrowIfConsumed();
        _delegateDispatcher = dispatcher ?? throw new ArgumentNullException(nameof(dispatcher));
        return this;
    }

    /// <summary>Register an observability provider.</summary>
    public ShieldBuilder WithObservability(IObservabilityProvider provider)
    {
        ThrowIfConsumed();
        if (provider == null) throw new ArgumentNullException(nameof(provider));
        _observabilityProviders.Add(provider);
        return this;
    }

    /// <summary>Set <see cref="ShieldMode.Enforce"/> or <see cref="ShieldMode.Monitor"/>.</summary>
    public ShieldBuilder WithMode(ShieldMode mode)
    {
        ThrowIfConsumed();
        _mode = mode;
        return this;
    }

    /// <summary>Set the on-block policy.</summary>
    public ShieldBuilder WithOnBlock(OnBlockPolicy policy)
    {
        ThrowIfConsumed();
        _onBlock = policy;
        _onBlockCallback = null;
        return this;
    }

    /// <summary>Set a custom on-block callback. Receives the verdict (may be null
    /// for non-verdict block paths) and the formatted block message; whatever
    /// the callback returns is forwarded back to the caller, attempting to
    /// coerce to the target <c>TResult</c>.</summary>
    public ShieldBuilder WithOnBlock(Func<StageVerdict?, string, object?> custom)
    {
        ThrowIfConsumed();
        _onBlockCallback = custom ?? throw new ArgumentNullException(nameof(custom));
        return this;
    }

    /// <summary>
    /// Set the capability report this Shield exposes. Per-adapter
    /// extension methods (e.g. <c>WithAutoGen</c>, <c>WithSemanticKernel</c>)
    /// call this with their honest profile.
    /// </summary>
    public ShieldBuilder WithCapability(CapabilityReport report)
    {
        ThrowIfConsumed();
        _capabilities = report ?? throw new ArgumentNullException(nameof(report));
        return this;
    }

    /// <summary>
    /// Attach an optional <see cref="FrameworkBundle"/>. Per-adapter
    /// extension methods supply this so <see cref="Shield.ProtectTools"/>
    /// can reach the framework's tool wrapper, etc.
    /// </summary>
    public ShieldBuilder WithBundle(FrameworkBundle bundle)
    {
        ThrowIfConsumed();
        _bundle = bundle ?? throw new ArgumentNullException(nameof(bundle));
        // CapabilityReport tracks whichever the adapter actually
        // declared — bundles always overwrite.
        _capabilities = bundle.Capabilities;
        return this;
    }

    /// <summary>
    /// Register a hook that runs once the <see cref="GuardrailsRuntime"/>
    /// has been built but before the <see cref="Shield"/> is returned
    /// from <see cref="Build"/>. Used by adapter extensions (e.g.
    /// Microsoft.Extensions.AI's <c>WithLlmJudge</c>) that register an
    /// <see cref="ILlmCaller"/> *before* the runtime exists and need
    /// to bind the caller to the runtime's
    /// <see cref="GuardrailsRuntime.LlmConfiguration"/> accessor after
    /// build. Mirrors Python's <c>_ConfigurationResolverHolder.bind</c>
    /// pattern.
    /// </summary>
    public ShieldBuilder WithPostBuildHook(Action<GuardrailsRuntime> hook)
    {
        ThrowIfConsumed();
        if (hook == null) throw new ArgumentNullException(nameof(hook));
        _postBuildHooks.Add(hook);
        return this;
    }

    /// <summary>Consume the builder and produce a <see cref="Shield"/>.
    /// May only be called once; subsequent calls (and any further
    /// <c>With*</c> registration) throw <see cref="InvalidOperationException"/>.</summary>
    public Shield Build()
    {
        ThrowIfConsumed();

        GuardrailsRuntime runtime;
        bool ownsRuntime;
        if (_runtime != null)
        {
            runtime = _runtime;
            ownsRuntime = _ownsRuntime;
        }
        else
        {
            var rb = _runtimeBuilder!;
            if (_llmCaller != null) rb.RegisterLlmCaller(_llmCaller);
            if (_classifierCaller != null) rb.RegisterClassifierCaller(_classifierCaller);
            foreach (var (name, ext) in _extractors)
                rb.RegisterExtractor(name, ext);
            if (_agentResolver != null) rb.RegisterAgentResolver(_agentResolver);
            if (_delegateDispatcher != null) rb.RegisterDelegateDispatcher(_delegateDispatcher);
            foreach (var op in _observabilityProviders)
                rb.RegisterObservabilityProvider(op);
            runtime = rb.Build();
            ownsRuntime = true;
        }

        foreach (var hook in _postBuildHooks)
            hook(runtime);

        var session = runtime.NewSession();
        var shield = new Shield(
            runtime,
            ownsRuntime,
            session,
            ownsSession: true,
            _capabilities,
            _mode,
            _onBlock,
            _onBlockCallback,
            _bundle);
        _consumed = true;
        return shield;
    }
}
