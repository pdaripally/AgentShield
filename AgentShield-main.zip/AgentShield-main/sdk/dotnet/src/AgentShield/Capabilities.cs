using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace AgentShield;

/// <summary>
/// Per-stage protection profile exposed by every framework adapter
/// and by sibling integrations (MCP, ...). Surfaced via
/// <see cref="Shield.Capabilities"/> so customers can audit what an
/// adapter actually protects without reading the source.
/// </summary>
public enum CoverageLevel
{
    /// <summary>Stage is fully covered by this adapter.</summary>
    Full,
    /// <summary>Stage is partially covered (see notes for caveats).</summary>
    Partial,
    /// <summary>Adapter does not / cannot cover this stage.</summary>
    Unsupported,
}

/// <summary>
/// Behavioural mode for a <see cref="Shield"/>. <c>Enforce</c> blocks
/// disallowed actions; <c>Monitor</c> records every blocked verdict
/// through observability but proceeds as if the verdict was allowed.
/// Used for safe rollout of new policies in production.
/// </summary>
public enum ShieldMode
{
    Enforce,
    Monitor,
}

/// <summary>
/// Customer-controlled handling of blocked verdicts.
/// <list type="bullet">
///   <item><c>ReturnBlocked</c> (default) — return the framework's blocked result.</item>
///   <item><c>ReturnVerdict</c> — return the raw <see cref="StageVerdict"/>.</item>
///   <item><c>Raise</c> — throw <see cref="AgentShieldBlockedException"/>.</item>
/// </list>
/// </summary>
public enum OnBlockPolicy
{
    ReturnBlocked,
    ReturnVerdict,
    Raise,
}

/// <summary>
/// Thrown when a stage verdict denies an action and the configured
/// on-block policy is <see cref="OnBlockPolicy.Raise"/>.
/// </summary>
public sealed class AgentShieldBlockedException : Exception
{
    public StageVerdict? Verdict { get; }

    public AgentShieldBlockedException(StageVerdict? verdict, string message)
        : base(message)
    {
        Verdict = verdict;
    }
}

/// <summary>
/// Adapter capability profile. Every framework adapter and sibling
/// integration (MCP) exposes a <see cref="CapabilityReport"/> so
/// customers can see the actual coverage at construction time.
///
/// <para>
/// Each stage carries one of three coverage levels —
/// <see cref="CoverageLevel.Full"/>,
/// <see cref="CoverageLevel.Partial"/>, or
/// <see cref="CoverageLevel.Unsupported"/>. Notes carry caveats for
/// partial / unsupported stages.
/// </para>
///
/// <para>
/// Conforms to <c>spec/schemas/wire/capability_report.schema.json</c>
/// (the canonical JSON Schema artifact).
/// </para>
/// </summary>
public sealed class CapabilityReport
{
    public string Framework { get; }
    public CoverageLevel InputValidation { get; }
    public CoverageLevel StateValidation { get; }
    public CoverageLevel ToolAuthorization { get; }
    public CoverageLevel ToolExecutionValidation { get; }
    public CoverageLevel ToolOutputValidation { get; }
    public CoverageLevel OutputValidation { get; }
    public CoverageLevel StreamingOutput { get; }
    public IReadOnlyList<string> Notes { get; }

    public CapabilityReport(
        string framework,
        CoverageLevel inputValidation = CoverageLevel.Full,
        CoverageLevel stateValidation = CoverageLevel.Full,
        CoverageLevel toolAuthorization = CoverageLevel.Full,
        CoverageLevel toolExecutionValidation = CoverageLevel.Full,
        CoverageLevel toolOutputValidation = CoverageLevel.Full,
        CoverageLevel outputValidation = CoverageLevel.Full,
        CoverageLevel streamingOutput = CoverageLevel.Full,
        IEnumerable<string>? notes = null)
    {
        Framework = framework ?? throw new ArgumentNullException(nameof(framework));
        InputValidation = inputValidation;
        StateValidation = stateValidation;
        ToolAuthorization = toolAuthorization;
        ToolExecutionValidation = toolExecutionValidation;
        ToolOutputValidation = toolOutputValidation;
        OutputValidation = outputValidation;
        StreamingOutput = streamingOutput;
        Notes = new ReadOnlyCollection<string>(notes is null
            ? Array.Empty<string>()
            : new List<string>(notes));
    }

    /// <summary>True iff every stage is <see cref="CoverageLevel.Full"/>.</summary>
    public bool IsFullCoverage()
    {
        return InputValidation == CoverageLevel.Full
            && StateValidation == CoverageLevel.Full
            && ToolAuthorization == CoverageLevel.Full
            && ToolExecutionValidation == CoverageLevel.Full
            && ToolOutputValidation == CoverageLevel.Full
            && OutputValidation == CoverageLevel.Full
            && StreamingOutput == CoverageLevel.Full;
    }
}
