using System;
using System.Text.Json;
using System.Text.Json.Serialization;
using AgentShield.Interop;

namespace AgentShield;

/// <summary>
/// Canonical Stage 1 / Stage 5 verdict-handling decision.
///
/// Mirrors the wire shape produced by
/// <c>agent_shield_core::dispatch_outcome_to_wire</c> and is the
/// payload every SDK gets back from
/// <c>shield_dispatch_stage_verdict</c>. The .NET Shield routes its
/// per-stage decisions through this single helper so the dispatch
/// logic is byte-equivalent to the Python / Node / Rust SDKs.
/// </summary>
public sealed record VerdictDispatch(
    [property: JsonPropertyName("action")] DispatchAction Action,
    [property: JsonPropertyName("record_block")] bool RecordBlock,
    [property: JsonPropertyName("override_to_proceed")] bool OverrideToProceed)
{
    internal static VerdictDispatch FromJson(string json) =>
        JsonSerializer.Deserialize<VerdictDispatch>(json, AgentShieldJsonOptions.Default)
            ?? throw new InvalidOperationException($"Invalid VerdictDispatch JSON: {json}");
}

/// <summary>
/// One of:
///   <c>{kind: "proceed"}</c> — verdict allowed, no transform.
///   <c>{kind: "proceed_with_mutation", value}</c> — Stage 5 produced
///     a redacted / appended / prepended final string.
///   <c>{kind: "return_blocked", message}</c> — block: SDK should
///     return its framework-shaped blocked result.
///   <c>{kind: "return_verdict"}</c> — block: SDK should return the
///     raw verdict.
///   <c>{kind: "raise", message}</c> — block: SDK should throw.
///   <c>{kind: "invoke_custom", message}</c> — block: SDK should
///     call its host-registered callback.
/// </summary>
public sealed record DispatchAction(
    [property: JsonPropertyName("kind")] string Kind,
    [property: JsonPropertyName("value")] string? Value = null,
    [property: JsonPropertyName("message")] string? Message = null);

/// <summary>
/// Canonical Stage 2/3/4 (tool-call) verdict-handling decision.
/// </summary>
public sealed record ToolVerdictDispatch(
    [property: JsonPropertyName("action")] ToolDispatchAction Action,
    [property: JsonPropertyName("record_failure")] bool RecordFailure,
    [property: JsonPropertyName("record_success")] bool RecordSuccess,
    [property: JsonPropertyName("override_to_proceed")] bool OverrideToProceed)
{
    internal static ToolVerdictDispatch FromJson(string json) =>
        JsonSerializer.Deserialize<ToolVerdictDispatch>(json, AgentShieldJsonOptions.Default)
            ?? throw new InvalidOperationException($"Invalid ToolVerdictDispatch JSON: {json}");
}

/// <summary>
/// Tool-stage action — either proceed (with optional mutation) or
/// blocked (with the canonical <c>(tool: name)</c>-suffixed message).
/// </summary>
public sealed record ToolDispatchAction(
    [property: JsonPropertyName("kind")] string Kind,
    [property: JsonPropertyName("value")] string? Value = null,
    [property: JsonPropertyName("message")] string? Message = null);

/// <summary>Tool-call stage marker for <see cref="VerdictDispatcher"/>.</summary>
public enum ToolStage
{
    /// <summary>Stage 2/3 — pre-execute (no resource-cycle records).</summary>
    Call = 0,
    /// <summary>Stage 4 — post-execute (record success / failure).</summary>
    Output = 1,
}

/// <summary>
/// Static facade for the canonical verdict-handling decisions in
/// <c>agent_shield_core::shield_primitives</c>. Every Shield
/// orchestrator routes its Stage 1/5 and Stage 2/3/4 verdicts
/// through these methods so the dispatch behaviour is byte-equivalent
/// to the Python / Node / Rust SDKs.
/// </summary>
public static class VerdictDispatcher
{
    /// <summary>
    /// Decide what an SDK orchestrator should do with a Stage 1 /
    /// Stage 5 verdict.
    /// </summary>
    public static VerdictDispatch DispatchStage(
        StageVerdict verdict,
        OnBlockPolicy policy = OnBlockPolicy.ReturnBlocked,
        ShieldMode mode = ShieldMode.Enforce)
    {
        var json = SerializeVerdict(verdict);
        var ptr = NativeMethods.shield_dispatch_stage_verdict(
            json, (uint)policy, (uint)mode, out var err);
        NativeMethods.ThrowIfErr(err);
        var result = NativeMethods.ReadAndFreeString(ptr)
            ?? throw new InvalidOperationException("dispatch_stage_verdict returned null");
        return VerdictDispatch.FromJson(result);
    }

    /// <summary>
    /// Decide what an SDK orchestrator should do with a Stage 2/3/4
    /// verdict on a tool call.
    /// </summary>
    public static ToolVerdictDispatch DispatchTool(
        StageVerdict verdict,
        string toolName,
        ToolStage stage = ToolStage.Output,
        OnBlockPolicy policy = OnBlockPolicy.ReturnBlocked,
        ShieldMode mode = ShieldMode.Enforce)
    {
        var json = SerializeVerdict(verdict);
        var ptr = NativeMethods.shield_dispatch_tool_verdict(
            json, toolName, (uint)stage, (uint)policy, (uint)mode, out var err);
        NativeMethods.ThrowIfErr(err);
        var result = NativeMethods.ReadAndFreeString(ptr)
            ?? throw new InvalidOperationException("dispatch_tool_verdict returned null");
        return ToolVerdictDispatch.FromJson(result);
    }

    /// <summary>
    /// Format a verdict as the canonical
    /// <c>[GUARDRAIL ACTION] reason</c> string. Equivalent to calling
    /// <see cref="BlockMessageFormatter.Format(StageVerdict?)"/> but
    /// routed through the core FFI so the source of truth is one
    /// implementation.
    /// </summary>
    public static string FormatBlockMessage(StageVerdict verdict)
    {
        var json = SerializeVerdict(verdict);
        var ptr = NativeMethods.shield_format_block_message(json, out var err);
        NativeMethods.ThrowIfErr(err);
        return NativeMethods.ReadAndFreeString(ptr)
            ?? throw new InvalidOperationException("format_block_message returned null");
    }

    private static string SerializeVerdict(StageVerdict verdict)
    {
        // The wire-shape parser in core only reads the named fields it
        // recognises; we send the standard JsonSerializer output which
        // matches the canonical key names exactly.
        return JsonSerializer.Serialize(verdict, AgentShieldJsonOptions.Default);
    }
}
