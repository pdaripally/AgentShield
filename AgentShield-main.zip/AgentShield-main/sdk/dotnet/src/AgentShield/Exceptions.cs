using System;

namespace AgentShield;

/// <summary>
/// Base class for all Agent Shield SDK exceptions.
/// </summary>
public class GuardrailsException : Exception
{
    public GuardrailsException(string message) : base(message) { }
    public GuardrailsException(string message, Exception inner) : base(message, inner) { }
}

/// <summary>
/// Thrown when an operation is performed on a runtime / session that has
/// already been disposed.
/// </summary>
public sealed class GuardrailsDisposedException : GuardrailsException
{
    public GuardrailsDisposedException(string what)
        : base($"{what} is disposed") { }
}

/// <summary>
/// Thrown when a guardrails YAML config fails to load or build.
/// </summary>
public sealed class GuardrailsConfigException : GuardrailsException
{
    public GuardrailsConfigException(string message) : base(message) { }
}

/// <summary>
/// Thrown when a fallible runtime call (registration, validation,
/// session op) returns a non-zero status from the native ABI.
/// </summary>
public sealed class GuardrailsRuntimeException : GuardrailsException
{
    public GuardrailsRuntimeException(string message) : base(message) { }
}

/// <summary>
/// Variable status mirrors <c>VariableState.status</c> from the Rust
/// runtime (spec §11.3).
/// </summary>
public enum VariableStatus
{
    Unset,
    Resolved,
    Denied,
}

/// <summary>
/// Thrown when an LLM-caller adapter is asked to invoke a
/// <c>configurations[]</c> entry that does not declare <c>model:</c>.
///
/// <para>
/// A security library MUST NOT pick a model on the customer's behalf.
/// When the runtime resolves the configuration referenced by a guard
/// policy's stage and finds an entry with no <c>model:</c> — or no
/// matching entry at all — the LLM caller surfaces this typed
/// exception instead of silently falling back to a hard-coded SKU.
/// The schema in <c>spec/schema/guardrails.schema.json</c> rejects
/// entries missing <c>model:</c> at load time, so in normal operation
/// this exception fires only when an out-of-band configuration source
/// bypasses schema validation or when the runtime asks for a
/// <see cref="ConfigurationId"/> that doesn't exist.
/// </para>
///
/// <para>
/// Recovery: declare <c>model: &lt;name&gt;</c> on the offending
/// <c>configurations[]</c> entry in <c>.guardrails.yaml</c>.
/// <c>model:</c> is the identifier passed verbatim to the provider
/// SDK — a model name for direct OpenAI, a deployment name for Azure
/// OpenAI, the provider-native identifier for Anthropic / Bedrock /
/// Vertex / etc.
/// </para>
/// </summary>
public sealed class ConfigurationMissingModelException : GuardrailsException
{
    /// <summary>
    /// The <c>configurations[].id</c> the runtime asked for, or
    /// <c>null</c> when no id was supplied.
    /// </summary>
    public string? ConfigurationId { get; }

    public ConfigurationMissingModelException(string? configurationId)
        : base(BuildMessage(configurationId))
    {
        ConfigurationId = configurationId;
    }

    private static string BuildMessage(string? configurationId)
    {
        var idRepr = string.IsNullOrEmpty(configurationId) ? "<unset>" : configurationId;
        return $"LLM configuration '{idRepr}' is missing 'model'. Add " +
               "'model: <name>' to the configurations[] entry in your " +
               ".guardrails.yaml. 'model:' is passed verbatim to the " +
               "provider SDK — a model name for direct OpenAI, a " +
               "deployment name for Azure OpenAI.";
    }
}
