using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

using AgentShield.Interop;

namespace AgentShield;

/// <summary>
/// Immutable guardrails runtime. Construct via
/// <see cref="RuntimeBuilder"/> then create per-request sessions with
/// <see cref="NewSession"/>. A runtime is safe to share across threads;
/// each thread should obtain its own session.
/// </summary>
public sealed class GuardrailsRuntime : IDisposable
{
    private IntPtr _handle;
    private bool _disposed;
    private readonly List<GCHandle> _pinnedDelegates;

    internal GuardrailsRuntime(IntPtr handle, List<GCHandle> pinnedDelegates)
    {
        _handle = handle;
        _pinnedDelegates = pinnedDelegates;
    }

    ~GuardrailsRuntime()
    {
        DisposeCore();
    }

    /// <summary>Convenience: build a runtime directly from a YAML path.</summary>
    public static GuardrailsRuntime FromYaml(string path)
    {
        using var b = RuntimeBuilder.FromYaml(path);
        return b.Build();
    }

    /// <summary>Convenience: build a runtime from a chain of YAML paths.</summary>
    public static GuardrailsRuntime FromYamlChain(IEnumerable<string> paths)
    {
        using var b = RuntimeBuilder.FromYamlChain(paths);
        return b.Build();
    }

    /// <summary>Open a per-request session. Default <see cref="RequestContext"/> is used when omitted.</summary>
    public GuardrailsSession NewSession(RequestContext? context = null)
    {
        ThrowIfDisposed();
        var ctxJson = (context ?? RequestContext.Default).ToJson();
        var sessHandle = NativeMethods.shield_runtime_new_session(_handle, ctxJson, out var err);
        NativeMethods.ThrowIfErr(err);
        if (sessHandle == IntPtr.Zero)
            throw new GuardrailsException("shield_runtime_new_session returned null");
        return new GuardrailsSession(sessHandle);
    }

    /// <summary>
    /// Effective runtime mode (#14): <c>"active"</c> or
    /// <c>"shadow"</c>. YAML <c>mode:</c> with
    /// <c>AGENT_SHIELD_MODE</c> env override. Shadow forces the
    /// <see cref="Shield"/> to <see cref="ShieldMode.Monitor"/>.
    /// </summary>
    public string Mode
    {
        get
        {
            ThrowIfDisposed();
            var ptr = NativeMethods.shield_runtime_mode(_handle);
            if (ptr == IntPtr.Zero) return "active";
            return Marshal.PtrToStringUTF8(ptr) ?? "active";
        }
    }

    /// <summary>
    /// Look up a <c>configurations[]</c> entry by id (spec §6).
    /// Returns a typed <see cref="AgentShield.LlmConfiguration"/> for
    /// the resolved entry, or <c>null</c> when no entry matches.
    ///
    /// <para>
    /// Mirrors <c>Runtime.llm_configuration(id)</c> (Python) and
    /// <c>Runtime.llmConfiguration(id)</c> (Node). Adapter LLM-callers
    /// invoke this from inside their <see cref="ILlmCaller.Call"/>
    /// implementation, passing
    /// <c>request.ConfigurationId</c>, to drive per-stage
    /// model / max_tokens choices from YAML rather than hard-coding a
    /// fallback (see <see cref="AgentShield.AI.MEAILlmCaller"/> in the
    /// Microsoft.Extensions.AI adapter).
    /// </para>
    /// </summary>
    public LlmConfiguration? LlmConfiguration(string configurationId)
    {
        ThrowIfDisposed();
        if (configurationId == null) throw new ArgumentNullException(nameof(configurationId));
        var ptr = NativeMethods.shield_runtime_llm_configuration(_handle, configurationId, out var err);
        NativeMethods.ThrowIfErr(err);
        var json = NativeMethods.ReadAndFreeString(ptr);
        if (json == null) return null;
        return System.Text.Json.JsonSerializer.Deserialize<LlmConfiguration>(json);
    }

    /// <summary>Get the native ABI version string.</summary>
    public static string Version
    {
        get
        {
            var ptr = NativeMethods.shield_version();
            return Marshal.PtrToStringUTF8(ptr) ?? "unknown";
        }
    }

    public void Dispose()
    {
        DisposeCore();
        GC.SuppressFinalize(this);
    }

    private void DisposeCore()
    {
        if (_disposed) return;
        _disposed = true;

        if (_handle != IntPtr.Zero)
        {
            NativeMethods.shield_runtime_free(_handle);
            _handle = IntPtr.Zero;
        }

        // Free pinned delegates after the runtime — the runtime may
        // still be invoking them up until shield_runtime_free returns.
        foreach (var h in _pinnedDelegates)
            if (h.IsAllocated) h.Free();
        _pinnedDelegates.Clear();
    }

    private void ThrowIfDisposed()
    {
        if (_disposed) throw new GuardrailsDisposedException(nameof(GuardrailsRuntime));
    }
}
