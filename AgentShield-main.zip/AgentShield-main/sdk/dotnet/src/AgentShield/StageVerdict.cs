using System;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace AgentShield;

/// <summary>
/// Outcome of a stage validation. Wire format mirrors §12 StageVerdict:
/// <code>
/// {"allowed": bool, "action": "block"|"warn"|"redact"|"append"|"prepend"|null,
///  "reason": string|null, "policy": string|null,
///  "evaluate_when_index": int|null,
///  "bypassed_by_allowed_when": bool,
///  "redaction": string|null, "appended": string|null, "prepended": string|null,
///  "pending_resolution": object|null,
///  "invocation_hash": string|null,
///  "post_validation_invocation_hash": string|null}
/// </code>
/// </summary>
/// <remarks>
/// <c>InvocationHash</c> and <c>PostValidationInvocationHash</c> carry the
/// SHA-256 canonical invocation hash for invocation-bound stages
/// (§16.0). Per spec §16.0 the host MUST execute the post-validation
/// invocation and MUST NOT execute a later-mutated invocation under
/// the prior verdict. Both fields are <c>null</c> on input / output
/// stages and on verdicts emitted before this branch.
/// </remarks>
public sealed record StageVerdict(
    bool Allowed,
    string? Action,
    string? Reason,
    string? Policy,
    int? EvaluateWhenIndex,
    bool BypassedByAllowedWhen,
    string? Redaction,
    string? Appended,
    string? Prepended,
    PendingResolution? PendingResolution = null,
    string? InvocationHash = null,
    string? PostValidationInvocationHash = null)
{
    /// <summary>Convenience constant for an unconditional allow.</summary>
    public static StageVerdict Allow { get; } =
        new(true, null, null, null, null, false, null, null, null, null, null, null);

    internal static StageVerdict FromJson(string json)
    {
        if (string.IsNullOrEmpty(json))
            throw new InvalidOperationException("Empty StageVerdict JSON");

        return JsonSerializer.Deserialize<StageVerdict>(json, AgentShieldJsonOptions.Default)
            ?? throw new InvalidOperationException($"Invalid StageVerdict JSON: {json}");
    }
}

/// <summary>
/// Side-channel description of a deny that was caused by a
/// <c>kind: tool</c> (or synthesised <c>kind: human</c>) resolver
/// suspending while waiting for the agent to call its tool.
/// </summary>
/// <remarks>
/// The host is expected to surface this to the agent's framework so
/// the agent's LLM calls the named tool with the rendered prompt; the
/// tool's <c>populated_by:</c> writes the response back into the
/// variable, which unblocks the next gate evaluation.
/// </remarks>
public sealed record PendingResolution(
    [property: JsonPropertyName("tool")] string Tool,
    [property: JsonPropertyName("variable")] string Variable,
    [property: JsonPropertyName("prompt")] string? Prompt,
    [property: JsonPropertyName("request_id")] string RequestId,
    [property: JsonPropertyName("kind")] string Kind);

