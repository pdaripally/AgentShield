using System.Runtime.InteropServices;

namespace AgentShield.Interop;

/// <summary>
/// Managed delegate types matching the Rust FFI callback signatures.
/// Every delegate uses Cdecl calling convention for cross-platform P/Invoke.
/// </summary>

[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
internal delegate IntPtr ShieldLlmCallback(IntPtr prompt, IntPtr userData);

[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
internal delegate IntPtr ShieldApprovalCallback(
    IntPtr toolName, IntPtr paramsJson, IntPtr reason, IntPtr contextJson, IntPtr userData);

[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
internal delegate IntPtr ShieldDelegateHttpCallback(
    IntPtr url, IntPtr headersJson, IntPtr body, IntPtr userData);

[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
internal delegate IntPtr ShieldAttributeExtractorCallback(
    IntPtr toolName, IntPtr toolResult, IntPtr setsAttributesJson, IntPtr userData);

[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
internal delegate void ShieldFreeResultCallback(IntPtr ptr, IntPtr userData);
