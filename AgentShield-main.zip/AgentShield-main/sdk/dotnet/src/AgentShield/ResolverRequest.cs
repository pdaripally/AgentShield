using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace AgentShield;

/// <summary>
/// Envelope passed to a host-implemented resolver / dispatcher. The
/// fields are NUL-checked then UTF-8 decoded from the native struct.
///
/// <para>
/// <see cref="ResourceParams"/> carries the §11.10 <c>resource.params</c>
/// map (the same JSON object the agent passed to the gated tool /
/// agent / endpoint). Hosts use it to make parameter-sensitive
/// approval decisions. <c>null</c> when the resolver fires outside an
/// invocation context (e.g. a top-level variable resolution).
/// </para>
/// </summary>
public sealed record ResolverRequest(
    string RequestId,
    string? Variable,
    string? ResourceKind,
    string? ResourceName,
    string? Prompt,
    string? Reason,
    JsonElement Context,
    JsonElement? ResourceParams = null);

/// <summary>
/// Decisions a resolver can return. Maps to spec §11 resolver semantics
/// (allow / deny / cancelled).
/// </summary>
public enum ResolverDecision
{
    Allow,
    Deny,
    Cancelled,
}

/// <summary>
/// Response a resolver returns to the runtime.
///
/// <para>
/// <see cref="Value"/> populates the variable when <see cref="Decision"/>
/// is <see cref="ResolverDecision.Allow"/>. <see cref="SetVariables"/>
/// optionally lets the resolver set additional variables atomically.
/// </para>
/// </summary>
public sealed record ResolverResponse(
    ResolverDecision Decision,
    JsonElement? Value = null,
    IReadOnlyDictionary<string, JsonElement>? SetVariables = null,
    string? Reason = null)
{
    /// <summary>Build a basic allow response with a value.</summary>
    public static ResolverResponse AllowWith(JsonElement value) =>
        new(ResolverDecision.Allow, value);

    /// <summary>Build a deny response with an optional reason.</summary>
    public static ResolverResponse DenyWith(string? reason = null) =>
        new(ResolverDecision.Deny, null, null, reason);

    /// <summary>Build a cancellation response with an optional reason.</summary>
    public static ResolverResponse CancelledWith(string? reason = null) =>
        new(ResolverDecision.Cancelled, null, null, reason);

    internal string ToWireJson()
    {
        var obj = new JsonObject
        {
            ["decision"] = Decision switch
            {
                ResolverDecision.Allow => "allow",
                ResolverDecision.Deny => "deny",
                ResolverDecision.Cancelled => "cancelled",
                _ => "deny",
            },
        };
        obj["value"] = Value.HasValue
            ? JsonNode.Parse(Value.Value.GetRawText())
            : null;
        if (SetVariables is { Count: > 0 })
        {
            var sv = new JsonObject();
            foreach (var kv in SetVariables)
                sv[kv.Key] = JsonNode.Parse(kv.Value.GetRawText());
            obj["set_variables"] = sv;
        }
        if (Reason is not null)
            obj["reason"] = Reason;
        return obj.ToJsonString();
    }
}
