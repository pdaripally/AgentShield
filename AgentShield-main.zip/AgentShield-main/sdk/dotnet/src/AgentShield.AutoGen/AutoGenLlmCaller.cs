using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

using AutoGen.Core;

using AgentShield;

namespace AgentShield.AutoGen;

/// <summary>
/// AutoGen .NET <see cref="ILlmCaller"/> adapter that routes
/// guard-policy LLM-judge invocations through an
/// <see cref="IAgent"/> while honouring the <c>configurations[]</c>
/// block in <c>.guardrails.yaml</c> (spec §6).
///
/// <para>
/// On each call this adapter:
/// </para>
/// <list type="number">
///   <item><description>
///     Looks up the configuration entry on the runtime via
///     <see cref="GuardrailsRuntime.LlmConfiguration(string)"/> using
///     the <see cref="LlmRequest.ConfigurationId"/> the runtime
///     supplied.
///   </description></item>
///   <item><description>
///     Builds an <see cref="GenerateReplyOptions"/> envelope
///     carrying any cfg fields AutoGen's reply API actually accepts —
///     today <see cref="GenerateReplyOptions.Temperature"/> and
///     <see cref="GenerateReplyOptions.MaxToken"/>. Mirrors the
///     Python AutoGen adapter at
///     <c>sdk/python/agent_shield/adapters/autogen.py</c> which
///     plumbs cfg through <c>extra_create_args</c>.
///   </description></item>
///   <item><description>
///     Calls <see cref="IAgent.GenerateReplyAsync"/> with a single
///     <see cref="TextMessage"/> carrying the prompt and parses the
///     reply text as the <see cref="LlmResponse"/> JSON wire shape
///     (decision / reason / categories / bool_flags). Free-form text
///     that doesn't parse falls back to <see cref="LlmResponse.Allow"/>
///     with the raw text in <see cref="LlmResponse.Reason"/>.
///   </description></item>
/// </list>
///
/// <para>
/// Unlike the Microsoft.Extensions.AI / Semantic Kernel adapters,
/// AutoGen .NET binds the model identifier at agent construction
/// time — <see cref="GenerateReplyOptions"/> has no model-override
/// field. The cfg's <see cref="LlmConfiguration.Model"/> is therefore
/// *not* forwarded per-call here; routing happens via the customer
/// wiring the right pre-bound <see cref="IAgent"/> into
/// <see cref="ShieldExtensions.WithAutoGenLlmJudge"/>. This matches
/// the Python AutoGen adapter's documented contract — see the class
/// docstring in <c>sdk/python/agent_shield/adapters/autogen.py</c>.
/// The schema still requires <c>model:</c> on every <c>type: llm</c>
/// configuration so callers using the SK or MEAI adapter against the
/// same YAML get routing parity; the AutoGen adapter simply ignores
/// the field.
/// </para>
/// </summary>
public sealed class AutoGenLlmCaller : ILlmCaller
{
    private readonly IAgent _agent;
    private GuardrailsRuntime? _runtime;

    public AutoGenLlmCaller(IAgent agent)
    {
        _agent = agent ?? throw new ArgumentNullException(nameof(agent));
    }

    /// <summary>
    /// Bind the caller to a <see cref="GuardrailsRuntime"/> so it can
    /// look up <c>configurations[]</c> entries by id at call time.
    /// Invoked by the
    /// <see cref="ShieldExtensions.WithAutoGenLlmJudge"/> post-build
    /// hook. Mirrors the Python
    /// <c>_ConfigurationResolverHolder.bind</c> pattern.
    /// </summary>
    public void Bind(GuardrailsRuntime runtime)
    {
        _runtime = runtime ?? throw new ArgumentNullException(nameof(runtime));
    }

    public LlmResponse Call(LlmRequest request)
    {
        LlmConfiguration? cfg = null;
        if (_runtime != null && !string.IsNullOrEmpty(request.ConfigurationId))
        {
            try
            {
                cfg = _runtime.LlmConfiguration(request.ConfigurationId);
            }
            catch
            {
                // Resolver lookup must never break the LLM caller —
                // fall through to the documented fallback path.
                cfg = null;
            }
        }

        var options = BuildOptions(cfg);
        var messages = new IMessage[] { new TextMessage(Role.User, request.Prompt, "agent_shield") };

        // The Rust core invokes ILlmCaller.Call synchronously — bridge
        // through to the async agent reply with
        // GetAwaiter().GetResult(). Matches the
        // sync_client.chat.completions.create(...) pattern in the
        // Python adapter and the synchronous bridge in
        // MEAILlmCaller / SKLlmCaller.
        var reply = _agent.GenerateReplyAsync(messages, options, CancellationToken.None)
            .ConfigureAwait(false)
            .GetAwaiter()
            .GetResult();

        var text = reply?.GetContent() ?? string.Empty;
        return ParseResponse(text);
    }

    /// <summary>
    /// Build a <see cref="GenerateReplyOptions"/> envelope from the
    /// resolved cfg. Returns <c>null</c> when no cfg matched and no
    /// options need to be sent — AutoGen then uses the agent's
    /// construction-time defaults.
    ///
    /// <para>
    /// <see cref="LlmConfiguration.Model"/> is intentionally NOT
    /// applied — see class docstring. <c>temperature</c> is applied
    /// opportunistically per spec §6.6 (today only via the
    /// <see cref="LlmConfiguration.Metadata"/> / <c>provider_config</c>
    /// envelope since the FFI doesn't surface a typed
    /// <c>temperature</c> field yet; we read it best-effort from
    /// those JSON blobs to forward when the customer declares it).
    /// </para>
    /// </summary>
    private static GenerateReplyOptions? BuildOptions(LlmConfiguration? cfg)
    {
        if (cfg == null) return null;

        var options = new GenerateReplyOptions();
        var any = false;

        if (cfg.MaxTokens.HasValue)
        {
            options.MaxToken = (int)cfg.MaxTokens.Value;
            any = true;
        }

        // §6.6 — temperature / top_p / presence_penalty / etc. are
        // "applied opportunistically". The current FFI surface only
        // exposes typed `max_tokens`; provider-tunable kwargs live
        // under `metadata` or `provider_config` as free-form JSON.
        // Best-effort read of `temperature` from those envelopes so
        // customers who declare it get it forwarded.
        var temperature = ReadFloatProperty(cfg.Metadata, "temperature")
            ?? ReadFloatProperty(cfg.ProviderConfig, "temperature");
        if (temperature.HasValue)
        {
            options.Temperature = temperature.Value;
            any = true;
        }

        return any ? options : null;
    }

    private static float? ReadFloatProperty(JsonElement? element, string propertyName)
    {
        if (element == null) return null;
        var el = element.Value;
        if (el.ValueKind != JsonValueKind.Object) return null;
        if (!el.TryGetProperty(propertyName, out var prop)) return null;
        if (prop.ValueKind != JsonValueKind.Number) return null;
        try
        {
            return (float)prop.GetDouble();
        }
        catch
        {
            return null;
        }
    }

    private static LlmResponse ParseResponse(string text)
    {
        if (string.IsNullOrWhiteSpace(text))
        {
            return LlmResponse.Allow(reason: "");
        }

        // The judge LLM is expected to return a JSON verdict matching
        // the LlmResponse wire shape. If parsing fails, treat the
        // text as a free-form rationale and default to allow — the
        // guard-policy engine still gets the reason via the envelope.
        try
        {
            using var doc = JsonDocument.Parse(text);
            if (doc.RootElement.ValueKind != JsonValueKind.Object)
            {
                return LlmResponse.Allow(reason: text);
            }

            var root = doc.RootElement;
            string decision = "allow";
            if (root.TryGetProperty("decision", out var decisionEl) && decisionEl.ValueKind == JsonValueKind.String)
            {
                decision = decisionEl.GetString() ?? "allow";
            }

            double confidence = 1.0;
            if (root.TryGetProperty("confidence", out var confidenceEl) && confidenceEl.ValueKind == JsonValueKind.Number)
            {
                confidence = confidenceEl.GetDouble();
            }

            string? reason = null;
            if (root.TryGetProperty("reason", out var reasonEl) && reasonEl.ValueKind == JsonValueKind.String)
            {
                reason = reasonEl.GetString();
            }

            List<string>? categories = null;
            if (root.TryGetProperty("categories", out var catsEl) && catsEl.ValueKind == JsonValueKind.Array)
            {
                categories = new List<string>();
                foreach (var c in catsEl.EnumerateArray())
                {
                    if (c.ValueKind == JsonValueKind.String)
                        categories.Add(c.GetString() ?? "");
                }
            }

            Dictionary<string, bool>? boolFlags = null;
            if (root.TryGetProperty("bool_flags", out var flagsEl) && flagsEl.ValueKind == JsonValueKind.Object)
            {
                boolFlags = new Dictionary<string, bool>();
                foreach (var kv in flagsEl.EnumerateObject())
                {
                    if (kv.Value.ValueKind == JsonValueKind.True || kv.Value.ValueKind == JsonValueKind.False)
                        boolFlags[kv.Name] = kv.Value.GetBoolean();
                }
            }

            return new LlmResponse(decision, confidence, reason, categories, boolFlags);
        }
        catch (JsonException)
        {
            return LlmResponse.Allow(reason: text);
        }
    }
}
