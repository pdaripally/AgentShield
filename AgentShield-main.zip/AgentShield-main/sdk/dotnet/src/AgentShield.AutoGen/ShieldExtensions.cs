using System;

using AutoGen.Core;

using AgentShield;

namespace AgentShield.AutoGen;

/// <summary>
/// AutoGen <see cref="ShieldBuilder"/> extension that attaches the
/// AutoGen capability profile to the Shield. AutoGen exposes only a
/// turn-level <c>IMiddleware</c> hook, so the unified
/// <see cref="Shield"/> orchestrator drives Stage 1 + Stage 5 via
/// <c>RunAsync</c> and tools must be guarded explicitly with
/// <c>ProtectToolAsync</c> (or the existing <see cref="ToolProtection"/>
/// helpers).
///
/// <example>
/// Drop-in usage:
/// <code>
/// using var shield = Shield.FromYaml("guardrails.yaml")
///     .WithAutoGen()
///     .Build();
/// var reply = await shield.RunAsync(userInput, () =&gt; agent.GenerateReplyAsync(messages));
/// </code>
/// </example>
/// </summary>
public static class ShieldExtensions
{
    /// <summary>
    /// Honest capability profile for AutoGen — Stage 1 + Stage 5 are
    /// fully covered through <c>RunAsync</c>; Stage 2/3/4 require
    /// explicit per-tool wrapping (no per-tool middleware hook in
    /// AutoGen) so we report Partial there.
    /// </summary>
    public static readonly CapabilityReport CapabilityReport = new(
        framework: "autogen",
        inputValidation: CoverageLevel.Full,
        stateValidation: CoverageLevel.Partial,
        toolAuthorization: CoverageLevel.Partial,
        toolExecutionValidation: CoverageLevel.Partial,
        toolOutputValidation: CoverageLevel.Partial,
        outputValidation: CoverageLevel.Full,
        streamingOutput: CoverageLevel.Unsupported,
        notes: new[]
        {
            "AutoGen does not surface a per-tool middleware hook — Stage 2/3/4 require explicit ProtectToolAsync calls in the tool body.",
            "Streaming output is not currently driven through this Shield surface; use the existing AgentShieldMiddleware path if needed.",
        });

    /// <summary>
    /// Attach the AutoGen capability profile to this builder. The
    /// resulting Shield exposes <see cref="Shield.RunAsync{TResult}"/>
    /// for Stage 1 + Stage 5 enforcement around an AutoGen agent's
    /// generate-reply call.
    /// </summary>
    public static ShieldBuilder WithAutoGen(this ShieldBuilder builder)
    {
        if (builder == null) throw new ArgumentNullException(nameof(builder));
        return builder.WithCapability(CapabilityReport);
    }

    /// <summary>
    /// Register an AutoGen <see cref="IAgent"/> as the guard-policy
    /// LLM-judge caller. Wires the agent through an
    /// <see cref="AutoGenLlmCaller"/> that honours the YAML's
    /// <c>configurations[]</c> entries (per-stage <c>max_tokens</c>
    /// and provider-tunable <c>temperature</c> selection) by binding
    /// to the runtime's
    /// <see cref="GuardrailsRuntime.LlmConfiguration"/> accessor at
    /// build time.
    ///
    /// <example>
    /// <code>
    /// using var shield = Shield.FromYaml("guardrails.yaml")
    ///     .WithAutoGen()
    ///     .WithAutoGenLlmJudge(judgeAgent)
    ///     .Build();
    /// </code>
    /// </example>
    ///
    /// <para>
    /// AutoGen .NET binds the model identifier at agent construction
    /// time (matching the Python AutoGen adapter's documented
    /// contract — see
    /// <c>sdk/python/agent_shield/adapters/autogen.py</c>) so
    /// <c>model:</c> from <c>configurations[]</c> is NOT forwarded
    /// per-call. Customers who want per-stage model routing on
    /// AutoGen should construct distinct <see cref="IAgent"/>
    /// instances per stage or use the Microsoft.Extensions.AI /
    /// Semantic Kernel adapters which do support per-call model
    /// overrides.
    /// </para>
    /// </summary>
    public static ShieldBuilder WithAutoGenLlmJudge(
        this ShieldBuilder builder,
        IAgent judgeAgent)
    {
        if (builder == null) throw new ArgumentNullException(nameof(builder));
        if (judgeAgent == null) throw new ArgumentNullException(nameof(judgeAgent));
        var caller = new AutoGenLlmCaller(judgeAgent);
        return builder
            .WithLlm(caller)
            .WithPostBuildHook(rt => caller.Bind(rt));
    }
}
