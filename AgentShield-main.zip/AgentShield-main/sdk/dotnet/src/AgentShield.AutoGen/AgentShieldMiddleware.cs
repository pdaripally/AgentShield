using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using AutoGen.Core;

using AgentShield;

namespace AgentShield.AutoGen;

/// <summary>
/// AutoGen middleware that enforces Agent Shield guardrails on each
/// agent message. Wires all five spec stages onto AutoGen's
/// <see cref="IMiddleware"/> contract:
/// <list type="bullet">
///   <item>Stage 1 (input) — last <see cref="Role.User"/> message text.</item>
///   <item>Stage 2 + 3 (tool execution) — applied when the inner
///         agent's reply is a <see cref="ToolCallMessage"/>. On block,
///         the call is short-circuited with a
///         <see cref="ToolCallResultMessage"/> carrying the block reason
///         so downstream <see cref="FunctionCallMiddleware"/> sees a
///         result rather than an unexecuted call. On mutation the
///         transformed <see cref="ToolCall.FunctionArguments"/> are
///         propagated so the real tool receives the rewritten params.</item>
///   <item>Stage 4 (post-tool) — applied to every
///         <see cref="ToolCallResultMessage"/> and to the result half of
///         a <see cref="ToolCallAggregateMessage"/>. Each tool's result
///         text is validated; on block the result is replaced with the
///         block message and <see cref="GuardrailsSession.RecordToolFailure"/>
///         is invoked; on allow / mutation
///         <see cref="GuardrailsSession.RecordToolSuccess"/> is invoked
///         with the (possibly redacted) value.</item>
///   <item>Stage 5 (output) — applied to plain text replies (any
///         <see cref="IMessage"/> that isn't a tool-call / tool-result
///         shape) as the final gate.</item>
/// </list>
///
/// <para>
/// To intercept a tool call BEFORE it executes, wire this middleware
/// directly around the LLM agent and place a
/// <see cref="FunctionCallMiddleware"/> on the outside. The LLM's
/// <see cref="ToolCallMessage"/> reply then flows through Agent Shield
/// first, and the outer <see cref="FunctionCallMiddleware"/> only sees
/// the (possibly mutated, possibly already-blocked) result.
/// </para>
///
/// <para>
/// <see cref="ToolProtection"/> remains as a host-driven shortcut for
/// callers that own their own tool-dispatch loop and want to invoke
/// Stage 2/3 + Stage 4 manually without going through AutoGen middleware.
/// </para>
/// </summary>
public sealed class AgentShieldMiddleware : IMiddleware
{
    private readonly GuardrailsRuntime _runtime;

    public string? Name => "AgentShield";

    public AgentShieldMiddleware(GuardrailsRuntime runtime)
    {
        _runtime = runtime ?? throw new ArgumentNullException(nameof(runtime));
    }

    public async Task<IMessage> InvokeAsync(
        MiddlewareContext context,
        IAgent agent,
        CancellationToken cancellationToken = default)
    {
        using var session = _runtime.NewSession();
        session.BeginTurn();
        try
        {
            // ── Stage 1 — input validation ──────────────────────────
            var lastUser = context.Messages.LastOrDefault(m => m.GetRole() == Role.User);
            var inputText = lastUser?.GetContent() ?? "";
            if (!string.IsNullOrEmpty(inputText))
            {
                var inVerdict = session.ValidateInput(inputText);
                if (!inVerdict.Allowed)
                {
                    return new TextMessage(
                        Role.Assistant,
                        $"[Blocked by Agent Shield] {inVerdict.Reason ?? "policy violation"}",
                        agent.Name);
                }
            }

            // ── Capture inbound tool calls for failure attribution ──
            // If the inbound conversation ends in a ToolCallMessage, the
            // inner pipeline is about to execute it. We record the tool
            // names so a downstream exception (e.g. tool threw) can be
            // attributed via RecordToolFailure on the right tool.
            var inboundToolCalls = (context.Messages.LastOrDefault() as ToolCallMessage)
                ?.GetToolCalls().ToList()
                ?? new List<ToolCall>();

            IMessage reply;
            try
            {
                reply = await agent.GenerateReplyAsync(
                    context.Messages, context.Options, cancellationToken)
                    .ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                foreach (var tc in inboundToolCalls)
                {
                    try { session.RecordToolFailure(tc.FunctionName, ex.Message); }
                    catch { /* best-effort observability */ }
                }
                throw;
            }

            // ── Stage 2/3/4 dispatch by reply shape ─────────────────
            switch (reply)
            {
                case ToolCallMessage toolCalls:
                    return GuardToolCallMessage(session, toolCalls, agent.Name);

                case ToolCallResultMessage toolResults:
                    return GuardToolResultMessage(session, toolResults, agent.Name);

                case ToolCallAggregateMessage agg:
                {
                    // The aggregate carries both the call and the
                    // already-executed result. We validate calls (block
                    // / mutate) and post-tool results.
                    var guardedCalls = GuardToolCallMessage(session, agg.Message1, agent.Name);
                    if (guardedCalls is ToolCallResultMessage blocked)
                    {
                        // Stage 2/3 short-circuited — surface the block
                        // as the entire aggregate result. The actual
                        // pre-execution mutation is moot here because
                        // the inner pipeline already ran the tool.
                        return blocked;
                    }
                    var guardedResults = (ToolCallResultMessage)GuardToolResultMessage(
                        session, agg.Message2, agent.Name);
                    return new ToolCallAggregateMessage(
                        (ToolCallMessage)guardedCalls, guardedResults, agent.Name);
                }

                default:
                    return GuardTextReply(session, reply, agent.Name);
            }
        }
        finally
        {
            session.EndTurn();
        }
    }

    // ── Stage 5 — text output ──────────────────────────────────────

    private static IMessage GuardTextReply(GuardrailsSession session, IMessage reply, string? from)
    {
        var outputText = reply.GetContent() ?? "";
        if (string.IsNullOrEmpty(outputText)) return reply;

        var (verdict, redacted) = session.ValidateOutput(outputText);
        if (!verdict.Allowed)
        {
            return new TextMessage(
                Role.Assistant,
                $"[Blocked by Agent Shield] {verdict.Reason ?? "policy violation"}",
                from);
        }
        if (redacted != outputText)
        {
            return new TextMessage(Role.Assistant, redacted, from);
        }
        return reply;
    }

    // ── Stage 2 + 3 — tool call validation ─────────────────────────

    /// <summary>
    /// Runs Stage 2/3 against each <see cref="ToolCall"/> inside the
    /// message. On block we return a <see cref="ToolCallResultMessage"/>
    /// so downstream <see cref="FunctionCallMiddleware"/> short-circuits
    /// to a "result" path instead of executing the call. On allow /
    /// mutation we propagate the transformed FunctionArguments back
    /// into the outgoing <see cref="ToolCallMessage"/>.
    /// </summary>
    private static IMessage GuardToolCallMessage(
        GuardrailsSession session, ToolCallMessage msg, string? from)
    {
        var mutatedCalls = new List<ToolCall>(msg.ToolCalls.Count);
        foreach (var tc in msg.ToolCalls)
        {
            var argsJson = string.IsNullOrEmpty(tc.FunctionArguments) ? "{}" : tc.FunctionArguments;
            JsonElement args;
            try
            {
                args = JsonDocument.Parse(argsJson).RootElement.Clone();
            }
            catch (JsonException)
            {
                // Tool args weren't valid JSON — fall back to an empty
                // object so Stage 2/3 still runs. We preserve the raw
                // string when propagating downstream below.
                args = JsonDocument.Parse("{}").RootElement.Clone();
            }

            // §16.0 — bind Stage 3 → Stage 4 through the upstream
            // tool-call id. When AutoGen doesn't carry one we mint a
            // per-call id and propagate it on the rewritten ToolCall so
            // the downstream ToolCallResultMessage sees the same id.
            var boundId = !string.IsNullOrEmpty(tc.ToolCallId)
                ? tc.ToolCallId!
                : Guid.NewGuid().ToString("N");
            var (verdict, mutated) = session.ValidateToolCall(tc.FunctionName, args, boundId);
            if (!verdict.Allowed)
            {
                var blockMsg =
                    $"[Blocked by Agent Shield] {verdict.Reason ?? "policy violation"} (tool: {tc.FunctionName})";

                // Replace the entire ToolCallMessage with a
                // ToolCallResultMessage so the call never reaches the
                // executor. Carry the block message in each result so
                // the LLM sees what happened on its next turn.
                var blockedResults = msg.ToolCalls
                    .Select(c => new ToolCall(c.FunctionName, c.FunctionArguments, blockMsg)
                    {
                        ToolCallId = c.ToolCallId,
                    })
                    .ToList();
                return new ToolCallResultMessage(blockedResults, from);
            }

            // Stage 3 — propagate mutated args. Always set ToolCallId
            // to `boundId` so Stage 4 binds against the same key, even
            // when the upstream message lacked an id.
            var mutatedArgs = mutated.GetRawText();
            mutatedCalls.Add(new ToolCall(tc.FunctionName, mutatedArgs)
            {
                ToolCallId = boundId,
            });
        }

        return new ToolCallMessage(mutatedCalls, from) { Content = msg.Content };
    }

    // ── Stage 4 — tool result validation ───────────────────────────

    /// <summary>
    /// Runs Stage 4 against each <see cref="ToolCall.Result"/> entry.
    /// On block the result string is replaced with the block message
    /// and <see cref="GuardrailsSession.RecordToolFailure"/> is invoked;
    /// on allow / mutation <see cref="GuardrailsSession.RecordToolSuccess"/>
    /// is invoked with the (possibly redacted) value.
    /// </summary>
    private static IMessage GuardToolResultMessage(
        GuardrailsSession session, ToolCallResultMessage msg, string? from)
    {
        var redactedResults = new List<ToolCall>(msg.ToolCalls.Count);
        foreach (var tc in msg.ToolCalls)
        {
            var raw = tc.Result ?? string.Empty;
            // Wrap the result text as a JSON string element so the
            // Stage 4 regex / span machinery operates on its contents.
            var resultJson = JsonSerializer.SerializeToElement(raw);

            // §16.0 — bind Stage 4 back to the Stage 3 id. When the
            // upstream message carried no id we fall back to a fresh
            // synthesized one, which intentionally fails closed in the
            // core: an unbound Stage 4 must not pass.
            var resultBoundId = !string.IsNullOrEmpty(tc.ToolCallId)
                ? tc.ToolCallId!
                : Guid.NewGuid().ToString("N");
            var (verdict, mutated) = session.ValidateToolOutput(tc.FunctionName, resultJson, resultBoundId);
            if (!verdict.Allowed)
            {
                var blockMsg =
                    $"[Blocked by Agent Shield] {verdict.Reason ?? "policy violation"} (tool: {tc.FunctionName})";
                try { session.RecordToolFailure(tc.FunctionName, verdict.Reason ?? "blocked by policy"); }
                catch { /* best-effort observability */ }
                redactedResults.Add(new ToolCall(tc.FunctionName, tc.FunctionArguments, blockMsg)
                {
                    ToolCallId = tc.ToolCallId,
                });
                continue;
            }

            var mutatedText = mutated.ValueKind == JsonValueKind.String
                ? (mutated.GetString() ?? string.Empty)
                : mutated.GetRawText();

            try { session.RecordToolSuccess(tc.FunctionName, mutated); }
            catch { /* best-effort observability */ }

            redactedResults.Add(new ToolCall(tc.FunctionName, tc.FunctionArguments, mutatedText)
            {
                ToolCallId = tc.ToolCallId,
            });
        }

        return new ToolCallResultMessage(redactedResults, from);
    }
}

/// <summary>
/// Helpers for protecting individual tool calls when the host owns the
/// tool-dispatch loop directly (without AutoGen middleware ordering).
/// Apply <see cref="GuardToolCall"/> at tool-dispatch time and
/// <see cref="GuardToolOutput"/> on the result.
/// </summary>
public static class ToolProtection
{
    /// <summary>
    /// Stage 2 + 3 — validate a tool call. Throws on block.
    ///
    /// Pass <paramref name="toolCallId"/> (the upstream tool-call
    /// handle, e.g. the OpenAI <c>tool_call.id</c> AutoGen surfaces
    /// in its <c>ToolCallMessage</c>) so §16.0 binding can match
    /// Stage 4 back to this canonical Stage 3 invocation under
    /// concurrent same-name calls.
    /// </summary>
    public static System.Text.Json.JsonElement GuardToolCall(
        GuardrailsSession session, string tool, System.Text.Json.JsonElement parameters,
        string? toolCallId = null)
    {
        var boundId = toolCallId ?? Guid.NewGuid().ToString("N");
        var (verdict, mutated) = session.ValidateToolCall(tool, parameters, boundId);
        if (!verdict.Allowed)
            throw new GuardrailsException(
                $"Tool '{tool}' blocked: {verdict.Reason ?? "policy violation"}");
        return mutated;
    }

    /// <summary>
    /// Stage 4 — validate a tool result. Returns the (possibly
    /// redacted) value. Pass the same <paramref name="toolCallId"/>
    /// used at <see cref="GuardToolCall"/> for §16.0 binding.
    /// </summary>
    public static System.Text.Json.JsonElement GuardToolOutput(
        GuardrailsSession session, string tool, System.Text.Json.JsonElement result,
        string? toolCallId = null)
    {
        var boundId = toolCallId ?? Guid.NewGuid().ToString("N");
        var (verdict, mutated) = session.ValidateToolOutput(tool, result, boundId);
        if (!verdict.Allowed)
            throw new GuardrailsException(
                $"Tool '{tool}' output blocked: {verdict.Reason ?? "policy violation"}");
        return mutated;
    }
}
