using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using OpenAI.Chat;

using AgentShield;

namespace AgentShield.OpenAI;

/// <summary>
/// Helpers for integrating Agent Shield with the OpenAI .NET SDK.
/// Routes through <see cref="GuardrailsSession"/> for stage validation.
/// </summary>
public static class OpenAIAdapter
{
    /// <summary>
    /// Stage 1: validate the last user message in a conversation.
    /// Returns null if the input is allowed, or a "blocked" string
    /// suitable to surface back to the model.
    /// </summary>
    public static string? GuardConversation(
        GuardrailsSession session,
        IEnumerable<ChatMessage> messages)
    {
        var lastUser = messages.LastOrDefault(m => m is UserChatMessage) as UserChatMessage;
        if (lastUser == null) return null;
        var text = string.Join("", lastUser.Content
            .Where(p => p.Kind == ChatMessageContentPartKind.Text)
            .Select(p => p.Text));
        if (string.IsNullOrEmpty(text)) return null;
        var verdict = session.ValidateInput(text);
        return verdict.Allowed
            ? null
            : $"[Blocked by Agent Shield] {verdict.Reason ?? "policy violation"}";
    }

    /// <summary>
    /// Stage 2 + 3: validate a tool call and return the (possibly
    /// transformed) parameters JSON. Throws <see cref="GuardrailsException"/>
    /// when blocked.
    ///
    /// Pass <paramref name="toolCallId"/> (the OpenAI
    /// <c>ChatToolCall.Id</c>) so §16.0 binding can match Stage 4 back
    /// to this canonical Stage 3 invocation under concurrent same-name
    /// calls.
    /// </summary>
    public static string GuardToolCall(
        GuardrailsSession session,
        string toolName,
        string parametersJson,
        string? toolCallId = null)
    {
        using var doc = JsonDocument.Parse(parametersJson);
        var boundId = toolCallId ?? Guid.NewGuid().ToString("N");
        var (verdict, mutated) = session.ValidateToolCall(toolName, doc.RootElement.Clone(), boundId);
        if (!verdict.Allowed)
            throw new GuardrailsException(
                $"Tool '{toolName}' blocked: {verdict.Reason ?? "policy violation"}");
        return mutated.GetRawText();
    }

    /// <summary>
    /// Stage 5: validate / redact the final agent response text.
    /// Returns the (possibly redacted) text.
    /// </summary>
    public static string GuardResponse(
        GuardrailsSession session,
        string responseText)
    {
        if (string.IsNullOrEmpty(responseText)) return responseText;
        var (verdict, mutated) = session.ValidateOutput(responseText);
        if (!verdict.Allowed)
            return $"[Blocked by Agent Shield] {verdict.Reason ?? "policy violation"}";
        return mutated;
    }

    /// <summary>
    /// Convenience wrapper that opens a session, brackets it with
    /// <see cref="GuardrailsSession.BeginRequest"/>, runs the user
    /// callback, and disposes the session.
    /// </summary>
    public static async Task<T> WithSessionAsync<T>(
        GuardrailsRuntime runtime,
        Func<GuardrailsSession, Task<T>> body)
    {
        using var session = runtime.NewSession();
        session.BeginRequest();
        try
        {
            return await body(session).ConfigureAwait(false);
        }
        finally
        {
            session.EndRequest();
        }
    }
}
