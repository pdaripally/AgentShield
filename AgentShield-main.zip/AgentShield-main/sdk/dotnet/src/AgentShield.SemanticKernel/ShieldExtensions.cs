using System;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;

using AgentShield;

namespace AgentShield.SemanticKernel;

/// <summary>
/// Semantic Kernel <see cref="ShieldBuilder"/> extension. SK's
/// <c>IAutoFunctionInvocationFilter</c> hook gives full Stage 2/3/4
/// coverage; combined with the unified Shield orchestrator's
/// Stage 1 + Stage 5 enforcement, SK is full-coverage end-to-end.
///
/// <example>
/// Drop-in usage:
/// <code>
/// using var shield = Shield.FromYaml("guardrails.yaml")
///     .WithSemanticKernel(kernel)
///     .Build();
/// var reply = await shield.RunAsync(userInput, () =&gt; kernel.InvokePromptAsync(prompt));
/// </code>
/// </example>
/// </summary>
public static class ShieldExtensions
{
    /// <summary>Honest capability profile for Semantic Kernel — full coverage.</summary>
    public static readonly CapabilityReport CapabilityReport = new(
        framework: "semantic_kernel",
        inputValidation: CoverageLevel.Full,
        stateValidation: CoverageLevel.Full,
        toolAuthorization: CoverageLevel.Full,
        toolExecutionValidation: CoverageLevel.Full,
        toolOutputValidation: CoverageLevel.Full,
        outputValidation: CoverageLevel.Full,
        streamingOutput: CoverageLevel.Full,
        notes: new[]
        {
            "Stage 2/3/4 are wired through Semantic Kernel's IAutoFunctionInvocationFilter; the filter is registered on the kernel passed to WithSemanticKernel.",
        });

    /// <summary>
    /// Attach Semantic Kernel integration to this builder. Registers
    /// an <see cref="AgentShieldFilter"/> on the supplied kernel so
    /// every kernel function call goes through Stage 2/3/4. Stage 1
    /// + Stage 5 still come from <see cref="Shield.RunAsync{TResult}"/>.
    /// </summary>
    public static ShieldBuilder WithSemanticKernel(this ShieldBuilder builder, Kernel kernel)
    {
        if (builder == null) throw new ArgumentNullException(nameof(builder));
        if (kernel == null) throw new ArgumentNullException(nameof(kernel));

        var built = builder.WithCapability(CapabilityReport);
        // Stash the kernel so the build-time hook can register the
        // filter once the runtime is ready. We piggyback on the
        // bundle slot for the kernel reference.
        var bundle = new FrameworkBundle(CapabilityReport, agentBoundary: kernel);
        return built.WithBundle(bundle);
    }

    /// <summary>
    /// Wire the <see cref="AgentShieldFilter"/> onto the supplied
    /// kernel using this Shield's runtime. The filter's per-async-flow
    /// session is set to the Shield's session so Stage 2/3/4 share
    /// state with Stage 1 + Stage 5.
    ///
    /// <para>
    /// Usage: build the Shield, then call <c>shield.AttachFilter(kernel)</c>
    /// once before invoking the kernel.
    /// </para>
    /// </summary>
    public static AgentShieldFilter AttachFilter(this Shield shield, Kernel kernel)
    {
        if (shield == null) throw new ArgumentNullException(nameof(shield));
        if (kernel == null) throw new ArgumentNullException(nameof(kernel));
        var filter = new AgentShieldFilter(shield.Runtime);
        filter.CurrentSession = shield.Session;
        kernel.AutoFunctionInvocationFilters.Add(filter);
        return filter;
    }

    /// <summary>
    /// Register an <see cref="IChatCompletionService"/> as the
    /// guard-policy LLM-judge caller. Wires the chat service through
    /// an <see cref="SKLlmCaller"/> that honours the YAML's
    /// <c>configurations[]</c> entries (per-stage <c>model</c> /
    /// <c>max_tokens</c> selection) by binding to the runtime's
    /// <see cref="GuardrailsRuntime.LlmConfiguration"/> accessor at
    /// build time.
    ///
    /// <example>
    /// <code>
    /// var judgeService = kernel.GetRequiredService&lt;IChatCompletionService&gt;();
    /// using var shield = Shield.FromYaml("guardrails.yaml")
    ///     .WithSemanticKernel(kernel)
    ///     .WithSKLlmJudge(judgeService)
    ///     .Build();
    /// </code>
    /// </example>
    ///
    /// <para>
    /// Mirrors the Python <c>make_llm_caller(kernel,
    /// configuration_resolver=...)</c> shape on
    /// <c>sdk/python/agent_shield/adapters/semantic_kernel.py</c> and
    /// the
    /// <see cref="AgentShield.AI.ShieldExtensions.WithLlmJudge"/>
    /// shape on the Microsoft.Extensions.AI adapter so the same
    /// <c>.guardrails.yaml</c> drives identical per-stage model
    /// selection across all four SDKs.
    /// </para>
    /// </summary>
    public static ShieldBuilder WithSKLlmJudge(
        this ShieldBuilder builder,
        IChatCompletionService judgeService,
        Kernel? kernel = null)
    {
        if (builder == null) throw new ArgumentNullException(nameof(builder));
        if (judgeService == null) throw new ArgumentNullException(nameof(judgeService));
        var caller = new SKLlmCaller(judgeService, kernel);
        return builder
            .WithLlm(caller)
            .WithPostBuildHook(rt => caller.Bind(rt));
    }
}
