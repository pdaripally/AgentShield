using System;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.SemanticKernel;

using AgentShield;

namespace AgentShield.SemanticKernel;

/// <summary>
/// Semantic Kernel auto-function-invocation filter that enforces
/// Agent Shield guardrails on every kernel function call.
/// Stage 2 + 3 are run before invocation (with the parameter map);
/// Stage 4 is run on the result.
///
/// <para>
/// The filter expects a <see cref="GuardrailsSession"/> per turn —
/// callers should pass one in via the constructor or assign it via
/// <see cref="CurrentSession"/>. When no session is set the filter is
/// a no-op.
/// </para>
/// </summary>
public sealed class AgentShieldFilter : IAutoFunctionInvocationFilter
{
    private readonly GuardrailsRuntime _runtime;
    private readonly System.Threading.AsyncLocal<GuardrailsSession?> _current = new();

    public AgentShieldFilter(GuardrailsRuntime runtime)
    {
        _runtime = runtime ?? throw new ArgumentNullException(nameof(runtime));
    }

    /// <summary>Per-async-flow session. Assign before invoking the kernel.</summary>
    public GuardrailsSession? CurrentSession
    {
        get => _current.Value;
        set => _current.Value = value;
    }

    public async Task OnAutoFunctionInvocationAsync(
        AutoFunctionInvocationContext context,
        Func<AutoFunctionInvocationContext, Task> next)
    {
        var session = _current.Value;
        var ownsSession = session is null;
        session ??= _runtime.NewSession();

        try
        {
            var toolName = string.IsNullOrEmpty(context.Function.PluginName)
                ? context.Function.Name
                : $"{context.Function.PluginName}.{context.Function.Name}";

            // Build a JSON object of the arguments.
            var argsObj = new System.Collections.Generic.Dictionary<string, object?>();
            if (context.Arguments is not null)
            {
                foreach (var arg in context.Arguments)
                    argsObj[arg.Key] = arg.Value;
            }
            var argsJson = JsonSerializer.Serialize(argsObj);
            using var argsDoc = JsonDocument.Parse(argsJson);

            // §16.0 binding — SK's AutoFunctionInvocationContext does
            // not surface a per-invocation handle; mint a stable
            // per-call id so Stage 3 → Stage 4 bind to the same
            // canonical invocation under concurrent same-name calls.
            var boundId = Guid.NewGuid().ToString("N");

            var (verdict, mutated) = session!.ValidateToolCall(toolName, argsDoc.RootElement.Clone(), boundId);
            if (!verdict.Allowed)
            {
                context.Result = new FunctionResult(
                    context.Function,
                    $"[Blocked by Agent Shield] {verdict.Reason ?? "policy violation"}");
                context.Terminate = true;
                return;
            }

            // Project Stage-3 mutated arguments back into context.Arguments
            // so the underlying SK function receives the redacted values.
            // Fail closed: if we can't reconcile, skip the call with a
            // synthetic block verdict rather than passing raw arguments.
            if (context.Arguments is not null
                && mutated.ValueKind == JsonValueKind.Object
                && !ArgumentsRoundtripEqual(argsDoc.RootElement, mutated))
            {
                try
                {
                    foreach (var prop in mutated.EnumerateObject())
                    {
                        context.Arguments[prop.Name] = JsonElementToObject(prop.Value);
                    }
                }
                catch (Exception ex)
                {
                    context.Result = new FunctionResult(
                        context.Function,
                        $"[Blocked by Agent Shield] failed to apply redaction: {ex.Message}");
                    context.Terminate = true;
                    return;
                }
            }

            await next(context).ConfigureAwait(false);

            var resultObj = context.Result?.GetValue<object?>();
            var resultJson = JsonSerializer.Serialize(resultObj);
            using var resultDoc = JsonDocument.Parse(resultJson);
            var (outVerdict, outMutated) = session!.ValidateToolOutput(
                toolName, resultDoc.RootElement.Clone(), boundId);
            if (!outVerdict.Allowed)
            {
                context.Result = new FunctionResult(
                    context.Function,
                    $"[Blocked by Agent Shield] {outVerdict.Reason ?? "policy violation"}");
                return;
            }
            if (outMutated.GetRawText() != resultJson)
            {
                context.Result = new FunctionResult(context.Function, outMutated.GetRawText());
            }
        }
        finally
        {
            if (ownsSession) session?.Dispose();
        }
    }

    /// <summary>
    /// Compare a freshly-serialized arguments JsonElement to the
    /// runtime's mutated copy. Equal raw text means no Stage-3 transform
    /// fired, so we can skip the projection back into KernelArguments.
    /// </summary>
    private static bool ArgumentsRoundtripEqual(JsonElement original, JsonElement mutated)
    {
        return original.GetRawText() == mutated.GetRawText();
    }

    /// <summary>
    /// Convert a JsonElement to a CLR object suitable for storing into a
    /// <see cref="KernelArguments"/> value slot. Mirrors SK's parameter
    /// conventions: scalars unboxed, objects/arrays kept as JsonElement.
    /// </summary>
    private static object? JsonElementToObject(JsonElement el)
    {
        return el.ValueKind switch
        {
            JsonValueKind.Null => null,
            JsonValueKind.True => true,
            JsonValueKind.False => false,
            JsonValueKind.String => el.GetString(),
            JsonValueKind.Number when el.TryGetInt64(out var i) => i,
            JsonValueKind.Number => el.GetDouble(),
            _ => el.Clone(),
        };
    }
}
