using System;
using System.Collections.Generic;
using System.Text.Json;

using AgentShield;

namespace AgentShield.MCP;

/// <summary>
/// Session-scoping policy for an <see cref="MCPShield"/>.
/// </summary>
public enum SessionScope
{
    /// <summary>
    /// One long-lived session is held for the lifetime of the
    /// <see cref="MCPShield"/> (i.e. one MCP connection). State
    /// predicates therefore span tool calls. This is the default.
    /// </summary>
    Connection,

    /// <summary>
    /// A fresh session is created per <c>ProtectTool</c> /
    /// <c>ProtectToolOutput</c> call. Stateless; legacy behaviour.
    /// </summary>
    Call,
}

/// <summary>
/// Composable shield for MCP (Model Context Protocol) servers.
///
/// <para>
/// MCP servers are tool providers, not agent loops, so Agent Shield
/// treats them as a sibling integration family rather than a framework
/// adapter. There is no Stage 1 input boundary or Stage 5 output
/// boundary — the MCP server only sees tool calls and tool results.
/// </para>
///
/// <para>
/// Mirrors <c>agent_shield.mcp.MCPShield</c> in the Python SDK and
/// <c>mcp.js</c> in the Node SDK. By default a single session is held
/// for the connection so state predicates span tool calls; pass
/// <see cref="SessionScope.Call"/> to opt out.
/// </para>
/// </summary>
public sealed class MCPShield : IDisposable
{
    private static readonly CapabilityReport _mcpCapabilities = new(
        framework: "mcp",
        inputValidation: CoverageLevel.Unsupported,
        outputValidation: CoverageLevel.Unsupported,
        streamingOutput: CoverageLevel.Unsupported,
        notes: new[]
        {
            "MCP is a tool-provider integration; no user-facing input or assistant-output boundary exists for Stage 1 / Stage 5 / streaming",
        });

    public GuardrailsRuntime Runtime { get; }
    public CapabilityReport Capabilities => _mcpCapabilities;
    public SessionScope SessionScope { get; }

    private GuardrailsSession? _session;

    private MCPShield(GuardrailsRuntime runtime, SessionScope scope)
    {
        Runtime = runtime ?? throw new ArgumentNullException(nameof(runtime));
        SessionScope = scope;
    }

    /// <summary>Build an MCPShield from a single guardrails YAML file.</summary>
    public static MCPShieldBuilder FromYaml(string path) => new(path);

    /// <summary>Build an MCPShield from a chain of guardrails YAML files.</summary>
    public static MCPShieldBuilder FromYamlChain(IEnumerable<string> paths)
    {
        var b = new MCPShieldBuilder(string.Empty);
        b.SetChain(paths);
        return b;
    }

    /// <summary>Build an MCPShield from a composable <see cref="GuardrailsConfig"/>.</summary>
    public static MCPShieldBuilder FromConfig(GuardrailsConfig config)
    {
        var b = new MCPShieldBuilder(string.Empty);
        b.SetConfig(config);
        return b;
    }

    internal static MCPShield WrapRuntime(GuardrailsRuntime runtime, SessionScope scope)
        => new(runtime, scope);

    public void Dispose()
    {
        _session?.Dispose();
        _session = null;
        Runtime.Dispose();
    }

    /// <summary>
    /// The held connection session, or <c>null</c> when scope is
    /// <see cref="SessionScope.Call"/>. Lazily created on first
    /// access in connection mode.
    /// </summary>
    public GuardrailsSession? Session
    {
        get
        {
            if (SessionScope != SessionScope.Connection) return null;
            return _session ??= Runtime.NewSession();
        }
    }

    /// <summary>
    /// Drop the held connection session. The next call lazily creates
    /// a fresh one. No-op when scope is <see cref="SessionScope.Call"/>.
    /// </summary>
    public void ResetSession()
    {
        _session?.Dispose();
        _session = null;
    }

    private (GuardrailsSession sess, bool ownsSession) ResolveSession(GuardrailsSession? explicitSession)
    {
        if (explicitSession is not null) return (explicitSession, false);
        if (SessionScope == SessionScope.Connection)
            return (Session!, false);
        return (Runtime.NewSession(), true);
    }

    private static string FormatBlock(StageVerdict verdict)
        => $"[GUARDRAIL {(verdict.Action ?? "block").ToUpperInvariant()}] {verdict.Reason ?? "blocked by policy"}";

    // ── Per-call helpers ─────────────────────────────────────────

    /// <summary>
    /// Stage 2 + 3 validation for an inbound MCP tool call. Returns
    /// the verdict + the (possibly Stage-3-mutated) effective JSON
    /// parameters so the caller can pass safe values to the underlying
    /// tool.
    ///
    /// <paramref name="toolCallId"/> is required (§16.0): it is the
    /// stable per-invocation handle the runtime uses to bind this
    /// Stage 3 admission to the matching Stage 4 output. Reuse the
    /// same id when calling <see cref="ProtectToolOutput"/> for the
    /// same invocation. When the host framework does not natively
    /// expose an id (e.g. raw MCP without a request id), generate
    /// one via <c>Guid.NewGuid().ToString("N")</c> and thread the
    /// result through both calls.
    /// </summary>
    public (bool Allowed, string EffectiveParametersJson, string? BlockMessage) ProtectTool(
        string toolName,
        string parametersJson,
        string toolCallId,
        GuardrailsSession? session = null)
    {
        if (toolName is null) throw new ArgumentNullException(nameof(toolName));
        if (parametersJson is null) throw new ArgumentNullException(nameof(parametersJson));
        ArgumentNullException.ThrowIfNull(toolCallId);
        if (string.IsNullOrWhiteSpace(toolCallId))
            throw new ArgumentException("toolCallId is required and must be non-empty", nameof(toolCallId));

        var (sess, ownsSession) = ResolveSession(session);
        try
        {
            using var doc = JsonDocument.Parse(parametersJson);
            var (verdict, mutated) = sess.ValidateToolCall(toolName, doc.RootElement.Clone(), toolCallId);
            if (!verdict.Allowed)
            {
                return (false, parametersJson, FormatBlock(verdict));
            }
            return (true, mutated.GetRawText(), null);
        }
        finally
        {
            if (ownsSession) sess.Dispose();
        }
    }

    /// <summary>
    /// Stage 4 validation for an outbound MCP tool result. Records
    /// success / failure on the session unless <paramref name="record"/>
    /// is false. <paramref name="toolCallId"/> is required (§16.0)
    /// and MUST match the id passed to <see cref="ProtectTool"/> for
    /// the same invocation; the runtime fails closed with a
    /// <c>&lt;binding&gt;</c> verdict if no Stage 3 admission for this
    /// id exists.
    /// </summary>
    public (bool Allowed, string EffectiveOutput, string? BlockMessage) ProtectToolOutput(
        string toolName,
        string output,
        string toolCallId,
        GuardrailsSession? session = null,
        bool record = true)
    {
        if (toolName is null) throw new ArgumentNullException(nameof(toolName));
        if (output is null) throw new ArgumentNullException(nameof(output));
        ArgumentNullException.ThrowIfNull(toolCallId);
        if (string.IsNullOrWhiteSpace(toolCallId))
            throw new ArgumentException("toolCallId is required and must be non-empty", nameof(toolCallId));

        var (sess, ownsSession) = ResolveSession(session);
        try
        {
            // Always wrap as a JSON-string element to match Python/Node MCP
            // surfaces, which forward outputs as raw strings (FFI marshals as
            // JSON-string). Parsing-and-cloning would silently upgrade valid-JSON
            // string outputs to Object/Array kinds on .NET only, breaking the
            // spec §1.1 "identical observable semantics" invariant for
            // Stage 4 policies that read `result.<field>`.
            var outputElement = JsonSerializer.SerializeToElement(output);

            var (verdict, mutated) = sess.ValidateToolOutput(toolName, outputElement, toolCallId);
            if (!verdict.Allowed)
            {
                if (record)
                {
                    try { sess.RecordToolFailure(toolName, verdict.Reason ?? "blocked"); }
                    catch { /* best-effort */ }
                }
                return (false, output, FormatBlock(verdict));
            }
            if (record)
            {
                try { sess.RecordToolSuccess(toolName, mutated); }
                catch { /* best-effort */ }
            }
            var effective = mutated.ValueKind == JsonValueKind.String
                ? (mutated.GetString() ?? string.Empty)
                : mutated.GetRawText();
            return (true, effective, null);
        }
        finally
        {
            if (ownsSession) sess.Dispose();
        }
    }
}

/// <summary>Fluent builder for <see cref="MCPShield"/>.</summary>
public sealed class MCPShieldBuilder
{
    private readonly string _path;
    private List<string>? _yamlChain;
    private GuardrailsConfig? _config;
    private readonly List<IObservabilityProvider> _providers = new();
    private ILlmCaller? _llmCaller;
    private SessionScope _sessionScope = SessionScope.Connection;

    internal MCPShieldBuilder(string path) { _path = path; }

    internal void SetChain(IEnumerable<string> paths) => _yamlChain = new List<string>(paths);
    internal void SetConfig(GuardrailsConfig config) => _config = config;

    /// <summary>Register a single observability provider. Chain to
    /// register more.</summary>
    public MCPShieldBuilder WithObservability(IObservabilityProvider provider)
    {
        _providers.Add(provider);
        return this;
    }

    public MCPShieldBuilder WithLlmCaller(ILlmCaller caller)
    {
        _llmCaller = caller;
        return this;
    }

    /// <summary>
    /// Override the default <see cref="SessionScope.Connection"/>
    /// scope. Pass <see cref="SessionScope.Call"/> to force a fresh
    /// session per call.
    /// </summary>
    public MCPShieldBuilder WithSessionScope(SessionScope scope)
    {
        _sessionScope = scope;
        return this;
    }

    public MCPShield Build()
    {
        RuntimeBuilder builder;
        if (_config is not null)
            builder = RuntimeBuilder.FromConfig(_config);
        else if (_yamlChain is not null)
            builder = RuntimeBuilder.FromYamlChain(_yamlChain);
        else
            builder = RuntimeBuilder.FromYaml(_path);

        if (_llmCaller is not null) builder.RegisterLlmCaller(_llmCaller);
        foreach (var p in _providers) builder.RegisterObservabilityProvider(p);

        return MCPShield.WrapRuntime(builder.Build(), _sessionScope);
    }
}

/// <summary>
/// Thrown when a guarded MCP tool is blocked and the host opts into
/// exception-based on-block handling.
/// </summary>
public sealed class MCPGuardrailBlockedException : Exception
{
    public string ToolName { get; }

    public MCPGuardrailBlockedException(string toolName, string message)
        : base(message)
    {
        ToolName = toolName;
    }
}
