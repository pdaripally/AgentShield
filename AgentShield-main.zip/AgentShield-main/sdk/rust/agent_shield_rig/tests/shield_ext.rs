//! Smoke tests for the Rig `Shield` extension trait + Pattern B wrapper.

use std::path::PathBuf;
use std::sync::Arc;

use agent_shield::{CoverageLevel, Shield};
use agent_shield_rig::{GuardedRigTool, RigToolWrapper, ShieldRigExt, CAPABILITY_REPORT};
use rig::completion::ToolDefinition;
use rig::tool::{ToolDyn, ToolError};
use serde_json::json;

fn fixture() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("../../..")
        .join("tests/fixtures/smoke/minimal.guardrails.yaml")
}

#[test]
fn capability_report_const_marks_tool_exec_partial() {
    assert_eq!(
        CAPABILITY_REPORT.tool_execution_validation,
        Some(CoverageLevel::Partial),
        "rig hook path is partial because ToolCallHookAction has no Replace{{args}}"
    );
}

#[test]
fn with_rig_installs_partial_capability() {
    let shield = Shield::from_yaml(fixture())
        .with_rig()
        .build()
        .expect("build");
    let r = shield.capabilities();
    assert_eq!(r.framework, "rig");
    assert_eq!(r.tool_execution_validation, Some(CoverageLevel::Partial));
    assert!(r.notes.iter().any(|n| n.contains("Replace")));
}

#[test]
fn with_rig_full_coverage_promotes_tool_exec() {
    let shield = Shield::from_yaml(fixture())
        .with_rig_full_coverage()
        .build()
        .expect("build");
    let r = shield.capabilities();
    assert_eq!(r.framework, "rig");
    assert_eq!(
        r.tool_execution_validation,
        Some(CoverageLevel::Full),
        "Pattern B promotes tool_execution_validation to Full"
    );
}

// ── Pattern B wrapping ─────────────────────────────────────────────

struct EchoTool;

impl ToolDyn for EchoTool {
    fn name(&self) -> String {
        "echo".to_string()
    }

    fn definition<'a>(
        &'a self,
        _prompt: String,
    ) -> std::pin::Pin<Box<dyn std::future::Future<Output = ToolDefinition> + Send + 'a>> {
        Box::pin(async move {
            ToolDefinition {
                name: "echo".into(),
                description: "echoes args".into(),
                parameters: json!({"type": "object"}),
            }
        })
    }

    fn call<'a>(
        &'a self,
        args: String,
    ) -> std::pin::Pin<Box<dyn std::future::Future<Output = Result<String, ToolError>> + Send + 'a>>
    {
        Box::pin(async move { Ok(format!("echoed: {args}")) })
    }
}

#[tokio::test]
async fn pattern_b_wraps_each_tool() {
    let shield = Shield::from_yaml(fixture())
        .with_rig_full_coverage()
        .build()
        .expect("build");
    let tools: Vec<Arc<dyn ToolDyn>> = vec![Arc::new(EchoTool)];
    let wrapped: Vec<Arc<dyn ToolDyn>> = shield.protect_tools::<RigToolWrapper>(tools);
    assert_eq!(wrapped.len(), 1);
    assert_eq!(wrapped[0].name(), "echo");
}

#[tokio::test]
async fn guarded_tool_blocks_unauthorized_call() {
    let shield = Shield::from_yaml(fixture())
        .with_rig_full_coverage()
        .build()
        .expect("build");
    let inner: Arc<dyn ToolDyn> = Arc::new(EchoTool);
    let wrapped = GuardedRigTool::new(shield.runtime(), inner);
    let result = wrapped.call(r#"{"msg":"hi"}"#.to_string()).await;
    // The minimal fixture's `echo_only_when_authorized` policy blocks
    // when authorized != true. Our wrapped tool opens a fresh session
    // each call (default unauthorized), so the call must block.
    assert!(matches!(result, Err(ToolError::ToolCallError(_))));
}
