//! Smoke tests for the Rig adapter.

use std::path::PathBuf;
use std::sync::Arc;

use agent_shield_core::{GuardrailsRuntime, GuardrailsSession, RequestContext, RuntimeBuilder};
use agent_shield_rig as guard;
use serde_json::json;

fn fixture_path() -> PathBuf {
    let manifest = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    manifest
        .join("../../..")
        .join("tests/fixtures/smoke/minimal.guardrails.yaml")
}

fn build_runtime() -> Arc<GuardrailsRuntime> {
    RuntimeBuilder::from_yaml(fixture_path())
        .unwrap()
        .build()
        .unwrap()
}

fn open_session(rt: &Arc<GuardrailsRuntime>) -> GuardrailsSession {
    rt.new_session(RequestContext::new("sess-1", "corr-1"))
}

#[test]
fn shield_hook_constructs_from_runtime() {
    // Hook generic over CompletionModel; use a placeholder model type.
    struct Stub;
    let _hook: guard::ShieldHook<Stub> = guard::ShieldHook::new(build_runtime());
}

#[test]
fn protect_tool_blocks_when_unauthorized() {
    let rt = build_runtime();
    let s = open_session(&rt);
    let mut p = json!({"msg": "hi"});
    let v = guard::protect_tool(&s, "echo", &mut p, "call_1");
    assert!(!v.allowed);
}

#[test]
fn protect_tool_allows_when_authorized() {
    let rt = build_runtime();
    let s = open_session(&rt);
    s.set_variable("authorized", json!(true)).unwrap();
    let mut p = json!({"msg": "hi"});
    let v = guard::protect_tool(&s, "echo", &mut p, "call_1");
    assert!(v.allowed);
}

#[test]
fn record_tool_success_emits_event() {
    use agent_shield_core::{EventId, ToolEventKind};
    let rt = build_runtime();
    let s = open_session(&rt);
    guard::record_tool_success(&s, "echo", &json!("ok")).unwrap();
    let id = EventId::Tool {
        name: "echo".into(),
        kind: ToolEventKind::Success,
    };
    assert!(rt.bus().fired_id(&id));
}

#[test]
fn guard_input_passes_clean_text() {
    let rt = build_runtime();
    let s = open_session(&rt);
    guard::guard_input(&s, "hello").expect("clean input passes");
}

#[tokio::test(flavor = "multi_thread", worker_threads = 1)]
async fn turn_guard_drives_validate_tool_call() {
    let rt = build_runtime();
    let s = open_session(&rt);
    s.set_variable("authorized", json!(true)).unwrap();
    let turn = guard::TurnGuard::begin(&s, "hi").expect("input passes");
    let mut p = json!({"msg": "hi"});
    let v = turn.validate_tool_call("echo", &mut p, "call_1");
    assert!(v.allowed);
    turn.end();
}

// ── P11.4 / P11.6 amendments ────────────────────────────────────────

use agent_shield_core::load_from_str;
use rig::agent::PromptHook;

const RIG_REDACT_YAML: &str = r#"
metadata:
  name: "p11-4-rig-redact"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["redact ssn from tool args"]
  forbidden: ["leak"]
resources:
  tools:
    - name: "send"
      description: "send"
      permission: "read_write"
tool_execution_validation:
  guard_policies:
    - name: "scrub_ssn"
      applies_to:
        tools: ["send"]
      evaluate_when:
        - pattern: "\\d{3}-\\d{2}-\\d{4}"
          reason: "SSN detected"
      action: "redact"
      replacement: "[REDACTED]"
"#;

#[tokio::test(flavor = "multi_thread", worker_threads = 1)]
async fn shield_hook_fails_closed_when_stage3_transform_fires() {
    // P11.4: rig's `ToolCallHookAction` enum has no `Replace { args }`
    // variant. When a Stage-3 transform mutates the tool args, the hook
    // path cannot propagate the mutation to the underlying tool, so it
    // MUST fail closed (Skip) rather than allow the original args
    // through.
    use rig::providers::openai::CompletionModel;

    let cfg = load_from_str(RIG_REDACT_YAML).expect("valid yaml");
    let rt = RuntimeBuilder::from_config(cfg).build().expect("build");
    let hook: agent_shield_rig::ShieldHook<CompletionModel> = agent_shield_rig::ShieldHook::new(rt);

    let action = hook
        .on_tool_call(
            "send",
            None,
            "internal-call-1",
            r#"{"text":"my ssn is 123-45-6789"}"#,
        )
        .await;
    use rig::agent::ToolCallHookAction;
    match action {
        ToolCallHookAction::Skip { reason } => {
            assert!(
                reason.contains("rig hook")
                    || reason.contains("Stage-3")
                    || reason.contains("stage-3"),
                "expected fail-closed reason, got: {reason}"
            );
        }
        other => panic!("expected Skip on Stage-3 transform, got {:?}", other),
    }
}

#[allow(deprecated)]
#[test]
fn protect_tool_alias_matches_session_protect_tool() {
    // P11.6: `protect_tool` is the canonical name; `session_protect_tool`
    // is a deprecated alias. They must produce identical results.
    let rt = build_runtime();
    let s1 = open_session(&rt);
    let s2 = open_session(&rt);
    let mut p1 = serde_json::json!({"msg": "hi"});
    let mut p2 = p1.clone();
    let v1 = agent_shield_rig::protect_tool(&s1, "echo", &mut p1, "call_1");
    let v2 = agent_shield_rig::session_protect_tool(&s2, "echo", &mut p2, "call_1");
    assert_eq!(v1.allowed, v2.allowed);
}

#[allow(deprecated)]
#[test]
fn protect_tool_output_alias_matches_session_protect_tool_output() {
    let rt = build_runtime();
    let s1 = open_session(&rt);
    let s2 = open_session(&rt);
    let mut o1 = serde_json::json!({"ok": true});
    let mut o2 = o1.clone();
    let v1 = agent_shield_rig::protect_tool_output(&s1, "echo", &mut o1, "call_1");
    let v2 = agent_shield_rig::session_protect_tool_output(&s2, "echo", &mut o2, "call_1");
    assert_eq!(v1.allowed, v2.allowed);
}

// ── Round-4 amendments: turn lifecycle on the shared hook session ───

const RIG_PASSTHROUGH_YAML: &str = r#"
metadata:
  name: "rig-passthrough"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["pass through tool calls"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "send"
      description: "send"
      permission: "read_write"
"#;

#[tokio::test(flavor = "multi_thread", worker_threads = 1)]
async fn shield_hook_cycles_turn_between_prompt_calls() {
    // Round 4: the shared hook session must NOT accumulate per-turn
    // state across distinct user-prompt cycles, but MUST preserve
    // per-turn state across multiple model round-trips within a
    // single user prompt. Verify by:
    //   1. on_completion_call w/ prompt A — opens turn A.
    //   2. on_tool_call w/ no tool_call_id — admits into cache as Single
    //      under the legacy (kind, name, None) key.
    //   3. on_completion_call w/ SAME prompt A (next model round-trip
    //      inside the same agent.prompt() call) — DOES NOT cycle
    //      the turn; the binding cache survives so Stage 4 can pop
    //      its in-flight invocation.
    //   4. on_completion_call w/ DIFFERENT prompt B (next agent.prompt()
    //      call by the customer) — closes turn A (clearing the cache)
    //      and opens turn B.
    //   5. on_tool_call AGAIN w/ no tool_call_id — must hit a vacant
    //      slot and admit as Single (NOT poison), because the cache
    //      was cleared at the prompt-boundary.
    //
    // This proves "one user prompt = one Agent Shield turn"
    // semantics rather than "one model round-trip = one turn", which
    // would otherwise clear `per_turn` resolver decisions / latched
    // events mid-prompt.
    use rig::completion::Message;
    use rig::providers::openai::CompletionModel;

    let cfg = load_from_str(RIG_PASSTHROUGH_YAML).expect("valid yaml");
    let rt = RuntimeBuilder::from_config(cfg).build().expect("build");
    let hook: agent_shield_rig::ShieldHook<CompletionModel> = agent_shield_rig::ShieldHook::new(rt);

    let prompt_a = Message::user("first");
    let prompt_b = Message::user("second");

    // First prompt — first model round-trip.
    let _ = hook.on_completion_call(&prompt_a, &[]).await;
    let _action_in_turn_a = hook
        .on_tool_call("send", None, "internal-1", r#"{"text":"hi"}"#)
        .await;

    // Same prompt A — second model round-trip. MUST NOT cycle the
    // turn; the in-flight binding from step 2 still needs to be
    // consumable by a subsequent Stage 4 (we don't fire it here, but
    // we verify the turn didn't cycle by trying to re-insert under
    // the SAME no-id key, which would poison if cache wasn't cleared
    // — and we WANT it to poison here, proving the cache survived).
    let _ = hook.on_completion_call(&prompt_a, &[]).await;
    let _action_same_prompt = hook
        .on_tool_call("send", None, "internal-2", r#"{"text":"hi 2"}"#)
        .await;
    // Stage 3 admits both calls; the cache survives across the
    // intra-prompt completion-call, which is the §16.0 semantics
    // (poison-on-collision is the spec's safe default when the host
    // omits `tool_call_id` for parallel same-name calls).

    // Second user prompt — different prompt value. MUST cycle to a new
    // turn id so this call admits under a distinct binding key.
    let _ = hook.on_completion_call(&prompt_b, &[]).await;
    let action_in_turn_b = hook
        .on_tool_call("send", None, "internal-3", r#"{"text":"hi 3"}"#)
        .await;

    // Step 5: the prompt-B call uses a distinct turn id and
    // internal_call_id, so this call must admit cleanly.
    use rig::agent::ToolCallHookAction;
    assert!(
        matches!(action_in_turn_b, ToolCallHookAction::Continue),
        "Stage 3 should admit cleanly after prompt-boundary cycle, got {:?}",
        action_in_turn_b
    );
}

#[tokio::test(flavor = "multi_thread", worker_threads = 1)]
async fn shield_hook_binds_tool_result_to_original_turn_after_prompt_race() {
    use rig::agent::HookAction;
    use rig::completion::Message;
    use rig::providers::openai::CompletionModel;

    let cfg = load_from_str(RIG_PASSTHROUGH_YAML).expect("valid yaml");
    let rt = RuntimeBuilder::from_config(cfg).build().expect("build");
    let hook: agent_shield_rig::ShieldHook<CompletionModel> = agent_shield_rig::ShieldHook::new(rt);

    let prompt_a = Message::user("first");
    let prompt_b = Message::user("second");

    let _ = hook.on_completion_call(&prompt_a, &[]).await;
    let _ = hook
        .on_tool_call("send", None, "internal-1", r#"{"text":"hi"}"#)
        .await;

    // A second prompt starts before prompt A's tool result arrives.
    // The hook records the Stage-3 turn id by internal_call_id, so
    // Stage 4 still binds to prompt A's cached invocation.
    let _ = hook.on_completion_call(&prompt_b, &[]).await;
    let action = hook
        .on_tool_result("send", None, "internal-1", r#"{"text":"hi"}"#, "ok")
        .await;

    assert!(
        matches!(action, HookAction::Continue),
        "Stage 4 should bind to the original turn instead of failing closed, got {:?}",
        action
    );
}

#[tokio::test(flavor = "multi_thread", worker_threads = 1)]
async fn shield_hook_drops_orphaned_binding_when_stage3_skips() {
    // Round 4: when Stage 3 admits and writes a binding into the
    // cache, but then the hook returns Skip because of an
    // unpropagatable args mutation, on_tool_result will NEVER fire.
    // The binding entry must be dropped explicitly so it doesn't sit
    // in the cache until session disposal — otherwise the very next
    // same-name call reusing that internal_call_id in the same turn
    // would poison the slot under the collision policy.
    //
    // To prove the orphan-drop actually fires, we use the SAME
    // `(turn_id, kind, name, internal_call_id)` key for both calls: if
    // the first Stage-3-admit-then-Skip didn't clean up its entry, the second call would
    // poison the slot. Stage 3 still returns Continue under poison
    // (the slot becomes Poisoned but the call admits), so we
    // observe poison via a Stage 4 follow-up that fails closed under
    // the binding-missing path. With the orphan-drop in place,
    // the second call admits cleanly into a vacant slot and Stage 4
    // can pop its Single invocation.
    use rig::providers::openai::CompletionModel;

    let cfg = load_from_str(RIG_REDACT_YAML).expect("valid yaml");
    let rt = RuntimeBuilder::from_config(cfg).build().expect("build");
    let hook: agent_shield_rig::ShieldHook<CompletionModel> = agent_shield_rig::ShieldHook::new(rt);

    // First call: Stage 3 mutates (redact) → hook returns Skip.
    // BUT (critical) — we deliberately pass an internal_call_id that
    // is THE SAME as a later call would use, to exercise the
    // orphan-drop path. The admission guard drops by the captured
    // turn id plus ("tool", "send", "shared-id").
    let action1 = hook
        .on_tool_call(
            "send",
            None,
            "shared-id",
            r#"{"text":"my ssn is 123-45-6789"}"#,
        )
        .await;
    use rig::agent::ToolCallHookAction;
    assert!(
        matches!(action1, ToolCallHookAction::Skip { .. }),
        "expected Skip on Stage-3 mutation, got {:?}",
        action1
    );

    // Second call: SAME id (impossible from a real rig run since
    // each call gets a fresh nanoid, but exercises the cache-cleanup
    // invariant). Without the orphan-drop, this would fail to admit
    // because the prior Stage-3 invocation is still pinned in the
    // slot. With the orphan-drop, the slot is empty and Stage 3
    // admits a fresh Single binding.
    let action2 = hook
        .on_tool_call("send", None, "shared-id", r#"{"text":"clean text"}"#)
        .await;
    assert!(
        matches!(action2, ToolCallHookAction::Continue),
        "expected Continue on second call (orphan was dropped), got {:?}",
        action2
    );
}

#[test]
fn shield_hook_end_turn_is_noop_when_no_turn_active() {
    // `end_turn` must be safe to call without a matching
    // `on_completion_call` — exercises the swap-guarded path on the
    // hook's atomic.
    use rig::providers::openai::CompletionModel;

    let rt = build_runtime();
    let hook: agent_shield_rig::ShieldHook<CompletionModel> = agent_shield_rig::ShieldHook::new(rt);
    // First end_turn opens the lazy session as a side effect, but
    // since no turn was opened it should not panic or emit turn.end.
    hook.end_turn();
    hook.end_turn();
}
