//! Cross-language adapter-scenario harness — Rig.
//!
//! See `sdk/rust/adapter_scenarios_common.rs` for the shared body.
//! Uses `with_rig_full_coverage()` (Pattern B) so Stage-3 mutations
//! propagate. Without Pattern B, Rig's hook path can't carry mutated
//! args (rig-core 0.35's `ToolCallHookAction` has no `Replace{args}`
//! variant); `with_rig_full_coverage()` wraps tools up-front to
//! sidestep that limitation, matching how a real Rig host would
//! enforce Stage 3.

use agent_shield_rig::ShieldRigExt;

#[path = "../../adapter_scenarios_common.rs"]
mod common;

#[tokio::test(flavor = "current_thread")]
async fn shared_adapter_scenarios() {
    common::run_with("rig", |b| b.with_rig_full_coverage()).await;
}
