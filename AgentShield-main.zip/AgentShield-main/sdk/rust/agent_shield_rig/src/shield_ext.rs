//! `Shield`-builder extension trait + Pattern B tool wrapper for the
//! Rig adapter.
//!
//! Rig's `ToolCallHookAction` enum has no `Replace { args }` variant
//! in `rig-core 0.35`, so the hook-based path cannot propagate
//! Stage-3-mutated arguments to the underlying tool. The hook
//! adapter therefore reports
//! `tool_execution_validation = Partial`. Pattern B wraps each tool
//! up-front via [`RigToolWrapper`] before constructing the Rig agent;
//! that path achieves full Stage-3 mutation coverage and the
//! capability report can be promoted with [`with_rig_full_coverage`].
//!
//! # Example (≤ 5 lines)
//!
//! ```no_run
//! # fn ex() -> Result<(), Box<dyn std::error::Error>> {
//! use agent_shield::Shield;
//! use agent_shield_rig::ShieldRigExt;
//! let shield = Shield::from_yaml(".guardrails.yaml").with_rig().build()?;
//! # let _ = shield; Ok(()) }
//! ```

use std::pin::Pin;
use std::sync::Arc;

use agent_shield::{CapabilityReport, CoverageLevel, ShieldBuilder, ToolWrapper};
use agent_shield_core::{synthetic_tool_call_id, GuardrailsRuntime, RequestContext};
use rig::completion::ToolDefinition;
use rig::tool::{ToolDyn, ToolError};

/// Capability report when Rig is wired via the `ShieldHook` path
/// (the default). `tool_execution_validation` is downgraded to
/// `Partial` because Rig's hook surface cannot carry Stage-3 mutated
/// args forward to the inner tool.
pub const CAPABILITY_REPORT: CapabilityReport = CapabilityReport {
    framework: String::new(),
    input_validation: Some(CoverageLevel::Full),
    state_validation: Some(CoverageLevel::Full),
    tool_authorization: Some(CoverageLevel::Full),
    tool_execution_validation: Some(CoverageLevel::Partial),
    tool_output_validation: Some(CoverageLevel::Full),
    output_validation: Some(CoverageLevel::Full),
    streaming_output: Some(CoverageLevel::Partial),
    notes: Vec::new(),
};

fn report_partial() -> CapabilityReport {
    CapabilityReport {
        framework: "rig".to_string(),
        notes: vec![
            "tool_execution_validation is partial via the ShieldHook path: \
             rig-core 0.35's ToolCallHookAction has no Replace{args} variant, \
             so Stage-3 mutated args cannot be propagated. The hook fails \
             closed (Skip) on any Stage-3 mutation."
                .to_string(),
            "streaming_output is partial: chunk-level redaction is not \
             plumbed through Rig's stream surface."
                .to_string(),
            "Use shield.protect_tools::<RigToolWrapper>(rig_tools) before \
             constructing the agent to achieve Full tool_execution_validation; \
             call .with_rig_full_coverage() in that case."
                .to_string(),
        ],
        ..CAPABILITY_REPORT
    }
}

fn report_full() -> CapabilityReport {
    CapabilityReport {
        framework: "rig".to_string(),
        tool_execution_validation: Some(CoverageLevel::Full),
        notes: vec![
            "Pattern B (RigToolWrapper) wraps tools up-front so Stage-3 \
             mutations propagate before Rig dispatches the inner call."
                .to_string(),
            "streaming_output is partial: chunk-level redaction is not \
             plumbed through Rig's stream surface."
                .to_string(),
        ],
        ..CAPABILITY_REPORT
    }
}

/// Extension trait adding `with_rig` / `with_rig_full_coverage` to
/// [`ShieldBuilder`].
pub trait ShieldRigExt {
    /// Install the default (hook-path) Rig capability report.
    fn with_rig(self) -> Self;

    /// Install the Pattern-B (RigToolWrapper) capability report —
    /// promotes `tool_execution_validation` to `Full`. Use this when
    /// you wrap tools via [`crate::shield_ext::RigToolWrapper`] before
    /// constructing the Rig agent.
    fn with_rig_full_coverage(self) -> Self;
}

impl ShieldRigExt for ShieldBuilder {
    fn with_rig(self) -> Self {
        self.with_capability(report_partial())
    }

    fn with_rig_full_coverage(self) -> Self {
        self.with_capability(report_full())
    }
}

// ── Pattern B: RigToolWrapper ───────────────────────────────────────

/// Wraps an `Arc<dyn ToolDyn>` so Stage 2/3 / Stage 4 run around every
/// call, and Stage-3-mutated args are re-serialized before delegating
/// to the inner tool. Each call opens a fresh `GuardrailsSession`.
pub struct GuardedRigTool {
    inner: Arc<dyn ToolDyn>,
    runtime: Arc<GuardrailsRuntime>,
}

impl GuardedRigTool {
    pub fn new(runtime: Arc<GuardrailsRuntime>, inner: Arc<dyn ToolDyn>) -> Self {
        Self { inner, runtime }
    }
}

impl ToolDyn for GuardedRigTool {
    fn name(&self) -> String {
        self.inner.name()
    }

    fn definition<'a>(
        &'a self,
        prompt: String,
    ) -> Pin<Box<dyn std::future::Future<Output = ToolDefinition> + Send + 'a>> {
        self.inner.definition(prompt)
    }

    fn call<'a>(
        &'a self,
        args: String,
    ) -> Pin<Box<dyn std::future::Future<Output = Result<String, ToolError>> + Send + 'a>> {
        let inner = self.inner.clone();
        let rt = self.runtime.clone();
        let name = self.inner.name();
        Box::pin(async move {
            let session = rt.new_session(RequestContext::default());

            // Rig's `Tool::call` boundary has no stable per-invocation
            // handle (`internal_call_id` is only exposed to the hook
            // path, not to wrapped tools). Synthesize a UUID so Stage 3
            // and Stage 4 bind the same canonical invocation per §16.0.
            let tool_call_id = synthetic_tool_call_id();

            // Parse args. Fail closed on bad JSON.
            let mut value: serde_json::Value = match serde_json::from_str(&args) {
                Ok(v) => v,
                Err(e) => {
                    if let Err(rec_err) =
                        session.record_tool_failure(&name, "malformed tool arguments")
                    {
                        log::warn!(target: "agent_shield::rig", "record_tool_failure failed: {rec_err:?}");
                    }
                    return Err(ToolError::JsonError(e));
                }
            };

            // Stage 2/3.
            let stage23 = session.validate_tool_call(&name, &mut value, &tool_call_id);
            if !stage23.allowed {
                if let Err(e) = session
                    .record_tool_failure(&name, stage23.reason.as_deref().unwrap_or("blocked"))
                {
                    log::warn!(target: "agent_shield::rig", "record_tool_failure failed: {e:?}");
                }
                return Err(ToolError::ToolCallError(
                    format!(
                        "[GUARDRAIL BLOCK] {} (tool: {})",
                        stage23.reason.as_deref().unwrap_or("blocked"),
                        name
                    )
                    .into(),
                ));
            }

            // Re-serialize the (possibly mutated) args before
            // dispatching to the inner tool.
            let serialized = match serde_json::to_string(&value) {
                Ok(s) => s,
                Err(e) => {
                    if let Err(rec_err) = session.record_tool_failure(
                        &name,
                        "failed to re-serialize transformed tool arguments",
                    ) {
                        log::warn!(target: "agent_shield::rig", "record_tool_failure failed: {rec_err:?}");
                    }
                    return Err(ToolError::JsonError(e));
                }
            };

            let raw = match inner.call(serialized).await {
                Ok(s) => s,
                Err(e) => {
                    if let Err(rec_err) = session.record_tool_failure(&name, &e.to_string()) {
                        log::warn!(target: "agent_shield::rig", "record_tool_failure failed: {rec_err:?}");
                    }
                    return Err(e);
                }
            };

            // Stage 4.
            let mut out = serde_json::Value::String(raw.clone());
            let stage4 = session.validate_tool_output(&name, &mut out, &tool_call_id);
            if !stage4.allowed {
                if let Err(e) = session.record_tool_failure(&name, "post-tool-blocked") {
                    log::warn!(target: "agent_shield::rig", "record_tool_failure failed: {e:?}");
                }
                return Err(ToolError::ToolCallError(
                    format!(
                        "[GUARDRAIL BLOCK] {} (tool: {})",
                        stage4.reason.as_deref().unwrap_or("blocked"),
                        name
                    )
                    .into(),
                ));
            }
            if let Err(e) = session.record_tool_success(&name, &out) {
                log::warn!(target: "agent_shield::rig", "record_tool_success failed: {e:?}");
            }
            Ok(out.as_str().map(|s| s.to_string()).unwrap_or(raw))
        })
    }
}

/// `ToolWrapper` impl for Rig tools (Pattern B).
pub struct RigToolWrapper;

impl ToolWrapper for RigToolWrapper {
    type Tool = Arc<dyn ToolDyn>;
    type Wrapped = Arc<dyn ToolDyn>;

    fn wrap(runtime: Arc<GuardrailsRuntime>, tool: Arc<dyn ToolDyn>) -> Arc<dyn ToolDyn> {
        Arc::new(GuardedRigTool::new(runtime, tool)) as Arc<dyn ToolDyn>
    }
}
