//! Agent Shield adapter for Rig.
//!
//! Provides guardrail validation for Rig tool integrations.
//!
//! ## Coverage caveat
//!
//! The hook-based path (`ShieldHook`) reports
//! `tool_execution_validation = Partial`: rig-core 0.35's
//! [`rig::agent::ToolCallHookAction`] enum has no `Replace { args }`
//! variant, so Stage-3 mutated arguments cannot be propagated through
//! the hook surface. The hook fails closed (returning `Skip`) on any
//! Stage-3 mutation. For full Stage-3 mutation coverage, use the
//! [`shield_ext::RigToolWrapper`] (Pattern B): wrap each tool before
//! constructing the Rig agent, and call
//! [`shield_ext::ShieldRigExt::with_rig_full_coverage`] on the
//! [`agent_shield::ShieldBuilder`] so the capability report is
//! promoted accordingly.
//!
//! Upstream: <https://github.com/0xPlaygrounds/rig/issues/1744> tracks
//! adding a `ToolCallHookAction::Replace { args }` variant. When that
//! lands the hook-based path can promote to `Full` coverage and the
//! `RigToolWrapper` fallback becomes optional.
//!
//! ## Concurrency caveat
//!
//! The hook-based [`ShieldHook`] also requires single-prompt-at-a-time
//! usage on each hook instance (clones share state). For concurrent
//! prompt cycles on a shared `Arc<rig::Agent>` — the standard pattern
//! for HTTP-server worker pools — use the wrap-up-front
//! [`shield_ext::RigToolWrapper`] path instead. `GuardedRigTool::call`
//! creates a fresh session per invocation, so concurrent calls across
//! concurrent prompts cannot race on the §16.0 binding cache.
//! See [`ShieldHook`] docs for the exact race scenario.

#![allow(clippy::result_large_err)]

pub mod shield_ext;

pub use shield_ext::{GuardedRigTool, RigToolWrapper, ShieldRigExt, CAPABILITY_REPORT};

use std::collections::HashMap;
use std::marker::PhantomData;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex, OnceLock};

use agent_shield_core::{
    GuardrailsRuntime, GuardrailsSession, RequestContext, RuntimeError, StageVerdict,
};
use rig::agent::{HookAction, PromptHook, ToolCallHookAction};
use rig::completion::CompletionModel;
use rig::message::Message;
use serde_json::Value;

/// [`PromptHook`] that enforces Agent Shield guardrails.
///
/// **§16.0 binding model.** The hook maintains a single
/// long-lived [`GuardrailsSession`] (lazily initialised on the first
/// callback) so Stage 3 and Stage 4 share the same session and Stage 4
/// can pop the same canonical invocation Stage 3 admitted.
///
/// The binding id passed to `validate_tool_call` /
/// `validate_tool_output` is **rig's `internal_call_id`**: a
/// stable per-invocation handle rig generates and threads through to
/// both hook callbacks. That makes the binding §16.0-compliant by
/// construction even when the upstream model omits `tool_call_id`,
/// and it correctly distinguishes parallel same-name calls within one
/// turn (each gets a distinct `internal_call_id`).
///
/// **Turn lifecycle — one user prompt = one Agent Shield turn.**
/// Rig has no native per-prompt-cycle hook, so the adapter derives
/// turn boundaries from the `_prompt: &Message` parameter passed to
/// every `on_completion_call`: within a single `agent.prompt(text)`
/// invocation, rig fires `on_completion_call` multiple times (once
/// per model round-trip) with the SAME `_prompt`. The hook tracks
/// the previous prompt and only cycles the turn when the prompt
/// changes — preserving spec semantics that `per_turn` resolver
/// decisions, latched events, and variable lifetimes span the whole
/// user prompt rather than a single intermediate round-trip. The
/// last turn opened by the hook is closed lazily when the next
/// `on_completion_call` fires with a different prompt; customers can
/// also call [`ShieldHook::end_turn`] explicitly after their final
/// `agent.prompt()` call to release per-turn state immediately
/// instead of waiting for the next prompt.
///
/// **Concurrency caveat — single-prompt-at-a-time.** `ShieldHook` is
/// `Clone`, but every clone shares the same
/// [`Arc<OnceLock<Arc<GuardrailsSession>>>`] and the same
/// `turn_active` / `last_prompt` state, so cloning the hook does NOT
/// give callers independent sessions. The same agent-attached hook
/// MUST NOT be used to drive concurrent `agent.prompt()` cycles
/// (e.g. a single `Arc<rig::Agent>` shared across HTTP-request
/// worker tasks issuing different prompts in flight). If two cycles
/// race on `on_completion_call` with different prompts, the second
/// cycle's `open_turn` will end the first cycle's turn. Stage 4 tool
/// outputs still bind to the turn captured at Stage 3, but other
/// per-turn state (resolver decisions, latches, variable lifetimes)
/// remains shared at the hook-session level. The hook fails closed for
/// policy violations, but this surface is still not the recommended
/// shape for concurrent prompt cycles.
///
/// **For concurrent prompt cycles, use the wrap-up-front path
/// [`GuardedRigTool`] / [`ShieldRigExt::with_rig_full_coverage`]
/// instead** of the [`PromptHook`] path. `GuardedRigTool::call`
/// opens a fresh session per invocation, so concurrent tool calls
/// across concurrent prompts cannot collide. The wrap-up-front path
/// also gives Full coverage (Stage 3 redact/replace mutations are
/// propagated through `RigToolWrapper`), versus the hook path's
/// documented Partial coverage. The hook is the right choice only
/// when (a) coverage trade-off is acceptable AND (b) the agent is
/// driven by a single sequential consumer (CLI tool, single-prompt
/// request handler, test harness).
#[derive(Clone)]
pub struct ShieldHook<M> {
    runtime: Arc<GuardrailsRuntime>,
    // OnceLock so the very first hook callback opens the shared
    // session lazily; cheap to clone via Arc.
    session: Arc<OnceLock<Arc<GuardrailsSession>>>,
    // Tracks whether a turn is currently active on the shared session,
    // so the hook never double-emits `turn.start` or skips `turn.end`.
    turn_active: Arc<AtomicBool>,
    // Identity of the user prompt that opened the active turn. Used
    // to detect prompt-boundary transitions across `on_completion_call`
    // invocations: identical prompts within a single agent loop reuse
    // the open turn; a different prompt cycles the turn.
    last_prompt: Arc<Mutex<Option<Message>>>,
    // Maps rig's stable internal call id to the Agent Shield turn that
    // admitted it, so Stage 4 can bind correctly even if another
    // prompt opens a new turn before `on_tool_result` fires.
    tool_turns: Arc<Mutex<HashMap<String, u64>>>,
    _model: PhantomData<M>,
}

impl<M> ShieldHook<M> {
    /// Create a new hook from a runtime.
    pub fn new(runtime: Arc<GuardrailsRuntime>) -> Self {
        Self {
            runtime,
            session: Arc::new(OnceLock::new()),
            turn_active: Arc::new(AtomicBool::new(false)),
            last_prompt: Arc::new(Mutex::new(None)),
            tool_turns: Arc::new(Mutex::new(HashMap::new())),
            _model: PhantomData,
        }
    }

    fn tool_turn_key(tool_name: &str, internal_call_id: &str) -> String {
        format!("{tool_name}\0{internal_call_id}")
    }

    /// Get (or lazily open) the long-lived hook session. Cheap: subsequent
    /// callers share an `Arc` to the same session.
    fn shared_session(&self) -> Arc<GuardrailsSession> {
        self.session
            .get_or_init(|| Arc::new(self.runtime.new_session(RequestContext::default())))
            .clone()
    }

    /// Close the active turn on the shared session, if one is open.
    /// Idempotent and side-effect-safe; logs and continues on error
    /// so a single bus failure doesn't deadlock the hook lifecycle.
    fn close_active_turn(&self, session: &GuardrailsSession) {
        if self.turn_active.swap(false, Ordering::AcqRel) {
            if let Err(e) = session.end_turn() {
                log::warn!(target: "agent_shield::rig", "end_turn failed: {e:?}");
            }
        }
    }

    /// Open a fresh turn on the shared session. Idempotent: if a turn
    /// is already active (because the customer used `TurnGuard`
    /// externally or a prior `end_turn` failed), the existing turn is
    /// closed first.
    fn open_turn(&self, session: &GuardrailsSession) {
        self.close_active_turn(session);
        match session.begin_turn() {
            Ok(_) => {
                self.turn_active.store(true, Ordering::Release);
            }
            Err(e) => {
                log::warn!(target: "agent_shield::rig", "begin_turn failed: {e:?}");
            }
        }
    }

    /// Explicitly end the hook's active turn. Customers can call this
    /// after their final `agent.prompt()` call to release per-turn
    /// state immediately instead of waiting for the next prompt to
    /// cycle the turn lazily. Idempotent.
    pub fn end_turn(&self) {
        let session = self.shared_session();
        self.close_active_turn(&session);
        if let Ok(mut g) = self.last_prompt.lock() {
            *g = None;
        }
        if let Ok(mut g) = self.tool_turns.lock() {
            g.clear();
        }
    }

    /// Borrow the long-lived shared session. Customers who need
    /// direct access to the session (e.g. to set variables, drive
    /// Stage 1 / Stage 5, or attach a [`TurnGuard`]) can use this to
    /// reach into the same session the hook callbacks use.
    pub fn session(&self) -> Arc<GuardrailsSession> {
        self.shared_session()
    }
}

impl<M: CompletionModel> PromptHook<M> for ShieldHook<M> {
    fn on_completion_call(
        &self,
        prompt: &Message,
        _history: &[Message],
    ) -> impl std::future::Future<Output = HookAction> + Send {
        // §16.1 / spec §10: one user prompt = one Agent Shield turn.
        // Within a single `agent.prompt(text)` call, rig fires this
        // hook once per model round-trip with the SAME `prompt`
        // value. We detect prompt-boundary transitions by identity
        // comparison and only cycle the turn when the prompt
        // actually changes, so `per_turn` lifetimes / resolver
        // decisions / latched events span the WHOLE user prompt
        // rather than a single intermediate round-trip.
        let session = self.shared_session();
        let prompt_changed = match self.last_prompt.lock() {
            Ok(mut g) => {
                let changed = match &*g {
                    None => true,                 // cold start
                    Some(prev) => prev != prompt, // boundary
                };
                if changed {
                    *g = Some(prompt.clone());
                }
                changed
            }
            // Lock poisoned: fail open by cycling the turn — losing
            // some per-turn state is preferable to leaking forever.
            Err(_) => true,
        };
        if prompt_changed {
            self.open_turn(&session);
        }
        async { HookAction::cont() }
    }

    // `impl Future` keeps the return type aligned with rig 0.35's
    // `PromptHook` trait (which uses `impl Future + Send`); using
    // `async fn` here would require `async fn` in trait impls plus
    // an explicit `Send` bound shim. Body is intentionally a single
    // `async {}` block — clippy's `manual_async_fn` is a false
    // positive for this trait-impl shape.
    #[allow(clippy::manual_async_fn)]
    fn on_completion_response(
        &self,
        _prompt: &Message,
        _response: &rig::completion::CompletionResponse<M::Response>,
    ) -> impl std::future::Future<Output = HookAction> + Send {
        // Tool callbacks (`on_tool_call` / `on_tool_result`) fire
        // AFTER `on_completion_response` returns, so we cannot close
        // the turn here — Stage 3 + Stage 4 still need to land
        // inside it. The turn is cycled by the next
        // `on_completion_call` when the customer issues a NEW user
        // prompt, or by `ShieldHook::end_turn` if the customer calls
        // it explicitly.
        async { HookAction::cont() }
    }

    fn on_tool_call(
        &self,
        tool_name: &str,
        _tool_call_id: Option<String>,
        internal_call_id: &str,
        args: &str,
    ) -> impl std::future::Future<Output = ToolCallHookAction> + Send {
        let name = tool_name.to_string();
        let args_str = args.to_string();
        // `internal_call_id` is the stable per-invocation handle rig
        // threads through to both `on_tool_call` and `on_tool_result`.
        // We use it as the §16.0 binding id so Stage 4 can find the
        // SAME canonical invocation Stage 3 admitted, even when the
        // upstream model omits `tool_call_id`. (We still accept the
        // model-supplied id for logging compatibility; rig itself
        // already correlates results to calls via internal_call_id.)
        let binding_id = internal_call_id.to_string();
        let session = self.shared_session();
        let tool_turns = self.tool_turns.clone();
        async move {
            let mut value: Value = match serde_json::from_str(&args_str) {
                Ok(v) => v,
                Err(e) => {
                    log::warn!(target: "agent_shield::rig", "malformed tool arguments (invalid JSON): {e}");
                    return ToolCallHookAction::Skip {
                        reason: format_tool_block(&name, "malformed tool arguments (invalid JSON)"),
                    };
                }
            };
            // P11.4: snapshot the pre-validation args so we can detect
            // Stage 3 transforms. Rig's `ToolCallHookAction` enum has
            // no `Replace { args }` variant (rig-core 0.35), so we
            // cannot propagate mutated args to the underlying tool
            // through the hook surface.
            let original = value.clone();
            let admission = session.validate_tool_admission(&name, &mut value, &binding_id);
            let verdict = admission.verdict().clone();
            if !verdict.allowed {
                return ToolCallHookAction::Skip {
                    reason: format_tool_block(
                        &name,
                        verdict.reason.as_deref().unwrap_or("blocked"),
                    ),
                };
            }
            if value != original {
                // Stage 3 transform mutated the args. Rig cannot carry
                // those mutations forward, so fail closed: skipping is
                // the safe action — letting the original args reach
                // the tool would silently bypass the redact/replace
                // policy. Hosts that need Stage-3 transforms must use
                // the session-level `protect_tool` helper directly.
                //
                // Because we return `Skip`, rig will NOT fire
                // `on_tool_result` for this invocation. Dropping the
                // admission removes the pending Stage-4 binding.
                admission.abandon();
                if let Err(e) = session
                    .record_tool_failure(&name, "stage-3 transforms not supported in rig hook path")
                {
                    log::warn!(target: "agent_shield::rig", "record_tool_failure failed: {e:?}");
                }
                return ToolCallHookAction::Skip {
                    reason: format_tool_block(
                        &name,
                        "stage-3 transforms (redact/replace) are not supported in the rig hook path; use the session-level `protect_tool` helper",
                    ),
                };
            }
            if let Ok(mut g) = tool_turns.lock() {
                g.insert(
                    Self::tool_turn_key(&name, &binding_id),
                    session.current_turn_id(),
                );
            }
            admission.commit_to_stage4();
            ToolCallHookAction::cont()
        }
    }

    fn on_tool_result(
        &self,
        tool_name: &str,
        _tool_call_id: Option<String>,
        internal_call_id: &str,
        _args: &str,
        result_text: &str,
    ) -> impl std::future::Future<Output = HookAction> + Send {
        let name = tool_name.to_string();
        let output = result_text.to_string();
        // Same `internal_call_id` rig used on `on_tool_call`; binds
        // Stage 4 to the Stage 3 invocation per §16.0.
        let binding_id = internal_call_id.to_string();
        let session = self.shared_session();
        let tool_turns = self.tool_turns.clone();
        async move {
            let mut value = Value::String(output.clone());
            let turn_id = match tool_turns.lock() {
                Ok(mut g) => g
                    .remove(&Self::tool_turn_key(&name, &binding_id))
                    .unwrap_or_else(|| session.current_turn_id()),
                Err(_) => session.current_turn_id(),
            };
            let post =
                session.validate_tool_output_for_turn(&name, &mut value, &binding_id, turn_id);
            if !post.allowed {
                if let Err(e) = session.record_tool_failure(&name, "post-tool-blocked") {
                    log::warn!(target: "agent_shield::rig", "record_tool_failure failed: {e:?}");
                }
                return HookAction::Terminate {
                    reason: format_tool_output_block(
                        &name,
                        post.reason.as_deref().unwrap_or("blocked"),
                    ),
                };
            }

            // Detect redaction by comparing the validated output to
            // the original (Rig has no native span/redaction hook).
            // When the engine rewrites, terminate to avoid leaking the
            // unredacted original.
            let after = value
                .as_str()
                .map(|s| s.to_string())
                .unwrap_or(output.clone());
            if after != output {
                if let Err(e) = session.record_tool_success(&name, &value) {
                    log::warn!(target: "agent_shield::rig", "record_tool_success failed: {e:?}");
                }
                return HookAction::Terminate {
                    reason: format_tool_output_block(&name, "tool output redacted by policy"),
                };
            }

            if let Err(e) = session.record_tool_success(&name, &value) {
                log::warn!(target: "agent_shield::rig", "record_tool_success failed: {e:?}");
            }
            HookAction::cont()
        }
    }
}

// ── Standalone helpers ──────────────────────────────────────────────

/// Stage 1 — guard a user input string.
pub fn guard_input(session: &GuardrailsSession, text: &str) -> Result<(), StageVerdict> {
    let v = session.validate_input(text);
    if v.allowed {
        Ok(())
    } else {
        Err(v)
    }
}

/// Stage 5 — guard a final assistant string. Mutates in place.
pub fn guard_output(session: &GuardrailsSession, text: &mut String) -> StageVerdict {
    session.validate_output(text)
}

/// Stage 2+3 against a long-lived session.
///
/// `tool_call_id` is REQUIRED per spec §16.0; the matching Stage 4
/// [`protect_tool_output`] call MUST pass the same id. Pass the
/// adapter-supplied id when the framework provides one; synthesize a
/// UUIDv4 unique within the turn otherwise.
pub fn protect_tool(
    session: &GuardrailsSession,
    tool_name: &str,
    params: &mut Value,
    tool_call_id: &str,
) -> StageVerdict {
    session.validate_tool_call(tool_name, params, tool_call_id)
}

/// Deprecated alias for [`protect_tool`].
#[deprecated(note = "Use protect_tool instead")]
pub fn session_protect_tool(
    session: &GuardrailsSession,
    tool_name: &str,
    params: &mut Value,
    tool_call_id: &str,
) -> StageVerdict {
    protect_tool(session, tool_name, params, tool_call_id)
}

/// Stage 4 against a long-lived session. `tool_call_id` MUST match
/// the id passed to the paired [`protect_tool`] call (§16.0).
pub fn protect_tool_output(
    session: &GuardrailsSession,
    tool_name: &str,
    result: &mut Value,
    tool_call_id: &str,
) -> StageVerdict {
    session.validate_tool_output(tool_name, result, tool_call_id)
}

/// Deprecated alias for [`protect_tool_output`].
#[deprecated(note = "Use protect_tool_output instead")]
pub fn session_protect_tool_output(
    session: &GuardrailsSession,
    tool_name: &str,
    result: &mut Value,
    tool_call_id: &str,
) -> StageVerdict {
    protect_tool_output(session, tool_name, result, tool_call_id)
}

/// Record a successful tool execution (§10.3 / §21).
pub fn record_tool_success(
    session: &GuardrailsSession,
    tool_name: &str,
    result: &Value,
) -> Result<(), RuntimeError> {
    session.record_tool_success(tool_name, result)
}

/// Record a failed tool execution.
pub fn record_tool_failure(
    session: &GuardrailsSession,
    tool_name: &str,
    error: &str,
) -> Result<(), RuntimeError> {
    session.record_tool_failure(tool_name, error)
}

// ── TurnGuard ───────────────────────────────────────────────────────

/// Per-turn guard — borrows a long-lived session and drives
/// `begin_turn` / `end_turn`.
pub struct TurnGuard<'a> {
    session: &'a GuardrailsSession,
    ended: std::cell::Cell<bool>,
}

impl<'a> TurnGuard<'a> {
    /// Begin a new turn against `session`, run Stage 1 against
    /// `user_input`, and return the guard. Returns `Err(verdict)` if
    /// Stage 1 blocks.
    pub fn begin(session: &'a GuardrailsSession, user_input: &str) -> Result<Self, StageVerdict> {
        if let Err(e) = session.begin_turn() {
            log::warn!(target: "agent_shield::rig", "begin_turn failed: {e:?}");
        }
        let v = session.validate_input(user_input);
        if !v.allowed {
            if let Err(e) = session.end_turn() {
                log::warn!(target: "agent_shield::rig", "end_turn failed: {e:?}");
            }
            return Err(v);
        }
        Ok(Self {
            session,
            ended: std::cell::Cell::new(false),
        })
    }

    /// Borrow the underlying session.
    pub fn session(&self) -> &GuardrailsSession {
        self.session
    }

    /// Stage 2+3 against the held session. `tool_call_id` is REQUIRED
    /// per spec §16.0; pair the same id with the matching
    /// [`Self::validate_tool_output`].
    pub fn validate_tool_call(
        &self,
        name: &str,
        params: &mut Value,
        tool_call_id: &str,
    ) -> StageVerdict {
        self.session.validate_tool_call(name, params, tool_call_id)
    }

    /// Stage 4 against the held session. `tool_call_id` MUST match
    /// the id passed to the paired
    /// [`Self::validate_tool_call`] (§16.0).
    pub fn validate_tool_output(
        &self,
        name: &str,
        result: &mut Value,
        tool_call_id: &str,
    ) -> StageVerdict {
        self.session
            .validate_tool_output(name, result, tool_call_id)
    }

    /// Stage 5 against the held session.
    pub fn validate_output(&self, response: &mut String) -> StageVerdict {
        self.session.validate_output(response)
    }

    /// Explicitly end the turn. Idempotent — calling `end()` multiple
    /// times (or `end()` followed by `Drop`) only fires `turn.end`
    /// once.
    pub fn end(&self) {
        if !self.ended.replace(true) {
            if let Err(e) = self.session.end_turn() {
                log::warn!(target: "agent_shield::rig", "end_turn failed: {e:?}");
            }
        }
    }
}

impl Drop for TurnGuard<'_> {
    fn drop(&mut self) {
        if !self.ended.replace(true) {
            if let Err(e) = self.session.end_turn() {
                log::warn!(target: "agent_shield::rig", "end_turn (Drop) failed: {e:?}");
            }
        }
    }
}

// ── Internal helpers ────────────────────────────────────────────────

fn format_tool_block(tool_name: &str, reason: &str) -> String {
    format!("[Agent Shield] Tool '{}' blocked: {}", tool_name, reason)
}

fn format_tool_output_block(tool_name: &str, reason: &str) -> String {
    format!(
        "[Agent Shield] Tool '{}' output blocked: {}",
        tool_name, reason
    )
}
