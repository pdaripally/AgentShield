//! Smoke tests for the MCP adapter.

use std::path::PathBuf;
use std::sync::Arc;

use agent_shield_core::{GuardrailsRuntime, GuardrailsSession, RequestContext, RuntimeBuilder};
use agent_shield_mcp as guard;
use serde_json::json;

fn fixture_path() -> PathBuf {
    let manifest = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    manifest
        .join("../../..")
        .join("tests/fixtures/smoke/minimal.guardrails.yaml")
}

fn build_runtime() -> Arc<GuardrailsRuntime> {
    RuntimeBuilder::from_yaml(fixture_path())
        .unwrap()
        .build()
        .unwrap()
}

fn open_session(rt: &Arc<GuardrailsRuntime>) -> GuardrailsSession {
    rt.new_session(RequestContext::new("sess-1", "corr-1"))
}

#[test]
fn protect_tool_blocks_when_unauthorized() {
    let rt = build_runtime();
    let (v, _) = guard::protect_tool(&rt, "echo", &json!({"msg": "hi"}), "call-1");
    assert!(!v.allowed);
}

#[test]
fn protect_tool_output_without_binding_fails_closed() {
    let rt = build_runtime();
    let mut output = json!({"result": "ok"});
    let v = guard::protect_tool_output(&rt, "echo", &mut output, "call-1");
    assert!(!v.allowed);
    assert_eq!(v.policy.as_deref(), Some("<binding>"));
}

#[test]
fn session_validate_tool_output_runs_stage_4() {
    let rt = build_runtime();
    let s = open_session(&rt);
    s.set_variable("authorized", json!(true)).unwrap();
    let mut params = json!({"msg": "hi"});
    let call = guard::session_validate_tool_call(&s, "echo", &mut params, "call-1");
    assert!(call.allowed);

    let mut output = json!({"result": "ok"});
    let v = guard::session_validate_tool_output(&s, "echo", &mut output, "call-1");
    assert!(v.allowed);
}

#[test]
fn guard_input_passes_clean_text() {
    let rt = build_runtime();
    guard::guard_input(&rt, "hello").expect("clean input passes");
}

#[test]
fn session_validate_tool_call_uses_long_lived_session() {
    let rt = build_runtime();
    let s = open_session(&rt);
    s.set_variable("authorized", json!(true)).unwrap();
    let mut p = json!({"msg": "hi"});
    let v = guard::session_validate_tool_call(&s, "echo", &mut p, "call-1");
    assert!(v.allowed);
}

#[test]
fn record_tool_failure_emits_event() {
    use agent_shield_core::{EventId, ToolEventKind};
    let rt = build_runtime();
    let s = open_session(&rt);
    guard::record_tool_failure(&s, "echo", "boom").unwrap();
    let id = EventId::Tool {
        name: "echo".into(),
        kind: ToolEventKind::Failure,
    };
    assert!(rt.bus().fired_id(&id));
}

#[tokio::test(flavor = "multi_thread", worker_threads = 1)]
async fn turn_guard_drives_validate_tool_call() {
    let rt = build_runtime();
    let s = open_session(&rt);
    s.set_variable("authorized", json!(true)).unwrap();
    let turn = guard::TurnGuard::begin(&s, "hello").expect("input passes");
    let mut p = json!({"msg": "hi"});
    let v = turn.validate_tool_call("echo", &mut p, "call-1");
    assert!(v.allowed);
    turn.end();
}
