//! Agent Shield adapter for MCP (Model Context Protocol).
//!
//! Provides guardrail validation for MCP server tools.
//!
//! ## `agent_shield.ask_human` integration
//!
//! When a `kind: human` resolver suspends, the runtime synthesises an
//! MCP tool call with name [`ASK_HUMAN_TOOL`]. Hosts that integrate
//! Agent Shield over MCP MUST register a tool under exactly that
//! name; the reference implementation lives at
//! `examples/tools/ask-human-mcp-server/`. Use [`is_ask_human`] inside an
//! MCP server's tool dispatcher to route human-approval calls to the
//! host's UI instead of the standard tool catalog.

#![allow(clippy::result_large_err)]

use std::sync::Arc;

use agent_shield_core::{
    GuardrailsRuntime, GuardrailsSession, RequestContext, RuntimeError, StageVerdict,
};
use serde_json::Value;

// ── ask_human MCP integration ───────────────────────────────────────

/// The canonical name of the MCP tool the runtime expects to be
/// available when a `kind: human` resolver suspends.
///
/// Hosts that integrate Agent Shield over MCP MUST register a tool
/// named exactly this. The reference implementation is at
/// `examples/tools/ask-human-mcp-server/`.
///
/// Re-exported from [`agent_shield_core::ASK_HUMAN_TOOL_NAME`] — the
/// two are guaranteed to be byte-identical.
pub const ASK_HUMAN_TOOL: &str = agent_shield_core::ASK_HUMAN_TOOL_NAME;

/// Returns `true` if `tool_name` is the canonical [`ASK_HUMAN_TOOL`].
///
/// MCP server authors use this to dispatch incoming tool calls — when
/// it returns `true`, route the call to the host's human-approval UI;
/// otherwise route to the standard tool catalog.
pub fn is_ask_human(tool_name: &str) -> bool {
    tool_name == ASK_HUMAN_TOOL
}

// `Arc<GuardrailsRuntime>` is required by the standalone helpers
// because `GuardrailsRuntime::new_session` is defined on `&Arc<Self>`
// — sessions clone the Arc to keep a runtime handle alive. The
// helpers cannot take `&GuardrailsRuntime` directly.

// ── Standalone helpers (per-call sessions) ──────────────────────────

/// Stage 2+3 — guard an MCP tool call. Opens a fresh session on the
/// supplied runtime (one session per tool call for isolation).
///
/// Returns a tuple of (verdict, parsed_params). On block, the host
/// returns the verdict's `reason` to the caller. `tool_call_id` is
/// required per spec §16.0 — pass the MCP JSON-RPC request id (or a
/// synthetic UUID if the host does not expose it). Stage 4 MUST be
/// invoked with the same id.
pub fn protect_tool(
    runtime: &Arc<GuardrailsRuntime>,
    tool_name: &str,
    arguments: &Value,
    tool_call_id: &str,
) -> (StageVerdict, Value) {
    let mut value = match arguments {
        Value::Object(_) => arguments.clone(),
        other => {
            let mut m = serde_json::Map::new();
            m.insert("input".into(), other.clone());
            Value::Object(m)
        }
    };
    let session = runtime.new_session(RequestContext::default());
    let v = session.validate_tool_call(tool_name, &mut value, tool_call_id);
    (v, value)
}

/// Stage 4 — guard an MCP tool result. Opens a fresh session.
///
/// Because §16.0 bindings are session-scoped, hosts that need a paired
/// Stage 3 + 4 flow MUST use [`session_validate_tool_call`] and
/// [`session_validate_tool_output`] on the same long-lived session.
/// This standalone helper therefore fails closed with `<binding>` when
/// used without a pre-existing Stage 3 admit on that session.
pub fn protect_tool_output(
    runtime: &Arc<GuardrailsRuntime>,
    tool_name: &str,
    output: &mut Value,
    tool_call_id: &str,
) -> StageVerdict {
    let session = runtime.new_session(RequestContext::default());
    let v = session.validate_tool_output(tool_name, output, tool_call_id);
    if v.allowed {
        if let Err(e) = session.record_tool_success(tool_name, output) {
            log::warn!(target: "agent_shield::mcp", "record_tool_success failed: {e:?}");
        }
    } else if let Err(e) = session.record_tool_failure(
        tool_name,
        v.reason.as_deref().unwrap_or("post-tool-blocked"),
    ) {
        log::warn!(target: "agent_shield::mcp", "record_tool_failure failed: {e:?}");
    }
    v
}

/// Stage 1 — guard an MCP user prompt with a fresh session.
pub fn guard_input(runtime: &Arc<GuardrailsRuntime>, text: &str) -> Result<(), StageVerdict> {
    let session = runtime.new_session(RequestContext::default());
    let v = session.validate_input(text);
    if v.allowed {
        Ok(())
    } else {
        Err(v)
    }
}

/// Stage 5 — guard an MCP-emitted assistant string with a fresh
/// session. Mutates `text` in place.
pub fn guard_output(runtime: &Arc<GuardrailsRuntime>, text: &mut String) -> StageVerdict {
    let session = runtime.new_session(RequestContext::default());
    session.validate_output(text)
}

// ── Session-borrowing helpers ───────────────────────────────────────

/// Stage 2+3 against a long-lived session. `tool_call_id` is
/// required per §16.0 — pair it with the matching Stage 4 call.
pub fn session_validate_tool_call(
    session: &GuardrailsSession,
    tool_name: &str,
    params: &mut Value,
    tool_call_id: &str,
) -> StageVerdict {
    session.validate_tool_call(tool_name, params, tool_call_id)
}

/// Stage 4 against a long-lived session. Does NOT auto-record success
/// or failure — the caller controls the lifecycle. `tool_call_id`
/// MUST match the id passed to the paired Stage 3 call.
pub fn session_validate_tool_output(
    session: &GuardrailsSession,
    tool_name: &str,
    output: &mut Value,
    tool_call_id: &str,
) -> StageVerdict {
    session.validate_tool_output(tool_name, output, tool_call_id)
}

/// Record a successful tool execution (§10.3 / §21).
pub fn record_tool_success(
    session: &GuardrailsSession,
    tool_name: &str,
    result: &Value,
) -> Result<(), RuntimeError> {
    session.record_tool_success(tool_name, result)
}

/// Record a failed tool execution.
pub fn record_tool_failure(
    session: &GuardrailsSession,
    tool_name: &str,
    error: &str,
) -> Result<(), RuntimeError> {
    session.record_tool_failure(tool_name, error)
}

// ── TurnGuard ───────────────────────────────────────────────────────

/// Per-turn guard — borrows a long-lived session and drives
/// `begin_turn` / `end_turn`.
pub struct TurnGuard<'a> {
    session: &'a GuardrailsSession,
    ended: std::cell::Cell<bool>,
}

impl<'a> TurnGuard<'a> {
    /// Begin a new turn against `session`, run Stage 1 against
    /// `user_input`, and return the guard. Returns `Err(verdict)` if
    /// Stage 1 blocks.
    pub fn begin(session: &'a GuardrailsSession, user_input: &str) -> Result<Self, StageVerdict> {
        if let Err(e) = session.begin_turn() {
            log::warn!(target: "agent_shield::mcp", "begin_turn failed: {e:?}");
        }
        let v = session.validate_input(user_input);
        if !v.allowed {
            if let Err(e) = session.end_turn() {
                log::warn!(target: "agent_shield::mcp", "end_turn failed: {e:?}");
            }
            return Err(v);
        }
        Ok(Self {
            session,
            ended: std::cell::Cell::new(false),
        })
    }

    /// Borrow the underlying session.
    pub fn session(&self) -> &GuardrailsSession {
        self.session
    }

    /// Stage 2+3 against the held session. `tool_call_id` is
    /// required per §16.0.
    pub fn validate_tool_call(
        &self,
        name: &str,
        params: &mut Value,
        tool_call_id: &str,
    ) -> StageVerdict {
        self.session.validate_tool_call(name, params, tool_call_id)
    }

    /// Stage 4 against the held session. `tool_call_id` MUST match
    /// the id passed to the paired Stage 3 call.
    pub fn validate_tool_output(
        &self,
        name: &str,
        result: &mut Value,
        tool_call_id: &str,
    ) -> StageVerdict {
        self.session
            .validate_tool_output(name, result, tool_call_id)
    }

    /// Stage 5 against the held session.
    pub fn validate_output(&self, response: &mut String) -> StageVerdict {
        self.session.validate_output(response)
    }

    /// Explicitly end the turn. Idempotent — calling `end()` multiple
    /// times (or `end()` followed by `Drop`) only fires `turn.end`
    /// once.
    pub fn end(&self) {
        if !self.ended.replace(true) {
            if let Err(e) = self.session.end_turn() {
                log::warn!(target: "agent_shield::mcp", "end_turn failed: {e:?}");
            }
        }
    }
}

impl Drop for TurnGuard<'_> {
    fn drop(&mut self) {
        if !self.ended.replace(true) {
            if let Err(e) = self.session.end_turn() {
                log::warn!(target: "agent_shield::mcp", "end_turn (Drop) failed: {e:?}");
            }
        }
    }
}
