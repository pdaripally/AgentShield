//! Smoke tests for the OpenAI adapter.

use std::path::PathBuf;
use std::sync::Arc;

use agent_shield_core::{GuardrailsRuntime, GuardrailsSession, RequestContext, RuntimeBuilder};
use agent_shield_openai as guard;
use async_openai::types::chat::{
    ChatCompletionRequestMessage, ChatCompletionRequestUserMessage,
    ChatCompletionRequestUserMessageContent,
};
use serde_json::json;

fn fixture_path() -> PathBuf {
    let manifest = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    manifest
        .join("../../..")
        .join("tests/fixtures/smoke/minimal.guardrails.yaml")
}

fn build_runtime() -> Arc<GuardrailsRuntime> {
    RuntimeBuilder::from_yaml(fixture_path())
        .unwrap()
        .build()
        .unwrap()
}

fn open_session(rt: &Arc<GuardrailsRuntime>) -> GuardrailsSession {
    rt.new_session(RequestContext::new("sess-1", "corr-1"))
}

#[test]
fn protect_tool_blocks_when_unauthorized() {
    let rt = build_runtime();
    let s = open_session(&rt);
    let mut p = json!({"msg": "hi"});
    let v = guard::protect_tool(&s, "echo", &mut p, "call_1");
    assert!(!v.allowed);
}

#[test]
fn protect_tool_json_fails_closed_on_invalid_json() {
    let rt = build_runtime();
    let s = open_session(&rt);
    let (v, _value) = guard::protect_tool_json(&s, "echo", "{invalid json", "call_1");
    assert!(!v.allowed);
    assert!(v
        .reason
        .as_deref()
        .map(|r| r.contains("malformed"))
        .unwrap_or(false));
}

#[test]
fn protect_tool_allows_when_authorized() {
    let rt = build_runtime();
    let s = open_session(&rt);
    s.set_variable("authorized", json!(true)).unwrap();
    let mut p = json!({"msg": "hi"});
    let v = guard::protect_tool(&s, "echo", &mut p, "call_1");
    assert!(v.allowed);
}

#[test]
fn record_tool_success_emits_event() {
    use agent_shield_core::{EventId, ToolEventKind};
    let rt = build_runtime();
    let s = open_session(&rt);
    guard::record_tool_success(&s, "echo", &json!("ok")).unwrap();
    let id = EventId::Tool {
        name: "echo".into(),
        kind: ToolEventKind::Success,
    };
    assert!(rt.bus().fired_id(&id));
}

#[test]
fn guard_conversation_passes_clean_user_text() {
    let rt = build_runtime();
    let s = open_session(&rt);
    let messages = vec![ChatCompletionRequestMessage::User(
        ChatCompletionRequestUserMessage {
            content: ChatCompletionRequestUserMessageContent::Text("hello".into()),
            name: None,
        },
    )];
    guard::guard_conversation(&s, &messages).expect("clean input passes");
}

#[test]
fn guard_response_passes_clean_text() {
    let rt = build_runtime();
    let s = open_session(&rt);
    let mut text = "hello".to_string();
    let v = guard::guard_response(&s, &mut text);
    assert!(v.allowed);
    assert_eq!(text, "hello");
}

#[tokio::test(flavor = "multi_thread", worker_threads = 1)]
async fn turn_guard_drives_validate_tool_call() {
    let rt = build_runtime();
    let s = open_session(&rt);
    s.set_variable("authorized", json!(true)).unwrap();
    let messages = vec![ChatCompletionRequestMessage::User(
        ChatCompletionRequestUserMessage {
            content: ChatCompletionRequestUserMessageContent::Text("hello".into()),
            name: None,
        },
    )];
    let turn = guard::TurnGuard::begin(&s, &messages).expect("input passes");
    let mut p = json!({"msg": "hi"});
    let v = turn.validate_tool_call("echo", &mut p, "call_1");
    assert!(v.allowed);
    turn.end();
}

// ── P11.3 / P11.5 amendments ────────────────────────────────────────

use agent_shield_core::{load_from_str, ObservabilityProvider, ShieldLogEvent};
use std::sync::{Arc as StdArc, Mutex};

#[derive(Clone, Default)]
struct CapturingProvider {
    events: StdArc<Mutex<Vec<ShieldLogEvent>>>,
}

impl ObservabilityProvider for CapturingProvider {
    fn emit(&self, event: ShieldLogEvent) {
        self.events.lock().unwrap().push(event);
    }
}

const REDACT_YAML: &str = r#"
metadata:
  name: "p11-3-redact"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["redact ssn from tool args"]
  forbidden: ["leak"]
resources:
  tools:
    - name: "send"
      description: "send"
      permission: "read_write"
tool_execution_validation:
  guard_policies:
    - name: "scrub_ssn"
      applies_to:
        tools: ["send"]
      evaluate_when:
        - pattern: "\\d{3}-\\d{2}-\\d{4}"
          reason: "SSN detected"
      action: "redact"
      replacement: "[REDACTED]"
"#;

#[tokio::test(flavor = "multi_thread", worker_threads = 1)]
async fn protect_tool_executor_passes_transformed_args_to_exec() {
    // P11.3: Stage-3 redact in `tool_execution_validation` mutates
    // `value` in place. The wrapped executor MUST receive the
    // transformed JSON, not the original.
    let cfg = load_from_str(REDACT_YAML).expect("valid yaml");
    let rt = RuntimeBuilder::from_config(cfg).build().expect("build");
    let s = Arc::new(open_session(&rt));

    let seen: StdArc<Mutex<Option<String>>> = StdArc::new(Mutex::new(None));
    let seen_clone = seen.clone();
    let exec = guard::protect_tool_executor(s.clone(), move |_name, args| {
        let seen_clone = seen_clone.clone();
        Box::pin(async move {
            *seen_clone.lock().unwrap() = Some(args.clone());
            Ok::<String, String>("ok".to_string())
        })
    });

    let _ = exec(
        "send".to_string(),
        r#"{"text":"my ssn is 123-45-6789"}"#.to_string(),
        "call_1".to_string(),
    )
    .await;

    let received = seen.lock().unwrap().clone().expect("exec must have run");
    assert!(
        !received.contains("123-45-6789"),
        "exec received raw SSN: {received}"
    );
    assert!(
        received.contains("[REDACTED]"),
        "exec did not receive redacted args: {received}"
    );
}

#[tokio::test(flavor = "multi_thread", worker_threads = 1)]
async fn protect_tool_executor_records_failure_on_invalid_json() {
    // P11.5: when `serde_json::from_str` fails on the executor input,
    // we must record `tool.<name>.failure` before returning the block
    // message — symmetry with the post-tool-blocked path.
    let provider = CapturingProvider::default();
    let events = provider.events.clone();
    let rt = RuntimeBuilder::from_yaml(fixture_path())
        .unwrap()
        .register_provider(Arc::new(provider))
        .build()
        .unwrap();
    let s = Arc::new(open_session(&rt));

    let exec = guard::protect_tool_executor(s.clone(), |_n, _a| {
        Box::pin(async { Ok::<String, String>("never".to_string()) })
    });

    let out = exec(
        "echo".to_string(),
        "{not json".to_string(),
        "call_1".to_string(),
    )
    .await
    .expect("returns Ok with block message");
    assert!(
        out.contains("malformed") || out.contains("invalid JSON"),
        "expected block message about malformed JSON, got: {out}"
    );

    let captured = events.lock().unwrap();
    assert!(
        captured
            .iter()
            .any(|e| e.event_id.as_deref() == Some("tool.echo.failure")),
        "expected tool.echo.failure event, saw: {:?}",
        captured
            .iter()
            .map(|e| e.event_id.clone())
            .collect::<Vec<_>>()
    );
}
