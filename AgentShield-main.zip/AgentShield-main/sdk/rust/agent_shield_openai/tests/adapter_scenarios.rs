//! Cross-language adapter-scenario harness — OpenAI.
//!
//! See `sdk/rust/adapter_scenarios_common.rs` for the shared body.
//! Mirrors `tests/e2e/run_openai_agents.py` and
//! `tests/e2e/node/run-openai.test.mjs` so all four languages
//! assert byte-equivalent behaviour over the same shared fixture.

use agent_shield_openai::ShieldOpenAIExt;

#[path = "../../adapter_scenarios_common.rs"]
mod common;

#[tokio::test(flavor = "current_thread")]
async fn shared_adapter_scenarios() {
    common::run_with("openai", |b| b.with_openai()).await;
}
