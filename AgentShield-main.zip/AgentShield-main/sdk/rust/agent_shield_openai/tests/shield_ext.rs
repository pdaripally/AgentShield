//! Smoke tests for the OpenAI `Shield` extension trait.

use std::path::PathBuf;

use agent_shield::{CoverageLevel, Shield};
use agent_shield_openai::{ShieldOpenAIExt, CAPABILITY_REPORT};

fn fixture() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("../../..")
        .join("tests/fixtures/smoke/minimal.guardrails.yaml")
}

#[test]
fn capability_report_has_partial_streaming() {
    assert_eq!(
        CAPABILITY_REPORT.tool_execution_validation,
        Some(CoverageLevel::Full)
    );
    assert_eq!(
        CAPABILITY_REPORT.streaming_output,
        Some(CoverageLevel::Partial)
    );
}

#[test]
fn with_openai_installs_capability() {
    let shield = Shield::from_yaml(fixture())
        .with_openai()
        .build()
        .expect("build");
    assert_eq!(shield.capabilities().framework, "openai");
}
