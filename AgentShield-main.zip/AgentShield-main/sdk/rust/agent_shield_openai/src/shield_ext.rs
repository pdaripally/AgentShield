//! `Shield`-builder extension trait for the OpenAI Rust adapter.
//!
//! Exports a [`CAPABILITY_REPORT`] constant and a [`ShieldOpenAIExt`]
//! trait that adds [`with_openai`](ShieldOpenAIExt::with_openai) to
//! [`agent_shield::ShieldBuilder`].
//!
//! # Example (≤ 5 lines)
//!
//! ```no_run
//! # fn ex() -> Result<(), Box<dyn std::error::Error>> {
//! use agent_shield::Shield;
//! use agent_shield_openai::ShieldOpenAIExt;
//! let shield = Shield::from_yaml(".guardrails.yaml").with_openai().build()?;
//! # let _ = shield; Ok(()) }
//! ```

use agent_shield::{CapabilityReport, CoverageLevel, ShieldBuilder};

/// Honest capability report for the OpenAI adapter.
///
/// Stage 2/3/4 work end-to-end via [`crate::protect_tool_executor`],
/// which re-serializes Stage-3-mutated args before dispatching to the
/// inner executor. Streaming output is `Partial`: the adapter
/// validates the accumulated output after `stream_complete` finalizes,
/// but mid-stream chunk-level redaction across `ChatCompletionChunk`
/// boundaries is not reliable without a host-side `StreamingGuard`.
pub const CAPABILITY_REPORT: CapabilityReport = CapabilityReport {
    framework: String::new(),
    input_validation: Some(CoverageLevel::Full),
    state_validation: Some(CoverageLevel::Full),
    tool_authorization: Some(CoverageLevel::Full),
    tool_execution_validation: Some(CoverageLevel::Full),
    tool_output_validation: Some(CoverageLevel::Full),
    output_validation: Some(CoverageLevel::Full),
    streaming_output: Some(CoverageLevel::Partial),
    notes: Vec::new(),
};

fn report() -> CapabilityReport {
    CapabilityReport {
        framework: "openai".to_string(),
        notes: vec![
            "streaming_output is partial: stream_complete validates the \
             accumulated text post-stream; chunk-level redaction across \
             ChatCompletionChunk boundaries requires a host StreamingGuard"
                .to_string(),
        ],
        ..CAPABILITY_REPORT
    }
}

/// Extension trait adding `with_openai` to [`ShieldBuilder`].
pub trait ShieldOpenAIExt {
    /// Install the OpenAI capability report.
    fn with_openai(self) -> Self;
}

impl ShieldOpenAIExt for ShieldBuilder {
    fn with_openai(self) -> Self {
        self.with_capability(report())
    }
}
