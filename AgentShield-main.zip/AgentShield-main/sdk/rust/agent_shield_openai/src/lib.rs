//! Agent Shield adapter for [async-openai](https://crates.io/crates/async-openai).
//!
//! Provides guardrail validation for OpenAI Chat Completions API integrations.
//!
//! # Quick start
//!
//! ```no_run
//! use agent_shield_openai as guard;
//! use agent_shield_core::{GuardrailsRuntime, RequestContext};
//! use serde_json::json;
//!
//! # fn try_main() -> Result<(), Box<dyn std::error::Error>> {
//! let runtime = agent_shield_core::RuntimeBuilder::from_yaml("guardrails.yaml")?.build()?;
//! let session = runtime.new_session(RequestContext::new("sess-1", "corr-1"));
//!
//! let mut params = json!({"query": "search"});
//! let tool_call_id = "call_abc123";
//! let verdict = guard::protect_tool(&session, "search_tool", &mut params, tool_call_id);
//! if verdict.allowed {
//!     // ... call the real tool ...
//!     let result = json!({"status": "ok"});
//!     guard::record_tool_success(&session, "search_tool", &result).ok();
//! }
//! # Ok(())
//! # }
//! ```

#![allow(clippy::result_large_err)]

pub mod shield_ext;

pub use shield_ext::{ShieldOpenAIExt, CAPABILITY_REPORT};

use std::sync::Arc;

use agent_shield_core::{GuardrailsSession, ObsStage, RuntimeError, StageVerdict};
use async_openai::types::chat::{
    ChatCompletionRequestMessage, ChatCompletionRequestMessageContentPartText,
    ChatCompletionRequestUserMessageContent, ChatCompletionRequestUserMessageContentPart,
};
use serde_json::Value;

// ── Internal helpers ────────────────────────────────────────────────

fn format_tool_block(tool_name: &str, reason: &str) -> String {
    format!("[Agent Shield] Tool '{}' blocked: {}", tool_name, reason)
}

fn format_tool_output_block(tool_name: &str, reason: &str) -> String {
    format!(
        "[Agent Shield] Tool '{}' output blocked: {}",
        tool_name, reason
    )
}

fn format_tool_error(tool_name: &str, error: &str) -> String {
    format!("[Agent Shield] Tool '{}' error: {}", tool_name, error)
}

fn format_response_block(reason: &str) -> String {
    format!("[Agent Shield] Response blocked: {}", reason)
}

// ── Stage 2+3+4 helpers ─────────────────────────────────────────────

/// Stage 2+3 — guard a tool call. Mutates `params` in place when a
/// Stage 3 transform applies. `tool_call_id` is required per spec
/// §16.0 — forward the OpenAI `tool_call.id` from the model
/// response. Stage 4 MUST be invoked with the same id.
pub fn protect_tool(
    session: &GuardrailsSession,
    tool_name: &str,
    params: &mut Value,
    tool_call_id: &str,
) -> StageVerdict {
    session.validate_tool_call(tool_name, params, tool_call_id)
}

/// Convenience: parse a JSON string of tool arguments and call
/// [`protect_tool`]. Fails closed with a `Block` verdict when the
/// arguments aren't valid JSON. `tool_call_id` is required per
/// §16.0.
pub fn protect_tool_json(
    session: &GuardrailsSession,
    tool_name: &str,
    arguments_json: &str,
    tool_call_id: &str,
) -> (StageVerdict, Value) {
    let mut value: Value = match serde_json::from_str(arguments_json) {
        Ok(v) => v,
        Err(_) => {
            let v = StageVerdict::block(
                "<malformed-args>",
                "malformed tool arguments (invalid JSON)",
                None,
            );
            return (v, Value::Null);
        }
    };
    let v = session.validate_tool_call(tool_name, &mut value, tool_call_id);
    (v, value)
}

/// Stage 4 — guard tool output. `tool_call_id` MUST match the id
/// passed to the paired Stage 3 call (§16.0).
pub fn protect_tool_output(
    session: &GuardrailsSession,
    tool_name: &str,
    result: &mut Value,
    tool_call_id: &str,
) -> StageVerdict {
    session.validate_tool_output(tool_name, result, tool_call_id)
}

/// Record a successful tool execution (§10.3 / §21).
pub fn record_tool_success(
    session: &GuardrailsSession,
    tool_name: &str,
    result: &Value,
) -> Result<(), RuntimeError> {
    session.record_tool_success(tool_name, result)
}

/// Record a failed tool execution.
pub fn record_tool_failure(
    session: &GuardrailsSession,
    tool_name: &str,
    error: &str,
) -> Result<(), RuntimeError> {
    session.record_tool_failure(tool_name, error)
}

/// Stage 1 — guard the last user message in a conversation.
pub fn guard_conversation(
    session: &GuardrailsSession,
    messages: &[ChatCompletionRequestMessage],
) -> Result<(), StageVerdict> {
    let user_text = extract_last_user_message(messages);
    if user_text.is_empty() {
        return Ok(());
    }
    let v = session.validate_input(&user_text);
    if v.allowed {
        Ok(())
    } else {
        Err(v)
    }
}

/// Stage 5 — guard a response.
pub fn guard_response(session: &GuardrailsSession, text: &mut String) -> StageVerdict {
    session.validate_output(text)
}

/// Extract text from the last user message in a conversation.
fn extract_last_user_message(messages: &[ChatCompletionRequestMessage]) -> String {
    use ChatCompletionRequestMessage as M;
    for msg in messages.iter().rev() {
        match msg {
            M::User(u) => {
                let txt = match &u.content {
                    ChatCompletionRequestUserMessageContent::Text(s) => s.clone(),
                    ChatCompletionRequestUserMessageContent::Array(parts) => parts
                        .iter()
                        .filter_map(|p| match p {
                            ChatCompletionRequestUserMessageContentPart::Text(
                                ChatCompletionRequestMessageContentPartText { text, .. },
                            ) => Some(text.as_str()),
                            _ => None,
                        })
                        .collect::<Vec<_>>()
                        .join(" "),
                };
                if !txt.is_empty() {
                    return txt;
                }
            }
            _ => continue,
        }
    }
    String::new()
}

// ── TurnGuard ───────────────────────────────────────────────────────

/// Per-turn guard — borrows a session and drives `begin_turn` /
/// `end_turn`.
pub struct TurnGuard<'a> {
    session: &'a GuardrailsSession,
    ended: std::cell::Cell<bool>,
}

impl<'a> TurnGuard<'a> {
    /// Begin a turn with Stage 1 validation against the last user
    /// message. Returns `Err(verdict)` if Stage 1 blocks.
    pub fn begin(
        session: &'a GuardrailsSession,
        messages: &[ChatCompletionRequestMessage],
    ) -> Result<Self, StageVerdict> {
        if let Err(e) = session.begin_turn() {
            log::warn!(target: "agent_shield::openai", "begin_turn failed: {e:?}");
        }
        let user_text = extract_last_user_message(messages);
        if !user_text.is_empty() {
            let v = session.validate_input(&user_text);
            if !v.allowed {
                if let Err(e) = session.end_turn() {
                    log::warn!(target: "agent_shield::openai", "end_turn failed: {e:?}");
                }
                return Err(v);
            }
        }
        Ok(Self {
            session,
            ended: std::cell::Cell::new(false),
        })
    }

    /// Borrow the underlying session.
    pub fn session(&self) -> &GuardrailsSession {
        self.session
    }

    /// Stage 2+3 against the held session. `tool_call_id` is REQUIRED
    /// per spec §16.0; pair the same id with the matching
    /// [`Self::validate_tool_output`]. Forward the OpenAI
    /// `tool_call.id` when one is available, or use
    /// [`agent_shield_core::synthetic_tool_call_id`] otherwise.
    pub fn validate_tool_call(
        &self,
        name: &str,
        params: &mut Value,
        tool_call_id: &str,
    ) -> StageVerdict {
        self.session.validate_tool_call(name, params, tool_call_id)
    }

    /// Stage 4 against the held session. `tool_call_id` MUST match
    /// the id passed to the paired [`Self::validate_tool_call`] (§16.0).
    pub fn validate_tool_output(
        &self,
        name: &str,
        result: &mut Value,
        tool_call_id: &str,
    ) -> StageVerdict {
        self.session
            .validate_tool_output(name, result, tool_call_id)
    }

    /// Stage 5 against the held session.
    pub fn validate_output(&self, response: &mut String) -> StageVerdict {
        self.session.validate_output(response)
    }

    /// Construct a streaming guard for the given stage (Stage 4 or 5).
    pub fn streaming_session(&self, stage: ObsStage) -> agent_shield_core::StreamingGuard {
        self.session.streaming_session(stage)
    }

    /// Explicitly end the turn. Idempotent — calling `end()` multiple
    /// times (or `end()` followed by `Drop`) only fires `turn.end`
    /// once.
    pub fn end(&self) {
        if !self.ended.replace(true) {
            if let Err(e) = self.session.end_turn() {
                log::warn!(target: "agent_shield::openai", "end_turn failed: {e:?}");
            }
        }
    }
}

impl Drop for TurnGuard<'_> {
    fn drop(&mut self) {
        if !self.ended.replace(true) {
            if let Err(e) = self.session.end_turn() {
                log::warn!(target: "agent_shield::openai", "end_turn (Drop) failed: {e:?}");
            }
        }
    }
}

// ── Streaming ───────────────────────────────────────────────────────

/// Result of guarding a streamed OpenAI response.
pub enum GuardStreamResult<C> {
    Passed(C),
    Redacted(C),
    Blocked(String),
}

/// Buffer an OpenAI stream and validate at end-of-stream using
/// `OnComplete` semantics. For windowed validation, drive the
/// `StreamingGuard` directly via [`TurnGuard::streaming_session`].
pub async fn stream_complete<C, F>(
    session: &GuardrailsSession,
    mut stream: futures::stream::BoxStream<'_, Result<C, String>>,
    extract_text: F,
    reconstruct: impl FnOnce(String) -> C,
) -> GuardStreamResult<C>
where
    C: Send,
    F: Fn(&C) -> String,
{
    use futures::StreamExt;

    let mut accumulated = String::new();
    while let Some(item) = stream.next().await {
        match item {
            Ok(chunk) => {
                let t = extract_text(&chunk);
                accumulated.push_str(&t);
            }
            Err(e) => {
                log::warn!(target: "agent_shield::openai", "stream error — fail-closed: {e}");
                return GuardStreamResult::Blocked(format_response_block(
                    "stream error — fail-closed",
                ));
            }
        }
    }
    if accumulated.is_empty() {
        return GuardStreamResult::Passed(reconstruct(String::new()));
    }
    let mut text = accumulated.clone();
    let v = session.validate_output(&mut text);
    if !v.allowed {
        return GuardStreamResult::Blocked(format_response_block(
            v.reason.as_deref().unwrap_or("blocked"),
        ));
    }
    if text != accumulated {
        GuardStreamResult::Redacted(reconstruct(text))
    } else {
        GuardStreamResult::Passed(reconstruct(text))
    }
}

// ── Tool wrapping ───────────────────────────────────────────────────

/// Async tool executor function signature.
///
/// Arguments: `(tool_name, args_json, tool_call_id)`. The
/// `tool_call_id` is the §16.0 binding handle — pass the OpenAI
/// `tool_call.id` from the model response when available, or
/// [`agent_shield_core::synthetic_tool_call_id`] otherwise.
pub type ToolExecutor = Arc<
    dyn Fn(
            String,
            String,
            String,
        )
            -> std::pin::Pin<Box<dyn std::future::Future<Output = Result<String, String>> + Send>>
        + Send
        + Sync,
>;

/// Wrap a tool executor with guardrails. The returned executor:
///
/// 1. Parses arguments JSON (fails closed on malformed input).
/// 2. Stage 2+3 against the parsed value (bound to `tool_call_id`).
/// 3. Runs the underlying tool.
/// 4. Stage 4 against the tool output (bound to the same id).
/// 5. Records `tool.<name>.success` / `tool.<name>.failure`.
///
/// The caller MUST forward the OpenAI `tool_call.id` from the model
/// response when it is available; if the host loop does not have a
/// stable id, pass [`agent_shield_core::synthetic_tool_call_id`].
/// The inner `tool_fn` keeps the original `(name, args_json)`
/// signature — only the outer wrapper sees the id.
pub fn protect_tool_executor<F>(session: Arc<GuardrailsSession>, tool_fn: F) -> ToolExecutor
where
    F: Fn(
            String,
            String,
        )
            -> std::pin::Pin<Box<dyn std::future::Future<Output = Result<String, String>> + Send>>
        + Send
        + Sync
        + 'static,
{
    let exec = Arc::new(tool_fn);
    Arc::new(
        move |name: String, args_json: String, tool_call_id: String| {
            let session = session.clone();
            let exec = exec.clone();
            Box::pin(async move {
                let mut value: Value = match serde_json::from_str(&args_json) {
                    Ok(v) => v,
                    Err(e) => {
                        log::warn!(target: "agent_shield::openai", "malformed tool arguments (invalid JSON): {e}");
                        // P11.5: symmetric with the post-tool-blocked path.
                        if let Err(rec_err) = session
                            .record_tool_failure(&name, "malformed tool arguments (invalid JSON)")
                        {
                            log::warn!(target: "agent_shield::openai", "record_tool_failure failed: {rec_err:?}");
                        }
                        return Ok(format_tool_block(
                            &name,
                            "malformed tool arguments (invalid JSON)",
                        ));
                    }
                };
                let verdict = session.validate_tool_call(&name, &mut value, &tool_call_id);
                if !verdict.allowed {
                    return Ok(format_tool_block(
                        &name,
                        verdict.reason.as_deref().unwrap_or("blocked"),
                    ));
                }

                // P11.3: re-serialize the (possibly Stage-3-mutated) value
                // so the downstream executor receives the transformed args,
                // not the raw input. Fail closed on serialization error.
                let serialized = match serde_json::to_string(&value) {
                    Ok(s) => s,
                    Err(e) => {
                        log::warn!(target: "agent_shield::openai", "failed to re-serialize transformed tool arguments: {e}");
                        if let Err(rec_err) = session.record_tool_failure(
                            &name,
                            "failed to re-serialize transformed tool arguments",
                        ) {
                            log::warn!(target: "agent_shield::openai", "record_tool_failure failed: {rec_err:?}");
                        }
                        return Ok(format_tool_block(
                            &name,
                            "failed to re-serialize transformed tool arguments",
                        ));
                    }
                };
                let res = exec(name.clone(), serialized).await;
                match res {
                    Ok(text) => {
                        let mut out = Value::String(text.clone());
                        let post = session.validate_tool_output(&name, &mut out, &tool_call_id);
                        if !post.allowed {
                            if let Err(e) = session.record_tool_failure(&name, "post-tool-blocked")
                            {
                                log::warn!(target: "agent_shield::openai", "record_tool_failure failed: {e:?}");
                            }
                            return Ok(format_tool_output_block(
                                &name,
                                post.reason.as_deref().unwrap_or("blocked"),
                            ));
                        }
                        if let Err(e) = session.record_tool_success(&name, &out) {
                            log::warn!(target: "agent_shield::openai", "record_tool_success failed: {e:?}");
                        }
                        Ok(out.as_str().map(|s| s.to_string()).unwrap_or(text))
                    }
                    Err(e) => {
                        if let Err(rec_err) = session.record_tool_failure(&name, &e) {
                            log::warn!(target: "agent_shield::openai", "record_tool_failure failed: {rec_err:?}");
                        }
                        Ok(format_tool_error(&name, &e))
                    }
                }
            })
        },
    )
}
