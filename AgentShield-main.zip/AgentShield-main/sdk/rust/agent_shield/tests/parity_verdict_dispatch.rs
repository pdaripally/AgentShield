//! Cross-SDK verdict-dispatch parity test (Rust side).
//!
//! Reads the canonical fixture in
//! `tests/parity/verdict_dispatch_canonical.json` and runs every
//! (verdict, policy, mode) input through the canonical core
//! dispatcher. Each expected output is the byte-equivalent payload
//! every SDK MUST produce for the same input.
//!
//! The Python, Node, and .NET SDKs run the equivalent test against
//! the same fixture so the four SDKs stay byte-aligned on the
//! orchestrator's deterministic decisions.

use std::fs;
use std::path::PathBuf;

use agent_shield_core::{
    dispatch_outcome_to_wire, dispatch_stage_verdict, dispatch_tool_verdict,
    stage_verdict_from_wire, tool_dispatch_outcome_to_wire, OnBlockPolicy, ShieldMode, ToolStage,
};
use serde_json::Value;

fn fixture_path() -> Option<PathBuf> {
    let mut dir = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    while !dir.join(".git").exists() {
        if !dir.pop() {
            return None;
        }
    }
    let p = dir
        .join("tests")
        .join("parity")
        .join("verdict_dispatch_canonical.json");
    if p.exists() {
        Some(p)
    } else {
        None
    }
}

fn parse_policy(s: &str) -> OnBlockPolicy {
    OnBlockPolicy::from_wire_str(s).unwrap_or_else(|| panic!("unknown policy: {s}"))
}

fn parse_mode(s: &str) -> ShieldMode {
    ShieldMode::from_wire_str(s).unwrap_or_else(|| panic!("unknown mode: {s}"))
}

fn parse_stage(s: &str) -> ToolStage {
    match s {
        "call" => ToolStage::Call,
        "output" => ToolStage::Output,
        other => panic!("unknown stage: {other}"),
    }
}

#[test]
fn stage_dispatch_matches_canonical() {
    let path = match fixture_path() {
        Some(p) => p,
        None => {
            eprintln!("verdict_dispatch_canonical.json not found; skipping");
            return;
        }
    };
    let raw = fs::read_to_string(&path).expect("read fixture");
    let doc: Value = serde_json::from_str(&raw).expect("parse fixture");
    let cases = doc["stage_cases"].as_array().expect("stage_cases array");

    for case in cases {
        let name = case["name"].as_str().unwrap_or("<unnamed>");
        let verdict = stage_verdict_from_wire(&case["verdict"])
            .unwrap_or_else(|| panic!("[{name}] malformed verdict"));
        let policy = parse_policy(case["policy"].as_str().unwrap());
        let mode = parse_mode(case["mode"].as_str().unwrap());
        let actual = dispatch_outcome_to_wire(&dispatch_stage_verdict(&verdict, policy, mode));
        let expected = &case["expected"];

        assert_eq!(
            actual["action"], expected["action"],
            "[{name}] action mismatch"
        );
        assert_eq!(
            actual["record_block"], expected["record_block"],
            "[{name}] record_block mismatch"
        );
        assert_eq!(
            actual["override_to_proceed"], expected["override_to_proceed"],
            "[{name}] override_to_proceed mismatch"
        );
    }
}

#[test]
fn tool_dispatch_matches_canonical() {
    let path = match fixture_path() {
        Some(p) => p,
        None => {
            eprintln!("verdict_dispatch_canonical.json not found; skipping");
            return;
        }
    };
    let raw = fs::read_to_string(&path).expect("read fixture");
    let doc: Value = serde_json::from_str(&raw).expect("parse fixture");
    let cases = doc["tool_cases"].as_array().expect("tool_cases array");

    for case in cases {
        let name = case["name"].as_str().unwrap_or("<unnamed>");
        let verdict = stage_verdict_from_wire(&case["verdict"])
            .unwrap_or_else(|| panic!("[{name}] malformed verdict"));
        let tool_name = case["tool_name"].as_str().unwrap();
        let stage = parse_stage(case["stage"].as_str().unwrap());
        let policy = parse_policy(case["policy"].as_str().unwrap());
        let mode = parse_mode(case["mode"].as_str().unwrap());
        let actual = tool_dispatch_outcome_to_wire(&dispatch_tool_verdict(
            &verdict, tool_name, stage, policy, mode,
        ));
        let expected = &case["expected"];

        assert_eq!(
            actual["action"], expected["action"],
            "[{name}] action mismatch"
        );
        assert_eq!(
            actual["record_failure"], expected["record_failure"],
            "[{name}] record_failure mismatch"
        );
        assert_eq!(
            actual["record_success"], expected["record_success"],
            "[{name}] record_success mismatch"
        );
        assert_eq!(
            actual["override_to_proceed"], expected["override_to_proceed"],
            "[{name}] override_to_proceed mismatch"
        );
    }
}
