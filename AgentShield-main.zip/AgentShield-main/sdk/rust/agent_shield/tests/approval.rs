//! End-to-end coverage for the bundled `kind: human` resolver
//! providers. Drives each provider through a real YAML guardrails
//! contract — the gate's deny / allow decision is produced by the
//! registered handler, end-to-end.

use std::fs;
use std::path::PathBuf;
use std::sync::Arc;
use std::time::Duration;

use agent_shield::approval::{
    AutoRejectHandler, CallbackApprovalHandler, ConsoleApprovalHandler, HumanResolveRequest,
    HumanResolverFn, ResolverDecision, ResolverResponse,
};
use agent_shield_core::resolver_runtime::HumanResolver;
use agent_shield_core::runtime::{RequestContext, RuntimeBuilder};
use serde_json::json;

const HUMAN_GATE_YAML: &str = r#"
metadata:
  name: "human-gate-fixture"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["only-when-approved tool calls"]
  forbidden: ["never"]
resources:
  tools:
    - name: "send_money"
      description: "send money"
      permission: "execute"
variables:
  - name: "send_authorized"
    type: "boolean"
    on_demand_by:
      kind: human
      __PROVIDER_LINE__
      prompt: "Authorize send_money?"
state_validation:
  guard_policies:
    - name: "send_requires_approval"
      applies_to:
        tools:
          - "send_money"
      evaluate_when:
        - expression: "send_authorized == true"
          reason: "send_money requires explicit approval"
      action: "block"
"#;

fn yaml_with_provider_line(provider_line: &str) -> String {
    HUMAN_GATE_YAML.replace("__PROVIDER_LINE__", provider_line)
}

fn yaml_with_provider(provider: &str) -> String {
    yaml_with_provider_line(&format!("provider: \"{provider}\""))
}

fn write_yaml(yaml: &str, name: &str) -> PathBuf {
    let manifest = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    let dir = manifest.join("target/test-yaml");
    fs::create_dir_all(&dir).unwrap();
    let path = dir.join(format!("{name}.guardrails.yaml"));
    fs::write(&path, yaml).unwrap();
    path
}

#[test]
fn auto_reject_provider_denies_tool_call() {
    let yaml_path = write_yaml(&yaml_with_provider("auto_reject"), "auto_reject");
    let runtime = RuntimeBuilder::from_yaml(&yaml_path)
        .expect("yaml load")
        .register_human_provider("auto_reject", Arc::new(AutoRejectHandler))
        .build()
        .expect("build");

    let session = runtime.new_session(RequestContext::new("s1", "c1"));
    let mut params = json!({"amount": 100});
    let v = session.validate_tool_call("send_money", &mut params, "call_1");
    assert!(!v.allowed, "auto_reject must deny");
    assert_eq!(v.policy.as_deref(), Some("send_requires_approval"));
}

#[test]
fn callback_provider_allows_when_closure_returns_allow() {
    let yaml_path = write_yaml(&yaml_with_provider("user_approval"), "callback_allow");
    let allow_handler =
        CallbackApprovalHandler::new(|_req: HumanResolveRequest| ResolverResponse {
            decision: ResolverDecision::Allow,
            value: Some(json!(true)),
            set_variables: Default::default(),
            reason: None,
        });
    let runtime = RuntimeBuilder::from_yaml(&yaml_path)
        .expect("yaml load")
        .register_human_provider("user_approval", Arc::new(allow_handler))
        .build()
        .expect("build");

    let session = runtime.new_session(RequestContext::new("s1", "c1"));
    let mut params = json!({"amount": 100});
    let v = session.validate_tool_call("send_money", &mut params, "call_1");
    assert!(v.allowed, "callback returning Allow should permit the call");
}

#[test]
fn callback_provider_blocks_when_closure_returns_deny() {
    let yaml_path = write_yaml(&yaml_with_provider("user_approval"), "callback_deny");
    let deny_handler = CallbackApprovalHandler::new(|_req: HumanResolveRequest| ResolverResponse {
        decision: ResolverDecision::Deny,
        value: None,
        set_variables: Default::default(),
        reason: Some("policy denies".into()),
    });
    let runtime = RuntimeBuilder::from_yaml(&yaml_path)
        .expect("yaml load")
        .register_human_provider("user_approval", Arc::new(deny_handler))
        .build()
        .expect("build");

    let session = runtime.new_session(RequestContext::new("s1", "c1"));
    let mut params = json!({"amount": 100});
    let v = session.validate_tool_call("send_money", &mut params, "call_1");
    assert!(!v.allowed);
}

#[test]
fn unregistered_provider_fails_closed_through_gate() {
    let yaml_path = write_yaml(&yaml_with_provider("never_registered_xyz"), "unregistered");
    let runtime = RuntimeBuilder::from_yaml(&yaml_path)
        .expect("yaml load")
        .build()
        .expect("build");

    let session = runtime.new_session(RequestContext::new("s1", "c1"));
    let mut params = json!({"amount": 100});
    let v = session.validate_tool_call("send_money", &mut params, "call_1");
    assert!(!v.allowed, "unregistered provider must fail closed");
}

#[test]
fn console_provider_with_scripted_input_allows_on_o() {
    use agent_shield::approval::console::ScriptedReader;
    let yaml_path = write_yaml(&yaml_with_provider("console"), "console_o");
    let reader = Arc::new(ScriptedReader::new(["o\n"]));
    let console = ConsoleApprovalHandler::with_reader(Duration::from_secs(1), reader);
    let runtime = RuntimeBuilder::from_yaml(&yaml_path)
        .expect("yaml load")
        .register_human_provider("console", Arc::new(console))
        .build()
        .expect("build");

    let session = runtime.new_session(RequestContext::new("s1", "c1"));
    let mut params = json!({"amount": 100});
    let v = session.validate_tool_call("send_money", &mut params, "call_1");
    assert!(v.allowed, "console `o` (allow once) should permit the call");
}

#[test]
fn console_provider_with_scripted_input_blocks_on_n() {
    use agent_shield::approval::console::ScriptedReader;
    let yaml_path = write_yaml(&yaml_with_provider("console"), "console_n");
    let reader = Arc::new(ScriptedReader::new(["n\n"]));
    let console = ConsoleApprovalHandler::with_reader(Duration::from_secs(1), reader);
    let runtime = RuntimeBuilder::from_yaml(&yaml_path)
        .expect("yaml load")
        .register_human_provider("console", Arc::new(console))
        .build()
        .expect("build");

    let session = runtime.new_session(RequestContext::new("s1", "c1"));
    let mut params = json!({"amount": 100});
    let v = session.validate_tool_call("send_money", &mut params, "call_1");
    assert!(!v.allowed);
}

#[test]
fn name_field_aliases_provider_through_gate() {
    let yaml_path = write_yaml(
        &yaml_with_provider_line("name: \"my_handler\""),
        "name_alias",
    );
    let runtime = RuntimeBuilder::from_yaml(&yaml_path)
        .expect("yaml load")
        .register_human_provider(
            "my_handler",
            Arc::new(HumanResolverFn(|_req: HumanResolveRequest| {
                ResolverResponse {
                    decision: ResolverDecision::Allow,
                    value: Some(json!(true)),
                    set_variables: Default::default(),
                    reason: None,
                }
            })),
        )
        .build()
        .expect("build");

    let session = runtime.new_session(RequestContext::new("s1", "c1"));
    let mut params = json!({"amount": 100});
    let v = session.validate_tool_call("send_money", &mut params, "call_1");
    assert!(v.allowed);
}

#[test]
fn surface_check_handlers_implement_human_resolver() {
    let _: &dyn HumanResolver = &AutoRejectHandler;
    let _: &dyn HumanResolver = &ConsoleApprovalHandler::new();
    let _: &dyn HumanResolver = &CallbackApprovalHandler::new(|_| ResolverResponse {
        decision: ResolverDecision::Deny,
        value: None,
        set_variables: Default::default(),
        reason: None,
    });
}

#[test]
fn auto_reject_is_auto_wired_from_yaml_without_host_registration() {
    // This is the YAML-driven path: `provider: auto_reject` in YAML,
    // no `register_human_provider` call from the host. The runtime
    // builder MUST auto-register the bundled handler so the gate
    // denies on first contact.
    let yaml_path = write_yaml(&yaml_with_provider("auto_reject"), "auto_reject_auto_wired");
    let runtime = RuntimeBuilder::from_yaml(&yaml_path)
        .expect("yaml load")
        // Deliberately no .register_human_provider() — proves the
        // bundled handler is auto-wired by build().
        .build()
        .expect("build");

    let session = runtime.new_session(RequestContext::new("s1", "c1"));
    let mut params = json!({"amount": 100});
    let v = session.validate_tool_call("send_money", &mut params, "call_1");
    assert!(!v.allowed, "auto-wired auto_reject must deny");
    assert_eq!(v.policy.as_deref(), Some("send_requires_approval"));
}

#[test]
fn deny_alias_is_auto_wired_from_yaml() {
    // Same as above but using the `deny` alias.
    let yaml_path = write_yaml(&yaml_with_provider("deny"), "deny_alias_auto_wired");
    let runtime = RuntimeBuilder::from_yaml(&yaml_path)
        .expect("yaml load")
        .build()
        .expect("build");

    let session = runtime.new_session(RequestContext::new("s1", "c1"));
    let mut params = json!({"amount": 100});
    let v = session.validate_tool_call("send_money", &mut params, "call_1");
    assert!(!v.allowed, "auto-wired `deny` alias must deny");
}

#[test]
fn host_registration_overrides_bundled_provider_name() {
    // If the YAML refers to `auto_reject` but the host registers an
    // explicit handler under the same name, the host wins. Prove this
    // by registering an "always allow" handler under the
    // `auto_reject` name and asserting the gate passes.
    let yaml_path = write_yaml(&yaml_with_provider("auto_reject"), "host_overrides_bundled");
    let allow_handler =
        CallbackApprovalHandler::new(|_req: HumanResolveRequest| ResolverResponse {
            decision: ResolverDecision::Allow,
            value: Some(json!(true)),
            set_variables: Default::default(),
            reason: None,
        });
    let runtime = RuntimeBuilder::from_yaml(&yaml_path)
        .expect("yaml load")
        .register_human_provider("auto_reject", Arc::new(allow_handler))
        .build()
        .expect("build");

    let session = runtime.new_session(RequestContext::new("s1", "c1"));
    let mut params = json!({"amount": 100});
    let v = session.validate_tool_call("send_money", &mut params, "call_1");
    assert!(
        v.allowed,
        "host-registered handler under same name must override the bundled default"
    );
}
