//! Tests for the `Shield` orchestrator.
//!
//! Exercises:
//! - Stage 1 block path (`guarded_run` returns `ShieldError::Blocked`).
//! - Stage 5 redact path.
//! - `protect_tool` Stage 2/3 + Stage 4 brackets.
//! - `protect_tools` (Pattern B) via a synthetic `ToolWrapper`.
//! - `with_mode(Monitor)` keeps the host flow alive on a Stage 1 deny.
//! - `OnBlockPolicy` + `resolve_on_block` round-trip.

use std::path::PathBuf;
use std::sync::{Arc, Mutex};

use agent_shield::{OnBlockOutcome, OnBlockPolicy, Shield, ShieldError, ShieldMode, ToolWrapper};
use agent_shield_core::{GuardrailsRuntime, ObservabilityProvider, ShieldLogEvent};
use serde_json::{json, Value};

fn fixture_path(name: &str) -> PathBuf {
    let manifest = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    manifest
        .join("../../..")
        .join("tests/fixtures/smoke")
        .join(name)
}

#[derive(Clone, Default)]
struct CapturingProvider {
    events: Arc<Mutex<Vec<ShieldLogEvent>>>,
}

impl ObservabilityProvider for CapturingProvider {
    fn emit(&self, event: ShieldLogEvent) {
        self.events.lock().unwrap().push(event);
    }
}

#[tokio::test]
async fn guarded_run_blocks_on_stage1() {
    let shield = Shield::from_yaml(fixture_path("input-block.guardrails.yaml"))
        .build()
        .expect("build input-block fixture");
    let result = shield
        .guarded_run(
            "DENY_ME please",
            |_| async move { Ok("never runs".to_string()) },
        )
        .await;
    match result {
        Err(ShieldError::Blocked { message, verdict }) => {
            assert!(message.starts_with("[GUARDRAIL "), "got: {message}");
            assert!(!verdict.allowed);
        }
        other => panic!("expected Blocked, got {other:?}"),
    }
}

#[tokio::test]
async fn guarded_run_passes_clean_input() {
    let shield = Shield::from_yaml(fixture_path("minimal.guardrails.yaml"))
        .build()
        .expect("build minimal fixture");
    let out = shield
        .guarded_run(
            "hello",
            |input| async move { Ok(format!("you said {input}")) },
        )
        .await
        .expect("clean input must pass");
    assert_eq!(out, "you said hello");
}

#[tokio::test]
async fn run_brackets_turn_lifecycle() {
    let provider = CapturingProvider::default();
    let events = provider.events.clone();
    let shield = Shield::from_yaml(fixture_path("minimal.guardrails.yaml"))
        .with_observability(provider)
        .build()
        .expect("build");
    let value = shield.run(|| async { 42_u32 }).await.expect("run");
    assert_eq!(value, 42);
    let captured = events.lock().unwrap();
    let ids: Vec<String> = captured.iter().filter_map(|e| e.event_id.clone()).collect();
    assert!(
        ids.iter().any(|k| k == "turn.start"),
        "expected turn.start, saw {ids:?}"
    );
    assert!(
        ids.iter().any(|k| k == "turn.end"),
        "expected turn.end, saw {ids:?}"
    );
}

#[tokio::test]
async fn protect_tool_blocks_stage_2_when_unauthorized() {
    let shield = Shield::from_yaml(fixture_path("minimal.guardrails.yaml"))
        .build()
        .expect("build minimal fixture");
    let mut params = json!({"msg": "hi"});
    let res = shield
        .protect_tool("echo", &mut params, "call_1", |_args| async move {
            Ok::<Value, String>(json!("never runs"))
        })
        .await;
    match res {
        Err(ShieldError::Blocked { message, .. }) => {
            assert!(message.contains("(tool: echo)"), "got: {message}");
        }
        other => panic!("expected Blocked, got {other:?}"),
    }
}

#[tokio::test]
async fn protect_tool_passes_when_authorized() {
    let shield = Shield::from_yaml(fixture_path("minimal.guardrails.yaml"))
        .build()
        .expect("build minimal fixture");
    // The minimal fixture's policy reads `authorized == true`.
    shield
        .session()
        .set_variable("authorized", Value::Bool(true))
        .expect("set var");
    let mut params = json!({"msg": "hi"});
    let result = shield
        .protect_tool("echo", &mut params, "call_1", |args| async move {
            assert_eq!(args["msg"], "hi");
            Ok::<Value, String>(json!("done"))
        })
        .await
        .expect("authorized echo passes");
    assert_eq!(result, json!("done"));
}

#[tokio::test]
async fn monitor_mode_does_not_block() {
    let shield = Shield::from_yaml(fixture_path("input-block.guardrails.yaml"))
        .with_mode(ShieldMode::Monitor)
        .build()
        .expect("build");
    let out = shield
        .guarded_run("DENY_ME please", |input| async move { Ok(input) })
        .await
        .expect("monitor mode never blocks");
    assert_eq!(out, "DENY_ME please");
}

// ── ToolWrapper / protect_tools ────────────────────────────────────

struct StringTool {
    name: String,
}

struct WrappedStringTool {
    name: String,
    runtime_present: bool,
}

struct StringToolWrapper;
impl ToolWrapper for StringToolWrapper {
    type Tool = StringTool;
    type Wrapped = WrappedStringTool;

    fn wrap(runtime: Arc<GuardrailsRuntime>, tool: StringTool) -> WrappedStringTool {
        // Touch runtime so the test asserts the wrapper actually
        // received a populated runtime handle.
        let _ = runtime.config().metadata.name.as_str();
        WrappedStringTool {
            name: tool.name,
            runtime_present: true,
        }
    }
}

#[tokio::test]
async fn protect_tools_pattern_b_wraps_each() {
    let shield = Shield::from_yaml(fixture_path("minimal.guardrails.yaml"))
        .build()
        .expect("build");
    let wrapped = shield.protect_tools::<StringToolWrapper>(vec![
        StringTool {
            name: "alpha".into(),
        },
        StringTool {
            name: "beta".into(),
        },
    ]);
    assert_eq!(wrapped.len(), 2);
    assert_eq!(wrapped[0].name, "alpha");
    assert!(wrapped[0].runtime_present);
    assert_eq!(wrapped[1].name, "beta");
}

// ── On-block dispatch ──────────────────────────────────────────────

#[test]
fn on_block_policy_dispatch() {
    use agent_shield::resolve_on_block;
    use agent_shield_core::Action;
    use agent_shield_core::StageVerdict;
    let verdict = StageVerdict {
        allowed: false,
        action: Some(Action::Block),
        reason: Some("nope".into()),
        policy: None,
        evaluate_when_index: None,
        bypassed_by_allowed_when: false,
        redaction: None,
        appended: None,
        prepended: None,
        pending_resolution: None,
        declassify_to: None,
        invocation_hash: None,
        post_validation_invocation_hash: None,
    };

    match resolve_on_block(OnBlockPolicy::ReturnBlocked, &verdict) {
        OnBlockOutcome::ReturnBlocked { message } => {
            assert_eq!(message, "[GUARDRAIL BLOCK] nope");
        }
        other => panic!("unexpected: {other:?}"),
    }

    assert_eq!(
        resolve_on_block(OnBlockPolicy::ReturnVerdict, &verdict),
        OnBlockOutcome::ReturnVerdict
    );

    match resolve_on_block(OnBlockPolicy::Raise, &verdict) {
        OnBlockOutcome::Raise { message } => {
            assert_eq!(message, "[GUARDRAIL BLOCK] nope");
        }
        other => panic!("unexpected: {other:?}"),
    }

    match resolve_on_block(OnBlockPolicy::Custom, &verdict) {
        OnBlockOutcome::Custom { message } => {
            assert_eq!(message, "[GUARDRAIL BLOCK] nope");
        }
        other => panic!("unexpected: {other:?}"),
    }
}

#[tokio::test]
async fn capability_report_defaults_to_core() {
    let shield = Shield::from_yaml(fixture_path("minimal.guardrails.yaml"))
        .build()
        .expect("build");
    assert_eq!(shield.capabilities().framework, "core");
}

#[tokio::test]
async fn from_runtime_rejects_post_hoc_hooks() {
    let runtime =
        agent_shield_core::RuntimeBuilder::from_yaml(fixture_path("minimal.guardrails.yaml"))
            .expect("yaml")
            .build()
            .expect("rt");
    let result = Shield::from_runtime(runtime)
        .with_tool_retry_limit(5)
        .build();
    assert!(result.is_err(), "from_runtime + hooks must be rejected");
}
