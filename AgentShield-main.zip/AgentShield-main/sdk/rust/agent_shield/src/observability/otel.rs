//! OpenTelemetry observability backend.
//!
//! [`ObservabilityProvider`] has a single
//! [`emit`](ObservabilityProvider::emit) method, so this implementation
//! routes the event through the `log` crate (an OTel log-bridge picks
//! it up) AND increments an OTel counter named
//! `agent_shield_<event_type>` so aggregable per-event-type counters
//! are still available downstream.
//!
//! ## Enabling
//!
//! ```toml
//! agent_shield = { version = "0.13", features = ["otel"] }
//! ```

use std::collections::HashMap;

use agent_shield_core::{ObservabilityProvider, ShieldLogEvent};

use crate::constants::DEFAULT_OTEL_METER_NAME;

/// OpenTelemetry-based observability provider.
///
/// Routes Agent Shield events to the OTel logging pipeline (via the
/// `log` crate bridge) and synthesises per-event-type counters on the
/// OTel metrics pipeline.
pub struct OTelProvider {
    meter_name: String,
}

impl OTelProvider {
    /// Create a new OTel provider with the given meter name.
    pub fn new(meter_name: &str) -> Self {
        Self {
            meter_name: meter_name.to_string(),
        }
    }

    fn record_metric(&self, name: &str, value: f64, attributes: &HashMap<String, String>) {
        use opentelemetry::global;
        use opentelemetry::{InstrumentationScope, KeyValue};

        let scope = InstrumentationScope::builder(self.meter_name.clone()).build();
        let meter = global::meter_with_scope(scope);
        let counter = meter.f64_counter(name.to_string()).build();
        let kvs: Vec<KeyValue> = attributes
            .iter()
            .map(|(k, v)| KeyValue::new(k.clone(), v.clone()))
            .collect();
        counter.add(value, &kvs);
    }
}

impl Default for OTelProvider {
    fn default() -> Self {
        Self::new(DEFAULT_OTEL_METER_NAME)
    }
}

impl ObservabilityProvider for OTelProvider {
    fn emit(&self, event: ShieldLogEvent) {
        // 1. Log bridge — let the OTel SDK pick this up via the
        //    `log` -> OTLP appender that hosts wire externally.
        let event_type = event.event_type.as_str();
        let category = &event.category;
        let session_id = &event.session_id;
        match event.severity.as_str() {
            "critical" | "high" => log::error!(
                target: "agent_shield.otel",
                "{} category={} session_id={}",
                event_type, category, session_id
            ),
            "medium" => log::warn!(
                target: "agent_shield.otel",
                "{} category={} session_id={}",
                event_type, category, session_id
            ),
            _ => log::info!(
                target: "agent_shield.otel",
                "{} category={} session_id={}",
                event_type, category, session_id
            ),
        }

        // 2. Metric — increment a counter keyed by event type. Hosts
        //    that don't have an OTel SDK installed will see the
        //    counter calls become no-ops; that's the SDK's documented
        //    behavior.
        let metric_name = format!("agent_shield_{}", event_type);
        let mut attrs = HashMap::with_capacity(4);
        attrs.insert("severity".to_string(), event.severity.as_str().to_string());
        attrs.insert("category".to_string(), category.clone());
        attrs.insert("session_id".to_string(), session_id.clone());
        if let Some(stage) = event.stage {
            attrs.insert("stage".to_string(), stage.as_str().to_string());
        }
        self.record_metric(&metric_name, 1.0, &attrs);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use agent_shield_core::observability::event::{EventType, Severity};

    #[test]
    fn emit_does_not_panic_without_otel_sdk_installed() {
        // Without an OTel pipeline configured, the meter calls are
        // no-ops via the SDK's NoopMeterProvider. Verify emit() is
        // panic-free in that path — the most common test environment.
        let p = OTelProvider::new("agent_shield_test");
        p.emit(ShieldLogEvent::new(
            EventType::Info,
            Severity::Info,
            "smoke",
        ));
        p.emit(ShieldLogEvent::new(
            EventType::GatingVerdict,
            Severity::High,
            "smoke",
        ));
    }

    #[test]
    fn default_uses_canonical_meter_name() {
        let p = OTelProvider::default();
        assert_eq!(p.meter_name, DEFAULT_OTEL_METER_NAME);
    }
}
