//! `GuardedTurn` — pre-validated per-turn handle.
//!
//! A `GuardedTurn` is returned by [`crate::Shield::start_turn`] after
//! Stage 1 has succeeded. It owns the underlying [`GuardrailsSession`]
//! and exposes Stage 2/3/4/5 helpers + an idempotent `end_turn`.

use agent_shield_core::{GuardrailsSession, StageVerdict};

/// A pre-validated turn handle: input has already passed Stage 1,
/// and the host can run Stage 2/3 + Stage 4 + Stage 5 against the
/// held session.
pub struct GuardedTurn {
    session: GuardrailsSession,
    user_input: String,
}

impl GuardedTurn {
    /// Construct a new `GuardedTurn` (used by [`crate::Shield::start_turn`]).
    pub(crate) fn new(session: GuardrailsSession, user_input: String) -> Self {
        Self {
            session,
            user_input,
        }
    }

    /// Borrow the underlying session.
    pub fn session(&self) -> &GuardrailsSession {
        &self.session
    }

    /// The user input that passed Stage 1.
    pub fn user_input(&self) -> &str {
        &self.user_input
    }

    /// Stage 2+3 — validate a tool call. `params` is mutated in place
    /// if a Stage 3 transform applies. `tool_call_id` is REQUIRED per
    /// spec §16.0; pair the same id with the matching
    /// [`Self::validate_tool_output`].
    pub fn validate_tool_call(
        &self,
        tool: &str,
        params: &mut serde_json::Value,
        tool_call_id: &str,
    ) -> StageVerdict {
        self.session.validate_tool_call(tool, params, tool_call_id)
    }

    /// Stage 4 — validate tool output. `result` is mutated in place
    /// if a `redact` transform applies. `tool_call_id` MUST match the
    /// id passed to the paired [`Self::validate_tool_call`] (§16.0).
    pub fn validate_tool_output(
        &self,
        tool: &str,
        result: &mut serde_json::Value,
        tool_call_id: &str,
    ) -> StageVerdict {
        self.session
            .validate_tool_output(tool, result, tool_call_id)
    }

    /// Stage 5 — validate the final assistant response. `response` is
    /// mutated in place for `redact` / `append` / `prepend` actions.
    pub fn validate_output(&self, response: &mut String) -> StageVerdict {
        self.session.validate_output(response)
    }

    /// End the turn. Idempotent.
    pub fn end_turn(&self) {
        if let Err(e) = self.session.end_turn() {
            log::warn!(target: "agent_shield::facade", "end_turn failed: {e:?}");
        }
    }
}

impl Drop for GuardedTurn {
    /// Ensures `turn.end` is emitted even if the host forgets to call
    /// [`GuardedTurn::end_turn`] explicitly. `end_turn` is idempotent
    /// (§21), so an explicit call followed by Drop is safe.
    fn drop(&mut self) {
        if let Err(e) = self.session.end_turn() {
            log::warn!(target: "agent_shield::facade", "end_turn (Drop) failed: {e:?}");
        }
    }
}
