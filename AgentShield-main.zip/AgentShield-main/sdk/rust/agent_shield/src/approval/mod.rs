//! Bundled `kind: human` resolver providers.
//!
//! Re-exported from [`agent_shield_core::approval`] so customers can
//! continue importing them via `agent_shield::approval::*`. The
//! handlers themselves live in core, where they're auto-registered
//! into the `HumanRegistry` from YAML by [`agent_shield_core::runtime::RuntimeBuilder::build`]
//! (host-supplied registrations always win).
//!
//! See the core module for usage and YAML examples.

pub use agent_shield_core::approval::{
    bundled_handler, AutoRejectHandler, CallbackApprovalHandler, ConsoleApprovalHandler,
    HumanRegistry, HumanResolveRequest, HumanResolver, HumanResolverFn, PromptReader,
    ResolverDecision, ResolverResponse, StdinPromptReader, BUNDLED_PROVIDER_NAMES,
};

/// Console-handler submodule re-export — kept so existing imports
/// like `agent_shield::approval::console::ScriptedReader` continue to
/// work. Everything inside is in [`agent_shield_core::approval::console`].
pub use agent_shield_core::approval::console;
