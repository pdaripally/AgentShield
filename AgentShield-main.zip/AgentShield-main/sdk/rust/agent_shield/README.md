# Agent Shield — Rust SDK

Rust SDK for [Agent Shield](https://github.com/microsoft/AgentShield), an open specification and reference implementation for runtime security controls on AI agents. Loads a [`.guardrails.yaml`](../../../spec/SPECIFICATION.md) contract and enforces it across **5 validation stages** (Input → State → Tool execution → Post-tool → Output).

## Crates

| Crate | What it does |
|---|---|
| `agent_shield_core` | Reference engine: parser / evaluator, lifetime tracker, event bus, resolver runtime, guard-policy engine, observability. All other SDKs (Python, Node, .NET) wrap this via FFI. |
| `agent_shield` | Ergonomic Rust facade — `Shield` builder + bundled approval handlers + observability providers + per-stage helpers. |
| `agent_shield_openai` | Adapter for [`async-openai`](https://crates.io/crates/async-openai). |
| `agent_shield_anthropic` | Adapter for [`anthropic-sdk-rust`](https://crates.io/crates/anthropic-sdk). |
| `agent_shield_rig` | Adapter for [`rig-core`](https://crates.io/crates/rig-core) — the only production-viable Rust agent framework as of 2025. |
| `agent_shield_langchain` | Adapter for [`langchain-rust`](https://crates.io/crates/langchain-rust). |
| `agent_shield_mcp` | Adapter for the Model Context Protocol. |

## Install

This repo does not publish to crates.io — consume via git tag (see [`RELEASING.md`](../../../RELEASING.md)):

```toml
[dependencies]
agent_shield = { git = "https://github.com/microsoft/AgentShield", tag = "v<version>" }
# Add adapter crates as needed:
agent_shield_rig = { git = "https://github.com/microsoft/AgentShield", tag = "v<version>" }
```

## Quick start

```rust
use agent_shield::Shield;

#[tokio::main]
async fn main() -> Result<(), agent_shield::ShieldError> {
    let shield = Shield::from_yaml("guardrails.yaml").build()?;

    // Pattern C — Stage 1 + Stage 5 around an opaque agent thunk:
    let answer = shield.guarded_run("hello", |input| async move {
        // your model call here
        Ok::<_, agent_shield::ShieldError>(format!("you said: {input}"))
    }).await?;

    println!("{answer}");
    Ok(())
}
```

## Three integration patterns

The same conceptual model — **Patterns A / B / C** — applies across all four AgentShield SDKs (Python, Node, Rust, .NET); the *implementation shape* matches each ecosystem's idiomatic middleware surface. In Rust, that means:

### Pattern A — Guard the agent loop (full coverage)

For [`rig`](https://crates.io/crates/rig-core)-based agents, AgentShield provides a [`PromptHook`](https://docs.rs/rig-core/latest/rig/agent/trait.PromptHook.html) implementation that gates every model call and tool invocation:

```rust
use agent_shield::Shield;
use agent_shield_rig::ShieldHook;
use rig::{providers::openai, agent::PromptRequest};

let shield = Shield::from_yaml("guardrails.yaml").build()?;
let hook = ShieldHook::new(shield.runtime().clone());

let agent = openai::Client::from_env().agent("gpt-4o-mini").build();
let answer = PromptRequest::new(&agent, "user message")
    .with_hook(hook)
    .send().await?;
```

> **Coverage caveat for `rig`**: rig's `ToolCallHookAction` enum has no `Replace { args }` variant ([upstream issue 1744](https://github.com/0xPlaygrounds/rig/issues/1744)). Stage 3 mutated arguments cannot flow through the hook surface — for full Stage-3 coverage, use Pattern B below (`RigToolWrapper`).

### Pattern B — Protect individual tools

The full-coverage path for `rig` (and any framework whose hook surface lacks arg mutation). Wrap each tool before constructing the agent:

```rust
use agent_shield::Shield;
use agent_shield_rig::{ShieldRigExt, RigToolWrapper};

let shield = Shield::from_yaml("guardrails.yaml")
    .with_rig_full_coverage()   // promotes capability report to Full
    .build()?;

let guarded_tools: Vec<_> = shield.protect_tools::<RigToolWrapper>(my_tools);
let agent = openai::Client::from_env()
    .agent("gpt-4o-mini")
    .tools(guarded_tools)
    .build();
```

### Pattern C — Stage 1 + 5 boundary (opaque loops)

For raw `async-openai` / `anthropic-sdk-rust` HTTP clients (which don't have agent-loop frameworks). Wrap your call site in `Shield::guarded_run` and wrap individual tool calls with `Shield::protect_tool`:

```rust
use agent_shield::Shield;

let shield = Shield::from_yaml("guardrails.yaml").build()?;

let answer = shield.guarded_run("user message", |input| async move {
    // your model call + custom loop here
    let result = client.chat(...).await?;
    Ok(result)
}).await?;

// And for individual tool calls inside the loop:
let safe = shield.protect_tool("send_email", &mut params, |params| async move {
    actually_send(params).await
}).await?;
```

## YAML auto-wiring

YAML configurations drive everything; no host code needed for the common case:

- **Bundled `kind: human` providers** — `provider: auto_reject` / `provider: deny` / `provider: console` work out of the box.
- **LLM clients** — `configurations: - {id, type: llm, provider, model, api_key_env}` auto-wire HTTP-based callers.
- **Classifiers** — `configurations: - {id, type: classifier, provider: lakera_guard | llama_guard | openai_moderation | perspective | aacs}` auto-wire HTTP-based callers (gated by Cargo features).

## Observability

`Shield::with_observability(ConsoleObservabilityProvider::new())` registers a console provider. Every emitted event carries [OpenTelemetry GenAI semantic-convention](https://opentelemetry.io/docs/specs/semconv/gen-ai/) attributes (`gen_ai.system="agent_shield"`, `gen_ai.operation.name="guard.<stage>"`, `gen_ai.response.finish_reason="content_filter"` on blocks), so any OTel exporter (Phoenix, Logfire, Honeycomb, Azure Monitor) sees AgentShield events with the same shape it sees LangChain / OpenAI / Anthropic telemetry.

For cloud backends:

```toml
agent_shield = { git = "...", tag = "v<version>", features = ["otel"] }            # OpenTelemetry SDK
agent_shield = { git = "...", tag = "v<version>", features = ["azure-monitor"] }   # Azure Monitor
agent_shield = { git = "...", tag = "v<version>", features = ["cloudwatch"] }      # AWS CloudWatch
```

## Testing locally

```sh
# Core
cd sdk/rust/agent_shield_core && cargo test --all-features

# Facade
cd sdk/rust/agent_shield && cargo test --all-features

# Per-adapter
cd sdk/rust/agent_shield_rig && cargo test
```

## More

- [Specification](../../../spec/SPECIFICATION.md) — the source of truth for `.guardrails.yaml` semantics.
- [Expression-language reference](../../../spec/expressions/LANGUAGE.md).
- [Examples](../../../examples/) — bank-manager, sensitive-documents, IFC, ask-human MCP server.
