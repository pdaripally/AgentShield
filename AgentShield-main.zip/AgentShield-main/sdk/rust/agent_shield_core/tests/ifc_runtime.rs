//! End-to-end IFC runtime tests on the **tag-set** algebra.
//!
//! Covers the lattice runtime's three core invariants under the
//! tag-set primitive (proof: `docs/information-flow-control-proof.md`,
//! design: `docs/information-flow-control.md`):
//!
//! 1. **Monotonic raise** — every recorded read unions `λ(source)` into
//!    the running exposure; the exposure can only stay or rise within
//!    a scope (proof Lemma 1).
//!
//! 2. **Egress check** — `Eₙ ⊆ μ(sink)` is verified before allowing a
//!    Stage-3 call or a Stage-5 output emission (proof Theorem 1
//!    Case A / Case B); failures produce a `<ifc>` deny verdict.
//!
//! 3. **Scope reset** — `per_session` keeps the exposure across turns;
//!    `per_turn` and `per_request` reset on the matching boundary
//!    *only when the host advertises `supports_context_reset`* (proof
//!    TC-3); otherwise the configuration is rejected at build time.
//!
//! Plus: TC-7 (unsafe-flag for admit-all default), TC-8 (μ ⊆ ν),
//! TC-9 (λ ⊆ ν), strict mode, host-capability gating, declassify_to
//! action verb, IFC audit events.

use agent_shield_core::loader::load_from_str;
use agent_shield_core::runtime::{builder::RuntimeBuilder, request_context::RequestContext};
use serde_json::Value;

fn rt(yaml: &str) -> std::sync::Arc<agent_shield_core::runtime::runtime::GuardrailsRuntime> {
    let merged = load_from_str(yaml).expect("yaml loads");
    RuntimeBuilder::from_config(merged)
        .build()
        .expect("runtime builds")
}

fn rt_with_reset(
    yaml: &str,
) -> std::sync::Arc<agent_shield_core::runtime::runtime::GuardrailsRuntime> {
    let merged = load_from_str(yaml).expect("yaml loads");
    RuntimeBuilder::from_config(merged)
        .supports_context_reset(true)
        .build()
        .expect("runtime builds")
}

fn ctx() -> RequestContext {
    RequestContext::new("sess-1", "corr-1")
}

const PII_FINANCIAL_YAML: &str = r#"
metadata:
  name: "tagset-runtime-test"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
  forbidden: ["never"]
ifc:
  tags: [pii, financial, internal]
  strict: false
  default_audience: ["*"]
  default_clearance: ["*"]
  unsafe_default_clearance_top: true
  user_input_tags: []
  user_output_clearance: ["*"]
resources:
  tools:
    - name: read_customer_balance
      tags: [pii, financial]
      audience: ["*"]
      clearance: ["*"]
    - name: write_audit_log
      tags: []
      clearance: [pii, financial, internal]
      audience: [pii, financial, internal]
    - name: send_email_external
      tags: []
      clearance: []
      audience: []
"#;

#[test]
fn no_ifc_block_means_every_check_passes() {
    let yaml = r#"
metadata:
  name: "no-lattice"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
  forbidden: ["never"]
resources:
  tools:
    - name: t1
"#;
    let r = rt(yaml);
    let s = r.new_session(ctx());
    assert!(s.validate_input("hi").allowed);
    let mut p = Value::Null;
    assert!(s.validate_tool_call("t1", &mut p, "call_1").allowed);
    let mut out = "ok".to_string();
    assert!(s.validate_output(&mut out).allowed);
}

#[test]
fn read_pii_then_email_external_is_denied() {
    let r = rt(PII_FINANCIAL_YAML);
    let s = r.new_session(ctx());
    s.record_tool_success("read_customer_balance", &Value::Null)
        .unwrap();
    let exposure = s.current_exposure();
    assert!(!exposure.is_empty(), "exposure raised after read");

    let mut params = Value::Null;
    let v = s.validate_tool_call("send_email_external", &mut params, "call_1");
    assert!(!v.allowed, "egress to public sink must deny");
    let reason = v.reason.as_deref().unwrap_or("");
    assert!(reason.starts_with("ifc:"), "got: {reason}");
    assert!(
        reason.contains("send_email_external") && reason.contains("pii"),
        "got: {reason}"
    );
    assert_eq!(v.policy.as_deref(), Some("<ifc>"));
}

#[test]
fn read_pii_then_audit_log_is_admitted() {
    let r = rt(PII_FINANCIAL_YAML);
    let s = r.new_session(ctx());
    s.record_tool_success("read_customer_balance", &Value::Null)
        .unwrap();

    let mut params = Value::Null;
    let v = s.validate_tool_call("write_audit_log", &mut params, "call_1");
    assert!(v.allowed, "audit-log clearance accepts pii+financial");
}

#[test]
fn output_validation_denies_when_exposure_exceeds_user_clearance() {
    // user_output_clearance = ["*"] above admits everything, so we
    // need a tighter local config to test denial.
    let yaml = r#"
metadata:
  name: "out-deny"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
  forbidden: ["never"]
ifc:
  tags: [pii]
  strict: false
  default_clearance: ["*"]
  default_audience: ["*"]
  unsafe_default_clearance_top: true
  user_output_clearance: []
resources:
  tools:
    - name: read_pii
      tags: [pii]
      audience: ["*"]
      clearance: ["*"]
"#;
    let r = rt(yaml);
    let s = r.new_session(ctx());
    s.record_tool_success("read_pii", &Value::Null).unwrap();

    let mut response = "the answer".to_string();
    let v = s.validate_output(&mut response);
    assert!(!v.allowed);
    let reason = v.reason.as_deref().unwrap_or("");
    assert!(reason.starts_with("ifc:"));
    assert!(reason.contains("output"));
}

#[test]
fn per_session_scope_does_not_reset_across_turns() {
    let r = rt(PII_FINANCIAL_YAML);
    let s = r.new_session(ctx());
    s.begin_turn().unwrap();
    s.record_tool_success("read_customer_balance", &Value::Null)
        .unwrap();
    let after_read = s.current_exposure();
    s.end_turn().unwrap();
    assert_eq!(
        s.current_exposure(),
        after_read,
        "per_session keeps exposure across turn boundary"
    );
}

#[test]
fn per_turn_scope_requires_host_capability() {
    let yaml = r#"
metadata:
  name: "per-turn-no-capability"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
  forbidden: ["never"]
ifc:
  tags: [pii]
  scope: per_turn
  strict: false
"#;
    let merged = load_from_str(yaml).expect("yaml loads");
    let result = RuntimeBuilder::from_config(merged).build();
    assert!(
        result.is_err(),
        "per_turn without supports_context_reset must reject"
    );
    let err = format!("{:?}", result.err().unwrap());
    assert!(err.contains("supports_context_reset"), "got: {err}");
    assert!(err.contains("TC-3"), "got: {err}");
}

#[test]
fn per_turn_scope_resets_when_capability_advertised() {
    let yaml = r#"
metadata:
  name: "per-turn-with-capability"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
  forbidden: ["never"]
ifc:
  tags: [pii]
  scope: per_turn
  strict: false
  default_clearance: ["*"]
  default_audience: ["*"]
  unsafe_default_clearance_top: true
resources:
  tools:
    - name: read_pii
      tags: [pii]
      audience: ["*"]
      clearance: ["*"]
"#;
    let r = rt_with_reset(yaml);
    let s = r.new_session(ctx());
    s.begin_turn().unwrap();
    s.record_tool_success("read_pii", &Value::Null).unwrap();
    assert!(!s.current_exposure().is_empty());
    s.end_turn().unwrap();
    assert!(
        s.current_exposure().is_empty(),
        "per_turn + capability resets exposure to ⊥"
    );
}

#[test]
fn tc7_admit_all_default_clearance_requires_unsafe_flag() {
    let yaml = r#"
metadata:
  name: "unsafe-default"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
  forbidden: ["never"]
ifc:
  tags: [pii]
  default_clearance: ["*"]
"#;
    let err = load_from_str(yaml).unwrap_err();
    let s = format!("{err:?}");
    assert!(s.contains("unsafe_default_clearance_top"), "got: {s}");
}

#[test]
fn tc8_clearance_must_be_subset_of_audience() {
    let yaml = r#"
metadata:
  name: "tc8"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
  forbidden: ["never"]
ifc:
  tags: [pii, internal]
  strict: false
resources:
  tools:
    - name: leaky_external
      clearance: [pii]
      audience: []
"#;
    let err = load_from_str(yaml).unwrap_err();
    let s = format!("{err:?}");
    assert!(s.contains("TC-8"), "got: {s}");
    assert!(s.contains("clearance"));
    assert!(s.contains("audience"));
}

#[test]
fn tc9_tags_must_be_subset_of_audience() {
    let yaml = r#"
metadata:
  name: "tc9"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
  forbidden: ["never"]
ifc:
  tags: [pii, internal]
  strict: false
resources:
  tools:
    - name: leaky_source
      tags: [pii]
      audience: []
"#;
    let err = load_from_str(yaml).unwrap_err();
    let s = format!("{err:?}");
    assert!(s.contains("TC-9"), "got: {s}");
}

#[test]
fn strict_mode_rejects_resource_without_tags() {
    let yaml = r#"
metadata:
  name: "strict"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
  forbidden: ["never"]
ifc:
  tags: [pii]
  default_audience: ["*"]
resources:
  tools:
    - name: untagged
"#;
    let err = load_from_str(yaml).unwrap_err();
    let s = format!("{err:?}");
    assert!(s.contains("missing `tags:`"), "got: {s}");
}

#[test]
fn lenient_mode_accepts_resource_without_tags() {
    let yaml = r#"
metadata:
  name: "lenient"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
  forbidden: ["never"]
ifc:
  tags: [pii]
  strict: false
  default_audience: ["*"]
resources:
  tools:
    - name: untagged
"#;
    let r = rt(yaml);
    let s = r.new_session(ctx());
    s.record_tool_success("untagged", &Value::Null).unwrap();
    assert!(s.current_exposure().is_empty(), "no tags → no raise");
}

#[test]
fn unknown_tag_in_resource_is_load_time_error() {
    let yaml = r#"
metadata:
  name: "typo"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
  forbidden: ["never"]
ifc:
  tags: [pii]
  strict: false
  default_audience: ["*"]
resources:
  tools:
    - name: typo
      tags: [sekret]
"#;
    let err = load_from_str(yaml).unwrap_err();
    let s = format!("{err:?}");
    assert!(s.contains("not declared in ifc.tags"), "got: {s}");
}

#[test]
fn ifc_block_is_required_when_resources_use_ifc_fields() {
    let yaml = r#"
metadata:
  name: "no-ifc-block"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
  forbidden: ["never"]
resources:
  tools:
    - name: tagged
      tags: [pii]
"#;
    let err = load_from_str(yaml).unwrap_err();
    let s = format!("{err:?}");
    assert!(s.contains("no top-level `ifc:`"), "got: {s}");
}

#[test]
fn declassify_to_lowers_exposure_on_state_admit() {
    let yaml = r#"
metadata:
  name: "declassify"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
  forbidden: ["never"]
ifc:
  tags: [pii, financial]
  strict: false
  default_clearance: ["*"]
  default_audience: ["*"]
  unsafe_default_clearance_top: true
resources:
  tools:
    - name: read_pii
      tags: [pii]
      audience: ["*"]
      clearance: ["*"]
state_validation:
  guard_policies:
    - name: end_of_turn_release
      active_if: "true"
      applies_to:
        tools: ["read_pii"]
      evaluate_when:
        - expression: "false"
          reason: "release at named boundary"
          action: declassify_to
          declassify_target: []
"#;
    let r = rt(yaml);
    let s = r.new_session(ctx());
    s.record_tool_success("read_pii", &Value::Null).unwrap();
    assert!(!s.current_exposure().is_empty(), "exposure raised");

    // Trigger state validation; the declassify_to action fires and
    // lowers exposure to ∅.
    let invocation = agent_shield_core::populator::Invocation::tool("read_pii", Value::Null);
    let v = s.validate_state(&invocation);
    assert!(v.allowed);
    assert!(
        s.current_exposure().is_empty(),
        "declassify_to ∅ lowered exposure"
    );
}

#[test]
fn declassify_target_only_with_declassify_to_action() {
    let yaml = r#"
metadata:
  name: "wrong-action"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
  forbidden: ["never"]
ifc:
  tags: [pii]
  strict: false
  default_audience: ["*"]
state_validation:
  guard_policies:
    - name: bad
      applies_to:
        tools: ["x"]
      evaluate_when:
        - expression: "true"
          reason: "x"
          action: block
          declassify_target: [pii]
"#;
    let err = load_from_str(yaml).unwrap_err();
    let s = format!("{err:?}");
    assert!(s.contains("only meaningful with"), "got: {s}");
}

#[test]
fn ifc_audit_events_emitted_on_raise_and_deny() {
    use std::sync::{Arc, Mutex};

    let yaml = PII_FINANCIAL_YAML;
    let merged = load_from_str(yaml).expect("yaml loads");
    let captured: Arc<Mutex<Vec<String>>> = Arc::new(Mutex::new(Vec::new()));
    let captured_for_provider = captured.clone();

    struct CapturingProvider {
        events: Arc<Mutex<Vec<String>>>,
    }
    impl agent_shield_core::observability::ObservabilityProvider for CapturingProvider {
        fn emit(&self, ev: agent_shield_core::observability::ShieldLogEvent) {
            if let Some(id) = ev.event_id {
                let _ = self.events.lock().map(|mut g| g.push(id));
            }
        }
    }

    let r = RuntimeBuilder::from_config(merged)
        .register_provider(Arc::new(CapturingProvider {
            events: captured_for_provider,
        }))
        .build()
        .unwrap();

    let s = r.new_session(ctx());
    s.record_tool_success("read_customer_balance", &Value::Null)
        .unwrap();

    let mut params = Value::Null;
    let v = s.validate_tool_call("send_email_external", &mut params, "call_1");
    assert!(!v.allowed);
    drop(s);

    let events = captured.lock().unwrap();
    let ids: Vec<&str> = events.iter().map(String::as_str).collect();
    assert!(
        ids.iter().any(|e| *e == "ifc.exposure_raised"),
        "ifc.exposure_raised not emitted; got events: {ids:?}"
    );
    assert!(
        ids.iter().any(|e| *e == "ifc.egress_denied"),
        "ifc.egress_denied not emitted; got events: {ids:?}"
    );
}
