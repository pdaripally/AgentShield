//! Concurrent observability emission regression test.
//!
//! Locks in the `CLogProvider` concurrency contract documented in
//! `sdk/rust/agent_shield_core/src/ffi.rs`: the registered
//! [`ObservabilityProvider`](agent_shield_core::ObservabilityProvider)
//! must tolerate concurrent invocation from multiple threads when more
//! than one [`GuardrailsSession`](agent_shield_core::GuardrailsSession)
//! is driven against the same
//! [`GuardrailsRuntime`](agent_shield_core::GuardrailsRuntime).
//!
//! Both `cargo test --test observability_concurrent` and
//! `cargo test --test observability_concurrent -- --test-threads=1`
//! must pass — the runtime itself is required to behave the same way
//! regardless of the harness's threading strategy.
//!
//! Spec references:
//! - §19 (observability)
//! - §6.5 / §19.3 (single dispatcher shared across sessions)

use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, Barrier, Mutex};
use std::thread;

use agent_shield_core::{
    load_from_str, ObservabilityProvider, RequestContext, RuntimeBuilder, ShieldLogEvent,
};

/// Stage-5 (output) guard policy that fires on every emission so each
/// `validate_output` call generates at least one log event.
const STAGE5_BLOCK_YAML: &str = r#"
metadata:
  name: "obs-concurrent-stage5"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["redact ssn"]
  forbidden: ["leak"]
resources:
  tools:
    - name: "noop"
      description: "noop"
      permission: "read_only"
output_validation:
  guard_policies:
    - name: "scrub_ssn"
      evaluate_when:
        - pattern: "\\d{3}-\\d{2}-\\d{4}"
          reason: "SSN detected"
      action: "redact"
      replacement: "[REDACTED]"
"#;

/// Capturing provider that counts emissions atomically AND stores the
/// full payloads under a `Mutex` so the test can inspect them after
/// joining. The atomic counter is the primary load-bearing assertion;
/// the mutexed buffer is a secondary correctness probe.
struct ConcurrentCaptureProvider {
    counter: AtomicUsize,
    events: Mutex<Vec<ShieldLogEvent>>,
}

impl ConcurrentCaptureProvider {
    fn new() -> Self {
        Self {
            counter: AtomicUsize::new(0),
            events: Mutex::new(Vec::new()),
        }
    }
}

impl ObservabilityProvider for ConcurrentCaptureProvider {
    fn emit(&self, event: ShieldLogEvent) {
        self.counter.fetch_add(1, Ordering::SeqCst);
        self.events.lock().unwrap().push(event);
    }
}

const EVENTS_PER_THREAD: usize = 32;

/// Drive two sessions on one runtime from two concurrent threads, each
/// running a tight loop of `validate_output` calls, and assert:
///
///   1. The provider observed *at least* `EVENTS_PER_THREAD * 2` events.
///      (Each `validate_output` produces one or more log events; the
///      session lifecycle adds a few more. We assert the lower bound so
///      the test does not become brittle to spec-compliant emission
///      additions.)
///   2. The atomic counter and the `Mutex<Vec<_>>` buffer agree — any
///      drift would indicate a torn write, a dropped event, or a
///      reordering of the increment vs. the push.
///   3. Every captured event round-trips through serde without error
///      and carries a non-empty `category` — proving no event payload
///      was corrupted by the concurrent emit path. (The concurrent
///      dispatcher holds providers behind a `Mutex`, but the events
///      themselves are cloned per provider; this check pins the
///      invariant that the clone path is sound.)
///   4. Both `sess-a` and `sess-b` appear as `session_id` values in
///      the captured events. Spec §19.2 makes `session_id` a required
///      top-level field on every log event; this assertion pins the
///      bus → log mirror and direct-emit emitter helpers to propagate
///      the originating session.
#[test]
fn provider_handles_concurrent_emissions_from_two_sessions() {
    let cap = Arc::new(ConcurrentCaptureProvider::new());

    let cfg = load_from_str(STAGE5_BLOCK_YAML).expect("yaml parses");
    let rt = RuntimeBuilder::from_config(cfg)
        .register_provider(cap.clone())
        .build()
        .expect("runtime builds");

    let sess_a = rt.new_session(RequestContext::new("sess-a", "corr-a"));
    let sess_b = rt.new_session(RequestContext::new("sess-b", "corr-b"));

    let barrier = Arc::new(Barrier::new(2));
    let cap_for_assertion = cap.clone();

    let barrier_a = barrier.clone();
    let handle_a = thread::spawn(move || {
        barrier_a.wait();
        for i in 0..EVENTS_PER_THREAD {
            let mut payload = format!("response from thread a iteration {i} 111-22-3333");
            let _ = sess_a.validate_output(&mut payload);
        }
    });

    let barrier_b = barrier.clone();
    let handle_b = thread::spawn(move || {
        barrier_b.wait();
        for i in 0..EVENTS_PER_THREAD {
            let mut payload = format!("response from thread b iteration {i} 444-55-6666");
            let _ = sess_b.validate_output(&mut payload);
        }
    });

    handle_a.join().expect("thread a joined");
    handle_b.join().expect("thread b joined");

    // (1) Lower-bound emission count.
    let total = cap_for_assertion.counter.load(Ordering::SeqCst);
    assert!(
        total >= EVENTS_PER_THREAD * 2,
        "expected at least {} concurrent emissions, observed {total}",
        EVENTS_PER_THREAD * 2,
    );

    let events = cap_for_assertion.events.lock().unwrap();
    assert_eq!(
        events.len(),
        total,
        "atomic counter and Mutex<Vec<_>> must agree — any drift indicates a torn write or a dropped event"
    );

    // (2) No torn / partial payloads — every event carries the
    //     spec-defined typed fields. `session_id` is allowed to be
    //     empty for runtime-level emissions that occur outside a
    //     session context; what we need to guarantee is that the
    //     payload itself was not corrupted by the concurrent emit
    //     path (i.e. `category` and the typed enum discriminants are
    //     well-formed serde values).
    for e in events.iter() {
        assert!(
            !e.category.is_empty(),
            "every emitted event must carry a non-empty category (spec §19.2)"
        );
        // Round-trip through JSON proves the discriminant fields are
        // not torn (an interleaved write would surface as a serde
        // error here).
        let json = serde_json::to_string(e).expect("event round-trips through serde");
        let _back: ShieldLogEvent = serde_json::from_str(&json).expect("event re-parses cleanly");
    }

    // (3) Both sessions reached the shared provider. Spec §19.2 makes
    //     `session_id` a required top-level field on every log event;
    //     since each thread drove a distinct session, both ids MUST
    //     appear in the captured stream. (Runtime-level emissions
    //     without a session context — load errors etc. — produce
    //     empty `session_id`; the assertion is positive-only, not
    //     "session_id is non-empty for every event".)
    let session_ids: std::collections::HashSet<&str> =
        events.iter().map(|e| e.session_id.as_str()).collect();
    assert!(
        session_ids.contains("sess-a"),
        "expected `sess-a` in captured session_ids, got {:?}",
        session_ids
    );
    assert!(
        session_ids.contains("sess-b"),
        "expected `sess-b` in captured session_ids, got {:?}",
        session_ids
    );
}
