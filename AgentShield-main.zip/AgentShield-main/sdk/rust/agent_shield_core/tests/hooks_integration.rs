//! Integration tests for [`agent_shield_core::integrations::hooks`].
//!
//! Covers:
//! - `SessionRegistry::acquire` cache hit / cache miss.
//! - Lease counter blocks eviction.
//! - LRU eviction (respects held + just-inserted entries).
//! - `HookSession::begin_turn` idempotency + `restart_turn`.
//! - Scratch K/V scoping (cleared on turn boundary).
//! - `begin_request` / `end_request` cross-hook token semantics.
//! - In-flight token stale recovery.
//! - `StageDispatcher` Stages 1/2-3/4/5 + monitor mode.
//!
//! Async serialization of concurrent hook callbacks for the same
//! session is intentionally a host-runtime concern (Python
//! `asyncio.Lock`, Node single-threaded event loop); the core does
//! not own that lock. The eviction-protection lease counter is the
//! only synchronisation primitive the registry uses internally.

use std::sync::Arc;
use std::time::Duration;

use agent_shield_core::integrations::hooks::{
    ConcurrencyError, RegistryOptions, RequestStateError, SessionRegistry, StageDispatcher,
};
use agent_shield_core::shield_primitives::{
    DispatchAction, OnBlockPolicy, ShieldMode, ToolDispatchAction,
};
use agent_shield_core::{load_from_str, GuardrailsRuntime, RequestContext, RuntimeBuilder};
use serde_json::json;

// ── Fixtures ───────────────────────────────────────────────────────

fn minimal_yaml() -> &'static str {
    r#"
metadata:
  name: "hooks-test"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "echo"
      description: "Echo tool."
      permission: "read_only"
"#
}

/// YAML with one input-stage policy that blocks when the input
/// contains the literal token `"FORBIDDEN"`.
fn blocking_input_yaml() -> &'static str {
    r#"
metadata:
  name: "hooks-test-input-block"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
  forbidden: ["containing FORBIDDEN"]
resources:
  tools:
    - name: "echo"
      description: "Echo tool."
      permission: "read_only"
input_validation:
  guard_policies:
    - name: "reject_forbidden_input"
      action: "block"
      evaluate_when:
        - patterns:
            - "FORBIDDEN"
          reason: "Input contained FORBIDDEN."
"#
}

fn build_runtime(yaml: &str) -> Arc<GuardrailsRuntime> {
    let cfg = load_from_str(yaml).expect("valid yaml");
    RuntimeBuilder::from_config(cfg).build().expect("build")
}

fn ctx(sess: &str) -> RequestContext {
    RequestContext::new(sess, format!("corr-{sess}"))
}

// ── Registry ───────────────────────────────────────────────────────

#[test]
fn registry_cache_hit_returns_same_session() {
    let rt = build_runtime(minimal_yaml());
    let reg = SessionRegistry::new(rt, RegistryOptions::default());

    let lease1 = reg.acquire("sess-A", ctx("sess-A")).unwrap();
    let session_ptr_1 = Arc::as_ptr(lease1.session()) as usize;
    drop(lease1);

    let lease2 = reg.acquire("sess-A", ctx("sess-A")).unwrap();
    let session_ptr_2 = Arc::as_ptr(lease2.session()) as usize;

    assert_eq!(
        session_ptr_1, session_ptr_2,
        "cache hit must return the same HookSession"
    );
}

#[test]
fn registry_different_session_ids_get_distinct_entries() {
    let rt = build_runtime(minimal_yaml());
    let reg = SessionRegistry::new(rt, RegistryOptions::default());

    let lease_a = reg.acquire("sess-A", ctx("sess-A")).unwrap();
    let lease_b = reg.acquire("sess-B", ctx("sess-B")).unwrap();
    assert_ne!(
        Arc::as_ptr(lease_a.session()) as usize,
        Arc::as_ptr(lease_b.session()) as usize,
    );
    assert_eq!(reg.len(), 2);
}

#[test]
fn registry_lru_eviction_when_over_capacity() {
    let rt = build_runtime(minimal_yaml());
    let opts = RegistryOptions {
        max_size: 2,
        ttl: Duration::ZERO,
        in_flight_timeout: Duration::from_secs(60),
    };
    let reg = SessionRegistry::new(rt, opts);

    // Fill capacity. Drop leases so entries become evictable.
    drop(reg.acquire("A", ctx("A")).unwrap());
    drop(reg.acquire("B", ctx("B")).unwrap());
    assert_eq!(reg.len(), 2);

    // Add a third — A is LRU, gets evicted.
    drop(reg.acquire("C", ctx("C")).unwrap());
    assert_eq!(reg.len(), 2, "registry stays at capacity after eviction");
}

#[test]
fn registry_eviction_skips_held_entries() {
    let rt = build_runtime(minimal_yaml());
    let opts = RegistryOptions {
        max_size: 2,
        ttl: Duration::ZERO,
        in_flight_timeout: Duration::from_secs(60),
    };
    let reg = SessionRegistry::new(rt, opts);

    let lease_a = reg.acquire("A", ctx("A")).unwrap();
    drop(reg.acquire("B", ctx("B")).unwrap());
    assert_eq!(reg.len(), 2);

    // The held entry A must be skipped; B (next-oldest, unheld) is
    // evicted instead.
    let _lease_c = reg.acquire("C", ctx("C")).unwrap();
    drop(lease_a);
    // Reaching A again on a fresh acquire must be a cache hit.
    let lease_a2 = reg.acquire("A", ctx("A")).unwrap();
    assert!(reg.len() <= 2);
    drop(lease_a2);
}

#[test]
fn registry_lease_counter_is_visible_inside_critical_section() {
    // Regression test: the lease counter MUST be bumped inside the
    // registry state mutex so a concurrent acquire on a different
    // session id can't evict an entry between its lookup and its
    // counter increment. We can't directly test the inside-mutex
    // property from outside the type, but we can verify the
    // observable invariant: a freshly-built entry, returned from
    // acquire, always reports active_holders >= 1.
    let rt = build_runtime(minimal_yaml());
    let opts = RegistryOptions {
        max_size: 1,
        ttl: Duration::ZERO,
        in_flight_timeout: Duration::from_secs(60),
    };
    let reg = SessionRegistry::new(rt, opts);
    let lease = reg.acquire("A", ctx("A")).unwrap();
    // If the bump-after-mutex bug were present, another acquire on
    // the same registry with a different id would evict "A" (max_size
    // is 1) BEFORE the counter is bumped. Verify that even at
    // max_size=1 with eviction pressure, the original lease's
    // session reference stays valid.
    let _ = reg.acquire("B", ctx("B")).unwrap();
    // Use the original lease to drive a turn — must not have been
    // evicted out from under us.
    lease.begin_turn().expect("A's session must still be valid");
    assert!(lease.turn_is_open());
}

// ── Turn lifecycle ────────────────────────────────────────────────

#[test]
fn begin_turn_is_idempotent() {
    let rt = build_runtime(minimal_yaml());
    let reg = SessionRegistry::new(rt, RegistryOptions::default());
    let lease = reg.acquire("A", ctx("A")).unwrap();

    lease.begin_turn().expect("first begin_turn");
    lease.begin_turn().expect("idempotent second begin_turn");
    assert!(lease.turn_is_open());
    lease.end_turn().expect("end_turn");
    assert!(!lease.turn_is_open());
}

#[test]
fn restart_turn_clears_scratch() {
    let rt = build_runtime(minimal_yaml());
    let reg = SessionRegistry::new(rt, RegistryOptions::default());
    let lease = reg.acquire("A", ctx("A")).unwrap();

    lease.begin_turn().unwrap();
    lease.turn_kv_set("k", json!("v"));
    assert_eq!(lease.turn_kv_get("k"), Some(json!("v")));

    lease.restart_turn().expect("restart_turn");
    assert_eq!(lease.turn_kv_get("k"), None, "scratch must be cleared");
    assert!(lease.turn_is_open());
}

#[test]
fn scratch_writes_outside_turn_are_silently_dropped() {
    let rt = build_runtime(minimal_yaml());
    let reg = SessionRegistry::new(rt, RegistryOptions::default());
    let lease = reg.acquire("A", ctx("A")).unwrap();

    // No begin_turn — scratch write must not stick.
    assert_eq!(lease.turn_kv_set("k", json!("v")), None);
    assert_eq!(lease.turn_kv_get("k"), None);
}

// ── Request lifecycle ────────────────────────────────────────────

#[test]
fn begin_request_returns_token_and_end_retires_it() {
    let rt = build_runtime(minimal_yaml());
    let reg = SessionRegistry::new(rt, RegistryOptions::default());
    let lease = reg.acquire("A", ctx("A")).unwrap();

    let token = lease.begin_request(None).expect("first begin_request");
    assert!(lease.request_is_open());
    lease.end_request(token).expect("end_request");
    assert!(!lease.request_is_open());
}

#[test]
fn begin_request_rejects_concurrent_when_no_timeout() {
    let rt = build_runtime(minimal_yaml());
    let reg = SessionRegistry::new(rt, RegistryOptions::default());
    let lease = reg.acquire("A", ctx("A")).unwrap();

    let token1 = lease.begin_request(None).unwrap();
    match lease.begin_request(None) {
        Err(ConcurrencyError::AlreadyInFlight { .. }) => {}
        other => panic!("expected AlreadyInFlight, got {:?}", other),
    }
    lease.end_request(token1).unwrap();
}

#[test]
fn stale_token_is_invalidated_by_timeout() {
    let rt = build_runtime(minimal_yaml());
    let reg = SessionRegistry::new(rt, RegistryOptions::default());
    let lease = reg.acquire("A", ctx("A")).unwrap();

    let stale = lease.begin_request(Some(Duration::ZERO)).unwrap();
    // Timeout=0 means any prior token is immediately stale.
    let fresh = lease.begin_request(Some(Duration::ZERO)).unwrap();
    assert_ne!(stale, fresh);

    // Late end_request with the stale token returns Mismatch.
    match lease.end_request(stale) {
        Err(RequestStateError::Mismatch) => {}
        other => panic!("expected Mismatch, got {:?}", other),
    }
    lease
        .end_request(fresh)
        .expect("fresh token retires cleanly");
}

#[test]
fn end_request_with_no_open_request_returns_no_request_open() {
    let rt = build_runtime(minimal_yaml());
    let reg = SessionRegistry::new(rt, RegistryOptions::default());
    let lease = reg.acquire("A", ctx("A")).unwrap();

    let token = lease.begin_request(None).unwrap();
    lease.end_request(token).unwrap();
    // Second end_request — failure-hook double-call path.
    match lease.end_request(token) {
        Err(RequestStateError::NoRequestOpen) => {}
        other => panic!("expected NoRequestOpen, got {:?}", other),
    }
}

#[test]
fn end_request_token_from_other_session_returns_mismatch() {
    let rt = build_runtime(minimal_yaml());
    let reg = SessionRegistry::new(rt, RegistryOptions::default());

    let token_a = {
        let lease_a = reg.acquire("A", ctx("A")).unwrap();
        lease_a.begin_request(None).unwrap()
    };

    let lease_b = reg.acquire("B", ctx("B")).unwrap();
    // B has no open request — passing A's token to B.end_request
    // gets NoRequestOpen.
    match lease_b.end_request(token_a) {
        Err(RequestStateError::NoRequestOpen) => {}
        other => panic!(
            "expected NoRequestOpen on B (no request open), got {:?}",
            other
        ),
    }
}

// ── Dispatcher: Stage 1 ──────────────────────────────────────────

#[test]
fn dispatcher_validate_input_allows_clean_input() {
    let rt = build_runtime(minimal_yaml());
    let reg = SessionRegistry::new(rt, RegistryOptions::default());
    let lease = reg.acquire("A", ctx("A")).unwrap();
    lease.begin_turn().unwrap();

    let disp = StageDispatcher;
    let result = disp.validate_input(
        &lease,
        "hello world",
        ShieldMode::Enforce,
        OnBlockPolicy::ReturnBlocked,
    );
    assert_eq!(result.dispatch.action, DispatchAction::Proceed);
    assert!(!result.dispatch.record_block);
    assert!(!result.dispatch.override_to_proceed);
}

#[test]
fn dispatcher_validate_input_blocks_forbidden() {
    let rt = build_runtime(blocking_input_yaml());
    let reg = SessionRegistry::new(rt, RegistryOptions::default());
    let lease = reg.acquire("A", ctx("A")).unwrap();
    lease.begin_turn().unwrap();

    let disp = StageDispatcher;
    let result = disp.validate_input(
        &lease,
        "this contains FORBIDDEN content",
        ShieldMode::Enforce,
        OnBlockPolicy::ReturnBlocked,
    );
    assert!(matches!(
        result.dispatch.action,
        DispatchAction::ReturnBlocked { .. }
    ));
    assert!(result.dispatch.record_block);
    assert!(!result.dispatch.override_to_proceed);
}

#[test]
fn monitor_mode_overrides_block_to_proceed() {
    let rt = build_runtime(blocking_input_yaml());
    let reg = SessionRegistry::new(rt, RegistryOptions::default());
    let lease = reg.acquire("A", ctx("A")).unwrap();
    lease.begin_turn().unwrap();

    let disp = StageDispatcher;
    let result = disp.validate_input(
        &lease,
        "this contains FORBIDDEN content",
        ShieldMode::Monitor,
        OnBlockPolicy::ReturnBlocked,
    );
    assert!(
        result.dispatch.record_block,
        "monitor mode still records the block"
    );
    assert!(
        result.dispatch.override_to_proceed,
        "monitor mode overrides to proceed"
    );
    assert!(matches!(
        result.dispatch.action,
        DispatchAction::ReturnBlocked { .. }
    ));
}

// ── Dispatcher: Stage 2/3/4 binding ──────────────────────────────

#[test]
fn dispatcher_stage_3_and_4_bind_by_tool_call_id() {
    let rt = build_runtime(minimal_yaml());
    let reg = SessionRegistry::new(rt, RegistryOptions::default());
    let lease = reg.acquire("A", ctx("A")).unwrap();
    lease.begin_turn().unwrap();

    let disp = StageDispatcher;
    let call = disp.validate_tool_call(
        &lease,
        "echo",
        json!({"msg": "hi"}),
        "call-1",
        ShieldMode::Enforce,
        OnBlockPolicy::ReturnBlocked,
    );
    assert_eq!(call.dispatch.action, ToolDispatchAction::Proceed);
    assert!(
        !call.dispatch.record_success,
        "stage 2/3 does not record success"
    );
    assert_eq!(call.effective_params, json!({"msg": "hi"}));

    let output = disp.validate_tool_output(
        &lease,
        "echo",
        json!("hi back"),
        "call-1",
        ShieldMode::Enforce,
        OnBlockPolicy::ReturnBlocked,
    );
    assert_eq!(output.dispatch.action, ToolDispatchAction::Proceed);
    assert!(
        output.dispatch.record_success,
        "stage 4 records success on clean allow"
    );
    assert_eq!(output.effective_output, json!("hi back"));
}

// ── Dispatcher: Stage 5 ──────────────────────────────────────────

#[test]
fn dispatcher_validate_output_allows_clean_output() {
    let rt = build_runtime(minimal_yaml());
    let reg = SessionRegistry::new(rt, RegistryOptions::default());
    let lease = reg.acquire("A", ctx("A")).unwrap();
    lease.begin_turn().unwrap();

    let disp = StageDispatcher;
    let mut content = String::from("clean response");
    let result = disp.validate_output(
        &lease,
        &mut content,
        ShieldMode::Enforce,
        OnBlockPolicy::ReturnBlocked,
    );
    assert_eq!(result.dispatch.action, DispatchAction::Proceed);
}

// ── Resource-cycle pass-throughs ─────────────────────────────────

#[test]
fn record_tool_success_and_failure_pass_through() {
    let rt = build_runtime(minimal_yaml());
    let reg = SessionRegistry::new(rt, RegistryOptions::default());
    let lease = reg.acquire("A", ctx("A")).unwrap();
    lease.begin_turn().unwrap();

    let disp = StageDispatcher;
    let _ = disp.validate_tool_call(
        &lease,
        "echo",
        json!({}),
        "rc-1",
        ShieldMode::Enforce,
        OnBlockPolicy::ReturnBlocked,
    );
    lease
        .record_tool_success("echo", &json!({"ok": true}))
        .expect("record_tool_success pass-through");

    let _ = disp.validate_tool_call(
        &lease,
        "echo",
        json!({}),
        "rc-2",
        ShieldMode::Enforce,
        OnBlockPolicy::ReturnBlocked,
    );
    lease
        .record_tool_failure("echo", "timeout")
        .expect("record_tool_failure pass-through");
}
