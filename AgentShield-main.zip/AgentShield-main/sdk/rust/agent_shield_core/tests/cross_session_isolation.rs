//! Cross-session isolation contract tests.
//!
//! These tests lock in the spec §9 / §10 contract that a
//! [`GuardrailsRuntime`](agent_shield_core::GuardrailsRuntime) is
//! shared, immutable plumbing while every
//! [`GuardrailsSession`](agent_shield_core::GuardrailsSession) owns
//! its own *runtime state* — variables, event latches, predicate
//! memoization, and `active_if:` activation snapshots.
//!
//! Per the spec, `LifetimeTracker` stores per-session state keyed by
//! `SessionId`, `EventBus` latches by `(SessionId, EventId)` (the bus
//! itself is intentionally a single in-memory bus per §9.3 — only the
//! latching is per-session), and the guard-policy engine's
//! [`ActivationCache`](agent_shield_core::ActivationCache) keys by
//! `(SessionId, policy_name)`. Two simultaneous user conversations on
//! the same `GuardrailsRuntime` therefore do NOT see each other's
//! variables, event latches, or activation snapshots.
//!
//! Every test below builds ONE runtime, opens TWO sessions on it,
//! mutates state in session A, and asserts that session B is
//! unaffected. The suite is a standing regression guard — any
//! reintroduction of cross-session state bleed will surface here.
//! Run with:
//!
//! ```text
//! cargo test --test cross_session_isolation
//! ```
//!
//! Spec references:
//! - §9.1 (variable lifetimes, including `per_session` /
//!   `per_request` / `per_call` / `per_turn` / `for:` / `until_event:`)
//! - §9.3 (closed event namespace; `session.*`, `turn.*`, `request.*`,
//!   `tool.*`, `approval.*`, `guard_policy.*`)
//! - §10.5 (approval auto-flip semantics)
//! - §12.4 (`active_if:` activation events)

use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, Barrier, Mutex};
use std::thread;

use agent_shield_core::{
    load_from_str, BusEvent, EventId, GpEventKind, GuardrailsRuntime, GuardrailsSession,
    Invocation, RequestContext, RuntimeBuilder, VarStatus,
};
use serde_json::json;

// ────────────────────────────────────────────────────────────────────
// Test helpers
// ────────────────────────────────────────────────────────────────────

/// Build an `Arc<GuardrailsRuntime>` from inline YAML. Mirrors the
/// pattern used in `tests/runtime.rs`. Tests that need session-scoped
/// state declarations inline the YAML themselves — the helper is
/// agnostic.
fn build_runtime_for_test(yaml: &str) -> Arc<GuardrailsRuntime> {
    let cfg = load_from_str(yaml).expect("yaml parses");
    RuntimeBuilder::from_config(cfg)
        .build()
        .expect("runtime builds")
}

/// Per-session [`RequestContext`] with a deterministic id pair so the
/// failure messages are easy to read.
fn ctx(session_id: &str) -> RequestContext {
    RequestContext::new(session_id, format!("{session_id}-corr"))
}

/// Open two sessions on the same runtime — every test does this.
fn open_two(rt: &Arc<GuardrailsRuntime>) -> (GuardrailsSession, GuardrailsSession) {
    let a = rt.new_session(ctx("sess-a"));
    let b = rt.new_session(ctx("sess-b"));
    (a, b)
}

// ────────────────────────────────────────────────────────────────────
// Inline guardrails YAML fragments
// ────────────────────────────────────────────────────────────────────

/// Single string variable, no explicit lifetime.
const VAR_OMITTED_LIFETIME: &str = r#"
metadata:
  name: "isolation-omitted-lifetime"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["isolate"]
  forbidden: ["leak"]
resources:
  tools:
    - name: "noop"
      description: "noop"
      permission: "read_only"
variables:
  - name: "shared_state"
    type: "string"
"#;

/// Variable scoped to `per_session`.
const VAR_PER_SESSION: &str = r#"
metadata:
  name: "isolation-per-session"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["isolate"]
  forbidden: ["leak"]
resources:
  tools:
    - name: "noop"
      description: "noop"
      permission: "read_only"
variables:
  - name: "user_role"
    type: "string"
    lifetime: "per_session"
"#;

/// Variable scoped to `per_request`.
const VAR_PER_REQUEST: &str = r#"
metadata:
  name: "isolation-per-request"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["isolate"]
  forbidden: ["leak"]
resources:
  tools:
    - name: "noop"
      description: "noop"
      permission: "read_only"
variables:
  - name: "request_total"
    type: "number"
    lifetime: "per_request"
"#;

/// Variable scoped to `per_call`.
const VAR_PER_CALL: &str = r#"
metadata:
  name: "isolation-per-call"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["isolate"]
  forbidden: ["leak"]
resources:
  tools:
    - name: "noop"
      description: "noop"
      permission: "read_only"
variables:
  - name: "call_token"
    type: "string"
    lifetime: "per_call"
"#;

/// Variable scoped to `per_turn`.
const VAR_PER_TURN: &str = r#"
metadata:
  name: "isolation-per-turn"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["isolate"]
  forbidden: ["leak"]
resources:
  tools:
    - name: "noop"
      description: "noop"
      permission: "read_only"
variables:
  - name: "turn_step"
    type: "number"
    lifetime: "per_turn"
"#;

/// Variable scoped to `for: 1h`.
const VAR_FOR_DURATION: &str = r#"
metadata:
  name: "isolation-for-duration"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["isolate"]
  forbidden: ["leak"]
resources:
  tools:
    - name: "noop"
      description: "noop"
      permission: "read_only"
variables:
  - name: "auth_token"
    type: "string"
    lifetime:
      for: "1h"
"#;

/// Variable scoped to `until_event: turn.end`.
const VAR_UNTIL_EVENT: &str = r#"
metadata:
  name: "isolation-until-event"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["isolate"]
  forbidden: ["leak"]
resources:
  tools:
    - name: "noop"
      description: "noop"
      permission: "read_only"
variables:
  - name: "draft_message"
    type: "string"
    lifetime:
      until_event: "turn.end"
"#;

/// Variable that can be Denied by a human resolver branch.
const VAR_DENY_BRANCH: &str = r#"
metadata:
  name: "isolation-deny-branch"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["isolate"]
  forbidden: ["leak"]
resources:
  tools:
    - name: "send_message"
      description: "send"
      permission: "execute"
variables:
  - name: "send_authorized"
    type: "boolean"
    on_demand_by:
      kind: "human"
      prompt: "Authorize send?"
    lifetime:
      allow: "per_call"
      deny: "per_session"
"#;

/// Variable with a `default:` value — should be initialized at
/// session start independently per session.
const VAR_WITH_DEFAULT: &str = r#"
metadata:
  name: "isolation-default"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["isolate"]
  forbidden: ["leak"]
resources:
  tools:
    - name: "noop"
      description: "noop"
      permission: "read_only"
variables:
  - name: "preferred_locale"
    type: "string"
    default: "en-US"
"#;

/// Approval-bound variable (`approval.<name>.{allow,deny}` auto-flip
/// per §10.5).
const VAR_APPROVAL_BOUND: &str = r#"
metadata:
  name: "isolation-approval"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["isolate"]
  forbidden: ["leak"]
resources:
  tools:
    - name: "deploy"
      description: "deploy"
      permission: "execute"
variables:
  - name: "deploy_prod"
    type: "boolean"
    on_demand_by:
      kind: "human"
      prompt: "Approve prod deploy?"
"#;

/// Guard policy whose `evaluate_when[]` references a `tool.*.success`
/// latched event — used to verify event isolation through the gating
/// path.
const POLICY_DEPENDS_ON_TOOL_SUCCESS: &str = r#"
metadata:
  name: "isolation-event-fired"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["isolate"]
  forbidden: ["leak"]
resources:
  tools:
    - name: "noop"
      description: "noop"
      permission: "read_only"
state_validation:
  guard_policies:
    - name: "block_after_send_email_succeeded"
      applies_to:
        tools: ["noop"]
      evaluate_when:
        - expression: "not @event.fired('tool.send_email.success')"
          reason: "block once send_email has succeeded earlier"
      action: "block"
"#;

/// Guard policy whose `evaluate_when[]` references the `turn.end`
/// boundary event.
const POLICY_DEPENDS_ON_TURN_END: &str = r#"
metadata:
  name: "isolation-turn-end"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["isolate"]
  forbidden: ["leak"]
resources:
  tools:
    - name: "noop"
      description: "noop"
      permission: "read_only"
state_validation:
  guard_policies:
    - name: "block_after_turn_ended"
      applies_to:
        tools: ["noop"]
      evaluate_when:
        - expression: "not @event.fired('turn.end')"
          reason: "block once any turn has ended"
      action: "block"
"#;

/// Predicate that depends on a `per_session` variable.
const PREDICATE_ON_PER_SESSION_VAR: &str = r#"
metadata:
  name: "isolation-predicate"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["isolate"]
  forbidden: ["leak"]
resources:
  tools:
    - name: "admin_action"
      description: "admin"
      permission: "execute"
variables:
  - name: "role"
    type: "string"
    lifetime: "per_session"
predicates:
  is_admin: "role == 'admin'"
state_validation:
  guard_policies:
    - name: "admin_only"
      applies_to:
        tools: ["admin_action"]
      evaluate_when:
        - expression: "is_admin"
          reason: "admin role required"
      action: "block"
"#;

/// Guard policy whose `active_if:` reads a per-session variable.
const POLICY_ACTIVE_IF_FLAG: &str = r#"
metadata:
  name: "isolation-active-if"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["isolate"]
  forbidden: ["leak"]
resources:
  tools:
    - name: "noop"
      description: "noop"
      permission: "read_only"
variables:
  - name: "incident_mode"
    type: "boolean"
    lifetime: "per_session"
state_validation:
  guard_policies:
    - name: "lockdown"
      applies_to:
        tools: ["noop"]
      active_if: "incident_mode == true"
      evaluate_when:
        - expression: "false"
          reason: "blocked during incident"
      action: "block"
"#;

// ────────────────────────────────────────────────────────────────────
// Variables — lifetime isolation
// ────────────────────────────────────────────────────────────────────

#[test]

fn per_session_vars_isolated_across_sessions() {
    let rt = build_runtime_for_test(VAR_PER_SESSION);
    let (a, b) = open_two(&rt);

    a.set_variable("user_role", json!("admin"))
        .expect("set in A");
    let st_a = a.read_variable("user_role").expect("declared");
    assert_eq!(
        st_a.status,
        VarStatus::Resolved,
        "A should see its own write"
    );
    assert_eq!(st_a.value, json!("admin"));

    let st_b = b.read_variable("user_role").expect("declared");
    assert_eq!(
        st_b.status,
        VarStatus::Unset,
        "session B must NOT see A's per_session variable; got {:?}",
        st_b
    );
}

#[test]

fn per_request_vars_isolated_across_sessions() {
    let rt = build_runtime_for_test(VAR_PER_REQUEST);
    let (a, b) = open_two(&rt);

    a.begin_request().expect("begin in A");
    a.set_variable("request_total", json!(7)).expect("set in A");

    // Session B starts its OWN request scope; the variable is
    // session-scoped state and must not be visible.
    b.begin_request().expect("begin in B");
    let st_b = b.read_variable("request_total").expect("declared");
    assert_eq!(
        st_b.status,
        VarStatus::Unset,
        "session B must not see A's per_request variable; got {:?}",
        st_b
    );
}

#[test]

fn per_call_vars_isolated_across_sessions() {
    let rt = build_runtime_for_test(VAR_PER_CALL);
    let (a, b) = open_two(&rt);

    a.set_variable("call_token", json!("abc-123"))
        .expect("set in A");
    let st_b = b.read_variable("call_token").expect("declared");
    assert_eq!(
        st_b.status,
        VarStatus::Unset,
        "session B must not see A's per_call variable; got {:?}",
        st_b
    );
}

#[test]

fn per_turn_vars_isolated_across_sessions() {
    let rt = build_runtime_for_test(VAR_PER_TURN);
    let (a, b) = open_two(&rt);

    a.begin_turn().expect("begin in A");
    a.set_variable("turn_step", json!(3)).expect("set in A");

    b.begin_turn().expect("begin in B");
    let st_b = b.read_variable("turn_step").expect("declared");
    assert_eq!(
        st_b.status,
        VarStatus::Unset,
        "session B must not see A's per_turn variable; got {:?}",
        st_b
    );
}

#[test]

fn for_duration_vars_isolated_across_sessions() {
    let rt = build_runtime_for_test(VAR_FOR_DURATION);
    let (a, b) = open_two(&rt);

    a.set_variable("auth_token", json!("tok-xyz"))
        .expect("set in A");

    let st_b = b.read_variable("auth_token").expect("declared");
    assert_eq!(
        st_b.status,
        VarStatus::Unset,
        "session B must not see A's `for: 1h` variable; got {:?}",
        st_b
    );
}

#[test]

fn until_event_vars_isolated_across_sessions() {
    let rt = build_runtime_for_test(VAR_UNTIL_EVENT);
    let (a, b) = open_two(&rt);

    a.set_variable("draft_message", json!("hello"))
        .expect("set in A");

    let st_b = b.read_variable("draft_message").expect("declared");
    assert_eq!(
        st_b.status,
        VarStatus::Unset,
        "session B must not see A's `until_event:` variable; got {:?}",
        st_b
    );
}

#[test]

fn omitted_lifetime_vars_isolated_across_sessions() {
    let rt = build_runtime_for_test(VAR_OMITTED_LIFETIME);
    let (a, b) = open_two(&rt);

    a.set_variable("shared_state", json!("hello-from-A"))
        .expect("set in A");

    let st_b = b.read_variable("shared_state").expect("declared");
    assert_eq!(
        st_b.status,
        VarStatus::Unset,
        "session B must not see A's lifetime-omitted variable; got {:?}",
        st_b
    );
}

#[test]

fn denied_state_isolated_across_sessions() {
    // Drive the variable into Denied via the deny branch lifetime by
    // emitting `approval.send_authorized.deny` in session A.
    let rt = build_runtime_for_test(VAR_DENY_BRANCH);
    let (a, b) = open_two(&rt);

    a.emit_event(
        "approval.send_authorized.deny",
        None,
        Some(json!({"reason": "user declined"})),
    )
    .expect("emit deny in A");

    let st_a = a.read_variable("send_authorized").expect("declared");
    assert_eq!(st_a.status, VarStatus::Denied, "A must observe Denied");

    let st_b = b.read_variable("send_authorized").expect("declared");
    assert_ne!(
        st_b.status,
        VarStatus::Denied,
        "session B must not inherit A's Denied state; got {:?}",
        st_b
    );
}

#[test]

fn default_initialized_per_session() {
    // Each session should observe `default:` independently. The
    // contract is: writing to A's copy must NOT change B's view.
    let rt = build_runtime_for_test(VAR_WITH_DEFAULT);
    let (a, b) = open_two(&rt);

    // A overwrites its session-local copy.
    a.set_variable("preferred_locale", json!("fr-FR"))
        .expect("set in A");

    // B should still see the declared default (each session
    // materializes the default independently per spec §9). At minimum,
    // B must not observe A's "fr-FR" write.
    let st_b = b.read_variable("preferred_locale").expect("declared");
    assert_ne!(
        st_b.value,
        json!("fr-FR"),
        "session B must not see A's overwrite of the defaulted variable; got {:?}",
        st_b
    );
}

#[test]

fn session_a_end_does_not_clear_session_b_vars() {
    let rt = build_runtime_for_test(VAR_PER_SESSION);
    let (a, b) = open_two(&rt);

    // B writes its own value; A is irrelevant except to be dropped
    // below.
    b.set_variable("user_role", json!("editor"))
        .expect("set in B");

    // Drop session A → triggers session.end emission. In the current
    // shared-state architecture this clears the latched events for
    // EVERYTHING, but more importantly: any tracker write is also
    // wiped because both sessions share state. We assert B's variable
    // survives.
    drop(a);

    let st_b = b.read_variable("user_role").expect("declared");
    assert_eq!(
        st_b.status,
        VarStatus::Resolved,
        "session B's variable must survive session A drop / session.end; got {:?}",
        st_b
    );
    assert_eq!(st_b.value, json!("editor"));
}

// ────────────────────────────────────────────────────────────────────
// Events — latched event isolation
// ────────────────────────────────────────────────────────────────────

#[test]

fn event_fired_isolated_across_sessions() {
    // Session A latches `tool.send_email.success`; session B's
    // gating expression `not @event.fired(...)` should evaluate to
    // true (event not seen in B), so the policy allows the call.
    let rt = build_runtime_for_test(POLICY_DEPENDS_ON_TOOL_SUCCESS);
    let (a, b) = open_two(&rt);

    a.emit_event("tool.send_email.success", None, None)
        .expect("emit in A");

    let inv = Invocation::tool("noop", json!({}));
    let v_b = b.validate_state(&inv);
    assert!(
        v_b.allowed,
        "session B should pass the gate because tool.send_email.success was \
         never fired in B; got verdict {:?}",
        v_b
    );
}

#[test]

fn turn_end_event_isolated_across_sessions() {
    let rt = build_runtime_for_test(POLICY_DEPENDS_ON_TURN_END);
    let (a, b) = open_two(&rt);

    a.begin_turn().expect("begin A");
    a.end_turn().expect("end A");

    // Session B never started or ended a turn, so `turn.end` must not
    // appear fired from its perspective.
    let inv = Invocation::tool("noop", json!({}));
    let v_b = b.validate_state(&inv);
    assert!(
        v_b.allowed,
        "session B should not see A's turn.end latch; got {:?}",
        v_b
    );
}

#[test]

fn session_a_end_does_not_clear_session_b_latches() {
    // B emits its own incident latch; dropping A (which fires
    // session.end on the shared bus) must not wipe B's latches.
    let rt = build_runtime_for_test(VAR_OMITTED_LIFETIME);
    let (a, b) = open_two(&rt);

    b.emit_event("incident.b_only", None, Some(json!({"src": "B"})))
        .expect("emit in B");

    let id = EventId::Incident {
        name: "b_only".into(),
    };
    assert!(
        rt.bus().fired_id(&id),
        "B's latch should be present before A drops"
    );

    drop(a);

    // After A drops, session.end was emitted on the shared bus and
    // wiped every latch. Once each session owns its own bus, B's
    // latch survives.
    assert!(
        rt.bus().fired_id(&id),
        "session B's incident latch must survive session A's drop / session.end"
    );
}

#[test]

fn approval_auto_flip_isolated_across_sessions() {
    let rt = build_runtime_for_test(VAR_APPROVAL_BOUND);
    let (a, b) = open_two(&rt);

    // A approves the deploy_prod variable.
    a.emit_event(
        "approval.deploy_prod.allow",
        None,
        Some(json!({"value": true})),
    )
    .expect("emit approval in A");

    let st_a = a.read_variable("deploy_prod").expect("declared");
    assert_eq!(st_a.status, VarStatus::Resolved, "A should be auto-flipped");

    // B did not approve; B's view of `deploy_prod` must be Unset.
    let st_b = b.read_variable("deploy_prod").expect("declared");
    assert_eq!(
        st_b.status,
        VarStatus::Unset,
        "session B must not be auto-flipped by A's approval; got {:?}",
        st_b
    );
}

// ────────────────────────────────────────────────────────────────────
// Predicates — memoization isolation
// ────────────────────────────────────────────────────────────────────

#[test]

fn predicate_memo_isolated_across_sessions() {
    // The predicate `is_admin` reads a per_session variable `role`.
    // A sets role=admin, B leaves it unset. The guard policy
    // `admin_only` blocks unless `is_admin` is true. Therefore:
    //  - A → allowed (is_admin true).
    //  - B → blocked (role is unset → null == 'admin' is false).
    let rt = build_runtime_for_test(PREDICATE_ON_PER_SESSION_VAR);
    let (a, b) = open_two(&rt);

    a.set_variable("role", json!("admin")).expect("set in A");

    let inv = Invocation::tool("admin_action", json!({}));

    let v_a = a.validate_state(&inv);
    assert!(v_a.allowed, "A should pass admin_only; got {:?}", v_a);

    let v_b = b.validate_state(&inv);
    assert!(
        !v_b.allowed,
        "B must be blocked because role is unset in B; got {:?}",
        v_b
    );
}

// ────────────────────────────────────────────────────────────────────
// GuardPolicyEngine — `active_if:` activation cache isolation
// ────────────────────────────────────────────────────────────────────

#[test]

fn active_if_state_isolated_across_sessions() {
    // After A activates the `lockdown` policy (incident_mode=true,
    // active_if true), session B — which never set incident_mode —
    // must not observe `lockdown` as active. We probe via verdict:
    // when the policy is inactive, the call passes; when it's active,
    // the call is blocked by the unconditional `false` evaluator.
    let rt = build_runtime_for_test(POLICY_ACTIVE_IF_FLAG);
    let (a, b) = open_two(&rt);

    a.set_variable("incident_mode", json!(true))
        .expect("set in A");
    let inv = Invocation::tool("noop", json!({}));
    let v_a = a.validate_state(&inv);
    assert!(!v_a.allowed, "A should be blocked while in lockdown");

    // B never set incident_mode → active_if false → policy inactive
    // → call allowed. This passes today on the variable side because
    // B's read of incident_mode goes through the shared tracker which
    // shows it as resolved=true. After the refactor, B reads
    // incident_mode as Unset, active_if evaluates false, and the
    // call is allowed.
    let v_b = b.validate_state(&inv);
    assert!(
        v_b.allowed,
        "session B must not observe lockdown as active; got {:?}",
        v_b
    );
}

#[test]

fn activation_events_session_scoped() {
    // Per §12.4, `guard_policy.<name>.activated` fires on the
    // *transition* from inactive → active. With session-scoped
    // activation caches, when both sessions activate the same policy
    // we should see TWO emissions (one per session). With the
    // current shared cache, the second session's evaluation finds
    // the policy already latched as active and emits nothing.
    let rt = build_runtime_for_test(POLICY_ACTIVE_IF_FLAG);

    // Subscribe before opening sessions so we capture every
    // activation emission.
    let activations: Arc<Mutex<Vec<EventId>>> = Arc::new(Mutex::new(Vec::new()));
    let cap = activations.clone();
    rt.bus().subscribe(
        Some(Box::new(|ev: &BusEvent| match ev {
            BusEvent::Emitted { event_id, .. } => matches!(
                event_id,
                EventId::GuardPolicy {
                    kind: GpEventKind::Activated,
                    ..
                }
            ),
            _ => false,
        })),
        move |ev: &BusEvent| {
            if let BusEvent::Emitted { event_id, .. } = ev {
                cap.lock().unwrap().push(event_id.clone());
            }
        },
    );

    let (a, b) = open_two(&rt);
    a.set_variable("incident_mode", json!(true)).expect("set A");
    b.set_variable("incident_mode", json!(true)).expect("set B");

    let inv = Invocation::tool("noop", json!({}));
    let _ = a.validate_state(&inv);
    let _ = b.validate_state(&inv);

    let seen = activations.lock().unwrap();
    let lockdowns = seen
        .iter()
        .filter(|id| {
            matches!(
                id,
                EventId::GuardPolicy { name, kind: GpEventKind::Activated } if name == "lockdown"
            )
        })
        .count();
    assert_eq!(
        lockdowns, 2,
        "expected guard_policy.lockdown.activated to fire ONCE PER SESSION \
         (2 emissions total) — saw {} emissions: {:?}",
        lockdowns, *seen
    );
}

// ────────────────────────────────────────────────────────────────────
// Concurrency stress
// ────────────────────────────────────────────────────────────────────

#[test]

fn concurrent_per_session_writes_dont_lose_data() {
    // Two threads, two sessions, each writes its own `per_session`
    // variable in a tight loop. Final values should reflect each
    // session's last write, with no cross-pollination.
    //
    // Since both sessions in the current architecture share the same
    // `vars` map under the same `(name, key)` tuple, they race on the
    // same slot — the final value is non-deterministic and one
    // session's perspective is wrong.
    let yaml = r#"
metadata:
  name: "isolation-concurrent"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["isolate"]
  forbidden: ["leak"]
resources:
  tools:
    - name: "noop"
      description: "noop"
      permission: "read_only"
variables:
  - name: "counter"
    type: "number"
    lifetime: "per_session"
"#;
    let rt = build_runtime_for_test(yaml);
    let rt_a = rt.clone();
    let rt_b = rt.clone();

    let barrier = Arc::new(Barrier::new(2));
    let ba = barrier.clone();
    let bb = barrier.clone();

    const ITERATIONS: i64 = 1_000;
    const A_FINAL: i64 = 100_001;
    const B_FINAL: i64 = 200_001;

    let h_a = thread::spawn(move || {
        let s = rt_a.new_session(ctx("sess-conc-a"));
        ba.wait();
        for i in 0..ITERATIONS {
            s.set_variable("counter", json!(100_000 + i)).unwrap();
        }
        // Final deterministic write to assert against.
        s.set_variable("counter", json!(A_FINAL)).unwrap();
        let st = s.read_variable("counter").unwrap();
        assert_eq!(
            st.value,
            json!(A_FINAL),
            "session A's final read does not reflect its own last write \
             — cross-session interference; got {:?}",
            st
        );
    });

    let h_b = thread::spawn(move || {
        let s = rt_b.new_session(ctx("sess-conc-b"));
        bb.wait();
        for i in 0..ITERATIONS {
            s.set_variable("counter", json!(200_000 + i)).unwrap();
        }
        s.set_variable("counter", json!(B_FINAL)).unwrap();
        let st = s.read_variable("counter").unwrap();
        assert_eq!(
            st.value,
            json!(B_FINAL),
            "session B's final read does not reflect its own last write \
             — cross-session interference; got {:?}",
            st
        );
    });

    h_a.join().expect("thread A");
    h_b.join().expect("thread B");
}

#[test]

fn concurrent_event_emit_dont_cross_sessions() {
    // Two threads emit DIFFERENT latched events from their own
    // sessions concurrently. Each session's perspective should show
    // ONLY its own latch fired.
    let rt = build_runtime_for_test(VAR_OMITTED_LIFETIME);

    // Track per-session latch observations through a shared bus
    // listener. Each session emits a uniquely-named incident; once
    // sessions own their own bus, the listener registered against
    // session A's bus only sees A's latch. We approximate that here
    // by counting per-name fires on the (currently shared) bus and
    // asserting cross-talk is absent.
    let saw_a_only = Arc::new(AtomicUsize::new(0));
    let saw_b_only = Arc::new(AtomicUsize::new(0));
    let saw_a_clone = saw_a_only.clone();
    let saw_b_clone = saw_b_only.clone();
    rt.bus().subscribe(None, move |ev: &BusEvent| {
        if let BusEvent::Emitted { event_id, .. } = ev {
            if let EventId::Incident { name } = event_id {
                if name == "a_only" {
                    saw_a_clone.fetch_add(1, Ordering::SeqCst);
                } else if name == "b_only" {
                    saw_b_clone.fetch_add(1, Ordering::SeqCst);
                }
            }
        }
    });

    let rt_a = rt.clone();
    let rt_b = rt.clone();
    let barrier = Arc::new(Barrier::new(2));
    let ba = barrier.clone();
    let bb = barrier.clone();

    let h_a = thread::spawn(move || {
        let s = rt_a.new_session(ctx("sess-evt-a"));
        ba.wait();
        for _ in 0..100 {
            s.emit_event("incident.a_only", None, None).unwrap();
        }
        // From A's perspective, only `incident.a_only` should be
        // latched. We use the session-scoped query because the
        // runtime-level `bus().fired_id` aggregates across all sessions
        // (it would see B's latch too, which is a different invariant).
        let id_b = EventId::Incident {
            name: "b_only".into(),
        };
        assert!(
            !s.event_fired_id(&id_b),
            "session A must not see B's `incident.b_only` latch"
        );
    });

    let h_b = thread::spawn(move || {
        let s = rt_b.new_session(ctx("sess-evt-b"));
        bb.wait();
        for _ in 0..100 {
            s.emit_event("incident.b_only", None, None).unwrap();
        }
        let id_a = EventId::Incident {
            name: "a_only".into(),
        };
        assert!(
            !s.event_fired_id(&id_a),
            "session B must not see A's `incident.a_only` latch"
        );
    });

    h_a.join().expect("thread A");
    h_b.join().expect("thread B");

    // Sanity: both subscribers fired at least once each (they
    // serialized through the shared bus's mutex but both are
    // observable).
    assert!(saw_a_only.load(Ordering::SeqCst) >= 1);
    assert!(saw_b_only.load(Ordering::SeqCst) >= 1);
}

// ────────────────────────────────────────────────────────────────────
// Sentinel: any failure here proves cross-session state bleed has
// been reintroduced. Keep this file as the standing regression suite
// for the spec §9 / §10 isolation contract.
// ────────────────────────────────────────────────────────────────────

#[test]
fn meta_runtime_can_open_two_sessions() {
    // Smoke check: the test infrastructure assumes
    // `runtime.new_session` can be called twice on the same Arc. If
    // this ever stops being true the cross-session isolation tests
    // can't be authored.
    let rt = build_runtime_for_test(VAR_PER_SESSION);
    let (a, b) = open_two(&rt);
    assert_ne!(
        a.request_context().session_id,
        b.request_context().session_id
    );
}
