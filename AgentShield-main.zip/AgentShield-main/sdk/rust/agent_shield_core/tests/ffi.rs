//! Integration tests for the C FFI surface exposed by
//! [`agent_shield_core::ffi`].
//!
//! The tests exercise the FFI from the same process via the
//! `extern "C"` symbols. They focus on the wire contract — JSON shapes,
//! null safety, mutated-out-params, and the resolver-envelope callback
//! plumbing — rather than re-testing the underlying runtime semantics
//! (those live in `tests/runtime.rs`).
//!
//! All `unsafe` blocks below check pointers before deref to preserve the
//! "FFI panics never escape across the ABI" invariant.

use std::ffi::{c_void, CStr, CString};
use std::os::raw::c_char;
use std::ptr;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Mutex;

use agent_shield_core::ffi::*;
use serde_json::{json, Value};

// ────────────────────────────────────────────────────────────────────
// Tiny helpers for the test harness
// ────────────────────────────────────────────────────────────────────

fn cstr(s: &str) -> CString {
    CString::new(s).expect("test string contained NUL")
}

unsafe fn read_and_free(p: *mut c_char) -> Option<String> {
    if p.is_null() {
        return None;
    }
    let s = CStr::from_ptr(p).to_str().expect("utf8").to_owned();
    shield_free_string(p);
    Some(s)
}

unsafe fn drain_err(err: *mut *mut c_char) -> Option<String> {
    if err.is_null() {
        return None;
    }
    let p = *err;
    *err = std::ptr::null_mut();
    read_and_free(p)
}

const MINIMAL_YAML: &str = r#"
metadata:
  name: "ffi-min"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "echo"
      description: "echo"
      permission: "read_only"
"#;

unsafe fn build_minimal() -> *mut ShieldBuilder {
    let yaml = cstr(MINIMAL_YAML);
    let mut err: *mut c_char = std::ptr::null_mut();
    let b = shield_builder_from_config_json(yaml.as_ptr(), &mut err);
    assert!(!b.is_null(), "build err: {:?}", drain_err(&mut err));
    b
}

unsafe fn build_runtime_minimal() -> *mut ShieldRuntime {
    let b = build_minimal();
    let mut err: *mut c_char = std::ptr::null_mut();
    let rt = shield_builder_build(b, &mut err);
    assert!(
        !rt.is_null(),
        "build runtime err: {:?}",
        drain_err(&mut err)
    );
    shield_builder_free(b);
    rt
}

unsafe fn open_session(rt: *mut ShieldRuntime) -> *mut ShieldSession {
    let mut err: *mut c_char = std::ptr::null_mut();
    let ctx = cstr(r#"{"session_id":"sess-ffi","correlation_id":"corr-ffi","user_id":"alice"}"#);
    let sess = shield_runtime_new_session(rt, ctx.as_ptr(), &mut err);
    assert!(!sess.is_null(), "session err: {:?}", drain_err(&mut err));
    sess
}

// ────────────────────────────────────────────────────────────────────
// 1) Lifecycle
// ────────────────────────────────────────────────────────────────────

#[test]
fn version_returns_expected_string() {
    unsafe {
        let p = shield_version();
        assert!(!p.is_null());
        let s = CStr::from_ptr(p).to_str().unwrap();
        assert_eq!(s, "0.13.0");
    }
}

#[test]
fn from_config_json_round_trip() {
    unsafe {
        let b = build_minimal();
        shield_builder_free(b);
    }
}

#[test]
fn from_config_json_null_path_errors() {
    unsafe {
        let mut err: *mut c_char = std::ptr::null_mut();
        let b = shield_builder_from_config_json(std::ptr::null(), &mut err);
        assert!(b.is_null());
        let msg = drain_err(&mut err).unwrap_or_default();
        assert!(msg.contains("null"), "got: {msg}");
    }
}

#[test]
fn from_config_json_invalid_yaml_errors() {
    unsafe {
        let yaml = cstr("this: is: not: valid: yaml:");
        let mut err: *mut c_char = std::ptr::null_mut();
        let b = shield_builder_from_config_json(yaml.as_ptr(), &mut err);
        assert!(b.is_null());
        let msg = drain_err(&mut err).unwrap_or_default();
        assert!(
            msg.contains("load_from_str failed") || msg.contains("invalid"),
            "got: {msg}"
        );
    }
}

#[test]
fn from_yaml_chain_empty_array_errors() {
    unsafe {
        let mut err: *mut c_char = std::ptr::null_mut();
        let b = shield_builder_from_yaml_chain(std::ptr::null(), 0, &mut err);
        assert!(b.is_null());
        let msg = drain_err(&mut err).unwrap_or_default();
        assert!(!msg.is_empty());
    }
}

#[test]
fn from_yaml_loads_smoke_fixture() {
    let manifest = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    let p = manifest
        .join("../../..")
        .join("tests/fixtures/smoke/minimal.guardrails.yaml");
    let s = p.to_string_lossy().to_string();
    unsafe {
        let path_c = cstr(&s);
        let mut err: *mut c_char = std::ptr::null_mut();
        let b = shield_builder_from_yaml(path_c.as_ptr(), &mut err);
        assert!(!b.is_null(), "build err: {:?}", drain_err(&mut err));
        let rt = shield_builder_build(b, &mut err);
        assert!(!rt.is_null());
        shield_builder_free(b);
        shield_runtime_free(rt);
    }
}

#[test]
fn build_consumes_builder() {
    unsafe {
        let b = build_minimal();
        let mut err: *mut c_char = std::ptr::null_mut();
        let rt = shield_builder_build(b, &mut err);
        assert!(!rt.is_null());
        // Building again should fail because the inner is taken.
        let rt2 = shield_builder_build(b, &mut err);
        assert!(rt2.is_null());
        let msg = drain_err(&mut err).unwrap_or_default();
        assert!(
            msg.contains("consumed") || msg.contains("null"),
            "got: {msg}"
        );
        shield_builder_free(b);
        shield_runtime_free(rt);
    }
}

#[test]
fn null_pointers_dont_segfault() {
    unsafe {
        // Each *_free is null-safe.
        shield_builder_free(std::ptr::null_mut());
        shield_runtime_free(std::ptr::null_mut());
        shield_session_free(std::ptr::null_mut());
        shield_stream_free(std::ptr::null_mut());
        shield_free_string(std::ptr::null_mut());
    }
}

#[test]
fn new_session_with_default_context_when_null() {
    unsafe {
        let rt = build_runtime_minimal();
        let mut err: *mut c_char = std::ptr::null_mut();
        let sess = shield_runtime_new_session(rt, std::ptr::null(), &mut err);
        assert!(!sess.is_null());
        shield_session_free(sess);
        shield_runtime_free(rt);
    }
}

// ────────────────────────────────────────────────────────────────────
// 2) Variable ops
// ────────────────────────────────────────────────────────────────────

const COUNTER_YAML: &str = r#"
metadata:
  name: "ffi-counter"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["counter"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "noop"
      description: "noop"
      permission: "read_only"
variables:
  - name: "score"
    type: "number"
    default: 0
    update: "max(@current, @incoming)"
"#;

unsafe fn build_runtime_with(yaml: &str) -> *mut ShieldRuntime {
    let yaml_c = cstr(yaml);
    let mut err: *mut c_char = std::ptr::null_mut();
    let b = shield_builder_from_config_json(yaml_c.as_ptr(), &mut err);
    assert!(!b.is_null(), "build err: {:?}", drain_err(&mut err));
    let rt = shield_builder_build(b, &mut err);
    assert!(!rt.is_null(), "rt err: {:?}", drain_err(&mut err));
    shield_builder_free(b);
    rt
}

#[test]
fn set_variable_round_trip() {
    unsafe {
        let rt = build_runtime_with(COUNTER_YAML);
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        let name = cstr("score");
        let val = cstr("42");
        let rc = shield_session_set_variable(s, name.as_ptr(), val.as_ptr(), &mut err);
        assert_eq!(rc, 0, "err: {:?}", drain_err(&mut err));
        let p = shield_session_read_variable(s, name.as_ptr(), &mut err);
        let body = read_and_free(p).expect("read returned null");
        let v: Value = serde_json::from_str(&body).unwrap();
        assert_eq!(v["status"], "resolved");
        assert_eq!(v["value"], 42);
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

#[test]
fn reset_variable_returns_status_unset() {
    unsafe {
        let rt = build_runtime_with(COUNTER_YAML);
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        let name = cstr("score");
        shield_session_set_variable(s, name.as_ptr(), cstr("5").as_ptr(), &mut err);
        let rc = shield_session_reset_variable(s, name.as_ptr(), &mut err);
        assert_eq!(rc, 0);
        let p = shield_session_read_variable(s, name.as_ptr(), &mut err);
        let body = read_and_free(p).expect("read returned null");
        let v: Value = serde_json::from_str(&body).unwrap();
        assert_eq!(v["status"], "unset");
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

#[test]
fn set_unknown_variable_returns_error() {
    unsafe {
        let rt = build_runtime_with(COUNTER_YAML);
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        let rc =
            shield_session_set_variable(s, cstr("ghost").as_ptr(), cstr("1").as_ptr(), &mut err);
        assert_eq!(rc, -1);
        let msg = drain_err(&mut err).unwrap_or_default();
        assert!(
            msg.contains("unknown") || msg.contains("ghost"),
            "got: {msg}"
        );
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

#[test]
fn read_unknown_variable_returns_null() {
    unsafe {
        let rt = build_runtime_with(COUNTER_YAML);
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        let p = shield_session_read_variable(s, cstr("ghost").as_ptr(), &mut err);
        assert!(p.is_null());
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

#[test]
fn resolve_variable_no_resolver_returns_null_literal() {
    unsafe {
        let rt = build_runtime_with(COUNTER_YAML);
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        let p = shield_session_resolve_variable(s, cstr("score").as_ptr(), &mut err);
        let body = read_and_free(p).expect("resolve returned null pointer");
        assert_eq!(body, "null");
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

#[test]
fn set_variable_invalid_json_returns_error() {
    unsafe {
        let rt = build_runtime_with(COUNTER_YAML);
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        let rc = shield_session_set_variable(
            s,
            cstr("score").as_ptr(),
            cstr("not json").as_ptr(),
            &mut err,
        );
        assert_eq!(rc, -1);
        let msg = drain_err(&mut err).unwrap_or_default();
        assert!(msg.contains("invalid JSON"), "got: {msg}");
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

// ────────────────────────────────────────────────────────────────────
// 3) Event ops
// ────────────────────────────────────────────────────────────────────

#[test]
fn emit_and_clear_event_round_trip() {
    unsafe {
        let rt = build_runtime_minimal();
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        let id = cstr("incident.lockdown");
        let rc = shield_session_emit_event(
            s,
            id.as_ptr(),
            std::ptr::null(),
            cstr(r#"{"why":"drill"}"#).as_ptr(),
            &mut err,
        );
        assert_eq!(rc, 0, "err: {:?}", drain_err(&mut err));
        let rc = shield_session_clear_event(s, id.as_ptr(), &mut err);
        assert_eq!(rc, 0);
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

#[test]
fn emit_invalid_event_id_errors() {
    unsafe {
        let rt = build_runtime_minimal();
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        let rc = shield_session_emit_event(
            s,
            cstr("bad.event.id").as_ptr(),
            std::ptr::null(),
            std::ptr::null(),
            &mut err,
        );
        assert_eq!(rc, -1);
        let msg = drain_err(&mut err).unwrap_or_default();
        assert!(
            msg.contains("invalid event id") || msg.contains("Invalid"),
            "got: {msg}"
        );
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

#[test]
fn emit_incident_helper_round_trip() {
    unsafe {
        let rt = build_runtime_minimal();
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        let rc = shield_session_emit_incident(
            s,
            cstr("breach").as_ptr(),
            cstr(r#"{"sev":5}"#).as_ptr(),
            &mut err,
        );
        assert_eq!(rc, 0, "err: {:?}", drain_err(&mut err));
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

// ────────────────────────────────────────────────────────────────────
// 4) Boundary ops
// ────────────────────────────────────────────────────────────────────

#[test]
fn begin_turn_returns_increasing_ids() {
    unsafe {
        let rt = build_runtime_minimal();
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        let t1 = shield_session_begin_turn(s, &mut err);
        let t2 = shield_session_begin_turn(s, &mut err);
        assert_eq!(t1, 1);
        assert_eq!(t2, 2);
        let rc = shield_session_end_turn(s, &mut err);
        assert_eq!(rc, 0);
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

#[test]
fn begin_request_independent_from_turn() {
    unsafe {
        let rt = build_runtime_minimal();
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        let r1 = shield_session_begin_request(s, &mut err);
        let _ = shield_session_begin_turn(s, &mut err);
        let r2 = shield_session_begin_request(s, &mut err);
        assert_eq!(r1, 1);
        assert_eq!(r2, 2);
        let _ = shield_session_end_request(s, &mut err);
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

// ────────────────────────────────────────────────────────────────────
// 5) Stage validation
// ────────────────────────────────────────────────────────────────────

#[test]
fn validate_input_returns_stage_verdict_json() {
    unsafe {
        let rt = build_runtime_minimal();
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        let p = shield_session_validate_input(s, cstr("hello world").as_ptr(), &mut err);
        let body = read_and_free(p).expect("verdict null");
        let v: Value = serde_json::from_str(&body).unwrap();
        assert_eq!(v["allowed"], true);
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

const STAGE1_BLOCK_YAML: &str = r#"
metadata:
  name: "ffi-stage1-block"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["block secret"]
  forbidden: ["leak"]
resources:
  tools:
    - name: "noop"
      description: "noop"
      permission: "read_only"
input_validation:
  guard_policies:
    - name: "no_secret"
      evaluate_when:
        - pattern: "(?i)secret"
          reason: "input contains secret"
      action: "block"
"#;

#[test]
fn validate_input_blocks_pattern_match() {
    unsafe {
        let rt = build_runtime_with(STAGE1_BLOCK_YAML);
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        let p = shield_session_validate_input(s, cstr("the secret is 42").as_ptr(), &mut err);
        let body = read_and_free(p).expect("verdict null");
        let v: Value = serde_json::from_str(&body).unwrap();
        assert_eq!(v["allowed"], false);
        assert_eq!(v["action"], "block");
        assert_eq!(v["policy"], "no_secret");
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

#[test]
fn validate_tool_call_returns_mutated_params() {
    let yaml = r#"
metadata:
  name: "ffi-redact"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["redact"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "send"
      description: "send"
      permission: "read_write"
tool_execution_validation:
  guard_policies:
    - name: "scrub_ssn"
      applies_to:
        tools: ["send"]
      evaluate_when:
        - pattern: "\\d{3}-\\d{2}-\\d{4}"
          reason: "SSN"
      action: "redact"
      replacement: "[REDACTED]"
"#;
    unsafe {
        let rt = build_runtime_with(yaml);
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        let mut mutated: *mut c_char = std::ptr::null_mut();
        let p = shield_session_validate_tool_call(
            s,
            cstr("send").as_ptr(),
            cstr(r#"{"text":"my ssn is 123-45-6789"}"#).as_ptr(),
            cstr("call_1").as_ptr(),
            &mut mutated,
            &mut err,
        );
        let body = read_and_free(p).expect("verdict null");
        let v: Value = serde_json::from_str(&body).unwrap();
        assert_eq!(v["allowed"], true);
        let mutated_str = read_and_free(mutated).expect("mutated null");
        let mp: Value = serde_json::from_str(&mutated_str).unwrap();
        let txt = mp["text"].as_str().unwrap();
        assert!(!txt.contains("123-45-6789"), "got: {txt}");
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

#[test]
fn validate_endpoint_call_emits_called_event_via_verdict() {
    unsafe {
        let rt = build_runtime_minimal();
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        let mut mutated: *mut c_char = std::ptr::null_mut();
        let p = shield_session_validate_endpoint_call(
            s,
            cstr("POST").as_ptr(),
            cstr("/v1/orders").as_ptr(),
            cstr(r#"{"x":1}"#).as_ptr(),
            cstr("call_1").as_ptr(),
            &mut mutated,
            &mut err,
        );
        let body = read_and_free(p).expect("verdict null");
        let v: Value = serde_json::from_str(&body).unwrap();
        assert_eq!(v["allowed"], true);
        // Body unchanged on a clean pass.
        let mp = read_and_free(mutated).expect("mutated null");
        assert!(mp.contains("\"x\":1"));
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

#[test]
fn validate_agent_call_returns_verdict() {
    unsafe {
        let rt = build_runtime_minimal();
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        let mut mutated: *mut c_char = std::ptr::null_mut();
        let p = shield_session_validate_agent_call(
            s,
            cstr("planner").as_ptr(),
            cstr(r#"{"task":"x"}"#).as_ptr(),
            cstr("call_1").as_ptr(),
            &mut mutated,
            &mut err,
        );
        let body = read_and_free(p).expect("verdict null");
        let v: Value = serde_json::from_str(&body).unwrap();
        assert_eq!(v["allowed"], true);
        let _ = read_and_free(mutated);
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

#[test]
fn validate_output_passes_clean_response() {
    unsafe {
        let rt = build_runtime_minimal();
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        let mut mutated: *mut c_char = std::ptr::null_mut();
        let p =
            shield_session_validate_output(s, cstr("all good").as_ptr(), &mut mutated, &mut err);
        let body = read_and_free(p).expect("verdict null");
        let v: Value = serde_json::from_str(&body).unwrap();
        assert_eq!(v["allowed"], true);
        let mp = read_and_free(mutated).expect("mutated null");
        assert_eq!(mp, "all good");
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

#[test]
fn validate_tool_output_passes_clean_result() {
    unsafe {
        let rt = build_runtime_minimal();
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        let mut mutated: *mut c_char = std::ptr::null_mut();
        // §16.0: bind a Stage 3 invocation first so Stage 4 has a
        // matching cache entry.
        let mut prebind_mut: *mut c_char = std::ptr::null_mut();
        let prebind = shield_session_validate_tool_call(
            s,
            cstr("echo").as_ptr(),
            cstr("{}").as_ptr(),
            cstr("call_1").as_ptr(),
            &mut prebind_mut,
            &mut err,
        );
        let _ = read_and_free(prebind);
        let _ = read_and_free(prebind_mut);
        let p = shield_session_validate_tool_output(
            s,
            cstr("echo").as_ptr(),
            cstr(r#"{"ok":true}"#).as_ptr(),
            cstr("call_1").as_ptr(),
            &mut mutated,
            &mut err,
        );
        let body = read_and_free(p).expect("verdict null");
        let v: Value = serde_json::from_str(&body).unwrap();
        assert_eq!(v["allowed"], true);
        let _ = read_and_free(mutated);
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

#[test]
fn validate_state_with_invocation_json() {
    let yaml = r#"
metadata:
  name: "ffi-state"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["block unless authorized"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "echo"
      description: "echo"
      permission: "read_only"
state_validation:
  guard_policies:
    - name: "echo_only_when_authorized"
      applies_to:
        tools: ["echo"]
      evaluate_when:
        - expression: "authorized == true"
          reason: "auth required"
      action: "block"
variables:
  - name: "authorized"
    type: "boolean"
    default: false
"#;
    unsafe {
        let rt = build_runtime_with(yaml);
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        let inv = cstr(r#"{"kind":"tool","name":"echo","params":{"msg":"hi"}}"#);
        let p = shield_session_validate_state(s, inv.as_ptr(), &mut err);
        let body = read_and_free(p).expect("verdict null");
        let v: Value = serde_json::from_str(&body).unwrap();
        assert_eq!(v["allowed"], false);
        // Now authorize and re-run.
        shield_session_set_variable(
            s,
            cstr("authorized").as_ptr(),
            cstr("true").as_ptr(),
            &mut err,
        );
        let p2 = shield_session_validate_state(s, inv.as_ptr(), &mut err);
        let body2 = read_and_free(p2).expect("verdict null");
        let v2: Value = serde_json::from_str(&body2).unwrap();
        assert_eq!(v2["allowed"], true);
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

// ────────────────────────────────────────────────────────────────────
// 6) Resource cycle helpers
// ────────────────────────────────────────────────────────────────────

#[test]
fn record_tool_success_runs_populator_and_emits_event() {
    let yaml = r#"
metadata:
  name: "ffi-pop"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["populate"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "lookup"
      description: "lookup"
      permission: "read_only"
variables:
  - name: "user_role"
    type: "string"
    default: "guest"
    populated_by:
      - kind: "tool"
        name: "lookup"
        phase: "after"
        expression: "@result.user_role"
"#;
    unsafe {
        let rt = build_runtime_with(yaml);
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        let rc = shield_session_record_tool_success(
            s,
            cstr("lookup").as_ptr(),
            cstr(r#"{"user_role":"admin"}"#).as_ptr(),
            &mut err,
        );
        assert_eq!(rc, 0, "err: {:?}", drain_err(&mut err));
        let p = shield_session_read_variable(s, cstr("user_role").as_ptr(), &mut err);
        let body = read_and_free(p).expect("read null");
        let v: Value = serde_json::from_str(&body).unwrap();
        assert_eq!(v["value"], "admin");
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

#[test]
fn record_tool_failure_sets_payload() {
    unsafe {
        let rt = build_runtime_minimal();
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        let rc = shield_session_record_tool_failure(
            s,
            cstr("echo").as_ptr(),
            cstr("boom").as_ptr(),
            &mut err,
        );
        assert_eq!(rc, 0);
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

#[test]
fn record_endpoint_and_agent_helpers_succeed() {
    unsafe {
        let rt = build_runtime_minimal();
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        assert_eq!(
            0,
            shield_session_record_endpoint_success(
                s,
                cstr("POST").as_ptr(),
                cstr("/v1/x").as_ptr(),
                cstr("{}").as_ptr(),
                &mut err,
            )
        );
        assert_eq!(
            0,
            shield_session_record_endpoint_failure(
                s,
                cstr("POST").as_ptr(),
                cstr("/v1/x").as_ptr(),
                cstr("down").as_ptr(),
                &mut err,
            )
        );
        assert_eq!(
            0,
            shield_session_record_agent_success(
                s,
                cstr("planner").as_ptr(),
                cstr(r#"{"plan":"x"}"#).as_ptr(),
                &mut err,
            )
        );
        assert_eq!(
            0,
            shield_session_record_agent_failure(
                s,
                cstr("planner").as_ptr(),
                cstr("timeout").as_ptr(),
                &mut err,
            )
        );
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

// ────────────────────────────────────────────────────────────────────
// 7) Streaming
// ────────────────────────────────────────────────────────────────────

#[test]
fn streaming_session_pushes_and_finishes() {
    unsafe {
        let rt = build_runtime_minimal();
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        let stream = shield_session_streaming_session(s, 5, &mut err);
        assert!(!stream.is_null());
        let p = shield_stream_push(stream, cstr("hello world").as_ptr(), &mut err);
        let pushed = read_and_free(p).expect("push null");
        let v: Value = serde_json::from_str(&pushed).unwrap();
        assert!(["pass", "replace", "stop"].contains(&v["action"].as_str().unwrap()));
        let p2 = shield_stream_finish(stream, &mut err);
        let finished = read_and_free(p2).expect("finish null");
        let v2: Value = serde_json::from_str(&finished).unwrap();
        assert!(v2["action"].is_string());
        shield_stream_free(stream);
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

#[test]
fn streaming_session_invalid_stage_errors() {
    unsafe {
        let rt = build_runtime_minimal();
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        let stream = shield_session_streaming_session(s, 1, &mut err);
        assert!(stream.is_null());
        let msg = drain_err(&mut err).unwrap_or_default();
        assert!(msg.contains("stage"), "got: {msg}");
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

#[test]
fn streaming_session_redacts_pattern() {
    let yaml = r#"
metadata:
  name: "ffi-stream"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["redact ssn"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "noop"
      description: "noop"
      permission: "read_only"
output_validation:
  guard_policies:
    - name: "scrub"
      evaluate_when:
        - pattern: "\\d{3}-\\d{2}-\\d{4}"
          reason: "SSN"
      action: "redact"
      replacement: "[REDACTED]"
"#;
    unsafe {
        let rt = build_runtime_with(yaml);
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        let stream = shield_session_streaming_session(s, 5, &mut err);
        assert!(!stream.is_null());
        let _ = shield_stream_push(stream, cstr("My ssn is 123-45-6789 ok?").as_ptr(), &mut err);
        let p = shield_stream_finish(stream, &mut err);
        let body = read_and_free(p).expect("finish null");
        let v: Value = serde_json::from_str(&body).unwrap();
        let payload = v["payload"].as_str().unwrap_or("");
        assert!(!payload.contains("123-45-6789"), "got: {payload}");
        shield_stream_free(stream);
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

// ────────────────────────────────────────────────────────────────────
// 8) Resolver-envelope callback (block-unless-approved Stage 4 flow)
//
// We exercise the C-ABI callback path via `kind: agent` since that is
// the canonical host-callback resolver under the refactored design.
// `kind: human` is now a thin shim over `kind: tool`'s
// signal-and-suspend path — it does not touch the C callback ABI;
// see `human_resolver_kind_emits_canonical_tool_signal_via_ffi` below
// for that surface.
// ────────────────────────────────────────────────────────────────────

// One-shot stub allocator and free-callback.
static APPROVAL_INVOCATIONS: AtomicUsize = AtomicUsize::new(0);

unsafe extern "C" fn approve_always(
    _req: *const ShieldResolverRequest,
    _user_data: *mut c_void,
) -> *mut c_char {
    APPROVAL_INVOCATIONS.fetch_add(1, Ordering::SeqCst);
    let s = r#"{"decision":"allow","value":true,"reason":"ok"}"#;
    let cs = CString::new(s).unwrap();
    cs.into_raw()
}

unsafe extern "C" fn deny_always(
    _req: *const ShieldResolverRequest,
    _user_data: *mut c_void,
) -> *mut c_char {
    let s = r#"{"decision":"deny","reason":"no"}"#;
    let cs = CString::new(s).unwrap();
    cs.into_raw()
}

unsafe extern "C" fn free_via_cstring(ptr: *mut c_char, _user_data: *mut c_void) {
    if !ptr.is_null() {
        drop(CString::from_raw(ptr));
    }
}

const AGENT_RESOLVER_YAML: &str = r#"
metadata:
  name: "ffi-agent-resolver"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["x"]
  forbidden: ["y"]
resources:
  tools:
    - name: "send"
      description: "send"
      permission: "read_write"
variables:
  - name: "send_authorized"
    type: "boolean"
    default: false
    on_demand_by:
      kind: agent
      prompt: "Authorize send?"
"#;

#[test]
fn agent_resolver_callback_allow_marks_variable_resolved() {
    unsafe {
        APPROVAL_INVOCATIONS.store(0, Ordering::SeqCst);
        let yaml = cstr(AGENT_RESOLVER_YAML);
        let mut err: *mut c_char = std::ptr::null_mut();
        let b = shield_builder_from_config_json(yaml.as_ptr(), &mut err);
        assert!(!b.is_null());
        shield_builder_register_agent_resolver(
            b,
            Some(approve_always),
            Some(free_via_cstring),
            std::ptr::null_mut(),
            &mut err,
        );
        let rt = shield_builder_build(b, &mut err);
        assert!(!rt.is_null());
        shield_builder_free(b);
        let s = open_session(rt);
        let p = shield_session_resolve_variable(s, cstr("send_authorized").as_ptr(), &mut err);
        let body = read_and_free(p).expect("resolve null");
        // Body should be `true` (the resolver's value).
        assert_eq!(body, "true", "got: {body}");
        // Confirm the C callback actually fired.
        assert!(APPROVAL_INVOCATIONS.load(Ordering::SeqCst) >= 1);
        // The variable should be resolved now.
        let p2 = shield_session_read_variable(s, cstr("send_authorized").as_ptr(), &mut err);
        let st = read_and_free(p2).expect("read null");
        let v: Value = serde_json::from_str(&st).unwrap();
        assert_eq!(v["status"], "resolved");
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

#[test]
fn agent_resolver_callback_deny_returns_null_value() {
    unsafe {
        let yaml = cstr(AGENT_RESOLVER_YAML);
        let mut err: *mut c_char = std::ptr::null_mut();
        let b = shield_builder_from_config_json(yaml.as_ptr(), &mut err);
        assert!(!b.is_null());
        shield_builder_register_agent_resolver(
            b,
            Some(deny_always),
            Some(free_via_cstring),
            std::ptr::null_mut(),
            &mut err,
        );
        let rt = shield_builder_build(b, &mut err);
        assert!(!rt.is_null());
        shield_builder_free(b);
        let s = open_session(rt);
        let p = shield_session_resolve_variable(s, cstr("send_authorized").as_ptr(), &mut err);
        let body = read_and_free(p).expect("resolve null");
        // Deny → no value → "null".
        assert_eq!(body, "null", "got: {body}");
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

const HUMAN_RESOLVER_YAML: &str = r#"
metadata:
  name: "ffi-human-shim"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["x"]
  forbidden: ["y"]
resources:
  tools:
    - name: "send"
      description: "send"
      permission: "read_write"
variables:
  - name: "send_authorized"
    type: "boolean"
    default: false
    on_demand_by:
      kind: human
      prompt: "Authorize send?"
"#;

/// `kind: human` no longer touches the C-ABI host callback. Instead the
/// runtime emits a `pending_resolution` deny that names the canonical
/// `agent_shield.ask_human` MCP tool. This test asserts that surface
/// through FFI: no callback is registered, but the runtime still
/// produces a structured deny that tells the agent which tool to call.
#[test]
fn human_resolver_kind_emits_canonical_tool_signal_via_ffi() {
    unsafe {
        let yaml = cstr(HUMAN_RESOLVER_YAML);
        let mut err: *mut c_char = std::ptr::null_mut();
        let b = shield_builder_from_config_json(yaml.as_ptr(), &mut err);
        assert!(!b.is_null());
        let rt = shield_builder_build(b, &mut err);
        assert!(!rt.is_null());
        shield_builder_free(b);
        let s = open_session(rt);
        // Resolving the variable surfaces no value (the resolver
        // suspended) but does NOT crash and does NOT need a callback.
        let p = shield_session_resolve_variable(s, cstr("send_authorized").as_ptr(), &mut err);
        let body = read_and_free(p).expect("resolve null");
        assert_eq!(body, "null", "kind: human suspends and yields null");
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

// ────────────────────────────────────────────────────────────────────
// 9) Observability provider callback
// ────────────────────────────────────────────────────────────────────

static LOG_EVENTS: Mutex<Vec<String>> = Mutex::new(Vec::new());

unsafe extern "C" fn log_capture(event_json: *const c_char, _user_data: *mut c_void) {
    if event_json.is_null() {
        return;
    }
    if let Ok(s) = CStr::from_ptr(event_json).to_str() {
        LOG_EVENTS.lock().unwrap().push(s.to_string());
    }
}

#[test]
fn observability_callback_receives_events() {
    unsafe {
        LOG_EVENTS.lock().unwrap().clear();
        let yaml = cstr(MINIMAL_YAML);
        let mut err: *mut c_char = std::ptr::null_mut();
        let b = shield_builder_from_config_json(yaml.as_ptr(), &mut err);
        assert!(!b.is_null());
        shield_builder_register_observability_provider(
            b,
            Some(log_capture),
            std::ptr::null_mut(),
            &mut err,
        );
        let rt = shield_builder_build(b, &mut err);
        shield_builder_free(b);
        // Open a session to trigger session_start and force a few events.
        let s = open_session(rt);
        let _ = shield_session_begin_turn(s, &mut err);
        let mut mp: *mut c_char = std::ptr::null_mut();
        let p = shield_session_validate_tool_call(
            s,
            cstr("echo").as_ptr(),
            cstr("{}").as_ptr(),
            cstr("call_1").as_ptr(),
            &mut mp,
            &mut err,
        );
        let _ = read_and_free(p);
        let _ = read_and_free(mp);
        shield_session_free(s);
        shield_runtime_free(rt);
        let events = LOG_EVENTS.lock().unwrap();
        assert!(
            !events.is_empty(),
            "expected at least one log event from session lifecycle"
        );
    }
}

// ────────────────────────────────────────────────────────────────────
// 10) tool_retry_limit / streaming_window builder knobs
// ────────────────────────────────────────────────────────────────────

#[test]
fn tool_retry_limit_does_not_break_build() {
    unsafe {
        let b = build_minimal();
        shield_builder_tool_retry_limit(b, 7);
        let mut err: *mut c_char = std::ptr::null_mut();
        let rt = shield_builder_build(b, &mut err);
        assert!(!rt.is_null());
        shield_builder_free(b);
        shield_runtime_free(rt);
    }
}

#[test]
fn streaming_window_does_not_break_build() {
    unsafe {
        let b = build_minimal();
        shield_builder_streaming_window(b, 2 /* PerChunk */, 200, 50);
        let mut err: *mut c_char = std::ptr::null_mut();
        let rt = shield_builder_build(b, &mut err);
        assert!(!rt.is_null());
        shield_builder_free(b);
        shield_runtime_free(rt);
    }
}

// ────────────────────────────────────────────────────────────────────
// 11) Misc — null safety on session/state operations
// ────────────────────────────────────────────────────────────────────

#[test]
fn session_ops_with_null_session_return_errors() {
    unsafe {
        let mut err: *mut c_char = std::ptr::null_mut();
        let null_s: *mut ShieldSession = std::ptr::null_mut();
        let rc =
            shield_session_set_variable(null_s, cstr("x").as_ptr(), cstr("1").as_ptr(), &mut err);
        assert_eq!(rc, -1);
        let _ = drain_err(&mut err);
        let p = shield_session_validate_input(null_s, cstr("x").as_ptr(), &mut err);
        assert!(p.is_null());
        let _ = drain_err(&mut err);
    }
}

#[test]
fn session_validate_input_null_input_errors() {
    unsafe {
        let rt = build_runtime_minimal();
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        let p = shield_session_validate_input(s, std::ptr::null(), &mut err);
        assert!(p.is_null());
        let msg = drain_err(&mut err).unwrap_or_default();
        assert!(msg.contains("null"), "got: {msg}");
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

#[test]
fn validate_state_invalid_invocation_errors() {
    unsafe {
        let rt = build_runtime_minimal();
        let s = open_session(rt);
        let mut err: *mut c_char = std::ptr::null_mut();
        let p = shield_session_validate_state(s, cstr(r#"{"kind":"bogus"}"#).as_ptr(), &mut err);
        assert!(p.is_null());
        let msg = drain_err(&mut err).unwrap_or_default();
        assert!(
            msg.contains("unknown") || msg.contains("kind"),
            "got: {msg}"
        );
        shield_session_free(s);
        shield_runtime_free(rt);
    }
}

// ────────────────────────────────────────────────────────────────────
// 12) yaml_chain with single path
// ────────────────────────────────────────────────────────────────────

#[test]
fn yaml_chain_with_single_path() {
    let manifest = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    let p = manifest
        .join("../../..")
        .join("tests/fixtures/smoke/minimal.guardrails.yaml")
        .to_string_lossy()
        .to_string();
    unsafe {
        let path_c = cstr(&p);
        let arr: [*const c_char; 1] = [path_c.as_ptr()];
        let mut err: *mut c_char = std::ptr::null_mut();
        let b = shield_builder_from_yaml_chain(arr.as_ptr(), 1, &mut err);
        assert!(!b.is_null(), "err: {:?}", drain_err(&mut err));
        let rt = shield_builder_build(b, &mut err);
        assert!(!rt.is_null());
        shield_builder_free(b);
        shield_runtime_free(rt);
    }
}

// Silence unused-import warning: c_void is used via callback signatures.
#[allow(dead_code)]
fn _force_use_c_void(_: *mut c_void) {}

// Silence unused-import warning: ptr::null is implicitly used.
#[allow(dead_code)]
fn _force_use_ptr() {
    let _ = ptr::null::<u8>();
    let _ = json!({});
}
