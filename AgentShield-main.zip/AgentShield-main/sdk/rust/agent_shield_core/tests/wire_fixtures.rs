//! Cross-language wire-shape golden fixture conformance — Rust side.
//!
//! Mirrors the Python (`tests/test_wire_fixtures.py`), Node
//! (`__tests__/wire_fixtures.test.ts`), and .NET
//! (`WireFixtureTests.cs`) suites. Every fixture under
//! `tests/fixtures/wire/` is loaded and validated against its schema
//! under `spec/schemas/wire/`.
//!
//! Phase 0 of the SDK minimisation plan — drift detection across all
//! four implementations.

use std::fs;
use std::path::{Path, PathBuf};

use jsonschema::Validator;
use serde_json::Value;

fn repo_root() -> PathBuf {
    let mut path = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    while !path.join(".git").exists() {
        if !path.pop() {
            panic!("could not locate repo root");
        }
    }
    path
}

fn fixtures_dir() -> PathBuf {
    repo_root().join("tests").join("fixtures").join("wire")
}

fn schemas_dir() -> PathBuf {
    repo_root().join("spec").join("schemas").join("wire")
}

fn list_shape_dirs() -> Vec<PathBuf> {
    let mut dirs: Vec<PathBuf> = fs::read_dir(fixtures_dir())
        .expect("fixtures dir")
        .filter_map(|e| e.ok().map(|e| e.path()))
        .filter(|p| p.is_dir())
        .collect();
    dirs.sort();
    dirs
}

fn list_fixtures(shape_dir: &Path) -> Vec<PathBuf> {
    let mut files: Vec<PathBuf> = fs::read_dir(shape_dir)
        .expect("shape dir")
        .filter_map(|e| e.ok().map(|e| e.path()))
        .filter(|p| p.extension().and_then(|s| s.to_str()) == Some("json"))
        .collect();
    files.sort();
    files
}

fn load_json(path: &Path) -> Value {
    let text =
        fs::read_to_string(path).unwrap_or_else(|e| panic!("read {}: {}", path.display(), e));
    serde_json::from_str(&text).unwrap_or_else(|e| panic!("parse {}: {}", path.display(), e))
}

fn compile_validator(schema_path: &Path) -> Validator {
    let mut schema = load_json(schema_path);
    // jsonschema 0.30 rejects fragment-bearing `$id`s like
    // "https://.../foo.schema.json#v2.0.0-prototype" because RFC 3986
    // says base URIs can't carry fragments. Our version pinning
    // convention puts the version in the fragment for human
    // readability; strip it before compiling so the spec contract
    // doesn't fight the validator's strictness.
    if let Some(id) = schema
        .as_object_mut()
        .and_then(|m| m.get_mut("$id"))
        .and_then(|v| v.as_str().map(|s| s.to_owned()))
    {
        if let Some(idx) = id.find('#') {
            let stripped = &id[..idx];
            schema
                .as_object_mut()
                .unwrap()
                .insert("$id".to_string(), Value::String(stripped.to_string()));
        }
    }
    jsonschema::draft7::new(&schema)
        .unwrap_or_else(|e| panic!("compile {}: {}", schema_path.display(), e))
}

fn all_keys(v: &Value, out: &mut Vec<String>) {
    match v {
        Value::Object(map) => {
            for (k, child) in map {
                out.push(k.clone());
                all_keys(child, out);
            }
        }
        Value::Array(items) => {
            for item in items {
                all_keys(item, out);
            }
        }
        _ => {}
    }
}

#[test]
fn every_schema_has_at_least_one_fixture() {
    for entry in fs::read_dir(schemas_dir()).unwrap() {
        let path = entry.unwrap().path();
        if path.extension().and_then(|s| s.to_str()) != Some("json") {
            continue;
        }
        let stem = path
            .file_stem()
            .and_then(|s| s.to_str())
            .unwrap()
            .replace(".schema", "");
        let dir = fixtures_dir().join(&stem);
        assert!(
            dir.is_dir(),
            "schema {} has no fixtures dir at {}",
            path.display(),
            dir.display(),
        );
        let fixtures = list_fixtures(&dir);
        assert!(
            !fixtures.is_empty(),
            "schema {} has no fixtures in {}",
            path.display(),
            dir.display(),
        );
    }
}

#[test]
fn no_orphan_fixture_directories() {
    for shape_dir in list_shape_dirs() {
        let shape = shape_dir.file_name().unwrap().to_str().unwrap();
        let schema = schemas_dir().join(format!("{shape}.schema.json"));
        assert!(
            schema.exists(),
            "fixture directory {} has no matching schema at {}",
            shape,
            schema.display(),
        );
    }
}

#[test]
fn every_fixture_validates_against_its_schema() {
    let mut tested = 0;
    let mut failed: Vec<String> = Vec::new();

    for shape_dir in list_shape_dirs() {
        let shape = shape_dir.file_name().unwrap().to_str().unwrap().to_owned();
        let schema_path = schemas_dir().join(format!("{shape}.schema.json"));
        let validator = compile_validator(&schema_path);

        for fixture_path in list_fixtures(&shape_dir) {
            tested += 1;
            let fixture = load_json(&fixture_path);
            if let Err(err) = validator.validate(&fixture) {
                failed.push(format!("{}: {}", fixture_path.display(), err));
            }
        }
    }

    assert!(
        failed.is_empty(),
        "{} of {} fixtures failed validation:\n{}",
        failed.len(),
        tested,
        failed.join("\n"),
    );
    assert!(tested > 0, "no fixtures tested — repo layout broken?");
}

#[test]
fn every_fixture_round_trips_through_serde_json() {
    let mut tested = 0;
    for shape_dir in list_shape_dirs() {
        let shape = shape_dir.file_name().unwrap().to_str().unwrap().to_owned();
        let schema_path = schemas_dir().join(format!("{shape}.schema.json"));
        let validator = compile_validator(&schema_path);

        for fixture_path in list_fixtures(&shape_dir) {
            tested += 1;
            let value = load_json(&fixture_path);
            let serialised = serde_json::to_string(&value).unwrap();
            let reparsed: Value = serde_json::from_str(&serialised).unwrap();
            validator
                .validate(&reparsed)
                .unwrap_or_else(|e| panic!("round-trip {} failed: {}", fixture_path.display(), e));
        }
    }
    assert!(tested > 0);
}

#[test]
fn every_fixture_uses_snake_case_keys() {
    for shape_dir in list_shape_dirs() {
        for fixture_path in list_fixtures(&shape_dir) {
            let value = load_json(&fixture_path);
            let mut keys = Vec::new();
            all_keys(&value, &mut keys);
            for key in &keys {
                assert!(
                    !key.chars().any(|c| c.is_ascii_uppercase()),
                    "key {:?} in {} has uppercase characters \
                     (canonical wire format is snake_case)",
                    key,
                    fixture_path.display(),
                );
            }
        }
    }
}
