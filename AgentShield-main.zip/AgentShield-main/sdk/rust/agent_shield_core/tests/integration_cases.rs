//! Cross-language integration test runner for Agent Shield (Rust).
//!
//! Loads shared YAML test cases from `tests/cases/` and shared fixtures
//! from `tests/fixtures/`, then runs each case directly against
//! [`agent_shield_core`]'s [`RuntimeBuilder`] / [`GuardrailsRuntime`] /
//! [`GuardrailsSession`].
//!
//! Mirrors the Python (`sdk/python/tests/test_integration_cases.py`), Node
//! (`sdk/node/__tests__/integration_cases.test.mjs`), and .NET
//! (`sdk/dotnet/tests/AgentShield.Tests/IntegrationCaseTests.cs`)
//! runners — this is the Rust leg of the cross-language parity matrix.
//!
//! Schema reference: `tests/cases/test-cases.schema.json`. The runner
//! recognizes the action / assertion verbs that the shared cases
//! actually use today; unknown verbs cause a per-case failure with an
//! explicit message rather than a silent skip.

use std::fs;
use std::path::{Path, PathBuf};
use std::sync::Arc;

use agent_shield_core::{
    guard_policy::Action, guard_policy_runtime::ClassifierCaller,
    guard_policy_runtime::ClassifierVerdict, guard_policy_runtime::LlmCaller,
    guard_policy_runtime::LlmDecision, guard_policy_runtime::LlmResponse,
    guard_policy_runtime::StageVerdict, lifetime::parse_lifetime, GuardrailsRuntime,
    GuardrailsSession, RequestContext, RuntimeBuilder,
};
use serde_json::Value as JsonValue;
use serde_yaml::Value as YamlValue;

// ── Path resolution ─────────────────────────────────────────────────

fn repo_root() -> PathBuf {
    // CARGO_MANIFEST_DIR points at sdk/rust/agent_shield_core; the
    // repository root is three directories up.
    let manifest = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    manifest
        .join("..")
        .join("..")
        .join("..")
        .canonicalize()
        .expect("repo root canonicalize")
}

fn cases_dir() -> PathBuf {
    repo_root().join("tests").join("cases")
}

fn fixtures_dir() -> PathBuf {
    repo_root().join("tests").join("fixtures")
}

fn find_fixture(name: &str) -> Option<PathBuf> {
    let direct = fixtures_dir().join(name);
    if direct.is_file() {
        return Some(direct);
    }
    let leaf = Path::new(name).file_name()?;
    if let Ok(entries) = fs::read_dir(fixtures_dir()) {
        for entry in entries.flatten() {
            let candidate = entry.path().join(leaf);
            if candidate.is_file() {
                return Some(candidate);
            }
        }
    }
    None
}

// ── YAML helpers ────────────────────────────────────────────────────

fn yaml_to_json(node: &YamlValue) -> JsonValue {
    match node {
        YamlValue::Null => JsonValue::Null,
        YamlValue::Bool(b) => JsonValue::Bool(*b),
        YamlValue::Number(n) => {
            if let Some(i) = n.as_i64() {
                JsonValue::Number(i.into())
            } else if let Some(u) = n.as_u64() {
                JsonValue::Number(u.into())
            } else if let Some(f) = n.as_f64() {
                serde_json::Number::from_f64(f)
                    .map(JsonValue::Number)
                    .unwrap_or(JsonValue::Null)
            } else {
                JsonValue::Null
            }
        }
        YamlValue::String(s) => JsonValue::String(s.clone()),
        YamlValue::Sequence(seq) => JsonValue::Array(seq.iter().map(yaml_to_json).collect()),
        YamlValue::Mapping(map) => {
            let mut obj = serde_json::Map::with_capacity(map.len());
            for (k, v) in map {
                let key = match k {
                    YamlValue::String(s) => s.clone(),
                    other => serde_yaml::to_string(other)
                        .unwrap_or_default()
                        .trim()
                        .to_string(),
                };
                obj.insert(key, yaml_to_json(v));
            }
            JsonValue::Object(obj)
        }
        YamlValue::Tagged(t) => yaml_to_json(&t.value),
    }
}

fn map_get<'a>(node: &'a YamlValue, key: &str) -> Option<&'a YamlValue> {
    node.as_mapping()
        .and_then(|m| m.get(YamlValue::String(key.to_string())))
}

fn get_str(node: &YamlValue, key: &str) -> Option<String> {
    map_get(node, key)
        .and_then(|v| v.as_str())
        .map(|s| s.to_string())
}

fn get_str_list(node: &YamlValue, key: &str) -> Option<Vec<String>> {
    let v = map_get(node, key)?;
    match v {
        YamlValue::Sequence(seq) => Some(
            seq.iter()
                .filter_map(|x| x.as_str().map(|s| s.to_string()))
                .collect(),
        ),
        YamlValue::String(s) => Some(vec![s.clone()]),
        _ => None,
    }
}

// ── Default-allow LLM / classifier callers (mirrors Python harness) ─

struct AllowLlm;
impl LlmCaller for AllowLlm {
    fn call(&self, _cfg: Option<&str>, _prompt: &str) -> Result<LlmResponse, String> {
        Ok(LlmResponse {
            decision: Some(LlmDecision::Allow),
            ..LlmResponse::default()
        })
    }
}

struct AllowClassifier;
impl ClassifierCaller for AllowClassifier {
    fn classify(&self, _cfg: &str, _subject: &str) -> Result<ClassifierVerdict, String> {
        Ok(ClassifierVerdict {
            score: 0.0,
            threshold: 0.5,
            flagged: false,
            ..ClassifierVerdict::default()
        })
    }
}

// ── Runtime construction ────────────────────────────────────────────

fn build_runtime(paths: &[PathBuf]) -> Result<Arc<GuardrailsRuntime>, String> {
    let builder = if paths.len() == 1 {
        RuntimeBuilder::from_yaml(&paths[0]).map_err(|e| format!("from_yaml: {e:?}"))?
    } else {
        RuntimeBuilder::from_yaml_chain(paths).map_err(|e| format!("from_yaml_chain: {e:?}"))?
    };
    builder
        .register_llm_caller(Arc::new(AllowLlm))
        .register_classifier_caller(Arc::new(AllowClassifier))
        .build()
        .map_err(|e| format!("build: {e:?}"))
}

fn open_session(rt: &Arc<GuardrailsRuntime>) -> GuardrailsSession {
    let session = rt.new_session(RequestContext::default());
    // Open per_turn / per_request boundaries so populator phases tied
    // to those lifetimes engage. Mirrors the other harnesses; the
    // session API ignores duplicate calls.
    let _ = session.begin_request();
    let _ = session.begin_turn();
    session
}

// ── Action execution ────────────────────────────────────────────────

/// What a single action returns. `Verdict` carries a stage verdict plus
/// the surfaced text (mutated string for output / JSON-encoded mutated
/// value for tool output / verdict.redaction for input). `None` is for
/// pure-state actions like `set_variable`.
enum ActionOutcome {
    Verdict { verdict: StageVerdict, text: String },
    None,
}

fn execute_action(session: &GuardrailsSession, when: &YamlValue) -> Result<ActionOutcome, String> {
    let verb = get_str(when, "action")
        .or_else(|| get_str(when, "type"))
        .ok_or_else(|| "missing 'action' field on when block".to_string())?;
    let params = map_get(when, "params").cloned().unwrap_or(YamlValue::Null);

    match verb.as_str() {
        "validate_input" => {
            let input = get_str(&params, "input")
                .or_else(|| get_str(when, "input"))
                .unwrap_or_default();
            let verdict = session.validate_input(&input);
            // `validate_input` doesn't take a `&mut`; redacted text (if
            // any) lives on the verdict.
            let text = verdict
                .redaction
                .clone()
                .or_else(|| verdict.appended.clone())
                .or_else(|| verdict.prepended.clone())
                .unwrap_or_else(|| input.clone());
            Ok(ActionOutcome::Verdict { verdict, text })
        }
        "validate_tool_call" => {
            let tool_name = get_str(&params, "tool_name")
                .or_else(|| get_str(when, "tool_name"))
                .unwrap_or_default();
            let raw_params = map_get(&params, "tool_params")
                .or_else(|| map_get(when, "tool_params"))
                .map(yaml_to_json)
                .unwrap_or_else(|| JsonValue::Object(Default::default()));
            let mut tool_params = raw_params;
            let tool_call_id = get_str(&params, "tool_call_id")
                .or_else(|| get_str(when, "tool_call_id"))
                .unwrap_or_else(|| "case_invocation".to_string());
            let verdict = session.validate_tool_call(&tool_name, &mut tool_params, &tool_call_id);
            let text = serde_json::to_string(&tool_params).unwrap_or_default();
            Ok(ActionOutcome::Verdict { verdict, text })
        }
        "validate_tool_output" => {
            let tool_name = get_str(&params, "tool_name")
                .or_else(|| get_str(when, "tool_name"))
                .unwrap_or_else(|| "unknown_tool".to_string());
            let raw = map_get(&params, "output")
                .or_else(|| map_get(&params, "result"))
                .or_else(|| map_get(when, "output"))
                .or_else(|| map_get(when, "result"))
                .map(yaml_to_json)
                .unwrap_or(JsonValue::Null);
            let tool_call_id = get_str(&params, "tool_call_id")
                .or_else(|| get_str(when, "tool_call_id"))
                .unwrap_or_else(|| "case_invocation".to_string());
            // First attempt: run Stage 4 directly. If a paired Stage 3
            // step in this case already bound the invocation, this is
            // the expected path.
            let mut result = raw.clone();
            let mut verdict = session.validate_tool_output(&tool_name, &mut result, &tool_call_id);
            // §16.0 fallback: many cross-language case fixtures exercise
            // Stage 4 in isolation. If the first attempt fails closed
            // with `<binding>` we transparently emit a Stage 3 admit so
            // the test continues to exercise the Stage-4 policy logic
            // rather than the binding-missing fail-closed path.
            if !verdict.allowed && verdict.policy.as_deref() == Some("<binding>") {
                let mut prebind_params = map_get(&params, "tool_params")
                    .or_else(|| map_get(when, "tool_params"))
                    .map(yaml_to_json)
                    .unwrap_or_else(|| JsonValue::Object(Default::default()));
                let _ = session.validate_tool_call(&tool_name, &mut prebind_params, &tool_call_id);
                result = raw;
                verdict = session.validate_tool_output(&tool_name, &mut result, &tool_call_id);
            }
            // Surface the post-redaction text representation: if the
            // mutated result is a JSON string, expose the raw string;
            // otherwise the canonical JSON.
            let text = match &result {
                JsonValue::String(s) => s.clone(),
                _ => serde_json::to_string(&result).unwrap_or_default(),
            };
            Ok(ActionOutcome::Verdict { verdict, text })
        }
        "validate_endpoint_call" => {
            let method = get_str(&params, "method")
                .or_else(|| get_str(when, "method"))
                .unwrap_or_else(|| "GET".to_string());
            let uri = get_str(&params, "path")
                .or_else(|| get_str(&params, "uri"))
                .or_else(|| get_str(&params, "url"))
                .or_else(|| get_str(when, "path"))
                .or_else(|| get_str(when, "url"))
                .unwrap_or_default();
            let mut body = map_get(&params, "body")
                .or_else(|| map_get(&params, "query_params"))
                .map(yaml_to_json)
                .unwrap_or(JsonValue::Null);
            let tool_call_id = get_str(&params, "tool_call_id")
                .or_else(|| get_str(when, "tool_call_id"))
                .unwrap_or_else(|| "case_invocation".to_string());
            let verdict = session.validate_endpoint_call(&method, &uri, &mut body, &tool_call_id);
            let text = serde_json::to_string(&body).unwrap_or_default();
            Ok(ActionOutcome::Verdict { verdict, text })
        }
        "validate_agent_call" => {
            let agent_name = get_str(&params, "agent_name")
                .or_else(|| get_str(when, "agent_name"))
                .unwrap_or_default();
            let mut agent_params = map_get(&params, "agent_params")
                .or_else(|| map_get(when, "agent_params"))
                .map(yaml_to_json)
                .unwrap_or_else(|| JsonValue::Object(Default::default()));
            let tool_call_id = get_str(&params, "tool_call_id")
                .or_else(|| get_str(when, "tool_call_id"))
                .unwrap_or_else(|| "case_invocation".to_string());
            let verdict =
                session.validate_agent_call(&agent_name, &mut agent_params, &tool_call_id);
            let text = serde_json::to_string(&agent_params).unwrap_or_default();
            Ok(ActionOutcome::Verdict { verdict, text })
        }
        "validate_output" => {
            let initial = get_str(&params, "output")
                .or_else(|| get_str(when, "output"))
                .unwrap_or_default();
            let mut response = initial;
            let verdict = session.validate_output(&mut response);
            Ok(ActionOutcome::Verdict {
                verdict,
                text: response,
            })
        }
        "set_variable" => {
            let name = get_str(&params, "name")
                .or_else(|| get_str(when, "name"))
                .ok_or_else(|| "set_variable: missing name".to_string())?;
            let value = map_get(&params, "value")
                .or_else(|| map_get(when, "value"))
                .map(yaml_to_json)
                .unwrap_or(JsonValue::Null);
            session
                .set_variable(&name, value)
                .map_err(|e| format!("set_variable({name}): {e:?}"))?;
            Ok(ActionOutcome::None)
        }
        "reset_variable" => {
            let name = get_str(&params, "name")
                .or_else(|| get_str(when, "name"))
                .ok_or_else(|| "reset_variable: missing name".to_string())?;
            session
                .reset_variable(&name)
                .map_err(|e| format!("reset_variable({name}): {e:?}"))?;
            Ok(ActionOutcome::None)
        }
        "emit_event" => {
            let id = get_str(&params, "id")
                .or_else(|| get_str(when, "id"))
                .ok_or_else(|| "emit_event: missing id".to_string())?;
            let lifetime = params
                .get("lifetime")
                .or_else(|| when.get("lifetime"))
                .map(yaml_to_json)
                .map(|v| parse_lifetime(v))
                .transpose()
                .map_err(|e| format!("emit_event({id}): invalid lifetime: {e}"))?;
            let payload = params
                .get("payload")
                .or_else(|| when.get("payload"))
                .map(yaml_to_json);
            session
                .emit_event(&id, lifetime, payload)
                .map_err(|e| format!("emit_event({id}): {e:?}"))?;
            Ok(ActionOutcome::None)
        }
        "clear_event" => {
            let id = get_str(&params, "id")
                .or_else(|| get_str(when, "id"))
                .ok_or_else(|| "clear_event: missing id".to_string())?;
            session
                .clear_event(&id)
                .map_err(|e| format!("clear_event({id}): {e:?}"))?;
            Ok(ActionOutcome::None)
        }
        "emit_incident" => {
            let name = get_str(&params, "name")
                .or_else(|| get_str(when, "name"))
                .ok_or_else(|| "emit_incident: missing name".to_string())?;
            let payload = map_get(&params, "payload").map(yaml_to_json);
            session
                .emit_incident(&name, payload)
                .map_err(|e| format!("emit_incident({name}): {e:?}"))?;
            Ok(ActionOutcome::None)
        }
        "begin_turn" => {
            session
                .begin_turn()
                .map_err(|e| format!("begin_turn: {e:?}"))?;
            Ok(ActionOutcome::None)
        }
        "end_turn" => {
            session.end_turn().map_err(|e| format!("end_turn: {e:?}"))?;
            Ok(ActionOutcome::None)
        }
        "begin_request" => {
            session
                .begin_request()
                .map_err(|e| format!("begin_request: {e:?}"))?;
            Ok(ActionOutcome::None)
        }
        "end_request" => {
            session
                .end_request()
                .map_err(|e| format!("end_request: {e:?}"))?;
            Ok(ActionOutcome::None)
        }
        "record_tool_success" => {
            let tool = get_str(&params, "tool_name")
                .or_else(|| get_str(when, "tool_name"))
                .unwrap_or_default();
            let result = map_get(&params, "result")
                .or_else(|| map_get(when, "result"))
                .map(yaml_to_json)
                .unwrap_or(JsonValue::Null);
            session
                .record_tool_success(&tool, &result)
                .map_err(|e| format!("record_tool_success({tool}): {e:?}"))?;
            Ok(ActionOutcome::None)
        }
        "record_tool_failure" => {
            let tool = get_str(&params, "tool_name")
                .or_else(|| get_str(when, "tool_name"))
                .unwrap_or_default();
            let error = get_str(&params, "error")
                .or_else(|| get_str(when, "error"))
                .unwrap_or_default();
            session
                .record_tool_failure(&tool, &error)
                .map_err(|e| format!("record_tool_failure({tool}): {e:?}"))?;
            Ok(ActionOutcome::None)
        }
        other => Err(format!("unsupported action verb: {other}")),
    }
}

// ── Assertion checking ──────────────────────────────────────────────

fn action_str(action: Option<&Action>) -> &'static str {
    match action {
        Some(Action::Block) => "block",
        Some(Action::Redact) => "redact",
        Some(Action::Warn) => "warn",
        Some(Action::Append) => "append",
        Some(Action::Prepend) => "prepend",
        Some(Action::DeclassifyTo) => "declassify_to",
        None => "(none)",
    }
}

fn check_assertions(
    case_id: &str,
    outcome: &ActionOutcome,
    then: &YamlValue,
) -> Result<(), String> {
    let then_map = match then.as_mapping() {
        Some(m) => m,
        None => return Ok(()),
    };
    if then_map.is_empty() {
        return Ok(());
    }

    let (verdict, text) = match outcome {
        ActionOutcome::Verdict { verdict, text } => (Some(verdict), text.as_str()),
        ActionOutcome::None => (None, ""),
    };

    if let Some(want) = map_get(then, "allowed").and_then(|v| v.as_bool()) {
        let v = verdict.ok_or_else(|| {
            format!("[{case_id}] expected `allowed={want}` but action returned no verdict")
        })?;
        if v.allowed != want {
            return Err(format!(
                "[{case_id}] expected allowed={want}, got {} (action={}, policy={:?}, reason={:?})",
                v.allowed,
                action_str(v.action.as_ref()),
                v.policy,
                v.reason
            ));
        }
    }

    if let Some(want) = get_str(then, "expect_verdict_action") {
        let v = verdict
            .ok_or_else(|| format!("[{case_id}] expected verdict_action={want} but no verdict"))?;
        let got = action_str(v.action.as_ref());
        if got != want {
            return Err(format!(
                "[{case_id}] expected action={want}, got {got} (policy={:?}, reason={:?})",
                v.policy, v.reason
            ));
        }
    }

    if let Some(want) = get_str(then, "expect_verdict_reason") {
        let v =
            verdict.ok_or_else(|| format!("[{case_id}] expected verdict_reason but no verdict"))?;
        let actual = v.reason.clone().unwrap_or_default();
        if !actual.contains(&want) {
            return Err(format!(
                "[{case_id}] expected reason to contain {want:?}, got {actual:?}"
            ));
        }
    }

    if let Some(want) = get_str(then, "expect_verdict_policy") {
        let v = verdict
            .ok_or_else(|| format!("[{case_id}] expected verdict_policy={want} but no verdict"))?;
        let got = v.policy.clone().unwrap_or_default();
        if got != want {
            return Err(format!(
                "[{case_id}] expected policy={want}, got {got:?} (action={}, reason={:?})",
                action_str(v.action.as_ref()),
                v.reason
            ));
        }
    }

    if let Some(want) = get_str(then, "text_contains") {
        if !text.contains(&want) {
            return Err(format!(
                "[{case_id}] expected text to contain {want:?}; got {text:?}"
            ));
        }
    }

    if let Some(items) = get_str_list(then, "text_not_contains") {
        for item in items {
            if text.contains(&item) {
                return Err(format!(
                    "[{case_id}] expected text NOT to contain {item:?}; got {text:?}"
                ));
            }
        }
    }

    Ok(())
}

// ── Pre-state setup ─────────────────────────────────────────────────

fn seed_session(session: &GuardrailsSession, given: &YamlValue) -> Result<(), String> {
    if let Some(vars) = map_get(given, "variables").and_then(|v| v.as_mapping()) {
        for (k, v) in vars {
            let name = k
                .as_str()
                .ok_or_else(|| format!("non-string variable name: {:?}", k))?;
            session
                .set_variable(name, yaml_to_json(v))
                .map_err(|e| format!("seed set_variable({name}): {e:?}"))?;
        }
    }
    if let Some(events) = map_get(given, "events").and_then(|v| v.as_sequence()) {
        for entry in events {
            match entry {
                YamlValue::String(id) => {
                    session
                        .emit_event(id, None, None)
                        .map_err(|e| format!("seed emit_event({id}): {e:?}"))?;
                }
                YamlValue::Mapping(_) => {
                    let id =
                        get_str(entry, "id").ok_or_else(|| "event entry missing id".to_string())?;
                    let payload = map_get(entry, "payload").map(yaml_to_json);
                    session
                        .emit_event(&id, None, payload)
                        .map_err(|e| format!("seed emit_event({id}): {e:?}"))?;
                }
                _ => {}
            }
        }
    }
    Ok(())
}

// ── Case loading ────────────────────────────────────────────────────

struct LoadedCase {
    id: String,
    case: YamlValue,
    suite_fixture: Option<String>,
    suite_fixtures: Option<Vec<String>>,
}

fn load_all_cases() -> Vec<LoadedCase> {
    let mut out = Vec::new();
    let dir = cases_dir();
    let mut entries: Vec<PathBuf> = fs::read_dir(&dir)
        .unwrap_or_else(|_| panic!("cases dir not readable: {}", dir.display()))
        .filter_map(|e| e.ok().map(|e| e.path()))
        .filter(|p| {
            p.file_name()
                .and_then(|n| n.to_str())
                .map(|s| s.ends_with(".cases.yaml"))
                .unwrap_or(false)
        })
        .collect();
    entries.sort();

    for path in entries {
        let text =
            fs::read_to_string(&path).unwrap_or_else(|e| panic!("read {}: {e}", path.display()));
        let doc: YamlValue =
            serde_yaml::from_str(&text).unwrap_or_else(|e| panic!("parse {}: {e}", path.display()));

        let suite_name = get_str(&doc, "suite").unwrap_or_else(|| {
            path.file_stem()
                .and_then(|s| s.to_str())
                .unwrap_or("")
                .to_string()
        });
        let suite_fixture = get_str(&doc, "fixture");
        let suite_fixtures = get_str_list(&doc, "fixtures");

        let cases = match map_get(&doc, "cases").and_then(|v| v.as_sequence()) {
            Some(seq) => seq.clone(),
            None => continue,
        };

        for case in cases {
            let name = get_str(&case, "name").unwrap_or_else(|| "unnamed".to_string());
            out.push(LoadedCase {
                id: format!("{suite_name}::{name}"),
                case,
                suite_fixture: suite_fixture.clone(),
                suite_fixtures: suite_fixtures.clone(),
            });
        }
    }
    out
}

fn resolve_fixtures(
    case: &YamlValue,
    suite_fixture: Option<&str>,
    suite_fixtures: Option<&[String]>,
) -> Option<Vec<PathBuf>> {
    let given = map_get(case, "given").cloned().unwrap_or(YamlValue::Null);
    let case_fixtures = get_str_list(&given, "fixtures");

    let names: Vec<String> = if let Some(list) = case_fixtures {
        list
    } else if let Some(list) = suite_fixtures {
        list.to_vec()
    } else if let Some(dir) = suite_fixture {
        let scenario = fixtures_dir().join(dir);
        if !scenario.is_dir() {
            return None;
        }
        let mut found: Vec<String> = fs::read_dir(&scenario)
            .ok()?
            .filter_map(|e| e.ok())
            .filter(|e| {
                e.file_name()
                    .to_str()
                    .map(|s| s.ends_with(".guardrails.yaml"))
                    .unwrap_or(false)
            })
            .filter_map(|e| e.file_name().into_string().ok())
            .collect();
        found.sort();
        found
    } else {
        return None;
    };

    if names.is_empty() {
        return None;
    }
    let mut paths = Vec::with_capacity(names.len());
    for n in &names {
        paths.push(find_fixture(n)?);
    }
    Some(paths)
}

// ── The driver ─────────────────────────────────────────────────────

fn run_case(loaded: &LoadedCase) -> Result<(), String> {
    let case = &loaded.case;
    let id = &loaded.id;
    let paths = match resolve_fixtures(
        case,
        loaded.suite_fixture.as_deref(),
        loaded.suite_fixtures.as_deref(),
    ) {
        Some(p) => p,
        None => return Err(format!("[{id}] no fixtures resolvable for case")),
    };

    let runtime = build_runtime(&paths).map_err(|e| format!("[{id}] {e}"))?;
    let session = open_session(&runtime);

    let given = map_get(case, "given").cloned().unwrap_or(YamlValue::Null);
    seed_session(&session, &given).map_err(|e| format!("[{id}] {e}"))?;

    // Single-step `when`/`then` shape.
    if let (Some(when), Some(then)) = (map_get(case, "when"), map_get(case, "then")) {
        let outcome = execute_action(&session, when).map_err(|e| format!("[{id}] {e}"))?;
        check_assertions(id, &outcome, then)?;
    } else if let Some(steps) = map_get(case, "steps").and_then(|v| v.as_sequence()) {
        for (i, step) in steps.iter().enumerate() {
            let step_id = format!("{id}[step {i}]");
            let when = map_get(step, "when")
                .ok_or_else(|| format!("[{step_id}] missing 'when' in step"))?;
            let outcome = execute_action(&session, when).map_err(|e| format!("[{step_id}] {e}"))?;
            if let Some(then) = map_get(step, "then") {
                check_assertions(&step_id, &outcome, then)?;
            }
        }
    } else {
        return Err(format!("[{id}] case has neither when/then nor steps"));
    }

    let _ = session.end_turn();
    let _ = session.end_request();
    Ok(())
}

#[test]
fn shared_cross_language_cases() {
    let cases = load_all_cases();
    assert!(
        !cases.is_empty(),
        "no shared cases discovered under tests/cases/"
    );

    let mut passed = 0usize;
    let mut failures: Vec<String> = Vec::new();

    for loaded in &cases {
        match run_case(loaded) {
            Ok(()) => passed += 1,
            Err(msg) => failures.push(msg),
        }
    }

    let total = cases.len();
    eprintln!(
        "shared_cross_language_cases: {passed}/{total} passed ({} failed)",
        failures.len()
    );

    if !failures.is_empty() {
        let mut report = String::new();
        report.push_str(&format!(
            "\n{} of {} shared cases failed:\n",
            failures.len(),
            total
        ));
        for f in &failures {
            report.push_str("  - ");
            report.push_str(f);
            report.push('\n');
        }
        panic!("{report}");
    }
}
