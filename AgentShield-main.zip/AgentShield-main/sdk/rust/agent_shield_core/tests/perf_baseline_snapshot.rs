//! Phase-0 baseline snapshot — the load-bearing compat anchor for the
//! v7 perf-logging plan (Step 0 of `docs/perf-logging-implementation-plan.md`).
//!
//! Captures every `ShieldLogEvent` emitted by a multi-fixture canonical
//! scenario, normalizes for non-determinism (timestamp + HashMap key
//! order), and compares against
//! `tests/fixtures/snapshots/perf_logging/phase0_baseline.json`.
//!
//! Per CD9, this snapshot is the **byte-exact compat proof** every
//! subsequent step relies on:
//!
//!   * Every Phase 1 instrumentation step adds new perf events
//!     (`stage_evaluated`, `policy_evaluated`, `llm_called`,
//!     `classifier_called`).
//!   * The escape-hatch test with `min_log_duration_ms = u64::MAX` +
//!     `category` filter must reproduce this baseline byte-for-byte
//!     (proving default behavior unchanged for adopters who opt out).
//!
//! ## Snapshot baseline policy (CD9 / P1)
//!
//! `phase0_baseline.json` is a **moving baseline**. Steps that
//! legitimately add events to the canonical scenario (e.g. Step 2's
//! resolver fix introducing `ResolverInvoked` events) update the
//! snapshot in the same PR. The commit message MUST explain *which*
//! events were added and *why*. Reviewers reject snapshot regenerations
//! without explicit `why-adding-events` justification.
//!
//! To regenerate after an intentional change:
//!
//! ```bash
//! UPDATE_SNAPSHOTS=1 cargo test -p agent_shield_core --test perf_baseline_snapshot
//! ```
//!
//! ## Coverage gaps deliberately accepted for Step 0
//!
//! Stage 4 (post_tool_validation) is not exercised by any of the four
//! `tests/fixtures/smoke/*.guardrails.yaml` fixtures used here. This is
//! deliberate: Phase 1 Step 7 (per-policy + per-detection timing) will
//! be the natural point to add a Stage-4 fixture and regenerate the
//! baseline. Tracking this gap here so future readers don't think it's
//! an oversight.

use std::collections::BTreeMap;
use std::path::PathBuf;
use std::sync::{Arc, Mutex};

use agent_shield_core::{
    GuardrailsRuntime, ObservabilityProvider, RequestContext, RuntimeBuilder, ShieldLogEvent,
};
use serde_json::{json, Value};

// ────────────────────────────────────────────────────────────────────
// Path helpers
// ────────────────────────────────────────────────────────────────────

fn fixture(rel: &str) -> PathBuf {
    let manifest = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    manifest.join("../../..").join("tests/fixtures").join(rel)
}

fn snapshot_path() -> PathBuf {
    let manifest = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    manifest
        .join("../../..")
        .join("tests/fixtures/snapshots/perf_logging/phase0_baseline.json")
}

// ────────────────────────────────────────────────────────────────────
// Capture provider — inline per the V1 pattern (CapturingProvider in
// `src/observability/test_support.rs` is `pub(crate)`, so integration
// tests must inline their own).
// ────────────────────────────────────────────────────────────────────

#[derive(Default)]
struct CaptureProvider {
    events: Mutex<Vec<ShieldLogEvent>>,
}

impl ObservabilityProvider for CaptureProvider {
    fn emit(&self, event: ShieldLogEvent) {
        self.events.lock().unwrap().push(event);
    }
}

// ────────────────────────────────────────────────────────────────────
// Per-fixture scenarios — each function drives one fixture through a
// representative slice of the Session API.
// ────────────────────────────────────────────────────────────────────

fn run_minimal(rt: &Arc<GuardrailsRuntime>) {
    let s = rt.new_session(RequestContext::new("sess-minimal", "corr-minimal"));
    s.begin_turn().unwrap();
    let _ = s.validate_input("hello world");

    // Stage 2 block path: `authorized` defaults to `false`.
    // NOTE: `validate_tool_call` takes `&mut params` and is permitted to
    // mutate (e.g. in-flight redaction). Stage 2 doesn't mutate today,
    // but using a fresh binding for each call keeps the snapshot stable
    // if that ever changes.
    let mut params = json!({"msg": "hi"});
    let _ = s.validate_tool_call("echo", &mut params, "perf_1");

    // Stage 2 allow path: flip the variable, retry with fresh params.
    s.set_variable("authorized", json!(true)).unwrap();
    let mut params = json!({"msg": "hi"});
    let _ = s.validate_tool_call("echo", &mut params, "perf_2");

    let mut response = String::from("ok");
    let _ = s.validate_output(&mut response);
    s.end_turn().unwrap();
}

fn run_input_block(rt: &Arc<GuardrailsRuntime>) {
    let s = rt.new_session(RequestContext::new("sess-inblock", "corr-inblock"));
    s.begin_turn().unwrap();
    let _ = s.validate_input("DENY_ME please");
    let _ = s.validate_input("clean input");
    s.end_turn().unwrap();
}

fn run_redact(rt: &Arc<GuardrailsRuntime>) {
    let s = rt.new_session(RequestContext::new("sess-redact", "corr-redact"));
    s.begin_turn().unwrap();
    let _ = s.validate_input("hello");
    let mut response = String::from("here is SECRET-ABCD123 for you");
    let _ = s.validate_output(&mut response);
    s.end_turn().unwrap();
}

fn run_event_gate(rt: &Arc<GuardrailsRuntime>) {
    let s = rt.new_session(RequestContext::new("sess-evgate", "corr-evgate"));
    s.begin_turn().unwrap();

    // Pre-incident allow path. Fresh `params` per call (see `run_minimal`).
    let mut params = json!({});
    let _ = s.validate_tool_call("ping", &mut params, "perf_ev_1");

    // Host emits incident; subsequent calls are blocked by `event.fired()`.
    s.emit_incident("lockdown", None).unwrap();
    let mut params = json!({});
    let _ = s.validate_tool_call("ping", &mut params, "perf_ev_2");

    s.end_turn().unwrap();
}

// ────────────────────────────────────────────────────────────────────
// Canonical scenario + normalization
// ────────────────────────────────────────────────────────────────────

fn capture_canonical_scenario() -> Vec<ShieldLogEvent> {
    let cap = Arc::new(CaptureProvider::default());

    type Runner = fn(&Arc<GuardrailsRuntime>);
    let scenarios: &[(&str, Runner)] = &[
        ("smoke/minimal.guardrails.yaml", run_minimal),
        ("smoke/input-block.guardrails.yaml", run_input_block),
        ("smoke/redact.guardrails.yaml", run_redact),
        ("smoke/event_gate.guardrails.yaml", run_event_gate),
    ];
    for (rel, runner) in scenarios {
        let path = fixture(rel);
        let rt = RuntimeBuilder::from_yaml(&path)
            .unwrap()
            .register_provider(cap.clone())
            .build()
            .unwrap();
        runner(&rt);
        // Drop runtime to flush any session-end / dispatcher shutdown events.
        drop(rt);
    }

    // The let-binding is load-bearing on Rust 2021: writing
    // `cap.events.lock().unwrap().clone()` as the tail expression
    // extends the `MutexGuard` temporary past the end of the function,
    // which conflicts with the drop of `cap` itself. The semicolon
    // here drops the guard early, before `cap` goes out of scope.
    // Rust 2024's tail-expression temporary scoping (RFC 3535) would
    // make the inline form work; revisit when this crate moves edition.
    let events = cap.events.lock().unwrap().clone();
    events
}

/// Strip non-deterministic fields from one event:
///   * `timestamp` — varies per run (uses `Utc::now()`)
///   * `attributes` — Rust `HashMap` iteration order is randomized for
///     DoS resistance; round-trip through `BTreeMap` to force sorted
///     keys so the serialized output is byte-stable across runs.
fn normalize_event(ev: &ShieldLogEvent) -> Value {
    let mut v = serde_json::to_value(ev).expect("event serializes");
    if let Some(obj) = v.as_object_mut() {
        obj.remove("timestamp");
        if let Some(attrs) = obj.get_mut("attributes") {
            if let Some(attr_obj) = attrs.as_object() {
                // BTreeMap forces sorted-key iteration; serde_json::Map
                // implements FromIterator<(String, Value)> so collect()
                // builds the final object in one pass.
                let sorted: BTreeMap<String, Value> = attr_obj
                    .iter()
                    .map(|(k, val)| (k.clone(), val.clone()))
                    .collect();
                *attrs = Value::Object(sorted.into_iter().collect());
            }
        }
    }
    v
}

fn normalize_events(events: &[ShieldLogEvent]) -> Vec<Value> {
    // Three sources of non-determinism we normalize against:
    //
    //   1. `timestamp` differs per emit (stripped in `normalize_event`).
    //   2. `attributes` is a `HashMap` with randomized iteration order
    //      (sorted via `BTreeMap` in `normalize_event`).
    //   3. **Event ordering within a single flush burst** — when the
    //      `EventBus` clears latched events at session-end (or when
    //      multiple events fire from the same dispatcher tick), the
    //      iteration order over the bus's internal `HashMap` is also
    //      randomized. Two events emitted within the same Windows
    //      timestamp tick (~100ns resolution) cannot be ordered by
    //      timestamp alone.
    //
    // Fix: normalize first (strip timestamps + sort attribute keys),
    // then sort the normalized stream by serialized content. This makes
    // ordering depend only on the content of each event, which is
    // stable across runs, while still preserving causally-ordered
    // distinct events (different stages produce different content).
    //
    // Trade-off: causal order between same-content events is lost, but
    // those are by definition indistinguishable observations — losing
    // their relative order is benign.
    let mut normalized: Vec<Value> = events.iter().map(normalize_event).collect();
    // Cached-key sort: serialize each value once into a stable key,
    // then sort by &str. Avoids the 2× per-comparison serialization
    // that a naive `sort_by(|a, b| serialize(a).cmp(&serialize(b)))`
    // would do.
    normalized
        .sort_by_cached_key(|v| serde_json::to_string(v).expect("normalized event serializes"));
    normalized
}

/// Pretty-print a JSON array of normalized events with one event per
/// element, two-space indent. Stable across runs because:
///   * top-level array order matches event production order
///   * `serde_json` preserves `Map` insertion order on serialize, and
///     our normalized events use `BTreeMap`-sourced sorted maps.
fn serialize_pretty(events: &[Value]) -> String {
    serde_json::to_string_pretty(events).expect("snapshot serializes") + "\n"
}

// ────────────────────────────────────────────────────────────────────
// The snapshot test (CD9 anchor)
// ────────────────────────────────────────────────────────────────────

#[test]
fn phase0_baseline_matches_snapshot() {
    let events = capture_canonical_scenario();
    assert!(!events.is_empty(), "canonical scenario produced no events");

    let normalized = normalize_events(&events);
    let actual = serialize_pretty(&normalized);

    let snap = snapshot_path();

    // UPDATE mode: regenerate the snapshot file.
    // `is_ok_and(|v| !v.is_empty())` so a stray `export UPDATE_SNAPSHOTS=`
    // doesn't accidentally trigger regeneration.
    if std::env::var("UPDATE_SNAPSHOTS").is_ok_and(|v| !v.is_empty()) {
        if let Some(parent) = snap.parent() {
            std::fs::create_dir_all(parent).expect("create snapshot dir");
        }
        std::fs::write(&snap, &actual).expect("write snapshot");
        eprintln!(
            "Snapshot regenerated: {} ({} events)",
            snap.display(),
            events.len()
        );
        return;
    }

    // ASSERT mode: load + compare.
    let expected = std::fs::read_to_string(&snap).unwrap_or_else(|e| {
        panic!(
            "Snapshot file missing at {}: {}\n\
             To create the initial baseline, run:\n  \
             UPDATE_SNAPSHOTS=1 cargo test -p agent_shield_core --test perf_baseline_snapshot",
            snap.display(),
            e
        )
    });

    if actual != expected {
        // Write the divergent output to a side file so a reviewer can
        // diff it against the snapshot without re-running.
        let actual_side = std::env::temp_dir().join("phase0_baseline_actual.json");
        let _ = std::fs::write(&actual_side, &actual);

        // Also surface a unified-style line diff *inline* in the panic
        // message. CI runners don't capture `/tmp/phase0_baseline_actual.json`
        // as an artifact, so a maintainer triaging a remote failure
        // would otherwise have to reproduce it locally to see what
        // diverged. Capping at 40 differing lines keeps the panic
        // message bounded for large divergences.
        let expected_lines: Vec<&str> = expected.lines().collect();
        let actual_lines: Vec<&str> = actual.lines().collect();
        let mut diff_lines: Vec<String> = Vec::new();
        let mut shown = 0usize;
        const MAX_DIFF_LINES: usize = 40;
        let max_len = expected_lines.len().max(actual_lines.len());
        for i in 0..max_len {
            let e = expected_lines.get(i).copied().unwrap_or("");
            let a = actual_lines.get(i).copied().unwrap_or("");
            if e != a {
                if shown >= MAX_DIFF_LINES {
                    diff_lines.push(format!(
                        "      ... ({} more differing lines suppressed)",
                        max_len - i
                    ));
                    break;
                }
                diff_lines.push(format!("  L{:>4} -{}", i + 1, e));
                diff_lines.push(format!("  L{:>4} +{}", i + 1, a));
                shown += 1;
            }
        }
        if diff_lines.is_empty() {
            diff_lines.push("  (lengths or trailing whitespace differ; no per-line diff)".into());
        }

        panic!(
            "\n\
             ════════════════════════════════════════════════════════════════════\n\
              Phase-0 baseline snapshot diverged.\n\
             ════════════════════════════════════════════════════════════════════\n\
             Expected:  {}\n\
             Actual:    {} (written for diffing)\n\
             \n\
             Inline diff (first {MAX_DIFF_LINES} differing line pairs; expected lines prefixed `-`, actual `+`):\n\
             {}\n\
             \n\
             If this divergence is INTENTIONAL (a step legitimately added new\n\
             events to the canonical scenario), regenerate the snapshot:\n\
             \n  \
             UPDATE_SNAPSHOTS=1 cargo test -p agent_shield_core --test perf_baseline_snapshot\n\
             \n\
             ⚠ Per CD9 of the v7 perf-logging plan: snapshot regenerations\n\
              require an explicit 'why-adding-events' justification in the\n\
              commit message. Reviewers reject regenerations without it —\n\
              the snapshot is the load-bearing compat proof, not a\n\
              convenience artifact.\n\
             ════════════════════════════════════════════════════════════════════\n",
            snap.display(),
            actual_side.display(),
            diff_lines.join("\n"),
        );
    }
}
