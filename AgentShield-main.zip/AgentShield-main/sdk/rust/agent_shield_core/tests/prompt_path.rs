//! §12.9.2 `prompt_path:` integration tests.
//!
//! Exercises the loader's pre-`parse_yaml_strict` inlining pass for
//! every error variant in `PromptFileErrorKind` plus the digest /
//! parity guarantees.
//!
//! Test names embed the `PromptFileErrorKind` variant they exercise
//! (e.g. `..._is_NoAnchorDir`) for grep-ability; suppress the lint
//! because the upper-case identifiers are intentional.
#![allow(non_snake_case)]

use std::fs;
use std::path::PathBuf;

use agent_shield_core::{
    load_from_path, load_from_str, ConfigError, DetectionKind, PromptFileErrorKind,
};

fn manifest_dir() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
}

/// Write a single guardrails YAML + matching prompt files into a fresh
/// scratch directory and return the path to the leaf YAML.
fn scratch_dir(name: &str) -> PathBuf {
    let d = manifest_dir()
        .join("target")
        .join("test-scratch")
        .join("prompt-path")
        .join(name);
    let _ = fs::remove_dir_all(&d);
    fs::create_dir_all(&d).unwrap();
    d
}

fn minimal_yaml_with_llm(prompt_form: &str) -> String {
    format!(
        r#"metadata:
  name: prompt-path-smoke
  version: "1.0.0"
  agent_shield_version: "2.0"

input_validation:
  guard_policies:
    - name: jb
      evaluate_when:
        - llm:
{prompt_form}
          reason: "block jb"
"#,
        prompt_form = prompt_form,
    )
}

fn read_loaded_llm_prompt(merged: &agent_shield_core::MergedConfig) -> String {
    let DetectionKind::Llm(llm) =
        &merged.input_validation.guard_policies[0].evaluate_when[0].detection
    else {
        panic!("expected llm detection");
    };
    assert!(
        llm.prompt_path.is_none(),
        "post-load `prompt_path` must always be None"
    );
    llm.prompt.clone()
}

#[test]
fn prompt_path_loads_file_relative_to_declaring_yaml_dir() {
    let dir = scratch_dir("relative");
    fs::write(dir.join("jb.md"), "INLINE PROMPT BODY\n").unwrap();
    let yaml_path = dir.join("policy.guardrails.yaml");
    fs::write(
        &yaml_path,
        minimal_yaml_with_llm("            prompt_path: jb.md"),
    )
    .unwrap();

    let merged = load_from_path(&yaml_path).unwrap_or_else(|e| panic!("loader error: {e}"));
    assert_eq!(read_loaded_llm_prompt(&merged), "INLINE PROMPT BODY\n");
}

#[test]
fn prompt_path_resolved_against_parent_dir_in_extends_chain() {
    // Parent declares `prompt_path: ./jb.md`. Child extends parent. The
    // path MUST resolve against the *parent's* directory, not the
    // child's — `extends:` semantics for path-bearing fields are
    // per-declaring-file (§1.3).
    let root = scratch_dir("extends-anchor");
    let parent_dir = root.join("parent");
    let child_dir = root.join("child");
    fs::create_dir_all(&parent_dir).unwrap();
    fs::create_dir_all(&child_dir).unwrap();

    fs::write(parent_dir.join("jb.md"), "PARENT PROMPT\n").unwrap();
    let parent_path = parent_dir.join("base.guardrails.yaml");
    fs::write(
        &parent_path,
        minimal_yaml_with_llm("            prompt_path: jb.md"),
    )
    .unwrap();

    let child_path = child_dir.join("leaf.guardrails.yaml");
    fs::write(
        &child_path,
        format!(
            r#"metadata:
  name: child
  version: "1.0.0"
  agent_shield_version: "2.0"
extends:
  - "{}"
"#,
            parent_path.display()
        ),
    )
    .unwrap();

    let merged = load_from_path(&child_path).unwrap_or_else(|e| panic!("loader error: {e}"));
    assert_eq!(read_loaded_llm_prompt(&merged), "PARENT PROMPT\n");
}

#[test]
fn prompt_and_prompt_path_both_set_is_BothSet() {
    let dir = scratch_dir("both-set");
    fs::write(dir.join("jb.md"), "X\n").unwrap();
    let yaml_path = dir.join("policy.guardrails.yaml");
    fs::write(
        &yaml_path,
        minimal_yaml_with_llm("            prompt: inline body\n            prompt_path: jb.md"),
    )
    .unwrap();

    let err = load_from_path(&yaml_path).unwrap_err();
    assert!(
        matches!(
            err,
            ConfigError::PromptFile {
                kind: PromptFileErrorKind::BothSet,
                ..
            }
        ),
        "got: {err}"
    );
}

#[test]
fn prompt_path_null_value_is_NeitherSet() {
    // Regression guard: a YAML that writes `prompt_path: ~` (or any
    // non-string value) must NOT slip through to produce an empty
    // inline prompt. Serde's `Option<String>` would deserialize null
    // as `None`; `inline_prompt_paths` rejects it explicitly.
    let dir = scratch_dir("null-prompt-path");
    let yaml_path = dir.join("policy.guardrails.yaml");
    fs::write(
        &yaml_path,
        minimal_yaml_with_llm("            prompt_path: ~"),
    )
    .unwrap();

    let err = load_from_path(&yaml_path).unwrap_err();
    assert!(
        matches!(
            err,
            ConfigError::PromptFile {
                kind: PromptFileErrorKind::NeitherSet,
                ..
            }
        ),
        "got: {err}"
    );
}

#[test]
fn prompt_path_empty_string_value_is_NeitherSet() {
    // `prompt_path: ""` is structurally unusable — treat as
    // NeitherSet rather than attempting to resolve an empty path.
    let dir = scratch_dir("empty-prompt-path-string");
    let yaml_path = dir.join("policy.guardrails.yaml");
    fs::write(
        &yaml_path,
        minimal_yaml_with_llm("            prompt_path: \"\""),
    )
    .unwrap();

    let err = load_from_path(&yaml_path).unwrap_err();
    assert!(
        matches!(
            err,
            ConfigError::PromptFile {
                kind: PromptFileErrorKind::NeitherSet,
                ..
            }
        ),
        "got: {err}"
    );
}

#[test]
fn empty_prompt_string_input_is_NeitherSet() {
    // Defense-in-depth: an inline `prompt: ""` would otherwise
    // produce an empty effective prompt and fail at runtime. Reject
    // at load time.
    let yaml = minimal_yaml_with_llm("            prompt: \"\"");
    let err = load_from_str(&yaml).unwrap_err();
    assert!(
        matches!(
            err,
            ConfigError::PromptFile {
                kind: PromptFileErrorKind::NeitherSet,
                ..
            }
        ),
        "got: {err}"
    );
}

#[test]
fn empty_prompt_path_backed_load_is_NeitherSet() {
    // Same invariant as `empty_prompt_string_input_is_NeitherSet`
    // but exercised through the path-backed load pipeline (where
    // `inline_prompt_paths` runs). The pre-walk no-ops on an inline
    // `prompt: ""`; `parse_one` catches it.
    let dir = scratch_dir("empty-prompt-path-backed");
    let yaml_path = dir.join("policy.guardrails.yaml");
    fs::write(
        &yaml_path,
        minimal_yaml_with_llm("            prompt: \"\""),
    )
    .unwrap();

    let err = load_from_path(&yaml_path).unwrap_err();
    assert!(
        matches!(
            err,
            ConfigError::PromptFile {
                kind: PromptFileErrorKind::NeitherSet,
                ..
            }
        ),
        "got: {err}"
    );
}

#[test]
fn empty_prompt_with_prompt_path_is_still_BothSet() {
    // Regression guard: the mutual-exclusion check is on key presence,
    // not value truthiness. A YAML that writes `prompt: ""` alongside
    // `prompt_path:` must NOT silently inline the path-form — it's
    // still `BothSet`.
    let dir = scratch_dir("empty-prompt-both");
    fs::write(dir.join("jb.md"), "should not be inlined\n").unwrap();
    let yaml_path = dir.join("policy.guardrails.yaml");
    fs::write(
        &yaml_path,
        minimal_yaml_with_llm("            prompt: \"\"\n            prompt_path: jb.md"),
    )
    .unwrap();

    let err = load_from_path(&yaml_path).unwrap_err();
    assert!(
        matches!(
            err,
            ConfigError::PromptFile {
                kind: PromptFileErrorKind::BothSet,
                ..
            }
        ),
        "got: {err}"
    );
}

#[test]
fn neither_prompt_nor_prompt_path_is_NeitherSet() {
    let dir = scratch_dir("neither-set");
    let yaml_path = dir.join("policy.guardrails.yaml");
    fs::write(
        &yaml_path,
        minimal_yaml_with_llm("            configuration: anything"),
    )
    .unwrap();

    let err = load_from_path(&yaml_path).unwrap_err();
    assert!(
        matches!(
            err,
            ConfigError::PromptFile {
                kind: PromptFileErrorKind::NeitherSet,
                ..
            }
        ),
        "got: {err}"
    );
}

#[test]
fn prompt_path_missing_file_is_NotFound_with_resolved_path() {
    let dir = scratch_dir("missing");
    let yaml_path = dir.join("policy.guardrails.yaml");
    fs::write(
        &yaml_path,
        minimal_yaml_with_llm("            prompt_path: does-not-exist.md"),
    )
    .unwrap();

    let err = load_from_path(&yaml_path).unwrap_err();
    let ConfigError::PromptFile {
        kind: PromptFileErrorKind::NotFound { .. },
        path,
        ..
    } = err
    else {
        panic!("expected NotFound, got: {err}");
    };
    assert!(
        path.ends_with("does-not-exist.md"),
        "resolved path should appear in error: {path:?}"
    );
}

#[test]
fn prompt_path_non_utf8_is_NotUtf8() {
    let dir = scratch_dir("non-utf8");
    fs::write(dir.join("jb.md"), &[0xff_u8, 0xfe_u8, 0x00_u8]).unwrap();
    let yaml_path = dir.join("policy.guardrails.yaml");
    fs::write(
        &yaml_path,
        minimal_yaml_with_llm("            prompt_path: jb.md"),
    )
    .unwrap();

    let err = load_from_path(&yaml_path).unwrap_err();
    assert!(
        matches!(
            err,
            ConfigError::PromptFile {
                kind: PromptFileErrorKind::NotUtf8,
                ..
            }
        ),
        "got: {err}"
    );
}

#[test]
fn prompt_path_empty_file_is_EmptyFile() {
    let dir = scratch_dir("empty");
    fs::write(dir.join("jb.md"), "").unwrap();
    let yaml_path = dir.join("policy.guardrails.yaml");
    fs::write(
        &yaml_path,
        minimal_yaml_with_llm("            prompt_path: jb.md"),
    )
    .unwrap();

    let err = load_from_path(&yaml_path).unwrap_err();
    assert!(
        matches!(
            err,
            ConfigError::PromptFile {
                kind: PromptFileErrorKind::EmptyFile,
                ..
            }
        ),
        "got: {err}"
    );
}

#[test]
fn prompt_path_exceeds_size_cap_is_TooLarge() {
    let dir = scratch_dir("too-large");
    // Cap is 64 KiB; write 64 KiB + 1 byte.
    let blob = "A".repeat(64 * 1024 + 1);
    fs::write(dir.join("jb.md"), &blob).unwrap();
    let yaml_path = dir.join("policy.guardrails.yaml");
    fs::write(
        &yaml_path,
        minimal_yaml_with_llm("            prompt_path: jb.md"),
    )
    .unwrap();

    let err = load_from_path(&yaml_path).unwrap_err();
    assert!(
        matches!(
            err,
            ConfigError::PromptFile {
                kind: PromptFileErrorKind::TooLarge { .. },
                ..
            }
        ),
        "got: {err}"
    );
}

#[test]
fn prompt_path_is_a_directory_is_NotRegularFile() {
    let dir = scratch_dir("is-dir");
    fs::create_dir_all(dir.join("not-a-file")).unwrap();
    let yaml_path = dir.join("policy.guardrails.yaml");
    fs::write(
        &yaml_path,
        minimal_yaml_with_llm("            prompt_path: not-a-file"),
    )
    .unwrap();

    let err = load_from_path(&yaml_path).unwrap_err();
    assert!(
        matches!(
            err,
            ConfigError::PromptFile {
                kind: PromptFileErrorKind::NotRegularFile,
                ..
            }
        ),
        "got: {err}"
    );
}

#[test]
fn prompt_path_absolute_path_resolves() {
    let dir = scratch_dir("absolute");
    let abs_prompt = dir.join("jb.md");
    fs::write(&abs_prompt, "ABS\n").unwrap();
    let yaml_path = dir.join("policy.guardrails.yaml");
    fs::write(
        &yaml_path,
        minimal_yaml_with_llm(&format!(
            "            prompt_path: {}",
            abs_prompt.display()
        )),
    )
    .unwrap();

    let merged = load_from_path(&yaml_path).unwrap_or_else(|e| panic!("loader error: {e}"));
    assert_eq!(read_loaded_llm_prompt(&merged), "ABS\n");
}

#[test]
fn prompt_path_dotdot_climb_resolves() {
    // ../prompts/jb.md from a nested YAML — `..` climbs are allowed
    // because the YAML is already trusted (B.4.5).
    let root = scratch_dir("dotdot");
    let prompts = root.join("prompts");
    let policies = root.join("policies");
    fs::create_dir_all(&prompts).unwrap();
    fs::create_dir_all(&policies).unwrap();
    fs::write(prompts.join("jb.md"), "DOTDOT\n").unwrap();
    let yaml_path = policies.join("policy.guardrails.yaml");
    fs::write(
        &yaml_path,
        minimal_yaml_with_llm("            prompt_path: ../prompts/jb.md"),
    )
    .unwrap();

    let merged = load_from_path(&yaml_path).unwrap_or_else(|e| panic!("loader error: {e}"));
    assert_eq!(read_loaded_llm_prompt(&merged), "DOTDOT\n");
}

#[test]
fn prompt_path_in_load_from_str_is_NoAnchorDir() {
    let yaml = minimal_yaml_with_llm("            prompt_path: jb.md");
    let err = load_from_str(&yaml).unwrap_err();
    assert!(
        matches!(
            err,
            ConfigError::PromptFile {
                kind: PromptFileErrorKind::NoAnchorDir,
                ..
            }
        ),
        "got: {err}"
    );
}

#[test]
fn state_validation_llm_with_prompt_path_is_rejected_by_validate_for_stage() {
    // Stage 2 is expression-only — an `llm:` block there is a schema
    // error caught by `GuardPolicy::validate_for_stage`, not by the
    // prompt-path reader. The state-stage entry must surface a
    // stage-shape error, not a file-not-found error.
    let dir = scratch_dir("state-stage");
    let yaml_path = dir.join("policy.guardrails.yaml");
    let yaml = r#"metadata:
  name: state-stage-llm
  version: "1.0.0"
  agent_shield_version: "2.0"

state_validation:
  guard_policies:
    - name: bad
      applies_to:
        tools: ["*"]
      evaluate_when:
        - llm:
            prompt_path: nope.md
          reason: "should be rejected by stage shape, not file reader"
"#;
    fs::write(&yaml_path, yaml).unwrap();

    let err = load_from_path(&yaml_path).unwrap_err();
    // The pre-walk skips state_validation so the file read is never
    // attempted. The error MUST come from the stage-shape validator
    // — specifically `ConfigError::Schema` with a message that points
    // to the §15 state-stage shape rule (LLM detections forbidden).
    let ConfigError::Schema { message, .. } = err else {
        panic!(
            "state-stage `llm:` must surface ConfigError::Schema, not a prompt-file error: got {err:?}"
        );
    };
    let m = message.to_lowercase();
    assert!(
        m.contains("state") || m.contains("expression"),
        "state-stage shape error should mention the state-stage / expression-only rule; got: {message}"
    );
}

#[test]
fn loaded_llm_detection_serializes_without_prompt_path_field() {
    let dir = scratch_dir("serialize-omits");
    fs::write(dir.join("jb.md"), "x\n").unwrap();
    let yaml_path = dir.join("policy.guardrails.yaml");
    fs::write(
        &yaml_path,
        minimal_yaml_with_llm("            prompt_path: jb.md"),
    )
    .unwrap();

    let merged = load_from_path(&yaml_path).unwrap();
    let DetectionKind::Llm(llm) =
        &merged.input_validation.guard_policies[0].evaluate_when[0].detection
    else {
        unreachable!()
    };
    let json = serde_json::to_string(llm).unwrap();
    assert!(
        !json.contains("prompt_path"),
        "post-load Serialize must not emit prompt_path (skip_serializing_if), got: {json}"
    );
    assert!(
        json.contains("\"prompt\""),
        "prompt must be present: {json}"
    );
}

#[test]
fn digest_changes_when_prompt_file_content_changes() {
    use agent_shield_core::GuardrailsConfig;
    let dir = scratch_dir("digest-content");
    fs::write(dir.join("jb.md"), "A\n").unwrap();
    let yaml_path = dir.join("policy.guardrails.yaml");
    fs::write(
        &yaml_path,
        minimal_yaml_with_llm("            prompt_path: jb.md"),
    )
    .unwrap();
    let cfg = GuardrailsConfig::load(yaml_path.as_path());
    let digest_a = cfg.digest().unwrap();

    fs::write(dir.join("jb.md"), "B\n").unwrap();
    let cfg = GuardrailsConfig::load(yaml_path.as_path());
    let digest_b = cfg.digest().unwrap();

    assert_ne!(
        digest_a, digest_b,
        "digest must change when prompt-file content changes"
    );
}

#[test]
fn digest_matches_between_inlined_and_path_form_with_same_content() {
    use agent_shield_core::GuardrailsConfig;
    let dir = scratch_dir("digest-parity");

    // Form 1: prompt_path → content "HELLO\n"
    fs::write(dir.join("jb.md"), "HELLO\n").unwrap();
    let path_form = dir.join("path-form.guardrails.yaml");
    fs::write(
        &path_form,
        minimal_yaml_with_llm("            prompt_path: jb.md"),
    )
    .unwrap();
    let digest_path = GuardrailsConfig::load(path_form.as_path())
        .digest()
        .unwrap();

    // Form 2: same content inlined directly.
    let inline_form = dir.join("inline-form.guardrails.yaml");
    fs::write(
        &inline_form,
        minimal_yaml_with_llm("            prompt: \"HELLO\\n\""),
    )
    .unwrap();
    let digest_inline = GuardrailsConfig::load(inline_form.as_path())
        .digest()
        .unwrap();

    assert_eq!(
        digest_path, digest_inline,
        "digest must be byte-stable across prompt_path-inlined and prompt-inline forms"
    );
}

#[test]
fn digest_covers_extends_parent_prompt_files() {
    use agent_shield_core::GuardrailsConfig;
    let root = scratch_dir("digest-extends");
    fs::write(root.join("jb.md"), "PARENT VERSION 1\n").unwrap();
    let parent_path = root.join("base.guardrails.yaml");
    fs::write(
        &parent_path,
        minimal_yaml_with_llm("            prompt_path: jb.md"),
    )
    .unwrap();
    let child_path = root.join("leaf.guardrails.yaml");
    fs::write(
        &child_path,
        format!(
            r#"metadata:
  name: leaf
  version: "1.0.0"
  agent_shield_version: "2.0"
extends:
  - "{}"
"#,
            parent_path.display()
        ),
    )
    .unwrap();

    let digest_a = GuardrailsConfig::load(child_path.as_path())
        .digest()
        .unwrap();

    // Change the parent's prompt file. The leaf is unchanged.
    fs::write(root.join("jb.md"), "PARENT VERSION 2\n").unwrap();
    let digest_b = GuardrailsConfig::load(child_path.as_path())
        .digest()
        .unwrap();

    assert_ne!(
        digest_a, digest_b,
        "digest must change when an extends: parent's prompt file content changes"
    );
}

#[test]
fn load_from_path_and_load_from_paths_share_inlining_behavior() {
    let dir = scratch_dir("shared-core");
    fs::write(dir.join("jb.md"), "SHARED\n").unwrap();
    let yaml_path = dir.join("policy.guardrails.yaml");
    fs::write(
        &yaml_path,
        minimal_yaml_with_llm("            prompt_path: jb.md"),
    )
    .unwrap();

    let via_path = load_from_path(&yaml_path).unwrap();
    let via_paths = agent_shield_core::load_from_paths(&[yaml_path.as_path()]).unwrap();

    assert_eq!(
        read_loaded_llm_prompt(&via_path),
        read_loaded_llm_prompt(&via_paths),
        "load_from_path and load_from_paths must produce the same inlined prompt"
    );
}

#[test]
fn from_config_or_build_rejects_unloaded_prompt_path() {
    // Hand-construct a MergedConfig with an unresolved prompt_path and
    // route it through RuntimeBuilder::from_config(...).build() — the
    // defense-in-depth check in build() should reject it.
    use agent_shield_core::{
        AgentShieldVersion, GuardPolicy, LlmDetection, Metadata, RuntimeBuilder,
    };

    // We don't have an easy public way to build a MergedConfig from
    // scratch (Default is fine), but we DO have it via load_from_str of
    // an inline YAML; then we splice the prompt_path back in.
    let mut merged = load_from_str(
        r#"metadata:
  name: x
  version: "1.0.0"
  agent_shield_version: "2.0"
input_validation:
  guard_policies:
    - name: jb
      evaluate_when:
        - llm:
            prompt: "inline"
          reason: "block"
"#,
    )
    .unwrap();

    // Verify baseline: builder succeeds with inline prompt.
    let _ = RuntimeBuilder::from_config(merged.clone()).build().unwrap();

    // Now splice in an unresolved prompt_path. The builder should
    // refuse it with UnresolvedPromptPath.
    let DetectionKind::Llm(ref mut llm) =
        merged.input_validation.guard_policies[0].evaluate_when[0].detection
    else {
        unreachable!()
    };
    llm.prompt_path = Some("dangling.md".into());

    let err = RuntimeBuilder::from_config(merged).build().unwrap_err();
    let s = err.to_string();
    assert!(
        s.contains("UnresolvedPromptPath") || s.contains("unresolved `prompt_path`"),
        "expected UnresolvedPromptPath in: {s}"
    );

    // Silence dead-code warnings for imports that we wanted to test
    // exist on the public surface.
    let _ = std::any::TypeId::of::<AgentShieldVersion>();
    let _ = std::any::TypeId::of::<GuardPolicy>();
    let _ = std::any::TypeId::of::<LlmDetection>();
    let _ = std::any::TypeId::of::<Metadata>();
}
