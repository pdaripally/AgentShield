//! End-to-end integration tests for the runtime-wide shadow / active
//! mode introduced by microsoft/AgentShield#14.
//!
//! These tests exercise the five validation stages plus the resolver
//! runtime via the host-facing `GuardrailsRuntime` surface and prove
//! the spec contract for shadow mode:
//!
//! - Blocks become log-only "would have blocked" — the verdict still
//!   carries the action, but every audit event tagged with
//!   `mode: shadow, enforced: false` records what active mode would
//!   have done. The SDK orchestrator (mapped to
//!   [`ShieldMode::Monitor`] via
//!   [`RuntimeMode::effective_shield_mode`]) proceeds as if allowed.
//! - Stage-3 / Stage-4 in-place mutations are NOT applied.
//! - Stage-1 / Stage-5 redactions / appends / prepends do NOT show up
//!   on the verdict (so the SDK's `ProceedWithMutation` path is not
//!   triggered).
//! - Side-effecting resolvers (human / tool / agent / delegate) are
//!   NOT invoked — the host hook is never called.
//! - The target variable of a suppressed resolver stays `Unset`; no
//!   `approval.<var>.<outcome>` event fires.
//! - Every observability event minted by the runtime in shadow carries
//!   `mode: shadow`; action-bearing events carry `enforced: false`.
//! - Explicit variable extraction still happens identically across
//!   modes.

use std::sync::{Arc, Mutex};

use agent_shield_core::{
    load_from_str, AgentResolveRequest, AgentResolver, BusEvent, GuardrailsRuntime,
    GuardrailsSession, LogAction, ObservabilityProvider, RequestContext, ResolverDecision,
    ResolverResponse, RuntimeBuilder, RuntimeMode, ShieldLogEvent, VarStatus,
};
use serde_json::{json, Value};

// ─────────────────────────────────────────────────────────────────────
// Fixtures
// ─────────────────────────────────────────────────────────────────────

fn build_runtime(yaml: &str, mode: RuntimeMode) -> Arc<GuardrailsRuntime> {
    let cfg = load_from_str(yaml).expect("valid yaml");
    RuntimeBuilder::from_config(cfg)
        .with_mode(mode)
        .build()
        .expect("build")
}

fn open_session(rt: &Arc<GuardrailsRuntime>, session: &str) -> GuardrailsSession {
    rt.new_session(RequestContext::new(session, "corr-1"))
}

#[derive(Default, Clone)]
struct CapturedEvents(Arc<Mutex<Vec<ShieldLogEvent>>>);

impl CapturedEvents {
    fn snapshot(&self) -> Vec<ShieldLogEvent> {
        self.0.lock().unwrap().clone()
    }
}

impl ObservabilityProvider for CapturedEvents {
    fn emit(&self, ev: ShieldLogEvent) {
        self.0.lock().unwrap().push(ev);
    }
    fn shutdown(&self) {}
}

fn build_runtime_with_capture(
    yaml: &str,
    mode: RuntimeMode,
) -> (Arc<GuardrailsRuntime>, CapturedEvents) {
    let cfg = load_from_str(yaml).expect("valid yaml");
    let cap = CapturedEvents::default();
    let rt = RuntimeBuilder::from_config(cfg)
        .with_mode(mode)
        .register_provider(Arc::new(cap.clone()))
        .build()
        .expect("build");
    (rt, cap)
}

// ─────────────────────────────────────────────────────────────────────
// Tests
// ─────────────────────────────────────────────────────────────────────

const SHADOW_INPUT_BLOCK: &str = r#"

metadata:
  name: shadow-input-block
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
resources:
  tools:
    - name: echo
      permission: read_only
input_validation:
  guard_policies:
    - name: block_secret
      evaluate_when:
        - pattern: "(?i)secret"
          reason: "input contained secret"
          action: block
"#;

const ACTIVE_INPUT_BLOCK: &str = r#"

metadata:
  name: active-input-block
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
resources:
  tools:
    - name: echo
      permission: read_only
input_validation:
  guard_policies:
    - name: block_secret
      evaluate_when:
        - pattern: "(?i)secret"
          reason: "input contained secret"
          action: block
"#;

#[test]
fn runtime_mode_reflects_builder_value() {
    let rt_active = build_runtime(ACTIVE_INPUT_BLOCK, RuntimeMode::Active);
    let rt_shadow = build_runtime(SHADOW_INPUT_BLOCK, RuntimeMode::Shadow);
    assert_eq!(rt_active.mode(), RuntimeMode::Active);
    assert_eq!(rt_shadow.mode(), RuntimeMode::Shadow);
}

#[test]
fn input_block_in_active_denies_verdict() {
    let rt = build_runtime(ACTIVE_INPUT_BLOCK, RuntimeMode::Active);
    let s = open_session(&rt, "sess-active");
    let verdict = s.validate_input("this is a secret thing");
    assert!(!verdict.allowed, "active mode must produce a deny verdict");
    assert!(verdict.reason.is_some());
}

#[test]
fn shadow_mode_emits_block_logs_with_enforced_false() {
    let (rt, cap) = build_runtime_with_capture(SHADOW_INPUT_BLOCK, RuntimeMode::Shadow);
    let s = open_session(&rt, "sess-shadow");
    let _ = s.validate_input("this is a secret thing");

    let events = cap.snapshot();
    let block_event = events
        .iter()
        .find(|e| {
            e.action == Some(LogAction::Block) && e.guard_policy.as_deref() == Some("block_secret")
        })
        .expect("expected a block-action event for `block_secret`");
    assert_eq!(block_event.mode, Some(RuntimeMode::Shadow));
    assert_eq!(
        block_event.enforced,
        Some(false),
        "shadow-mode block events must carry enforced=false"
    );

    let (rt_a, cap_a) = build_runtime_with_capture(ACTIVE_INPUT_BLOCK, RuntimeMode::Active);
    let s_a = open_session(&rt_a, "sess-active");
    let _ = s_a.validate_input("this is a secret thing");
    let block_a = cap_a
        .snapshot()
        .into_iter()
        .find(|e| {
            e.action == Some(LogAction::Block) && e.guard_policy.as_deref() == Some("block_secret")
        })
        .expect("active mode also emits a block event");
    assert_eq!(block_a.mode, Some(RuntimeMode::Active));
    assert_eq!(block_a.enforced, Some(true));
}

// ── Stage 3 transform suppression ────────────────────────────────────

const SHADOW_TOOL_REDACT: &str = r#"

metadata:
  name: shadow-tool-redact
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
resources:
  tools:
    - name: echo
      permission: read_only
tool_execution_validation:
  guard_policies:
    - name: redact_ssn
      applies_to: { tools: ["echo"] }
      evaluate_when:
        - pattern: '\d{3}-\d{2}-\d{4}'
          reason: ssn
          action: redact
      replacement: "[X]"
"#;

const ACTIVE_TOOL_REDACT: &str = r#"

metadata:
  name: active-tool-redact
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
resources:
  tools:
    - name: echo
      permission: read_only
tool_execution_validation:
  guard_policies:
    - name: redact_ssn
      applies_to: { tools: ["echo"] }
      evaluate_when:
        - pattern: '\d{3}-\d{2}-\d{4}'
          reason: ssn
          action: redact
      replacement: "[X]"
"#;

#[test]
fn active_tool_execution_redact_mutates_params() {
    let rt = build_runtime(ACTIVE_TOOL_REDACT, RuntimeMode::Active);
    let s = open_session(&rt, "sess-active");
    let mut params = json!({ "msg": "id is 123-45-6789, thanks" });
    let v = s.validate_tool_call("echo", &mut params, "call-echo");
    assert!(v.allowed);
    let serialized = serde_json::to_string(&params).unwrap();
    assert!(
        serialized.contains("[X]"),
        "active mode must rewrite the SSN: {serialized}"
    );
    assert!(
        !serialized.contains("123-45-6789"),
        "active mode must strip the original SSN: {serialized}"
    );
}

#[test]
fn shadow_tool_execution_redact_still_emits_active_equivalent_verdict() {
    // Core no longer gates mutation in shadow (#14 / host-enforcement
    // story). The SDK wrappers in Python/Node/.NET fold to
    // `ShieldMode::Monitor` and discard mutated values via their
    // MONITOR auto-fold; direct `agent_shield_core` callers are
    // responsible for not applying the mutation themselves. What the
    // core promises is that the *verdict shape* in shadow matches what
    // active would have produced — so the audit log records identical
    // decisions.
    let rt_shadow = build_runtime(SHADOW_TOOL_REDACT, RuntimeMode::Shadow);
    let rt_active = build_runtime(ACTIVE_TOOL_REDACT, RuntimeMode::Active);

    let ss = open_session(&rt_shadow, "sess-shadow");
    let mut ps = json!({ "msg": "id is 123-45-6789, thanks" });
    let vs = ss.validate_tool_call("echo", &mut ps, "call-shadow");

    let sa = open_session(&rt_active, "sess-active");
    let mut pa = json!({ "msg": "id is 123-45-6789, thanks" });
    let va = sa.validate_tool_call("echo", &mut pa, "call-active");

    assert_eq!(vs.allowed, va.allowed, "verdict allowance must match");
    assert_eq!(vs.action, va.action, "verdict.action must match");
    assert_eq!(
        vs.policy.as_deref(),
        va.policy.as_deref(),
        "verdict.policy must match"
    );
}

// ── Stage 4 post-tool transform suppression ──────────────────────────

const SHADOW_POST_TOOL_REDACT: &str = r#"

metadata:
  name: shadow-post-redact
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
resources:
  tools:
    - name: echo
      permission: read_only
post_tool_validation:
  guard_policies:
    - name: redact_ssn
      applies_to: { tools: ["echo"] }
      evaluate_when:
        - pattern: '\d{3}-\d{2}-\d{4}'
          reason: ssn
          action: redact
      replacement: "[X]"
"#;

const ACTIVE_POST_TOOL_REDACT: &str = r#"

metadata:
  name: active-post-redact
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
resources:
  tools:
    - name: echo
      permission: read_only
post_tool_validation:
  guard_policies:
    - name: redact_ssn
      applies_to: { tools: ["echo"] }
      evaluate_when:
        - pattern: '\d{3}-\d{2}-\d{4}'
          reason: ssn
          action: redact
      replacement: "[X]"
"#;

#[test]
fn active_post_tool_redact_mutates_result_and_sets_verdict_redaction() {
    let rt = build_runtime(ACTIVE_POST_TOOL_REDACT, RuntimeMode::Active);
    let s = open_session(&rt, "sess-active");
    let mut params = json!({"msg": "hi"});
    let _ = s.validate_tool_call("echo", &mut params, "call-echo");
    let mut result = Value::String("hello 123-45-6789 world".into());
    let v = s.validate_tool_output("echo", &mut result, "call-echo");
    assert!(v.allowed);
    assert_eq!(
        result.as_str().unwrap(),
        "hello [X] world",
        "active mode must rewrite result"
    );
    assert_eq!(v.redaction.as_deref(), Some("hello [X] world"));
}

#[test]
fn shadow_post_tool_redact_still_emits_active_equivalent_verdict() {
    // Same contract change as Stage 3: core no longer gates mutation.
    // We assert verdict-shape parity instead of no-mutation. SDK-level
    // tests cover the orchestrator-side no-mutation guarantee.
    let rt_shadow = build_runtime(SHADOW_POST_TOOL_REDACT, RuntimeMode::Shadow);
    let rt_active = build_runtime(ACTIVE_POST_TOOL_REDACT, RuntimeMode::Active);

    let ss = open_session(&rt_shadow, "sess-shadow");
    let mut params_s = json!({"msg": "hi"});
    let _ = ss.validate_tool_call("echo", &mut params_s, "call-shadow");
    let mut result_s = Value::String("hello 123-45-6789 world".into());
    let vs = ss.validate_tool_output("echo", &mut result_s, "call-shadow");

    let sa = open_session(&rt_active, "sess-active");
    let mut params_a = json!({"msg": "hi"});
    let _ = sa.validate_tool_call("echo", &mut params_a, "call-active");
    let mut result_a = Value::String("hello 123-45-6789 world".into());
    let va = sa.validate_tool_output("echo", &mut result_a, "call-active");

    assert_eq!(vs.allowed, va.allowed);
    assert_eq!(vs.action, va.action);
}

// ── Stage 5 output transform suppression ─────────────────────────────

const SHADOW_OUTPUT_REDACT: &str = r#"

metadata:
  name: shadow-output-redact
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
resources:
  tools: []
output_validation:
  guard_policies:
    - name: redact_ssn
      evaluate_when:
        - pattern: '\d{3}-\d{2}-\d{4}'
          reason: ssn
          action: redact
      replacement: "[X]"
"#;

const ACTIVE_OUTPUT_REDACT: &str = r#"

metadata:
  name: active-output-redact
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
resources:
  tools: []
output_validation:
  guard_policies:
    - name: redact_ssn
      evaluate_when:
        - pattern: '\d{3}-\d{2}-\d{4}'
          reason: ssn
          action: redact
      replacement: "[X]"
"#;

#[test]
fn active_output_redact_mutates_response() {
    let rt = build_runtime(ACTIVE_OUTPUT_REDACT, RuntimeMode::Active);
    let s = open_session(&rt, "sess-active");
    let mut resp = "leak: 123-45-6789".to_string();
    let v = s.validate_output(&mut resp);
    assert!(v.allowed);
    assert_eq!(resp, "leak: [X]");
}

#[test]
fn shadow_output_redact_still_emits_active_equivalent_verdict() {
    // Same contract change as Stages 3/4: core mutates in shadow too;
    // host (SDK MONITOR auto-fold) is responsible for discarding it.
    let rt_shadow = build_runtime(SHADOW_OUTPUT_REDACT, RuntimeMode::Shadow);
    let rt_active = build_runtime(ACTIVE_OUTPUT_REDACT, RuntimeMode::Active);

    let ss = open_session(&rt_shadow, "sess-shadow");
    let mut resp_s = "leak: 123-45-6789".to_string();
    let vs = ss.validate_output(&mut resp_s);

    let sa = open_session(&rt_active, "sess-active");
    let mut resp_a = "leak: 123-45-6789".to_string();
    let va = sa.validate_output(&mut resp_a);

    assert_eq!(vs.allowed, va.allowed);
    assert_eq!(vs.action, va.action);
}

// ── Resolver side-effect suppression ─────────────────────────────────

const SHADOW_HUMAN_RESOLVER: &str = r#"

metadata:
  name: shadow-human-resolver
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
resources:
  tools:
    - name: send_money
      permission: read_write
variables:
  - name: amount_approved
    type: boolean
    lifetime: per_call
    on_demand_by:
      kind: human
      provider: auto_reject
      prompt: "approve transfer?"
tool_execution_validation:
  guard_policies:
    - name: require_approval
      applies_to: { tools: ["send_money"] }
      evaluate_when:
        - expression: "amount_approved == true"
          reason: "approval not yet granted"
          action: block
"#;

const ACTIVE_HUMAN_RESOLVER: &str = r#"

metadata:
  name: active-human-resolver
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
resources:
  tools:
    - name: send_money
      permission: read_write
variables:
  - name: amount_approved
    type: boolean
    lifetime: per_call
    on_demand_by:
      kind: human
      provider: auto_reject
      prompt: "approve transfer?"
tool_execution_validation:
  guard_policies:
    - name: require_approval
      applies_to: { tools: ["send_money"] }
      evaluate_when:
        - expression: "amount_approved == true"
          reason: "approval not yet granted"
          action: block
"#;

fn collect_approval_event_ids(rt: &Arc<GuardrailsRuntime>) -> Arc<Mutex<Vec<String>>> {
    let approvals = Arc::new(Mutex::new(Vec::<String>::new()));
    let aw = approvals.clone();
    let _handle = rt.bus().subscribe(None, move |ev: &BusEvent| {
        if let BusEvent::Emitted { event_id, .. } = ev {
            let s = format!("{event_id}");
            if s.starts_with("approval.") {
                aw.lock().unwrap().push(s);
            }
        }
    });
    approvals
}

#[test]
fn active_human_resolver_invocation_records_approval_deny_event() {
    let rt = build_runtime(ACTIVE_HUMAN_RESOLVER, RuntimeMode::Active);
    let approvals = collect_approval_event_ids(&rt);

    let s = open_session(&rt, "sess-active");
    let mut params = json!({});
    let _ = s.validate_tool_call("send_money", &mut params, "call-send-money");

    let seen = approvals.lock().unwrap().clone();
    assert!(
        seen.iter().any(|e| e.contains("amount_approved")),
        "active mode must emit an approval.<var>.deny event; saw {seen:?}"
    );
}

#[test]
fn shadow_human_resolver_is_not_invoked_and_emits_no_approval_event() {
    let (rt, cap) = build_runtime_with_capture(SHADOW_HUMAN_RESOLVER, RuntimeMode::Shadow);
    let approvals = collect_approval_event_ids(&rt);

    let s = open_session(&rt, "sess-shadow");
    let mut params = json!({});
    let _ = s.validate_tool_call("send_money", &mut params, "call-send-money");

    let seen = approvals.lock().unwrap().clone();
    assert!(
        seen.is_empty(),
        "shadow mode must NOT emit approval.<var>.<outcome> events; saw {seen:?}"
    );

    let events = cap.snapshot();
    let audit = events
        .iter()
        .find(|e| e.action == Some(LogAction::RequireApproval))
        .expect("expected one require_approval audit event in shadow");
    assert_eq!(audit.mode, Some(RuntimeMode::Shadow));
    assert_eq!(audit.enforced, Some(false));
    assert_eq!(audit.variable.as_deref(), Some("amount_approved"));
    assert_eq!(
        audit
            .attributes
            .get("agent_shield.resolver.kind")
            .and_then(|v| v.as_str()),
        Some("human")
    );

    let state = s.read_variable("amount_approved").expect("var exists");
    assert_eq!(
        state.status,
        VarStatus::Unset,
        "shadow-suppressed resolver must leave the variable Unset, not Denied",
    );
}

// ── Variable extraction still runs in shadow ─────────────────────────

#[test]
fn variables_set_explicitly_track_identically_across_modes() {
    let active = build_runtime(ACTIVE_HUMAN_RESOLVER, RuntimeMode::Active);
    let shadow = build_runtime(SHADOW_HUMAN_RESOLVER, RuntimeMode::Shadow);

    let sa = open_session(&active, "sess-active");
    let ss = open_session(&shadow, "sess-shadow");

    sa.set_variable("amount_approved", json!(true)).unwrap();
    ss.set_variable("amount_approved", json!(true)).unwrap();

    let sa_state = sa.read_variable("amount_approved").unwrap();
    let ss_state = ss.read_variable("amount_approved").unwrap();
    assert_eq!(sa_state.status, ss_state.status);
    assert_eq!(sa_state.value, ss_state.value);
    assert_eq!(sa_state.status, VarStatus::Resolved);
}

// ── Resolver hook not invoked: probe via custom AgentResolver ────────

struct CountingAgentResolver(Arc<Mutex<u32>>);
impl AgentResolver for CountingAgentResolver {
    fn resolve(&self, _req: AgentResolveRequest) -> ResolverResponse {
        *self.0.lock().unwrap() += 1;
        ResolverResponse {
            decision: ResolverDecision::Allow,
            value: Some(json!("ok")),
            set_variables: Default::default(),
            reason: None,
        }
    }
}

const SHADOW_AGENT_RESOLVER: &str = r#"

metadata:
  name: shadow-agent-resolver
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
resources:
  tools:
    - name: ship
      permission: read_write
variables:
  - name: orchestrator_token
    type: string
    lifetime: per_call
    on_demand_by:
      kind: agent
      prompt: "please approve"
tool_execution_validation:
  guard_policies:
    - name: require_token
      applies_to: { tools: ["ship"] }
      evaluate_when:
        - expression: "orchestrator_token == 'ok'"
          reason: "no token"
          action: block
"#;

#[test]
fn shadow_does_not_invoke_agent_resolver_hook() {
    let cfg = load_from_str(SHADOW_AGENT_RESOLVER).unwrap();
    let counter = Arc::new(Mutex::new(0u32));
    let rt = RuntimeBuilder::from_config(cfg)
        .with_mode(RuntimeMode::Shadow)
        .register_agent_resolver(Arc::new(CountingAgentResolver(counter.clone())))
        .build()
        .unwrap();
    let s = open_session(&rt, "sess-shadow");
    let mut params = json!({});
    let _ = s.validate_tool_call("ship", &mut params, "call-ship");
    let calls = *counter.lock().unwrap();
    assert_eq!(
        calls, 0,
        "shadow mode must NOT invoke the agent resolver hook (saw {calls} calls)"
    );
}

// ── Multi-policy Stage-3 parity ──────────────────────────────────────

const STAGE3_MULTI_POLICY_TEMPLATE: &str = r#"

metadata:
  name: shadow-stage3-multi
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
resources:
  tools:
    - name: echo
      permission: read_write
tool_execution_validation:
  guard_policies:
    - name: redact_first
      applies_to: { tools: ["echo"] }
      evaluate_when:
        - pattern: "secret"
          reason: "first-pass redaction"
          action: redact
      replacement: "[X]"
    - name: block_on_redacted_marker
      applies_to: { tools: ["echo"] }
      evaluate_when:
        - pattern: '\[X\]'
          reason: "post-redaction marker present"
          action: block
"#;

#[test]
fn shadow_stage3_multi_policy_sees_same_decisions_as_active() {
    // Two policies in Stage 3:
    //   A: redact `secret` → `[X]`
    //   B: block on the literal `[X]` marker
    //
    // In active mode, A's mutation makes B fire (the params now
    // contain `[X]`). In shadow mode, core also mutates in-loop —
    // host (SDK MONITOR auto-fold) is responsible for discarding
    // the result. What the spec promises is that the verdict / audit
    // trail records IDENTICAL decisions across modes.
    let yaml = STAGE3_MULTI_POLICY_TEMPLATE;

    let (rt_active, cap_active) = build_runtime_with_capture(yaml, RuntimeMode::Active);
    let (rt_shadow, cap_shadow) = build_runtime_with_capture(yaml, RuntimeMode::Shadow);

    let sa = open_session(&rt_active, "sess-active");
    let mut pa = json!({"msg": "the secret word"});
    let va = sa.validate_tool_call("echo", &mut pa, "call-echo-a");

    let ss = open_session(&rt_shadow, "sess-shadow");
    let mut ps = json!({"msg": "the secret word"});
    let _vs = ss.validate_tool_call("echo", &mut ps, "call-echo-s");

    // Active blocks because policy B sees the redacted marker.
    assert!(
        !va.allowed,
        "active multi-policy chain must block on the redaction marker"
    );

    // Verdict-level decisions in shadow are identical to active —
    // the SDK orchestrator's Monitor fold proceeds the call, but
    // the audit log says exactly what active would have said.
    let block_active = cap_active
        .snapshot()
        .into_iter()
        .find(|e| {
            e.action == Some(LogAction::Block)
                && e.guard_policy.as_deref() == Some("block_on_redacted_marker")
        })
        .expect("active mode must emit a block event from policy B");
    let block_shadow = cap_shadow
        .snapshot()
        .into_iter()
        .find(|e| {
            e.action == Some(LogAction::Block)
                && e.guard_policy.as_deref() == Some("block_on_redacted_marker")
        })
        .expect(
            "shadow mode must ALSO emit a block event from policy B \
             (the inner-loop mutation must propagate so multi-policy \
              audit decisions are parity-identical across modes)",
        );

    assert_eq!(block_active.mode, Some(RuntimeMode::Active));
    assert_eq!(block_active.enforced, Some(true));
    assert_eq!(block_shadow.mode, Some(RuntimeMode::Shadow));
    assert_eq!(block_shadow.enforced, Some(false));
}

// ── Populator extraction parity (#14 state-extraction carve-out) ─────

const POPULATOR_PARITY_TEMPLATE: &str = r#"

metadata:
  name: shadow-populator-parity
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
resources:
  tools:
    - name: lookup
      permission: read_only
variables:
  - name: user_role
    type: string
    default: guest
    populated_by:
      - kind: tool
        name: lookup
        phase: after
        expression: "@result.user_role"
"#;

#[test]
fn shadow_runs_populator_extractor_identically_to_active() {
    // §3.5.3 carve-out: "attribute extraction and state activation
    // still run normally". This test asserts a `populated_by:`
    // extractor that reads `@result.user_role` writes the variable
    // identically in both modes. The populator fires on
    // `tool.lookup.success` which `record_tool_success` emits.
    let yaml = POPULATOR_PARITY_TEMPLATE;

    let rt_a = build_runtime(yaml, RuntimeMode::Active);
    let rt_s = build_runtime(yaml, RuntimeMode::Shadow);

    let sa = open_session(&rt_a, "sess-active");
    sa.record_tool_success("lookup", &json!({"user_role": "admin"}))
        .unwrap();

    let ss = open_session(&rt_s, "sess-shadow");
    ss.record_tool_success("lookup", &json!({"user_role": "admin"}))
        .unwrap();

    let state_a = sa.read_variable("user_role").expect("variable exists");
    let state_s = ss.read_variable("user_role").expect("variable exists");
    assert_eq!(
        state_a.status, state_s.status,
        "populator extractor must drive variable status identically across modes"
    );
    assert_eq!(
        state_a.value, state_s.value,
        "populator extractor must produce the same value in both modes"
    );
    assert_eq!(
        state_a.value.as_str(),
        Some("admin"),
        "populator should have extracted the user_role string"
    );
}
