//! Integration smoke tests for the loader.
//!
//! Exercises the hand-rolled fixtures in `tests/fixtures/smoke/`.

use std::path::PathBuf;

use agent_shield_core::{load_from_path, load_from_str, ConfigError, DetectionKind, ResourceKind};

fn fixture(rel: &str) -> PathBuf {
    let manifest = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    // The crate lives at sdk/rust/agent_shield_core; fixtures are at
    // ../../../tests/fixtures/...
    manifest.join("../../..").join("tests/fixtures").join(rel)
}

#[test]
fn loads_minimal_fixture() {
    let path = fixture("smoke/minimal.guardrails.yaml");
    let m = load_from_path(&path).unwrap_or_else(|e| panic!("loader error: {e}"));
    assert_eq!(m.metadata.name, "smoke-minimal");
    assert_eq!(m.objective.tiers.len(), 1);
    assert_eq!(m.objective.tiers[0].goal.len(), 1);
    assert!(!m.objective.tiers[0].forbidden.is_empty());
    assert_eq!(m.resources.tools.len(), 1);
    assert_eq!(m.state_validation.guard_policies.len(), 1);
    assert_eq!(m.variables.len(), 1);

    let gp = &m.state_validation.guard_policies[0];
    assert_eq!(gp.name, "echo_only_when_authorized");
    assert!(matches!(
        gp.evaluate_when[0].detection,
        DetectionKind::Expression(_)
    ));
}

#[test]
fn loads_variables_and_events_fixture() {
    let path = fixture("smoke/variables-and-events.guardrails.yaml");
    let m = load_from_path(&path).unwrap_or_else(|e| panic!("loader error: {e}"));
    assert_eq!(m.metadata.name, "smoke-variables-and-events");
    assert_eq!(m.configurations.len(), 1);
    assert_eq!(m.resources.tools.len(), 2);
    assert_eq!(m.variables.len(), 3);
    // send_authorized — human resolver, lifetime map.
    let send = m
        .variables
        .iter()
        .find(|v| v.name == "send_authorized")
        .expect("send_authorized variable");
    assert!(send.on_demand_by.is_some());
    assert!(send.lifetime.is_some());

    // recipient_profile — populator + reset_by.
    let profile = m
        .variables
        .iter()
        .find(|v| v.name == "recipient_profile")
        .expect("recipient_profile");
    assert_eq!(profile.populated_by.len(), 1);
    assert!(matches!(profile.populated_by[0].kind, ResourceKind::Tool));
    assert_eq!(profile.reset_by.len(), 1);

    // 1 predicate + 2 guard policies.
    assert_eq!(m.predicates.len(), 1);
    assert_eq!(m.state_validation.guard_policies.len(), 2);
    let lockdown = m
        .state_validation
        .guard_policies
        .iter()
        .find(|g| g.name == "no_send_during_lockdown")
        .unwrap();
    assert!(lockdown.active_if.is_some());
}

#[test]
fn loads_extends_chain_and_merges_correctly() {
    let path = fixture("smoke/guard-policy-merge.guardrails.yaml");
    let m = load_from_path(&path).unwrap_or_else(|e| panic!("loader error: {e}"));
    assert_eq!(m.metadata.name, "smoke-guard-policy-merge-leaf");

    // Objective tiers: parent + leaf.
    assert_eq!(m.objective.tiers.len(), 2);
    assert_eq!(
        m.objective.tiers[0].source,
        "smoke-guard-policy-merge-parent"
    );
    assert_eq!(m.objective.tiers[1].source, "smoke-guard-policy-merge-leaf");

    // Variables are concatenated across tiers.
    assert_eq!(m.variables.len(), 2);
    assert!(m.variables.iter().any(|v| v.name == "emergency_override"));
    assert!(m.variables.iter().any(|v| v.name == "two_factor_passed"));

    // State stage: same-name `high_risk_gate` policy merges.
    let gate = m
        .state_validation
        .guard_policies
        .iter()
        .find(|g| g.name == "high_risk_gate")
        .expect("high_risk_gate must merge across the chain");
    // active_if from parent is preserved.
    assert_eq!(
        gate.active_if.as_deref(),
        Some("emergency_override == false")
    );
    // evaluate_when[] concatenated: parent had 1, leaf adds 1, expect 2.
    assert_eq!(gate.evaluate_when.len(), 2);
    // allowed_when: leaf-only, becomes the merged value.
    assert!(gate.allowed_when.is_some());

    // Input stage: leaf-only block_jailbreak_attempts policy.
    let jb = m
        .input_validation
        .guard_policies
        .iter()
        .find(|g| g.name == "block_jailbreak_attempts")
        .unwrap();
    assert!(matches!(
        jb.evaluate_when[0].detection,
        DetectionKind::Patterns(_)
    ));
}

#[test]
fn loads_comprehensive_fixture() {
    let path = fixture("comprehensive/comprehensive-spec-test.guardrails.yaml");
    let m =
        load_from_path(&path).unwrap_or_else(|e| panic!("comprehensive fixture must load: {e}"));
    assert_eq!(m.metadata.name, "comprehensive-spec-test");
    // Spot-check that a representative slice of the surface is populated.
    assert!(
        m.variables
            .iter()
            .any(|v| v.name == "wire_transfer_authorized"),
        "wire_transfer_authorized variable must be present"
    );
    assert!(
        m.state_validation
            .guard_policies
            .iter()
            .any(|g| g.name == "block_delete_database"),
        "delete_database block guard policy must be present"
    );
}

// ── Fine-grained reject cases ────────────────────────────────────────

#[test]
fn rejects_scalar_goal() {
    let yaml = r#"
metadata:
  name: x
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: "single string"
"#;
    let err = load_from_str(yaml).unwrap_err().to_string();
    assert!(err.contains("scalar form") || err.contains("goal"));
}

#[test]
fn rejects_camel_case_agent_shield_version() {
    let yaml = r#"
metadata:
  name: x
  version: "0.1.0"
  agentShieldVersion: "2.0"
"#;
    let err = load_from_str(yaml).unwrap_err();
    assert!(matches!(err, ConfigError::V1Vocabulary { .. }));
    assert!(err.to_string().contains("agentShieldVersion"));
}

#[test]
fn rejects_state_validation_policies() {
    let yaml = r#"
metadata:
  name: x
  version: "0.1.0"
  agent_shield_version: "2.0"
state_validation:
  policies:
    - name: x
"#;
    let err = load_from_str(yaml).unwrap_err();
    assert!(matches!(err, ConfigError::V1Vocabulary { .. }));
    assert!(err.to_string().contains("policies"));
}

#[test]
fn rejects_multi_kind_evaluate_when_entry() {
    let yaml = r#"
metadata:
  name: x
  version: "0.1.0"
  agent_shield_version: "2.0"
input_validation:
  guard_policies:
    - name: bad
      evaluate_when:
        - expression: "y"
          pattern: "abc"
          reason: r
"#;
    let err = load_from_str(yaml).unwrap_err().to_string();
    assert!(err.contains("exactly one") || err.contains("evaluate_when"));
}

#[test]
fn rejects_evaluate_when_entry_without_reason() {
    let yaml = r#"
metadata:
  name: x
  version: "0.1.0"
  agent_shield_version: "2.0"
input_validation:
  guard_policies:
    - name: bad
      evaluate_when:
        - expression: "y"
"#;
    let err = load_from_str(yaml).unwrap_err().to_string();
    assert!(err.contains("reason"));
}
