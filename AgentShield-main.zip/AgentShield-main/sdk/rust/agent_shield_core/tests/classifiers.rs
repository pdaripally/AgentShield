//! End-to-end smoke tests for the bundled classifier providers.
//!
//! Drives [`AutoWiredClassifierCaller`] through `ClassifierCaller`
//! against canned HTTP responses (no live network) and asserts the
//! §11.12.4 fold for each provider.

#![cfg(all(
    feature = "lakera-guard",
    feature = "openai-moderation",
    feature = "perspective",
    feature = "llama-guard",
    feature = "aacs",
))]

use std::collections::HashMap;
use std::sync::Arc;

use agent_shield_core::classifiers::{AutoWiredClassifierCaller, StubHttpTransport};
use agent_shield_core::configurations::{ConfigurationType, ShieldConfiguration};
use agent_shield_core::guard_policy_runtime::ClassifierCaller;

fn classifier_cfg(id: &str, provider: &str, endpoint: &str, key_env: &str) -> ShieldConfiguration {
    let mut thresholds = HashMap::new();
    thresholds.insert("listed_cat".into(), 0.7);
    ShieldConfiguration {
        id: id.into(),
        config_type: ConfigurationType::Classifier,
        default: None,
        provider: Some(provider.into()),
        provider_config: None,
        endpoint: Some(endpoint.into()),
        timeout: Some(1000),
        on_error: None,
        on_error_log: None,
        headers: HashMap::new(),
        model: None,
        max_tokens: None,
        api_key_env: Some(key_env.into()),
        metadata: None,
        threshold: Some(0.5),
        method: None,
        category_thresholds: thresholds,
        agent_id: None,
        tool: None,
    }
}

fn build_caller(
    cfgs: &[ShieldConfiguration],
    response: &str,
    status: u16,
) -> AutoWiredClassifierCaller {
    let stub: Arc<dyn agent_shield_core::classifiers::HttpTransport> =
        Arc::new(StubHttpTransport::with_response(status, response));
    AutoWiredClassifierCaller::from_configurations_with_transport(cfgs, stub)
}

#[test]
fn unknown_provider_does_not_install_caller() {
    let cfg = classifier_cfg("x", "no_such_provider", "http://x", "AS_TEST_BUNDLED_KEY");
    std::env::set_var("AS_TEST_BUNDLED_KEY", "k");
    let caller = build_caller(std::slice::from_ref(&cfg), "{}", 200);
    assert!(!caller.has_any());
}

#[test]
fn unknown_id_returns_error() {
    let cfg = classifier_cfg("x", "lakera_guard", "http://x", "AS_TEST_LAKERA_KEY");
    std::env::set_var("AS_TEST_LAKERA_KEY", "k");
    let caller = build_caller(
        std::slice::from_ref(&cfg),
        r#"{"results":[{"flagged":false,"category_scores":{}}]}"#,
        200,
    );
    let err = caller.classify("nope", "subject").unwrap_err();
    assert!(err.contains("no resolved classifier configuration"));
}

#[test]
fn lakera_guard_dispatches_through_caller() {
    let cfg = classifier_cfg("lk", "lakera_guard", "http://x", "AS_TEST_LAKERA_KEY");
    std::env::set_var("AS_TEST_LAKERA_KEY", "k");
    let caller = build_caller(
        std::slice::from_ref(&cfg),
        r#"{"results":[{"flagged":true,"category_scores":{"listed_cat":0.95}}]}"#,
        200,
    );
    let v = caller.classify("lk", "subject").unwrap();
    assert!(v.is_failure());
    assert_eq!(v.label.as_deref(), Some("listed_cat"));
}

#[test]
fn openai_moderation_5xx_is_fail_closed() {
    let cfg = classifier_cfg("om", "openai_moderation", "http://x", "AS_TEST_OPENAI_KEY");
    std::env::set_var("AS_TEST_OPENAI_KEY", "k");
    let caller = build_caller(std::slice::from_ref(&cfg), "internal error", 500);
    let err = caller.classify("om", "subject").unwrap_err();
    assert!(err.contains("HTTP 500"));
}

#[test]
fn aacs_dispatches_through_caller_with_severity_normalization() {
    let cfg = classifier_cfg(
        "az",
        "azure_content_safety",
        "https://my.cognitiveservices.azure.com",
        "AS_TEST_AACS_KEY",
    );
    std::env::set_var("AS_TEST_AACS_KEY", "k");
    let caller = build_caller(
        std::slice::from_ref(&cfg),
        r#"{"categoriesAnalysis":[{"category":"listed_cat","severity":6}]}"#,
        200,
    );
    let v = caller.classify("az", "subject").unwrap();
    assert!(v.is_failure());
}

#[test]
fn perspective_low_score_passes() {
    let cfg = classifier_cfg(
        "p",
        "perspective",
        "https://commentanalyzer.googleapis.com/v1alpha1/comments:analyze",
        "AS_TEST_PERSPECTIVE_KEY",
    );
    std::env::set_var("AS_TEST_PERSPECTIVE_KEY", "k");
    let caller = build_caller(
        std::slice::from_ref(&cfg),
        r#"{"attributeScores":{"LISTED_CAT":{"summaryScore":{"value":0.1}}}}"#,
        200,
    );
    let v = caller.classify("p", "subject").unwrap();
    assert!(!v.is_failure());
}

#[test]
fn llama_guard_unsafe_blocks() {
    let cfg = classifier_cfg(
        "lg",
        "llama_guard",
        "http://localhost:8080/v1/chat/completions",
        "AS_TEST_LLAMA_KEY",
    );
    std::env::set_var("AS_TEST_LLAMA_KEY", "k");
    let caller = build_caller(
        std::slice::from_ref(&cfg),
        r#"{"choices":[{"message":{"content":"unsafe\nS3"}}]}"#,
        200,
    );
    let v = caller.classify("lg", "subject").unwrap();
    assert!(v.is_failure());
}

#[test]
fn malformed_json_is_fail_closed() {
    let cfg = classifier_cfg("lk", "lakera_guard", "http://x", "AS_TEST_LAKERA_KEY");
    std::env::set_var("AS_TEST_LAKERA_KEY", "k");
    let caller = build_caller(std::slice::from_ref(&cfg), "{not-json", 200);
    let err = caller.classify("lk", "subject").unwrap_err();
    assert!(err.contains("JSON parse"));
}
