//! `objective` block (§5).
//!
//! The merged objective preserves authority attribution per §5.1: each
//! contributing tier carries its `metadata.name` so a renderer can emit
//! `(authority N)` headings.

use serde::{Deserialize, Serialize};

/// One tier's contribution to the merged objective.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ObjectiveTier {
    /// Source tier label — typically `metadata.name` of the contributing file.
    pub source: String,
    /// `goal[]` from this tier (REQUIRED to be non-empty for the leaf, but a
    /// parent file may omit `objective:` entirely).
    pub goal: Vec<String>,
    /// `forbidden[]` from this tier.
    #[serde(default)]
    pub forbidden: Vec<String>,
}

/// Top-level merged objective. A thin tier-list consumed by the §5.1
/// rendering helper to emit Markdown.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Objective {
    /// Tiers in ancestry order — parent first, leaf last.
    pub tiers: Vec<ObjectiveTier>,
}

impl Objective {
    /// Concatenated `goal[]` across all tiers, in ancestry order.
    pub fn flat_goals(&self) -> impl Iterator<Item = &str> {
        self.tiers
            .iter()
            .flat_map(|t| t.goal.iter().map(String::as_str))
    }

    /// Concatenated `forbidden[]` across all tiers, in ancestry order.
    pub fn flat_forbidden(&self) -> impl Iterator<Item = &str> {
        self.tiers
            .iter()
            .flat_map(|t| t.forbidden.iter().map(String::as_str))
    }
}

/// Single-file wire shape — what the YAML actually carries.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ObjectiveFile {
    pub goal: GoalList,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub forbidden: Option<Vec<String>>,
}

/// Strict array form for `goal[]`. Scalars are rejected with a clear error
/// (§5: legacy scalar `goal:` MUST NOT validate).
#[derive(Debug, Clone, Serialize)]
#[serde(transparent)]
pub struct GoalList(pub Vec<String>);

impl<'de> Deserialize<'de> for GoalList {
    fn deserialize<D: serde::Deserializer<'de>>(de: D) -> std::result::Result<Self, D::Error> {
        let v = serde_yaml::Value::deserialize(de)?;
        match v {
            serde_yaml::Value::Sequence(seq) => {
                let mut out = Vec::with_capacity(seq.len());
                for item in seq {
                    match item {
                        serde_yaml::Value::String(s) => {
                            if s.is_empty() {
                                return Err(serde::de::Error::custom(
                                    "objective.goal[] entries must be non-empty strings",
                                ));
                            }
                            out.push(s);
                        }
                        other => {
                            return Err(serde::de::Error::custom(format!(
                                "objective.goal[] entries must be strings, got {:?}",
                                other
                            )))
                        }
                    }
                }
                if out.is_empty() {
                    return Err(serde::de::Error::custom(
                        "objective.goal[] must declare at least one entry",
                    ));
                }
                Ok(GoalList(out))
            }
            serde_yaml::Value::String(_) => Err(serde::de::Error::custom(
                "objective.goal must be a list of strings — the legacy scalar form is rejected (§5)",
            )),
            other => Err(serde::de::Error::custom(format!(
                "objective.goal must be a list of strings, got {:?}",
                other
            ))),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_array_goal() {
        let f: ObjectiveFile =
            serde_yaml::from_str("goal:\n  - one\n  - two\nforbidden:\n  - bad\n").unwrap();
        assert_eq!(f.goal.0.len(), 2);
        assert_eq!(f.forbidden.unwrap().len(), 1);
    }

    #[test]
    fn rejects_scalar_goal() {
        let err = serde_yaml::from_str::<ObjectiveFile>("goal: \"single string\"\n")
            .unwrap_err()
            .to_string();
        assert!(err.contains("scalar form"));
    }

    #[test]
    fn rejects_empty_goal_list() {
        let err = serde_yaml::from_str::<ObjectiveFile>("goal: []\n")
            .unwrap_err()
            .to_string();
        assert!(err.contains("at least one"));
    }

    #[test]
    fn flat_goals_preserves_ancestry_order() {
        let obj = Objective {
            tiers: vec![
                ObjectiveTier {
                    source: "parent".into(),
                    goal: vec!["a".into()],
                    forbidden: vec![],
                },
                ObjectiveTier {
                    source: "leaf".into(),
                    goal: vec!["b".into(), "c".into()],
                    forbidden: vec!["x".into()],
                },
            ],
        };
        let goals: Vec<&str> = obj.flat_goals().collect();
        assert_eq!(goals, vec!["a", "b", "c"]);
        let forb: Vec<&str> = obj.flat_forbidden().collect();
        assert_eq!(forb, vec!["x"]);
    }
}
