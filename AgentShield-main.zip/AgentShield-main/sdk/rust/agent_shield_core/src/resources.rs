//! Identity-only resources catalog (§13). Tools, endpoints, sub-agents.

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Permission {
    ReadOnly,
    ReadWrite,
    Execute,
    Destructive,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum OnErrorPolicy {
    Allow,
    Block,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct LogBlock {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub severity: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub category: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub message: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct ToolResource {
    pub name: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub description: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub permission: Option<Permission>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub protocol: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub on_error: Option<OnErrorPolicy>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub on_error_log: Option<LogBlock>,
    /// IFC `λ` for this tool — the tag set its result is classified
    /// at. Reading the result unions this set into the running
    /// exposure. Names resolved against `ifc.tags`. Use `["*"]` for
    /// the full universe. Omitted ⇒ `∅` in lenient mode, load-time
    /// error in strict mode (the default). See proof TC-9.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub tags: Option<Vec<String>>,
    /// IFC `μ` for this tool — the tag set its arguments will accept.
    /// Runtime denies the call when `exposure ⊆ clearance` fails.
    /// Omitted ⇒ `ifc.default_clearance`. See proof TC-7, TC-8.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub clearance: Option<Vec<String>>,
    /// IFC `ν` for this tool — the tag set an observer must hold to
    /// see this tool's invocation and side-effects. Read directionally:
    /// `ν = []` means "no clearance required (publicly observable)"
    /// and `ν = ["*"]` means "top clearance required (fully restricted)".
    /// Omitted ⇒ `ifc.default_audience`. See proof TC-8, TC-9.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub audience: Option<Vec<String>>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct EndpointResource {
    pub pattern: String,
    pub methods: Vec<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub description: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub on_error: Option<OnErrorPolicy>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub on_error_log: Option<LogBlock>,
    /// See [`ToolResource::tags`].
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub tags: Option<Vec<String>>,
    /// See [`ToolResource::clearance`].
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub clearance: Option<Vec<String>>,
    /// See [`ToolResource::audience`].
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub audience: Option<Vec<String>>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct AgentResource {
    pub name: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub description: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub on_error: Option<OnErrorPolicy>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub on_error_log: Option<LogBlock>,
    /// See [`ToolResource::tags`].
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub tags: Option<Vec<String>>,
    /// See [`ToolResource::clearance`].
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub clearance: Option<Vec<String>>,
    /// See [`ToolResource::audience`].
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub audience: Option<Vec<String>>,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct ResourcesBlock {
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub tools: Vec<ToolResource>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub endpoints: Vec<EndpointResource>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub agents: Vec<AgentResource>,
}

impl ResourcesBlock {
    pub fn is_empty(&self) -> bool {
        self.tools.is_empty() && self.endpoints.is_empty() && self.agents.is_empty()
    }

    pub fn count(&self) -> usize {
        self.tools.len() + self.endpoints.len() + self.agents.len()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_minimal_tool() {
        let yaml = "tools:\n  - name: send_email\n";
        let r: ResourcesBlock = serde_yaml::from_str(yaml).unwrap();
        assert_eq!(r.tools.len(), 1);
        assert_eq!(r.tools[0].name, "send_email");
        assert!(r.tools[0].permission.is_none());
    }

    #[test]
    fn rejects_unknown_field_on_tool() {
        let yaml = "tools:\n  - name: x\n    bogus: 1\n";
        let err = serde_yaml::from_str::<ResourcesBlock>(yaml).unwrap_err();
        assert!(err.to_string().contains("bogus"));
    }

    #[test]
    fn parses_full_endpoint() {
        let yaml = "
endpoints:
  - pattern: \"/api/v1/x\"
    methods: [GET, POST]
    description: hello
";
        let r: ResourcesBlock = serde_yaml::from_str(yaml).unwrap();
        assert_eq!(r.endpoints[0].methods.len(), 2);
    }

    #[test]
    fn count_aggregates() {
        let r = ResourcesBlock {
            tools: vec![ToolResource {
                name: "x".into(),
                description: None,
                permission: None,
                protocol: None,
                on_error: None,
                on_error_log: None,
                tags: None,
                clearance: None,
                audience: None,
            }],
            agents: vec![AgentResource {
                name: "y".into(),
                description: None,
                on_error: None,
                on_error_log: None,
                tags: None,
                clearance: None,
                audience: None,
            }],
            endpoints: vec![],
        };
        assert_eq!(r.count(), 2);
    }
}
