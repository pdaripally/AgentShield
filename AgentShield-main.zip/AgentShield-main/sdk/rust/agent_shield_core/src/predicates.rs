//! `predicates` map (§8).
//!
//! Same-name redefinition across files is a load-time error (§8.4). The
//! per-file map carries each entry's source path so the merger can produce a
//! useful error when redefinition is detected.

use std::collections::BTreeMap;
use std::path::PathBuf;

use serde::{Deserialize, Serialize};

use super::lifetime::Lifetime;

/// Body of a single predicate. Matches the schema's bare-or-object oneOf.
#[derive(Debug, Clone, Serialize)]
#[serde(deny_unknown_fields)]
pub struct PredicateBody {
    pub expression: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub lifetime: Option<Lifetime>,
}

impl<'de> Deserialize<'de> for PredicateBody {
    fn deserialize<D: serde::Deserializer<'de>>(de: D) -> std::result::Result<Self, D::Error> {
        let v = serde_yaml::Value::deserialize(de)?;
        match v {
            serde_yaml::Value::String(expression) => {
                if expression.is_empty() {
                    return Err(serde::de::Error::custom("predicate body must be non-empty"));
                }
                Ok(PredicateBody {
                    expression,
                    lifetime: None,
                })
            }
            serde_yaml::Value::Mapping(_) => {
                #[derive(Deserialize)]
                #[serde(deny_unknown_fields)]
                struct ObjForm {
                    expression: String,
                    #[serde(default)]
                    lifetime: Option<Lifetime>,
                }
                let o: ObjForm = serde_yaml::from_value(v).map_err(serde::de::Error::custom)?;
                if o.expression.is_empty() {
                    return Err(serde::de::Error::custom(
                        "predicate body `expression:` must be non-empty",
                    ));
                }
                Ok(PredicateBody {
                    expression: o.expression,
                    lifetime: o.lifetime,
                })
            }
            other => Err(serde::de::Error::custom(format!(
                "predicate body must be a string or mapping, got {:?}",
                other
            ))),
        }
    }
}

/// Single-file predicate wire shape: `name -> body`.
pub type PredicateFileMap = BTreeMap<String, PredicateBody>;

/// Merged predicate entry: body + source provenance.
#[derive(Debug, Clone)]
pub struct PredicateEntry {
    pub body: PredicateBody,
    pub origin: PathBuf,
}

/// Merged predicate map across the `extends:` chain.
#[derive(Debug, Clone, Default)]
pub struct PredicateMap {
    pub entries: BTreeMap<String, PredicateEntry>,
}

impl PredicateMap {
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    pub fn len(&self) -> usize {
        self.entries.len()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_bare_predicate() {
        let m: PredicateFileMap = serde_yaml::from_str("is_admin: \"role == 'admin'\"\n").unwrap();
        assert_eq!(m.len(), 1);
        assert_eq!(m["is_admin"].expression, "role == 'admin'");
        assert!(m["is_admin"].lifetime.is_none());
    }

    #[test]
    fn parses_object_predicate_with_lifetime() {
        let yaml = "
is_admin:
  expression: \"role == 'admin'\"
  lifetime: per_session
";
        let m: PredicateFileMap = serde_yaml::from_str(yaml).unwrap();
        assert!(m["is_admin"].lifetime.is_some());
    }

    #[test]
    fn rejects_unknown_keys() {
        let err = serde_yaml::from_str::<PredicateFileMap>(
            "is_admin:\n  expression: \"x\"\n  bogus: 1\n",
        )
        .unwrap_err();
        assert!(err.to_string().contains("bogus"));
    }
}
