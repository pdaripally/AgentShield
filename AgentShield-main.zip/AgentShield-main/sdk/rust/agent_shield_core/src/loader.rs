//! YAML loader.
//!
//! Public entries:
//! - [`load_from_str`]: parse a single YAML buffer (no `extends:` resolution).
//! - [`load_from_path`]: read a file from disk, follow `extends:`, merge.
//! - [`load_chain`]: alias for `load_from_path` for clarity.
//!
//! Behaviour:
//! - Reject unknown YAML keys at every level.
//! - Reject pre-v1 vocabulary with a clear migration error pointing at
//!   `agent_shield_version`.
//! - Resolve `extends:` chain (depth ≥10, dedupe diamond loads, cycle detection).
//! - Enforce `agent_shield_version` band rules across the chain (§4.2).
//! - Build resolver dependency graph and reject cycles.

use std::collections::{BTreeMap, BTreeSet, HashMap};
use std::path::{Path, PathBuf};

use serde::Deserialize;

use crate::configurations::ShieldConfiguration;
pub use crate::constants::loader::{
    MAX_EXTENDS_DEPTH, MAX_PROMPT_FILE_BYTES, MAX_REMOTE_BODY_BYTES, MAX_REMOTE_FETCHES,
    MAX_REMOTE_TOTAL_BYTES,
};
use crate::errors::{ConfigError, PromptFileErrorKind, Result, SourceLoc};
use crate::guard_policy::{GuardPolicy, StageFlavor};
use crate::merge::{merge_chain, MergedConfig, ParsedFile};
use crate::metadata::{Metadata, RUNTIME_SPEC_VERSION};
use crate::objective::{ObjectiveFile, ObjectiveTier};
use crate::predicates::{PredicateBody, PredicateFileMap};
use crate::resources::ResourcesBlock;
use crate::variables::Variable;

/// Top-level file shape — pre-merge. Single file only.
#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct FileWire {
    #[serde(default)]
    extends: Vec<ExtendsEntry>,
    #[serde(default)]
    metadata: Option<Metadata>,
    #[serde(default)]
    objective: Option<ObjectiveFile>,
    #[serde(default)]
    configurations: Vec<ShieldConfiguration>,
    #[serde(default)]
    predicates: PredicateFileMap,
    #[serde(default)]
    variables: Vec<Variable>,
    #[serde(default)]
    resources: ResourcesBlock,
    #[serde(default)]
    input_validation: Option<StageBlockWire>,
    #[serde(default)]
    state_validation: Option<StageStateBlockWire>,
    #[serde(default)]
    tool_execution_validation: Option<StageBlockWire>,
    #[serde(default)]
    post_tool_validation: Option<StageBlockWire>,
    #[serde(default)]
    output_validation: Option<StageBlockWire>,
    #[serde(default)]
    ifc: Option<crate::ifc::IfcSpec>,
}

/// One entry of the file's `extends:` list (§3.2).
///
/// Two shapes are accepted:
///
/// 1. A bare string — a path or relative URL resolved against the
///    declaring file. Bare strings are valid when the declaring file
///    is a **local** file (the entry resolves as a filesystem path).
///    When the declaring file is itself remote, a bare-string entry is
///    rejected because its bytes would not be integrity-pinned.
/// 2. An object `{ url, integrity }` or `{ url, unverified: true }`.
///    The `integrity` form is the secure-by-default path: an SRI
///    literal of the form `sha256-<base64>` is computed over the
///    fetched body and verified at load time. The `unverified: true`
///    form is an explicit acknowledgment that the loaded bytes are
///    not byte-verified at load time; the deployment is taking
///    responsibility for trust by some out-of-band means (internal
///    network containment, a signing proxy, dev-only iteration, etc.).
///    Exactly one of `integrity` or `unverified: true` MUST be present.
///
/// Plain string entries that start with an HTTP(S) scheme are rejected
/// with a hint to use the object form. The reviewer of a `.guardrails.yaml`
/// should never have to read a list of strings to discover that one of
/// them is silently pulling bytes from the network — the choice MUST
/// be explicit.
#[derive(Debug, Deserialize, Clone)]
#[serde(untagged)]
enum ExtendsEntry {
    Bare(String),
    Url(ExtendsUrl),
}

#[derive(Debug, Deserialize, Clone)]
#[serde(deny_unknown_fields)]
struct ExtendsUrl {
    url: String,
    #[serde(default)]
    integrity: Option<String>,
    /// When `true`, skip the SHA-256 body comparison at load time. The
    /// resource bounds (scheme, redirects, body cap, fetch budget) and
    /// the rest of the load pipeline still apply; only the content
    /// trust check is opted out. Mutually exclusive with `integrity`.
    #[serde(default)]
    unverified: Option<bool>,
}

#[derive(Debug, Deserialize, Default)]
#[serde(deny_unknown_fields)]
#[allow(dead_code)]
struct StageBlockWire {
    #[serde(default)]
    configuration: Option<String>,
    #[serde(default)]
    guard_policies: Vec<GuardPolicy>,
    // Stage 3 / 4 also accept block-level applies_to per the schema; we
    // accept it explicitly so unknown-field detection doesn't reject it:
    #[serde(default)]
    applies_to: Option<crate::guard_policy::AppliesTo>,
}

#[derive(Debug, Deserialize, Default)]
#[serde(deny_unknown_fields)]
struct StageStateBlockWire {
    #[serde(default)]
    guard_policies: Vec<GuardPolicy>,
}

/// Load and merge a chain of guardrails files from disk. Each path's `extends:`
/// chain is resolved independently; the resulting parents-then-leaf
/// emit-order from each path is concatenated in the supplied order.
/// Diamond loads (a parent shared between paths) are deduped via a
/// shared canonical-path visited set so each file contributes its
/// content exactly once.
///
/// At least one path is required; the LAST path is treated as the
/// effective leaf (its `metadata` block must be populated, per §4).
///
/// **Explicit-path precedence.** If an earlier explicit path's
/// `extends:` chain pulls in a later explicit path (i.e., the caller
/// passes `[A, B]` and `A extends B`), `walk_extends` would emit `B`
/// inside `A`'s chain and skip the later explicit `B` as already
/// visited — that would silently invert the documented rightmost-wins
/// semantics. To preserve the API contract, every explicit path is
/// promoted to the end of the merge order after its chain has been
/// resolved, so the LAST explicit path is always the merge leaf.
/// Result of a successful path-backed load — both the merged config
/// AND the canonical inlined YAML bytes for each loaded node, in
/// chain order (parents first, leaf last).
///
/// The `inlined_yamls` field is the digest pipeline's input. Each
/// string is the bytes-on-disk for one node with any
/// `evaluate_when[].llm.prompt_path` already replaced by inlined
/// `prompt:` text (§12.9.2). Files that didn't carry any
/// `prompt_path:` are returned byte-for-byte from disk so the
/// digest doesn't churn under serializer formatting normalisation.
///
/// `pub(crate)` — only the `GuardrailsConfig::compile` digest path
/// in `config.rs` consumes this today. If/when an external caller
/// needs the inlined chain, the field set can be promoted; keeping
/// it crate-internal avoids building API surface we can't easily
/// reshape.
pub(crate) struct LoadedChain {
    pub(crate) merged: MergedConfig,
    pub(crate) inlined_yamls: Vec<String>,
}

/// Load and merge a chain of YAML files. See [`load_from_paths`] for
/// the wrapper that drops `inlined_yamls`.
pub(crate) fn load_from_paths_impl<P: AsRef<Path>>(paths: &[P]) -> Result<LoadedChain> {
    if paths.is_empty() {
        return Err(ConfigError::Schema {
            loc: SourceLoc::default(),
            message: "load_from_paths: paths slice is empty".into(),
        });
    }

    let mut visited: HashMap<NodeKey, usize> = HashMap::new();
    let mut in_progress: BTreeSet<NodeKey> = BTreeSet::new();
    let mut stack: Vec<NodeKey> = Vec::new();
    let mut order: Vec<NodeKey> = Vec::new();
    let mut wires: HashMap<NodeKey, (FileWire, String)> = HashMap::new();
    let mut remote = RemoteCtx::default();
    let mut leaf_node: Option<NodeKey> = None;

    for path in paths {
        let canonical = canonicalize(path.as_ref())?;
        let node = NodeKey::Path(canonical);
        walk_extends(
            &node,
            0,
            &mut visited,
            &mut in_progress,
            &mut stack,
            &mut order,
            &mut wires,
            &mut remote,
        )?;
        // Promote the explicit path to the end of `order` so the
        // last-listed path always wins merge_chain's leaf-wins semantics
        // even if it was already pulled in by an earlier path's
        // extends-chain.
        if let Some(pos) = order.iter().position(|p| p == &node) {
            if pos != order.len() - 1 {
                let p = order.remove(pos);
                order.push(p);
            }
        }
        leaf_node = Some(node);
    }

    let mut parsed: Vec<ParsedFile> = Vec::with_capacity(order.len());
    let mut inlined_yamls: Vec<String> = Vec::with_capacity(order.len());
    for node in &order {
        let (wire, yaml) = wires.remove(node).unwrap();
        inlined_yamls.push(yaml);
        parsed.push(parse_one(node.to_path_buf(), wire)?);
    }

    let leaf = leaf_node.expect("non-empty paths guaranteed by check above");
    let leaf_path = leaf.to_path_buf();

    // The LAST file must be the effective leaf (metadata required, §4).
    let leaf_parsed = parsed
        .iter()
        .find(|p| p.path == leaf_path)
        .expect("leaf path must be present in parsed set");
    if leaf_parsed.metadata.name.is_empty() {
        return Err(ConfigError::Schema {
            loc: SourceLoc::from_path(leaf_path.clone()),
            message: "leaf file (last in chain) must declare `metadata` (§4)".into(),
        });
    }

    let merged = merge_chain(parsed)?;
    validate_merged_config(&merged, Some(&leaf_path))?;
    Ok(LoadedChain {
        merged,
        inlined_yamls,
    })
}

/// Load and merge a chain of YAML files (resolving `extends:`).
///
/// Path-merge semantics: rightmost-wins. The last path in `paths` is
/// always the merge leaf; if an earlier path's `extends:` chain
/// already pulled the same file in, it's promoted to the leaf
/// position so that the API contract (`load_from_paths(&[A, B])`
/// behaves identically whether or not `A extends B`) holds.
pub fn load_from_paths<P: AsRef<Path>>(paths: &[P]) -> Result<MergedConfig> {
    load_from_paths_impl(paths).map(|c| c.merged)
}

/// Load and merge a guardrails file (resolving `extends:`) from a
/// path on disk. Equivalent to [`load_from_paths`] with a
/// single-element slice.
pub fn load_from_path(path: &Path) -> Result<MergedConfig> {
    load_from_paths(&[path])
}

/// Alias for clarity.
pub fn load_chain(path: &Path) -> Result<MergedConfig> {
    load_from_path(path)
}

/// Parse a single YAML buffer with NO `extends:` resolution. The caller is
/// responsible for chains. Useful for tests and host-supplied strings.
pub fn load_from_str(yaml: &str) -> Result<MergedConfig> {
    let wire = parse_yaml_strict(yaml, &SourceLoc::default())?;
    if !wire.extends.is_empty() {
        return Err(ConfigError::Schema {
            loc: SourceLoc::default(),
            message:
                "load_from_str: `extends:` is not supported on string inputs — use load_from_path"
                    .into(),
        });
    }
    let parsed = parse_one(PathBuf::from("<inline>"), wire)?;
    let merged = merge_chain(vec![parsed])?;
    validate_merged_config(&merged, None)?;
    Ok(merged)
}

/// Load and merge an explicit chain of YAML *strings* into a [`MergedConfig`].
///
/// Each input string is parsed independently (no `extends:` on string
/// inputs) and the parsed files are merged left-to-right with leaf-wins
/// semantics — semantically identical to [`load_from_paths`] but without
/// touching the filesystem.
///
/// Designed for in-memory composition (`GuardrailsConfig.extend(...)` /
/// `with_overrides`) where the host has already produced the materialised
/// YAML for each layer.
pub fn load_from_strings(yamls: &[&str]) -> Result<MergedConfig> {
    if yamls.is_empty() {
        return Err(ConfigError::Schema {
            loc: SourceLoc::default(),
            message: "load_from_strings: input slice is empty".into(),
        });
    }
    let mut parsed_chain: Vec<ParsedFile> = Vec::with_capacity(yamls.len());
    for (i, yaml) in yamls.iter().enumerate() {
        let wire = parse_yaml_strict(yaml, &SourceLoc::default())?;
        if !wire.extends.is_empty() {
            return Err(ConfigError::Schema {
                loc: SourceLoc::default(),
                message: format!(
                    "load_from_strings: `extends:` is not supported on string \
                     inputs (chain entry #{i})"
                ),
            });
        }
        let pseudo_path = PathBuf::from(format!("<inline-{i}>"));
        parsed_chain.push(parse_one(pseudo_path, wire)?);
    }
    let merged = merge_chain(parsed_chain)?;
    validate_merged_config(&merged, None)?;
    Ok(merged)
}

/// Run the full post-merge validation pipeline.
///
/// Both `load_from_str` and `load_from_path` route through this
/// function so that string-input loads are validated identically to
/// disk-backed loads . Steps, in order:
///
/// 1. `agent_shield_version` runtime-compatibility check (§4.1).
/// 2. Per-stage shape validation (§12.3.1, §15).
/// 3. Reference-resolution: every `applies_to.tools/agents`, resolver
///    `name`/`configuration` reference must resolve to a declared
///    resource/configuration (§1.3, §11.10, §12.3).
/// 4. `event.fired()` argument validation (§9.3).
/// 5. Resolver-graph cycle detection (§11.5).
fn validate_merged_config(merged: &MergedConfig, canonical: Option<&Path>) -> Result<()> {
    // §4.1 runtime-compatibility check.
    if let Some(declared) = &merged.effective_agent_shield_version {
        if !declared.compatible_with(&RUNTIME_SPEC_VERSION) {
            let loc = canonical
                .map(|p| SourceLoc::from_path(p.to_path_buf()))
                .unwrap_or_default();
            return Err(ConfigError::IncompatibleAgentShieldVersion {
                loc,
                declared: declared.to_string(),
                runtime: RUNTIME_SPEC_VERSION.to_string(),
            });
        }
    }

    // Per-stage shape validation.
    for gp in &merged.input_validation.guard_policies {
        gp.validate_for_stage(StageFlavor::Input)
            .map_err(|m| ConfigError::schema(SourceLoc::default(), m))?;
    }
    for gp in &merged.state_validation.guard_policies {
        gp.validate_for_stage(StageFlavor::State)
            .map_err(|m| ConfigError::schema(SourceLoc::default(), m))?;
    }
    for gp in &merged.tool_execution_validation.guard_policies {
        gp.validate_for_stage(StageFlavor::ToolExecution)
            .map_err(|m| ConfigError::schema(SourceLoc::default(), m))?;
    }
    for gp in &merged.post_tool_validation.guard_policies {
        gp.validate_for_stage(StageFlavor::PostTool)
            .map_err(|m| ConfigError::schema(SourceLoc::default(), m))?;
    }
    for gp in &merged.output_validation.guard_policies {
        gp.validate_for_stage(StageFlavor::Output)
            .map_err(|m| ConfigError::schema(SourceLoc::default(), m))?;
    }

    // Resource/configuration reference resolution (§1.3, §11.10, §12.3).
    validate_references(merged)?;

    // event.fired() argument validation (§9.3).
    validate_event_fired_calls(merged)?;

    detect_resolver_cycles(merged)?;

    Ok(())
}

// ── Internals ────────────────────────────────────────────────────────

/// Identity of a node in the `extends:` graph. Either a local file
/// (canonicalised path) or a remote HTTPS URL (normalised string). Used
/// as the key for tri-color cycle detection and diamond dedupe across
/// mixed local/remote chains (§3.2).
#[derive(Debug, Clone, PartialEq, Eq, Hash, PartialOrd, Ord)]
enum NodeKey {
    Path(PathBuf),
    Url(String),
}

impl NodeKey {
    /// Render the node identity as a `PathBuf` for `ParsedFile.path` and
    /// `SourceLoc::from_path`. Remote URLs are stashed verbatim into the
    /// PathBuf so error display strings show the original URL.
    fn to_path_buf(&self) -> PathBuf {
        match self {
            NodeKey::Path(p) => p.clone(),
            NodeKey::Url(u) => PathBuf::from(u),
        }
    }

    fn display(&self) -> String {
        match self {
            NodeKey::Path(p) => p.display().to_string(),
            NodeKey::Url(u) => u.clone(),
        }
    }
}

/// One fetched-and-verified remote `extends:` body, cached for the
/// duration of a single load call. Cached entries are keyed by the
/// normalised URL (lowercase scheme/host, no fragment, no credentials).
struct FetchedRemote {
    /// Only read by the `http`-gated fetch path; held for cache hits.
    #[cfg_attr(not(feature = "http"), allow(dead_code))]
    body: String,
    actual_integrity: String,
}

/// Per-load remote-fetch budget and cache. The counters are advanced
/// only by the `http`-gated fetch path; with `http` disabled the
/// struct exists solely as the cache carrier for the cycle-detection
/// pass through `walk_extends_inner`.
#[derive(Default)]
struct RemoteCtx {
    cache: HashMap<String, FetchedRemote>,
    #[cfg_attr(not(feature = "http"), allow(dead_code))]
    fetch_count: usize,
    #[cfg_attr(not(feature = "http"), allow(dead_code))]
    bytes_total: usize,
    /// Cached `reqwest::blocking::Client` for the duration of a single
    /// load. Built lazily on first fetch and reused for the rest so
    /// connection pooling and TLS-root parsing happen once per load,
    /// not once per fetch.
    #[cfg(feature = "http")]
    client: Option<reqwest::blocking::Client>,
}

#[cfg(feature = "http")]
impl RemoteCtx {
    /// Lazily build (once per load) a `reqwest::blocking::Client` and
    /// return a cheap `Client::clone()` for the caller. `for_url` is
    /// only consulted to populate the `RemoteFetch.url` field if
    /// client construction itself fails, so callers should pass the
    /// URL they are about to fetch.
    fn http_client(&mut self, for_url: &str) -> Result<reqwest::blocking::Client> {
        use crate::constants::loader::{MAX_REMOTE_REDIRECTS, REMOTE_FETCH_TIMEOUT_SECS};
        if let Some(c) = &self.client {
            return Ok(c.clone());
        }
        let client = reqwest::blocking::Client::builder()
            .timeout(std::time::Duration::from_secs(REMOTE_FETCH_TIMEOUT_SECS))
            .redirect(reqwest::redirect::Policy::custom(|attempt| {
                if attempt.previous().len() >= MAX_REMOTE_REDIRECTS {
                    attempt.error("too many redirects")
                } else if attempt.url().scheme() != "https" {
                    attempt.error("redirect to non-https URL is not permitted")
                } else {
                    attempt.follow()
                }
            }))
            .user_agent(concat!("agent-shield-core/", env!("CARGO_PKG_VERSION")))
            .build()
            .map_err(|e| ConfigError::RemoteFetch {
                url: for_url.to_string(),
                message: format!("client build failed: {e}"),
            })?;
        self.client = Some(client.clone());
        Ok(client)
    }
}

fn canonicalize(path: &Path) -> Result<PathBuf> {
    path.canonicalize().or_else(|_| {
        Ok::<_, ConfigError>(
            std::env::current_dir()
                .map(|d| d.join(path))
                .unwrap_or_else(|_| path.to_path_buf()),
        )
    })
}

/// Normalise an absolute HTTPS URL for use as a cache key / NodeKey.
/// Lowercases scheme and host, strips fragment and credentials, leaves
/// path/query intact. Returns the absolute URL serialised in normalised
/// form.
fn normalise_url(u: &url::Url) -> String {
    let mut u = u.clone();
    let _ = u.set_username("");
    let _ = u.set_password(None);
    u.set_fragment(None);
    // `set_scheme` lowercases the value automatically (url crate stores
    // scheme as lowercase); host is lowercased by the parser.
    u.to_string()
}

/// Resolve an `ExtendsEntry` against its declaring parent into a
/// concrete child NodeKey plus, for URL children, the verified declared
/// integrity that we then check against the fetched body in
/// `fetch_remote`.
fn resolve_child(
    parent: &NodeKey,
    entry: &ExtendsEntry,
    parent_loc: &SourceLoc,
) -> Result<(NodeKey, Option<String>)> {
    match entry {
        ExtendsEntry::Bare(s) => {
            // Reject URL-shaped bare strings — integrity must be explicit.
            let lower = s.trim_start().to_ascii_lowercase();
            if lower.starts_with("https://") || lower.starts_with("http://") {
                return Err(ConfigError::UrlExtendsRequiresIntegrity {
                    loc: parent_loc.clone(),
                    url: s.clone(),
                });
            }
            match parent {
                NodeKey::Path(p) => {
                    let child_path = p.parent().unwrap_or(Path::new(".")).join(s);
                    let canonical = canonicalize(&child_path)?;
                    Ok((NodeKey::Path(canonical), None))
                }
                NodeKey::Url(_) => {
                    // Bare-string entries in a remote file would have no
                    // integrity. Force the object form.
                    Err(ConfigError::UrlExtendsRequiresIntegrity {
                        loc: parent_loc.clone(),
                        url: s.clone(),
                    })
                }
            }
        }
        ExtendsEntry::Url(spec) => {
            let absolute = resolve_url_string(&spec.url, parent, parent_loc)?;
            // Exactly one of `integrity` or `unverified: true` must be
            // present (§3.2). Both-set and neither-set are load-time
            // errors — the choice between byte-verified and not MUST
            // be explicit at the call site, and the reviewer MUST see
            // exactly one signal.
            let unverified = spec.unverified.unwrap_or(false);
            match (spec.integrity.as_deref(), unverified) {
                (Some(_), true) => Err(ConfigError::UrlExtendsConflictingTrust {
                    loc: parent_loc.clone(),
                    url: spec.url.clone(),
                }),
                (None, false) => Err(ConfigError::UrlExtendsMissingTrust {
                    loc: parent_loc.clone(),
                    url: spec.url.clone(),
                }),
                (Some(raw_integrity), false) => {
                    let integrity = parse_integrity(raw_integrity, parent_loc)?;
                    Ok((NodeKey::Url(absolute), Some(integrity)))
                }
                (None, true) => Ok((NodeKey::Url(absolute), None)),
            }
        }
    }
}

/// Convert a (possibly-relative) URL string into a validated absolute
/// HTTPS URL, applying RFC 3986 reference resolution against the
/// parent's URL when the parent is itself remote.
fn resolve_url_string(raw: &str, parent: &NodeKey, loc: &SourceLoc) -> Result<String> {
    let absolute = match url::Url::parse(raw) {
        Ok(u) => u,
        Err(url::ParseError::RelativeUrlWithoutBase) => match parent {
            NodeKey::Url(base) => {
                let base_url = url::Url::parse(base).map_err(|e| ConfigError::Schema {
                    loc: loc.clone(),
                    message: format!("internal: parent url `{base}` is malformed: {e}"),
                })?;
                base_url.join(raw).map_err(|e| ConfigError::Schema {
                    loc: loc.clone(),
                    message: format!("malformed `extends:` url `{raw}`: {e}"),
                })?
            }
            NodeKey::Path(_) => {
                return Err(ConfigError::RelativeUrlNeedsRemoteParent {
                    loc: loc.clone(),
                    url: raw.to_string(),
                });
            }
        },
        Err(e) => {
            return Err(ConfigError::Schema {
                loc: loc.clone(),
                message: format!("malformed `extends:` url `{raw}`: {e}"),
            });
        }
    };
    if absolute.scheme() != "https" {
        return Err(ConfigError::UrlExtendsBadScheme {
            loc: loc.clone(),
            url: absolute.to_string(),
        });
    }
    if !absolute.username().is_empty()
        || absolute.password().is_some()
        || absolute.fragment().is_some()
    {
        return Err(ConfigError::UrlExtendsForbiddenComponents {
            loc: loc.clone(),
            url: absolute.to_string(),
        });
    }
    Ok(normalise_url(&absolute))
}

/// Parse and normalise a Subresource-Integrity literal. Only
/// `sha256-<base64>` is accepted (32-byte digest, standard or
/// URL-safe base64 padding tolerated). Returns the canonical
/// `sha256-<standard-base64-with-padding>` form for comparison.
fn parse_integrity(raw: &str, loc: &SourceLoc) -> Result<String> {
    use base64::Engine;

    let trimmed = raw.trim();
    let rest =
        trimmed
            .strip_prefix("sha256-")
            .ok_or_else(|| ConfigError::UrlExtendsBadIntegrity {
                loc: loc.clone(),
                value: raw.to_string(),
            })?;
    let decoded = base64::engine::general_purpose::STANDARD
        .decode(rest)
        .or_else(|_| base64::engine::general_purpose::STANDARD_NO_PAD.decode(rest))
        .or_else(|_| base64::engine::general_purpose::URL_SAFE.decode(rest))
        .or_else(|_| base64::engine::general_purpose::URL_SAFE_NO_PAD.decode(rest))
        .map_err(|_| ConfigError::UrlExtendsBadIntegrity {
            loc: loc.clone(),
            value: raw.to_string(),
        })?;
    if decoded.len() != 32 {
        return Err(ConfigError::UrlExtendsBadIntegrity {
            loc: loc.clone(),
            value: raw.to_string(),
        });
    }
    let canonical = base64::engine::general_purpose::STANDARD.encode(&decoded);
    Ok(format!("sha256-{canonical}"))
}

#[allow(clippy::too_many_arguments)]
fn walk_extends(
    node: &NodeKey,
    depth: usize,
    visited: &mut HashMap<NodeKey, usize>,
    in_progress: &mut BTreeSet<NodeKey>,
    stack: &mut Vec<NodeKey>,
    order: &mut Vec<NodeKey>,
    wires: &mut HashMap<NodeKey, (FileWire, String)>,
    remote: &mut RemoteCtx,
) -> Result<()> {
    walk_extends_inner(
        node,
        depth,
        visited,
        in_progress,
        stack,
        order,
        wires,
        remote,
        None,
    )
}

#[allow(clippy::too_many_arguments)]
fn walk_extends_inner(
    node: &NodeKey,
    depth: usize,
    visited: &mut HashMap<NodeKey, usize>,
    in_progress: &mut BTreeSet<NodeKey>,
    stack: &mut Vec<NodeKey>,
    order: &mut Vec<NodeKey>,
    wires: &mut HashMap<NodeKey, (FileWire, String)>,
    remote: &mut RemoteCtx,
    declared_integrity: Option<&str>,
) -> Result<()> {
    if depth > MAX_EXTENDS_DEPTH {
        return Err(ConfigError::ExtendsDepthExceeded {
            depth,
            max: MAX_EXTENDS_DEPTH,
            path: node.display(),
        });
    }

    // Tri-color cycle detection (§3.2):
    // - In-progress (gray): the node is currently on the recursion stack →
    //   genuine extends-chain cycle.
    // - Already completed (black): the node was fully processed earlier
    //   (diamond load) — dedupe and return Ok, BUT for remote nodes still
    //   verify that this declaration's integrity matches the cached actual
    //   so a later sibling can't widen the trust boundary by re-declaring
    //   the same URL with a weaker pin.
    //
    // For URL nodes we check declared-integrity vs the cache BEFORE the
    // in-progress branch — an intra-chain integrity conflict is a more
    // precise (and more useful) diagnostic than a cycle, and the load
    // still fails closed either way.
    if let (NodeKey::Url(url), Some(declared)) = (node, declared_integrity) {
        if let Some(entry) = remote.cache.get(url) {
            if entry.actual_integrity != declared {
                return Err(ConfigError::IntegrityConflict {
                    url: url.clone(),
                    first: entry.actual_integrity.clone(),
                    second: declared.to_string(),
                });
            }
        }
    }
    if in_progress.contains(node) {
        let mut cycle = stack.clone();
        cycle.push(node.clone());
        let display = cycle
            .iter()
            .map(|p| p.display())
            .collect::<Vec<_>>()
            .join(" → ");
        return Err(ConfigError::ExtendsCycle { path: display });
    }
    if visited.contains_key(node) {
        return Ok(());
    }

    let node_loc = SourceLoc::from_path(node.to_path_buf());
    let bytes = read_node_bytes(node, declared_integrity, remote, &node_loc)?;
    // §12.9.2 prompt_path inlining. For local nodes we replace any
    // `prompt_path: <p>` under content-stage `evaluate_when[].llm`
    // entries with the file contents BEFORE `parse_yaml_strict` runs,
    // so both the typed `FileWire` and the canonical digest pipeline
    // see the inlined form. Remote nodes reject `prompt_path:` (the
    // integrity story for remote prompt files is intentionally out of
    // scope for this spec revision).
    let inlined = inline_prompt_paths(node, &bytes, &node_loc)?;
    let wire = parse_yaml_strict(&inlined, &node_loc)?;

    visited.insert(node.clone(), depth);
    in_progress.insert(node.clone());
    stack.push(node.clone());

    // Resolve every child entry against this node BEFORE recursion so a
    // shape error in one child surfaces with this node as the source.
    let mut children: Vec<(NodeKey, Option<String>)> = Vec::with_capacity(wire.extends.len());
    for entry in &wire.extends {
        children.push(resolve_child(node, entry, &node_loc)?);
    }

    wires.insert(node.clone(), (wire, inlined));

    for (child_node, child_integrity) in children {
        walk_extends_inner(
            &child_node,
            depth + 1,
            visited,
            in_progress,
            stack,
            order,
            wires,
            remote,
            child_integrity.as_deref(),
        )?;
    }

    stack.pop();
    in_progress.remove(node);
    order.push(node.clone());
    Ok(())
}

/// Load the YAML body for a node, dispatching to disk-read or remote
/// fetch as appropriate. Remote nodes go through `fetch_remote` which
/// enforces the per-load fetch budget, body-size cap, integrity check
/// (when declared), and HTTPS-only redirect policy. `node_loc` is
/// threaded so that feature-disabled and fetch errors carry the
/// declaring file's location in their message.
///
/// `declared_integrity` carries the trust contract from the declaring
/// entry: `Some(sri)` for `{ url, integrity }` entries (verify the
/// body bytes against `sri` at fetch time and on every cache hit),
/// `None` for `{ url, unverified: true }` entries (skip the byte
/// check; resource bounds still apply).
fn read_node_bytes(
    node: &NodeKey,
    declared_integrity: Option<&str>,
    remote: &mut RemoteCtx,
    node_loc: &SourceLoc,
) -> Result<String> {
    match node {
        NodeKey::Path(p) => std::fs::read_to_string(p).map_err(|source| ConfigError::Io {
            path: p.clone(),
            source,
        }),
        NodeKey::Url(url) => fetch_remote(url, declared_integrity, remote, node_loc),
    }
}

#[cfg(feature = "http")]
fn fetch_remote(
    url: &str,
    declared: Option<&str>,
    remote: &mut RemoteCtx,
    _node_loc: &SourceLoc,
) -> Result<String> {
    use std::io::Read;

    if let Some(cached) = remote.cache.get(url) {
        if let Some(d) = declared {
            if cached.actual_integrity != d {
                return Err(ConfigError::IntegrityMismatch {
                    url: url.to_string(),
                    expected: d.to_string(),
                    actual: cached.actual_integrity.clone(),
                });
            }
        }
        return Ok(cached.body.clone());
    }

    if remote.fetch_count >= MAX_REMOTE_FETCHES {
        return Err(ConfigError::RemoteFetchCountBudgetExceeded {
            count: remote.fetch_count + 1,
            max: MAX_REMOTE_FETCHES,
            bytes_total: remote.bytes_total,
        });
    }

    let client = remote.http_client(url)?;

    let response = client
        .get(url)
        .send()
        .map_err(|e| ConfigError::RemoteFetch {
            url: url.to_string(),
            message: e.to_string(),
        })?;

    if !response.status().is_success() {
        return Err(ConfigError::RemoteFetch {
            url: url.to_string(),
            message: format!("HTTP {}", response.status()),
        });
    }

    // Enforce both the per-body cap AND the cumulative-bytes cap during
    // read: take only as many bytes as fit in the remaining budget plus
    // one (the sentinel byte that signals "too large"). Never buffer
    // over-cap bodies.
    let remaining_total = MAX_REMOTE_TOTAL_BYTES.saturating_sub(remote.bytes_total);
    let per_fetch_cap = MAX_REMOTE_BODY_BYTES.min(remaining_total);
    let mut body = Vec::with_capacity(8 * 1024);
    let mut reader = response.take(per_fetch_cap as u64 + 1);
    reader
        .read_to_end(&mut body)
        .map_err(|e| ConfigError::RemoteFetch {
            url: url.to_string(),
            message: format!("read body: {e}"),
        })?;

    verify_and_cache_body(url, declared, body, remote)
}

/// Pure post-read verification: enforce body cap and cumulative-bytes
/// cap, compute SHA-256, optionally compare with declared integrity,
/// decode UTF-8, and insert into the cache. Extracted from
/// `fetch_remote` so the invariants can be unit-tested without opening
/// a socket.
///
/// `declared` follows the same `Option` semantics as `fetch_remote`:
/// `Some(sri)` runs the byte-equality check and rejects on mismatch;
/// `None` (from a `{ url, unverified: true }` declaration) skips that
/// check. Resource caps (body size, cumulative bytes) are enforced in
/// both modes; only content trust is opted out.
///
/// On success returns the decoded body and advances `remote.fetch_count`
/// + `remote.bytes_total`. On any failure leaves both counters untouched.
///
/// The cache always stores the actual SHA-256 of the fetched bytes so
/// a later pinned declaration of the same URL can verify against the
/// real digest even if the earlier sibling declared `unverified: true`.
///
/// Only the `http`-gated `fetch_remote` calls into this function; with
/// `http` disabled it's reachable only via the in-tree unit tests, which
/// are compiled with `--all-features`.
#[cfg_attr(not(feature = "http"), allow(dead_code))]
fn verify_and_cache_body(
    url: &str,
    declared: Option<&str>,
    body: Vec<u8>,
    remote: &mut RemoteCtx,
) -> Result<String> {
    use sha2::{Digest, Sha256};

    if body.len() > MAX_REMOTE_BODY_BYTES {
        return Err(ConfigError::RemoteBodyTooLarge {
            url: url.to_string(),
            max: MAX_REMOTE_BODY_BYTES,
        });
    }
    let remaining_total = MAX_REMOTE_TOTAL_BYTES.saturating_sub(remote.bytes_total);
    if body.len() > remaining_total {
        return Err(ConfigError::RemoteBytesBudgetExceeded {
            count: remote.fetch_count + 1,
            max_bytes: MAX_REMOTE_TOTAL_BYTES,
            bytes_total: remote.bytes_total.saturating_add(body.len()),
        });
    }

    let mut hasher = Sha256::new();
    hasher.update(&body);
    let digest = hasher.finalize();
    let actual = {
        use base64::Engine;
        format!(
            "sha256-{}",
            base64::engine::general_purpose::STANDARD.encode(digest)
        )
    };
    if let Some(d) = declared {
        if actual != d {
            return Err(ConfigError::IntegrityMismatch {
                url: url.to_string(),
                expected: d.to_string(),
                actual,
            });
        }
    }

    let body_str = String::from_utf8(body).map_err(|e| ConfigError::RemoteFetch {
        url: url.to_string(),
        message: format!("body is not valid UTF-8: {e}"),
    })?;

    // Counters advance only after all verification passes. Order matches
    // the rest of the loader: detect the failure mode first, mutate state
    // second.
    remote.fetch_count += 1;
    remote.bytes_total = remote.bytes_total.saturating_add(body_str.len());
    remote.cache.insert(
        url.to_string(),
        FetchedRemote {
            body: body_str.clone(),
            actual_integrity: actual,
        },
    );
    Ok(body_str)
}

#[cfg(not(feature = "http"))]
fn fetch_remote(
    _url: &str,
    _declared: Option<&str>,
    _remote: &mut RemoteCtx,
    node_loc: &SourceLoc,
) -> Result<String> {
    Err(ConfigError::RemoteExtendsFeatureDisabled {
        loc: node_loc.clone(),
    })
}

fn parse_yaml_strict(yaml: &str, loc: &SourceLoc) -> Result<FileWire> {
    // First pass: detect pre-v1 top-level keys. We deserialize into a
    // generic YAML mapping and inspect keys; this lets us emit a clear
    // migration hint instead of serde's default `unknown field` message.
    let value: serde_yaml::Value =
        serde_yaml::from_str(yaml).map_err(|source| ConfigError::Yaml {
            loc: loc.clone(),
            source,
        })?;

    if let Some(map) = value.as_mapping() {
        for (k, _) in map {
            if let Some(key) = k.as_str() {
                if let Some(hint) = top_level_v1_hint(key) {
                    return Err(ConfigError::v1_vocab(loc.clone(), key, hint));
                }
            }
        }
        // Detect `agentShieldVersion` (camelCase) inside metadata.
        if let Some(serde_yaml::Value::Mapping(meta)) =
            map.get(serde_yaml::Value::String("metadata".into()))
        {
            for (k, _) in meta {
                if k.as_str() == Some("agentShieldVersion") {
                    return Err(ConfigError::v1_vocab(
                        loc.clone(),
                        "metadata.agentShieldVersion",
                        "rename to `agent_shield_version` (snake_case is the convention; §1.3, §4)",
                    ));
                }
            }
        }
        // Detect `state_validation.policies` and `state_validation.global_states`.
        if let Some(serde_yaml::Value::Mapping(state)) =
            map.get(serde_yaml::Value::String("state_validation".into()))
        {
            for (k, _) in state {
                if let Some(key) = k.as_str() {
                    match key {
                        "policies" => {
                            return Err(ConfigError::v1_vocab(
                                loc.clone(),
                                "state_validation.policies",
                                "use `guard_policies:` instead of `policies:` (§15)",
                            ));
                        }
                        "global_states" => {
                            return Err(ConfigError::v1_vocab(
                                loc.clone(),
                                "state_validation.global_states",
                                "no `global_states`; engagement filters move to `active_if:` on guard policies (§12.4)",
                            ));
                        }
                        _ => {}
                    }
                }
            }
        }
        for stage in [
            "input_validation",
            "tool_execution_validation",
            "post_tool_validation",
            "output_validation",
        ] {
            if let Some(serde_yaml::Value::Mapping(stage_map)) =
                map.get(serde_yaml::Value::String(stage.into()))
            {
                for (k, _) in stage_map {
                    if k.as_str() == Some("validators") {
                        return Err(ConfigError::v1_vocab(
                            loc.clone(),
                            format!("{}.validators", stage),
                            "no `validators[]` block; every detection lives in `guard_policies[].evaluate_when[]` (§12.5)",
                        ));
                    }
                }
            }
        }
    }

    let wire: FileWire = serde_yaml::from_value(value).map_err(|source| ConfigError::Yaml {
        loc: loc.clone(),
        source,
    })?;
    Ok(wire)
}

fn top_level_v1_hint(key: &str) -> Option<&'static str> {
    match key {
        "attributes" => Some(
            "rename `attributes:` to `variables:` (§9). Migration: rename the block.",
        ),
        "agentShieldVersion" => Some(
            "use snake_case `agent_shield_version` inside `metadata:` (§1.3, §4).",
        ),
        "states" => Some(
            "no top-level `states:` block; engagement filters move to `active_if:` on guard policies (§12.4).",
        ),
        _ => None,
    }
}

/// Spec §12.9.2 — replace `prompt_path: <p>` with `prompt: <contents>`
/// in every content-stage `evaluate_when[].llm` mapping.
///
/// Runs in `walk_extends_inner` immediately after `read_node_bytes`,
/// so the YAML reaching `parse_yaml_strict` is fully inlined. This is
/// the **single canonical resolution site** for path-backed loads:
/// downstream the typed `FileWire` / `LlmDetection` model sees only
/// `prompt:`, and `canonical_digest` consumes the same inlined bytes
/// so prompt file content participates in policy identity.
///
/// Stage scope: input, tool_execution, post_tool, output. Stage 2
/// (`state_validation`) is intentionally skipped — any `llm:` block
/// there is a schema error and rejected later by
/// `GuardPolicy::validate_for_stage`, which produces a more useful
/// diagnostic than a file-read error.
///
/// Remote (`NodeKey::Url`) nodes raise
/// `PromptFileErrorKind::RemoteNotSupported` on the first `prompt_path:`
/// encountered: a remote prompt-file integrity story is intentionally
/// out of scope for this spec revision.
///
/// Non-mapping `llm:` values, malformed `evaluate_when[]` entries, and
/// every other shape issue are left to `parse_yaml_strict` / serde —
/// this pre-walk only acts on well-formed mapping shapes and writes
/// **back** to the same mapping shape.
fn inline_prompt_paths(node: &NodeKey, raw_yaml: &str, node_loc: &SourceLoc) -> Result<String> {
    let mut value: serde_yaml::Value =
        serde_yaml::from_str(raw_yaml).map_err(|source| ConfigError::Yaml {
            loc: node_loc.clone(),
            source,
        })?;

    let dir = match node {
        NodeKey::Path(p) => p.parent().map(|d| d.to_path_buf()),
        NodeKey::Url(_) => None, // Remote — only used to short-circuit to RemoteNotSupported below.
    };

    let mut changed = false;
    let mut visited_llm = |llm: &mut serde_yaml::Value| -> Result<()> {
        // Only act on mapping shapes — leave malformed values to serde.
        let serde_yaml::Value::Mapping(map) = llm else {
            return Ok(());
        };

        let prompt_key = serde_yaml::Value::String("prompt".into());
        let prompt_path_key = serde_yaml::Value::String("prompt_path".into());

        // §12.9.2 mutual exclusion is checked on **key presence**, not on
        // the value's truthiness. A YAML that declares both keys (even
        // with `prompt: ""` / non-string `prompt:`) is `BothSet` and must
        // be rejected before the file read so a malformed entry can't
        // get masked by inlining.
        let has_prompt_key = map.contains_key(&prompt_key);
        let has_prompt_path_key = map.contains_key(&prompt_path_key);

        if has_prompt_key && has_prompt_path_key {
            let path_for_diag = map
                .get(&prompt_path_key)
                .and_then(|v| v.as_str())
                .map(PathBuf::from)
                .unwrap_or_default();
            return Err(ConfigError::PromptFile {
                loc: node_loc.clone(),
                path: path_for_diag,
                kind: PromptFileErrorKind::BothSet,
            });
        }
        if !has_prompt_key && !has_prompt_path_key {
            return Err(ConfigError::PromptFile {
                loc: node_loc.clone(),
                path: PathBuf::new(),
                kind: PromptFileErrorKind::NeitherSet,
            });
        }
        if has_prompt_key {
            // Inline already (or malformed inline value — left to
            // `parse_yaml_strict` / serde to surface).
            return Ok(());
        }

        // has_prompt_path_key && !has_prompt_key — the work case.
        //
        // The value MUST be a non-empty string. Any other shape
        // (`prompt_path: ~`, `prompt_path: 42`, `prompt_path: {}`,
        // `prompt_path: ""`) is rejected explicitly here so a
        // malformed YAML can't fall through to serde where
        // `Option<String>::None` would silently collapse to an empty
        // inline prompt. The diagnostic name for these is
        // `NeitherSet` because, from the spec's perspective, a
        // declared-but-unusable `prompt_path:` is equivalent to not
        // declaring one at all.
        let Some(prompt_path) = map
            .get(&prompt_path_key)
            .and_then(|v| v.as_str())
            .map(String::from)
        else {
            return Err(ConfigError::PromptFile {
                loc: node_loc.clone(),
                path: PathBuf::new(),
                kind: PromptFileErrorKind::NeitherSet,
            });
        };
        if prompt_path.is_empty() {
            return Err(ConfigError::PromptFile {
                loc: node_loc.clone(),
                path: PathBuf::new(),
                kind: PromptFileErrorKind::NeitherSet,
            });
        }

        if matches!(node, NodeKey::Url(_)) {
            return Err(ConfigError::PromptFile {
                loc: node_loc.clone(),
                path: PathBuf::from(prompt_path),
                kind: PromptFileErrorKind::RemoteNotSupported,
            });
        }
        let Some(anchor) = dir.as_ref() else {
            // NodeKey::Path with no parent (e.g. "/") — treat as no
            // anchor available; this path is unusual but consistent
            // with how an in-memory synthetic path would be handled.
            return Err(ConfigError::PromptFile {
                loc: node_loc.clone(),
                path: PathBuf::from(prompt_path),
                kind: PromptFileErrorKind::NoAnchorDir,
            });
        };
        let resolved = anchor.join(&prompt_path);
        let content = read_prompt_file(&resolved, node_loc)?;
        map.remove(&prompt_path_key);
        map.insert(prompt_key, serde_yaml::Value::String(content));
        changed = true;
        Ok(())
    };

    walk_llm_detections(&mut value, &mut visited_llm)?;

    if !changed {
        // No mutations — return the original bytes byte-for-byte so the
        // digest pipeline sees the author's exact YAML when no
        // `prompt_path:` was used. Re-serializing through serde_yaml
        // normalises whitespace / quoting and would silently change the
        // digest for unaffected files.
        return Ok(raw_yaml.to_string());
    }

    serde_yaml::to_string(&value).map_err(|e| ConfigError::Schema {
        loc: node_loc.clone(),
        message: format!("§12.9.2: re-serialise inlined YAML: {e}"),
    })
}

/// Walk the content-stage `guard_policies[].evaluate_when[].llm` mappings
/// in a YAML `Value` and call `f` on each. State-stage detections are
/// intentionally skipped per §12.9.2 / B.4.2.
fn walk_llm_detections<F>(value: &mut serde_yaml::Value, f: &mut F) -> Result<()>
where
    F: FnMut(&mut serde_yaml::Value) -> Result<()>,
{
    let Some(top) = value.as_mapping_mut() else {
        return Ok(());
    };
    for stage in [
        "input_validation",
        "tool_execution_validation",
        "post_tool_validation",
        "output_validation",
    ] {
        let Some(stage_block) = top.get_mut(serde_yaml::Value::String(stage.into())) else {
            continue;
        };
        let Some(stage_map) = stage_block.as_mapping_mut() else {
            continue;
        };
        let Some(policies) = stage_map.get_mut(serde_yaml::Value::String("guard_policies".into()))
        else {
            continue;
        };
        let Some(policies_seq) = policies.as_sequence_mut() else {
            continue;
        };
        for policy in policies_seq.iter_mut() {
            let Some(policy_map) = policy.as_mapping_mut() else {
                continue;
            };
            let Some(ew) = policy_map.get_mut(serde_yaml::Value::String("evaluate_when".into()))
            else {
                continue;
            };
            let Some(ew_seq) = ew.as_sequence_mut() else {
                continue;
            };
            for entry in ew_seq.iter_mut() {
                let Some(entry_map) = entry.as_mapping_mut() else {
                    continue;
                };
                let Some(llm) = entry_map.get_mut(serde_yaml::Value::String("llm".into())) else {
                    continue;
                };
                f(llm)?;
            }
        }
    }
    Ok(())
}

/// Read a single UTF-8 prompt file under the `MAX_PROMPT_FILE_BYTES`
/// cap. Streams via `Read::take(cap as u64 + 1)` so over-cap content
/// fails closed without being buffered fully (mirrors the remote-body
/// pattern in `fetch_remote`).
fn read_prompt_file(path: &Path, node_loc: &SourceLoc) -> Result<String> {
    use std::io::Read;

    let metadata = match std::fs::metadata(path) {
        Ok(m) => m,
        Err(e) => {
            return Err(ConfigError::PromptFile {
                loc: node_loc.clone(),
                path: path.to_path_buf(),
                kind: PromptFileErrorKind::NotFound {
                    message: e.to_string(),
                },
            });
        }
    };
    if !metadata.file_type().is_file() {
        return Err(ConfigError::PromptFile {
            loc: node_loc.clone(),
            path: path.to_path_buf(),
            kind: PromptFileErrorKind::NotRegularFile,
        });
    }

    let cap = MAX_PROMPT_FILE_BYTES;
    let file = std::fs::File::open(path).map_err(|e| ConfigError::PromptFile {
        loc: node_loc.clone(),
        path: path.to_path_buf(),
        kind: PromptFileErrorKind::NotFound {
            message: e.to_string(),
        },
    })?;

    let mut buf: Vec<u8> = Vec::with_capacity(cap.min(8 * 1024));
    file.take(cap as u64 + 1)
        .read_to_end(&mut buf)
        .map_err(|e| ConfigError::PromptFile {
            loc: node_loc.clone(),
            path: path.to_path_buf(),
            kind: PromptFileErrorKind::NotFound {
                message: e.to_string(),
            },
        })?;

    if buf.len() > cap {
        return Err(ConfigError::PromptFile {
            loc: node_loc.clone(),
            path: path.to_path_buf(),
            kind: PromptFileErrorKind::TooLarge { max: cap },
        });
    }

    if buf.is_empty() {
        return Err(ConfigError::PromptFile {
            loc: node_loc.clone(),
            path: path.to_path_buf(),
            kind: PromptFileErrorKind::EmptyFile,
        });
    }

    String::from_utf8(buf).map_err(|_| ConfigError::PromptFile {
        loc: node_loc.clone(),
        path: path.to_path_buf(),
        kind: PromptFileErrorKind::NotUtf8,
    })
}

fn parse_one(path: PathBuf, wire: FileWire) -> Result<ParsedFile> {
    let metadata = wire.metadata.ok_or_else(|| ConfigError::MissingField {
        loc: SourceLoc::from_path(path.clone()),
        field: "metadata".into(),
    })?;

    if metadata.name.is_empty() {
        return Err(ConfigError::Schema {
            loc: SourceLoc::from_path(path.clone()),
            message: "metadata.name must be non-empty".into(),
        });
    }
    if metadata.version.is_empty() {
        return Err(ConfigError::Schema {
            loc: SourceLoc::from_path(path.clone()),
            message: "metadata.version must be non-empty".into(),
        });
    }

    let agent_shield_version = metadata.agent_shield_version.clone();

    let objective_tier = wire.objective.map(|o| ObjectiveTier {
        source: metadata.name.clone(),
        goal: o.goal.0,
        forbidden: o.forbidden.unwrap_or_default(),
    });

    let mut predicates = BTreeMap::new();
    for (k, v) in wire.predicates {
        if !is_snake_case(&k) {
            return Err(ConfigError::Schema {
                loc: SourceLoc::from_path(path.clone()),
                message: format!("predicate name `{}` must be snake_case", k),
            });
        }
        predicates.insert(
            k,
            PredicateBody {
                expression: v.expression,
                lifetime: v.lifetime,
            },
        );
    }

    let input_validation = wire
        .input_validation
        .map(|s| s.guard_policies)
        .unwrap_or_default();
    let state_validation = wire
        .state_validation
        .map(|s| s.guard_policies)
        .unwrap_or_default();
    let tool_execution_validation = wire
        .tool_execution_validation
        .map(|s| s.guard_policies)
        .unwrap_or_default();
    let post_tool_validation = wire
        .post_tool_validation
        .map(|s| s.guard_policies)
        .unwrap_or_default();
    let output_validation = wire
        .output_validation
        .map(|s| s.guard_policies)
        .unwrap_or_default();

    // §12.9.2 — prompt_path invariant check.
    //
    // For path-backed loads, the loader's `inline_prompt_paths` walk
    // (called from `walk_extends_inner`) replaces every content-stage
    // `prompt_path:` with the file's contents before `parse_yaml_strict`
    // runs, so any `LlmDetection.prompt_path == Some(_)` here is a bug
    // (file lost its inlining pass) → emit `UnresolvedPromptPath`.
    //
    // For string-input loads (`load_from_str` / `load_from_strings`)
    // the synthetic paths `<inline>` / `<inline-N>` skip
    // `walk_extends_inner`, so `LlmDetection.prompt_path` reaching
    // `parse_one` is the author's literal YAML — there's no anchor
    // directory to resolve relative paths against → emit
    // `NoAnchorDir`. We distinguish the two cases by whether `path`
    // is a real filesystem path.
    let is_synthetic = is_synthetic_inline_path(&path);
    for pol in input_validation
        .iter()
        .chain(tool_execution_validation.iter())
        .chain(post_tool_validation.iter())
        .chain(output_validation.iter())
    {
        for ew in &pol.evaluate_when {
            let crate::guard_policy::DetectionKind::Llm(llm) = &ew.detection else {
                continue;
            };
            if llm.prompt_path.is_some() {
                let prompt_path = llm.prompt_path.as_deref().unwrap_or("").to_string();
                let kind = if is_synthetic {
                    PromptFileErrorKind::NoAnchorDir
                } else {
                    PromptFileErrorKind::UnresolvedPromptPath
                };
                return Err(ConfigError::PromptFile {
                    loc: SourceLoc::from_path(path.clone()),
                    path: PathBuf::from(prompt_path),
                    kind,
                });
            }
            // §12.9.2 post-load invariant: after `inline_prompt_paths`
            // has run (path-backed) or after `parse_yaml_strict` has
            // accepted a non-empty inline `prompt:` (string-input),
            // the effective `prompt` field MUST be non-empty. A YAML
            // that ships `prompt: ""` or only sets `prompt_path:` to
            // a YAML null would have slipped past serde defaults and
            // ended up here with an empty prompt; treat that as
            // structurally `NeitherSet` (neither provides usable text).
            if llm.prompt.is_empty() {
                return Err(ConfigError::PromptFile {
                    loc: SourceLoc::from_path(path.clone()),
                    path: PathBuf::new(),
                    kind: PromptFileErrorKind::NeitherSet,
                });
            }
        }
    }

    Ok(ParsedFile {
        path,
        metadata,
        objective_tier,
        configurations: wire.configurations,
        predicates,
        variables: wire.variables,
        resources: wire.resources,
        input_validation,
        state_validation,
        tool_execution_validation,
        post_tool_validation,
        output_validation,
        agent_shield_version,
        ifc: wire.ifc,
    })
}

/// `true` iff this is a synthetic path minted for `load_from_str` /
/// `load_from_strings`. We use a literal-prefix check rather than
/// `fs::metadata` to avoid an extra syscall on every load and to keep
/// the policy local to the two sites that mint these paths.
fn is_synthetic_inline_path(path: &Path) -> bool {
    let Some(name) = path.file_name().and_then(|n| n.to_str()) else {
        return false;
    };
    name == "<inline>" || name.starts_with("<inline-")
}

fn is_snake_case(s: &str) -> bool {
    if s.is_empty() {
        return false;
    }
    let bytes = s.as_bytes();
    let head_ok = bytes[0].is_ascii_lowercase() || bytes[0] == b'_';
    let tail_ok = bytes
        .iter()
        .skip(1)
        .all(|b| b.is_ascii_lowercase() || b.is_ascii_digit() || *b == b'_');
    head_ok && tail_ok
}

/// Apply post-merge stage block enrichment. We hand-stitch `configuration:`
/// and (for stages 3/4) the block-level `applies_to:` because `merge_chain`
/// only handles the guard-policy lists.
#[allow(dead_code)]
fn enrich_stage_blocks(_merged: &mut MergedConfig, _files: &[ParsedFile]) {
    // Stage-level `configuration:` and stage-3/4 `applies_to:` are not
    // currently consumed by the runtime; this hook is reserved for when
    // they become load-bearing.
}

/// Detect cycles in the resolver dependency graph (§11.5).
///
/// Edges:
/// - For each variable v with `kind: expression` resolver: every identifier
///   in the body that names another variable with `on_demand_by:` is an
///   outgoing edge from v.
/// - For each variable v with `human|delegate|agent` resolver: every
///   identifier in `context:` and `on_allow:` values that names a variable
///   with `on_demand_by:` is an outgoing edge.
fn detect_resolver_cycles(merged: &MergedConfig) -> Result<()> {
    use crate::resolver::Resolver;

    // Map name → has on_demand_by?
    let on_demand_names: BTreeSet<&str> = merged
        .variables
        .iter()
        .filter(|v| v.on_demand_by.is_some())
        .map(|v| v.name.as_str())
        .collect();

    // Build adjacency.
    let mut adj: BTreeMap<String, Vec<String>> = BTreeMap::new();
    for v in &merged.variables {
        let name = &v.name;
        let mut edges: BTreeSet<String> = BTreeSet::new();
        if let Some(resolver) = &v.on_demand_by {
            for r in resolver.iter_chain() {
                match r {
                    Resolver::Expression {
                        expression,
                        on_allow,
                        ..
                    } => {
                        collect_identifiers(expression, &on_demand_names, name, &mut edges);
                        if let Some(map) = on_allow {
                            for expr in map.values() {
                                collect_identifiers(expr, &on_demand_names, name, &mut edges);
                            }
                        }
                    }
                    Resolver::Tool {
                        context, on_allow, ..
                    }
                    | Resolver::Human {
                        context, on_allow, ..
                    }
                    | Resolver::Delegate {
                        context, on_allow, ..
                    }
                    | Resolver::Agent {
                        context, on_allow, ..
                    } => {
                        if let Some(map) = context {
                            for expr in map.values() {
                                collect_identifiers(expr, &on_demand_names, name, &mut edges);
                            }
                        }
                        if let Some(map) = on_allow {
                            for expr in map.values() {
                                collect_identifiers(expr, &on_demand_names, name, &mut edges);
                            }
                        }
                    }
                }
            }
        }
        adj.insert(name.clone(), edges.into_iter().collect());
    }

    // DFS for cycle detection.
    let mut state: BTreeMap<String, Mark> = adj.keys().map(|k| (k.clone(), Mark::White)).collect();
    let mut path_stack: Vec<String> = Vec::new();

    for start in adj.keys().cloned().collect::<Vec<_>>() {
        if let Some(cycle) = visit(&start, &adj, &mut state, &mut path_stack) {
            return Err(ConfigError::ResolverCycle {
                loc: SourceLoc::default(),
                path: cycle,
            });
        }
    }
    Ok(())
}

fn visit(
    node: &str,
    adj: &BTreeMap<String, Vec<String>>,
    state: &mut BTreeMap<String, Mark>,
    path_stack: &mut Vec<String>,
) -> Option<String> {
    match state.get(node) {
        Some(Mark::Black) => return None,
        Some(Mark::Gray) => {
            // Cycle: build path.
            let mut cycle = path_stack.clone();
            cycle.push(node.to_string());
            return Some(cycle.join(" → "));
        }
        _ => {}
    }
    state.insert(node.to_string(), Mark::Gray);
    path_stack.push(node.to_string());
    if let Some(edges) = adj.get(node) {
        for next in edges {
            if let Some(c) = visit(next, adj, state, path_stack) {
                return Some(c);
            }
        }
    }
    path_stack.pop();
    state.insert(node.to_string(), Mark::Black);
    None
}

enum Mark {
    White,
    Gray,
    Black,
}

/// Walk an expression's AST and collect every identifier that names a
/// candidate variable (a variable declared with `on_demand_by:`).
///
/// Roots in the documented scope namespaces (`tool`, `endpoint`, `agent`,
/// `context`, `result`) and `@`-namespace metadata reads are excluded. Every
/// other root identifier (including the head of dotted accesses like
/// `approval.value`) is treated as a real variable reference, since at
/// runtime the root identifier auto-resolves before the dotted suffix
/// applies (§11.5).
///
/// Falls back to a conservative no-op on parse error: the cycle check is
/// fail-closed only for well-formed inputs. Other validators surface
/// expression-syntax errors.
fn collect_identifiers(
    expr: &str,
    candidates: &BTreeSet<&str>,
    self_name: &str,
    out: &mut BTreeSet<String>,
) {
    use crate::expressions::ast::Expr;

    fn is_scope_root(name: &str) -> bool {
        matches!(name, "tool" | "endpoint" | "agent" | "context" | "result")
    }

    fn record(
        name: &str,
        candidates: &BTreeSet<&str>,
        self_name: &str,
        out: &mut BTreeSet<String>,
    ) {
        if is_scope_root(name) {
            return;
        }
        if name == self_name {
            return;
        }
        if candidates.contains(name) {
            out.insert(name.to_string());
        }
    }

    fn walk(e: &Expr, candidates: &BTreeSet<&str>, self_name: &str, out: &mut BTreeSet<String>) {
        match e {
            Expr::Ident(name) => record(name, candidates, self_name, out),
            Expr::DottedAccess { root, .. } => {
                if let Expr::Ident(name) = root.as_ref() {
                    record(name, candidates, self_name, out);
                } else {
                    walk(root, candidates, self_name, out);
                }
            }
            Expr::BinaryOp { left, right, .. } => {
                walk(left, candidates, self_name, out);
                walk(right, candidates, self_name, out);
            }
            Expr::UnaryOp { operand, .. } => walk(operand, candidates, self_name, out),
            Expr::FnCall { args, .. } => {
                for a in args {
                    walk(a, candidates, self_name, out);
                }
            }
            Expr::Ternary {
                condition,
                then_expr,
                else_expr,
            } => {
                walk(condition, candidates, self_name, out);
                walk(then_expr, candidates, self_name, out);
                walk(else_expr, candidates, self_name, out);
            }
            Expr::List(items) => {
                for it in items {
                    walk(it, candidates, self_name, out);
                }
            }
            Expr::Index { object, index } => {
                walk(object, candidates, self_name, out);
                walk(index, candidates, self_name, out);
            }
            Expr::Assignment { value, .. } => walk(value, candidates, self_name, out),
            Expr::Quantifier {
                collection,
                var,
                predicate,
                ..
            } => {
                walk(collection, candidates, self_name, out);
                // The bound variable is scoped to the predicate; treat any
                // matching candidate name as shadowed within the predicate.
                if candidates.contains(var.as_str()) {
                    let mut shadowed: BTreeSet<&str> = candidates.clone();
                    shadowed.remove(var.as_str());
                    walk(predicate, &shadowed, self_name, out);
                } else {
                    walk(predicate, candidates, self_name, out);
                }
            }
            Expr::MetaField { var, .. } => record(var, candidates, self_name, out),
            Expr::Literal(_) => {}
        }
    }

    if let Ok(ast) = crate::expressions::parser::parse(expr) {
        walk(&ast, candidates, self_name, out);
    }
}

/// §1.3 / §11.10 / §12.3: every reference to a tool, agent, or
/// configuration must resolve to a declared resource at load time.
///
/// Endpoint patterns in `applies_to.endpoints[]` are first-class selectors
/// per §12.3 — they are NOT cross-checked against `resources.endpoints[]`.
fn validate_references(merged: &MergedConfig) -> Result<()> {
    use crate::resolver::Resolver;

    let tool_names: BTreeSet<&str> = merged
        .resources
        .tools
        .iter()
        .map(|t| t.name.as_str())
        .collect();
    let agent_names: BTreeSet<&str> = merged
        .resources
        .agents
        .iter()
        .map(|a| a.name.as_str())
        .collect();
    let configuration_ids: BTreeSet<&str> = merged
        .configurations
        .iter()
        .map(|c| c.id.as_str())
        .collect();

    let stages = [
        ("input_validation", &merged.input_validation.guard_policies),
        ("state_validation", &merged.state_validation.guard_policies),
        (
            "tool_execution_validation",
            &merged.tool_execution_validation.guard_policies,
        ),
        (
            "post_tool_validation",
            &merged.post_tool_validation.guard_policies,
        ),
        (
            "output_validation",
            &merged.output_validation.guard_policies,
        ),
    ];

    for (_stage, gps) in stages {
        for gp in gps {
            if let Some(applies) = &gp.applies_to {
                for t in &applies.tools {
                    if t == "*" {
                        continue;
                    }
                    if !tool_names.contains(t.as_str()) {
                        return Err(ConfigError::UnresolvedReference {
                            loc: SourceLoc::default(),
                            kind: "tool",
                            name: t.clone(),
                        });
                    }
                }
                for a in &applies.agents {
                    if a == "*" {
                        continue;
                    }
                    if !agent_names.contains(a.as_str()) {
                        return Err(ConfigError::UnresolvedReference {
                            loc: SourceLoc::default(),
                            kind: "agent",
                            name: a.clone(),
                        });
                    }
                }
                // endpoints[] are pattern selectors — not cross-checked.
            }
        }
    }

    for v in &merged.variables {
        if let Some(resolver) = &v.on_demand_by {
            for r in resolver.iter_chain() {
                match r {
                    Resolver::Tool { name, .. } => {
                        if !tool_names.contains(name.as_str()) {
                            return Err(ConfigError::UnresolvedReference {
                                loc: SourceLoc::default(),
                                kind: "tool",
                                name: name.clone(),
                            });
                        }
                    }
                    Resolver::Delegate { configuration, .. } => {
                        if !configuration_ids.contains(configuration.as_str()) {
                            return Err(ConfigError::UnresolvedReference {
                                loc: SourceLoc::default(),
                                kind: "configuration",
                                name: configuration.clone(),
                            });
                        }
                    }
                    Resolver::Expression { .. }
                    | Resolver::Human { .. }
                    | Resolver::Agent { .. } => {}
                }
            }
        }
    }

    Ok(())
}

/// §9.3: validate every `event.fired("…")` call argument against the
/// closed event-namespace registry. Walks every expression-bearing field
/// in the merged config (predicate bodies, guard policies, populators,
/// resolver expressions/contexts).
fn validate_event_fired_calls(merged: &MergedConfig) -> Result<()> {
    use crate::events::EventId;
    use crate::expressions::ast::{Expr, LitValue};
    use crate::resolver::Resolver;

    fn check_expr(expr: &str, location: &str) -> Result<()> {
        let ast = match crate::expressions::parser::parse(expr) {
            Ok(a) => a,
            Err(_) => return Ok(()),
        };
        walk(&ast, location)
    }

    fn walk(e: &Expr, location: &str) -> Result<()> {
        match e {
            Expr::FnCall { name, args } => {
                if name == "event.fired" {
                    if let Some(Expr::Literal(LitValue::Str(s))) = args.first() {
                        if EventId::parse(s).is_err() {
                            return Err(ConfigError::UnknownEventId {
                                id: s.clone(),
                                location: location.to_string(),
                            });
                        }
                    }
                }
                for a in args {
                    walk(a, location)?;
                }
                Ok(())
            }
            Expr::BinaryOp { left, right, .. } => {
                walk(left, location)?;
                walk(right, location)
            }
            Expr::UnaryOp { operand, .. } => walk(operand, location),
            Expr::Ternary {
                condition,
                then_expr,
                else_expr,
            } => {
                walk(condition, location)?;
                walk(then_expr, location)?;
                walk(else_expr, location)
            }
            Expr::List(items) => {
                for it in items {
                    walk(it, location)?;
                }
                Ok(())
            }
            Expr::Index { object, index } => {
                walk(object, location)?;
                walk(index, location)
            }
            Expr::Assignment { value, .. } => walk(value, location),
            Expr::DottedAccess { root, .. } => walk(root, location),
            Expr::Quantifier {
                collection,
                predicate,
                ..
            } => {
                walk(collection, location)?;
                walk(predicate, location)
            }
            Expr::MetaField { .. } | Expr::Ident(_) | Expr::Literal(_) => Ok(()),
        }
    }

    // Predicate bodies.
    for (name, entry) in &merged.predicates.entries {
        check_expr(&entry.body.expression, &format!("predicate `{}`", name))?;
    }

    // Stage guard policies.
    let stages = [
        ("input_validation", &merged.input_validation.guard_policies),
        ("state_validation", &merged.state_validation.guard_policies),
        (
            "tool_execution_validation",
            &merged.tool_execution_validation.guard_policies,
        ),
        (
            "post_tool_validation",
            &merged.post_tool_validation.guard_policies,
        ),
        (
            "output_validation",
            &merged.output_validation.guard_policies,
        ),
    ];
    for (stage, gps) in stages {
        for gp in gps {
            if let Some(active) = &gp.active_if {
                check_expr(active, &format!("{}/{}/active_if", stage, gp.name))?;
            }
            if let Some(allowed) = &gp.allowed_when {
                check_expr(allowed, &format!("{}/{}/allowed_when", stage, gp.name))?;
            }
            for (i, ew) in gp.evaluate_when.iter().enumerate() {
                if let crate::guard_policy::DetectionKind::Expression(e) = &ew.detection {
                    check_expr(
                        e,
                        &format!("{}/{}/evaluate_when[{}]/expression", stage, gp.name, i),
                    )?;
                }
            }
        }
    }

    // Variable populators / resolvers.
    for v in &merged.variables {
        for (i, p) in v.populated_by.iter().enumerate() {
            if let Some(e) = &p.expression {
                check_expr(
                    e,
                    &format!("variables/{}/populated_by[{}]/expression", v.name, i),
                )?;
            }
        }
        if let Some(resolver) = &v.on_demand_by {
            for (link_idx, r) in resolver.iter_chain().enumerate() {
                let label = format!("variables/{}/on_demand_by[{}]", v.name, link_idx);
                match r {
                    Resolver::Expression {
                        expression,
                        on_allow,
                        ..
                    } => {
                        check_expr(expression, &format!("{}/expression", label))?;
                        if let Some(map) = on_allow {
                            for (k, ex) in map {
                                check_expr(ex, &format!("{}/on_allow/{}", label, k))?;
                            }
                        }
                    }
                    Resolver::Tool {
                        context, on_allow, ..
                    }
                    | Resolver::Human {
                        context, on_allow, ..
                    }
                    | Resolver::Delegate {
                        context, on_allow, ..
                    }
                    | Resolver::Agent {
                        context, on_allow, ..
                    } => {
                        if let Some(map) = context {
                            for (k, ex) in map {
                                check_expr(ex, &format!("{}/context/{}", label, k))?;
                            }
                        }
                        if let Some(map) = on_allow {
                            for (k, ex) in map {
                                check_expr(ex, &format!("{}/on_allow/{}", label, k))?;
                            }
                        }
                    }
                }
            }
        }
    }

    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use sha2::Digest;
    use std::io::Write;

    fn write_temp(name: &str, body: &str) -> PathBuf {
        let dir = std::env::temp_dir().join("loader_tests");
        std::fs::create_dir_all(&dir).unwrap();
        let p = dir.join(name);
        let mut f = std::fs::File::create(&p).unwrap();
        f.write_all(body.as_bytes()).unwrap();
        p
    }

    #[test]
    fn loads_minimal_string_buffer() {
        let yaml = r#"
metadata:
  name: x
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal:
    - one
"#;
        let m = load_from_str(yaml).unwrap();
        assert_eq!(m.metadata.name, "x");
        assert_eq!(m.objective.tiers.len(), 1);
    }

    #[test]
    fn rejects_top_level_attributes_v1_block() {
        let yaml = r#"
metadata:
  name: x
  version: "0.1.0"
attributes:
  - name: x
"#;
        let err = load_from_str(yaml).unwrap_err().to_string();
        assert!(err.contains("attributes"));
    }

    #[test]
    fn rejects_camel_case_agent_shield_version() {
        let yaml = r#"
metadata:
  name: x
  version: "0.1.0"
  agentShieldVersion: "2.0"
"#;
        let err = load_from_str(yaml).unwrap_err().to_string();
        assert!(err.contains("agentShieldVersion"));
    }

    #[test]
    fn rejects_state_policies_v1_key() {
        let yaml = r#"
metadata:
  name: x
  version: "0.1.0"
state_validation:
  policies:
    - name: x
"#;
        let err = load_from_str(yaml).unwrap_err().to_string();
        assert!(err.contains("policies"));
    }

    #[test]
    fn rejects_validators_block() {
        let yaml = r#"
metadata:
  name: x
  version: "0.1.0"
input_validation:
  validators:
    - name: x
"#;
        let err = load_from_str(yaml).unwrap_err().to_string();
        assert!(err.contains("validators"));
    }

    #[test]
    fn rejects_incompatible_agent_shield_version() {
        let yaml = r#"
metadata:
  name: x
  version: "0.1.0"
  agent_shield_version: "1.0"
"#;
        let err = load_from_str(yaml).unwrap_err().to_string();
        // Cross-band rejection: 1.x policy is not satisfied by 2.x runtime.
        assert!(err.contains("1.0") || err.contains("not satisfied"));
    }

    #[test]
    fn predicate_detects_redefinition() {
        // Build two-file extends chain with same predicate name.
        let parent = write_temp(
            "redef-parent.guardrails.yaml",
            r#"
metadata:
  name: parent
  version: "0.1.0"
  agent_shield_version: "2.0"
predicates:
  is_admin: "x == 1"
"#,
        );
        let leaf_body = format!(
            r#"
extends:
  - "{}"
metadata:
  name: leaf
  version: "0.1.0"
  agent_shield_version: "2.0"
predicates:
  is_admin: "y == 2"
"#,
            parent.file_name().unwrap().to_string_lossy()
        );
        let leaf = write_temp("redef-leaf.guardrails.yaml", &leaf_body);
        let err = load_from_path(&leaf).unwrap_err();
        assert!(matches!(err, ConfigError::PredicateRedefinition { .. }));
    }

    #[test]
    fn detects_resolver_cycle() {
        // a → b (via human resolver context), b → a (via expression).
        let yaml = r#"
metadata:
  name: x
  version: "0.1.0"
  agent_shield_version: "2.0"
variables:
  - name: a
    type: boolean
    on_demand_by:
      kind: expression
      expression: "b"
  - name: b
    type: boolean
    on_demand_by:
      kind: human
      prompt: "approve"
      context:
        x: "a"
"#;
        let err = load_from_str(yaml).unwrap_err().to_string();
        assert!(err.contains("cycle") || err.contains("→"));
    }

    // ───────────────────────────────────────────────────────────────────
    // Review-amendment tests
    // ───────────────────────────────────────────────────────────────────

    /// P1.1: same-name variable redefinition across files is a load error.
    #[test]
    fn p1_1_duplicate_variable_across_extends_chain() {
        let parent = write_temp(
            "p1-1-parent.guardrails.yaml",
            r#"
metadata:
  name: parent
  version: "0.1.0"
  agent_shield_version: "2.0"
variables:
  - name: x
    type: boolean
"#,
        );
        let leaf_body = format!(
            r#"
extends:
  - "{}"
metadata:
  name: leaf
  version: "0.1.0"
  agent_shield_version: "2.0"
variables:
  - name: x
    type: string
"#,
            parent.file_name().unwrap().to_string_lossy()
        );
        let leaf = write_temp("p1-1-leaf.guardrails.yaml", &leaf_body);
        let err = load_from_path(&leaf).unwrap_err();
        assert!(
            matches!(err, ConfigError::DuplicateVariable { .. }),
            "expected DuplicateVariable, got {err:?}"
        );
    }

    /// P1.2: `load_from_str` runs the same per-stage shape validation
    /// as `load_from_path`. A state-stage policy lacking `applies_to:`
    /// is rejected by both loaders.
    #[test]
    fn p1_2_string_loader_runs_stage_validation() {
        let yaml = r#"
metadata:
  name: x
  version: "0.1.0"
  agent_shield_version: "2.0"
state_validation:
  guard_policies:
    - name: bad
      evaluate_when:
        - expression: "x == 1"
          reason: r
"#;
        let err = load_from_str(yaml).unwrap_err().to_string();
        assert!(err.contains("applies_to"), "got: {err}");
    }

    /// P1.3: `extends:` cycle is rejected via tri-color DFS.
    #[test]
    fn p1_3_extends_chain_cycle_rejected() {
        let dir = std::env::temp_dir().join("loader_tests_extends");
        std::fs::create_dir_all(&dir).unwrap();
        let a_path = dir.join("a.yaml");
        let b_path = dir.join("b.yaml");
        std::fs::write(
            &a_path,
            r#"
extends:
  - "b.yaml"
metadata:
  name: a
  version: "0.1.0"
  agent_shield_version: "2.0"
"#,
        )
        .unwrap();
        std::fs::write(
            &b_path,
            r#"
extends:
  - "a.yaml"
metadata:
  name: b
  version: "0.1.0"
  agent_shield_version: "2.0"
"#,
        )
        .unwrap();
        let err = load_from_path(&a_path).unwrap_err();
        let msg = err.to_string();
        assert!(
            matches!(err, ConfigError::ExtendsCycle { .. }),
            "expected ExtendsCycle, got {err:?}"
        );
        assert!(msg.contains("a.yaml") && msg.contains("b.yaml"), "{msg}");
    }

    /// P1.4: cycle detection follows the head of dotted access.
    #[test]
    fn p1_4_resolver_cycle_through_dotted_access() {
        let yaml = r#"
metadata:
  name: x
  version: "0.1.0"
  agent_shield_version: "2.0"
variables:
  - name: a
    type: object
    on_demand_by:
      kind: expression
      expression: "b.value"
  - name: b
    type: object
    on_demand_by:
      kind: expression
      expression: "a.value"
"#;
        let err = load_from_str(yaml).unwrap_err();
        assert!(
            matches!(err, ConfigError::ResolverCycle { .. }),
            "got {err:?}"
        );
    }

    /// P1.5: `applies_to.tools` references a tool not declared in resources.
    #[test]
    fn p1_5_applies_to_unknown_tool_rejected() {
        let yaml = r#"
metadata:
  name: x
  version: "0.1.0"
  agent_shield_version: "2.0"
resources:
  tools:
    - name: known_tool
state_validation:
  guard_policies:
    - name: gp
      applies_to:
        tools: [unknown_tool]
      evaluate_when:
        - expression: "x"
          reason: r
"#;
        let err = load_from_str(yaml).unwrap_err();
        assert!(
            matches!(&err, ConfigError::UnresolvedReference { kind: "tool", name, .. } if name == "unknown_tool"),
            "got {err:?}"
        );
    }

    /// P1.5: wildcard `*` in `applies_to.tools` is accepted.
    #[test]
    fn p1_5_applies_to_wildcard_accepted() {
        let yaml = r#"
metadata:
  name: x
  version: "0.1.0"
  agent_shield_version: "2.0"
state_validation:
  guard_policies:
    - name: gp
      applies_to:
        tools: ["*"]
      evaluate_when:
        - expression: "x"
          reason: r
"#;
        let _m = load_from_str(yaml).unwrap();
    }

    /// P1.5: `applies_to.agents` referencing an undeclared agent.
    #[test]
    fn p1_5_applies_to_unknown_agent_rejected() {
        let yaml = r#"
metadata:
  name: x
  version: "0.1.0"
  agent_shield_version: "2.0"
state_validation:
  guard_policies:
    - name: gp
      applies_to:
        agents: [ghost]
      evaluate_when:
        - expression: "x"
          reason: r
"#;
        let err = load_from_str(yaml).unwrap_err();
        assert!(
            matches!(&err, ConfigError::UnresolvedReference { kind: "agent", name, .. } if name == "ghost"),
            "got {err:?}"
        );
    }

    /// P1.5: `kind: tool` resolver with unknown tool name.
    #[test]
    fn p1_5_tool_resolver_unknown_name_rejected() {
        let yaml = r#"
metadata:
  name: x
  version: "0.1.0"
  agent_shield_version: "2.0"
variables:
  - name: x
    type: boolean
    on_demand_by:
      kind: tool
      name: nope
"#;
        let err = load_from_str(yaml).unwrap_err();
        assert!(
            matches!(&err, ConfigError::UnresolvedReference { kind: "tool", name, .. } if name == "nope"),
            "got {err:?}"
        );
    }

    /// P1.5: `kind: delegate` with unknown configuration id.
    #[test]
    fn p1_5_delegate_resolver_unknown_configuration_rejected() {
        let yaml = r#"
metadata:
  name: x
  version: "0.1.0"
  agent_shield_version: "2.0"
variables:
  - name: x
    type: boolean
    on_demand_by:
      kind: delegate
      configuration: missing_cfg
"#;
        let err = load_from_str(yaml).unwrap_err();
        assert!(
            matches!(&err, ConfigError::UnresolvedReference { kind: "configuration", name, .. } if name == "missing_cfg"),
            "got {err:?}"
        );
    }

    /// P1.10: `event.fired()` argument validated against the closed
    /// event-namespace at load time.
    #[test]
    fn p1_10_unknown_event_in_active_if_rejected() {
        let yaml = r#"
metadata:
  name: x
  version: "0.1.0"
  agent_shield_version: "2.0"
state_validation:
  guard_policies:
    - name: gp
      applies_to:
        tools: ["*"]
      active_if: "event.fired('not_a_real_event')"
      evaluate_when:
        - expression: "x"
          reason: r
"#;
        let err = load_from_str(yaml).unwrap_err();
        assert!(
            matches!(&err, ConfigError::UnknownEventId { id, .. } if id == "not_a_real_event"),
            "got {err:?}"
        );
    }

    /// P1.10: a valid event identifier passes.
    #[test]
    fn p1_10_known_event_in_active_if_accepted() {
        let yaml = r#"
metadata:
  name: x
  version: "0.1.0"
  agent_shield_version: "2.0"
state_validation:
  guard_policies:
    - name: gp
      applies_to:
        tools: ["*"]
      active_if: "event.fired('session.start')"
      evaluate_when:
        - expression: "x"
          reason: r
"#;
        let _m = load_from_str(yaml).unwrap();
    }

    // ── URL `extends:` tests (§3.2) ─────────────────────────────────────

    /// A bare string starting with `https://` is rejected with the
    /// integrity-required hint — fail-closed: remote bytes must be pinned.
    #[test]
    fn p2_1_bare_https_string_rejected() {
        let yaml = r#"
extends:
  - "https://example.com/base.yaml"
metadata:
  name: x
  version: "0.1.0"
  agent_shield_version: "2.0"
"#;
        let dir = std::env::temp_dir().join("loader_url_tests_bare_https");
        std::fs::create_dir_all(&dir).unwrap();
        let p = dir.join("leaf.yaml");
        std::fs::write(&p, yaml).unwrap();
        let err = load_from_path(&p).unwrap_err();
        assert!(
            matches!(err, ConfigError::UrlExtendsRequiresIntegrity { .. }),
            "got {err:?}"
        );
    }

    /// `http://` (plain TCP) is rejected — TLS required.
    #[test]
    fn p2_2_http_scheme_rejected() {
        let yaml = r#"
extends:
  - url: "http://example.com/base.yaml"
    integrity: "sha256-47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU="
metadata:
  name: x
  version: "0.1.0"
  agent_shield_version: "2.0"
"#;
        // load_from_str rejects any extends entries up front — exercise the
        // resolver via a path-based load. Build a tmp file that extends a
        // bad URL.
        let dir = std::env::temp_dir().join("loader_url_tests_http");
        std::fs::create_dir_all(&dir).unwrap();
        let p = dir.join("leaf.yaml");
        std::fs::write(&p, yaml).unwrap();
        let err = load_from_path(&p).unwrap_err();
        assert!(
            matches!(err, ConfigError::UrlExtendsBadScheme { .. }),
            "got {err:?}"
        );
    }

    /// URL with userinfo or fragment is rejected.
    #[test]
    fn p2_3_url_credentials_or_fragment_rejected() {
        for url in [
            "https://user:pass@example.com/base.yaml",
            "https://example.com/base.yaml#frag",
        ] {
            let yaml = format!(
                r#"
extends:
  - url: "{url}"
    integrity: "sha256-47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU="
metadata:
  name: x
  version: "0.1.0"
  agent_shield_version: "2.0"
"#
            );
            let dir = std::env::temp_dir().join("loader_url_tests_components");
            std::fs::create_dir_all(&dir).unwrap();
            let p = dir.join("leaf.yaml");
            std::fs::write(&p, &yaml).unwrap();
            let err = load_from_path(&p).unwrap_err();
            assert!(
                matches!(err, ConfigError::UrlExtendsForbiddenComponents { .. }),
                "url={url} got {err:?}"
            );
        }
    }

    /// Malformed integrity literals are rejected at load time.
    #[test]
    fn p2_4_bad_integrity_format_rejected() {
        for bad in [
            "sha256:0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef", // hex form is NOT accepted (must be SRI sha256-<base64>)
            "md5-abc",       // wrong algorithm
            "sha256-shorty", // bad base64
            "sha256-",       // empty
        ] {
            let yaml = format!(
                r#"
extends:
  - url: "https://example.com/base.yaml"
    integrity: "{bad}"
metadata:
  name: x
  version: "0.1.0"
  agent_shield_version: "2.0"
"#
            );
            let dir = std::env::temp_dir().join("loader_url_tests_integrity");
            std::fs::create_dir_all(&dir).unwrap();
            let p = dir.join("leaf.yaml");
            std::fs::write(&p, &yaml).unwrap();
            let err = load_from_path(&p).unwrap_err();
            assert!(
                matches!(err, ConfigError::UrlExtendsBadIntegrity { .. }),
                "integrity={bad} got {err:?}"
            );
        }
    }

    /// A relative `url:` in a local file has no remote parent to resolve
    /// against — load-time error.
    #[test]
    fn p2_5_relative_url_in_local_file_rejected() {
        let yaml = r#"
extends:
  - url: "./common.yaml"
    integrity: "sha256-47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU="
metadata:
  name: x
  version: "0.1.0"
  agent_shield_version: "2.0"
"#;
        let dir = std::env::temp_dir().join("loader_url_tests_relative");
        std::fs::create_dir_all(&dir).unwrap();
        let p = dir.join("leaf.yaml");
        std::fs::write(&p, yaml).unwrap();
        let err = load_from_path(&p).unwrap_err();
        assert!(
            matches!(err, ConfigError::RelativeUrlNeedsRemoteParent { .. }),
            "got {err:?}"
        );
    }

    /// Cache hit with a declared integrity that disagrees with the
    /// cached actual integrity must fail closed — a sibling cannot
    /// silently widen the trust boundary by re-declaring the same URL
    /// with a different pin. The cache is pre-populated here to
    /// exercise the conflict path without a network fetch.
    #[test]
    fn p2_6_integrity_conflict_on_cached_url_fails_closed() {
        use base64::Engine;
        let url = "https://example.com/common.yaml".to_string();
        let cached_integrity = format!(
            "sha256-{}",
            base64::engine::general_purpose::STANDARD.encode([0u8; 32])
        );
        let lying_integrity = format!(
            "sha256-{}",
            base64::engine::general_purpose::STANDARD.encode([0x42u8; 32])
        );
        let mut remote = RemoteCtx::default();
        remote.cache.insert(
            url.clone(),
            FetchedRemote {
                body:
                    "metadata:\n  name: c\n  version: \"0.1.0\"\n  agent_shield_version: \"2.0\"\n"
                        .to_string(),
                actual_integrity: cached_integrity.clone(),
            },
        );

        let err = fetch_remote(
            &url,
            Some(&lying_integrity),
            &mut remote,
            &SourceLoc::default(),
        )
        .unwrap_err();
        assert!(
            matches!(&err, ConfigError::IntegrityMismatch { url: u, .. } if u == "https://example.com/common.yaml"),
            "got {err:?}"
        );
    }

    /// Cache hit with matching integrity returns the cached body
    /// without re-fetching.
    #[test]
    fn p2_7_cache_hit_with_matching_integrity_returns_body() {
        use base64::Engine;
        let url = "https://example.com/common.yaml".to_string();
        let body = "metadata:\n  name: c\n".to_string();
        let cached_integrity = format!(
            "sha256-{}",
            base64::engine::general_purpose::STANDARD.encode([0u8; 32])
        );
        let mut remote = RemoteCtx::default();
        remote.cache.insert(
            url.clone(),
            FetchedRemote {
                body: body.clone(),
                actual_integrity: cached_integrity.clone(),
            },
        );
        let out = fetch_remote(
            &url,
            Some(&cached_integrity),
            &mut remote,
            &SourceLoc::default(),
        )
        .unwrap();
        assert_eq!(out, body);
        // Crucial: no network fetch happened, so the fetch counter stays 0.
        assert_eq!(remote.fetch_count, 0);
    }

    /// SRI parser accepts URL-safe and standard base64; canonicalises to
    /// standard form so downstream string comparison works regardless of
    /// the writer's encoding choice.
    #[test]
    fn p2_8_integrity_parser_canonicalises_base64() {
        use base64::Engine;
        let loc = SourceLoc::default();
        let zeros_std = format!(
            "sha256-{}",
            base64::engine::general_purpose::STANDARD.encode([0u8; 32])
        );
        let zeros_url_safe = format!(
            "sha256-{}",
            base64::engine::general_purpose::URL_SAFE_NO_PAD.encode([0u8; 32])
        );
        let canonical = parse_integrity(&zeros_std, &loc).unwrap();
        let canonical_url = parse_integrity(&zeros_url_safe, &loc).unwrap();
        assert_eq!(canonical, canonical_url);
    }

    /// Integrity with a digest of the wrong length is rejected (e.g.,
    /// SHA-1 encoded as `sha256-…`).
    #[test]
    fn p2_9_integrity_wrong_digest_length_rejected() {
        use base64::Engine;
        let loc = SourceLoc::default();
        // 20 zero bytes = SHA-1 length; the `sha256-` prefix lies about it.
        let twenty = format!(
            "sha256-{}",
            base64::engine::general_purpose::STANDARD.encode([0u8; 20])
        );
        let err = parse_integrity(&twenty, &loc).unwrap_err();
        assert!(
            matches!(err, ConfigError::UrlExtendsBadIntegrity { .. }),
            "got {err:?}"
        );
    }

    /// Validate that `resolve_url_string` correctly applies RFC 3986
    /// reference resolution when the parent is itself remote — relative
    /// `extends:` URLs inside a fetched file resolve to absolute URLs on
    /// the same host/path.
    #[test]
    fn p2_10_relative_url_resolves_against_remote_parent() {
        let parent = NodeKey::Url("https://example.com/policies/leaf.yaml".to_string());
        let loc = SourceLoc::default();
        let abs = resolve_url_string("./common.yaml", &parent, &loc).unwrap();
        assert_eq!(abs, "https://example.com/policies/common.yaml");
        let up = resolve_url_string("../shared/base.yaml", &parent, &loc).unwrap();
        assert_eq!(up, "https://example.com/shared/base.yaml");
        let abs_form = resolve_url_string("https://other.example/x.yaml", &parent, &loc).unwrap();
        assert_eq!(abs_form, "https://other.example/x.yaml");
    }

    /// A bare-string entry inside a remote file is rejected — would
    /// have no integrity and would silently widen the trust boundary.
    /// Exercised by pre-populating the remote cache with a parent that
    /// declares a bare-string child and letting `walk_extends` recurse.
    #[test]
    fn p2_11_bare_string_in_remote_file_rejected() {
        let url = "https://example.com/parent.yaml".to_string();
        let yaml = r#"
extends:
  - "./common.yaml"
metadata:
  name: parent
  version: "0.1.0"
  agent_shield_version: "2.0"
"#;
        let mut hasher = sha2::Sha256::new();
        sha2::Digest::update(&mut hasher, yaml.as_bytes());
        let actual = {
            use base64::Engine;
            format!(
                "sha256-{}",
                base64::engine::general_purpose::STANDARD.encode(sha2::Digest::finalize(hasher))
            )
        };

        let mut remote = RemoteCtx::default();
        remote.cache.insert(
            url.clone(),
            FetchedRemote {
                body: yaml.to_string(),
                actual_integrity: actual.clone(),
            },
        );

        // Construct a local file that points at the cached URL.
        let dir = std::env::temp_dir().join("loader_url_tests_bare_in_remote");
        std::fs::create_dir_all(&dir).unwrap();
        let leaf_path = dir.join("leaf.yaml");
        std::fs::write(
            &leaf_path,
            format!(
                r#"
extends:
  - url: "{url}"
    integrity: "{actual}"
metadata:
  name: leaf
  version: "0.1.0"
  agent_shield_version: "2.0"
"#
            ),
        )
        .unwrap();

        // Drive walk_extends with the pre-populated cache so we don't hit
        // the network. We simulate `load_from_path` but pass our cache.
        let canonical = canonicalize(&leaf_path).unwrap();
        let node = NodeKey::Path(canonical);
        let mut visited = HashMap::new();
        let mut in_progress = BTreeSet::new();
        let mut stack = Vec::new();
        let mut order = Vec::new();
        let mut wires = HashMap::new();
        let err = walk_extends(
            &node,
            0,
            &mut visited,
            &mut in_progress,
            &mut stack,
            &mut order,
            &mut wires,
            &mut remote,
        )
        .unwrap_err();
        assert!(
            matches!(err, ConfigError::UrlExtendsRequiresIntegrity { .. }),
            "got {err:?}"
        );
    }

    /// §12.9.2: `prompt_path:` in a YAML fetched over a remote
    /// `extends:` URL must be rejected with
    /// `PromptFileErrorKind::RemoteNotSupported`. Integrity for remote
    /// prompt files needs its own SRI story; out of scope for this spec
    /// revision. Pre-populates the remote cache so we don't hit the
    /// network.
    #[test]
    #[allow(non_snake_case)]
    fn prompt_path_in_remote_extends_yaml_is_RemoteNotSupported() {
        let url = "https://example.com/base.guardrails.yaml".to_string();
        let remote_yaml = r#"metadata:
  name: remote-base
  version: "1.0.0"
  agent_shield_version: "2.0"

input_validation:
  guard_policies:
    - name: jb
      evaluate_when:
        - llm:
            prompt_path: should-be-rejected.md
          reason: "rejected"
"#;
        let mut hasher = sha2::Sha256::new();
        sha2::Digest::update(&mut hasher, remote_yaml.as_bytes());
        let actual = {
            use base64::Engine;
            format!(
                "sha256-{}",
                base64::engine::general_purpose::STANDARD.encode(sha2::Digest::finalize(hasher))
            )
        };

        let mut remote = RemoteCtx::default();
        remote.cache.insert(
            url.clone(),
            FetchedRemote {
                body: remote_yaml.to_string(),
                actual_integrity: actual.clone(),
            },
        );

        let dir = std::env::temp_dir().join("loader_prompt_path_remote_test");
        std::fs::create_dir_all(&dir).unwrap();
        let leaf_path = dir.join("leaf.guardrails.yaml");
        std::fs::write(
            &leaf_path,
            format!(
                r#"metadata:
  name: leaf
  version: "1.0.0"
  agent_shield_version: "2.0"
extends:
  - url: "{url}"
    integrity: "{actual}"
"#
            ),
        )
        .unwrap();

        let canonical = canonicalize(&leaf_path).unwrap();
        let node = NodeKey::Path(canonical);
        let mut visited = HashMap::new();
        let mut in_progress = BTreeSet::new();
        let mut stack = Vec::new();
        let mut order = Vec::new();
        let mut wires = HashMap::new();
        let err = walk_extends(
            &node,
            0,
            &mut visited,
            &mut in_progress,
            &mut stack,
            &mut order,
            &mut wires,
            &mut remote,
        )
        .unwrap_err();
        assert!(
            matches!(
                err,
                ConfigError::PromptFile {
                    kind: PromptFileErrorKind::RemoteNotSupported,
                    ..
                }
            ),
            "got {err:?}"
        );
    }

    /// Diamond load through the same URL with consistent integrity works
    /// and only stores one copy in the merge order. The second declaration
    /// short-circuits via the visited set after integrity re-verification.
    #[test]
    fn p2_12_diamond_url_load_dedupes_with_matching_integrity() {
        let url = "https://example.com/common.yaml".to_string();
        let yaml = r#"
metadata:
  name: common
  version: "0.1.0"
  agent_shield_version: "2.0"
"#;
        let mut hasher = sha2::Sha256::new();
        sha2::Digest::update(&mut hasher, yaml.as_bytes());
        let actual = {
            use base64::Engine;
            format!(
                "sha256-{}",
                base64::engine::general_purpose::STANDARD.encode(sha2::Digest::finalize(hasher))
            )
        };

        // Two parents both declaring the same URL with the same integrity.
        let dir = std::env::temp_dir().join("loader_url_tests_diamond");
        std::fs::create_dir_all(&dir).unwrap();
        for n in ["a.yaml", "b.yaml"] {
            std::fs::write(
                dir.join(n),
                format!(
                    r#"
extends:
  - url: "{url}"
    integrity: "{actual}"
metadata:
  name: parent_{}
  version: "0.1.0"
  agent_shield_version: "2.0"
"#,
                    n.trim_end_matches(".yaml")
                ),
            )
            .unwrap();
        }
        let leaf = dir.join("leaf.yaml");
        std::fs::write(
            &leaf,
            r#"
extends:
  - "a.yaml"
  - "b.yaml"
metadata:
  name: leaf
  version: "0.1.0"
  agent_shield_version: "2.0"
"#,
        )
        .unwrap();

        // Pre-populate the cache (avoids real network).
        let mut remote = RemoteCtx::default();
        remote.cache.insert(
            url.clone(),
            FetchedRemote {
                body: yaml.to_string(),
                actual_integrity: actual.clone(),
            },
        );

        let canonical = canonicalize(&leaf).unwrap();
        let node = NodeKey::Path(canonical);
        let mut visited = HashMap::new();
        let mut in_progress = BTreeSet::new();
        let mut stack = Vec::new();
        let mut order = Vec::new();
        let mut wires = HashMap::new();
        walk_extends(
            &node,
            0,
            &mut visited,
            &mut in_progress,
            &mut stack,
            &mut order,
            &mut wires,
            &mut remote,
        )
        .unwrap();

        // The url node appears exactly once in the merge order.
        let url_count = order
            .iter()
            .filter(|n| matches!(n, NodeKey::Url(u) if u == &url))
            .count();
        assert_eq!(url_count, 1, "diamond load should dedupe URL nodes");
    }

    /// Two declarations of the same URL with **different** integrity
    /// values fail closed via `IntegrityConflict` even on the second
    /// (cache-hit) declaration.
    #[test]
    fn p2_13_diamond_url_load_rejects_conflicting_integrity() {
        let url = "https://example.com/common.yaml".to_string();
        let body = "metadata:\n  name: c\n  version: \"0.1.0\"\n  agent_shield_version: \"2.0\"\n";
        let mut hasher = sha2::Sha256::new();
        sha2::Digest::update(&mut hasher, body.as_bytes());
        let real_integrity = {
            use base64::Engine;
            format!(
                "sha256-{}",
                base64::engine::general_purpose::STANDARD.encode(sha2::Digest::finalize(hasher))
            )
        };
        let lying_integrity = {
            use base64::Engine;
            format!(
                "sha256-{}",
                base64::engine::general_purpose::STANDARD.encode([0x42u8; 32])
            )
        };

        let dir = std::env::temp_dir().join("loader_url_tests_conflict");
        std::fs::create_dir_all(&dir).unwrap();
        let a = dir.join("a.yaml");
        let b = dir.join("b.yaml");
        std::fs::write(
            &a,
            format!(
                r#"
extends:
  - url: "{url}"
    integrity: "{real_integrity}"
metadata:
  name: a
  version: "0.1.0"
  agent_shield_version: "2.0"
"#
            ),
        )
        .unwrap();
        std::fs::write(
            &b,
            format!(
                r#"
extends:
  - url: "{url}"
    integrity: "{lying_integrity}"
metadata:
  name: b
  version: "0.1.0"
  agent_shield_version: "2.0"
"#
            ),
        )
        .unwrap();
        let leaf = dir.join("leaf.yaml");
        std::fs::write(
            &leaf,
            r#"
extends:
  - "a.yaml"
  - "b.yaml"
metadata:
  name: leaf
  version: "0.1.0"
  agent_shield_version: "2.0"
"#,
        )
        .unwrap();

        let mut remote = RemoteCtx::default();
        remote.cache.insert(
            url.clone(),
            FetchedRemote {
                body: body.to_string(),
                actual_integrity: real_integrity.clone(),
            },
        );

        let canonical = canonicalize(&leaf).unwrap();
        let node = NodeKey::Path(canonical);
        let mut visited = HashMap::new();
        let mut in_progress = BTreeSet::new();
        let mut stack = Vec::new();
        let mut order = Vec::new();
        let mut wires = HashMap::new();
        let err = walk_extends(
            &node,
            0,
            &mut visited,
            &mut in_progress,
            &mut stack,
            &mut order,
            &mut wires,
            &mut remote,
        )
        .unwrap_err();
        assert!(
            matches!(err, ConfigError::IntegrityConflict { .. }),
            "got {err:?}"
        );
    }

    /// A remote file may itself `extends:` another remote URL (transitive
    /// remote chain) — bytes are pinned at every hop. Exercised via the
    /// pre-populated cache.
    #[test]
    fn p2_14_transitive_remote_extends_works() {
        let grandparent_url = "https://example.com/base.yaml".to_string();
        let parent_url = "https://example.com/middle.yaml".to_string();

        let grandparent_yaml = r#"
metadata:
  name: grandparent
  version: "0.1.0"
  agent_shield_version: "2.0"
"#;
        let mut hasher = sha2::Sha256::new();
        sha2::Digest::update(&mut hasher, grandparent_yaml.as_bytes());
        let grandparent_integrity = {
            use base64::Engine;
            format!(
                "sha256-{}",
                base64::engine::general_purpose::STANDARD.encode(sha2::Digest::finalize(hasher))
            )
        };

        let parent_yaml = format!(
            r#"
extends:
  - url: "{grandparent_url}"
    integrity: "{grandparent_integrity}"
metadata:
  name: parent
  version: "0.1.0"
  agent_shield_version: "2.0"
"#
        );
        let mut hasher2 = sha2::Sha256::new();
        sha2::Digest::update(&mut hasher2, parent_yaml.as_bytes());
        let parent_integrity = {
            use base64::Engine;
            format!(
                "sha256-{}",
                base64::engine::general_purpose::STANDARD.encode(sha2::Digest::finalize(hasher2))
            )
        };

        let mut remote = RemoteCtx::default();
        remote.cache.insert(
            grandparent_url.clone(),
            FetchedRemote {
                body: grandparent_yaml.to_string(),
                actual_integrity: grandparent_integrity.clone(),
            },
        );
        remote.cache.insert(
            parent_url.clone(),
            FetchedRemote {
                body: parent_yaml.clone(),
                actual_integrity: parent_integrity.clone(),
            },
        );

        let dir = std::env::temp_dir().join("loader_url_tests_transitive");
        std::fs::create_dir_all(&dir).unwrap();
        let leaf = dir.join("leaf.yaml");
        std::fs::write(
            &leaf,
            format!(
                r#"
extends:
  - url: "{parent_url}"
    integrity: "{parent_integrity}"
metadata:
  name: leaf
  version: "0.1.0"
  agent_shield_version: "2.0"
"#
            ),
        )
        .unwrap();

        let canonical = canonicalize(&leaf).unwrap();
        let node = NodeKey::Path(canonical);
        let mut visited = HashMap::new();
        let mut in_progress = BTreeSet::new();
        let mut stack = Vec::new();
        let mut order = Vec::new();
        let mut wires = HashMap::new();
        walk_extends(
            &node,
            0,
            &mut visited,
            &mut in_progress,
            &mut stack,
            &mut order,
            &mut wires,
            &mut remote,
        )
        .unwrap();
        assert_eq!(order.len(), 3, "expected grandparent → parent → leaf");
        assert!(matches!(&order[0], NodeKey::Url(u) if u == &grandparent_url));
        assert!(matches!(&order[1], NodeKey::Url(u) if u == &parent_url));
        assert!(matches!(&order[2], NodeKey::Path(_)));
    }

    /// Local path canonicalisation regression: `./parent.yaml` and
    /// `parent.yaml` reach the same file. Without canonicalisation in
    /// `resolve_child`, the loader would visit the same on-disk file
    /// twice (or fail to detect a cycle if they participate in one).
    /// We verify dedupe via two leaves whose `extends:` use different
    /// spellings of the same parent.
    #[test]
    fn p2_15_local_path_canonicalisation_dedupes_alternate_spellings() {
        let dir = std::env::temp_dir().join("loader_url_tests_canon");
        std::fs::create_dir_all(&dir).unwrap();
        std::fs::write(
            dir.join("common.yaml"),
            r#"
metadata:
  name: common
  version: "0.1.0"
  agent_shield_version: "2.0"
"#,
        )
        .unwrap();
        std::fs::write(
            dir.join("a.yaml"),
            r#"
extends:
  - "common.yaml"
metadata:
  name: a
  version: "0.1.0"
  agent_shield_version: "2.0"
"#,
        )
        .unwrap();
        std::fs::write(
            dir.join("b.yaml"),
            r#"
extends:
  - "./common.yaml"
metadata:
  name: b
  version: "0.1.0"
  agent_shield_version: "2.0"
"#,
        )
        .unwrap();
        let leaf = dir.join("leaf.yaml");
        std::fs::write(
            &leaf,
            r#"
extends:
  - "a.yaml"
  - "b.yaml"
metadata:
  name: leaf
  version: "0.1.0"
  agent_shield_version: "2.0"
"#,
        )
        .unwrap();

        let canonical = canonicalize(&leaf).unwrap();
        let node = NodeKey::Path(canonical);
        let mut visited = HashMap::new();
        let mut in_progress = BTreeSet::new();
        let mut stack = Vec::new();
        let mut order = Vec::new();
        let mut wires = HashMap::new();
        let mut remote = RemoteCtx::default();
        walk_extends(
            &node,
            0,
            &mut visited,
            &mut in_progress,
            &mut stack,
            &mut order,
            &mut wires,
            &mut remote,
        )
        .unwrap();

        // common.yaml must appear exactly once in the merge order even
        // though it's reached through two alternate spellings.
        let common_count = order
            .iter()
            .filter(|n| match n {
                NodeKey::Path(p) => p.file_name().and_then(|s| s.to_str()) == Some("common.yaml"),
                _ => false,
            })
            .count();
        assert_eq!(
            common_count, 1,
            "alternate spellings must canonicalise to the same NodeKey"
        );
    }

    /// `MAX_REMOTE_FETCHES` cap: after the budget is exhausted, the
    /// next un-cached URL must fail closed with
    /// `RemoteFetchCountBudgetExceeded` BEFORE the runtime opens a socket.
    #[test]
    fn p2_16_remote_fetch_count_budget_exceeded() {
        // Simulate the budget being already consumed by prior siblings.
        let mut remote = RemoteCtx {
            fetch_count: MAX_REMOTE_FETCHES,
            ..Default::default()
        };
        // An URL that is NOT in the cache forces fetch_remote past the
        // cache-hit short-circuit into the budget check.
        let url = "https://example.com/no-cache.yaml";
        // A well-formed declared integrity is fine — the budget check
        // sits before any integrity work.
        use base64::Engine;
        let declared = format!(
            "sha256-{}",
            base64::engine::general_purpose::STANDARD.encode([0u8; 32])
        );
        let err =
            fetch_remote(url, Some(&declared), &mut remote, &SourceLoc::default()).unwrap_err();
        assert!(
            matches!(err, ConfigError::RemoteFetchCountBudgetExceeded { .. }),
            "got {err:?}"
        );
        // Crucially: no socket was opened, so the byte counter must not
        // have advanced.
        assert_eq!(remote.bytes_total, 0);
    }

    /// `MAX_REMOTE_TOTAL_BYTES` cap, pre-fetch guard arm: if a prior
    /// `read_to_end` produced bytes that would push us past the
    /// cumulative budget, `verify_and_cache_body` rejects them with
    /// `RemoteBytesBudgetExceeded` and leaves the counters untouched.
    /// This exercises the post-read arithmetic without opening a
    /// socket.
    #[test]
    fn p2_17_verify_body_rejects_over_cumulative_budget() {
        // Saturate the cumulative-bytes budget; the next body of any
        // non-zero length must trip `body.len() > remaining_total`.
        let mut remote = RemoteCtx {
            bytes_total: MAX_REMOTE_TOTAL_BYTES,
            ..Default::default()
        };
        let body = b"metadata: { name: x }\n".to_vec();
        use base64::Engine;
        let declared = format!(
            "sha256-{}",
            base64::engine::general_purpose::STANDARD.encode([0u8; 32])
        );
        let url = "https://example.com/over-budget.yaml";
        let before = (remote.fetch_count, remote.bytes_total, remote.cache.len());
        let err = verify_and_cache_body(url, Some(&declared), body, &mut remote).unwrap_err();
        assert!(
            matches!(err, ConfigError::RemoteBytesBudgetExceeded { .. }),
            "got {err:?}"
        );
        assert_eq!(
            (remote.fetch_count, remote.bytes_total, remote.cache.len()),
            before,
            "failed verification must not advance any counter or insert into the cache"
        );
    }

    /// Body strictly larger than `MAX_REMOTE_BODY_BYTES` is rejected
    /// with `RemoteBodyTooLarge` regardless of cumulative-budget state.
    #[test]
    fn p2_19_verify_body_rejects_over_per_body_cap() {
        let mut remote = RemoteCtx::default();
        let body = vec![0u8; MAX_REMOTE_BODY_BYTES + 1];
        use base64::Engine;
        let declared = format!(
            "sha256-{}",
            base64::engine::general_purpose::STANDARD.encode([0u8; 32])
        );
        let url = "https://example.com/too-big.yaml";
        let err = verify_and_cache_body(url, Some(&declared), body, &mut remote).unwrap_err();
        assert!(
            matches!(err, ConfigError::RemoteBodyTooLarge { .. }),
            "got {err:?}"
        );
        assert_eq!(remote.fetch_count, 0);
        assert_eq!(remote.bytes_total, 0);
    }

    /// Mismatched integrity on a freshly-fetched (uncached) body must
    /// fail with `IntegrityMismatch` and the cache must remain empty.
    #[test]
    fn p2_20_verify_body_rejects_integrity_mismatch_on_fresh_fetch() {
        let mut remote = RemoteCtx::default();
        let body = b"hello world".to_vec();
        // Wrong declared integrity (digest of 32 zeros, not "hello world").
        use base64::Engine;
        let declared = format!(
            "sha256-{}",
            base64::engine::general_purpose::STANDARD.encode([0u8; 32])
        );
        let url = "https://example.com/mismatch.yaml";
        let err = verify_and_cache_body(url, Some(&declared), body, &mut remote).unwrap_err();
        assert!(
            matches!(&err, ConfigError::IntegrityMismatch { url: u, .. } if u == "https://example.com/mismatch.yaml"),
            "got {err:?}"
        );
        assert!(remote.cache.is_empty());
        assert_eq!(remote.fetch_count, 0);
    }

    /// Bytes that pass the integrity check but are not valid UTF-8
    /// fail closed with a clear message.
    #[test]
    fn p2_21_verify_body_rejects_invalid_utf8() {
        let mut remote = RemoteCtx::default();
        // 32 bytes of 0xff: valid SHA-256 input, but invalid UTF-8.
        let body = vec![0xffu8; 32];
        use base64::Engine;
        let mut hasher = sha2::Sha256::new();
        Digest::update(&mut hasher, &body);
        let declared = format!(
            "sha256-{}",
            base64::engine::general_purpose::STANDARD.encode(Digest::finalize(hasher))
        );
        let url = "https://example.com/invalid-utf8.yaml";
        let err = verify_and_cache_body(url, Some(&declared), body, &mut remote).unwrap_err();
        assert!(
            matches!(&err, ConfigError::RemoteFetch { message, .. } if message.contains("UTF-8")),
            "got {err:?}"
        );
        // Counters untouched on failure.
        assert!(remote.cache.is_empty());
        assert_eq!(remote.fetch_count, 0);
    }

    /// Happy path through `verify_and_cache_body`: matching integrity
    /// caches the body, advances the per-load counters, and returns
    /// the decoded string.
    #[test]
    fn p2_22_verify_body_happy_path_advances_counters() {
        let mut remote = RemoteCtx::default();
        let body_bytes = b"metadata:\n  name: x\n".to_vec();
        use base64::Engine;
        let mut hasher = sha2::Sha256::new();
        Digest::update(&mut hasher, &body_bytes);
        let declared = format!(
            "sha256-{}",
            base64::engine::general_purpose::STANDARD.encode(Digest::finalize(hasher))
        );
        let url = "https://example.com/ok.yaml";
        let out =
            verify_and_cache_body(url, Some(&declared), body_bytes.clone(), &mut remote).unwrap();
        assert_eq!(out.as_bytes(), &body_bytes[..]);
        assert_eq!(remote.fetch_count, 1);
        assert_eq!(remote.bytes_total, body_bytes.len());
        assert_eq!(remote.cache.len(), 1);
        assert_eq!(remote.cache.get(url).unwrap().actual_integrity, declared);
    }

    /// Gray-URL integrity conflict: when the same URL appears on the
    /// current recursion stack but is re-declared with a conflicting
    /// integrity, the runtime must surface `IntegrityConflict` rather
    /// than `ExtendsCycle` for a more precise diagnostic. Fail-closed
    /// is preserved either way.
    #[test]
    fn p2_18_gray_url_integrity_conflict_diagnoses_precisely() {
        let url = "https://example.com/self.yaml".to_string();
        // The body is a *self-referential* YAML — its `extends:` points
        // at itself with a DIFFERENT integrity than its actual hash.
        // The runtime resolves the child entry, then re-enters
        // walk_extends_inner for the same URL while it is gray.
        let body = r#"
extends:
  - url: "https://example.com/self.yaml"
    integrity: "sha256-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
metadata:
  name: self
  version: "0.1.0"
  agent_shield_version: "2.0"
"#;
        let mut hasher = sha2::Sha256::new();
        Digest::update(&mut hasher, body.as_bytes());
        let real_integrity = {
            use base64::Engine;
            format!(
                "sha256-{}",
                base64::engine::general_purpose::STANDARD.encode(Digest::finalize(hasher))
            )
        };

        let mut remote = RemoteCtx::default();
        remote.cache.insert(
            url.clone(),
            FetchedRemote {
                body: body.to_string(),
                actual_integrity: real_integrity.clone(),
            },
        );

        // Top-level local leaf that points at the URL with its true
        // integrity. The fetched body then re-declares the same URL
        // with the lying `sha256-AAA…=` integrity.
        let dir = std::env::temp_dir().join("loader_url_tests_gray_conflict");
        std::fs::create_dir_all(&dir).unwrap();
        let leaf = dir.join("leaf.yaml");
        std::fs::write(
            &leaf,
            format!(
                r#"
extends:
  - url: "{url}"
    integrity: "{real_integrity}"
metadata:
  name: leaf
  version: "0.1.0"
  agent_shield_version: "2.0"
"#
            ),
        )
        .unwrap();

        let canonical = canonicalize(&leaf).unwrap();
        let node = NodeKey::Path(canonical);
        let mut visited = HashMap::new();
        let mut in_progress = BTreeSet::new();
        let mut stack = Vec::new();
        let mut order = Vec::new();
        let mut wires = HashMap::new();
        let err = walk_extends(
            &node,
            0,
            &mut visited,
            &mut in_progress,
            &mut stack,
            &mut order,
            &mut wires,
            &mut remote,
        )
        .unwrap_err();
        assert!(
            matches!(err, ConfigError::IntegrityConflict { .. }),
            "gray-URL declared with conflicting integrity must surface as IntegrityConflict, not ExtendsCycle; got {err:?}"
        );
    }

    // ── `unverified: true` opt-out (§3.2) ────────────────────────────────

    /// Declaring `{ url, unverified: true }` makes the loader skip the
    /// SHA-256 body comparison, but every other resource bound
    /// (HTTPS-only, fetch budget, body cap) still applies. Verified
    /// via `verify_and_cache_body` with `declared: None`: the body is
    /// accepted, the cache stores the actual hash for later pinned
    /// declarations to verify against, and counters advance.
    #[test]
    fn p2_23_unverified_skips_integrity_check_but_caches_actual() {
        let mut remote = RemoteCtx::default();
        let body = b"metadata:\n  name: u\n".to_vec();
        let url = "https://example.com/unverified.yaml";
        let out = verify_and_cache_body(url, None, body.clone(), &mut remote).unwrap();
        assert_eq!(out.as_bytes(), &body[..]);
        assert_eq!(remote.fetch_count, 1);
        assert_eq!(remote.bytes_total, body.len());
        // The cache MUST still hold the real SHA-256 even though no
        // verification was performed — a sibling that later declares a
        // pinned hash for the same URL needs the real digest to compare
        // against.
        let cached = remote.cache.get(url).expect("cache must hold the body");
        assert!(
            cached.actual_integrity.starts_with("sha256-"),
            "cache integrity must be the real SHA-256, got {:?}",
            cached.actual_integrity
        );
    }

    /// An entry that declares BOTH `integrity:` and `unverified: true`
    /// is a load-time error: the trust model MUST be exactly one of
    /// pinned or unverified.
    #[test]
    fn p2_24_both_integrity_and_unverified_rejected() {
        let yaml = r#"
extends:
  - url: "https://example.com/x.yaml"
    integrity: "sha256-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
    unverified: true
metadata:
  name: leaf
  version: "0.1.0"
  agent_shield_version: "2.0"
"#;
        let dir = std::env::temp_dir().join("loader_url_tests_both_trust");
        std::fs::create_dir_all(&dir).unwrap();
        let p = dir.join("leaf.yaml");
        std::fs::write(&p, yaml).unwrap();
        let err = load_from_path(&p).unwrap_err();
        assert!(
            matches!(err, ConfigError::UrlExtendsConflictingTrust { .. }),
            "got {err:?}"
        );
    }

    /// An entry that declares NEITHER `integrity:` NOR `unverified: true`
    /// is a load-time error: the trust model MUST be explicit. The
    /// lazy path (just `{ url: X }`) is not allowed.
    #[test]
    fn p2_25_neither_integrity_nor_unverified_rejected() {
        let yaml = r#"
extends:
  - url: "https://example.com/x.yaml"
metadata:
  name: leaf
  version: "0.1.0"
  agent_shield_version: "2.0"
"#;
        let dir = std::env::temp_dir().join("loader_url_tests_no_trust");
        std::fs::create_dir_all(&dir).unwrap();
        let p = dir.join("leaf.yaml");
        std::fs::write(&p, yaml).unwrap();
        let err = load_from_path(&p).unwrap_err();
        assert!(
            matches!(err, ConfigError::UrlExtendsMissingTrust { .. }),
            "got {err:?}"
        );
    }

    /// `unverified: false` is treated as if the field were absent — and
    /// since that leaves neither trust signal present, the entry is
    /// rejected for the same reason as p2_25. This keeps the trust
    /// signal a strict boolean: anything other than literal
    /// `unverified: true` is "no opt-out".
    #[test]
    fn p2_26_unverified_false_does_not_opt_out() {
        let yaml = r#"
extends:
  - url: "https://example.com/x.yaml"
    unverified: false
metadata:
  name: leaf
  version: "0.1.0"
  agent_shield_version: "2.0"
"#;
        let dir = std::env::temp_dir().join("loader_url_tests_unverified_false");
        std::fs::create_dir_all(&dir).unwrap();
        let p = dir.join("leaf.yaml");
        std::fs::write(&p, yaml).unwrap();
        let err = load_from_path(&p).unwrap_err();
        assert!(
            matches!(err, ConfigError::UrlExtendsMissingTrust { .. }),
            "got {err:?}"
        );
    }

    /// `unverified: true` still rejects `http://` URLs. The opt-out is
    /// scoped to *content trust*; the protocol-hygiene checks
    /// (scheme, credentials, fragments, redirects) are unconditional.
    #[test]
    fn p2_27_unverified_still_rejects_http_scheme() {
        let yaml = r#"
extends:
  - url: "http://example.com/x.yaml"
    unverified: true
metadata:
  name: leaf
  version: "0.1.0"
  agent_shield_version: "2.0"
"#;
        let dir = std::env::temp_dir().join("loader_url_tests_unverified_http");
        std::fs::create_dir_all(&dir).unwrap();
        let p = dir.join("leaf.yaml");
        std::fs::write(&p, yaml).unwrap();
        let err = load_from_path(&p).unwrap_err();
        assert!(
            matches!(err, ConfigError::UrlExtendsBadScheme { .. }),
            "got {err:?}"
        );
    }

    /// A `{ url, unverified: true }` declaration followed by a pinned
    /// declaration of the same URL must still verify the pin against
    /// the actual bytes cached by the unverified fetch. The pinned
    /// declaration is the strictest contract in the chain; the
    /// unverified one cannot widen the trust boundary.
    #[test]
    fn p2_28_unverified_then_pinned_verifies_against_actual() {
        let url = "https://example.com/mixed.yaml".to_string();
        let body = "metadata:\n  name: c\n  version: \"0.1.0\"\n  agent_shield_version: \"2.0\"\n";
        let mut hasher = sha2::Sha256::new();
        Digest::update(&mut hasher, body.as_bytes());
        let real_integrity = {
            use base64::Engine;
            format!(
                "sha256-{}",
                base64::engine::general_purpose::STANDARD.encode(Digest::finalize(hasher))
            )
        };

        // Simulate the unverified fetch having happened first.
        let mut remote = RemoteCtx::default();
        remote.cache.insert(
            url.clone(),
            FetchedRemote {
                body: body.to_string(),
                actual_integrity: real_integrity.clone(),
            },
        );

        // Subsequent fetch with the CORRECT pinned hash succeeds: the
        // pin matches the cached actual.
        let out = fetch_remote(
            &url,
            Some(&real_integrity),
            &mut remote,
            &SourceLoc::default(),
        )
        .unwrap();
        assert_eq!(out, body);

        // Subsequent fetch with a WRONG pinned hash fails closed.
        use base64::Engine;
        let wrong = format!(
            "sha256-{}",
            base64::engine::general_purpose::STANDARD.encode([0x42u8; 32])
        );
        let err = fetch_remote(&url, Some(&wrong), &mut remote, &SourceLoc::default()).unwrap_err();
        assert!(
            matches!(err, ConfigError::IntegrityMismatch { .. }),
            "got {err:?}"
        );
    }
}
