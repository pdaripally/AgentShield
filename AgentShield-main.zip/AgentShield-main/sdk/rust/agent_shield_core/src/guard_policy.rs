//! Guard policies (§12) — the unified gating surface.
//!
//! Two flavors per §12 differ only in which detection kinds and action modes
//! they accept:
//!   - **State** (Stage 2): `expression`-only detection; `block`/`warn`.
//!   - **Content** (Stages 1, 3, 4, 5): all detection kinds; all action modes.
//!
//! This module defines the static guard-policy schema. The runtime that
//! evaluates policies lives in [`crate::guard_policy_runtime`].

use serde::{Deserialize, Serialize};

use super::resources::LogBlock;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Action {
    Block,
    Redact,
    Warn,
    Append,
    Prepend,
    /// Lower the running IFC exposure to a designated target tag set
    /// (the proof's δ at named lifecycle boundaries — see TC-5 in
    /// `docs/information-flow-control-proof.md` §3.6). The target is
    /// declared via the `declassify_target:` sibling field on the
    /// `evaluate_when[]` entry. The runtime structural pre-condition
    /// `target ⊆ exposure` is enforced when the action fires;
    /// release-function correctness and host-side context replacement
    /// are TCB axioms. The action does **not** block — it admits and
    /// applies the declassification as a side-effect.
    DeclassifyTo,
}

/// Selector for guard policies (§12.3).
#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq)]
#[serde(deny_unknown_fields)]
pub struct AppliesTo {
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub tools: Vec<String>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub agents: Vec<String>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub endpoints: Vec<EndpointSelector>,
}

impl AppliesTo {
    pub fn is_empty(&self) -> bool {
        self.tools.is_empty() && self.agents.is_empty() && self.endpoints.is_empty()
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(deny_unknown_fields)]
pub struct EndpointSelector {
    pub pattern: String,
    pub methods: Vec<String>,
}

/// LLM detection arm of an `evaluate_when[]` entry (§12.9).
///
/// `prompt_path:` is a load-time-only authoring convenience for
/// referring to a prompt file on disk; the loader reads the file in
/// `walk_extends_inner` (before `parse_yaml_strict` runs) and replaces
/// `prompt_path: <p>` with `prompt: <contents>` in the YAML so that
/// downstream `serde` sees a fully-inlined detection. The runtime
/// guarantee is therefore: **post-load, `prompt_path` is always `None`
/// and `prompt` is the inlined text**. See §12.9.2.
///
/// `#[serde(default)]` on `prompt` allows YAMLs that supply
/// `prompt_path:` instead — the loader's pre-`parse_yaml_strict`
/// inlining pass (B.4.2 in the design notes) replaces it before serde
/// runs. `#[serde(skip_serializing_if = "Option::is_none")]` on
/// `prompt_path` keeps the canonical wire output of a loaded
/// `LlmDetection` clean (no spurious `prompt_path: null`).
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct LlmDetection {
    #[serde(default)]
    pub prompt: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub prompt_path: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub configuration: Option<String>,
}

/// Classifier detection arm.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct ClassifierDetection {
    pub configuration: String,
}

/// The detection kind of an `evaluate_when[]` entry. Exactly one of the
/// variants is set per entry per §12.5.1.
#[derive(Debug, Clone, PartialEq)]
pub enum DetectionKind {
    Expression(String),
    Pattern(String),
    Patterns(Vec<String>),
    Llm(LlmDetection),
    Classifier(ClassifierDetection),
}

/// Single entry in an `evaluate_when[]` list (§12.5).
#[derive(Debug, Clone, PartialEq)]
pub struct EvaluateWhenEntry {
    pub detection: DetectionKind,
    pub reason: String,
    pub action: Option<Action>,
    pub replacement: Option<String>,
    pub text: Option<String>,
    pub paths: Vec<String>,
    pub log: Option<LogBlock>,
    /// Target tag set for `action: declassify_to`. List of tag names
    /// from `ifc.tags`, or `["*"]` for the full universe. Required
    /// when action is `DeclassifyTo`; ignored otherwise.
    pub declassify_target: Vec<String>,
}

impl<'de> Deserialize<'de> for EvaluateWhenEntry {
    fn deserialize<D: serde::Deserializer<'de>>(de: D) -> std::result::Result<Self, D::Error> {
        #[derive(Deserialize)]
        #[serde(deny_unknown_fields)]
        struct H {
            #[serde(default)]
            expression: Option<String>,
            #[serde(default)]
            pattern: Option<String>,
            #[serde(default)]
            patterns: Option<Vec<String>>,
            #[serde(default)]
            llm: Option<LlmDetection>,
            #[serde(default)]
            classifier: Option<ClassifierDetection>,
            reason: String,
            #[serde(default)]
            action: Option<Action>,
            #[serde(default)]
            replacement: Option<String>,
            #[serde(default)]
            text: Option<String>,
            #[serde(default)]
            paths: Vec<String>,
            #[serde(default)]
            log: Option<LogBlock>,
            #[serde(default)]
            declassify_target: Vec<String>,
        }
        let h = H::deserialize(de)?;

        // Exactly one detection kind.
        let count = [
            h.expression.is_some(),
            h.pattern.is_some(),
            h.patterns.is_some(),
            h.llm.is_some(),
            h.classifier.is_some(),
        ]
        .iter()
        .filter(|b| **b)
        .count();
        if count != 1 {
            return Err(serde::de::Error::custom(format!(
                "evaluate_when[] entry must declare exactly one of \
                 `expression`/`pattern`/`patterns`/`llm`/`classifier` (found {}) — §12.5.1",
                count
            )));
        }

        if h.reason.is_empty() {
            return Err(serde::de::Error::custom(
                "evaluate_when[] entry: `reason` is required (§12.5.2)",
            ));
        }

        let detection = if let Some(e) = h.expression {
            if e.is_empty() {
                return Err(serde::de::Error::custom(
                    "evaluate_when[].expression must be non-empty",
                ));
            }
            DetectionKind::Expression(e)
        } else if let Some(p) = h.pattern {
            DetectionKind::Pattern(p)
        } else if let Some(ps) = h.patterns {
            if ps.is_empty() {
                return Err(serde::de::Error::custom(
                    "evaluate_when[].patterns must not be empty",
                ));
            }
            DetectionKind::Patterns(ps)
        } else if let Some(l) = h.llm {
            DetectionKind::Llm(l)
        } else {
            DetectionKind::Classifier(h.classifier.unwrap())
        };

        // Cross-field validation: declassify_target only meaningful
        // for action: declassify_to. An empty list under declassify_to
        // is allowed and means "lower to ⊥".
        if h.action != Some(Action::DeclassifyTo) && !h.declassify_target.is_empty() {
            return Err(serde::de::Error::custom(
                "evaluate_when[] entry: `declassify_target:` is only meaningful with \
                 `action: declassify_to`",
            ));
        }

        Ok(EvaluateWhenEntry {
            detection,
            reason: h.reason,
            action: h.action,
            replacement: h.replacement,
            text: h.text,
            paths: h.paths,
            log: h.log,
            declassify_target: h.declassify_target,
        })
    }
}

impl Serialize for EvaluateWhenEntry {
    fn serialize<S: serde::Serializer>(&self, ser: S) -> std::result::Result<S::Ok, S::Error> {
        use serde::ser::SerializeMap;
        let mut m = ser.serialize_map(None)?;
        match &self.detection {
            DetectionKind::Expression(e) => m.serialize_entry("expression", e)?,
            DetectionKind::Pattern(p) => m.serialize_entry("pattern", p)?,
            DetectionKind::Patterns(ps) => m.serialize_entry("patterns", ps)?,
            DetectionKind::Llm(l) => m.serialize_entry("llm", l)?,
            DetectionKind::Classifier(c) => m.serialize_entry("classifier", c)?,
        }
        m.serialize_entry("reason", &self.reason)?;
        if let Some(a) = &self.action {
            m.serialize_entry("action", a)?;
        }
        if let Some(r) = &self.replacement {
            m.serialize_entry("replacement", r)?;
        }
        if let Some(t) = &self.text {
            m.serialize_entry("text", t)?;
        }
        if !self.paths.is_empty() {
            m.serialize_entry("paths", &self.paths)?;
        }
        if let Some(l) = &self.log {
            m.serialize_entry("log", l)?;
        }
        m.end()
    }
}

/// Per-stage flavor metadata used for shape-validation when we know which
/// stage a guard policy comes from.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum StageFlavor {
    /// Stage 1: input validation; `applies_to:` REJECTED.
    Input,
    /// Stage 2: state validation; `applies_to:` REQUIRED; expression-only.
    State,
    /// Stage 3: tool-execution validation; `applies_to:` optional.
    ToolExecution,
    /// Stage 4: post-tool validation; `applies_to:` optional.
    PostTool,
    /// Stage 5: output validation; `applies_to:` REJECTED.
    Output,
}

impl StageFlavor {
    pub fn applies_to_required(&self) -> bool {
        matches!(self, StageFlavor::State)
    }
    pub fn applies_to_rejected(&self) -> bool {
        matches!(self, StageFlavor::Input | StageFlavor::Output)
    }
    /// State flavor: only `expression` detection allowed.
    pub fn expression_only(&self) -> bool {
        matches!(self, StageFlavor::State)
    }
    /// State flavor: only `block` and `warn` action modes allowed.
    pub fn state_actions_only(&self) -> bool {
        matches!(self, StageFlavor::State)
    }
    /// Stages where `append`/`prepend` are forbidden (§12.7). Only Stage 3
    /// (tool-execution) accepts mutating-style transforms; every other
    /// stage rejects them at load time.
    pub fn append_prepend_rejected(&self) -> bool {
        !matches!(self, StageFlavor::ToolExecution)
    }
    /// Human-readable stage label for diagnostics.
    pub fn label(&self) -> &'static str {
        match self {
            StageFlavor::Input => "input",
            StageFlavor::State => "state",
            StageFlavor::ToolExecution => "tool_execution",
            StageFlavor::PostTool => "post_tool",
            StageFlavor::Output => "output",
        }
    }
}

fn action_str(a: Action) -> &'static str {
    match a {
        Action::Block => "block",
        Action::Redact => "redact",
        Action::Warn => "warn",
        Action::Append => "append",
        Action::Prepend => "prepend",
        Action::DeclassifyTo => "declassify_to",
    }
}

/// A single guard policy (§12.2). Stage-specific shape constraints are
/// enforced by the loader after deserialization, since YAML doesn't tell
/// us which stage the entry belongs to.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(deny_unknown_fields)]
pub struct GuardPolicy {
    pub name: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub description: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub applies_to: Option<AppliesTo>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub active_if: Option<String>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub evaluate_when: Vec<EvaluateWhenEntry>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub allowed_when: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub action: Option<Action>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub reason: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub replacement: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub log: Option<LogBlock>,
}

impl GuardPolicy {
    /// Apply per-stage shape constraints (§12.3.1, §15). Returns a
    /// human-readable error if the shape doesn't match the flavor.
    pub fn validate_for_stage(&self, flavor: StageFlavor) -> std::result::Result<(), String> {
        if flavor.applies_to_required()
            && self
                .applies_to
                .as_ref()
                .map(|a| a.is_empty())
                .unwrap_or(true)
        {
            return Err(format!(
                "guard policy `{}`: stage requires non-empty `applies_to:` (§12.3.1)",
                self.name
            ));
        }
        if flavor.applies_to_rejected() && self.applies_to.is_some() {
            return Err(format!(
                "guard policy `{}`: stage rejects `applies_to:` (§12.3.1)",
                self.name
            ));
        }
        if flavor.expression_only() {
            for (i, e) in self.evaluate_when.iter().enumerate() {
                if !matches!(e.detection, DetectionKind::Expression(_)) {
                    return Err(format!(
                        "guard policy `{}`: state-stage entry [{}] must use `expression:` only (§15)",
                        self.name, i
                    ));
                }
            }
        }
        if flavor.state_actions_only() {
            // Outer action and per-entry actions must be Block, Warn,
            // or DeclassifyTo (the IFC declassification action verb,
            // typically fired at lifecycle event boundaries via Stage 2
            // state validation).
            if let Some(a) = self.action {
                if !matches!(a, Action::Block | Action::Warn | Action::DeclassifyTo) {
                    return Err(format!(
                        "guard policy `{}`: state-stage `action:` must be `block`, `warn`, or `declassify_to` (§15)",
                        self.name
                    ));
                }
            }
            for (i, e) in self.evaluate_when.iter().enumerate() {
                if let Some(a) = e.action {
                    if !matches!(a, Action::Block | Action::Warn | Action::DeclassifyTo) {
                        return Err(format!(
                            "guard policy `{}`: state-stage entry [{}] action must be `block`, `warn`, or `declassify_to` (§15)",
                            self.name, i
                        ));
                    }
                }
            }
        }
        // §12.7: append/prepend are only valid on Stage 3 (tool-execution).
        // Reject them outright on every other stage. Outer action and
        // every per-entry action are checked.
        if flavor.append_prepend_rejected() {
            if let Some(a) = self.action {
                if matches!(a, Action::Append | Action::Prepend) {
                    return Err(format!(
                        "guard policy `{}`: action `{}` is forbidden on stage `{}` (§12.7 — append/prepend are Stage 3 only)",
                        self.name, action_str(a), flavor.label()
                    ));
                }
            }
            for (i, e) in self.evaluate_when.iter().enumerate() {
                if let Some(a) = e.action {
                    if matches!(a, Action::Append | Action::Prepend) {
                        return Err(format!(
                            "guard policy `{}`: entry [{}] action `{}` is forbidden on stage `{}` (§12.7 — append/prepend are Stage 3 only)",
                            self.name, i, action_str(a), flavor.label()
                        ));
                    }
                }
            }
        }
        // §12.7: append/prepend on Stage 3 entries REQUIRE non-empty
        // `paths:` (you must say where the appended text is inserted) AND
        // a non-empty `text:` (the text to insert). Without these the
        // runtime no-ops silently — fail closed at load time.
        if matches!(flavor, StageFlavor::ToolExecution) {
            for (i, e) in self.evaluate_when.iter().enumerate() {
                if let Some(a) = e.action {
                    if matches!(a, Action::Append | Action::Prepend) {
                        if e.paths.is_empty() {
                            return Err(format!(
                                "guard policy `{}`: entry [{}] action `{}` requires non-empty `paths:` (§12.7)",
                                self.name, i, action_str(a)
                            ));
                        }
                        if e.text.as_ref().map(|t| t.is_empty()).unwrap_or(true) {
                            return Err(format!(
                                "guard policy `{}`: entry [{}] action `{}` requires non-empty `text:` (§12.7)",
                                self.name, i, action_str(a)
                            ));
                        }
                    }
                }
            }
        }
        // §12.7 + §12.9: `action: redact` is only meaningful on entries
        // whose detection produces span output (pattern, patterns, llm,
        // classifier). An `expression:` detection has no span surface, so
        // redact would silently no-op the policy — fail closed at load.
        for (i, e) in self.evaluate_when.iter().enumerate() {
            if let Some(Action::Redact) = e.action {
                if matches!(e.detection, DetectionKind::Expression(_)) {
                    return Err(format!(
                        "guard policy `{}`: entry [{}] uses `action: redact` with `expression:` detection — \
                         redact requires a span-producing detector (`pattern`, `patterns`, `llm`, or `classifier`) (§12.9)",
                        self.name, i
                    ));
                }
            }
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_basic_guard_policy() {
        let yaml = "
name: x
applies_to:
  tools: [t1]
evaluate_when:
  - expression: \"y == 1\"
    reason: \"because\"
action: block
";
        let g: GuardPolicy = serde_yaml::from_str(yaml).unwrap();
        assert_eq!(g.name, "x");
        assert_eq!(g.evaluate_when.len(), 1);
    }

    #[test]
    fn rejects_multi_kind_in_evaluate_when_entry() {
        let yaml = "
name: x
evaluate_when:
  - expression: \"y\"
    pattern: \"abc\"
    reason: r
";
        let err = serde_yaml::from_str::<GuardPolicy>(yaml)
            .unwrap_err()
            .to_string();
        assert!(err.contains("exactly one"));
    }

    #[test]
    fn rejects_missing_reason() {
        let yaml = "
name: x
evaluate_when:
  - expression: \"y\"
";
        let err = serde_yaml::from_str::<GuardPolicy>(yaml)
            .unwrap_err()
            .to_string();
        assert!(err.contains("reason"));
    }

    #[test]
    fn validate_for_stage_state_requires_applies_to() {
        let g: GuardPolicy =
            serde_yaml::from_str("name: x\nevaluate_when:\n  - expression: y\n    reason: r\n")
                .unwrap();
        let err = g.validate_for_stage(StageFlavor::State).unwrap_err();
        assert!(err.contains("applies_to"));
    }

    #[test]
    fn validate_for_stage_input_rejects_applies_to() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\napplies_to:\n  tools: [t]\nevaluate_when:\n  - pattern: x\n    reason: r\n",
        )
        .unwrap();
        let err = g.validate_for_stage(StageFlavor::Input).unwrap_err();
        assert!(err.contains("rejects"));
    }

    #[test]
    fn validate_for_stage_state_rejects_pattern() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\napplies_to:\n  tools: [t]\nevaluate_when:\n  - pattern: \"abc\"\n    reason: r\n",
        )
        .unwrap();
        let err = g.validate_for_stage(StageFlavor::State).unwrap_err();
        assert!(err.contains("expression"));
    }

    #[test]
    fn validate_for_stage_input_rejects_append_outer_action() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - pattern: \"abc\"\n    reason: r\naction: append\n",
        )
        .unwrap();
        let err = g.validate_for_stage(StageFlavor::Input).unwrap_err();
        assert!(err.contains("append"), "got: {err}");
        assert!(err.contains("input"), "got: {err}");
    }

    #[test]
    fn validate_for_stage_post_tool_rejects_prepend_entry_action() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - pattern: \"abc\"\n    reason: r\n    action: prepend\n",
        )
        .unwrap();
        let err = g.validate_for_stage(StageFlavor::PostTool).unwrap_err();
        assert!(err.contains("prepend"), "got: {err}");
        assert!(err.contains("post_tool"), "got: {err}");
    }

    #[test]
    fn validate_for_stage_tool_exec_requires_paths_for_append() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - pattern: \"abc\"\n    reason: r\n    action: append\n    text: hi\n",
        )
        .unwrap();
        let err = g
            .validate_for_stage(StageFlavor::ToolExecution)
            .unwrap_err();
        assert!(err.contains("paths"), "got: {err}");
    }

    #[test]
    fn validate_for_stage_tool_exec_requires_text_for_prepend() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - pattern: \"abc\"\n    reason: r\n    action: prepend\n    paths: [\"$.body\"]\n",
        )
        .unwrap();
        let err = g
            .validate_for_stage(StageFlavor::ToolExecution)
            .unwrap_err();
        assert!(err.contains("text"), "got: {err}");
    }

    #[test]
    fn validate_for_stage_tool_exec_accepts_complete_append() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - pattern: \"abc\"\n    reason: r\n    action: append\n    text: \"hi\"\n    paths: [\"$.body\"]\n",
        )
        .unwrap();
        g.validate_for_stage(StageFlavor::ToolExecution).unwrap();
    }

    #[test]
    fn validate_rejects_redact_with_expression_detection() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - expression: \"y == 1\"\n    reason: r\n    action: redact\n",
        )
        .unwrap();
        let err = g.validate_for_stage(StageFlavor::Output).unwrap_err();
        assert!(err.contains("redact"), "got: {err}");
        assert!(err.contains("expression"), "got: {err}");
    }
}
