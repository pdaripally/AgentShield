//! Resetter engine (§10.6).
//!
//! Symmetric counterpart to [`crate::populator`]: when a tool / endpoint
//! / agent invocation fires, the runtime walks every variable's
//! `reset_by[]` list. Entries whose `kind:` + identity match the
//! invocation transition the variable to `@status == 'unset'` (cleared
//! value, lifetime stamps reset). The action itself is a method on
//! [`crate::lifetime_tracker::LifetimeTracker::invalidate_variable`];
//! this module is purely the *selection* layer.
//!
//! ## Spec mapping
//!
//! - §10.6 — `reset_by[]` schema.
//! - §10.8 — pre/post-execution lifecycle layers.
//!
//! `reset_by[]` shares its resource-targeting grammar with
//! `populated_by[]` (§10.5.1), so this module reuses the matchers exposed
//! by [`crate::populator`].

use super::populator::{methods_match, pattern_matches_uri, Invocation};
use super::variables::{Phase, ResetEntry, ResourceKind, Variable};

/// Walk the declared variables and return all `(variable, entry)` pairs
/// whose `kind` + identity + phase match the invocation.
pub fn select_resetters<'a>(
    variables: &'a [Variable],
    invocation: &Invocation,
    phase: Phase,
) -> Vec<(&'a Variable, &'a ResetEntry)> {
    let mut out = Vec::new();
    for var in variables {
        for entry in &var.reset_by {
            if entry.phase == phase && entry_matches(entry, invocation) {
                out.push((var, entry));
            }
        }
    }
    out
}

fn entry_matches(entry: &ResetEntry, inv: &Invocation) -> bool {
    if entry.kind != inv.kind {
        return false;
    }
    match entry.kind {
        ResourceKind::Tool | ResourceKind::Agent => match (&entry.name, &inv.name) {
            (Some(en), Some(in_n)) => en == "*" || en == in_n,
            _ => false,
        },
        ResourceKind::Endpoint => endpoint_match(entry, inv),
    }
}

fn endpoint_match(entry: &ResetEntry, inv: &Invocation) -> bool {
    let Some(pattern) = entry.pattern.as_deref() else {
        return false;
    };
    let Some(uri) = inv.uri.as_deref() else {
        return false;
    };
    let Some(method) = inv.method.as_deref() else {
        return false;
    };
    methods_match(&entry.methods, method) && pattern_matches_uri(pattern, uri)
}

// ── Tests ──────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use crate::variables::{ResetEntry, ResourceKind, Variable, VariableType};
    use serde_json::json;

    fn reset_tool(name: &str, phase: Phase) -> ResetEntry {
        ResetEntry {
            kind: ResourceKind::Tool,
            name: Some(name.into()),
            pattern: None,
            methods: vec![],
            phase,
            expression: None,
            extractor: None,
        }
    }

    fn reset_agent(name: &str, phase: Phase) -> ResetEntry {
        ResetEntry {
            kind: ResourceKind::Agent,
            name: Some(name.into()),
            pattern: None,
            methods: vec![],
            phase,
            expression: None,
            extractor: None,
        }
    }

    fn reset_endpoint(pattern: &str, methods: Vec<&str>, phase: Phase) -> ResetEntry {
        ResetEntry {
            kind: ResourceKind::Endpoint,
            name: None,
            pattern: Some(pattern.into()),
            methods: methods.into_iter().map(String::from).collect(),
            phase,
            expression: None,
            extractor: None,
        }
    }

    fn var_with_reset(name: &str, entries: Vec<ResetEntry>) -> Variable {
        Variable {
            name: name.into(),
            var_type: VariableType::Object,
            description: None,
            default: None,
            members: None,
            update: None,
            key: None,
            lifetime: None,
            on_demand_by: None,
            populated_by: vec![],
            reset_by: entries,
        }
    }

    #[test]
    fn selects_tool_resetter_by_name() {
        let v = var_with_reset("x", vec![reset_tool("send", Phase::After)]);
        let inv = Invocation::tool("send", json!({}));
        let hits = select_resetters(std::slice::from_ref(&v), &inv, Phase::After);
        assert_eq!(hits.len(), 1);
    }

    #[test]
    fn skips_tool_resetter_on_phase_mismatch() {
        let v = var_with_reset("x", vec![reset_tool("send", Phase::After)]);
        let inv = Invocation::tool("send", json!({}));
        let hits = select_resetters(std::slice::from_ref(&v), &inv, Phase::Before);
        assert!(hits.is_empty());
    }

    #[test]
    fn matches_wildcard_tool_name() {
        let v = var_with_reset("x", vec![reset_tool("*", Phase::Before)]);
        let inv = Invocation::tool("ad_hoc", json!({}));
        let hits = select_resetters(std::slice::from_ref(&v), &inv, Phase::Before);
        assert_eq!(hits.len(), 1);
    }

    #[test]
    fn distinguishes_agent_from_tool() {
        let v = var_with_reset("x", vec![reset_agent("planner", Phase::After)]);
        let agent_inv = Invocation::agent("planner", json!({}));
        let tool_inv = Invocation::tool("planner", json!({}));
        assert_eq!(
            select_resetters(std::slice::from_ref(&v), &agent_inv, Phase::After).len(),
            1
        );
        assert!(select_resetters(std::slice::from_ref(&v), &tool_inv, Phase::After).is_empty());
    }

    #[test]
    fn endpoint_resetter_matches_pattern_and_method() {
        let v = var_with_reset(
            "x",
            vec![reset_endpoint(
                "/api/users/{id}",
                vec!["DELETE"],
                Phase::After,
            )],
        );
        let inv = Invocation::endpoint("DELETE", "/api/users/42", json!({}));
        let hits = select_resetters(std::slice::from_ref(&v), &inv, Phase::After);
        assert_eq!(hits.len(), 1);

        let inv2 = Invocation::endpoint("GET", "/api/users/42", json!({}));
        assert!(select_resetters(std::slice::from_ref(&v), &inv2, Phase::After).is_empty());
    }

    #[test]
    fn endpoint_resetter_glob_pattern() {
        let v = var_with_reset(
            "x",
            vec![reset_endpoint("/admin/**", vec!["*"], Phase::Before)],
        );
        for path in &["/admin", "/admin/users", "/admin/users/42/perms"] {
            let inv = Invocation::endpoint("POST", *path, json!({}));
            let hits = select_resetters(std::slice::from_ref(&v), &inv, Phase::Before);
            assert_eq!(hits.len(), 1, "path {} should match", path);
        }
    }
}
