//! Lifetime grammar (§10.1) — bare and map forms.
//!
//! The bare form applies to predicates and events; the map form
//! (`{ allow:, deny:, cancelled? }`) is variables-only (§9.1.2).

use std::str::FromStr;

use chrono::Duration;
use serde::{Deserialize, Serialize};

use super::events::EventId;

/// Bare lifetime per §9.1.1.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum BareLifetime {
    PerCall,
    PerTurn,
    PerSession,
    PerRequest,
    For(Duration),
    UntilEvent(Vec<EventId>),
}

impl BareLifetime {
    /// True if this lifetime accepts the runtime ever caching the value.
    pub fn allows_caching(&self) -> bool {
        !matches!(self, BareLifetime::PerCall)
    }
}

/// Either a bare lifetime or the variable-only map form (§9.1.2).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Lifetime {
    Bare(BareLifetime),
    Map(LifetimeMap),
}

/// §9.1.2.1 — a single branch of the map form. Either a literal
/// [`BareLifetime`] (the §9.1.1 grammar) or an expression evaluated at
/// write time against `@incoming` / `@current` to produce the effective
/// lifetime for that single write.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum LifetimeBranch {
    Bare(BareLifetime),
    /// Expression source. Evaluation happens at write time in
    /// [`crate::lifetime_tracker::LifetimeTracker::set_variable_keyed_full`].
    Expression(String),
}

impl LifetimeBranch {
    /// Borrow the literal [`BareLifetime`] when this branch is a literal.
    /// Returns `None` for the expression form — callers MUST evaluate
    /// the expression to obtain the effective bare lifetime.
    pub fn as_bare(&self) -> Option<&BareLifetime> {
        match self {
            LifetimeBranch::Bare(b) => Some(b),
            LifetimeBranch::Expression(_) => None,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LifetimeMap {
    pub allow: LifetimeBranch,
    pub deny: LifetimeBranch,
    pub cancelled: Option<LifetimeBranch>,
}

// ── Duration parsing ─────────────────────────────────────────────────

/// Parse the duration literal grammar accepted by `time.duration()` in the
/// expression language (§7.7) and by `lifetime: { for: <duration> }`.
///
/// Accepted forms:
///   • ISO-8601 `PnDTnHnMnS` (uppercase only, after the leading `P`).
///   • Shorthand `12h`, `30m`, `45s`, `500ms`, `2d`, `1h30m`, `90m`, etc.
pub fn parse_duration(s: &str) -> std::result::Result<Duration, String> {
    let trimmed = s.trim();
    if trimmed.is_empty() {
        return Err("empty duration".into());
    }
    if let Some(rest) = trimmed.strip_prefix('P') {
        return parse_iso8601(rest);
    }
    parse_shorthand(trimmed)
}

fn parse_iso8601(rest: &str) -> std::result::Result<Duration, String> {
    let mut total_ms: i64 = 0;
    let mut in_time = false;
    let mut acc = String::new();
    let mut consumed_anything = false;
    for c in rest.chars() {
        match c {
            'T' => {
                if !acc.is_empty() {
                    return Err(format!("ISO-8601: stray digits before `T`: `{}`", acc));
                }
                in_time = true;
            }
            '0'..='9' | '.' => acc.push(c),
            unit => {
                if acc.is_empty() {
                    return Err(format!("ISO-8601: unit `{}` without value", unit));
                }
                let val: f64 = acc
                    .parse()
                    .map_err(|e| format!("ISO-8601: invalid number `{}`: {}", acc, e))?;
                if val < 0.0 {
                    return Err(format!(
                        "ISO-8601: negative duration components are not allowed: `{}`",
                        acc
                    ));
                }
                acc.clear();
                let ms = match (in_time, unit) {
                    (false, 'D') => (val * 86_400_000.0) as i64,
                    (true, 'H') => (val * 3_600_000.0) as i64,
                    (true, 'M') => (val * 60_000.0) as i64,
                    (true, 'S') => (val * 1_000.0) as i64,
                    _ => return Err(format!("ISO-8601: unsupported unit `{}` for context", unit)),
                };
                total_ms = total_ms
                    .checked_add(ms)
                    .ok_or_else(|| "ISO-8601: overflow".to_string())?;
                consumed_anything = true;
            }
        }
    }
    if !acc.is_empty() {
        return Err(format!("ISO-8601: trailing digits without unit: `{}`", acc));
    }
    if !consumed_anything {
        return Err("ISO-8601: empty duration; `P` requires at least one component".into());
    }
    Ok(Duration::milliseconds(total_ms))
}

fn parse_shorthand(input: &str) -> std::result::Result<Duration, String> {
    let mut total_ms: i64 = 0;
    let mut acc = String::new();
    let mut chars = input.chars().peekable();
    let mut consumed_anything = false;
    while let Some(&c) = chars.peek() {
        if c.is_ascii_digit() || c == '.' {
            acc.push(c);
            chars.next();
        } else if c.is_ascii_alphabetic() {
            if acc.is_empty() {
                return Err(format!(
                    "shorthand: unit without preceding number near `{}`",
                    c
                ));
            }
            let mut unit = String::new();
            while let Some(&c) = chars.peek() {
                if c.is_ascii_alphabetic() {
                    unit.push(c);
                    chars.next();
                } else {
                    break;
                }
            }
            let val: f64 = acc
                .parse()
                .map_err(|e| format!("shorthand: invalid number `{}`: {}", acc, e))?;
            if val < 0.0 {
                return Err(format!(
                    "shorthand: negative duration components are not allowed: `{}`",
                    acc
                ));
            }
            acc.clear();
            let ms = match unit.as_str() {
                // `ms` is a deliberate extension over the spec's canonical
                // `s|m|h|d` units — useful for tests/hosts that need
                // sub-second granularity. `us`/`ns` are intentionally rejected.
                "ms" => val as i64,
                "s" => (val * 1_000.0) as i64,
                "m" => (val * 60_000.0) as i64,
                "h" => (val * 3_600_000.0) as i64,
                "d" => (val * 86_400_000.0) as i64,
                other => return Err(format!("shorthand: unknown unit `{}`", other)),
            };
            total_ms = total_ms
                .checked_add(ms)
                .ok_or_else(|| "shorthand: overflow".to_string())?;
            consumed_anything = true;
        } else if c.is_whitespace() {
            chars.next();
        } else {
            return Err(format!("shorthand: unexpected character `{}`", c));
        }
    }
    if !acc.is_empty() {
        return Err(format!(
            "shorthand: trailing digits without unit: `{}`",
            acc
        ));
    }
    if !consumed_anything {
        return Err("shorthand: no value/unit pairs".into());
    }
    Ok(Duration::milliseconds(total_ms))
}

// ── Serde for BareLifetime ───────────────────────────────────────────

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct BareObject {
    #[serde(default)]
    r#for: Option<String>,
    #[serde(default)]
    until_event: Option<UntilEventList>,
}

/// Single-or-many wrapper for `until_event:`. We dispatch on YAML shape so a
/// bad inner `EventId` surfaces as the actual parser error instead of the
/// useless "data did not match any variant" output of `serde(untagged)`.
#[derive(Debug)]
enum UntilEventList {
    Single(EventId),
    Many(Vec<EventId>),
}

impl<'de> Deserialize<'de> for UntilEventList {
    fn deserialize<D: serde::Deserializer<'de>>(de: D) -> std::result::Result<Self, D::Error> {
        let v = serde_yaml::Value::deserialize(de)?;
        match v {
            serde_yaml::Value::String(s) => {
                let id = EventId::parse(&s).map_err(serde::de::Error::custom)?;
                Ok(UntilEventList::Single(id))
            }
            serde_yaml::Value::Sequence(seq) => {
                let mut out = Vec::with_capacity(seq.len());
                for item in seq {
                    match item {
                        serde_yaml::Value::String(s) => {
                            out.push(EventId::parse(&s).map_err(serde::de::Error::custom)?);
                        }
                        other => {
                            return Err(serde::de::Error::custom(format!(
                                "until_event[] entries must be strings, got {:?}",
                                other
                            )))
                        }
                    }
                }
                Ok(UntilEventList::Many(out))
            }
            other => Err(serde::de::Error::custom(format!(
                "until_event must be a string or list of strings, got {:?}",
                other
            ))),
        }
    }
}

impl<'de> Deserialize<'de> for BareLifetime {
    fn deserialize<D: serde::Deserializer<'de>>(de: D) -> std::result::Result<Self, D::Error> {
        // Dispatch on YAML value shape so error messages can attribute the
        // failure to the right field instead of "data did not match any
        // variant" (the cost of `untagged` enums).
        let v = serde_yaml::Value::deserialize(de)?;
        match v {
            serde_yaml::Value::String(k) => match k.as_str() {
                "per_call" => Ok(BareLifetime::PerCall),
                "per_turn" => Ok(BareLifetime::PerTurn),
                "per_session" => Ok(BareLifetime::PerSession),
                "per_request" => Ok(BareLifetime::PerRequest),
                other => Err(serde::de::Error::custom(format!(
                    "unknown lifetime keyword `{}` (expected per_call|per_turn|per_session|per_request)",
                    other
                ))),
            },
            serde_yaml::Value::Mapping(_) => {
                let obj: BareObject = serde_yaml::from_value(v).map_err(serde::de::Error::custom)?;
                match (obj.r#for, obj.until_event) {
                    (Some(_), Some(_)) => Err(serde::de::Error::custom(
                        "lifetime object cannot declare both `for` and `until_event`",
                    )),
                    (Some(s), None) => parse_duration(&s)
                        .map(BareLifetime::For)
                        .map_err(serde::de::Error::custom),
                    (None, Some(UntilEventList::Single(id))) => {
                        Ok(BareLifetime::UntilEvent(vec![id]))
                    }
                    (None, Some(UntilEventList::Many(ids))) => {
                        if ids.is_empty() {
                            Err(serde::de::Error::custom(
                                "until_event list must not be empty",
                            ))
                        } else {
                            Ok(BareLifetime::UntilEvent(ids))
                        }
                    }
                    (None, None) => Err(serde::de::Error::custom(
                        "lifetime object must declare `for` or `until_event`",
                    )),
                }
            }
            other => Err(serde::de::Error::custom(format!(
                "lifetime: expected scalar keyword or mapping, got {:?}",
                other
            ))),
        }
    }
}

impl Serialize for BareLifetime {
    fn serialize<S: serde::Serializer>(&self, ser: S) -> std::result::Result<S::Ok, S::Error> {
        use serde::ser::SerializeMap;
        match self {
            BareLifetime::PerCall => ser.serialize_str("per_call"),
            BareLifetime::PerTurn => ser.serialize_str("per_turn"),
            BareLifetime::PerSession => ser.serialize_str("per_session"),
            BareLifetime::PerRequest => ser.serialize_str("per_request"),
            BareLifetime::For(d) => {
                let mut m = ser.serialize_map(Some(1))?;
                m.serialize_entry("for", &format!("{}ms", d.num_milliseconds()))?;
                m.end()
            }
            BareLifetime::UntilEvent(ids) => {
                let mut m = ser.serialize_map(Some(1))?;
                if ids.len() == 1 {
                    m.serialize_entry("until_event", &ids[0])?;
                } else {
                    m.serialize_entry("until_event", ids)?;
                }
                m.end()
            }
        }
    }
}

// ── Serde for Lifetime (bare-or-map) ─────────────────────────────────

impl<'de> Deserialize<'de> for Lifetime {
    fn deserialize<D: serde::Deserializer<'de>>(de: D) -> std::result::Result<Self, D::Error> {
        let v = serde_yaml::Value::deserialize(de)?;
        match v {
            serde_yaml::Value::String(k) => Ok(Lifetime::Bare(parse_keyword::<D>(&k)?)),
            serde_yaml::Value::Mapping(_) => {
                let mapping = v.as_mapping().unwrap();
                let has_allow = mapping.iter().any(|(k, _)| k.as_str() == Some("allow"));
                let has_deny = mapping.iter().any(|(k, _)| k.as_str() == Some("deny"));
                if has_allow || has_deny {
                    let map: LifetimeMap =
                        serde_yaml::from_value(v).map_err(serde::de::Error::custom)?;
                    Ok(Lifetime::Map(map))
                } else {
                    let bare: BareLifetime =
                        serde_yaml::from_value(v).map_err(serde::de::Error::custom)?;
                    Ok(Lifetime::Bare(bare))
                }
            }
            other => Err(serde::de::Error::custom(format!(
                "lifetime: expected scalar keyword or mapping, got {:?}",
                other
            ))),
        }
    }
}

fn parse_keyword<'de, D: serde::Deserializer<'de>>(
    k: &str,
) -> std::result::Result<BareLifetime, D::Error> {
    match k {
        "per_call" => Ok(BareLifetime::PerCall),
        "per_turn" => Ok(BareLifetime::PerTurn),
        "per_session" => Ok(BareLifetime::PerSession),
        "per_request" => Ok(BareLifetime::PerRequest),
        other => Err(serde::de::Error::custom(format!(
            "unknown lifetime keyword `{}`",
            other
        ))),
    }
}

impl Serialize for Lifetime {
    fn serialize<S: serde::Serializer>(&self, ser: S) -> std::result::Result<S::Ok, S::Error> {
        match self {
            Lifetime::Bare(b) => b.serialize(ser),
            Lifetime::Map(m) => m.serialize(ser),
        }
    }
}

/// §9.1.2: a single branch of the map form. On the wire, this is
/// either a string scalar / sequence (literal forms) or an object with
/// an `expression:` key (the §9.1.2.1 form). The `BareLifetime`
/// deserializer accepts the literal vocabulary (keyword scalars,
/// event-id scalars/sequences, `for:`, `until_event:`); the
/// `expression:`-keyed object is the v2.0.0 escape hatch.
fn deserialize_branch<'de, D>(de: D) -> std::result::Result<LifetimeBranch, D::Error>
where
    D: serde::Deserializer<'de>,
{
    let v = serde_yaml::Value::deserialize(de)?;
    // The expression form is the only shape carrying an `expression:` key
    // on a top-level mapping.
    if let serde_yaml::Value::Mapping(m) = &v {
        if let Some(expr) = m.get(serde_yaml::Value::String("expression".into())) {
            if m.len() != 1 {
                return Err(serde::de::Error::custom(
                    "lifetime branch with `expression:` key must have no sibling fields (§9.1.2.1)",
                ));
            }
            let s = expr.as_str().ok_or_else(|| {
                serde::de::Error::custom("lifetime branch `expression:` value must be a string")
            })?;
            return Ok(LifetimeBranch::Expression(s.to_string()));
        }
    }
    // Otherwise it's a literal — round-trip through BareLifetime.
    let bare: BareLifetime = serde_yaml::from_value(v).map_err(serde::de::Error::custom)?;
    Ok(LifetimeBranch::Bare(bare))
}

/// Adapter type for serde derive on `LifetimeMapWire`.
#[derive(Debug)]
struct BranchAdapter(LifetimeBranch);

impl<'de> Deserialize<'de> for BranchAdapter {
    fn deserialize<D: serde::Deserializer<'de>>(de: D) -> std::result::Result<Self, D::Error> {
        deserialize_branch(de).map(BranchAdapter)
    }
}

impl Serialize for BranchAdapter {
    fn serialize<S: serde::Serializer>(&self, ser: S) -> std::result::Result<S::Ok, S::Error> {
        match &self.0 {
            LifetimeBranch::Bare(b) => b.serialize(ser),
            LifetimeBranch::Expression(s) => {
                use serde::ser::SerializeMap;
                let mut m = ser.serialize_map(Some(1))?;
                m.serialize_entry("expression", s)?;
                m.end()
            }
        }
    }
}

#[derive(Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
struct LifetimeMapWire {
    allow: BranchAdapter,
    deny: BranchAdapter,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    cancelled: Option<BranchAdapter>,
}

impl<'de> Deserialize<'de> for LifetimeMap {
    fn deserialize<D: serde::Deserializer<'de>>(de: D) -> std::result::Result<Self, D::Error> {
        let w = LifetimeMapWire::deserialize(de)?;
        Ok(LifetimeMap {
            allow: w.allow.0,
            deny: w.deny.0,
            cancelled: w.cancelled.map(|c| c.0),
        })
    }
}

impl Serialize for LifetimeMap {
    fn serialize<S: serde::Serializer>(&self, ser: S) -> std::result::Result<S::Ok, S::Error> {
        use serde::ser::SerializeMap;
        let mut n = 2;
        if self.cancelled.is_some() {
            n += 1;
        }
        let mut m = ser.serialize_map(Some(n))?;
        let allow = BranchAdapter(self.allow.clone());
        let deny = BranchAdapter(self.deny.clone());
        m.serialize_entry("allow", &allow)?;
        m.serialize_entry("deny", &deny)?;
        if let Some(c) = &self.cancelled {
            let c = BranchAdapter(c.clone());
            m.serialize_entry("cancelled", &c)?;
        }
        m.end()
    }
}

impl FromStr for BareLifetime {
    type Err = String;
    fn from_str(s: &str) -> std::result::Result<Self, Self::Err> {
        match s {
            "per_call" => Ok(BareLifetime::PerCall),
            "per_turn" => Ok(BareLifetime::PerTurn),
            "per_session" => Ok(BareLifetime::PerSession),
            "per_request" => Ok(BareLifetime::PerRequest),
            other => Err(format!("unknown lifetime keyword `{}`", other)),
        }
    }
}

/// Parse a [`Lifetime`] from a JSON / YAML-shaped value.
///
/// Accepts both grammar forms:
///
/// * **Bare (§9.1.1)** — a string like `"per_call"` / `"per_turn"` /
///   `"per_session"` / `"per_request"`, or a map `{ "for": "<duration>" }`,
///   `{ "until_event": "<event_id>" | [...] }`.
/// * **Map (§9.1.2)** — `{ "allow": <bare>, "deny": <bare>, "cancelled"?: <bare> }`.
///
/// The parser is the single canonical entry point used by every
/// language SDK (Python / Node / .NET) through their FFI layer. SDK
/// shells MUST route through this function rather than implementing
/// their own lifetime grammar parser.
pub fn parse_lifetime(value: serde_json::Value) -> Result<Lifetime, String> {
    serde_json::from_value(value).map_err(|e| e.to_string())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_iso8601_durations() {
        assert_eq!(parse_duration("PT1H").unwrap(), Duration::hours(1));
        assert_eq!(
            parse_duration("PT1H30M").unwrap(),
            Duration::hours(1) + Duration::minutes(30)
        );
        assert_eq!(parse_duration("P2D").unwrap(), Duration::days(2));
    }

    #[test]
    fn parses_shorthand_durations() {
        assert_eq!(parse_duration("3h").unwrap(), Duration::hours(3));
        assert_eq!(parse_duration("30m").unwrap(), Duration::minutes(30));
        assert_eq!(
            parse_duration("500ms").unwrap(),
            Duration::milliseconds(500)
        );
        assert_eq!(parse_duration("1h30m").unwrap(), Duration::minutes(90));
    }

    #[test]
    fn rejects_bad_duration() {
        assert!(parse_duration("").is_err());
        assert!(parse_duration("5x").is_err());
        assert!(parse_duration("h").is_err());
    }

    #[test]
    fn deserializes_keyword_lifetime() {
        let l: Lifetime = serde_yaml::from_str("per_call").unwrap();
        assert!(matches!(l, Lifetime::Bare(BareLifetime::PerCall)));
    }

    #[test]
    fn deserializes_for_lifetime() {
        let l: Lifetime = serde_yaml::from_str("for: 3h\n").unwrap();
        match l {
            Lifetime::Bare(BareLifetime::For(d)) => assert_eq!(d, Duration::hours(3)),
            _ => panic!(),
        }
    }

    #[test]
    fn deserializes_until_event_single_or_many() {
        let l: Lifetime = serde_yaml::from_str("until_event: session.end\n").unwrap();
        assert!(matches!(l, Lifetime::Bare(BareLifetime::UntilEvent(ids)) if ids.len() == 1));
        let l: Lifetime =
            serde_yaml::from_str("until_event:\n  - session.end\n  - turn.end\n").unwrap();
        assert!(matches!(l, Lifetime::Bare(BareLifetime::UntilEvent(ids)) if ids.len() == 2));
    }

    #[test]
    fn deserializes_map_lifetime() {
        let yaml = "
allow: per_call
deny:
  until_event:
    - session.end
";
        let l: Lifetime = serde_yaml::from_str(yaml).unwrap();
        match l {
            Lifetime::Map(m) => {
                assert_eq!(m.allow, LifetimeBranch::Bare(BareLifetime::PerCall));
                assert!(matches!(
                    m.deny,
                    LifetimeBranch::Bare(BareLifetime::UntilEvent(_))
                ));
                assert!(m.cancelled.is_none());
            }
            _ => panic!(),
        }
    }

    #[test]
    fn rejects_until_event_unknown_prefix() {
        let err = serde_yaml::from_str::<Lifetime>("until_event: foo.bar\n").unwrap_err();
        let s = err.to_string();
        assert!(
            s.contains("foo.bar") || s.contains("UnknownPrefix") || s.contains("closed-namespace")
        );
    }

    // ── Review-amendment tests (P1.6, P1.8) ─────────────────────────────

    #[test]
    fn p1_6_negative_shorthand_duration_rejected() {
        assert!(parse_duration("-5h").is_err());
    }

    #[test]
    fn p1_6_negative_iso_duration_rejected() {
        assert!(parse_duration("PT-5H").is_err());
    }

    #[test]
    fn p1_6_zero_duration_succeeds() {
        let d = parse_duration("0h").unwrap();
        assert_eq!(d, Duration::zero());
    }

    #[test]
    fn p1_8_empty_iso_p_rejected() {
        assert!(parse_duration("P").is_err());
    }

    #[test]
    fn p1_8_empty_iso_pt_rejected() {
        assert!(parse_duration("PT").is_err());
    }

    #[test]
    fn p1_8_us_unit_rejected() {
        assert!(parse_duration("100us").is_err());
    }

    #[test]
    fn p1_8_ns_unit_rejected() {
        assert!(parse_duration("100ns").is_err());
    }

    #[test]
    fn p1_8_ms_unit_accepted() {
        let d = parse_duration("500ms").unwrap();
        assert_eq!(d, Duration::milliseconds(500));
    }
}
