//! `configurations[]` block (§6) — type-discriminated routing.
//!
//! This module models the static configuration shape; runtime dispatch
//! lives in [`crate::resolver_runtime::delegate_kind`]. The deserializer
//! enforces the §6.2 routing matrix:
//!
//! - `llm` requires `model`
//! - `http_endpoint` requires `endpoint`
//! - `mcp_server` requires `tool` plus an endpoint or registered provider
//! - `a2a_agent` requires `agent_id` plus endpoint/provider
//! - `default: true` is rejected on `http_endpoint`/`mcp_server`/`a2a_agent`
//!
//! Same-`id` redefinition across the `extends:` chain is last-wins per
//! field, but `type:` MUST NOT change (§6.7) — enforced in `merge.rs`.

use std::collections::HashMap;

use serde::{Deserialize, Serialize};

use super::resources::LogBlock;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ConfigurationType {
    Llm,
    Classifier,
    HttpEndpoint,
    McpServer,
    A2aAgent,
}

impl ConfigurationType {
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Llm => "llm",
            Self::Classifier => "classifier",
            Self::HttpEndpoint => "http_endpoint",
            Self::McpServer => "mcp_server",
            Self::A2aAgent => "a2a_agent",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "UPPERCASE")]
pub enum HttpMethod {
    Get,
    Post,
}

/// `on_error` policy on a configuration entry (§6.2).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ConfigOnError {
    Block,
    Allow,
}

/// One entry in the `configurations[]` block (§6.2).
///
/// Field validity per the routing matrix is enforced at deserialization time
/// — any field set on the wrong type raises a clear schema error.
#[derive(Debug, Clone, Serialize, PartialEq)]
#[serde(deny_unknown_fields)]
pub struct ShieldConfiguration {
    pub id: String,
    #[serde(rename = "type")]
    pub config_type: ConfigurationType,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub default: Option<bool>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub provider: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub provider_config: Option<serde_json::Value>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub endpoint: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub timeout: Option<u32>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub on_error: Option<ConfigOnError>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub on_error_log: Option<LogBlock>,
    #[serde(default, skip_serializing_if = "HashMap::is_empty")]
    pub headers: HashMap<String, String>,

    // type=llm
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub model: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub max_tokens: Option<u32>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub api_key_env: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub metadata: Option<serde_json::Value>,

    // type=classifier
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub threshold: Option<f64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub method: Option<HttpMethod>,
    /// Per-category score thresholds for classifiers that emit
    /// per-category scores (§11.12.4). When present and non-empty,
    /// the bundled provider implementations restrict their failure
    /// check to listed categories — unlisted high scores cannot
    /// trigger the verdict via the global `threshold` field. When
    /// absent or empty, the global `threshold` plus the provider's
    /// native flagging signal apply.
    #[serde(default, skip_serializing_if = "HashMap::is_empty")]
    pub category_thresholds: HashMap<String, f64>,

    // type=a2a_agent
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub agent_id: Option<String>,

    // type=mcp_server
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub tool: Option<String>,
}

impl<'de> Deserialize<'de> for ShieldConfiguration {
    fn deserialize<D: serde::Deserializer<'de>>(de: D) -> std::result::Result<Self, D::Error> {
        // Helper struct mirrors the public fields with serde defaults.
        #[derive(Deserialize)]
        #[serde(deny_unknown_fields)]
        struct H {
            id: String,
            #[serde(rename = "type")]
            config_type: ConfigurationType,
            #[serde(default)]
            default: Option<bool>,
            #[serde(default)]
            provider: Option<String>,
            #[serde(default)]
            provider_config: Option<serde_json::Value>,
            #[serde(default)]
            endpoint: Option<String>,
            #[serde(default)]
            timeout: Option<u32>,
            #[serde(default)]
            on_error: Option<ConfigOnError>,
            #[serde(default)]
            on_error_log: Option<LogBlock>,
            #[serde(default)]
            headers: HashMap<String, String>,
            #[serde(default)]
            model: Option<String>,
            #[serde(default)]
            max_tokens: Option<u32>,
            #[serde(default)]
            api_key_env: Option<String>,
            #[serde(default)]
            metadata: Option<serde_json::Value>,
            #[serde(default)]
            threshold: Option<f64>,
            #[serde(default)]
            method: Option<HttpMethod>,
            #[serde(default)]
            category_thresholds: HashMap<String, f64>,
            #[serde(default)]
            agent_id: Option<String>,
            #[serde(default)]
            tool: Option<String>,
        }

        let h = H::deserialize(de)?;

        // §6.2 routing matrix.
        let kind = h.config_type;
        let id = &h.id;

        if id.is_empty() {
            return Err(serde::de::Error::custom(
                "configuration: `id` must be non-empty",
            ));
        }

        // default: true allowed only on llm/classifier.
        if h.default == Some(true)
            && matches!(
                kind,
                ConfigurationType::HttpEndpoint
                    | ConfigurationType::McpServer
                    | ConfigurationType::A2aAgent,
            )
        {
            return Err(serde::de::Error::custom(format!(
                "configuration `{}`: `default: true` is permitted only on `llm` or `classifier` (§6.2)",
                id
            )));
        }

        match kind {
            ConfigurationType::Llm => {
                if h.model.is_none() {
                    return Err(serde::de::Error::custom(format!(
                        "configuration `{}` of type `llm`: `model` is required (§6.2)",
                        id
                    )));
                }
            }
            ConfigurationType::Classifier => {
                // endpoint OR registered provider; we cannot verify provider
                // registration at load time without a registry, so accept
                // either being present.
                if h.endpoint.is_none() && h.provider.is_none() {
                    return Err(serde::de::Error::custom(format!(
                        "configuration `{}` of type `classifier`: requires `endpoint` or a registered `provider` (§6.2)",
                        id
                    )));
                }
            }
            ConfigurationType::HttpEndpoint => {
                if h.endpoint.is_none() {
                    return Err(serde::de::Error::custom(format!(
                        "configuration `{}` of type `http_endpoint`: `endpoint` is required (§6.2)",
                        id
                    )));
                }
            }
            ConfigurationType::McpServer => {
                if h.tool.is_none() {
                    return Err(serde::de::Error::custom(format!(
                        "configuration `{}` of type `mcp_server`: `tool` is required (§6.2)",
                        id
                    )));
                }
                if h.endpoint.is_none() && h.provider.is_none() {
                    return Err(serde::de::Error::custom(format!(
                        "configuration `{}` of type `mcp_server`: requires `endpoint` or a registered `provider` (§6.2)",
                        id
                    )));
                }
            }
            ConfigurationType::A2aAgent => {
                if h.agent_id.is_none() {
                    return Err(serde::de::Error::custom(format!(
                        "configuration `{}` of type `a2a_agent`: `agent_id` is required (§6.2)",
                        id
                    )));
                }
                if h.endpoint.is_none() && h.provider.is_none() {
                    return Err(serde::de::Error::custom(format!(
                        "configuration `{}` of type `a2a_agent`: requires `endpoint` or a registered `provider` (§6.2)",
                        id
                    )));
                }
            }
        }

        if let Some(t) = h.timeout {
            if t == 0 {
                return Err(serde::de::Error::custom(format!(
                    "configuration `{}`: `timeout` must be a positive integer (§6.2)",
                    id
                )));
            }
        }

        Ok(ShieldConfiguration {
            id: h.id,
            config_type: h.config_type,
            default: h.default,
            provider: h.provider,
            provider_config: h.provider_config,
            endpoint: h.endpoint,
            timeout: h.timeout,
            on_error: h.on_error,
            on_error_log: h.on_error_log,
            headers: h.headers,
            model: h.model,
            max_tokens: h.max_tokens,
            api_key_env: h.api_key_env,
            metadata: h.metadata,
            threshold: h.threshold,
            method: h.method,
            category_thresholds: h.category_thresholds,
            agent_id: h.agent_id,
            tool: h.tool,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_llm_config() {
        let yaml = "
id: default-llm
type: llm
provider: anthropic.claude
model: claude-3-5-haiku
default: true
";
        let c: ShieldConfiguration = serde_yaml::from_str(yaml).unwrap();
        assert_eq!(c.config_type, ConfigurationType::Llm);
        assert_eq!(c.default, Some(true));
    }

    #[test]
    fn rejects_llm_without_model() {
        let err = serde_yaml::from_str::<ShieldConfiguration>("id: x\ntype: llm\n")
            .unwrap_err()
            .to_string();
        assert!(err.contains("`model` is required"));
    }

    #[test]
    fn rejects_default_on_http_endpoint() {
        let yaml = "
id: x
type: http_endpoint
endpoint: \"https://example.com\"
default: true
";
        let err = serde_yaml::from_str::<ShieldConfiguration>(yaml)
            .unwrap_err()
            .to_string();
        assert!(err.contains("default"));
    }

    #[test]
    fn rejects_a2a_without_agent_id() {
        let yaml = "id: x\ntype: a2a_agent\nendpoint: https://e\n";
        let err = serde_yaml::from_str::<ShieldConfiguration>(yaml)
            .unwrap_err()
            .to_string();
        assert!(err.contains("agent_id"));
    }

    #[test]
    fn rejects_zero_timeout() {
        let yaml = "id: x\ntype: llm\nmodel: m\ntimeout: 0\n";
        let err = serde_yaml::from_str::<ShieldConfiguration>(yaml)
            .unwrap_err()
            .to_string();
        assert!(err.contains("timeout"));
    }

    #[test]
    fn rejects_unknown_field() {
        let yaml = "id: x\ntype: llm\nmodel: m\nbogus: 1\n";
        let err = serde_yaml::from_str::<ShieldConfiguration>(yaml)
            .unwrap_err()
            .to_string();
        assert!(err.contains("bogus"));
    }
}
