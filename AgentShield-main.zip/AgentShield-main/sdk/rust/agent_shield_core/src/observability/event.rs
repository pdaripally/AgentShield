//! Structured log event schema (`spec/SPECIFICATION.md` §19.2).
//!
//! [`ShieldLogEvent`] is the canonical on-the-wire payload that every
//! [`ObservabilityProvider`](super::provider::ObservabilityProvider)
//! receives. The shape uses closed enums for the spec-defined
//! dimensions (severity / event type / stage / action) and an open
//! `attributes` map keyed by the `agent_shield.*` namespace from §19.3.

use std::collections::HashMap;

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use serde_json::Value;

pub use crate::guard_policy::Action;

// ── LogAction ───────────────────────────────────────────────────────

/// Closed enum reflecting the §19.1 / §19.2 `action` taxonomy in log
/// events. Distinct from [`crate::guard_policy::Action`] (which is the
/// guard-policy enforcement decision) because observability also needs an
/// `allow` value: per §19.1 a passed evaluation — and per §12.6 a
/// failure suppressed by `allowed_when:` — MUST be logged with
/// `action: allow`. Guard-policy authors cannot write `action: allow`, so
/// `Action` deliberately does not carry that variant.
///
/// `RequireApproval` (#14) is emitted by the shadow-mode resolver
/// suppression audit path.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum LogAction {
    Allow,
    Block,
    Redact,
    Warn,
    Append,
    Prepend,
    DeclassifyTo,
    RequireApproval,
}

impl LogAction {
    pub fn as_str(&self) -> &'static str {
        match self {
            LogAction::Allow => "allow",
            LogAction::Block => "block",
            LogAction::Redact => "redact",
            LogAction::Warn => "warn",
            LogAction::Append => "append",
            LogAction::Prepend => "prepend",
            LogAction::DeclassifyTo => "declassify_to",
            LogAction::RequireApproval => "require_approval",
        }
    }

    /// `true` for every action except `allow`. The dispatcher uses
    /// this to decide whether to stamp `enforced` on the log event
    /// (#14).
    pub fn is_enforceable(&self) -> bool {
        !matches!(self, LogAction::Allow)
    }
}

impl From<Action> for LogAction {
    fn from(a: Action) -> Self {
        match a {
            Action::Block => LogAction::Block,
            Action::Redact => LogAction::Redact,
            Action::Warn => LogAction::Warn,
            Action::Append => LogAction::Append,
            Action::Prepend => LogAction::Prepend,
            Action::DeclassifyTo => LogAction::DeclassifyTo,
        }
    }
}

// ── Severity ────────────────────────────────────────────────────────

/// Closed severity enum per spec §19.1.
///
/// A typed enum so providers can dispatch on severity without string
/// compares and so the loader can reject unknown severity strings at
/// parse time.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Severity {
    Critical,
    High,
    Medium,
    Low,
    Info,
}

impl Severity {
    pub fn as_str(&self) -> &'static str {
        match self {
            Severity::Critical => "critical",
            Severity::High => "high",
            Severity::Medium => "medium",
            Severity::Low => "low",
            Severity::Info => "info",
        }
    }

    /// Parse a spec-defined severity literal. Returns `None` for unknown
    /// values — callers decide whether to reject or default to `medium`.
    pub fn parse(s: &str) -> Option<Self> {
        match s {
            "critical" => Some(Severity::Critical),
            "high" => Some(Severity::High),
            "medium" => Some(Severity::Medium),
            "low" => Some(Severity::Low),
            "info" => Some(Severity::Info),
            _ => None,
        }
    }

    /// "Highest wins" composability rule from §19.6: when multiple tiers
    /// declare the same log entry, the strongest severity wins.
    pub fn rank(&self) -> u8 {
        match self {
            Severity::Info => 0,
            Severity::Low => 1,
            Severity::Medium => 2,
            Severity::High => 3,
            Severity::Critical => 4,
        }
    }

    /// Returns the more severe of `self` and `other` per §19.6.
    pub fn max(self, other: Severity) -> Severity {
        if self.rank() >= other.rank() {
            self
        } else {
            other
        }
    }
}

// ── Stage ───────────────────────────────────────────────────────────

/// The five validation stages per spec §15. Mirrors
/// [`crate::guard_policy::StageFlavor`] but with snake_case serde
/// renaming so it round-trips through JSON as the spec strings.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Stage {
    Input,
    State,
    ToolExecution,
    PostTool,
    Output,
}

impl Stage {
    pub fn as_str(&self) -> &'static str {
        match self {
            Stage::Input => "input",
            Stage::State => "state",
            Stage::ToolExecution => "tool_execution",
            Stage::PostTool => "post_tool",
            Stage::Output => "output",
        }
    }

    pub fn parse(s: &str) -> Option<Self> {
        match s {
            "input" => Some(Stage::Input),
            "state" => Some(Stage::State),
            "tool_execution" => Some(Stage::ToolExecution),
            "post_tool" => Some(Stage::PostTool),
            "output" => Some(Stage::Output),
            _ => None,
        }
    }

    /// 1-based stage number per §15. Used in attribute serialization where
    /// numeric stage indices are useful (e.g. metric labels).
    pub fn ordinal(&self) -> u8 {
        match self {
            Stage::Input => 1,
            Stage::State => 2,
            Stage::ToolExecution => 3,
            Stage::PostTool => 4,
            Stage::Output => 5,
        }
    }
}

// ── EventType ───────────────────────────────────────────────────────

/// Closed enum reflecting the §19.2 `event_type` taxonomy plus the
/// closed-namespace bus events from §9.3 that get mirrored into the log
/// stream per §19.5.
///
/// `event_type` is closed so providers can dispatch on it. Free-form
/// taxonomy belongs in [`ShieldLogEvent::category`].
///
/// Wire strings follow §19.2 verbatim:
/// - `validation_triggered` for guard-policy evaluations.
/// - `call_blocked` for stage gating verdicts that produced a deny.
/// - `resolution_invoked` for resolver invocations (§11.9).
/// - `guard_policy_activated` / `_deactivated` / `_passed` / `_failed`
///   for closed-namespace `guard_policy.*` mirroring.
/// - `approval_<outcome>` mirrors the `approval.<variable>.<outcome>`
///   bus events.
/// - `incident_emitted`, `event_emitted`, `event_cleared`,
///   `variable_changed`, `load_error`, `runtime_error`, `warning`, `info`
///   round out the diagnostic / mirroring set.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum EventType {
    // ── Validation lifecycle (§19.2 explicit list) ────────────────
    /// A guard-policy `evaluate_when[]` entry was evaluated against an
    /// input/state/output. Carries the verdict in `action` (allow ⇒ none).
    /// Wire string: `validation_triggered` per §19.2.
    #[serde(rename = "validation_triggered")]
    GuardrailEvaluation,
    /// A gating-tier verdict that produced a `block` action — covers the
    /// `call_blocked` flavor in §19.2. Allow verdicts use
    /// [`EventType::GuardrailEvaluation`] to match the spec's two-name
    /// taxonomy (`validation_triggered` for the audit, `call_blocked` only
    /// when a call was actually blocked).
    #[serde(rename = "call_blocked")]
    GatingVerdict,

    // ── Resolver lifecycle (§11.9) ────────────────────────────────
    /// A resolver was invoked. Mandatory audit-log event per §11.9 — emitted
    /// for every resolver call regardless of decision. Wire string:
    /// `resolution_invoked` per §11.9 / §19.2.
    #[serde(rename = "resolution_invoked")]
    ResolverInvoked,

    // ── Closed-namespace mirroring (§19.5 → §9.3) ────────────────
    /// Bus event `Emitted` was mirrored into the log stream.
    #[serde(rename = "event_emitted")]
    EventEmitted,
    /// Bus event was cleared (explicit / session-end / expiry / until_event).
    #[serde(rename = "event_cleared")]
    EventCleared,
    /// `variable.<name>.changed` bus event mirror — split out so log
    /// pipelines can route variable mutations independently.
    #[serde(rename = "variable_changed")]
    VariableChanged,
    /// `guard_policy.<name>.activated`. Wire string `guard_policy_activated`
    /// per §19.2.
    #[serde(rename = "guard_policy_activated")]
    GuardPolicyActivated,
    /// `guard_policy.<name>.deactivated`. Wire string
    /// `guard_policy_deactivated` per §19.2.
    #[serde(rename = "guard_policy_deactivated")]
    GuardPolicyDeactivated,
    /// `guard_policy.<name>.passed` — bypass via `allowed_when` also flows
    /// through here per §12.6.
    #[serde(rename = "guard_policy_passed")]
    GuardPolicyPassed,
    /// `guard_policy.<name>.failed`.
    #[serde(rename = "guard_policy_failed")]
    GuardPolicyFailed,
    /// `approval.<variable>.allow`.
    #[serde(rename = "approval_allowed")]
    ApprovalAllowed,
    /// `approval.<variable>.deny`.
    #[serde(rename = "approval_denied")]
    ApprovalDenied,
    /// `approval.<variable>.cancelled`.
    #[serde(rename = "approval_cancelled")]
    ApprovalCancelled,
    /// `incident.<name>` — author-defined incident events.
    #[serde(rename = "incident_emitted")]
    IncidentEmitted,

    // ── Diagnostics ──────────────────────────────────────────────
    /// Configuration load failed. Always severity `critical` per §19.1.
    #[serde(rename = "load_error")]
    LoadError,
    /// Internal runtime error (resolver crash, classifier timeout, etc.).
    #[serde(rename = "runtime_error")]
    RuntimeError,
    /// Generic warning — used by `log_warning` and warn-mode bypass paths.
    #[serde(rename = "warning")]
    Warning,
    /// Generic informational event — boundary events (`session.start`,
    /// `turn.start`, etc.) and audit traces.
    #[serde(rename = "info")]
    Info,
}

impl EventType {
    pub fn as_str(&self) -> &'static str {
        match self {
            EventType::GuardrailEvaluation => "validation_triggered",
            EventType::GatingVerdict => "call_blocked",
            EventType::ResolverInvoked => "resolution_invoked",
            EventType::EventEmitted => "event_emitted",
            EventType::EventCleared => "event_cleared",
            EventType::VariableChanged => "variable_changed",
            EventType::GuardPolicyActivated => "guard_policy_activated",
            EventType::GuardPolicyDeactivated => "guard_policy_deactivated",
            EventType::GuardPolicyPassed => "guard_policy_passed",
            EventType::GuardPolicyFailed => "guard_policy_failed",
            EventType::ApprovalAllowed => "approval_allowed",
            EventType::ApprovalDenied => "approval_denied",
            EventType::ApprovalCancelled => "approval_cancelled",
            EventType::IncidentEmitted => "incident_emitted",
            EventType::LoadError => "load_error",
            EventType::RuntimeError => "runtime_error",
            EventType::Warning => "warning",
            EventType::Info => "info",
        }
    }

    pub fn parse(s: &str) -> Option<Self> {
        match s {
            "validation_triggered" => Some(EventType::GuardrailEvaluation),
            "call_blocked" => Some(EventType::GatingVerdict),
            "resolution_invoked" => Some(EventType::ResolverInvoked),
            "event_emitted" => Some(EventType::EventEmitted),
            "event_cleared" => Some(EventType::EventCleared),
            "variable_changed" => Some(EventType::VariableChanged),
            "guard_policy_activated" => Some(EventType::GuardPolicyActivated),
            "guard_policy_deactivated" => Some(EventType::GuardPolicyDeactivated),
            "guard_policy_passed" => Some(EventType::GuardPolicyPassed),
            "guard_policy_failed" => Some(EventType::GuardPolicyFailed),
            "approval_allowed" => Some(EventType::ApprovalAllowed),
            "approval_denied" => Some(EventType::ApprovalDenied),
            "approval_cancelled" => Some(EventType::ApprovalCancelled),
            "incident_emitted" => Some(EventType::IncidentEmitted),
            "load_error" => Some(EventType::LoadError),
            "runtime_error" => Some(EventType::RuntimeError),
            "warning" => Some(EventType::Warning),
            "info" => Some(EventType::Info),
            _ => None,
        }
    }
}

// ── Resource ref ────────────────────────────────────────────────────

/// What kind of resource a log event refers to. Mirrors the §6 resource
/// taxonomy plus an `Other` escape hatch for resolver kinds (`human`,
/// `delegate`, etc.) that aren't tools/agents/endpoints.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ResourceKind {
    Tool,
    Agent,
    Endpoint,
    Other,
}

impl ResourceKind {
    pub fn as_str(&self) -> &'static str {
        match self {
            ResourceKind::Tool => "tool",
            ResourceKind::Agent => "agent",
            ResourceKind::Endpoint => "endpoint",
            ResourceKind::Other => "other",
        }
    }
}

/// A reference to the resource a log event was raised on.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ResourceRef {
    pub kind: ResourceKind,
    pub name: String,
}

impl ResourceRef {
    pub fn tool(name: impl Into<String>) -> Self {
        Self {
            kind: ResourceKind::Tool,
            name: name.into(),
        }
    }
    pub fn agent(name: impl Into<String>) -> Self {
        Self {
            kind: ResourceKind::Agent,
            name: name.into(),
        }
    }
    pub fn endpoint(pattern: impl Into<String>) -> Self {
        Self {
            kind: ResourceKind::Endpoint,
            name: pattern.into(),
        }
    }
    pub fn other(name: impl Into<String>) -> Self {
        Self {
            kind: ResourceKind::Other,
            name: name.into(),
        }
    }
}

// ── ShieldLogEvent ────────────────────────────────────────────────

/// The structured log event payload (§19.2).
///
/// Spec-defined attributes live in dedicated typed fields; everything else
/// goes into [`Self::attributes`] keyed by the `agent_shield.*` namespace.
/// The recommended way to populate `attributes` is via
/// [`crate::observability::AgentShieldAttributes`], which provides typed
/// setters for every spec-defined key.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ShieldLogEvent {
    pub timestamp: DateTime<Utc>,
    pub severity: Severity,
    pub event_type: EventType,
    pub category: String,

    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub stage: Option<Stage>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub action: Option<LogAction>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub guard_policy: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub evaluate_when_index: Option<usize>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub resource: Option<ResourceRef>,
    /// `tool` top-level alias from §19.2 — populated whenever
    /// [`Self::resource`] is a [`ResourceKind::Tool`]. Spec examples use
    /// the bare `tool:` key on log events; emitting both lets downstream
    /// pipelines key on either shape.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub tool: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub variable: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub event_id: Option<String>,

    pub correlation_id: String,
    pub session_id: String,
    /// `agent_id` top-level field from §19.2 — sourced from the loaded
    /// config's `metadata.name`. The dispatcher stamps this on every event
    /// it mints so downstream pipelines can attribute log events to the
    /// originating agent without parsing attribute keys.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub agent_id: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub user_id: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub tenant_id: Option<String>,

    /// Effective runtime mode (#14), stamped by the dispatcher on
    /// every event. `None` for mode-unaware dispatchers (test
    /// fixtures, pre-config tools).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub mode: Option<crate::shield_primitives::RuntimeMode>,

    /// Whether the action was actually applied (#14). `true` in
    /// active, `false` in shadow. Present only on action-bearing
    /// events; `None` for `action: allow` or pre-mode events.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub enforced: Option<bool>,

    pub message: String,

    #[serde(default, skip_serializing_if = "HashMap::is_empty")]
    pub attributes: HashMap<String, Value>,
}

impl ShieldLogEvent {
    /// Construct a minimal event. Most fields default to empty / `None`;
    /// callers populate the rest through builder-style setters or by
    /// merging in an [`AgentShieldAttributes`](super::attributes::AgentShieldAttributes).
    pub fn new(event_type: EventType, severity: Severity, category: impl Into<String>) -> Self {
        Self {
            timestamp: Utc::now(),
            severity,
            event_type,
            category: category.into(),
            stage: None,
            action: None,
            guard_policy: None,
            evaluate_when_index: None,
            resource: None,
            tool: None,
            variable: None,
            event_id: None,
            correlation_id: String::new(),
            session_id: String::new(),
            agent_id: None,
            user_id: None,
            tenant_id: None,
            mode: None,
            enforced: None,
            message: String::new(),
            attributes: HashMap::new(),
        }
    }

    // ── Builder-style setters ──────────────────────────────────────

    pub fn with_timestamp(mut self, ts: DateTime<Utc>) -> Self {
        self.timestamp = ts;
        self
    }

    pub fn with_stage(mut self, stage: Stage) -> Self {
        self.stage = Some(stage);
        self
    }

    pub fn with_action(mut self, action: impl Into<LogAction>) -> Self {
        self.action = Some(action.into());
        self
    }

    pub fn with_guard_policy(mut self, name: impl Into<String>) -> Self {
        self.guard_policy = Some(name.into());
        self
    }

    pub fn with_evaluate_when_index(mut self, idx: usize) -> Self {
        self.evaluate_when_index = Some(idx);
        self
    }

    pub fn with_resource(mut self, resource: ResourceRef) -> Self {
        // Populate the `tool` top-level alias whenever the resource is a
        // tool reference, per §19.2.
        if matches!(resource.kind, ResourceKind::Tool) {
            self.tool = Some(resource.name.clone());
        }
        self.resource = Some(resource);
        self
    }

    pub fn with_variable(mut self, var: impl Into<String>) -> Self {
        self.variable = Some(var.into());
        self
    }

    pub fn with_event_id(mut self, id: impl Into<String>) -> Self {
        self.event_id = Some(id.into());
        self
    }

    pub fn with_correlation_id(mut self, id: impl Into<String>) -> Self {
        self.correlation_id = id.into();
        self
    }

    pub fn with_session_id(mut self, id: impl Into<String>) -> Self {
        self.session_id = id.into();
        self
    }

    /// Stamp the agent identifier from `metadata.name` per §19.2.
    pub fn with_agent_id(mut self, id: impl Into<String>) -> Self {
        self.agent_id = Some(id.into());
        self
    }

    pub fn with_user_id(mut self, id: impl Into<String>) -> Self {
        self.user_id = Some(id.into());
        self
    }

    pub fn with_tenant_id(mut self, id: impl Into<String>) -> Self {
        self.tenant_id = Some(id.into());
        self
    }

    pub fn with_message(mut self, msg: impl Into<String>) -> Self {
        self.message = msg.into();
        self
    }

    /// Insert one `agent_shield.*` attribute. Use
    /// [`merge_attributes`](Self::merge_attributes) to bulk-import a built
    /// [`AgentShieldAttributes`](super::attributes::AgentShieldAttributes).
    pub fn with_attribute(mut self, key: impl Into<String>, value: Value) -> Self {
        self.attributes.insert(key.into(), value);
        self
    }

    /// Merge a pre-built map of `agent_shield.*` attributes into this event.
    pub fn merge_attributes(mut self, attrs: HashMap<String, Value>) -> Self {
        self.attributes.extend(attrs);
        self
    }

    /// Decorate this event with [OpenTelemetry GenAI semantic
    /// convention](https://opentelemetry.io/docs/specs/semconv/gen-ai/)
    /// attributes (`gen_ai.system`, `gen_ai.operation.name`,
    /// `gen_ai.response.finish_reason`) so any OTel exporter that
    /// consumes the event sees AgentShield in the same shape it sees
    /// LangChain / OpenAI / Anthropic / SK telemetry — no customer
    /// configuration required.
    ///
    /// Idempotent: existing values for the OTel keys are preserved
    /// (host code may have set them already; we never overwrite).
    ///
    /// Mapping:
    /// - `gen_ai.system` → always `"agent_shield"`
    /// - `gen_ai.operation.name` → `"guard"` (or `"guard.<stage>"`
    ///   when the event has a stage)
    /// - `gen_ai.response.finish_reason` → `"content_filter"` when
    ///   the event's action is `block` or `redact` (no value emitted
    ///   for `allow`/`warn`/`append`/`prepend` — those aren't
    ///   "response-finishing" outcomes)
    pub fn with_otel_genai_attributes(mut self) -> Self {
        use super::attributes::{
            GENAI_SYSTEM_AGENT_SHIELD, KEY_GENAI_OPERATION_NAME, KEY_GENAI_RESPONSE_FINISH_REASON,
            KEY_GENAI_SYSTEM,
        };

        self.attributes
            .entry(KEY_GENAI_SYSTEM.to_string())
            .or_insert_with(|| Value::from(GENAI_SYSTEM_AGENT_SHIELD));

        let op_name = match self.stage {
            Some(stage) => format!("guard.{}", stage.as_str()),
            None => "guard".to_string(),
        };
        self.attributes
            .entry(KEY_GENAI_OPERATION_NAME.to_string())
            .or_insert_with(|| Value::from(op_name));

        if matches!(
            self.action,
            Some(LogAction::Block) | Some(LogAction::Redact)
        ) {
            self.attributes
                .entry(KEY_GENAI_RESPONSE_FINISH_REASON.to_string())
                .or_insert_with(|| Value::from("content_filter"));
        }

        self
    }
}

// ── Tests ───────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn severity_round_trip_and_rank() {
        for s in [
            Severity::Critical,
            Severity::High,
            Severity::Medium,
            Severity::Low,
            Severity::Info,
        ] {
            assert_eq!(Severity::parse(s.as_str()), Some(s));
        }
        assert!(Severity::Critical.rank() > Severity::Info.rank());
        assert_eq!(Severity::Info.max(Severity::High), Severity::High);
        assert_eq!(Severity::Critical.max(Severity::Medium), Severity::Critical);
        assert_eq!(Severity::parse("bogus"), None);
    }

    #[test]
    fn stage_round_trip_and_ordinal() {
        for s in [
            Stage::Input,
            Stage::State,
            Stage::ToolExecution,
            Stage::PostTool,
            Stage::Output,
        ] {
            assert_eq!(Stage::parse(s.as_str()), Some(s));
        }
        assert_eq!(Stage::Input.ordinal(), 1);
        assert_eq!(Stage::Output.ordinal(), 5);
        assert_eq!(Stage::parse("bogus"), None);
    }

    #[test]
    fn event_type_round_trip_covers_all_variants() {
        let variants = [
            EventType::GuardrailEvaluation,
            EventType::GatingVerdict,
            EventType::ResolverInvoked,
            EventType::EventEmitted,
            EventType::EventCleared,
            EventType::VariableChanged,
            EventType::GuardPolicyActivated,
            EventType::GuardPolicyDeactivated,
            EventType::GuardPolicyPassed,
            EventType::GuardPolicyFailed,
            EventType::ApprovalAllowed,
            EventType::ApprovalDenied,
            EventType::ApprovalCancelled,
            EventType::IncidentEmitted,
            EventType::LoadError,
            EventType::RuntimeError,
            EventType::Warning,
            EventType::Info,
        ];
        for v in variants {
            assert_eq!(EventType::parse(v.as_str()), Some(v));
        }
        assert_eq!(EventType::parse("bogus"), None);
    }

    #[test]
    fn resource_ref_constructors_set_kind() {
        assert_eq!(ResourceRef::tool("send_email").kind, ResourceKind::Tool);
        assert_eq!(ResourceRef::agent("planner").kind, ResourceKind::Agent);
        assert_eq!(
            ResourceRef::endpoint("https://api/*").kind,
            ResourceKind::Endpoint
        );
        assert_eq!(ResourceRef::other("human").kind, ResourceKind::Other);
    }

    #[test]
    fn shield_log_event_serde_round_trip() {
        let mut attrs = HashMap::new();
        attrs.insert("agent_shield.event_type".into(), Value::from("warning"));
        attrs.insert("agent_shield.guard_policy.name".into(), Value::from("p1"));

        let ev = ShieldLogEvent::new(
            EventType::GuardPolicyFailed,
            Severity::High,
            "guardrail.evaluation",
        )
        .with_stage(Stage::State)
        .with_action(Action::Block)
        .with_guard_policy("send_requires_authorization")
        .with_evaluate_when_index(2)
        .with_resource(ResourceRef::tool("send_email"))
        .with_variable("approval_required")
        .with_event_id("guard_policy.send_requires_authorization.failed")
        .with_correlation_id("c-1")
        .with_session_id("s-1")
        .with_user_id("u-1")
        .with_tenant_id("t-1")
        .with_message("blocked")
        .merge_attributes(attrs);

        let json = serde_json::to_string(&ev).unwrap();
        let parsed: ShieldLogEvent = serde_json::from_str(&json).unwrap();
        assert_eq!(parsed.severity, Severity::High);
        assert_eq!(parsed.event_type, EventType::GuardPolicyFailed);
        assert_eq!(parsed.stage, Some(Stage::State));
        assert_eq!(parsed.action, Some(LogAction::Block));
        assert_eq!(parsed.evaluate_when_index, Some(2));
        assert_eq!(parsed.resource.as_ref().unwrap().name, "send_email");
        assert_eq!(parsed.variable.as_deref(), Some("approval_required"));
        assert_eq!(
            parsed.event_id.as_deref(),
            Some("guard_policy.send_requires_authorization.failed")
        );
        assert_eq!(parsed.attributes.len(), 2);
    }

    #[test]
    fn shield_log_event_minimal_omits_optional_fields() {
        let ev = ShieldLogEvent::new(EventType::Info, Severity::Info, "boundary")
            .with_correlation_id("c-1")
            .with_session_id("s-1")
            .with_message("session.start");
        let json = serde_json::to_value(&ev).unwrap();
        let obj = json.as_object().unwrap();
        assert!(!obj.contains_key("stage"));
        assert!(!obj.contains_key("action"));
        assert!(!obj.contains_key("guard_policy"));
        assert!(!obj.contains_key("evaluate_when_index"));
        assert!(!obj.contains_key("resource"));
        assert!(!obj.contains_key("tool"));
        assert!(!obj.contains_key("variable"));
        assert!(!obj.contains_key("event_id"));
        assert!(!obj.contains_key("agent_id"));
        assert!(!obj.contains_key("user_id"));
        assert!(!obj.contains_key("tenant_id"));
        assert!(!obj.contains_key("attributes"));
    }

    // ── OTel GenAI semantic-convention decoration ──────────────

    #[test]
    fn otel_decoration_sets_system_and_operation_for_block_events() {
        let ev = ShieldLogEvent::new(EventType::GuardPolicyFailed, Severity::High, "guardrail")
            .with_stage(Stage::State)
            .with_action(Action::Block)
            .with_otel_genai_attributes();
        assert_eq!(
            ev.attributes.get("gen_ai.system"),
            Some(&Value::from("agent_shield"))
        );
        assert_eq!(
            ev.attributes.get("gen_ai.operation.name"),
            Some(&Value::from("guard.state"))
        );
        assert_eq!(
            ev.attributes.get("gen_ai.response.finish_reason"),
            Some(&Value::from("content_filter"))
        );
    }

    #[test]
    fn otel_decoration_sets_finish_reason_for_redact() {
        let ev = ShieldLogEvent::new(EventType::GuardPolicyFailed, Severity::Medium, "guardrail")
            .with_stage(Stage::Output)
            .with_action(Action::Redact)
            .with_otel_genai_attributes();
        assert_eq!(
            ev.attributes.get("gen_ai.response.finish_reason"),
            Some(&Value::from("content_filter")),
            "redact action must emit finish_reason=content_filter so OTel exporters see it as a filtered response"
        );
        assert_eq!(
            ev.attributes.get("gen_ai.operation.name"),
            Some(&Value::from("guard.output"))
        );
    }

    #[test]
    fn otel_decoration_omits_finish_reason_for_warn_and_passes() {
        let warn_ev = ShieldLogEvent::new(EventType::Warning, Severity::Medium, "warn")
            .with_stage(Stage::Input)
            .with_action(Action::Warn)
            .with_otel_genai_attributes();
        assert!(
            !warn_ev
                .attributes
                .contains_key("gen_ai.response.finish_reason"),
            "warn is not a response-finishing outcome — finish_reason must NOT be set"
        );

        let allow_ev = ShieldLogEvent::new(EventType::GuardPolicyPassed, Severity::Info, "passed")
            .with_stage(Stage::Input)
            .with_otel_genai_attributes();
        assert!(!allow_ev
            .attributes
            .contains_key("gen_ai.response.finish_reason"));
    }

    #[test]
    fn otel_decoration_uses_bare_guard_when_no_stage() {
        let ev = ShieldLogEvent::new(EventType::Info, Severity::Info, "boundary")
            .with_otel_genai_attributes();
        assert_eq!(
            ev.attributes.get("gen_ai.operation.name"),
            Some(&Value::from("guard")),
            "events without a stage get the bare `guard` operation name"
        );
    }

    #[test]
    fn otel_decoration_is_idempotent_and_does_not_overwrite() {
        let mut attrs = HashMap::new();
        attrs.insert(
            "gen_ai.system".to_string(),
            Value::from("custom-host-system"),
        );
        let ev = ShieldLogEvent::new(EventType::GuardPolicyFailed, Severity::High, "guardrail")
            .with_stage(Stage::Input)
            .with_action(Action::Block)
            .merge_attributes(attrs)
            .with_otel_genai_attributes();
        assert_eq!(
            ev.attributes.get("gen_ai.system"),
            Some(&Value::from("custom-host-system")),
            "host-supplied gen_ai.system must not be overwritten"
        );
    }
}
