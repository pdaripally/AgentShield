//! Observability provider trait.
//!
//! The trait is synchronous — adding `async_trait` here would force
//! every provider author to pick up an async dependency. Async
//! providers can wrap a tokio handle internally:
//!
//! ```ignore
//! struct OtelProvider { handle: tokio::runtime::Handle }
//! impl ObservabilityProvider for OtelProvider {
//!     fn emit(&self, ev: ShieldLogEvent) {
//!         self.handle.spawn(async move { /* … */ });
//!     }
//! }
//! ```

use super::event::ShieldLogEvent;

/// Interface for observability backends.
///
/// Every spec-mandated log event (§19.5) is delivered through
/// [`Self::emit`]. Providers that need to flush buffers on shutdown can
/// override [`Self::shutdown`]; the default is a no-op.
pub trait ObservabilityProvider: Send + Sync {
    /// Emit one structured log event.
    fn emit(&self, event: ShieldLogEvent);

    /// Optional shutdown hook for buffered providers.
    fn shutdown(&self) {}
}

// ── Tests ───────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::super::event::{EventType, Severity};
    use super::*;

    #[test]
    fn provider_receives_emitted_event() {
        struct LocalCapture {
            count: std::sync::Mutex<usize>,
        }
        impl ObservabilityProvider for LocalCapture {
            fn emit(&self, _: ShieldLogEvent) {
                *self.count.lock().unwrap() += 1;
            }
        }
        let p = LocalCapture {
            count: std::sync::Mutex::new(0),
        };
        let trait_ref: &dyn ObservabilityProvider = &p;
        trait_ref.emit(ShieldLogEvent::new(EventType::Info, Severity::Info, "test"));
        assert_eq!(*p.count.lock().unwrap(), 1);
    }

    #[test]
    fn shutdown_default_is_noop() {
        struct BareProvider;
        impl ObservabilityProvider for BareProvider {
            fn emit(&self, _: ShieldLogEvent) {}
        }
        // Just calling it should compile and not panic.
        BareProvider.shutdown();
    }

    #[test]
    fn shutdown_override_is_called() {
        struct LocalProvider {
            n: std::sync::Mutex<usize>,
        }
        impl ObservabilityProvider for LocalProvider {
            fn emit(&self, _: ShieldLogEvent) {}
            fn shutdown(&self) {
                *self.n.lock().unwrap() += 1;
            }
        }
        let p = LocalProvider {
            n: std::sync::Mutex::new(0),
        };
        p.shutdown();
        assert_eq!(*p.n.lock().unwrap(), 1);
    }
}
