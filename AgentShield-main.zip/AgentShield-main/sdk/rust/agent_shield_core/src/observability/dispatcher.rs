//! Fan-out dispatcher that bridges the [`EventBus`] into the log stream
//! and exposes a direct emit hook for runtime sites that don't go through
//! the bus (resolver invocations, gating verdicts, load errors, etc.).
//!
//! ## Spec mapping
//!
//! - §19.5 — every closed-namespace event from §9.3 MUST be logged. The
//!   dispatcher's bus subscriber satisfies that requirement.
//! - §19.4 — resolver-invocation audit events are always emitted; runtimes
//!   call into [`ObservabilityDispatcher::emit`] directly for those.
//! - §19.6 — composability of `log:` blocks is handled at YAML-load /
//!   guard-policy-evaluation time, not in this module.
//!
//! ## Lifetime model
//!
//! The dispatcher is constructed with [`ObservabilityDispatcher::new`]
//! and returns an `Arc<Self>`. The constructor immediately registers a
//! subscriber on the [`EventBus`] that forwards every [`BusEvent`] into
//! the registered providers, so callers never need to wire up the bridge
//! manually. The subscriber holds a `Weak<Self>` reference so dispatcher
//! teardown breaks the cycle automatically.

use std::sync::{Arc, Mutex};

use serde_json::Value;

use super::attributes::AgentShieldAttributes;
use super::event::{EventType, ResourceKind, Severity, ShieldLogEvent};
use super::provider::ObservabilityProvider;
use crate::event_bus::{BusEvent, ClearCause, EventBus, SubscriberHandle};
use crate::events::{ApprovalEventKind, EventId, GpEventKind, ToolEventKind};

// ── Dispatcher ──────────────────────────────────────────────────────

/// Fan-out dispatcher routing log events to all registered providers
/// and bridging the closed-namespace [`EventBus`] into the log stream.
pub struct ObservabilityDispatcher {
    providers: Mutex<Vec<Arc<dyn ObservabilityProvider>>>,
    bus: EventBus,
    bus_subscriber: Mutex<Option<SubscriberHandle>>,
    /// `metadata.name` from the loaded config, stamped on every event the
    /// dispatcher mints (direct emit + bus-mirror) per §19.2 / §19.3.
    /// `None` for ad-hoc dispatchers built without a config (the test
    /// fixtures and downstream tools that emit before a config is loaded).
    agent_id: Option<String>,
    /// Effective `MergedConfig.mode` (#14). Stamped on every event;
    /// `None` for mode-unaware dispatchers.
    mode: Option<crate::shield_primitives::RuntimeMode>,
}

impl std::fmt::Debug for ObservabilityDispatcher {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("ObservabilityDispatcher")
            .field("providers", &self.provider_count())
            .finish_non_exhaustive()
    }
}

impl ObservabilityDispatcher {
    /// Build a new dispatcher and immediately subscribe it to `bus`. The
    /// dispatcher will not stamp an `agent_id` on emitted events; for
    /// production runtimes that want §19.2-conformant `agent_id` tagging,
    /// use [`ObservabilityDispatcher::with_agent_id`].
    ///
    /// The returned `Arc` owns the bus subscription. Dropping the last
    /// `Arc` releases the subscription via [`Drop`].
    pub fn new(bus: EventBus) -> Arc<Self> {
        Self::build(bus, None, None)
    }

    /// Build a dispatcher pre-configured with the loaded config's
    /// `metadata.name`. The dispatcher stamps `agent_id` on every event it
    /// mints (direct emit + bus-mirror) per §19.2 / §19.3.
    pub fn with_agent_id(bus: EventBus, agent_id: impl Into<String>) -> Arc<Self> {
        Self::build(bus, Some(agent_id.into()), None)
    }

    /// Build a dispatcher pre-configured with `metadata.name` and the
    /// effective [`RuntimeMode`] (#14). Stamps `agent_id`, `mode`, and
    /// (on action-bearing events) `enforced` on every minted event.
    ///
    /// [`RuntimeMode`]: crate::shield_primitives::RuntimeMode
    pub fn with_agent_id_and_mode(
        bus: EventBus,
        agent_id: impl Into<String>,
        mode: crate::shield_primitives::RuntimeMode,
    ) -> Arc<Self> {
        Self::build(bus, Some(agent_id.into()), Some(mode))
    }

    fn build(
        bus: EventBus,
        agent_id: Option<String>,
        mode: Option<crate::shield_primitives::RuntimeMode>,
    ) -> Arc<Self> {
        let dispatcher = Arc::new(Self {
            providers: Mutex::new(Vec::new()),
            bus: bus.clone(),
            bus_subscriber: Mutex::new(None),
            agent_id,
            mode,
        });

        // Register a bus subscriber that forwards into self via a Weak ref.
        // We use Weak so the dispatcher can be dropped without leaking.
        let weak = Arc::downgrade(&dispatcher);
        let handle = bus.subscribe(None, move |ev: &BusEvent| {
            if let Some(this) = weak.upgrade() {
                let log_ev = bus_event_to_log(ev, this.agent_id.as_deref());
                this.emit(log_ev);
            }
        });
        *dispatcher.bus_subscriber.lock().unwrap() = Some(handle);

        dispatcher
    }

    /// Returns the dispatcher's stamped `agent_id`, if configured.
    pub fn agent_id(&self) -> Option<&str> {
        self.agent_id.as_deref()
    }

    /// Effective runtime mode if configured (#14).
    pub fn mode(&self) -> Option<crate::shield_primitives::RuntimeMode> {
        self.mode
    }

    /// Register a provider. All future emits — direct or bus-mirrored —
    /// fan out to every registered provider.
    pub fn register_provider(&self, provider: Arc<dyn ObservabilityProvider>) {
        self.providers.lock().unwrap().push(provider);
    }

    /// Number of registered providers.
    pub fn provider_count(&self) -> usize {
        self.providers.lock().unwrap().len()
    }

    /// Borrow the bus this dispatcher is subscribed to. Used by callers
    /// that want to emit a bus event and have it flow through the log
    /// stream without setting up their own subscriber.
    pub fn bus(&self) -> &EventBus {
        &self.bus
    }

    /// Direct emission path for events that don't flow through the bus
    /// (resolver-invocation audits, load errors, gating verdicts). Stamps
    /// `agent_id`, `mode` (#14), and `enforced` on action-bearing events
    /// when not already set, and adds OTel GenAI semantic-convention
    /// attributes.
    pub fn emit(&self, mut event: ShieldLogEvent) {
        if event.agent_id.is_none() {
            if let Some(id) = &self.agent_id {
                event.agent_id = Some(id.clone());
                event
                    .attributes
                    .entry(super::attributes::KEY_AGENT_ID.to_string())
                    .or_insert_with(|| Value::from(id.clone()));
            }
        }
        if event.mode.is_none() {
            if let Some(m) = self.mode {
                event.mode = Some(m);
                event
                    .attributes
                    .entry(super::attributes::KEY_RUNTIME_MODE.to_string())
                    .or_insert_with(|| Value::from(m.as_wire_str()));
            }
        }
        if event.enforced.is_none() {
            if let (Some(action), Some(m)) = (event.action, self.mode) {
                if action.is_enforceable() {
                    let enforced = matches!(m, crate::shield_primitives::RuntimeMode::Active);
                    event.enforced = Some(enforced);
                    event
                        .attributes
                        .entry(super::attributes::KEY_ENFORCED.to_string())
                        .or_insert_with(|| Value::from(enforced));
                }
            }
        }
        event = event.with_otel_genai_attributes();
        let providers: Vec<Arc<dyn ObservabilityProvider>> = self.providers.lock().unwrap().clone();
        for p in &providers {
            p.emit(event.clone());
        }
    }

    /// Shutdown every registered provider. Safe to call more than once.
    pub fn shutdown(&self) {
        let providers: Vec<Arc<dyn ObservabilityProvider>> = self.providers.lock().unwrap().clone();
        for p in &providers {
            p.shutdown();
        }
    }
}

impl Drop for ObservabilityDispatcher {
    fn drop(&mut self) {
        if let Some(handle) = self.bus_subscriber.lock().unwrap().take() {
            self.bus.unsubscribe(handle);
        }
    }
}

// ── Bus → log bridge ────────────────────────────────────────────────

/// Convert a [`BusEvent`] into a [`ShieldLogEvent`] per §19.5. When
/// `agent_id` is supplied the dispatcher's configured `metadata.name` is
/// stamped on the resulting event (typed field + `agent_shield.agent_id`
/// attribute) per §19.2 / §19.3.
///
/// Severities follow §19.1's "warn-mode is high by default" guidance and
/// the broader "security-relevant events warrant elevated severity"
/// principle: failures and incidents map to `high`; denials/cancels to
/// `medium`; boundary events (`session.start`, `turn.start`, etc.) to
/// `info`.
fn bus_event_to_log(ev: &BusEvent, agent_id: Option<&str>) -> ShieldLogEvent {
    let (mut log, session_id) = match ev {
        BusEvent::Emitted {
            session_id,
            event_id,
            payload,
            refreshed,
        } => (
            emitted_to_log(event_id, payload.as_ref(), *refreshed),
            session_id,
        ),
        BusEvent::Cleared {
            session_id,
            event_id,
            cause,
        } => (cleared_to_log(event_id, *cause), session_id),
    };
    // §19.2: every bus-mirrored event MUST carry the originating
    // `session_id` so multi-session pipelines can attribute log events
    // to the right session.
    log.session_id = session_id.as_str().to_string();
    if let Some(id) = agent_id {
        log.agent_id = Some(id.to_string());
        log.attributes
            .entry(super::attributes::KEY_AGENT_ID.to_string())
            .or_insert_with(|| Value::from(id.to_string()));
    }
    log.with_otel_genai_attributes()
}

/// Categorize an [`EventId`] for log routing — kept stable so log
/// pipelines can filter on `category` without depending on the exact
/// event-id string.
fn category_for_event(id: &EventId) -> &'static str {
    match id {
        EventId::SessionStart | EventId::SessionEnd => "lifecycle.session",
        EventId::TurnStart | EventId::TurnEnd => "lifecycle.turn",
        EventId::RequestStart | EventId::RequestEnd => "lifecycle.request",
        EventId::Tool { .. } => "resource.tool",
        EventId::Endpoint { .. } => "resource.endpoint",
        EventId::Agent { .. } => "resource.agent",
        EventId::VariableChanged { .. } => "variable.changed",
        EventId::GuardPolicy { .. } => "guard_policy",
        EventId::Approval { .. } => "approval",
        EventId::Incident { .. } => "incident",
        EventId::Ifc { .. } => "ifc",
    }
}

fn event_id_to_string(id: &EventId) -> String {
    match id {
        EventId::SessionStart => "session.start".to_string(),
        EventId::SessionEnd => "session.end".to_string(),
        EventId::TurnStart => "turn.start".to_string(),
        EventId::TurnEnd => "turn.end".to_string(),
        EventId::RequestStart => "request.start".to_string(),
        EventId::RequestEnd => "request.end".to_string(),
        EventId::Tool { name, kind } => format!("tool.{}.{}", name, kind.as_str()),
        EventId::Endpoint { pattern, kind } => format!("endpoint.{}.{}", pattern, kind.as_str()),
        EventId::Agent { name, kind } => format!("agent.{}.{}", name, kind.as_str()),
        EventId::VariableChanged { name } => format!("variable.{}.changed", name),
        EventId::GuardPolicy { name, kind } => format!("guard_policy.{}.{}", name, kind.as_str()),
        EventId::Approval { variable, kind } => format!("approval.{}.{}", variable, kind.as_str()),
        EventId::Incident { name } => format!("incident.{}", name),
        EventId::Ifc { kind } => format!("ifc.{}", kind.as_str()),
    }
}

/// Severity for an `Emitted` notification. Failures/incidents elevate to
/// `high`; boundary events stay at `info`.
fn severity_for_emitted(id: &EventId) -> Severity {
    match id {
        EventId::Tool {
            kind: ToolEventKind::Failure,
            ..
        }
        | EventId::Endpoint {
            kind: ToolEventKind::Failure,
            ..
        }
        | EventId::Agent {
            kind: ToolEventKind::Failure,
            ..
        } => Severity::Medium,

        EventId::GuardPolicy {
            kind: GpEventKind::Failed,
            ..
        }
        | EventId::Incident { .. } => Severity::High,

        EventId::Approval {
            kind: ApprovalEventKind::Deny,
            ..
        }
        | EventId::Approval {
            kind: ApprovalEventKind::Cancelled,
            ..
        } => Severity::Medium,

        EventId::Approval {
            kind: ApprovalEventKind::Allow,
            ..
        } => Severity::Info,

        EventId::GuardPolicy {
            kind: GpEventKind::Activated | GpEventKind::Deactivated | GpEventKind::Passed,
            ..
        } => Severity::Info,

        // Boundary / variable / called / success events all default to info.
        _ => Severity::Info,
    }
}

/// EventType for an `Emitted` notification. Spec-defined `event_type`s
/// are taken; everything else maps to the generic `EventEmitted`.
fn event_type_for_emitted(id: &EventId) -> EventType {
    match id {
        EventId::VariableChanged { .. } => EventType::VariableChanged,
        EventId::GuardPolicy {
            kind: GpEventKind::Activated,
            ..
        } => EventType::GuardPolicyActivated,
        EventId::GuardPolicy {
            kind: GpEventKind::Deactivated,
            ..
        } => EventType::GuardPolicyDeactivated,
        EventId::GuardPolicy {
            kind: GpEventKind::Passed,
            ..
        } => EventType::GuardPolicyPassed,
        EventId::GuardPolicy {
            kind: GpEventKind::Failed,
            ..
        } => EventType::GuardPolicyFailed,
        EventId::Approval {
            kind: ApprovalEventKind::Allow,
            ..
        } => EventType::ApprovalAllowed,
        EventId::Approval {
            kind: ApprovalEventKind::Deny,
            ..
        } => EventType::ApprovalDenied,
        EventId::Approval {
            kind: ApprovalEventKind::Cancelled,
            ..
        } => EventType::ApprovalCancelled,
        EventId::Incident { .. } => EventType::IncidentEmitted,
        _ => EventType::EventEmitted,
    }
}

fn emitted_to_log(id: &EventId, payload: Option<&Value>, refreshed: bool) -> ShieldLogEvent {
    let category = category_for_event(id);
    let event_type = event_type_for_emitted(id);
    let severity = severity_for_emitted(id);
    let id_str = event_id_to_string(id);

    let mut attrs = AgentShieldAttributes::new();
    attrs.set_event_type(event_type);
    attrs.set_severity(severity);
    attrs.set_event_id(&id_str);
    attrs.set_event_refreshed(refreshed);

    let mut ev = ShieldLogEvent::new(event_type, severity, category)
        .with_event_id(&id_str)
        .with_message(format!("event emitted: {}", id_str));

    // Populate spec-typed fields when the event id implies them.
    match id {
        EventId::Tool { name, .. } => {
            attrs.set_resource(ResourceKind::Tool, name);
            ev = ev.with_resource(super::event::ResourceRef::tool(name));
        }
        EventId::Agent { name, .. } => {
            attrs.set_resource(ResourceKind::Agent, name);
            ev = ev.with_resource(super::event::ResourceRef::agent(name));
        }
        EventId::Endpoint { pattern, .. } => {
            attrs.set_resource(ResourceKind::Endpoint, pattern);
            ev = ev.with_resource(super::event::ResourceRef::endpoint(pattern));
        }
        EventId::VariableChanged { name } => {
            attrs.set_variable_name(name);
            ev = ev.with_variable(name);
        }
        EventId::GuardPolicy { name, .. } => {
            // §19.3: bus-mirrored guard_policy events MUST also populate
            // the `agent_shield.guard_policy` attribute key, not just the
            // typed top-level field.
            attrs.set_guard_policy(name);
            ev = ev.with_guard_policy(name);
        }
        EventId::Approval { variable, .. } => {
            attrs.set_variable_name(variable);
            ev = ev.with_variable(variable);
        }
        _ => {}
    }

    if let Some(p) = payload {
        attrs.set_raw("agent_shield.event.payload", p.clone());
    }

    ev.merge_attributes(attrs.into_map())
}

fn cleared_to_log(id: &EventId, cause: ClearCause) -> ShieldLogEvent {
    let category = category_for_event(id);
    let id_str = event_id_to_string(id);
    let cause_str = match cause {
        ClearCause::Explicit => "explicit",
        ClearCause::SessionEnd => "session_end",
        ClearCause::Expired => "expired",
        ClearCause::UntilEventTriggered => "until_event_triggered",
    };

    let mut attrs = AgentShieldAttributes::new();
    attrs.set_event_type(EventType::EventCleared);
    attrs.set_severity(Severity::Info);
    attrs.set_event_id(&id_str);
    attrs.set_event_cause(cause_str);

    let mut ev = ShieldLogEvent::new(EventType::EventCleared, Severity::Info, category)
        .with_event_id(&id_str)
        .with_message(format!("event cleared: {} ({})", id_str, cause_str));

    match id {
        EventId::Tool { name, .. } => {
            attrs.set_resource(ResourceKind::Tool, name);
            ev = ev.with_resource(super::event::ResourceRef::tool(name));
        }
        EventId::Agent { name, .. } => {
            attrs.set_resource(ResourceKind::Agent, name);
            ev = ev.with_resource(super::event::ResourceRef::agent(name));
        }
        EventId::Endpoint { pattern, .. } => {
            attrs.set_resource(ResourceKind::Endpoint, pattern);
            ev = ev.with_resource(super::event::ResourceRef::endpoint(pattern));
        }
        EventId::VariableChanged { name } => {
            attrs.set_variable_name(name);
            ev = ev.with_variable(name);
        }
        EventId::GuardPolicy { name, .. } => {
            // §19.3: cleared `guard_policy.*` events MUST stamp the
            // attribute key alongside the typed field.
            attrs.set_guard_policy(name);
            ev = ev.with_guard_policy(name);
        }
        EventId::Approval { variable, .. } => {
            attrs.set_variable_name(variable);
            ev = ev.with_variable(variable);
        }
        _ => {}
    }

    ev.merge_attributes(attrs.into_map())
}

/// Public accessor for the bus → log mapping. Re-exported so `emitter.rs`
/// can reuse the same shape, and so tests can pin the wiring.
/// Public accessor for the bus → log mapping. Re-exported so `emitter.rs`
/// can reuse the same shape, and so tests can pin the wiring. Pass
/// `agent_id` to stamp the §19.2 `agent_id` field; pass `None` to skip.
pub fn bus_event_to_log_event(ev: &BusEvent, agent_id: Option<&str>) -> ShieldLogEvent {
    bus_event_to_log(ev, agent_id)
}

// ── Tests ───────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::super::test_support::CaptureProvider;
    use super::*;
    use crate::events::{ApprovalEventKind, GpEventKind, ToolEventKind};

    fn fresh() -> (Arc<ObservabilityDispatcher>, EventBus) {
        let bus = EventBus::new();
        let d = ObservabilityDispatcher::new(bus.clone());
        (d, bus)
    }

    #[test]
    fn dispatcher_fans_out_direct_emit_to_all_providers() {
        let (d, _bus) = fresh();
        let p1 = CaptureProvider::new();
        let p2 = CaptureProvider::new();
        d.register_provider(p1.clone());
        d.register_provider(p2.clone());
        assert_eq!(d.provider_count(), 2);

        d.emit(ShieldLogEvent::new(EventType::Info, Severity::Info, "test"));
        assert_eq!(p1.events.lock().unwrap().len(), 1);
        assert_eq!(p2.events.lock().unwrap().len(), 1);
    }

    #[test]
    fn bus_emit_is_mirrored_into_providers() {
        let (d, bus) = fresh();
        let p = CaptureProvider::new();
        d.register_provider(p.clone());

        bus.emit_session_start().unwrap();
        bus.emit_turn_start().unwrap();
        bus.emit_tool_called("send_email").unwrap();

        let events = p.events.lock().unwrap();
        assert_eq!(events.len(), 3);
        assert_eq!(events[0].event_type, EventType::EventEmitted);
        assert_eq!(events[0].event_id.as_deref(), Some("session.start"));
        assert_eq!(events[2].event_type, EventType::EventEmitted);
        assert_eq!(
            events[2].event_id.as_deref(),
            Some("tool.send_email.called")
        );
        assert_eq!(events[2].resource.as_ref().unwrap().name, "send_email");
    }

    #[test]
    fn tool_failure_logs_at_medium_severity() {
        let (d, bus) = fresh();
        let p = CaptureProvider::new();
        d.register_provider(p.clone());
        bus.emit_tool_failure("send_email").unwrap();
        let events = p.events.lock().unwrap();
        assert_eq!(events.len(), 1);
        assert_eq!(events[0].severity, Severity::Medium);
    }

    #[test]
    fn guard_policy_failed_logs_at_high_severity() {
        let (d, bus) = fresh();
        let p = CaptureProvider::new();
        d.register_provider(p.clone());
        bus.emit(
            EventId::GuardPolicy {
                name: "send_requires_authorization".into(),
                kind: GpEventKind::Failed,
            },
            None,
            None,
        )
        .unwrap();
        let events = p.events.lock().unwrap();
        assert_eq!(events.len(), 1);
        assert_eq!(events[0].severity, Severity::High);
        assert_eq!(events[0].event_type, EventType::GuardPolicyFailed);
        assert_eq!(
            events[0].guard_policy.as_deref(),
            Some("send_requires_authorization")
        );
        // §19.3: bus-mirrored guard_policy events stamp `agent_shield.guard_policy`.
        assert_eq!(
            events[0]
                .attributes
                .get(super::super::attributes::KEY_GUARD_POLICY)
                .unwrap(),
            "send_requires_authorization"
        );
    }

    #[test]
    fn guard_policy_activated_logs_at_info_with_correct_event_type() {
        let (d, bus) = fresh();
        let p = CaptureProvider::new();
        d.register_provider(p.clone());
        bus.emit(
            EventId::GuardPolicy {
                name: "no_secrets".into(),
                kind: GpEventKind::Activated,
            },
            None,
            None,
        )
        .unwrap();
        let events = p.events.lock().unwrap();
        assert_eq!(events.len(), 1);
        assert_eq!(events[0].severity, Severity::Info);
        assert_eq!(events[0].event_type, EventType::GuardPolicyActivated);
    }

    #[test]
    fn approval_events_map_correctly() {
        let (d, bus) = fresh();
        let p = CaptureProvider::new();
        d.register_provider(p.clone());

        bus.emit(
            EventId::Approval {
                variable: "approve_send".into(),
                kind: ApprovalEventKind::Allow,
            },
            None,
            None,
        )
        .unwrap();
        bus.emit(
            EventId::Approval {
                variable: "approve_send".into(),
                kind: ApprovalEventKind::Deny,
            },
            None,
            None,
        )
        .unwrap();
        bus.emit(
            EventId::Approval {
                variable: "approve_send".into(),
                kind: ApprovalEventKind::Cancelled,
            },
            None,
            None,
        )
        .unwrap();

        let events = p.events.lock().unwrap();
        assert_eq!(events[0].event_type, EventType::ApprovalAllowed);
        assert_eq!(events[0].severity, Severity::Info);
        assert_eq!(events[1].event_type, EventType::ApprovalDenied);
        assert_eq!(events[1].severity, Severity::Medium);
        assert_eq!(events[2].event_type, EventType::ApprovalCancelled);
        assert_eq!(events[2].severity, Severity::Medium);
    }

    #[test]
    fn incident_logs_at_high_severity() {
        let (d, bus) = fresh();
        let p = CaptureProvider::new();
        d.register_provider(p.clone());
        bus.emit(
            EventId::Incident {
                name: "secret_leak".into(),
            },
            None,
            None,
        )
        .unwrap();
        let events = p.events.lock().unwrap();
        assert_eq!(events[0].event_type, EventType::IncidentEmitted);
        assert_eq!(events[0].severity, Severity::High);
    }

    #[test]
    fn variable_changed_event_is_logged_with_variable_name() {
        let (d, bus) = fresh();
        let p = CaptureProvider::new();
        d.register_provider(p.clone());
        bus.emit(
            EventId::VariableChanged {
                name: "approval_for_send".into(),
            },
            None,
            None,
        )
        .unwrap();
        let events = p.events.lock().unwrap();
        assert_eq!(events[0].event_type, EventType::VariableChanged);
        assert_eq!(events[0].variable.as_deref(), Some("approval_for_send"));
    }

    #[test]
    fn cleared_event_logs_with_cause_attribute() {
        let (d, bus) = fresh();
        let p = CaptureProvider::new();
        d.register_provider(p.clone());
        bus.emit_tool_called("send_email").unwrap();
        bus.clear_event(&EventId::Tool {
            name: "send_email".into(),
            kind: ToolEventKind::Called,
        });
        let events = p.events.lock().unwrap();
        // First emit, then clear.
        assert_eq!(events.len(), 2);
        assert_eq!(events[1].event_type, EventType::EventCleared);
        assert_eq!(
            events[1]
                .attributes
                .get("agent_shield.event.cause")
                .unwrap(),
            "explicit"
        );
    }

    #[test]
    fn session_end_clears_latched_events_in_log() {
        let (d, bus) = fresh();
        let p = CaptureProvider::new();
        d.register_provider(p.clone());

        bus.emit_turn_start().unwrap();
        bus.emit_request_start().unwrap();
        bus.emit_session_end().unwrap();

        let events = p.events.lock().unwrap();
        // session.end emit + clears for turn.start + request.start (order
        // depends on hashmap iteration; assert by membership).
        let cleared_ids: Vec<_> = events
            .iter()
            .filter(|e| e.event_type == EventType::EventCleared)
            .filter_map(|e| e.event_id.clone())
            .collect();
        assert!(cleared_ids.iter().any(|s| s == "turn.start"));
        assert!(cleared_ids.iter().any(|s| s == "request.start"));
        for cleared in events
            .iter()
            .filter(|e| e.event_type == EventType::EventCleared)
        {
            assert_eq!(
                cleared.attributes.get("agent_shield.event.cause").unwrap(),
                "session_end"
            );
        }
    }

    #[test]
    fn dropping_dispatcher_unsubscribes_from_bus() {
        let bus = EventBus::new();
        {
            let d = ObservabilityDispatcher::new(bus.clone());
            let p = CaptureProvider::new();
            d.register_provider(p.clone());
            bus.emit_turn_start().unwrap();
            assert_eq!(p.events.lock().unwrap().len(), 1);
            // dispatcher dropped here
        }
        // Emitting after the dispatcher is gone must not panic. There's no
        // observable assertion beyond "didn't panic"; we still emit to
        // exercise the path.
        bus.emit_turn_end().unwrap();
    }

    #[test]
    fn bus_event_to_log_event_is_pure() {
        let id = EventId::Tool {
            name: "send_email".into(),
            kind: ToolEventKind::Failure,
        };
        let ev = BusEvent::Emitted {
            session_id: crate::session_id::SessionId::default(),
            event_id: id.clone(),
            payload: Some(Value::from("oops")),
            refreshed: false,
        };
        let log = bus_event_to_log_event(&ev, None);
        assert_eq!(log.event_type, EventType::EventEmitted);
        assert_eq!(log.severity, Severity::Medium);
        assert_eq!(log.event_id.as_deref(), Some("tool.send_email.failure"));
        assert!(log.attributes.contains_key("agent_shield.event.payload"));
        // No agent_id → no top-level field, no attribute.
        assert!(log.agent_id.is_none());
        assert!(!log.attributes.contains_key("agent_shield.agent_id"));
    }

    #[test]
    fn dispatcher_with_agent_id_stamps_minted_events() {
        let bus = EventBus::new();
        let d = ObservabilityDispatcher::with_agent_id(bus.clone(), "minimal");
        assert_eq!(d.agent_id(), Some("minimal"));
        let p = CaptureProvider::new();
        d.register_provider(p.clone());

        // Direct emit path: dispatcher stamps agent_id when not supplied.
        d.emit(ShieldLogEvent::new(EventType::Info, Severity::Info, "test"));
        // Bus path: subscriber stamps agent_id on mirrored events.
        bus.emit_session_start().unwrap();

        let events = p.events.lock().unwrap();
        assert_eq!(events.len(), 2);
        for ev in events.iter() {
            assert_eq!(ev.agent_id.as_deref(), Some("minimal"));
            assert_eq!(
                ev.attributes
                    .get(super::super::attributes::KEY_AGENT_ID)
                    .unwrap(),
                "minimal"
            );
        }
    }

    #[test]
    fn dispatcher_emit_preserves_caller_supplied_agent_id() {
        let bus = EventBus::new();
        let d = ObservabilityDispatcher::with_agent_id(bus.clone(), "minimal");
        let p = CaptureProvider::new();
        d.register_provider(p.clone());

        let ev =
            ShieldLogEvent::new(EventType::Info, Severity::Info, "test").with_agent_id("override");
        d.emit(ev);

        let events = p.events.lock().unwrap();
        assert_eq!(events[0].agent_id.as_deref(), Some("override"));
    }

    #[test]
    fn tool_event_populates_top_level_tool_alias() {
        let (d, bus) = fresh();
        let p = CaptureProvider::new();
        d.register_provider(p.clone());
        bus.emit_tool_called("send_email").unwrap();
        let events = p.events.lock().unwrap();
        // §19.2: `tool` top-level alias is stamped whenever resource.kind=Tool.
        assert_eq!(events[0].tool.as_deref(), Some("send_email"));
        assert_eq!(events[0].resource.as_ref().unwrap().name, "send_email");
    }

    #[test]
    fn dispatcher_decorates_every_event_with_otel_genai_attrs() {
        // Both the direct-emit and bus-mirror paths must add the
        // OTel GenAI semantic-convention attributes
        // (gen_ai.system="agent_shield", gen_ai.operation.name="guard"
        // or "guard.<stage>"). This is what makes AgentShield events
        // light up in Phoenix / Logfire / Honeycomb / Azure Monitor
        // dashboards without any customer configuration.
        use super::super::event::{LogAction, Stage};

        let (d, bus) = fresh();
        let p = CaptureProvider::new();
        d.register_provider(p.clone());

        // Direct emit — block event with stage should produce
        // gen_ai.response.finish_reason="content_filter".
        d.emit(
            ShieldLogEvent::new(EventType::GuardPolicyFailed, Severity::High, "guardrail")
                .with_stage(Stage::State)
                .with_action(LogAction::Block),
        );

        // Bus path — session.start has no stage, so it gets
        // gen_ai.operation.name="guard" (no finish_reason).
        bus.emit_session_start().unwrap();

        let events = p.events.lock().unwrap();
        assert_eq!(events.len(), 2);

        // Every event has gen_ai.system="agent_shield".
        for ev in events.iter() {
            assert_eq!(
                ev.attributes.get("gen_ai.system").and_then(|v| v.as_str()),
                Some("agent_shield"),
                "every dispatched event must carry gen_ai.system=agent_shield"
            );
            assert!(
                ev.attributes.contains_key("gen_ai.operation.name"),
                "every dispatched event must carry gen_ai.operation.name"
            );
        }

        // Direct-emit block event — finish_reason populated.
        assert_eq!(
            events[0]
                .attributes
                .get("gen_ai.response.finish_reason")
                .and_then(|v| v.as_str()),
            Some("content_filter"),
            "block events must carry gen_ai.response.finish_reason=content_filter"
        );
        assert_eq!(
            events[0]
                .attributes
                .get("gen_ai.operation.name")
                .and_then(|v| v.as_str()),
            Some("guard.state")
        );

        // Bus-mirror session.start — no finish_reason (not a
        // response-finishing event).
        assert!(!events[1]
            .attributes
            .contains_key("gen_ai.response.finish_reason"));
    }

    // ── Runtime mode + enforced stamping (#14) ────────────────────────

    use super::super::event::LogAction;
    use crate::shield_primitives::RuntimeMode;

    #[test]
    fn mode_stamped_on_direct_emit_when_dispatcher_built_with_mode() {
        let bus = EventBus::new();
        let d = ObservabilityDispatcher::with_agent_id_and_mode(bus, "agent", RuntimeMode::Shadow);
        let p = CaptureProvider::new();
        d.register_provider(p.clone());

        d.emit(ShieldLogEvent::new(EventType::Info, Severity::Info, "ev"));

        let events = p.events.lock().unwrap();
        assert_eq!(events[0].mode, Some(RuntimeMode::Shadow));
        // `enforced` is NOT stamped on events without an action.
        assert_eq!(events[0].enforced, None);
        assert_eq!(
            events[0]
                .attributes
                .get(super::super::attributes::KEY_RUNTIME_MODE)
                .and_then(|v| v.as_str()),
            Some("shadow")
        );
    }

    #[test]
    fn enforced_true_in_active_mode_for_action_events() {
        let bus = EventBus::new();
        let d = ObservabilityDispatcher::with_agent_id_and_mode(bus, "agent", RuntimeMode::Active);
        let p = CaptureProvider::new();
        d.register_provider(p.clone());

        d.emit(
            ShieldLogEvent::new(EventType::GuardPolicyFailed, Severity::High, "guard.state")
                .with_action(LogAction::Block),
        );

        let events = p.events.lock().unwrap();
        assert_eq!(events[0].mode, Some(RuntimeMode::Active));
        assert_eq!(events[0].enforced, Some(true));
    }

    #[test]
    fn enforced_false_in_shadow_mode_for_action_events() {
        let bus = EventBus::new();
        let d = ObservabilityDispatcher::with_agent_id_and_mode(bus, "agent", RuntimeMode::Shadow);
        let p = CaptureProvider::new();
        d.register_provider(p.clone());

        d.emit(
            ShieldLogEvent::new(EventType::GuardPolicyFailed, Severity::High, "guard.state")
                .with_action(LogAction::Block),
        );

        let events = p.events.lock().unwrap();
        assert_eq!(events[0].mode, Some(RuntimeMode::Shadow));
        assert_eq!(events[0].enforced, Some(false));
    }

    #[test]
    fn enforced_omitted_on_allow_events_even_with_mode() {
        let bus = EventBus::new();
        let d = ObservabilityDispatcher::with_agent_id_and_mode(bus, "agent", RuntimeMode::Active);
        let p = CaptureProvider::new();
        d.register_provider(p.clone());

        d.emit(
            ShieldLogEvent::new(EventType::Info, Severity::Info, "ok")
                .with_action(LogAction::Allow),
        );

        let events = p.events.lock().unwrap();
        assert_eq!(events[0].mode, Some(RuntimeMode::Active));
        assert_eq!(events[0].enforced, None);
    }

    #[test]
    fn bus_mirrored_events_also_carry_mode_and_enforced_when_applicable() {
        let bus = EventBus::new();
        let d = ObservabilityDispatcher::with_agent_id_and_mode(
            bus.clone(),
            "agent",
            RuntimeMode::Shadow,
        );
        let p = CaptureProvider::new();
        d.register_provider(p.clone());

        bus.emit_session_start().unwrap();

        let events = p.events.lock().unwrap();
        assert_eq!(events[0].mode, Some(RuntimeMode::Shadow));
        // session.start doesn't carry an enforceable action, so
        // `enforced` is omitted.
        assert_eq!(events[0].enforced, None);
    }

    #[test]
    fn no_mode_dispatcher_does_not_stamp_mode() {
        let (d, _bus) = fresh();
        let p = CaptureProvider::new();
        d.register_provider(p.clone());

        d.emit(
            ShieldLogEvent::new(EventType::Info, Severity::Info, "test")
                .with_action(LogAction::Block),
        );

        let events = p.events.lock().unwrap();
        assert_eq!(events[0].mode, None);
        assert_eq!(events[0].enforced, None);
    }
}
