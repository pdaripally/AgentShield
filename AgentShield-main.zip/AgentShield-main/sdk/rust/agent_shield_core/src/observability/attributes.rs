//! Typed accessors over the `agent_shield.*` semantic-attribute namespace
//! defined in spec §19.3.
//!
//! [`AgentShieldAttributes`] is a thin wrapper around a
//! `HashMap<String, serde_json::Value>` that exposes a typed setter and
//! getter for every spec-defined key. Use it to assemble the
//! [`ShieldLogEvent::attributes`](super::event::ShieldLogEvent::attributes)
//! map without spelling out string keys at every call site:
//!
//! ```ignore
//! let mut attrs = AgentShieldAttributes::new();
//! attrs.set_event_type(EventType::GuardPolicyFailed);
//! attrs.set_guard_policy("send_requires_authorization");
//! attrs.set_stage(Stage::State);
//! let map = attrs.into_map();   // HashMap<String, Value> with `agent_shield.*` keys
//! ```
//!
//! All keys are declared as `pub const` strings so external code can
//! reference them without typo risk.

use std::collections::HashMap;

use serde_json::Value;

#[cfg(test)]
use super::event::Action;
use super::event::{EventType, LogAction, ResourceKind, Severity, Stage};

// ── Canonical key constants (§19.3) ─────────────────────────────────

/// `agent_shield.event_type` — closed enum from §19.2.
pub const KEY_EVENT_TYPE: &str = "agent_shield.event_type";
/// `agent_shield.stage` — `input` / `state` / `tool_execution` / `post_tool` / `output`.
pub const KEY_STAGE: &str = "agent_shield.stage";
/// `agent_shield.action` — gating decision: `block` / `redact` / `warn` / `append` / `prepend`.
pub const KEY_ACTION: &str = "agent_shield.action";
/// `agent_shield.severity` — `critical` / `high` / `medium` / `low` / `info`.
pub const KEY_SEVERITY: &str = "agent_shield.severity";
/// `agent_shield.category` — free-form routing tag from `log.category`.
pub const KEY_CATEGORY: &str = "agent_shield.category";
/// `agent_shield.message` — interpolated message text from `log.message`.
pub const KEY_MESSAGE: &str = "agent_shield.message";
/// `agent_shield.reason` — bypass reason or audit reason text.
pub const KEY_REASON: &str = "agent_shield.reason";

/// `agent_shield.guard_policy` — guard-policy identifier (§19.3).
pub const KEY_GUARD_POLICY: &str = "agent_shield.guard_policy";
/// Pre-§19.3-alignment alias; kept for callers that want the nested name.
/// New code SHOULD prefer [`KEY_GUARD_POLICY`].
pub const KEY_GUARD_POLICY_NAME: &str = KEY_GUARD_POLICY;
/// `agent_shield.evaluate_when_index` — 0-based index of the failing
/// entry in the `evaluate_when[]` list (§19.3).
pub const KEY_EVALUATE_WHEN_INDEX: &str = "agent_shield.evaluate_when_index";
/// Pre-§19.3-alignment alias; kept for callers that want the nested name.
/// New code SHOULD prefer [`KEY_EVALUATE_WHEN_INDEX`].
pub const KEY_GUARD_POLICY_EVALUATE_WHEN_INDEX: &str = KEY_EVALUATE_WHEN_INDEX;
/// `agent_shield.guard_policy.reason` — reason text from the guard policy
/// (or its `evaluate_when[]` entry).
pub const KEY_GUARD_POLICY_REASON: &str = "agent_shield.guard_policy.reason";
/// `agent_shield.guard_policy.allowed_when_bypassed` — `true` when the
/// failure was suppressed by `allowed_when:` per §12.6.
pub const KEY_GUARD_POLICY_ALLOWED_WHEN_BYPASSED: &str =
    "agent_shield.guard_policy.allowed_when_bypassed";

/// `agent_shield.resolver.kind` — `static` / `human` / `delegate` / etc.
pub const KEY_RESOLVER_KIND: &str = "agent_shield.resolver.kind";
/// `agent_shield.resolver.variable` — the variable being resolved.
pub const KEY_RESOLVER_VARIABLE: &str = "agent_shield.resolver.variable";
/// `agent_shield.resolver.decision` — final resolver decision (allow / deny / cancelled / pending).
pub const KEY_RESOLVER_DECISION: &str = "agent_shield.resolver.decision";
/// `agent_shield.resolver.latency_ms` — elapsed milliseconds for the resolver call.
pub const KEY_RESOLVER_LATENCY_MS: &str = "agent_shield.resolver.latency_ms";
/// `agent_shield.resolver.error` — error kind on resolver failure.
pub const KEY_RESOLVER_ERROR: &str = "agent_shield.resolver.error";

/// `agent_shield.resource.kind` — `tool` / `agent` / `endpoint` / `other`.
pub const KEY_RESOURCE_KIND: &str = "agent_shield.resource.kind";
/// `agent_shield.resource.name` — resource identifier.
pub const KEY_RESOURCE_NAME: &str = "agent_shield.resource.name";
/// `agent_shield.tool` — short alias for resource name when kind is tool
/// (emitted alongside `resource.kind`/`resource.name` for ergonomics).
pub const KEY_RESOURCE_TOOL_ALIAS: &str = "agent_shield.tool";

/// `agent_shield.event.id` — closed-namespace event identifier.
pub const KEY_EVENT_ID: &str = "agent_shield.event.id";
/// `agent_shield.event.lifetime` — bare-form lifetime string (`per_call`,
/// `per_session`, `for: 30s`, `until_event: ...`).
pub const KEY_EVENT_LIFETIME: &str = "agent_shield.event.lifetime";
/// `agent_shield.event.cause` — clear cause (`explicit` / `session_end` /
/// `expired` / `until_event_triggered`).
pub const KEY_EVENT_CAUSE: &str = "agent_shield.event.cause";
/// `agent_shield.event.refreshed` — `true` when an existing latch was
/// refreshed rather than created.
pub const KEY_EVENT_REFRESHED: &str = "agent_shield.event.refreshed";

/// `agent_shield.variable.name` — variable identifier.
pub const KEY_VARIABLE_NAME: &str = "agent_shield.variable.name";
/// `agent_shield.variable.status` — variable status enum (`unresolved` /
/// `pending` / `resolved` / `expired`).
pub const KEY_VARIABLE_STATUS: &str = "agent_shield.variable.status";
/// `agent_shield.variable.value` — JSON-serialized current value.
pub const KEY_VARIABLE_VALUE: &str = "agent_shield.variable.value";

/// `agent_shield.config.name` — `metadata.name` from the loaded config.
pub const KEY_CONFIG_NAME: &str = "agent_shield.config.name";
/// `agent_shield.config.version` — `metadata.version` from the loaded config.
pub const KEY_CONFIG_VERSION: &str = "agent_shield.config.version";
/// `agent_shield.agent_id` — alias for config name.
pub const KEY_AGENT_ID: &str = "agent_shield.agent_id";

/// `agent_shield.session.id` — session identifier.
pub const KEY_SESSION_ID: &str = "agent_shield.session.id";
/// `agent_shield.correlation.id` — request-correlation identifier.
pub const KEY_CORRELATION_ID: &str = "agent_shield.correlation.id";
/// `agent_shield.tenant.id` — tenant identifier.
pub const KEY_TENANT_ID: &str = "agent_shield.tenant.id";
/// `agent_shield.user.id` — user identifier.
pub const KEY_USER_ID: &str = "agent_shield.user.id";

/// `agent_shield.runtime.mode` — `"active"` or `"shadow"` (#14).
pub const KEY_RUNTIME_MODE: &str = "agent_shield.runtime.mode";
/// `agent_shield.runtime.enforced` — bool, action-bearing events
/// only; mirrors the top-level `enforced` field (#14).
pub const KEY_ENFORCED: &str = "agent_shield.runtime.enforced";

/// `agent_shield.load.file` — file path that triggered a load error.
pub const KEY_LOAD_FILE: &str = "agent_shield.load.file";
/// `agent_shield.load.message` — human-readable load-error description.
pub const KEY_LOAD_MESSAGE: &str = "agent_shield.load.message";

// ── OTel GenAI Semantic Convention keys ────────────────────────────
//
// These ride alongside the `agent_shield.*` namespace on every log
// event so any OpenTelemetry exporter (Phoenix, Logfire, Honeycomb,
// Azure Monitor, OTel Collector) sees AgentShield events the same way
// it sees LangChain / OpenAI / Anthropic / SK telemetry, without any
// customer configuration. Reference:
// https://opentelemetry.io/docs/specs/semconv/gen-ai/

/// `gen_ai.system` — vendor of the GenAI subsystem. We always emit
/// `"agent_shield"` so dashboards can filter AgentShield events out of
/// (or into) the broader LLM-call stream.
pub const KEY_GENAI_SYSTEM: &str = "gen_ai.system";

/// `gen_ai.operation.name` — the GenAI operation. AgentShield emits
/// `"guard"` (or `"guard.<stage>"` when a stage is known) so events
/// are distinguishable from `chat` / `execute_tool` / `invoke_agent`
/// emissions from the surrounding agent loop.
pub const KEY_GENAI_OPERATION_NAME: &str = "gen_ai.operation.name";

/// `gen_ai.response.finish_reason` — emitted on guardrail outcomes
/// that terminate or modify the response. AgentShield uses the OTel
/// canonical value `"content_filter"` for `block` and `redact` actions
/// (the closest semantic match in the OTel-defined enum, which has no
/// dedicated `guard` variant).
pub const KEY_GENAI_RESPONSE_FINISH_REASON: &str = "gen_ai.response.finish_reason";

/// AgentShield's `gen_ai.system` value. Constant so customers can
/// filter on it.
pub const GENAI_SYSTEM_AGENT_SHIELD: &str = "agent_shield";

/// All known `agent_shield.*` keys defined by this module. Useful for
/// validation and for round-tripping the namespace in tests.
pub const KNOWN_KEYS: &[&str] = &[
    KEY_EVENT_TYPE,
    KEY_STAGE,
    KEY_ACTION,
    KEY_SEVERITY,
    KEY_CATEGORY,
    KEY_MESSAGE,
    KEY_REASON,
    KEY_GUARD_POLICY,
    KEY_EVALUATE_WHEN_INDEX,
    KEY_GUARD_POLICY_REASON,
    KEY_GUARD_POLICY_ALLOWED_WHEN_BYPASSED,
    KEY_RESOLVER_KIND,
    KEY_RESOLVER_VARIABLE,
    KEY_RESOLVER_DECISION,
    KEY_RESOLVER_LATENCY_MS,
    KEY_RESOLVER_ERROR,
    KEY_RESOURCE_KIND,
    KEY_RESOURCE_NAME,
    KEY_RESOURCE_TOOL_ALIAS,
    KEY_EVENT_ID,
    KEY_EVENT_LIFETIME,
    KEY_EVENT_CAUSE,
    KEY_EVENT_REFRESHED,
    KEY_VARIABLE_NAME,
    KEY_VARIABLE_STATUS,
    KEY_VARIABLE_VALUE,
    KEY_CONFIG_NAME,
    KEY_CONFIG_VERSION,
    KEY_AGENT_ID,
    KEY_SESSION_ID,
    KEY_CORRELATION_ID,
    KEY_TENANT_ID,
    KEY_USER_ID,
    KEY_RUNTIME_MODE,
    KEY_ENFORCED,
    KEY_LOAD_FILE,
    KEY_LOAD_MESSAGE,
];

/// All known `gen_ai.*` keys AgentShield emits. These are OTel-spec
/// keys, NOT in the `agent_shield.*` namespace — but we include them
/// in a sibling list for tests and validation.
pub const KNOWN_GENAI_KEYS: &[&str] = &[
    KEY_GENAI_SYSTEM,
    KEY_GENAI_OPERATION_NAME,
    KEY_GENAI_RESPONSE_FINISH_REASON,
];

// ── Builder ─────────────────────────────────────────────────────────

/// Typed builder over the `agent_shield.*` attribute namespace.
///
/// Setters take typed values; the resulting [`HashMap`] uses the canonical
/// key strings declared above.
#[derive(Debug, Clone, Default)]
pub struct AgentShieldAttributes {
    inner: HashMap<String, Value>,
}

impl AgentShieldAttributes {
    pub fn new() -> Self {
        Self::default()
    }

    /// Number of attributes set so far.
    pub fn len(&self) -> usize {
        self.inner.len()
    }

    pub fn is_empty(&self) -> bool {
        self.inner.is_empty()
    }

    /// Borrow the underlying map.
    pub fn as_map(&self) -> &HashMap<String, Value> {
        &self.inner
    }

    /// Consume the builder and return the underlying attribute map.
    pub fn into_map(self) -> HashMap<String, Value> {
        self.inner
    }

    /// Generic insert / read for keys outside the typed surface (typically
    /// extension attributes outside `agent_shield.*`).
    pub fn set_raw(&mut self, key: impl Into<String>, value: Value) -> &mut Self {
        self.inner.insert(key.into(), value);
        self
    }

    pub fn get(&self, key: &str) -> Option<&Value> {
        self.inner.get(key)
    }

    // ── Spec-typed setters ─────────────────────────────────────────

    pub fn set_event_type(&mut self, et: EventType) -> &mut Self {
        self.set_raw(KEY_EVENT_TYPE, Value::from(et.as_str()))
    }

    pub fn set_stage(&mut self, stage: Stage) -> &mut Self {
        self.set_raw(KEY_STAGE, Value::from(stage.as_str()))
    }

    pub fn set_action(&mut self, action: impl Into<LogAction>) -> &mut Self {
        self.set_raw(KEY_ACTION, Value::from(action.into().as_str()))
    }

    pub fn set_severity(&mut self, sev: Severity) -> &mut Self {
        self.set_raw(KEY_SEVERITY, Value::from(sev.as_str()))
    }

    pub fn set_category(&mut self, category: impl Into<String>) -> &mut Self {
        self.set_raw(KEY_CATEGORY, Value::from(category.into()))
    }

    pub fn set_message(&mut self, message: impl Into<String>) -> &mut Self {
        self.set_raw(KEY_MESSAGE, Value::from(message.into()))
    }

    pub fn set_reason(&mut self, reason: impl Into<String>) -> &mut Self {
        self.set_raw(KEY_REASON, Value::from(reason.into()))
    }

    // ── Guard-policy ──────────────────────────────────────────────

    pub fn set_guard_policy(&mut self, name: impl Into<String>) -> &mut Self {
        self.set_raw(KEY_GUARD_POLICY, Value::from(name.into()))
    }

    pub fn set_evaluate_when_index(&mut self, idx: usize) -> &mut Self {
        self.set_raw(KEY_EVALUATE_WHEN_INDEX, Value::from(idx as u64))
    }

    pub fn set_guard_policy_reason(&mut self, reason: impl Into<String>) -> &mut Self {
        self.set_raw(KEY_GUARD_POLICY_REASON, Value::from(reason.into()))
    }

    pub fn set_allowed_when_bypassed(&mut self, bypassed: bool) -> &mut Self {
        self.set_raw(
            KEY_GUARD_POLICY_ALLOWED_WHEN_BYPASSED,
            Value::from(bypassed),
        )
    }

    // ── Resolver ──────────────────────────────────────────────────

    pub fn set_resolver_kind(&mut self, kind: impl Into<String>) -> &mut Self {
        self.set_raw(KEY_RESOLVER_KIND, Value::from(kind.into()))
    }

    pub fn set_resolver_variable(&mut self, var: impl Into<String>) -> &mut Self {
        self.set_raw(KEY_RESOLVER_VARIABLE, Value::from(var.into()))
    }

    pub fn set_resolver_decision(&mut self, decision: impl Into<String>) -> &mut Self {
        self.set_raw(KEY_RESOLVER_DECISION, Value::from(decision.into()))
    }

    pub fn set_resolver_latency_ms(&mut self, ms: u64) -> &mut Self {
        self.set_raw(KEY_RESOLVER_LATENCY_MS, Value::from(ms))
    }

    pub fn set_resolver_error(&mut self, error: impl Into<String>) -> &mut Self {
        self.set_raw(KEY_RESOLVER_ERROR, Value::from(error.into()))
    }

    // ── Resource ──────────────────────────────────────────────────

    pub fn set_resource_kind(&mut self, kind: ResourceKind) -> &mut Self {
        self.set_raw(KEY_RESOURCE_KIND, Value::from(kind.as_str()))
    }

    pub fn set_resource_name(&mut self, name: impl Into<String>) -> &mut Self {
        let n: String = name.into();
        // Tool resources additionally surface as the top-level
        // `agent_shield.tool` alias (§19.2) so downstream filters can
        // pivot on tool name without inspecting `resource.kind`.
        self.inner
            .insert(KEY_RESOURCE_NAME.to_string(), Value::from(n.clone()));
        if matches!(
            self.inner.get(KEY_RESOURCE_KIND),
            Some(v) if v.as_str() == Some(ResourceKind::Tool.as_str())
        ) {
            self.inner
                .insert(KEY_RESOURCE_TOOL_ALIAS.to_string(), Value::from(n));
        }
        self
    }

    pub fn set_resource(&mut self, kind: ResourceKind, name: impl Into<String>) -> &mut Self {
        self.set_resource_kind(kind);
        self.set_resource_name(name);
        self
    }

    // ── Bus event ─────────────────────────────────────────────────

    pub fn set_event_id(&mut self, id: impl Into<String>) -> &mut Self {
        self.set_raw(KEY_EVENT_ID, Value::from(id.into()))
    }

    pub fn set_event_lifetime(&mut self, lifetime: impl Into<String>) -> &mut Self {
        self.set_raw(KEY_EVENT_LIFETIME, Value::from(lifetime.into()))
    }

    pub fn set_event_cause(&mut self, cause: impl Into<String>) -> &mut Self {
        self.set_raw(KEY_EVENT_CAUSE, Value::from(cause.into()))
    }

    pub fn set_event_refreshed(&mut self, refreshed: bool) -> &mut Self {
        self.set_raw(KEY_EVENT_REFRESHED, Value::from(refreshed))
    }

    // ── Variable ──────────────────────────────────────────────────

    pub fn set_variable_name(&mut self, name: impl Into<String>) -> &mut Self {
        self.set_raw(KEY_VARIABLE_NAME, Value::from(name.into()))
    }

    pub fn set_variable_status(&mut self, status: impl Into<String>) -> &mut Self {
        self.set_raw(KEY_VARIABLE_STATUS, Value::from(status.into()))
    }

    pub fn set_variable_value(&mut self, value: Value) -> &mut Self {
        self.set_raw(KEY_VARIABLE_VALUE, value)
    }

    // ── Config ────────────────────────────────────────────────────

    pub fn set_config_name(&mut self, name: impl Into<String>) -> &mut Self {
        let n: String = name.into();
        self.inner
            .insert(KEY_CONFIG_NAME.to_string(), Value::from(n.clone()));
        self.inner.insert(KEY_AGENT_ID.to_string(), Value::from(n));
        self
    }

    pub fn set_config_version(&mut self, version: impl Into<String>) -> &mut Self {
        self.set_raw(KEY_CONFIG_VERSION, Value::from(version.into()))
    }

    // ── Identity ──────────────────────────────────────────────────

    pub fn set_session_id(&mut self, id: impl Into<String>) -> &mut Self {
        self.set_raw(KEY_SESSION_ID, Value::from(id.into()))
    }

    /// Stamp `agent_shield.agent_id` from `metadata.name` per §19.3. Use
    /// this when only the agent identifier is known (e.g. the dispatcher
    /// stamps it on every minted event); [`Self::set_config_name`] also
    /// populates this key.
    pub fn set_agent_id(&mut self, id: impl Into<String>) -> &mut Self {
        self.set_raw(KEY_AGENT_ID, Value::from(id.into()))
    }

    pub fn set_correlation_id(&mut self, id: impl Into<String>) -> &mut Self {
        self.set_raw(KEY_CORRELATION_ID, Value::from(id.into()))
    }

    pub fn set_user_id(&mut self, id: impl Into<String>) -> &mut Self {
        self.set_raw(KEY_USER_ID, Value::from(id.into()))
    }

    pub fn set_tenant_id(&mut self, id: impl Into<String>) -> &mut Self {
        self.set_raw(KEY_TENANT_ID, Value::from(id.into()))
    }

    // ── Load errors ───────────────────────────────────────────────

    pub fn set_load_file(&mut self, path: impl Into<String>) -> &mut Self {
        self.set_raw(KEY_LOAD_FILE, Value::from(path.into()))
    }

    pub fn set_load_message(&mut self, msg: impl Into<String>) -> &mut Self {
        self.set_raw(KEY_LOAD_MESSAGE, Value::from(msg.into()))
    }
}

// ── Tests ───────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn known_keys_are_unique_and_namespaced() {
        let mut seen = std::collections::HashSet::new();
        for k in KNOWN_KEYS {
            assert!(k.starts_with("agent_shield."), "key {k} not namespaced");
            assert!(seen.insert(*k), "duplicate key in KNOWN_KEYS: {k}");
        }
    }

    #[test]
    fn typed_setters_use_canonical_keys() {
        let mut a = AgentShieldAttributes::new();
        a.set_event_type(EventType::GuardPolicyFailed);
        a.set_stage(Stage::State);
        a.set_action(Action::Block);
        a.set_severity(Severity::High);
        a.set_category("guardrail.evaluation");
        a.set_message("blocked");
        a.set_reason("not authorized");
        a.set_guard_policy("send_requires_authorization");
        a.set_evaluate_when_index(2);
        a.set_guard_policy_reason("Send was not authorized.");
        a.set_allowed_when_bypassed(false);
        let m = a.into_map();

        assert_eq!(m.get(KEY_EVENT_TYPE).unwrap(), "guard_policy_failed");
        assert_eq!(m.get(KEY_STAGE).unwrap(), "state");
        assert_eq!(m.get(KEY_ACTION).unwrap(), "block");
        assert_eq!(m.get(KEY_SEVERITY).unwrap(), "high");
        assert_eq!(m.get(KEY_CATEGORY).unwrap(), "guardrail.evaluation");
        assert_eq!(m.get(KEY_MESSAGE).unwrap(), "blocked");
        assert_eq!(m.get(KEY_REASON).unwrap(), "not authorized");
        assert_eq!(
            m.get(KEY_GUARD_POLICY).unwrap(),
            "send_requires_authorization"
        );
        // §19.3-aligned attribute key.
        assert_eq!(
            m.get("agent_shield.guard_policy").unwrap(),
            "send_requires_authorization"
        );
        assert_eq!(m.get(KEY_EVALUATE_WHEN_INDEX).unwrap(), 2);
        assert_eq!(m.get("agent_shield.evaluate_when_index").unwrap(), 2);
        assert_eq!(
            m.get(KEY_GUARD_POLICY_ALLOWED_WHEN_BYPASSED).unwrap(),
            false
        );
    }

    #[test]
    fn resolver_setters_serialize() {
        let mut a = AgentShieldAttributes::new();
        a.set_resolver_kind("human");
        a.set_resolver_variable("approval_for_send");
        a.set_resolver_decision("allow");
        a.set_resolver_latency_ms(123);
        a.set_resolver_error("timeout");
        let m = a.into_map();
        assert_eq!(m.get(KEY_RESOLVER_KIND).unwrap(), "human");
        assert_eq!(m.get(KEY_RESOLVER_VARIABLE).unwrap(), "approval_for_send");
        assert_eq!(m.get(KEY_RESOLVER_DECISION).unwrap(), "allow");
        assert_eq!(m.get(KEY_RESOLVER_LATENCY_MS).unwrap(), 123);
        assert_eq!(m.get(KEY_RESOLVER_ERROR).unwrap(), "timeout");
    }

    #[test]
    fn resource_tool_kind_emits_v1_alias() {
        let mut a = AgentShieldAttributes::new();
        a.set_resource(ResourceKind::Tool, "send_email");
        let m = a.into_map();
        assert_eq!(m.get(KEY_RESOURCE_KIND).unwrap(), "tool");
        assert_eq!(m.get(KEY_RESOURCE_NAME).unwrap(), "send_email");
        assert_eq!(m.get(KEY_RESOURCE_TOOL_ALIAS).unwrap(), "send_email");
    }

    #[test]
    fn resource_non_tool_kind_omits_alias() {
        let mut a = AgentShieldAttributes::new();
        a.set_resource(ResourceKind::Agent, "planner");
        let m = a.into_map();
        assert_eq!(m.get(KEY_RESOURCE_KIND).unwrap(), "agent");
        assert_eq!(m.get(KEY_RESOURCE_NAME).unwrap(), "planner");
        assert!(!m.contains_key(KEY_RESOURCE_TOOL_ALIAS));
    }

    #[test]
    fn event_setters_serialize() {
        let mut a = AgentShieldAttributes::new();
        a.set_event_id("guard_policy.foo.failed");
        a.set_event_lifetime("for: 30s");
        a.set_event_cause("expired");
        a.set_event_refreshed(true);
        let m = a.into_map();
        assert_eq!(m.get(KEY_EVENT_ID).unwrap(), "guard_policy.foo.failed");
        assert_eq!(m.get(KEY_EVENT_LIFETIME).unwrap(), "for: 30s");
        assert_eq!(m.get(KEY_EVENT_CAUSE).unwrap(), "expired");
        assert_eq!(m.get(KEY_EVENT_REFRESHED).unwrap(), true);
    }

    #[test]
    fn variable_setters_serialize() {
        let mut a = AgentShieldAttributes::new();
        a.set_variable_name("approval_for_send");
        a.set_variable_status("resolved");
        a.set_variable_value(serde_json::json!({"value": "allow"}));
        let m = a.into_map();
        assert_eq!(m.get(KEY_VARIABLE_NAME).unwrap(), "approval_for_send");
        assert_eq!(m.get(KEY_VARIABLE_STATUS).unwrap(), "resolved");
        assert!(m.get(KEY_VARIABLE_VALUE).unwrap().is_object());
    }

    #[test]
    fn config_name_emits_agent_id_alias() {
        let mut a = AgentShieldAttributes::new();
        a.set_config_name("bank-manager");
        a.set_config_version("0.1.0");
        let m = a.into_map();
        assert_eq!(m.get(KEY_CONFIG_NAME).unwrap(), "bank-manager");
        assert_eq!(m.get(KEY_AGENT_ID).unwrap(), "bank-manager");
        assert_eq!(m.get(KEY_CONFIG_VERSION).unwrap(), "0.1.0");
    }

    #[test]
    fn identity_setters_serialize() {
        let mut a = AgentShieldAttributes::new();
        a.set_session_id("s-1");
        a.set_correlation_id("c-1");
        a.set_user_id("u-1");
        a.set_tenant_id("t-1");
        let m = a.into_map();
        assert_eq!(m.get(KEY_SESSION_ID).unwrap(), "s-1");
        assert_eq!(m.get(KEY_CORRELATION_ID).unwrap(), "c-1");
        assert_eq!(m.get(KEY_USER_ID).unwrap(), "u-1");
        assert_eq!(m.get(KEY_TENANT_ID).unwrap(), "t-1");
    }

    #[test]
    fn load_setters_serialize() {
        let mut a = AgentShieldAttributes::new();
        a.set_load_file("/path/to/.guardrails.yaml");
        a.set_load_message("expected mapping at line 4");
        let m = a.into_map();
        assert_eq!(m.get(KEY_LOAD_FILE).unwrap(), "/path/to/.guardrails.yaml");
        assert_eq!(
            m.get(KEY_LOAD_MESSAGE).unwrap(),
            "expected mapping at line 4"
        );
    }

    #[test]
    fn raw_setter_passes_through() {
        let mut a = AgentShieldAttributes::new();
        a.set_raw("custom.tag", Value::from("hello"));
        assert_eq!(a.get("custom.tag").unwrap(), "hello");
    }

    #[test]
    fn every_action_variant_serializes_to_snake_case() {
        for (action, expected) in [
            (Action::Block, "block"),
            (Action::Redact, "redact"),
            (Action::Warn, "warn"),
            (Action::Append, "append"),
            (Action::Prepend, "prepend"),
        ] {
            let mut a = AgentShieldAttributes::new();
            a.set_action(action);
            assert_eq!(a.get(KEY_ACTION).unwrap(), expected);
        }
    }
}
