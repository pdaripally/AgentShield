//! Shared `#[cfg(test)]` helpers for the observability test suite.
//!
//! Kept in its own module so `dispatcher.rs` and `emitter.rs` can both
//! reuse [`CaptureProvider`] without exposing private test items across
//! sibling modules.

#![cfg(test)]

use std::sync::{Arc, Mutex};

use super::event::ShieldLogEvent;
use super::provider::ObservabilityProvider;

/// A capturing [`ObservabilityProvider`] for use in unit tests.
/// Stores every emitted event in an internal `Vec` so tests can inspect
/// what reached the provider, and counts shutdown calls.
pub(crate) struct CaptureProvider {
    pub events: Arc<Mutex<Vec<ShieldLogEvent>>>,
    pub shutdown_count: Arc<Mutex<usize>>,
}

impl CaptureProvider {
    pub(crate) fn new() -> Arc<Self> {
        Arc::new(Self {
            events: Arc::new(Mutex::new(Vec::new())),
            shutdown_count: Arc::new(Mutex::new(0)),
        })
    }
}

impl ObservabilityProvider for CaptureProvider {
    fn emit(&self, event: ShieldLogEvent) {
        self.events.lock().unwrap().push(event);
    }
    fn shutdown(&self) {
        *self.shutdown_count.lock().unwrap() += 1;
    }
}
