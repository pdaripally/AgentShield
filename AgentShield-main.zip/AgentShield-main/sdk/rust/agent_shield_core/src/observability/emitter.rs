//! Canonical emitters for the §19.5 required log events that the host
//! runtime triggers manually (gating verdicts, resolver invocations,
//! load errors, warn-mode surfacing).
//!
//! Closed-namespace events from §9.3 are mirrored automatically by
//! [`ObservabilityDispatcher`]'s bus subscriber — the helpers here
//! cover the rest of §19.5.
//!
//! Each helper builds a correctly-shaped [`ShieldLogEvent`] and calls
//! [`ObservabilityDispatcher::emit`]. Severity is selected per §19.1:
//!
//! | Helper                                | Severity baseline                     |
//! |---------------------------------------|---------------------------------------|
//! | `log_guard_policy_evaluation`         | follows action: warn ⇒ high; block/redact ⇒ medium; allow ⇒ info; allowed_when bypass ⇒ info |
//! | `log_resolver_invoked`                | info (audit log)                      |
//! | `log_gating_verdict`                  | block ⇒ medium; allow ⇒ info          |
//! | `log_load_error`                      | critical                              |
//! | `log_warning`                         | high (warn-mode default §19.1)        |

use super::attributes::AgentShieldAttributes;
use super::dispatcher::ObservabilityDispatcher;
use super::event::{Action, EventType, LogAction, Severity, ShieldLogEvent, Stage};

/// Severity selection for a guard-policy evaluation per §19.1.
fn severity_for_evaluation(action: Option<Action>, allowed_when_bypassed: bool) -> Severity {
    if allowed_when_bypassed {
        // §12.6 — bypass auto-resolution audits at info.
        return Severity::Info;
    }
    match action {
        Some(Action::Warn) => Severity::High, // warn defaults louder so shadow rollouts are visible
        Some(Action::Block) | Some(Action::Redact) => Severity::Medium,
        Some(Action::Append) | Some(Action::Prepend) => Severity::Medium,
        Some(Action::DeclassifyTo) => Severity::Info, // declassification is admit + side-effect
        None => Severity::Info,                       // pass / allow
    }
}

/// EventType for a guard-policy evaluation. When the guard policy passed
/// (no action), we emit `GuardPolicyPassed` so observers can route by
/// outcome; when an action fired, we emit `GuardrailEvaluation` with the
/// action attached.
fn event_type_for_evaluation(action: Option<Action>, allowed_when_bypassed: bool) -> EventType {
    if allowed_when_bypassed {
        EventType::GuardPolicyPassed
    } else {
        match action {
            None => EventType::GuardPolicyPassed,
            Some(_) => EventType::GuardrailEvaluation,
        }
    }
}

/// LogAction for a guard-policy evaluation per §19.1. A pass — and a
/// failure suppressed by `allowed_when:` (§12.6) — log as `allow`. An
/// active enforcement carries the corresponding action verbatim.
fn log_action_for_evaluation(
    action: Option<Action>,
    allowed_when_bypassed: bool,
) -> Option<LogAction> {
    if allowed_when_bypassed {
        return Some(LogAction::Allow);
    }
    match action {
        None => Some(LogAction::Allow),
        Some(a) => Some(a.into()),
    }
}

/// Log a guard-policy evaluation outcome (§19.5 — gating decisions are
/// always logged).
///
/// `session_id` is the originating session (§19.2 — required top-level
/// field on every log event); pass an empty `&str` only for ad-hoc
/// callers that have no session context (none in the production
/// runtime, but a few internal tests).
///
/// `action = None` means the guard policy evaluation passed (allow);
/// `allowed_when_bypassed = true` means a failure was suppressed by the
/// guard policy's `allowed_when:` per §12.6 — the spec requires we log
/// it as an `allow` for the guard policy.
#[allow(clippy::too_many_arguments)]
pub fn log_guard_policy_evaluation(
    dispatcher: &ObservabilityDispatcher,
    session_id: &str,
    policy_name: &str,
    stage: Stage,
    evaluate_when_index: Option<usize>,
    action: Option<Action>,
    reason: &str,
    allowed_when_bypassed: bool,
) {
    let severity = severity_for_evaluation(action, allowed_when_bypassed);
    let event_type = event_type_for_evaluation(action, allowed_when_bypassed);
    let log_action = log_action_for_evaluation(action, allowed_when_bypassed);

    let mut attrs = AgentShieldAttributes::new();
    attrs.set_event_type(event_type);
    attrs.set_severity(severity);
    attrs.set_stage(stage);
    attrs.set_guard_policy(policy_name);
    if let Some(idx) = evaluate_when_index {
        attrs.set_evaluate_when_index(idx);
    }
    if let Some(la) = log_action {
        attrs.set_action(la);
    }
    if !reason.is_empty() {
        attrs.set_guard_policy_reason(reason);
    }
    if allowed_when_bypassed {
        attrs.set_allowed_when_bypassed(true);
    }

    let mut ev = ShieldLogEvent::new(event_type, severity, "guardrail.evaluation")
        .with_session_id(session_id)
        .with_stage(stage)
        .with_guard_policy(policy_name)
        .with_message(if reason.is_empty() {
            format!("guard policy `{}` evaluated", policy_name)
        } else {
            reason.to_string()
        });
    if let Some(idx) = evaluate_when_index {
        ev = ev.with_evaluate_when_index(idx);
    }
    if let Some(la) = log_action {
        ev = ev.with_action(la);
    }
    ev = ev.merge_attributes(attrs.into_map());

    dispatcher.emit(ev);
}

/// Log a resolver invocation (§11.9 / §19.4 — always emitted regardless
/// of decision). `decision` is the final resolver outcome (`allow`,
/// `deny`, `cancelled`, `pending`, etc.); `lifetime` is the resolver's
/// declared `lifetime:` — the bare-form string from §9.1.1 — when
/// available; pass `None` for resolvers without a declared lifetime.
///
/// `session_id` is the originating session (§19.2 — required top-level
/// field); pass an empty `&str` for runtime-level invocations that
/// occur outside a session context.
pub fn log_resolver_invoked(
    dispatcher: &ObservabilityDispatcher,
    session_id: &str,
    kind: &str,
    variable: &str,
    decision: &str,
    lifetime: Option<&str>,
    reason: Option<&str>,
) {
    let mut attrs = AgentShieldAttributes::new();
    attrs.set_event_type(EventType::ResolverInvoked);
    attrs.set_severity(Severity::Info);
    attrs.set_resolver_kind(kind);
    attrs.set_resolver_variable(variable);
    attrs.set_resolver_decision(decision);
    if let Some(l) = lifetime {
        if !l.is_empty() {
            attrs.set_event_lifetime(l);
        }
    }
    if let Some(r) = reason {
        if !r.is_empty() {
            attrs.set_reason(r);
        }
    }

    let ev = ShieldLogEvent::new(
        EventType::ResolverInvoked,
        Severity::Info,
        "resolver.invoked",
    )
    .with_session_id(session_id)
    .with_variable(variable)
    .with_message(format!(
        "resolver `{}` invoked for `{}` -> {}",
        kind, variable, decision
    ))
    .merge_attributes(attrs.into_map());

    dispatcher.emit(ev);
}

/// Log a resolver invocation with full audit fields (§11.9). Adds the
/// `latency_ms` field, an optional `lifetime` (§9.1.1 bare-form string),
/// and an optional `error_kind`. Per §19.1 the event severity defaults
/// to `info` on success; an invocation that surfaced an `error_kind`
/// elevates to `high` because resolver failures are security-relevant.
///
/// `session_id` is the originating session (§19.2 — required top-level
/// field); pass an empty `&str` for runtime-level invocations that
/// occur outside a session context.
#[allow(clippy::too_many_arguments)]
pub fn log_resolver_invoked_full(
    dispatcher: &ObservabilityDispatcher,
    session_id: &str,
    kind: &str,
    variable: &str,
    decision: &str,
    latency_ms: u64,
    lifetime: Option<&str>,
    error_kind: Option<&str>,
    reason: Option<&str>,
) {
    let severity = if error_kind.is_some_and(|e| !e.is_empty()) {
        Severity::High
    } else {
        Severity::Info
    };

    let mut attrs = AgentShieldAttributes::new();
    attrs.set_event_type(EventType::ResolverInvoked);
    attrs.set_severity(severity);
    attrs.set_resolver_kind(kind);
    attrs.set_resolver_variable(variable);
    attrs.set_resolver_decision(decision);
    attrs.set_resolver_latency_ms(latency_ms);
    if let Some(l) = lifetime {
        if !l.is_empty() {
            attrs.set_event_lifetime(l);
        }
    }
    if let Some(e) = error_kind {
        if !e.is_empty() {
            attrs.set_resolver_error(e);
        }
    }
    if let Some(r) = reason {
        if !r.is_empty() {
            attrs.set_reason(r);
        }
    }

    let ev = ShieldLogEvent::new(EventType::ResolverInvoked, severity, "resolver.invoked")
        .with_session_id(session_id)
        .with_variable(variable)
        .with_message(format!(
            "resolver `{}` invoked for `{}` -> {} ({} ms)",
            kind, variable, decision, latency_ms
        ))
        .merge_attributes(attrs.into_map());

    dispatcher.emit(ev);
}

/// Log a stage gating verdict (§19.5 — all gating decisions). `allowed`
/// drives severity: blocks log at medium; allows at info. The `action`
/// field always carries the §19.1-aligned value — `allow` for passes,
/// `block` for denials.
///
/// `session_id` is the originating session (§19.2 — required top-level
/// field); pass an empty `&str` only for ad-hoc callers without a
/// session context.
pub fn log_gating_verdict(
    dispatcher: &ObservabilityDispatcher,
    session_id: &str,
    stage: Stage,
    allowed: bool,
    reason: &str,
) {
    let severity = if allowed {
        Severity::Info
    } else {
        Severity::Medium
    };
    let log_action = if allowed {
        LogAction::Allow
    } else {
        LogAction::Block
    };

    let mut attrs = AgentShieldAttributes::new();
    attrs.set_event_type(EventType::GatingVerdict);
    attrs.set_severity(severity);
    attrs.set_stage(stage);
    attrs.set_action(log_action);
    if !reason.is_empty() {
        attrs.set_reason(reason);
    }

    let ev = ShieldLogEvent::new(EventType::GatingVerdict, severity, "gating.verdict")
        .with_session_id(session_id)
        .with_stage(stage)
        .with_action(log_action)
        .with_message(if allowed {
            format!("stage `{}` allowed", stage.as_str())
        } else {
            format!("stage `{}` blocked: {}", stage.as_str(), reason)
        })
        .merge_attributes(attrs.into_map());

    dispatcher.emit(ev);
}

/// Log a configuration load error (§19.1 — load errors are critical).
///
/// Load errors are emitted before any session exists, so this helper
/// does not accept a `session_id` — the field stays empty on the
/// produced event (§19.2 permits the empty-string runtime-level
/// session).
pub fn log_load_error(dispatcher: &ObservabilityDispatcher, file_path: &str, message: &str) {
    let mut attrs = AgentShieldAttributes::new();
    attrs.set_event_type(EventType::LoadError);
    attrs.set_severity(Severity::Critical);
    attrs.set_load_file(file_path);
    attrs.set_load_message(message);

    let ev = ShieldLogEvent::new(
        EventType::LoadError,
        Severity::Critical,
        "config.load_error",
    )
    .with_message(format!("load error in {}: {}", file_path, message))
    .merge_attributes(attrs.into_map());

    dispatcher.emit(ev);
}

/// Log a generic warning. Defaults to `high` severity per §19.1's
/// "warn-mode is louder by default" rule — this helper covers warn-mode
/// surfacing where no `log:` block is configured.
///
/// `session_id` is the originating session (§19.2 — required top-level
/// field); pass an empty `&str` for runtime-level warnings without a
/// session context.
pub fn log_warning(
    dispatcher: &ObservabilityDispatcher,
    session_id: &str,
    category: &str,
    message: &str,
) {
    let mut attrs = AgentShieldAttributes::new();
    attrs.set_event_type(EventType::Warning);
    attrs.set_severity(Severity::High);
    if !category.is_empty() {
        attrs.set_category(category);
    }
    if !message.is_empty() {
        attrs.set_message(message);
    }

    let ev = ShieldLogEvent::new(EventType::Warning, Severity::High, category)
        .with_session_id(session_id)
        .with_message(message)
        .merge_attributes(attrs.into_map());

    dispatcher.emit(ev);
}

// ── Tests ───────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::super::attributes::{
        KEY_ACTION, KEY_EVALUATE_WHEN_INDEX, KEY_EVENT_LIFETIME, KEY_EVENT_TYPE, KEY_GUARD_POLICY,
        KEY_GUARD_POLICY_ALLOWED_WHEN_BYPASSED, KEY_GUARD_POLICY_REASON, KEY_LOAD_FILE,
        KEY_LOAD_MESSAGE, KEY_REASON, KEY_RESOLVER_DECISION, KEY_RESOLVER_ERROR, KEY_RESOLVER_KIND,
        KEY_RESOLVER_LATENCY_MS, KEY_RESOLVER_VARIABLE, KEY_SEVERITY, KEY_STAGE,
    };
    use super::super::test_support::CaptureProvider;
    use super::*;
    use crate::event_bus::EventBus;

    fn fresh() -> (
        std::sync::Arc<ObservabilityDispatcher>,
        std::sync::Arc<CaptureProvider>,
    ) {
        let bus = EventBus::new();
        let d = ObservabilityDispatcher::new(bus);
        let p = CaptureProvider::new();
        d.register_provider(p.clone());
        (d, p)
    }

    #[test]
    fn guard_policy_evaluation_block_logs_at_medium() {
        let (d, p) = fresh();
        log_guard_policy_evaluation(
            &d,
            "sess-1",
            "send_requires_authorization",
            Stage::State,
            Some(0),
            Some(Action::Block),
            "Send was not authorized.",
            false,
        );
        let events = p.events.lock().unwrap();
        assert_eq!(events.len(), 1);
        let ev = &events[0];
        assert_eq!(ev.event_type, EventType::GuardrailEvaluation);
        assert_eq!(ev.severity, Severity::Medium);
        assert_eq!(ev.stage, Some(Stage::State));
        assert_eq!(ev.action, Some(LogAction::Block));
        assert_eq!(ev.evaluate_when_index, Some(0));
        assert_eq!(ev.session_id, "sess-1");
        assert_eq!(
            ev.guard_policy.as_deref(),
            Some("send_requires_authorization")
        );
        let attrs = &ev.attributes;
        assert_eq!(attrs.get(KEY_EVENT_TYPE).unwrap(), "validation_triggered");
        assert_eq!(attrs.get(KEY_STAGE).unwrap(), "state");
        assert_eq!(attrs.get(KEY_ACTION).unwrap(), "block");
        assert_eq!(attrs.get(KEY_SEVERITY).unwrap(), "medium");
        assert_eq!(attrs.get(KEY_EVALUATE_WHEN_INDEX).unwrap(), 0);
        assert_eq!(
            attrs.get(KEY_GUARD_POLICY).unwrap(),
            "send_requires_authorization"
        );
        assert_eq!(
            attrs.get(KEY_GUARD_POLICY_REASON).unwrap(),
            "Send was not authorized."
        );
    }

    #[test]
    fn guard_policy_evaluation_warn_logs_at_high() {
        let (d, p) = fresh();
        log_guard_policy_evaluation(
            &d,
            "sess-warn",
            "shadow_check",
            Stage::Output,
            Some(1),
            Some(Action::Warn),
            "Output looks suspicious.",
            false,
        );
        let events = p.events.lock().unwrap();
        let ev = &events[0];
        assert_eq!(ev.severity, Severity::High);
        assert_eq!(ev.event_type, EventType::GuardrailEvaluation);
        assert_eq!(ev.action, Some(LogAction::Warn));
        assert_eq!(ev.session_id, "sess-warn");
    }

    #[test]
    fn guard_policy_evaluation_allow_logs_as_passed_at_info() {
        let (d, p) = fresh();
        log_guard_policy_evaluation(&d, "", "no_secrets", Stage::Output, None, None, "", false);
        let events = p.events.lock().unwrap();
        let ev = &events[0];
        assert_eq!(ev.event_type, EventType::GuardPolicyPassed);
        assert_eq!(ev.severity, Severity::Info);
        // §19.1: a pass logs `action: allow`.
        assert_eq!(ev.action, Some(LogAction::Allow));
        assert_eq!(ev.attributes.get(KEY_ACTION).unwrap(), "allow");
    }

    #[test]
    fn guard_policy_evaluation_allowed_when_bypass_logs_as_passed_at_info() {
        let (d, p) = fresh();
        log_guard_policy_evaluation(
            &d,
            "sess-bypass",
            "send_requires_authorization",
            Stage::State,
            Some(0),
            Some(Action::Block),
            "bypassed by allowed_when",
            true,
        );
        let events = p.events.lock().unwrap();
        let ev = &events[0];
        assert_eq!(ev.event_type, EventType::GuardPolicyPassed);
        assert_eq!(ev.severity, Severity::Info);
        // §12.6: bypass logs `action: allow` regardless of the underlying
        // policy's enforcement action.
        assert_eq!(ev.action, Some(LogAction::Allow));
        assert_eq!(ev.attributes.get(KEY_ACTION).unwrap(), "allow");
        assert_eq!(ev.session_id, "sess-bypass");
        assert_eq!(
            ev.attributes
                .get(KEY_GUARD_POLICY_ALLOWED_WHEN_BYPASSED)
                .unwrap(),
            true
        );
    }

    #[test]
    fn guard_policy_evaluation_redact_logs_at_medium() {
        let (d, p) = fresh();
        log_guard_policy_evaluation(
            &d,
            "sess-redact",
            "pii_redact",
            Stage::Output,
            Some(0),
            Some(Action::Redact),
            "Redacted PII.",
            false,
        );
        let ev = &p.events.lock().unwrap()[0];
        assert_eq!(ev.severity, Severity::Medium);
        assert_eq!(ev.action, Some(LogAction::Redact));
        assert_eq!(ev.session_id, "sess-redact");
    }

    #[test]
    fn resolver_invoked_logs_at_info_with_kind_and_decision() {
        let (d, p) = fresh();
        log_resolver_invoked(
            &d,
            "sess-resolve",
            "human",
            "approve_send",
            "allow",
            Some("per_call"),
            Some("user clicked OK"),
        );
        let events = p.events.lock().unwrap();
        let ev = &events[0];
        assert_eq!(ev.event_type, EventType::ResolverInvoked);
        assert_eq!(ev.severity, Severity::Info);
        assert_eq!(ev.variable.as_deref(), Some("approve_send"));
        assert_eq!(ev.session_id, "sess-resolve");
        let attrs = &ev.attributes;
        assert_eq!(attrs.get(KEY_RESOLVER_KIND).unwrap(), "human");
        assert_eq!(attrs.get(KEY_RESOLVER_VARIABLE).unwrap(), "approve_send");
        assert_eq!(attrs.get(KEY_RESOLVER_DECISION).unwrap(), "allow");
        assert_eq!(attrs.get(KEY_EVENT_LIFETIME).unwrap(), "per_call");
        assert_eq!(attrs.get(KEY_REASON).unwrap(), "user clicked OK");
    }

    #[test]
    fn resolver_invoked_full_records_latency_and_error() {
        let (d, p) = fresh();
        log_resolver_invoked_full(
            &d,
            "sess-err",
            "delegate",
            "approve_send",
            "deny",
            42,
            Some("per_session"),
            Some("timeout"),
            None,
        );
        let ev = &p.events.lock().unwrap()[0];
        // §19.1: an errored resolver invocation elevates to `high`.
        assert_eq!(ev.severity, Severity::High);
        assert_eq!(ev.session_id, "sess-err");
        let attrs = &ev.attributes;
        assert_eq!(attrs.get(KEY_RESOLVER_LATENCY_MS).unwrap(), 42);
        assert_eq!(attrs.get(KEY_RESOLVER_ERROR).unwrap(), "timeout");
        assert_eq!(attrs.get(KEY_EVENT_LIFETIME).unwrap(), "per_session");
        assert_eq!(attrs.get(KEY_SEVERITY).unwrap(), "high");
    }

    #[test]
    fn resolver_invoked_full_success_logs_at_info() {
        let (d, p) = fresh();
        log_resolver_invoked_full(&d, "", "static", "v", "allow", 1, None, None, None);
        let ev = &p.events.lock().unwrap()[0];
        assert_eq!(ev.severity, Severity::Info);
        // No lifetime declared ⇒ no event.lifetime attribute.
        assert!(ev.attributes.get(KEY_EVENT_LIFETIME).is_none());
        assert!(ev.attributes.get(KEY_RESOLVER_ERROR).is_none());
    }

    #[test]
    fn gating_verdict_block_logs_at_medium_with_action() {
        let (d, p) = fresh();
        log_gating_verdict(&d, "sess-block", Stage::Input, false, "blocked by p1");
        let ev = &p.events.lock().unwrap()[0];
        assert_eq!(ev.event_type, EventType::GatingVerdict);
        assert_eq!(ev.severity, Severity::Medium);
        assert_eq!(ev.action, Some(LogAction::Block));
        assert_eq!(ev.stage, Some(Stage::Input));
        assert_eq!(ev.session_id, "sess-block");
        assert!(ev.message.contains("blocked"));
    }

    #[test]
    fn gating_verdict_allow_logs_at_info_with_allow_action() {
        let (d, p) = fresh();
        log_gating_verdict(&d, "sess-allow", Stage::Input, true, "");
        let ev = &p.events.lock().unwrap()[0];
        assert_eq!(ev.severity, Severity::Info);
        // §19.1: allow gating verdict carries `action: allow`.
        assert_eq!(ev.action, Some(LogAction::Allow));
        assert_eq!(ev.attributes.get(KEY_ACTION).unwrap(), "allow");
        assert_eq!(ev.session_id, "sess-allow");
    }

    #[test]
    fn load_error_logs_at_critical() {
        let (d, p) = fresh();
        log_load_error(&d, "/path/.guardrails.yaml", "missing metadata.name");
        let ev = &p.events.lock().unwrap()[0];
        assert_eq!(ev.event_type, EventType::LoadError);
        assert_eq!(ev.severity, Severity::Critical);
        let attrs = &ev.attributes;
        assert_eq!(attrs.get(KEY_LOAD_FILE).unwrap(), "/path/.guardrails.yaml");
        assert_eq!(
            attrs.get(KEY_LOAD_MESSAGE).unwrap(),
            "missing metadata.name"
        );
    }

    #[test]
    fn warning_logs_at_high() {
        let (d, p) = fresh();
        log_warning(&d, "sess-warning", "shadow.rollout", "warn-mode triggered");
        let ev = &p.events.lock().unwrap()[0];
        assert_eq!(ev.event_type, EventType::Warning);
        assert_eq!(ev.severity, Severity::High);
        assert_eq!(ev.category, "shadow.rollout");
        assert_eq!(ev.session_id, "sess-warning");
    }

    #[test]
    fn helpers_fan_out_to_multiple_providers() {
        let bus = EventBus::new();
        let d = ObservabilityDispatcher::new(bus);
        let p1 = CaptureProvider::new();
        let p2 = CaptureProvider::new();
        d.register_provider(p1.clone());
        d.register_provider(p2.clone());

        log_warning(&d, "", "x", "y");
        log_resolver_invoked(&d, "", "static", "v", "allow", None, None);
        log_gating_verdict(&d, "", Stage::Input, true, "");

        assert_eq!(p1.events.lock().unwrap().len(), 3);
        assert_eq!(p2.events.lock().unwrap().len(), 3);
    }

    #[test]
    fn severity_helper_handles_append_and_prepend() {
        assert_eq!(
            severity_for_evaluation(Some(Action::Append), false),
            Severity::Medium
        );
        assert_eq!(
            severity_for_evaluation(Some(Action::Prepend), false),
            Severity::Medium
        );
    }
}
