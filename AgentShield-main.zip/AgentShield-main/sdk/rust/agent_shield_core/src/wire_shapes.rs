//! Canonical wire-shape parsers for host callbacks (§11.3, §12.5.1, §12.9.3).
//!
//! Every language binding (Python, Node, .NET, raw C) must agree on
//! exactly one set of rules for turning a host callback's return value
//! into a typed Rust shape. Without that, each binding ends up with its
//! own slightly-different fail-closed boundary — and any divergence is a
//! latent security bug. (cf. the PyLlmCaller silent fail-closed bug
//! fixed in 31ae2c4: that bridge accepted bare-word strings and Python
//! dicts but not JSON-encoded strings, the natural shape returned by
//! every modern LLM client.)
//!
//! This module is the single source of truth. Bindings MUST route every
//! callback return through one of the `parse_*_json` functions here, and
//! every callback request through the matching `serialize_*_json` helper.
//!
//! # Fail-closed semantics
//!
//! The runtime invariant is: **any input the parser does not understand
//! MUST produce a `BLOCK` / `Deny` shape** (§12.9.3 ¶3, §11.3). Every
//! parser below is total — it never returns an error to the caller, only
//! a typed shape that may carry a "deny because: …" reason. Callers that
//! need to distinguish "host returned no response at all" from "host
//! returned a malformed envelope" should detect the missing-response
//! case before invoking these parsers.

use std::collections::HashMap;

use serde_json::{Map, Value};

use crate::guard_policy_runtime::detection::{ClassifierVerdict, LlmDecision, LlmResponse, Span};
use crate::resolver::{ResolverDecision, ResolverResponse};
use crate::resolver_runtime::{AgentResolveRequest, DelegateRequest};
use crate::variables::ResourceKind;

// ────────────────────────────────────────────────────────────────────
// LLM response (§12.9.3)
// ────────────────────────────────────────────────────────────────────

/// Parse a host LLM caller's return value into [`LlmResponse`].
///
/// Accepts:
/// - Bare-word strings: `"allow"`, `"ALLOW"`, `"Allow"`, `"block"`,
///   `"BLOCK"`, `"pass"`, `"fail"`, `"deny"` (and any leading/trailing
///   whitespace).
/// - JSON envelope strings: `{"decision": "allow|block", "confidence":
///   …, "reason": …, "categories": […], "spans": […], "bool_flags":
///   {…}}`. Top-level boolean fields outside the reserved keys are
///   collected into `bool_flags` (so a host returning `{"is_jailbreak":
///   true}` produces a BLOCK per §12.9.3 ¶2).
///
/// Any other input — empty string, malformed JSON, JSON of the wrong
/// shape — produces an [`LlmResponse::default()`] which folds to
/// [`LlmDecision::Block`] per §12.9.3 ¶3.
///
/// **Markdown code-fence tolerance.** LLMs routinely wrap their JSON in
/// ```` ```json ... ``` ```` despite explicit "JSON only" instructions.
/// Accepting only strict JSON would mean every popular chat model would
/// fail-closed on legitimate ALLOW verdicts. So we strip a single
/// outermost ```` ``` ```` fence (with optional language tag) when
/// strict-JSON parsing fails, then re-parse. The §12.9.3 fail-closed
/// guarantee still applies to anything that doesn't parse after the
/// fence strip.
pub fn parse_llm_response_json(raw: &str) -> LlmResponse {
    let trimmed = raw.trim();

    // Bare-word shorthand. We accept what every host might naturally
    // emit — uppercase, lowercase, and the `pass`/`fail`/`deny` aliases
    // that map onto allow/block at the §12.9.3 wire layer.
    if let Some(decision) = parse_llm_decision_word(trimmed) {
        return LlmResponse {
            decision: Some(decision),
            ..Default::default()
        };
    }

    // JSON envelope. Try strict first; if that fails and the input
    // looks like a markdown code fence, strip the fence and retry.
    let value: Value = match serde_json::from_str(trimmed) {
        Ok(v) => v,
        Err(_) => match strip_code_fence(trimmed) {
            Some(unfenced) => match serde_json::from_str(unfenced) {
                Ok(v) => v,
                // Fence stripped but inner body still doesn't parse —
                // fail closed per §12.9.3 ¶3.
                Err(_) => return LlmResponse::default(),
            },
            // Not fenced and not parseable — fail closed.
            None => return LlmResponse::default(),
        },
    };

    // A JSON string at the top level (e.g. the host JSON-encoded a bare
    // word into `"\"allow\""`) is also handled.
    if let Some(s) = value.as_str() {
        if let Some(decision) = parse_llm_decision_word(s.trim()) {
            return LlmResponse {
                decision: Some(decision),
                ..Default::default()
            };
        }
        return LlmResponse::default();
    }

    let obj = match value.as_object() {
        Some(o) => o,
        None => return LlmResponse::default(),
    };

    let decision = obj
        .get("decision")
        .and_then(|d| d.as_str())
        .and_then(parse_llm_decision_word);
    let confidence = obj.get("confidence").and_then(|c| c.as_f64());
    let reason = obj
        .get("reason")
        .and_then(|r| r.as_str())
        .map(|s| s.to_string());
    let categories: Vec<String> = obj
        .get("categories")
        .and_then(|c| c.as_array())
        .map(|arr| {
            arr.iter()
                .filter_map(|x| x.as_str().map(|s| s.to_string()))
                .collect()
        })
        .unwrap_or_default();

    let mut bool_flags: HashMap<String, bool> = HashMap::new();
    if let Some(flags) = obj.get("bool_flags").and_then(|f| f.as_object()) {
        for (k, vv) in flags {
            if let Some(b) = vv.as_bool() {
                bool_flags.insert(k.clone(), b);
            }
        }
    }
    // Top-level boolean shorthand fields per §12.9.3 ¶2 — `contains_pii:
    // true`, `is_jailbreak: true`, etc. fold into `bool_flags`.
    for (k, vv) in obj {
        if matches!(
            k.as_str(),
            "decision" | "confidence" | "reason" | "categories" | "spans" | "bool_flags"
        ) {
            continue;
        }
        if let Some(b) = vv.as_bool() {
            bool_flags.insert(k.clone(), b);
        }
    }

    LlmResponse {
        decision,
        confidence,
        reason,
        categories,
        spans: parse_spans_array(obj.get("spans")),
        bool_flags,
    }
}

/// Map a bare LLM decision word (any case) to an [`LlmDecision`].
/// Returns `None` for anything unrecognized — callers MUST treat that as
/// fail-closed (§12.9.3 ¶3).
fn parse_llm_decision_word(s: &str) -> Option<LlmDecision> {
    match s.trim().to_ascii_lowercase().as_str() {
        "allow" | "pass" => Some(LlmDecision::Allow),
        "block" | "fail" | "deny" => Some(LlmDecision::Block),
        _ => None,
    }
}

/// Strip a single outermost markdown code fence (with optional language
/// tag) from `raw`. Returns `Some(inner)` if `raw` starts with three
/// backticks (or three tildes) and ends with the same; otherwise
/// returns `None`.
///
/// Defensive only — the runtime calls this when strict JSON parsing
/// fails on a model's response. Models routinely emit
/// ```` ```json\n{...}\n``` ```` despite "JSON only" instructions, and
/// without this fall-back every popular chat model would fail-closed
/// on legitimate ALLOW verdicts. The fail-closed guarantee in §12.9.3
/// ¶3 still applies — anything that doesn't parse after the strip is
/// treated as a missing decision.
fn strip_code_fence(raw: &str) -> Option<&str> {
    let trimmed = raw.trim();
    let (open, close) = if trimmed.starts_with("```") {
        ("```", "```")
    } else if trimmed.starts_with("~~~") {
        ("~~~", "~~~")
    } else {
        return None;
    };
    let body = trimmed.strip_prefix(open)?;
    // Drop the optional language tag on the first line. If the first
    // line still contains `{` the model put the JSON on the same line
    // as the fence open, which we tolerate.
    let body = match body.find('\n') {
        Some(nl) => {
            let first_line = &body[..nl];
            if first_line.trim().contains('{') || first_line.trim().contains('[') {
                body
            } else {
                &body[nl + 1..]
            }
        }
        None => body,
    };
    let body = body.trim_end();
    let body = body.strip_suffix(close).unwrap_or(body);
    Some(body.trim())
}

// ────────────────────────────────────────────────────────────────────
// Classifier verdict (§12.5.1)
// ────────────────────────────────────────────────────────────────────

/// Parse a host classifier callback's return value into
/// [`ClassifierVerdict`]. Per §12.5.1 a classifier verdict fails iff
/// `flagged: true` OR `score >= threshold`.
///
/// Accepts a JSON envelope `{"score": …, "threshold": …, "flagged":
/// …, "label": "…", "reason": "…", "spans": [...]}`. Missing fields
/// default to: `score=0.0`, `threshold=0.0`, `flagged=false`, no label
/// or reason. Note that a default verdict (`score=0.0, threshold=0.0`)
/// is NOT a failure — a host that returns `null` or `{}` is implicitly
/// passing the classifier; the per-stage `on_error:` policy is the
/// fail-closed boundary for "no response at all", not this parser.
///
/// Malformed JSON / non-object / empty input → default-Pass verdict.
/// Bindings that need a fail-closed override should detect the
/// no-response case before invoking this function.
pub fn parse_classifier_verdict_json(raw: &str) -> ClassifierVerdict {
    let trimmed = raw.trim();
    let value: Value = match serde_json::from_str(trimmed) {
        Ok(v) => v,
        Err(_) => return ClassifierVerdict::default(),
    };
    let obj = match value.as_object() {
        Some(o) => o,
        None => return ClassifierVerdict::default(),
    };
    let score = obj.get("score").and_then(|x| x.as_f64()).unwrap_or(0.0);
    let threshold = obj.get("threshold").and_then(|x| x.as_f64()).unwrap_or(0.0);
    let flagged = obj
        .get("flagged")
        .and_then(|x| x.as_bool())
        .unwrap_or(false);
    let label = obj
        .get("label")
        .and_then(|x| x.as_str())
        .map(|s| s.to_string());
    let reason = obj
        .get("reason")
        .and_then(|x| x.as_str())
        .map(|s| s.to_string());
    ClassifierVerdict {
        score,
        threshold,
        flagged,
        label,
        reason,
        spans: parse_spans_array(obj.get("spans")),
    }
}

// ────────────────────────────────────────────────────────────────────
// Resolver response (§11.3)
// ────────────────────────────────────────────────────────────────────

/// Parse a host resolver / dispatcher callback's return value into
/// [`ResolverResponse`] (§11.3).
///
/// Accepts a JSON envelope `{"decision": "allow"|"deny"|"cancelled",
/// "value": <any>, "set_variables": {…}, "reason": "…"}`. All four
/// fields are optional — missing `decision` defaults to `Deny`,
/// missing `value` to `null`, missing `set_variables` to `{}`,
/// missing `reason` to a populated parse explanation.
///
/// Per §11.3, any unrecognized shape MUST fail closed to `Deny`. This
/// parser never returns an error; on malformed input it returns a
/// `Deny` envelope whose `reason` explains what went wrong.
pub fn parse_resolver_response_json(raw: &str) -> ResolverResponse {
    let trimmed = raw.trim();
    let value: Value = match serde_json::from_str(trimmed) {
        Ok(v) => v,
        Err(e) => {
            return ResolverResponse {
                decision: ResolverDecision::Deny,
                value: None,
                set_variables: HashMap::new(),
                reason: Some(format!("invalid resolver envelope JSON: {e}")),
            }
        }
    };
    let obj = match value.as_object() {
        Some(o) => o,
        None => {
            return ResolverResponse {
                decision: ResolverDecision::Deny,
                value: None,
                set_variables: HashMap::new(),
                reason: Some("resolver envelope must be a JSON object".to_string()),
            }
        }
    };

    let raw_decision = obj.get("decision").and_then(|d| d.as_str());
    let decision = raw_decision
        .and_then(parse_resolver_decision_word)
        .unwrap_or(ResolverDecision::Deny);
    let value = obj.get("value").cloned();
    let reason = obj
        .get("reason")
        .and_then(|r| r.as_str())
        .map(|s| s.to_string())
        .or_else(|| match raw_decision {
            None => Some("missing resolver decision".to_string()),
            Some(word) if parse_resolver_decision_word(word).is_none() => {
                Some(format!("unknown resolver decision `{word}`"))
            }
            _ => None,
        });
    let mut set_variables: HashMap<String, Value> = HashMap::new();
    if let Some(sv) = obj.get("set_variables").and_then(|s| s.as_object()) {
        for (k, vv) in sv {
            set_variables.insert(k.clone(), vv.clone());
        }
    }
    ResolverResponse {
        decision,
        value,
        set_variables,
        reason,
    }
}

/// Parse a bare resolver-decision word into a [`ResolverDecision`].
/// Returns `None` for unrecognized inputs — callers fail closed.
fn parse_resolver_decision_word(s: &str) -> Option<ResolverDecision> {
    match s.trim().to_ascii_lowercase().as_str() {
        "allow" => Some(ResolverDecision::Allow),
        "deny" => Some(ResolverDecision::Deny),
        // `canceled` is the §11.3 alternate spelling we accept; the
        // canonical spec form is `cancelled`.
        "cancelled" | "canceled" => Some(ResolverDecision::Cancelled),
        _ => None,
    }
}

/// Stringify a [`ResolverDecision`] for the wire envelope. The wire
/// uses lowercase `snake_case`.
pub fn resolver_decision_str(d: &ResolverDecision) -> &'static str {
    match d {
        ResolverDecision::Allow => "allow",
        ResolverDecision::Deny => "deny",
        ResolverDecision::Cancelled => "cancelled",
    }
}

// ────────────────────────────────────────────────────────────────────
// Extractor output
// ────────────────────────────────────────────────────────────────────

/// Parse a populator extractor's return JSON. Per the populator
/// contract, returning `null` (or an empty / malformed string) signals
/// "skip this populator" — only a properly-shaped JSON value flows
/// through to the runtime.
pub fn parse_extractor_output_json(raw: &str) -> Option<Value> {
    let trimmed = raw.trim();
    if trimmed.is_empty() {
        return None;
    }
    match serde_json::from_str::<Value>(trimmed) {
        Ok(Value::Null) => None,
        Ok(v) => Some(v),
        Err(_) => None,
    }
}

// ────────────────────────────────────────────────────────────────────
// Span helpers (shared between LLM and classifier shapes per §12.9.3)
// ────────────────────────────────────────────────────────────────────

/// Parse a `[{start, end, replacement?}, …]` JSON array into the
/// runtime [`Span`] type. Half-open ranges; entries with end < start
/// are dropped silently (the callback path is recovery — a hard error
/// would short-circuit the entire stage).
fn parse_spans_array(value: Option<&Value>) -> Vec<Span> {
    let arr = match value.and_then(|v| v.as_array()) {
        Some(a) => a,
        None => return Vec::new(),
    };
    arr.iter()
        .filter_map(|entry| {
            let obj = entry.as_object()?;
            let start = obj.get("start").and_then(|x| x.as_u64())? as usize;
            let end = obj.get("end").and_then(|x| x.as_u64())? as usize;
            if end < start {
                return None;
            }
            let replacement = obj
                .get("replacement")
                .and_then(|r| r.as_str())
                .map(|s| s.to_string());
            Some(Span {
                start,
                end,
                replacement,
            })
        })
        .collect()
}

// ────────────────────────────────────────────────────────────────────
// Resolver request → JSON serialization
// ────────────────────────────────────────────────────────────────────

/// Stringify a [`ResourceKind`] for the wire (§11.10). Always
/// lowercase: `tool` / `agent` / `endpoint`.
pub fn resource_kind_str(k: ResourceKind) -> &'static str {
    match k {
        ResourceKind::Tool => "tool",
        ResourceKind::Agent => "agent",
        ResourceKind::Endpoint => "endpoint",
    }
}

/// Build the §11.10 `resource: {kind, name, params?}` envelope for the
/// wire. Returns `Value::Null` when the resolver fires outside any
/// resource invocation context.
fn resource_envelope(
    kind: Option<ResourceKind>,
    name: Option<&String>,
    params: Option<&Value>,
) -> Value {
    let (kind, name) = match (kind, name) {
        (Some(k), Some(n)) => (k, n.clone()),
        _ => return Value::Null,
    };
    let mut m = Map::new();
    m.insert(
        "kind".into(),
        Value::String(resource_kind_str(kind).to_string()),
    );
    m.insert("name".into(), Value::String(name));
    if let Some(p) = params {
        m.insert("params".into(), p.clone());
    }
    Value::Object(m)
}

/// Encode an [`AgentResolveRequest`] into the JSON shape host callbacks
/// receive (§11.5).
pub fn serialize_agent_request_json(req: &AgentResolveRequest) -> Value {
    let mut m = Map::new();
    m.insert("request_id".into(), Value::String(req.request_id.clone()));
    m.insert(
        "variable".into(),
        req.variable
            .clone()
            .map(Value::String)
            .unwrap_or(Value::Null),
    );
    m.insert(
        "resource".into(),
        resource_envelope(
            req.resource_kind,
            req.resource_name.as_ref(),
            req.resource_params.as_ref(),
        ),
    );
    m.insert("prompt".into(), Value::String(req.prompt.clone()));
    m.insert(
        "reason".into(),
        req.reason.clone().map(Value::String).unwrap_or(Value::Null),
    );
    m.insert("context".into(), Value::Object(req.context.clone()));
    Value::Object(m)
}

/// Encode a [`DelegateRequest`] into the JSON shape host dispatchers
/// receive (§11.12.1).
pub fn serialize_delegate_request_json(req: &DelegateRequest) -> Value {
    let mut m = Map::new();
    m.insert("request_id".into(), Value::String(req.request_id.clone()));
    m.insert(
        "variable".into(),
        req.variable
            .clone()
            .map(Value::String)
            .unwrap_or(Value::Null),
    );
    m.insert(
        "configuration_id".into(),
        Value::String(req.configuration.id.clone()),
    );
    m.insert(
        "configuration_type".into(),
        Value::String(req.configuration.config_type.as_str().to_string()),
    );
    m.insert(
        "configuration".into(),
        serde_json::to_value(&req.configuration).unwrap_or(Value::Null),
    );
    m.insert(
        "effective_timeout_ms".into(),
        Value::Number(serde_json::Number::from(req.effective_timeout_ms)),
    );
    m.insert(
        "resource".into(),
        resource_envelope(
            req.resource_kind,
            req.resource_name.as_ref(),
            req.invocation_params.as_ref(),
        ),
    );
    m.insert(
        "prompt".into(),
        req.prompt.clone().map(Value::String).unwrap_or(Value::Null),
    );
    m.insert(
        "reason".into(),
        req.reason.clone().map(Value::String).unwrap_or(Value::Null),
    );
    m.insert("context".into(), Value::Object(req.context.clone()));
    if let Some(lh) = &req.lifetime_hint {
        if let Ok(lifetime_json) = serde_json::to_value(lh) {
            m.insert("lifetime".into(), lifetime_json);
        }
    }
    Value::Object(m)
}

// ────────────────────────────────────────────────────────────────────
// Tests
// ────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    // ── strip_code_fence ────────────────────────────────────────────

    #[test]
    fn strip_code_fence_with_language_tag() {
        let s = "```json\n{\"decision\":\"ALLOW\"}\n```";
        let inner = strip_code_fence(s).unwrap();
        assert_eq!(inner, "{\"decision\":\"ALLOW\"}");
    }

    #[test]
    fn strip_code_fence_without_language_tag() {
        let s = "```\n{\"decision\":\"BLOCK\"}\n```";
        let inner = strip_code_fence(s).unwrap();
        assert_eq!(inner, "{\"decision\":\"BLOCK\"}");
    }

    #[test]
    fn strip_code_fence_tilde_form() {
        let s = "~~~json\n{\"decision\":\"ALLOW\"}\n~~~";
        let inner = strip_code_fence(s).unwrap();
        assert_eq!(inner, "{\"decision\":\"ALLOW\"}");
    }

    #[test]
    fn strip_code_fence_inline_open() {
        // Some models put the opening brace on the same line as the fence.
        let s = "```json {\"decision\":\"ALLOW\"} ```";
        let inner = strip_code_fence(s).unwrap();
        // The first-line tolerance keeps the body so subsequent JSON
        // parsing handles the trailing fence; we only care that the
        // closing fence is stripped.
        assert!(inner.contains("\"ALLOW\""));
        assert!(!inner.contains("```"));
    }

    #[test]
    fn strip_code_fence_no_fence_returns_none() {
        assert!(strip_code_fence("{\"decision\":\"ALLOW\"}").is_none());
        assert!(strip_code_fence("just text").is_none());
        assert!(strip_code_fence("").is_none());
    }

    #[test]
    fn parse_llm_response_strips_markdown_fence() {
        // The exact shape Azure GPT-4.1-mini returns for the bank demo.
        let raw = "```json\n{\n  \"decision\": \"ALLOW\",\n  \"confidence\": 1.0,\n  \"reason\": \"benign account lookup\"\n}\n```";
        let r = parse_llm_response_json(raw);
        assert_eq!(r.decision, Some(LlmDecision::Allow));
        assert_eq!(r.folded_decision(), LlmDecision::Allow);
        assert_eq!(r.reason.as_deref(), Some("benign account lookup"));
    }

    #[test]
    fn parse_llm_response_strips_fence_around_block_decision() {
        let raw = "```json\n{\"decision\":\"BLOCK\",\"reason\":\"jailbreak\"}\n```";
        let r = parse_llm_response_json(raw);
        assert_eq!(r.folded_decision(), LlmDecision::Block);
    }

    #[test]
    fn parse_llm_response_unfenced_garbage_still_fail_closed() {
        // §12.9.3 ¶3 — the markdown-fence tolerance does NOT relax the
        // fail-closed guarantee for genuinely unparseable input.
        let r = parse_llm_response_json("```json\nnot really json\n```");
        assert_eq!(r.folded_decision(), LlmDecision::Block);
    }

    // ── LLM response: bare-word inputs ─────────────────────────────

    #[test]
    fn llm_bare_lowercase_allow() {
        let r = parse_llm_response_json("allow");
        assert_eq!(r.decision, Some(LlmDecision::Allow));
        assert_eq!(r.folded_decision(), LlmDecision::Allow);
    }

    #[test]
    fn llm_bare_uppercase_block() {
        let r = parse_llm_response_json("BLOCK");
        assert_eq!(r.decision, Some(LlmDecision::Block));
        assert_eq!(r.folded_decision(), LlmDecision::Block);
    }

    #[test]
    fn llm_bare_mixed_case_with_whitespace() {
        let r = parse_llm_response_json("  Allow  \n");
        assert_eq!(r.decision, Some(LlmDecision::Allow));
    }

    #[test]
    fn llm_bare_pass_alias() {
        let r = parse_llm_response_json("pass");
        assert_eq!(r.decision, Some(LlmDecision::Allow));
    }

    #[test]
    fn llm_bare_fail_alias() {
        let r = parse_llm_response_json("fail");
        assert_eq!(r.decision, Some(LlmDecision::Block));
    }

    // ── LLM response: JSON envelope inputs ─────────────────────────

    #[test]
    fn llm_json_envelope_allow_uppercase_decision() {
        // The exact shape that triggered the silent fail-closed bug
        // (commit 31ae2c4) — JSON-encoded string with uppercase
        // decision. Must NOT fall through to Block.
        let r = parse_llm_response_json(r#"{"decision": "ALLOW"}"#);
        assert_eq!(r.decision, Some(LlmDecision::Allow));
        assert_eq!(r.folded_decision(), LlmDecision::Allow);
    }

    #[test]
    fn llm_json_envelope_full_shape() {
        let s = r#"{
            "decision": "block",
            "confidence": 0.92,
            "reason": "PII detected",
            "categories": ["pii", "ssn"],
            "spans": [{"start": 0, "end": 11, "replacement": "[REDACTED]"}],
            "bool_flags": {"contains_pii": true}
        }"#;
        let r = parse_llm_response_json(s);
        assert_eq!(r.decision, Some(LlmDecision::Block));
        assert_eq!(r.confidence, Some(0.92));
        assert_eq!(r.reason.as_deref(), Some("PII detected"));
        assert_eq!(r.categories, vec!["pii", "ssn"]);
        assert_eq!(r.spans.len(), 1);
        assert_eq!(r.spans[0].replacement.as_deref(), Some("[REDACTED]"));
        assert!(r.bool_flags["contains_pii"]);
    }

    #[test]
    fn llm_json_top_level_bool_overrides_allow() {
        // §12.9.3 ¶2: any truthy boolean field flips the verdict to Block.
        let s = r#"{"decision": "allow", "is_jailbreak": true}"#;
        let r = parse_llm_response_json(s);
        assert_eq!(r.decision, Some(LlmDecision::Allow));
        assert!(r.bool_flags["is_jailbreak"]);
        assert_eq!(r.folded_decision(), LlmDecision::Block);
    }

    #[test]
    fn llm_json_double_encoded_bare_word() {
        // Some hosts json.dumps("allow") which yields `"\"allow\""`.
        let r = parse_llm_response_json(r#""allow""#);
        assert_eq!(r.decision, Some(LlmDecision::Allow));
    }

    // ── LLM response: fail-closed inputs ───────────────────────────

    #[test]
    fn llm_empty_string_fails_closed() {
        let r = parse_llm_response_json("");
        assert!(r.decision.is_none());
        assert_eq!(r.folded_decision(), LlmDecision::Block);
    }

    #[test]
    fn llm_whitespace_only_fails_closed() {
        let r = parse_llm_response_json("   \n\t  ");
        assert_eq!(r.folded_decision(), LlmDecision::Block);
    }

    #[test]
    fn llm_garbage_fails_closed() {
        let r = parse_llm_response_json("definitely not JSON {{{");
        assert_eq!(r.folded_decision(), LlmDecision::Block);
    }

    #[test]
    fn llm_unknown_decision_fails_closed() {
        let r = parse_llm_response_json(r#"{"decision": "maybe"}"#);
        assert!(r.decision.is_none());
        assert_eq!(r.folded_decision(), LlmDecision::Block);
    }

    #[test]
    fn llm_missing_decision_fails_closed() {
        let r = parse_llm_response_json(r#"{"confidence": 0.5}"#);
        assert!(r.decision.is_none());
        assert_eq!(r.folded_decision(), LlmDecision::Block);
    }

    #[test]
    fn llm_array_root_fails_closed() {
        let r = parse_llm_response_json(r#"["allow"]"#);
        assert_eq!(r.folded_decision(), LlmDecision::Block);
    }

    #[test]
    fn llm_number_root_fails_closed() {
        let r = parse_llm_response_json("42");
        assert_eq!(r.folded_decision(), LlmDecision::Block);
    }

    #[test]
    fn llm_drops_malformed_spans_silently() {
        let s = r#"{
            "decision": "allow",
            "spans": [
                {"start": 0, "end": 5},
                {"start": "bad"},
                {"end": 5},
                {"start": 10, "end": 5}
            ]
        }"#;
        let r = parse_llm_response_json(s);
        assert_eq!(r.spans.len(), 1);
        assert_eq!(r.spans[0].start, 0);
        assert_eq!(r.spans[0].end, 5);
    }

    // ── Classifier verdict ─────────────────────────────────────────

    #[test]
    fn classifier_score_above_threshold_is_failure() {
        let v = parse_classifier_verdict_json(r#"{"score":0.9,"threshold":0.5}"#);
        assert!(v.is_failure());
    }

    #[test]
    fn classifier_flagged_true_is_failure() {
        let v = parse_classifier_verdict_json(r#"{"score":0.0,"threshold":1.0,"flagged":true}"#);
        assert!(v.is_failure());
    }

    #[test]
    fn classifier_picks_up_label_and_reason() {
        let v = parse_classifier_verdict_json(
            r#"{"score":0.1,"threshold":0.5,"label":"safe","reason":"ok"}"#,
        );
        assert_eq!(v.label.as_deref(), Some("safe"));
        assert_eq!(v.reason.as_deref(), Some("ok"));
        assert!(!v.is_failure());
    }

    #[test]
    fn classifier_picks_up_spans() {
        let v = parse_classifier_verdict_json(
            r#"{"score":0.9,"threshold":0.5,"flagged":true,
                 "spans":[{"start":3,"end":7,"replacement":"***"}]}"#,
        );
        assert_eq!(v.spans.len(), 1);
        assert_eq!(v.spans[0].replacement.as_deref(), Some("***"));
    }

    #[test]
    fn classifier_malformed_returns_default() {
        let v = parse_classifier_verdict_json("not JSON");
        assert_eq!(v.score, 0.0);
        assert!(!v.flagged);
    }

    // ── Resolver response ──────────────────────────────────────────

    #[test]
    fn resolver_allow_with_value() {
        let r = parse_resolver_response_json(r#"{"decision":"allow","value":42}"#);
        assert_eq!(r.decision, ResolverDecision::Allow);
        assert_eq!(r.value, Some(Value::from(42)));
    }

    #[test]
    fn resolver_canceled_alias_accepted() {
        let r = parse_resolver_response_json(r#"{"decision":"canceled"}"#);
        assert_eq!(r.decision, ResolverDecision::Cancelled);
    }

    #[test]
    fn resolver_set_variables_round_trip() {
        let r =
            parse_resolver_response_json(r#"{"decision":"allow","set_variables":{"k":"v","n":7}}"#);
        assert_eq!(r.decision, ResolverDecision::Allow);
        assert_eq!(r.set_variables.len(), 2);
        assert_eq!(r.set_variables["k"], Value::from("v"));
        assert_eq!(r.set_variables["n"], Value::from(7));
    }

    #[test]
    fn resolver_missing_decision_denies() {
        let r = parse_resolver_response_json(r#"{"value":7}"#);
        assert_eq!(r.decision, ResolverDecision::Deny);
    }

    #[test]
    fn resolver_unknown_decision_denies() {
        let r = parse_resolver_response_json(r#"{"decision":"maybe"}"#);
        assert_eq!(r.decision, ResolverDecision::Deny);
    }

    #[test]
    fn resolver_unknown_decision_denies_with_reason() {
        let r = parse_resolver_response_json(r#"{"decision":"approve-ish"}"#);
        assert_eq!(r.decision, ResolverDecision::Deny);
        assert!(r.reason.unwrap_or_default().contains("unknown"));
    }

    #[test]
    fn resolver_invalid_json_denies_with_reason() {
        let r = parse_resolver_response_json("not JSON");
        assert_eq!(r.decision, ResolverDecision::Deny);
        assert!(r.reason.unwrap().contains("invalid"));
    }

    #[test]
    fn resolver_empty_string_denies() {
        let r = parse_resolver_response_json("");
        assert_eq!(r.decision, ResolverDecision::Deny);
    }

    #[test]
    fn resolver_array_root_denies() {
        let r = parse_resolver_response_json(r#"["allow"]"#);
        assert_eq!(r.decision, ResolverDecision::Deny);
        assert!(r.reason.is_some());
    }

    #[test]
    fn resolver_decision_str_round_trip() {
        assert_eq!(resolver_decision_str(&ResolverDecision::Allow), "allow");
        assert_eq!(resolver_decision_str(&ResolverDecision::Deny), "deny");
        assert_eq!(
            resolver_decision_str(&ResolverDecision::Cancelled),
            "cancelled"
        );
    }

    // ── Extractor output ───────────────────────────────────────────

    #[test]
    fn extractor_null_skips_populator() {
        assert!(parse_extractor_output_json("null").is_none());
    }

    #[test]
    fn extractor_object_passes_through() {
        let v = parse_extractor_output_json(r#"{"k":"v"}"#);
        assert!(v.is_some());
        assert_eq!(v.unwrap()["k"], Value::from("v"));
    }

    #[test]
    fn extractor_empty_string_skips() {
        assert!(parse_extractor_output_json("").is_none());
        assert!(parse_extractor_output_json("   ").is_none());
    }

    #[test]
    fn extractor_invalid_json_skips() {
        assert!(parse_extractor_output_json("not JSON").is_none());
    }

    // ── Resource kind / wire helpers ───────────────────────────────

    #[test]
    fn resource_kind_str_round_trip() {
        assert_eq!(resource_kind_str(ResourceKind::Tool), "tool");
        assert_eq!(resource_kind_str(ResourceKind::Agent), "agent");
        assert_eq!(resource_kind_str(ResourceKind::Endpoint), "endpoint");
    }

    #[test]
    fn resource_envelope_null_when_unbound() {
        assert_eq!(resource_envelope(None, None, None), Value::Null);
        assert_eq!(
            resource_envelope(Some(ResourceKind::Tool), None, None),
            Value::Null
        );
    }

    #[test]
    fn resource_envelope_with_params() {
        let name = "search".to_string();
        let params = serde_json::json!({"q": "x"});
        let env = resource_envelope(Some(ResourceKind::Tool), Some(&name), Some(&params));
        assert_eq!(env["kind"], Value::from("tool"));
        assert_eq!(env["name"], Value::from("search"));
        assert_eq!(env["params"], params);
    }
}
