//! Resolver wire envelope (§11.3) and per-kind resolver type (§11.10).
//!
//! This module models the data shape — the runtime that actually
//! invokes resolvers lives in [`crate::resolver_runtime`].

use std::collections::HashMap;

use serde::{Deserialize, Serialize};

use super::lifetime::Lifetime;

/// Resolver decision per the wire envelope (§11.3).
///
/// The enum is strictly `{Allow, Deny, Cancelled}` — these are the
/// three canonical values defined in the spec. Per-outcome lifetime
/// (the v1 `AllowOnce`/`DenyOnce` use case) is expressed through the
/// `lifetime:` map form, e.g. `lifetime: { allow: per_call, deny:
/// per_session }` (§9.1.2). The legacy `AllowOnce`/`DenyOnce` decision
/// values are not part of the v2 envelope.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ResolverDecision {
    Allow,
    Deny,
    Cancelled,
}

/// `on_error` policy on a resolver (§11.7).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum OnError {
    Block,
    Allow,
    UseFallback,
    UseDefault,
}

/// Audit-log overrides per §11.9.
#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct AuditConfig {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub severity: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub category: Option<String>,
}

/// The wire envelope returned by every resolver invocation (§11.3).
///
/// Internal Rust callers should construct this directly. Wire-facing
/// deserialization MUST go through [`WireResolverResponse`] which requires
/// all four fields to be present.
#[derive(Debug, Clone, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ResolverResponse {
    pub decision: ResolverDecision,
    /// Always serialized — `null` when no value is set.
    #[serde(serialize_with = "serialize_value_explicit_null")]
    pub value: Option<serde_json::Value>,
    /// Always serialized — `{}` when no companion writes are set.
    #[serde(serialize_with = "serialize_set_variables_explicit")]
    pub set_variables: HashMap<String, serde_json::Value>,
    /// Always serialized — `null` when no reason is set.
    #[serde(serialize_with = "serialize_reason_explicit_null")]
    pub reason: Option<String>,
}

fn serialize_value_explicit_null<S: serde::Serializer>(
    v: &Option<serde_json::Value>,
    s: S,
) -> std::result::Result<S::Ok, S::Error> {
    match v {
        Some(val) => val.serialize(s),
        None => s.serialize_none(),
    }
}

fn serialize_set_variables_explicit<S: serde::Serializer>(
    v: &HashMap<String, serde_json::Value>,
    s: S,
) -> std::result::Result<S::Ok, S::Error> {
    use serde::ser::SerializeMap;
    let mut m = s.serialize_map(Some(v.len()))?;
    for (k, val) in v {
        m.serialize_entry(k, val)?;
    }
    m.end()
}

fn serialize_reason_explicit_null<S: serde::Serializer>(
    v: &Option<String>,
    s: S,
) -> std::result::Result<S::Ok, S::Error> {
    match v {
        Some(val) => s.serialize_str(val),
        None => s.serialize_none(),
    }
}

/// Strict wire-facing deserializer for `ResolverResponse` (§11.3).
///
/// Requires all four fields (`decision`, `value`, `set_variables`, `reason`)
/// to be present in the incoming payload. `null`/`{}` are accepted; absence
/// is rejected. Convert into [`ResolverResponse`] via `From`/`Into` for
/// internal use.
#[derive(Debug, Clone, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct WireResolverResponse {
    pub decision: ResolverDecision,
    pub value: Option<serde_json::Value>,
    pub set_variables: HashMap<String, serde_json::Value>,
    pub reason: Option<String>,
}

impl From<WireResolverResponse> for ResolverResponse {
    fn from(w: WireResolverResponse) -> Self {
        ResolverResponse {
            decision: w.decision,
            value: w.value,
            set_variables: w.set_variables,
            reason: w.reason,
        }
    }
}

impl<'de> Deserialize<'de> for ResolverResponse {
    fn deserialize<D: serde::Deserializer<'de>>(de: D) -> std::result::Result<Self, D::Error> {
        // Route every external deserialization through the strict wire shape.
        let w = WireResolverResponse::deserialize(de)?;
        Ok(w.into())
    }
}

/// Per-kind resolver shape (§11.10). Matches the JSON schema's `kind`-tagged
/// union with per-kind field-allowed/forbidden constraints.
#[derive(Debug, Clone, Serialize, PartialEq, Eq)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum Resolver {
    Expression {
        expression: String,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        lifetime: Option<Lifetime>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        fallback: Option<Box<Resolver>>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        on_allow: Option<HashMap<String, String>>,
    },
    Tool {
        name: String,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        prompt: Option<String>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        context: Option<HashMap<String, String>>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        on_allow: Option<HashMap<String, String>>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        lifetime: Option<Lifetime>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        fallback: Option<Box<Resolver>>,
    },
    Human {
        /// Free-form prompt the handler shows the human. Optional —
        /// bundled providers like `auto_reject` ignore it; `console`
        /// falls back to a variable-name + reason synthesis when
        /// omitted.
        #[serde(default, skip_serializing_if = "Option::is_none")]
        prompt: Option<String>,
        /// Bundled human-resolver provider name — when set, the
        /// runtime dispatches to a registered
        /// [`crate::resolver_runtime::HumanResolver`] instead of
        /// going through the canonical `agent_shield.ask_human` MCP
        /// signal. Examples: `auto_reject`, `console`. Hosts that
        /// register a closure-based handler via
        /// [`crate::resolver_runtime::HumanResolver`] and reference
        /// it by `name:` use the same dispatch surface.
        #[serde(default, skip_serializing_if = "Option::is_none")]
        provider: Option<String>,
        /// Optional registered handler name. Equivalent to
        /// `provider:` — `name:` is the closure-based / per-host
        /// alias; `provider:` is the bundled-implementation alias.
        /// At most one of the two may be set.
        #[serde(default, skip_serializing_if = "Option::is_none")]
        name: Option<String>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        context: Option<HashMap<String, String>>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        on_allow: Option<HashMap<String, String>>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        lifetime: Option<Lifetime>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        fallback: Option<Box<Resolver>>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        on_error: Option<OnError>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        audit: Option<AuditConfig>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        timeout_ms: Option<u32>,
    },
    Delegate {
        configuration: String,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        prompt: Option<String>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        context: Option<HashMap<String, String>>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        on_allow: Option<HashMap<String, String>>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        lifetime: Option<Lifetime>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        fallback: Option<Box<Resolver>>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        on_error: Option<OnError>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        audit: Option<AuditConfig>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        timeout_ms: Option<u32>,
    },
    Agent {
        prompt: String,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        context: Option<HashMap<String, String>>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        on_allow: Option<HashMap<String, String>>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        lifetime: Option<Lifetime>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        fallback: Option<Box<Resolver>>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        on_error: Option<OnError>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        audit: Option<AuditConfig>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        timeout_ms: Option<u32>,
    },
}

// Custom Deserialize: accept the spec's `kind`-tagged map shape and enforce
// per-kind field allow/forbid constraints (mirrors the schema's `oneOf`).
impl<'de> Deserialize<'de> for Resolver {
    fn deserialize<D: serde::Deserializer<'de>>(de: D) -> std::result::Result<Self, D::Error> {
        let mut value = serde_yaml::Value::deserialize(de)?;
        let mapping = value
            .as_mapping_mut()
            .ok_or_else(|| serde::de::Error::custom("resolver: expected a mapping"))?;

        let kind = mapping
            .get(serde_yaml::Value::String("kind".into()))
            .and_then(|v| v.as_str())
            .ok_or_else(|| serde::de::Error::custom("resolver: missing required field `kind`"))?
            .to_string();

        // Snapshot keys for forbidden-field checks.
        let keys: std::collections::BTreeSet<String> = mapping
            .iter()
            .filter_map(|(k, _)| k.as_str().map(|s| s.to_string()))
            .collect();

        // Strip `kind` from the mapping before re-deserializing into the
        // per-kind Wire helper. The Wire helpers carry
        // `#[serde(deny_unknown_fields)]` so leaving `kind` in would fail.
        mapping.remove(serde_yaml::Value::String("kind".into()));

        // Allow-set per kind, taken from §11.10 / schema.
        let (required, allowed_extra): (&[&str], &[&str]) = match kind.as_str() {
            "expression" => (&["expression"], &["lifetime", "fallback", "on_allow"]),
            "tool" => (
                &["name"],
                &["prompt", "context", "on_allow", "lifetime", "fallback"],
            ),
            "human" => (
                // `prompt` becomes optional when a bundled provider /
                // closure handler is used. We keep it permitted in the
                // allowed_extra list and drop it from required.
                &[],
                &[
                    "prompt",
                    "provider",
                    "name",
                    "context",
                    "on_allow",
                    "lifetime",
                    "fallback",
                    "on_error",
                    "audit",
                    "timeout_ms",
                ],
            ),
            "delegate" => (
                &["configuration"],
                &[
                    "prompt",
                    "context",
                    "on_allow",
                    "lifetime",
                    "fallback",
                    "on_error",
                    "audit",
                    "timeout_ms",
                ],
            ),
            "agent" => (
                &["prompt"],
                &[
                    "context",
                    "on_allow",
                    "lifetime",
                    "fallback",
                    "on_error",
                    "audit",
                    "timeout_ms",
                ],
            ),
            other => {
                return Err(serde::de::Error::custom(format!(
                    "resolver: unknown kind `{}` (expected expression|tool|human|delegate|agent)",
                    other
                )))
            }
        };

        for r in required {
            if !keys.contains(*r) {
                return Err(serde::de::Error::custom(format!(
                    "resolver kind `{}`: missing required field `{}`",
                    kind, r
                )));
            }
        }
        let allowed: std::collections::BTreeSet<&str> = std::iter::once("kind")
            .chain(required.iter().copied())
            .chain(allowed_extra.iter().copied())
            .collect();
        for k in &keys {
            if !allowed.contains(k.as_str()) {
                return Err(serde::de::Error::custom(format!(
                    "resolver kind `{}`: field `{}` is not allowed (allowed: {:?})",
                    kind,
                    k,
                    allowed.iter().copied().collect::<Vec<_>>()
                )));
            }
        }

        // Now re-deserialize against a per-kind helper struct.
        match kind.as_str() {
            "expression" => {
                #[derive(Deserialize)]
                #[serde(deny_unknown_fields)]
                struct H {
                    expression: String,
                    #[serde(default)]
                    lifetime: Option<Lifetime>,
                    #[serde(default)]
                    fallback: Option<Box<Resolver>>,
                    #[serde(default)]
                    on_allow: Option<HashMap<String, String>>,
                }
                let h: H = serde_yaml::from_value(value).map_err(serde::de::Error::custom)?;
                Ok(Resolver::Expression {
                    expression: h.expression,
                    lifetime: h.lifetime,
                    fallback: h.fallback,
                    on_allow: h.on_allow,
                })
            }
            "tool" => {
                #[derive(Deserialize)]
                #[serde(deny_unknown_fields)]
                struct H {
                    name: String,
                    #[serde(default)]
                    prompt: Option<String>,
                    #[serde(default)]
                    context: Option<HashMap<String, String>>,
                    #[serde(default)]
                    on_allow: Option<HashMap<String, String>>,
                    #[serde(default)]
                    lifetime: Option<Lifetime>,
                    #[serde(default)]
                    fallback: Option<Box<Resolver>>,
                }
                let h: H = serde_yaml::from_value(value).map_err(serde::de::Error::custom)?;
                Ok(Resolver::Tool {
                    name: h.name,
                    prompt: h.prompt,
                    context: h.context,
                    on_allow: h.on_allow,
                    lifetime: h.lifetime,
                    fallback: h.fallback,
                })
            }
            "human" => {
                let h: HumanWire =
                    serde_yaml::from_value(value).map_err(serde::de::Error::custom)?;
                if h.provider.is_some() && h.name.is_some() {
                    return Err(serde::de::Error::custom(
                        "kind: human — `provider:` and `name:` are mutually exclusive",
                    ));
                }
                Ok(Resolver::Human {
                    prompt: h.prompt,
                    provider: h.provider,
                    name: h.name,
                    context: h.context,
                    on_allow: h.on_allow,
                    lifetime: h.lifetime,
                    fallback: h.fallback,
                    on_error: h.on_error,
                    audit: h.audit,
                    timeout_ms: h.timeout_ms,
                })
            }
            "delegate" => {
                let h: DelegateWire =
                    serde_yaml::from_value(value).map_err(serde::de::Error::custom)?;
                Ok(Resolver::Delegate {
                    configuration: h.configuration,
                    prompt: h.prompt,
                    context: h.context,
                    on_allow: h.on_allow,
                    lifetime: h.lifetime,
                    fallback: h.fallback,
                    on_error: h.on_error,
                    audit: h.audit,
                    timeout_ms: h.timeout_ms,
                })
            }
            "agent" => {
                let h: AgentWire =
                    serde_yaml::from_value(value).map_err(serde::de::Error::custom)?;
                Ok(Resolver::Agent {
                    prompt: h.prompt,
                    context: h.context,
                    on_allow: h.on_allow,
                    lifetime: h.lifetime,
                    fallback: h.fallback,
                    on_error: h.on_error,
                    audit: h.audit,
                    timeout_ms: h.timeout_ms,
                })
            }
            _ => unreachable!(),
        }
    }
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct HumanWire {
    #[serde(default)]
    prompt: Option<String>,
    #[serde(default)]
    provider: Option<String>,
    #[serde(default)]
    name: Option<String>,
    #[serde(default)]
    context: Option<HashMap<String, String>>,
    #[serde(default)]
    on_allow: Option<HashMap<String, String>>,
    #[serde(default)]
    lifetime: Option<Lifetime>,
    #[serde(default)]
    fallback: Option<Box<Resolver>>,
    #[serde(default)]
    on_error: Option<OnError>,
    #[serde(default)]
    audit: Option<AuditConfig>,
    #[serde(default)]
    timeout_ms: Option<u32>,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct DelegateWire {
    configuration: String,
    #[serde(default)]
    prompt: Option<String>,
    #[serde(default)]
    context: Option<HashMap<String, String>>,
    #[serde(default)]
    on_allow: Option<HashMap<String, String>>,
    #[serde(default)]
    lifetime: Option<Lifetime>,
    #[serde(default)]
    fallback: Option<Box<Resolver>>,
    #[serde(default)]
    on_error: Option<OnError>,
    #[serde(default)]
    audit: Option<AuditConfig>,
    #[serde(default)]
    timeout_ms: Option<u32>,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct AgentWire {
    prompt: String,
    #[serde(default)]
    context: Option<HashMap<String, String>>,
    #[serde(default)]
    on_allow: Option<HashMap<String, String>>,
    #[serde(default)]
    lifetime: Option<Lifetime>,
    #[serde(default)]
    fallback: Option<Box<Resolver>>,
    #[serde(default)]
    on_error: Option<OnError>,
    #[serde(default)]
    audit: Option<AuditConfig>,
    #[serde(default)]
    timeout_ms: Option<u32>,
}

impl Resolver {
    /// Returns the kind tag for diagnostics.
    pub fn kind_str(&self) -> &'static str {
        match self {
            Resolver::Expression { .. } => "expression",
            Resolver::Tool { .. } => "tool",
            Resolver::Human { .. } => "human",
            Resolver::Delegate { .. } => "delegate",
            Resolver::Agent { .. } => "agent",
        }
    }

    /// Walk the chain head + every fallback link, in order.
    pub fn iter_chain(&self) -> ResolverChainIter<'_> {
        ResolverChainIter { next: Some(self) }
    }
}

pub struct ResolverChainIter<'a> {
    next: Option<&'a Resolver>,
}

impl<'a> Iterator for ResolverChainIter<'a> {
    type Item = &'a Resolver;
    fn next(&mut self) -> Option<Self::Item> {
        let cur = self.next.take()?;
        let next = match cur {
            Resolver::Expression { fallback, .. }
            | Resolver::Tool { fallback, .. }
            | Resolver::Human { fallback, .. }
            | Resolver::Delegate { fallback, .. }
            | Resolver::Agent { fallback, .. } => fallback.as_deref(),
        };
        self.next = next;
        Some(cur)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_human_resolver() {
        let yaml = "
kind: human
prompt: \"Authorize?\"
context:
  who: \"current_user\"
lifetime: per_call
";
        let r: Resolver = serde_yaml::from_str(yaml).unwrap();
        assert_eq!(r.kind_str(), "human");
    }

    #[test]
    fn parses_expression_resolver_chain() {
        let yaml = "
kind: expression
expression: \"data_sensitivity == 'public'\"
fallback:
  kind: human
  prompt: \"approve?\"
";
        let r: Resolver = serde_yaml::from_str(yaml).unwrap();
        let kinds: Vec<_> = r.iter_chain().map(Resolver::kind_str).collect();
        assert_eq!(kinds, vec!["expression", "human"]);
    }

    #[test]
    fn rejects_disallowed_field_per_kind() {
        let yaml = "
kind: expression
expression: \"x\"
prompt: \"nope\"
";
        let err = serde_yaml::from_str::<Resolver>(yaml)
            .unwrap_err()
            .to_string();
        assert!(err.contains("not allowed"));
    }

    #[test]
    fn rejects_unknown_kind() {
        let err = serde_yaml::from_str::<Resolver>("kind: bogus\n")
            .unwrap_err()
            .to_string();
        assert!(err.contains("unknown kind"));
    }

    #[test]
    fn rejects_missing_required_field() {
        let err = serde_yaml::from_str::<Resolver>("kind: tool\n")
            .unwrap_err()
            .to_string();
        assert!(err.contains("missing required field"));
    }

    // ── Review-amendment tests (P1.7, P1.9) ────────────────────────────

    /// P1.7: a human resolver with an unknown field is rejected.
    #[test]
    fn p1_7_human_resolver_unknown_field_rejected() {
        // `timeout_seconds` is not in the schema; `timeout_ms` is.
        let yaml = r#"
kind: human
prompt: "approve?"
timeout_seconds: 10
"#;
        let err = serde_yaml::from_str::<Resolver>(yaml)
            .unwrap_err()
            .to_string();
        assert!(
            err.contains("not allowed") || err.contains("timeout_seconds"),
            "got: {err}"
        );
    }

    /// P1.9: deserializing a wire response missing required fields fails.
    #[test]
    fn p1_9_wire_resolver_response_requires_all_fields() {
        let json = r#"{"decision":"allow"}"#;
        let res: std::result::Result<WireResolverResponse, _> = serde_json::from_str(json);
        assert!(res.is_err(), "expected missing-field error, got: {res:?}");
    }

    /// P1.9: a complete wire response deserializes into ResolverResponse.
    #[test]
    fn p1_9_wire_resolver_response_complete_deserialize() {
        let json = r#"{"decision":"allow","value":null,"set_variables":{},"reason":null}"#;
        let w: WireResolverResponse = serde_json::from_str(json).unwrap();
        let r: ResolverResponse = w.into();
        assert_eq!(r.decision, ResolverDecision::Allow);
        assert!(r.value.is_none());
        assert!(r.set_variables.is_empty());
        assert!(r.reason.is_none());
    }

    /// P1.9: ResolverResponse always emits all four fields with explicit
    /// nulls/empty for missing values.
    #[test]
    fn p1_9_resolver_response_serialize_explicit_nulls() {
        let r = ResolverResponse {
            decision: ResolverDecision::Allow,
            value: None,
            set_variables: HashMap::new(),
            reason: None,
        };
        let s = serde_json::to_string(&r).unwrap();
        // Must contain explicit `value: null`, `set_variables: {}`, `reason: null`.
        assert!(s.contains("\"value\":null"), "got: {s}");
        assert!(s.contains("\"set_variables\":{}"), "got: {s}");
        assert!(s.contains("\"reason\":null"), "got: {s}");
    }
}
