//! Session identifier newtype.
//!
//! [`SessionId`] is a cheap-clone (`Arc<str>`) handle used to scope
//! per-session state in [`crate::lifetime_tracker::LifetimeTracker`],
//! [`crate::event_bus::EventBus`], and
//! [`crate::guard_policy_runtime::ActivationCache`]. Each
//! [`crate::runtime::GuardrailsSession`] holds its own [`SessionId`] and
//! threads it through every interaction with the shared, immutable
//! runtime so concurrent sessions on the same
//! [`crate::runtime::GuardrailsRuntime`] do not see each other's
//! variables, event latches, or `active_if:` activation snapshots
//! (per spec §9 / §10 / §12.4).
//!
//! A small set of legacy code paths construct trackers / buses / caches
//! directly without a session — those are bound to
//! [`SessionId::default`] (the empty-string anonymous session) so
//! pre-existing tests and the C ABI test surface keep working.

use std::sync::Arc;

/// Cheap-clone session identifier. Wraps an `Arc<str>` so cloning is a
/// pointer bump.
#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub struct SessionId(Arc<str>);

impl SessionId {
    /// Build a [`SessionId`] from any string-like value.
    pub fn new(s: impl Into<String>) -> Self {
        Self(Arc::from(s.into()))
    }

    /// Borrow the underlying string.
    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl Default for SessionId {
    /// The anonymous "global" session. Used by legacy methods that
    /// don't yet thread a session id (existing internal tests and the
    /// C-ABI test surface).
    fn default() -> Self {
        Self(Arc::from(""))
    }
}

impl From<&str> for SessionId {
    fn from(s: &str) -> Self {
        Self::new(s)
    }
}

impl From<String> for SessionId {
    fn from(s: String) -> Self {
        Self::new(s)
    }
}

impl From<&String> for SessionId {
    fn from(s: &String) -> Self {
        Self::new(s.clone())
    }
}

impl std::fmt::Display for SessionId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(&self.0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn cheap_clone_via_arc() {
        let a = SessionId::new("abc");
        let b = a.clone();
        assert_eq!(a, b);
        assert_eq!(a.as_str(), "abc");
    }

    #[test]
    fn default_is_empty() {
        assert_eq!(SessionId::default().as_str(), "");
    }

    #[test]
    fn from_string_variants() {
        let a: SessionId = "abc".into();
        let b: SessionId = "abc".to_string().into();
        assert_eq!(a, b);
    }
}
