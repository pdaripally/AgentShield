//! Update engine (§10.2): evaluates a variable's `update:` expression
//! against the runtime locals `@current` and `@incoming` to produce the
//! merged value that gets stored.
//!
//! ## Spec mapping
//!
//! - §10.2 — `update:` expression semantics (default replace; runs only
//!   when `@status == 'resolved'`; type-incompatible results dropped
//!   with a structured warning).
//! - §10.1 — `type: enum` write-time validation against `members:`.
//! - §7.4 — `max() / min() / union() / object.merge_patch()` — the
//!   stdlib functions that v2 uses in place of the v1 update_policy
//!   enum. They live in `expressions::eval`.
//!
//! The single public entry point is [`apply_update`], invoked by
//! [`crate::lifetime_tracker::LifetimeTracker::set_variable`]. The
//! tracker handles the `@status == 'unset'` short-circuit before
//! calling here, so this engine sees only "transition while resolved"
//! writes.

use std::collections::HashMap;

use serde_json::Value;

use super::expressions::eval::{evaluate_to_value, EvalContext};
use super::variables::{Variable, VariableType};
pub use crate::constants::merge::MAX_OBJECT_DEPTH;

// ── Errors ──────────────────────────────────────────────────────────

#[derive(Debug, thiserror::Error, PartialEq)]
pub enum UpdateError {
    /// The `update:` expression returned a value whose JSON shape is
    /// incompatible with the variable's declared `type:` (§10.2). The
    /// caller is responsible for surfacing the structured warning;
    /// this engine does not log directly.
    #[error("type mismatch on update of `{var}`: expected {expected}, got {got}")]
    TypeMismatch {
        var: String,
        expected: String,
        got: String,
    },

    /// The `update:` expression returned a string that is not in
    /// `members:` for a `type: enum` variable (§10.2 / §10.1).
    #[error("enum-domain violation on update of `{var}`: value `{value}` not in members")]
    EnumNotInMembers { var: String, value: String },

    /// The `update:` expression evaluated to `null`, which is not a
    /// type-compatible write for the variable's declared type. Dropped
    /// per §10.2.
    #[error("update expression on `{var}` evaluated to null; dropped")]
    UpdateProducedNull { var: String },

    /// The `update:` expression failed to parse or to evaluate within
    /// the limits (LANGUAGE.md §6). Dropped per §10.2.
    #[error("update expression on `{var}` could not be evaluated: {detail}")]
    UpdateExpressionFailed { var: String, detail: String },

    /// Resulting object exceeds the §10.2 nesting limit (10 levels).
    #[error(
        "update on `{var}` produced an object exceeding the {MAX_OBJECT_DEPTH}-level nesting limit"
    )]
    NestingExceeded { var: String },
}

// ── Public entry point ──────────────────────────────────────────────

/// Apply a write to a variable that is currently `@status == 'resolved'`.
///
/// Per §10.2:
/// - When the variable declares an `update:` expression, evaluate it
///   with `@current` bound to the prior value and `@incoming` bound to
///   the candidate write. The expression's result is what gets stored.
/// - When `update:` is omitted, the default behavior is replace —
///   equivalent to `update: "@incoming"`.
/// - The result MUST be type-compatible with the variable's declared
///   `type:` (and, for `type: enum`, MUST be a member of `members:`).
///   Incompatible results return an error; callers (typically
///   [`crate::lifetime_tracker`]) MUST surface the §10.2 structured
///   warning and leave the existing value unchanged.
pub fn apply_update(
    variable: &Variable,
    current: Option<&Value>,
    incoming: Value,
) -> Result<Value, UpdateError> {
    // §10.2 short-circuit: `update:` runs only when the variable is
    // already `@status == 'resolved'` (current is Some). On `unset` and
    // `denied`, the incoming value is accepted unconditionally — the
    // caller (lifetime_tracker) signals this by passing `current = None`.
    let result = match (current, variable.update.as_deref()) {
        (None, _) => incoming,
        (Some(_), None) => incoming,
        (Some(cur), Some(expr)) => {
            let mut attrs: HashMap<String, Value> = HashMap::with_capacity(3);
            attrs.insert("@current".into(), cur.clone());
            attrs.insert("@incoming".into(), incoming);
            // §7.3 / §10.1: when the variable is `type: enum`, the
            // standard-library reducers `max()` / `min()` MUST compare
            // string values by member-index order (not lexicographic).
            // We surface the active enum domain through a sentinel attrs
            // entry; the evaluator's two-scalar max/min checks for it
            // and falls through to the normal scalar comparison
            // otherwise. The sentinel name carries an `@` prefix so it
            // cannot collide with author identifiers.
            if matches!(variable.var_type, VariableType::Enum) {
                if let Some(members) = &variable.members {
                    let arr = members
                        .iter()
                        .map(|m| Value::String(m.clone()))
                        .collect::<Vec<_>>();
                    attrs.insert("@__enum_domain__".into(), Value::Array(arr));
                }
            }
            let mut ctx = EvalContext::from_attrs(&attrs);
            // §10.2: update: is NOT a gating site — auto-resolution
            // MUST NOT fire on reads of `unset` session variables.
            ctx.is_gating_site = false;
            match evaluate_to_value(expr, &ctx) {
                Some(Value::Null) => {
                    return Err(UpdateError::UpdateProducedNull {
                        var: variable.name.clone(),
                    });
                }
                Some(v) => v,
                None => {
                    return Err(UpdateError::UpdateExpressionFailed {
                        var: variable.name.clone(),
                        detail: "expression returned no value (parse or evaluation error)".into(),
                    });
                }
            }
        }
    };

    // §10.2 type compatibility (and §10.1 enum membership).
    type_check_value(variable, &result)?;
    enforce_nesting_limit(variable, &result, 0)?;

    Ok(result)
}

// ── Type compatibility ──────────────────────────────────────────────

fn type_check_value(var: &Variable, val: &Value) -> Result<(), UpdateError> {
    let ty_label = type_label(&var.var_type);
    let got_label = json_type_label(val);
    let ok = match (&var.var_type, val) {
        // `null` is never type-compatible — apply_update routes it
        // through UpdateProducedNull above. This branch handles values
        // that other paths might inject.
        (_, Value::Null) => false,
        (VariableType::String, Value::String(_)) => true,
        (VariableType::Number, Value::Number(_)) => true,
        (VariableType::Boolean, Value::Bool(_)) => true,
        (VariableType::Array, Value::Array(_)) => true,
        (VariableType::Object, Value::Object(_)) => true,
        (VariableType::Datetime, Value::String(s)) => {
            chrono::DateTime::parse_from_rfc3339(s).is_ok()
        }
        (VariableType::Enum, Value::String(s)) => {
            // Membership is enforced separately so we can return the
            // EnumNotInMembers variant with the offending value.
            if let Some(members) = &var.members {
                if members.iter().any(|m| m == s) {
                    return Ok(());
                }
                return Err(UpdateError::EnumNotInMembers {
                    var: var.name.clone(),
                    value: s.clone(),
                });
            }
            false
        }
        _ => false,
    };
    if ok {
        Ok(())
    } else {
        Err(UpdateError::TypeMismatch {
            var: var.name.clone(),
            expected: ty_label.into(),
            got: got_label.into(),
        })
    }
}

fn type_label(t: &VariableType) -> &'static str {
    match t {
        VariableType::String => "string",
        VariableType::Number => "number",
        VariableType::Boolean => "boolean",
        VariableType::Array => "array",
        VariableType::Object => "object",
        VariableType::Datetime => "datetime",
        VariableType::Enum => "enum",
    }
}

fn json_type_label(v: &Value) -> &'static str {
    match v {
        Value::Null => "null",
        Value::Bool(_) => "boolean",
        Value::Number(_) => "number",
        Value::String(_) => "string",
        Value::Array(_) => "array",
        Value::Object(_) => "object",
    }
}

// ── Nesting limit ───────────────────────────────────────────────────

/// §10.2: implementations MUST support at least 10 levels of object
/// nesting. We enforce ≤ 10 levels and reject deeper trees. Arrays are
/// not counted; only Value::Object levels accumulate.
fn enforce_nesting_limit(var: &Variable, val: &Value, depth: usize) -> Result<(), UpdateError> {
    if depth > MAX_OBJECT_DEPTH {
        return Err(UpdateError::NestingExceeded {
            var: var.name.clone(),
        });
    }
    match val {
        Value::Object(map) => {
            for v in map.values() {
                enforce_nesting_limit(var, v, depth + 1)?;
            }
        }
        Value::Array(items) => {
            for v in items {
                enforce_nesting_limit(var, v, depth)?;
            }
        }
        _ => {}
    }
    Ok(())
}

// ── Tests ───────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use crate::variables::{Variable, VariableType};
    use serde_json::json;

    fn var(name: &str, ty: VariableType, update: Option<&str>) -> Variable {
        Variable {
            name: name.into(),
            var_type: ty,
            description: None,
            default: None,
            members: None,
            update: update.map(String::from),
            key: None,
            lifetime: None,
            on_demand_by: None,
            populated_by: vec![],
            reset_by: vec![],
        }
    }

    fn var_enum(name: &str, members: &[&str], update: Option<&str>) -> Variable {
        Variable {
            name: name.into(),
            var_type: VariableType::Enum,
            description: None,
            default: None,
            members: Some(members.iter().map(|s| s.to_string()).collect()),
            update: update.map(String::from),
            key: None,
            lifetime: None,
            on_demand_by: None,
            populated_by: vec![],
            reset_by: vec![],
        }
    }

    // §10.2 default: omitted update: ⇒ replace.
    #[test]
    fn default_update_replaces() {
        let v = var("x", VariableType::Number, None);
        let merged = apply_update(&v, Some(&json!(1)), json!(2)).unwrap();
        assert_eq!(merged, json!(2));
    }

    // §10.2 explicit "@incoming" is the same as omitting.
    #[test]
    fn explicit_at_incoming_is_replace() {
        let v = var("x", VariableType::Number, Some("@incoming"));
        let merged = apply_update(&v, Some(&json!(1)), json!(2)).unwrap();
        assert_eq!(merged, json!(2));
    }

    // §10.2 first-write-wins via "@current".
    #[test]
    fn at_current_is_first_write_wins() {
        let v = var("x", VariableType::String, Some("@current"));
        let merged = apply_update(&v, Some(&json!("first")), json!("second")).unwrap();
        assert_eq!(merged, json!("first"));
    }

    // §10.2 ratchet over numbers: max(@current, @incoming).
    #[test]
    fn max_over_numbers() {
        let v = var(
            "score",
            VariableType::Number,
            Some("max(@current, @incoming)"),
        );
        assert_eq!(
            apply_update(&v, Some(&json!(50)), json!(80)).unwrap(),
            json!(80)
        );
        // Ratchet does not lower.
        assert_eq!(
            apply_update(&v, Some(&json!(80)), json!(50)).unwrap(),
            json!(80)
        );
    }

    // §10.2 set-union over arrays.
    #[test]
    fn union_over_arrays() {
        let v = var(
            "tags",
            VariableType::Array,
            Some("union(@current, @incoming)"),
        );
        let merged = apply_update(&v, Some(&json!(["a", "b"])), json!(["b", "c"])).unwrap();
        assert_eq!(merged, json!(["a", "b", "c"]));
    }

    // §10.2 deep object merge.
    #[test]
    fn merge_patch_over_objects() {
        let v = var(
            "doc",
            VariableType::Object,
            Some("object.merge_patch(@current, @incoming)"),
        );
        let current = json!({"a": 1, "b": {"c": 2}});
        let incoming = json!({"b": {"c": 99, "d": 3}});
        let merged = apply_update(&v, Some(&current), incoming).unwrap();
        assert_eq!(merged, json!({"a": 1, "b": {"c": 99, "d": 3}}));
    }

    // §10.2 counter / accumulator.
    #[test]
    fn counter_accumulates() {
        let v = var("hits", VariableType::Number, Some("@current + @incoming"));
        let merged = apply_update(&v, Some(&json!(5)), json!(1)).unwrap();
        assert_eq!(merged, json!(6));
    }

    // §10.2 type compatibility: incompatible result returns TypeMismatch.
    #[test]
    fn type_mismatch_returns_error() {
        // update: returns a number, but variable is declared as string.
        let v = var("name", VariableType::String, Some("@current + @incoming"));
        let err = apply_update(&v, Some(&json!(1)), json!(2)).unwrap_err();
        assert!(matches!(err, UpdateError::TypeMismatch { .. }));
    }

    // §10.2: null result is dropped (UpdateProducedNull).
    #[test]
    fn null_result_dropped() {
        // update: returns @current which is null when previously unset
        // — but apply_update is only called when @status == 'resolved',
        // so @current is whatever the prior value was. Force null via
        // a missing reference.
        let v = var("x", VariableType::Number, Some("nonexistent_session_var"));
        let err = apply_update(&v, Some(&json!(5)), json!(7)).unwrap_err();
        assert!(matches!(err, UpdateError::UpdateProducedNull { .. }));
    }

    // §10.1 / §10.2 enum membership enforced on write.
    #[test]
    fn enum_member_accepted() {
        let v = var_enum(
            "sensitivity",
            &["public", "internal", "confidential", "restricted"],
            Some("@incoming"),
        );
        let merged = apply_update(&v, Some(&json!("public")), json!("confidential")).unwrap();
        assert_eq!(merged, json!("confidential"));
    }

    #[test]
    fn enum_non_member_rejected() {
        let v = var_enum("sensitivity", &["public", "internal"], Some("@incoming"));
        let err = apply_update(&v, Some(&json!("public")), json!("top_secret")).unwrap_err();
        assert!(
            matches!(err, UpdateError::EnumNotInMembers { ref value, .. } if value == "top_secret")
        );
    }

    // §10.2 nesting limit.
    #[test]
    fn nesting_at_limit_passes() {
        // Build an object 10 levels deep.
        let mut v = json!("leaf");
        for _ in 0..MAX_OBJECT_DEPTH {
            v = json!({ "nested": v });
        }
        let var = var("doc", VariableType::Object, Some("@incoming"));
        // Depth at 10 levels passes (MAX_OBJECT_DEPTH = 10).
        let _ = apply_update(&var, Some(&json!({})), v).unwrap();
    }

    #[test]
    fn nesting_exceeds_limit_rejected() {
        let mut v = json!("leaf");
        for _ in 0..(MAX_OBJECT_DEPTH + 2) {
            v = json!({ "nested": v });
        }
        let var = var("doc", VariableType::Object, Some("@incoming"));
        let err = apply_update(&var, Some(&json!({})), v).unwrap_err();
        assert!(matches!(err, UpdateError::NestingExceeded { .. }));
    }

    // §10.2 expression body that fails to parse.
    #[test]
    fn malformed_update_expression_returns_error() {
        let v = var("x", VariableType::Number, Some("@incoming + + +"));
        let err = apply_update(&v, Some(&json!(1)), json!(2)).unwrap_err();
        assert!(matches!(
            err,
            UpdateError::UpdateExpressionFailed { .. } | UpdateError::UpdateProducedNull { .. }
        ));
    }
}
