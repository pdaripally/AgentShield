//! Canonical block-message formatting and on-block policy types.
//!
//! These are the small deterministic invariants every SDK Shield
//! orchestrator shares. Keeping them in core means the customer-visible
//! block string format is byte-equivalent across Python / Node / .NET /
//! Rust SDKs, and the on-block policy enum has one canonical
//! serialisation.
//!
//! What this module does NOT own: the actual dispatch of a "Custom"
//! callback (executes user code in the host language) or the async
//! state machine that calls Stage 1 → execute → Stage 5. Those stay
//! per-SDK because they re-enter host runtimes in language-specific
//! ways.

use serde::{Deserialize, Serialize};

use crate::guard_policy::Action;
use crate::guard_policy_runtime::StageVerdict;

// ───────────────────────────────────────────────────────────────────────
// Block-message canonical format
// ───────────────────────────────────────────────────────────────────────

fn action_label(action: Option<Action>) -> &'static str {
    match action {
        Some(Action::Block) => "BLOCK",
        Some(Action::Redact) => "REDACT",
        Some(Action::Warn) => "WARN",
        Some(Action::Append) => "APPEND",
        Some(Action::Prepend) => "PREPEND",
        Some(Action::DeclassifyTo) => "DECLASSIFY_TO",
        None => "BLOCK",
    }
}

/// Build the canonical `[GUARDRAIL <ACTION>] <reason>` string from a
/// stage verdict. Used by every SDK's Shield orchestrator so the
/// customer-visible block message is byte-equivalent across languages.
pub fn format_block_message(verdict: &StageVerdict) -> String {
    let action = action_label(verdict.action);
    let reason = verdict
        .reason
        .as_deref()
        .map(str::trim)
        .filter(|s| !s.is_empty())
        .unwrap_or("blocked by policy");
    format!("[GUARDRAIL {action}] {reason}")
}

/// Build the canonical block message for a tool call:
/// `[GUARDRAIL <ACTION>] <reason> (tool: <name>)`.
pub fn format_tool_block_message(verdict: &StageVerdict, tool_name: &str) -> String {
    let base = format_block_message(verdict);
    format!("{base} (tool: {tool_name})")
}

// ───────────────────────────────────────────────────────────────────────
// On-block policy
// ───────────────────────────────────────────────────────────────────────

/// What an SDK Shield should do when a stage verdict denies an action.
///
/// `Custom` indicates the host has registered a callable that owns the
/// dispatch decision; core never invokes it. The variant is preserved
/// here so the wire shape and FFI surface have a single source of
/// truth.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
#[derive(Default)]
pub enum OnBlockPolicy {
    /// Default — return the framework's blocked result (e.g. an
    /// `AIMessage` carrying the block string).
    #[default]
    ReturnBlocked,
    /// Return the raw [`StageVerdict`] so the caller can inspect it.
    ReturnVerdict,
    /// Throw / raise an exception in the host language.
    Raise,
    /// Host has provided a custom callback; SDK dispatches it.
    Custom,
}

impl OnBlockPolicy {
    /// Canonical wire-shape string for this policy.
    pub fn as_wire_str(&self) -> &'static str {
        match self {
            Self::ReturnBlocked => "return_blocked",
            Self::ReturnVerdict => "return_verdict",
            Self::Raise => "raise",
            Self::Custom => "custom",
        }
    }

    /// Parse a wire-shape string. Accepts both snake_case (canonical)
    /// and camelCase (legacy Node) forms. Returns `None` for unknown
    /// values so callers can choose their own error semantics.
    pub fn from_wire_str(s: &str) -> Option<Self> {
        match s {
            "return_blocked" | "returnBlocked" => Some(Self::ReturnBlocked),
            "return_verdict" | "returnVerdict" => Some(Self::ReturnVerdict),
            "raise" => Some(Self::Raise),
            "custom" => Some(Self::Custom),
            _ => None,
        }
    }
}

/// Outcome of resolving an on-block policy. Each SDK is responsible
/// for the language-specific dispatch (raising an exception, calling
/// a host callback, etc.); core just reduces the policy + verdict to
/// one of these tags.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum OnBlockOutcome {
    /// SDK should call its `make_blocked(message)` (framework
    /// boundary).
    ReturnBlocked { message: String },
    /// SDK should return the raw verdict to the caller.
    ReturnVerdict,
    /// SDK should throw / raise with the canonical block message.
    Raise { message: String },
    /// SDK should invoke its registered host callback. Core does not
    /// own that callable.
    Custom { message: String },
}

/// Resolve an [`OnBlockPolicy`] into an [`OnBlockOutcome`] given the
/// triggering verdict. The block message is constructed via
/// [`format_block_message`].
pub fn resolve_on_block(policy: OnBlockPolicy, verdict: &StageVerdict) -> OnBlockOutcome {
    let message = format_block_message(verdict);
    match policy {
        OnBlockPolicy::ReturnBlocked => OnBlockOutcome::ReturnBlocked { message },
        OnBlockPolicy::ReturnVerdict => OnBlockOutcome::ReturnVerdict,
        OnBlockPolicy::Raise => OnBlockOutcome::Raise { message },
        OnBlockPolicy::Custom => OnBlockOutcome::Custom { message },
    }
}

// ───────────────────────────────────────────────────────────────────────
// Shield enforcement mode
// ───────────────────────────────────────────────────────────────────────

/// Enforcement mode for an SDK Shield orchestrator.
///
/// In `Enforce` mode, a deny verdict short-circuits the host flow per
/// the on-block policy. In `Monitor` mode, the verdict still drives
/// observability (and the SDK should log the block) but the
/// orchestrator proceeds as if the call had been allowed. This is the
/// canonical place every SDK reads the mode from.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "snake_case")]
pub enum ShieldMode {
    /// Block at any stage that denies (spec default).
    #[default]
    Enforce,
    /// Shadow mode: every stage still runs, blocks are logged but the
    /// host flow proceeds.
    Monitor,
}

impl ShieldMode {
    /// Canonical wire-shape string.
    pub fn as_wire_str(&self) -> &'static str {
        match self {
            Self::Enforce => "enforce",
            Self::Monitor => "monitor",
        }
    }

    /// Parse a wire-shape string. Accepts the canonical snake_case
    /// form. Returns `None` for unknown values so callers can choose
    /// their own error semantics.
    pub fn from_wire_str(s: &str) -> Option<Self> {
        match s {
            "enforce" | "Enforce" | "ENFORCE" => Some(Self::Enforce),
            "monitor" | "Monitor" | "MONITOR" => Some(Self::Monitor),
            _ => None,
        }
    }
}

// ───────────────────────────────────────────────────────────────────────
// Runtime mode (YAML / env-driven, runtime-wide)
// ───────────────────────────────────────────────────────────────────────

/// Runtime-wide enforcement mode (#14). Set by top-level YAML
/// `mode:` or by `AGENT_SHIELD_MODE` (env wins; default `Active`).
///
/// Distinct from [`ShieldMode`]: that is a per-SDK-orchestrator
/// knob; this is the runtime-wide value read by core stage runners
/// and the resolver runtime. In `Shadow`, verdicts are still
/// computed but side effects are suppressed (in-place transforms,
/// human / tool / agent / delegate resolvers). SDKs map
/// `Shadow → ShieldMode::Monitor` so the existing "log the block,
/// proceed anyway" path is reused.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default, Hash)]
#[serde(rename_all = "snake_case")]
pub enum RuntimeMode {
    /// Default: evaluate every stage and enforce every decision.
    #[default]
    Active,
    /// Evaluate every stage and log every decision; never enforce.
    /// Log events carry `mode: shadow, enforced: false`.
    Shadow,
}

impl RuntimeMode {
    /// Canonical wire-shape string (snake_case).
    pub fn as_wire_str(&self) -> &'static str {
        match self {
            Self::Active => "active",
            Self::Shadow => "shadow",
        }
    }

    /// Parse a wire-shape string (case-insensitive, trimmed). `None`
    /// on unknown values; callers choose their own error semantics.
    pub fn from_wire_str(s: &str) -> Option<Self> {
        let t = s.trim();
        if t.eq_ignore_ascii_case("active") {
            Some(Self::Active)
        } else if t.eq_ignore_ascii_case("shadow") {
            Some(Self::Shadow)
        } else {
            None
        }
    }

    /// `true` when this is the shadow (log-only) mode.
    pub fn is_shadow(self) -> bool {
        matches!(self, Self::Shadow)
    }

    /// Effective orchestrator mode: `Shadow` forces `Monitor`,
    /// otherwise pass through.
    pub fn effective_shield_mode(self, configured: ShieldMode) -> ShieldMode {
        match self {
            Self::Active => configured,
            Self::Shadow => ShieldMode::Monitor,
        }
    }
}

// ───────────────────────────────────────────────────────────────────────
// Canonical verdict-handling decision (Stage 1 / Stage 5)
// ───────────────────────────────────────────────────────────────────────

/// What action the SDK orchestrator should take after a stage's
/// validation.
///
/// This is the deterministic decision that every SDK previously
/// re-implemented inline. The SDK is still responsible for the
/// language-specific dispatch (raising, calling host callbacks, mutating
/// the framework result, etc.); core just hands back a tagged action.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum DispatchAction {
    /// Verdict allowed, no mutation. Proceed to the next stage.
    Proceed,
    /// Verdict allowed but a transform (Stage 5 redaction / append /
    /// prepend) produced a final string. The SDK should swap the
    /// content for `value` before delivering.
    ProceedWithMutation { value: String },
    /// Stage blocked. SDK should call its `make_blocked(message)` and
    /// return that to the host.
    ReturnBlocked { message: String },
    /// Stage blocked. SDK should return the raw `StageVerdict` to the
    /// caller.
    ReturnVerdict,
    /// Stage blocked. SDK should throw / raise an exception with the
    /// canonical block message.
    Raise { message: String },
    /// Stage blocked. SDK should invoke its host-registered callback
    /// with the verdict and use the result. Core never owns that
    /// callable.
    InvokeCustom { message: String },
}

/// The full result of the canonical verdict-handling decision.
///
/// SDKs branch on `action` for what to do, on `record_block` for what
/// to surface to observability, and on `override_to_proceed` for the
/// monitor-mode override (the orchestrator should log the block and
/// then proceed even though the action says "block").
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct VerdictDispatch {
    pub action: DispatchAction,
    /// `true` if the SDK should record this as a block in its
    /// observability sinks (the case for every deny, including
    /// monitor-mode-overridden ones).
    pub record_block: bool,
    /// `true` when the verdict denied but the mode is `Monitor`: the
    /// SDK should log the block and then proceed as if allowed. The
    /// `action` field still carries the canonical message so monitor
    /// loggers can render the same string the enforce path would.
    pub override_to_proceed: bool,
}

/// Canonical decision for a Stage 1 / Stage 5 verdict.
///
/// Pure function — no I/O, no observability calls, no host callbacks.
/// Every SDK Shield orchestrator routes its verdict-handling through
/// this single implementation so customer-visible block strings and
/// dispatch semantics are byte-equivalent across languages.
pub fn dispatch_stage_verdict(
    verdict: &StageVerdict,
    policy: OnBlockPolicy,
    mode: ShieldMode,
) -> VerdictDispatch {
    if verdict.allowed {
        // Stage 5 may have rewritten the content. Prefer the
        // redaction string when present; fall back to append/prepend
        // outputs (the runtime sets exactly one of these on
        // transform-only verdicts).
        if let Some(value) = verdict
            .redaction
            .as_ref()
            .or(verdict.appended.as_ref())
            .or(verdict.prepended.as_ref())
        {
            return VerdictDispatch {
                action: DispatchAction::ProceedWithMutation {
                    value: value.clone(),
                },
                record_block: false,
                override_to_proceed: false,
            };
        }
        return VerdictDispatch {
            action: DispatchAction::Proceed,
            record_block: false,
            override_to_proceed: false,
        };
    }
    // Verdict denied — build the canonical block message.
    let message = format_block_message(verdict);
    let action = match policy {
        OnBlockPolicy::ReturnBlocked => DispatchAction::ReturnBlocked { message },
        OnBlockPolicy::ReturnVerdict => DispatchAction::ReturnVerdict,
        OnBlockPolicy::Raise => DispatchAction::Raise { message },
        OnBlockPolicy::Custom => DispatchAction::InvokeCustom { message },
    };
    VerdictDispatch {
        action,
        record_block: true,
        override_to_proceed: matches!(mode, ShieldMode::Monitor),
    }
}

// ───────────────────────────────────────────────────────────────────────
// Canonical verdict-handling decision (Stage 2 + 3 + 4 — tool calls)
// ───────────────────────────────────────────────────────────────────────

/// What action the SDK orchestrator should take after a tool-stage
/// verdict.
///
/// Tool stages have a slightly different shape than Stage 1/5: the
/// orchestrator pairs the action with a `(blocked, output)` tuple and
/// must record success or failure on the resource cycle in addition to
/// the dispatch decision.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ToolDispatchAction {
    /// Tool call may proceed (Stage 2+3) or its output may be returned
    /// to the agent (Stage 4) unchanged.
    Proceed,
    /// Stage 4 redact / append / prepend produced a transformed
    /// output. The SDK should hand the agent `value` instead of the
    /// raw tool output.
    ProceedWithMutation { value: String },
    /// Stage blocked. The SDK should hand the agent the canonical
    /// block message and surface a tool failure on the resource
    /// cycle.
    Blocked { message: String },
}

/// Full result of the canonical tool-verdict decision.
///
/// SDKs branch on `action` and use the side-channel flags to drive
/// `record_tool_success` / `record_tool_failure`. `record_failure`
/// fires on any deny (including monitor-mode); `record_success`
/// fires only on a clean Stage-4 allow.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ToolVerdictDispatch {
    pub action: ToolDispatchAction,
    /// `true` when the SDK should call `record_tool_failure` on the
    /// resource cycle.
    pub record_failure: bool,
    /// `true` when the SDK should call `record_tool_success` on the
    /// resource cycle.
    pub record_success: bool,
    /// `true` when the verdict denied but the mode is `Monitor`: the
    /// SDK should log the block and then proceed as if allowed. The
    /// canonical message still appears in `action` so monitor loggers
    /// render the same string the enforce path would.
    pub override_to_proceed: bool,
}

/// Tool-stage canonical decision context. The same function handles
/// Stage 2/3 (`Call`) and Stage 4 (`Output`) since the dispatch shape
/// only differs in which resource-cycle records to emit on a clean
/// allow.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ToolStage {
    /// Stage 2 + Stage 3 — the call site, pre-execute. A clean allow
    /// does NOT record success (the tool hasn't run yet); a deny does
    /// not record failure either (no resource cycle was opened).
    Call,
    /// Stage 4 — post-execute. A clean allow records success; a deny
    /// records failure on the resource cycle.
    Output,
}

/// Canonical decision for a Stage 2/3/4 verdict on a tool call.
///
/// Pure function — no I/O. The SDK is still responsible for actually
/// invoking `record_tool_success` / `record_tool_failure` and for
/// returning the framework-shaped tool result.
pub fn dispatch_tool_verdict(
    verdict: &StageVerdict,
    tool_name: &str,
    stage: ToolStage,
    _policy: OnBlockPolicy,
    mode: ShieldMode,
) -> ToolVerdictDispatch {
    if verdict.allowed {
        let action = if let Some(value) = verdict
            .redaction
            .as_ref()
            .or(verdict.appended.as_ref())
            .or(verdict.prepended.as_ref())
        {
            ToolDispatchAction::ProceedWithMutation {
                value: value.clone(),
            }
        } else {
            ToolDispatchAction::Proceed
        };
        return ToolVerdictDispatch {
            action,
            record_failure: false,
            // Only Stage 4 (post-execute) records a success on a clean
            // allow — Stage 2/3 fires before the tool runs.
            record_success: matches!(stage, ToolStage::Output),
            override_to_proceed: false,
        };
    }
    // Verdict denied. Tool-call messages get the `(tool: <name>)`
    // suffix per the canonical wire shape.
    let message = format_tool_block_message(verdict, tool_name);
    ToolVerdictDispatch {
        action: ToolDispatchAction::Blocked { message },
        // Stage 2/3 deny: no resource cycle was opened, nothing to
        // record. Stage 4 deny: record the failure.
        record_failure: matches!(stage, ToolStage::Output),
        record_success: false,
        override_to_proceed: matches!(mode, ShieldMode::Monitor),
    }
}

// ───────────────────────────────────────────────────────────────────────
// JSON wire-shape helpers
// ───────────────────────────────────────────────────────────────────────

/// JSON wire-shape for [`VerdictDispatch`] — the payload every SDK
/// sees over its FFI / PyO3 / napi bridge. Action is encoded as
/// `{"kind": "...", ...}` so language bindings can match on a single
/// string field.
pub fn dispatch_outcome_to_wire(outcome: &VerdictDispatch) -> serde_json::Value {
    let action = match &outcome.action {
        DispatchAction::Proceed => serde_json::json!({ "kind": "proceed" }),
        DispatchAction::ProceedWithMutation { value } => serde_json::json!({
            "kind": "proceed_with_mutation",
            "value": value,
        }),
        DispatchAction::ReturnBlocked { message } => serde_json::json!({
            "kind": "return_blocked",
            "message": message,
        }),
        DispatchAction::ReturnVerdict => serde_json::json!({ "kind": "return_verdict" }),
        DispatchAction::Raise { message } => serde_json::json!({
            "kind": "raise",
            "message": message,
        }),
        DispatchAction::InvokeCustom { message } => serde_json::json!({
            "kind": "invoke_custom",
            "message": message,
        }),
    };
    serde_json::json!({
        "action": action,
        "record_block": outcome.record_block,
        "override_to_proceed": outcome.override_to_proceed,
    })
}

/// JSON wire-shape for [`ToolVerdictDispatch`].
pub fn tool_dispatch_outcome_to_wire(outcome: &ToolVerdictDispatch) -> serde_json::Value {
    let action = match &outcome.action {
        ToolDispatchAction::Proceed => serde_json::json!({ "kind": "proceed" }),
        ToolDispatchAction::ProceedWithMutation { value } => serde_json::json!({
            "kind": "proceed_with_mutation",
            "value": value,
        }),
        ToolDispatchAction::Blocked { message } => serde_json::json!({
            "kind": "blocked",
            "message": message,
        }),
    };
    serde_json::json!({
        "action": action,
        "record_failure": outcome.record_failure,
        "record_success": outcome.record_success,
        "override_to_proceed": outcome.override_to_proceed,
    })
}

/// Parse a JSON-wire `StageVerdict` (the same shape every FFI export
/// already produces via `stage_verdict_to_json`) into the in-memory
/// `StageVerdict`. This is the inverse of the existing serializer and
/// is used by the dispatch FFI exports so language bindings can ship
/// the verdict they already hold without a second native crossing.
///
/// Returns `None` on missing required fields or malformed JSON.
pub fn stage_verdict_from_wire(value: &serde_json::Value) -> Option<StageVerdict> {
    let obj = value.as_object()?;
    let allowed = obj.get("allowed")?.as_bool()?;
    let action = obj.get("action").and_then(|v| match v {
        serde_json::Value::String(s) => match s.as_str() {
            "block" => Some(Action::Block),
            "redact" => Some(Action::Redact),
            "warn" => Some(Action::Warn),
            "append" => Some(Action::Append),
            "prepend" => Some(Action::Prepend),
            _ => None,
        },
        _ => None,
    });
    let reason = obj
        .get("reason")
        .and_then(|v| v.as_str().map(str::to_string));
    let policy = obj
        .get("policy")
        .and_then(|v| v.as_str().map(str::to_string));
    let evaluate_when_index = obj
        .get("evaluate_when_index")
        .and_then(|v| v.as_u64().map(|n| n as usize));
    let bypassed_by_allowed_when = obj
        .get("bypassed_by_allowed_when")
        .and_then(|v| v.as_bool())
        .unwrap_or(false);
    let redaction = obj
        .get("redaction")
        .and_then(|v| v.as_str().map(str::to_string));
    let appended = obj
        .get("appended")
        .and_then(|v| v.as_str().map(str::to_string));
    let prepended = obj
        .get("prepended")
        .and_then(|v| v.as_str().map(str::to_string));
    let invocation_hash = obj
        .get("invocation_hash")
        .and_then(|v| v.as_str().map(str::to_string));
    let post_validation_invocation_hash = obj
        .get("post_validation_invocation_hash")
        .and_then(|v| v.as_str().map(str::to_string));
    Some(StageVerdict {
        allowed,
        action,
        reason,
        policy,
        evaluate_when_index,
        bypassed_by_allowed_when,
        redaction,
        appended,
        prepended,
        // pending_resolution is not part of the dispatch decision, so
        // we never need to round-trip it through this path. SDKs hold
        // it independently and can consult it after the dispatch call.
        pending_resolution: None,
        // declassify_to is applied as a side-effect by the session at
        // verdict-handling time, not transported through the wire
        // dispatch shape. SDKs read it off the StageVerdict directly.
        declassify_to: None,
        invocation_hash,
        post_validation_invocation_hash,
    })
}

// ───────────────────────────────────────────────────────────────────────
// Tests
// ───────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    fn verdict_blocked(action: Option<Action>, reason: Option<&str>) -> StageVerdict {
        StageVerdict {
            allowed: false,
            action,
            reason: reason.map(String::from),
            policy: None,
            evaluate_when_index: None,
            bypassed_by_allowed_when: false,
            redaction: None,
            appended: None,
            prepended: None,
            pending_resolution: None,
            declassify_to: None,
            invocation_hash: None,
            post_validation_invocation_hash: None,
        }
    }

    #[test]
    fn format_uses_action_uppercased() {
        let v = verdict_blocked(Some(Action::Block), Some("PII detected"));
        assert_eq!(format_block_message(&v), "[GUARDRAIL BLOCK] PII detected");
    }

    #[test]
    fn format_handles_redact_action() {
        let v = verdict_blocked(Some(Action::Redact), Some("phone number"));
        assert_eq!(format_block_message(&v), "[GUARDRAIL REDACT] phone number",);
    }

    #[test]
    fn format_falls_back_when_action_missing() {
        let v = verdict_blocked(None, Some("denied"));
        assert_eq!(format_block_message(&v), "[GUARDRAIL BLOCK] denied");
    }

    #[test]
    fn format_falls_back_when_reason_missing() {
        let v = verdict_blocked(Some(Action::Block), None);
        assert_eq!(
            format_block_message(&v),
            "[GUARDRAIL BLOCK] blocked by policy",
        );
    }

    #[test]
    fn format_falls_back_when_reason_is_blank() {
        let v = verdict_blocked(Some(Action::Block), Some(""));
        assert_eq!(
            format_block_message(&v),
            "[GUARDRAIL BLOCK] blocked by policy",
        );
    }

    #[test]
    fn tool_format_appends_tool_name() {
        let v = verdict_blocked(Some(Action::Block), Some("denied"));
        assert_eq!(
            format_tool_block_message(&v, "send_email"),
            "[GUARDRAIL BLOCK] denied (tool: send_email)",
        );
    }

    #[test]
    fn on_block_policy_wire_roundtrip() {
        for p in [
            OnBlockPolicy::ReturnBlocked,
            OnBlockPolicy::ReturnVerdict,
            OnBlockPolicy::Raise,
            OnBlockPolicy::Custom,
        ] {
            let s = p.as_wire_str();
            assert_eq!(OnBlockPolicy::from_wire_str(s), Some(p));
        }
    }

    #[test]
    fn on_block_accepts_camel_case_legacy() {
        assert_eq!(
            OnBlockPolicy::from_wire_str("returnBlocked"),
            Some(OnBlockPolicy::ReturnBlocked),
        );
        assert_eq!(
            OnBlockPolicy::from_wire_str("returnVerdict"),
            Some(OnBlockPolicy::ReturnVerdict),
        );
    }

    #[test]
    fn on_block_unknown_value() {
        assert_eq!(OnBlockPolicy::from_wire_str("nope"), None);
    }

    #[test]
    fn resolve_return_blocked() {
        let v = verdict_blocked(Some(Action::Block), Some("policy says no"));
        let out = resolve_on_block(OnBlockPolicy::ReturnBlocked, &v);
        match out {
            OnBlockOutcome::ReturnBlocked { message } => {
                assert_eq!(message, "[GUARDRAIL BLOCK] policy says no");
            }
            other => panic!("unexpected outcome: {other:?}"),
        }
    }

    #[test]
    fn resolve_return_verdict() {
        let v = verdict_blocked(Some(Action::Block), Some("policy says no"));
        let out = resolve_on_block(OnBlockPolicy::ReturnVerdict, &v);
        assert_eq!(out, OnBlockOutcome::ReturnVerdict);
    }

    #[test]
    fn resolve_raise() {
        let v = verdict_blocked(Some(Action::Block), Some("policy says no"));
        let out = resolve_on_block(OnBlockPolicy::Raise, &v);
        match out {
            OnBlockOutcome::Raise { message } => {
                assert_eq!(message, "[GUARDRAIL BLOCK] policy says no");
            }
            other => panic!("unexpected outcome: {other:?}"),
        }
    }

    #[test]
    fn resolve_custom() {
        let v = verdict_blocked(Some(Action::Block), Some("policy says no"));
        let out = resolve_on_block(OnBlockPolicy::Custom, &v);
        match out {
            OnBlockOutcome::Custom { message } => {
                assert_eq!(message, "[GUARDRAIL BLOCK] policy says no");
            }
            other => panic!("unexpected outcome: {other:?}"),
        }
    }

    #[test]
    fn default_policy_is_return_blocked() {
        assert_eq!(OnBlockPolicy::default(), OnBlockPolicy::ReturnBlocked);
    }

    // ── ShieldMode ───────────────────────────────────────────────────

    #[test]
    fn shield_mode_default_is_enforce() {
        assert_eq!(ShieldMode::default(), ShieldMode::Enforce);
    }

    #[test]
    fn shield_mode_wire_roundtrip() {
        for m in [ShieldMode::Enforce, ShieldMode::Monitor] {
            assert_eq!(ShieldMode::from_wire_str(m.as_wire_str()), Some(m));
        }
        assert_eq!(ShieldMode::from_wire_str("unknown"), None);
    }

    // ── dispatch_stage_verdict — happy paths ─────────────────────────

    fn allow_clean() -> StageVerdict {
        StageVerdict {
            allowed: true,
            action: None,
            reason: None,
            policy: None,
            evaluate_when_index: None,
            bypassed_by_allowed_when: false,
            redaction: None,
            appended: None,
            prepended: None,
            pending_resolution: None,
            declassify_to: None,
            invocation_hash: None,
            post_validation_invocation_hash: None,
        }
    }

    fn allow_with_redaction(redacted: &str) -> StageVerdict {
        StageVerdict {
            redaction: Some(redacted.into()),
            action: Some(Action::Redact),
            ..allow_clean()
        }
    }

    fn allow_with_appended(text: &str) -> StageVerdict {
        StageVerdict {
            appended: Some(text.into()),
            action: Some(Action::Append),
            ..allow_clean()
        }
    }

    fn allow_with_prepended(text: &str) -> StageVerdict {
        StageVerdict {
            prepended: Some(text.into()),
            action: Some(Action::Prepend),
            ..allow_clean()
        }
    }

    #[test]
    fn dispatch_proceed_on_clean_allow() {
        let v = allow_clean();
        for policy in [
            OnBlockPolicy::ReturnBlocked,
            OnBlockPolicy::ReturnVerdict,
            OnBlockPolicy::Raise,
            OnBlockPolicy::Custom,
        ] {
            for mode in [ShieldMode::Enforce, ShieldMode::Monitor] {
                let out = dispatch_stage_verdict(&v, policy, mode);
                assert_eq!(
                    out,
                    VerdictDispatch {
                        action: DispatchAction::Proceed,
                        record_block: false,
                        override_to_proceed: false,
                    },
                    "policy={policy:?} mode={mode:?}",
                );
            }
        }
    }

    #[test]
    fn dispatch_proceed_with_mutation_when_redacted() {
        let v = allow_with_redaction("REDACTED OUTPUT");
        let out = dispatch_stage_verdict(&v, OnBlockPolicy::ReturnBlocked, ShieldMode::Enforce);
        assert_eq!(
            out.action,
            DispatchAction::ProceedWithMutation {
                value: "REDACTED OUTPUT".into()
            }
        );
        assert!(!out.record_block);
        assert!(!out.override_to_proceed);
    }

    #[test]
    fn dispatch_proceed_with_mutation_when_appended() {
        let v = allow_with_appended("HELLO + suffix");
        let out = dispatch_stage_verdict(&v, OnBlockPolicy::ReturnBlocked, ShieldMode::Enforce);
        assert_eq!(
            out.action,
            DispatchAction::ProceedWithMutation {
                value: "HELLO + suffix".into()
            }
        );
    }

    #[test]
    fn dispatch_proceed_with_mutation_when_prepended() {
        let v = allow_with_prepended("prefix + WORLD");
        let out = dispatch_stage_verdict(&v, OnBlockPolicy::ReturnBlocked, ShieldMode::Enforce);
        assert_eq!(
            out.action,
            DispatchAction::ProceedWithMutation {
                value: "prefix + WORLD".into()
            }
        );
    }

    #[test]
    fn dispatch_redaction_takes_precedence_over_append_or_prepend() {
        let v = StageVerdict {
            allowed: true,
            redaction: Some("R".into()),
            appended: Some("A".into()),
            prepended: Some("P".into()),
            action: Some(Action::Redact),
            ..allow_clean()
        };
        let out = dispatch_stage_verdict(&v, OnBlockPolicy::ReturnBlocked, ShieldMode::Enforce);
        assert_eq!(
            out.action,
            DispatchAction::ProceedWithMutation { value: "R".into() }
        );
    }

    // ── dispatch_stage_verdict — deny paths × every policy × mode ────

    #[test]
    fn dispatch_return_blocked_in_enforce() {
        let v = verdict_blocked(Some(Action::Block), Some("policy says no"));
        let out = dispatch_stage_verdict(&v, OnBlockPolicy::ReturnBlocked, ShieldMode::Enforce);
        assert_eq!(
            out.action,
            DispatchAction::ReturnBlocked {
                message: "[GUARDRAIL BLOCK] policy says no".into()
            }
        );
        assert!(out.record_block);
        assert!(!out.override_to_proceed);
    }

    #[test]
    fn dispatch_return_blocked_in_monitor_overrides_to_proceed() {
        let v = verdict_blocked(Some(Action::Block), Some("policy says no"));
        let out = dispatch_stage_verdict(&v, OnBlockPolicy::ReturnBlocked, ShieldMode::Monitor);
        assert_eq!(
            out.action,
            DispatchAction::ReturnBlocked {
                message: "[GUARDRAIL BLOCK] policy says no".into()
            }
        );
        assert!(out.record_block);
        assert!(out.override_to_proceed);
    }

    #[test]
    fn dispatch_return_verdict_in_enforce_and_monitor() {
        let v = verdict_blocked(Some(Action::Block), Some("nope"));
        let enforce = dispatch_stage_verdict(&v, OnBlockPolicy::ReturnVerdict, ShieldMode::Enforce);
        assert_eq!(enforce.action, DispatchAction::ReturnVerdict);
        assert!(enforce.record_block);
        assert!(!enforce.override_to_proceed);

        let monitor = dispatch_stage_verdict(&v, OnBlockPolicy::ReturnVerdict, ShieldMode::Monitor);
        assert_eq!(monitor.action, DispatchAction::ReturnVerdict);
        assert!(monitor.record_block);
        assert!(monitor.override_to_proceed);
    }

    #[test]
    fn dispatch_raise_in_enforce_and_monitor() {
        let v = verdict_blocked(Some(Action::Block), Some("nope"));
        let enforce = dispatch_stage_verdict(&v, OnBlockPolicy::Raise, ShieldMode::Enforce);
        assert_eq!(
            enforce.action,
            DispatchAction::Raise {
                message: "[GUARDRAIL BLOCK] nope".into()
            }
        );
        assert!(enforce.record_block);
        assert!(!enforce.override_to_proceed);

        let monitor = dispatch_stage_verdict(&v, OnBlockPolicy::Raise, ShieldMode::Monitor);
        assert_eq!(
            monitor.action,
            DispatchAction::Raise {
                message: "[GUARDRAIL BLOCK] nope".into()
            }
        );
        assert!(monitor.override_to_proceed);
    }

    #[test]
    fn dispatch_custom_in_enforce_and_monitor() {
        let v = verdict_blocked(Some(Action::Block), Some("nope"));
        let enforce = dispatch_stage_verdict(&v, OnBlockPolicy::Custom, ShieldMode::Enforce);
        assert_eq!(
            enforce.action,
            DispatchAction::InvokeCustom {
                message: "[GUARDRAIL BLOCK] nope".into()
            }
        );
        assert!(enforce.record_block);

        let monitor = dispatch_stage_verdict(&v, OnBlockPolicy::Custom, ShieldMode::Monitor);
        assert!(monitor.override_to_proceed);
    }

    #[test]
    fn dispatch_uses_canonical_block_message_for_redact_action() {
        let v = verdict_blocked(Some(Action::Redact), Some("PII detected"));
        let out = dispatch_stage_verdict(&v, OnBlockPolicy::Raise, ShieldMode::Enforce);
        assert_eq!(
            out.action,
            DispatchAction::Raise {
                message: "[GUARDRAIL REDACT] PII detected".into()
            }
        );
    }

    #[test]
    fn dispatch_falls_back_to_blocked_by_policy_when_reason_missing() {
        let v = verdict_blocked(Some(Action::Block), None);
        let out = dispatch_stage_verdict(&v, OnBlockPolicy::ReturnBlocked, ShieldMode::Enforce);
        assert_eq!(
            out.action,
            DispatchAction::ReturnBlocked {
                message: "[GUARDRAIL BLOCK] blocked by policy".into()
            }
        );
    }

    // ── dispatch_tool_verdict ─────────────────────────────────────────

    #[test]
    fn tool_dispatch_stage23_clean_allow_does_not_record_success() {
        let v = allow_clean();
        let out = dispatch_tool_verdict(
            &v,
            "send_email",
            ToolStage::Call,
            OnBlockPolicy::ReturnBlocked,
            ShieldMode::Enforce,
        );
        assert_eq!(out.action, ToolDispatchAction::Proceed);
        assert!(!out.record_failure);
        assert!(!out.record_success);
        assert!(!out.override_to_proceed);
    }

    #[test]
    fn tool_dispatch_stage4_clean_allow_records_success() {
        let v = allow_clean();
        let out = dispatch_tool_verdict(
            &v,
            "send_email",
            ToolStage::Output,
            OnBlockPolicy::ReturnBlocked,
            ShieldMode::Enforce,
        );
        assert_eq!(out.action, ToolDispatchAction::Proceed);
        assert!(!out.record_failure);
        assert!(out.record_success);
    }

    #[test]
    fn tool_dispatch_stage4_redacted_output_proceeds_with_mutation() {
        let v = allow_with_redaction("[redacted]");
        let out = dispatch_tool_verdict(
            &v,
            "lookup_account",
            ToolStage::Output,
            OnBlockPolicy::ReturnBlocked,
            ShieldMode::Enforce,
        );
        assert_eq!(
            out.action,
            ToolDispatchAction::ProceedWithMutation {
                value: "[redacted]".into()
            }
        );
        assert!(out.record_success);
        assert!(!out.record_failure);
    }

    #[test]
    fn tool_dispatch_stage23_blocked_in_enforce() {
        let v = verdict_blocked(Some(Action::Block), Some("policy denied tool"));
        let out = dispatch_tool_verdict(
            &v,
            "send_email",
            ToolStage::Call,
            OnBlockPolicy::ReturnBlocked,
            ShieldMode::Enforce,
        );
        assert_eq!(
            out.action,
            ToolDispatchAction::Blocked {
                message: "[GUARDRAIL BLOCK] policy denied tool (tool: send_email)".into()
            }
        );
        // Stage 2/3 deny: no resource cycle was opened, nothing to
        // record on the tool resource.
        assert!(!out.record_failure);
        assert!(!out.record_success);
        assert!(!out.override_to_proceed);
    }

    #[test]
    fn tool_dispatch_stage23_blocked_in_monitor_overrides() {
        let v = verdict_blocked(Some(Action::Block), Some("nope"));
        let out = dispatch_tool_verdict(
            &v,
            "t",
            ToolStage::Call,
            OnBlockPolicy::ReturnBlocked,
            ShieldMode::Monitor,
        );
        assert!(out.override_to_proceed);
    }

    #[test]
    fn tool_dispatch_stage4_blocked_records_failure_in_enforce() {
        let v = verdict_blocked(Some(Action::Block), Some("output denied"));
        let out = dispatch_tool_verdict(
            &v,
            "lookup",
            ToolStage::Output,
            OnBlockPolicy::ReturnBlocked,
            ShieldMode::Enforce,
        );
        assert_eq!(
            out.action,
            ToolDispatchAction::Blocked {
                message: "[GUARDRAIL BLOCK] output denied (tool: lookup)".into()
            }
        );
        assert!(out.record_failure);
        assert!(!out.record_success);
    }

    #[test]
    fn tool_dispatch_stage4_blocked_records_failure_in_monitor() {
        // Even in monitor mode the record_failure side-effect fires
        // because the resource cycle WAS opened (the tool ran). Mode
        // only governs whether the orchestrator returns the block to
        // the agent.
        let v = verdict_blocked(Some(Action::Block), Some("nope"));
        let out = dispatch_tool_verdict(
            &v,
            "t",
            ToolStage::Output,
            OnBlockPolicy::ReturnBlocked,
            ShieldMode::Monitor,
        );
        assert!(out.record_failure);
        assert!(out.override_to_proceed);
    }

    // ── Wire shape ───────────────────────────────────────────────────

    #[test]
    fn dispatch_outcome_wire_proceed() {
        let out = VerdictDispatch {
            action: DispatchAction::Proceed,
            record_block: false,
            override_to_proceed: false,
        };
        let v = dispatch_outcome_to_wire(&out);
        assert_eq!(v["action"]["kind"], "proceed");
        assert_eq!(v["record_block"], false);
        assert_eq!(v["override_to_proceed"], false);
    }

    #[test]
    fn dispatch_outcome_wire_proceed_with_mutation() {
        let out = VerdictDispatch {
            action: DispatchAction::ProceedWithMutation {
                value: "ABC".into(),
            },
            record_block: false,
            override_to_proceed: false,
        };
        let v = dispatch_outcome_to_wire(&out);
        assert_eq!(v["action"]["kind"], "proceed_with_mutation");
        assert_eq!(v["action"]["value"], "ABC");
    }

    #[test]
    fn dispatch_outcome_wire_return_blocked() {
        let out = VerdictDispatch {
            action: DispatchAction::ReturnBlocked {
                message: "MSG".into(),
            },
            record_block: true,
            override_to_proceed: false,
        };
        let v = dispatch_outcome_to_wire(&out);
        assert_eq!(v["action"]["kind"], "return_blocked");
        assert_eq!(v["action"]["message"], "MSG");
        assert_eq!(v["record_block"], true);
    }

    #[test]
    fn dispatch_outcome_wire_invoke_custom() {
        let out = VerdictDispatch {
            action: DispatchAction::InvokeCustom {
                message: "MSG".into(),
            },
            record_block: true,
            override_to_proceed: true,
        };
        let v = dispatch_outcome_to_wire(&out);
        assert_eq!(v["action"]["kind"], "invoke_custom");
        assert_eq!(v["action"]["message"], "MSG");
        assert_eq!(v["override_to_proceed"], true);
    }

    #[test]
    fn tool_dispatch_outcome_wire_blocked() {
        let out = ToolVerdictDispatch {
            action: ToolDispatchAction::Blocked {
                message: "MSG".into(),
            },
            record_failure: true,
            record_success: false,
            override_to_proceed: false,
        };
        let v = tool_dispatch_outcome_to_wire(&out);
        assert_eq!(v["action"]["kind"], "blocked");
        assert_eq!(v["action"]["message"], "MSG");
        assert_eq!(v["record_failure"], true);
        assert_eq!(v["record_success"], false);
    }

    // ── stage_verdict_from_wire round-trip ────────────────────────────

    #[test]
    fn stage_verdict_from_wire_blocked() {
        let json = serde_json::json!({
            "allowed": false,
            "action": "block",
            "reason": "policy says no",
            "policy": "p1",
            "evaluate_when_index": 0,
            "bypassed_by_allowed_when": false,
            "redaction": null,
            "appended": null,
            "prepended": null,
        });
        let v = stage_verdict_from_wire(&json).expect("parses");
        assert!(!v.allowed);
        assert_eq!(v.action, Some(Action::Block));
        assert_eq!(v.reason.as_deref(), Some("policy says no"));
    }

    #[test]
    fn stage_verdict_from_wire_allowed_with_redaction() {
        let json = serde_json::json!({
            "allowed": true,
            "action": "redact",
            "reason": null,
            "policy": null,
            "evaluate_when_index": null,
            "bypassed_by_allowed_when": false,
            "redaction": "REDACTED",
            "appended": null,
            "prepended": null,
        });
        let v = stage_verdict_from_wire(&json).expect("parses");
        assert!(v.allowed);
        assert_eq!(v.redaction.as_deref(), Some("REDACTED"));
    }

    #[test]
    fn stage_verdict_from_wire_rejects_missing_allowed() {
        let json = serde_json::json!({});
        assert!(stage_verdict_from_wire(&json).is_none());
    }

    // ── End-to-end: parse → dispatch → wire ─────────────────────────

    #[test]
    fn end_to_end_parse_dispatch_serialize() {
        let json = serde_json::json!({
            "allowed": false,
            "action": "block",
            "reason": "denied",
            "policy": null,
            "evaluate_when_index": null,
            "bypassed_by_allowed_when": false,
            "redaction": null,
            "appended": null,
            "prepended": null,
        });
        let v = stage_verdict_from_wire(&json).unwrap();
        let out = dispatch_stage_verdict(&v, OnBlockPolicy::Raise, ShieldMode::Enforce);
        let wire = dispatch_outcome_to_wire(&out);
        assert_eq!(wire["action"]["kind"], "raise");
        assert_eq!(wire["action"]["message"], "[GUARDRAIL BLOCK] denied");
        assert_eq!(wire["record_block"], true);
        assert_eq!(wire["override_to_proceed"], false);
    }
}
