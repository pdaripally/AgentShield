//! `metadata` block (§4) and `AgentShieldVersion` semver-band logic (§4.1).
//!
//! Hand-rolled semver to avoid pulling a new dependency.

use serde::{Deserialize, Serialize};
use std::str::FromStr;
use std::sync::LazyLock;

use super::errors::{ConfigError, SourceLoc};

/// Runtime spec version this build claims to implement (`2.0.0-alpha`).
///
/// Per spec §4.1 (pre-release is documentation only), any file declaring
/// `2.0`, `2.0.0`, or any `2.0.0-<pre>` is satisfied by this runtime.
/// Files declaring `1.x` are cross-band and rejected by the §4.1
/// compatibility check.
pub static RUNTIME_SPEC_VERSION: LazyLock<AgentShieldVersion> =
    LazyLock::new(|| AgentShieldVersion {
        major: 2,
        minor: 0,
        patch: 0,
        pre_release: Some("alpha".to_string()),
    });

/// `metadata` block (§4).
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Metadata {
    pub name: String,
    pub version: String,
    #[serde(skip_serializing_if = "Option::is_none", default)]
    pub description: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none", default)]
    pub agent_shield_version: Option<AgentShieldVersion>,
}

/// A simplified semver representation for `agent_shield_version` (§4.1).
///
/// Accepts `MAJOR.MINOR.PATCH` and `MAJOR.MINOR` shorthand, optionally with a
/// `-pre.release` suffix.
#[derive(Debug, Clone, Eq, PartialEq)]
pub struct AgentShieldVersion {
    pub major: u32,
    pub minor: u32,
    pub patch: u32,
    pub pre_release: Option<String>,
}

impl AgentShieldVersion {
    pub const fn new(major: u32, minor: u32, patch: u32) -> Self {
        Self {
            major,
            minor,
            patch,
            pre_release: None,
        }
    }

    /// Spec §4.1: returns `true` iff `runtime` satisfies a file declaring `self`.
    ///
    /// Rules:
    /// - `runtime >= self`, AND
    /// - same compatibility band:
    ///   - `MAJOR == 0` → same minor (`runtime.minor == self.minor`)
    ///   - `MAJOR >= 1` → same major (`runtime.major == self.major`)
    ///
    /// Pre-release suffixes on either side are **documentation only**
    /// per spec §4.1. They do not participate in the `>=` comparison
    /// or in `most_restrictive`-ordering across an `extends:` chain.
    /// Authors MUST NOT use pre-release suffixes on
    /// `agent_shield_version` to require feature levels — a runtime
    /// declaring `2.0.0-alpha` will satisfy a YAML that declares
    /// `"2.0.0-rc.1"`.
    pub fn compatible_with(&self, runtime: &AgentShieldVersion) -> bool {
        if !self.same_band(runtime) {
            return false;
        }
        runtime.cmp_release_precedence(self).is_ge()
    }

    /// Two versions are in the same compatibility band per §4.1.
    pub fn same_band(&self, other: &AgentShieldVersion) -> bool {
        if self.major == 0 || other.major == 0 {
            // Pre-1.0 band is MAJOR.MINOR; both sides must agree on both.
            self.major == other.major && self.minor == other.minor
        } else {
            self.major == other.major
        }
    }

    /// Ordering on the **numeric release** component only — `(major, minor,
    /// patch)`. Pre-release suffixes are ignored on both sides; this is
    /// the comparator the spec §4.1 "satisfies" check uses, and §4.2's
    /// `most_restrictive` ordering uses it too. See `compatible_with` for
    /// the policy rationale.
    fn cmp_release_precedence(&self, other: &Self) -> std::cmp::Ordering {
        (self.major, self.minor, self.patch).cmp(&(other.major, other.minor, other.patch))
    }
}

impl std::fmt::Display for AgentShieldVersion {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        if let Some(pre) = &self.pre_release {
            write!(f, "{}.{}.{}-{}", self.major, self.minor, self.patch, pre)
        } else {
            write!(f, "{}.{}.{}", self.major, self.minor, self.patch)
        }
    }
}

impl FromStr for AgentShieldVersion {
    type Err = String;

    fn from_str(s: &str) -> std::result::Result<Self, Self::Err> {
        if s.is_empty() {
            return Err("empty version string".to_string());
        }
        let (core, pre) = match s.split_once('-') {
            Some((core, pre)) => (core, Some(pre.to_string())),
            None => (s, None),
        };

        let parts: Vec<&str> = core.split('.').collect();
        if parts.len() < 2 || parts.len() > 3 {
            return Err(format!(
                "expected MAJOR.MINOR or MAJOR.MINOR.PATCH, got `{}`",
                s
            ));
        }
        let parse = |p: &str| -> std::result::Result<u32, String> {
            p.parse::<u32>()
                .map_err(|e| format!("component `{}` is not a valid u32: {}", p, e))
        };
        let major = parse(parts[0])?;
        let minor = parse(parts[1])?;
        let patch = if parts.len() == 3 {
            parse(parts[2])?
        } else {
            0
        };

        Ok(AgentShieldVersion {
            major,
            minor,
            patch,
            pre_release: pre,
        })
    }
}

impl Serialize for AgentShieldVersion {
    fn serialize<S: serde::Serializer>(&self, ser: S) -> std::result::Result<S::Ok, S::Error> {
        ser.serialize_str(&self.to_string())
    }
}

impl<'de> Deserialize<'de> for AgentShieldVersion {
    fn deserialize<D: serde::Deserializer<'de>>(de: D) -> std::result::Result<Self, D::Error> {
        let raw = String::deserialize(de)?;
        AgentShieldVersion::from_str(&raw).map_err(serde::de::Error::custom)
    }
}

/// Compute the most-restrictive declared `agent_shield_version` across an
/// `extends:` chain (§4.2). Returns the highest-precedence version, or an
/// `IncompatibleVersionBands` error if any pair declares incompatible bands.
///
/// Per spec §4.1 (pre-release is documentation only), the ordering uses
/// numeric `(major, minor, patch)` comparison and ignores pre-release
/// suffixes — see [`AgentShieldVersion::cmp_release_precedence`].
pub fn most_restrictive(
    declared: &[(AgentShieldVersion, SourceLoc)],
) -> std::result::Result<Option<(AgentShieldVersion, SourceLoc)>, ConfigError> {
    if declared.is_empty() {
        return Ok(None);
    }
    let mut max_idx = 0usize;
    for i in 1..declared.len() {
        if !declared[0].0.same_band(&declared[i].0) {
            return Err(ConfigError::IncompatibleVersionBands {
                a: declared[0].0.to_string(),
                a_loc: declared[0].1.clone(),
                b: declared[i].0.to_string(),
                b_loc: declared[i].1.clone(),
            });
        }
        if declared[i]
            .0
            .cmp_release_precedence(&declared[max_idx].0)
            .is_gt()
        {
            max_idx = i;
        }
    }
    Ok(Some(declared[max_idx].clone()))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_major_minor_shorthand() {
        let v: AgentShieldVersion = "1.0".parse().unwrap();
        assert_eq!(v, AgentShieldVersion::new(1, 0, 0));
    }

    #[test]
    fn parses_full_semver_with_pre() {
        let v: AgentShieldVersion = "0.13.2-rc1".parse().unwrap();
        assert_eq!(v.major, 0);
        assert_eq!(v.minor, 13);
        assert_eq!(v.patch, 2);
        assert_eq!(v.pre_release.as_deref(), Some("rc1"));
    }

    #[test]
    fn rejects_garbage() {
        assert!("not.a.version".parse::<AgentShieldVersion>().is_err());
        assert!("1".parse::<AgentShieldVersion>().is_err());
        assert!("1.2.3.4".parse::<AgentShieldVersion>().is_err());
    }

    #[test]
    fn band_rules_pre_one_zero() {
        let a = AgentShieldVersion::new(0, 9, 1);
        let b = AgentShieldVersion::new(0, 10, 0);
        let c = AgentShieldVersion::new(0, 9, 2);
        assert!(a.same_band(&c));
        assert!(!a.same_band(&b));
    }

    #[test]
    fn band_rules_post_one_zero() {
        let a = AgentShieldVersion::new(1, 0, 0);
        let b = AgentShieldVersion::new(1, 4, 5);
        let c = AgentShieldVersion::new(2, 0, 0);
        assert!(a.same_band(&b));
        assert!(!a.same_band(&c));
    }

    #[test]
    fn compatible_within_band() {
        let declared = AgentShieldVersion::new(1, 0, 0);
        let runtime = AgentShieldVersion::new(1, 4, 0);
        assert!(declared.compatible_with(&runtime));
        // older runtime cannot satisfy newer declaration:
        let older = AgentShieldVersion::new(1, 0, 0);
        let newer = AgentShieldVersion::new(1, 4, 0);
        assert!(!newer.compatible_with(&older));
    }

    #[test]
    fn incompatible_across_bands() {
        let zero = AgentShieldVersion::new(0, 13, 0);
        let one = AgentShieldVersion::new(1, 0, 0);
        assert!(!zero.compatible_with(&one));
        assert!(!one.compatible_with(&zero));
    }

    #[test]
    fn most_restrictive_returns_max_in_band() {
        let chain = vec![
            (AgentShieldVersion::new(1, 0, 0), SourceLoc::default()),
            (AgentShieldVersion::new(1, 4, 0), SourceLoc::default()),
            (AgentShieldVersion::new(1, 2, 0), SourceLoc::default()),
        ];
        let res = most_restrictive(&chain).unwrap().unwrap();
        assert_eq!(res.0, AgentShieldVersion::new(1, 4, 0));
    }

    #[test]
    fn most_restrictive_rejects_band_mix() {
        let chain = vec![
            (AgentShieldVersion::new(0, 13, 0), SourceLoc::default()),
            (AgentShieldVersion::new(1, 0, 0), SourceLoc::default()),
        ];
        assert!(most_restrictive(&chain).is_err());
    }

    // ── §4.1 pre-release-non-gating policy ─────────────────────────────

    /// Helper to build an `AgentShieldVersion` with a pre-release tag.
    fn v_pre(major: u32, minor: u32, patch: u32, pre: &str) -> AgentShieldVersion {
        AgentShieldVersion {
            major,
            minor,
            patch,
            pre_release: Some(pre.to_string()),
        }
    }

    #[test]
    fn compatible_when_runtime_is_prerelease_of_same_base() {
        // Spec §4.1: a 2.0.0-alpha runtime satisfies a file declaring "2.0".
        let declared = AgentShieldVersion::new(2, 0, 0);
        let runtime = v_pre(2, 0, 0, "alpha");
        assert!(declared.compatible_with(&runtime));
    }

    #[test]
    fn compatible_when_declared_carries_prerelease_suffix() {
        // Spec §4.1 author warning: pre-release on the declared side is
        // documentation only; it MUST NOT be used as a feature-maturity gate.
        // A runtime in any pre-release of the same base satisfies it.
        let declared = v_pre(2, 0, 0, "rc.1");
        let runtime = v_pre(2, 0, 0, "alpha");
        assert!(declared.compatible_with(&runtime));
    }

    #[test]
    fn incompatible_when_declared_numeric_is_higher() {
        // Pre-release is non-gating, but the numeric tuple still gates.
        // 2.0.0-alpha cannot satisfy declared 2.0.1 or 2.1.0.
        let runtime = v_pre(2, 0, 0, "alpha");
        let declared_patch = AgentShieldVersion::new(2, 0, 1);
        let declared_minor = AgentShieldVersion::new(2, 1, 0);
        assert!(!declared_patch.compatible_with(&runtime));
        assert!(!declared_minor.compatible_with(&runtime));
    }

    #[test]
    fn same_band_ignores_prerelease() {
        // Band membership compares (major, minor) for MAJOR==0 and major for
        // MAJOR>=1, independent of pre-release.
        let a = v_pre(2, 0, 0, "alpha");
        let b = AgentShieldVersion::new(2, 4, 0);
        assert!(a.same_band(&b));

        let c = v_pre(0, 13, 0, "alpha");
        let d = AgentShieldVersion::new(0, 13, 2);
        assert!(c.same_band(&d));
        let e = AgentShieldVersion::new(0, 14, 0);
        assert!(!c.same_band(&e));
    }

    #[test]
    fn most_restrictive_ignores_prerelease() {
        // §4.2 ordering uses the same numeric-only comparator as §4.1.
        // A chain with mixed pre-release suffixes picks the highest numeric.
        let chain = vec![
            (v_pre(2, 0, 0, "alpha"), SourceLoc::default()),
            (AgentShieldVersion::new(2, 0, 0), SourceLoc::default()),
            (v_pre(2, 4, 0, "rc.1"), SourceLoc::default()),
        ];
        let res = most_restrictive(&chain).unwrap().unwrap();
        assert_eq!(
            (res.0.major, res.0.minor, res.0.patch),
            (2, 4, 0),
            "2.4.0-rc.1 has the highest numeric (2,4,0) in the chain"
        );
    }
}
