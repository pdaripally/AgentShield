//! host-facing runtime API for the unified-resolver model.
//!
//! Public surface (the §21 spec contract, Rust idiomatic shape):
//!
//! - [`RuntimeBuilder`] — collects host hooks and the merged config.
//! - [`GuardrailsRuntime`] — Arc-shared, immutable; spawns sessions.
//! - [`GuardrailsSession`] — per-conversation, owns boundary state.
//! - [`RequestContext`] — the §6.3 host-supplied envelope.
//! - [`StreamingOptions`] — defaults applied to streaming guards.
//! - [`RuntimeError`] — error envelope for every fallible op.
//! - [`hooks`] — convenience re-exports of the host-implemented traits.
//! - [`DefaultDelegateDispatcher`] — the wired-by-default
//!   `kind: delegate` dispatcher (HTTP / classifier / fail-closed for
//!   MCP / A2A).
//! - [`FailClosedLlmCaller`] — a sentinel `LlmCaller` that always
//!   blocks; used when the host hasn't registered a real LLM hook.
//!
//! ## Wiring summary
//!
//! ```text
//!     RuntimeBuilder
//!         │
//!         │ build()
//!         ▼
//!     ┌──────────────────────────┐
//!     │ EventBus                 │── ObservabilityDispatcher
//!     │   ├── LifetimeTracker    │── (subscribed for §9.3 events)
//!     │   ├── ResolverDispatcher │
//!     │   └── GuardPolicyEngine  │
//!     └──────────────────────────┘
//!              │  Arc-shared
//!              ▼
//!     GuardrailsRuntime
//!         │ new_session(ctx)
//!         ▼
//!     GuardrailsSession  (one per conversation)
//! ```
//!
//! ## Spec ambiguities
//!
//! - §21 lists "canonical operations" but doesn't pin signatures across
//!   SDKs. We use Rust-idiomatic `&self` plus interior mutability, with
//!   `&mut Value` / `&mut String` for in-place transform stages.
//! - §21's `register_provider` is generic; we expose
//!   [`RuntimeBuilder::register_provider`] as
//!   `ObservabilityProvider` registration (the §6.5
//!   `configurations[].provider` plug-in surface is host-specific and
//!   is not modeled here).
//! - The `tool.<name>.called` / `success` / `failure` cadence requires
//!   host cooperation. The runtime emits `called` at the end of
//!   [`GuardrailsSession::validate_tool_call`]; the host MUST call
//!   [`GuardrailsSession::record_tool_success`] /
//!   [`GuardrailsSession::record_tool_failure`] AFTER actually
//!   executing the tool.

pub mod builder;
pub mod configuration_caller;
pub mod delegate_default;
pub mod errors;
pub mod hooks;
pub mod llm_auto;
pub mod llm_default;
pub mod request_context;
#[allow(clippy::module_inception)]
pub mod runtime;
pub mod session;

pub use builder::{RuntimeBuilder, StreamingOptions};
pub use configuration_caller::{make_configuration_caller, ConfigurationCaller};
pub use delegate_default::DefaultDelegateDispatcher;
pub use errors::RuntimeError;
#[cfg(feature = "http")]
pub use llm_auto::AutoWiredLlmCaller;
pub use llm_default::FailClosedLlmCaller;
pub use request_context::RequestContext;
pub use runtime::GuardrailsRuntime;
pub use session::{GuardrailsSession, InvocationTarget, ToolAdmission};

/// Synthesize a `tool_call_id` for the §16.0 binding cache.
///
/// Adapters wrapping frameworks that do not natively expose a stable
/// per-invocation handle (LangChain `Tool::run`, rig `Tool::call`, …)
/// MUST call this once per invocation and pass the returned id to
/// BOTH the paired Stage 3 [`GuardrailsSession::validate_tool_call`]
/// and the matching Stage 4
/// [`GuardrailsSession::validate_tool_output`]. The id only needs to
/// be unique within the turn; UUIDv4 satisfies that with overwhelming
/// probability.
///
/// Adapters wrapping frameworks that DO expose a stable id (OpenAI
/// `tool_call.id`, Anthropic `tool_use.id`, MCP request id, rig
/// `internal_call_id`) MUST forward that id verbatim instead.
pub fn synthetic_tool_call_id() -> String {
    uuid::Uuid::new_v4().to_string()
}
