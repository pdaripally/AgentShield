//! [`GuardrailsSession`].
//!
//! One session per concurrent agent conversation. The session holds:
//!
//! - A reference to the immutable [`GuardrailsRuntime`].
//! - A per-session [`RequestContext`] (§6.3).
//! - Per-turn / per-request id counters that drive the §9.3 boundary
//!   events (`turn.start`, `turn.end`, `request.start`, `request.end`).
//!
//! Hosts call into the session to perform every spec §21 host-callable
//! operation:
//!
//! - **Variable ops**: `set_variable`, `reset_variable`,
//!   `resolve_variable`, `read_variable`.
//! - **Event ops**: `emit_event`, `clear_event`, `emit_incident`.
//! - **Boundary ops**: `begin_turn`, `end_turn`, `begin_request`,
//!   `end_request`.
//! - **Stage validation**: `validate_input` (§14), `validate_state`,
//!   `validate_tool_call` (§16), `validate_endpoint_call`,
//!   `validate_agent_call`, `validate_tool_output` (§17),
//!   `validate_output` (§18).
//! - **Tool-cycle helpers**: `record_tool_success`,
//!   `record_tool_failure`, plus endpoint / agent variants. Per the
//!   §21 contract the host calls these AFTER actually running the
//!   tool — the runtime is not the executor.
//! - **Streaming**: `streaming_session(stage)` constructs a chunk-aware
//!   guard (§17 / §18).
//!
//! ## Spec ambiguities resolved here
//!
//! - §21 lists `register_provider` generically. We expose it on the
//!   builder as `register_provider` and document that it specifically
//!   registers an `ObservabilityProvider`. The §6.5
//!   `configurations[].provider` plug-in surface is host-specific and
//!   not modeled by this layer.
//! - §21 doesn't pin method signatures. Rust idiom uses
//!   `&self` + interior-mutability so the session can be shared across
//!   threads cheaply (per-turn / request counters use `AtomicU64`).

use std::collections::hash_map::DefaultHasher;
use std::collections::HashMap;
use std::hash::{Hash, Hasher};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;

use serde_json::Value;

use crate::guard_policy_runtime::{
    streaming::{OwnedEvalRuntime, StreamingTrigger},
    EvalRuntime, StageVerdict, StreamingGuard,
};
use crate::lifetime::Lifetime;
use crate::lifetime_tracker::{ResolverOutcome, VarStatus, VariableState};
use crate::observability::Stage;
use crate::populator::{apply_populator, select_populators, Invocation};
use crate::resolver_runtime::ResolverContext;
use crate::session_id::SessionId;
use crate::variables::{Phase, ResourceKind};

use super::errors::RuntimeError;
use super::request_context::RequestContext;
use super::runtime::GuardrailsRuntime;

/// Per-key state of the §16.0 binding cache stored in
/// [`GuardrailsSession::validated_invocations`].
///
/// The slot is populated by Stage 3 (`validate_*_call`) and
/// consumed by Stage 4 (`validate_tool_output`). Two states:
///
/// - [`BindingSlot::Single`] — one in-flight invocation awaiting
///   Stage 4. Removed when Stage 4 pops the slot; the cached
///   invocation drives `invocation_hash` /
///   `post_validation_invocation_hash` on the resulting verdict.
///   The payload is boxed because `Invocation` is large (~232 B) and
///   the `Poisoned` variant carries no data — boxing keeps the
///   `BindingSlot` enum compact and silences clippy's
///   `large_enum_variant` lint.
/// - [`BindingSlot::Poisoned`] — two or more Stage 3 calls collided on
///   the same cache key. Per §16.0, `tool_call_id`s are required to be
///   unique per invocation, so a collision is a host contract
///   violation. When poisoned, every subsequent Stage 4 lookup for this
///   key fails closed with no trusted canonical invocation binding. The
///   poison persists until the entry is explicitly removed or the
///   session is dropped.
#[derive(Debug, Clone)]
enum BindingSlot {
    Single(Box<Invocation>),
    Poisoned,
}

/// Cache key for [`GuardrailsSession::validated_invocations`].
///
/// Components: `(turn_id, resource_kind, resource_name, tool_call_id)`.
/// `resource_kind` is typed as [`ResourceKind`]. `tool_call_id` is the
/// stable per-invocation handle the host MUST provide on every Stage-3 /
/// Stage-4 entry per spec §16.0 — either the model-supplied id (OpenAI
/// `tool_call.id`, Anthropic `tool_use.id`, MCP request id, …) or an
/// adapter-synthesized UUID unique within the turn.
type BindingKey = (u64, ResourceKind, String, String);

/// Map type for the §16.0 binding cache. Extracted as a type alias so
/// the [`GuardrailsSession`] field type stays readable and clippy's
/// `type_complexity` lint stays silent.
type BindingMap = HashMap<BindingKey, BindingSlot>;

const VALIDATED_INVOCATION_SHARDS: usize = 16;

type BindingShards = [std::sync::Mutex<BindingMap>; VALIDATED_INVOCATION_SHARDS];

/// Typed target for Stage 3 invocation validation.
///
/// This is the single Rust-core surface behind the legacy
/// `validate_tool_call` / `validate_endpoint_call` / `validate_agent_call`
/// wrappers. The wrappers remain for SDK ergonomics, while all
/// validation semantics stay unified here.
#[derive(Debug, Clone, Copy)]
pub enum InvocationTarget<'a> {
    Tool { name: &'a str },
    Endpoint { method: &'a str, uri: &'a str },
    Agent { name: &'a str },
}

impl<'a> InvocationTarget<'a> {
    fn kind(self) -> ResourceKind {
        match self {
            Self::Tool { .. } => ResourceKind::Tool,
            Self::Endpoint { .. } => ResourceKind::Endpoint,
            Self::Agent { .. } => ResourceKind::Agent,
        }
    }

    fn resource_name(self) -> &'a str {
        match self {
            Self::Tool { name } | Self::Agent { name } => name,
            Self::Endpoint { uri, .. } => uri,
        }
    }

    fn kind_str(self) -> &'static str {
        match self {
            Self::Tool { .. } => "tool",
            Self::Endpoint { .. } => "endpoint",
            Self::Agent { .. } => "agent",
        }
    }

    fn invocation(self, params: Value) -> Invocation {
        match self {
            Self::Tool { name } => Invocation::tool(name, params),
            Self::Endpoint { method, uri } => Invocation::endpoint(method, uri, params),
            Self::Agent { name } => Invocation::agent(name, params),
        }
    }
}

/// RAII handle for a Stage-3-admitted tool invocation.
///
/// If an adapter validates a tool call and then decides not to execute it
/// (for example because the host framework cannot propagate Stage-3
/// mutations), dropping this handle removes the pending §16.0 binding.
/// Call [`Self::commit_to_stage4`] once the adapter has handed execution
/// to the host and expects a later `validate_tool_output` call to consume
/// the binding.
pub struct ToolAdmission<'a> {
    session: &'a GuardrailsSession,
    turn_id: u64,
    tool: String,
    tool_call_id: String,
    verdict: StageVerdict,
    cleanup_on_drop: bool,
}

impl<'a> ToolAdmission<'a> {
    pub fn verdict(&self) -> &StageVerdict {
        &self.verdict
    }

    pub fn commit_to_stage4(mut self) -> StageVerdict {
        self.cleanup_on_drop = false;
        self.verdict.clone()
    }

    pub fn abandon(mut self) -> StageVerdict {
        if self.cleanup_on_drop {
            self.session.drop_validated_invocation(
                self.turn_id,
                ResourceKind::Tool,
                &self.tool,
                &self.tool_call_id,
            );
            self.cleanup_on_drop = false;
        }
        self.verdict.clone()
    }
}

impl Drop for ToolAdmission<'_> {
    fn drop(&mut self) {
        if self.cleanup_on_drop {
            self.session.drop_validated_invocation(
                self.turn_id,
                ResourceKind::Tool,
                &self.tool,
                &self.tool_call_id,
            );
        }
    }
}

/// One per-conversation session — see module docs.
pub struct GuardrailsSession {
    runtime: Arc<GuardrailsRuntime>,
    request_context: RequestContext,
    /// Cached cheap-clone session id derived from
    /// [`RequestContext::session_id`] at construction. Threaded into
    /// every tracker / bus / activation-cache call so per-session state
    /// stays isolated (spec §9 / §10).
    session_id: SessionId,
    /// Monotonically increasing counter incremented on every
    /// successful [`Self::begin_turn`].
    turn_id: AtomicU64,
    /// Monotonically increasing counter incremented on every
    /// successful [`Self::begin_request`].
    request_id: AtomicU64,
    /// `true` between [`Self::begin_turn`] and [`Self::end_turn`].
    /// Used so duplicate `end_turn` calls don't double-clear.
    turn_active: std::sync::atomic::AtomicBool,
    /// `true` between [`Self::begin_request`] and [`Self::end_request`].
    request_active: std::sync::atomic::AtomicBool,
    /// `true` after [`Self::close`] runs once. Idempotent so `Drop` and
    /// explicit `close` don't double-emit `session.end` / re-clean
    /// session state.
    closed: std::sync::atomic::AtomicBool,
    /// User input cached by `validate_input` so subsequent stages bind
    /// it as `{user_input}` per §12.9.2 without forcing the host to
    /// re-pass.
    cached_user_input: std::sync::Mutex<String>,
    /// Per-turn buffer of `(tool_name, sanitized_result_text)` captured
    /// AFTER `validate_tool_output` runs Stage-4 mutations. Stage-3
    /// LLM-detection prompts append these as `## START TOOL RESPONSE: ##`
    /// boundary markers per §16.1 so the validator LLM can distinguish
    /// trusted user input from untrusted tool-returned data.
    /// Cleared on `begin_turn`. FIFO-bounded by
    /// [`crate::constants::stage_tool_exec::MAX_RETAINED_RESULTS`].
    tool_results_this_turn: std::sync::Mutex<Vec<(String, String)>>,
    /// Per-session §16.0 binding cache. Keyed by `(turn_id,
    /// resource_kind, name, tool_call_id)` and consumed by Stage 4 so the
    /// post-validation invocation hashes the SAME canonical
    /// invocation Stage 3 admitted (spec §16.0 "post-validation
    /// invocation MUST be executed").
    ///
    /// **Slot values:**
    /// - [`BindingSlot::Single`] — one in-flight Stage 3 invocation
    ///   awaiting Stage 4. Removed on the matching Stage 4 lookup.
    /// - [`BindingSlot::Poisoned`] — two or more Stage 3 inserts
    ///   collided on the same `(turn_id, kind, name, id)` key. Indicates a host
    ///   bug (re-using a `tool_call_id`); subsequent Stage 4 lookups
    ///   for this slot fail closed deterministically. The poison
    ///   persists until the entry is explicitly removed or the session
    ///   is dropped.
    ///
    /// **Parallel/repeated same-name calls (§16.0):** with `tool_call_id`
    /// required at every Stage 3 / Stage 4 entry (model-supplied or
    /// adapter-synthesized), cache keys collide only when a host
    /// re-uses an id — a contract violation. The implementation still
    /// detects this and routes both outputs to a fail-closed verdict
    /// rather than silently binding the first output to the second
    /// invocation.
    validated_invocations: BindingShards,
    /// IFC running exposure `Eₙ`. Joined with `λ(source)` on every
    /// recorded read; checked against `μ(sink)` at every gated egress.
    /// Reset on the boundary chosen by `ifc.scope`:
    ///
    /// - `per_session`: cleared on session disposal.
    /// - `per_turn`: cleared on `end_turn`.
    /// - `per_request`: cleared on `end_request`.
    ///
    /// When the merged config has no `ifc:` block, the exposure stays
    /// at `⊥` of the trivial 1-element lattice and every check passes.
    exposure: std::sync::Mutex<crate::ifc::TagSet>,
}

impl std::fmt::Debug for GuardrailsSession {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("GuardrailsSession")
            .field("session_id", &self.request_context.session_id)
            .field("correlation_id", &self.request_context.correlation_id)
            .field("turn_id", &self.turn_id.load(Ordering::Relaxed))
            .field("request_id", &self.request_id.load(Ordering::Relaxed))
            .field("turn_active", &self.turn_active.load(Ordering::Relaxed))
            .field(
                "request_active",
                &self.request_active.load(Ordering::Relaxed),
            )
            .finish_non_exhaustive()
    }
}

impl GuardrailsSession {
    pub(crate) fn new(runtime: Arc<GuardrailsRuntime>, ctx: RequestContext) -> Self {
        let session_id = SessionId::new(ctx.session_id.clone());
        let _ = runtime.bus().emit_session_start_in(&session_id);
        let initial_exposure = crate::ifc::TagSet::EMPTY;
        Self {
            runtime,
            request_context: ctx,
            session_id,
            turn_id: AtomicU64::new(0),
            request_id: AtomicU64::new(0),
            turn_active: std::sync::atomic::AtomicBool::new(false),
            request_active: std::sync::atomic::AtomicBool::new(false),
            closed: std::sync::atomic::AtomicBool::new(false),
            cached_user_input: std::sync::Mutex::new(String::new()),
            tool_results_this_turn: std::sync::Mutex::new(Vec::new()),
            validated_invocations: std::array::from_fn(|_| std::sync::Mutex::new(HashMap::new())),
            exposure: std::sync::Mutex::new(initial_exposure),
        }
    }

    /// Borrow the request context (§6.3).
    pub fn request_context(&self) -> &RequestContext {
        &self.request_context
    }

    fn binding_key(
        turn_id: u64,
        kind: ResourceKind,
        name: &str,
        invocation_handle: &str,
    ) -> BindingKey {
        (
            turn_id,
            kind,
            name.to_string(),
            invocation_handle.to_string(),
        )
    }

    fn binding_shard(&self, key: &BindingKey) -> &std::sync::Mutex<BindingMap> {
        let mut hasher = DefaultHasher::new();
        key.hash(&mut hasher);
        let idx = (hasher.finish() as usize) % VALIDATED_INVOCATION_SHARDS;
        &self.validated_invocations[idx]
    }

    /// The cheap-clone session id this session uses to scope tracker /
    /// bus / activation-cache state.
    pub fn session_id(&self) -> &SessionId {
        &self.session_id
    }

    /// Borrow the parent runtime.
    pub fn runtime(&self) -> &Arc<GuardrailsRuntime> {
        &self.runtime
    }

    /// Latest turn id (or `0` before the first `begin_turn`).
    pub fn current_turn_id(&self) -> u64 {
        self.turn_id.load(Ordering::Relaxed)
    }

    /// Latest request id (or `0` before the first `begin_request`).
    pub fn current_request_id(&self) -> u64 {
        self.request_id.load(Ordering::Relaxed)
    }

    /// `true` between [`Self::begin_turn`] and [`Self::end_turn`].
    pub fn is_turn_active(&self) -> bool {
        self.turn_active.load(Ordering::Relaxed)
    }

    /// `true` between [`Self::begin_request`] and [`Self::end_request`].
    pub fn is_request_active(&self) -> bool {
        self.request_active.load(Ordering::Relaxed)
    }

    // ── Variable ops (§21 / §9) ─────────────────────────────────────

    /// Apply a value to a declared variable, subject to its
    /// `update:` expression (§10 / §21). Transitions `@status` to
    /// `resolved`. Returns [`RuntimeError::UnknownVariable`] for
    /// names not in the merged config. Non-keyed accessor — use
    /// [`Self::set_variable_keyed`] for keyed variables (§9.4).
    pub fn set_variable(&self, name: &str, value: Value) -> Result<(), RuntimeError> {
        self.set_variable_keyed(name, None, value)
    }

    /// §21 / §9.4: write a keyed variable. The `key` argument is
    /// applied verbatim — the host is responsible for supplying it,
    /// matching the `key:` expression authors declared. A `None` key
    /// targets the non-keyed slot (and matches what `set_variable`
    /// delegates to). A `Some(Value::Null)` key is rejected with a
    /// structured warning.
    pub fn set_variable_keyed(
        &self,
        name: &str,
        key: Option<&Value>,
        value: Value,
    ) -> Result<(), RuntimeError> {
        if !self.runtime.variables.contains_key(name) {
            return Err(RuntimeError::UnknownVariable(name.into()));
        }
        self.runtime
            .tracker
            .set_variable_keyed_in(
                &self.session_id,
                name,
                key,
                value,
                Some("host_api"),
                Some("runtime_api"),
                ResolverOutcome::Allow,
            )
            .map_err(RuntimeError::from)
    }

    /// Clear a declared variable to `@status == 'unset'` (§21 / §10).
    /// Non-keyed accessor — use [`Self::reset_variable_keyed`] for
    /// keyed variables.
    pub fn reset_variable(&self, name: &str) -> Result<(), RuntimeError> {
        self.reset_variable_keyed(name, None)
    }

    /// §21 / §9.4: clear one keyed slot of a declared variable.
    pub fn reset_variable_keyed(
        &self,
        name: &str,
        key: Option<&Value>,
    ) -> Result<(), RuntimeError> {
        if !self.runtime.variables.contains_key(name) {
            return Err(RuntimeError::UnknownVariable(name.into()));
        }
        self.runtime
            .tracker
            .invalidate_variable_keyed_in(&self.session_id, name, key);
        Ok(())
    }

    /// Synchronously invoke the variable's declared resolver and apply
    /// the returned envelope (§21 / §11). Returns:
    ///
    /// - `Ok(Some(value))` — variable is already resolved (returns the
    ///   cached value), or the on-demand resolver returned `Allow`.
    /// - `Ok(None)` — resolver returned `Deny` / `Cancelled`, or no
    ///   `on_demand_by:` is declared and the variable is unset.
    /// - `Err(UnknownVariable)` — name not in the merged config.
    pub fn resolve_variable(&self, name: &str) -> Result<Option<Value>, RuntimeError> {
        if !self.runtime.variables.contains_key(name) {
            return Err(RuntimeError::UnknownVariable(name.into()));
        }

        // If the variable is already in the `resolved` state — set via
        // `set_variable`, populated by a tool/agent/endpoint cycle, or a
        // prior `resolve_variable` — return the cached value without
        // re-invoking the on-demand resolver. This matches the
        // ergonomic contract callers expect: "give me the current
        // value, resolving on demand only when not yet known."
        let cached = self
            .runtime
            .tracker
            .read_variable_in(&self.session_id, name);
        if matches!(cached.status, VarStatus::Resolved) {
            return Ok(Some(cached.value));
        }

        let attrs = self.build_attrs();
        let mut ctx = ResolverContext::new()
            .with_attrs(attrs)
            .with_request_context(self.request_context.to_map())
            .with_session_id(self.session_id.clone());
        ctx.request_id = Some(format!(
            "{}-{}",
            self.request_context.correlation_id,
            self.current_turn_id()
        ));
        Ok(self.runtime.resolver.auto_resolve(name, &ctx))
    }

    /// Read the current cached state of a variable. `None` when the
    /// variable is not declared.
    pub fn read_variable(&self, name: &str) -> Option<VariableState> {
        if !self.runtime.variables.contains_key(name) {
            return None;
        }
        Some(
            self.runtime
                .tracker
                .read_variable_in(&self.session_id, name),
        )
    }

    // ── Event ops (§21 / §10) ───────────────────────────────────────

    /// Emit a host-driven event from the closed namespace (§9.3). The
    /// runtime parses `event_id` against the §9.3 grammar and rejects
    /// unrecognized ids with [`RuntimeError::InvalidEventId`].
    ///
    /// Approval events (`approval.<variable>.<outcome>`) auto-flip the
    /// bound variable's `@status` per §10.5 — that's wired via the
    /// tracker's bus subscriber, so it Just Works.
    pub fn emit_event(
        &self,
        event_id: &str,
        lifetime: Option<Lifetime>,
        payload: Option<Value>,
    ) -> Result<(), RuntimeError> {
        let id = crate::events::EventId::parse(event_id)
            .map_err(|_| RuntimeError::InvalidEventId(event_id.into()))?;
        self.runtime
            .bus
            .emit_in(&self.session_id, id, lifetime, payload)
            .map_err(RuntimeError::from)
    }

    /// Clear a previously-latched event so `event.fired(<id>)` returns
    /// `false` again (§10 / §21).
    pub fn clear_event(&self, event_id: &str) -> Result<(), RuntimeError> {
        let id = crate::events::EventId::parse(event_id)
            .map_err(|_| RuntimeError::InvalidEventId(event_id.into()))?;
        let _ = self.runtime.bus.clear_event_in(&self.session_id, &id);
        Ok(())
    }

    /// Convenience: emit an `incident.<name>` event (§9.3).
    pub fn emit_incident(&self, name: &str, payload: Option<Value>) -> Result<(), RuntimeError> {
        let full = format!("incident.{}", name);
        self.runtime
            .bus
            .emit_incident_in(&self.session_id, &full, None, payload)
            .map_err(RuntimeError::from)
    }

    /// Session-scoped query: has `event_id` been latched in **this** session?
    /// Use this instead of `runtime.bus().fired_id(...)` when checking
    /// from inside a multi-session test or runtime path — the
    /// runtime-level query aggregates across sessions.
    pub fn event_fired(&self, event_id: &str) -> bool {
        match crate::events::EventId::parse(event_id) {
            Ok(id) => self.runtime.bus.fired_id_in(&self.session_id, &id),
            Err(_) => false,
        }
    }

    /// Session-scoped variant taking a typed [`crate::events::EventId`].
    pub fn event_fired_id(&self, event_id: &crate::events::EventId) -> bool {
        self.runtime.bus.fired_id_in(&self.session_id, event_id)
    }

    // ── Boundary ops (§21 / §10) ────────────────────────────────────

    /// Begin a new turn. Emits `turn.start`, advances the per-turn
    /// counter, and clears any state lifetime'd to `per_turn` (§9.1.1).
    /// Returns the new turn id.
    ///
    /// `note_turn_start` on the resolver dispatcher is wired
    /// automatically via the bus subscription set up at build time, so
    /// the per-(turn, variable, tool) retry counter (§11.10.2) advances
    /// in lockstep.
    pub fn begin_turn(&self) -> Result<u64, RuntimeError> {
        // Emit BEFORE mutating any state. If this fails, the turn never
        // started — no rollback needed because nothing has changed.
        self.runtime
            .bus
            .emit_turn_start_in(&self.session_id)
            .map_err(RuntimeError::from)?;
        let new_id = self.turn_id.fetch_add(1, Ordering::Relaxed) + 1;
        self.turn_active.store(true, Ordering::Relaxed);
        // §16.1 — the per-turn `tool_results_this_turn` buffer feeds
        // Stage-3 `{user_input}` enrichment with prior tool-result
        // boundary markers. Reset at the turn boundary so a fresh turn
        // starts with no inherited tool-output history.
        if let Ok(mut g) = self.tool_results_this_turn.lock() {
            g.clear();
        }
        // Do not clear `validated_invocations` here. Its key includes
        // `turn_id`, so cross-turn aliasing is impossible, and adapters
        // that receive tool outputs after another prompt opened a new
        // turn can still validate against the original turn.
        Ok(new_id)
    }

    /// End the current turn. Clears any state lifetime'd to `per_turn`
    /// FIRST — both the tracker and the bus's latched per-turn events —
    /// and only then emits `turn.end`. Subscribers receiving `turn.end`
    /// see the post-clear state, which matches the §9.1.1 contract that
    /// `per_turn` lifetime ends *at* the turn boundary, not after it.
    /// Idempotent: calling without a matching `begin_turn` is a no-op
    /// (logs at debug).
    pub fn end_turn(&self) -> Result<(), RuntimeError> {
        if !self.turn_active.swap(false, Ordering::Relaxed) {
            log::debug!(
                target: "agent_shield::runtime",
                "end_turn called without matching begin_turn — no-op"
            );
            return Ok(());
        }
        // Clear tracker AND bus state BEFORE emitting `turn.end` so that
        // subscribers see fresh state.
        self.runtime.tracker.clear_per_turn_in(&self.session_id);
        self.runtime.bus.clear_per_turn_in(&self.session_id);
        if matches!(
            self.runtime.config().ifc.scope,
            crate::ifc::ScopePolicy::PerTurn
        ) {
            self.reset_exposure();
        }
        self.runtime
            .bus
            .emit_turn_end_in(&self.session_id)
            .map_err(RuntimeError::from)?;
        Ok(())
    }

    /// Drop a single §16.0 binding cache entry without consuming it
    /// through Stage 4. Used by adapters that admit a Stage-3
    /// invocation but then decide (after Stage 3 returns) not to
    /// execute the tool — e.g. the Rig hook path returning `Skip`
    /// after a Stage 3 redact/replace mutation that it cannot
    /// propagate to the underlying tool. Without this, the binding
    /// slot would remain occupied until session disposal, holding
    /// memory and (more importantly) colliding with a subsequent Stage 3
    /// call in the same turn that re-uses the same `tool_call_id`.
    ///
    /// `kind` MUST match the kind used at insert time (currently
    /// only [`ResourceKind::Tool`] writes to this cache). No-op if the
    /// entry is already absent. If the entry is a `BindingSlot::Poisoned`
    /// sentinel (Stage 3 collision), it is also removed.
    fn drop_validated_invocation(
        &self,
        turn_id: u64,
        kind: ResourceKind,
        name: &str,
        tool_call_id: &str,
    ) {
        let key = Self::binding_key(turn_id, kind, name, tool_call_id);
        if let Ok(mut g) = self.binding_shard(&key).lock() {
            g.remove(&key);
        }
    }

    /// Begin a new request scope. Emits `request.start` first; only on a
    /// successful emit does the per-session counter advance and the
    /// `request_active` flag flip. Same rationale as [`Self::begin_turn`].
    pub fn begin_request(&self) -> Result<u64, RuntimeError> {
        self.runtime
            .bus
            .emit_request_start_in(&self.session_id)
            .map_err(RuntimeError::from)?;
        let new_id = self.request_id.fetch_add(1, Ordering::Relaxed) + 1;
        self.request_active.store(true, Ordering::Relaxed);
        Ok(new_id)
    }

    /// End the current request scope. Clears any state lifetime'd to
    /// `per_request` FIRST (both tracker and bus latches), then emits
    /// `request.end`.
    pub fn end_request(&self) -> Result<(), RuntimeError> {
        if !self.request_active.swap(false, Ordering::Relaxed) {
            log::debug!(
                target: "agent_shield::runtime",
                "end_request called without matching begin_request — no-op"
            );
            return Ok(());
        }
        self.runtime.tracker.clear_per_request_in(&self.session_id);
        self.runtime.bus.clear_per_request_in(&self.session_id);
        if matches!(
            self.runtime.config().ifc.scope,
            crate::ifc::ScopePolicy::PerRequest
        ) {
            self.reset_exposure();
        }
        self.runtime
            .bus
            .emit_request_end_in(&self.session_id)
            .map_err(RuntimeError::from)?;
        Ok(())
    }

    // ── IFC running exposure (§lattice IFC) ─────────────────────────

    /// Read the current running exposure `Eₙ`. When the merged config
    /// has no `ifc:` block, this is always `⊥` (empty tag set) of the
    /// disabled / empty universe.
    pub fn current_exposure(&self) -> crate::ifc::TagSet {
        self.exposure
            .lock()
            .map(|g| *g)
            .unwrap_or_else(|p| *p.into_inner())
    }

    /// Union `tags` into the running exposure. No-op when the
    /// resulting set has the same membership — keeps the mutex
    /// uncontested in the common ⊥-only case.
    pub(crate) fn raise_exposure(&self, tags: crate::ifc::TagSet) {
        let mut g = match self.exposure.lock() {
            Ok(g) => g,
            Err(p) => p.into_inner(),
        };
        let prev = *g;
        let joined = g.union(tags);
        if joined != prev {
            *g = joined;
            drop(g);
            // Audit event: emit ifc.exposure_raised with from/to
            // tag-name lists for correlation with downstream gates.
            let universe = &self.runtime.config().ifc.universe;
            let _ = self.runtime.bus.emit_in(
                &self.session_id,
                crate::events::EventId::Ifc {
                    kind: crate::events::IfcEventKind::ExposureRaised,
                },
                None,
                Some(serde_json::json!({
                    "from": universe.names_of(prev),
                    "to": universe.names_of(joined),
                    "joined": universe.names_of(tags),
                })),
            );
        }
    }

    /// `Eₙ ⊆ μ` — admit-test for an egress.
    pub(crate) fn flows_to_clearance(&self, clearance: crate::ifc::TagSet) -> bool {
        let g = match self.exposure.lock() {
            Ok(g) => g,
            Err(p) => p.into_inner(),
        };
        g.is_subset(clearance)
    }

    /// Declassify `Eₙ` to `target`. Caller is responsible for
    /// enforcing `target ⊆ Eₙ` (declassification can only relax,
    /// never tighten — proof TC-5 pre-condition). Used at trusted
    /// boundaries; the host is also responsible for the
    /// context-replacement discipline (proof TC-5 axiom).
    pub fn declassify_to(&self, target: crate::ifc::TagSet) {
        let mut g = match self.exposure.lock() {
            Ok(g) => g,
            Err(p) => p.into_inner(),
        };
        let prev = *g;
        *g = target;
        drop(g);
        // Audit event: ifc.declassified — proof TC-5 audit boundary.
        let universe = &self.runtime.config().ifc.universe;
        let _ = self.runtime.bus.emit_in(
            &self.session_id,
            crate::events::EventId::Ifc {
                kind: crate::events::IfcEventKind::Declassified,
            },
            None,
            Some(serde_json::json!({
                "from": universe.names_of(prev),
                "to": universe.names_of(target),
            })),
        );
    }

    /// Reset the running exposure to `⊥` (empty tag set). Called on
    /// the boundary chosen by `ifc.scope`.
    fn reset_exposure(&self) {
        let mut g = match self.exposure.lock() {
            Ok(g) => g,
            Err(p) => p.into_inner(),
        };
        let prev = *g;
        *g = crate::ifc::TagSet::EMPTY;
        drop(g);
        if !prev.is_empty() {
            let universe = &self.runtime.config().ifc.universe;
            let _ = self.runtime.bus.emit_in(
                &self.session_id,
                crate::events::EventId::Ifc {
                    kind: crate::events::IfcEventKind::ExposureCleared,
                },
                None,
                Some(serde_json::json!({
                    "from": universe.names_of(prev),
                })),
            );
        }
    }

    /// Build a Stage-3 / Stage-5 deny verdict for an IFC violation.
    /// `target_kind` is `"tool"` / `"endpoint"` / `"agent"` /
    /// `"output"` — the surface that the egress targeted. The
    /// reason text follows the `<exposure> ⋢ <clearance>` shape so
    /// log readers can spot IFC denials without parsing structured
    /// fields. Also emits the `ifc.egress_denied` audit event.
    fn ifc_denied_verdict(
        &self,
        target_kind: &str,
        target_name: &str,
        clearance: crate::ifc::TagSet,
    ) -> StageVerdict {
        let exposure = self.current_exposure();
        let universe = &self.runtime.config().ifc.universe;
        let reason = format!(
            "ifc: exposure {:?} does not flow to {} `{}` clearance {:?}",
            universe.names_of(exposure),
            target_kind,
            target_name,
            universe.names_of(clearance),
        );
        let _ = self.runtime.bus.emit_in(
            &self.session_id,
            crate::events::EventId::Ifc {
                kind: crate::events::IfcEventKind::EgressDenied,
            },
            None,
            Some(serde_json::json!({
                "exposure": universe.names_of(exposure),
                "target_kind": target_kind,
                "target_name": target_name,
                "clearance": universe.names_of(clearance),
            })),
        );
        StageVerdict::block("<ifc>", reason, None)
    }

    // ── Stage validation entry points (§14–§18) ─────────────────────

    /// Stage 1 — input validation (§14). Pure-content stage: no
    /// invocation, no `applies_to`. Caches `input` for downstream
    /// `{user_input}` template binding.
    pub fn validate_input(&self, input: &str) -> StageVerdict {
        // Cache the input for later stages.
        if let Ok(mut g) = self.cached_user_input.lock() {
            *g = input.to_string();
        }
        // Stage 1 is per-call (the call here being the user turn) but
        // §9.1.1's `per_call` lifetime is scoped to the gating call —
        // we don't clear here because Stage 1 is the FIRST gate of the
        // turn, so no per_call state can exist yet. It clears at end
        // of the call cycle implicitly.
        let request_context = self.request_context.to_value();
        let user_input = self.cached_user_input_clone();
        let objective = self.objective_text();
        let forbidden = self.forbidden_list();
        let ctx = EvalRuntime {
            session_id: &self.request_context.session_id,
            correlation_id: &self.request_context.correlation_id,
            user_id: self.request_context.user_id.as_deref(),
            tenant_id: self.request_context.tenant_id.as_deref(),
            request_context,
            turn_id: self.current_turn_id(),
            objective: &objective,
            forbidden: &forbidden,
            user_input: &user_input,
            active_guard_policies: "",
            variables_snapshot: "",
            prior_checks_summary: "",
        };
        let verdict = self.runtime.engine.evaluate_input(input, &ctx);
        // IFC: on admit, raise the running exposure with `λ(user_input)`.
        // Trivial-lattice (no `ifc:` block) is an O(1) no-op.
        if verdict.allowed {
            let tags = self.runtime.config().ifc.user_input_tags;
            self.raise_exposure(tags);
        }
        verdict
    }

    /// Stage 2 — state validation (§15). Operates on the same
    /// invocation as Stage 3 will, but evaluates pre-execution gates
    /// (`active_if`, `evaluate_when[]` against state expressions).
    /// `per_call` state is cleared at the start of this stage because
    /// Stage 2 is the entry point to a gating call (§9.1.1).
    pub fn validate_state(&self, invocation: &Invocation) -> StageVerdict {
        self.runtime.tracker.clear_per_call_in(&self.session_id);
        let request_context = self.request_context.to_value();
        let user_input = self.cached_user_input_clone();
        let objective = self.objective_text();
        let forbidden = self.forbidden_list();
        let ctx = EvalRuntime {
            session_id: &self.request_context.session_id,
            correlation_id: &self.request_context.correlation_id,
            user_id: self.request_context.user_id.as_deref(),
            tenant_id: self.request_context.tenant_id.as_deref(),
            request_context,
            turn_id: self.current_turn_id(),
            objective: &objective,
            forbidden: &forbidden,
            user_input: &user_input,
            active_guard_policies: "",
            variables_snapshot: "",
            prior_checks_summary: "",
        };
        let verdict = self.runtime.engine.evaluate_state(invocation, &ctx);
        // IFC declassification: if a `declassify_to` action fired and
        // the gate admitted, lower the running exposure. Enforce the
        // structural pre-condition `target ⊆ E` (proof TC-5);
        // reject as a load-time-style error if the author tried to
        // declassify *up*. Composition correctness and host context
        // replacement are TCB axioms (proof §3.5).
        if verdict.allowed {
            if let Some(target) = verdict.declassify_to {
                if target.is_subset(self.current_exposure()) {
                    self.declassify_to(target);
                } else {
                    log::warn!(
                        target: "agent_shield::ifc",
                        "declassify_to target {:?} ⊄ current exposure {:?}; skipped (proof TC-5 pre-condition)",
                        self.runtime.config().ifc.universe.names_of(target),
                        self.runtime.config().ifc.universe.names_of(self.current_exposure()),
                    );
                }
            }
        }
        verdict
    }

    /// Stage 3 — unified invocation validation (§16). Constructs a
    /// typed invocation, runs Stage 2 + Stage 3 gates in order, applies
    /// any parameter transforms via the engine, and emits the matching
    /// `<kind>.<name>.called` event immediately before returning the
    /// allow verdict.
    ///
    /// `invocation_handle` is REQUIRED per spec §16.0 on every validate
    /// function. Only `kind: tool` currently writes a Stage-4 binding
    /// because the spec defines post-call validation only for tools.
    pub fn validate_invocation_call(
        &self,
        target: InvocationTarget<'_>,
        params: &mut Value,
        invocation_handle: &str,
    ) -> StageVerdict {
        let mut invocation = target.invocation(params.clone());

        // Run pre-call populators (§10.5.1 phase: before).
        self.run_populators(&invocation, None, Phase::Before);

        // Stage 2 first (§15) — state gating.
        let state_verdict = self.validate_state(&invocation);
        if !state_verdict.allowed {
            return state_verdict;
        }

        // IFC: `Eₙ ⊆ μ(resource)` admit-test before Stage 3 work.
        let clearance = match target {
            InvocationTarget::Tool { name } => self.runtime.config().ifc_clearance_for_tool(name),
            InvocationTarget::Endpoint { uri, .. } => {
                self.runtime.config().ifc_clearance_for_endpoint(uri)
            }
            InvocationTarget::Agent { name } => self.runtime.config().ifc_clearance_for_agent(name),
        };
        if !self.flows_to_clearance(clearance) {
            return self.ifc_denied_verdict(target.kind_str(), target.resource_name(), clearance);
        }

        // Stage 3 (§16) — adversarial / parameter transforms. Build the
        // §16.1 enrichment context once and pass to the engine.
        let stage3 = self.build_stage3_context(&invocation);
        let verdict = self
            .runtime
            .engine
            .evaluate_tool_execution(&mut invocation, &stage3.runtime());

        if verdict.allowed {
            // Stage 3 may have rewritten the params via redact /
            // append / prepend. Surface back to the host.
            *params = invocation.params.clone();

            match target {
                InvocationTarget::Tool { name } => {
                    // Cache the post-Stage-3 invocation so Stage 4
                    // (`validate_tool_output`) hashes the SAME canonical
                    // invocation that Stage 3 admitted (spec §16.0).
                    let key = Self::binding_key(
                        self.current_turn_id(),
                        target.kind(),
                        name,
                        invocation_handle,
                    );
                    if let Ok(mut g) = self.binding_shard(&key).lock() {
                        // §16.0 — poison-on-collision. Two Stage 3 calls
                        // landing on the SAME `(kind, name, id)` key indicate
                        // a host bug (re-using a `tool_call_id`); both Stage 4
                        // calls MUST fail closed rather than silently bind one
                        // output to the other invocation's params.
                        match g.entry(key) {
                            std::collections::hash_map::Entry::Vacant(v) => {
                                v.insert(BindingSlot::Single(Box::new(invocation.clone())));
                            }
                            std::collections::hash_map::Entry::Occupied(mut o) => {
                                log::warn!(
                                    target: "agent_shield::runtime::session",
                                    "validate_invocation_call: §16.0 binding cache collision for tool `{}` (tool_call_id `{}`). Poisoning the slot — both Stage 4 outputs will fail closed. The host re-used a tool_call_id within one turn.",
                                    name,
                                    invocation_handle,
                                );
                                o.insert(BindingSlot::Poisoned);
                            }
                        }
                    }
                    let _ = self.runtime.bus.emit_tool_called_in(&self.session_id, name);
                }
                InvocationTarget::Endpoint { uri, .. } => {
                    let _ = self
                        .runtime
                        .bus
                        .emit_endpoint_called_in(&self.session_id, uri);
                }
                InvocationTarget::Agent { name } => {
                    let _ = self
                        .runtime
                        .bus
                        .emit_agent_called_in(&self.session_id, name);
                }
            }
        }
        verdict
    }

    /// Stage 3 — tool execution validation (§16). `tool_call_id` is
    /// REQUIRED per spec §16.0 and must match the paired
    /// [`Self::validate_tool_output`] call.
    pub fn validate_tool_call(
        &self,
        tool: &str,
        params: &mut Value,
        tool_call_id: &str,
    ) -> StageVerdict {
        self.validate_invocation_call(InvocationTarget::Tool { name: tool }, params, tool_call_id)
    }

    /// Stage 3 — tool execution validation with RAII cleanup. If the
    /// returned admission is dropped without [`ToolAdmission::commit_to_stage4`],
    /// any pending §16.0 binding is removed.
    pub fn validate_tool_admission(
        &self,
        tool: &str,
        params: &mut Value,
        tool_call_id: &str,
    ) -> ToolAdmission<'_> {
        let verdict = self.validate_tool_call(tool, params, tool_call_id);
        ToolAdmission {
            session: self,
            turn_id: self.current_turn_id(),
            tool: tool.to_string(),
            tool_call_id: tool_call_id.to_string(),
            cleanup_on_drop: verdict.allowed,
            verdict,
        }
    }

    /// Stage 3 — endpoint variant. `tool_call_id` is REQUIRED for API
    /// symmetry across the three kinds, but only `tool` currently has a
    /// Stage 4 consumer.
    pub fn validate_endpoint_call(
        &self,
        method: &str,
        uri: &str,
        body: &mut Value,
        tool_call_id: &str,
    ) -> StageVerdict {
        self.validate_invocation_call(
            InvocationTarget::Endpoint { method, uri },
            body,
            tool_call_id,
        )
    }

    /// Stage 3 — agent variant. `tool_call_id` is REQUIRED for API
    /// symmetry across the three kinds, but only `tool` currently has a
    /// Stage 4 consumer.
    pub fn validate_agent_call(
        &self,
        agent: &str,
        params: &mut Value,
        tool_call_id: &str,
    ) -> StageVerdict {
        self.validate_invocation_call(
            InvocationTarget::Agent { name: agent },
            params,
            tool_call_id,
        )
    }

    /// Stage 4 — post-tool validation (§17). The host calls this after
    /// running the tool; `result` is the raw tool output. The runner
    /// runs `phase: after` populators, then evaluates Stage 4 gates.
    /// `result` may be redacted in place by a `redact:` action.
    ///
    /// `tool_call_id` is REQUIRED and MUST match the id passed to the
    /// paired [`Self::validate_tool_call`] in this turn. A missing or
    /// non-matching id fails closed per spec §16.0 — there is no
    /// synthetic-fallback path. AFTER Stage-4 mutations apply, the
    /// (now-sanitized) result text is captured into the per-turn
    /// buffer that feeds §16.1 `{user_input}` enrichment for
    /// subsequent Stage-3 prompts in the same turn. We store the
    /// post-redaction view (not the raw input) so the validator never
    /// sees data Stage 4 just stripped.
    pub fn validate_tool_output(
        &self,
        tool: &str,
        result: &mut Value,
        tool_call_id: &str,
    ) -> StageVerdict {
        self.validate_tool_output_for_turn(tool, result, tool_call_id, self.current_turn_id())
    }

    /// Stage 4 against an explicit turn id. Adapters that receive tool
    /// outputs after another prompt has opened a new turn can pass the
    /// turn id captured at Stage 3 so the §16.0 binding remains exact.
    pub fn validate_tool_output_for_turn(
        &self,
        tool: &str,
        result: &mut Value,
        tool_call_id: &str,
        turn_id: u64,
    ) -> StageVerdict {
        // §16.0 — Stage 4 MUST bind the same canonical invocation that
        // Stage 3 admitted. Pop the cached post-Stage-3 invocation
        // under the matching `(turn_id, kind, name, tool_call_id)` key.
        //
        // Slot states:
        // - `Some(BindingSlot::Single(inv))` — single in-flight call;
        //   remove and bind to `inv`.
        // - `Some(BindingSlot::Poisoned)` — Stage 3 detected a host bug
        //   (`tool_call_id` re-use); **do not consume the slot** so
        //   both Stage 4 calls fail closed deterministically.
        // - `None` — no Stage 3 ever ran for this key. Fail closed.
        let key = Self::binding_key(turn_id, ResourceKind::Tool, tool, tool_call_id);
        let cached = match self.binding_shard(&key).lock() {
            Ok(mut g) => match g.get(&key) {
                Some(BindingSlot::Poisoned) => None,
                Some(BindingSlot::Single(_)) => {
                    if let Some(BindingSlot::Single(inv)) = g.remove(&key) {
                        Some(*inv)
                    } else {
                        unreachable!("get returned Single but remove returned None or Poisoned")
                    }
                }
                None => None,
            },
            Err(_) => None,
        };

        let invocation = match cached {
            Some(inv) => inv,
            None => {
                // §16.0 fail-closed: a missing entry means a Stage 3
                // call was never made (or was already consumed, or
                // the slot is poisoned by a prior id re-use). The
                // spec is explicit: a tool-name-only synthetic
                // invocation MUST NOT satisfy the §16.0 binding
                // requirement.
                log::warn!(
                    target: "agent_shield::runtime::session",
                    "validate_tool_output: no §16.0 binding cache entry for tool `{}` + tool_call_id `{}` — failing closed per spec §16.0.",
                    tool,
                    tool_call_id,
                );
                return StageVerdict::block(
                    "<binding>",
                    format!(
                        "stage4: §16.0 binding missing for tool `{}` with tool_call_id `{}` — host must call validate_tool_call before validate_tool_output",
                        tool, tool_call_id,
                    ),
                    None,
                );
            }
        };
        self.run_populators(&invocation, Some(result), Phase::After);

        let request_context = self.request_context.to_value();
        let user_input = self.cached_user_input_clone();
        let objective = self.objective_text();
        let forbidden = self.forbidden_list();
        let ctx = EvalRuntime {
            session_id: &self.request_context.session_id,
            correlation_id: &self.request_context.correlation_id,
            user_id: self.request_context.user_id.as_deref(),
            tenant_id: self.request_context.tenant_id.as_deref(),
            request_context,
            turn_id,
            objective: &objective,
            forbidden: &forbidden,
            user_input: &user_input,
            active_guard_policies: "",
            variables_snapshot: "",
            prior_checks_summary: "",
        };
        let verdict = self
            .runtime
            .engine
            .evaluate_post_tool(&invocation, result, &ctx);

        // §16.1 — capture the SANITIZED result for downstream Stage-3
        // `{user_input}` enrichment. We append even on warn/redact
        // verdicts (the agent processes those results); only block
        // verdicts skip capture, since the agent never sees a blocked
        // result.
        if verdict.allowed {
            self.push_tool_result_for_enrichment(tool, result);
        }

        verdict
    }

    /// Stage 5 — output validation (§18). Mutates `response` in place
    /// for `redact` / `append` / `prepend` actions.
    pub fn validate_output(&self, response: &mut String) -> StageVerdict {
        // IFC: `Eₙ ⊑ μ(user_output_clearance)` admit-test before any
        // policy work. Ensures secrets accumulated this scope can't be
        // emitted to the user even if no guard policy fires.
        let clearance = self.runtime.config().ifc.user_output_clearance;
        if !self.flows_to_clearance(clearance) {
            return self.ifc_denied_verdict("output", "user", clearance);
        }
        let request_context = self.request_context.to_value();
        let user_input = self.cached_user_input_clone();
        let objective = self.objective_text();
        let forbidden = self.forbidden_list();
        let ctx = EvalRuntime {
            session_id: &self.request_context.session_id,
            correlation_id: &self.request_context.correlation_id,
            user_id: self.request_context.user_id.as_deref(),
            tenant_id: self.request_context.tenant_id.as_deref(),
            request_context,
            turn_id: self.current_turn_id(),
            objective: &objective,
            forbidden: &forbidden,
            user_input: &user_input,
            active_guard_policies: "",
            variables_snapshot: "",
            prior_checks_summary: "",
        };
        self.runtime.engine.evaluate_output(response, &ctx)
    }

    // ── Tool-cycle host hooks (§9.3 / §21) ─────────────────────────

    /// Host MUST call after a successful tool execution. Runs
    /// `populated_by[]` for matched `phase: after` entries (§10.5.1)
    /// and emits `tool.<name>.success` (§9.3). Resets the resolver
    /// dispatcher's per-(turn, *, tool) attempt counter for every
    /// variable that suspended on this tool, per §11.10.2.
    pub fn record_tool_success(&self, tool: &str, result: &Value) -> Result<(), RuntimeError> {
        let invocation = Invocation::tool(tool, Value::Null);
        self.run_populators(&invocation, Some(result), Phase::After);
        // IFC: tool succeeded ⇒ `λ(tool)` flowed into the agent's view.
        let tags = self.runtime.config().ifc_tags_for_tool(tool);
        self.raise_exposure(tags);
        // The resolver dispatcher's tool-loop counter resets when the
        // tool actually runs, regardless of which variable suspended on
        // it (§11.10.2).
        self.runtime.resolver.note_tool_succeeded(tool);
        self.runtime
            .bus
            .emit_tool_success_in(&self.session_id, tool)
            .map_err(RuntimeError::from)
    }

    /// Host MUST call after a failed tool execution. Emits
    /// `tool.<name>.failure` with the error string in the payload.
    pub fn record_tool_failure(&self, tool: &str, error: &str) -> Result<(), RuntimeError> {
        // Use bus.emit directly so we can attach a payload — the
        // emit_tool_failure helper takes only a name.
        let id = crate::events::EventId::Tool {
            name: tool.into(),
            kind: crate::events::ToolEventKind::Failure,
        };
        self.runtime
            .bus
            .emit_in(
                &self.session_id,
                id,
                None,
                Some(serde_json::json!({ "error": error })),
            )
            .map_err(RuntimeError::from)
    }

    /// Endpoint variant of [`Self::record_tool_success`]. The `method`
    /// argument flows into the synthetic [`Invocation`] used to match
    /// `populated_by[]` entries — without it, method-filtered after-phase
    /// populators (e.g. `methods: ["GET"]`) would never match.
    pub fn record_endpoint_success(
        &self,
        method: &str,
        pattern: &str,
        result: &Value,
    ) -> Result<(), RuntimeError> {
        let invocation = Invocation::endpoint(method, pattern, Value::Null);
        self.run_populators(&invocation, Some(result), Phase::After);
        // IFC: endpoint succeeded ⇒ `λ(endpoint)` flowed into the
        // agent's view.
        let label = self.runtime.config().ifc_tags_for_endpoint(pattern);
        self.raise_exposure(label);
        self.runtime
            .bus
            .emit_simple_in(
                &self.session_id,
                crate::events::EventId::Endpoint {
                    pattern: pattern.into(),
                    kind: crate::events::ToolEventKind::Success,
                },
            )
            .map_err(RuntimeError::from)
    }

    /// Endpoint variant of [`Self::record_tool_failure`]. Carries the
    /// HTTP method into the bus payload so subscribers can filter on
    /// method without parsing the pattern.
    pub fn record_endpoint_failure(
        &self,
        method: &str,
        pattern: &str,
        error: &str,
    ) -> Result<(), RuntimeError> {
        let id = crate::events::EventId::Endpoint {
            pattern: pattern.into(),
            kind: crate::events::ToolEventKind::Failure,
        };
        self.runtime
            .bus
            .emit_in(
                &self.session_id,
                id,
                None,
                Some(serde_json::json!({ "method": method, "error": error })),
            )
            .map_err(RuntimeError::from)
    }

    /// Agent variant of [`Self::record_tool_success`].
    pub fn record_agent_success(&self, agent: &str, result: &Value) -> Result<(), RuntimeError> {
        let invocation = Invocation::agent(agent, Value::Null);
        self.run_populators(&invocation, Some(result), Phase::After);
        // IFC: sub-agent succeeded ⇒ `λ(agent)` flowed into the
        // calling agent's view.
        let label = self.runtime.config().ifc_tags_for_agent(agent);
        self.raise_exposure(label);
        self.runtime
            .bus
            .emit_simple_in(
                &self.session_id,
                crate::events::EventId::Agent {
                    name: agent.into(),
                    kind: crate::events::ToolEventKind::Success,
                },
            )
            .map_err(RuntimeError::from)
    }

    /// Agent variant of [`Self::record_tool_failure`].
    pub fn record_agent_failure(&self, agent: &str, error: &str) -> Result<(), RuntimeError> {
        let id = crate::events::EventId::Agent {
            name: agent.into(),
            kind: crate::events::ToolEventKind::Failure,
        };
        self.runtime
            .bus
            .emit_in(
                &self.session_id,
                id,
                None,
                Some(serde_json::json!({ "error": error })),
            )
            .map_err(RuntimeError::from)
    }

    // ── Streaming (§17 / §18) ───────────────────────────────────────

    /// Construct a chunk-aware streaming guard for Stage 4 or 5. The
    /// runtime's pinned [`super::builder::StreamingOptions`] (set via
    /// [`super::builder::RuntimeBuilder::streaming_window`])
    /// determine the trigger / window / overlap defaults — hosts can
    /// override per call by chaining the returned
    /// [`StreamingGuard`]'s builder methods.
    pub fn streaming_session(&self, stage: Stage) -> StreamingGuard {
        let opts = self.runtime.streaming_options();
        let mut owned = OwnedEvalRuntime::minimal(
            &self.request_context.session_id,
            &self.request_context.correlation_id,
        );
        owned.user_id = self.request_context.user_id.clone();
        owned.tenant_id = self.request_context.tenant_id.clone();
        owned.request_context = self.request_context.to_value();
        owned.turn_id = self.current_turn_id();
        owned.objective = self.objective_text();
        owned.forbidden = self.forbidden_list();
        owned.user_input = self.cached_user_input_clone();

        let guard = self.runtime.engine.streaming_session(stage, owned);
        let trig: StreamingTrigger = opts.trigger;
        guard
            .with_trigger(trig)
            .with_window_size(opts.window_size)
            .with_overlap(opts.overlap)
    }

    // ── Internal helpers ────────────────────────────────────────────

    fn build_attrs(&self) -> std::collections::HashMap<String, Value> {
        let mut attrs = std::collections::HashMap::new();
        attrs.insert("@context".into(), self.request_context.to_value());
        let mut session = serde_json::Map::new();
        session.insert(
            "id".into(),
            Value::String(self.request_context.session_id.clone()),
        );
        if let Some(u) = &self.request_context.user_id {
            session.insert("user_id".into(), Value::String(u.clone()));
        }
        if let Some(t) = &self.request_context.tenant_id {
            session.insert("tenant_id".into(), Value::String(t.clone()));
        }
        attrs.insert("session".into(), Value::Object(session));
        attrs.insert(
            "correlation_id".into(),
            Value::String(self.request_context.correlation_id.clone()),
        );
        attrs
    }

    fn cached_user_input_clone(&self) -> String {
        self.cached_user_input
            .lock()
            .map(|g| g.clone())
            .unwrap_or_default()
    }

    fn objective_text(&self) -> String {
        // §4 / §5: concatenated tier goals.
        let mut s = String::new();
        for tier in &self.runtime.config.objective.tiers {
            for line in &tier.goal {
                if !s.is_empty() {
                    s.push('\n');
                }
                s.push_str(line);
            }
        }
        s
    }

    fn forbidden_list(&self) -> Vec<String> {
        let mut out: Vec<String> = Vec::new();
        for tier in &self.runtime.config.objective.tiers {
            out.extend(tier.forbidden.iter().cloned());
        }
        out
    }

    /// Walk `select_populators` for the given invocation/phase and
    /// apply each entry. Errors are logged and the next populator is
    /// tried — populator failures are non-fatal per §10.5.1.
    fn run_populators(&self, invocation: &Invocation, result: Option<&Value>, phase: Phase) {
        let pairs = select_populators(&self.runtime.config.variables, invocation, phase);
        // Snapshot current variable state so populator expressions like
        // `attempt_count + 1` can read the previous value (§10.5.3).
        let var_snapshot: HashMap<String, Value> = self
            .runtime
            .config
            .variables
            .iter()
            .filter_map(|var| {
                let st = self
                    .runtime
                    .tracker
                    .read_variable_in(&self.session_id, &var.name);
                if matches!(st.status, VarStatus::Resolved) {
                    Some((var.name.clone(), st.value.clone()))
                } else {
                    None
                }
            })
            .collect();
        for (var, entry) in pairs {
            match apply_populator(
                var,
                entry,
                invocation,
                result,
                Some(self.runtime.extractors.as_ref()),
                Some(&var_snapshot),
            ) {
                Ok(Some(value)) => {
                    let var_key = self.compute_populator_key(var, invocation, &var_snapshot);
                    let source_params = build_source_params(invocation);
                    if let Err(e) = self.runtime.tracker.set_variable_keyed_full_in(
                        &self.session_id,
                        &var.name,
                        var_key.as_ref(),
                        value,
                        Some("populator"),
                        Some(&format!(
                            "{}:{}",
                            phase_str(phase),
                            invocation_target(invocation)
                        )),
                        source_params,
                        ResolverOutcome::Allow,
                    ) {
                        log::warn!(
                            target: "agent_shield::runtime",
                            "populator write to `{}` failed: {}", var.name, e
                        );
                    }
                }
                Ok(None) => {}
                Err(e) => {
                    log::warn!(
                        target: "agent_shield::runtime",
                        "populator on `{}` raised {:?}; skipping", var.name, e
                    );
                }
            }
        }
    }

    /// §9.4.3: evaluate a variable's `key:` expression at the
    /// populator's bound namespace. Returns `None` for non-keyed
    /// variables; returns `Some(Value::Null)` if the expression
    /// produces null (the tracker's `set_variable_keyed` rejects null
    /// keys with a structured warning per §9.4.2).
    fn compute_populator_key(
        &self,
        var: &crate::variables::Variable,
        invocation: &Invocation,
        variable_state: &HashMap<String, Value>,
    ) -> Option<Value> {
        use crate::expressions::eval::{evaluate_to_value, EvalContext};
        let key_expr = var.key.as_deref()?;
        let mut attrs: HashMap<String, Value> = HashMap::new();
        for (k, v) in variable_state {
            attrs.insert(k.clone(), v.clone());
        }
        // Bind the invocation namespace under @-prefixed keys per §7.1.
        crate::guard_policy_runtime::bind_invocation_into(&mut attrs, invocation);
        // Bind request context too so `key: "@context.user_id"` works.
        attrs.insert("@context".into(), self.request_context.to_value());
        let ctx = EvalContext::from_attrs(&attrs);
        evaluate_to_value(key_expr, &ctx)
    }

    // ── Stage-3 §16.1 / §16.2 prompt-enrichment helpers ─────────────

    /// Build the per-call Stage-3 context: enriched user_input plus the
    /// three §16.1 strings (`{active_guard_policies}`, `{variables}`,
    /// `{prior_checks_summary}`) that the engine binds as template
    /// variables and that drive the §16.2 Runtime Context block.
    fn build_stage3_context(&self, invocation: &Invocation) -> Stage3Context {
        let active = self.active_guard_policies_csv();
        let variables = self.variables_snapshot_json();
        let prior = self.prior_checks_summary(invocation);
        let base_input = self.cached_user_input_clone();
        let user_input = self.enrich_user_input_with_tool_responses(&base_input);

        Stage3Context {
            session_id: self.request_context.session_id.clone(),
            correlation_id: self.request_context.correlation_id.clone(),
            user_id: self.request_context.user_id.clone(),
            tenant_id: self.request_context.tenant_id.clone(),
            request_context: self.request_context.to_value(),
            turn_id: self.current_turn_id(),
            objective: self.objective_text(),
            forbidden: self.forbidden_list(),
            user_input,
            active_guard_policies: active,
            variables_snapshot: variables,
            prior_checks_summary: prior,
        }
    }

    /// §16.1 — append `(tool_name, sanitized_text)` to the per-turn
    /// buffer that feeds Stage-3 `{user_input}` enrichment. Truncates
    /// the result to the per-result cap and applies a FIFO bound on
    /// total retained entries.
    fn push_tool_result_for_enrichment(&self, tool: &str, result: &Value) {
        let text = stringify_tool_result(result);
        let truncated = truncate_chars(
            &text,
            crate::constants::stage_tool_exec::TOOL_RESULT_TRUNCATION,
        );
        if let Ok(mut buf) = self.tool_results_this_turn.lock() {
            buf.push((tool.to_string(), truncated));
            let max = crate::constants::stage_tool_exec::MAX_RETAINED_RESULTS;
            let len = buf.len();
            if len > max {
                buf.drain(0..(len - max));
            }
        }
    }

    /// §16.1 — build the enriched `{user_input}` for a Stage-3 LLM
    /// detection prompt. When no tools have executed yet in the turn,
    /// returns the base user input unchanged.
    fn enrich_user_input_with_tool_responses(&self, base: &str) -> String {
        let buf = match self.tool_results_this_turn.lock() {
            Ok(g) => g.clone(),
            Err(_) => return base.to_string(),
        };
        if buf.is_empty() {
            return base.to_string();
        }
        let mut out = base.to_string();
        for (tool, text) in &buf {
            out.push_str("\n\n## START TOOL RESPONSE: ");
            out.push_str(tool);
            out.push_str(" ##\n");
            out.push_str(text);
            out.push_str("\n## END TOOL RESPONSE: ");
            out.push_str(tool);
            out.push_str(" ##");
        }
        out
    }

    /// §16.1 — comma-separated list of currently-active guard-policy
    /// names. Empty string when nothing is active; the Stage-3 template
    /// builder substitutes `(none)` in that case per the spec example.
    fn active_guard_policies_csv(&self) -> String {
        let snap = self.runtime.engine.activation_snapshot_in(&self.session_id);
        let mut names: Vec<String> = snap
            .into_iter()
            .filter(|(_, active)| *active)
            .map(|(name, _)| name)
            .collect();
        names.sort();
        names.join(", ")
    }

    /// §16.1 — JSON-encoded snapshot of every currently-`Resolved`
    /// variable. `unset` and `denied` variables are excluded; the
    /// validator LLM does not need their negative status, and including
    /// them would add prompt noise. Returns `{}` when nothing is
    /// resolved (the Stage-3 template builder substitutes the empty
    /// JSON object for null/empty cases).
    fn variables_snapshot_json(&self) -> String {
        let snap = self.runtime.tracker.resolved_snapshot_in(&self.session_id);
        if snap.is_empty() {
            return "{}".into();
        }
        // Sort keys for deterministic output — useful for diagnostics
        // and for cross-language assertions in the integration suite.
        let mut keys: Vec<&String> = snap.keys().collect();
        keys.sort();
        let mut map = serde_json::Map::new();
        for k in keys {
            if let Some(v) = snap.get(k) {
                map.insert(k.clone(), v.clone());
            }
        }
        serde_json::to_string(&Value::Object(map)).unwrap_or_else(|_| "{}".into())
    }

    /// §16.1 — plain-English summary of Stage-2 (`state_validation`)
    /// guard policies that ran for the current invocation. Lists every
    /// state policy whose `applies_to:` matched the invocation AND
    /// whose `active_if` evaluated truthy. We're invoked AFTER Stage 2
    /// returned `allowed`, so by definition all such policies passed.
    fn prior_checks_summary(&self, invocation: &Invocation) -> String {
        use crate::guard_policy_runtime::{applies_to_matches, SelectorSubject};
        use crate::variables::ResourceKind;

        let subject = match invocation.kind {
            ResourceKind::Tool => SelectorSubject::Tool {
                name: invocation.name.as_deref().unwrap_or(""),
            },
            ResourceKind::Agent => SelectorSubject::Agent {
                name: invocation.name.as_deref().unwrap_or(""),
            },
            ResourceKind::Endpoint => SelectorSubject::Endpoint {
                method: invocation.method.as_deref().unwrap_or(""),
                uri: invocation.uri.as_deref().unwrap_or(""),
            },
        };

        let active_snapshot = self.runtime.engine.activation_snapshot_in(&self.session_id);

        let mut passed: Vec<String> = Vec::new();
        for policy in &self.runtime.engine.config().state_validation.guard_policies {
            if !applies_to_matches(policy.applies_to.as_ref(), &subject) {
                continue;
            }
            // Treat omitted `active_if` as always-active. Otherwise read
            // the activation cache (Stage 2 just populated it).
            let active = match policy.active_if.as_deref() {
                None => true,
                Some(_) => active_snapshot.get(&policy.name).copied().unwrap_or(false),
            };
            if active {
                passed.push(policy.name.clone());
            }
        }

        if passed.is_empty() {
            "No deterministic state-validation policies applied to this call.".to_string()
        } else {
            passed.sort();
            format!(
                "Stage-2 state_validation policies that passed for this call: {}.",
                passed.join(", ")
            )
        }
    }
}

fn phase_str(p: Phase) -> &'static str {
    match p {
        Phase::Before => "before",
        Phase::After => "after",
    }
}

fn invocation_target(inv: &Invocation) -> String {
    match inv.kind {
        ResourceKind::Tool => inv.name.clone().unwrap_or_default(),
        ResourceKind::Agent => inv.name.clone().unwrap_or_default(),
        ResourceKind::Endpoint => format!(
            "{} {}",
            inv.method.clone().unwrap_or_default(),
            inv.uri.clone().unwrap_or_default()
        ),
    }
}

/// §9.3.2 — build the `@source_params` snapshot for a populator/
/// resolver write. For `tool` and `agent` writers this is the call's
/// `params`; for `endpoint` writers it's the merged
/// `{ path: <path_params>, query: <query_params>, body: <params> }`
/// object. Per spec, this snapshot is captured at write time and is
/// read-only thereafter.
fn build_source_params(inv: &Invocation) -> Option<Value> {
    match inv.kind {
        ResourceKind::Tool | ResourceKind::Agent => Some(inv.params.clone()),
        ResourceKind::Endpoint => {
            let mut obj = serde_json::Map::new();
            // path_params and query_params aren't separately tracked
            // on Invocation today — they live inside `params` when
            // the host extracted them. We surface the body verbatim
            // and let authors index `@source_params.<field>` directly.
            // When a host populates `path` / `query` separately they
            // can supply them in `params` keyed under those names.
            obj.insert("body".into(), inv.params.clone());
            if let Some(method) = &inv.method {
                obj.insert("method".into(), Value::String(method.clone()));
            }
            if let Some(uri) = &inv.uri {
                obj.insert("uri".into(), Value::String(uri.clone()));
            }
            Some(Value::Object(obj))
        }
    }
}

/// Owned per-call Stage-3 context. Holds the strings that
/// [`EvalRuntime`] borrows so the `runtime()` call returns a borrowed
/// view that's valid for the duration of the Stage-3 evaluation.
struct Stage3Context {
    session_id: String,
    correlation_id: String,
    user_id: Option<String>,
    tenant_id: Option<String>,
    request_context: Value,
    turn_id: u64,
    objective: String,
    forbidden: Vec<String>,
    user_input: String,
    active_guard_policies: String,
    variables_snapshot: String,
    prior_checks_summary: String,
}

impl Stage3Context {
    fn runtime(&self) -> EvalRuntime<'_> {
        EvalRuntime {
            session_id: &self.session_id,
            correlation_id: &self.correlation_id,
            user_id: self.user_id.as_deref(),
            tenant_id: self.tenant_id.as_deref(),
            request_context: self.request_context.clone(),
            turn_id: self.turn_id,
            objective: &self.objective,
            forbidden: &self.forbidden,
            user_input: &self.user_input,
            active_guard_policies: &self.active_guard_policies,
            variables_snapshot: &self.variables_snapshot,
            prior_checks_summary: &self.prior_checks_summary,
        }
    }
}

/// Stringify a tool result for the §16.1 boundary-marker enrichment.
/// String values pass through directly so the validator sees the same
/// shape the agent does. Non-string values serialize as compact JSON.
fn stringify_tool_result(result: &Value) -> String {
    if let Value::String(s) = result {
        return s.clone();
    }
    serde_json::to_string(result).unwrap_or_default()
}

/// Truncate to at most `max_chars` Unicode code points, preserving
/// char boundaries. The truncation cap is the §16.1 SHOULD ceiling
/// (~2000 chars per result by default).
fn truncate_chars(s: &str, max_chars: usize) -> String {
    if s.chars().count() <= max_chars {
        return s.to_string();
    }
    s.chars().take(max_chars).collect()
}

impl GuardrailsSession {
    /// Idempotent shutdown for this session. Drains dangling boundary
    /// scopes (`turn` / `request`) into matching `*.end` emissions and
    /// emits `session.end` once. Subsequent calls are no-ops. Drops
    /// every per-session entry from the runtime's tracker, bus, and
    /// activation cache so they don't leak across sessions.
    ///
    /// Hosts can call this explicitly when a conversation winds down;
    /// otherwise [`Drop`] runs the same cleanup.
    pub fn close(&self) {
        if self.closed.swap(true, std::sync::atomic::Ordering::SeqCst) {
            return;
        }
        if self.turn_active.swap(false, Ordering::Relaxed) {
            let _ = self.runtime.bus.emit_turn_end_in(&self.session_id);
            self.runtime.tracker.clear_per_turn_in(&self.session_id);
        }
        if self.request_active.swap(false, Ordering::Relaxed) {
            let _ = self.runtime.bus.emit_request_end_in(&self.session_id);
            self.runtime.tracker.clear_per_request_in(&self.session_id);
        }
        // Emit session.end on the session's own bus partition. Only
        // this session's latches are wiped per the partition semantics.
        let _ = self.runtime.bus.emit_session_end_in(&self.session_id);
        // Final eviction of any state that survived emission processing.
        self.runtime.bus.cleanup_session(&self.session_id);
        self.runtime.tracker.cleanup_session(&self.session_id);
        self.runtime.engine.cleanup_session(&self.session_id);
    }
}

impl Drop for GuardrailsSession {
    fn drop(&mut self) {
        // §21: implementations MUST tolerate begin-without-end at
        // session disposal — the [`Self::close`] hook handles boundary
        // emission, latch wipe, and per-session state cleanup
        // idempotently.
        self.close();
    }
}
