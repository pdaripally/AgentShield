//! `RequestContext` (spec §6.3).
//!
//! The Request Context is the host-supplied envelope that every external
//! call (gating, resolver, populator) reads as `context.*` in the
//! expression engine and as `${context.*}` in configuration string
//! interpolation. Spec §6.3 mandates the well-known fields
//! (`user_id`, `tenant_id`, `session_id`, `correlation_id`, `extensions`).
//!
//! ## Spec ambiguities
//!
//! - §6.3 does not pin a session-id format. We accept any non-empty
//!   string and auto-generate a UUIDv4 when the host omits it.
//! - `extensions` is an open object; we keep it as `serde_json::Value`
//!   so the host can pass any JSON shape through.

use serde_json::{Map, Value};

/// Per-session host-supplied context (§6.3).
///
/// Hosts construct one [`RequestContext`] per agent session. The runtime
/// reads `user_id`, `tenant_id`, etc. into the expression evaluator's
/// `context.*` namespace and into the resolver dispatcher's
/// per-invocation context map. The `extensions` field carries any
/// host-specific fields that policy authors want to expression-match —
/// e.g. `context.extensions.region == "EU"`.
#[derive(Debug, Clone, PartialEq)]
pub struct RequestContext {
    /// Authenticated user identifier (§6.3).
    pub user_id: Option<String>,
    /// Tenant / organization identifier (§6.3).
    pub tenant_id: Option<String>,
    /// Unique session identifier — host-supplied or auto-generated.
    pub session_id: String,
    /// Distributed-tracing correlation id (§6.3).
    pub correlation_id: String,
    /// Open-shape host-supplied additional fields. Defaults to `{}`.
    pub extensions: Value,
}

impl Default for RequestContext {
    fn default() -> Self {
        Self {
            user_id: None,
            tenant_id: None,
            session_id: gen_id("sess"),
            correlation_id: gen_id("corr"),
            extensions: Value::Object(Map::new()),
        }
    }
}

impl RequestContext {
    /// Construct a context with explicit session and correlation ids.
    pub fn new(session_id: impl Into<String>, correlation_id: impl Into<String>) -> Self {
        Self {
            user_id: None,
            tenant_id: None,
            session_id: session_id.into(),
            correlation_id: correlation_id.into(),
            extensions: Value::Object(Map::new()),
        }
    }

    /// Builder: set `user_id`.
    pub fn with_user_id(mut self, u: impl Into<String>) -> Self {
        self.user_id = Some(u.into());
        self
    }

    /// Builder: set `tenant_id`.
    pub fn with_tenant_id(mut self, t: impl Into<String>) -> Self {
        self.tenant_id = Some(t.into());
        self
    }

    /// Builder: replace the entire `extensions` object.
    pub fn with_extensions(mut self, v: Value) -> Self {
        self.extensions = v;
        self
    }

    /// Builder: insert a single `extensions.<key>` field.
    pub fn extend(mut self, key: impl Into<String>, value: Value) -> Self {
        match &mut self.extensions {
            Value::Object(m) => {
                m.insert(key.into(), value);
            }
            _ => {
                let mut m = Map::new();
                m.insert(key.into(), value);
                self.extensions = Value::Object(m);
            }
        }
        self
    }

    /// Build the structured `Value` form delivered into the expression
    /// evaluator as the `context` namespace per §3.6.1.
    pub fn to_value(&self) -> Value {
        let mut m = Map::new();
        if let Some(u) = &self.user_id {
            m.insert("user_id".into(), Value::String(u.clone()));
        }
        if let Some(t) = &self.tenant_id {
            m.insert("tenant_id".into(), Value::String(t.clone()));
        }
        m.insert("session_id".into(), Value::String(self.session_id.clone()));
        m.insert(
            "correlation_id".into(),
            Value::String(self.correlation_id.clone()),
        );
        m.insert("extensions".into(), self.extensions.clone());
        Value::Object(m)
    }

    /// Same as [`Self::to_value`] but returned as a `serde_json::Map` so
    /// the resolver runtime can consume it without an extra unwrap.
    pub fn to_map(&self) -> Map<String, Value> {
        match self.to_value() {
            Value::Object(m) => m,
            _ => Map::new(),
        }
    }
}

fn gen_id(prefix: &str) -> String {
    format!("{}-{}", prefix, uuid::Uuid::new_v4())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn default_generates_unique_ids() {
        let a = RequestContext::default();
        let b = RequestContext::default();
        assert_ne!(a.session_id, b.session_id);
        assert_ne!(a.correlation_id, b.correlation_id);
    }

    #[test]
    fn to_value_includes_required_fields() {
        let ctx = RequestContext::new("s1", "c1")
            .with_user_id("alice")
            .with_tenant_id("acme");
        let v = ctx.to_value();
        let obj = v.as_object().unwrap();
        assert_eq!(obj["session_id"], Value::String("s1".into()));
        assert_eq!(obj["correlation_id"], Value::String("c1".into()));
        assert_eq!(obj["user_id"], Value::String("alice".into()));
        assert_eq!(obj["tenant_id"], Value::String("acme".into()));
        assert!(obj["extensions"].is_object());
    }

    #[test]
    fn extend_adds_to_extensions() {
        let ctx = RequestContext::default().extend("region", Value::String("EU".into()));
        let m = ctx.extensions.as_object().unwrap();
        assert_eq!(m["region"], Value::String("EU".into()));
    }
}
