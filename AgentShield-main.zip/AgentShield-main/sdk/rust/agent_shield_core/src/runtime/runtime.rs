//! [`GuardrailsRuntime`].
//!
//! A `GuardrailsRuntime` owns the immutable, session-shared state
//! (config, event bus, lifetime tracker, resolver dispatcher,
//! guard-policy engine, observability dispatcher) and spawns one
//! [`GuardrailsSession`](super::session::GuardrailsSession) per
//! concurrent agent conversation.
//!
//! The runtime is constructed by
//! [`super::builder::RuntimeBuilder::build`]; hosts shouldn't build it
//! manually.

use std::collections::HashMap;
use std::sync::Arc;

use crate::event_bus::EventBus;
use crate::guard_policy_runtime::GuardPolicyEngine;
use crate::lifetime_tracker::LifetimeTracker;
use crate::merge::MergedConfig;
use crate::observability::ObservabilityDispatcher;
use crate::populator::ExtractorRegistry;
use crate::resolver_runtime::ResolverDispatcher;

use super::builder::StreamingOptions;
use super::request_context::RequestContext;
use super::session::GuardrailsSession;

/// Top-level runtime (§21).
///
/// Holds Arc-shared immutable state across sessions:
///
/// - `config` — merged YAML produced by the loader.
/// - `bus` / `tracker` / `resolver` / `engine` — the §10 / §11 / §12
///   machinery wired together.
/// - `observability` — dispatcher subscribed to the bus for §9.3
///   closed-namespace mirroring (§19.5).
/// - `extractors` — host-supplied `result.*` extractors used by the
///   §10.5.1 populator engine.
///
/// Sessions are cheap to spawn — they hold a per-session
/// [`RequestContext`] plus per-turn / per-request id counters and
/// reference everything else through the runtime's `Arc`s.
pub struct GuardrailsRuntime {
    pub(crate) config: Arc<MergedConfig>,
    pub(crate) bus: EventBus,
    pub(crate) tracker: Arc<LifetimeTracker>,
    pub(crate) resolver: Arc<ResolverDispatcher>,
    pub(crate) engine: Arc<GuardPolicyEngine>,
    pub(crate) observability: Arc<ObservabilityDispatcher>,
    pub(crate) extractors: Arc<ExtractorRegistry>,
    /// Variable registry — same map handed to the tracker; held here
    /// for `set_variable` / `reset_variable` / `resolve_variable`
    /// validation (the runtime answers `UnknownVariable` synchronously
    /// rather than waiting for the tracker to fail).
    pub(crate) variables: Arc<HashMap<String, crate::variables::Variable>>,
    /// Streaming defaults applied to every new
    /// [`crate::guard_policy_runtime::StreamingGuard`] created by
    /// [`GuardrailsSession::streaming_session`](super::session::GuardrailsSession::streaming_session).
    pub(crate) streaming: StreamingOptions,
}

impl std::fmt::Debug for GuardrailsRuntime {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("GuardrailsRuntime")
            .field("config_metadata_name", &self.config.metadata.name)
            .field(
                "policies_input",
                &self.config.input_validation.guard_policies.len(),
            )
            .field(
                "policies_state",
                &self.config.state_validation.guard_policies.len(),
            )
            .field(
                "policies_tool_execution",
                &self.config.tool_execution_validation.guard_policies.len(),
            )
            .field(
                "policies_post_tool",
                &self.config.post_tool_validation.guard_policies.len(),
            )
            .field(
                "policies_output",
                &self.config.output_validation.guard_policies.len(),
            )
            .field("variables", &self.variables.len())
            .finish_non_exhaustive()
    }
}

impl GuardrailsRuntime {
    /// Spawn a per-conversation session bound to the given request
    /// context (§6.3).
    pub fn new_session(self: &Arc<Self>, ctx: RequestContext) -> GuardrailsSession {
        GuardrailsSession::new(self.clone(), ctx)
    }

    /// Borrow the merged configuration (§3 / §4).
    pub fn config(&self) -> &MergedConfig {
        &self.config
    }

    /// Borrow the event bus (§10). Hosts subscribing to closed-namespace
    /// events read from this.
    pub fn bus(&self) -> &EventBus {
        &self.bus
    }

    /// Borrow the observability dispatcher (§19).
    pub fn observability(&self) -> &Arc<ObservabilityDispatcher> {
        &self.observability
    }

    /// Borrow the lifetime tracker (§9 / §10).
    pub fn tracker(&self) -> &Arc<LifetimeTracker> {
        &self.tracker
    }

    /// Borrow the resolver dispatcher (§11).
    pub fn resolver(&self) -> &Arc<ResolverDispatcher> {
        &self.resolver
    }

    /// Borrow the guard-policy engine (§12).
    pub fn engine(&self) -> &Arc<GuardPolicyEngine> {
        &self.engine
    }

    /// Borrow the variable registry (§9).
    pub fn variables(&self) -> &HashMap<String, crate::variables::Variable> {
        &self.variables
    }

    /// Borrow the extractor registry used by populators (§10.5.1).
    pub fn extractors(&self) -> &ExtractorRegistry {
        &self.extractors
    }

    /// The streaming defaults pinned at build time (§17 / §18).
    pub fn streaming_options(&self) -> StreamingOptions {
        self.streaming
    }

    /// Effective runtime mode (#14). YAML `mode:`, `AGENT_SHIELD_MODE`
    /// env (env wins), or default `Active`.
    pub fn mode(&self) -> crate::shield_primitives::RuntimeMode {
        self.config.mode
    }
}
