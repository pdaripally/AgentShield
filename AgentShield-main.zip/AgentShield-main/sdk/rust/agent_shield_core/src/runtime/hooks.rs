//! public hook traits the host implements.
//!
//! These are re-exports from the underlying engine modules, gathered into
//! one place so downstream hosts can `use agent_shield_core::runtime::hooks::*;`
//! to bring the entire pluggability surface into scope.
//!
//! ## Hook → spec section map
//!
//! | Hook trait | Spec | Used by |
//! |------------|------|---------|
//! | [`AgentResolver`] | §11.4 | `kind: agent` resolvers |
//! | [`DelegateDispatcher`] | §11.10.3 / §11.12 | `kind: delegate` (HTTP / classifier / MCP / A2A) |
//! | [`LlmCaller`] | §12.5.1 | `llm:` detection entries |
//! | [`ClassifierCaller`] | §12.5.1 | `classifier:` detection entries |
//! | [`ObservabilityProvider`] | §19 | structured-log fan-out |
//!
//! `kind: human` (§11.11) is not in the table — it's no longer a
//! host-trait callback. The runtime synthesises a canonical MCP tool
//! call (`agent_shield.ask_human`) instead; the host registers an MCP
//! tool under that name (see `examples/tools/ask-human-mcp-server/`).
//!
//! All traits are sync (`Send + Sync`). Async hosts adapt by blocking
//! on a tokio handle inside the trait method (see the observability
//! provider module-level docs for an example).

pub use crate::guard_policy_runtime::{
    ClassifierCaller, ClassifierVerdict, LlmCaller, LlmDecision, LlmResponse,
};
pub use crate::observability::ObservabilityProvider;
pub use crate::resolver_runtime::{
    AgentResolveRequest, AgentResolver, DelegateDispatcher, DelegateRequest,
};
