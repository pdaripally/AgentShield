//! default [`DelegateDispatcher`] implementation.
//!
//! Hosts that don't bring their own `kind: delegate` plumbing get a
//! batteries-included dispatcher that handles the four configuration
//! types §6.2 lists for delegate resolvers:
//!
//! | `configuration.type` | Behavior |
//! |----------------------|----------|
//! | `http_endpoint`      | POST a JSON envelope (§11.12.1) and parse `ResolverResponse` |
//! | `classifier`         | POST `{ "input": "..." }` and fold the structured response into a wire envelope per §11.12.4 |
//! | `mcp_server`         | Fail closed with `MCP transport not registered` |
//! | `a2a_agent`          | Fail closed with `A2A transport not registered` |
//! | `llm`                | Fail closed (the `llm` configuration type is for `evaluate_when[].llm`, not `kind: delegate`) |
//!
//! ## HTTP transport
//!
//! Gated on `cfg(feature = "http")` — `reqwest` is already a feature-gated
//! optional dependency. With `http` disabled, every config type falls back
//! to a clearly-labeled fail-closed deny so the runtime never silently
//! allows a delegate that the host expected to enforce.
//!
//! ## Header / endpoint interpolation
//!
//! Hosts pre-interpolate `${env|context|var}` references at config-load
//! time; this dispatcher treats `endpoint` and `headers[*]` as already
//! rendered strings. The classifier path obeys §6.4's `Authorization` /
//! `X-API-Key` empty-value-fail-closed rule.
//!
//! ## Classifier mapping
//!
//! `delegate_default` implements the AACS-compatible §11.12.4 folding
//! rules. The dispatcher recognizes three response shapes:
//!
//! 1. The §11.3 wire envelope verbatim — `{ "decision": "...", "value": ..., "reason": "..." }`.
//! 2. The §11.12.4 score+threshold shape — `{ "score": <number>, "label": "..." }`.
//! 3. Any boolean detection field listed in `bool_detection_fields` (e.g.
//!    `{ "contains_pii": true }`) — true ⇒ deny, false ⇒ allow.
//!
//! Hosts wanting deeper AACS support (per-category severity thresholds)
//! should implement [`crate::runtime::hooks::DelegateDispatcher`]
//! directly.

use std::collections::HashMap;
use std::sync::Arc;

use serde_json::{json, Value};

use crate::configurations::{ConfigurationType, ShieldConfiguration};
use crate::resolver::{ResolverDecision, ResolverResponse};
use crate::resolver_runtime::{
    classifier_score_to_envelope, DelegateDispatcher, DelegateRequest, ResolverRuntimeError,
};

/// Default delegate dispatcher (§11.10.3 / §11.12).
///
/// Routes by `configuration.config_type`:
/// - `HttpEndpoint` → HTTP POST (feature-gated)
/// - `Classifier`   → HTTP POST + classifier envelope folding
/// - `McpServer`    → fail-closed (host must register a transport)
/// - `A2aAgent`     → fail-closed (host must register a transport)
/// - `Llm`          → fail-closed (wrong kind)
pub struct DefaultDelegateDispatcher {
    /// Whether to consider truthy-boolean fields in classifier responses
    /// as `Deny`. The spec §11.12.4 mandates this for AACS-style
    /// classifiers; hosts may disable for stricter envelope-only
    /// parsing.
    pub bool_detection_fields: Vec<String>,
}

impl Default for DefaultDelegateDispatcher {
    fn default() -> Self {
        Self {
            bool_detection_fields: vec![
                "contains_pii".into(),
                "is_jailbreak".into(),
                "flagged".into(),
                "blocked".into(),
                "detected".into(),
            ],
        }
    }
}

impl DefaultDelegateDispatcher {
    /// Construct a new dispatcher with the spec defaults.
    pub fn new() -> Self {
        Self::default()
    }

    /// Wrap in an [`Arc`] so the builder can register it as
    /// `Arc<dyn DelegateDispatcher>`.
    pub fn shared() -> Arc<Self> {
        Arc::new(Self::default())
    }
}

impl DelegateDispatcher for DefaultDelegateDispatcher {
    fn dispatch(&self, req: DelegateRequest) -> Result<ResolverResponse, ResolverRuntimeError> {
        match req.configuration.config_type {
            ConfigurationType::HttpEndpoint => self.dispatch_http_envelope(&req),
            ConfigurationType::Classifier => self.dispatch_classifier(&req),
            ConfigurationType::McpServer => Err(ResolverRuntimeError::MissingHook {
                kind: "delegate",
                hook: "mcp_server transport not registered — register a custom DelegateDispatcher",
            }),
            ConfigurationType::A2aAgent => Err(ResolverRuntimeError::MissingHook {
                kind: "delegate",
                hook: "a2a_agent transport not registered — register a custom DelegateDispatcher",
            }),
            ConfigurationType::Llm => Err(ResolverRuntimeError::WrongConfigurationType {
                id: req.configuration.id.clone(),
                actual: "llm".into(),
                expected: "http_endpoint|classifier|mcp_server|a2a_agent".into(),
            }),
        }
    }
}

// ── HTTP envelope path ──────────────────────────────────────────────

impl DefaultDelegateDispatcher {
    /// Build the §11.12.1 request envelope as a JSON value. Pulled out
    /// for unit testing — the body bytes the host actually sends are
    /// `serde_json::to_vec(&self.build_envelope(req))`.
    pub(crate) fn build_envelope(&self, req: &DelegateRequest) -> Value {
        let mut body = serde_json::Map::new();
        body.insert("request_id".into(), Value::String(req.request_id.clone()));
        body.insert(
            "configuration_id".into(),
            Value::String(req.configuration.id.clone()),
        );
        if let Some(v) = &req.variable {
            body.insert("variable".into(), Value::String(v.clone()));
        }
        body.insert(
            "prompt".into(),
            req.prompt
                .as_ref()
                .map(|p| Value::String(p.clone()))
                .unwrap_or(Value::Null),
        );
        if let Some(r) = &req.reason {
            body.insert("reason".into(), Value::String(r.clone()));
        }
        body.insert("context".into(), Value::Object(req.context.clone()));
        if let Some(p) = &req.invocation_params {
            body.insert("invocation_params".into(), p.clone());
        }
        if let Some(rk) = &req.resource_kind {
            body.insert(
                "resource_kind".into(),
                Value::String(format!("{:?}", rk).to_lowercase()),
            );
        }
        if let Some(rn) = &req.resource_name {
            body.insert("resource_name".into(), Value::String(rn.clone()));
        }
        // §9.4 / §11.12.1: keyed-variable resolutions surface the
        // resolved key as `requested_key` so the delegate knows which
        // key the gate was probing and stores the response under it.
        if let Some(rk) = &req.requested_key {
            body.insert("requested_key".into(), rk.clone());
        }
        Value::Object(body)
    }

    /// Construct the headers map. Per §6.4, headers whose names match
    /// the auth-header denylist (`Authorization`, `X-API-Key`, etc.)
    /// MUST cause the call to fail rather than emit an empty value.
    /// The loader already enforces this for `${...}` interpolation;
    /// here we re-check the post-interpolation values just in case the
    /// host registered raw empty-string headers.
    pub(crate) fn build_headers(
        &self,
        config: &ShieldConfiguration,
    ) -> Result<HashMap<String, String>, ResolverRuntimeError> {
        let mut out: HashMap<String, String> = HashMap::with_capacity(config.headers.len() + 1);
        for (k, v) in &config.headers {
            if v.is_empty() && is_sensitive_header(k) {
                return Err(ResolverRuntimeError::Other {
                    kind: "delegate",
                    message: format!(
                        "header `{}` is empty after interpolation — refusing to send unauthenticated request",
                        k
                    ),
                });
            }
            out.insert(k.clone(), v.clone());
        }
        if !out.contains_key("Content-Type") && !out.contains_key("content-type") {
            out.insert("Content-Type".into(), "application/json".into());
        }
        Ok(out)
    }

    fn dispatch_http_envelope(
        &self,
        req: &DelegateRequest,
    ) -> Result<ResolverResponse, ResolverRuntimeError> {
        #[cfg(not(feature = "http"))]
        {
            let _ = req; // silence unused in no-http builds
            return Err(ResolverRuntimeError::Transport {
                kind: "delegate",
                message: "agent_shield_core compiled without `http` feature".into(),
            });
        }
        #[cfg(feature = "http")]
        {
            let endpoint = req.configuration.endpoint.as_deref().ok_or_else(|| {
                ResolverRuntimeError::Other {
                    kind: "delegate",
                    message: "http_endpoint configuration missing `endpoint`".into(),
                }
            })?;

            let headers = self.build_headers(&req.configuration)?;
            let body = self.build_envelope(req);

            let resp_text = http_post_json(endpoint, &body, &headers, req.effective_timeout_ms)?;

            // Parse as ResolverResponse first; fall back to the
            // classifier shape on parse failure for hosts that wire an
            // http_endpoint configuration to a classifier-style remote.
            if let Ok(rr) = serde_json::from_str::<ResolverResponse>(&resp_text) {
                return Ok(rr);
            }

            let raw: Value = serde_json::from_str(&resp_text).map_err(|e| {
                ResolverRuntimeError::InvalidResponse {
                    kind: "delegate",
                    message: format!("response is not JSON: {}", e),
                }
            })?;
            Ok(self.fold_loose_response(&raw, &req.configuration))
        }
    }
}

// ── Classifier path ─────────────────────────────────────────────────

impl DefaultDelegateDispatcher {
    fn dispatch_classifier(
        &self,
        req: &DelegateRequest,
    ) -> Result<ResolverResponse, ResolverRuntimeError> {
        #[cfg(not(feature = "http"))]
        {
            let _ = req;
            return Err(ResolverRuntimeError::Transport {
                kind: "delegate",
                message: "classifier requires `http` feature".into(),
            });
        }
        #[cfg(feature = "http")]
        {
            let endpoint = req.configuration.endpoint.as_deref().ok_or_else(|| {
                ResolverRuntimeError::Other {
                    kind: "delegate",
                    message: "classifier configuration missing `endpoint`".into(),
                }
            })?;

            let headers = self.build_headers(&req.configuration)?;

            // Classifier subject — by §11.12.4 we send `{"input": <prompt-or-stringified-params>}`.
            let subject = req
                .prompt
                .clone()
                .or_else(|| req.invocation_params.as_ref().map(stringify_value))
                .unwrap_or_default();
            let body = json!({ "input": subject });

            let resp_text = http_post_json(endpoint, &body, &headers, req.effective_timeout_ms)?;

            let raw: Value = serde_json::from_str(&resp_text).map_err(|e| {
                ResolverRuntimeError::InvalidResponse {
                    kind: "delegate",
                    message: format!("classifier response is not JSON: {}", e),
                }
            })?;

            Ok(self.fold_loose_response(&raw, &req.configuration))
        }
    }

    /// Take an arbitrary classifier-style JSON object and produce a
    /// `ResolverResponse` per the AACS-compatible §11.12.4 folding
    /// rules.
    fn fold_loose_response(&self, raw: &Value, config: &ShieldConfiguration) -> ResolverResponse {
        // 1. {decision, ...} envelope shape.
        if let Some(obj) = raw.as_object() {
            if obj.contains_key("decision") {
                if let Ok(rr) = serde_json::from_value::<ResolverResponse>(raw.clone()) {
                    return rr;
                }
            }
        }

        // 2. Boolean-detection shape.
        if let Some(obj) = raw.as_object() {
            for k in &self.bool_detection_fields {
                if let Some(Value::Bool(true)) = obj.get(k) {
                    return ResolverResponse {
                        decision: ResolverDecision::Deny,
                        value: Some(Value::Bool(false)),
                        set_variables: HashMap::new(),
                        reason: Some(format!("classifier field `{}` is true", k)),
                    };
                }
                if let Some(Value::Bool(false)) = obj.get(k) {
                    return ResolverResponse {
                        decision: ResolverDecision::Allow,
                        value: Some(Value::Bool(true)),
                        set_variables: HashMap::new(),
                        reason: Some(format!("classifier field `{}` is false", k)),
                    };
                }
            }
        }

        // 3. score+threshold shape.
        let threshold = config.threshold.unwrap_or(0.5);
        if let Some(score) = raw
            .get("score")
            .and_then(Value::as_f64)
            .or_else(|| raw.get("severity").and_then(Value::as_f64))
        {
            let label = raw
                .get("label")
                .or_else(|| raw.get("category"))
                .and_then(Value::as_str);
            return classifier_score_to_envelope(score, threshold, label);
        }

        // 4. AACS-compatible categoriesAnalysis array — fold to max
        //    severity / 6.0 against the configured threshold.
        if let Some(arr) = raw.get("categoriesAnalysis").and_then(Value::as_array) {
            let mut max_sev: f64 = 0.0;
            let mut category_label: Option<String> = None;
            for cat in arr {
                if let Some(s) = cat.get("severity").and_then(Value::as_f64) {
                    if s > max_sev {
                        max_sev = s;
                        category_label = cat
                            .get("category")
                            .and_then(Value::as_str)
                            .map(String::from);
                    }
                }
            }
            let normalized = (max_sev / 6.0).min(1.0);
            return classifier_score_to_envelope(normalized, threshold, category_label.as_deref());
        }

        // Fail closed when the response shape is unrecognized.
        ResolverResponse {
            decision: ResolverDecision::Deny,
            value: Some(Value::Bool(false)),
            set_variables: HashMap::new(),
            reason: Some(
                "default delegate dispatcher: classifier response shape not recognized — failing closed".into(),
            ),
        }
    }
}

// ── Helpers ─────────────────────────────────────────────────────────

fn is_sensitive_header(name: &str) -> bool {
    matches!(
        name.to_ascii_lowercase().as_str(),
        "authorization" | "x-api-key" | "x-auth-token" | "cookie"
    )
}

fn stringify_value(v: &Value) -> String {
    match v {
        Value::String(s) => s.clone(),
        other => other.to_string(),
    }
}

/// Sync HTTP POST built on the async [`reqwest::Client`] plus a private
/// single-thread tokio runtime. The crate's existing reqwest dependency
/// pins `default-features=false` with only `json + rustls-tls`, so the
/// `blocking` client isn't available. We bridge async → sync via a
/// runtime owned by this dispatcher's call site to avoid pulling in
/// new dependencies.
///
/// The runtime is created per call. That's not free, but the delegate
/// dispatch is already a network round-trip; the runtime construction
/// cost is dwarfed by the I/O. Hosts that need very high throughput
/// SHOULD register a custom [`DelegateDispatcher`] backed by a shared
/// async runtime.
#[cfg(feature = "http")]
fn http_post_json(
    endpoint: &str,
    body: &Value,
    headers: &HashMap<String, String>,
    timeout_ms: u32,
) -> Result<String, ResolverRuntimeError> {
    use std::time::Duration;

    let rt = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .map_err(|e| ResolverRuntimeError::Transport {
            kind: "delegate",
            message: format!("tokio runtime build: {}", e),
        })?;

    rt.block_on(async move {
        let client = reqwest::Client::builder()
            .timeout(Duration::from_millis(timeout_ms.max(1) as u64))
            .build()
            .map_err(|e| ResolverRuntimeError::Transport {
                kind: "delegate",
                message: format!("client build: {}", e),
            })?;

        let mut req = client.post(endpoint).json(body);
        for (k, v) in headers {
            req = req.header(k, v);
        }
        let resp = req.send().await.map_err(|e| {
            if e.is_timeout() {
                ResolverRuntimeError::Timeout {
                    kind: "delegate",
                    timeout_ms,
                }
            } else {
                ResolverRuntimeError::Transport {
                    kind: "delegate",
                    message: e.to_string(),
                }
            }
        })?;
        let status = resp.status();
        let text = resp
            .text()
            .await
            .map_err(|e| ResolverRuntimeError::Transport {
                kind: "delegate",
                message: format!("response read: {}", e),
            })?;
        if !status.is_success() {
            return Err(ResolverRuntimeError::Transport {
                kind: "delegate",
                message: format!("HTTP {} from delegate: {}", status.as_u16(), text),
            });
        }
        Ok::<_, ResolverRuntimeError>(text)
    })
}
