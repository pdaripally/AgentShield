//! YAML-driven auto-wired [`LlmCaller`].
//!
//! [`LlmCaller`](crate::guard_policy_runtime::LlmCaller) is a single
//! multiplexer: every `evaluate_when[].llm` site supplies a
//! `configuration_id` and the caller routes to the matching `configurations[]`
//! entry. This module provides a host-implementation-free default that:
//!
//! 1. Snapshots all `type: llm` configurations at build time.
//! 2. Resolves API keys from `api_key_env` once; missing-env entries are
//!    skipped (and the runtime falls back to the engine's fail-closed path
//!    for those configuration ids). Exception: providers that run
//!    unauthenticated by default (currently Ollama) accept entries
//!    without `api_key_env`.
//! 3. Dispatches per-call to OpenAI-compatible (OpenAI / Azure OpenAI /
//!    Google Gemini / Ollama) or Anthropic HTTP endpoints.
//!
//! Bedrock is recognized as a provider name but **not** auto-wired: AWS
//! SigV4 signing is intentionally not pulled into the core crate. The
//! resolver skips Bedrock entries with a warning log that points the
//! user at the alternative paths (the `agent_shield_anthropic` adapter
//! with an `AnthropicBedrock` client, or the Python adapter via LiteLLM
//! `bedrock/...` model strings).
//!
//! Every error path — unknown configuration id, unsupported provider,
//! missing model, HTTP failure, malformed body — returns `Err(reason)`,
//! which the engine folds into `BLOCK` per §12.9.3 ¶3.
//!
//! Auto-wiring is engaged only when the host did not call
//! [`crate::runtime::RuntimeBuilder::register_llm_caller`] explicitly,
//! and only when `feature = "http"` is on. With the feature off, this
//! module compiles to a stub and the builder leaves `llm_caller = None`
//! so the engine's fail-closed path runs.

#[cfg(feature = "http")]
use std::collections::HashMap;
#[cfg(feature = "http")]
use std::time::Duration;

#[cfg(feature = "http")]
use serde_json::{json, Value};

#[cfg(feature = "http")]
use crate::configurations::{ConfigurationType, ShieldConfiguration};
#[cfg(feature = "http")]
use crate::guard_policy_runtime::{LlmCaller, LlmDecision, LlmResponse};

#[cfg(feature = "http")]
const DEFAULT_OPENAI_ENDPOINT: &str = "https://api.openai.com/v1/chat/completions";
#[cfg(feature = "http")]
const DEFAULT_ANTHROPIC_ENDPOINT: &str = "https://api.anthropic.com/v1/messages";
#[cfg(feature = "http")]
const DEFAULT_ANTHROPIC_API_VERSION: &str = "2023-06-01";
/// Google's OpenAI-compatible Gemini endpoint. The Google AI Studio
/// REST API exposes an OpenAI-compatible surface at this path; requests
/// use the same `{model, messages, ...}` chat-completions body that
/// OpenAI accepts and Bearer auth with a Google API key.
#[cfg(feature = "http")]
const DEFAULT_GEMINI_ENDPOINT: &str =
    "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions";
/// Default Ollama loopback endpoint. Ollama exposes an OpenAI-compatible
/// chat-completions API at `/v1/chat/completions` (Ollama ≥ 0.1.30).
/// The `OLLAMA_HOST` env var (or configuration `endpoint:`) overrides
/// the base URL; when only a base URL is supplied (no path), the path
/// `/v1/chat/completions` is appended automatically.
#[cfg(feature = "http")]
const DEFAULT_OLLAMA_BASE: &str = "http://localhost:11434";
#[cfg(feature = "http")]
const OLLAMA_CHAT_PATH: &str = "/v1/chat/completions";
#[cfg(feature = "http")]
const DEFAULT_LLM_TIMEOUT: Duration = Duration::from_secs(30);
/// Anthropic requires `max_tokens`. Used when the configuration omits it.
#[cfg(feature = "http")]
const ANTHROPIC_DEFAULT_MAX_TOKENS: u32 = 1024;

/// Snapshot of one resolved LLM configuration — model + credential
/// already validated.
///
/// `api_key` is `Option`-typed because some providers (notably the
/// default Ollama loopback) run without auth. Auth-required providers
/// (OpenAI / Azure / Anthropic / Gemini) fail at `resolve()` time when
/// `api_key_env` is unset, so by the time we reach `call_*`, an
/// `Option::None` means "this provider explicitly does not require
/// auth" rather than "we forgot to look one up."
#[cfg(feature = "http")]
#[derive(Debug, Clone)]
struct ResolvedLlmConfig {
    provider: Provider,
    model: String,
    api_key: Option<String>,
    endpoint: String,
    max_tokens: u32,
    api_version: String,
}

#[cfg(feature = "http")]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Provider {
    OpenAi,
    Azure,
    Anthropic,
    /// Google Gemini via the OpenAI-compatible REST endpoint at
    /// `generativelanguage.googleapis.com/v1beta/openai/`. Body and
    /// auth follow the OpenAI chat-completions shape — Bearer auth
    /// with a Google API key. Vertex AI (the GCP-IAM-authenticated
    /// path) is intentionally not handled here; customers needing
    /// Vertex configure a custom `LlmCaller` via
    /// `RuntimeBuilder::register_llm_caller`.
    Gemini,
    /// Locally-hosted Llama / Mistral / etc. through Ollama. Ollama
    /// exposes an OpenAI-compatible `/v1/chat/completions` endpoint
    /// (Ollama ≥ 0.1.30) and runs without auth by default, so
    /// `api_key_env` is optional for this provider.
    Ollama,
    /// Recognized but **not auto-wired**: AWS Bedrock requires SigV4
    /// signing which the auto-wired caller intentionally does not pull
    /// into the core crate. Customers route Bedrock through either
    /// (a) the `agent_shield_anthropic` adapter with an
    /// `AnthropicBedrock` client, or (b) the Python `crewai` adapter
    /// via LiteLLM model strings like `bedrock/anthropic.claude-...`.
    /// `resolve()` skips Bedrock entries with a logged warning that
    /// names the alternative.
    Bedrock,
}

#[cfg(feature = "http")]
impl Provider {
    /// Parse a `configurations[].provider` value.
    ///
    /// Both short names (`openai`, `gemini`, `ollama`, `bedrock`, …)
    /// and the spec §6.5 reverse-domain forms (`openai.chat`,
    /// `anthropic.claude`, `google.gemini`, `meta.ollama`,
    /// `amazon.bedrock`, `microsoft.azure.openai`) are accepted —
    /// docs/examples canonicalize on reverse-domain, the short names
    /// exist because they shipped in v0.x before the spec adopted
    /// reverse-domain.
    fn parse(s: &str) -> Option<Self> {
        match s.to_lowercase().as_str() {
            "openai" | "openai.chat" => Some(Self::OpenAi),
            "azure" | "azure_openai" | "microsoft.azure.openai" => Some(Self::Azure),
            "anthropic" | "anthropic.claude" => Some(Self::Anthropic),
            "gemini" | "google.gemini" => Some(Self::Gemini),
            "ollama" | "meta.ollama" => Some(Self::Ollama),
            "bedrock" | "amazon.bedrock" => Some(Self::Bedrock),
            _ => None,
        }
    }

    /// True iff this provider sends the OpenAI chat-completions body
    /// shape (`{model, messages, max_tokens?}`) and bearer auth. Used
    /// to route in [`AutoWiredLlmCaller::call`].
    fn is_openai_compatible(self) -> bool {
        matches!(
            self,
            Self::OpenAi | Self::Azure | Self::Gemini | Self::Ollama
        )
    }
}

/// Built-in [`LlmCaller`] that dispatches to OpenAI / Azure OpenAI /
/// Anthropic / Google Gemini / Ollama over HTTP based on the §6.2
/// `configurations[]` block. Bedrock is recognized but routed through
/// the host LLM caller path (`register_llm_caller`) — see module docs.
///
/// See module docs for behavior. Unknown configuration ids and any
/// transport / parse failure return `Err`, which folds to `BLOCK`.
#[cfg(feature = "http")]
pub struct AutoWiredLlmCaller {
    configs: HashMap<String, ResolvedLlmConfig>,
    transport: Box<dyn HttpTransport + Send + Sync>,
}

#[cfg(feature = "http")]
impl AutoWiredLlmCaller {
    /// Snapshot the LLM configurations from a merged config. Entries
    /// with an unsupported provider, missing model, or unset
    /// `api_key_env` (for providers that require auth) are silently
    /// skipped — the runtime will fail closed for those ids when
    /// invoked.
    pub fn from_configurations(configurations: &[ShieldConfiguration]) -> Self {
        let mut configs = HashMap::new();
        for cfg in configurations {
            if cfg.config_type != ConfigurationType::Llm {
                continue;
            }
            if let Some(resolved) = resolve(cfg) {
                configs.insert(cfg.id.clone(), resolved);
            }
        }
        Self {
            configs,
            transport: Box::new(ReqwestTransport),
        }
    }

    /// Returns `true` if at least one LLM configuration was resolved
    /// (used by the builder to decide whether to install this caller
    /// instead of `FailClosedLlmCaller`).
    pub fn has_any(&self) -> bool {
        !self.configs.is_empty()
    }

    /// Test seam: replace the HTTP transport. Production callers use
    /// the `reqwest`-backed default installed by
    /// [`Self::from_configurations`]; tests install an in-memory
    /// transport to assert outbound request shape without touching
    /// the network.
    #[cfg(test)]
    fn with_transport(mut self, transport: Box<dyn HttpTransport + Send + Sync>) -> Self {
        self.transport = transport;
        self
    }
}

#[cfg(feature = "http")]
impl LlmCaller for AutoWiredLlmCaller {
    fn call(&self, configuration_id: Option<&str>, prompt: &str) -> Result<LlmResponse, String> {
        let Some(id) = configuration_id else {
            return Err("auto-wired LLM caller requires a configuration_id".into());
        };
        let Some(cfg) = self.configs.get(id) else {
            return Err(format!(
                "no resolved LLM configuration for id '{id}' (missing model, provider, or api_key_env)"
            ));
        };

        let raw_text = if cfg.provider.is_openai_compatible() {
            call_openai(cfg, prompt, self.transport.as_ref())?
        } else if cfg.provider == Provider::Anthropic {
            call_anthropic(cfg, prompt, self.transport.as_ref())?
        } else {
            // Bedrock and any future recognized-but-unsupported
            // provider land here. `resolve()` should have skipped
            // these entries, so reaching this branch means the
            // configuration was constructed by some path other than
            // `from_configurations` — fail closed loudly.
            return Err(format!(
                "auto-wired LLM caller does not route provider '{:?}'; \
                 configure a custom LlmCaller via \
                 RuntimeBuilder::register_llm_caller (Bedrock: use \
                 agent_shield_anthropic with an AnthropicBedrock client, \
                 or the Python adapter via LiteLLM)",
                cfg.provider
            ));
        };

        Ok(parse_llm_text(&raw_text))
    }
}

// ── Resolution ─────────────────────────────────────────────────────

#[cfg(feature = "http")]
fn resolve(cfg: &ShieldConfiguration) -> Option<ResolvedLlmConfig> {
    let provider_str = cfg.provider.as_deref().unwrap_or("");
    let Some(provider) = Provider::parse(provider_str) else {
        if !provider_str.is_empty() {
            log::debug!(
                "[agent-shield] LLM configuration '{}' uses unsupported provider '{}' — auto-wire skipped",
                cfg.id,
                provider_str
            );
        }
        return None;
    };

    if provider == Provider::Bedrock {
        log::warn!(
            "[agent-shield] LLM configuration '{}' uses provider 'amazon.bedrock' — the auto-wired \
             caller does not sign AWS SigV4 requests; install a custom LlmCaller via \
             RuntimeBuilder::register_llm_caller (Anthropic-on-Bedrock: agent_shield_anthropic with \
             AnthropicBedrock client; Llama/Mistral on Bedrock: Python adapter via LiteLLM \
             'bedrock/...' model strings). Auto-wire skipped.",
            cfg.id
        );
        return None;
    }

    let model = cfg.model.as_deref().unwrap_or("").trim();
    if model.is_empty() {
        log::warn!(
            "[agent-shield] LLM configuration '{}' has no model — auto-wire skipped",
            cfg.id
        );
        return None;
    }

    // Auth resolution: Ollama runs unauthenticated by default
    // (loopback). Every other supported provider requires an API key.
    //
    // We trim env-var values: a whitespace-only `OPENAI_API_KEY="   "`
    // (the kind of thing copy-pasted .env files produce) MUST NOT be
    // accepted as a real credential. Treating it as unset matches
    // the empty-string treatment elsewhere in the resolver and makes
    // the failure surface as "configuration skipped, fail closed at
    // call time" instead of "provider returns 401 from a header full
    // of whitespace."
    let api_key_env = cfg.api_key_env.as_deref().unwrap_or("").trim();
    let api_key: Option<String> = if api_key_env.is_empty() {
        if provider == Provider::Ollama {
            None
        } else {
            log::debug!(
                "[agent-shield] LLM configuration '{}' has no api_key_env — auto-wire skipped",
                cfg.id
            );
            return None;
        }
    } else {
        let resolved = std::env::var(api_key_env)
            .ok()
            .map(|s| s.trim().to_owned())
            .filter(|s| !s.is_empty());
        match resolved {
            Some(k) => Some(k),
            None => {
                if provider == Provider::Ollama {
                    // Ollama declared `api_key_env` but the env var is
                    // unset, empty, or whitespace-only. Treat as
                    // unauthenticated rather than skip, so a
                    // misconfigured env var doesn't take the loopback
                    // path off the air.
                    log::debug!(
                        "[agent-shield] env var '{}' for Ollama LLM configuration '{}' not set or whitespace-only — \
                         continuing without auth header (Ollama loopback)",
                        api_key_env,
                        cfg.id
                    );
                    None
                } else {
                    log::debug!(
                        "[agent-shield] env var '{}' for LLM configuration '{}' not set or whitespace-only — auto-wire skipped",
                        api_key_env,
                        cfg.id
                    );
                    return None;
                }
            }
        }
    };

    let endpoint = match (provider, cfg.endpoint.as_deref().unwrap_or("")) {
        (Provider::OpenAi, "") => DEFAULT_OPENAI_ENDPOINT.to_string(),
        (Provider::Anthropic, "") => DEFAULT_ANTHROPIC_ENDPOINT.to_string(),
        (Provider::Gemini, "") => DEFAULT_GEMINI_ENDPOINT.to_string(),
        (Provider::Ollama, "") => {
            // OLLAMA_HOST is canonical (Ollama's own SDK reads it the
            // same way). Treat the value as a base URL and append the
            // chat-completions path when the user only supplied a
            // host (no path). Empty AND whitespace-only values are
            // treated as unset so an `OLLAMA_HOST="   "` (the kind of
            // thing copy-pasted .env files produce) falls through to
            // the loopback default instead of being trimmed to ""
            // and producing the invalid endpoint `/v1/chat/completions`.
            let base = std::env::var("OLLAMA_HOST")
                .ok()
                .map(|s| s.trim().to_owned())
                .filter(|s| !s.is_empty())
                .unwrap_or_else(|| DEFAULT_OLLAMA_BASE.to_string());
            normalize_ollama_endpoint(&base)
        }
        (Provider::Azure, "") => match std::env::var("AZURE_OPENAI_ENDPOINT") {
            Ok(e) if !e.trim().is_empty() => e.trim().to_string(),
            _ => {
                log::warn!(
                    "[agent-shield] LLM configuration '{}' is azure but no endpoint and AZURE_OPENAI_ENDPOINT unset — auto-wire skipped",
                    cfg.id
                );
                return None;
            }
        },
        (Provider::Ollama, e) => normalize_ollama_endpoint(e),
        (_, e) => e.to_string(),
    };

    let api_version = cfg
        .metadata
        .as_ref()
        .and_then(|m| m.get("api_version"))
        .and_then(|v| v.as_str())
        .unwrap_or(DEFAULT_ANTHROPIC_API_VERSION)
        .to_string();

    let max_tokens = cfg.max_tokens.unwrap_or(0);
    let max_tokens = if provider == Provider::Anthropic && max_tokens == 0 {
        ANTHROPIC_DEFAULT_MAX_TOKENS
    } else {
        max_tokens
    };

    Some(ResolvedLlmConfig {
        provider,
        model: model.to_string(),
        api_key,
        endpoint,
        max_tokens,
        api_version,
    })
}

/// Append `/v1/chat/completions` to an Ollama endpoint when the caller
/// only supplied a base host. Customers expect `OLLAMA_HOST` to behave
/// like the official Ollama SDK does (host-shaped), but our HTTP
/// transport needs a full URL.
///
/// The function handles three input shapes:
/// 1. **Bare host** (`http://localhost:11434`, with or without a
///    trailing slash) → append `/v1/chat/completions`.
/// 2. **Base with `/v1`** (`http://localhost:11434/v1`, with or
///    without a trailing slash) → append `/chat/completions`. The
///    explicit branch avoids the duplicated-`/v1/` bug that a naive
///    substring check would produce for `http://x/v1/`.
/// 3. **Full URL** (anything ending with `/chat/completions`) → use
///    as-is after stripping any trailing slash.
#[cfg(feature = "http")]
fn normalize_ollama_endpoint(value: &str) -> String {
    let trimmed = value.trim_end_matches('/');
    if trimmed.ends_with("/chat/completions") {
        return trimmed.to_string();
    }
    if trimmed.ends_with("/v1") {
        return format!("{trimmed}/chat/completions");
    }
    format!("{trimmed}{OLLAMA_CHAT_PATH}")
}

// ── HTTP transport ─────────────────────────────────────────────────

#[cfg(feature = "http")]
fn call_openai(
    cfg: &ResolvedLlmConfig,
    prompt: &str,
    transport: &(dyn HttpTransport + Send + Sync),
) -> Result<String, String> {
    let mut body = json!({
        "model": cfg.model,
        "messages": [{"role": "user", "content": prompt}],
    });
    if cfg.max_tokens > 0 {
        body["max_tokens"] = json!(cfg.max_tokens);
    }

    let mut headers = HashMap::new();
    match (cfg.provider, cfg.api_key.as_deref()) {
        // Azure uses `api-key:` header, not Bearer.
        (Provider::Azure, Some(key)) => {
            headers.insert("api-key".to_string(), key.to_string());
        }
        // OpenAI / Gemini / Ollama (when authenticated) use Bearer.
        (_, Some(key)) => {
            headers.insert("Authorization".to_string(), format!("Bearer {key}"));
        }
        // Unauthenticated path (Ollama loopback). No auth header at
        // all — sending `Bearer ` with an empty key would 401 against
        // some Ollama gateways that strictly parse the header.
        (_, None) => {}
    }
    headers.insert("Content-Type".to_string(), "application/json".to_string());

    let text = transport.post_json(&cfg.endpoint, &body, &headers)?;
    let json: Value = serde_json::from_str(&text).map_err(|e| {
        format!(
            "OpenAI JSON parse error: {e}: body={}",
            truncate(&text, 200)
        )
    })?;

    json.get("choices")
        .and_then(|c| c.get(0))
        .and_then(|c| c.get("message"))
        .and_then(|m| m.get("content"))
        .and_then(|c| c.as_str())
        .filter(|s| !s.is_empty())
        .map(|s| s.to_string())
        .ok_or_else(|| {
            "OpenAI response has no text content (refusal, tool_call, or content filter)".into()
        })
}

#[cfg(feature = "http")]
fn call_anthropic(
    cfg: &ResolvedLlmConfig,
    prompt: &str,
    transport: &(dyn HttpTransport + Send + Sync),
) -> Result<String, String> {
    let body = json!({
        "model": cfg.model,
        "max_tokens": cfg.max_tokens,
        "messages": [{"role": "user", "content": prompt}],
    });

    // Anthropic always requires an API key — `resolve()` enforced
    // this. Treat a missing key as a hard error to surface the
    // invariant rather than silently sending an unauthenticated
    // request that would 401.
    let Some(key) = cfg.api_key.as_deref() else {
        return Err("Anthropic LLM configuration is missing an API key".into());
    };

    let mut headers = HashMap::new();
    headers.insert("x-api-key".to_string(), key.to_string());
    headers.insert("anthropic-version".to_string(), cfg.api_version.clone());
    headers.insert("Content-Type".to_string(), "application/json".to_string());

    let text = transport.post_json(&cfg.endpoint, &body, &headers)?;
    let json: Value = serde_json::from_str(&text).map_err(|e| {
        format!(
            "Anthropic JSON parse error: {e}: body={}",
            truncate(&text, 200)
        )
    })?;

    json.get("content")
        .and_then(|c| c.as_array())
        .and_then(|blocks| {
            blocks.iter().find_map(|block| {
                if block.get("type").and_then(|t| t.as_str()) == Some("text") {
                    block.get("text").and_then(|t| t.as_str())
                } else {
                    None
                }
            })
        })
        .filter(|s| !s.is_empty())
        .map(|s| s.to_string())
        .ok_or_else(|| "Anthropic response has no text content (tool_use or empty)".into())
}

// ── HTTP transport seam ────────────────────────────────────────────
//
// `HttpTransport` is the indirection layer that lets unit tests assert
// outbound request shape (endpoint, headers, body) without hitting
// the network. Production code uses [`ReqwestTransport`]; tests use
// an in-memory transport (see the test module below).

/// Pluggable HTTP transport for the auto-wired LLM caller.
///
/// Implementations receive the canonical OpenAI-/Anthropic-shaped
/// JSON body, the destination URL, and the header map already built
/// by `call_openai` / `call_anthropic`. The transport's only job is
/// to send the request and return the raw response body as a string;
/// JSON parsing and decision folding happen in the caller.
#[cfg(feature = "http")]
trait HttpTransport {
    fn post_json(
        &self,
        endpoint: &str,
        body: &Value,
        headers: &HashMap<String, String>,
    ) -> Result<String, String>;
}

/// Default `reqwest`-backed transport. Builds a single-threaded tokio
/// runtime per call (the LLM-caller protocol is synchronous so we
/// cannot share an outer runtime), times out per
/// [`DEFAULT_LLM_TIMEOUT`], and returns the response body verbatim.
#[cfg(feature = "http")]
struct ReqwestTransport;

#[cfg(feature = "http")]
impl HttpTransport for ReqwestTransport {
    fn post_json(
        &self,
        endpoint: &str,
        body: &Value,
        headers: &HashMap<String, String>,
    ) -> Result<String, String> {
        let rt = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .map_err(|e| format!("tokio runtime build: {e}"))?;

        rt.block_on(async move {
            let client = reqwest::Client::builder()
                .timeout(DEFAULT_LLM_TIMEOUT)
                .build()
                .map_err(|e| format!("reqwest client build: {e}"))?;

            let mut req = client.post(endpoint).json(body);
            for (k, v) in headers {
                req = req.header(k, v);
            }
            let resp = req
                .send()
                .await
                .map_err(|e| format!("LLM HTTP send error: {e}"))?;
            let status = resp.status();
            let text = resp
                .text()
                .await
                .map_err(|e| format!("LLM HTTP read error: {e}"))?;
            if !status.is_success() {
                return Err(format!(
                    "LLM HTTP {} response: {}",
                    status.as_u16(),
                    truncate(&text, 200)
                ));
            }
            Ok(text)
        })
    }
}

// ── Response folding ───────────────────────────────────────────────

/// Heuristically map a free-form LLM response into [`LlmResponse`].
///
/// The §12.9.3 contract is that the LLM returns either a structured
/// JSON envelope (preferred) or a free-form decision keyword. We honor
/// both shapes. Fail-closed default is `BLOCK` if neither is parsable.
#[cfg(feature = "http")]
fn parse_llm_text(text: &str) -> LlmResponse {
    if let Ok(json) = serde_json::from_str::<Value>(text.trim()) {
        let decision = json
            .get("decision")
            .and_then(|d| d.as_str())
            .map(|s| s.to_ascii_uppercase());
        let folded = match decision.as_deref() {
            Some("ALLOW") | Some("PASS") => Some(LlmDecision::Allow),
            Some("BLOCK") | Some("DENY") | Some("FAIL") => Some(LlmDecision::Block),
            _ => None,
        };
        let mut bool_flags = HashMap::new();
        if let Some(obj) = json.as_object() {
            for (k, v) in obj {
                if let Some(b) = v.as_bool() {
                    bool_flags.insert(k.clone(), b);
                }
            }
        }
        return LlmResponse {
            decision: folded,
            confidence: json.get("confidence").and_then(|v| v.as_f64()),
            reason: json
                .get("reason")
                .and_then(|v| v.as_str())
                .map(|s| s.to_string()),
            categories: json
                .get("categories")
                .and_then(|c| c.as_array())
                .map(|arr| {
                    arr.iter()
                        .filter_map(|v| v.as_str().map(|s| s.to_string()))
                        .collect()
                })
                .unwrap_or_default(),
            spans: Vec::new(),
            bool_flags,
        };
    }

    // Free-form keyword fallback.
    let upper = text.trim().to_ascii_uppercase();
    let decision = if upper.starts_with("ALLOW") || upper.starts_with("PASS") {
        Some(LlmDecision::Allow)
    } else if upper.starts_with("BLOCK") || upper.starts_with("DENY") || upper.starts_with("FAIL") {
        Some(LlmDecision::Block)
    } else {
        None
    };
    LlmResponse {
        decision,
        confidence: None,
        reason: Some(truncate(text, 200)),
        categories: Vec::new(),
        spans: Vec::new(),
        bool_flags: HashMap::new(),
    }
}

#[cfg(feature = "http")]
fn truncate(s: &str, n: usize) -> String {
    if s.len() <= n {
        s.to_string()
    } else {
        format!("{}…", &s[..n])
    }
}

// ── Tests ──────────────────────────────────────────────────────────

#[cfg(all(test, feature = "http"))]
mod tests {
    use super::*;
    use std::sync::Mutex;

    /// Test-only HTTP transport that records every request and returns
    /// a pre-canned response body. Lets transport-shape tests assert
    /// the exact endpoint, headers, and body the auto-wired caller
    /// emits without touching the network.
    struct RecordingTransport {
        canned_response: String,
        seen: Mutex<Vec<RecordedCall>>,
    }

    #[derive(Debug, Clone)]
    struct RecordedCall {
        endpoint: String,
        body: Value,
        headers: HashMap<String, String>,
    }

    impl RecordingTransport {
        fn new(canned_response: &str) -> Self {
            Self {
                canned_response: canned_response.to_string(),
                seen: Mutex::new(Vec::new()),
            }
        }

        fn last(&self) -> RecordedCall {
            self.seen
                .lock()
                .unwrap()
                .last()
                .cloned()
                .expect("no recorded transport call")
        }
    }

    impl HttpTransport for RecordingTransport {
        fn post_json(
            &self,
            endpoint: &str,
            body: &Value,
            headers: &HashMap<String, String>,
        ) -> Result<String, String> {
            self.seen.lock().unwrap().push(RecordedCall {
                endpoint: endpoint.to_string(),
                body: body.clone(),
                headers: headers.clone(),
            });
            Ok(self.canned_response.clone())
        }
    }

    fn cfg(id: &str, provider: &str, model: &str, api_key_env: &str) -> ShieldConfiguration {
        ShieldConfiguration {
            id: id.to_string(),
            config_type: ConfigurationType::Llm,
            default: None,
            provider: Some(provider.to_string()),
            provider_config: None,
            endpoint: None,
            timeout: None,
            on_error: None,
            on_error_log: None,
            headers: HashMap::new(),
            model: Some(model.to_string()),
            max_tokens: None,
            api_key_env: Some(api_key_env.to_string()),
            metadata: None,
            threshold: None,
            method: None,
            category_thresholds: HashMap::new(),
            agent_id: None,
            tool: None,
        }
    }

    /// Helper: build a caller from a single resolved config plus a
    /// recording transport. Keeps every transport-shape test below
    /// to two lines of setup.
    fn caller_with(
        resolved: ResolvedLlmConfig,
        canned: &str,
    ) -> (AutoWiredLlmCaller, std::sync::Arc<RecordingTransport>) {
        // We can't put an `Arc<Recording>` in a `Box<dyn>` and also
        // borrow it back, so we hand the test a sibling Arc and the
        // caller a freshly-Box'd transport that points at the same
        // recorder via interior mutability. Easiest path: build two
        // recorders sharing nothing, but mutate via the box. Simpler
        // — just store a clone-able Arc<RecordingTransport> and wrap
        // it in a forwarder Box.
        struct Forward(std::sync::Arc<RecordingTransport>);
        impl HttpTransport for Forward {
            fn post_json(
                &self,
                endpoint: &str,
                body: &Value,
                headers: &HashMap<String, String>,
            ) -> Result<String, String> {
                self.0.post_json(endpoint, body, headers)
            }
        }
        let recorder = std::sync::Arc::new(RecordingTransport::new(canned));
        let mut configs = HashMap::new();
        configs.insert(resolved.model.clone(), resolved);
        let caller = AutoWiredLlmCaller {
            configs,
            transport: Box::new(ReqwestTransport),
        }
        .with_transport(Box::new(Forward(recorder.clone())));
        (caller, recorder)
    }

    fn resolved(provider: Provider, model: &str, endpoint: &str) -> ResolvedLlmConfig {
        ResolvedLlmConfig {
            provider,
            model: model.to_string(),
            api_key: Some("test-key".into()),
            endpoint: endpoint.to_string(),
            max_tokens: 0,
            api_version: DEFAULT_ANTHROPIC_API_VERSION.to_string(),
        }
    }

    fn openai_canned_response() -> String {
        r#"{"choices":[{"message":{"content":"{\"decision\":\"ALLOW\"}"}}]}"#.to_string()
    }

    #[test]
    fn skips_entries_without_env_var() {
        // Use a deterministically-unset env var name.
        let configs = vec![cfg(
            "safety",
            "openai",
            "gpt-4o-mini",
            "AS_FORWARD_PORT_TEST_UNSET_KEY_xyz",
        )];
        let caller = AutoWiredLlmCaller::from_configurations(&configs);
        assert!(!caller.has_any());
    }

    #[test]
    fn unknown_id_returns_error() {
        let caller = AutoWiredLlmCaller {
            configs: HashMap::new(),
            transport: Box::new(ReqwestTransport),
        };
        let err = caller.call(Some("missing"), "hi").unwrap_err();
        assert!(err.contains("no resolved LLM configuration"));
    }

    #[test]
    fn missing_id_returns_error() {
        let caller = AutoWiredLlmCaller {
            configs: HashMap::new(),
            transport: Box::new(ReqwestTransport),
        };
        let err = caller.call(None, "hi").unwrap_err();
        assert!(err.contains("requires a configuration_id"));
    }

    #[test]
    fn parse_llm_text_json_envelope_allow() {
        let r = parse_llm_text(r#"{"decision":"ALLOW","confidence":0.9,"reason":"safe"}"#);
        assert_eq!(r.folded_decision(), LlmDecision::Allow);
        assert_eq!(r.confidence, Some(0.9));
        assert_eq!(r.reason.as_deref(), Some("safe"));
    }

    #[test]
    fn parse_llm_text_json_envelope_block() {
        let r = parse_llm_text(r#"{"decision":"BLOCK","reason":"jailbreak detected"}"#);
        assert_eq!(r.folded_decision(), LlmDecision::Block);
    }

    #[test]
    fn parse_llm_text_bool_flag_blocks() {
        let r = parse_llm_text(r#"{"decision":"ALLOW","contains_pii":true}"#);
        // §12.9.3 — any truthy boolean field forces BLOCK.
        assert_eq!(r.folded_decision(), LlmDecision::Block);
    }

    #[test]
    fn parse_llm_text_freeform_keyword() {
        let r = parse_llm_text("BLOCK: prompt injection");
        assert_eq!(r.folded_decision(), LlmDecision::Block);
    }

    #[test]
    fn parse_llm_text_unknown_fails_closed() {
        let r = parse_llm_text("uh, maybe?");
        assert_eq!(r.folded_decision(), LlmDecision::Block);
    }

    #[test]
    fn provider_parse_recognizes_aliases() {
        // Existing v0.x short names.
        assert_eq!(Provider::parse("openai"), Some(Provider::OpenAi));
        assert_eq!(Provider::parse("OpenAI"), Some(Provider::OpenAi));
        assert_eq!(Provider::parse("azure"), Some(Provider::Azure));
        assert_eq!(Provider::parse("azure_openai"), Some(Provider::Azure));
        assert_eq!(Provider::parse("anthropic"), Some(Provider::Anthropic));

        // New providers (issue #8): short + reverse-domain forms.
        assert_eq!(Provider::parse("gemini"), Some(Provider::Gemini));
        assert_eq!(Provider::parse("google.gemini"), Some(Provider::Gemini));
        assert_eq!(Provider::parse("ollama"), Some(Provider::Ollama));
        assert_eq!(Provider::parse("meta.ollama"), Some(Provider::Ollama));
        assert_eq!(Provider::parse("bedrock"), Some(Provider::Bedrock));
        assert_eq!(Provider::parse("amazon.bedrock"), Some(Provider::Bedrock));

        // Spec §6.5 reverse-domain forms for the v0.x providers.
        assert_eq!(Provider::parse("openai.chat"), Some(Provider::OpenAi));
        assert_eq!(
            Provider::parse("anthropic.claude"),
            Some(Provider::Anthropic)
        );
        assert_eq!(
            Provider::parse("microsoft.azure.openai"),
            Some(Provider::Azure)
        );

        // `custom` is the sentinel for "host installs its own
        // LlmCaller" and MUST NOT auto-wire.
        assert_eq!(Provider::parse("custom"), None);

        // Typos / not-quite-right names MUST NOT match.
        assert_eq!(Provider::parse("gemeini"), None);
        assert_eq!(Provider::parse("olama"), None);
        assert_eq!(Provider::parse("amazon.bedrok"), None);
        assert_eq!(Provider::parse("google.generativeai"), None);
        assert_eq!(Provider::parse(""), None);
    }

    /// RAII guard that locks a shared mutex AND save/clears/restores
    /// a process-global env var on scope exit. Used to keep tests
    /// deterministic when the production code reads ambient env vars
    /// (`OLLAMA_HOST`, `AZURE_OPENAI_ENDPOINT`, etc.) that may be set
    /// on a developer's machine or in a CI runner, AND to serialise
    /// multiple tests that touch the SAME env var so they don't race
    /// under the default multi-threaded test harness.
    ///
    /// The lock is per env-var name (held for the lifetime of the
    /// guard). Tests for an env var that nothing else in the module
    /// touches can use [`ScopedEnvSet`] / [`ScopedEnvUnset`] directly
    /// without the mutex; tests for an env var with multiple touch
    /// points must go through this guard.
    struct EnvLockGuard {
        name: &'static str,
        previous: Option<String>,
        // Held for the lifetime of the guard. Released on drop.
        _lock: std::sync::MutexGuard<'static, ()>,
    }

    impl EnvLockGuard {
        /// Lock the mutex and clear the env var.
        fn clear(name: &'static str, lock: &'static std::sync::Mutex<()>) -> Self {
            let _lock = lock.lock().unwrap_or_else(|poison| poison.into_inner());
            let previous = std::env::var(name).ok();
            std::env::remove_var(name);
            Self {
                name,
                previous,
                _lock,
            }
        }

        /// Lock the mutex and set the env var to `value`.
        fn set(name: &'static str, value: &str, lock: &'static std::sync::Mutex<()>) -> Self {
            let _lock = lock.lock().unwrap_or_else(|poison| poison.into_inner());
            let previous = std::env::var(name).ok();
            std::env::set_var(name, value);
            Self {
                name,
                previous,
                _lock,
            }
        }
    }

    impl Drop for EnvLockGuard {
        fn drop(&mut self) {
            match self.previous.take() {
                Some(v) => std::env::set_var(self.name, v),
                None => std::env::remove_var(self.name),
            }
        }
    }

    /// Shared lock for every test that mutates `OLLAMA_HOST`. Two
    /// tests in this module touch it (`ollama_resolves_without_api_key_env`
    /// and `ollama_whitespace_host_falls_back_to_loopback`); under the
    /// default multi-threaded test harness, an interleaving where one
    /// test restores the env var while the other is mid-resolve would
    /// flip the second test's outcome. Serialise both behind this lock.
    static OLLAMA_HOST_LOCK: std::sync::Mutex<()> = std::sync::Mutex::new(());

    // ── Issue #8 — Ollama / Gemini / Bedrock resolution ───────────

    #[test]
    fn ollama_resolves_without_api_key_env() {
        // Ollama runs unauthenticated on loopback. Omitting
        // `api_key_env` MUST still register the configuration so the
        // runtime can route policy LLM calls to a local model.
        //
        // The resolver reads `OLLAMA_HOST` from the environment when
        // the configuration omits `endpoint:`. Clear it for this
        // test so a developer or CI runner with `OLLAMA_HOST` set
        // globally doesn't see a spurious failure. Serialise against
        // every other test that touches `OLLAMA_HOST` via the shared
        // lock.
        let _ollama_host = EnvLockGuard::clear("OLLAMA_HOST", &OLLAMA_HOST_LOCK);

        let mut c = cfg("local", "ollama", "llama3.1", "");
        c.api_key_env = None;
        let caller = AutoWiredLlmCaller::from_configurations(&[c]);
        assert!(
            caller.has_any(),
            "ollama config without api_key_env must auto-wire"
        );
        let resolved = caller
            .configs
            .get("local")
            .expect("ollama config registered");
        assert!(resolved.api_key.is_none(), "ollama auth must be optional");
        assert!(
            resolved.endpoint.starts_with("http://localhost:11434"),
            "ollama default endpoint must be loopback, got {}",
            resolved.endpoint
        );
        assert!(
            resolved.endpoint.ends_with("/v1/chat/completions"),
            "ollama endpoint must include chat-completions path, got {}",
            resolved.endpoint
        );
    }

    #[test]
    fn whitespace_api_key_env_value_treated_as_unset() {
        // A whitespace-only `OPENAI_API_KEY="   "` (or any other
        // provider's api-key env var) MUST be treated as unset — both
        // for the fail-closed providers (skip the configuration) and
        // for Ollama (fall through to unauthenticated loopback).
        // Otherwise the resolver would send "Bearer    " as the auth
        // header, which 401s opaquely.
        //
        // Use a uniquely-named test env var so concurrent tests in
        // this module can't observe each other's `AS_TEST_WS_KEY`
        // state. The Ollama branch also reads `OLLAMA_HOST`, so
        // serialise against the other Ollama-touching tests.
        std::env::set_var("AS_TEST_WS_KEY", "   ");

        // Non-Ollama: skip.
        let c = cfg("o", "openai", "gpt-4o-mini", "AS_TEST_WS_KEY");
        let caller = AutoWiredLlmCaller::from_configurations(&[c]);
        assert!(
            !caller.has_any(),
            "whitespace api_key_env value must skip non-Ollama provider"
        );

        // Ollama: fall through to unauthenticated.
        let _ollama_host = EnvLockGuard::clear("OLLAMA_HOST", &OLLAMA_HOST_LOCK);
        let c = cfg("local", "ollama", "llama3.1", "AS_TEST_WS_KEY");
        let caller = AutoWiredLlmCaller::from_configurations(&[c]);
        std::env::remove_var("AS_TEST_WS_KEY");
        let resolved = caller
            .configs
            .get("local")
            .expect("ollama config registered with whitespace api_key_env");
        assert!(
            resolved.api_key.is_none(),
            "whitespace api_key_env value must result in no auth header for Ollama"
        );
    }

    #[test]
    fn ollama_whitespace_host_falls_back_to_loopback() {
        // An `OLLAMA_HOST="   "` (whitespace-only, the kind a
        // copy-pasted `.env` file produces) MUST be treated as unset
        // so the loopback default kicks in. Without the trim, the
        // resolver would compose `   /v1/chat/completions`, which
        // every HTTP client rejects. Serialise against the other
        // Ollama-touching tests via the shared lock.
        let _ollama_host = EnvLockGuard::set("OLLAMA_HOST", "   ", &OLLAMA_HOST_LOCK);
        let mut c = cfg("local", "ollama", "llama3.1", "");
        c.api_key_env = None;
        let caller = AutoWiredLlmCaller::from_configurations(&[c]);
        let resolved = caller
            .configs
            .get("local")
            .expect("ollama config registered");
        assert!(
            resolved.endpoint.starts_with("http://localhost:11434"),
            "whitespace-only OLLAMA_HOST must fall back to loopback, got {}",
            resolved.endpoint
        );
    }

    #[test]
    fn gemini_resolves_with_default_endpoint() {
        // Gemini requires an API key (Bearer auth on Google's
        // OpenAI-compatible endpoint).
        std::env::set_var("AS_TEST_GEMINI_KEY", "g-fake");
        let c = cfg("g", "gemini", "gemini-1.5-pro", "AS_TEST_GEMINI_KEY");
        let caller = AutoWiredLlmCaller::from_configurations(&[c]);
        std::env::remove_var("AS_TEST_GEMINI_KEY");
        let resolved = caller.configs.get("g").expect("gemini config registered");
        assert_eq!(resolved.api_key.as_deref(), Some("g-fake"));
        assert_eq!(resolved.endpoint, DEFAULT_GEMINI_ENDPOINT);
    }

    #[test]
    fn bedrock_skipped_with_warning_pointer() {
        // Bedrock is parse-recognized but `resolve()` must skip it —
        // SigV4 signing lives in the Anthropic/LiteLLM adapters, not
        // the core HTTP caller.
        std::env::set_var("AS_TEST_AWS_KEY", "aws-fake");
        let c = cfg(
            "br",
            "amazon.bedrock",
            "anthropic.claude-3-5-sonnet-20241022-v2:0",
            "AS_TEST_AWS_KEY",
        );
        let caller = AutoWiredLlmCaller::from_configurations(&[c]);
        std::env::remove_var("AS_TEST_AWS_KEY");
        assert!(
            !caller.has_any(),
            "bedrock config must NOT auto-wire — host installs its own caller"
        );
    }

    #[test]
    fn normalize_ollama_endpoint_appends_path() {
        // Bare host → append `/v1/chat/completions`.
        assert_eq!(
            normalize_ollama_endpoint("http://localhost:11434"),
            "http://localhost:11434/v1/chat/completions"
        );
        // Trailing slash on bare host — strip then append.
        assert_eq!(
            normalize_ollama_endpoint("http://localhost:11434/"),
            "http://localhost:11434/v1/chat/completions"
        );
        // Already-full URL — leave alone.
        assert_eq!(
            normalize_ollama_endpoint("http://localhost:11434/v1/chat/completions"),
            "http://localhost:11434/v1/chat/completions"
        );
        // Custom remote Ollama host.
        assert_eq!(
            normalize_ollama_endpoint("https://ollama.internal:443"),
            "https://ollama.internal:443/v1/chat/completions"
        );
        // Base URL ending in `/v1` (the Ollama Python SDK's convention
        // when you call `OpenAI(base_url=...)`) → append only the
        // chat-completions path. The previous substring-`/v1/` heuristic
        // produced a duplicated `/v1/v1/chat/completions` for these.
        assert_eq!(
            normalize_ollama_endpoint("http://ollama.internal/v1"),
            "http://ollama.internal/v1/chat/completions"
        );
        assert_eq!(
            normalize_ollama_endpoint("http://ollama.internal/v1/"),
            "http://ollama.internal/v1/chat/completions"
        );
    }

    // ── Transport-shape parity tests ──────────────────────────────
    //
    // The auto-wired caller is the one place per-provider HTTP shape
    // diverges. These tests assert the outbound request shape using
    // a recording transport so the network is never touched.

    #[test]
    fn openai_transport_uses_bearer_auth_and_chat_shape() {
        let (caller, recorder) = caller_with(
            resolved(Provider::OpenAi, "gpt-4o-mini", DEFAULT_OPENAI_ENDPOINT),
            &openai_canned_response(),
        );
        caller.call(Some("gpt-4o-mini"), "hello").unwrap();
        let call = recorder.last();
        assert_eq!(call.endpoint, DEFAULT_OPENAI_ENDPOINT);
        assert_eq!(
            call.headers.get("Authorization").map(String::as_str),
            Some("Bearer test-key")
        );
        assert!(call.headers.get("api-key").is_none());
        assert_eq!(call.body["model"], "gpt-4o-mini");
        assert_eq!(call.body["messages"][0]["role"], "user");
        assert_eq!(call.body["messages"][0]["content"], "hello");
    }

    #[test]
    fn azure_transport_uses_api_key_header() {
        let (caller, recorder) = caller_with(
            resolved(Provider::Azure, "gpt-4o", "https://x.openai.azure.com/v1"),
            &openai_canned_response(),
        );
        caller.call(Some("gpt-4o"), "hello").unwrap();
        let call = recorder.last();
        assert_eq!(
            call.headers.get("api-key").map(String::as_str),
            Some("test-key")
        );
        assert!(call.headers.get("Authorization").is_none());
    }

    #[test]
    fn gemini_transport_uses_openai_shape_and_bearer() {
        // Gemini's OpenAI-compatible endpoint accepts the same body
        // as OpenAI. Auth is `Authorization: Bearer <key>` against a
        // Google API key.
        let (caller, recorder) = caller_with(
            resolved(Provider::Gemini, "gemini-1.5-pro", DEFAULT_GEMINI_ENDPOINT),
            &openai_canned_response(),
        );
        caller.call(Some("gemini-1.5-pro"), "hello").unwrap();
        let call = recorder.last();
        assert_eq!(call.endpoint, DEFAULT_GEMINI_ENDPOINT);
        assert_eq!(
            call.headers.get("Authorization").map(String::as_str),
            Some("Bearer test-key")
        );
        assert_eq!(call.body["model"], "gemini-1.5-pro");
    }

    #[test]
    fn ollama_transport_omits_auth_header_when_no_key() {
        let mut r = resolved(
            Provider::Ollama,
            "llama3.1",
            "http://localhost:11434/v1/chat/completions",
        );
        r.api_key = None;
        let (caller, recorder) = caller_with(r, &openai_canned_response());
        caller.call(Some("llama3.1"), "hello").unwrap();
        let call = recorder.last();
        // No Bearer header, no `api-key` header — Ollama loopback
        // accepts unauthenticated requests and some Ollama gateways
        // reject an empty Bearer.
        assert!(call.headers.get("Authorization").is_none());
        assert!(call.headers.get("api-key").is_none());
        // Body is still OpenAI-shaped.
        assert_eq!(call.body["model"], "llama3.1");
        assert_eq!(call.body["messages"][0]["content"], "hello");
    }

    #[test]
    fn ollama_transport_uses_bearer_when_key_present() {
        // Users running Ollama behind an auth proxy can declare
        // `api_key_env:` and the caller passes the value through as
        // a Bearer token (matches OpenAI-compatible API conventions).
        let (caller, recorder) = caller_with(
            resolved(
                Provider::Ollama,
                "llama3.1",
                "http://proxy.internal/v1/chat/completions",
            ),
            &openai_canned_response(),
        );
        caller.call(Some("llama3.1"), "hello").unwrap();
        assert_eq!(
            recorder
                .last()
                .headers
                .get("Authorization")
                .map(String::as_str),
            Some("Bearer test-key")
        );
    }

    #[test]
    fn anthropic_transport_uses_x_api_key_and_version() {
        let canned = r#"{"content":[{"type":"text","text":"{\"decision\":\"ALLOW\"}"}]}"#;
        let mut r = resolved(
            Provider::Anthropic,
            "claude-3-5-sonnet-20241022",
            DEFAULT_ANTHROPIC_ENDPOINT,
        );
        r.max_tokens = ANTHROPIC_DEFAULT_MAX_TOKENS;
        let (caller, recorder) = caller_with(r, canned);
        caller
            .call(Some("claude-3-5-sonnet-20241022"), "hi")
            .unwrap();
        let call = recorder.last();
        assert_eq!(
            call.headers.get("x-api-key").map(String::as_str),
            Some("test-key")
        );
        assert_eq!(
            call.headers.get("anthropic-version").map(String::as_str),
            Some(DEFAULT_ANTHROPIC_API_VERSION)
        );
        // Anthropic body always includes `max_tokens` even when the
        // configuration omits it (the API rejects a request without).
        assert_eq!(call.body["max_tokens"], ANTHROPIC_DEFAULT_MAX_TOKENS);
    }

    #[test]
    fn bedrock_call_errors_with_actionable_pointer() {
        // If a caller is somehow constructed with a Bedrock-resolved
        // config (bypassing `resolve()`), the call MUST fail closed
        // with a message that names the canonical alternative paths.
        let r = resolved(Provider::Bedrock, "anthropic.claude-...", "");
        let (caller, _recorder) = caller_with(r, "");
        let err = caller.call(Some("anthropic.claude-..."), "hi").unwrap_err();
        assert!(
            err.contains("register_llm_caller"),
            "bedrock error must point at the host-caller path, got: {err}"
        );
        assert!(
            err.contains("AnthropicBedrock") || err.contains("LiteLLM"),
            "bedrock error must name a canonical alternative, got: {err}"
        );
    }
}
