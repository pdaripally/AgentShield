//! Per-configuration LLM caller dispatcher.
//!
//! Cross-SDK parity helper. The runtime invokes
//! [`LlmCaller::call`] with the
//! YAML-declared `configuration_id` as the first argument. When a host
//! wants distinct underlying callers per `configurations[]` entry
//! (different model, mocked response, separate provider) this helper
//! composes them into a single [`LlmCaller`] that routes by EXACT
//! `configuration_id` match.
//!
//! Mirrors Python's `agent_shield.make_configuration_caller`, Node's
//! `makeConfigurationCaller`, and .NET's
//! `AgentShield.ConfigurationLlmCaller`.

use std::collections::HashMap;
use std::sync::Arc;

use crate::guard_policy_runtime::{LlmCaller, LlmResponse};

/// LLM caller that dispatches to one of N inner callers by
/// `configuration_id`. See [`make_configuration_caller`].
pub struct ConfigurationCaller {
    routes: HashMap<String, Arc<dyn LlmCaller>>,
    default: Option<Arc<dyn LlmCaller>>,
}

impl LlmCaller for ConfigurationCaller {
    fn call(&self, configuration_id: Option<&str>, prompt: &str) -> Result<LlmResponse, String> {
        if let Some(id) = configuration_id {
            if let Some(caller) = self.routes.get(id) {
                return caller.call(Some(id), prompt);
            }
        }
        if let Some(default) = &self.default {
            return default.call(configuration_id, prompt);
        }
        let mut known: Vec<&str> = self.routes.keys().map(|k| k.as_str()).collect();
        known.sort_unstable();
        let known_quoted: Vec<String> = known.iter().map(|k| format!("'{k}'")).collect();
        let id_repr = match configuration_id {
            Some(id) => format!("'{id}'"),
            None => "null".to_string(),
        };
        Err(format!(
            "no LLM caller registered for configuration_id={id_repr}; \
             known ids: [{}]; no default provided",
            known_quoted.join(", "),
        ))
    }
}

/// Build an [`LlmCaller`] that routes by EXACT `configuration_id` match.
///
/// Each entry in `callers` maps a YAML `configurations[].id` to an inner
/// [`LlmCaller`]. When the runtime dispatches with a `configuration_id`
/// not present in the map and `default` is `Some(...)`, dispatch falls
/// back to `default`; otherwise the dispatcher returns `Err(...)` listing
/// the registered ids (which folds into a `BLOCK` per §12.9.3).
///
/// # Example
///
/// ```ignore
/// use std::sync::Arc;
/// use agent_shield_core::{make_configuration_caller, LlmCaller};
///
/// let safety_caller: Arc<dyn LlmCaller> = /* ... */;
/// let tool_caller: Arc<dyn LlmCaller> = /* ... */;
/// let dispatcher = make_configuration_caller(
///     [
///         ("safety_llm".to_string(), safety_caller),
///         ("tool_execution_llm".to_string(), tool_caller),
///     ],
///     None,
/// );
/// ```
pub fn make_configuration_caller(
    callers: impl IntoIterator<Item = (String, Arc<dyn LlmCaller>)>,
    default: Option<Arc<dyn LlmCaller>>,
) -> ConfigurationCaller {
    ConfigurationCaller {
        routes: callers.into_iter().collect(),
        default,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::guard_policy_runtime::{LlmDecision, LlmResponse};
    use std::sync::Mutex;

    struct RecordingCaller {
        label: &'static str,
        prompts: Mutex<Vec<String>>,
    }

    impl RecordingCaller {
        fn new(label: &'static str) -> Self {
            Self {
                label,
                prompts: Mutex::new(Vec::new()),
            }
        }
    }

    impl LlmCaller for RecordingCaller {
        fn call(&self, _id: Option<&str>, prompt: &str) -> Result<LlmResponse, String> {
            self.prompts.lock().unwrap().push(prompt.into());
            Ok(LlmResponse {
                decision: Some(LlmDecision::Allow),
                reason: Some(self.label.into()),
                ..Default::default()
            })
        }
    }

    #[test]
    fn exact_match_routes_to_registered_caller() {
        let input_caller = Arc::new(RecordingCaller::new("input"));
        let tool_caller = Arc::new(RecordingCaller::new("tool"));
        let dispatcher = make_configuration_caller(
            [
                (
                    "input_llm".to_string(),
                    input_caller.clone() as Arc<dyn LlmCaller>,
                ),
                (
                    "tool_execution_llm".to_string(),
                    tool_caller.clone() as Arc<dyn LlmCaller>,
                ),
            ],
            None,
        );

        let r = dispatcher.call(Some("input_llm"), "hello").unwrap();
        assert_eq!(r.reason.as_deref(), Some("input"));
        let r = dispatcher.call(Some("tool_execution_llm"), "calc").unwrap();
        assert_eq!(r.reason.as_deref(), Some("tool"));

        assert_eq!(input_caller.prompts.lock().unwrap().as_slice(), &["hello"]);
        assert_eq!(tool_caller.prompts.lock().unwrap().as_slice(), &["calc"]);
    }

    #[test]
    fn substring_match_does_not_route() {
        let input_caller = Arc::new(RecordingCaller::new("input"));
        let fallback = Arc::new(RecordingCaller::new("default"));
        let dispatcher = make_configuration_caller(
            [(
                "input_llm".to_string(),
                input_caller.clone() as Arc<dyn LlmCaller>,
            )],
            Some(fallback.clone() as Arc<dyn LlmCaller>),
        );

        let r = dispatcher.call(Some("my_input_check"), "hello").unwrap();
        assert_eq!(r.reason.as_deref(), Some("default"));
        assert!(input_caller.prompts.lock().unwrap().is_empty());
        assert_eq!(fallback.prompts.lock().unwrap().as_slice(), &["hello"]);
    }

    #[test]
    fn default_used_when_configuration_id_is_none() {
        let input_caller = Arc::new(RecordingCaller::new("input"));
        let fallback = Arc::new(RecordingCaller::new("default"));
        let dispatcher = make_configuration_caller(
            [("input_llm".to_string(), input_caller as Arc<dyn LlmCaller>)],
            Some(fallback.clone() as Arc<dyn LlmCaller>),
        );

        let r = dispatcher.call(None, "x").unwrap();
        assert_eq!(r.reason.as_deref(), Some("default"));
        assert_eq!(fallback.prompts.lock().unwrap().as_slice(), &["x"]);
    }

    #[test]
    fn no_default_unknown_id_errors() {
        let input_caller = Arc::new(RecordingCaller::new("input"));
        let dispatcher = make_configuration_caller(
            [("input_llm".to_string(), input_caller as Arc<dyn LlmCaller>)],
            None,
        );

        let err = dispatcher.call(Some("unknown"), "x").unwrap_err();
        assert!(err.contains("no LLM caller registered"));
        assert!(err.contains("'input_llm'"));
        assert!(err.contains("'unknown'"));
        assert!(err.contains("no default provided"));
    }

    #[test]
    fn error_message_quotes_null_for_none_id() {
        let empty: Vec<(String, Arc<dyn LlmCaller>)> = Vec::new();
        let dispatcher = make_configuration_caller(empty, None);
        let err = dispatcher.call(None, "x").unwrap_err();
        // Match the Python (`None`-as-quoted), Node (`null`), and .NET (`null`)
        // representations rather than Rust's `Option<&str>` `Debug` form.
        assert!(err.contains("configuration_id=null"), "got: {err}");
    }

    #[test]
    fn dispatcher_takes_defensive_copy() {
        // Parity with Python/Node/.NET tests: mutating the source map after
        // construction must not affect dispatch. The current API takes an
        // `IntoIterator`, which already consumes by value — this test pins
        // that contract by collecting into a Vec first, then dropping it.
        let caller = Arc::new(RecordingCaller::new("a"));
        let mut source: Vec<(String, Arc<dyn LlmCaller>)> =
            vec![("a".to_string(), caller.clone() as Arc<dyn LlmCaller>)];
        let dispatcher = make_configuration_caller(source.drain(..), None);
        // `source` is now empty; the dispatcher still routes.
        assert!(source.is_empty());
        let r = dispatcher.call(Some("a"), "x").unwrap();
        assert_eq!(r.reason.as_deref(), Some("a"));
    }
}
