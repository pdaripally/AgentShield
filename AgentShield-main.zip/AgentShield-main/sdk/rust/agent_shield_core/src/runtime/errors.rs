//! `RuntimeError`, the error envelope returned by the public host
//! API in [`crate::runtime`].
//!
//! This is the **only** error type a host calling
//! [`super::session::GuardrailsSession`] or [`super::builder::RuntimeBuilder`]
//! sees. Internal modules raise their own typed errors
//! ([`crate::lifetime_tracker::TrackerError`],
//! [`crate::event_bus::EmitError`], etc.); the runtime maps each into
//! a [`RuntimeError`] variant so the spec-mandated semantics
//! (fail-closed when a hook is missing, propagate `unknown variable`, etc.)
//! are visible at the API boundary.

use std::fmt;

use crate::errors::ConfigError;
use crate::event_bus::EmitError;
use crate::lifetime_tracker::TrackerError;

/// Error envelope returned by every fallible operation on
/// [`crate::runtime::builder::RuntimeBuilder`] and
/// [`crate::runtime::session::GuardrailsSession`].
///
/// All variants are non-fatal at the API surface — they describe a
/// recoverable failure the host MUST propagate to the caller, not a
/// process crash. Per §21 the runtime fails closed: missing host hooks
/// produce a structured [`Self::HostHookMissing`] rather than panicking.
#[derive(Debug)]
pub enum RuntimeError {
    /// YAML load / merge error.
    Config(ConfigError),
    /// Lifetime tracker rejected the operation (e.g. unknown variable,
    /// `update_policy:` violation).
    Tracker(TrackerError),
    /// Event bus rejected the emission (e.g. bad `incident.<name>`).
    EmitEvent(EmitError),
    /// `set_variable` / `reset_variable` / `resolve_variable` referenced
    /// a name that's not in the merged config's `variables[]`.
    UnknownVariable(String),
    /// Caller passed a malformed event id to `emit_event` / `clear_event`.
    InvalidEventId(String),
    /// A spec-required host hook was not registered before
    /// [`crate::runtime::builder::RuntimeBuilder::build`].
    ///
    /// The string identifies which hook is missing in §21 terms
    /// (`"human_resolver"`, `"agent_resolver"`, `"llm_caller"`, etc.).
    /// Per §21 / §11.7 the runtime fails closed when a required hook is
    /// absent — this variant surfaces that failure at the API boundary
    /// instead of letting the gating call silently deny.
    HostHookMissing(&'static str),
    /// IO error reading a configuration path.
    Io(std::io::Error),
}

impl fmt::Display for RuntimeError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            RuntimeError::Config(e) => write!(f, "config error: {}", e),
            RuntimeError::Tracker(e) => write!(f, "tracker error: {}", e),
            RuntimeError::EmitEvent(e) => write!(f, "emit error: {}", e),
            RuntimeError::UnknownVariable(name) => write!(f, "unknown variable `{}`", name),
            RuntimeError::InvalidEventId(id) => write!(f, "invalid event id `{}`", id),
            RuntimeError::HostHookMissing(hook) => {
                write!(f, "required host hook `{}` not registered", hook)
            }
            RuntimeError::Io(e) => write!(f, "io error: {}", e),
        }
    }
}

impl std::error::Error for RuntimeError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            RuntimeError::Config(e) => Some(e),
            RuntimeError::Tracker(e) => Some(e),
            RuntimeError::EmitEvent(e) => Some(e),
            RuntimeError::Io(e) => Some(e),
            _ => None,
        }
    }
}

impl From<ConfigError> for RuntimeError {
    fn from(e: ConfigError) -> Self {
        RuntimeError::Config(e)
    }
}

impl From<TrackerError> for RuntimeError {
    fn from(e: TrackerError) -> Self {
        match &e {
            TrackerError::UnknownVariable(n) => RuntimeError::UnknownVariable(n.clone()),
            _ => RuntimeError::Tracker(e),
        }
    }
}

impl From<EmitError> for RuntimeError {
    fn from(e: EmitError) -> Self {
        match &e {
            EmitError::InvalidEventId(id, _) => RuntimeError::InvalidEventId(id.clone()),
            _ => RuntimeError::EmitEvent(e),
        }
    }
}

impl From<std::io::Error> for RuntimeError {
    fn from(e: std::io::Error) -> Self {
        RuntimeError::Io(e)
    }
}
