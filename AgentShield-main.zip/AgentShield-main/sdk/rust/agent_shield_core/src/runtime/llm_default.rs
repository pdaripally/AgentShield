//! fail-closed default [`LlmCaller`] implementation.
//!
//! The spec (§12.5.1 / §12.9.3) requires that `evaluate_when[].llm`
//! detection entries have a host-provided LLM caller. There's no
//! "reasonable default" — every realistic deployment ships its own
//! provider configuration with credentials, and silently allowing an
//! `llm:` entry to pass would defeat the security model.
//!
//! This default therefore **always returns BLOCK**. Hosts that want
//! actual LLM-based detection register their own
//! [`LlmCaller`](crate::guard_policy_runtime::LlmCaller) via
//! [`super::builder::RuntimeBuilder::register_llm_caller`].
//!
//! ## Why we ship a default at all
//!
//! 1. The `GuardPolicyEngine` accepts `Option<Arc<dyn LlmCaller>>` and
//!    treats `None` as fail-closed. The default exists for hosts that
//!    want an explicit registration of "no LLM" rather than relying on
//!    the implicit None path — surfacing in logs that an LLM-typed
//!    policy fired without a caller.
//! 2. Some smoke tests register the default to exercise the
//!    fail-closed path symmetrically with the "happy path" registered
//!    caller.

use crate::guard_policy_runtime::{LlmCaller, LlmDecision, LlmResponse};

/// Default LLM caller — every call returns `BLOCK`.
///
/// This is a fail-closed sentinel; no host should rely on it as the
/// terminal LLM provider. See module docs.
pub struct FailClosedLlmCaller;

impl LlmCaller for FailClosedLlmCaller {
    fn call(&self, _configuration_id: Option<&str>, _prompt: &str) -> Result<LlmResponse, String> {
        Ok(LlmResponse {
            decision: Some(LlmDecision::Block),
            confidence: Some(1.0),
            reason: Some(
                "default LlmCaller: no LLM provider registered — failing closed (BLOCK)".into(),
            ),
            ..Default::default()
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn fail_closed_returns_block() {
        let c = FailClosedLlmCaller;
        let r = c.call(Some("safety_llm"), "hi").unwrap();
        assert_eq!(r.folded_decision(), LlmDecision::Block);
    }
}
