//! Variables (§9): declared types, populator/resetter entries, lifetimes,
//! resolvers, and the status envelope. This module models the static schema
//! only — the runtime status envelope lives in [`crate::lifetime_tracker`].

use serde::{Deserialize, Serialize};

use super::lifetime::Lifetime;
use super::resolver::Resolver;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum VariableType {
    String,
    Number,
    Boolean,
    Array,
    Object,
    Datetime,
    /// Spec §7.3 / §10.1: closed string domain. The variable's
    /// `members:` list both enumerates the legal values and defines the
    /// ordering used by `max()` / `min()` and `<` / `<=` / `>` / `>=`.
    Enum,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ResourceKind {
    Tool,
    Endpoint,
    Agent,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "snake_case")]
pub enum Phase {
    Before,
    #[default]
    After,
}

/// Push-style populator entry (§10.5). Discriminated by `kind`.
#[derive(Debug, Clone, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct PopulatorEntry {
    pub kind: ResourceKind,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub name: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub pattern: Option<String>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub methods: Vec<String>,
    #[serde(default = "default_after_phase")]
    pub phase: Phase,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub expression: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub extractor: Option<String>,
}

#[allow(dead_code)]
fn default_after_phase() -> Phase {
    Phase::After
}

impl<'de> Deserialize<'de> for PopulatorEntry {
    fn deserialize<D: serde::Deserializer<'de>>(de: D) -> std::result::Result<Self, D::Error> {
        #[derive(Deserialize)]
        #[serde(deny_unknown_fields)]
        struct H {
            kind: ResourceKind,
            #[serde(default)]
            name: Option<String>,
            #[serde(default)]
            pattern: Option<String>,
            #[serde(default)]
            methods: Vec<String>,
            #[serde(default)]
            phase: Option<Phase>,
            #[serde(default)]
            expression: Option<String>,
            #[serde(default)]
            extractor: Option<String>,
        }
        let h = H::deserialize(de)?;
        let phase = h.phase.unwrap_or(Phase::After);
        validate_resource_target::<D>(h.kind, &h.name, &h.pattern, &h.methods, "populated_by")?;

        if matches!(phase, Phase::Before) && h.expression.as_deref().is_some() {
            // §10.5.2: phase: before MUST NOT see result.* — simple syntactic check.
            if h.expression.as_deref().unwrap_or("").contains("result.") {
                return Err(serde::de::Error::custom(
                    "populated_by[]: `phase: before` expression must not reference `result.*` (§10.5.2)",
                ));
            }
        }
        Ok(PopulatorEntry {
            kind: h.kind,
            name: h.name,
            pattern: h.pattern,
            methods: h.methods,
            phase,
            expression: h.expression,
            extractor: h.extractor,
        })
    }
}

/// Reset-style entry (§10.6). Same shape as `PopulatorEntry` but `phase` is
/// REQUIRED — there is no default.
#[derive(Debug, Clone, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ResetEntry {
    pub kind: ResourceKind,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub name: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub pattern: Option<String>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub methods: Vec<String>,
    pub phase: Phase,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub expression: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub extractor: Option<String>,
}

impl<'de> Deserialize<'de> for ResetEntry {
    fn deserialize<D: serde::Deserializer<'de>>(de: D) -> std::result::Result<Self, D::Error> {
        #[derive(Deserialize)]
        #[serde(deny_unknown_fields)]
        struct H {
            kind: ResourceKind,
            #[serde(default)]
            name: Option<String>,
            #[serde(default)]
            pattern: Option<String>,
            #[serde(default)]
            methods: Vec<String>,
            phase: Phase,
            #[serde(default)]
            expression: Option<String>,
            #[serde(default)]
            extractor: Option<String>,
        }
        let h = H::deserialize(de)?;
        validate_resource_target::<D>(h.kind, &h.name, &h.pattern, &h.methods, "reset_by")?;
        Ok(ResetEntry {
            kind: h.kind,
            name: h.name,
            pattern: h.pattern,
            methods: h.methods,
            phase: h.phase,
            expression: h.expression,
            extractor: h.extractor,
        })
    }
}

fn validate_resource_target<'de, D: serde::Deserializer<'de>>(
    kind: ResourceKind,
    name: &Option<String>,
    pattern: &Option<String>,
    methods: &[String],
    site: &str,
) -> std::result::Result<(), D::Error> {
    match kind {
        ResourceKind::Tool | ResourceKind::Agent => {
            if name.is_none() {
                return Err(serde::de::Error::custom(format!(
                    "{}: `kind: {:?}` requires `name`",
                    site, kind
                )));
            }
        }
        ResourceKind::Endpoint => {
            if pattern.is_none() {
                return Err(serde::de::Error::custom(format!(
                    "{}: `kind: endpoint` requires `pattern`",
                    site
                )));
            }
            if methods.is_empty() {
                return Err(serde::de::Error::custom(format!(
                    "{}: `kind: endpoint` requires non-empty `methods`",
                    site
                )));
            }
        }
    }
    Ok(())
}

/// Single variable declaration (§10.1).
///
/// Key fields:
/// - `var_type` (`type:`): one of the eight types incl. `enum`.
/// - `members:` REQUIRED iff `type: enum`; the ordered string domain.
/// - `update:` (§10.2): single-line expression evaluated on each write
///   while `@status == 'resolved'`. When omitted, behaves as
///   `update: "@incoming"` (replace).
/// - `key:` (§9.4): optional binding-key expression that makes the
///   variable a per-key store. Re-evaluated at every read and write.
#[derive(Debug, Clone, Serialize, PartialEq)]
#[serde(deny_unknown_fields)]
pub struct Variable {
    pub name: String,
    #[serde(rename = "type")]
    pub var_type: VariableType,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub description: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub default: Option<serde_json::Value>,
    /// `type: enum` only — the ordered string domain. `None` for every
    /// other type. The list both enumerates the legal values and defines
    /// the comparison ordering (member-index).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub members: Option<Vec<String>>,
    /// §10.2 `update:` expression. `None` ⇒ default replace semantics
    /// (equivalent to `update: "@incoming"`).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub update: Option<String>,
    /// §9.4 binding key expression. `None` ⇒ single-slot variable.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub key: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub lifetime: Option<Lifetime>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub on_demand_by: Option<Resolver>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub populated_by: Vec<PopulatorEntry>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub reset_by: Vec<ResetEntry>,
}

impl<'de> Deserialize<'de> for Variable {
    fn deserialize<D: serde::Deserializer<'de>>(de: D) -> std::result::Result<Self, D::Error> {
        // We deserialize through a permissive helper so we can reject v1
        // vocabulary (`source`, `sticky_on_deny`, `max_duration_seconds`,
        // `set_after_execute`, `sets_attributes`, `update_policy`,
        // `properties`, `ordering`) with a clear migration message rather
        // than serde's default "unknown field" wording.
        let value = serde_yaml::Value::deserialize(de)?;
        if let Some(map) = value.as_mapping() {
            for (k, _) in map {
                if let Some(key) = k.as_str() {
                    if let Some(hint) = v1_field_migration_hint(key) {
                        return Err(serde::de::Error::custom(format!(
                            "variable: rejected v1 field `{}` ({})",
                            key, hint
                        )));
                    }
                }
            }
        }

        #[derive(Deserialize)]
        #[serde(deny_unknown_fields)]
        struct H {
            name: String,
            #[serde(default, rename = "type")]
            var_type: Option<VariableType>,
            #[serde(default)]
            description: Option<String>,
            #[serde(default)]
            default: Option<serde_json::Value>,
            #[serde(default)]
            members: Option<Vec<String>>,
            #[serde(default)]
            update: Option<String>,
            #[serde(default)]
            key: Option<String>,
            #[serde(default)]
            lifetime: Option<Lifetime>,
            #[serde(default)]
            on_demand_by: Option<Resolver>,
            #[serde(default)]
            populated_by: Vec<PopulatorEntry>,
            #[serde(default)]
            reset_by: Vec<ResetEntry>,
        }

        let h: H = serde_yaml::from_value(value).map_err(serde::de::Error::custom)?;

        if h.name.is_empty() {
            return Err(serde::de::Error::custom(
                "variable: `name` must be non-empty",
            ));
        }

        // Cheap snake_case check.
        let bytes = h.name.as_bytes();
        let head_ok = bytes
            .first()
            .map(|b| b.is_ascii_lowercase() || *b == b'_')
            .unwrap_or(false);
        let tail_ok = bytes
            .iter()
            .skip(1)
            .all(|b| b.is_ascii_lowercase() || b.is_ascii_digit() || *b == b'_');
        if !(head_ok && tail_ok) {
            return Err(serde::de::Error::custom(format!(
                "variable name `{}` must be snake_case (§1.3)",
                h.name
            )));
        }

        // §10.1 boolean-flag shorthand: a variable declared with only a
        // `name:` (no `type:`) is interpreted as `type: boolean, default: false`.
        // The shorthand cannot coexist with `default:`, `members:`,
        // `update:`, or any other typed field — those imply the author
        // wanted an explicit `type:` and forgot to declare it.
        let var_type = match h.var_type {
            Some(t) => t,
            None => {
                if h.default.is_some() || h.members.is_some() || h.update.is_some() {
                    return Err(serde::de::Error::custom(format!(
                        "variable `{}`: `type:` required when any of `default:`, `members:`, or `update:` is declared",
                        h.name
                    )));
                }
                VariableType::Boolean
            }
        };
        let default = match (h.default.clone(), &var_type) {
            (Some(v), _) => Some(v),
            (None, VariableType::Boolean) if h.var_type.is_none() => {
                // Boolean-flag shorthand default: false
                Some(serde_json::Value::Bool(false))
            }
            _ => None,
        };

        // §10.1 `enum` type requires non-empty `members:`. Other types
        // MUST NOT declare `members:`.
        match (var_type, &h.members) {
            (VariableType::Enum, Some(m)) => {
                if m.is_empty() {
                    return Err(serde::de::Error::custom(format!(
                        "variable `{}`: `type: enum` requires a non-empty `members:` list (§10.1)",
                        h.name
                    )));
                }
                let mut seen: std::collections::HashSet<&str> = std::collections::HashSet::new();
                for member in m {
                    if !seen.insert(member.as_str()) {
                        return Err(serde::de::Error::custom(format!(
                            "variable `{}`: duplicate enum member `{}` in `members:` (§10.1)",
                            h.name, member
                        )));
                    }
                }
                if let Some(serde_json::Value::String(d)) = &default {
                    if !m.iter().any(|mem| mem == d) {
                        return Err(serde::de::Error::custom(format!(
                            "variable `{}`: `default:` value `{}` is not in `members:` (§10.1)",
                            h.name, d
                        )));
                    }
                } else if let Some(d) = &default {
                    return Err(serde::de::Error::custom(format!(
                        "variable `{}`: `type: enum` default must be a string member, got {}",
                        h.name, d
                    )));
                }
            }
            (VariableType::Enum, None) => {
                return Err(serde::de::Error::custom(format!(
                    "variable `{}`: `type: enum` requires a `members:` list (§10.1)",
                    h.name
                )));
            }
            (_, Some(_)) => {
                return Err(serde::de::Error::custom(format!(
                    "variable `{}`: `members:` is only valid on `type: enum` (§10.1)",
                    h.name
                )));
            }
            (_, None) => {}
        }

        Ok(Variable {
            name: h.name,
            var_type,
            description: h.description,
            default,
            members: h.members,
            update: h.update,
            key: h.key,
            lifetime: h.lifetime,
            on_demand_by: h.on_demand_by,
            populated_by: h.populated_by,
            reset_by: h.reset_by,
        })
    }
}

fn v1_field_migration_hint(key: &str) -> Option<&'static str> {
    match key {
        "source" => Some(
            "the spec unifies population through `on_demand_by:` (resolver) and `populated_by:` (push-style). Migration: replace with one of those.",
        ),
        "sticky_on_deny" => Some(
            "deny-stickiness is expressed through `lifetime: { allow:, deny: until_event: ... }` (§9.1.2).",
        ),
        "max_duration_seconds" => Some(
            "use `lifetime: { for: <duration> }` (§9.1.1) — the legacy `max_duration_seconds` form is removed.",
        ),
        "set_after_execute" => Some(
            "use `populated_by[]` on the variable (§10.5) — the legacy resource-side `set_after_execute` form is removed.",
        ),
        "sets_attributes" => Some(
            "no `sets_attributes:` on resources. Use `populated_by[]` on the variable (§10.5).",
        ),
        "update_policy" => Some(
            "v2 uses `update: <expression>` (§10.2) instead of an enum. Migrate `update_policy: max` → `update: \"max(@current, @incoming)\"`, `collect` → `union(@current, @incoming)`, `merge` → `object.merge_patch(@current, @incoming)`, `replace` → omit (default).",
        ),
        "properties" => Some(
            "v2 expresses per-sub-property merges inline within an `update:` expression (§10.2.2). Migrate the `properties:` map into a single `object.merge_patch(@current, { ... })` or split into one variable per field.",
        ),
        "ordering" => Some(
            "v2 expresses ordered string domains via `type: enum` + `members:` (§7.3 / §10.1). Migrate `update_policy: max` + `ordering: [...]` → `type: enum` + `members: [...]` + `update: \"max(@current, @incoming)\"`.",
        ),
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_simple_boolean_variable() {
        let yaml = "name: x\ntype: boolean\ndefault: false\n";
        let v: Variable = serde_yaml::from_str(yaml).unwrap();
        assert_eq!(v.var_type, VariableType::Boolean);
        // §10.2 default: omitted update: ⇒ replace semantics. The
        // struct field is None to signal "use the default".
        assert!(v.update.is_none());
    }

    /// §10.1 boolean-flag shorthand: a variable declared with only a
    /// `name:` is interpreted as `type: boolean, default: false`.
    #[test]
    fn boolean_flag_shorthand_no_type_defaults_to_boolean_false() {
        let yaml = "name: lockdown_active\n";
        let v: Variable = serde_yaml::from_str(yaml).unwrap();
        assert_eq!(v.var_type, VariableType::Boolean);
        assert_eq!(v.default, Some(serde_json::Value::Bool(false)));
    }

    #[test]
    fn boolean_flag_shorthand_with_lifetime_still_works() {
        let yaml = "name: incident_active\nlifetime:\n  for: \"30m\"\n";
        let v: Variable = serde_yaml::from_str(yaml).unwrap();
        assert_eq!(v.var_type, VariableType::Boolean);
        assert_eq!(v.default, Some(serde_json::Value::Bool(false)));
        assert!(v.lifetime.is_some());
    }

    #[test]
    fn boolean_flag_shorthand_rejects_typed_fields_without_type() {
        // Declaring `default:` without `type:` is ambiguous — fail closed.
        let yaml = "name: x\ndefault: 42\n";
        let err = serde_yaml::from_str::<Variable>(yaml)
            .unwrap_err()
            .to_string();
        assert!(err.contains("`type:` required"));
    }

    /// §10.2: `update:` is the v2 merge mechanism. The legacy
    /// `update_policy:` enum is rejected with a migration hint.
    #[test]
    fn parses_variable_with_update_expression() {
        let yaml = "
name: tags
type: array
update: \"union(@current, @incoming)\"
populated_by:
  - kind: tool
    name: get_tags
    phase: after
    expression: \"@result.tags\"
reset_by:
  - kind: tool
    name: send_message
    phase: after
";
        let v: Variable = serde_yaml::from_str(yaml).unwrap();
        assert_eq!(v.update.as_deref(), Some("union(@current, @incoming)"));
        assert_eq!(v.populated_by.len(), 1);
        assert_eq!(v.reset_by.len(), 1);
    }

    /// §10.1 `type: enum` requires a non-empty `members:` list.
    #[test]
    fn parses_enum_with_members() {
        let yaml = "
name: data_sensitivity
type: enum
members: [public, internal, confidential, restricted]
default: public
update: \"max(@current, @incoming)\"
";
        let v: Variable = serde_yaml::from_str(yaml).unwrap();
        assert_eq!(v.var_type, VariableType::Enum);
        assert_eq!(
            v.members.as_deref().unwrap(),
            ["public", "internal", "confidential", "restricted"]
        );
        assert_eq!(v.default, Some(serde_json::Value::String("public".into())));
    }

    #[test]
    fn enum_without_members_rejected() {
        let yaml = "name: x\ntype: enum\n";
        let err = serde_yaml::from_str::<Variable>(yaml)
            .unwrap_err()
            .to_string();
        assert!(err.contains("requires a `members:`"));
    }

    #[test]
    fn enum_default_must_be_in_members() {
        let yaml = "
name: x
type: enum
members: [a, b, c]
default: d
";
        let err = serde_yaml::from_str::<Variable>(yaml)
            .unwrap_err()
            .to_string();
        assert!(err.contains("not in `members:`"));
    }

    #[test]
    fn members_only_valid_on_enum() {
        let yaml = "name: x\ntype: string\nmembers: [a, b]\n";
        let err = serde_yaml::from_str::<Variable>(yaml)
            .unwrap_err()
            .to_string();
        assert!(err.contains("only valid on `type: enum`"));
    }

    #[test]
    fn rejects_v1_update_policy() {
        let yaml = "name: x\ntype: number\nupdate_policy: max\n";
        let err = serde_yaml::from_str::<Variable>(yaml)
            .unwrap_err()
            .to_string();
        assert!(err.contains("rejected v1 field `update_policy`"));
        assert!(err.contains("update: \"max(@current, @incoming)\""));
    }

    #[test]
    fn rejects_v1_properties() {
        let yaml = "name: x\ntype: object\nproperties:\n  foo:\n    update_policy: max\n";
        let err = serde_yaml::from_str::<Variable>(yaml)
            .unwrap_err()
            .to_string();
        assert!(err.contains("rejected v1 field `properties`"));
    }

    #[test]
    fn rejects_v1_ordering() {
        let yaml = "name: x\ntype: string\nordering: [a, b]\n";
        let err = serde_yaml::from_str::<Variable>(yaml)
            .unwrap_err()
            .to_string();
        assert!(err.contains("rejected v1 field `ordering`"));
        assert!(err.contains("type: enum"));
    }

    #[test]
    fn rejects_v1_source_field() {
        let yaml = "name: x\ntype: boolean\nsource: \"foo\"\n";
        let err = serde_yaml::from_str::<Variable>(yaml)
            .unwrap_err()
            .to_string();
        assert!(err.contains("rejected v1 field `source`"));
    }

    #[test]
    fn rejects_v1_sticky_on_deny() {
        let yaml = "name: x\ntype: boolean\nsticky_on_deny: true\n";
        let err = serde_yaml::from_str::<Variable>(yaml)
            .unwrap_err()
            .to_string();
        assert!(err.contains("sticky_on_deny"));
    }

    #[test]
    fn rejects_invalid_name() {
        let yaml = "name: BadName\ntype: boolean\n";
        let err = serde_yaml::from_str::<Variable>(yaml)
            .unwrap_err()
            .to_string();
        assert!(err.contains("snake_case"));
    }

    #[test]
    fn rejects_phase_before_with_result_expr() {
        let yaml = "
name: ctr
type: number
populated_by:
  - kind: tool
    name: x
    phase: before
    expression: \"result.value + 1\"
";
        let err = serde_yaml::from_str::<Variable>(yaml)
            .unwrap_err()
            .to_string();
        assert!(err.contains("phase: before"));
    }

    #[test]
    fn requires_phase_in_reset_by() {
        let yaml = "
name: x
type: object
reset_by:
  - kind: tool
    name: y
";
        let err = serde_yaml::from_str::<Variable>(yaml)
            .unwrap_err()
            .to_string();
        assert!(err.contains("phase"));
    }

    #[test]
    fn deserializes_resolver_inline() {
        let yaml = "
name: x
type: boolean
on_demand_by:
  kind: human
  prompt: \"Approve?\"
";
        let v: Variable = serde_yaml::from_str(yaml).unwrap();
        assert!(v.on_demand_by.is_some());
    }
}
