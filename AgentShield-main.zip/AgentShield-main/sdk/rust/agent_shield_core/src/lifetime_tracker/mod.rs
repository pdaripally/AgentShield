//! Lifetime tracking for variables, predicates, and events.
//!
//! ## Spec mapping
//!
//! - §10.1 — bare and map lifetime forms (variables only get the map form).
//! - §9.1.3 — expiry transitions: variable `@status` → `unset`, predicate
//!   memoization invalidated, event latch cleared.
//! - §10.5 — host-emission approval auto-flip and `clear_event` revocation.
//! - §9.3 — variable status envelope (`@status`, `@set_at`, `@expires_at`,
//!   `@deny_reason`).
//!
//! The tracker pairs with [`crate::event_bus::EventBus`]:
//!
//! - `until_event:` lifetimes register a one-shot subscription on the bus so
//!   the variable / predicate cache invalidates when the named event fires.
//! - `for: <duration>` lifetimes are checked at every read against `time.now()`.
//!   Per §9.1.1, proactive expiry is OPTIONAL; we do reactive expiry only.
//! - Scope-bounded lifetimes (`per_call`, `per_turn`, `per_session`,
//!   `per_request`) are cleared by the runtime calling
//!   [`LifetimeTracker::clear_per_call`], `_per_turn`, `_per_session`, and
//!   `_per_request` at the appropriate boundary.
//! - Approval auto-flip (§10.5) is wired by registering a subscriber that
//!   listens for `approval.<variable>.<outcome>` emissions and `Cleared`
//!   notifications.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

use chrono::{DateTime, Utc};
use serde_json::Value;

use super::event_bus::{BusEvent, EventBus};
use super::events::{ApprovalEventKind, EventId};
use super::lifetime::{BareLifetime, LifetimeBranch};
use super::session_id::SessionId;
use super::update_policy::apply_update;
use super::variables::Variable;

// ── Submodule layout ─────────────────────────────────────────────
//
// The `lifetime_tracker` module is split into:
//
//   - this file (`mod.rs`): the locked state model (`Inner`,
//     `SessionState`, `LifetimeTracker`) and all `&mut self` write
//     paths. This is the security-critical section and is
//     deliberately kept in one place.
//   - [`helpers`]: variant types, parsers, and pure functions that
//     do not touch session state.
//   - `tests` (gated on `cfg(test)`): the unit-test module.
//
// All previously `pub` / `pub(crate)` symbols are re-exported here
// so external paths like `crate::lifetime_tracker::VarStatus` resolve
// to the same items as before this refactor.

mod helpers;
#[cfg(test)]
mod tests;

use helpers::{approval_value, default_deny_reason, evaluate_lifetime_expression};
pub(crate) use helpers::{canonical_key, select_branch_raw};
pub use helpers::{
    select_branch, PredicateState, ResolverOutcome, TrackerError, VarStatus, VariableState,
};

// ── Tracker state ────────────────────────────────────────────────────

type ClockFn = Arc<dyn Fn() -> DateTime<Utc> + Send + Sync>;

/// Per-session mutable state. Each [`crate::runtime::GuardrailsSession`]
/// gets its own slot (created lazily on first access) so concurrent
/// sessions don't see each other's variables, predicate memo, or
/// resolver outcomes (spec §9 / §10).
#[derive(Default)]
struct SessionState {
    /// Per-`(variable_name, key)` cache state. Non-keyed variables use
    /// `None` as the key tuple element. Keyed variables (§9.4)
    /// canonicalize the key value to a deterministic JSON string and
    /// store one independent entry per key.
    vars: HashMap<(String, Option<String>), VariableState>,
    /// Per-predicate memoization.
    predicates: HashMap<String, PredicateState>,
}

struct Inner {
    /// Master registry of declared variables (provides `default:`,
    /// `type:`, lifetime config). Owned by the runtime in P9; we accept a
    /// snapshot here.
    registry: HashMap<String, Variable>,
    /// Per-session storage. Sessions are inserted lazily on first
    /// access via [`Inner::session_state_mut`]. Dropped explicitly
    /// when [`LifetimeTracker::cleanup_session`] is called from
    /// [`crate::runtime::GuardrailsSession::close`] / `Drop`.
    sessions: HashMap<SessionId, SessionState>,
    clock: ClockFn,
}

impl Inner {
    fn now(&self) -> DateTime<Utc> {
        (self.clock)()
    }

    /// Lazily allocate session state on first touch.
    fn session_state_mut(&mut self, sid: &SessionId) -> &mut SessionState {
        self.sessions.entry(sid.clone()).or_default()
    }
}

/// Public facade.
#[derive(Clone)]
pub struct LifetimeTracker {
    inner: Arc<Mutex<Inner>>,
    bus: EventBus,
}

impl std::fmt::Debug for LifetimeTracker {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("LifetimeTracker").finish_non_exhaustive()
    }
}

impl LifetimeTracker {
    /// Build a new tracker.  `registry` is a snapshot of declared variables
    /// (the host runtime keeps the master copy and re-issues snapshots
    /// as configs reload).
    pub fn new(bus: EventBus, registry: HashMap<String, Variable>) -> Arc<Self> {
        Self::with_clock(bus, registry, Arc::new(Utc::now))
    }

    pub fn with_clock(
        bus: EventBus,
        registry: HashMap<String, Variable>,
        clock: ClockFn,
    ) -> Arc<Self> {
        let inner = Inner {
            registry,
            sessions: HashMap::new(),
            clock,
        };
        let tracker = Arc::new(Self {
            inner: Arc::new(Mutex::new(inner)),
            bus: bus.clone(),
        });
        // Wire the auto-flip subscriber.
        let weak_tracker = Arc::downgrade(&tracker);
        bus.subscribe(None, move |ev: &BusEvent| {
            if let Some(t) = weak_tracker.upgrade() {
                t.handle_bus_event(ev);
            }
        });
        tracker
    }

    /// The bus this tracker is wired to.
    pub fn bus(&self) -> &EventBus {
        &self.bus
    }

    // ── Subscriber callback (§10.5 wiring) ──────────────────────────

    fn handle_bus_event(&self, ev: &BusEvent) {
        match ev {
            BusEvent::Emitted {
                session_id,
                event_id,
                payload,
                ..
            } => {
                self.on_event_emitted(session_id, event_id, payload.as_ref());
            }
            BusEvent::Cleared {
                session_id,
                event_id,
                ..
            } => {
                self.on_event_cleared(session_id, event_id);
            }
        }
    }

    fn on_event_emitted(
        &self,
        session_id: &SessionId,
        event_id: &EventId,
        payload: Option<&Value>,
    ) {
        // 1. until_event: invalidation for any variable / predicate watching
        //    this event id WITHIN THIS SESSION. Tracks `(name, key)`
        //    tuples so per-key entries (§9.4) are invalidated independently.
        let mut to_clear_vars: Vec<(String, Option<String>)> = Vec::new();
        let mut to_clear_preds: Vec<String> = Vec::new();
        {
            let inner = self.inner.lock().unwrap();
            if let Some(state) = inner.sessions.get(session_id) {
                for ((name, key), st) in &state.vars {
                    if st.until_events.contains(event_id) {
                        to_clear_vars.push((name.clone(), key.clone()));
                    }
                }
                for (name, st) in &state.predicates {
                    if st.until_events.contains(event_id) {
                        to_clear_preds.push(name.clone());
                    }
                }
            }
        }
        if !to_clear_vars.is_empty() || !to_clear_preds.is_empty() {
            let mut inner = self.inner.lock().unwrap();
            let state = inner.session_state_mut(session_id);
            for (name, key) in to_clear_vars {
                state.vars.remove(&(name, key));
            }
            for p in to_clear_preds {
                state.predicates.remove(&p);
            }
        }

        // 2. Approval auto-flip (§10.5) — scoped to the emitting session.
        if let EventId::Approval { variable, kind } = event_id {
            self.auto_flip(session_id, variable, *kind, payload, event_id.clone());
        }
    }

    fn on_event_cleared(&self, session_id: &SessionId, event_id: &EventId) {
        // Revocation: remove `event_id` from each variable's
        // `auto_flipped_by` provenance list IN THIS SESSION ONLY. A
        // variable returns to `unset` only when its provenance list
        // becomes empty (§10.5).
        let to_revert: Vec<(String, Option<String>)> = {
            let mut inner = self.inner.lock().unwrap();
            let mut out: Vec<(String, Option<String>)> = Vec::new();
            if let Some(state) = inner.sessions.get_mut(session_id) {
                for ((n, key), st) in state.vars.iter_mut() {
                    if st.auto_flipped_by.iter().any(|e| e == event_id) {
                        st.auto_flipped_by.retain(|e| e != event_id);
                        if st.auto_flipped_by.is_empty() {
                            out.push((n.clone(), key.clone()));
                        }
                    }
                }
            }
            out
        };
        if !to_revert.is_empty() {
            let mut inner = self.inner.lock().unwrap();
            let state = inner.session_state_mut(session_id);
            for (name, key) in to_revert {
                state.vars.remove(&(name, key));
            }
        }
    }

    fn auto_flip(
        &self,
        session_id: &SessionId,
        variable: &str,
        kind: ApprovalEventKind,
        payload: Option<&Value>,
        source_event: EventId,
    ) {
        let mut inner = self.inner.lock().unwrap();
        let Some(decl) = inner.registry.get(variable).cloned() else {
            // §10.5: if `<name>` doesn't match a declared variable, no
            // auto-flip — the latch remains observable via `event.fired()`.
            return;
        };
        let now = inner.now();

        let outcome = ResolverOutcome::from_approval_kind(kind);
        let branch = decl.lifetime.as_ref().map(|l| select_branch(l, outcome));
        let (expires_at, until_events) = match &branch {
            Some(BareLifetime::For(d)) => (Some(now + *d), Vec::new()),
            Some(BareLifetime::UntilEvent(ids)) => (None, ids.clone()),
            _ => (None, Vec::new()),
        };

        let state = inner.session_state_mut(session_id);

        // §10.5: re-emission of `approval.<var>.<outcome>` supersedes any
        // previously latched outcome for the same variable. The new emission
        // becomes the sole entry in `auto_flipped_by` so that the most
        // recent outcome reflects the variable's state and clearing the
        // earlier event has no revocation effect.
        match kind {
            ApprovalEventKind::Allow => {
                let value = approval_value(&decl, payload);
                state.vars.insert(
                    (variable.to_string(), None),
                    VariableState {
                        value,
                        status: VarStatus::Resolved,
                        set_at: now,
                        expires_at,
                        lifetime_branch: branch,
                        deny_reason: None,
                        until_events,
                        auto_flipped_by: vec![source_event],
                        source_kind: Some("approval".into()),
                        set_by: Some(format!("approval:{}", variable)),
                        source_params: None,
                    },
                );
            }
            ApprovalEventKind::Deny | ApprovalEventKind::Cancelled => {
                let reason = payload
                    .and_then(|p| p.get("reason"))
                    .and_then(|r| r.as_str())
                    .map(str::to_string)
                    .or_else(|| Some(default_deny_reason(kind).to_string()));
                state.vars.insert(
                    (variable.to_string(), None),
                    VariableState {
                        value: Value::Null,
                        status: VarStatus::Denied,
                        set_at: now,
                        expires_at,
                        lifetime_branch: branch,
                        deny_reason: reason,
                        until_events,
                        auto_flipped_by: vec![source_event],
                        source_kind: Some("approval".into()),
                        set_by: Some(format!("approval:{}", variable)),
                        source_params: None,
                    },
                );
            }
        }
    }

    // ── Variables ───────────────────────────────────────────────────

    /// Read a variable's current state, lazily expiring it if the lifetime
    /// has elapsed (§9.1.3 / §9.1.1). Non-keyed accessor — see
    /// [`Self::read_variable_keyed`] for keyed variables (§9.4).
    pub fn read_variable(&self, name: &str) -> VariableState {
        self.read_variable_keyed(name, None)
    }

    /// Session-scoped variant of [`Self::read_variable`].
    pub fn read_variable_in(&self, session_id: &SessionId, name: &str) -> VariableState {
        self.read_variable_keyed_in(session_id, name, None)
    }

    /// Read a keyed variable's current state. `key = None` reads the
    /// non-keyed slot (and is what `read_variable` delegates to). For
    /// keyed variables (§9.4), the runtime evaluates `key:` against
    /// the reader's bound namespace and passes the result here.
    /// Missing key entries return `@status == 'unset'` per §9.4.4.
    pub fn read_variable_keyed(&self, name: &str, key: Option<&Value>) -> VariableState {
        self.read_variable_keyed_in(&SessionId::default(), name, key)
    }

    /// Session-scoped variant of [`Self::read_variable_keyed`].
    pub fn read_variable_keyed_in(
        &self,
        session_id: &SessionId,
        name: &str,
        key: Option<&Value>,
    ) -> VariableState {
        let key_id = canonical_key(key);
        let expired = {
            let inner = self.inner.lock().unwrap();
            let now = inner.now();
            inner
                .sessions
                .get(session_id)
                .and_then(|s| s.vars.get(&(name.to_string(), key_id.clone())))
                .and_then(|st| st.expires_at.map(|e| now >= e))
                .unwrap_or(false)
        };
        if expired {
            let mut inner = self.inner.lock().unwrap();
            let state = inner.session_state_mut(session_id);
            state.vars.remove(&(name.to_string(), key_id.clone()));
        }
        let inner = self.inner.lock().unwrap();
        let now = inner.now();
        inner
            .sessions
            .get(session_id)
            .and_then(|s| s.vars.get(&(name.to_string(), key_id)).cloned())
            .unwrap_or_else(|| VariableState::unset(now))
    }

    /// True iff the variable is currently `Resolved` (after lazy expiry).
    pub fn is_resolved(&self, name: &str) -> bool {
        matches!(self.read_variable(name).status, VarStatus::Resolved)
    }

    pub fn is_resolved_in(&self, session_id: &SessionId, name: &str) -> bool {
        matches!(
            self.read_variable_in(session_id, name).status,
            VarStatus::Resolved
        )
    }

    /// Read-only snapshot of every currently-`Resolved` variable's value
    /// keyed by variable name. Used by §10.5.1 populator evaluation (which
    /// needs a `variable_state` map of resolved values to pass to the
    /// expression evaluator).
    /// Read-only snapshot of every currently-`Resolved` non-keyed
    /// variable's value, keyed by variable name. Per §9.4 keyed
    /// entries are excluded — populator-state callers don't have a
    /// well-defined "current key" to choose, and {variables} template
    /// substitution treats keyed variables as opaque per-key stores.
    pub fn resolved_snapshot(&self) -> HashMap<String, Value> {
        self.resolved_snapshot_in(&SessionId::default())
    }

    /// Session-scoped variant of [`Self::resolved_snapshot`].
    pub fn resolved_snapshot_in(&self, session_id: &SessionId) -> HashMap<String, Value> {
        let inner = self.inner.lock().unwrap();
        match inner.sessions.get(session_id) {
            Some(state) => state
                .vars
                .iter()
                .filter(|((_, key), st)| key.is_none() && matches!(st.status, VarStatus::Resolved))
                .map(|((name, _), st)| (name.clone(), st.value.clone()))
                .collect(),
            None => HashMap::new(),
        }
    }

    /// Apply a host-driven write to a variable.  `outcome` selects the branch
    /// from the declared `lifetime:` (map form) or is ignored (bare form).
    /// Stamps `set_at = now()` and computes `expires_at` for `for:` branches.
    ///
    /// This is the **low-level bypass** — it stores `value` *as-is* without
    /// running it through [`crate::update_policy::apply_update`]. Use
    /// [`Self::set_variable`] for the canonical write path that honors the
    /// variable's declared `update_policy:`.
    pub fn write_variable(
        &self,
        name: &str,
        value: Value,
        outcome: ResolverOutcome,
    ) -> Result<(), TrackerError> {
        self.write_variable_in(&SessionId::default(), name, value, outcome)
    }

    /// Session-scoped variant of [`Self::write_variable`].
    pub fn write_variable_in(
        &self,
        session_id: &SessionId,
        name: &str,
        value: Value,
        outcome: ResolverOutcome,
    ) -> Result<(), TrackerError> {
        let mut inner = self.inner.lock().unwrap();
        let decl = inner
            .registry
            .get(name)
            .cloned()
            .ok_or_else(|| TrackerError::UnknownVariable(name.to_string()))?;
        let now = inner.now();
        let branch = decl.lifetime.as_ref().map(|l| select_branch(l, outcome));
        let (expires_at, until_events) = match &branch {
            Some(BareLifetime::For(d)) => (Some(now + *d), Vec::new()),
            Some(BareLifetime::UntilEvent(ids)) => (None, ids.clone()),
            _ => (None, Vec::new()),
        };
        let status = match outcome {
            ResolverOutcome::Allow => VarStatus::Resolved,
            ResolverOutcome::Deny | ResolverOutcome::Cancelled => VarStatus::Denied,
        };
        let state = inner.session_state_mut(session_id);
        state.vars.insert(
            (name.to_string(), None),
            VariableState {
                value,
                status,
                set_at: now,
                expires_at,
                lifetime_branch: branch,
                deny_reason: None,
                until_events,
                auto_flipped_by: Vec::new(),
                source_kind: None,
                set_by: None,
                source_params: None,
            },
        );
        Ok(())
    }

    /// Canonical write path (§21 runtime API surface). Non-keyed
    /// accessor — see [`Self::set_variable_keyed`] for keyed variables
    /// (§9.4).
    pub fn set_variable(
        &self,
        name: &str,
        new_value: Value,
        source_kind: Option<&str>,
        set_by: Option<&str>,
        outcome: ResolverOutcome,
    ) -> Result<(), TrackerError> {
        self.set_variable_keyed(name, None, new_value, source_kind, set_by, outcome)
    }

    /// Session-scoped variant of [`Self::set_variable`].
    pub fn set_variable_in(
        &self,
        session_id: &SessionId,
        name: &str,
        new_value: Value,
        source_kind: Option<&str>,
        set_by: Option<&str>,
        outcome: ResolverOutcome,
    ) -> Result<(), TrackerError> {
        self.set_variable_keyed_in(
            session_id,
            name,
            None,
            new_value,
            source_kind,
            set_by,
            outcome,
        )
    }

    /// Keyed write path. The runtime evaluates the variable's `key:`
    /// against the writer's bound namespace and passes the result here;
    /// hosts using the runtime API supply the key explicitly. A `None`
    /// key writes the non-keyed slot. Per §9.4.2: a `null` key MUST
    /// be rejected — keyed writes cannot land on `key == null`.
    #[allow(clippy::too_many_arguments)]
    pub fn set_variable_keyed(
        &self,
        name: &str,
        key: Option<&Value>,
        new_value: Value,
        source_kind: Option<&str>,
        set_by: Option<&str>,
        outcome: ResolverOutcome,
    ) -> Result<(), TrackerError> {
        self.set_variable_keyed_full(name, key, new_value, source_kind, set_by, None, outcome)
    }

    /// Session-scoped variant of [`Self::set_variable_keyed`].
    #[allow(clippy::too_many_arguments)]
    pub fn set_variable_keyed_in(
        &self,
        session_id: &SessionId,
        name: &str,
        key: Option<&Value>,
        new_value: Value,
        source_kind: Option<&str>,
        set_by: Option<&str>,
        outcome: ResolverOutcome,
    ) -> Result<(), TrackerError> {
        self.set_variable_keyed_full_in(
            session_id,
            name,
            key,
            new_value,
            source_kind,
            set_by,
            None,
            outcome,
        )
    }

    /// Full keyed write surface used by populator and resolver paths
    /// that capture the §9.3.2 `@source_params` snapshot — the
    /// resource-bound namespace at the writer's call site (for `tool`
    /// and `agent` writers, the call's `params`; for `endpoint`, the
    /// merged `{ path, query, body }` object). Host runtime API writes
    /// pass `source_params = None`.
    #[allow(clippy::too_many_arguments)]
    pub fn set_variable_keyed_full(
        &self,
        name: &str,
        key: Option<&Value>,
        new_value: Value,
        source_kind: Option<&str>,
        set_by: Option<&str>,
        source_params: Option<Value>,
        outcome: ResolverOutcome,
    ) -> Result<(), TrackerError> {
        self.set_variable_keyed_full_in(
            &SessionId::default(),
            name,
            key,
            new_value,
            source_kind,
            set_by,
            source_params,
            outcome,
        )
    }

    /// Session-scoped variant of [`Self::set_variable_keyed_full`] —
    /// the canonical primary write path. The session-aware variant of
    /// every other write helper delegates here.
    #[allow(clippy::too_many_arguments)]
    pub fn set_variable_keyed_full_in(
        &self,
        session_id: &SessionId,
        name: &str,
        key: Option<&Value>,
        new_value: Value,
        source_kind: Option<&str>,
        set_by: Option<&str>,
        source_params: Option<Value>,
        outcome: ResolverOutcome,
    ) -> Result<(), TrackerError> {
        // §9.4.2: null key is rejected for keyed-variable writes. The
        // legitimate non-keyed write uses `key = None` (no `key:`
        // expression on the variable); a `key = Some(Null)` indicates
        // the writer's `key:` expression evaluated to null and per spec
        // MUST be dropped with a structured warning.
        if let Some(Value::Null) = key {
            log::warn!(
                target: "agent_shield::lifetime_tracker",
                "variable `{}`: keyed write rejected — `key:` evaluated to null (§9.4.2)",
                name
            );
            return Ok(());
        }
        let key_id = canonical_key(key);
        // Hold the inner lock for the read + apply_update + write so concurrent
        // writes can't lose updates on `collect`/`merge` policies (which
        // read-modify-write the existing value). `apply_update` is pure
        // (no I/O, no callbacks) and bounded by the variable's value size,
        // so holding the lock across it is safe and short.
        {
            let mut inner = self.inner.lock().unwrap();
            let decl = inner
                .registry
                .get(name)
                .cloned()
                .ok_or_else(|| TrackerError::UnknownVariable(name.to_string()))?;
            let storage_key = (name.to_string(), key_id.clone());
            let current_value = inner
                .sessions
                .get(session_id)
                .and_then(|s| s.vars.get(&storage_key))
                .filter(|st| matches!(st.status, VarStatus::Resolved))
                .map(|st| st.value.clone());

            let merged = apply_update(&decl, current_value.as_ref(), new_value)
                .map_err(TrackerError::UpdatePolicy)?;

            let now = inner.now();
            // §9.1.2.1 — when the lifetime branch is in `expression:`
            // form, evaluate it now (after `update:` has produced the
            // stored value) against `@incoming` (the just-stored value)
            // and `@current` (the prior value, or null). Per spec the
            // result MUST be a recognized literal form; we coerce
            // strings, durations, and `for:`/`until_event:` maps and
            // fall back to PerSession on any malformed result.
            let branch: Option<BareLifetime> = match decl.lifetime.as_ref() {
                None => None,
                Some(l) => {
                    let raw = select_branch_raw(l, outcome);
                    Some(match raw {
                        LifetimeBranch::Bare(b) => b,
                        LifetimeBranch::Expression(expr) => {
                            evaluate_lifetime_expression(&expr, &merged, current_value.as_ref())
                        }
                    })
                }
            };
            let (expires_at, until_events) = match &branch {
                Some(BareLifetime::For(d)) => (Some(now + *d), Vec::new()),
                Some(BareLifetime::UntilEvent(ids)) => (None, ids.clone()),
                _ => (None, Vec::new()),
            };
            let status = match outcome {
                ResolverOutcome::Allow => VarStatus::Resolved,
                ResolverOutcome::Deny | ResolverOutcome::Cancelled => VarStatus::Denied,
            };
            // §9.3.2: @source_params is captured only on a successful
            // resolved-write. On deny/cancelled (denied state) we do
            // not stamp a source_params snapshot; the spec scopes it to
            // the @status == 'resolved' transition.
            let stamped_source_params = match status {
                VarStatus::Resolved => source_params,
                _ => None,
            };
            let state = inner.session_state_mut(session_id);
            state.vars.insert(
                storage_key,
                VariableState {
                    value: merged,
                    status,
                    set_at: now,
                    expires_at,
                    lifetime_branch: branch,
                    deny_reason: None,
                    until_events,
                    auto_flipped_by: Vec::new(),
                    source_kind: source_kind.map(str::to_string),
                    set_by: set_by.map(str::to_string),
                    source_params: stamped_source_params,
                },
            );
        }

        // Emit AFTER the lock drops. Errors here are logged but don't fail
        // the write — an emission failure usually means a bus subscriber
        // misbehaved and we don't want a write to roll back over downstream
        // noise.
        // §9.4.5: variable.<name>.changed events for keyed variables
        // include the key in the payload so subscribers can disambiguate.
        let payload = key.map(|k| serde_json::json!({ "key": k }));
        if let Err(e) = self
            .bus
            .emit_variable_changed_with_payload_in(session_id, name, payload)
        {
            log::warn!("variable.{}.changed emission failed: {}", name, e);
        }
        Ok(())
    }

    /// Drop a non-keyed variable's cached state (transition to `unset`).
    /// Use [`Self::invalidate_variable_keyed`] for keyed variables.
    pub fn invalidate_variable(&self, name: &str) {
        self.invalidate_variable_keyed(name, None);
    }

    pub fn invalidate_variable_in(&self, session_id: &SessionId, name: &str) {
        self.invalidate_variable_keyed_in(session_id, name, None);
    }

    /// Drop a keyed variable's cached state for a specific key.
    pub fn invalidate_variable_keyed(&self, name: &str, key: Option<&Value>) {
        self.invalidate_variable_keyed_in(&SessionId::default(), name, key);
    }

    pub fn invalidate_variable_keyed_in(
        &self,
        session_id: &SessionId,
        name: &str,
        key: Option<&Value>,
    ) {
        let key_id = canonical_key(key);
        let mut inner = self.inner.lock().unwrap();
        let state = inner.session_state_mut(session_id);
        state.vars.remove(&(name.to_string(), key_id));
    }

    // ── Predicates ──────────────────────────────────────────────────

    /// Memoize a predicate result with the given lifetime.
    pub fn memoize_predicate(&self, name: &str, value: bool, lifetime: Option<BareLifetime>) {
        self.memoize_predicate_in(&SessionId::default(), name, value, lifetime);
    }

    /// Session-scoped variant of [`Self::memoize_predicate`].
    pub fn memoize_predicate_in(
        &self,
        session_id: &SessionId,
        name: &str,
        value: bool,
        lifetime: Option<BareLifetime>,
    ) {
        let mut inner = self.inner.lock().unwrap();
        let now = inner.now();
        let (expires_at, until_events) = match &lifetime {
            Some(BareLifetime::For(d)) => (Some(now + *d), Vec::new()),
            Some(BareLifetime::UntilEvent(ids)) => (None, ids.clone()),
            _ => (None, Vec::new()),
        };
        let state = inner.session_state_mut(session_id);
        state.predicates.insert(
            name.to_string(),
            PredicateState {
                value,
                set_at: now,
                expires_at,
                lifetime,
                until_events,
            },
        );
    }

    /// Read a memoized predicate. Returns `None` if absent or expired (and
    /// removes expired entries lazily).
    pub fn read_predicate(&self, name: &str) -> Option<bool> {
        self.read_predicate_in(&SessionId::default(), name)
    }

    pub fn read_predicate_in(&self, session_id: &SessionId, name: &str) -> Option<bool> {
        let expired = {
            let inner = self.inner.lock().unwrap();
            let now = inner.now();
            inner
                .sessions
                .get(session_id)
                .and_then(|s| s.predicates.get(name))
                .and_then(|st| st.expires_at.map(|e| now >= e))
                .unwrap_or(false)
        };
        if expired {
            self.invalidate_predicate_in(session_id, name);
            return None;
        }
        self.inner
            .lock()
            .unwrap()
            .sessions
            .get(session_id)
            .and_then(|s| s.predicates.get(name).map(|st| st.value))
    }

    pub fn invalidate_predicate(&self, name: &str) {
        self.invalidate_predicate_in(&SessionId::default(), name);
    }

    pub fn invalidate_predicate_in(&self, session_id: &SessionId, name: &str) {
        let mut inner = self.inner.lock().unwrap();
        let state = inner.session_state_mut(session_id);
        state.predicates.remove(name);
    }

    // ── Scope-boundary clearers (called by the runtime in P9) ──────

    /// Clear every cached value whose lifetime branch is `per_call`.
    pub fn clear_per_call(&self) {
        self.clear_per_call_in(&SessionId::default());
    }

    pub fn clear_per_call_in(&self, session_id: &SessionId) {
        self.clear_scope(Some(session_id), BareLifetime::PerCall);
    }

    pub fn clear_per_turn(&self) {
        self.clear_per_turn_in(&SessionId::default());
    }

    pub fn clear_per_turn_in(&self, session_id: &SessionId) {
        self.clear_scope(Some(session_id), BareLifetime::PerTurn);
    }

    pub fn clear_per_session(&self) {
        self.clear_per_session_in(&SessionId::default());
    }

    pub fn clear_per_session_in(&self, session_id: &SessionId) {
        self.clear_scope(Some(session_id), BareLifetime::PerSession);
    }

    pub fn clear_per_request(&self) {
        self.clear_per_request_in(&SessionId::default());
    }

    pub fn clear_per_request_in(&self, session_id: &SessionId) {
        self.clear_scope(Some(session_id), BareLifetime::PerRequest);
    }

    fn clear_scope(&self, session_id: Option<&SessionId>, scope: BareLifetime) {
        let mut inner = self.inner.lock().unwrap();
        // Snapshot which sessions to walk (to side-step borrow issues).
        let sids: Vec<SessionId> = match session_id {
            Some(s) => vec![s.clone()],
            None => inner.sessions.keys().cloned().collect(),
        };
        for sid in sids {
            let Some(state) = inner.sessions.get_mut(&sid) else {
                continue;
            };
            let var_drop: Vec<(String, Option<String>)> = state
                .vars
                .iter()
                .filter_map(|((n, key), st)| {
                    if st.lifetime_branch.as_ref() == Some(&scope) {
                        Some((n.clone(), key.clone()))
                    } else {
                        None
                    }
                })
                .collect();
            for entry in var_drop {
                state.vars.remove(&entry);
            }
            let pred_drop: Vec<String> = state
                .predicates
                .iter()
                .filter_map(|(n, st)| {
                    if st.lifetime.as_ref() == Some(&scope) {
                        Some(n.clone())
                    } else {
                        None
                    }
                })
                .collect();
            for n in pred_drop {
                state.predicates.remove(&n);
            }
        }
    }

    /// Drop all per-session state for `session_id`. Called when a
    /// [`crate::runtime::GuardrailsSession`] is dropped or closed so
    /// dangling variable / predicate state doesn't accumulate. Idempotent
    /// — re-calling on a session that's already been cleaned up is a
    /// no-op.
    pub fn cleanup_session(&self, session_id: &SessionId) {
        let mut inner = self.inner.lock().unwrap();
        inner.sessions.remove(session_id);
    }

    // ── Diagnostics / introspection helpers ─────────────────────────

    /// Total variable entries across ALL sessions. Diagnostic only.
    pub fn variable_count(&self) -> usize {
        self.inner
            .lock()
            .unwrap()
            .sessions
            .values()
            .map(|s| s.vars.len())
            .sum()
    }

    /// Variable entries for `session_id`.
    pub fn variable_count_in(&self, session_id: &SessionId) -> usize {
        self.inner
            .lock()
            .unwrap()
            .sessions
            .get(session_id)
            .map(|s| s.vars.len())
            .unwrap_or(0)
    }

    pub fn predicate_count(&self) -> usize {
        self.inner
            .lock()
            .unwrap()
            .sessions
            .values()
            .map(|s| s.predicates.len())
            .sum()
    }

    pub fn predicate_count_in(&self, session_id: &SessionId) -> usize {
        self.inner
            .lock()
            .unwrap()
            .sessions
            .get(session_id)
            .map(|s| s.predicates.len())
            .unwrap_or(0)
    }

    /// Replace the registry in place. Used on config reload.
    pub fn replace_registry(&self, registry: HashMap<String, Variable>) {
        self.inner.lock().unwrap().registry = registry;
    }
}
