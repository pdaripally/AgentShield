//! Tests extracted from the previous monolithic `lifetime_tracker.rs`.
//! Logic and assertions are unchanged — only the file location moved.

use super::*;
use crate::event_bus::EventFiredHook;
use crate::lifetime::{Lifetime, LifetimeBranch, LifetimeMap};
use crate::variables::VariableType;
use chrono::Duration;
use std::sync::atomic::{AtomicI64, Ordering};

fn t0() -> DateTime<Utc> {
    DateTime::<Utc>::from_timestamp(1_700_000_000, 0).unwrap()
}

fn make_clock(t: DateTime<Utc>) -> (ClockFn, Arc<AtomicI64>) {
    let secs = Arc::new(AtomicI64::new(t.timestamp()));
    let s2 = secs.clone();
    let f: ClockFn =
        Arc::new(move || DateTime::<Utc>::from_timestamp(s2.load(Ordering::SeqCst), 0).unwrap());
    (f, secs)
}

fn var(name: &str, ty: VariableType) -> Variable {
    Variable {
        name: name.to_string(),
        var_type: ty,
        description: None,
        default: None,
        members: None,
        update: None,
        key: None,
        lifetime: None,
        on_demand_by: None,
        populated_by: vec![],
        reset_by: vec![],
    }
}

fn var_with_lifetime(name: &str, ty: VariableType, lifetime: Lifetime) -> Variable {
    let mut v = var(name, ty);
    v.lifetime = Some(lifetime);
    v
}

fn bus_with_clock(t: DateTime<Utc>) -> (EventBus, Arc<AtomicI64>) {
    let (clock, secs) = make_clock(t);
    let bus = EventBus::with_clock(clock);
    (bus, secs)
}

fn tracker(bus: EventBus, secs: Arc<AtomicI64>, decls: Vec<Variable>) -> Arc<LifetimeTracker> {
    let s2 = secs;
    let clock: ClockFn =
        Arc::new(move || DateTime::<Utc>::from_timestamp(s2.load(Ordering::SeqCst), 0).unwrap());
    let registry: HashMap<String, Variable> =
        decls.into_iter().map(|v| (v.name.clone(), v)).collect();
    LifetimeTracker::with_clock(bus, registry, clock)
}

#[test]
fn variable_for_lifetime_expires_to_unset() {
    let (bus, secs) = bus_with_clock(t0());
    let v = var_with_lifetime(
        "x",
        VariableType::Number,
        Lifetime::Bare(BareLifetime::For(Duration::seconds(10))),
    );
    let t = tracker(bus, secs.clone(), vec![v]);
    t.write_variable("x", serde_json::json!(7), ResolverOutcome::Allow)
        .unwrap();
    assert_eq!(t.read_variable("x").status, VarStatus::Resolved);

    secs.store(t0().timestamp() + 11, Ordering::SeqCst);
    assert_eq!(t.read_variable("x").status, VarStatus::Unset);
}

#[test]
fn variable_until_event_invalidates_via_bus() {
    let (bus, secs) = bus_with_clock(t0());
    let v = var_with_lifetime(
        "x",
        VariableType::Number,
        Lifetime::Bare(BareLifetime::UntilEvent(vec![EventId::TurnEnd])),
    );
    let t = tracker(bus.clone(), secs, vec![v]);
    t.write_variable("x", serde_json::json!(7), ResolverOutcome::Allow)
        .unwrap();
    assert!(t.is_resolved("x"));
    bus.emit_turn_end().unwrap();
    assert!(!t.is_resolved("x"));
}

#[test]
fn map_lifetime_selects_allow_branch() {
    let lt = Lifetime::Map(LifetimeMap {
        allow: LifetimeBranch::Bare(BareLifetime::For(Duration::seconds(60))),
        deny: LifetimeBranch::Bare(BareLifetime::PerSession),
        cancelled: None,
    });
    let b = select_branch(&lt, ResolverOutcome::Allow);
    assert!(matches!(b, BareLifetime::For(d) if d == Duration::seconds(60)));
}

#[test]
fn map_lifetime_selects_deny_branch() {
    let lt = Lifetime::Map(LifetimeMap {
        allow: LifetimeBranch::Bare(BareLifetime::PerCall),
        deny: LifetimeBranch::Bare(BareLifetime::PerSession),
        cancelled: None,
    });
    let b = select_branch(&lt, ResolverOutcome::Deny);
    assert!(matches!(b, BareLifetime::PerSession));
}

#[test]
fn map_lifetime_cancelled_falls_back_to_deny() {
    let lt = Lifetime::Map(LifetimeMap {
        allow: LifetimeBranch::Bare(BareLifetime::PerCall),
        deny: LifetimeBranch::Bare(BareLifetime::PerSession),
        cancelled: None,
    });
    let b = select_branch(&lt, ResolverOutcome::Cancelled);
    assert!(matches!(b, BareLifetime::PerSession));
}

#[test]
fn map_lifetime_cancelled_uses_explicit_branch_when_set() {
    let lt = Lifetime::Map(LifetimeMap {
        allow: LifetimeBranch::Bare(BareLifetime::PerCall),
        deny: LifetimeBranch::Bare(BareLifetime::PerSession),
        cancelled: Some(LifetimeBranch::Bare(BareLifetime::PerTurn)),
    });
    let b = select_branch(&lt, ResolverOutcome::Cancelled);
    assert!(matches!(b, BareLifetime::PerTurn));
}

#[test]
fn predicate_memoization_caches_value() {
    let (bus, secs) = bus_with_clock(t0());
    let t = tracker(bus, secs, vec![]);
    t.memoize_predicate("p", true, Some(BareLifetime::PerSession));
    assert_eq!(t.read_predicate("p"), Some(true));
}

#[test]
fn predicate_for_lifetime_invalidates() {
    let (bus, secs) = bus_with_clock(t0());
    let t = tracker(bus, secs.clone(), vec![]);
    t.memoize_predicate("p", true, Some(BareLifetime::For(Duration::seconds(5))));
    assert_eq!(t.read_predicate("p"), Some(true));
    secs.store(t0().timestamp() + 6, Ordering::SeqCst);
    assert_eq!(t.read_predicate("p"), None);
}

#[test]
fn predicate_until_event_invalidates() {
    let (bus, secs) = bus_with_clock(t0());
    let t = tracker(bus.clone(), secs, vec![]);
    t.memoize_predicate(
        "p",
        true,
        Some(BareLifetime::UntilEvent(vec![EventId::TurnEnd])),
    );
    assert_eq!(t.read_predicate("p"), Some(true));
    bus.emit_turn_end().unwrap();
    assert_eq!(t.read_predicate("p"), None);
}

#[test]
fn approval_allow_auto_flips_resolved_with_default() {
    let (bus, secs) = bus_with_clock(t0());
    let mut v = var("deploy_prod", VariableType::Boolean);
    v.default = Some(serde_json::json!(true));
    let t = tracker(bus.clone(), secs, vec![v]);

    bus.emit_approval("deploy_prod", ApprovalEventKind::Allow, None, None)
        .unwrap();
    let st = t.read_variable("deploy_prod");
    assert_eq!(st.status, VarStatus::Resolved);
    assert_eq!(st.value, serde_json::json!(true));
}

#[test]
fn approval_allow_uses_payload_value() {
    let (bus, secs) = bus_with_clock(t0());
    let v = var("deploy_prod", VariableType::Boolean);
    let t = tracker(bus.clone(), secs, vec![v]);
    bus.emit_approval(
        "deploy_prod",
        ApprovalEventKind::Allow,
        None,
        Some(serde_json::json!({"value": false})),
    )
    .unwrap();
    let st = t.read_variable("deploy_prod");
    assert_eq!(st.status, VarStatus::Resolved);
    assert_eq!(st.value, serde_json::json!(false));
}

#[test]
fn approval_allow_boolean_default_true() {
    let (bus, secs) = bus_with_clock(t0());
    let v = var("deploy_prod", VariableType::Boolean);
    let t = tracker(bus.clone(), secs, vec![v]);
    bus.emit_approval("deploy_prod", ApprovalEventKind::Allow, None, None)
        .unwrap();
    assert_eq!(
        t.read_variable("deploy_prod").value,
        serde_json::json!(true)
    );
}

#[test]
fn approval_deny_sets_denied_with_payload_reason() {
    let (bus, secs) = bus_with_clock(t0());
    let v = var("deploy_prod", VariableType::Boolean);
    let t = tracker(bus.clone(), secs, vec![v]);
    bus.emit_approval(
        "deploy_prod",
        ApprovalEventKind::Deny,
        None,
        Some(serde_json::json!({"reason": "policy"})),
    )
    .unwrap();
    let st = t.read_variable("deploy_prod");
    assert_eq!(st.status, VarStatus::Denied);
    assert_eq!(st.deny_reason.as_deref(), Some("policy"));
}

#[test]
fn approval_cancelled_sets_denied_with_default_reason() {
    let (bus, secs) = bus_with_clock(t0());
    let v = var("deploy_prod", VariableType::Boolean);
    let t = tracker(bus.clone(), secs, vec![v]);
    bus.emit_approval("deploy_prod", ApprovalEventKind::Cancelled, None, None)
        .unwrap();
    let st = t.read_variable("deploy_prod");
    assert_eq!(st.status, VarStatus::Denied);
    assert_eq!(st.deny_reason.as_deref(), Some("cancelled"));
}

#[test]
fn approval_for_unknown_variable_does_not_panic() {
    let (bus, secs) = bus_with_clock(t0());
    let t = tracker(bus.clone(), secs, vec![]);
    bus.emit_approval("ghost", ApprovalEventKind::Allow, None, None)
        .unwrap();
    // No declared variable → no auto-flip, but the event is still latched.
    assert_eq!(t.variable_count(), 0);
    assert!(bus.fired("approval.ghost.allow"));
}

#[test]
fn clear_event_revokes_auto_flip() {
    let (bus, secs) = bus_with_clock(t0());
    let v = var("deploy_prod", VariableType::Boolean);
    let t = tracker(bus.clone(), secs, vec![v]);
    bus.emit_approval("deploy_prod", ApprovalEventKind::Allow, None, None)
        .unwrap();
    assert!(t.is_resolved("deploy_prod"));
    let id = EventId::Approval {
        variable: "deploy_prod".into(),
        kind: ApprovalEventKind::Allow,
    };
    bus.clear_event(&id);
    assert_eq!(t.read_variable("deploy_prod").status, VarStatus::Unset);
}

#[test]
fn approval_lifetime_for_drives_expiry() {
    let (bus, secs) = bus_with_clock(t0());
    let v = var_with_lifetime(
        "deploy_prod",
        VariableType::Boolean,
        Lifetime::Bare(BareLifetime::For(Duration::seconds(30))),
    );
    let t = tracker(bus.clone(), secs.clone(), vec![v]);
    bus.emit_approval("deploy_prod", ApprovalEventKind::Allow, None, None)
        .unwrap();
    assert!(t.is_resolved("deploy_prod"));
    secs.store(t0().timestamp() + 40, Ordering::SeqCst);
    assert!(!t.is_resolved("deploy_prod"));
}

#[test]
fn approval_lifetime_map_form_routes_allow_short_deny_long() {
    // Pattern: yes-once, no-until-session-end (§9.1.2 example).
    let lt = Lifetime::Map(LifetimeMap {
        allow: LifetimeBranch::Bare(BareLifetime::For(Duration::seconds(5))),
        deny: LifetimeBranch::Bare(BareLifetime::UntilEvent(vec![EventId::SessionEnd])),
        cancelled: None,
    });
    let (bus, secs) = bus_with_clock(t0());
    let v = var_with_lifetime("x", VariableType::Boolean, lt);
    let t = tracker(bus.clone(), secs.clone(), vec![v]);
    bus.emit_approval("x", ApprovalEventKind::Allow, None, None)
        .unwrap();
    assert!(t.is_resolved("x"));
    secs.store(t0().timestamp() + 6, Ordering::SeqCst);
    assert!(!t.is_resolved("x")); // allow branch expired

    bus.emit_approval("x", ApprovalEventKind::Deny, None, None)
        .unwrap();
    assert_eq!(t.read_variable("x").status, VarStatus::Denied);
    // session.end clears the latched approval.deny event AND ends the
    // until_event lifetime branch on the variable.
    bus.emit_session_end().unwrap();
    assert_eq!(t.read_variable("x").status, VarStatus::Unset);
}

#[test]
fn clear_per_turn_drops_per_turn_variables() {
    let (bus, secs) = bus_with_clock(t0());
    let v = var_with_lifetime(
        "x",
        VariableType::Number,
        Lifetime::Bare(BareLifetime::PerTurn),
    );
    let t = tracker(bus, secs, vec![v]);
    t.write_variable("x", serde_json::json!(1), ResolverOutcome::Allow)
        .unwrap();
    assert!(t.is_resolved("x"));
    t.clear_per_turn();
    assert!(!t.is_resolved("x"));
}

#[test]
fn clear_per_call_drops_per_call_predicates() {
    let (bus, secs) = bus_with_clock(t0());
    let t = tracker(bus, secs, vec![]);
    t.memoize_predicate("p", true, Some(BareLifetime::PerCall));
    assert_eq!(t.read_predicate("p"), Some(true));
    t.clear_per_call();
    assert_eq!(t.read_predicate("p"), None);
}

#[test]
fn write_variable_unknown_returns_error() {
    let (bus, secs) = bus_with_clock(t0());
    let t = tracker(bus, secs, vec![]);
    let err = t
        .write_variable("ghost", serde_json::json!(1), ResolverOutcome::Allow)
        .unwrap_err();
    assert!(matches!(err, TrackerError::UnknownVariable(_)));
}

#[test]
fn predicate_count_and_variable_count() {
    let (bus, secs) = bus_with_clock(t0());
    let v = var("x", VariableType::Number);
    let t = tracker(bus, secs, vec![v]);
    t.write_variable("x", serde_json::json!(1), ResolverOutcome::Allow)
        .unwrap();
    t.memoize_predicate("p", true, None);
    assert_eq!(t.variable_count(), 1);
    assert_eq!(t.predicate_count(), 1);
}

#[test]
fn read_returns_unset_when_absent() {
    let (bus, secs) = bus_with_clock(t0());
    let t = tracker(bus, secs, vec![]);
    let st = t.read_variable("anything");
    assert_eq!(st.status, VarStatus::Unset);
}

#[test]
fn approval_lifetime_until_event_invalidates_variable() {
    let (bus, secs) = bus_with_clock(t0());
    let v = var_with_lifetime(
        "x",
        VariableType::Boolean,
        Lifetime::Bare(BareLifetime::UntilEvent(vec![EventId::TurnEnd])),
    );
    let t = tracker(bus.clone(), secs, vec![v]);
    bus.emit_approval("x", ApprovalEventKind::Allow, None, None)
        .unwrap();
    assert!(t.is_resolved("x"));
    bus.emit_turn_end().unwrap();
    assert!(!t.is_resolved("x"));
}

// ── Review-amendment tests (P3.1) ───────────────────────────────

/// P3.1: re-emission of `approval.<var>.<outcome>` supersedes any
/// previously-latched outcome — only the most recent emission appears
/// in `auto_flipped_by`. Clearing the LATER event reverts; clearing
/// the earlier one is a no-op.
#[test]
fn p3_1_latest_approval_supersedes_provenance() {
    let (bus, secs) = bus_with_clock(t0());
    let v = var("x", VariableType::Boolean);
    let t = tracker(bus.clone(), secs, vec![v]);

    // First Allow.
    bus.emit_approval("x", ApprovalEventKind::Allow, None, None)
        .unwrap();
    assert!(t.is_resolved("x"));

    // Second Deny supersedes Allow — variable transitions to Denied.
    bus.emit_approval(
        "x",
        ApprovalEventKind::Deny,
        None,
        Some(serde_json::json!({"reason": "policy"})),
    )
    .unwrap();
    let st = t.read_variable("x");
    assert_eq!(st.status, VarStatus::Denied);
    assert_eq!(st.auto_flipped_by.len(), 1);

    // Clearing the SUPERSEDED Allow event has no effect — the deny
    // is the current latched outcome.
    bus.clear_event(&EventId::Approval {
        variable: "x".into(),
        kind: ApprovalEventKind::Allow,
    });
    assert_eq!(t.read_variable("x").status, VarStatus::Denied);

    // Clearing the active Deny reverts to unset.
    bus.clear_event(&EventId::Approval {
        variable: "x".into(),
        kind: ApprovalEventKind::Deny,
    });
    let st = t.read_variable("x");
    assert_eq!(st.status, VarStatus::Unset);
}

/// P3.1: same-outcome re-emission doesn't accumulate stale entries.
#[test]
fn p3_1_same_outcome_re_emit_does_not_double_provenance() {
    let (bus, secs) = bus_with_clock(t0());
    let v = var("x", VariableType::Boolean);
    let t = tracker(bus.clone(), secs, vec![v]);

    bus.emit_approval("x", ApprovalEventKind::Allow, None, None)
        .unwrap();
    bus.emit_approval("x", ApprovalEventKind::Allow, None, None)
        .unwrap();
    let st = t.read_variable("x");
    assert_eq!(st.auto_flipped_by.len(), 1);
    assert_eq!(st.status, VarStatus::Resolved);
}

// ── set_variable: canonical write path (P4) ──────────────────────

fn var_full(
    name: &str,
    ty: VariableType,
    update: Option<&str>,
    members: Option<&[&str]>,
) -> Variable {
    let mut v = var(name, ty);
    v.update = update.map(String::from);
    v.members = members.map(|m| m.iter().map(|s| s.to_string()).collect());
    v
}

#[test]
fn set_variable_replace_writes_value() {
    let (bus, secs) = bus_with_clock(t0());
    let v = var("x", VariableType::Number);
    let t = tracker(bus, secs, vec![v]);
    t.set_variable(
        "x",
        serde_json::json!(7),
        Some("populator"),
        Some("inc_tool"),
        ResolverOutcome::Allow,
    )
    .unwrap();
    let st = t.read_variable("x");
    assert_eq!(st.value, serde_json::json!(7));
    assert_eq!(st.status, VarStatus::Resolved);
    assert_eq!(st.source_kind.as_deref(), Some("populator"));
    assert_eq!(st.set_by.as_deref(), Some("inc_tool"));
}

#[test]
fn set_variable_max_keeps_higher_number() {
    let (bus, secs) = bus_with_clock(t0());
    let v = var_full(
        "score",
        VariableType::Number,
        Some("max(@current, @incoming)"),
        None,
    );
    let t = tracker(bus, secs, vec![v]);
    t.set_variable(
        "score",
        serde_json::json!(5),
        None,
        None,
        ResolverOutcome::Allow,
    )
    .unwrap();
    t.set_variable(
        "score",
        serde_json::json!(3),
        None,
        None,
        ResolverOutcome::Allow,
    )
    .unwrap();
    assert_eq!(t.read_variable("score").value, serde_json::json!(5));
    t.set_variable(
        "score",
        serde_json::json!(9),
        None,
        None,
        ResolverOutcome::Allow,
    )
    .unwrap();
    assert_eq!(t.read_variable("score").value, serde_json::json!(9));
}

/// §10.1 / §10.2 — ordered string domains are now `type: enum` with
/// `members:` and an `update: "min(@current, @incoming)"` (or `max`)
/// expression. The two-scalar reducers compare by member-index when
/// the active enum domain is in scope (§7.4 / update_policy.rs).
#[test]
fn set_variable_min_string_with_ordering() {
    let (bus, secs) = bus_with_clock(t0());
    let v = var_full(
        "level",
        VariableType::Enum,
        Some("min(@current, @incoming)"),
        Some(&["low", "med", "high"]),
    );
    let t = tracker(bus, secs, vec![v]);
    t.set_variable(
        "level",
        serde_json::json!("med"),
        None,
        None,
        ResolverOutcome::Allow,
    )
    .unwrap();
    t.set_variable(
        "level",
        serde_json::json!("low"),
        None,
        None,
        ResolverOutcome::Allow,
    )
    .unwrap();
    assert_eq!(t.read_variable("level").value, serde_json::json!("low"));
}

/// §10.2: union() does NOT auto-promote scalars — the spec says
/// "Authors who push a single scalar MUST wrap it: union(@current,
/// [@incoming])". This test exercises the array-only path. The
/// scalar-wrapping form is exercised at the apply_update unit-test
/// level.
#[test]
fn set_variable_collect_dedupes_and_promotes() {
    let (bus, secs) = bus_with_clock(t0());
    let v = var_full(
        "tags",
        VariableType::Array,
        Some("union(@current, @incoming)"),
        None,
    );
    let t = tracker(bus, secs, vec![v]);
    // First write into unset bypasses update: per §10.2 short-circuit.
    // We push an array directly (matching the v2 "must wrap scalars"
    // contract).
    t.set_variable(
        "tags",
        serde_json::json!(["a"]),
        None,
        None,
        ResolverOutcome::Allow,
    )
    .unwrap();
    t.set_variable(
        "tags",
        serde_json::json!(["b", "a"]),
        None,
        None,
        ResolverOutcome::Allow,
    )
    .unwrap();
    assert_eq!(t.read_variable("tags").value, serde_json::json!(["a", "b"]));
}

#[test]
fn set_variable_merge_deep_merges_objects() {
    let (bus, secs) = bus_with_clock(t0());
    let v = var_full(
        "doc",
        VariableType::Object,
        Some("object.merge_patch(@current, @incoming)"),
        None,
    );
    let t = tracker(bus, secs, vec![v]);
    t.set_variable(
        "doc",
        serde_json::json!({"a": 1, "b": 2}),
        None,
        None,
        ResolverOutcome::Allow,
    )
    .unwrap();
    t.set_variable(
        "doc",
        serde_json::json!({"b": 99, "c": 3}),
        None,
        None,
        ResolverOutcome::Allow,
    )
    .unwrap();
    assert_eq!(
        t.read_variable("doc").value,
        serde_json::json!({"a": 1, "b": 99, "c": 3})
    );
}

#[test]
fn set_variable_type_mismatch_returns_error() {
    let (bus, secs) = bus_with_clock(t0());
    let v = var("n", VariableType::Number);
    let t = tracker(bus, secs, vec![v]);
    let err = t
        .set_variable(
            "n",
            serde_json::json!("oops"),
            None,
            None,
            ResolverOutcome::Allow,
        )
        .unwrap_err();
    assert!(matches!(err, TrackerError::UpdatePolicy(_)));
}

#[test]
fn set_variable_unknown_variable_errors() {
    let (bus, secs) = bus_with_clock(t0());
    let t = tracker(bus, secs, vec![]);
    let err = t
        .set_variable(
            "ghost",
            serde_json::json!(1),
            None,
            None,
            ResolverOutcome::Allow,
        )
        .unwrap_err();
    assert!(matches!(err, TrackerError::UnknownVariable(_)));
}

#[test]
fn set_variable_emits_variable_changed_event() {
    let (bus, secs) = bus_with_clock(t0());
    let v = var("x", VariableType::Number);
    let t = tracker(bus.clone(), secs, vec![v]);
    t.set_variable(
        "x",
        serde_json::json!(1),
        None,
        None,
        ResolverOutcome::Allow,
    )
    .unwrap();
    assert!(bus.fired("variable.x.changed"));
}

#[test]
fn set_variable_stamps_set_at_and_lifetime_for() {
    let (bus, secs) = bus_with_clock(t0());
    let v = var_with_lifetime(
        "x",
        VariableType::Number,
        Lifetime::Bare(BareLifetime::For(Duration::seconds(30))),
    );
    let t = tracker(bus, secs, vec![v]);
    t.set_variable(
        "x",
        serde_json::json!(1),
        None,
        None,
        ResolverOutcome::Allow,
    )
    .unwrap();
    let st = t.read_variable("x");
    assert_eq!(st.set_at, t0());
    assert_eq!(st.expires_at, Some(t0() + Duration::seconds(30)));
}

#[test]
fn set_variable_unset_short_circuits_max_policy() {
    let (bus, secs) = bus_with_clock(t0());
    let v = var_full(
        "score",
        VariableType::Number,
        Some("max(@current, @incoming)"),
        None,
    );
    let t = tracker(bus, secs, vec![v]);
    // First write into an unset Max variable accepts unconditionally.
    t.set_variable(
        "score",
        serde_json::json!(2),
        None,
        None,
        ResolverOutcome::Allow,
    )
    .unwrap();
    assert_eq!(t.read_variable("score").value, serde_json::json!(2));
}

#[test]
fn set_variable_does_not_bypass_update_policy() {
    // Confirm that write_variable (low-level) and set_variable
    // (canonical) differ: low-level overwrites; canonical respects max.
    let (bus, secs) = bus_with_clock(t0());
    let v = var_full(
        "score",
        VariableType::Number,
        Some("max(@current, @incoming)"),
        None,
    );
    let t = tracker(bus, secs, vec![v]);
    t.write_variable("score", serde_json::json!(10), ResolverOutcome::Allow)
        .unwrap();
    // set_variable with a smaller value MUST NOT replace.
    t.set_variable(
        "score",
        serde_json::json!(2),
        None,
        None,
        ResolverOutcome::Allow,
    )
    .unwrap();
    assert_eq!(t.read_variable("score").value, serde_json::json!(10));
    // write_variable bypasses policy.
    t.write_variable("score", serde_json::json!(0), ResolverOutcome::Allow)
        .unwrap();
    assert_eq!(t.read_variable("score").value, serde_json::json!(0));
}

#[test]
fn set_variable_atomic_under_concurrent_collect_writes() {
    // Two threads racing on `set_variable` against a `collect` variable
    // must both land in the final array — the canonical write path is
    // atomic under a single mutex acquisition for the whole RMW.
    let (bus, secs) = bus_with_clock(t0());
    let v = var_full(
        "xs",
        VariableType::Array,
        Some("union(@current, @incoming)"),
        None,
    );
    let t = tracker(bus, secs, vec![v]);

    let writers: Vec<_> = (0..8)
        .map(|i| {
            let tt = t.clone();
            std::thread::spawn(move || {
                let v = if i % 2 == 0 { "alpha" } else { "beta" };
                for _ in 0..32 {
                    tt.set_variable(
                        "xs",
                        // §10.2: union() requires arrays; wrap the
                        // scalar at the call site per the v2 spec.
                        serde_json::json!([v]),
                        None,
                        None,
                        ResolverOutcome::Allow,
                    )
                    .unwrap();
                }
            })
        })
        .collect();
    for w in writers {
        w.join().unwrap();
    }
    let st = t.read_variable("xs");
    let arr = st.value.as_array().expect("xs is array");
    // Collect dedups, so two distinct strings must both be present.
    assert!(arr.contains(&serde_json::json!("alpha")));
    assert!(arr.contains(&serde_json::json!("beta")));
    assert_eq!(
        arr.len(),
        2,
        "concurrent writes must not lose updates: {:?}",
        arr
    );
}

// ── §9.4 binding-key tests ─────────────────────────────────────

#[test]
fn keyed_read_returns_unset_for_missing_key() {
    let (bus, secs) = bus_with_clock(t0());
    let mut v = var("recipients", VariableType::Array);
    v.key = Some("@tool.params.channel_id".into());
    let t = tracker(bus, secs, vec![v]);
    // Read with key "C-A" — never written, so unset.
    let st = t.read_variable_keyed("recipients", Some(&serde_json::json!("C-A")));
    assert!(matches!(st.status, VarStatus::Unset));
}

#[test]
fn keyed_write_and_read_roundtrip() {
    let (bus, secs) = bus_with_clock(t0());
    let mut v = var("recipients", VariableType::Array);
    v.key = Some("@tool.params.channel_id".into());
    let t = tracker(bus, secs, vec![v]);
    let key = serde_json::json!("C-A");
    t.set_variable_keyed(
        "recipients",
        Some(&key),
        serde_json::json!(["alice@x.com"]),
        None,
        None,
        ResolverOutcome::Allow,
    )
    .unwrap();
    let st = t.read_variable_keyed("recipients", Some(&key));
    assert!(matches!(st.status, VarStatus::Resolved));
    assert_eq!(st.value, serde_json::json!(["alice@x.com"]));
}

#[test]
fn keyed_writes_under_different_keys_are_independent() {
    let (bus, secs) = bus_with_clock(t0());
    let mut v = var("recipients", VariableType::Array);
    v.key = Some("@tool.params.channel_id".into());
    let t = tracker(bus, secs, vec![v]);
    let key_a = serde_json::json!("C-A");
    let key_b = serde_json::json!("C-B");
    t.set_variable_keyed(
        "recipients",
        Some(&key_a),
        serde_json::json!(["alice@x.com"]),
        None,
        None,
        ResolverOutcome::Allow,
    )
    .unwrap();
    t.set_variable_keyed(
        "recipients",
        Some(&key_b),
        serde_json::json!(["bob@x.com"]),
        None,
        None,
        ResolverOutcome::Allow,
    )
    .unwrap();
    // Each key's slot stays distinct.
    assert_eq!(
        t.read_variable_keyed("recipients", Some(&key_a)).value,
        serde_json::json!(["alice@x.com"])
    );
    assert_eq!(
        t.read_variable_keyed("recipients", Some(&key_b)).value,
        serde_json::json!(["bob@x.com"])
    );
}

#[test]
fn keyed_invalidate_only_clears_named_key() {
    let (bus, secs) = bus_with_clock(t0());
    let mut v = var("recipients", VariableType::Array);
    v.key = Some("@tool.params.channel_id".into());
    let t = tracker(bus, secs, vec![v]);
    let key_a = serde_json::json!("C-A");
    let key_b = serde_json::json!("C-B");
    t.set_variable_keyed(
        "recipients",
        Some(&key_a),
        serde_json::json!(["a"]),
        None,
        None,
        ResolverOutcome::Allow,
    )
    .unwrap();
    t.set_variable_keyed(
        "recipients",
        Some(&key_b),
        serde_json::json!(["b"]),
        None,
        None,
        ResolverOutcome::Allow,
    )
    .unwrap();

    t.invalidate_variable_keyed("recipients", Some(&key_a));
    assert!(matches!(
        t.read_variable_keyed("recipients", Some(&key_a)).status,
        VarStatus::Unset
    ));
    // key_b survives.
    assert!(matches!(
        t.read_variable_keyed("recipients", Some(&key_b)).status,
        VarStatus::Resolved
    ));
}

#[test]
fn keyed_null_key_write_is_rejected_silently() {
    let (bus, secs) = bus_with_clock(t0());
    let mut v = var("recipients", VariableType::Array);
    v.key = Some("@tool.params.channel_id".into());
    let t = tracker(bus, secs, vec![v]);
    let null_key = serde_json::Value::Null;
    // Per §9.4.2: null key writes are dropped with a structured warning.
    // The call returns Ok(()) but no entry is stored.
    t.set_variable_keyed(
        "recipients",
        Some(&null_key),
        serde_json::json!(["x"]),
        None,
        None,
        ResolverOutcome::Allow,
    )
    .unwrap();
    // No keyed slot was written; read with the null "key" still returns unset.
    assert!(matches!(
        t.read_variable_keyed("recipients", Some(&null_key)).status,
        VarStatus::Unset
    ));
}

#[test]
fn keyed_object_keys_compare_by_canonical_equality() {
    // Per §9.4.2: composite keys (objects, arrays) compare by deep
    // equality after canonical ordering of object keys.
    let (bus, secs) = bus_with_clock(t0());
    let mut v = var("blob", VariableType::String);
    v.key = Some("@tool.params.composite".into());
    let t = tracker(bus, secs, vec![v]);
    let key1 = serde_json::json!({"a": 1, "b": 2});
    let key2 = serde_json::json!({"b": 2, "a": 1}); // same logical key, different insertion order
    t.set_variable_keyed(
        "blob",
        Some(&key1),
        serde_json::json!("alpha"),
        None,
        None,
        ResolverOutcome::Allow,
    )
    .unwrap();
    // Read using the differently-ordered key — should match.
    let st = t.read_variable_keyed("blob", Some(&key2));
    assert_eq!(st.value, serde_json::json!("alpha"));
}

#[test]
fn variable_changed_event_payload_carries_key() {
    let (bus, secs) = bus_with_clock(t0());
    let captured: Arc<Mutex<Vec<crate::event_bus::BusEvent>>> = Arc::new(Mutex::new(Vec::new()));
    let cap = captured.clone();
    bus.subscribe(None, move |ev: &crate::event_bus::BusEvent| {
        cap.lock().unwrap().push(ev.clone());
    });
    let mut v = var("recipients", VariableType::Array);
    v.key = Some("@tool.params.channel_id".into());
    let t = tracker(bus.clone(), secs, vec![v]);
    let key = serde_json::json!("C-A");
    t.set_variable_keyed(
        "recipients",
        Some(&key),
        serde_json::json!(["a"]),
        None,
        None,
        ResolverOutcome::Allow,
    )
    .unwrap();
    let events = captured.lock().unwrap().clone();
    let changed = events.iter().find_map(|ev| match ev {
        crate::event_bus::BusEvent::Emitted {
            event_id: crate::events::EventId::VariableChanged { name },
            payload,
            ..
        } if name == "recipients" => Some(payload.clone()),
        _ => None,
    });
    assert!(changed.is_some(), "variable.recipients.changed not emitted");
    let payload = changed.unwrap();
    assert!(payload.is_some(), "keyed write must carry payload");
    let p = payload.unwrap();
    assert_eq!(p.get("key"), Some(&serde_json::json!("C-A")));
}

#[test]
fn source_params_captured_on_resolved_write_via_full_api() {
    use serde_json::json;
    let (bus, secs) = bus_with_clock(t0());
    let v = var("kyc", VariableType::Object);
    let t = tracker(bus, secs, vec![v]);
    let params = json!({"customer_id": "C-1", "amount": 100});
    t.set_variable_keyed_full(
        "kyc",
        None,
        json!({"verified": true}),
        Some("populator"),
        Some("after:tool:get_kyc"),
        Some(params.clone()),
        ResolverOutcome::Allow,
    )
    .unwrap();
    let st = t.read_variable("kyc");
    assert!(matches!(st.status, VarStatus::Resolved));
    assert_eq!(st.source_params, Some(params));
}

#[test]
fn source_params_not_captured_on_denied_write() {
    use serde_json::json;
    let (bus, secs) = bus_with_clock(t0());
    let v = var("kyc", VariableType::Object);
    let t = tracker(bus, secs, vec![v]);
    let params = json!({"customer_id": "C-1"});
    t.set_variable_keyed_full(
        "kyc",
        None,
        json!({"verified": false}),
        Some("populator"),
        Some("after:tool:get_kyc"),
        Some(params),
        ResolverOutcome::Deny,
    )
    .unwrap();
    let st = t.read_variable("kyc");
    assert!(matches!(st.status, VarStatus::Denied));
    // §9.3.2: @source_params is `null while @status != 'resolved'`.
    assert!(st.source_params.is_none());
}

#[test]
fn lifetime_expression_branch_evaluates_at_write_time() {
    // §9.1.2.1 — when `lifetime.allow:` is an `expression:` form,
    // it evaluates at write time against @incoming/@current.
    use crate::lifetime::{LifetimeBranch, LifetimeMap};
    let (bus, secs) = bus_with_clock(t0());
    let mut v = var("ack", VariableType::String);
    v.lifetime = Some(Lifetime::Map(LifetimeMap {
        allow: LifetimeBranch::Expression(
            "@incoming == 'permanent' ? 'per_session' : 'per_call'".into(),
        ),
        deny: LifetimeBranch::Bare(BareLifetime::PerSession),
        cancelled: None,
    }));
    let t = tracker(bus, secs, vec![v]);
    // Write "permanent" — expression returns "per_session".
    t.set_variable(
        "ack",
        serde_json::json!("permanent"),
        None,
        None,
        ResolverOutcome::Allow,
    )
    .unwrap();
    let st = t.read_variable("ack");
    assert_eq!(st.lifetime_branch, Some(BareLifetime::PerSession));
}

#[test]
fn lifetime_expression_returning_duration_string_works() {
    use crate::lifetime::{LifetimeBranch, LifetimeMap};
    let (bus, secs) = bus_with_clock(t0());
    let mut v = var("flag", VariableType::Boolean);
    v.lifetime = Some(Lifetime::Map(LifetimeMap {
        allow: LifetimeBranch::Expression("'30s'".into()),
        deny: LifetimeBranch::Bare(BareLifetime::PerSession),
        cancelled: None,
    }));
    let t = tracker(bus, secs, vec![v]);
    t.set_variable(
        "flag",
        serde_json::json!(true),
        None,
        None,
        ResolverOutcome::Allow,
    )
    .unwrap();
    let st = t.read_variable("flag");
    assert!(matches!(st.lifetime_branch, Some(BareLifetime::For(_))));
}
