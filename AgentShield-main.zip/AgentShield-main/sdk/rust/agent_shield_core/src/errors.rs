//! Load-time errors for the guardrails loader.
//!
//! Every error preserves enough provenance (file path + serde-yaml line/column
//! when available) to point the author at the offending input.

#![allow(clippy::result_large_err)]

use std::path::PathBuf;

use thiserror::Error;

/// A source location used to enrich error messages.
#[derive(Debug, Clone, Default)]
pub struct SourceLoc {
    pub path: Option<PathBuf>,
    pub line: Option<usize>,
    pub column: Option<usize>,
}

impl SourceLoc {
    pub fn new(path: Option<PathBuf>, line: Option<usize>, column: Option<usize>) -> Self {
        Self { path, line, column }
    }

    pub fn from_path(path: PathBuf) -> Self {
        Self {
            path: Some(path),
            line: None,
            column: None,
        }
    }
}

impl std::fmt::Display for SourceLoc {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match (&self.path, self.line, self.column) {
            (Some(p), Some(line), Some(col)) => write!(f, "{}:{}:{}", p.display(), line, col),
            (Some(p), Some(line), None) => write!(f, "{}:{}", p.display(), line),
            (Some(p), _, _) => write!(f, "{}", p.display()),
            (None, Some(line), Some(col)) => write!(f, "line {}, column {}", line, col),
            (None, Some(line), _) => write!(f, "line {}", line),
            _ => write!(f, "<unknown location>"),
        }
    }
}

/// Top-level load-time error type. Each variant carries enough context
/// to pinpoint the file, key, or chain step that failed.
#[derive(Debug, Error)]
pub enum ConfigError {
    #[error("loader: file I/O error at {path}: {source}")]
    Io {
        path: PathBuf,
        #[source]
        source: std::io::Error,
    },

    #[error("loader: YAML parse error at {loc}: {source}")]
    Yaml {
        loc: SourceLoc,
        #[source]
        source: serde_yaml::Error,
    },

    #[error("loader: schema error at {loc}: {message}")]
    Schema { loc: SourceLoc, message: String },

    #[error(
        "loader: rejected legacy vocabulary at {loc}: `{key}` is no longer valid \
         (the current schema is declared via `agent_shield_version`). \
         Migration hint: {hint}"
    )]
    V1Vocabulary {
        loc: SourceLoc,
        key: String,
        hint: String,
    },

    #[error("loader: invalid agent_shield_version `{value}` at {loc}: {message}")]
    InvalidAgentShieldVersion {
        loc: SourceLoc,
        value: String,
        message: String,
    },

    #[error(
        "loader: declared agent_shield_version `{declared}` is not satisfied by \
         runtime spec version `{runtime}` at {loc}"
    )]
    IncompatibleAgentShieldVersion {
        loc: SourceLoc,
        declared: String,
        runtime: String,
    },

    #[error(
        "loader: agent_shield_version `{a}` (in {a_loc}) and `{b}` (in {b_loc}) are \
         in incompatible compatibility bands"
    )]
    IncompatibleVersionBands {
        a: String,
        a_loc: SourceLoc,
        b: String,
        b_loc: SourceLoc,
    },

    #[error("loader: extends-chain cycle detected: {path}")]
    ExtendsCycle { path: String },

    #[error(
        "loader: variable `{name}` redefined in {second_file}; same-name variable \
         redefinition across files is forbidden (originally declared in {first_file}) (§10.9/§11.13)"
    )]
    DuplicateVariable {
        name: String,
        first_file: PathBuf,
        second_file: PathBuf,
    },

    #[error(
        "loader: unresolved {kind} reference `{name}` at {loc}: \
         the referenced {kind} is not declared (§1.3, §11.10, §12.3)"
    )]
    UnresolvedReference {
        loc: SourceLoc,
        kind: &'static str,
        name: String,
    },

    #[error(
        "loader: unknown event identifier `{id}` at {location}: \
         `event.fired()` arguments must name a declared event (§9.3)"
    )]
    UnknownEventId { id: String, location: String },

    #[error("loader: extends-chain depth exceeded ({depth} > {max}); deepest path: {path}")]
    ExtendsDepthExceeded {
        depth: usize,
        max: usize,
        path: String,
    },

    #[error(
        "loader: predicate `{name}` redefined in {leaf}; same-name predicate \
         redefinition across files is forbidden (originally declared in {origin})"
    )]
    PredicateRedefinition {
        name: String,
        origin: PathBuf,
        leaf: PathBuf,
    },

    #[error(
        "loader: guard policy `{name}` redefines parent's `active_if` in {leaf} \
         (originally declared in {origin}); parent `active_if` is immutable"
    )]
    GuardPolicyActiveIfImmutable {
        name: String,
        origin: PathBuf,
        leaf: PathBuf,
    },

    #[error("loader: invalid event identifier `{value}` at {loc}: {message}")]
    InvalidEventId {
        loc: SourceLoc,
        value: String,
        message: String,
    },

    #[error("loader: invalid duration literal `{value}` at {loc}: {message}")]
    InvalidDuration {
        loc: SourceLoc,
        value: String,
        message: String,
    },

    #[error("loader: resolver dependency cycle through variable `{path}` (defined at {loc})")]
    ResolverCycle { loc: SourceLoc, path: String },

    #[error("loader: configuration `{id}` rejected at {loc}: {message}")]
    InvalidConfiguration {
        loc: SourceLoc,
        id: String,
        message: String,
    },

    #[error(
        "loader: evaluate_when entry at {loc} must declare exactly one of \
         `expression`/`pattern`/`patterns`/`llm`/`classifier` (found {count})"
    )]
    EvaluateWhenKindMismatch { loc: SourceLoc, count: usize },

    #[error("loader: missing required field `{field}` at {loc}")]
    MissingField { loc: SourceLoc, field: String },

    // ── Remote `extends:` errors (§3.2) ─────────────────────────────────
    #[error(
        "loader: remote `extends:` entry at {loc} must be the object form \
         `{{ url: <https://…>, integrity: sha256-<base64> }}`. Plain URL \
         strings are rejected because integrity must be explicit. (§3.2)"
    )]
    UrlExtendsRequiresIntegrity { loc: SourceLoc, url: String },

    #[error(
        "loader: remote `extends:` entry for `{url}` at {loc} declares both \
         `integrity:` and `unverified: true`; the trust model must be \
         exactly one of pinned or unverified. (§3.2)"
    )]
    UrlExtendsConflictingTrust { loc: SourceLoc, url: String },

    #[error(
        "loader: remote `extends:` entry for `{url}` at {loc} declares \
         neither `integrity:` nor `unverified: true`; the trust model \
         must be explicit. Use `integrity: sha256-<base64>` to pin the \
         body, or `unverified: true` to acknowledge the load is not \
         byte-verified. (§3.2)"
    )]
    UrlExtendsMissingTrust { loc: SourceLoc, url: String },

    #[error(
        "loader: remote `extends:` URL `{url}` at {loc} uses unsupported \
         scheme: only `https://` is accepted (§3.2)"
    )]
    UrlExtendsBadScheme { loc: SourceLoc, url: String },

    #[error(
        "loader: remote `extends:` URL `{url}` at {loc} carries forbidden \
         components (credentials or fragment); strip them (§3.2)"
    )]
    UrlExtendsForbiddenComponents { loc: SourceLoc, url: String },

    #[error(
        "loader: remote `extends:` integrity literal `{value}` at {loc} is \
         malformed: expected `sha256-<base64>` (SRI form) (§3.2)"
    )]
    UrlExtendsBadIntegrity { loc: SourceLoc, value: String },

    #[error(
        "loader: remote `extends:` relative URL `{url}` at {loc} requires \
         a remote parent file as its base (§3.2)"
    )]
    RelativeUrlNeedsRemoteParent { loc: SourceLoc, url: String },

    #[error("loader: remote `extends:` fetch of `{url}` failed: {message} (§3.2)")]
    RemoteFetch { url: String, message: String },

    #[error(
        "loader: remote `extends:` integrity mismatch for `{url}`: \
         expected {expected}, got {actual} (§3.2)"
    )]
    IntegrityMismatch {
        url: String,
        expected: String,
        actual: String,
    },

    #[error(
        "loader: remote `extends:` URL `{url}` declared with conflicting \
         integrity values across the chain: first {first}, now {second} (§3.2)"
    )]
    IntegrityConflict {
        url: String,
        first: String,
        second: String,
    },

    #[error(
        "loader: remote `extends:` body for `{url}` exceeds the {max}-byte \
         cap (§3.2)"
    )]
    RemoteBodyTooLarge { url: String, max: usize },

    /// Per-load fetch-count cap (`MAX_REMOTE_FETCHES`) exceeded.
    ///
    /// Field semantics (note the asymmetry vs. `RemoteBytesBudgetExceeded`):
    /// - `count`: the would-be attempt number that tripped the guard
    ///   (i.e. `fetch_count + 1`, since the cap check fires BEFORE the
    ///   fetch is attempted).
    /// - `max`: the configured fetch-count cap (`MAX_REMOTE_FETCHES`).
    /// - `bytes_total`: the cumulative bytes admitted by prior fetches
    ///   in this load. The failed fetch contributes nothing because no
    ///   socket was opened.
    #[error(
        "loader: too many remote `extends:` fetches in this load \
         ({count} > {max}); cumulative bytes {bytes_total} (§3.2)"
    )]
    RemoteFetchCountBudgetExceeded {
        count: usize,
        max: usize,
        bytes_total: usize,
    },

    /// Per-load cumulative-bytes cap (`MAX_REMOTE_TOTAL_BYTES`) would be
    /// exceeded by an in-flight fetch.
    ///
    /// Field semantics (note the asymmetry vs. `RemoteFetchCountBudgetExceeded`):
    /// - `count`: the in-flight fetch number whose body would breach
    ///   the cap (`fetch_count + 1`); this fetch's bytes are NOT
    ///   admitted to the cache or counters.
    /// - `max_bytes`: the configured cumulative-bytes cap
    ///   (`MAX_REMOTE_TOTAL_BYTES`).
    /// - `bytes_total`: the value `bytes_total` WOULD reach if the
    ///   in-flight body were admitted (i.e. prior bytes + this body's
    ///   length). The body is not actually admitted; this is reported
    ///   to make the diagnostic concrete about the overshoot.
    #[error(
        "loader: cumulative remote `extends:` body bytes in this load \
         exceeds the {max_bytes}-byte cap (would reach {bytes_total} \
         after fetch #{count}) (§3.2)"
    )]
    RemoteBytesBudgetExceeded {
        count: usize,
        max_bytes: usize,
        bytes_total: usize,
    },

    #[error(
        "loader: remote `extends:` requires the `http` feature; rebuild \
         `agent_shield_core` with `--features http` or remove the URL \
         entry at {loc}"
    )]
    RemoteExtendsFeatureDisabled { loc: SourceLoc },

    // ── §12.9.2 prompt_path errors ──────────────────────────────────────
    #[error("loader: prompt file error at {loc}: {kind} (path: {path})")]
    PromptFile {
        loc: SourceLoc,
        path: PathBuf,
        kind: PromptFileErrorKind,
    },
}

/// Why a `prompt_path:` (or post-load `prompt_path` invariant check)
/// failed. Spec §12.9.2.
#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum PromptFileErrorKind {
    #[error("`prompt:` and `prompt_path:` are mutually exclusive")]
    BothSet,
    #[error("exactly one of `prompt:` or `prompt_path:` is required")]
    NeitherSet,
    #[error("file not found or not readable: {message}")]
    NotFound { message: String },
    #[error("path is not a regular file")]
    NotRegularFile,
    #[error("file exceeds the {max}-byte cap")]
    TooLarge { max: usize },
    #[error("file is not valid UTF-8")]
    NotUtf8,
    #[error("file is empty")]
    EmptyFile,
    #[error("`prompt_path:` is not supported for string-input loads (no anchor directory)")]
    NoAnchorDir,
    #[error("`prompt_path:` is not supported for remote (HTTPS) extends: in this spec version")]
    RemoteNotSupported,
    #[error(
        "loaded config still carries an unresolved `prompt_path` — this MergedConfig \
         was hand-constructed or routed past the loader's inlining pass"
    )]
    UnresolvedPromptPath,
}

impl ConfigError {
    pub fn schema(loc: SourceLoc, message: impl Into<String>) -> Self {
        Self::Schema {
            loc,
            message: message.into(),
        }
    }

    pub fn v1_vocab(loc: SourceLoc, key: impl Into<String>, hint: impl Into<String>) -> Self {
        Self::V1Vocabulary {
            loc,
            key: key.into(),
            hint: hint.into(),
        }
    }
}

pub type Result<T> = std::result::Result<T, ConfigError>;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn source_loc_display_path_only() {
        let s = SourceLoc::from_path(PathBuf::from("/tmp/x.yaml")).to_string();
        assert!(s.contains("x.yaml"));
    }

    #[test]
    fn config_error_messages_contain_provenance() {
        let err = ConfigError::v1_vocab(
            SourceLoc::from_path(PathBuf::from("a.yaml")),
            "agentShieldVersion",
            "rename to `agent_shield_version`",
        );
        let msg = err.to_string();
        assert!(msg.contains("agentShieldVersion"));
        assert!(msg.contains("a.yaml"));
        assert!(msg.contains("rename"));
    }
}
