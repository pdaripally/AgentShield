//! Bundled `kind: human` resolver providers.
//!
//! These ship as built-in handlers so YAML can declare
//! `provider: <bundled-name>` without any host code, in any of the
//! four SDKs. The runtime auto-registers them in [`crate::runtime::RuntimeBuilder::build`]
//! when a `kind: human` resolver references one of the bundled
//! provider names and the host has not already registered a handler
//! under that name (host-supplied always wins).
//!
//! ## YAML usage
//!
//! ```yaml
//! variables:
//!   - name: send_authorized
//!     type: boolean
//!     on_demand_by:
//!       kind: human
//!       provider: auto_reject     # ← bundled, no host code
//! ```
//!
//! ```yaml
//! # Closure-based handler — host registers via
//! # RuntimeBuilder::register_human_provider("user_approval", ...)
//! variables:
//!   - name: send_authorized
//!     on_demand_by:
//!       kind: human
//!       name: user_approval
//! ```
//!
//! ## Available providers
//!
//! - [`AutoRejectHandler`] — always returns `Deny`. Useful for tests
//!   and "never approve in this environment" deployments. Auto-wired
//!   under the names `auto_reject` and `deny`.
//! - [`ConsoleApprovalHandler`] — stdin/stdout prompting with timeout
//!   (fail-closed-on-timeout). Auto-wired under the name `console`.
//!   Mirrors the v1 menu (`a`/`o`/`b`/`n`/`c`) with internal
//!   per-(session, variable) caching so `a`/`b` (allow always / block
//!   always) suppress subsequent prompts in the same session.
//! - [`CallbackApprovalHandler`] — closure adapter for hosts. Not
//!   auto-wired; the host constructs it with a closure and registers
//!   it under whatever name the YAML refers to.
//!
//! Hosts can override any bundled name by pre-registering their own
//! handler with the same name before [`crate::runtime::RuntimeBuilder::build`] runs.

mod auto_reject;
mod callback;
pub mod console;

pub use auto_reject::AutoRejectHandler;
pub use callback::CallbackApprovalHandler;
pub use console::{ConsoleApprovalHandler, PromptReader, StdinPromptReader};

// Re-export for ergonomic consumption.
pub use crate::resolver::{ResolverDecision, ResolverResponse};
pub use crate::resolver_runtime::{
    HumanRegistry, HumanResolveRequest, HumanResolver, HumanResolverFn,
};

use std::sync::Arc;

/// Bundled provider names that the runtime will auto-register on
/// [`crate::runtime::RuntimeBuilder::build`] when a `kind: human`
/// resolver references them and the host has not registered its own
/// handler under that name. Each entry maps the YAML provider name to
/// a factory that constructs the handler.
///
/// Currently auto-wired:
///
/// - `auto_reject` / `deny` → [`AutoRejectHandler`]
/// - `console`              → [`ConsoleApprovalHandler::default()`]
///
/// `callback` is **not** auto-wired — it requires a closure from the
/// host.
pub fn bundled_handler(name: &str) -> Option<Arc<dyn HumanResolver>> {
    match name {
        "auto_reject" | "deny" => Some(Arc::new(AutoRejectHandler)),
        "console" => Some(Arc::new(ConsoleApprovalHandler::default())),
        _ => None,
    }
}

/// Set of bundled provider names that [`bundled_handler`] knows about.
/// Useful for spec-loader validation and observability.
pub const BUNDLED_PROVIDER_NAMES: &[&str] = &["auto_reject", "deny", "console"];
