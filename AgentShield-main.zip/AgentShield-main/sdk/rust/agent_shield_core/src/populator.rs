//! Populator engine (§10.5).
//!
//! Implements the **push-style** value population path: when a tool,
//! endpoint, or agent executes, the runtime walks each declared variable's
//! `populated_by[]` list and fires the entries whose `kind:` and identity
//! match the invocation. Each fired entry runs an optional extractor over
//! the call's result and evaluates an optional `expression:` to produce a
//! value, which the runtime then writes through the variable's
//! `update_policy:` (see [`crate::update_policy::apply_update`]).
//!
//! ## Spec mapping
//!
//! - §10.5 — schema and resource targeting.
//! - §10.5.1 — `kind: tool` / `agent` / `endpoint` matchers.
//! - §10.5.2 — phase semantics. `phase: before` MUST NOT see `result.*`
//!   (load-time validation lives in [`crate::variables`]).
//! - §10.5.3 — value derivation via extractor + expression.
//! - §13.4 — endpoint matcher specificity (exact > parameterized > glob).
//!   This module implements the per-populator Boolean match; specificity-
//!   based tie-breaking across the merged endpoint table is the runtime's
//!   concern.
//!
//! ## Public surface
//!
//! - [`Invocation`] — runtime-side description of the call in flight.
//! - [`select_populators`] — pick the entries that match the invocation.
//! - [`apply_populator`] — run a single entry's extractor + expression
//!   and produce the value to write (or `None` when the populator was a
//!   no-op or its extractor signaled "skip").
//! - [`Extractor`] / [`ExtractorRegistry`] — pluggable parse hooks for
//!   structured payloads (default = identity over the raw `result`).

use std::collections::HashMap;

use serde_json::{json, Value};
use sha2::{Digest, Sha256};

use crate::expressions::ast::{Expr, LitValue};
use crate::expressions::eval::{evaluate_with, EvalContext};
use crate::expressions::parser::parse;

use super::variables::{Phase, PopulatorEntry, ResourceKind, Variable};

// ── Invocation ──────────────────────────────────────────────────────

/// A runtime-side description of the resource invocation that triggered the
/// populator/resetter walk. The runtime constructs one of these for every
/// tool, endpoint, or agent call and passes it to [`select_populators`] /
/// [`crate::resetter::select_resetters`] both before (phase: before)
/// and after (phase: after) the call executes.
#[derive(Debug, Clone)]
pub struct Invocation {
    pub kind: ResourceKind,

    /// Tool / agent name. Required when `kind` is `Tool` or `Agent`.
    pub name: Option<String>,

    /// The resource entry that was actually matched in the resources table
    /// — when this differs from `name` (e.g. wildcard catch-all matched a
    /// runtime-discovered tool), populators with explicit `name:` still
    /// match against `name`, while wildcard `name: "*"` populators match
    /// regardless. Reserved for future correlation; not currently consumed
    /// by the matcher beyond pass-through.
    pub matched_resource_name: Option<String>,

    /// HTTP method. Required when `kind` is `Endpoint`.
    pub method: Option<String>,

    /// URI of the endpoint call. Required when `kind` is `Endpoint`.
    pub uri: Option<String>,

    /// Path-template parameters extracted from the URI by the runtime.
    pub path_params: HashMap<String, Value>,

    /// Query-string parameters.
    pub query_params: HashMap<String, Value>,

    /// Tool args / endpoint body / agent payload. Bound into the eval
    /// context as `tool.params.*`, `endpoint.body.*`, or `agent.payload.*`.
    pub params: Value,
}

impl Invocation {
    /// Canonical JSON representation used to bind validation, approval,
    /// execution, and audit to the same invocation. Object keys are sorted
    /// recursively; semantically identical JSON values produce identical
    /// bytes across SDKs.
    pub fn canonical_value(&self) -> Value {
        canonicalise_json(json!({
            "kind": resource_kind_str(self.kind),
            "name": self.name,
            "matched_resource_name": self.matched_resource_name,
            "method": self.method,
            "uri": self.uri,
            "path_params": self.path_params,
            "query_params": self.query_params,
            "params": self.params,
        }))
    }

    /// SHA-256 (lowercase hex) over [`Self::canonical_value`]. Hosts can
    /// compare this before execution to detect validate-then-mutate bugs.
    pub fn canonical_hash(&self) -> String {
        let canonical = self.canonical_value();
        let bytes = serde_json::to_vec(&canonical)
            .expect("canonical invocation contains only serializable JSON values");
        let mut hasher = Sha256::new();
        hasher.update(bytes);
        hex_encode(&hasher.finalize())
    }

    pub fn tool(name: impl Into<String>, params: Value) -> Self {
        Self {
            kind: ResourceKind::Tool,
            name: Some(name.into()),
            matched_resource_name: None,
            method: None,
            uri: None,
            path_params: HashMap::new(),
            query_params: HashMap::new(),
            params,
        }
    }

    pub fn agent(name: impl Into<String>, params: Value) -> Self {
        Self {
            kind: ResourceKind::Agent,
            name: Some(name.into()),
            matched_resource_name: None,
            method: None,
            uri: None,
            path_params: HashMap::new(),
            query_params: HashMap::new(),
            params,
        }
    }

    pub fn endpoint(method: impl Into<String>, uri: impl Into<String>, body: Value) -> Self {
        Self {
            kind: ResourceKind::Endpoint,
            name: None,
            matched_resource_name: None,
            method: Some(method.into()),
            uri: Some(uri.into()),
            path_params: HashMap::new(),
            query_params: HashMap::new(),
            params: body,
        }
    }
}

fn resource_kind_str(kind: ResourceKind) -> &'static str {
    match kind {
        ResourceKind::Tool => "tool",
        ResourceKind::Endpoint => "endpoint",
        ResourceKind::Agent => "agent",
    }
}

fn canonicalise_json(value: Value) -> Value {
    match value {
        Value::Object(map) => {
            let mut entries: Vec<(String, Value)> = map
                .into_iter()
                .map(|(key, value)| (key, canonicalise_json(value)))
                .collect();
            entries.sort_by(|left, right| left.0.cmp(&right.0));
            let mut out = serde_json::Map::with_capacity(entries.len());
            for (key, value) in entries {
                out.insert(key, value);
            }
            Value::Object(out)
        }
        Value::Array(items) => Value::Array(items.into_iter().map(canonicalise_json).collect()),
        scalar => scalar,
    }
}

fn hex_encode(bytes: &[u8]) -> String {
    const HEX: &[u8] = b"0123456789abcdef";
    let mut out = String::with_capacity(bytes.len() * 2);
    for byte in bytes {
        out.push(HEX[(*byte >> 4) as usize] as char);
        out.push(HEX[(*byte & 0x0f) as usize] as char);
    }
    out
}

#[cfg(test)]
mod invocation_tests {
    use super::*;
    use serde_json::json;

    #[test]
    fn canonical_hash_ignores_object_key_order() {
        let left = Invocation::tool(
            "send_email",
            json!({"to":"a@example.com","body":{"b":2,"a":1}}),
        );
        let right = Invocation::tool(
            "send_email",
            json!({"body":{"a":1,"b":2},"to":"a@example.com"}),
        );
        assert_eq!(left.canonical_hash(), right.canonical_hash());
    }

    #[test]
    fn canonical_hash_changes_when_parameters_mutate() {
        let mut invocation =
            Invocation::tool("transfer", json!({"amount":100,"recipient":"Alice"}));
        let before = invocation.canonical_hash();
        invocation.params = json!({"amount":10000,"recipient":"Mallory"});
        assert_ne!(before, invocation.canonical_hash());
    }

    #[test]
    fn canonical_value_binds_resource_identity() {
        let tool = Invocation::tool("lookup", json!({"id":1}));
        let agent = Invocation::agent("lookup", json!({"id":1}));
        assert_ne!(tool.canonical_hash(), agent.canonical_hash());
    }
}

// ── Extractor plumbing ──────────────────────────────────────────────

/// Pluggable extractor: turns a raw call result into a JSON value the
/// expression sees as `result.*`. The default implementation is identity
/// (returns the raw result unchanged).
pub trait Extractor: Send + Sync {
    /// Extract a normalized payload. Returning `None` signals "skip this
    /// populator" (e.g. result not parseable in the expected shape).
    fn extract(&self, raw: &Value) -> Option<Value>;
}

/// Registry of extractors keyed by reverse-domain name (the value of
/// `extractor:` on a populator entry).
#[derive(Default)]
pub struct ExtractorRegistry {
    extractors: HashMap<String, Box<dyn Extractor>>,
}

impl std::fmt::Debug for ExtractorRegistry {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("ExtractorRegistry")
            .field("count", &self.extractors.len())
            .finish()
    }
}

impl ExtractorRegistry {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn register(&mut self, name: impl Into<String>, extractor: Box<dyn Extractor>) {
        self.extractors.insert(name.into(), extractor);
    }

    pub fn get(&self, name: &str) -> Option<&dyn Extractor> {
        self.extractors.get(name).map(|b| b.as_ref())
    }
}

/// The default extractor (§10.5.3): parses JSON-shaped string payloads
/// so populator expressions like `@result.sensitivity` can field-access
/// the result regardless of whether the host passed a parsed object or
/// the framework's serialised string. Non-string payloads are returned
/// unchanged. Strings that are not valid JSON are returned unchanged
/// so populators with `expression:` omitted (default-lookup) still see
/// the raw payload.
pub struct DefaultExtractor;

impl Extractor for DefaultExtractor {
    fn extract(&self, raw: &Value) -> Option<Value> {
        if let Value::String(s) = raw {
            let trimmed = s.trim_start();
            if matches!(trimmed.as_bytes().first(), Some(b'{') | Some(b'[')) {
                if let Ok(parsed) = serde_json::from_str::<Value>(s) {
                    return Some(parsed);
                }
            }
        }
        Some(raw.clone())
    }
}

// ── Errors ──────────────────────────────────────────────────────────

#[derive(Debug, thiserror::Error)]
pub enum PopulatorError {
    #[error("populator expression failed to parse: {0}")]
    ExpressionParse(String),

    #[error("populator references `result.*` but no result is bound (phase: before?)")]
    MissingResult,
}

// ── Selection ───────────────────────────────────────────────────────

/// Walk the declared variables and return all `(variable, entry)` pairs
/// whose `kind` + identity + phase match the invocation.
///
/// Match rules per §10.5.1:
///
/// - `kind: tool` matches `invocation.kind == Tool` and either
///   `entry.name == invocation.name` or `entry.name == "*"`.
/// - `kind: agent` matches `invocation.kind == Agent` analogously.
/// - `kind: endpoint` matches `invocation.kind == Endpoint`, the URI
///   matches the entry's `pattern`, and the method is in `entry.methods`
///   (or `entry.methods` is `["*"]`).
pub fn select_populators<'a>(
    variables: &'a [Variable],
    invocation: &Invocation,
    phase: Phase,
) -> Vec<(&'a Variable, &'a PopulatorEntry)> {
    let mut out = Vec::new();
    for var in variables {
        for entry in &var.populated_by {
            if entry.phase == phase && entry_matches_invocation(entry, invocation) {
                out.push((var, entry));
            }
        }
    }
    out
}

pub(crate) fn entry_matches_invocation(entry: &PopulatorEntry, inv: &Invocation) -> bool {
    if entry.kind != inv.kind {
        return false;
    }
    match entry.kind {
        ResourceKind::Tool | ResourceKind::Agent => match (&entry.name, &inv.name) {
            (Some(en), Some(in_n)) => en == "*" || en == in_n,
            _ => false,
        },
        ResourceKind::Endpoint => endpoint_match_pop(entry, inv),
    }
}

fn endpoint_match_pop(entry: &PopulatorEntry, inv: &Invocation) -> bool {
    let Some(pattern) = entry.pattern.as_deref() else {
        return false;
    };
    let Some(uri) = inv.uri.as_deref() else {
        return false;
    };
    let Some(method) = inv.method.as_deref() else {
        return false;
    };

    if !methods_match(&entry.methods, method) {
        return false;
    }
    pattern_matches_uri(pattern, uri)
}

pub(crate) fn methods_match(allowed: &[String], actual: &str) -> bool {
    if allowed.is_empty() {
        return true;
    }
    allowed
        .iter()
        .any(|m| m == "*" || m.eq_ignore_ascii_case(actual))
}

/// Endpoint pattern matcher.
///
/// Supports three forms (§13.4):
///   - exact: `/users/profile` — string equality.
///   - parameterized: `/users/{id}` — segment count must match;
///     `{name}` segments match any non-empty segment.
///   - prefix glob: `/admin/**` — matches the bare prefix `/admin` and any
///     descendant `/admin/...`. The bare-prefix case is already covered by
///     the `starts_with` + length check (when `uri.len() == prefix.len()`),
///     so no separate equality fallback is needed.
///
/// The standalone pattern `**` matches any URI. Specificity-based
/// tie-breaking across multiple candidate patterns is the runtime's
/// concern; this function is purely Boolean.
pub(crate) fn pattern_matches_uri(pattern: &str, uri: &str) -> bool {
    if pattern == uri {
        return true;
    }

    if let Some(prefix) = pattern.strip_suffix("/**") {
        return uri.starts_with(prefix)
            && (uri.len() == prefix.len() || uri[prefix.len()..].starts_with('/'));
    }
    if pattern == "**" {
        return true;
    }

    let pat_segs: Vec<&str> = pattern.trim_start_matches('/').split('/').collect();
    let uri_segs: Vec<&str> = uri.trim_start_matches('/').split('/').collect();
    if pat_segs.len() != uri_segs.len() {
        return false;
    }
    pat_segs
        .iter()
        .zip(uri_segs.iter())
        .all(|(p, u)| (p.starts_with('{') && p.ends_with('}') && !u.is_empty()) || p == u)
}

// ── Application ─────────────────────────────────────────────────────

/// Run a single populator entry. For `phase: after`, `result` is bound and
/// piped through the entry's extractor (or the default identity extractor)
/// before evaluation. For `phase: before`, no result is bound.
///
/// `variable_state` is a snapshot of the current declared-variable values
/// (bare attribute names → JSON value). Per spec §10.5.3 these are visible
/// inside populator expressions, e.g. `attempt_count + 1` reads the
/// current value of `attempt_count`. Callers that don't track state may
/// pass `None`; expressions that reference unbound names will see `null`.
///
/// Returns:
/// - `Ok(Some(value))` — the value to write (subject to update_policy).
/// - `Ok(None)` — no-op (extractor declined; default-lookup key absent;
///   evaluation produced no value).
/// - `Err(_)` — parse / structural error.
pub fn apply_populator(
    var: &Variable,
    entry: &PopulatorEntry,
    invocation: &Invocation,
    result: Option<&Value>,
    extractors: Option<&ExtractorRegistry>,
    variable_state: Option<&HashMap<String, Value>>,
) -> Result<Option<Value>, PopulatorError> {
    let extracted: Option<Value> = match (entry.phase, result) {
        (Phase::After, Some(raw)) => {
            let registry_hit = entry
                .extractor
                .as_deref()
                .and_then(|name| extractors.and_then(|r| r.get(name)));
            match registry_hit {
                Some(ex) => ex.extract(raw),
                None => DefaultExtractor.extract(raw),
            }
        }
        (Phase::After, None) => None,
        (Phase::Before, _) => None,
    };

    let mut attrs: HashMap<String, Value> = HashMap::new();
    // Bind the current variable-state snapshot first so namespaced bindings
    // (e.g. `tool.*`, `result`) override any same-named declared variable.
    if let Some(snapshot) = variable_state {
        for (k, v) in snapshot {
            attrs.insert(k.clone(), v.clone());
        }
    }
    bind_invocation_attrs(&mut attrs, invocation);
    if let Some(r) = &extracted {
        attrs.insert("@result".into(), r.clone());
    }

    let Some(expr_src) = entry.expression.as_deref() else {
        return Ok(default_lookup(var, &extracted));
    };

    let ast = parse(expr_src).map_err(|e| PopulatorError::ExpressionParse(format!("{:?}", e)))?;

    let value = eval_to_value(&ast, &attrs, expr_src);
    Ok(Some(value))
}

fn default_lookup(_var: &Variable, extracted: &Option<Value>) -> Option<Value> {
    // §10.5.3: the default extractor returns the raw result. Hosts that want
    // a sub-field can declare `expression: "result.<key>"` explicitly.
    extracted.as_ref().cloned()
}

fn bind_invocation_attrs(attrs: &mut HashMap<String, Value>, inv: &Invocation) {
    match inv.kind {
        ResourceKind::Tool => {
            let mut tool = serde_json::Map::new();
            if let Some(n) = &inv.name {
                tool.insert("name".into(), Value::String(n.clone()));
            }
            tool.insert("params".into(), inv.params.clone());
            attrs.insert("@tool".into(), Value::Object(tool));
        }
        ResourceKind::Agent => {
            let mut agent = serde_json::Map::new();
            if let Some(n) = &inv.name {
                agent.insert("name".into(), Value::String(n.clone()));
            }
            agent.insert("payload".into(), inv.params.clone());
            attrs.insert("@agent".into(), Value::Object(agent));
        }
        ResourceKind::Endpoint => {
            let mut ep = serde_json::Map::new();
            if let Some(m) = &inv.method {
                ep.insert("method".into(), Value::String(m.clone()));
            }
            if let Some(u) = &inv.uri {
                ep.insert("uri".into(), Value::String(u.clone()));
            }
            ep.insert("body".into(), inv.params.clone());
            ep.insert(
                "path_params".into(),
                Value::Object(map_to_json(&inv.path_params)),
            );
            ep.insert(
                "query".into(),
                Value::Object(map_to_json(&inv.query_params)),
            );
            attrs.insert("@endpoint".into(), Value::Object(ep));
        }
    }
}

fn map_to_json(m: &HashMap<String, Value>) -> serde_json::Map<String, Value> {
    let mut out = serde_json::Map::new();
    for (k, v) in m {
        out.insert(k.clone(), v.clone());
    }
    out
}

// ── Mini value-returning evaluator ─────────────────────────────────
//
// `evaluate_with` from the expressions crate returns `bool`. For populator
// expressions we need the raw value. We re-walk the (already parsed) AST
// here for the subset of forms a populator typically uses: literals,
// identifiers, dotted access, indexed access, list literals, and the
// arithmetic operators that show up in counter-update populators
// (`recipient_count + 1`). For boolean / comparison forms we delegate
// back to `evaluate_with`, which preserves fail-closed semantics.

fn eval_to_value(expr: &Expr, attrs: &HashMap<String, Value>, expr_src: &str) -> Value {
    match expr {
        Expr::Literal(lit) => lit_to_value(lit),
        Expr::Ident(name) => attrs.get(name).cloned().unwrap_or(Value::Null),
        Expr::DottedAccess { root, path } => {
            let base = eval_to_value(root, attrs, expr_src);
            walk_dotted(&base, path)
        }
        Expr::Index { object, index } => {
            let base = eval_to_value(object, attrs, expr_src);
            let idx = eval_to_value(index, attrs, expr_src);
            index_into(&base, &idx)
        }
        Expr::List(items) => {
            let vals: Vec<Value> = items
                .iter()
                .map(|i| eval_to_value(i, attrs, expr_src))
                .collect();
            Value::Array(vals)
        }
        Expr::UnaryOp { op, operand } => {
            use crate::expressions::ast::UnOp;
            let v = eval_to_value(operand, attrs, expr_src);
            match op {
                UnOp::Neg => match v.as_f64() {
                    Some(n) => json_num(-n),
                    None => Value::Null,
                },
                UnOp::Not => match &v {
                    Value::Bool(b) => Value::Bool(!*b),
                    Value::Null => Value::Bool(false),
                    other => Value::Bool(!truthy(other)),
                },
            }
        }
        Expr::BinaryOp { op, left, right } => {
            use crate::expressions::ast::BinOp;
            let lv = eval_to_value(left, attrs, expr_src);
            let rv = eval_to_value(right, attrs, expr_src);
            match op {
                BinOp::Add => arith(&lv, &rv, |a, b| a + b),
                BinOp::Sub => arith(&lv, &rv, |a, b| a - b),
                BinOp::Mul => arith(&lv, &rv, |a, b| a * b),
                BinOp::Div => arith(&lv, &rv, |a, b| {
                    if b == 0.0 {
                        log::warn!("populator: division by zero in expression `{}`", expr_src);
                        f64::NAN
                    } else {
                        a / b
                    }
                }),
                BinOp::Mod => arith(&lv, &rv, |a, b| {
                    if b == 0.0 {
                        log::warn!("populator: modulo by zero in expression `{}`", expr_src);
                        f64::NAN
                    } else {
                        a % b
                    }
                }),
                _ => Value::Null,
            }
        }
        // FnCall / Quantifier / MetaField / Ternary / Assignment fall back
        // to `Value::Null` for value-returning use; these are not expected
        // in populator expressions in practice. P5 lifts the populator to
        // `expressions::eval::evaluate_to_value` once that helper exists,
        // covering the full expression language.
        _ => Value::Null,
    }
}

fn lit_to_value(lit: &LitValue) -> Value {
    match lit {
        LitValue::Str(s) => Value::String(s.clone()),
        LitValue::Number(n) => json_num(*n),
        LitValue::Bool(b) => Value::Bool(*b),
        LitValue::Null => Value::Null,
    }
}

fn walk_dotted(base: &Value, path: &[String]) -> Value {
    let mut cur = base.clone();
    for seg in path {
        cur = match cur {
            Value::Object(map) => map.get(seg).cloned().unwrap_or(Value::Null),
            _ => return Value::Null,
        };
    }
    cur
}

fn index_into(base: &Value, idx: &Value) -> Value {
    match (base, idx) {
        (Value::Array(items), Value::Number(n)) => {
            let i = n.as_f64().unwrap_or(-1.0) as i64;
            if i < 0 {
                Value::Null
            } else {
                items.get(i as usize).cloned().unwrap_or(Value::Null)
            }
        }
        (Value::Object(map), Value::String(k)) => map.get(k).cloned().unwrap_or(Value::Null),
        _ => Value::Null,
    }
}

fn arith(a: &Value, b: &Value, op: impl Fn(f64, f64) -> f64) -> Value {
    match (a.as_f64(), b.as_f64()) {
        (Some(x), Some(y)) => json_num(op(x, y)),
        _ => Value::Null,
    }
}

fn json_num(f: f64) -> Value {
    if f.is_nan() || f.is_infinite() {
        return Value::Null;
    }
    if f.fract() == 0.0 && f.abs() < (i64::MAX as f64) {
        Value::Number((f as i64).into())
    } else {
        serde_json::Number::from_f64(f)
            .map(Value::Number)
            .unwrap_or(Value::Null)
    }
}

fn truthy(v: &Value) -> bool {
    match v {
        Value::Null => false,
        Value::Bool(b) => *b,
        Value::Number(n) => n.as_f64().map(|x| x != 0.0).unwrap_or(false),
        Value::String(s) => !s.is_empty(),
        Value::Array(a) => !a.is_empty(),
        Value::Object(o) => !o.is_empty(),
    }
}

/// Convenience: a one-shot "evaluate this expression as truthy bool against
/// these attrs" wrapper around `evaluate_with`. Used by tests and reserved
/// for guard-policy logic in later phases.
#[allow(dead_code)]
pub(crate) fn eval_bool(expr_src: &str, attrs: &HashMap<String, Value>) -> bool {
    let ctx = EvalContext::from_attrs(attrs);
    evaluate_with(expr_src, &ctx)
}

// ── Tests ──────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use crate::variables::{PopulatorEntry, ResourceKind};
    use serde_json::json;

    fn pop_tool(name: &str, expr: Option<&str>, phase: Phase) -> PopulatorEntry {
        PopulatorEntry {
            kind: ResourceKind::Tool,
            name: Some(name.into()),
            pattern: None,
            methods: vec![],
            phase,
            expression: expr.map(str::to_string),
            extractor: None,
        }
    }

    fn pop_agent(name: &str, expr: Option<&str>, phase: Phase) -> PopulatorEntry {
        PopulatorEntry {
            kind: ResourceKind::Agent,
            name: Some(name.into()),
            pattern: None,
            methods: vec![],
            phase,
            expression: expr.map(str::to_string),
            extractor: None,
        }
    }

    fn pop_endpoint(
        pattern: &str,
        methods: Vec<&str>,
        expr: Option<&str>,
        phase: Phase,
    ) -> PopulatorEntry {
        PopulatorEntry {
            kind: ResourceKind::Endpoint,
            name: None,
            pattern: Some(pattern.into()),
            methods: methods.into_iter().map(String::from).collect(),
            phase,
            expression: expr.map(str::to_string),
            extractor: None,
        }
    }

    fn var_with_pop(name: &str, entries: Vec<PopulatorEntry>) -> Variable {
        use crate::variables::VariableType;
        Variable {
            name: name.into(),
            var_type: VariableType::Object,
            description: None,
            default: None,
            members: None,
            update: None,
            key: None,
            lifetime: None,
            on_demand_by: None,
            populated_by: entries,
            reset_by: vec![],
        }
    }

    // ── Selection ─────────────────────────────────────────────────

    #[test]
    fn selects_tool_by_exact_name() {
        let v = var_with_pop("x", vec![pop_tool("send_email", None, Phase::After)]);
        let inv = Invocation::tool("send_email", json!({}));
        let hits = select_populators(std::slice::from_ref(&v), &inv, Phase::After);
        assert_eq!(hits.len(), 1);
    }

    #[test]
    fn skips_tool_when_name_mismatched() {
        let v = var_with_pop("x", vec![pop_tool("send_email", None, Phase::After)]);
        let inv = Invocation::tool("delete_file", json!({}));
        let hits = select_populators(std::slice::from_ref(&v), &inv, Phase::After);
        assert!(hits.is_empty());
    }

    #[test]
    fn matches_wildcard_tool() {
        let v = var_with_pop("x", vec![pop_tool("*", None, Phase::After)]);
        let inv = Invocation::tool("anything", json!({}));
        assert_eq!(
            select_populators(std::slice::from_ref(&v), &inv, Phase::After).len(),
            1
        );
    }

    #[test]
    fn matches_agent_kind_distinct_from_tool() {
        let v = var_with_pop("x", vec![pop_agent("planner", None, Phase::After)]);
        let inv_a = Invocation::agent("planner", json!({}));
        let inv_t = Invocation::tool("planner", json!({}));
        assert_eq!(
            select_populators(std::slice::from_ref(&v), &inv_a, Phase::After).len(),
            1
        );
        assert!(select_populators(std::slice::from_ref(&v), &inv_t, Phase::After).is_empty());
    }

    #[test]
    fn endpoint_matches_exact_pattern_and_method() {
        let v = var_with_pop(
            "x",
            vec![pop_endpoint(
                "/api/v1/users",
                vec!["GET"],
                None,
                Phase::After,
            )],
        );
        let inv = Invocation::endpoint("GET", "/api/v1/users", json!({}));
        assert_eq!(
            select_populators(std::slice::from_ref(&v), &inv, Phase::After).len(),
            1
        );
    }

    #[test]
    fn endpoint_method_case_insensitive() {
        let v = var_with_pop(
            "x",
            vec![pop_endpoint(
                "/api/v1/users",
                vec!["GET"],
                None,
                Phase::After,
            )],
        );
        let inv = Invocation::endpoint("get", "/api/v1/users", json!({}));
        assert_eq!(
            select_populators(std::slice::from_ref(&v), &inv, Phase::After).len(),
            1
        );
    }

    #[test]
    fn endpoint_method_wildcard() {
        let v = var_with_pop("x", vec![pop_endpoint("/x", vec!["*"], None, Phase::After)]);
        for m in &["GET", "POST", "DELETE", "PATCH"] {
            let inv = Invocation::endpoint(*m, "/x", json!({}));
            assert_eq!(
                select_populators(std::slice::from_ref(&v), &inv, Phase::After).len(),
                1
            );
        }
    }

    #[test]
    fn endpoint_glob_pattern_matches_subpaths() {
        let v = var_with_pop(
            "x",
            vec![pop_endpoint(
                "/api/v1/external/**",
                vec!["GET"],
                None,
                Phase::After,
            )],
        );
        let inv = Invocation::endpoint("GET", "/api/v1/external/foo/bar", json!({}));
        assert_eq!(
            select_populators(std::slice::from_ref(&v), &inv, Phase::After).len(),
            1
        );
    }

    #[test]
    fn endpoint_param_template_matches_segment() {
        let v = var_with_pop(
            "x",
            vec![pop_endpoint(
                "/api/v1/accounts/{id}",
                vec!["GET"],
                None,
                Phase::After,
            )],
        );
        let inv = Invocation::endpoint("GET", "/api/v1/accounts/42", json!({}));
        assert_eq!(
            select_populators(std::slice::from_ref(&v), &inv, Phase::After).len(),
            1
        );
        let inv2 = Invocation::endpoint("GET", "/api/v1/accounts/42/posts", json!({}));
        assert!(select_populators(std::slice::from_ref(&v), &inv2, Phase::After).is_empty());
    }

    #[test]
    fn phase_filter_separates_before_and_after() {
        let v = var_with_pop(
            "x",
            vec![
                pop_tool("t", None, Phase::Before),
                pop_tool("t", Some("@result.x"), Phase::After),
            ],
        );
        let inv = Invocation::tool("t", json!({}));
        assert_eq!(
            select_populators(std::slice::from_ref(&v), &inv, Phase::Before).len(),
            1
        );
        assert_eq!(
            select_populators(std::slice::from_ref(&v), &inv, Phase::After).len(),
            1
        );
    }

    #[test]
    fn multiple_populators_on_same_variable_independent() {
        let v = var_with_pop(
            "x",
            vec![
                pop_tool("a", None, Phase::After),
                pop_tool("b", None, Phase::After),
            ],
        );
        let inv = Invocation::tool("a", json!({}));
        let hits = select_populators(std::slice::from_ref(&v), &inv, Phase::After);
        assert_eq!(hits.len(), 1);
    }

    // ── Application ────────────────────────────────────────────────

    #[test]
    fn default_lookup_returns_raw_result() {
        // §10.5.3: the default extractor returns the raw `result` object.
        // Hosts that want a sub-field declare `expression: "result.<key>"`.
        let v = var_with_pop("profile", vec![pop_tool("get_profile", None, Phase::After)]);
        let entry = &v.populated_by[0];
        let inv = Invocation::tool("get_profile", json!({}));
        let result = json!({"profile": {"name": "alice"}});
        let out = apply_populator(&v, entry, &inv, Some(&result), None, None).unwrap();
        assert_eq!(out, Some(json!({"profile": {"name": "alice"}})));
    }

    #[test]
    fn default_lookup_returns_raw_scalar_result() {
        let v = var_with_pop("x", vec![pop_tool("t", None, Phase::After)]);
        let entry = &v.populated_by[0];
        let inv = Invocation::tool("t", json!({}));
        let result = json!(42);
        let out = apply_populator(&v, entry, &inv, Some(&result), None, None).unwrap();
        assert_eq!(out, Some(json!(42)));
    }

    #[test]
    fn expression_extracts_dotted_path() {
        let v = var_with_pop(
            "name",
            vec![pop_tool(
                "get_user",
                Some("@result.user.name"),
                Phase::After,
            )],
        );
        let entry = &v.populated_by[0];
        let inv = Invocation::tool("get_user", json!({}));
        let result = json!({"user": {"name": "alice"}});
        let out = apply_populator(&v, entry, &inv, Some(&result), None, None).unwrap();
        assert_eq!(out, Some(json!("alice")));
    }

    #[test]
    fn expression_arithmetic_increments_counter() {
        let v = var_with_pop(
            "n",
            vec![pop_tool("inc", Some("@result.value + 1"), Phase::After)],
        );
        let entry = &v.populated_by[0];
        let inv = Invocation::tool("inc", json!({}));
        let result = json!({"value": 7});
        let out = apply_populator(&v, entry, &inv, Some(&result), None, None).unwrap();
        assert_eq!(out, Some(json!(8)));
    }

    #[test]
    fn before_phase_literal_expression() {
        let v = var_with_pop("n", vec![pop_tool("inc", Some("42"), Phase::Before)]);
        let entry = &v.populated_by[0];
        let inv = Invocation::tool("inc", json!({}));
        let out = apply_populator(&v, entry, &inv, None, None, None).unwrap();
        assert_eq!(out, Some(json!(42)));
    }

    #[test]
    fn before_phase_default_lookup_yields_none() {
        let v = var_with_pop("n", vec![pop_tool("t", None, Phase::Before)]);
        let entry = &v.populated_by[0];
        let inv = Invocation::tool("t", json!({}));
        let out = apply_populator(&v, entry, &inv, None, None, None).unwrap();
        assert!(out.is_none());
    }

    // ── Extractor registry ─────────────────────────────────────────

    struct UpcaseExtractor;
    impl Extractor for UpcaseExtractor {
        fn extract(&self, raw: &Value) -> Option<Value> {
            raw.as_str().map(|s| Value::String(s.to_uppercase()))
        }
    }

    #[test]
    fn registered_extractor_runs_before_expression() {
        let mut reg = ExtractorRegistry::new();
        reg.register("test.upcase", Box::new(UpcaseExtractor));

        let mut entry = pop_tool("t", Some("@result"), Phase::After);
        entry.extractor = Some("test.upcase".into());
        let v = var_with_pop("greeting", vec![entry]);
        let entry = &v.populated_by[0];

        let inv = Invocation::tool("t", json!({}));
        let result = json!("hello");
        let out = apply_populator(&v, entry, &inv, Some(&result), Some(&reg), None).unwrap();
        assert_eq!(out, Some(json!("HELLO")));
    }

    #[test]
    fn unregistered_extractor_falls_back_to_default() {
        let reg = ExtractorRegistry::new();
        let mut entry = pop_tool("t", Some("@result.k"), Phase::After);
        entry.extractor = Some("unknown.ext".into());
        let v = var_with_pop("x", vec![entry]);
        let entry = &v.populated_by[0];
        let inv = Invocation::tool("t", json!({}));
        let result = json!({"k": "v"});
        let out = apply_populator(&v, entry, &inv, Some(&result), Some(&reg), None).unwrap();
        assert_eq!(out, Some(json!("v")));
    }

    // ── Pattern matching unit tests ────────────────────────────────

    #[test]
    fn pattern_matches_uri_unit() {
        assert!(pattern_matches_uri("/a/b", "/a/b"));
        assert!(pattern_matches_uri("/a/{id}", "/a/42"));
        assert!(!pattern_matches_uri("/a/{id}", "/a/42/extra"));
        assert!(pattern_matches_uri("/a/**", "/a/b/c/d"));
        assert!(pattern_matches_uri("/a/**", "/a"));
        assert!(!pattern_matches_uri("/a/**", "/b/c"));
        assert!(pattern_matches_uri("**", "/anything/at/all"));
    }

    #[test]
    fn methods_match_unit() {
        assert!(methods_match(&["GET".into()], "GET"));
        assert!(methods_match(&["GET".into()], "get"));
        assert!(methods_match(&["*".into()], "POST"));
        assert!(!methods_match(&["GET".into()], "POST"));
    }

    // ── Variable-state binding (§10.5.3) ────────────────────────────

    #[test]
    fn populator_expression_reads_current_variable_state() {
        // §10.5.3 says populator expressions evaluate against the current
        // variable state. A counter populator like `attempt_count + 1`
        // must see the existing value of `attempt_count`.
        let v = var_with_pop(
            "attempt_count",
            vec![pop_tool("retry", Some("attempt_count + 1"), Phase::After)],
        );
        let entry = &v.populated_by[0];
        let inv = Invocation::tool("retry", json!({}));
        let result = json!({});
        let mut state = HashMap::new();
        state.insert("attempt_count".into(), json!(5));
        let out = apply_populator(&v, entry, &inv, Some(&result), None, Some(&state)).unwrap();
        assert_eq!(out, Some(json!(6)));
    }

    #[test]
    fn populator_unbound_variable_state_evaluates_to_null() {
        // Without a state snapshot, `attempt_count` is unbound and the
        // arithmetic `null + 1` propagates to `null` per fail-closed
        // semantics.
        let v = var_with_pop(
            "attempt_count",
            vec![pop_tool("retry", Some("attempt_count + 1"), Phase::After)],
        );
        let entry = &v.populated_by[0];
        let inv = Invocation::tool("retry", json!({}));
        let result = json!({});
        let out = apply_populator(&v, entry, &inv, Some(&result), None, None).unwrap();
        assert_eq!(out, Some(Value::Null));
    }
}
