//! Adapters bridging runtime state into the expression evaluator's
//! hook traits.
//!
//! The expression module defines four hook traits — [`StatusLookup`],
//! [`EventFiredHook`], [`PredicateLookup`], and [`ResolverHook`] — that
//! callers populate per-evaluation. This module owns the
//! implementations:
//!
//! - [`TrackerStatusLookup`] wraps a [`LifetimeTracker`] reference.
//! - [`PredicateMapLookup`] wraps a [`PredicateMap`] reference.
//! - The [`crate::resolver_runtime::AutoResolveAdapter`] is reused
//!   directly for resolver auto-resolution.
//!
//! Hosts shouldn't need to use these directly — the per-stage runners
//! build them fresh per-call.

use crate::event_bus::EventBus;
use crate::events::EventId;
use crate::expressions::eval::{
    EvalResult, EventFiredHook, PredicateLookup, StatusLookup, VariableStatus,
};
use crate::lifetime_tracker::{LifetimeTracker, VarStatus};
use crate::predicates::PredicateMap;
use crate::session_id::SessionId;

/// Adapter that satisfies [`StatusLookup`] by reading from a
/// [`LifetimeTracker`] scoped to a specific session.
pub struct TrackerStatusLookup<'a> {
    pub tracker: &'a LifetimeTracker,
    pub session_id: SessionId,
}

impl<'a> TrackerStatusLookup<'a> {
    pub fn new(tracker: &'a LifetimeTracker) -> Self {
        Self {
            tracker,
            session_id: SessionId::default(),
        }
    }

    pub fn new_in(tracker: &'a LifetimeTracker, session_id: SessionId) -> Self {
        Self {
            tracker,
            session_id,
        }
    }
}

impl<'a> StatusLookup for TrackerStatusLookup<'a> {
    fn status(&self, var: &str) -> Option<VariableStatus> {
        let st = self.tracker.read_variable_in(&self.session_id, var);
        Some(match st.status {
            VarStatus::Unset => VariableStatus::Unset,
            VarStatus::Resolved => VariableStatus::Resolved,
            VarStatus::Denied => VariableStatus::Denied,
        })
    }

    fn meta(&self, var: &str, field: &str) -> Option<EvalResult> {
        let st = self.tracker.read_variable_in(&self.session_id, var);
        match field {
            "status" => Some(EvalResult::Str(
                match st.status {
                    VarStatus::Unset => "unset",
                    VarStatus::Resolved => "resolved",
                    VarStatus::Denied => "denied",
                }
                .to_string(),
            )),
            "set_at" => Some(EvalResult::DateTime(st.set_at)),
            "expires_at" => st.expires_at.map(EvalResult::DateTime),
            "source_kind" => st.source_kind.map(EvalResult::Str),
            "set_by" => st.set_by.map(EvalResult::Str),
            "deny_reason" => st.deny_reason.map(EvalResult::Str),
            // §9.3.2 v2 metadata fields:
            //
            // `@key` — the key under which the current read or write
            //   resolved. Always None on this non-keyed lookup path; the
            //   keyed read in bind_resolved_variables surfaces the key
            //   to attrs and authors who declared `key:` see their key
            //   value reflected in the variable's read at the gating site.
            //   For now we report None; full per-key metadata round-trip
            //   would need a keyed-aware StatusLookup, deferred.
            "key" => None,
            // `@deny_kind` — present when `@status == 'denied'`, valued
            //   as `'deny'` or `'cancelled'`. We don't currently
            //   distinguish between the two on the tracker; report None
            //   to remain spec-faithful (authors who need the
            //   distinction will see deny_reason text instead).
            "deny_kind" => match st.status {
                VarStatus::Denied => Some(EvalResult::Str("deny".to_string())),
                _ => None,
            },
            // `@source_reason` — alias of `deny_reason` in the v2
            //   nomenclature for consistency across writers (resolver,
            //   host, populator).
            "source_reason" => st.deny_reason.map(EvalResult::Str),
            // `@source_params` — snapshot captured by the populator /
            //   resolver write per §9.3.2.
            "source_params" => st.source_params.map(|v| {
                use crate::expressions::eval::value_to_eval;
                value_to_eval(&v)
            }),
            _ => None,
        }
    }
}

/// Adapter that satisfies [`PredicateLookup`] by reading from a
/// [`PredicateMap`].
pub struct PredicateMapLookup<'a> {
    pub map: &'a PredicateMap,
}

impl<'a> PredicateMapLookup<'a> {
    pub fn new(map: &'a PredicateMap) -> Self {
        Self { map }
    }
}

impl<'a> PredicateLookup for PredicateMapLookup<'a> {
    fn body(&self, name: &str) -> Option<&str> {
        self.map
            .entries
            .get(name)
            .map(|e| e.body.expression.as_str())
    }
}

/// Session-scoped [`EventFiredHook`] used by every per-stage runner so
/// `event.fired(<id>)` calls inside expressions consult only the
/// emitting session's latches (spec §10). The legacy
/// [`EventFiredHook for EventBus`] aggregates across sessions; the
/// stage runners never use that direct impl.
pub struct SessionScopedEventFired<'a> {
    pub bus: &'a EventBus,
    pub session_id: SessionId,
}

impl<'a> SessionScopedEventFired<'a> {
    pub fn new(bus: &'a EventBus, session_id: SessionId) -> Self {
        Self { bus, session_id }
    }
}

impl<'a> EventFiredHook for SessionScopedEventFired<'a> {
    fn fired(&self, event_id: &str) -> bool {
        match EventId::parse(event_id) {
            Ok(id) => self.bus.fired_id_in(&self.session_id, &id),
            Err(_) => false,
        }
    }
}
