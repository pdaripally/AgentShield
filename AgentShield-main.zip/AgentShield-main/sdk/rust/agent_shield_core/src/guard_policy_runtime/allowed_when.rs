//! `allowed_when:` bypass evaluation (§12.6 / §12.12).
//!
//! When an `evaluate_when[]` entry fails, the runtime calls into here to
//! check whether the guard policy's `allowed_when:` predicate suppresses
//! the failure. Auto-resolution **does** fire on these reads (in contrast
//! to `active_if:`), so we evaluate with `is_gating_site = true` and the
//! engine's resolver hook attached.

use std::collections::HashMap;

use serde_json::Value;

use crate::expressions::eval::{
    evaluate_with, EvalContext, EventFiredHook, PredicateLookup, ResolverHook, StatusLookup,
};

/// Evaluate `allowed_when:` truthiness. Returns `false` when the
/// predicate is absent (no bypass declared). Auto-resolution fires per
/// §11.5 / §12.6.
#[allow(clippy::too_many_arguments)]
pub fn evaluate_allowed_when(
    expr: Option<&str>,
    attrs: &HashMap<String, Value>,
    status_lookup: Option<&dyn StatusLookup>,
    event_fired: Option<&dyn EventFiredHook>,
    predicates: Option<&dyn PredicateLookup>,
    resolver_hook: Option<&dyn ResolverHook>,
) -> bool {
    let Some(e) = expr else {
        return false;
    };
    let mut ctx = EvalContext::from_attrs(attrs);
    ctx.status_lookup = status_lookup;
    ctx.event_fired = event_fired;
    ctx.predicates = predicates;
    ctx.is_gating_site = true;
    ctx.resolver_hook = resolver_hook;
    evaluate_with(e, &ctx)
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    #[test]
    fn absent_returns_false() {
        let attrs = HashMap::new();
        assert!(!evaluate_allowed_when(None, &attrs, None, None, None, None));
    }

    #[test]
    fn truthy_returns_true() {
        let mut attrs = HashMap::new();
        attrs.insert("approved".into(), json!(true));
        assert!(evaluate_allowed_when(
            Some("approved == true"),
            &attrs,
            None,
            None,
            None,
            None,
        ));
    }

    #[test]
    fn falsey_returns_false() {
        let mut attrs = HashMap::new();
        attrs.insert("approved".into(), json!(false));
        assert!(!evaluate_allowed_when(
            Some("approved == true"),
            &attrs,
            None,
            None,
            None,
            None,
        ));
    }
}
