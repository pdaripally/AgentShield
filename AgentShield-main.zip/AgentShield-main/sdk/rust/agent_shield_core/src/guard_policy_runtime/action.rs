//! Apply an effective action (`block` / `redact` / `warn` / `append` /
//! `prepend`) to a subject (§12.7).
//!
//! The runtime calls into here once it has determined the failing entry's
//! action and any spans / text to apply. Stage runners aggregate redaction
//! spans first (§12.10 step 5a), then prepends, then appends.

use super::detection::Span;

/// In-place text mutator: replace a list of spans with a replacement
/// string. Spans use **character (codepoint) offsets**, not byte offsets
/// — per spec the runtime computes spans against `chars()` so non-ASCII
/// subjects redact predictably. Non-overlapping spans are applied
/// right-to-left so subsequent offsets don't shift.
///
/// Per §12.8: each entry sees the **original** subject — the caller is
/// responsible for collecting all spans first, then asking us to apply
/// them in one shot.
pub fn apply_redactions(subject: &str, spans: &[(Span, String)]) -> String {
    if spans.is_empty() {
        return subject.to_string();
    }
    // Sort by start ascending, with the original index as tie-breaker.
    let mut indexed: Vec<(usize, &(Span, String))> = spans.iter().enumerate().collect();
    indexed.sort_by_key(|(idx, (s, _))| (s.start, *idx));

    // Filter overlaps: among overlapping spans, the earliest-starting wins
    // (with declaration-order tie-break). §12.8 says overlap behavior is
    // implementation-defined but must be deterministic.
    let mut owned: Vec<(Span, String)> = Vec::new();
    let mut cursor: usize = 0;
    for (_, (s, repl)) in &indexed {
        if s.start < cursor {
            continue;
        }
        owned.push(((*s).clone(), repl.clone()));
        cursor = s.end;
    }

    // Pre-compute the char-to-byte index table once so we can translate
    // every span without re-walking the string. Append `subject.len()`
    // as the sentinel for "one past the last char".
    let char_to_byte: Vec<usize> = subject
        .char_indices()
        .map(|(b, _)| b)
        .chain(std::iter::once(subject.len()))
        .collect();
    let char_count = char_to_byte.len() - 1;

    // Apply right-to-left so offsets stay valid as we mutate.
    let mut buf = subject.to_string();
    for (span, repl) in owned.iter().rev() {
        if span.end <= span.start || span.end > char_count {
            // Invalid char range — drop rather than clamp, per spec
            // intent (avoids partial-grapheme corruption).
            continue;
        }
        let start = char_to_byte[span.start];
        let end = char_to_byte[span.end];
        buf.replace_range(start..end, repl);
    }
    buf
}

/// Apply prepends and appends in declaration order to a text subject.
/// `prepends` are stacked (last-declared ends up at the very front per
/// §12.10 step 5b). Returns the transformed string.
pub fn apply_prepend_append(subject: &str, prepends: &[String], appends: &[String]) -> String {
    let mut buf = String::with_capacity(subject.len());
    // Stack prepends: last-declared appears first, so iterate in reverse
    // and accumulate.
    for p in prepends.iter().rev() {
        buf.push_str(p);
    }
    buf.push_str(subject);
    for a in appends {
        buf.push_str(a);
    }
    buf
}

#[cfg(test)]
mod tests {
    use super::*;

    fn span(start: usize, end: usize) -> Span {
        Span {
            start,
            end,
            replacement: None,
        }
    }

    #[test]
    fn no_spans_returns_original() {
        assert_eq!(apply_redactions("hello", &[]), "hello");
    }

    #[test]
    fn single_span_replaced() {
        let result = apply_redactions("my ssn is 123-45-6789 ok", &[(span(10, 21), "[X]".into())]);
        assert_eq!(result, "my ssn is [X] ok");
    }

    #[test]
    fn multiple_non_overlapping_spans_replaced() {
        let result = apply_redactions(
            "abc XXX def YYY ghi",
            &[(span(4, 7), "[1]".into()), (span(12, 15), "[2]".into())],
        );
        assert_eq!(result, "abc [1] def [2] ghi");
    }

    #[test]
    fn overlap_dropped_first_wins() {
        // Two spans at offsets 0..5 and 2..7 — keep the first, drop second.
        let result = apply_redactions(
            "abcdefghi",
            &[(span(0, 5), "[A]".into()), (span(2, 7), "[B]".into())],
        );
        assert_eq!(result, "[A]fghi");
    }

    #[test]
    fn append_only() {
        let v = apply_prepend_append("abc", &[], &["x".into(), "y".into()]);
        assert_eq!(v, "abcxy");
    }

    #[test]
    fn prepend_only_stacks_reverse() {
        // §12.10 step 5b: "the last-declared prepend ends up at the very front."
        let v = apply_prepend_append("abc", &["[1]".into(), "[2]".into()], &[]);
        assert_eq!(v, "[2][1]abc");
    }

    #[test]
    fn mixed_prepend_then_append() {
        let v = apply_prepend_append("abc", &["[P]".into()], &["[A]".into()]);
        assert_eq!(v, "[P]abc[A]");
    }

    // P6.7 — spans are character offsets, not byte offsets. `é` is 2
    // bytes in UTF-8 but a single character; a span 0..5 must redact 5
    // characters, not 5 bytes.
    #[test]
    fn redaction_uses_char_offsets_not_byte_offsets() {
        let result = apply_redactions("héllo world", &[(span(0, 5), "[X]".into())]);
        assert_eq!(result, "[X] world");
    }

    #[test]
    fn redaction_ignores_spans_past_char_count() {
        // "héllo" is 5 chars / 6 bytes. A span 0..6 (over by one char) is
        // invalid and dropped rather than clamped.
        let result = apply_redactions("héllo", &[(span(0, 6), "[X]".into())]);
        assert_eq!(result, "héllo");
    }

    #[test]
    fn redaction_invalid_zero_width_span_dropped() {
        let result = apply_redactions("héllo", &[(span(2, 2), "[X]".into())]);
        assert_eq!(result, "héllo");
    }
}
