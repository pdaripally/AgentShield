//! Stage 5 — `output_validation` runner (§18).
//!
//! Subject: the agent's final response text. `applies_to:` is rejected at
//! load. All detection kinds are accepted; `block` / `redact` / `warn` /
//! `append` / `prepend` actions all valid.

use std::collections::HashMap;
use std::sync::Mutex;

use crate::guard_policy::Action;
use crate::observability::Stage;
use crate::resolver_runtime::AutoResolveAdapter;

use super::action::{apply_prepend_append, apply_redactions};
use super::evaluate_when::run_evaluate_when;
use super::runtime_hooks::{PredicateMapLookup, SessionScopedEventFired, TrackerStatusLookup};
use super::stage_common::{
    bind_resolved_variables_in, block_verdict, build_allowed_when_deps_with_event_hook,
    build_detection_deps_with_event_hook, emit_stage_verdict, log_outcome_in, ResolverHookHolder,
};
use super::{EvalRuntime, GuardPolicyEngine, StageVerdict};
use crate::session_id::SessionId;

pub(crate) fn evaluate(
    engine: &GuardPolicyEngine,
    response: &mut String,
    ctx: &EvalRuntime<'_>,
) -> StageVerdict {
    let session_id = SessionId::new(ctx.session_id);
    let policies = &engine.deps().config.output_validation.guard_policies;
    let mut attrs = ctx.build_base_attrs();
    bind_resolved_variables_in(
        &session_id,
        &mut attrs,
        engine.deps().tracker.as_ref(),
        &engine.deps().config.variables,
    );

    let status_lookup =
        TrackerStatusLookup::new_in(engine.deps().tracker.as_ref(), session_id.clone());
    let pred_lookup = PredicateMapLookup::new(&engine.deps().config.predicates);
    let resolver_holder = ResolverHookHolder {
        adapter: AutoResolveAdapter::new_in(
            engine.deps().resolver.as_ref(),
            attrs.clone(),
            session_id.clone(),
        ),
        trace: Mutex::new(Vec::new()),
    };
    let resolver_hook: &dyn crate::expressions::eval::ResolverHook = &resolver_holder;
    let event_fired_hook =
        SessionScopedEventFired::new(&engine.deps().event_bus, session_id.clone());
    let mut current_text = response.clone();
    let mut last_action: Option<Action> = None;
    let mut transformed = false;
    let mut bypassed = false;
    let mut prepends_acc: Vec<String> = Vec::new();
    let mut appends_acc: Vec<String> = Vec::new();

    for policy in policies {
        let active = engine.activation().evaluate_and_emit_in(
            &session_id,
            &policy.name,
            policy.active_if.as_deref(),
            &attrs,
            Some(&pred_lookup as &dyn crate::expressions::eval::PredicateLookup),
            Some(&event_fired_hook as &dyn crate::expressions::eval::EventFiredHook),
            &engine.deps().event_bus,
        );
        if !active {
            continue;
        }

        if policy.evaluate_when.is_empty() {
            let reason = policy
                .reason
                .clone()
                .unwrap_or_else(|| format!("guard policy `{}` blocked", policy.name));
            let v = StageVerdict::block(&policy.name, reason, None)
                .with_pending_resolution(resolver_holder.adapter.take_pending());
            let _ = engine
                .deps()
                .event_bus
                .emit_guard_policy_failed_in(&session_id, policy.name.clone());
            emit_stage_verdict(engine, &session_id, Stage::Output, &v);
            return v;
        }

        let ddeps = build_detection_deps_with_event_hook(
            engine,
            ctx,
            &attrs,
            Some(&status_lookup),
            Some(&pred_lookup),
            Some(resolver_hook),
            Some(&event_fired_hook as &dyn crate::expressions::eval::EventFiredHook),
            // §12.9.2 — Stage 5 binds `{agent_output}`.
            {
                let mut m = HashMap::new();
                m.insert("agent_output".into(), current_text.clone());
                m
            },
            // Stage 5 does not append the §16.2 Runtime Context block.
            false,
        );
        let aw_deps = build_allowed_when_deps_with_event_hook(
            engine,
            &attrs,
            Some(&status_lookup),
            Some(&pred_lookup),
            Some(resolver_hook),
            Some(&event_fired_hook as &dyn crate::expressions::eval::EventFiredHook),
        );
        let outcome = run_evaluate_when(policy, &current_text, &ddeps, &aw_deps);
        log_outcome_in(&session_id, engine, Stage::Output, policy, &outcome);

        if outcome.allowed_when_bypass_fired {
            bypassed = true;
        }

        if let Some(b) = &outcome.block {
            let v = block_verdict(policy, b)
                .with_pending_resolution(resolver_holder.adapter.take_pending());
            emit_stage_verdict(engine, &session_id, Stage::Output, &v);
            return v;
        }

        if !outcome.redactions.is_empty() {
            current_text = apply_redactions(&current_text, &outcome.redactions);
            transformed = true;
            last_action = Some(Action::Redact);
        }
        for p in &outcome.prepends {
            prepends_acc.push(p.text.clone());
        }
        for a in &outcome.appends {
            appends_acc.push(a.text.clone());
        }
        if (!outcome.prepends.is_empty() || !outcome.appends.is_empty()) && last_action.is_none() {
            last_action = if !outcome.prepends.is_empty() {
                Some(Action::Prepend)
            } else {
                Some(Action::Append)
            };
        }
        if !outcome.warns.is_empty() && last_action.is_none() {
            last_action = Some(Action::Warn);
        }
    }

    if !prepends_acc.is_empty() || !appends_acc.is_empty() {
        current_text = apply_prepend_append(&current_text, &prepends_acc, &appends_acc);
        transformed = true;
    }

    if transformed {
        *response = current_text.clone();
    }

    let mut verdict = StageVerdict::allow();
    if transformed {
        verdict.action = last_action;
        verdict.redaction = Some(current_text);
        if !appends_acc.is_empty() {
            verdict.appended = Some(appends_acc.join(""));
        }
        if !prepends_acc.is_empty() {
            // last-declared at the very front
            let mut s = String::new();
            for p in prepends_acc.iter().rev() {
                s.push_str(p);
            }
            verdict.prepended = Some(s);
        }
    } else if let Some(a) = last_action {
        verdict.action = Some(a);
    }
    verdict.bypassed_by_allowed_when = bypassed;
    emit_stage_verdict(engine, &session_id, Stage::Output, &verdict);
    verdict
}

#[cfg(test)]
mod tests {
    use super::super::tests_support::*;
    use crate::guard_policy::Action;

    #[test]
    fn passes_when_no_policies() {
        let h = test_harness(|_| {});
        let mut s = "hello".to_string();
        let v = h.engine.evaluate_output(&mut s, &h.eval_runtime(""));
        assert!(v.allowed);
    }

    #[test]
    fn redact_modifies_response() {
        let h = test_harness(|cfg| {
            let mut p = make_policy(
                "ssn",
                vec![{
                    let mut e = pattern_entry("ssn", r"\d{3}-\d{2}-\d{4}");
                    e.action = Some(Action::Redact);
                    e
                }],
                None,
                None,
            );
            p.replacement = Some("[REDACTED]".into());
            cfg.output_validation.guard_policies.push(p);
        });
        let mut s = "user ssn 123-45-6789 here".to_string();
        let v = h.engine.evaluate_output(&mut s, &h.eval_runtime(""));
        assert!(v.allowed);
        assert_eq!(s, "user ssn [REDACTED] here");
    }

    #[test]
    fn block_terminates() {
        let h = test_harness(|cfg| {
            cfg.output_validation.guard_policies.push(make_policy(
                "p",
                vec![pattern_entry("hallucination", "fabricated")],
                None,
                Some(Action::Block),
            ));
        });
        let mut s = "this is fabricated content".to_string();
        let v = h.engine.evaluate_output(&mut s, &h.eval_runtime(""));
        assert!(!v.allowed);
    }

    #[test]
    fn append_attaches_text() {
        let h = test_harness(|cfg| {
            cfg.output_validation.guard_policies.push(make_policy(
                "disclaim",
                vec![{
                    let mut e = expression_entry("disclaimer", "false");
                    e.action = Some(Action::Append);
                    e.text = Some(" --AI--".into());
                    e
                }],
                None,
                None,
            ));
        });
        let mut s = "answer".to_string();
        let v = h.engine.evaluate_output(&mut s, &h.eval_runtime(""));
        assert!(v.allowed);
        assert_eq!(s, "answer --AI--");
    }

    #[test]
    fn multiple_prepends_stack_in_reverse() {
        let h = test_harness(|cfg| {
            cfg.output_validation.guard_policies.push(make_policy(
                "p1",
                vec![{
                    let mut e = expression_entry("a", "false");
                    e.action = Some(Action::Prepend);
                    e.text = Some("[1]".into());
                    e
                }],
                None,
                None,
            ));
            cfg.output_validation.guard_policies.push(make_policy(
                "p2",
                vec![{
                    let mut e = expression_entry("b", "false");
                    e.action = Some(Action::Prepend);
                    e.text = Some("[2]".into());
                    e
                }],
                None,
                None,
            ));
        });
        let mut s = "x".to_string();
        let v = h.engine.evaluate_output(&mut s, &h.eval_runtime(""));
        assert!(v.allowed);
        assert_eq!(s, "[2][1]x");
    }
}
