//! Detection-kind dispatch for `evaluate_when[]` entries (§12.5).
//!
//! Each `EvaluateWhenEntry` carries exactly one of the five detection
//! kinds: `expression`, `pattern`, `patterns`, `llm`, `classifier`. This
//! module owns the evaluation strategy for each kind plus the trait
//! definitions hosts implement to plug in LLM and classifier providers.
//!
//! ## Design
//!
//! - **Synchronous traits**: the engine is sync. Hosts that need async
//!   wrap their async clients with `tokio::runtime::Handle::block_on`
//!   inside the trait impl.
//! - **Spans**: only `pattern` / `patterns` produce character offsets
//!   natively; `llm` and `classifier` may optionally emit spans through
//!   their structured response types per §12.8.
//! - **Polarity**: per §12.5.1 — `expression:` is a predicate (truthy =
//!   pass), all others are detectors (positive detection = fail).
//! - **Fail-closed**: any error path in detection (regex compile failure,
//!   missing host trait, malformed LLM response, unrecognized
//!   configuration) yields a `Fail { reason }` so the gate denies. This
//!   is the security invariant.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

use regex::Regex;
use serde_json::Value;

use crate::expressions::eval::{
    evaluate_with, EvalContext, EventFiredHook, PredicateLookup, ResolverHook, StatusLookup,
};
use crate::guard_policy::{ClassifierDetection, DetectionKind, EvaluateWhenEntry, LlmDetection};

/// One byte-offset range identifying a redaction span. `start..end` is
/// half-open. Mirrors the §12.9.3 span format produced by LLM responses
/// and pattern matches.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Span {
    pub start: usize,
    pub end: usize,
    pub replacement: Option<String>,
}

/// Verdict produced by detecting against a single `evaluate_when[]` entry
/// against a content subject.
#[derive(Debug, Clone)]
pub enum DetectionVerdict {
    /// The entry passed (the call may proceed past this entry).
    Pass,
    /// The entry failed. `reason` is the entry's `reason:` (or a fallback
    /// surfaced by the detector when the LLM/classifier provided one).
    Fail {
        reason: String,
        /// Character spans for redaction (`pattern` / `patterns` / `llm`
        /// with `spans[]`). Empty for predicate-style failures or LLM
        /// block-mode without spans.
        spans: Vec<Span>,
    },
}

impl DetectionVerdict {
    pub fn is_pass(&self) -> bool {
        matches!(self, DetectionVerdict::Pass)
    }
    pub fn fail(reason: impl Into<String>) -> Self {
        DetectionVerdict::Fail {
            reason: reason.into(),
            spans: Vec::new(),
        }
    }
    pub fn fail_spans(reason: impl Into<String>, spans: Vec<Span>) -> Self {
        DetectionVerdict::Fail {
            reason: reason.into(),
            spans,
        }
    }
}

/// Structured LLM response per §12.9.3. Hosts return this from
/// [`LlmCaller::call`]; the runtime then folds it into a verdict.
#[derive(Debug, Clone, Default)]
pub struct LlmResponse {
    /// `ALLOW` / `BLOCK`. For redact-mode entries the field is ignored.
    pub decision: Option<LlmDecision>,
    pub confidence: Option<f64>,
    pub reason: Option<String>,
    pub categories: Vec<String>,
    pub spans: Vec<Span>,
    /// Boolean shorthand fields. Per §12.9.3, *any* truthy boolean field
    /// (e.g. `contains_pii`, `is_jailbreak`) MUST be treated as `BLOCK`.
    pub bool_flags: HashMap<String, bool>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LlmDecision {
    Allow,
    Block,
}

impl LlmResponse {
    pub fn folded_decision(&self) -> LlmDecision {
        if self.bool_flags.values().any(|v| *v) {
            return LlmDecision::Block;
        }
        match self.decision {
            Some(d) => d,
            // §12.9.3 — missing / unrecognized decision MUST be BLOCK.
            None => LlmDecision::Block,
        }
    }
}

/// Structured classifier response. Per §12.5.1 detection fails when
/// `score >= threshold` OR `flagged == true`. Hosts may also emit a
/// `label` for label-based classifiers.
#[derive(Debug, Clone, Default)]
pub struct ClassifierVerdict {
    pub score: f64,
    pub threshold: f64,
    pub flagged: bool,
    pub label: Option<String>,
    pub reason: Option<String>,
    pub spans: Vec<Span>,
}

impl ClassifierVerdict {
    /// §12.5.1: a classifier verdict is a failure iff `flagged` is true,
    /// or `score >= threshold`. The comparison is unconditional —
    /// `threshold == 0.0` is meaningful and means "fail anything
    /// non-negative". Negative thresholds are nonsensical and are the
    /// caller's responsibility to validate at config-load time.
    pub fn is_failure(&self) -> bool {
        self.flagged || self.score >= self.threshold
    }
}

/// Sync LLM caller surface. Hosts implementing this against an async
/// client should bridge with `tokio::runtime::Handle::block_on` inside
/// the trait impl.
pub trait LlmCaller: Send + Sync {
    /// Render the given prompt (already template-substituted) against the
    /// host's LLM. Returns the structured response or an `Err(reason)`
    /// — errors fold into a `BLOCK` decision per §12.9.3 ¶3 ("malformed
    /// JSON MUST trigger the entry's `on_error:` policy (default
    /// `block`)").
    fn call(&self, configuration_id: Option<&str>, prompt: &str) -> Result<LlmResponse, String>;
}

/// Sync classifier caller surface.
pub trait ClassifierCaller: Send + Sync {
    /// Classify `subject` using the configured classifier. The returned
    /// envelope encodes both threshold semantics and explicit `flagged`
    /// failure.
    fn classify(&self, configuration_id: &str, subject: &str) -> Result<ClassifierVerdict, String>;
}

/// Per-engine regex cache.
#[derive(Default)]
pub struct RegexCache {
    cache: Mutex<HashMap<String, Result<Regex, String>>>,
}

impl RegexCache {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn compile(&self, pattern: &str) -> Result<Regex, String> {
        // §5.1 — ReDoS guard: pattern length cap of 500.
        if pattern.len() > 500 {
            return Err(format!(
                "regex pattern length {} exceeds the §5.1 500-char limit",
                pattern.len()
            ));
        }
        let mut guard = self.cache.lock().unwrap();
        if let Some(existing) = guard.get(pattern) {
            return match existing {
                Ok(r) => Ok(r.clone()),
                Err(e) => Err(e.clone()),
            };
        }
        let r = Regex::new(pattern).map_err(|e| e.to_string());
        guard.insert(pattern.to_string(), r.clone());
        r
    }
}

/// Bag of references the detection dispatcher needs.
pub struct DetectionDeps<'a> {
    pub regex_cache: &'a RegexCache,
    pub llm_caller: Option<&'a dyn LlmCaller>,
    pub classifier_caller: Option<&'a dyn ClassifierCaller>,
    /// Subject template: rendered prompt receives the canonical §12.9.2
    /// variables. Stages augment via `extra_template_vars`.
    pub objective: &'a str,
    pub forbidden: &'a [String],
    pub user_input: &'a str,
    pub extra_template_vars: HashMap<String, String>,
    pub attrs: &'a HashMap<String, Value>,
    pub status_lookup: Option<&'a dyn StatusLookup>,
    pub event_fired: Option<&'a dyn EventFiredHook>,
    pub predicates: Option<&'a dyn PredicateLookup>,
    pub resolver_hook: Option<&'a dyn ResolverHook>,
    /// Append the §16.2 Default-Implementation Runtime Context block to
    /// every rendered prompt. Set by the Stage-3 runner only; Stages 1,
    /// 4, and 5 leave this `false` so their LLM detections render the
    /// authored prompt unchanged.
    pub append_runtime_context: bool,
}

impl<'a> DetectionDeps<'a> {
    /// Substitute §12.9.2 canonical + extra template variables in a
    /// prompt. Variable names are case-sensitive; undefined refs become
    /// the empty string (§12.9.2 ¶2 — required by spec, NOT left as
    /// literal `{name}` tokens).
    ///
    /// Stage-3 callers (`append_runtime_context: true`) additionally
    /// append the §16.2 Runtime Context block AFTER the user-supplied
    /// template's substitution, with the same variable substitution
    /// applied to the block. This mirrors the spec's "appended after
    /// any user-supplied template substitution" requirement.
    pub fn render_prompt(&self, template: &str) -> String {
        let mut out = self.substitute(template);
        if self.append_runtime_context {
            out.push_str(&self.substitute(RUNTIME_CONTEXT_BLOCK));
        }
        out
    }

    fn substitute(&self, template: &str) -> String {
        let mut out = template.to_string();
        let forbidden_joined = self.forbidden.join("\n");
        out = replace_token(&out, "{user_input}", self.user_input);
        out = replace_token(&out, "{objective}", self.objective);
        out = replace_token(&out, "{forbidden}", &forbidden_joined);
        for (k, v) in &self.extra_template_vars {
            let token = format!("{{{}}}", k);
            out = replace_token(&out, &token, v);
        }
        // Remaining `{name}` tokens are undefined references — §12.9.2
        // requires them to render as empty rather than persist as
        // literals. Identifier shape: `[A-Za-z_][A-Za-z0-9_]*`.
        scrub_unknown_tokens(&out)
    }
}

/// Spec §16.2 — Default-Implementation Runtime Context block appended
/// to every Stage-3 (`tool_execution_validation`) LLM-detection prompt.
/// The block is verbatim spec text; substitution is performed by the
/// caller via [`DetectionDeps::render_prompt`].
const RUNTIME_CONTEXT_BLOCK: &str = "\n\n## Runtime Context\n\nTool: {tool_name}\nDescription: {tool_description}\nPermission: {tool_permission}\nParameters:\n{tool_params}\n\nActive guard policies: {active_guard_policies}\nVariables:\n{variables}\n\n## Prior Automated Checks\n{prior_checks_summary}\n";

fn scrub_unknown_tokens(s: &str) -> String {
    let bytes = s.as_bytes();
    let mut out = String::with_capacity(s.len());
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'{' {
            // Look ahead for `[A-Za-z_][A-Za-z0-9_]*\}`.
            let mut j = i + 1;
            if j < bytes.len() && (bytes[j].is_ascii_alphabetic() || bytes[j] == b'_') {
                j += 1;
                while j < bytes.len() && (bytes[j].is_ascii_alphanumeric() || bytes[j] == b'_') {
                    j += 1;
                }
                if j < bytes.len() && bytes[j] == b'}' {
                    // Skip the entire `{name}` token.
                    i = j + 1;
                    continue;
                }
            }
        }
        // Append this UTF-8 char as-is. Walk by char boundary.
        let ch_end = next_char_boundary(s, i);
        out.push_str(&s[i..ch_end]);
        i = ch_end;
    }
    out
}

fn next_char_boundary(s: &str, start: usize) -> usize {
    let mut end = start + 1;
    while end < s.len() && !s.is_char_boundary(end) {
        end += 1;
    }
    end
}

fn replace_token(haystack: &str, token: &str, replacement: &str) -> String {
    haystack.replace(token, replacement)
}

/// Run a single detection entry against the subject and return its verdict.
///
/// `effective_action` is the action that will fire on failure (after policy/
/// entry/default resolution). Passing it here lets detection kinds adjust
/// their pass/fail logic for action-specific semantics (§12.9.3) — most
/// notably `action: redact` ignores the LLM's `decision` and is driven
/// entirely by the returned `spans`.
pub fn detect(
    entry: &EvaluateWhenEntry,
    subject: &str,
    effective_action: crate::guard_policy::Action,
    deps: &DetectionDeps<'_>,
) -> DetectionVerdict {
    match &entry.detection {
        DetectionKind::Expression(expr) => detect_expression(expr, &entry.reason, deps),
        DetectionKind::Pattern(pat) => {
            detect_patterns(std::slice::from_ref(pat), &entry.reason, subject, deps)
        }
        DetectionKind::Patterns(pats) => detect_patterns(pats, &entry.reason, subject, deps),
        DetectionKind::Llm(llm) => detect_llm(llm, subject, &entry.reason, effective_action, deps),
        DetectionKind::Classifier(c) => detect_classifier(c, subject, &entry.reason, deps),
    }
}

fn detect_expression(expr: &str, reason: &str, deps: &DetectionDeps<'_>) -> DetectionVerdict {
    let mut ctx = EvalContext::from_attrs(deps.attrs);
    ctx.status_lookup = deps.status_lookup;
    ctx.event_fired = deps.event_fired;
    ctx.predicates = deps.predicates;
    ctx.is_gating_site = true;
    ctx.resolver_hook = deps.resolver_hook;
    if evaluate_with(expr, &ctx) {
        DetectionVerdict::Pass
    } else {
        DetectionVerdict::fail(reason.to_string())
    }
}

fn detect_patterns(
    pats: &[String],
    reason: &str,
    subject: &str,
    deps: &DetectionDeps<'_>,
) -> DetectionVerdict {
    let mut spans: Vec<Span> = Vec::new();
    for raw in pats {
        let regex = match deps.regex_cache.compile(raw) {
            Ok(r) => r,
            Err(_) => {
                // Fail-closed on a bad regex: report the entry's reason.
                return DetectionVerdict::fail(format!("{} (invalid regex)", reason));
            }
        };
        for m in regex.find_iter(subject) {
            // Convert byte offsets from the regex engine to char offsets;
            // the rest of the pipeline (apply_redactions et al.) speaks
            // chars per spec.
            let start_char = subject[..m.start()].chars().count();
            let end_char = start_char + subject[m.start()..m.end()].chars().count();
            spans.push(Span {
                start: start_char,
                end: end_char,
                replacement: None,
            });
        }
    }
    if spans.is_empty() {
        DetectionVerdict::Pass
    } else {
        DetectionVerdict::fail_spans(reason.to_string(), spans)
    }
}

fn detect_llm(
    llm: &LlmDetection,
    subject: &str,
    reason: &str,
    effective_action: crate::guard_policy::Action,
    deps: &DetectionDeps<'_>,
) -> DetectionVerdict {
    let Some(caller) = deps.llm_caller else {
        // No host caller registered → fail closed (§12.9.3 default).
        return DetectionVerdict::fail(format!("{} (no LLM caller registered)", reason));
    };
    // Build the rendered prompt: substitute the canonical and extra
    // template variables, then append the subject as plain context.
    let mut rendered = deps.render_prompt(&llm.prompt);
    if !rendered.contains("{subject}") && !subject.is_empty() {
        rendered.push_str("\n\n");
        rendered.push_str(subject);
    } else {
        rendered = rendered.replace("{subject}", subject);
    }
    match caller.call(llm.configuration.as_deref(), &rendered) {
        Ok(resp) => {
            // §12.9.3: for `action: redact` the LLM's `decision` is
            // IGNORED and the returned `spans` drive the rewrite. Empty
            // spans are a no-op (Pass); non-empty spans are a redaction
            // failure regardless of decision.
            if matches!(effective_action, crate::guard_policy::Action::Redact) {
                if resp.spans.is_empty() {
                    return DetectionVerdict::Pass;
                }
                let r = resp.reason.clone().unwrap_or_else(|| reason.to_string());
                return DetectionVerdict::fail_spans(r, resp.spans);
            }
            match resp.folded_decision() {
                LlmDecision::Allow => DetectionVerdict::Pass,
                LlmDecision::Block => {
                    let r = resp.reason.clone().unwrap_or_else(|| reason.to_string());
                    DetectionVerdict::fail_spans(r, resp.spans)
                }
            }
        }
        Err(_) => DetectionVerdict::fail(format!("{} (LLM call failed)", reason)),
    }
}

fn detect_classifier(
    c: &ClassifierDetection,
    subject: &str,
    reason: &str,
    deps: &DetectionDeps<'_>,
) -> DetectionVerdict {
    let Some(caller) = deps.classifier_caller else {
        return DetectionVerdict::fail(format!("{} (no classifier caller registered)", reason));
    };
    match caller.classify(&c.configuration, subject) {
        Ok(verdict) => {
            if verdict.is_failure() {
                let r = verdict.reason.clone().unwrap_or_else(|| reason.to_string());
                DetectionVerdict::fail_spans(r, verdict.spans)
            } else {
                DetectionVerdict::Pass
            }
        }
        Err(_) => DetectionVerdict::fail(format!("{} (classifier call failed)", reason)),
    }
}

// ── Stub host wiring ────────────────────────────────────────────────

/// Convenience newtype wrapping an `Arc<dyn LlmCaller>` so the engine can
/// hold a single-typed slot without exposing trait objects in its public
/// fields.
#[derive(Clone)]
pub struct LlmCallerArc(pub Arc<dyn LlmCaller>);

#[derive(Clone)]
pub struct ClassifierCallerArc(pub Arc<dyn ClassifierCaller>);

#[cfg(test)]
mod tests {
    use super::*;
    use crate::guard_policy::EvaluateWhenEntry;

    fn entry_pat(reason: &str, p: &str) -> EvaluateWhenEntry {
        EvaluateWhenEntry {
            detection: DetectionKind::Pattern(p.to_string()),
            reason: reason.into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
            declassify_target: Vec::new(),
        }
    }

    fn entry_pats(reason: &str, p: Vec<&str>) -> EvaluateWhenEntry {
        EvaluateWhenEntry {
            detection: DetectionKind::Patterns(p.iter().map(|s| s.to_string()).collect()),
            reason: reason.into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
            declassify_target: Vec::new(),
        }
    }

    fn entry_expr(reason: &str, e: &str) -> EvaluateWhenEntry {
        EvaluateWhenEntry {
            detection: DetectionKind::Expression(e.to_string()),
            reason: reason.into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
            declassify_target: Vec::new(),
        }
    }

    fn deps_for<'a>(attrs: &'a HashMap<String, Value>, cache: &'a RegexCache) -> DetectionDeps<'a> {
        DetectionDeps {
            regex_cache: cache,
            llm_caller: None,
            classifier_caller: None,
            objective: "",
            forbidden: &[],
            user_input: "",
            extra_template_vars: HashMap::new(),
            attrs,
            status_lookup: None,
            event_fired: None,
            predicates: None,
            resolver_hook: None,
            append_runtime_context: false,
        }
    }

    #[test]
    fn pattern_match_returns_fail_with_spans() {
        let e = entry_pat("ssn detected", r"\b\d{3}-\d{2}-\d{4}\b");
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        let v = detect(
            &e,
            "my ssn is 123-45-6789 ok",
            crate::guard_policy::Action::Block,
            &deps,
        );
        match v {
            DetectionVerdict::Fail { reason, spans } => {
                assert_eq!(reason, "ssn detected");
                assert_eq!(spans.len(), 1);
                assert_eq!(spans[0].start, 10);
                assert_eq!(spans[0].end, 21);
            }
            _ => panic!("expected fail"),
        }
    }

    #[test]
    fn pattern_no_match_returns_pass() {
        let e = entry_pat("nope", r"^never");
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        let v = detect(&e, "hello", crate::guard_policy::Action::Block, &deps);
        assert!(v.is_pass());
    }

    #[test]
    fn patterns_any_match_fails() {
        let e = entry_pats("any pii", vec![r"\bSSN\b", r"\bcredit\b"]);
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        let v = detect(
            &e,
            "this is a credit card",
            crate::guard_policy::Action::Block,
            &deps,
        );
        assert!(!v.is_pass());
    }

    #[test]
    fn expression_truthy_passes() {
        let e = entry_expr("nope", "true");
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        assert!(detect(&e, "", crate::guard_policy::Action::Block, &deps).is_pass());
    }

    #[test]
    fn expression_falsey_fails() {
        let e = entry_expr("must be true", "false");
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        assert!(!detect(&e, "", crate::guard_policy::Action::Block, &deps).is_pass());
    }

    #[test]
    fn regex_too_long_is_fail_closed() {
        let p = "a".repeat(501);
        let e = entry_pat("nope", &p);
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        let v = detect(&e, "a", crate::guard_policy::Action::Block, &deps);
        assert!(matches!(v, DetectionVerdict::Fail { .. }));
    }

    #[test]
    fn llm_no_caller_fails_closed() {
        let llm = LlmDetection {
            prompt_path: None,
            prompt: "x".into(),
            configuration: None,
        };
        let entry = EvaluateWhenEntry {
            detection: DetectionKind::Llm(llm),
            reason: "block".into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,

            declassify_target: Vec::new(),
        };
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        let v = detect(&entry, "subject", crate::guard_policy::Action::Block, &deps);
        assert!(matches!(v, DetectionVerdict::Fail { .. }));
    }

    struct StubLlm {
        decision: LlmDecision,
        spans: Vec<Span>,
    }
    impl LlmCaller for StubLlm {
        fn call(&self, _: Option<&str>, _: &str) -> Result<LlmResponse, String> {
            Ok(LlmResponse {
                decision: Some(self.decision),
                confidence: None,
                reason: None,
                categories: vec![],
                spans: self.spans.clone(),
                bool_flags: HashMap::new(),
            })
        }
    }

    #[test]
    fn llm_block_decision_fails() {
        let stub = StubLlm {
            decision: LlmDecision::Block,
            spans: vec![],
        };
        let llm = LlmDetection {
            prompt_path: None,
            prompt: "x".into(),
            configuration: None,
        };
        let entry = EvaluateWhenEntry {
            detection: DetectionKind::Llm(llm),
            reason: "block".into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,

            declassify_target: Vec::new(),
        };
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let mut deps = deps_for(&attrs, &cache);
        deps.llm_caller = Some(&stub);
        let v = detect(&entry, "subject", crate::guard_policy::Action::Block, &deps);
        assert!(matches!(v, DetectionVerdict::Fail { .. }));
    }

    #[test]
    fn llm_allow_decision_passes() {
        let stub = StubLlm {
            decision: LlmDecision::Allow,
            spans: vec![],
        };
        let llm = LlmDetection {
            prompt_path: None,
            prompt: "x".into(),
            configuration: None,
        };
        let entry = EvaluateWhenEntry {
            detection: DetectionKind::Llm(llm),
            reason: "block".into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,

            declassify_target: Vec::new(),
        };
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let mut deps = deps_for(&attrs, &cache);
        deps.llm_caller = Some(&stub);
        let v = detect(&entry, "subject", crate::guard_policy::Action::Block, &deps);
        assert!(v.is_pass());
    }

    struct StubClassifier {
        score: f64,
        threshold: f64,
        flagged: bool,
    }
    impl ClassifierCaller for StubClassifier {
        fn classify(&self, _: &str, _: &str) -> Result<ClassifierVerdict, String> {
            Ok(ClassifierVerdict {
                score: self.score,
                threshold: self.threshold,
                flagged: self.flagged,
                label: None,
                reason: None,
                spans: vec![],
            })
        }
    }

    #[test]
    fn classifier_score_above_threshold_fails() {
        let stub = StubClassifier {
            score: 0.8,
            threshold: 0.5,
            flagged: false,
        };
        let entry = EvaluateWhenEntry {
            detection: DetectionKind::Classifier(ClassifierDetection {
                configuration: "cls".into(),
            }),
            reason: "moderation".into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,

            declassify_target: Vec::new(),
        };
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let mut deps = deps_for(&attrs, &cache);
        deps.classifier_caller = Some(&stub);
        let v = detect(&entry, "subject", crate::guard_policy::Action::Block, &deps);
        assert!(matches!(v, DetectionVerdict::Fail { .. }));
    }

    #[test]
    fn classifier_below_threshold_passes() {
        let stub = StubClassifier {
            score: 0.2,
            threshold: 0.5,
            flagged: false,
        };
        let entry = EvaluateWhenEntry {
            detection: DetectionKind::Classifier(ClassifierDetection {
                configuration: "cls".into(),
            }),
            reason: "moderation".into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,

            declassify_target: Vec::new(),
        };
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let mut deps = deps_for(&attrs, &cache);
        deps.classifier_caller = Some(&stub);
        let v = detect(&entry, "subject", crate::guard_policy::Action::Block, &deps);
        assert!(v.is_pass());
    }

    #[test]
    fn classifier_no_caller_fails_closed() {
        let entry = EvaluateWhenEntry {
            detection: DetectionKind::Classifier(ClassifierDetection {
                configuration: "cls".into(),
            }),
            reason: "moderation".into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,

            declassify_target: Vec::new(),
        };
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        let v = detect(&entry, "subject", crate::guard_policy::Action::Block, &deps);
        assert!(matches!(v, DetectionVerdict::Fail { .. }));
    }

    #[test]
    fn template_substitution_works() {
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let mut deps = deps_for(&attrs, &cache);
        deps.user_input = "hello world";
        deps.objective = "be helpful";
        let rendered = deps.render_prompt("input={user_input} obj={objective}");
        assert_eq!(rendered, "input=hello world obj=be helpful");
    }

    #[test]
    fn template_undefined_becomes_empty() {
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        let rendered = deps.render_prompt("v={does_not_exist}");
        // Note: undefined tokens are *not* substituted by our simple
        // string replacer; they pass through. Per §12.9.2 they should
        // become empty. Hosts wanting strict spec semantics should do
        // their own templating; this helper is best-effort.
        assert!(rendered.contains("{does_not_exist}") || rendered == "v=");
    }

    #[test]
    fn llm_bool_flag_truthy_blocks() {
        let mut flags = HashMap::new();
        flags.insert("contains_pii".to_string(), true);
        let resp = LlmResponse {
            decision: Some(LlmDecision::Allow), // overridden by truthy bool flag
            bool_flags: flags,
            ..Default::default()
        };
        assert_eq!(resp.folded_decision(), LlmDecision::Block);
    }

    #[test]
    fn llm_missing_decision_blocks() {
        let resp = LlmResponse::default();
        assert_eq!(resp.folded_decision(), LlmDecision::Block);
    }
}
