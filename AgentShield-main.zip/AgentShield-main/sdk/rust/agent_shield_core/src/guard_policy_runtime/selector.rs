//! `applies_to:` matching (§12.3, §13.4).
//!
//! Selectors are explicit name lists for tools and agents and pattern lists
//! for endpoints. Within a single guard policy the three lists are OR-joined
//! per §12.3. When more than one guard policy could match a given resource,
//! the runtime evaluates them in declaration order per §12.10. Specificity
//! tie-breaking from §13.4 only matters for **endpoint** matching when a
//! single guard policy carries multiple endpoint patterns; the most
//! specific wins.

use crate::guard_policy::{AppliesTo, EndpointSelector};
use crate::populator::pattern_matches_uri;

/// What kind of resource the runtime is gating right now.
#[derive(Debug, Clone)]
pub enum SelectorSubject<'a> {
    Tool {
        name: &'a str,
    },
    Agent {
        name: &'a str,
    },
    Endpoint {
        method: &'a str,
        uri: &'a str,
    },
    /// Stages 1 and 5 don't bind to a resource. `applies_to:` is rejected
    /// at load there, so the matcher always returns `true`.
    None,
}

/// Test whether `applies_to` matches `subject`. When `applies_to` is
/// `None` (the field was omitted), the guard policy applies to **all**
/// resources for the stage — Stage 3 / Stage 4 default behavior per §12.3.1.
pub fn applies_to_matches(applies_to: Option<&AppliesTo>, subject: &SelectorSubject<'_>) -> bool {
    let Some(at) = applies_to else {
        return true;
    };
    if at.is_empty() {
        return true;
    }
    match subject {
        SelectorSubject::Tool { name } => match_tool(&at.tools, name),
        SelectorSubject::Agent { name } => match_agent(&at.agents, name),
        SelectorSubject::Endpoint { method, uri } => match_endpoint(&at.endpoints, method, uri),
        SelectorSubject::None => false,
    }
}

fn match_tool(tools: &[String], name: &str) -> bool {
    tools.iter().any(|t| t == "*" || t == name)
}

fn match_agent(agents: &[String], name: &str) -> bool {
    agents.iter().any(|a| a == "*" || a == name)
}

fn match_endpoint(endpoints: &[EndpointSelector], method: &str, uri: &str) -> bool {
    // For the OR-test we only need *any* endpoint to match. Specificity
    // tie-breaking is handled by [`pick_best_endpoint`] when callers care
    // about which entry won.
    endpoints.iter().any(|e| endpoint_matches(e, method, uri))
}

fn endpoint_matches(sel: &EndpointSelector, method: &str, uri: &str) -> bool {
    if !sel.methods.is_empty()
        && !sel
            .methods
            .iter()
            .any(|m| m == "*" || m.eq_ignore_ascii_case(method))
    {
        return false;
    }
    pattern_matches_uri(&sel.pattern, uri)
}

/// §13.4 pattern mode (exact > parameterized > glob).
fn pattern_mode(pattern: &str) -> u8 {
    if pattern.contains("**") {
        0 // glob
    } else if pattern.contains('{') && pattern.contains('}') {
        1 // parameterized
    } else {
        2 // exact
    }
}

/// §13.4 specificity = literal segments − parameter segments.
fn specificity(pattern: &str) -> i32 {
    let mut literals = 0i32;
    let mut params = 0i32;
    for seg in pattern.trim_start_matches('/').split('/') {
        if seg == "**" {
            // glob is its own bucket; don't count
        } else if seg.starts_with('{') && seg.ends_with('}') {
            params += 1;
        } else if !seg.is_empty() {
            literals += 1;
        }
    }
    literals - params
}

/// §13.4 method-exact wins over `["*"]`.
fn method_specificity(methods: &[String]) -> u8 {
    if methods.iter().any(|m| m == "*") && methods.len() == 1 {
        0
    } else {
        1
    }
}

/// Pick the most specific matching endpoint inside an `applies_to:` block.
/// Returns its index. Uses (mode, specificity, method-specificity, declared
/// order) tuple ordering per §13.4.
pub fn pick_best_endpoint(
    endpoints: &[EndpointSelector],
    method: &str,
    uri: &str,
) -> Option<usize> {
    endpoints
        .iter()
        .enumerate()
        .filter(|(_, e)| endpoint_matches(e, method, uri))
        .max_by_key(|(idx, e)| {
            (
                pattern_mode(&e.pattern),
                specificity(&e.pattern),
                method_specificity(&e.methods),
                // declared order: earlier wins on tie ⇒ negate index
                -(*idx as i64),
            )
        })
        .map(|(i, _)| i)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn at_tool(t: &str) -> AppliesTo {
        AppliesTo {
            tools: vec![t.into()],
            ..Default::default()
        }
    }
    fn at_agent(a: &str) -> AppliesTo {
        AppliesTo {
            agents: vec![a.into()],
            ..Default::default()
        }
    }
    fn at_endpoint(p: &str, methods: &[&str]) -> AppliesTo {
        AppliesTo {
            endpoints: vec![EndpointSelector {
                pattern: p.into(),
                methods: methods.iter().map(|s| s.to_string()).collect(),
            }],
            ..Default::default()
        }
    }

    #[test]
    fn tool_exact_match() {
        let at = at_tool("send_email");
        assert!(applies_to_matches(
            Some(&at),
            &SelectorSubject::Tool { name: "send_email" }
        ));
        assert!(!applies_to_matches(
            Some(&at),
            &SelectorSubject::Tool { name: "send_other" }
        ));
    }

    #[test]
    fn tool_wildcard_match() {
        let at = at_tool("*");
        assert!(applies_to_matches(
            Some(&at),
            &SelectorSubject::Tool { name: "anything" }
        ));
    }

    #[test]
    fn agent_match() {
        let at = at_agent("fraud_agent");
        assert!(applies_to_matches(
            Some(&at),
            &SelectorSubject::Agent {
                name: "fraud_agent"
            }
        ));
        assert!(!applies_to_matches(
            Some(&at),
            &SelectorSubject::Tool {
                name: "fraud_agent"
            }
        ));
    }

    #[test]
    fn endpoint_pattern_match() {
        let at = at_endpoint("/api/v1/users/{id}", &["GET", "POST"]);
        assert!(applies_to_matches(
            Some(&at),
            &SelectorSubject::Endpoint {
                method: "GET",
                uri: "/api/v1/users/42"
            }
        ));
        assert!(!applies_to_matches(
            Some(&at),
            &SelectorSubject::Endpoint {
                method: "DELETE",
                uri: "/api/v1/users/42"
            }
        ));
    }

    #[test]
    fn endpoint_method_wildcard() {
        let at = at_endpoint("/api/v1/external/**", &["*"]);
        assert!(applies_to_matches(
            Some(&at),
            &SelectorSubject::Endpoint {
                method: "DELETE",
                uri: "/api/v1/external/foo/bar"
            }
        ));
    }

    #[test]
    fn omitted_applies_to_matches_anything() {
        assert!(applies_to_matches(
            None,
            &SelectorSubject::Tool { name: "x" }
        ));
    }

    #[test]
    fn empty_applies_to_matches_anything() {
        let at = AppliesTo::default();
        assert!(applies_to_matches(
            Some(&at),
            &SelectorSubject::Tool { name: "x" }
        ));
    }

    #[test]
    fn endpoint_specificity_exact_beats_param() {
        let endpoints = vec![
            EndpointSelector {
                pattern: "/api/v1/users/{id}".into(),
                methods: vec!["GET".into()],
            },
            EndpointSelector {
                pattern: "/api/v1/users/me".into(),
                methods: vec!["GET".into()],
            },
        ];
        let pick = pick_best_endpoint(&endpoints, "GET", "/api/v1/users/me");
        assert_eq!(pick, Some(1));
    }

    #[test]
    fn endpoint_specificity_param_beats_glob() {
        let endpoints = vec![
            EndpointSelector {
                pattern: "/api/v1/**".into(),
                methods: vec!["*".into()],
            },
            EndpointSelector {
                pattern: "/api/v1/users/{id}".into(),
                methods: vec!["GET".into()],
            },
        ];
        let pick = pick_best_endpoint(&endpoints, "GET", "/api/v1/users/42");
        assert_eq!(pick, Some(1));
    }

    #[test]
    fn endpoint_method_exact_beats_wildcard() {
        let endpoints = vec![
            EndpointSelector {
                pattern: "/api/v1/users/me".into(),
                methods: vec!["*".into()],
            },
            EndpointSelector {
                pattern: "/api/v1/users/me".into(),
                methods: vec!["GET".into()],
            },
        ];
        let pick = pick_best_endpoint(&endpoints, "GET", "/api/v1/users/me");
        assert_eq!(pick, Some(1));
    }

    #[test]
    fn endpoint_tie_break_first_wins() {
        let endpoints = vec![
            EndpointSelector {
                pattern: "/api/v1/users/{id}".into(),
                methods: vec!["GET".into()],
            },
            EndpointSelector {
                pattern: "/api/v1/users/{id}".into(),
                methods: vec!["GET".into()],
            },
        ];
        let pick = pick_best_endpoint(&endpoints, "GET", "/api/v1/users/42");
        // declared-first wins on equal specificity (§13.4)
        assert_eq!(pick, Some(0));
    }
}
