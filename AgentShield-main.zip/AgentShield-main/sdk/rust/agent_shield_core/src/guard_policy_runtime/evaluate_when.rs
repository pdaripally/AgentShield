//! `evaluate_when[]` runner (§12.5 / §12.10).
//!
//! Walks the entries in declaration order and produces the aggregated
//! state needed to apply transforms or report a block. Per §12.10 step 3:
//!
//! - For each entry: run detection.
//! - On failure, evaluate `allowed_when:` once and suppress the failure
//!   if it's truthy.
//! - Block short-circuits subsequent entries; warn / redact / append /
//!   prepend record their effects and continue.
//! - Block wins: if any block fired, all redactions and transforms are
//!   discarded.

use std::collections::HashMap;

use serde_json::Value;

use crate::expressions::eval::{EventFiredHook, PredicateLookup, ResolverHook, StatusLookup};
use crate::guard_policy::{Action, EvaluateWhenEntry, GuardPolicy};

use super::allowed_when::evaluate_allowed_when;
use super::detection::{detect, DetectionDeps, DetectionVerdict, Span};

/// Aggregated state produced by walking `evaluate_when[]` for a single
/// guard policy.
#[derive(Debug, Default)]
pub struct EvaluationOutcome {
    /// Set when a `block`-action entry fired (and was not bypassed). The
    /// failing entry's index plus the resolved `reason:` go in here.
    pub block: Option<BlockedEntry>,
    /// Warn entries that fired (one per failed warn).
    pub warns: Vec<TriggeredEntry>,
    /// Redaction spans collected from `pattern` / `patterns` / `llm` /
    /// `classifier` failures with `action: redact`. Each tuple carries
    /// `(span, replacement)` ready for [`super::action::apply_redactions`].
    pub redactions: Vec<(Span, String)>,
    /// Same redactions correlated with the originating `evaluate_when[]`
    /// entry index. Stage 3 uses this so LLM/classifier spans can be
    /// applied to the entry's declared `paths:` (§12.10 / §16.3) instead
    /// of being silently dropped.
    pub redactions_by_entry: Vec<(usize, Vec<(Span, String)>)>,
    /// `(text, paths, entry_index)` — Stage-3 transforms target dotted
    /// paths inside the parameter object. For Stages 4 & 5 `paths` is
    /// empty and the text applies to the whole subject.
    pub appends: Vec<TransformText>,
    pub prepends: Vec<TransformText>,
    /// Declassification targets emitted by `action: declassify_to`
    /// entries that fired. Last-wins is applied at the consuming
    /// stage runner (each declassifier should be deliberate;
    /// combining intentions is sketchy). Tag names; resolved to
    /// `TagSet` by the consuming runtime.
    pub declassifications: Vec<Vec<String>>,
    /// At least one entry's failure was suppressed by `allowed_when:`.
    pub allowed_when_bypass_fired: bool,
    /// Entry index ⇒ failed but was bypassed. Useful for logging.
    pub bypassed_entries: Vec<usize>,
    /// True if at least one entry failed (bypassed or not).
    pub any_failed: bool,
}

#[derive(Debug, Clone)]
pub struct BlockedEntry {
    pub entry_index: usize,
    pub reason: String,
}

#[derive(Debug, Clone)]
pub struct TriggeredEntry {
    pub entry_index: usize,
    pub reason: String,
}

#[derive(Debug, Clone)]
pub struct TransformText {
    pub entry_index: usize,
    pub text: String,
    pub paths: Vec<String>,
}

/// Resolve the effective action for a failing entry per §12.7:
/// 1. The entry's `action:` if declared.
/// 2. Otherwise the guard policy's top-level `action:`.
/// 3. Otherwise `block` (the fail-closed default).
pub fn effective_action(entry: &EvaluateWhenEntry, policy: &GuardPolicy) -> Action {
    entry.action.or(policy.action).unwrap_or(Action::Block)
}

/// Resolve the effective replacement for a redact entry — entry first,
/// then guard-policy-level. Returns `""` as the implementation default
/// when neither is set; callers SHOULD pre-validate at load.
pub fn effective_replacement(entry: &EvaluateWhenEntry, policy: &GuardPolicy) -> String {
    entry
        .replacement
        .clone()
        .or_else(|| policy.replacement.clone())
        .unwrap_or_else(|| "[REDACTED]".to_string())
}

/// Bag of references the runner needs in addition to [`DetectionDeps`].
pub struct AllowedWhenDeps<'a> {
    pub attrs: &'a HashMap<String, Value>,
    pub status_lookup: Option<&'a dyn StatusLookup>,
    pub event_fired: Option<&'a dyn EventFiredHook>,
    pub predicates: Option<&'a dyn PredicateLookup>,
    pub resolver_hook: Option<&'a dyn ResolverHook>,
}

/// Walk `evaluate_when[]` for one guard policy. The empty-list "always
/// block when active" form is handled by the caller — this function
/// simply returns an empty outcome for empty input.
pub fn run_evaluate_when(
    policy: &GuardPolicy,
    subject: &str,
    detection_deps: &DetectionDeps<'_>,
    allowed_when_deps: &AllowedWhenDeps<'_>,
) -> EvaluationOutcome {
    let mut outcome = EvaluationOutcome::default();
    let mut failed_indices: Vec<usize> = Vec::new();

    for (idx, entry) in policy.evaluate_when.iter().enumerate() {
        let action = effective_action(entry, policy);
        let v = detect(entry, subject, action, detection_deps);
        let DetectionVerdict::Fail { reason, spans } = v else {
            continue;
        };

        outcome.any_failed = true;
        failed_indices.push(idx);

        match action {
            Action::Block => {
                outcome.block = Some(BlockedEntry {
                    entry_index: idx,
                    reason,
                });
                // §12.10 step 3c: block short-circuits subsequent entries.
                break;
            }
            Action::Warn => {
                outcome.warns.push(TriggeredEntry {
                    entry_index: idx,
                    reason,
                });
            }
            Action::Redact => {
                let repl = effective_replacement(entry, policy);
                if spans.is_empty() {
                    // §12.9.3: redact-mode with no spans is a no-op.
                    continue;
                }
                let mut entry_spans: Vec<(Span, String)> = Vec::with_capacity(spans.len());
                for s in spans {
                    let r = s.replacement.clone().unwrap_or_else(|| repl.clone());
                    outcome.redactions.push((s.clone(), r.clone()));
                    entry_spans.push((s, r));
                }
                outcome.redactions_by_entry.push((idx, entry_spans));
            }
            Action::Append => {
                if let Some(text) = entry.text.clone() {
                    outcome.appends.push(TransformText {
                        entry_index: idx,
                        text,
                        paths: entry.paths.clone(),
                    });
                }
            }
            Action::Prepend => {
                if let Some(text) = entry.text.clone() {
                    outcome.prepends.push(TransformText {
                        entry_index: idx,
                        text,
                        paths: entry.paths.clone(),
                    });
                }
            }
            Action::DeclassifyTo => {
                outcome
                    .declassifications
                    .push(entry.declassify_target.clone());
            }
        }
    }

    // §12.12 — `allowed_when:` is the merged expression evaluated EXACTLY
    // once per policy invocation (not once per failing entry). Auto-
    // resolution side-effects on the variables it reads must therefore
    // not be amplified by the number of failures. Evaluate it once after
    // the entry loop, only if at least one entry actually failed.
    if outcome.any_failed
        && evaluate_allowed_when(
            policy.allowed_when.as_deref(),
            allowed_when_deps.attrs,
            allowed_when_deps.status_lookup,
            allowed_when_deps.event_fired,
            allowed_when_deps.predicates,
            allowed_when_deps.resolver_hook,
        )
    {
        outcome.allowed_when_bypass_fired = true;
        outcome.bypassed_entries = failed_indices;
        // The merged bypass suppresses every effect the failing entries
        // collected — block, warns, redactions, appends, prepends,
        // declassifications.
        outcome.block = None;
        outcome.warns.clear();
        outcome.redactions.clear();
        outcome.redactions_by_entry.clear();
        outcome.appends.clear();
        outcome.prepends.clear();
        outcome.declassifications.clear();
    }

    outcome
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::guard_policy::{DetectionKind, GuardPolicy};

    use super::super::detection::RegexCache;

    fn deps_attrs<'a>(
        attrs: &'a HashMap<String, Value>,
        cache: &'a RegexCache,
    ) -> (DetectionDeps<'a>, AllowedWhenDeps<'a>) {
        (
            DetectionDeps {
                regex_cache: cache,
                llm_caller: None,
                classifier_caller: None,
                objective: "",
                forbidden: &[],
                user_input: "",
                extra_template_vars: HashMap::new(),
                attrs,
                status_lookup: None,
                event_fired: None,
                predicates: None,
                resolver_hook: None,
                append_runtime_context: false,
            },
            AllowedWhenDeps {
                attrs,
                status_lookup: None,
                event_fired: None,
                predicates: None,
                resolver_hook: None,
            },
        )
    }

    fn policy_with_entries(name: &str, entries: Vec<EvaluateWhenEntry>) -> GuardPolicy {
        GuardPolicy {
            name: name.into(),
            description: None,
            applies_to: None,
            active_if: None,
            evaluate_when: entries,
            allowed_when: None,
            action: None,
            reason: None,
            replacement: None,
            log: None,
        }
    }

    fn entry(reason: &str, det: DetectionKind, action: Option<Action>) -> EvaluateWhenEntry {
        EvaluateWhenEntry {
            detection: det,
            reason: reason.into(),
            action,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
            declassify_target: Vec::new(),
        }
    }

    #[test]
    fn all_pass_yields_empty_outcome() {
        let p = policy_with_entries(
            "p",
            vec![entry("r", DetectionKind::Expression("true".into()), None)],
        );
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let (d, a) = deps_attrs(&attrs, &cache);
        let o = run_evaluate_when(&p, "", &d, &a);
        assert!(!o.any_failed);
        assert!(o.block.is_none());
    }

    #[test]
    fn first_block_short_circuits() {
        let mut p = policy_with_entries(
            "p",
            vec![
                entry(
                    "first",
                    DetectionKind::Expression("false".into()),
                    Some(Action::Block),
                ),
                entry(
                    "second",
                    DetectionKind::Expression("false".into()),
                    Some(Action::Block),
                ),
            ],
        );
        p.action = Some(Action::Block);
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let (d, a) = deps_attrs(&attrs, &cache);
        let o = run_evaluate_when(&p, "", &d, &a);
        assert!(o.block.is_some());
        assert_eq!(o.block.as_ref().unwrap().entry_index, 0);
        assert_eq!(o.block.as_ref().unwrap().reason, "first");
    }

    #[test]
    fn warn_entries_accumulate() {
        let p = policy_with_entries(
            "p",
            vec![
                entry(
                    "a",
                    DetectionKind::Expression("false".into()),
                    Some(Action::Warn),
                ),
                entry(
                    "b",
                    DetectionKind::Expression("false".into()),
                    Some(Action::Warn),
                ),
            ],
        );
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let (d, a) = deps_attrs(&attrs, &cache);
        let o = run_evaluate_when(&p, "", &d, &a);
        assert!(o.block.is_none());
        assert_eq!(o.warns.len(), 2);
    }

    #[test]
    fn allowed_when_bypass_suppresses() {
        let mut attrs = HashMap::new();
        attrs.insert("ok".into(), serde_json::json!(true));
        let mut p = policy_with_entries(
            "p",
            vec![entry(
                "a",
                DetectionKind::Expression("false".into()),
                Some(Action::Block),
            )],
        );
        p.allowed_when = Some("ok == true".into());
        let cache = RegexCache::new();
        let (d, a) = deps_attrs(&attrs, &cache);
        let o = run_evaluate_when(&p, "", &d, &a);
        assert!(o.block.is_none());
        assert!(o.allowed_when_bypass_fired);
        assert_eq!(o.bypassed_entries, vec![0]);
    }

    #[test]
    fn redact_entry_collects_spans() {
        let mut e = entry(
            "ssn",
            DetectionKind::Pattern(r"\d{3}-\d{2}-\d{4}".into()),
            Some(Action::Redact),
        );
        e.replacement = Some("[X]".into());
        let p = policy_with_entries("p", vec![e]);
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let (d, a) = deps_attrs(&attrs, &cache);
        let o = run_evaluate_when(&p, "ssn 123-45-6789 here", &d, &a);
        assert!(o.block.is_none());
        assert_eq!(o.redactions.len(), 1);
        assert_eq!(o.redactions[0].1, "[X]");
    }

    #[test]
    fn append_entry_collects_text() {
        let mut e = entry(
            "regulatory",
            DetectionKind::Expression("false".into()),
            Some(Action::Append),
        );
        e.text = Some("--disclaimer--".into());
        e.paths = vec!["tool.params.body".into()];
        let p = policy_with_entries("p", vec![e]);
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let (d, a) = deps_attrs(&attrs, &cache);
        let o = run_evaluate_when(&p, "", &d, &a);
        assert_eq!(o.appends.len(), 1);
        assert_eq!(o.appends[0].text, "--disclaimer--");
        assert_eq!(o.appends[0].paths, vec!["tool.params.body".to_string()]);
    }

    #[test]
    fn block_after_warn_keeps_block() {
        let p = policy_with_entries(
            "p",
            vec![
                entry(
                    "warned",
                    DetectionKind::Expression("false".into()),
                    Some(Action::Warn),
                ),
                entry(
                    "blocked",
                    DetectionKind::Expression("false".into()),
                    Some(Action::Block),
                ),
            ],
        );
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let (d, a) = deps_attrs(&attrs, &cache);
        let o = run_evaluate_when(&p, "", &d, &a);
        assert_eq!(o.warns.len(), 1);
        assert!(o.block.is_some());
        assert_eq!(o.block.as_ref().unwrap().reason, "blocked");
    }

    #[test]
    fn effective_action_default_is_block() {
        let e = entry("r", DetectionKind::Expression("true".into()), None);
        let p = policy_with_entries("p", vec![]);
        assert_eq!(effective_action(&e, &p), Action::Block);
    }

    #[test]
    fn effective_action_entry_overrides_policy() {
        let e = entry(
            "r",
            DetectionKind::Expression("true".into()),
            Some(Action::Warn),
        );
        let mut p = policy_with_entries("p", vec![]);
        p.action = Some(Action::Block);
        assert_eq!(effective_action(&e, &p), Action::Warn);
    }

    // P6.1 — `allowed_when:` is evaluated EXACTLY once per policy
    // invocation (§12.12), even when multiple `evaluate_when[]` entries
    // fail. Pre-fix the evaluator was called once per failing entry.
    struct CountingPredicates {
        calls: std::cell::RefCell<usize>,
        body: String,
    }

    impl crate::expressions::eval::PredicateLookup for CountingPredicates {
        fn body(&self, _name: &str) -> Option<&str> {
            *self.calls.borrow_mut() += 1;
            Some(&self.body)
        }
    }

    #[test]
    fn allowed_when_evaluated_once_per_policy_with_multiple_failures() {
        // Two failing warn entries (warns don't short-circuit). The
        // merged allowed_when must be evaluated exactly once. We probe
        // via a PredicateLookup whose body() is invoked on every
        // top-level evaluation.
        let p = {
            let mut p = policy_with_entries(
                "p",
                vec![
                    entry(
                        "first",
                        DetectionKind::Expression("false".into()),
                        Some(Action::Warn),
                    ),
                    entry(
                        "second",
                        DetectionKind::Expression("false".into()),
                        Some(Action::Warn),
                    ),
                ],
            );
            // allowed_when references a named predicate `gate`. The
            // PredicateLookup hook supplies its body and counts calls.
            p.allowed_when = Some("gate".into());
            p
        };

        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let counter = CountingPredicates {
            calls: std::cell::RefCell::new(0),
            body: "false".into(),
        };

        let detection_deps = DetectionDeps {
            regex_cache: &cache,
            llm_caller: None,
            classifier_caller: None,
            objective: "",
            forbidden: &[],
            user_input: "",
            extra_template_vars: HashMap::new(),
            attrs: &attrs,
            status_lookup: None,
            event_fired: None,
            predicates: None,
            resolver_hook: None,
            append_runtime_context: false,
        };
        let allowed_when_deps = AllowedWhenDeps {
            attrs: &attrs,
            status_lookup: None,
            event_fired: None,
            predicates: Some(&counter),
            resolver_hook: None,
        };
        let o = run_evaluate_when(&p, "", &detection_deps, &allowed_when_deps);
        assert!(o.any_failed);
        // allowed_when is "false" (does not bypass) — both warns survive.
        assert_eq!(o.warns.len(), 2);
        assert_eq!(
            *counter.calls.borrow(),
            1,
            "allowed_when must be evaluated exactly once per policy invocation"
        );
    }

    #[test]
    fn allowed_when_skipped_when_no_entries_fail() {
        // §12.12: allowed_when is only meaningful when an entry failed.
        // If all entries pass we must NOT evaluate it (and side-effect
        // its hooks).
        let p = {
            let mut p = policy_with_entries(
                "p",
                vec![entry(
                    "ok",
                    DetectionKind::Expression("true".into()),
                    Some(Action::Block),
                )],
            );
            p.allowed_when = Some("gate".into());
            p
        };
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let counter = CountingPredicates {
            calls: std::cell::RefCell::new(0),
            body: "true".into(),
        };
        let detection_deps = DetectionDeps {
            regex_cache: &cache,
            llm_caller: None,
            classifier_caller: None,
            objective: "",
            forbidden: &[],
            user_input: "",
            extra_template_vars: HashMap::new(),
            attrs: &attrs,
            status_lookup: None,
            event_fired: None,
            predicates: None,
            resolver_hook: None,
            append_runtime_context: false,
        };
        let allowed_when_deps = AllowedWhenDeps {
            attrs: &attrs,
            status_lookup: None,
            event_fired: None,
            predicates: Some(&counter),
            resolver_hook: None,
        };
        let o = run_evaluate_when(&p, "", &detection_deps, &allowed_when_deps);
        assert!(!o.any_failed);
        assert_eq!(*counter.calls.borrow(), 0);
    }
}
