//! Stage 4 — `post_tool_validation` runner (§17).
//!
//! Subject: the raw call result returned by a tool / endpoint / agent.
//! `applies_to:` is optional. All detection kinds are accepted; allowed
//! actions per §17 are `block` / `redact` / `warn` (Stage-4 `append` /
//! `prepend` are rejected at load per §12.7 ¶8 — defensive no-op).
//!
//! This stage is the canonical site for the **block-unless-approved**
//! pattern (§17.4): a `pattern:` entry detects the violation, the policy
//! declares `allowed_when: <approval_var>`, and a human resolver fires
//! through auto-resolution.

use std::collections::HashMap;
use std::sync::Mutex;

use serde_json::Value;

use crate::guard_policy::Action;
use crate::observability::Stage;
use crate::populator::Invocation;
use crate::resolver_runtime::AutoResolveAdapter;

use super::action::apply_redactions;
use super::evaluate_when::run_evaluate_when;
use super::runtime_hooks::{PredicateMapLookup, SessionScopedEventFired, TrackerStatusLookup};
use super::selector::applies_to_matches;
use super::stage_common::{
    bind_resolved_variables_in, block_verdict, build_allowed_when_deps_with_event_hook,
    build_detection_deps_with_event_hook, emit_stage_verdict, log_outcome_in, ResolverHookHolder,
};
use super::{
    bind_invocation_into, invocation_subject, EvalRuntime, GuardPolicyEngine, StageVerdict,
};
use crate::session_id::SessionId;

pub(crate) fn evaluate(
    engine: &GuardPolicyEngine,
    invocation: &Invocation,
    result: &mut Value,
    ctx: &EvalRuntime<'_>,
) -> StageVerdict {
    let invocation_hash_before = invocation.canonical_hash();
    let session_id = SessionId::new(ctx.session_id);
    let policies = &engine.deps().config.post_tool_validation.guard_policies;
    let mut attrs = ctx.build_base_attrs();
    bind_resolved_variables_in(
        &session_id,
        &mut attrs,
        engine.deps().tracker.as_ref(),
        &engine.deps().config.variables,
    );
    bind_invocation_into(&mut attrs, invocation);
    attrs.insert("@result".into(), result.clone());

    let status_lookup =
        TrackerStatusLookup::new_in(engine.deps().tracker.as_ref(), session_id.clone());
    let pred_lookup = PredicateMapLookup::new(&engine.deps().config.predicates);
    let resolver_holder = ResolverHookHolder {
        adapter: AutoResolveAdapter::new_in(
            engine.deps().resolver.as_ref(),
            attrs.clone(),
            session_id.clone(),
        )
        .with_invocation(invocation.clone()),
        trace: Mutex::new(Vec::new()),
    };
    let resolver_hook: &dyn crate::expressions::eval::ResolverHook = &resolver_holder;
    let event_fired_hook =
        SessionScopedEventFired::new(&engine.deps().event_bus, session_id.clone());
    let subject_kind = invocation_subject(invocation);
    let mut current_text = render_result_as_text(result);
    let mut last_action: Option<Action> = None;
    let mut transformed = false;
    let mut bypassed = false;

    for policy in policies {
        if !applies_to_matches(policy.applies_to.as_ref(), &subject_kind) {
            continue;
        }
        let active = engine.activation().evaluate_and_emit_in(
            &session_id,
            &policy.name,
            policy.active_if.as_deref(),
            &attrs,
            Some(&pred_lookup as &dyn crate::expressions::eval::PredicateLookup),
            Some(&event_fired_hook as &dyn crate::expressions::eval::EventFiredHook),
            &engine.deps().event_bus,
        );
        if !active {
            continue;
        }

        if policy.evaluate_when.is_empty() {
            let reason = policy
                .reason
                .clone()
                .unwrap_or_else(|| format!("guard policy `{}` blocked", policy.name));
            let v = StageVerdict::block(&policy.name, reason, None)
                .with_pending_resolution(resolver_holder.adapter.take_pending())
                .with_invocation_hashes(
                    invocation_hash_before.clone(),
                    invocation.canonical_hash(),
                );
            let _ = engine
                .deps()
                .event_bus
                .emit_guard_policy_failed_in(&session_id, policy.name.clone());
            emit_stage_verdict(engine, &session_id, Stage::PostTool, &v);
            return v;
        }

        let ddeps = build_detection_deps_with_event_hook(
            engine,
            ctx,
            &attrs,
            Some(&status_lookup),
            Some(&pred_lookup),
            Some(resolver_hook),
            Some(&event_fired_hook as &dyn crate::expressions::eval::EventFiredHook),
            // §12.9.2 — Stage 4 binds `{tool_result}`.
            {
                let mut m = HashMap::new();
                m.insert("tool_result".into(), current_text.clone());
                m
            },
            // Stage 4 does not append the §16.2 Runtime Context block.
            false,
        );
        let aw_deps = build_allowed_when_deps_with_event_hook(
            engine,
            &attrs,
            Some(&status_lookup),
            Some(&pred_lookup),
            Some(resolver_hook),
            Some(&event_fired_hook as &dyn crate::expressions::eval::EventFiredHook),
        );
        let outcome = run_evaluate_when(policy, &current_text, &ddeps, &aw_deps);
        log_outcome_in(&session_id, engine, Stage::PostTool, policy, &outcome);

        if outcome.allowed_when_bypass_fired {
            bypassed = true;
        }

        if let Some(b) = &outcome.block {
            let v = block_verdict(policy, b)
                .with_pending_resolution(resolver_holder.adapter.take_pending())
                .with_invocation_hashes(
                    invocation_hash_before.clone(),
                    invocation.canonical_hash(),
                );
            emit_stage_verdict(engine, &session_id, Stage::PostTool, &v);
            return v;
        }

        if !outcome.redactions.is_empty() {
            current_text = apply_redactions(&current_text, &outcome.redactions);
            transformed = true;
            last_action = Some(Action::Redact);
        }
        if !outcome.warns.is_empty() && last_action.is_none() {
            last_action = Some(Action::Warn);
        }
    }

    if transformed {
        *result = Value::String(current_text.clone());
    }

    let mut verdict = StageVerdict::allow();
    if transformed {
        verdict.action = last_action;
        verdict.redaction = Some(current_text);
    } else if let Some(a) = last_action {
        verdict.action = Some(a);
    }
    verdict.bypassed_by_allowed_when = bypassed;
    verdict = verdict.with_invocation_hash(invocation_hash_before);
    emit_stage_verdict(engine, &session_id, Stage::PostTool, &verdict);
    verdict
}

fn render_result_as_text(result: &Value) -> String {
    match result {
        Value::String(s) => s.clone(),
        other => serde_json::to_string(other).unwrap_or_default(),
    }
}

#[cfg(test)]
mod tests {
    use super::super::tests_support::*;
    use crate::guard_policy::Action;
    use crate::populator::Invocation;
    use serde_json::{json, Value};

    #[test]
    fn ssn_pattern_redacts_result() {
        let h = test_harness(|cfg| {
            let mut p = make_policy(
                "ssn",
                vec![{
                    let mut e = pattern_entry("ssn", r"\d{3}-\d{2}-\d{4}");
                    e.action = Some(Action::Redact);
                    e
                }],
                None,
                None,
            );
            p.replacement = Some("[X]".into());
            cfg.post_tool_validation.guard_policies.push(p);
        });
        let inv = Invocation::tool("get_user", json!({}));
        let mut result: Value = json!("user ssn 123-45-6789 ok");
        let v = h
            .engine
            .evaluate_post_tool(&inv, &mut result, &h.eval_runtime(""));
        assert!(v.allowed);
        assert_eq!(result, json!("user ssn [X] ok"));
    }

    #[test]
    fn block_unless_approved_pattern() {
        let h = test_harness(|cfg| {
            let mut p = make_policy(
                "pii_block",
                vec![pattern_entry("ssn", r"\d{3}-\d{2}-\d{4}")],
                None,
                Some(Action::Block),
            );
            p.allowed_when = Some("approved == true".into());
            cfg.post_tool_validation.guard_policies.push(p);
        });
        let inv = Invocation::tool("get_user", json!({}));
        let mut result: Value = json!("ssn 123-45-6789");
        // approved missing → block
        let v = h
            .engine
            .evaluate_post_tool(&inv, &mut result, &h.eval_runtime(""));
        assert!(!v.allowed);
    }

    #[test]
    fn block_unless_approved_passes_when_truthy() {
        let h = test_harness(|cfg| {
            let mut p = make_policy(
                "pii_block",
                vec![pattern_entry("ssn", r"\d{3}-\d{2}-\d{4}")],
                None,
                Some(Action::Block),
            );
            p.allowed_when = Some("@context.approved == true".into());
            cfg.post_tool_validation.guard_policies.push(p);
        });
        let inv = Invocation::tool("get_user", json!({}));
        let mut result: Value = json!("ssn 123-45-6789");
        let owned = h.eval_runtime_with_attrs(json!({"approved": true}));
        let v = h
            .engine
            .evaluate_post_tool(&inv, &mut result, &(&owned).into());
        assert!(v.allowed);
        assert!(v.bypassed_by_allowed_when);
    }
}
