//! Shared test fixtures and harness used across the per-stage runner
//! test modules.
//!
//! This is `pub(super)` only — never exposed as part of the public API.
//! Builds an in-memory `MergedConfig` plus the dispatcher / tracker /
//! resolver / observability scaffolding so individual tests can express
//! `evaluate_*` checks in a few lines.

#![cfg(test)]
#![allow(dead_code)]

use std::collections::HashMap;
use std::sync::Arc;

use serde_json::Value;

use crate::event_bus::EventBus;
use crate::guard_policy::{
    Action, AppliesTo, DetectionKind, EndpointSelector, EvaluateWhenEntry, GuardPolicy,
};
use crate::lifetime_tracker::LifetimeTracker;
use crate::merge::MergedConfig;
use crate::observability::ObservabilityDispatcher;
use crate::resolver_runtime::{ResolverDeps, ResolverDispatcher};

use super::{EvalRuntime, GuardPolicyDeps, GuardPolicyEngine};

pub struct Harness {
    pub engine: Arc<GuardPolicyEngine>,
    pub bus: EventBus,
    pub tracker: Arc<LifetimeTracker>,
    pub objective: String,
    pub forbidden: Vec<String>,
    pub user_input: String,
}

impl Harness {
    pub fn eval_runtime<'a>(&'a self, user_input: &'a str) -> EvalRuntime<'a> {
        EvalRuntime {
            session_id: "s1",
            correlation_id: "c1",
            user_id: None,
            tenant_id: None,
            request_context: Value::Null,
            turn_id: 0,
            objective: &self.objective,
            forbidden: &self.forbidden,
            user_input,
            active_guard_policies: "",
            variables_snapshot: "",
            prior_checks_summary: "",
        }
    }

    pub fn eval_runtime_with_attrs(&self, ctx: Value) -> EvalRuntimeOwned {
        EvalRuntimeOwned {
            session_id: "s1".into(),
            correlation_id: "c1".into(),
            request_context: ctx,
            objective: self.objective.clone(),
            forbidden: self.forbidden.clone(),
            user_input: self.user_input.clone(),
        }
    }
}

/// Owned variant suitable for passing into `evaluate_*` via `as_runtime()`.
pub struct EvalRuntimeOwned {
    pub session_id: String,
    pub correlation_id: String,
    pub request_context: Value,
    pub objective: String,
    pub forbidden: Vec<String>,
    pub user_input: String,
}

impl<'a> From<&'a EvalRuntimeOwned> for EvalRuntime<'a> {
    fn from(o: &'a EvalRuntimeOwned) -> Self {
        EvalRuntime {
            session_id: &o.session_id,
            correlation_id: &o.correlation_id,
            user_id: None,
            tenant_id: None,
            request_context: o.request_context.clone(),
            turn_id: 0,
            objective: &o.objective,
            forbidden: &o.forbidden,
            user_input: &o.user_input,
            active_guard_policies: "",
            variables_snapshot: "",
            prior_checks_summary: "",
        }
    }
}

/// Convenience extension so tests can pass `&owned` directly to engine
/// methods.
#[allow(clippy::wrong_self_convention)]
pub trait IntoEvalRuntime<'a> {
    fn as_runtime(self) -> EvalRuntime<'a>;
}

impl<'a> IntoEvalRuntime<'a> for &'a EvalRuntimeOwned {
    fn as_runtime(self) -> EvalRuntime<'a> {
        self.into()
    }
}

/// Allow stage_input tests to call `evaluate_input` with an owned ctx.
impl GuardPolicyEngine {
    #[cfg(test)]
    pub(super) fn evaluate_input_owned(
        &self,
        input: &str,
        ctx: &EvalRuntimeOwned,
    ) -> super::StageVerdict {
        let r: EvalRuntime<'_> = ctx.into();
        self.evaluate_input(input, &r)
    }
}

pub fn test_harness(mutator: impl FnOnce(&mut MergedConfig)) -> Harness {
    let mut config = MergedConfig::default();
    mutator(&mut config);

    let bus = EventBus::new();
    let tracker = LifetimeTracker::new(bus.clone(), HashMap::new());

    let resolver = Arc::new(ResolverDispatcher::new(ResolverDeps {
        event_bus: bus.clone(),
        tracker: tracker.clone(),
        variables: Arc::new(HashMap::new()),
        configurations: Arc::new(HashMap::new()),
        agent_resolver: None,
        delegate_dispatcher: None,
        human_registry: crate::resolver_runtime::HumanRegistry::new(),
        tool_retry_limit: 3,
        mode: crate::shield_primitives::RuntimeMode::Active,
        observability: None,
    }));

    let observability = ObservabilityDispatcher::new(bus.clone());

    let engine = GuardPolicyEngine::new(GuardPolicyDeps {
        config: Arc::new(config),
        event_bus: bus.clone(),
        tracker: tracker.clone(),
        resolver,
        observability,
        llm_caller: None,
        classifier_caller: None,
    });

    Harness {
        engine,
        bus,
        tracker,
        objective: "be helpful".into(),
        forbidden: vec![],
        user_input: "hi".into(),
    }
}

pub fn make_policy(
    name: &str,
    entries: Vec<EvaluateWhenEntry>,
    applies_to: Option<AppliesTo>,
    action: Option<Action>,
) -> GuardPolicy {
    GuardPolicy {
        name: name.into(),
        description: None,
        applies_to,
        active_if: None,
        evaluate_when: entries,
        allowed_when: None,
        action,
        reason: None,
        replacement: None,
        log: None,
    }
}

pub fn pattern_entry(reason: &str, p: &str) -> EvaluateWhenEntry {
    EvaluateWhenEntry {
        detection: DetectionKind::Pattern(p.into()),
        reason: reason.into(),
        action: None,
        replacement: None,
        text: None,
        paths: vec![],
        log: None,
        declassify_target: Vec::new(),
    }
}

pub fn expression_entry(reason: &str, expr: &str) -> EvaluateWhenEntry {
    EvaluateWhenEntry {
        detection: DetectionKind::Expression(expr.into()),
        reason: reason.into(),
        action: None,
        replacement: None,
        text: None,
        paths: vec![],
        log: None,
        declassify_target: Vec::new(),
    }
}

pub fn applies_to_tools(tools: &[&str]) -> AppliesTo {
    AppliesTo {
        tools: tools.iter().map(|s| s.to_string()).collect(),
        ..Default::default()
    }
}

pub fn applies_to_endpoint(pattern: &str, methods: &[&str]) -> AppliesTo {
    AppliesTo {
        endpoints: vec![EndpointSelector {
            pattern: pattern.into(),
            methods: methods.iter().map(|s| s.to_string()).collect(),
        }],
        ..Default::default()
    }
}
