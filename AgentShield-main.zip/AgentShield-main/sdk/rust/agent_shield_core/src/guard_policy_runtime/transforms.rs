//! Stage-3 parameter transforms (§16.3 / §12.10).
//!
//! Stage 3 (`tool_execution_validation`) gates *proposed* call parameters.
//! Per §12.10 step 5c: "Hosts MUST execute the transformed invocation,
//! not the original; integration code that mutates parameters between
//! gating and execution is forbidden." This module owns the actual
//! mutation: rewriting matched substrings (redact), prepending text, and
//! appending text inside dotted paths within `Invocation.params`.

use serde_json::Value;

use crate::populator::Invocation;

use super::action::{apply_prepend_append, apply_redactions};
use super::detection::Span;
use super::evaluate_when::TransformText;

/// Mutate `invocation.params` per a fully-resolved set of redactions and
/// append/prepend transforms.
///
/// `path_redactions` maps each affected dotted path to the list of
/// `(span, replacement)` pairs that target it. Spans are character
/// (codepoint) offsets **into the string at that path**.
pub fn apply_invocation_transforms(
    invocation: &mut Invocation,
    path_redactions: &[(String, Vec<(Span, String)>)],
    prepends: &[TransformText],
    appends: &[TransformText],
) {
    // Apply redactions per path first (§12.10 step 5a).
    for (path, spans) in path_redactions {
        if let Some(s) = read_string_at_path(&invocation.params, path) {
            let new_value = apply_redactions(s, spans);
            write_string_at_path(&mut invocation.params, path, new_value);
        }
    }

    // Then prepend/append per path (§12.10 step 5b).
    let all_paths = collect_target_paths(prepends, appends);
    for path in all_paths {
        let path_prepends: Vec<String> = prepends
            .iter()
            .filter(|t| t.paths.iter().any(|p| p == &path))
            .map(|t| t.text.clone())
            .collect();
        let path_appends: Vec<String> = appends
            .iter()
            .filter(|t| t.paths.iter().any(|p| p == &path))
            .map(|t| t.text.clone())
            .collect();
        if path_prepends.is_empty() && path_appends.is_empty() {
            continue;
        }
        let current = read_string_at_path(&invocation.params, &path)
            .map(|s| s.to_string())
            .unwrap_or_default();
        let mutated = apply_prepend_append(&current, &path_prepends, &path_appends);
        write_string_at_path(&mut invocation.params, &path, mutated);
    }
}

fn collect_target_paths(prepends: &[TransformText], appends: &[TransformText]) -> Vec<String> {
    let mut out = Vec::new();
    for t in prepends.iter().chain(appends.iter()) {
        for p in &t.paths {
            if !out.iter().any(|x: &String| x == p) {
                out.push(p.clone());
            }
        }
    }
    out
}

/// Resolve a dot-path against a `Value` and return a string reference.
/// Recognized roots (and their underlying keys) match the spec template
/// vocabulary:
///
/// - `tool.params.<rest>` ⇒ `params.<rest>` against [`Invocation::params`].
/// - `endpoint.params.<rest>` ⇒ `params.<rest>`.
/// - `endpoint.body.<rest>` ⇒ `params.<rest>`.
/// - `agent.params.<rest>` ⇒ `params.<rest>`.
/// - `agent.payload.<rest>` ⇒ `params.<rest>`.
/// - bare `<key>...` ⇒ direct lookup against `params`.
pub fn read_string_at_path<'a>(params: &'a Value, path: &str) -> Option<&'a str> {
    let normalized = strip_root(path);
    let mut cursor: &Value = params;
    for seg in normalized.split('.') {
        if seg.is_empty() {
            continue;
        }
        cursor = cursor.get(seg)?;
    }
    cursor.as_str()
}

/// Mutate the string at `path` to `new_value`. If the path doesn't
/// resolve to an existing string, the operation is a no-op (per §12.7
/// stage rules, transform paths SHOULD be load-validated against the
/// schema; runtime is best-effort).
pub fn write_string_at_path(params: &mut Value, path: &str, new_value: String) {
    let normalized = strip_root(path);
    let segs: Vec<&str> = normalized.split('.').filter(|s| !s.is_empty()).collect();
    if segs.is_empty() {
        return;
    }
    let mut cursor: &mut Value = params;
    for seg in &segs[..segs.len() - 1] {
        let next = match cursor {
            Value::Object(map) => map.get_mut(*seg),
            _ => None,
        };
        match next {
            Some(v) => cursor = v,
            None => return,
        }
    }
    let last = segs[segs.len() - 1];
    if let Value::Object(map) = cursor {
        if let Some(slot) = map.get_mut(last) {
            *slot = Value::String(new_value);
        }
    }
}

fn strip_root(path: &str) -> &str {
    for prefix in &[
        "tool.params.",
        "endpoint.params.",
        "endpoint.body.",
        "agent.params.",
        "agent.payload.",
        "params.",
    ] {
        if let Some(rest) = path.strip_prefix(prefix) {
            return rest;
        }
    }
    path
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::populator::Invocation;
    use serde_json::json;

    #[test]
    fn read_simple_path() {
        let v = json!({"body": "hello"});
        assert_eq!(read_string_at_path(&v, "tool.params.body"), Some("hello"));
        assert_eq!(read_string_at_path(&v, "params.body"), Some("hello"));
        assert_eq!(read_string_at_path(&v, "body"), Some("hello"));
    }

    #[test]
    fn read_nested_path() {
        let v = json!({"outer": {"inner": "x"}});
        assert_eq!(
            read_string_at_path(&v, "tool.params.outer.inner"),
            Some("x")
        );
    }

    #[test]
    fn write_replaces_string() {
        let mut v = json!({"body": "hello"});
        write_string_at_path(&mut v, "tool.params.body", "[REDACTED]".into());
        assert_eq!(v, json!({"body": "[REDACTED]"}));
    }

    #[test]
    fn write_missing_key_no_op() {
        let mut v = json!({"body": "hello"});
        write_string_at_path(&mut v, "tool.params.unknown", "x".into());
        assert_eq!(v, json!({"body": "hello"}));
    }

    #[test]
    fn append_modifies_path_in_invocation() {
        let mut inv = Invocation::tool("t", json!({"body": "hello"}));
        let appends = vec![TransformText {
            entry_index: 0,
            text: " world".into(),
            paths: vec!["tool.params.body".into()],
        }];
        apply_invocation_transforms(&mut inv, &[], &[], &appends);
        assert_eq!(inv.params, json!({"body": "hello world"}));
    }

    #[test]
    fn prepend_modifies_path_in_invocation() {
        let mut inv = Invocation::tool("t", json!({"body": "world"}));
        let prepends = vec![TransformText {
            entry_index: 0,
            text: "hello ".into(),
            paths: vec!["tool.params.body".into()],
        }];
        apply_invocation_transforms(&mut inv, &[], &prepends, &[]);
        assert_eq!(inv.params, json!({"body": "hello world"}));
    }

    #[test]
    fn redact_modifies_path_in_invocation() {
        let mut inv = Invocation::tool("t", json!({"body": "ssn 123-45-6789 ok"}));
        let redactions = vec![(
            "tool.params.body".to_string(),
            vec![(
                Span {
                    start: 4,
                    end: 15,
                    replacement: None,
                },
                "[X]".to_string(),
            )],
        )];
        apply_invocation_transforms(&mut inv, &redactions, &[], &[]);
        assert_eq!(inv.params, json!({"body": "ssn [X] ok"}));
    }

    #[test]
    fn multiple_appends_concatenate() {
        let mut inv = Invocation::tool("t", json!({"body": "x"}));
        let appends = vec![
            TransformText {
                entry_index: 0,
                text: "1".into(),
                paths: vec!["tool.params.body".into()],
            },
            TransformText {
                entry_index: 1,
                text: "2".into(),
                paths: vec!["tool.params.body".into()],
            },
        ];
        apply_invocation_transforms(&mut inv, &[], &[], &appends);
        assert_eq!(inv.params, json!({"body": "x12"}));
    }

    #[test]
    fn last_prepend_ends_at_front() {
        let mut inv = Invocation::tool("t", json!({"body": "x"}));
        let prepends = vec![
            TransformText {
                entry_index: 0,
                text: "[1]".into(),
                paths: vec!["tool.params.body".into()],
            },
            TransformText {
                entry_index: 1,
                text: "[2]".into(),
                paths: vec!["tool.params.body".into()],
            },
        ];
        apply_invocation_transforms(&mut inv, &[], &prepends, &[]);
        assert_eq!(inv.params, json!({"body": "[2][1]x"}));
    }
}
