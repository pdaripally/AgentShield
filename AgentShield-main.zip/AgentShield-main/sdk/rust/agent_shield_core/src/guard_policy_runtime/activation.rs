//! `active_if:` evaluation and activation events (§12.4).
//!
//! `active_if:` is observational — it MUST NOT trigger auto-resolution.
//! The evaluator runs with `is_gating_site = false` and a hookless
//! [`crate::expressions::eval::ResolverHook`]. Per-policy activation
//! state is latched here so we emit `guard_policy.<name>.activated` /
//! `.deactivated` exactly once per transition.
//!
//! State is keyed by `(SessionId, policy_name)` so two
//! [`crate::runtime::GuardrailsSession`]s on the same runtime each
//! observe their own activation transitions. Activation events emitted
//! by transitions carry the originating session id.

use std::collections::HashMap;
use std::sync::Mutex;

use serde_json::Value;

use crate::event_bus::EventBus;
use crate::expressions::eval::{evaluate_with, EvalContext, EventFiredHook, PredicateLookup};
use crate::session_id::SessionId;

/// Per-engine cache of last-evaluated `active_if` truthiness, keyed by
/// `(session_id, guard_policy_name)`. Initialized lazily on first
/// evaluation per session.
#[derive(Debug, Default)]
pub struct ActivationCache {
    last_state: Mutex<HashMap<(SessionId, String), bool>>,
}

impl ActivationCache {
    pub fn new() -> Self {
        Self::default()
    }

    /// Evaluate a policy's `active_if:` (or treat as always-active when
    /// absent) and emit transition events on the bus when the latched
    /// state changes. Returns the new active flag.
    ///
    /// Legacy session-blind variant — equivalent to
    /// [`Self::evaluate_and_emit_in`] with [`SessionId::default`].
    pub fn evaluate_and_emit(
        &self,
        policy_name: &str,
        active_if: Option<&str>,
        attrs: &HashMap<String, Value>,
        predicates: Option<&dyn PredicateLookup>,
        event_fired: Option<&dyn EventFiredHook>,
        bus: &EventBus,
    ) -> bool {
        self.evaluate_and_emit_in(
            &SessionId::default(),
            policy_name,
            active_if,
            attrs,
            predicates,
            event_fired,
            bus,
        )
    }

    /// Session-scoped variant of [`Self::evaluate_and_emit`]. The
    /// transition latch is keyed by `(session_id, policy_name)` so
    /// each session sees its own first-activation emission. Activation
    /// events are emitted on the bus carrying `session_id`.
    #[allow(clippy::too_many_arguments)]
    pub fn evaluate_and_emit_in(
        &self,
        session_id: &SessionId,
        policy_name: &str,
        active_if: Option<&str>,
        attrs: &HashMap<String, Value>,
        predicates: Option<&dyn PredicateLookup>,
        event_fired: Option<&dyn EventFiredHook>,
        bus: &EventBus,
    ) -> bool {
        let active = match active_if {
            None => true,
            Some(expr) => {
                let mut ctx = EvalContext::from_attrs(attrs);
                ctx.predicates = predicates;
                ctx.event_fired = event_fired;
                ctx.is_gating_site = false; // observational only
                evaluate_with(expr, &ctx)
            }
        };

        let mut guard = self.last_state.lock().unwrap();
        let key = (session_id.clone(), policy_name.to_string());
        match guard.get(&key).copied() {
            None => {
                guard.insert(key, active);
                drop(guard);
                if active {
                    let _ = bus.emit_guard_policy_activated_in(session_id, policy_name.to_string());
                } else {
                    // First evaluation went straight to "inactive": no
                    // transition event is emitted (we never claimed
                    // active, so we can't deactivate). This matches
                    // §12.4: "On a transition from inactive to active,
                    // emit `guard_policy.<name>.activated`."
                }
            }
            Some(prev) if prev != active => {
                guard.insert(key, active);
                drop(guard);
                if active {
                    let _ = bus.emit_guard_policy_activated_in(session_id, policy_name.to_string());
                } else {
                    let _ =
                        bus.emit_guard_policy_deactivated_in(session_id, policy_name.to_string());
                }
            }
            _ => {}
        }
        active
    }

    /// Test-only inspection helper.
    #[cfg(test)]
    pub fn current_state(&self, policy_name: &str) -> Option<bool> {
        self.current_state_in(&SessionId::default(), policy_name)
    }

    #[cfg(test)]
    pub fn current_state_in(&self, session_id: &SessionId, policy_name: &str) -> Option<bool> {
        self.last_state
            .lock()
            .unwrap()
            .get(&(session_id.clone(), policy_name.to_string()))
            .copied()
    }

    /// Read-only snapshot of the latched activation state for the
    /// default session. Kept for back-compat with pre-refactor tests.
    pub fn snapshot(&self) -> HashMap<String, bool> {
        self.snapshot_in(&SessionId::default())
    }

    /// Read-only snapshot of the latched activation state for
    /// `session_id`. Returned map holds the most recent `active_if:`
    /// evaluation outcome for every policy name the cache has seen
    /// since session start. Used by the session to compute
    /// `{active_guard_policies}` and `{prior_checks_summary}` for
    /// §16.1 Stage-3 prompt enrichment.
    pub fn snapshot_in(&self, session_id: &SessionId) -> HashMap<String, bool> {
        self.last_state
            .lock()
            .unwrap()
            .iter()
            .filter_map(|((sid, name), v)| {
                if sid == session_id {
                    Some((name.clone(), *v))
                } else {
                    None
                }
            })
            .collect()
    }

    /// Drop every latched activation entry belonging to `session_id`.
    /// Called when a [`crate::runtime::GuardrailsSession`] is dropped
    /// or closed. Idempotent.
    pub fn cleanup_session(&self, session_id: &SessionId) {
        let mut guard = self.last_state.lock().unwrap();
        guard.retain(|(sid, _), _| sid != session_id);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::event_bus::{BusEvent, EventBus};
    use serde_json::json;
    use std::sync::Arc;

    fn capture_events() -> (EventBus, Arc<Mutex<Vec<BusEvent>>>) {
        let bus = EventBus::new();
        let captured: Arc<Mutex<Vec<BusEvent>>> = Arc::new(Mutex::new(Vec::new()));
        let cap = captured.clone();
        bus.subscribe(None, move |ev: &BusEvent| {
            cap.lock().unwrap().push(ev.clone());
        });
        (bus, captured)
    }

    fn count_gp_kind(events: &[BusEvent], expected: crate::events::GpEventKind) -> usize {
        events
            .iter()
            .filter(|e| {
                matches!(
                    e,
                    BusEvent::Emitted {
                        event_id: crate::events::EventId::GuardPolicy { kind, .. },
                        ..
                    } if *kind == expected
                )
            })
            .count()
    }

    #[test]
    fn omitted_active_if_is_always_active() {
        let cache = ActivationCache::new();
        let (bus, _) = capture_events();
        let attrs = HashMap::new();
        assert!(cache.evaluate_and_emit("p", None, &attrs, None, None, &bus));
    }

    #[test]
    fn first_active_emits_activated() {
        let cache = ActivationCache::new();
        let (bus, captured) = capture_events();
        let attrs = HashMap::new();
        cache.evaluate_and_emit("p", Some("true"), &attrs, None, None, &bus);
        let events = captured.lock().unwrap();
        assert_eq!(
            count_gp_kind(&events, crate::events::GpEventKind::Activated),
            1
        );
    }

    #[test]
    fn transition_to_inactive_emits_deactivated() {
        let cache = ActivationCache::new();
        let (bus, captured) = capture_events();
        let mut attrs = HashMap::new();
        attrs.insert("flag".to_string(), json!(true));
        cache.evaluate_and_emit("p", Some("flag == true"), &attrs, None, None, &bus);
        attrs.insert("flag".to_string(), json!(false));
        cache.evaluate_and_emit("p", Some("flag == true"), &attrs, None, None, &bus);
        let events = captured.lock().unwrap();
        assert_eq!(
            count_gp_kind(&events, crate::events::GpEventKind::Deactivated),
            1
        );
    }

    #[test]
    fn no_repeat_event_when_state_unchanged() {
        let cache = ActivationCache::new();
        let (bus, captured) = capture_events();
        let attrs = HashMap::new();
        cache.evaluate_and_emit("p", Some("true"), &attrs, None, None, &bus);
        cache.evaluate_and_emit("p", Some("true"), &attrs, None, None, &bus);
        let events = captured.lock().unwrap();
        assert_eq!(
            count_gp_kind(&events, crate::events::GpEventKind::Activated),
            1
        );
    }

    #[test]
    fn first_inactive_emits_nothing() {
        let cache = ActivationCache::new();
        let (bus, captured) = capture_events();
        let mut attrs = HashMap::new();
        attrs.insert("flag".to_string(), json!(false));
        let active = cache.evaluate_and_emit("p", Some("flag == true"), &attrs, None, None, &bus);
        assert!(!active);
        let events = captured.lock().unwrap();
        assert_eq!(
            count_gp_kind(&events, crate::events::GpEventKind::Activated),
            0
        );
        assert_eq!(
            count_gp_kind(&events, crate::events::GpEventKind::Deactivated),
            0
        );
    }
}
