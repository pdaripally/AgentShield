//! Per-invocation context built by the runtime and threaded into every
//! resolver dispatch.
//!
//! The dispatcher is purely passive about *where* the runtime values
//! come from — the host populates [`ResolverContext::attrs`] from the
//! [`crate::lifetime_tracker`] and the §6.3 request context. This
//! module defines the shape and the helpers that consume it.
//!
//! ## Spec mapping
//!
//! - §3.5a — attribute namespaces (`tool.*`, `endpoint.*`, `agent.*`,
//!   `context.*`, declared variables).
//! - §6.3 — request context.
//! - §11.4a — resolver `prompt:` interpolation (the `interpolate_prompt`
//!   helper here is the canonical reference implementation).
//! - §11.5 — gating-site flag toggles auto-resolution inside resolver
//!   `context:` map evaluation: it MUST be `false` (§11.5 explicitly
//!   forbids auto-resolution inside a resolver's `context:`).

use std::collections::HashMap;

use serde_json::{Map, Value};

use super::super::populator::Invocation;
use super::super::variables::ResourceKind;

/// The resource currently being gated. Populated by the host runtime at the
/// gating site.
#[derive(Debug, Clone)]
pub struct GatedResourceRef {
    pub kind: ResourceKind,
    pub name: String,
    /// The structured invocation params (`tool.params.*`, etc.). The
    /// invocation-bound namespaces (§7.6.1–§7.6.3) are sourced from this
    /// snapshot when interpolating `prompt:` strings.
    pub params: Value,
}

impl GatedResourceRef {
    pub fn new(kind: ResourceKind, name: impl Into<String>, params: Value) -> Self {
        Self {
            kind,
            name: name.into(),
            params,
        }
    }
}

/// Thread-locally-constructed evaluation context shared across every
/// resolver dispatch within a single auto-resolution. Most fields are
/// optional because not every gating site has them (e.g. inline `kind:
/// expression` resolvers fired outside an active invocation).
///
/// `attrs` is the canonical attribute snapshot used for expression
/// evaluation. Conventionally:
///
/// - bare names map to declared session variables (§9 / §3.5a),
/// - `@context.<key>` reads come from the §6.3 request context,
/// - `@tool.<path>`, `@endpoint.<path>`, `@agent.<path>` reads come
///   from the active invocation (when `invocation` is `Some`).
///
/// The host populates `attrs` *before* calling the dispatcher; the
/// dispatcher does not perform tracker reads on its own (separation of
/// concerns — the tracker is the source of truth, the dispatcher is the
/// policy engine).
#[derive(Debug, Clone, Default)]
pub struct ResolverContext<'a> {
    /// Bare-name + scope-namespace map for the expression evaluator.
    pub attrs: HashMap<String, Value>,
    /// `@context.*` namespace (kept separately so the runtime can fold
    /// it into `attrs` once but keep the structured copy for prompt
    /// interpolation).
    pub request_context: Map<String, Value>,
    /// Active invocation, when the gate is invocation-bound.
    pub invocation: Option<&'a Invocation>,
    /// The §12 guard policy `evaluate_when[].reason` that triggered the
    /// resolver, when known.
    pub reason: Option<String>,
    /// Resource being gated.
    pub resource: Option<GatedResourceRef>,
    /// Stable request id surfaced to host hooks (§11.11 / §11.12.1).
    pub request_id: Option<String>,
    /// §9.4 / §11.5: when the target variable declares `key:`, the
    /// runtime evaluates the key at the gating-site read and forwards
    /// it here so the resolver wire envelope (§11.12.1 etc.) can carry
    /// it as `requested_key`. `None` when the variable is non-keyed or
    /// when the gating context is not invocation-bound.
    pub requested_key: Option<Value>,
    /// Session that owns this gating evaluation. Threaded through to
    /// the dispatcher so write-backs to
    /// [`crate::lifetime_tracker::LifetimeTracker`] /
    /// [`crate::event_bus::EventBus`] target the correct session.
    /// `None` ⇒ the legacy default ([`crate::session_id::SessionId::default`]).
    pub session_id: Option<crate::session_id::SessionId>,
}

impl<'a> ResolverContext<'a> {
    pub fn new() -> Self {
        Self::default()
    }

    /// Set the variable attribute snapshot. Convenience for tests and host
    /// integrators.
    pub fn with_attrs(mut self, attrs: HashMap<String, Value>) -> Self {
        self.attrs = attrs;
        self
    }

    pub fn with_request_context(mut self, ctx: Map<String, Value>) -> Self {
        self.request_context = ctx;
        self
    }

    pub fn with_invocation(mut self, inv: &'a Invocation) -> Self {
        self.invocation = Some(inv);
        self
    }

    pub fn with_reason(mut self, reason: impl Into<String>) -> Self {
        self.reason = Some(reason.into());
        self
    }

    pub fn with_resource(mut self, res: GatedResourceRef) -> Self {
        self.resource = Some(res);
        self
    }

    pub fn with_request_id(mut self, id: impl Into<String>) -> Self {
        self.request_id = Some(id.into());
        self
    }

    /// Bind this context to a specific session so dispatcher writebacks
    /// target the correct session's tracker / bus / activation cache.
    pub fn with_session_id(mut self, sid: crate::session_id::SessionId) -> Self {
        self.session_id = Some(sid);
        self
    }

    /// The session the context binds to, defaulting to
    /// [`crate::session_id::SessionId::default`] when unset.
    pub fn effective_session_id(&self) -> crate::session_id::SessionId {
        self.session_id.clone().unwrap_or_default()
    }
}

/// Outcome of [`interpolate_prompt`] for a single `${...}` reference whose
/// value is missing in an invocation-bound namespace (§11.4a). The runtime
/// SHOULD route this through the resolver's `on_error:` policy — see
/// `super::super::resolver::OnError`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum InterpolationError {
    /// Reference into one of the invocation-bound namespaces (`tool.*`,
    /// `endpoint.*`, `agent.*`) whose value is absent or `null`. §11.4a
    /// requires this to fail-closed.
    MissingInvocationField(String),
    /// `${env.*}` or `${result.*}` inside a resolver prompt — these
    /// namespaces are forbidden per §11.4a.
    ForbiddenNamespace(String),
}

/// Interpolate `${path}` references in a resolver prompt per §11.4a.
///
/// Returns `Ok(rendered)` when every reference resolves to a value (or to
/// a permissive empty string for `${context.*}` / `${var.*}` per §11.4a).
/// Returns `Err(InterpolationError)` when a forbidden namespace is used or
/// when an invocation-bound reference is missing or `null` — both cases
/// MUST be routed through the resolver's `on_error:` policy.
///
/// Sensitivity / redaction policy is intentionally NOT applied here — that
/// is a host-level concern (§11.4a). Hosts that need pre-delivery redaction
/// inspect the rendered string before passing it to the human resolver.
pub fn interpolate_prompt(
    template: &str,
    ctx: &ResolverContext<'_>,
) -> Result<String, InterpolationError> {
    let mut out = String::with_capacity(template.len());
    let mut chars = template.char_indices().peekable();
    while let Some((_, ch)) = chars.next() {
        if ch == '$' {
            if let Some(&(_, '{')) = chars.peek() {
                chars.next(); // consume '{'
                let mut path = String::new();
                let mut closed = false;
                for (_, c) in chars.by_ref() {
                    if c == '}' {
                        closed = true;
                        break;
                    }
                    path.push(c);
                }
                if !closed {
                    // Unterminated ${ — emit literally to be permissive
                    // about template typos.
                    out.push_str("${");
                    out.push_str(&path);
                    continue;
                }
                match resolve_template_path(&path, ctx) {
                    PathResolution::Found(rendered) => out.push_str(&rendered),
                    PathResolution::PermissiveMissing => {
                        log::warn!(
                            target: "agent_shield::resolver_runtime",
                            "prompt interpolation: missing value for `${{{}}}`; substituting empty string",
                            path
                        );
                    }
                    PathResolution::FailClosed(e) => return Err(e),
                }
            } else {
                out.push(ch);
            }
        } else {
            out.push(ch);
        }
    }
    Ok(out)
}

enum PathResolution {
    Found(String),
    /// `${context.*}` or `${var.*}` missing — substitute empty string.
    PermissiveMissing,
    /// Strict failure: invocation-bound missing, or forbidden namespace.
    FailClosed(InterpolationError),
}

fn resolve_template_path(path: &str, ctx: &ResolverContext<'_>) -> PathResolution {
    let path = path.trim();
    // §11.4a: `${@env.*}` and `${@result.*}` are forbidden inside
    // resolver prompts. We accept both the new `@`-prefixed form and
    // the legacy bare form during the migration.
    if path == "env" || path.starts_with("env.") || path == "@env" || path.starts_with("@env.") {
        return PathResolution::FailClosed(InterpolationError::ForbiddenNamespace("env".into()));
    }
    if path == "result"
        || path.starts_with("result.")
        || path == "@result"
        || path.starts_with("@result.")
    {
        return PathResolution::FailClosed(InterpolationError::ForbiddenNamespace("result".into()));
    }

    // Split into root + dotted tail.
    let (root, tail) = match path.split_once('.') {
        Some((r, t)) => (r, t),
        None => (path, ""),
    };

    // §7.1 / §11.4a: runtime-bound namespaces canonically carry the
    // `@` sigil. Strip it for the dispatch below; the legacy bare form
    // is still accepted during the migration to ease author updates.
    let canonical_root: &str = match root {
        "@context" => "context",
        "@tool" => "tool",
        "@endpoint" => "endpoint",
        "@agent" => "agent",
        other => other,
    };

    match canonical_root {
        "context" => {
            let v = walk_object_path(&Value::Object(ctx.request_context.clone()), tail);
            match v {
                Some(val) if !val.is_null() => PathResolution::Found(stringify_value(&val)),
                _ => PathResolution::PermissiveMissing,
            }
        }
        "var" => {
            let v = ctx.attrs.get(tail.split('.').next().unwrap_or("")).cloned();
            match v {
                Some(root_v) => {
                    let rest = tail.split_once('.').map(|(_, r)| r).unwrap_or("");
                    let walked = if rest.is_empty() {
                        Some(root_v)
                    } else {
                        walk_object_path(&root_v, rest)
                    };
                    match walked {
                        Some(val) if !val.is_null() => PathResolution::Found(stringify_value(&val)),
                        _ => PathResolution::PermissiveMissing,
                    }
                }
                None => PathResolution::PermissiveMissing,
            }
        }
        "tool" | "endpoint" | "agent" => {
            let inv = match ctx.invocation {
                Some(inv) => inv,
                None => {
                    return PathResolution::FailClosed(InterpolationError::MissingInvocationField(
                        path.to_string(),
                    ))
                }
            };
            let val = resolve_invocation_path(inv, canonical_root, tail);
            match val {
                Some(v) if !v.is_null() => PathResolution::Found(stringify_value(&v)),
                _ => PathResolution::FailClosed(InterpolationError::MissingInvocationField(
                    path.to_string(),
                )),
            }
        }
        // Bare names like `${current_user}` are not a §11.4a-listed form.
        // We treat them as `var.<name>` for backward compat with hosts that
        // already wrote bare-name templates.
        _ => {
            let v = ctx.attrs.get(root).cloned();
            match v {
                Some(root_v) => {
                    let walked = if tail.is_empty() {
                        Some(root_v)
                    } else {
                        walk_object_path(&root_v, tail)
                    };
                    match walked {
                        Some(val) if !val.is_null() => PathResolution::Found(stringify_value(&val)),
                        _ => PathResolution::PermissiveMissing,
                    }
                }
                None => PathResolution::PermissiveMissing,
            }
        }
    }
}

fn resolve_invocation_path(inv: &Invocation, root: &str, tail: &str) -> Option<Value> {
    // Translate `tool.params.x` / `endpoint.body.x` / `agent.payload.x` into
    // a walk of `inv.params`. Other roots are namespace-coercible aliases.
    let mut head = tail.split('.');
    let first = head.next().unwrap_or("");
    let rest: String = head.collect::<Vec<_>>().join(".");

    match (root, first) {
        ("tool", "params") | ("agent", "payload") | ("endpoint", "body") => {
            if rest.is_empty() {
                Some(inv.params.clone())
            } else {
                walk_object_path(&inv.params, &rest)
            }
        }
        ("tool", "name") | ("agent", "name") => inv.name.as_ref().map(|n| Value::String(n.clone())),
        ("endpoint", "method") => inv.method.as_ref().map(|m| Value::String(m.clone())),
        ("endpoint", "uri") => inv.uri.as_ref().map(|u| Value::String(u.clone())),
        ("endpoint", "path") | ("endpoint", "query") => {
            // Path / query namespaces aren't a hard contract here; surface
            // them when present.
            let map = if first == "path" {
                &inv.path_params
            } else {
                &inv.query_params
            };
            if rest.is_empty() {
                let mut obj = Map::new();
                for (k, v) in map {
                    obj.insert(k.clone(), v.clone());
                }
                Some(Value::Object(obj))
            } else {
                map.get(&rest).cloned()
            }
        }
        _ => None,
    }
}

fn walk_object_path(root: &Value, path: &str) -> Option<Value> {
    if path.is_empty() {
        return Some(root.clone());
    }
    let mut cur = root.clone();
    for segment in path.split('.') {
        cur = match cur {
            Value::Object(map) => map.get(segment).cloned()?,
            _ => return None,
        };
    }
    Some(cur)
}

fn stringify_value(v: &Value) -> String {
    match v {
        Value::String(s) => s.clone(),
        Value::Null => String::new(),
        other => other.to_string(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    fn ctx_with_var(name: &str, val: Value) -> ResolverContext<'static> {
        let mut attrs = HashMap::new();
        attrs.insert(name.into(), val);
        ResolverContext::default().with_attrs(attrs)
    }

    #[test]
    fn permissive_substitution_for_missing_context() {
        let ctx = ResolverContext::default();
        let out = interpolate_prompt("Hi ${context.user}", &ctx).unwrap();
        assert_eq!(out, "Hi ");
    }

    #[test]
    fn substitutes_var() {
        let ctx = ctx_with_var("user", json!("alice"));
        let out = interpolate_prompt("Hello ${var.user}", &ctx).unwrap();
        assert_eq!(out, "Hello alice");
    }

    #[test]
    fn substitutes_bare_name_back_compat() {
        let ctx = ctx_with_var("user", json!("bob"));
        let out = interpolate_prompt("Hi ${user}", &ctx).unwrap();
        assert_eq!(out, "Hi bob");
    }

    #[test]
    fn forbidden_env_namespace() {
        let ctx = ResolverContext::default();
        assert!(matches!(
            interpolate_prompt("${env.SECRET}", &ctx),
            Err(InterpolationError::ForbiddenNamespace(_))
        ));
    }

    #[test]
    fn forbidden_result_namespace() {
        let ctx = ResolverContext::default();
        assert!(matches!(
            interpolate_prompt("${result.x}", &ctx),
            Err(InterpolationError::ForbiddenNamespace(_))
        ));
    }

    #[test]
    fn invocation_field_present() {
        let inv = Invocation::tool("send_email", json!({"to": "ada@x", "amount": 200}));
        let ctx = ResolverContext::default().with_invocation(&inv);
        let out =
            interpolate_prompt("Send ${tool.params.amount} to ${tool.params.to}", &ctx).unwrap();
        assert_eq!(out, "Send 200 to ada@x");
    }

    #[test]
    fn invocation_field_missing_fails_closed() {
        let inv = Invocation::tool("send_email", json!({"to": "ada@x"}));
        let ctx = ResolverContext::default().with_invocation(&inv);
        assert!(matches!(
            interpolate_prompt("amt=${tool.params.amount}", &ctx),
            Err(InterpolationError::MissingInvocationField(_))
        ));
    }

    #[test]
    fn invocation_namespace_without_invocation_fails_closed() {
        let ctx = ResolverContext::default();
        assert!(matches!(
            interpolate_prompt("${tool.params.x}", &ctx),
            Err(InterpolationError::MissingInvocationField(_))
        ));
    }

    #[test]
    fn unterminated_dollar_brace_emits_literal() {
        let ctx = ResolverContext::default();
        let out = interpolate_prompt("$ and ${unterminated", &ctx).unwrap();
        assert!(out.contains("$"));
    }

    #[test]
    fn nested_var_object_path() {
        let mut attrs = HashMap::new();
        attrs.insert(
            "user".to_string(),
            json!({"name": "alice", "addr": {"city": "Seattle"}}),
        );
        let ctx = ResolverContext::default().with_attrs(attrs);
        let out = interpolate_prompt("from ${var.user.addr.city}", &ctx).unwrap();
        assert_eq!(out, "from Seattle");
    }
}
