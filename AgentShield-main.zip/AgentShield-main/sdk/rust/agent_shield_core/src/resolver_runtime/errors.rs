//! Runtime errors raised inside the resolver dispatcher.
//!
//! These are *internal* to the runtime — they MUST NOT escape the
//! [`super::ResolverDispatcher::resolve`] surface as an `Err`. Every error
//! variant is mapped through the per-resolver `on_error:` policy (§11.7)
//! into a synthetic `ResolverResponse` so callers see only a wire envelope.
//!
//! The `kind` identifiers below match the §11.9 audit-log `error_kind`
//! taxonomy (`timeout`, `transport`, `invalid_response`, `cycle`, etc.).

use super::super::resolver::OnError;

/// Errors raised by the dispatcher while running a single resolver link.
#[derive(Debug, Clone, thiserror::Error)]
pub enum ResolverRuntimeError {
    /// The resolver took longer than the effective timeout to respond.
    #[error("resolver `{kind}` timed out after {timeout_ms} ms")]
    Timeout { kind: &'static str, timeout_ms: u32 },

    /// Transport-level failure (connection refused, DNS, TCP reset, etc.).
    #[error("resolver `{kind}` transport failure: {message}")]
    Transport { kind: &'static str, message: String },

    /// The remote returned a payload the runtime could not parse against the
    /// §11.3 wire envelope, including a payload whose `decision` is not in
    /// the closed enum (§11.3 forbids case-folding / whitespace-trimming).
    #[error("resolver `{kind}` returned an invalid response: {message}")]
    InvalidResponse { kind: &'static str, message: String },

    /// A required dispatcher / hook was not registered. Default
    /// fail-closed treatment: deny.
    #[error("resolver `{kind}`: no host hook registered ({hook})")]
    MissingHook {
        kind: &'static str,
        hook: &'static str,
    },

    /// `kind: delegate` resolver references a configurations[] id that was
    /// not loaded. The loader catches most of these at load time; this
    /// variant covers runtime hot-reloads that drop a referenced
    /// configuration.
    #[error("resolver `delegate`: configuration `{0}` is not registered")]
    UnknownConfiguration(String),

    /// `kind: delegate` resolver references a configuration whose `type:`
    /// disagrees with what the dispatcher knows how to invoke (the load
    /// time check should have rejected this; defense in depth).
    #[error(
        "resolver `delegate`: configuration `{id}` has type `{actual}` but `{expected}` was expected"
    )]
    WrongConfigurationType {
        id: String,
        actual: String,
        expected: String,
    },

    /// Cycle detected at runtime while walking a fallback chain. Defense in
    /// depth — load-time checks should have caught it.
    #[error("resolver fallback cycle detected through `{0}`")]
    Cycle(String),

    /// Generic catch-all for transports / hooks that surface a
    /// non-classified failure. Treated as `transport` for audit purposes.
    #[error("resolver `{kind}`: {message}")]
    Other { kind: &'static str, message: String },
}

impl ResolverRuntimeError {
    /// Map to the §11.9 `error_kind` audit string. Useful for observability
    /// emitters when the dispatcher logs through the host's logger.
    pub fn error_kind(&self) -> &'static str {
        match self {
            ResolverRuntimeError::Timeout { .. } => "timeout",
            ResolverRuntimeError::Transport { .. } => "transport",
            ResolverRuntimeError::InvalidResponse { .. } => "invalid_response",
            ResolverRuntimeError::MissingHook { .. } => "missing_hook",
            ResolverRuntimeError::UnknownConfiguration(_) => "unknown_configuration",
            ResolverRuntimeError::WrongConfigurationType { .. } => "wrong_configuration_type",
            ResolverRuntimeError::Cycle(_) => "cycle",
            ResolverRuntimeError::Other { .. } => "transport",
        }
    }

    /// The resolver `kind:` that produced the error, when known.
    pub fn resolver_kind(&self) -> &'static str {
        match self {
            ResolverRuntimeError::Timeout { kind, .. }
            | ResolverRuntimeError::Transport { kind, .. }
            | ResolverRuntimeError::InvalidResponse { kind, .. }
            | ResolverRuntimeError::MissingHook { kind, .. }
            | ResolverRuntimeError::Other { kind, .. } => kind,
            ResolverRuntimeError::UnknownConfiguration(_)
            | ResolverRuntimeError::WrongConfigurationType { .. } => "delegate",
            ResolverRuntimeError::Cycle(_) => "fallback",
        }
    }

    /// True if the active `on_error:` policy is `use_fallback` (§11.7).
    /// Convenience for the chain runner.
    pub fn route_through_fallback(policy: OnError) -> bool {
        matches!(policy, OnError::UseFallback)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn error_kind_maps() {
        assert_eq!(
            ResolverRuntimeError::Timeout {
                kind: "human",
                timeout_ms: 100
            }
            .error_kind(),
            "timeout"
        );
        assert_eq!(
            ResolverRuntimeError::Transport {
                kind: "delegate",
                message: "connect refused".into()
            }
            .error_kind(),
            "transport"
        );
        assert_eq!(
            ResolverRuntimeError::InvalidResponse {
                kind: "delegate",
                message: "bad json".into()
            }
            .error_kind(),
            "invalid_response"
        );
        assert_eq!(
            ResolverRuntimeError::Cycle("v".into()).error_kind(),
            "cycle"
        );
    }

    #[test]
    fn route_through_fallback_only_for_use_fallback() {
        assert!(ResolverRuntimeError::route_through_fallback(
            OnError::UseFallback
        ));
        assert!(!ResolverRuntimeError::route_through_fallback(
            OnError::Block
        ));
        assert!(!ResolverRuntimeError::route_through_fallback(
            OnError::Allow
        ));
        assert!(!ResolverRuntimeError::route_through_fallback(
            OnError::UseDefault
        ));
    }
}
