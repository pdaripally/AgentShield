//! `kind: expression` resolver — local synthesis of the wire envelope
//! (§11.10.1).
//!
//! The runtime evaluates the inline `expression:` against the current
//! variable state. The result is folded into a wire envelope:
//!
//! - non-null and not boolean-`false` → `decision: allow`, `value:` = the
//!   raw evaluated value.
//! - `null` or `false` → `decision: deny`, with a synthetic `reason:`
//!   suitable for routing through `fallback:`.
//!
//! Per §11.10.1, runtime evaluation errors (parse failures, type-mismatch
//! propagation, divide-by-zero) MUST also be treated as `deny` with a
//! diagnostic `reason:` so the chain advances to `fallback:` if declared.
//! There is no `on_error:` field on `kind: expression` — synthesis uses
//! the deny-path directly.
//!
//! This kind makes no use of host hooks.

use std::collections::HashMap;

use serde_json::Value;

use crate::expressions::eval::{evaluate_to_value, EvalContext};

use super::super::resolver::{Resolver, ResolverDecision, ResolverResponse};
use super::context::ResolverContext;

/// Synthesize a wire envelope for a `kind: expression` resolver.
///
/// Returns `Some(envelope)` when the resolver kind is `Expression`; returns
/// `None` for any other kind (so the dispatcher can panic-free fall through
/// to a different per-kind invoker).
pub fn invoke(resolver: &Resolver, ctx: &ResolverContext<'_>) -> Option<ResolverResponse> {
    let expression = match resolver {
        Resolver::Expression { expression, .. } => expression,
        _ => return None,
    };

    let eval_ctx = EvalContext {
        attrs: &ctx.attrs,
        // `kind: expression` is NOT a gating site — auto-resolution must NOT
        // fire from inside it (§11.5).
        is_gating_site: false,
        ..EvalContext::from_attrs(&ctx.attrs)
    };

    let value = match evaluate_to_value(expression, &eval_ctx) {
        Some(v) => v,
        None => {
            return Some(ResolverResponse {
                decision: ResolverDecision::Deny,
                value: None,
                set_variables: HashMap::new(),
                reason: Some(format!(
                    "expression evaluation error: failed to parse `{}`",
                    expression
                )),
            });
        }
    };

    if is_truthy(&value) {
        Some(ResolverResponse {
            decision: ResolverDecision::Allow,
            value: Some(value),
            set_variables: HashMap::new(),
            reason: None,
        })
    } else {
        Some(ResolverResponse {
            decision: ResolverDecision::Deny,
            value: None,
            set_variables: HashMap::new(),
            reason: Some(
                "expression resolver returned null/false (synthesized deny per §11.10.1)".into(),
            ),
        })
    }
}

/// Spec §3.6.1.2: null/false/0/""/[]/{} → false; everything else → true.
fn is_truthy(v: &Value) -> bool {
    match v {
        Value::Null => false,
        Value::Bool(b) => *b,
        Value::Number(n) => n.as_f64().map(|x| x.abs() > 0.0).unwrap_or(false),
        Value::String(s) => !s.is_empty(),
        Value::Array(a) => !a.is_empty(),
        Value::Object(o) => !o.is_empty(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::resolver::Resolver;
    use serde_json::json;

    fn expr_resolver(src: &str) -> Resolver {
        let yaml = format!("kind: expression\nexpression: \"{}\"\n", src);
        serde_yaml::from_str(&yaml).unwrap()
    }

    fn ctx_with(attrs: &[(&str, Value)]) -> ResolverContext<'static> {
        let mut a = HashMap::new();
        for (k, v) in attrs {
            a.insert((*k).into(), v.clone());
        }
        ResolverContext::default().with_attrs(a)
    }

    #[test]
    fn truthy_expression_allows_with_value() {
        let r = expr_resolver("x + 1");
        let ctx = ctx_with(&[("x", json!(4))]);
        let out = invoke(&r, &ctx).unwrap();
        assert_eq!(out.decision, ResolverDecision::Allow);
        assert_eq!(out.value, Some(json!(5)));
    }

    #[test]
    fn boolean_true_allows() {
        let r = expr_resolver("level > 3");
        let ctx = ctx_with(&[("level", json!(5))]);
        let out = invoke(&r, &ctx).unwrap();
        assert_eq!(out.decision, ResolverDecision::Allow);
        assert_eq!(out.value, Some(json!(true)));
    }

    #[test]
    fn boolean_false_denies() {
        let r = expr_resolver("level > 100");
        let ctx = ctx_with(&[("level", json!(5))]);
        let out = invoke(&r, &ctx).unwrap();
        assert_eq!(out.decision, ResolverDecision::Deny);
    }

    #[test]
    fn null_attribute_resolves_to_deny() {
        let r = expr_resolver("missing");
        let ctx = ctx_with(&[]);
        let out = invoke(&r, &ctx).unwrap();
        assert_eq!(out.decision, ResolverDecision::Deny);
    }

    #[test]
    fn parse_error_resolves_to_deny() {
        let r = expr_resolver("(((");
        let ctx = ctx_with(&[]);
        let out = invoke(&r, &ctx).unwrap();
        assert_eq!(out.decision, ResolverDecision::Deny);
        assert!(out
            .reason
            .as_ref()
            .map(|r| r.contains("expression evaluation error"))
            .unwrap_or(false));
    }

    #[test]
    fn empty_string_denies() {
        // Verifies §3.6.1.2 truthy table: "" → false → deny.
        let r = expr_resolver("s");
        let ctx = ctx_with(&[("s", json!(""))]);
        let out = invoke(&r, &ctx).unwrap();
        assert_eq!(out.decision, ResolverDecision::Deny);
    }

    #[test]
    fn non_expression_kind_returns_none() {
        let r: Resolver = serde_yaml::from_str("kind: human\nprompt: \"go?\"\n").unwrap();
        assert!(invoke(&r, &ResolverContext::default()).is_none());
    }
}
