//! `kind: human` resolver — thin shim over `kind: tool` (§11.11),
//! plus an opt-in synchronous-handler path (§11.11.x extension).
//!
//! ## Default path: canonical MCP signal
//!
//! Per the design refactor, `kind: human` without `provider:` / `name:`
//! routes through the canonical-tool-call signal: a
//! `Resolver::Human { prompt, context, ... }` is dispatched through
//! the same `incident.resolution_needed` path as `kind: tool`, but with
//! the tool name hard-coded to [`tool_kind::ASK_HUMAN_TOOL_NAME`] (the
//! constant `"agent_shield.ask_human"`). The agent's LLM, when it sees
//! the deny verdict's `pending_resolution` field, calls that MCP tool
//! with the rendered prompt; the tool's `populated_by:` writes the
//! human's response into the variable; the agent retries the original
//! tool and the gate passes.
//!
//! ## Bundled / closure-based path: synchronous resolution
//!
//! YAML may set `provider:` (bundled implementation, e.g.
//! `auto_reject` / `console`) or `name:` (host-registered closure).
//! When set, the runtime looks up a registered [`HumanResolver`] in
//! the [`HumanRegistry`] threaded through [`ResolverDeps`] and calls
//! it synchronously, returning the [`ResolverResponse`] verbatim
//! (folded into [`DispatchOutcome::Resolved`] for the upstream
//! dispatcher). Hosts that want async / out-of-band approval flows
//! continue to use the canonical MCP path.
//!
//! Spec language is unchanged for the default case; the
//! `provider:` / `name:` extension is non-breaking and gated by the
//! presence of either field on the resolver.

use std::collections::HashMap;
use std::sync::{Arc, RwLock};

use serde_json::{Map, Value};

use super::super::event_bus::EventBus;
use super::super::resolver::{Resolver, ResolverDecision, ResolverResponse};
use super::super::variables::ResourceKind;
use super::context::{interpolate_prompt, ResolverContext};
use super::errors::ResolverRuntimeError;
use super::tool_kind::{
    self, evaluate_context_map, pseudo_request_id, DispatchOutcome, ToolLoopTracker,
};

// ── Synchronous handler surface ─────────────────────────────────────

/// Per-request payload delivered to a registered [`HumanResolver`].
/// Mirrors [`super::agent_kind::AgentResolveRequest`] in shape so
/// hosts can share helper code across `kind: human` and `kind: agent`.
#[derive(Debug, Clone)]
pub struct HumanResolveRequest {
    pub request_id: String,
    pub variable: Option<String>,
    pub resource_kind: Option<ResourceKind>,
    pub resource_name: Option<String>,
    pub resource_params: Option<Value>,
    pub invocation_hash: Option<String>,
    /// Cryptographically-unpredictable anti-replay token bound to this
    /// approval request (spec §11.0). Hosts MUST echo back the same
    /// value on the approval response; a mismatched or stale nonce
    /// MUST fail closed at the binding-check site. The runtime
    /// generates this via `uuid::Uuid::new_v4()`; do NOT substitute a
    /// uniqueness-only identifier here.
    pub approval_nonce: String,
    /// Session that issued this approval request (spec §11.0).
    /// Hosts that need to scope cached approval decisions to a session
    /// (e.g. the bundled `console` handler's `policy: always` cache)
    /// MUST key by this value rather than `request_id` — `request_id`
    /// is regenerated for every dispatch, so a request-id-keyed cache
    /// can never hit. `None` ⇒ legacy default session
    /// ([`crate::session_id::SessionId::default`]).
    pub session_id: Option<crate::session_id::SessionId>,
    /// Rendered prompt — `None` when the YAML omitted `prompt:`.
    /// Bundled handlers like `auto_reject` ignore the prompt;
    /// `console` falls back to a minimal synthesis.
    pub prompt: Option<String>,
    pub reason: Option<String>,
    pub context: Map<String, Value>,
    pub requested_key: Option<Value>,
    /// Optional per-resolver timeout (ms) carried over from
    /// [`Resolver::Human::timeout_ms`].
    pub timeout_ms: Option<u32>,
}

/// Synchronous handler registered for one provider name.
pub trait HumanResolver: Send + Sync {
    fn resolve(&self, req: HumanResolveRequest) -> ResolverResponse;
}

/// Closure-friendly adapter — same shape as
/// [`super::agent_kind::AgentResolverFn`].
pub struct HumanResolverFn<F>(pub F)
where
    F: Fn(HumanResolveRequest) -> ResolverResponse + Send + Sync;

impl<F> HumanResolver for HumanResolverFn<F>
where
    F: Fn(HumanResolveRequest) -> ResolverResponse + Send + Sync,
{
    fn resolve(&self, req: HumanResolveRequest) -> ResolverResponse {
        (self.0)(req)
    }
}

/// Registry of named [`HumanResolver`] implementations keyed by
/// `provider:` / `name:` from the YAML resolver. Construction is
/// thread-safe; lookups are read-only after construction.
#[derive(Default, Clone)]
pub struct HumanRegistry {
    inner: Arc<RwLock<HashMap<String, Arc<dyn HumanResolver>>>>,
}

impl HumanRegistry {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn register(&self, name: impl Into<String>, handler: Arc<dyn HumanResolver>) {
        self.inner.write().unwrap().insert(name.into(), handler);
    }

    pub fn lookup(&self, name: &str) -> Option<Arc<dyn HumanResolver>> {
        self.inner.read().unwrap().get(name).cloned()
    }

    pub fn is_empty(&self) -> bool {
        self.inner.read().unwrap().is_empty()
    }
}

impl std::fmt::Debug for HumanRegistry {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let names: Vec<String> = self.inner.read().unwrap().keys().cloned().collect();
        f.debug_struct("HumanRegistry")
            .field("registered", &names)
            .finish()
    }
}

// ── Dispatch ────────────────────────────────────────────────────────

/// Dispatch a `kind: human` resolver. Routes through a registered
/// [`HumanResolver`] when the YAML sets `provider:` / `name:`;
/// otherwise falls through to the canonical
/// [`tool_kind::ASK_HUMAN_TOOL_NAME`] MCP signal.
#[allow(clippy::too_many_arguments)]
pub fn invoke(
    resolver: &Resolver,
    ctx: &ResolverContext<'_>,
    variable_name: &str,
    tracker: &ToolLoopTracker,
    bus: &EventBus,
    retry_limit: u32,
    registry: Option<&HumanRegistry>,
) -> Result<DispatchOutcome, ResolverRuntimeError> {
    let (prompt_template, context_map, provider_name, timeout_ms) = match resolver {
        Resolver::Human {
            prompt,
            context,
            provider,
            name,
            timeout_ms,
            ..
        } => {
            let provider_name = provider.as_deref().or(name.as_deref());
            (
                prompt.as_deref(),
                context.as_ref(),
                provider_name,
                *timeout_ms,
            )
        }
        _ => {
            return Err(ResolverRuntimeError::Other {
                kind: "human",
                message: "invoke called with a non-human resolver".into(),
            })
        }
    };

    if let Some(name) = provider_name {
        return dispatch_registered(
            name,
            prompt_template,
            context_map,
            ctx,
            variable_name,
            registry,
            timeout_ms,
        );
    }

    tool_kind::dispatch_signal(
        tool_kind::ASK_HUMAN_TOOL_NAME,
        prompt_template,
        context_map,
        ctx,
        variable_name,
        tracker,
        bus,
        retry_limit,
        "human",
    )
}

#[allow(clippy::too_many_arguments)]
fn dispatch_registered(
    provider_name: &str,
    prompt_template: Option<&str>,
    context_map: Option<&HashMap<String, String>>,
    ctx: &ResolverContext<'_>,
    variable_name: &str,
    registry: Option<&HumanRegistry>,
    timeout_ms: Option<u32>,
) -> Result<DispatchOutcome, ResolverRuntimeError> {
    let prompt = match prompt_template {
        Some(template) => Some(interpolate_prompt(template, ctx).map_err(|e| {
            ResolverRuntimeError::InvalidResponse {
                kind: "human",
                message: format!("prompt interpolation failed: {:?}", e),
            }
        })?),
        None => None,
    };
    let context = context_map
        .map(|m| evaluate_context_map(Some(m), ctx))
        .unwrap_or_default();

    let req = HumanResolveRequest {
        request_id: ctx
            .request_id
            .clone()
            .unwrap_or_else(|| format!("req-{}", pseudo_request_id())),
        variable: Some(variable_name.to_string()),
        resource_kind: ctx.resource.as_ref().map(|r| r.kind),
        resource_name: ctx.resource.as_ref().map(|r| r.name.clone()),
        resource_params: ctx.invocation.map(|i| i.params.clone()),
        invocation_hash: ctx.invocation.map(|i| i.canonical_hash()),
        // §11.5.4 / §11.6 — `approval_nonce` is the anti-replay token a
        // host MUST echo back on the approval response. It is paired
        // with the invocation hash to bind the approval to the SAME
        // canonical invocation the runtime gated. The value MUST be
        // unpredictable so that an attacker who has observed prior
        // approvals (logs, side channels) cannot forge a nonce for a
        // pending request; we use a v4 UUID via the `uuid` crate, not
        // the timestamp+counter `pseudo_request_id()` used for opaque
        // request identifiers (which is uniqueness-only).
        approval_nonce: uuid::Uuid::new_v4().to_string(),
        session_id: ctx.session_id.clone(),
        prompt,
        reason: ctx.reason.clone(),
        context,
        requested_key: ctx.requested_key.clone(),
        timeout_ms,
    };

    let handler = match registry.and_then(|r| r.lookup(provider_name)) {
        Some(h) => h,
        None => {
            // Fail-closed: an unregistered provider name MUST NOT
            // silently fall through to the MCP path.
            log::warn!(
                target: "agent_shield::resolver_runtime",
                "kind: human — provider/name `{}` not registered (fail-closed deny)",
                provider_name
            );
            return Ok(DispatchOutcome::Resolved(ResolverResponse {
                decision: ResolverDecision::Deny,
                value: None,
                set_variables: HashMap::new(),
                reason: Some(format!(
                    "human-resolver `{}` not registered (fail-closed)",
                    provider_name
                )),
            }));
        }
    };

    Ok(DispatchOutcome::Resolved(handler.resolve(req)))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::events::EventId;
    use crate::populator::Invocation;
    use crate::resolver::Resolver;
    use serde_json::json;
    use std::collections::HashMap;

    fn human_resolver(yaml: &str) -> Resolver {
        serde_yaml::from_str(yaml).unwrap()
    }

    #[test]
    fn dispatches_through_canonical_tool_signal() {
        let bus = EventBus::new();
        let tr = ToolLoopTracker::new();
        let r = human_resolver("kind: human\nprompt: \"Authorize ${tool.params.amount}?\"\n");
        let inv = Invocation::tool("send", json!({"amount": 200}));
        let ctx = ResolverContext::default().with_invocation(&inv);

        let out = invoke(&r, &ctx, "send_authorized", &tr, &bus, 3, None).unwrap();
        match out {
            DispatchOutcome::Suspended {
                tool_name,
                prompt,
                kind,
                ..
            } => {
                assert_eq!(tool_name, tool_kind::ASK_HUMAN_TOOL_NAME);
                assert_eq!(prompt.as_deref(), Some("Authorize 200?"));
                assert_eq!(kind, "human");
            }
            other => panic!("expected Suspended, got {:?}", other),
        }
        let id = EventId::Incident {
            name: "resolution_needed".into(),
        };
        assert!(bus.fired_id(&id));
    }

    #[test]
    fn forbidden_env_namespace_in_prompt_errors() {
        let bus = EventBus::new();
        let tr = ToolLoopTracker::new();
        let r = human_resolver("kind: human\nprompt: \"k=${env.SECRET}\"\n");
        let ctx = ResolverContext::default();
        assert!(matches!(
            invoke(&r, &ctx, "v", &tr, &bus, 3, None),
            Err(ResolverRuntimeError::InvalidResponse { .. })
        ));
    }

    #[test]
    fn missing_invocation_field_in_prompt_errors() {
        let bus = EventBus::new();
        let tr = ToolLoopTracker::new();
        let r = human_resolver("kind: human\nprompt: \"amt=${tool.params.amount}\"\n");
        let inv = Invocation::tool("send", json!({}));
        let ctx = ResolverContext::default().with_invocation(&inv);
        assert!(matches!(
            invoke(&r, &ctx, "v", &tr, &bus, 3, None),
            Err(ResolverRuntimeError::InvalidResponse { .. })
        ));
    }

    #[test]
    fn evaluates_context_map() {
        let bus = EventBus::new();
        let tr = ToolLoopTracker::new();
        let r = human_resolver(
            "kind: human\nprompt: \"approve?\"\ncontext:\n  who: \"current_user\"\n  level: \"3 + 4\"\n",
        );
        let mut attrs = HashMap::new();
        attrs.insert("current_user".into(), json!("alice"));
        let ctx = ResolverContext::default().with_attrs(attrs);
        let _ = invoke(&r, &ctx, "v", &tr, &bus, 3, None).unwrap();
        // The context evaluation lives in the emitted incident payload;
        // verifying the round-trip belongs to the integration tests.
        let id = EventId::Incident {
            name: "resolution_needed".into(),
        };
        assert!(bus.fired_id(&id));
    }

    #[test]
    fn retry_limit_emits_resolution_loop_incident() {
        let bus = EventBus::new();
        let tr = ToolLoopTracker::new();
        let r = human_resolver("kind: human\nprompt: \"approve?\"\n");
        let ctx = ResolverContext::default();
        for _ in 0..=3 {
            let _ = invoke(&r, &ctx, "v", &tr, &bus, 3, None);
        }
        let id = EventId::Incident {
            name: "resolution_loop".into(),
        };
        assert!(bus.fired_id(&id));
    }

    // ── Registered-provider path ────────────────────────────────────

    /// §11.0 regression: the `approval_nonce` MUST be
    /// cryptographically unpredictable. Prior to the fix the runtime
    /// used `pseudo_request_id()` (timestamp_micros + relaxed
    /// counter), which is uniqueness-only and observable from prior
    /// approval logs. We now generate v4 UUIDs.
    ///
    /// This test asserts THREE properties:
    ///   1. Two consecutive nonces differ (uniqueness — necessary but
    ///      not sufficient for security).
    ///   2. Each nonce parses as a v4 UUID. A v4 UUID has version 4
    ///      in the 13th hex digit (`xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx`)
    ///      — the `uuid` crate enforces this on parse.
    ///   3. Neither nonce matches the legacy `pseudo_request_id`
    ///      shape (two hex tokens joined by `-`, where the second is
    ///      small). UUIDs have four `-` separators.
    #[test]
    fn approval_nonce_is_cryptographically_unpredictable() {
        let bus = EventBus::new();
        let tr = ToolLoopTracker::new();
        let captured: Arc<std::sync::Mutex<Vec<String>>> =
            Arc::new(std::sync::Mutex::new(Vec::new()));
        let captured_clone = Arc::clone(&captured);

        let registry = HumanRegistry::new();
        registry.register(
            "capture_nonce",
            Arc::new(HumanResolverFn(move |req: HumanResolveRequest| {
                captured_clone
                    .lock()
                    .unwrap()
                    .push(req.approval_nonce.clone());
                ResolverResponse {
                    decision: ResolverDecision::Allow,
                    value: Some(json!(true)),
                    set_variables: HashMap::new(),
                    reason: None,
                }
            })),
        );

        let r = human_resolver("kind: human\nprovider: \"capture_nonce\"\nprompt: \"approve?\"\n");
        for _ in 0..2 {
            let _ = invoke(
                &r,
                &ResolverContext::default(),
                "v",
                &tr,
                &bus,
                3,
                Some(&registry),
            )
            .unwrap();
        }

        let nonces = captured.lock().unwrap().clone();
        assert_eq!(nonces.len(), 2, "expected two captured nonces");
        assert_ne!(nonces[0], nonces[1], "consecutive nonces must differ");

        for (i, n) in nonces.iter().enumerate() {
            let parsed = uuid::Uuid::parse_str(n)
                .unwrap_or_else(|e| panic!("nonce {i} `{n}` is not a valid UUID: {e:?}"));
            assert_eq!(
                parsed.get_version_num(),
                4,
                "§11.0: approval_nonce must be a v4 UUID; got version {} for `{n}`",
                parsed.get_version_num()
            );

            // Defense in depth: the legacy `pseudo_request_id` shape was
            // exactly two hex tokens joined by a single `-`. UUIDs have
            // four `-` separators, so a stray regression to the old
            // generator would surface here even if the parse somehow
            // accepted the value.
            assert_eq!(
                n.matches('-').count(),
                4,
                "§11.0: approval_nonce must have UUID shape (4 dashes); got `{n}`"
            );
        }
    }

    #[test]
    fn registered_provider_dispatches_synchronously() {
        let bus = EventBus::new();
        let tr = ToolLoopTracker::new();
        let registry = HumanRegistry::new();
        registry.register(
            "auto_allow",
            Arc::new(HumanResolverFn(|_req: HumanResolveRequest| {
                ResolverResponse {
                    decision: ResolverDecision::Allow,
                    value: Some(json!(true)),
                    set_variables: HashMap::new(),
                    reason: None,
                }
            })),
        );

        let r = human_resolver("kind: human\nprovider: \"auto_allow\"\nprompt: \"approve?\"\n");
        let out = invoke(
            &r,
            &ResolverContext::default(),
            "v",
            &tr,
            &bus,
            3,
            Some(&registry),
        )
        .unwrap();
        match out {
            DispatchOutcome::Resolved(resp) => {
                assert_eq!(resp.decision, ResolverDecision::Allow);
            }
            other => panic!("expected Resolved, got {:?}", other),
        }
        // Critically: NO `resolution_needed` incident fired — the
        // synchronous path bypasses the MCP signal.
        let id = EventId::Incident {
            name: "resolution_needed".into(),
        };
        assert!(!bus.fired_id(&id));
    }

    #[test]
    fn name_field_aliases_provider() {
        let bus = EventBus::new();
        let tr = ToolLoopTracker::new();
        let registry = HumanRegistry::new();
        registry.register(
            "user_approval",
            Arc::new(HumanResolverFn(|_| ResolverResponse {
                decision: ResolverDecision::Deny,
                value: None,
                set_variables: HashMap::new(),
                reason: Some("policy".into()),
            })),
        );

        let r = human_resolver("kind: human\nname: \"user_approval\"\nprompt: \"approve?\"\n");
        let out = invoke(
            &r,
            &ResolverContext::default(),
            "v",
            &tr,
            &bus,
            3,
            Some(&registry),
        )
        .unwrap();
        match out {
            DispatchOutcome::Resolved(resp) => {
                assert_eq!(resp.decision, ResolverDecision::Deny);
                assert_eq!(resp.reason.as_deref(), Some("policy"));
            }
            other => panic!("expected Resolved, got {:?}", other),
        }
    }

    #[test]
    fn unregistered_provider_fails_closed() {
        let bus = EventBus::new();
        let tr = ToolLoopTracker::new();
        let registry = HumanRegistry::new();
        let r = human_resolver("kind: human\nprovider: \"missing\"\nprompt: \"approve?\"\n");
        let out = invoke(
            &r,
            &ResolverContext::default(),
            "v",
            &tr,
            &bus,
            3,
            Some(&registry),
        )
        .unwrap();
        match out {
            DispatchOutcome::Resolved(resp) => {
                assert_eq!(resp.decision, ResolverDecision::Deny);
                assert!(resp.reason.unwrap().contains("not registered"));
            }
            other => panic!("expected fail-closed Resolved deny, got {:?}", other),
        }
    }

    #[test]
    fn provider_and_name_both_set_rejected_at_parse() {
        // The custom Deserialize on Resolver enforces mutual
        // exclusion. Verify the error surfaces.
        let yaml = "kind: human\nprovider: \"console\"\nname: \"my_handler\"\nprompt: \"x\"\n";
        let r: Result<Resolver, _> = serde_yaml::from_str(yaml);
        assert!(r.is_err());
        assert!(format!("{}", r.unwrap_err()).contains("mutually exclusive"));
    }

    #[test]
    fn registered_provider_receives_request_payload() {
        use crate::populator::Invocation;

        let bus = EventBus::new();
        let tr = ToolLoopTracker::new();
        let registry = HumanRegistry::new();
        let captured: Arc<std::sync::Mutex<Option<HumanResolveRequest>>> =
            Arc::new(std::sync::Mutex::new(None));
        let captured_for_hook = captured.clone();
        registry.register(
            "capture",
            Arc::new(HumanResolverFn(move |req: HumanResolveRequest| {
                *captured_for_hook.lock().unwrap() = Some(req);
                ResolverResponse {
                    decision: ResolverDecision::Allow,
                    value: Some(json!(true)),
                    set_variables: HashMap::new(),
                    reason: None,
                }
            })),
        );

        let r = human_resolver(
            "kind: human\nprovider: \"capture\"\nprompt: \"approve ${tool.params.amount}?\"\n",
        );
        let inv = Invocation::tool("send", json!({"amount": 200}));
        let ctx = ResolverContext::default()
            .with_invocation(&inv)
            .with_reason("policy says so");

        let _ = invoke(&r, &ctx, "send_authorized", &tr, &bus, 3, Some(&registry)).unwrap();
        let cap = captured.lock().unwrap();
        let cap = cap.as_ref().unwrap();
        assert_eq!(cap.prompt.as_deref(), Some("approve 200?"));
        assert_eq!(cap.variable.as_deref(), Some("send_authorized"));
        assert_eq!(cap.reason.as_deref(), Some("policy says so"));
    }
}
