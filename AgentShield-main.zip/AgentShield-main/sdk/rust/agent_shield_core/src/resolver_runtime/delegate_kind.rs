//! `kind: delegate` resolver — cross-process / cross-protocol dispatch
//! routed through a `configurations[]` entry (§11.10.3, §11.12).
//!
//! The dispatcher in this module:
//!
//! 1. Looks up the configurations[] entry by id (fail-closed deny if
//!    missing).
//! 2. Validates the configuration's `type:` against the per-resolver
//!    routing matrix (§6.2 / §11.10).
//! 3. Builds a [`DelegateRequest`] carrying the resolved configuration
//!    plus the prompt / context / variable identity / lifetime hint.
//! 4. Hands the request to the host's [`DelegateDispatcher`]. The
//!    dispatcher is a single trait that switches internally on
//!    `configuration.type_` — or the host can register protocol-specific
//!    dispatchers behind the trait boundary.
//! 5. Returns the host's wire envelope verbatim, OR a `transport` /
//!    `invalid_response` error when the host bubbles one up.
//!
//! ## Transport scope
//!
//! This module does not implement HTTP / MCP / A2A wire transports.
//! Without a registered [`DelegateDispatcher`], a `kind: delegate`
//! resolver fails closed with `decision: deny` (§11.7 default). Hosts
//! register a real dispatcher via
//! [`super::super::runtime::builder::RuntimeBuilder::register_delegate_dispatcher`].
//!
//! Classifier desugaring per §11.12.4 IS implemented locally as a wrapper
//! around the host's HTTP dispatcher: the [`ClassifierWrapper`] takes a raw
//! score+threshold response and folds it into a wire envelope. Classifiers
//! that ship a registered provider can be wired through the
//! `delegate_dispatcher` trait directly.

use std::collections::HashMap;

use serde_json::Value;

use super::super::configurations::{ConfigurationType, ShieldConfiguration};
use super::super::resolver::{Resolver, ResolverDecision, ResolverResponse};
use super::super::variables::ResourceKind;
use super::context::{interpolate_prompt, ResolverContext};
use super::errors::ResolverRuntimeError;
use super::tool_kind::{evaluate_context_map, pseudo_request_id};

use crate::constants::delegate::{
    A2A_DEFAULT_TIMEOUT_MS, CLASSIFIER_DEFAULT_TIMEOUT_MS, HTTP_DEFAULT_TIMEOUT_MS,
    MCP_DEFAULT_TIMEOUT_MS,
};

/// One delegate dispatch request, fully marshaled. The dispatcher decides
/// whether to talk HTTP, MCP, A2A, or call a provider in-process based on
/// `configuration.config_type`.
#[derive(Debug, Clone)]
pub struct DelegateRequest {
    pub request_id: String,
    pub variable: Option<String>,
    pub configuration: ShieldConfiguration,
    /// Effective timeout in milliseconds — already merged across the
    /// resolver's `timeout_ms:`, the configuration's `timeout:`, and the
    /// per-kind default (§11.7).
    pub effective_timeout_ms: u32,
    pub resource_kind: Option<ResourceKind>,
    pub resource_name: Option<String>,
    pub prompt: Option<String>,
    pub reason: Option<String>,
    pub context: serde_json::Map<String, Value>,
    /// Raw `lifetime:` hint forwarded to the delegate per §11.12.1's
    /// request body. Stored as the original YAML node so the delegate can
    /// inspect bare/map forms uniformly.
    pub lifetime_hint: Option<serde_yaml::Value>,
    pub invocation_params: Option<Value>,
    /// §9.4 / §11.12.1: the key under which the delegate's response
    /// will be stored, when the target variable declares `key:`. `None`
    /// for non-keyed variables. The HTTP / MCP / A2A wire body
    /// surfaces this as `requested_key`.
    pub requested_key: Option<Value>,
}

/// Compute the effective timeout per §11.7's resolution order:
///   1. resolver's `timeout_ms:`
///   2. configuration's `timeout:`
///   3. per-kind default
pub fn effective_timeout(
    resolver_timeout_ms: Option<u32>,
    configuration: &ShieldConfiguration,
) -> u32 {
    if let Some(t) = resolver_timeout_ms {
        return t;
    }
    if let Some(t) = configuration.timeout {
        return t;
    }
    match configuration.config_type {
        ConfigurationType::HttpEndpoint => HTTP_DEFAULT_TIMEOUT_MS,
        ConfigurationType::McpServer => MCP_DEFAULT_TIMEOUT_MS,
        ConfigurationType::A2aAgent => A2A_DEFAULT_TIMEOUT_MS,
        ConfigurationType::Classifier => CLASSIFIER_DEFAULT_TIMEOUT_MS,
        // `llm` configuration is rare for `kind: delegate`; treat as HTTP.
        ConfigurationType::Llm => HTTP_DEFAULT_TIMEOUT_MS,
    }
}

/// Host integration trait. The host registers exactly one implementation;
/// the impl typically pattern-matches on `configuration.config_type` to
/// pick a transport.
pub trait DelegateDispatcher: Send + Sync {
    fn dispatch(&self, req: DelegateRequest) -> Result<ResolverResponse, ResolverRuntimeError>;
}

/// Look up the configuration by id, validate the type, and dispatch
/// through the registered [`DelegateDispatcher`].
pub fn invoke(
    resolver: &Resolver,
    ctx: &ResolverContext<'_>,
    variable_name: Option<&str>,
    configurations: &HashMap<String, ShieldConfiguration>,
    hook: Option<&dyn DelegateDispatcher>,
) -> Result<ResolverResponse, ResolverRuntimeError> {
    let (config_id, prompt_template, context_map, timeout_ms, lifetime) = match resolver {
        Resolver::Delegate {
            configuration,
            prompt,
            context,
            timeout_ms,
            lifetime,
            ..
        } => (
            configuration.as_str(),
            prompt.as_deref(),
            context.as_ref(),
            *timeout_ms,
            lifetime.as_ref(),
        ),
        _ => {
            return Err(ResolverRuntimeError::Other {
                kind: "delegate",
                message: "invoke called with a non-delegate resolver".into(),
            })
        }
    };

    let configuration = configurations
        .get(config_id)
        .cloned()
        .ok_or_else(|| ResolverRuntimeError::UnknownConfiguration(config_id.into()))?;

    // Type sanity check (defense in depth — §11.10's load-time check
    // should have caught this).
    if !matches!(
        configuration.config_type,
        ConfigurationType::HttpEndpoint
            | ConfigurationType::McpServer
            | ConfigurationType::A2aAgent
            | ConfigurationType::Classifier
            | ConfigurationType::Llm
    ) {
        return Err(ResolverRuntimeError::WrongConfigurationType {
            id: config_id.into(),
            actual: configuration.config_type.as_str().into(),
            expected: "http_endpoint|mcp_server|a2a_agent|classifier|llm".into(),
        });
    }

    // Optional prompt: §11.4a says delegates MAY omit a prompt; when
    // present we interpolate it. §11.4a also mandates that the
    // §11.12.1 request body's `"prompt"` is set to `null` (not
    // empty string) when omitted.
    let prompt = match prompt_template {
        Some(template) => Some(interpolate_prompt(template, ctx).map_err(|e| {
            ResolverRuntimeError::InvalidResponse {
                kind: "delegate",
                message: format!("prompt interpolation failed: {:?}", e),
            }
        })?),
        None => None,
    };

    let context = evaluate_context_map(context_map, ctx);

    let req = DelegateRequest {
        request_id: ctx
            .request_id
            .clone()
            .unwrap_or_else(|| format!("req-{}", pseudo_request_id())),
        variable: variable_name.map(str::to_owned),
        effective_timeout_ms: effective_timeout(timeout_ms, &configuration),
        configuration,
        resource_kind: ctx.resource.as_ref().map(|r| r.kind),
        resource_name: ctx.resource.as_ref().map(|r| r.name.clone()),
        prompt,
        reason: ctx.reason.clone(),
        context,
        // §11.12.1: the §11.10 wire body carries `lifetime`. Forward the
        // resolver's declared `lifetime:` (if any) as an opaque YAML
        // node so the dispatcher can mint per-call envelopes verbatim.
        lifetime_hint: lifetime.and_then(|l| serde_yaml::to_value(l).ok()),
        invocation_params: ctx.invocation.map(|i| i.params.clone()),
        requested_key: ctx.requested_key.clone(),
    };

    match hook {
        Some(h) => h.dispatch(req),
        None => {
            log::warn!(
                target: "agent_shield::resolver_runtime",
                "no DelegateDispatcher registered for `{}` — failing closed (deny)",
                config_id
            );
            Ok(ResolverResponse {
                decision: ResolverDecision::Deny,
                value: None,
                set_variables: HashMap::new(),
                reason: Some(format!(
                    "no delegate dispatcher registered for `{}` (fail-closed)",
                    config_id
                )),
            })
        }
    }
}

/// Helper for §11.12.4: fold a classifier's structured score into a wire
/// envelope. `score >= threshold` ⇒ `deny`, `score < threshold` ⇒ `allow`.
/// Hosts that ship a classifier delegate can call this from inside their
/// [`DelegateDispatcher::dispatch`] impl.
pub fn classifier_score_to_envelope(
    score: f64,
    threshold: f64,
    label: Option<&str>,
) -> ResolverResponse {
    let exceeds = score >= threshold;
    let reason = match label {
        Some(l) => format!("classifier label `{}` (score {:.4})", l, score),
        None => format!("classifier score {:.4}", score),
    };
    if exceeds {
        ResolverResponse {
            decision: ResolverDecision::Deny,
            value: Some(Value::Bool(false)),
            set_variables: HashMap::new(),
            reason: Some(reason),
        }
    } else {
        ResolverResponse {
            decision: ResolverDecision::Allow,
            value: Some(Value::Bool(true)),
            set_variables: HashMap::new(),
            reason: Some(reason),
        }
    }
}

/// Helper for the boolean classifier shape (§11.12.4 row 3): true → deny,
/// false → allow. Used by AACS-style providers that return a structured
/// `{contains_pii: true}` document.
pub fn classifier_bool_to_envelope(detected: bool, label: Option<&str>) -> ResolverResponse {
    let reason = match label {
        Some(l) => format!("classifier detection `{}`", l),
        None => "classifier detection".into(),
    };
    if detected {
        ResolverResponse {
            decision: ResolverDecision::Deny,
            value: Some(Value::Bool(false)),
            set_variables: HashMap::new(),
            reason: Some(reason),
        }
    } else {
        ResolverResponse {
            decision: ResolverDecision::Allow,
            value: Some(Value::Bool(true)),
            set_variables: HashMap::new(),
            reason: Some(reason),
        }
    }
}

/// Convenience adapter: turn a closure into a [`DelegateDispatcher`].
pub struct DelegateDispatcherFn<F>(pub F)
where
    F: Fn(DelegateRequest) -> Result<ResolverResponse, ResolverRuntimeError> + Send + Sync;

impl<F> DelegateDispatcher for DelegateDispatcherFn<F>
where
    F: Fn(DelegateRequest) -> Result<ResolverResponse, ResolverRuntimeError> + Send + Sync,
{
    fn dispatch(&self, req: DelegateRequest) -> Result<ResolverResponse, ResolverRuntimeError> {
        (self.0)(req)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    fn http_config() -> ShieldConfiguration {
        let yaml = "id: my-http\ntype: http_endpoint\nendpoint: \"https://example.invalid/x\"\n";
        serde_yaml::from_str(yaml).unwrap()
    }

    fn classifier_config() -> ShieldConfiguration {
        let yaml =
            "id: my-cls\ntype: classifier\nendpoint: \"https://cls.invalid\"\nthreshold: 0.5\n";
        serde_yaml::from_str(yaml).unwrap()
    }

    fn delegate_resolver(yaml: &str) -> Resolver {
        serde_yaml::from_str(yaml).unwrap()
    }

    fn registry(entries: Vec<ShieldConfiguration>) -> HashMap<String, ShieldConfiguration> {
        entries.into_iter().map(|c| (c.id.clone(), c)).collect()
    }

    #[test]
    fn unknown_configuration_errors() {
        let r = delegate_resolver("kind: delegate\nconfiguration: missing\n");
        let regs = registry(vec![]);
        let err = invoke(&r, &ResolverContext::default(), None, &regs, None).unwrap_err();
        assert!(matches!(err, ResolverRuntimeError::UnknownConfiguration(_)));
    }

    #[test]
    fn no_dispatcher_fails_closed() {
        let r = delegate_resolver("kind: delegate\nconfiguration: my-http\n");
        let regs = registry(vec![http_config()]);
        let resp = invoke(&r, &ResolverContext::default(), None, &regs, None).unwrap();
        assert_eq!(resp.decision, ResolverDecision::Deny);
    }

    #[test]
    fn dispatcher_receives_resolved_configuration() {
        let r = delegate_resolver("kind: delegate\nconfiguration: my-http\nprompt: \"approve?\"\n");
        let regs = registry(vec![http_config()]);
        let hook = DelegateDispatcherFn(|req| {
            assert_eq!(req.configuration.id, "my-http");
            assert_eq!(req.prompt.as_deref(), Some("approve?"));
            Ok(ResolverResponse {
                decision: ResolverDecision::Allow,
                value: Some(json!(true)),
                set_variables: HashMap::new(),
                reason: None,
            })
        });
        let resp = invoke(&r, &ResolverContext::default(), None, &regs, Some(&hook)).unwrap();
        assert_eq!(resp.decision, ResolverDecision::Allow);
    }

    #[test]
    fn dispatcher_can_propagate_invalid_response() {
        let r = delegate_resolver("kind: delegate\nconfiguration: my-http\n");
        let regs = registry(vec![http_config()]);
        let hook = DelegateDispatcherFn(|_| {
            Err(ResolverRuntimeError::InvalidResponse {
                kind: "delegate",
                message: "no decision".into(),
            })
        });
        let err = invoke(&r, &ResolverContext::default(), None, &regs, Some(&hook)).unwrap_err();
        assert_eq!(err.error_kind(), "invalid_response");
    }

    #[test]
    fn classifier_score_below_threshold_allows() {
        let env = classifier_score_to_envelope(0.2, 0.5, Some("safe"));
        assert_eq!(env.decision, ResolverDecision::Allow);
    }

    #[test]
    fn classifier_score_above_threshold_denies() {
        let env = classifier_score_to_envelope(0.8, 0.5, Some("hate"));
        assert_eq!(env.decision, ResolverDecision::Deny);
    }

    #[test]
    fn classifier_at_threshold_denies() {
        // §11.12.4: `score >= threshold` ⇒ deny.
        let env = classifier_score_to_envelope(0.5, 0.5, None);
        assert_eq!(env.decision, ResolverDecision::Deny);
    }

    #[test]
    fn classifier_bool_to_envelope_works() {
        assert_eq!(
            classifier_bool_to_envelope(true, Some("contains_pii")).decision,
            ResolverDecision::Deny
        );
        assert_eq!(
            classifier_bool_to_envelope(false, None).decision,
            ResolverDecision::Allow
        );
    }

    #[test]
    fn classifier_dispatch_via_hook() {
        let r = delegate_resolver("kind: delegate\nconfiguration: my-cls\n");
        let regs = registry(vec![classifier_config()]);
        let hook = DelegateDispatcherFn(|req| {
            // Pretend the classifier returned 0.8 with threshold 0.5.
            assert_eq!(req.configuration.config_type, ConfigurationType::Classifier);
            assert_eq!(req.configuration.threshold, Some(0.5));
            Ok(classifier_score_to_envelope(0.8, 0.5, Some("policy")))
        });
        let resp = invoke(&r, &ResolverContext::default(), None, &regs, Some(&hook)).unwrap();
        assert_eq!(resp.decision, ResolverDecision::Deny);
    }

    #[test]
    fn effective_timeout_resolver_overrides_config() {
        let mut cfg = http_config();
        cfg.timeout = Some(5000);
        assert_eq!(effective_timeout(Some(1000), &cfg), 1000);
    }

    #[test]
    fn effective_timeout_falls_back_to_config() {
        let mut cfg = http_config();
        cfg.timeout = Some(5000);
        assert_eq!(effective_timeout(None, &cfg), 5000);
    }

    #[test]
    fn effective_timeout_falls_back_to_default() {
        let cfg = http_config();
        assert_eq!(effective_timeout(None, &cfg), HTTP_DEFAULT_TIMEOUT_MS);
    }

    #[test]
    fn delegate_with_no_prompt_dispatches_with_none() {
        let r = delegate_resolver("kind: delegate\nconfiguration: my-http\n");
        let regs = registry(vec![http_config()]);
        let hook = DelegateDispatcherFn(|req| {
            assert!(req.prompt.is_none());
            Ok(ResolverResponse {
                decision: ResolverDecision::Allow,
                value: Some(json!(true)),
                set_variables: HashMap::new(),
                reason: None,
            })
        });
        let resp = invoke(&r, &ResolverContext::default(), None, &regs, Some(&hook)).unwrap();
        assert_eq!(resp.decision, ResolverDecision::Allow);
    }

    #[test]
    fn timeout_error_propagates() {
        let r = delegate_resolver("kind: delegate\nconfiguration: my-http\n");
        let regs = registry(vec![http_config()]);
        let hook = DelegateDispatcherFn(|_| {
            Err(ResolverRuntimeError::Timeout {
                kind: "delegate",
                timeout_ms: 30000,
            })
        });
        let err = invoke(&r, &ResolverContext::default(), None, &regs, Some(&hook)).unwrap_err();
        assert_eq!(err.error_kind(), "timeout");
    }
}
