//! Resolver invocation lifecycle state machine (§11 — host bridge spec).
//!
//! Centralises everything that's the same across the three host-language
//! scheduling shells (Python / asyncio, Node / napi-rs, .NET / Task) so
//! every resolver invocation reaches **exactly one core-visible terminal
//! state**. Per the architecture review:
//!
//! * Shared in core: request IDs, lifecycle, terminal-state validation,
//!   late-completion handling, cancellation races, timeout enforcement,
//!   shutdown semantics, error normalisation.
//! * Per-language native shell, minimal: submit to host runtime,
//!   complete back into Rust, best-effort cancel signal, shutdown / drop.
//!
//! Key correctness invariant: **core-visible cancellation is
//! authoritative; host-callback cancellation is best-effort.** A host
//! resolver that completes after the manager has already moved an
//! invocation to a cancelled / timed-out / abandoned terminal is silently
//! ignored — the core never sees a terminal flip.
//!
//! The manager is intentionally agnostic to the resolver kind. Callers
//! parameterise it with whatever response type their dispatch produces;
//! the manager only owns the lifecycle around it.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use std::time::Duration;

use tokio::sync::oneshot;
use uuid::Uuid;

// ───────────────────────────────────────────────────────────────────────
// Identifiers
// ───────────────────────────────────────────────────────────────────────

/// Per-invocation identifier. UUID v4 as a string so it round-trips
/// through every language binding cleanly.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct InvocationId(pub String);

impl InvocationId {
    pub fn new() -> Self {
        Self(Uuid::new_v4().to_string())
    }

    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl Default for InvocationId {
    fn default() -> Self {
        Self::new()
    }
}

impl std::fmt::Display for InvocationId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(&self.0)
    }
}

// ───────────────────────────────────────────────────────────────────────
// State machine
// ───────────────────────────────────────────────────────────────────────

/// Lifecycle state of a single resolver invocation. Transitions are
/// strictly forward — once a terminal state is reached, the invocation
/// is finalised and any subsequent signal is dropped.
#[derive(Debug, Clone, PartialEq)]
pub enum InvocationState {
    /// Newly created, not yet handed to the host shell.
    Created,
    /// Handed to the host shell (e.g. the Python bridge has scheduled
    /// the coroutine on its event loop).
    Submitted,
    /// The host has begun executing the resolver (e.g. tokio future is
    /// being polled). Some shells skip this state; it's optional.
    InFlight,
    /// Terminal: host returned a normal response.
    Completed,
    /// Terminal: host raised an error / panic / native fault that was
    /// normalised into a resolver-level failure.
    Failed,
    /// Terminal: core cancelled the invocation (cancellation token).
    /// The host callback may still complete later but its result is
    /// dropped.
    Cancelled,
    /// Terminal: the manager-enforced timeout fired before the host
    /// completed.
    TimedOut,
    /// Terminal: the manager was shut down while the invocation was
    /// pending.
    Abandoned,
}

impl InvocationState {
    /// True iff this is a terminal state — no further transitions
    /// permitted.
    pub fn is_terminal(&self) -> bool {
        matches!(
            self,
            InvocationState::Completed
                | InvocationState::Failed
                | InvocationState::Cancelled
                | InvocationState::TimedOut
                | InvocationState::Abandoned
        )
    }
}

// ───────────────────────────────────────────────────────────────────────
// Reasons surfaced through cancellation / shutdown
// ───────────────────────────────────────────────────────────────────────

/// Why a cancellation was requested. Surfaced through observability and
/// — best-effort — to the host's cancellation primitive.
#[derive(Debug, Clone, PartialEq)]
pub enum CancelReason {
    /// Caller invoked `cancel()` explicitly.
    HostCancelled,
    /// Upstream context (turn, request, session) was cancelled.
    ContextCancelled,
    /// Manager-level shutdown.
    ManagerShutdown,
    /// Free-form reason, recorded as-is.
    Other(String),
}

/// Why the manager is shutting down.
#[derive(Debug, Clone, PartialEq)]
pub enum ShutdownReason {
    GracefulStop,
    Drop,
    Other(String),
}

// ───────────────────────────────────────────────────────────────────────
// Terminal outcome
// ───────────────────────────────────────────────────────────────────────

/// Manager-visible outcome of an invocation. Exactly one of these is
/// delivered to the awaiting caller via the
/// [`InvocationCompletion`] handle.
#[derive(Debug, Clone, PartialEq)]
pub enum InvocationTerminal<R, E> {
    /// Host produced a normal response.
    Completed(R),
    /// Host produced an error / failure.
    Failed(E),
    /// Core cancelled the invocation. The carrier's response (if any)
    /// is discarded.
    Cancelled(CancelReason),
    /// Manager-enforced timeout fired before the host completed.
    TimedOut(Duration),
    /// The manager was shut down while the invocation was pending.
    Abandoned(ShutdownReason),
}

// ───────────────────────────────────────────────────────────────────────
// Manager
// ───────────────────────────────────────────────────────────────────────

/// Per-invocation registry entry.
struct PendingEntry<R, E> {
    state: InvocationState,
    /// Once-only sender for the terminal outcome. Wrapped in `Option`
    /// so we can take ownership when delivering the terminal.
    completion_tx: Option<oneshot::Sender<InvocationTerminal<R, E>>>,
}

/// Shared resolver invocation lifecycle manager.
///
/// Holds the registry of pending invocations and enforces:
///
/// * each invocation reaches exactly one terminal,
/// * late completions after a terminal are dropped,
/// * cancellation / timeout / shutdown all race correctly (first wins),
/// * pending entries are cleaned up at finalisation.
///
/// Send + Sync; designed to be wrapped in an `Arc` and shared across
/// language-bridge worker threads.
pub struct ResolverInvocationManager<R, E>
where
    R: Send + 'static,
    E: Send + 'static,
{
    pending: Mutex<HashMap<InvocationId, PendingEntry<R, E>>>,
    /// Latest stats. Useful for metrics and tests.
    stats: Mutex<InvocationStats>,
    /// True once the manager has been shut down.
    shut_down: Mutex<Option<ShutdownReason>>,
}

#[derive(Debug, Clone, Default, PartialEq)]
pub struct InvocationStats {
    pub submitted: u64,
    pub completed: u64,
    pub failed: u64,
    pub cancelled: u64,
    pub timed_out: u64,
    pub abandoned: u64,
    pub late_completions_dropped: u64,
}

/// Awaitable handle for the caller to await the invocation's terminal.
pub struct InvocationCompletion<R, E> {
    rx: oneshot::Receiver<InvocationTerminal<R, E>>,
}

impl<R, E> InvocationCompletion<R, E> {
    /// Await the terminal state. Returns `None` only if the manager
    /// dropped the sender without delivering — a programming error
    /// internal to the manager that the caller should treat as
    /// `Abandoned(Drop)`.
    pub async fn await_terminal(self) -> InvocationTerminal<R, E> {
        match self.rx.await {
            Ok(t) => t,
            Err(_) => InvocationTerminal::Abandoned(ShutdownReason::Drop),
        }
    }
}

impl<R, E> ResolverInvocationManager<R, E>
where
    R: Send + 'static,
    E: Send + 'static,
{
    pub fn new() -> Self {
        Self {
            pending: Mutex::new(HashMap::new()),
            stats: Mutex::new(InvocationStats::default()),
            shut_down: Mutex::new(None),
        }
    }

    /// Submit a new invocation. Returns the assigned id and a
    /// [`InvocationCompletion`] handle the caller awaits for the
    /// terminal outcome.
    ///
    /// Returns `None` if the manager is already shut down.
    pub fn submit(&self) -> Option<(InvocationId, InvocationCompletion<R, E>)> {
        // Refuse new invocations if shut down.
        {
            let s = self.shut_down.lock().unwrap();
            if s.is_some() {
                return None;
            }
        }

        let id = InvocationId::new();
        let (tx, rx) = oneshot::channel();
        {
            let mut pending = self.pending.lock().unwrap();
            pending.insert(
                id.clone(),
                PendingEntry {
                    state: InvocationState::Submitted,
                    completion_tx: Some(tx),
                },
            );
        }
        {
            let mut stats = self.stats.lock().unwrap();
            stats.submitted += 1;
        }
        Some((id, InvocationCompletion { rx }))
    }

    /// Mark the invocation as in-flight (the host has begun executing
    /// it). Optional — bridges that don't know when execution actually
    /// starts may skip this transition.
    pub fn mark_in_flight(&self, id: &InvocationId) -> bool {
        let mut pending = self.pending.lock().unwrap();
        if let Some(entry) = pending.get_mut(id) {
            if !entry.state.is_terminal() {
                entry.state = InvocationState::InFlight;
                return true;
            }
        }
        false
    }

    /// Deliver a normal completion. If the invocation has already
    /// reached a terminal (cancellation / timeout / shutdown), the
    /// response is silently dropped and `false` is returned. Otherwise
    /// the terminal is delivered and `true` is returned.
    pub fn complete(&self, id: &InvocationId, response: R) -> bool {
        self.finalise(
            id,
            |entry| {
                let tx = entry.completion_tx.take();
                let _ = tx.map(|tx| tx.send(InvocationTerminal::Completed(response)));
                entry.state = InvocationState::Completed;
            },
            |stats| stats.completed += 1,
            |stats| stats.late_completions_dropped += 1,
        )
    }

    /// Deliver a failure terminal.
    pub fn fail(&self, id: &InvocationId, error: E) -> bool {
        self.finalise(
            id,
            |entry| {
                let tx = entry.completion_tx.take();
                let _ = tx.map(|tx| tx.send(InvocationTerminal::Failed(error)));
                entry.state = InvocationState::Failed;
            },
            |stats| stats.failed += 1,
            |stats| stats.late_completions_dropped += 1,
        )
    }

    /// Cancel an invocation. Core-visible cancellation is authoritative
    /// — once this returns `true`, the awaiting caller will observe a
    /// `Cancelled` terminal even if the host shell later delivers a
    /// completion.
    pub fn cancel(&self, id: &InvocationId, reason: CancelReason) -> bool {
        self.finalise(
            id,
            |entry| {
                let tx = entry.completion_tx.take();
                let _ = tx.map(|tx| tx.send(InvocationTerminal::Cancelled(reason.clone())));
                entry.state = InvocationState::Cancelled;
            },
            |stats| stats.cancelled += 1,
            |_| { /* second-cancel: not a stat. */ },
        )
    }

    /// Time-out an invocation. Equivalent to `cancel` but recorded
    /// separately for metrics.
    pub fn time_out(&self, id: &InvocationId, elapsed: Duration) -> bool {
        self.finalise(
            id,
            |entry| {
                let tx = entry.completion_tx.take();
                let _ = tx.map(|tx| tx.send(InvocationTerminal::TimedOut(elapsed)));
                entry.state = InvocationState::TimedOut;
            },
            |stats| stats.timed_out += 1,
            |_| {},
        )
    }

    /// Mark the manager as shut down, abandoning every pending
    /// invocation. Delivers `Abandoned(reason)` to each pending
    /// completion. Future `submit()` calls return `None`.
    pub fn shutdown(&self, reason: ShutdownReason) {
        {
            let mut s = self.shut_down.lock().unwrap();
            if s.is_some() {
                return;
            }
            *s = Some(reason.clone());
        }
        let mut pending = self.pending.lock().unwrap();
        let mut stats = self.stats.lock().unwrap();
        for (_, mut entry) in pending.drain() {
            if !entry.state.is_terminal() {
                let tx = entry.completion_tx.take();
                let _ = tx.map(|tx| tx.send(InvocationTerminal::Abandoned(reason.clone())));
                stats.abandoned += 1;
            }
        }
    }

    /// Snapshot of the current statistics.
    pub fn stats(&self) -> InvocationStats {
        self.stats.lock().unwrap().clone()
    }

    /// Current state of an invocation, or `None` if it has been
    /// finalised and removed from the registry.
    pub fn state(&self, id: &InvocationId) -> Option<InvocationState> {
        self.pending
            .lock()
            .unwrap()
            .get(id)
            .map(|entry| entry.state.clone())
    }

    /// Number of pending invocations (those NOT yet in a terminal
    /// state). Terminal entries are kept in the registry for
    /// observability; this count excludes them.
    pub fn pending_count(&self) -> usize {
        self.pending
            .lock()
            .unwrap()
            .values()
            .filter(|entry| !entry.state.is_terminal())
            .count()
    }

    /// Total number of registry entries, including terminal ones.
    pub fn registry_size(&self) -> usize {
        self.pending.lock().unwrap().len()
    }

    /// Drop the registry entry for an already-terminal invocation.
    /// Returns true if an entry was removed.
    pub fn forget(&self, id: &InvocationId) -> bool {
        let mut pending = self.pending.lock().unwrap();
        match pending.get(id).map(|e| e.state.is_terminal()) {
            Some(true) => {
                pending.remove(id);
                true
            }
            _ => false,
        }
    }

    // ── Internal helpers ────────────────────────────────────────

    fn finalise<F, FStat, FStatLate>(
        &self,
        id: &InvocationId,
        on_finalise: F,
        on_first_terminal: FStat,
        on_late_attempt: FStatLate,
    ) -> bool
    where
        F: FnOnce(&mut PendingEntry<R, E>),
        FStat: FnOnce(&mut InvocationStats),
        FStatLate: FnOnce(&mut InvocationStats),
    {
        let mut pending = self.pending.lock().unwrap();
        if let Some(entry) = pending.get_mut(id) {
            if entry.state.is_terminal() {
                // Already finalised by a competing signal — drop.
                let mut stats = self.stats.lock().unwrap();
                on_late_attempt(&mut stats);
                false
            } else {
                on_finalise(entry);
                let mut stats = self.stats.lock().unwrap();
                on_first_terminal(&mut stats);
                true
            }
        } else {
            // Unknown id — counted as late.
            let mut stats = self.stats.lock().unwrap();
            on_late_attempt(&mut stats);
            false
        }
    }
}

impl<R, E> Default for ResolverInvocationManager<R, E>
where
    R: Send + 'static,
    E: Send + 'static,
{
    fn default() -> Self {
        Self::new()
    }
}

// ───────────────────────────────────────────────────────────────────────
// Host bridge contract (§11 — implemented per language)
// ───────────────────────────────────────────────────────────────────────

/// Contract every native scheduling shell implements.
///
/// The shell takes a request, schedules it onto its host runtime
/// (asyncio loop / Node event loop / .NET Task scheduler), and reports
/// back to the manager via `complete` / `fail` / `mark_in_flight`. The
/// shell is also responsible for propagating cancel/shutdown signals
/// best-effort to its host runtime.
///
/// The trait is intentionally minimal — everything that has the same
/// shape across hosts (lifecycle state, registry, terminal-state
/// validation) lives in [`ResolverInvocationManager`]. The shell only
/// owns the host-runtime-specific scheduling shell.
pub trait HostResolverBridge<Req, R, E>: Send + Sync
where
    R: Send + 'static,
    E: Send + 'static,
{
    /// Schedule the request onto the host runtime. The bridge MUST
    /// eventually call `manager.complete(id, …)` or
    /// `manager.fail(id, …)` (subject to cancellation / shutdown).
    ///
    /// Returns the assigned `InvocationId` so the caller can await its
    /// terminal via the completion handle returned from
    /// [`ResolverInvocationManager::submit`].
    fn submit(&self, manager: &Arc<ResolverInvocationManager<R, E>>, request: Req) -> InvocationId;

    /// Best-effort signal to the host runtime that an invocation has
    /// been cancelled. Implementations may translate this into an
    /// `AbortSignal` / `CancellationToken` / `asyncio.cancel()`. It is
    /// understood that the host callback may still complete after this
    /// signal — the manager makes the core-visible terminal
    /// authoritative regardless.
    fn request_cancel(&self, id: &InvocationId, reason: CancelReason);

    /// Stop processing new invocations and cancel the existing host
    /// schedules. After this returns, the bridge must not call
    /// `complete` / `fail` on the manager for new ids.
    fn shutdown(&self, reason: ShutdownReason);
}

// ───────────────────────────────────────────────────────────────────────
// Tests
// ───────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    type Mgr = ResolverInvocationManager<String, String>;

    fn submit(mgr: &Mgr) -> (InvocationId, InvocationCompletion<String, String>) {
        mgr.submit().expect("submit returned None")
    }

    #[tokio::test]
    async fn complete_delivers_terminal() {
        let mgr = Mgr::new();
        let (id, completion) = submit(&mgr);
        assert_eq!(mgr.state(&id), Some(InvocationState::Submitted));
        assert!(mgr.complete(&id, "ok".into()));
        assert!(matches!(
            completion.await_terminal().await,
            InvocationTerminal::Completed(s) if s == "ok"
        ));
        assert_eq!(mgr.stats().completed, 1);
    }

    #[tokio::test]
    async fn double_complete_dropped() {
        let mgr = Mgr::new();
        let (id, completion) = submit(&mgr);
        assert!(mgr.complete(&id, "first".into()));
        assert!(!mgr.complete(&id, "second".into()));
        assert!(matches!(
            completion.await_terminal().await,
            InvocationTerminal::Completed(s) if s == "first"
        ));
        let stats = mgr.stats();
        assert_eq!(stats.completed, 1);
        assert_eq!(stats.late_completions_dropped, 1);
    }

    #[tokio::test]
    async fn cancel_wins_against_late_complete() {
        let mgr = Mgr::new();
        let (id, completion) = submit(&mgr);
        assert!(mgr.cancel(&id, CancelReason::HostCancelled));
        // Host shell completes after cancel — silently dropped.
        assert!(!mgr.complete(&id, "host result".into()));
        assert!(matches!(
            completion.await_terminal().await,
            InvocationTerminal::Cancelled(CancelReason::HostCancelled)
        ));
        let stats = mgr.stats();
        assert_eq!(stats.cancelled, 1);
        assert_eq!(stats.completed, 0);
        assert_eq!(stats.late_completions_dropped, 1);
    }

    #[tokio::test]
    async fn timeout_wins_against_late_complete() {
        let mgr = Mgr::new();
        let (id, completion) = submit(&mgr);
        assert!(mgr.time_out(&id, Duration::from_millis(100)));
        assert!(!mgr.complete(&id, "late".into()));
        assert!(matches!(
            completion.await_terminal().await,
            InvocationTerminal::TimedOut(_)
        ));
        let stats = mgr.stats();
        assert_eq!(stats.timed_out, 1);
        assert_eq!(stats.late_completions_dropped, 1);
    }

    #[tokio::test]
    async fn fail_delivers_failed_terminal() {
        let mgr = Mgr::new();
        let (id, completion) = submit(&mgr);
        assert!(mgr.fail(&id, "host panic".into()));
        assert!(matches!(
            completion.await_terminal().await,
            InvocationTerminal::Failed(s) if s == "host panic"
        ));
        assert_eq!(mgr.stats().failed, 1);
    }

    #[tokio::test]
    async fn shutdown_abandons_pending_invocations() {
        let mgr = Mgr::new();
        let (_id1, c1) = submit(&mgr);
        let (_id2, c2) = submit(&mgr);
        mgr.shutdown(ShutdownReason::GracefulStop);

        for c in [c1, c2] {
            assert!(matches!(
                c.await_terminal().await,
                InvocationTerminal::Abandoned(ShutdownReason::GracefulStop)
            ));
        }
        let stats = mgr.stats();
        assert_eq!(stats.abandoned, 2);
        // Subsequent submit returns None — manager is shut down.
        assert!(mgr.submit().is_none());
    }

    #[tokio::test]
    async fn mark_in_flight_transitions_state() {
        let mgr = Mgr::new();
        let (id, _completion) = submit(&mgr);
        assert!(mgr.mark_in_flight(&id));
        assert_eq!(mgr.state(&id), Some(InvocationState::InFlight));
        // Once terminal, mark_in_flight returns false.
        assert!(mgr.complete(&id, "ok".into()));
        assert!(!mgr.mark_in_flight(&id));
    }

    #[tokio::test]
    async fn unknown_id_complete_returns_false() {
        let mgr = Mgr::new();
        let bogus = InvocationId::new();
        assert!(!mgr.complete(&bogus, "ok".into()));
        assert_eq!(mgr.stats().late_completions_dropped, 1);
    }

    #[tokio::test]
    async fn cancel_then_cancel_idempotent() {
        let mgr = Mgr::new();
        let (id, completion) = submit(&mgr);
        assert!(mgr.cancel(&id, CancelReason::HostCancelled));
        // Second cancel returns false (already terminal) without
        // panicking.
        assert!(!mgr.cancel(&id, CancelReason::ContextCancelled));
        assert!(matches!(
            completion.await_terminal().await,
            InvocationTerminal::Cancelled(CancelReason::HostCancelled)
        ));
        // Stats record exactly one cancellation.
        assert_eq!(mgr.stats().cancelled, 1);
    }

    #[tokio::test]
    async fn invocation_id_is_unique() {
        let mgr = Mgr::new();
        let (id1, _c1) = submit(&mgr);
        let (id2, _c2) = submit(&mgr);
        assert_ne!(id1, id2);
    }

    #[tokio::test]
    async fn pending_count_tracks_lifecycle() {
        let mgr = Mgr::new();
        let (id, _completion) = submit(&mgr);
        assert_eq!(mgr.pending_count(), 1);
        mgr.complete(&id, "ok".into());
        // After terminal: pending_count drops to 0; state() still
        // observable until forget().
        assert_eq!(mgr.pending_count(), 0);
        assert!(mgr.state(&id).map_or(false, |s| s.is_terminal()));
        assert!(mgr.forget(&id));
        assert!(mgr.state(&id).is_none());
    }

    #[test]
    fn invocation_state_is_terminal_classification() {
        assert!(!InvocationState::Created.is_terminal());
        assert!(!InvocationState::Submitted.is_terminal());
        assert!(!InvocationState::InFlight.is_terminal());
        assert!(InvocationState::Completed.is_terminal());
        assert!(InvocationState::Failed.is_terminal());
        assert!(InvocationState::Cancelled.is_terminal());
        assert!(InvocationState::TimedOut.is_terminal());
        assert!(InvocationState::Abandoned.is_terminal());
    }
}
