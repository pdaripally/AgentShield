//! `kind: tool` resolver — signal-and-suspend (§11.10.2).
//!
//! The runtime MUST NOT invoke the tool. It emits a `resolution_needed`
//! signal naming the tool and target variable; the calling agent is
//! expected to call the tool, whose `populated_by:` then fills the
//! variable. The next gate evaluation succeeds because the variable is
//! now `@status == 'resolved'` and auto-resolution is bypassed.
//!
//! ## Wire format for `resolution_needed`
//!
//! §11.10.2 describes the contract ("emit a signal naming the tool and
//! target variable") but does not pin a wire format. We carry the
//! signal as an `incident.resolution_needed` event on the
//! [`super::super::event_bus::EventBus`] with this JSON payload shape:
//!
//! ```json
//! {
//!   "request_id": "<uuid-like>",
//!   "variable": "<target variable name>",
//!   "tool_name": "<name from the kind: tool resolver>",
//!   "prompt": "<interpolated, optional>",
//!   "reason": "<triggering evaluate_when reason, optional>",
//!   "context": { ... },
//!   "attempt": 1
//! }
//! ```
//!
//! Hosts subscribe to the bus to surface the signal to the agent. Hosts that
//! prefer a side-channel can register an [`super::super::event_bus::EventBus`]
//! subscriber that filters for `incident.resolution_needed` payloads.
//!
//! ## Loop bound (§11.10.2)
//!
//! - The default retry limit is `3` attempts within a single turn for the
//!   same `(turn_id, variable, tool_name)` tuple.
//! - On exceeding the limit, the dispatcher emits
//!   `incident.resolution_loop` and treats the resolution as `Cancelled`.
//! - After a `Cancelled` outcome, the same `(turn_id, variable)` is
//!   suppressed for the rest of the turn — subsequent reads MUST NOT
//!   re-fire the tool resolver.
//!
//! ## DispatchOutcome
//!
//! The wire envelope only has `Allow|Deny|Cancelled`. Tool dispatch
//! introduces a third internal-only state: `Suspended`. The dispatcher
//! returns [`DispatchOutcome::Suspended`] from `resolve()` when the
//! resolver fired a fresh `resolution_needed` signal and is waiting for
//! the agent to call the tool. For external auto-resolution callers, this
//! presents as `None` and the gate fails closed for the current
//! evaluation. The next read after the tool actually executes (and
//! `populated_by:` writes have applied) sees the variable as `resolved`
//! and bypasses the resolver runtime entirely.

use std::collections::{HashMap, HashSet};
use std::sync::Mutex;

use serde_json::{Map, Value};

use crate::expressions::eval::{evaluate_to_value, EvalContext};

use super::super::event_bus::EventBus;
use super::super::resolver::{Resolver, ResolverDecision, ResolverResponse};
use super::context::{interpolate_prompt, ResolverContext};
use super::errors::ResolverRuntimeError;

pub use crate::constants::resolver::DEFAULT_TOOL_RETRY_LIMIT;

/// Canonical MCP tool name the runtime synthesises for `kind: human`
/// resolvers. The host registers a tool under this exact name (typically
/// via an MCP server like the one in `examples/tools/ask-human-mcp-server/`).
/// The agent's LLM, when it sees a `pending_resolution` deny that names
/// this tool, calls it with the rendered prompt; the tool's
/// `populated_by:` writes the human's response into the variable.
pub const ASK_HUMAN_TOOL_NAME: &str = "agent_shield.ask_human";

/// Internal dispatch outcome for tool resolvers. Other kinds always return
/// `Completed` or — for `kind: human` with `provider:`/`name:` — `Resolved`.
#[derive(Debug, Clone)]
pub enum DispatchOutcome {
    /// The resolver produced a wire envelope (allow/deny/cancelled).
    Completed(ResolverResponse),
    /// A `kind: human` resolver with `provider:` / `name:` set
    /// dispatched synchronously through a registered
    /// [`super::human_kind::HumanResolver`] and produced a
    /// [`ResolverResponse`] without going through the canonical MCP
    /// signal. Semantically identical to `Completed` for the upstream
    /// dispatcher; carried as a separate variant so subscribers that
    /// distinguish "agent-mediated" from "host-mediated" outcomes can
    /// pattern-match.
    Resolved(ResolverResponse),
    /// `kind: tool` (or the synthesised `kind: human` shim) fired
    /// `resolution_needed` and is waiting for the agent to call the tool.
    /// The auto-resolution caller surfaces this as `None` for the value
    /// channel and as a `PendingResolution` on the side channel.
    Suspended {
        /// Same `request_id` that was emitted on the bus payload.
        request_id: String,
        /// Tool the agent must call. For `kind: tool` this is the
        /// resolver's `name:`; for `kind: human` it's the canonical
        /// [`ASK_HUMAN_TOOL_NAME`].
        tool_name: String,
        /// Interpolated prompt (`None` when the resolver omitted one;
        /// `kind: human` always carries one because the YAML schema
        /// requires it).
        prompt: Option<String>,
        /// Originating resolver kind: `"tool"` or `"human"`.
        kind: &'static str,
    },
}

/// Evaluate each entry of a resolver's `context:` map per §11.4 and
/// §11.10. Each value is a single-line expression that MUST NOT trigger
/// auto-resolution (per §11.5 — `context:` is not a gating site).
pub(super) fn evaluate_context_map(
    map: Option<&HashMap<String, String>>,
    ctx: &ResolverContext<'_>,
) -> Map<String, Value> {
    let mut out = Map::new();
    let Some(map) = map else { return out };
    let eval_ctx = EvalContext {
        attrs: &ctx.attrs,
        is_gating_site: false,
        ..EvalContext::from_attrs(&ctx.attrs)
    };
    for (k, expr) in map {
        match evaluate_to_value(expr, &eval_ctx) {
            Some(v) => {
                out.insert(k.clone(), v);
            }
            None => {
                log::warn!(
                    target: "agent_shield::resolver_runtime",
                    "resolver context: failed to evaluate `{}` for key `{}`",
                    expr,
                    k
                );
                out.insert(k.clone(), Value::Null);
            }
        }
    }
    out
}

/// Cheap pseudo-uuid (timestamp + counter) used for OPAQUE request
/// identifiers (`request_id` fields on resolver wire envelopes). It is
/// uniqueness-only — DO NOT use this for security-sensitive values
/// such as approval nonces or anti-replay tokens. For nonces, use
/// `uuid::Uuid::new_v4().to_string()` so the value is
/// cryptographically unpredictable.
///
/// Hosts that want strict UUIDs for `request_id` override the field
/// themselves on the resolver context.
pub(super) fn pseudo_request_id() -> String {
    use std::sync::atomic::{AtomicU64, Ordering};
    static COUNTER: AtomicU64 = AtomicU64::new(1);
    let n = COUNTER.fetch_add(1, Ordering::Relaxed);
    let now = chrono::Utc::now().timestamp_micros();
    format!("{:x}-{:x}", now, n)
}

/// Per-turn loop tracker. Keyed by `(turn_id, variable, tool_name)`.
#[derive(Debug, Default)]
pub struct ToolLoopTracker {
    state: Mutex<TrackerInner>,
}

#[derive(Debug, Default)]
struct TrackerInner {
    /// Attempt counter per (turn, variable, tool).
    attempts: HashMap<(u64, String, String), u32>,
    /// Suppressed (turn, variable) tuples — set after a `Cancelled` outcome
    /// per §11.10.2 same-turn suppression.
    suppressed: HashSet<(u64, String)>,
    /// Current turn id; advanced via [`ToolLoopTracker::begin_turn`].
    current_turn: u64,
}

impl ToolLoopTracker {
    pub fn new() -> Self {
        Self::default()
    }

    /// Note a `turn.start` boundary. Increments the per-tracker turn id and
    /// drops every prior turn's attempts/suppression state.
    pub fn begin_turn(&self) -> u64 {
        let mut inner = self.state.lock().unwrap();
        inner.current_turn = inner.current_turn.wrapping_add(1);
        inner.attempts.clear();
        inner.suppressed.clear();
        inner.current_turn
    }

    pub fn current_turn(&self) -> u64 {
        self.state.lock().unwrap().current_turn
    }

    /// Manually mark a (variable, tool) as having executed — resets the
    /// attempt counter so the next `resolution_needed` for the same
    /// variable in the same turn doesn't immediately exhaust the bound.
    /// Per §11.10.2 implementations MAY count only retries with no
    /// intervening tool call; we expose this hook so P9's runtime can
    /// notify on `tool.<name>.success`.
    pub fn note_tool_called(&self, variable: &str, tool_name: &str) {
        let mut inner = self.state.lock().unwrap();
        let turn = inner.current_turn;
        inner
            .attempts
            .remove(&(turn, variable.to_string(), tool_name.to_string()));
    }

    /// Tool-only reset: clears the per-(turn, *, tool) attempt counter for
    /// every variable in the current turn. The host runtime calls this
    /// from `record_tool_success` because the host typically knows the
    /// tool name but not the variable that suspended on it (the variable
    /// association lives inside the runtime). §11.10.2 explicitly allows
    /// counting only retries with no intervening tool execution, so a
    /// successful run resets the counter for any variable that was
    /// blocked on that tool.
    pub fn note_tool_succeeded(&self, tool_name: &str) {
        let mut inner = self.state.lock().unwrap();
        let turn = inner.current_turn;
        inner
            .attempts
            .retain(|(t, _v, tool), _| !(*t == turn && tool == tool_name));
    }

    fn suppressed(&self, turn: u64, variable: &str) -> bool {
        self.state
            .lock()
            .unwrap()
            .suppressed
            .contains(&(turn, variable.to_string()))
    }

    fn bump_attempt(&self, turn: u64, variable: &str, tool: &str) -> u32 {
        let mut inner = self.state.lock().unwrap();
        let key = (turn, variable.to_string(), tool.to_string());
        let entry = inner.attempts.entry(key).or_insert(0);
        *entry += 1;
        *entry
    }

    fn mark_suppressed(&self, turn: u64, variable: &str) {
        self.state
            .lock()
            .unwrap()
            .suppressed
            .insert((turn, variable.to_string()));
    }
}

/// Dispatch a `kind: tool` resolver.
///
/// `variable_name` MUST be the target variable; tool resolvers are only
/// reachable from a variable's `on_demand_by:` chain (the inline / synthetic
/// case is meaningless because there's nothing to populate).
pub fn invoke(
    resolver: &Resolver,
    ctx: &ResolverContext<'_>,
    variable_name: &str,
    tracker: &ToolLoopTracker,
    bus: &EventBus,
    retry_limit: u32,
) -> Result<DispatchOutcome, ResolverRuntimeError> {
    let (tool_name, prompt_template, context_map) = match resolver {
        Resolver::Tool {
            name,
            prompt,
            context,
            ..
        } => (name.as_str(), prompt.as_deref(), context.as_ref()),
        _ => {
            return Err(ResolverRuntimeError::Other {
                kind: "tool",
                message: "invoke called with a non-tool resolver".into(),
            })
        }
    };
    dispatch_signal(
        tool_name,
        prompt_template,
        context_map,
        ctx,
        variable_name,
        tracker,
        bus,
        retry_limit,
        "tool",
    )
}

/// Generic signal-and-suspend emitter shared by `kind: tool` and the
/// synthesised `kind: human` shim. Bumps the per-(turn, variable, tool)
/// retry counter, emits `incident.resolution_needed`, and returns a
/// `Suspended` outcome carrying the data the runtime needs to populate
/// `StageVerdict.pending_resolution`.
#[allow(clippy::too_many_arguments)]
pub fn dispatch_signal(
    tool_name: &str,
    prompt_template: Option<&str>,
    context_map: Option<&HashMap<String, String>>,
    ctx: &ResolverContext<'_>,
    variable_name: &str,
    tracker: &ToolLoopTracker,
    bus: &EventBus,
    retry_limit: u32,
    resolver_kind: &'static str,
) -> Result<DispatchOutcome, ResolverRuntimeError> {
    let turn = tracker.current_turn();

    // Same-turn suppression after a Cancelled outcome (§11.10.2).
    if tracker.suppressed(turn, variable_name) {
        log::warn!(
            target: "agent_shield::resolver_runtime",
            "kind: {} resolver suppressed for `{}` (turn {}): prior cancellation",
            resolver_kind, variable_name, turn
        );
        return Ok(DispatchOutcome::Completed(ResolverResponse {
            decision: ResolverDecision::Cancelled,
            value: None,
            set_variables: HashMap::new(),
            reason: Some(format!(
                "{} resolver `{}` suppressed in current turn after prior loop exhaustion",
                resolver_kind, tool_name
            )),
        }));
    }

    let attempt = tracker.bump_attempt(turn, variable_name, tool_name);
    if attempt > retry_limit {
        // Loop bound exhausted — emit incident.resolution_loop and mark
        // suppressed so subsequent reads don't re-fire.
        let payload = serde_json::json!({
            "variable": variable_name,
            "tool_name": tool_name,
            "kind": resolver_kind,
            "attempts": attempt,
            "limit": retry_limit,
            "turn": turn,
        });
        if let Err(e) = bus.emit_incident_in(
            &ctx.effective_session_id(),
            "incident.resolution_loop",
            None,
            Some(payload),
        ) {
            log::warn!(
                target: "agent_shield::resolver_runtime",
                "incident.resolution_loop emission failed: {}",
                e
            );
        }
        tracker.mark_suppressed(turn, variable_name);
        return Ok(DispatchOutcome::Completed(ResolverResponse {
            decision: ResolverDecision::Cancelled,
            value: None,
            set_variables: HashMap::new(),
            reason: Some(format!(
                "{} resolver `{}` exceeded retry limit ({}) in turn {}",
                resolver_kind, tool_name, retry_limit, turn
            )),
        }));
    }

    // Build the resolution_needed payload. Prompt interpolation failures
    // map to an `invalid_response` runtime error so the chain's `on_error:`
    // can route through fallback if declared.
    let prompt = match prompt_template {
        Some(template) => Some(interpolate_prompt(template, ctx).map_err(|e| {
            ResolverRuntimeError::InvalidResponse {
                kind: resolver_kind,
                message: format!("prompt interpolation failed: {:?}", e),
            }
        })?),
        None => None,
    };
    let context = evaluate_context_map(context_map, ctx);

    let request_id = ctx
        .request_id
        .clone()
        .unwrap_or_else(|| format!("req-{}", pseudo_request_id()));

    let mut payload = Map::new();
    payload.insert("request_id".into(), Value::String(request_id.clone()));
    payload.insert("variable".into(), Value::String(variable_name.into()));
    payload.insert("tool_name".into(), Value::String(tool_name.into()));
    payload.insert("kind".into(), Value::String(resolver_kind.into()));
    payload.insert(
        "prompt".into(),
        prompt
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    payload.insert(
        "reason".into(),
        ctx.reason.clone().map(Value::String).unwrap_or(Value::Null),
    );
    payload.insert("context".into(), Value::Object(context));
    payload.insert("attempt".into(), Value::from(attempt));
    payload.insert("turn".into(), Value::from(turn));
    // §9.4 / §11.10.2: when the target variable is keyed, the
    // resolution_needed signal MUST include `requested_key` so the
    // agent knows which key the gate was probing. The runtime only
    // marks the variable resolved when a subsequent `populated_by:`
    // write under the matching key lands.
    if let Some(rk) = ctx.requested_key.as_ref() {
        payload.insert("requested_key".into(), rk.clone());
    } else {
        payload.insert("requested_key".into(), Value::Null);
    }

    if let Err(e) = bus.emit_incident_in(
        &ctx.effective_session_id(),
        "incident.resolution_needed",
        None,
        Some(Value::Object(payload)),
    ) {
        log::warn!(
            target: "agent_shield::resolver_runtime",
            "incident.resolution_needed emission failed: {}",
            e
        );
        // The signal is the contract — if we can't emit it, fail closed.
        return Err(ResolverRuntimeError::Transport {
            kind: resolver_kind,
            message: format!("event bus emission failed: {}", e),
        });
    }

    Ok(DispatchOutcome::Suspended {
        request_id,
        tool_name: tool_name.to_string(),
        prompt,
        kind: resolver_kind,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::events::EventId;
    use serde_json::json;

    fn tool_resolver(yaml: &str) -> Resolver {
        serde_yaml::from_str(yaml).unwrap()
    }

    #[test]
    fn first_call_suspends_and_emits() {
        let bus = EventBus::new();
        let tr = ToolLoopTracker::new();
        let r = tool_resolver(
            "kind: tool\nname: lookup_recipient\nprompt: \"call lookup_recipient\"\n",
        );
        let out = invoke(
            &r,
            &ResolverContext::default(),
            "recipient",
            &tr,
            &bus,
            DEFAULT_TOOL_RETRY_LIMIT,
        )
        .unwrap();
        match out {
            DispatchOutcome::Suspended { .. } => {}
            other => panic!("expected Suspended, got {:?}", other),
        }
        // The incident.resolution_needed event should be latched on the bus.
        let id = EventId::Incident {
            name: "resolution_needed".into(),
        };
        assert!(bus.fired_id(&id));
    }

    #[test]
    fn retry_limit_exhaustion_cancels_with_incident() {
        let bus = EventBus::new();
        let tr = ToolLoopTracker::new();
        let r = tool_resolver("kind: tool\nname: lookup_recipient\n");

        for _ in 0..DEFAULT_TOOL_RETRY_LIMIT {
            let out = invoke(
                &r,
                &ResolverContext::default(),
                "recipient",
                &tr,
                &bus,
                DEFAULT_TOOL_RETRY_LIMIT,
            )
            .unwrap();
            assert!(matches!(out, DispatchOutcome::Suspended { .. }));
        }
        // Next call exceeds the limit: incident.resolution_loop, Cancelled.
        let out = invoke(
            &r,
            &ResolverContext::default(),
            "recipient",
            &tr,
            &bus,
            DEFAULT_TOOL_RETRY_LIMIT,
        )
        .unwrap();
        match out {
            DispatchOutcome::Completed(resp) => {
                assert_eq!(resp.decision, ResolverDecision::Cancelled);
            }
            other => panic!("expected Cancelled completion, got {:?}", other),
        }
        let id = EventId::Incident {
            name: "resolution_loop".into(),
        };
        assert!(bus.fired_id(&id));
    }

    #[test]
    fn same_turn_suppression_after_cancelled() {
        let bus = EventBus::new();
        let tr = ToolLoopTracker::new();
        let r = tool_resolver("kind: tool\nname: lookup\n");

        // Exhaust the limit.
        for _ in 0..=DEFAULT_TOOL_RETRY_LIMIT {
            let _ = invoke(
                &r,
                &ResolverContext::default(),
                "v",
                &tr,
                &bus,
                DEFAULT_TOOL_RETRY_LIMIT,
            );
        }
        // Subsequent call in the same turn must short-circuit Cancelled.
        let out = invoke(
            &r,
            &ResolverContext::default(),
            "v",
            &tr,
            &bus,
            DEFAULT_TOOL_RETRY_LIMIT,
        )
        .unwrap();
        match out {
            DispatchOutcome::Completed(resp) => {
                assert_eq!(resp.decision, ResolverDecision::Cancelled);
                assert!(resp
                    .reason
                    .as_ref()
                    .map(|r| r.contains("suppressed"))
                    .unwrap_or(false));
            }
            other => panic!("expected suppression, got {:?}", other),
        }
    }

    #[test]
    fn begin_turn_resets_state() {
        let bus = EventBus::new();
        let tr = ToolLoopTracker::new();
        let r = tool_resolver("kind: tool\nname: lookup\n");
        for _ in 0..=DEFAULT_TOOL_RETRY_LIMIT {
            let _ = invoke(
                &r,
                &ResolverContext::default(),
                "v",
                &tr,
                &bus,
                DEFAULT_TOOL_RETRY_LIMIT,
            );
        }
        // Next turn — counters reset.
        tr.begin_turn();
        let out = invoke(
            &r,
            &ResolverContext::default(),
            "v",
            &tr,
            &bus,
            DEFAULT_TOOL_RETRY_LIMIT,
        )
        .unwrap();
        assert!(matches!(out, DispatchOutcome::Suspended { .. }));
    }

    #[test]
    fn note_tool_called_resets_attempt_counter() {
        let bus = EventBus::new();
        let tr = ToolLoopTracker::new();
        let r = tool_resolver("kind: tool\nname: lookup\n");
        for _ in 0..DEFAULT_TOOL_RETRY_LIMIT {
            let _ = invoke(
                &r,
                &ResolverContext::default(),
                "v",
                &tr,
                &bus,
                DEFAULT_TOOL_RETRY_LIMIT,
            );
        }
        tr.note_tool_called("v", "lookup");
        // After tool execution, retry counter is back to zero.
        let out = invoke(
            &r,
            &ResolverContext::default(),
            "v",
            &tr,
            &bus,
            DEFAULT_TOOL_RETRY_LIMIT,
        )
        .unwrap();
        assert!(matches!(out, DispatchOutcome::Suspended { .. }));
    }

    /// P9.7 — `note_tool_succeeded` clears the per-(turn, *, tool)
    /// attempt counter for every variable in the current turn. This is
    /// the path the runtime takes from `record_tool_success` because the
    /// host knows the tool name but typically not which variable
    /// suspended on it.
    #[test]
    fn note_tool_succeeded_resets_counter_for_all_variables() {
        let bus = EventBus::new();
        let tr = ToolLoopTracker::new();
        let r = tool_resolver("kind: tool\nname: lookup\n");
        // Suspend on two different variables, both blocked on `lookup`.
        for _ in 0..DEFAULT_TOOL_RETRY_LIMIT {
            let _ = invoke(
                &r,
                &ResolverContext::default(),
                "var_a",
                &tr,
                &bus,
                DEFAULT_TOOL_RETRY_LIMIT,
            );
        }
        for _ in 0..DEFAULT_TOOL_RETRY_LIMIT {
            let _ = invoke(
                &r,
                &ResolverContext::default(),
                "var_b",
                &tr,
                &bus,
                DEFAULT_TOOL_RETRY_LIMIT,
            );
        }
        // Tool ran successfully — clear by tool name only.
        tr.note_tool_succeeded("lookup");
        // Both variables now have a fresh counter and re-suspend rather
        // than immediately exhausting.
        let out_a = invoke(
            &r,
            &ResolverContext::default(),
            "var_a",
            &tr,
            &bus,
            DEFAULT_TOOL_RETRY_LIMIT,
        )
        .unwrap();
        assert!(matches!(out_a, DispatchOutcome::Suspended { .. }));
        let out_b = invoke(
            &r,
            &ResolverContext::default(),
            "var_b",
            &tr,
            &bus,
            DEFAULT_TOOL_RETRY_LIMIT,
        )
        .unwrap();
        assert!(matches!(out_b, DispatchOutcome::Suspended { .. }));
    }

    /// P9.7 — `note_tool_succeeded` does NOT touch attempts for unrelated
    /// tools in the same turn.
    #[test]
    fn note_tool_succeeded_only_clears_named_tool() {
        let bus = EventBus::new();
        let tr = ToolLoopTracker::new();
        let r1 = tool_resolver("kind: tool\nname: lookup\n");
        let r2 = tool_resolver("kind: tool\nname: other_tool\n");
        // Saturate both tools.
        for _ in 0..DEFAULT_TOOL_RETRY_LIMIT {
            let _ = invoke(
                &r1,
                &ResolverContext::default(),
                "v",
                &tr,
                &bus,
                DEFAULT_TOOL_RETRY_LIMIT,
            );
        }
        for _ in 0..DEFAULT_TOOL_RETRY_LIMIT {
            let _ = invoke(
                &r2,
                &ResolverContext::default(),
                "v",
                &tr,
                &bus,
                DEFAULT_TOOL_RETRY_LIMIT,
            );
        }
        // Reset only `lookup`; `other_tool` stays exhausted.
        tr.note_tool_succeeded("lookup");
        let out_other = invoke(
            &r2,
            &ResolverContext::default(),
            "v",
            &tr,
            &bus,
            DEFAULT_TOOL_RETRY_LIMIT,
        )
        .unwrap();
        match out_other {
            DispatchOutcome::Completed(resp) => {
                assert_eq!(resp.decision, ResolverDecision::Cancelled);
            }
            other => panic!("expected Cancelled for other_tool, got {:?}", other),
        }
    }

    #[test]
    fn payload_carries_request_id_variable_tool() {
        let bus = EventBus::new();
        let tr = ToolLoopTracker::new();
        let r = tool_resolver("kind: tool\nname: my_tool\n");
        let out = invoke(
            &r,
            &ResolverContext::default(),
            "my_var",
            &tr,
            &bus,
            DEFAULT_TOOL_RETRY_LIMIT,
        )
        .unwrap();
        let DispatchOutcome::Suspended { request_id, .. } = out else {
            panic!("expected suspended");
        };
        let id = EventId::Incident {
            name: "resolution_needed".into(),
        };
        let payload = bus.payload_of(&id).unwrap();
        assert_eq!(payload.get("variable"), Some(&json!("my_var")));
        assert_eq!(payload.get("tool_name"), Some(&json!("my_tool")));
        assert_eq!(payload.get("request_id"), Some(&json!(request_id)));
    }

    #[test]
    fn retry_limit_configurable() {
        let bus = EventBus::new();
        let tr = ToolLoopTracker::new();
        let r = tool_resolver("kind: tool\nname: lookup\n");
        // Custom retry limit of 1 — second call exhausts.
        let _ = invoke(&r, &ResolverContext::default(), "v", &tr, &bus, 1).unwrap();
        let out = invoke(&r, &ResolverContext::default(), "v", &tr, &bus, 1).unwrap();
        match out {
            DispatchOutcome::Completed(resp) => {
                assert_eq!(resp.decision, ResolverDecision::Cancelled);
            }
            other => panic!("expected Cancelled, got {:?}", other),
        }
    }
}
