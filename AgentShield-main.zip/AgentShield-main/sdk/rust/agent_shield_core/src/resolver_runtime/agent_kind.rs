//! `kind: agent` resolver — host-channel `resolution_request` (§11.10.4).
//!
//! The runtime emits a structured `resolution_request` to the calling
//! agent via the SDK's host channel; the host returns the wire envelope
//! (§11.3) drawn from its own state, conversation, or auxiliary mechanism.
//!
//! Per §11.10 there is **no** `name:` field on `kind: agent` — the
//! resolver targets the host's channel, not a named peer agent. Use
//! `kind: delegate` against a `type: a2a_agent` configuration to address a
//! specific peer.
//!
//! Per the spec ambiguity flagged at §11.10: this kind has NO
//! `agent_id:` field at the resolver level; the host channel is
//! implied. We route through an `AgentResolver` trait registered on
//! the dispatcher, the single-channel default that hosts plug into.
//! Hosts that want per-peer routing use `kind: delegate` instead,
//! which is dispatched through `delegate_kind` against the
//! configurations[] entry.

use std::collections::HashMap;

use serde_json::{Map, Value};

use super::super::resolver::{Resolver, ResolverDecision, ResolverResponse};
use super::super::variables::ResourceKind;
use super::context::{interpolate_prompt, ResolverContext};
use super::errors::ResolverRuntimeError;
use super::tool_kind::{evaluate_context_map, pseudo_request_id};

/// Per-request payload delivered to the host's agent resolver.
#[derive(Debug, Clone)]
pub struct AgentResolveRequest {
    pub request_id: String,
    pub variable: Option<String>,
    pub resource_kind: Option<ResourceKind>,
    pub resource_name: Option<String>,
    /// Resource invocation parameters (§11.10 `resource.params`).
    /// `None` when the resolver fires outside an invocation context.
    pub resource_params: Option<Value>,
    pub prompt: String,
    pub reason: Option<String>,
    pub context: Map<String, Value>,
    /// §9.4 / §11.5: the key under which the resolver's response will
    /// be stored, when the target variable declares `key:`. `None` for
    /// non-keyed variables.
    pub requested_key: Option<Value>,
}

pub trait AgentResolver: Send + Sync {
    fn resolve(&self, req: AgentResolveRequest) -> ResolverResponse;
}

/// Dispatch a `kind: agent` resolver. Mirrors [`super::human_kind::invoke`]
/// but delivers an [`AgentResolveRequest`] to the registered
/// [`AgentResolver`] hook.
pub fn invoke(
    resolver: &Resolver,
    ctx: &ResolverContext<'_>,
    variable_name: Option<&str>,
    hook: Option<&dyn AgentResolver>,
) -> Result<ResolverResponse, ResolverRuntimeError> {
    let (prompt_template, context_map) = match resolver {
        Resolver::Agent {
            prompt, context, ..
        } => (prompt.as_str(), context.as_ref()),
        _ => {
            return Err(ResolverRuntimeError::Other {
                kind: "agent",
                message: "invoke called with a non-agent resolver".into(),
            })
        }
    };

    let prompt = interpolate_prompt(prompt_template, ctx).map_err(|e| {
        ResolverRuntimeError::InvalidResponse {
            kind: "agent",
            message: format!("prompt interpolation failed: {:?}", e),
        }
    })?;
    let context = evaluate_context_map(context_map, ctx);

    let req = AgentResolveRequest {
        request_id: ctx
            .request_id
            .clone()
            .unwrap_or_else(|| format!("req-{}", pseudo_request_id())),
        variable: variable_name.map(str::to_owned),
        resource_kind: ctx.resource.as_ref().map(|r| r.kind),
        resource_name: ctx.resource.as_ref().map(|r| r.name.clone()),
        resource_params: ctx.invocation.map(|i| i.params.clone()),
        prompt,
        reason: ctx.reason.clone(),
        context,
        requested_key: ctx.requested_key.clone(),
    };

    let resp = match hook {
        Some(h) => h.resolve(req),
        None => {
            log::warn!(
                target: "agent_shield::resolver_runtime",
                "no AgentResolver registered — failing closed (deny)"
            );
            ResolverResponse {
                decision: ResolverDecision::Deny,
                value: None,
                set_variables: HashMap::new(),
                reason: Some("no agent resolver registered (fail-closed)".into()),
            }
        }
    };
    Ok(resp)
}

pub struct AgentResolverFn<F>(pub F)
where
    F: Fn(AgentResolveRequest) -> ResolverResponse + Send + Sync;

impl<F> AgentResolver for AgentResolverFn<F>
where
    F: Fn(AgentResolveRequest) -> ResolverResponse + Send + Sync,
{
    fn resolve(&self, req: AgentResolveRequest) -> ResolverResponse {
        (self.0)(req)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;
    use std::sync::{Arc, Mutex};

    fn agent_resolver(yaml: &str) -> Resolver {
        serde_yaml::from_str(yaml).unwrap()
    }

    #[test]
    fn allow_pass_through() {
        let r = agent_resolver("kind: agent\nprompt: \"approve?\"\n");
        let hook = AgentResolverFn(|_| ResolverResponse {
            decision: ResolverDecision::Allow,
            value: Some(json!(true)),
            set_variables: HashMap::new(),
            reason: None,
        });
        let out = invoke(&r, &ResolverContext::default(), None, Some(&hook)).unwrap();
        assert_eq!(out.decision, ResolverDecision::Allow);
    }

    #[test]
    fn missing_hook_fails_closed() {
        let r = agent_resolver("kind: agent\nprompt: \"approve?\"\n");
        let out = invoke(&r, &ResolverContext::default(), None, None).unwrap();
        assert_eq!(out.decision, ResolverDecision::Deny);
    }

    #[test]
    fn captures_request_fields() {
        let r = agent_resolver(
            "kind: agent\nprompt: \"approve ${var.amount}?\"\ncontext:\n  who: \"current_user\"\n",
        );
        let mut attrs = HashMap::new();
        attrs.insert("amount".into(), json!(50));
        attrs.insert("current_user".into(), json!("ada"));
        let ctx = ResolverContext::default()
            .with_attrs(attrs)
            .with_reason("policy says so");

        let captured: Arc<Mutex<Option<AgentResolveRequest>>> = Arc::new(Mutex::new(None));
        let captured_for_hook = captured.clone();
        let hook = AgentResolverFn(move |req| {
            *captured_for_hook.lock().unwrap() = Some(req);
            ResolverResponse {
                decision: ResolverDecision::Allow,
                value: Some(json!(true)),
                set_variables: HashMap::new(),
                reason: None,
            }
        });
        let _ = invoke(&r, &ctx, None, Some(&hook)).unwrap();
        let cap = captured.lock().unwrap();
        let cap = cap.as_ref().unwrap();
        assert_eq!(cap.prompt, "approve 50?");
        assert_eq!(cap.context.get("who"), Some(&json!("ada")));
        assert_eq!(cap.reason.as_deref(), Some("policy says so"));
    }

    #[test]
    fn cancelled_pass_through() {
        let r = agent_resolver("kind: agent\nprompt: \"approve?\"\n");
        let hook = AgentResolverFn(|_| ResolverResponse {
            decision: ResolverDecision::Cancelled,
            value: None,
            set_variables: HashMap::new(),
            reason: Some("aborted".into()),
        });
        let out = invoke(&r, &ResolverContext::default(), None, Some(&hook)).unwrap();
        assert_eq!(out.decision, ResolverDecision::Cancelled);
    }
}
