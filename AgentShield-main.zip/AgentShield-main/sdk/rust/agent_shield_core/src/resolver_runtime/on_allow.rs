//! `on_allow:` declarative bridge (§11.4) and `set_variables:` application
//! (§11.3).
//!
//! ## Application order
//!
//! Per §11.3 the application order on a final `decision: allow` is:
//!
//! 1. `value:` (handled by the variable-bound caller — the dispatcher writes
//!    the resolver value to `<variable>` directly, not through this module).
//! 2. `set_variables:` from the wire envelope.
//! 3. `on_allow:` map declared on the resolver's YAML.
//!
//! This module implements steps (2) and (3). Step (1) is the responsibility
//! of [`super::ResolverDispatcher::resolve`] because it needs to pass the
//! variable's resolver-outcome to [`crate::lifetime_tracker`] so the
//! lifetime branch is selected correctly.
//!
//! The `on_allow:` expressions are evaluated after `set_variables:` is
//! applied — the spec is silent on whether `on_allow:` sees the
//! `set_variables:` mutations, but applying earlier writes first is the
//! defensive, intuitive choice (the §11.3 application order says the same).
//! Where authors really need ordering control, they should split the
//! resolver into two-tier composition (§11.13).
//!
//! Cache hits MUST NOT re-apply either set (§11.8). The dispatcher enforces
//! that at the call site by short-circuiting cache hits before they reach
//! this module.

use std::collections::HashMap;

use serde_json::Value;

use crate::expressions::eval::{evaluate_to_value, EvalContext};

use super::super::lifetime_tracker::{LifetimeTracker, ResolverOutcome};
use super::super::variables::Variable;
use super::context::ResolverContext;

/// Outcome of applying the post-allow mutations.
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct ApplyReport {
    /// Variables whose writes succeeded.
    pub written: Vec<String>,
    /// Variables whose writes were dropped because they aren't declared
    /// (§11.3 — "Unknown names MUST produce a warning and be dropped").
    pub dropped_unknown: Vec<String>,
    /// Variables whose writes were dropped because the type / update_policy
    /// rejected the value (§11.3 / §10.2 silent no-op).
    pub dropped_typecheck: Vec<String>,
    /// Variables whose `on_allow:` expression failed to evaluate.
    pub on_allow_eval_errors: Vec<String>,
}

impl ApplyReport {
    pub fn merge(&mut self, other: ApplyReport) {
        self.written.extend(other.written);
        self.dropped_unknown.extend(other.dropped_unknown);
        self.dropped_typecheck.extend(other.dropped_typecheck);
        self.on_allow_eval_errors.extend(other.on_allow_eval_errors);
    }
}

/// Apply the wire envelope's `set_variables:` map (§11.3) followed by the
/// resolver's declared `on_allow:` (§11.4).
///
/// Per §11.3 / §11.4 ordering: `set_variables:` runs first and `on_allow:`
/// runs second. `on_allow:` expressions MUST observe the cumulative
/// writes — both the prior `set_variables:` entries and any earlier
/// `on_allow:` writes inside the same dispatch — so the eval context is
/// rebuilt against a working `attrs` map that grows after every successful
/// write.
///
/// `source_kind` and `set_by` are stamped onto every write; conventionally
/// the dispatcher passes the resolver kind (e.g. "human", "delegate") and
/// a variable / resolver identifier so the audit log can attribute the
/// write back to its origin.
#[allow(clippy::too_many_arguments)]
pub fn apply_set_variables_and_on_allow(
    tracker: &LifetimeTracker,
    registry: &HashMap<String, Variable>,
    set_variables: &HashMap<String, Value>,
    on_allow: Option<&HashMap<String, String>>,
    resolver_value: Option<&Value>,
    source_kind: &str,
    set_by: &str,
    ctx: &ResolverContext<'_>,
) -> ApplyReport {
    let mut report = ApplyReport::default();
    let session_id = ctx.effective_session_id();

    // Working attribute map seeded from the resolver context. We grow this
    // as set_variables: and on_allow: writes succeed so subsequent
    // expressions see earlier writes in the same dispatch.
    let mut working_attrs = ctx.attrs.clone();
    if let Some(v) = resolver_value {
        working_attrs.insert("value".into(), v.clone());
    }

    // ── (1) set_variables: from the wire envelope ───────────────────
    for (name, value) in set_variables {
        if !registry.contains_key(name) {
            log::warn!(
                target: "agent_shield::resolver_runtime",
                "resolver set_variables: dropping unknown variable `{}` (not declared)",
                name
            );
            report.dropped_unknown.push(name.clone());
            continue;
        }
        if !type_check(name, value, registry) {
            log::warn!(
                target: "agent_shield::resolver_runtime",
                "resolver set_variables: dropping type-incompatible value for `{}`",
                name
            );
            report.dropped_typecheck.push(name.clone());
            continue;
        }
        match tracker.set_variable_in(
            &session_id,
            name,
            value.clone(),
            Some(source_kind),
            Some(set_by),
            ResolverOutcome::Allow,
        ) {
            Ok(()) => {
                // Reflect the write into the working attrs so subsequent
                // set_variables: / on_allow: entries see it.
                working_attrs.insert(name.clone(), value.clone());
                report.written.push(name.clone());
            }
            Err(e) => {
                log::warn!(
                    target: "agent_shield::resolver_runtime",
                    "set_variables: write to `{}` rejected: {}",
                    name,
                    e
                );
                report.dropped_typecheck.push(name.clone());
            }
        }
    }

    // ── (2) on_allow: from the resolver's YAML ──────────────────────
    if let Some(map) = on_allow {
        for (target, expr) in map {
            if !registry.contains_key(target) {
                log::warn!(
                    target: "agent_shield::resolver_runtime",
                    "on_allow: dropping unknown variable `{}` (not declared)",
                    target
                );
                report.dropped_unknown.push(target.clone());
                continue;
            }
            // Rebuild the eval context per iteration so each on_allow:
            // expression sees writes from earlier on_allow: entries plus
            // the cumulative set_variables: writes above.
            let eval_ctx = EvalContext {
                attrs: &working_attrs,
                // on_allow is NOT a gating site — auto-resolution must
                // NOT fire here per §11.5.
                is_gating_site: false,
                ..EvalContext::from_attrs(&working_attrs)
            };
            let val = match evaluate_to_value(expr, &eval_ctx) {
                Some(v) => v,
                None => {
                    log::warn!(
                        target: "agent_shield::resolver_runtime",
                        "on_allow: expression for `{}` failed to parse: {}",
                        target,
                        expr
                    );
                    report.on_allow_eval_errors.push(target.clone());
                    continue;
                }
            };
            if !type_check(target, &val, registry) {
                log::warn!(
                    target: "agent_shield::resolver_runtime",
                    "on_allow: dropping type-incompatible value for `{}`",
                    target
                );
                report.dropped_typecheck.push(target.clone());
                continue;
            }
            match tracker.set_variable_in(
                &session_id,
                target,
                val.clone(),
                Some(source_kind),
                Some(set_by),
                ResolverOutcome::Allow,
            ) {
                Ok(()) => {
                    working_attrs.insert(target.clone(), val);
                    report.written.push(target.clone());
                }
                Err(e) => {
                    log::warn!(
                        target: "agent_shield::resolver_runtime",
                        "on_allow: write to `{}` rejected: {}",
                        target,
                        e
                    );
                    report.dropped_typecheck.push(target.clone());
                }
            }
        }
    }

    report
}

/// Lightweight type-check between a declared variable and a candidate
/// value. The full update_policy / properties validation lives in
/// [`crate::update_policy::apply_update`]; this is a fast pre-filter
/// that lets us short-circuit before paying the cost of the merge.
fn type_check(name: &str, value: &Value, registry: &HashMap<String, Variable>) -> bool {
    use super::super::variables::VariableType;
    let Some(decl) = registry.get(name) else {
        return false;
    };
    if matches!(value, Value::Null) {
        // null is type-compatible with every variable per §11.3 ("the
        // resolver value is null" is a valid envelope shape).
        return true;
    }
    match decl.var_type {
        VariableType::String => matches!(value, Value::String(_)),
        VariableType::Number => matches!(value, Value::Number(_)),
        VariableType::Boolean => matches!(value, Value::Bool(_)),
        VariableType::Array => matches!(value, Value::Array(_)),
        VariableType::Object => matches!(value, Value::Object(_)),
        VariableType::Datetime => matches!(value, Value::String(_)),
        // §10.1 — enum values travel as strings; membership against
        // `members:` is enforced at write time by `apply_update`, not
        // here. This check only screens the JSON shape.
        VariableType::Enum => matches!(value, Value::String(_)),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::event_bus::EventBus;
    use crate::variables::{Variable, VariableType};
    use serde_json::json;

    fn var(name: &str, ty: VariableType) -> Variable {
        Variable {
            name: name.to_string(),
            var_type: ty,
            description: None,
            default: None,
            members: None,
            update: None,
            key: None,
            lifetime: None,
            on_demand_by: None,
            populated_by: vec![],
            reset_by: vec![],
        }
    }

    fn fixture() -> (std::sync::Arc<LifetimeTracker>, HashMap<String, Variable>) {
        let bus = EventBus::new();
        let count = var("approval_count", VariableType::Number);
        let last = var("last_approved_at", VariableType::String);
        let other = var("approved_by", VariableType::String);
        let registry: HashMap<String, Variable> = [count, last, other]
            .into_iter()
            .map(|v| (v.name.clone(), v))
            .collect();
        let tracker = LifetimeTracker::new(bus, registry.clone());
        (tracker, registry)
    }

    #[test]
    fn set_variables_writes_known_drops_unknown() {
        let (tracker, registry) = fixture();
        let mut sv = HashMap::new();
        sv.insert("approval_count".into(), json!(1));
        sv.insert("ghost_var".into(), json!("ignored"));
        let report = apply_set_variables_and_on_allow(
            &tracker,
            &registry,
            &sv,
            None,
            None,
            "test",
            "test:resolver",
            &ResolverContext::default(),
        );
        assert!(report.written.contains(&"approval_count".to_string()));
        assert!(report.dropped_unknown.contains(&"ghost_var".to_string()));
        assert_eq!(tracker.read_variable("approval_count").value, json!(1));
    }

    #[test]
    fn set_variables_drops_typecheck_failures() {
        let (tracker, registry) = fixture();
        let mut sv = HashMap::new();
        sv.insert("approval_count".into(), json!("not a number"));
        let report = apply_set_variables_and_on_allow(
            &tracker,
            &registry,
            &sv,
            None,
            None,
            "test",
            "test:resolver",
            &ResolverContext::default(),
        );
        assert!(report
            .dropped_typecheck
            .contains(&"approval_count".to_string()));
    }

    #[test]
    fn on_allow_evaluates_expressions() {
        let (tracker, registry) = fixture();
        // seed approval_count = 4 so the expression has a base.
        tracker
            .set_variable(
                "approval_count",
                json!(4),
                Some("seed"),
                Some("seed"),
                ResolverOutcome::Allow,
            )
            .unwrap();

        let mut on_allow = HashMap::new();
        on_allow.insert("approval_count".into(), "approval_count + 1".into());

        let mut attrs = HashMap::new();
        attrs.insert("approval_count".into(), json!(4));
        let ctx = ResolverContext::default().with_attrs(attrs);

        let report = apply_set_variables_and_on_allow(
            &tracker,
            &registry,
            &HashMap::new(),
            Some(&on_allow),
            None,
            "human",
            "human:approval_count",
            &ctx,
        );
        assert!(report.written.contains(&"approval_count".to_string()));
        assert_eq!(tracker.read_variable("approval_count").value, json!(5));
    }

    #[test]
    fn on_allow_drops_unknown_target() {
        let (tracker, registry) = fixture();
        let mut on_allow = HashMap::new();
        on_allow.insert("not_declared".into(), "1".into());
        let report = apply_set_variables_and_on_allow(
            &tracker,
            &registry,
            &HashMap::new(),
            Some(&on_allow),
            None,
            "human",
            "human:approval_count",
            &ResolverContext::default(),
        );
        assert!(report.dropped_unknown.contains(&"not_declared".to_string()));
    }

    #[test]
    fn on_allow_eval_error_recorded() {
        let (tracker, registry) = fixture();
        let mut on_allow = HashMap::new();
        on_allow.insert("approval_count".into(), "(unbalanced(".into());
        let report = apply_set_variables_and_on_allow(
            &tracker,
            &registry,
            &HashMap::new(),
            Some(&on_allow),
            None,
            "human",
            "human:approval_count",
            &ResolverContext::default(),
        );
        assert!(report
            .on_allow_eval_errors
            .contains(&"approval_count".to_string()));
    }

    #[test]
    fn set_variables_then_on_allow_ordering() {
        // §11.3: set_variables is applied first, on_allow second.
        // We verify that on_allow can reference attrs that include the
        // set_variables write — but only because the test driver re-snapshots
        // them. The host runtime is responsible for refreshing attrs
        // between the two phases when the host wants on_allow to observe
        // set_variables writes; the dispatcher itself does not re-snapshot
        // (we pass `attrs` from `ctx` as a plain clone).
        let (tracker, registry) = fixture();

        let mut sv = HashMap::new();
        sv.insert("approval_count".into(), json!(10));

        let mut on_allow = HashMap::new();
        on_allow.insert("approval_count".into(), "20".into()); // overrides

        let report = apply_set_variables_and_on_allow(
            &tracker,
            &registry,
            &sv,
            Some(&on_allow),
            None,
            "human",
            "human:approval_count",
            &ResolverContext::default(),
        );
        // Both should attempt to write; on_allow runs second and wins.
        assert_eq!(
            report
                .written
                .iter()
                .filter(|n| *n == "approval_count")
                .count(),
            2
        );
        assert_eq!(tracker.read_variable("approval_count").value, json!(20));
    }

    // P5.3: on_allow expressions observe earlier set_variables: writes.
    #[test]
    fn on_allow_observes_set_variables_writes() {
        let (tracker, registry) = fixture();
        let mut sv = HashMap::new();
        sv.insert("approval_count".into(), json!(1));
        let mut on_allow = HashMap::new();
        // Reads `approval_count` written above and adds 1.
        on_allow.insert("approval_count".into(), "approval_count + 1".into());

        let report = apply_set_variables_and_on_allow(
            &tracker,
            &registry,
            &sv,
            Some(&on_allow),
            None,
            "human",
            "human:test",
            &ResolverContext::default(),
        );
        assert!(
            report.on_allow_eval_errors.is_empty(),
            "report: {:?}",
            report
        );
        // set_variables wrote 1; on_allow added 1; final value is 2.
        assert_eq!(tracker.read_variable("approval_count").value, json!(2));
    }

    // P5.3: cumulative on_allow writes — later entries see earlier ones.
    #[test]
    fn on_allow_entries_observe_earlier_on_allow_writes() {
        let (tracker, registry) = fixture();
        // BTreeMap-like ordering: HashMap iteration is non-deterministic,
        // so the test uses two independent observed dependencies that
        // must both hold regardless of iteration order.
        let sv = HashMap::new();
        let mut on_allow = HashMap::new();
        on_allow.insert("approved_by".into(), "\"alice\"".into());
        let report = apply_set_variables_and_on_allow(
            &tracker,
            &registry,
            &sv,
            Some(&on_allow),
            None,
            "human",
            "human:test",
            &ResolverContext::default(),
        );
        assert!(report.on_allow_eval_errors.is_empty());
        assert_eq!(tracker.read_variable("approved_by").value, json!("alice"));
    }
}
