//! Fallback-chain runner (§11.6).
//!
//! Walks `Resolver::*::fallback` recursively. Stops at the first `Allow`.
//! On `Deny` / `Cancelled` / runtime error, advances to the next link.
//!
//! ## Per-link error policy (§11.7)
//!
//! Errors are first mapped through the link's `on_error:`:
//!
//! - `block` (default) → synthetic `deny`. The chain continues to the
//!   next link (deny is fallback-eligible per §11.6).
//! - `allow` → synthetic `allow` with `value: null`. Chain terminates.
//! - `use_default` → synthetic `allow` with the variable's `default:` if
//!   declared; otherwise behaves as `block`.
//! - `use_fallback` → continues to the next link. If no next link,
//!   behaves as `block`.
//!
//! ## Cycle detection
//!
//! The loader catches resolver-graph cycles at load time. This module
//! additionally tracks visited resolver pointers during traversal and
//! breaks with a synthetic Deny if the same resolver is re-entered.
//! Defense in depth.

use std::collections::HashMap;
use std::collections::HashSet;

use serde_json::Value;

use super::super::resolver::{OnError, Resolver, ResolverDecision, ResolverResponse};
use super::super::variables::Variable;
use super::errors::ResolverRuntimeError;

pub use crate::constants::resolver::MAX_CHAIN_DEPTH;

/// Per-link dispatch closure: takes a single resolver and produces a
/// completed `Result<ResolverResponse, ResolverRuntimeError>`. Tool
/// resolvers in suspension are handled separately by the dispatcher
/// because they don't participate in fallback chains in the obvious way
/// (a Suspended outcome is not Allow / Deny / Cancelled — see
/// `super::tool_kind::DispatchOutcome`).
pub type LinkInvoker<'a> = dyn Fn(&Resolver) -> Result<LinkOutcome, ResolverRuntimeError> + 'a;

/// What a single resolver link produced.
///
/// Tool resolvers can return a fourth state — `Suspended` — that isn't
/// part of the wire envelope. Per §11.6 suspension does NOT trigger
/// fallback (the chain is invoked only on `deny` / `cancelled` / errors
/// with `on_error: use_fallback` / a `null`-or-`false` `kind: expression`
/// result). So when a link suspends, the chain runner terminates the
/// chain immediately and signals up.
#[derive(Debug, Clone)]
pub enum LinkOutcome {
    Completed(ResolverResponse),
    Suspended {
        /// The `incident.resolution_needed` request id.
        request_id: String,
        /// Tool the agent must call to satisfy the resolution.
        tool_name: String,
        /// Interpolated prompt, if any.
        prompt: Option<String>,
        /// Originating resolver kind: `"tool"` or `"human"`.
        kind: &'static str,
    },
    /// Shadow-mode (#14) skip: side-effecting kind (`human` / `tool`
    /// / `agent` / `delegate`) short-circuited before any host hook.
    /// The chain walker treats this as a deny-advance and remembers
    /// it so the dispatcher can skip `finalize()` (variable stays
    /// `Unset`, no `approval.<var>.<outcome>` event).
    Suppressed {
        /// Originating resolver kind (`"human"` / `"tool"` / `"agent"`
        /// / `"delegate"`), used in the dispatcher's audit event.
        kind: &'static str,
        /// Suppression rationale, surfaced in the audit event reason.
        reason: String,
    },
}

/// What [`run_with_fallback`] produced.
#[derive(Debug, Clone)]
pub enum ChainOutcome {
    /// The chain produced a final wire envelope (allow / deny / cancelled).
    Completed(ResolverResponse),
    /// The chain terminated because a tool resolver suspended waiting for
    /// the agent to call its tool. Per §11.6 fallbacks do NOT rescue
    /// suspension; the host runtime should see this as "wait" and re-read
    /// the variable on the next gate evaluation (which will see
    /// `@status == 'resolved'` if the agent complied).
    Suspended {
        request_id: String,
        tool_name: String,
        prompt: Option<String>,
        kind: &'static str,
    },
    /// Shadow mode (#14): at least one link was suppressed and no
    /// later link returned `Allow`. The dispatcher skips finalize.
    /// Carries audit metadata for the FIRST suppressed link.
    Suppressed { kind: &'static str, reason: String },
}

impl ChainOutcome {
    /// True when this is a [`ChainOutcome::Suspended`] outcome.
    pub fn is_suspended(&self) -> bool {
        matches!(self, ChainOutcome::Suspended { .. })
    }

    /// True when this is a [`ChainOutcome::Suppressed`] outcome (#14).
    pub fn is_suppressed(&self) -> bool {
        matches!(self, ChainOutcome::Suppressed { .. })
    }

    /// Convert to the wire envelope, surfacing suspension as a synthetic
    /// `Deny` so external callers (the host runtime) see a wire shape.
    /// The `is_suspended()` flag should be checked first when the caller
    /// needs to distinguish suspension from a normal deny.
    pub fn into_response(self) -> ResolverResponse {
        match self {
            ChainOutcome::Completed(r) => r,
            ChainOutcome::Suspended {
                request_id,
                tool_name,
                kind,
                ..
            } => ResolverResponse {
                decision: ResolverDecision::Deny,
                value: None,
                set_variables: HashMap::new(),
                reason: Some(format!(
                    "kind: {kind} resolver suspended pending tool execution \
                     (tool=`{tool_name}`, request_id={request_id})"
                )),
            },
            ChainOutcome::Suppressed { kind, reason } => ResolverResponse {
                decision: ResolverDecision::Deny,
                value: None,
                set_variables: HashMap::new(),
                reason: Some(format!(
                    "shadow_mode: kind: {kind} resolver suppressed ({reason})"
                )),
            },
        }
    }
}

/// Walk the chain starting at `head`. Returns the chain's final outcome.
pub fn run_with_fallback(
    head: &Resolver,
    target_variable: Option<&Variable>,
    invoker: &LinkInvoker<'_>,
) -> ChainOutcome {
    let mut visited: HashSet<*const Resolver> = HashSet::new();
    let mut current = head;
    let mut last: Option<ResolverResponse> = None;
    // First-seen [`LinkOutcome::Suppressed`] for the chain — the
    // dispatcher uses this to emit a single `require_approval` audit
    // event per shadow-suppressed chain (#14).
    let mut first_suppression: Option<(&'static str, String)> = None;
    // True iff the loop ran the full MAX_CHAIN_DEPTH iterations without
    // returning early or hitting `break` on `next_link == None`. In that
    // case there were still more links to walk and we truncated.
    let mut truncated = true;

    for _ in 0..MAX_CHAIN_DEPTH {
        if !visited.insert(current as *const Resolver) {
            log::warn!(
                target: "agent_shield::resolver_runtime",
                "fallback cycle detected at resolver `{}`; breaking",
                current.kind_str()
            );
            return ChainOutcome::Completed(ResolverResponse {
                decision: ResolverDecision::Deny,
                value: None,
                set_variables: HashMap::new(),
                reason: Some(format!(
                    "fallback cycle detected at `{}` resolver",
                    current.kind_str()
                )),
            });
        }

        let raw = invoker(current);
        let on_error_policy = on_error_of(current);
        let outcome = match raw {
            Ok(LinkOutcome::Completed(resp)) => ChainStep::Completed(resp),
            Ok(LinkOutcome::Suspended {
                request_id,
                tool_name,
                prompt,
                kind,
            }) => {
                // §11.6: suspension does NOT advance to fallback.
                return ChainOutcome::Suspended {
                    request_id,
                    tool_name,
                    prompt,
                    kind,
                };
            }
            Ok(LinkOutcome::Suppressed { kind, reason }) => {
                // Shadow (#14): advance to the next fallback so a
                // sibling `kind: expression` can still satisfy the
                // gate; remember the suppression so finalize is
                // skipped when no link allows.
                if first_suppression.is_none() {
                    first_suppression = Some((kind, reason.clone()));
                }
                match next_link(current) {
                    Some(next) => {
                        current = next;
                        continue;
                    }
                    None => {
                        truncated = false;
                        break;
                    }
                }
            }
            Err(e) => map_error(e, current, target_variable, on_error_policy),
        };

        match outcome {
            ChainStep::Completed(resp) => match resp.decision {
                ResolverDecision::Allow => return ChainOutcome::Completed(resp),
                ResolverDecision::Deny | ResolverDecision::Cancelled => {
                    last = Some(resp);
                    match next_link(current) {
                        Some(next) => current = next,
                        None => {
                            truncated = false;
                            break;
                        }
                    }
                }
            },
            ChainStep::AdvanceTo(reason) => {
                // use_fallback with a deny-like reason: skip directly to
                // the next link without recording a chain outcome.
                last = Some(reason);
                match next_link(current) {
                    Some(next) => current = next,
                    None => {
                        truncated = false;
                        break;
                    }
                }
            }
        }
    }

    if truncated {
        log::warn!(
            target: "agent_shield::resolver_runtime",
            "resolver chain truncated at MAX_CHAIN_DEPTH={}; deeper links ignored",
            MAX_CHAIN_DEPTH
        );
        // The truncated link might have been an Allow we never reached.
        // Annotate the deny-like outcome so callers and audit logs see why
        // the chain didn't continue. Allow / None outcomes already
        // returned earlier and aren't reached here.
        let resp = last.unwrap_or_else(|| ResolverResponse {
            decision: ResolverDecision::Deny,
            value: None,
            set_variables: HashMap::new(),
            reason: None,
        });
        let annotated_reason = match resp.reason {
            Some(r) => format!(
                "{} (resolver chain truncated at depth limit {})",
                r, MAX_CHAIN_DEPTH
            ),
            None => format!(
                "resolver chain truncated at depth limit {}",
                MAX_CHAIN_DEPTH
            ),
        };
        return ChainOutcome::Completed(ResolverResponse {
            reason: Some(annotated_reason),
            ..resp
        });
    }

    // Shadow (#14): convert terminal deny to Suppressed so finalize
    // is skipped (variable stays Unset).
    if let Some((kind, reason)) = first_suppression {
        return ChainOutcome::Suppressed { kind, reason };
    }

    ChainOutcome::Completed(last.unwrap_or_else(|| ResolverResponse {
        decision: ResolverDecision::Deny,
        value: None,
        set_variables: HashMap::new(),
        reason: Some("fallback chain exhausted with no responses".into()),
    }))
}

enum ChainStep {
    Completed(ResolverResponse),
    AdvanceTo(ResolverResponse),
}

fn map_error(
    err: ResolverRuntimeError,
    current: &Resolver,
    target_variable: Option<&Variable>,
    policy: OnError,
) -> ChainStep {
    let kind = current.kind_str();
    log::warn!(
        target: "agent_shield::resolver_runtime",
        "resolver `{}` errored ({}): {}; applying on_error: {:?}",
        kind, err.error_kind(), err, policy
    );
    let synthetic_reason = format!("resolver `{}` error: {}", kind, err);
    match policy {
        OnError::Block => ChainStep::Completed(ResolverResponse {
            decision: ResolverDecision::Deny,
            value: None,
            set_variables: HashMap::new(),
            reason: Some(synthetic_reason),
        }),
        OnError::Allow => ChainStep::Completed(ResolverResponse {
            decision: ResolverDecision::Allow,
            value: Some(Value::Null),
            set_variables: HashMap::new(),
            reason: Some(synthetic_reason),
        }),
        OnError::UseDefault => match target_variable.and_then(|v| v.default.clone()) {
            Some(default) => ChainStep::Completed(ResolverResponse {
                decision: ResolverDecision::Allow,
                value: Some(default),
                set_variables: HashMap::new(),
                reason: Some(synthetic_reason),
            }),
            None => ChainStep::Completed(ResolverResponse {
                decision: ResolverDecision::Deny,
                value: None,
                set_variables: HashMap::new(),
                reason: Some(format!(
                    "{} (on_error: use_default but variable has no `default:`)",
                    synthetic_reason
                )),
            }),
        },
        OnError::UseFallback => {
            // If a next link exists, carry a synthetic deny-like marker so
            // run_with_fallback advances. Otherwise behave like block.
            if next_link(current).is_some() {
                ChainStep::AdvanceTo(ResolverResponse {
                    decision: ResolverDecision::Deny,
                    value: None,
                    set_variables: HashMap::new(),
                    reason: Some(synthetic_reason),
                })
            } else {
                ChainStep::Completed(ResolverResponse {
                    decision: ResolverDecision::Deny,
                    value: None,
                    set_variables: HashMap::new(),
                    reason: Some(format!(
                        "{} (on_error: use_fallback but no fallback declared)",
                        synthetic_reason
                    )),
                })
            }
        }
    }
}

fn next_link(r: &Resolver) -> Option<&Resolver> {
    match r {
        Resolver::Expression { fallback, .. }
        | Resolver::Tool { fallback, .. }
        | Resolver::Human { fallback, .. }
        | Resolver::Delegate { fallback, .. }
        | Resolver::Agent { fallback, .. } => fallback.as_deref(),
    }
}

fn on_error_of(r: &Resolver) -> OnError {
    match r {
        Resolver::Expression { .. } | Resolver::Tool { .. } => OnError::Block,
        Resolver::Human { on_error, .. }
        | Resolver::Delegate { on_error, .. }
        | Resolver::Agent { on_error, .. } => on_error.unwrap_or(OnError::Block),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    fn allow() -> ResolverResponse {
        ResolverResponse {
            decision: ResolverDecision::Allow,
            value: Some(json!(true)),
            set_variables: HashMap::new(),
            reason: None,
        }
    }

    fn deny(msg: &str) -> ResolverResponse {
        ResolverResponse {
            decision: ResolverDecision::Deny,
            value: None,
            set_variables: HashMap::new(),
            reason: Some(msg.into()),
        }
    }

    fn cancelled(msg: &str) -> ResolverResponse {
        ResolverResponse {
            decision: ResolverDecision::Cancelled,
            value: None,
            set_variables: HashMap::new(),
            reason: Some(msg.into()),
        }
    }

    fn human_chain(prompts: &[&str]) -> Resolver {
        // build a chain "human" -> ... in YAML form
        let mut yaml = String::new();
        for (i, p) in prompts.iter().enumerate() {
            yaml.push_str(&"  ".repeat(i));
            if i > 0 {
                yaml.push_str("fallback:\n");
                yaml.push_str(&"  ".repeat(i));
            }
            yaml.push_str(&format!(
                "kind: human\n{}prompt: \"{}\"\n",
                "  ".repeat(i),
                p
            ));
        }
        // Simpler: hand-rolled YAML.
        let mut nested = String::new();
        for p in prompts.iter().rev() {
            if nested.is_empty() {
                nested = format!("kind: human\nprompt: \"{}\"\n", p);
            } else {
                let indented: String = nested.lines().map(|l| format!("  {}\n", l)).collect();
                nested = format!("kind: human\nprompt: \"{}\"\nfallback:\n{}", p, indented);
            }
        }
        serde_yaml::from_str(&nested).unwrap()
    }

    #[test]
    fn allow_at_head_short_circuits() {
        let chain = human_chain(&["a", "b", "c"]);
        let calls = std::cell::Cell::new(0u32);
        let resp = run_with_fallback(&chain, None, &|_r| {
            calls.set(calls.get() + 1);
            Ok(LinkOutcome::Completed(allow()))
        })
        .into_response();
        assert_eq!(resp.decision, ResolverDecision::Allow);
        assert_eq!(calls.get(), 1);
    }

    #[test]
    fn fallback_rescues_deny() {
        let chain = human_chain(&["a", "b"]);
        let counter = std::cell::Cell::new(0u32);
        let resp = run_with_fallback(&chain, None, &|_r| {
            counter.set(counter.get() + 1);
            if counter.get() == 1 {
                Ok(LinkOutcome::Completed(deny("first")))
            } else {
                Ok(LinkOutcome::Completed(allow()))
            }
        })
        .into_response();
        assert_eq!(resp.decision, ResolverDecision::Allow);
        assert_eq!(counter.get(), 2);
    }

    #[test]
    fn final_outcome_is_last_response_when_all_deny() {
        let chain = human_chain(&["a", "b", "c"]);
        let counter = std::cell::Cell::new(0u32);
        let resp = run_with_fallback(&chain, None, &|_r| {
            counter.set(counter.get() + 1);
            Ok(LinkOutcome::Completed(deny(&format!(
                "link{}",
                counter.get()
            ))))
        })
        .into_response();
        assert_eq!(resp.decision, ResolverDecision::Deny);
        assert_eq!(resp.reason.as_deref(), Some("link3"));
        assert_eq!(counter.get(), 3);
    }

    #[test]
    fn cancelled_advances_through_fallback() {
        let chain = human_chain(&["a", "b"]);
        let counter = std::cell::Cell::new(0u32);
        let resp = run_with_fallback(&chain, None, &|_r| {
            counter.set(counter.get() + 1);
            if counter.get() == 1 {
                Ok(LinkOutcome::Completed(cancelled("nope")))
            } else {
                Ok(LinkOutcome::Completed(allow()))
            }
        })
        .into_response();
        assert_eq!(resp.decision, ResolverDecision::Allow);
    }

    #[test]
    fn cancelled_terminal_yields_cancelled() {
        let chain = human_chain(&["a"]);
        let resp = run_with_fallback(&chain, None, &|_r| {
            Ok(LinkOutcome::Completed(cancelled("user aborted")))
        })
        .into_response();
        assert_eq!(resp.decision, ResolverDecision::Cancelled);
    }

    #[test]
    fn error_with_block_synthesizes_deny_and_advances() {
        // human resolver default on_error is `block` → deny → advance.
        let chain = human_chain(&["a", "b"]);
        let counter = std::cell::Cell::new(0u32);
        let resp = run_with_fallback(&chain, None, &|_r| {
            counter.set(counter.get() + 1);
            if counter.get() == 1 {
                Err(ResolverRuntimeError::Timeout {
                    kind: "human",
                    timeout_ms: 100,
                })
            } else {
                Ok(LinkOutcome::Completed(allow()))
            }
        })
        .into_response();
        assert_eq!(resp.decision, ResolverDecision::Allow);
        assert_eq!(counter.get(), 2);
    }

    #[test]
    fn error_with_use_fallback_advances() {
        let yaml = "kind: human\nprompt: \"a\"\non_error: use_fallback\nfallback:\n  kind: human\n  prompt: \"b\"\n";
        let chain: Resolver = serde_yaml::from_str(yaml).unwrap();
        let counter = std::cell::Cell::new(0u32);
        let resp = run_with_fallback(&chain, None, &|_r| {
            counter.set(counter.get() + 1);
            if counter.get() == 1 {
                Err(ResolverRuntimeError::Transport {
                    kind: "human",
                    message: "x".into(),
                })
            } else {
                Ok(LinkOutcome::Completed(allow()))
            }
        })
        .into_response();
        assert_eq!(resp.decision, ResolverDecision::Allow);
        assert_eq!(counter.get(), 2);
    }

    #[test]
    fn error_with_allow_terminates() {
        let yaml = "kind: human\nprompt: \"a\"\non_error: allow\n";
        let chain: Resolver = serde_yaml::from_str(yaml).unwrap();
        let resp = run_with_fallback(&chain, None, &|_r| {
            Err(ResolverRuntimeError::Timeout {
                kind: "human",
                timeout_ms: 100,
            })
        })
        .into_response();
        assert_eq!(resp.decision, ResolverDecision::Allow);
        assert_eq!(resp.value, Some(Value::Null));
    }

    #[test]
    fn error_with_use_default_uses_variable_default() {
        let yaml = "kind: human\nprompt: \"a\"\non_error: use_default\n";
        let chain: Resolver = serde_yaml::from_str(yaml).unwrap();
        let var = Variable {
            name: "x".into(),
            var_type: crate::variables::VariableType::Boolean,
            description: None,
            default: Some(json!(true)),
            members: None,
            update: None,
            key: None,
            lifetime: None,
            on_demand_by: None,
            populated_by: vec![],
            reset_by: vec![],
        };
        let resp = run_with_fallback(&chain, Some(&var), &|_r| {
            Err(ResolverRuntimeError::Timeout {
                kind: "human",
                timeout_ms: 100,
            })
        })
        .into_response();
        assert_eq!(resp.decision, ResolverDecision::Allow);
        assert_eq!(resp.value, Some(json!(true)));
    }

    #[test]
    fn error_with_use_default_no_default_blocks() {
        let yaml = "kind: human\nprompt: \"a\"\non_error: use_default\n";
        let chain: Resolver = serde_yaml::from_str(yaml).unwrap();
        let resp = run_with_fallback(&chain, None, &|_r| {
            Err(ResolverRuntimeError::Timeout {
                kind: "human",
                timeout_ms: 100,
            })
        })
        .into_response();
        assert_eq!(resp.decision, ResolverDecision::Deny);
    }

    #[test]
    fn three_deep_chain_walks_in_order() {
        let chain = human_chain(&["a", "b", "c"]);
        let counter = std::cell::Cell::new(0u32);
        let resp = run_with_fallback(&chain, None, &|_r| {
            counter.set(counter.get() + 1);
            if counter.get() == 3 {
                Ok(LinkOutcome::Completed(allow()))
            } else {
                Ok(LinkOutcome::Completed(deny("x")))
            }
        })
        .into_response();
        assert_eq!(resp.decision, ResolverDecision::Allow);
        assert_eq!(counter.get(), 3);
    }

    #[test]
    fn cycle_detection_breaks_at_repeat() {
        // We can't trivially construct a cycle through the `Resolver` AST
        // because `fallback` is `Box<Resolver>` (owned). Synthesize a
        // cycle by repeatedly invoking the same head — the visited-pointer
        // test ensures we don't loop indefinitely.
        let chain = human_chain(&["a"]);
        let resp = run_with_fallback(&chain, None, &|_r| Ok(LinkOutcome::Completed(deny("x"))))
            .into_response();
        // Single-link chain: returns the first deny.
        assert_eq!(resp.decision, ResolverDecision::Deny);
    }

    // P5.5: chain longer than MAX_CHAIN_DEPTH truncates with annotated reason.
    #[test]
    fn truncation_at_max_chain_depth_annotates_reason() {
        // Build a chain of MAX_CHAIN_DEPTH + 4 deny links.
        let prompts: Vec<String> = (0..(MAX_CHAIN_DEPTH + 4))
            .map(|i| format!("p{}", i))
            .collect();
        let prompt_refs: Vec<&str> = prompts.iter().map(String::as_str).collect();
        let chain = human_chain(&prompt_refs);
        let calls = std::cell::Cell::new(0u32);
        let resp = run_with_fallback(&chain, None, &|_r| {
            calls.set(calls.get() + 1);
            Ok(LinkOutcome::Completed(deny("nope")))
        })
        .into_response();
        assert_eq!(
            calls.get() as usize,
            MAX_CHAIN_DEPTH,
            "loop must visit exactly MAX_CHAIN_DEPTH links before truncating"
        );
        assert_eq!(resp.decision, ResolverDecision::Deny);
        let reason = resp
            .reason
            .as_deref()
            .expect("reason annotated on truncation");
        assert!(
            reason.contains("truncated"),
            "reason must mention truncation: {:?}",
            reason
        );
    }

    #[test]
    fn chain_at_exactly_max_depth_is_not_truncated() {
        // Exactly MAX_CHAIN_DEPTH deny links: the loop ends naturally
        // because the last link's `next_link()` returns None. No
        // truncation reason annotation should be added.
        let prompts: Vec<String> = (0..MAX_CHAIN_DEPTH).map(|i| format!("p{}", i)).collect();
        let prompt_refs: Vec<&str> = prompts.iter().map(String::as_str).collect();
        let chain = human_chain(&prompt_refs);
        let resp = run_with_fallback(&chain, None, &|_r| {
            Ok(LinkOutcome::Completed(deny("plain")))
        })
        .into_response();
        assert_eq!(resp.decision, ResolverDecision::Deny);
        assert_eq!(resp.reason.as_deref(), Some("plain"));
    }
}
