//! Composable guardrails configuration.
//!
//! [`GuardrailsConfig`] is the user-facing builder for assembling a
//! guardrails policy from multiple sources (file paths, YAML strings,
//! Rust `Value` objects) with leaf-wins layering. [`compile()`]
//! materialises the chain into a hashable [`CompiledPolicy`] that the
//! runtime accepts directly via
//! [`RuntimeBuilder::from_compiled_policy`](crate::runtime::RuntimeBuilder::from_compiled_policy).
//!
//! The [`CompiledPolicy`] carries:
//!
//! * the canonical merged configuration (`Arc<MergedConfig>`), and
//! * a `digest` — SHA-256 over a canonical JSON encoding of the merged
//!   configuration AST (sorted keys, post-`extends`, post-overrides,
//!   post-validation, post-defaults). The digest is byte-stable across
//!   languages so SaaS multi-tenant callers can cache compiled
//!   runtimes by content.
//!
//! The same logic is exposed identically through PyO3, napi-rs, and
//! the C ABI so every SDK shares one canonical implementation.

use std::path::{Path, PathBuf};
use std::sync::Arc;

use serde_json::Value;
use sha2::{Digest, Sha256};

use crate::errors::{ConfigError, SourceLoc};
use crate::loader::{load_from_paths_impl, load_from_strings};
use crate::merge::MergedConfig;

// ─────────────────────────────────────────────────────────────────────
// Layer
// ─────────────────────────────────────────────────────────────────────

/// One layer of a [`GuardrailsConfig`] chain.
///
/// At [`compile()`](GuardrailsConfig::compile) time each layer is
/// materialised to a YAML string and the chain is merged with leaf-wins
/// semantics through [`load_from_strings`].
#[derive(Debug, Clone)]
pub enum Layer {
    /// A path to a YAML file on disk. Read at compile time.
    Path(PathBuf),
    /// A raw YAML string supplied by the host.
    String(String),
    /// A typed value supplied by the host (serialised to YAML at
    /// compile time). Useful for in-memory overrides that don't need
    /// to round-trip through YAML at the call site.
    Object(Value),
}

// ─────────────────────────────────────────────────────────────────────
// GuardrailsConfig
// ─────────────────────────────────────────────────────────────────────

/// Composable, immutable-by-convention guardrails configuration.
///
/// Every fluent method returns a new instance — layers compose without
/// aliasing. [`compile()`](Self::compile) produces a
/// [`CompiledPolicy`] that the runtime accepts via
/// [`RuntimeBuilder::from_compiled_policy`](crate::runtime::RuntimeBuilder::from_compiled_policy).
///
/// ```no_run
/// use agent_shield_core::config::GuardrailsConfig;
///
/// let cfg = GuardrailsConfig::load("base.yaml")
///     .extend(GuardrailsConfig::load("enterprise.yaml"))
///     .with_overrides(serde_json::json!({
///         "metadata": { "description": "monitor mode" }
///     }))
///     .compile()
///     .unwrap();
///
/// // cfg.digest is stable across languages for the same content.
/// ```
#[derive(Debug, Clone, Default)]
pub struct GuardrailsConfig {
    layers: Vec<Layer>,
}

impl GuardrailsConfig {
    // ── Constructors ─────────────────────────────────────────────

    /// Start a chain from a single YAML file.
    pub fn load(path: impl Into<PathBuf>) -> Self {
        Self {
            layers: vec![Layer::Path(path.into())],
        }
    }

    /// Start a chain from a raw YAML string.
    pub fn from_string(yaml: impl Into<String>) -> Self {
        Self {
            layers: vec![Layer::String(yaml.into())],
        }
    }

    /// Start a chain from a typed value (serialised to YAML at compile
    /// time).
    pub fn from_value(value: Value) -> Self {
        Self {
            layers: vec![Layer::Object(value)],
        }
    }

    /// Compose multiple sources in one call. Each source is dispatched
    /// by type to the appropriate constructor.
    pub fn compose(layers: Vec<Layer>) -> Self {
        Self { layers }
    }

    // ── Fluent extension ────────────────────────────────────────

    /// Append another configuration's layers to this chain. Leaf-wins
    /// — `other`'s layers come after `self`'s.
    pub fn extend(mut self, other: Self) -> Self {
        self.layers.extend(other.layers);
        self
    }

    /// Append a single path layer.
    pub fn extend_path(mut self, path: impl Into<PathBuf>) -> Self {
        self.layers.push(Layer::Path(path.into()));
        self
    }

    /// Append a single YAML-string layer.
    pub fn extend_string(mut self, yaml: impl Into<String>) -> Self {
        self.layers.push(Layer::String(yaml.into()));
        self
    }

    /// Append a final value-shaped layer that overrides earlier values.
    /// Equivalent to `extend_value` but documents intent for
    /// targeted overrides (mode change, metadata patch, per-tenant
    /// flag).
    pub fn with_overrides(mut self, overrides: Value) -> Self {
        self.layers.push(Layer::Object(overrides));
        self
    }

    /// Append a "policy pack" layer. Semantically identical to
    /// `extend_path` / `with_overrides` — separate name documents
    /// intent.
    pub fn with_policy_pack(mut self, pack: Layer) -> Self {
        self.layers.push(pack);
        self
    }

    // ── Inspection ──────────────────────────────────────────────

    pub fn layers(&self) -> &[Layer] {
        &self.layers
    }

    pub fn len(&self) -> usize {
        self.layers.len()
    }

    pub fn is_empty(&self) -> bool {
        self.layers.is_empty()
    }

    // ── Digest-only ─────────────────────────────────────────────

    /// Compute the canonical SHA-256 digest over the materialised YAML
    /// chain.
    ///
    /// This is the introspection twin of [`compile()`](Self::compile):
    /// it lets callers fingerprint a chain (multi-tenant cache key,
    /// log line, deduplication). The digest is **byte-stable** with
    /// the digest produced by [`compile()`](Self::compile) for the
    /// same content — including `extends:` parents and resolved
    /// `prompt_path:` file contents on pure-path chains.
    ///
    /// **Side effect**: for pure-path chains, `digest()` exercises the
    /// loader's full path-load pipeline (so `extends:` parents and
    /// `prompt_path:` files are resolved). A chain that fails to
    /// load (missing file, integrity mismatch, etc.) will therefore
    /// fail here too — partial-overlay introspection on chains with
    /// `extends:` is not supported.
    ///
    /// Source-only: this does NOT fold in the `AGENT_SHIELD_MODE` env
    /// override (#14). For an effective-mode-aware fingerprint, use
    /// [`CompiledPolicy::digest`].
    pub fn digest(&self) -> Result<String, ConfigError> {
        if self.layers.is_empty() {
            return Err(ConfigError::Schema {
                loc: SourceLoc::default(),
                message: "GuardrailsConfig.digest: no layers".into(),
            });
        }
        let digest_input = self.digest_input()?;
        canonical_digest(&digest_input)
    }

    /// Materialise the same digest input that `compile()` would use,
    /// without computing the SHA-256 hash. See `compile()` for the
    /// pure-path vs. mixed-chain dispatch rationale.
    fn digest_input(&self) -> Result<Vec<String>, ConfigError> {
        if self.layers.iter().all(|l| matches!(l, Layer::Path(_))) {
            let paths: Vec<&Path> = self
                .layers
                .iter()
                .map(|l| match l {
                    Layer::Path(p) => p.as_path(),
                    _ => unreachable!(),
                })
                .collect();
            Ok(load_from_paths_impl(&paths)?.inlined_yamls)
        } else {
            self.materialise_strings()
        }
    }

    // ── Compilation ─────────────────────────────────────────────

    /// Materialise the chain into a [`CompiledPolicy`].
    ///
    /// Steps:
    ///
    /// 1. Each layer is rendered to a YAML string (paths read from
    ///    disk; values serialised via `serde_yaml`).
    /// 2. Each YAML string is parsed to a JSON `Value` and canonicalised
    ///    (recursive sorted-key encoding); the digest is SHA-256 over
    ///    the joined canonical-JSON inputs. Same content → same digest
    ///    across languages, independent of YAML formatting (whitespace,
    ///    quote style, key order).
    /// 3. The chain is fed to [`load_from_strings`] for parsing, merge,
    ///    `extends:` rejection, default materialisation, and validation.
    pub fn compile(&self) -> Result<CompiledPolicy, ConfigError> {
        if self.layers.is_empty() {
            return Err(ConfigError::Schema {
                loc: SourceLoc::default(),
                message: "GuardrailsConfig.compile: no layers to compile".into(),
            });
        }

        // Pure-path chains keep author-supplied `extends:` resolution
        // at the file level. Mixed chains go through load_from_strings.
        //
        // The two branches diverge on what feeds the digest:
        //
        // - Pure-path: `load_from_paths_impl` returns the **inlined**
        //   YAML bytes for every node in the loaded chain (parents
        //   first, leaf last), with `evaluate_when[].llm.prompt_path`
        //   already replaced by inlined `prompt:` text per §12.9.2.
        //   The digest covers all of those — including `extends:`
        //   parents and resolved prompt-file contents — so two
        //   policies with identical YAML text but different prompt
        //   files produce different digests.
        //
        // - Mixed: `materialise_strings` emits only explicit layer
        //   YAMLs (path layers are read raw; string/object layers are
        //   serialised). These then flow into `load_from_strings`,
        //   which rejects both `extends:` and `prompt_path:` (the
        //   latter via `parse_one` raising `NoAnchorDir` — a
        //   string-input load has no anchor directory). So the
        //   digest input for the mixed path is also byte-correct:
        //   every prompt is inline.
        let (merged, digest_input) = if self.layers.iter().all(|l| matches!(l, Layer::Path(_))) {
            let paths: Vec<&Path> = self
                .layers
                .iter()
                .map(|l| match l {
                    Layer::Path(p) => p.as_path(),
                    _ => unreachable!(),
                })
                .collect();
            let loaded = load_from_paths_impl(&paths)?;
            (loaded.merged, loaded.inlined_yamls)
        } else {
            let yamls = self.materialise_strings()?;
            let refs: Vec<&str> = yamls.iter().map(|s| s.as_str()).collect();
            let merged = load_from_strings(&refs)?;
            (merged, yamls)
        };

        let digest = canonical_digest(&digest_input)?;
        Ok(CompiledPolicy {
            merged: Arc::new(merged),
            digest,
        })
    }

    /// Render every layer to a YAML string.
    fn materialise_strings(&self) -> Result<Vec<String>, ConfigError> {
        let mut out = Vec::with_capacity(self.layers.len());
        for layer in &self.layers {
            match layer {
                Layer::Path(p) => {
                    let text = std::fs::read_to_string(p).map_err(|e| ConfigError::Schema {
                        loc: SourceLoc::default(),
                        message: format!("GuardrailsConfig: read {}: {}", p.display(), e),
                    })?;
                    out.push(text);
                }
                Layer::String(s) => out.push(s.clone()),
                Layer::Object(v) => {
                    let yaml = serde_yaml::to_string(v).map_err(|e| ConfigError::Schema {
                        loc: SourceLoc::default(),
                        message: format!("GuardrailsConfig: serialise object layer: {e}"),
                    })?;
                    out.push(yaml);
                }
            }
        }
        Ok(out)
    }
}

// ─────────────────────────────────────────────────────────────────────
// CompiledPolicy
// ─────────────────────────────────────────────────────────────────────

/// The materialised, hashable result of [`GuardrailsConfig::compile`].
///
/// `digest` is SHA-256 (lowercase hex) over a canonical JSON encoding
/// of the merged configuration AST. Identical content always produces
/// identical digests across languages — multi-tenant SaaS callers can
/// cache compiled runtimes by content.
#[derive(Debug, Clone)]
pub struct CompiledPolicy {
    merged: Arc<MergedConfig>,
    digest: String,
}

impl CompiledPolicy {
    /// Access the inner merged configuration. Used by
    /// [`RuntimeBuilder::from_compiled_policy`](crate::runtime::RuntimeBuilder::from_compiled_policy).
    pub fn merged(&self) -> &Arc<MergedConfig> {
        &self.merged
    }

    /// SHA-256 (lowercase hex) of the canonical JSON encoding of the
    /// merged configuration.
    pub fn digest(&self) -> &str {
        &self.digest
    }
}

impl PartialEq for CompiledPolicy {
    fn eq(&self, other: &Self) -> bool {
        self.digest == other.digest
    }
}

impl Eq for CompiledPolicy {}

impl std::hash::Hash for CompiledPolicy {
    fn hash<H: std::hash::Hasher>(&self, state: &mut H) {
        self.digest.hash(state);
    }
}

// ─────────────────────────────────────────────────────────────────────
// Canonical digest
// ─────────────────────────────────────────────────────────────────────

/// SHA-256 (lowercase hex) over the canonical JSON encoding of the
/// chain's input YAMLs.
///
/// "Canonical" here means: each YAML string is parsed to a JSON
/// `Value`; every JSON object's keys are sorted recursively; the per-
/// layer canonical bytes are joined with a fixed delimiter
/// (`\n---\n`); the result is hashed.
///
/// Same content produces the same digest across SDKs regardless of
/// YAML formatting (whitespace, quote style, key order, comments).
fn canonical_digest(yaml_layers: &[String]) -> Result<String, ConfigError> {
    let mut hasher = Sha256::new();
    for (i, yaml) in yaml_layers.iter().enumerate() {
        if i > 0 {
            hasher.update(b"\n---\n");
        }
        // Parse YAML → serde_json::Value, then canonicalise keys.
        let value: Value = serde_yaml::from_str(yaml).map_err(|e| ConfigError::Schema {
            loc: SourceLoc::default(),
            message: format!("GuardrailsConfig: parse layer {i} for digest: {e}"),
        })?;
        let canonical = canonicalise_json(value);
        let bytes = serde_json::to_vec(&canonical).map_err(|e| ConfigError::Schema {
            loc: SourceLoc::default(),
            message: format!("GuardrailsConfig: serialise layer {i} for digest: {e}"),
        })?;
        hasher.update(&bytes);
    }
    Ok(hex_encode(&hasher.finalize()))
}

/// Recursively sort object keys so any equivalent input produces the
/// same byte sequence.
fn canonicalise_json(value: Value) -> Value {
    match value {
        Value::Object(map) => {
            let mut entries: Vec<(String, Value)> = map
                .into_iter()
                .map(|(k, v)| (k, canonicalise_json(v)))
                .collect();
            entries.sort_by(|a, b| a.0.cmp(&b.0));
            let mut out = serde_json::Map::with_capacity(entries.len());
            for (k, v) in entries {
                out.insert(k, v);
            }
            Value::Object(out)
        }
        Value::Array(items) => Value::Array(items.into_iter().map(canonicalise_json).collect()),
        scalar => scalar,
    }
}

fn hex_encode(bytes: &[u8]) -> String {
    const HEX: &[u8] = b"0123456789abcdef";
    let mut out = String::with_capacity(bytes.len() * 2);
    for b in bytes {
        out.push(HEX[(*b >> 4) as usize] as char);
        out.push(HEX[(*b & 0xf) as usize] as char);
    }
    out
}

// ─────────────────────────────────────────────────────────────────────
// Tests
// ─────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use crate::shield_primitives::RuntimeMode;
    use std::io::Write;

    fn write_temp(yaml: &str) -> tempfile::NamedTempFile {
        let mut f = tempfile::Builder::new()
            .suffix(".guardrails.yaml")
            .tempfile()
            .unwrap();
        f.write_all(yaml.as_bytes()).unwrap();
        f
    }

    fn minimal_yaml() -> &'static str {
        r#"
metadata:
  name: minimal
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
  forbidden: ["evil"]
resources:
  tools: []
"#
    }

    #[test]
    fn empty_chain_compile_errors() {
        let cfg = GuardrailsConfig::default();
        assert!(cfg.compile().is_err());
    }

    #[test]
    fn single_path_layer_compiles() {
        let f = write_temp(minimal_yaml());
        let cfg = GuardrailsConfig::load(f.path());
        let compiled = cfg.compile().unwrap();
        assert_eq!(compiled.merged().metadata.name, "minimal");
        assert_eq!(compiled.digest().len(), 64); // sha256 hex
    }

    #[test]
    fn single_string_layer_compiles() {
        let cfg = GuardrailsConfig::from_string(minimal_yaml());
        let compiled = cfg.compile().unwrap();
        assert_eq!(compiled.merged().metadata.name, "minimal");
    }

    #[test]
    fn digest_is_deterministic_for_same_content() {
        let a = GuardrailsConfig::from_string(minimal_yaml())
            .compile()
            .unwrap();
        let b = GuardrailsConfig::from_string(minimal_yaml())
            .compile()
            .unwrap();
        assert_eq!(a.digest(), b.digest());
        assert_eq!(a, b);
    }

    #[test]
    fn digest_differs_when_content_differs() {
        let a = GuardrailsConfig::from_string(minimal_yaml())
            .compile()
            .unwrap();
        let modified = minimal_yaml().replace("name: minimal", "name: leaf");
        let b = GuardrailsConfig::from_string(&modified).compile().unwrap();
        assert_ne!(a.digest(), b.digest());
    }

    #[test]
    fn fluent_extend_appends_layers() {
        let cfg = GuardrailsConfig::from_string(minimal_yaml())
            .extend(GuardrailsConfig::from_string(minimal_yaml()));
        assert_eq!(cfg.len(), 2);
        let _ = cfg.compile().unwrap();
    }

    #[test]
    fn with_overrides_appends_object_layer() {
        let overlay = serde_json::json!({
            "metadata": {
                "name": "leaf",
                "version": "0.1.0",
                "agent_shield_version": "2.0",
            },
            "objective": { "goal": ["overlay"], "forbidden": [] },
            "resources": { "tools": [] },
        });
        let cfg = GuardrailsConfig::from_string(minimal_yaml()).with_overrides(overlay);
        let compiled = cfg.compile().unwrap();
        // Leaf wins on metadata.name.
        assert_eq!(compiled.merged().metadata.name, "leaf");
    }

    #[test]
    fn canonical_digest_ignores_key_order() {
        // Two YAML strings differing only in key order should produce
        // the same digest because canonical_json sorts keys.
        let yaml_a = r#"
metadata:
  name: same
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["a"]
  forbidden: []
resources:
  tools: []
"#;
        let yaml_b = r#"
resources:
  tools: []
objective:
  forbidden: []
  goal: ["a"]
metadata:
  agent_shield_version: "2.0"
  version: "0.1.0"
  name: same
"#;
        let a = GuardrailsConfig::from_string(yaml_a).compile().unwrap();
        let b = GuardrailsConfig::from_string(yaml_b).compile().unwrap();
        assert_eq!(a.digest(), b.digest());
    }

    #[test]
    fn compiled_digest_is_unaffected_by_runtime_mode() {
        // `mode:` is a runtime knob, not a YAML field. The digest is
        // identity for the policy bundle bytes only — multi-tenant
        // cache keys that need to distinguish active vs. shadow runs
        // must compose `(digest, mode)` themselves.
        let yaml = minimal_yaml().to_string();
        let a = GuardrailsConfig::from_string(&yaml).compile().unwrap();
        let b = GuardrailsConfig::from_string(&yaml).compile().unwrap();
        assert_eq!(a.digest(), b.digest());
        assert_eq!(a.merged().mode, RuntimeMode::Active);
    }
}
