//! Azure AI Content Safety (AACS).
//!
//! Endpoint: `<resource>.cognitiveservices.azure.com/contentsafety/text:analyze?api-version=...`.
//! Request body: `{ "text": "<subject>", "categories": [...], "outputType": "FourSeverityLevels" }`.
//! Response body: `{ "categoriesAnalysis": [{ "category": "...", "severity": int }] }`.
//!
//! Severity is an integer 0..6 (FourSeverityLevels uses 0/2/4/6); we
//! normalize to a [0.0, 1.0] score so `category_thresholds` and the
//! global `threshold` use a consistent scale.

use std::collections::HashMap;

use serde_json::{json, Value};

use crate::classifiers::auto::BundledProvider;
use crate::classifiers::transport::{HttpTransport, TransportRequest};
use crate::classifiers::verdict::{fold_score_verdict, ResolvedClassifierConfig};
use crate::guard_policy_runtime::ClassifierVerdict;

const DEFAULT_API_VERSION: &str = "2024-09-01";
const DEFAULT_CATEGORIES: &[&str] = &["Hate", "SelfHarm", "Sexual", "Violence"];

pub struct AacsProvider;

impl BundledProvider for AacsProvider {
    fn classify(
        &self,
        cfg: &ResolvedClassifierConfig,
        subject: &str,
        transport: &dyn HttpTransport,
    ) -> Result<ClassifierVerdict, String> {
        let api_key = cfg.api_key.as_deref().ok_or("aacs: api_key not resolved")?;
        if cfg.endpoint.is_empty() {
            return Err("aacs: `endpoint` is required (Azure resource URL)".into());
        }
        let api_version = cfg
            .provider_config
            .get("api_version")
            .and_then(|v| v.as_str())
            .unwrap_or(DEFAULT_API_VERSION);
        // Build the analyze URL: append /contentsafety/text:analyze?api-version=...
        // unless the host has already supplied that path.
        let endpoint = cfg.endpoint.trim_end_matches('/');
        let url = if endpoint.contains("/contentsafety/") {
            // Author supplied a fully-qualified analyze URL.
            if endpoint.contains("?api-version=") {
                endpoint.to_string()
            } else {
                format!("{endpoint}?api-version={api_version}")
            }
        } else {
            format!("{endpoint}/contentsafety/text:analyze?api-version={api_version}")
        };

        let categories: Vec<String> = if !cfg.category_thresholds.is_empty() {
            cfg.category_thresholds.keys().cloned().collect()
        } else if let Some(arr) = cfg
            .provider_config
            .get("categories")
            .and_then(|v| v.as_array())
        {
            arr.iter()
                .filter_map(|v| v.as_str().map(|s| s.to_string()))
                .collect()
        } else {
            DEFAULT_CATEGORIES.iter().map(|s| s.to_string()).collect()
        };

        let body = json!({
            "text": subject,
            "categories": categories,
            "outputType": "FourSeverityLevels",
        });

        let mut req = TransportRequest::post(url)
            .header("Content-Type", "application/json")
            .header("Ocp-Apim-Subscription-Key", api_key.to_string())
            .json(body)
            .timeout_ms(cfg.timeout_ms);
        for (k, v) in &cfg.headers {
            req = req.header(k.as_str(), v.clone());
        }
        let (status, body) = transport.send(req)?;
        if !(200..300).contains(&status) {
            return Err(format!("aacs HTTP {status}: {body}"));
        }
        parse(cfg, &body)
    }
}

fn parse(cfg: &ResolvedClassifierConfig, body: &str) -> Result<ClassifierVerdict, String> {
    let json: Value = serde_json::from_str(body).map_err(|e| format!("aacs JSON parse: {e}"))?;
    let arr = json
        .get("categoriesAnalysis")
        .and_then(|v| v.as_array())
        .ok_or_else(|| "aacs response missing `categoriesAnalysis`".to_string())?;
    let mut scores: HashMap<String, f64> = HashMap::new();
    for entry in arr {
        let Some(cat) = entry.get("category").and_then(|c| c.as_str()) else {
            continue;
        };
        let sev = entry
            .get("severity")
            .and_then(|s| s.as_i64())
            .unwrap_or(0)
            .max(0);
        // 0/2/4/6 → 0.0 / 0.33 / 0.66 / 1.0
        let normalized = (sev as f64).min(6.0) / 6.0;
        scores.insert(cat.to_string(), normalized);
    }
    Ok(fold_score_verdict(cfg, &scores, false))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::classifiers::transport::StubHttpTransport;

    fn cfg() -> ResolvedClassifierConfig {
        let mut cats = HashMap::new();
        cats.insert("Hate".into(), 0.5);
        ResolvedClassifierConfig {
            id: "az".into(),
            provider: "aacs".into(),
            endpoint: "https://my.cognitiveservices.azure.com".into(),
            api_key: Some("k".into()),
            timeout_ms: 1000,
            threshold: 0.5,
            category_thresholds: cats,
            provider_config: Value::Null,
            headers: HashMap::new(),
        }
    }

    #[test]
    fn allow_when_severity_is_zero() {
        let body = r#"{
            "categoriesAnalysis":[
                { "category": "Hate", "severity": 0 }
            ]
        }"#;
        let t = StubHttpTransport::with_response(200, body);
        let v = AacsProvider.classify(&cfg(), "hi", &t).unwrap();
        assert!(!v.is_failure());
    }

    #[test]
    fn deny_when_severity_is_high() {
        let body = r#"{
            "categoriesAnalysis":[
                { "category": "Hate", "severity": 6 }
            ]
        }"#;
        let t = StubHttpTransport::with_response(200, body);
        let v = AacsProvider.classify(&cfg(), "hi", &t).unwrap();
        assert!(v.is_failure());
        assert_eq!(v.label.as_deref(), Some("Hate"));
    }

    #[test]
    fn http_429_is_fail_closed() {
        let t = StubHttpTransport::with_response(429, "rate-limited");
        let err = AacsProvider.classify(&cfg(), "x", &t).unwrap_err();
        assert!(err.contains("HTTP 429"));
    }

    #[test]
    fn malformed_response_is_fail_closed() {
        let t = StubHttpTransport::with_response(200, r#"{"foo":[]}"#);
        let err = AacsProvider.classify(&cfg(), "x", &t).unwrap_err();
        assert!(err.contains("missing `categoriesAnalysis`"));
    }

    #[test]
    fn header_uses_subscription_key() {
        let body = r#"{"categoriesAnalysis":[{"category":"Hate","severity":0}]}"#;
        let t = StubHttpTransport::with_response(200, body);
        let _ = AacsProvider.classify(&cfg(), "hi", &t).unwrap();
        let req = t.last_request().unwrap();
        assert_eq!(
            req.headers
                .get("Ocp-Apim-Subscription-Key")
                .map(String::as_str),
            Some("k")
        );
        assert!(req.url.contains("/contentsafety/text:analyze"));
    }
}
