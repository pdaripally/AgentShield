//! Meta Llama Guard — self-hosted safety classifier (typically served
//! via vLLM / Ollama / TGI / a custom inference endpoint).
//!
//! Llama Guard returns free-form text starting with `safe` or `unsafe`
//! followed by an optional comma-separated category list (`S1,S3`).
//! We parse that response shape against the §11.12.4 envelope.

#[allow(unused_imports)]
use std::collections::HashMap;

use serde_json::{json, Value};

use crate::classifiers::auto::BundledProvider;
use crate::classifiers::transport::{HttpTransport, TransportRequest};
use crate::classifiers::verdict::ResolvedClassifierConfig;
use crate::guard_policy_runtime::ClassifierVerdict;

pub struct LlamaGuardProvider;

impl BundledProvider for LlamaGuardProvider {
    fn classify(
        &self,
        cfg: &ResolvedClassifierConfig,
        subject: &str,
        transport: &dyn HttpTransport,
    ) -> Result<ClassifierVerdict, String> {
        if cfg.endpoint.is_empty() {
            return Err("llama_guard: `endpoint` is required (self-hosted)".into());
        }
        let model = cfg
            .provider_config
            .get("model")
            .and_then(|v| v.as_str())
            .unwrap_or("meta-llama/Llama-Guard-3-8B");
        // Default shape: OpenAI-compatible /v1/chat/completions.
        let body = json!({
            "model": model,
            "messages": [{"role": "user", "content": subject}],
            "temperature": 0.0,
            "max_tokens": 64,
        });
        let mut req = TransportRequest::post(cfg.endpoint.clone())
            .header("Content-Type", "application/json")
            .json(body)
            .timeout_ms(cfg.timeout_ms);
        if let Some(key) = &cfg.api_key {
            req = req.header("Authorization", format!("Bearer {key}"));
        }
        for (k, v) in &cfg.headers {
            req = req.header(k.as_str(), v.clone());
        }

        let (status, body) = transport.send(req)?;
        if !(200..300).contains(&status) {
            return Err(format!("llama_guard HTTP {status}: {body}"));
        }
        parse(cfg, &body)
    }
}

fn parse(cfg: &ResolvedClassifierConfig, body: &str) -> Result<ClassifierVerdict, String> {
    let json: Value =
        serde_json::from_str(body).map_err(|e| format!("llama_guard JSON parse: {e}"))?;
    let content = json
        .get("choices")
        .and_then(|c| c.get(0))
        .and_then(|c| c.get("message"))
        .and_then(|m| m.get("content"))
        .and_then(|c| c.as_str())
        .ok_or_else(|| "llama_guard response missing choices[0].message.content".to_string())?;

    let trimmed = content.trim();
    let (verdict_token, categories) = match trimmed.split_once('\n') {
        Some((first, rest)) => (first.trim(), rest.trim()),
        None => (trimmed, ""),
    };
    let lower = verdict_token.to_ascii_lowercase();
    let unsafe_label = lower.starts_with("unsafe");
    let safe_label = lower.starts_with("safe");
    if !unsafe_label && !safe_label {
        return Err(format!(
            "llama_guard: response did not start with 'safe' or 'unsafe': {}",
            trimmed
        ));
    }

    let categories_vec: Vec<String> = categories
        .split(|c: char| c == ',' || c.is_whitespace())
        .filter(|s| !s.is_empty())
        .map(|s| s.to_string())
        .collect();

    let label = categories_vec.first().cloned();
    Ok(ClassifierVerdict {
        score: if unsafe_label { 1.0 } else { 0.0 },
        threshold: cfg.threshold,
        flagged: unsafe_label,
        label,
        reason: if unsafe_label && !categories_vec.is_empty() {
            Some(format!(
                "llama_guard categories: {}",
                categories_vec.join(",")
            ))
        } else {
            None
        },
        spans: Vec::new(),
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::classifiers::transport::StubHttpTransport;

    fn cfg() -> ResolvedClassifierConfig {
        ResolvedClassifierConfig {
            id: "lg".into(),
            provider: "llama_guard".into(),
            endpoint: "http://llama:8080/v1/chat/completions".into(),
            api_key: None,
            timeout_ms: 1000,
            threshold: 0.5,
            category_thresholds: HashMap::new(),
            provider_config: Value::Null,
            headers: HashMap::new(),
        }
    }

    #[test]
    fn allow_on_safe() {
        let body = r#"{
            "choices":[{"message":{"content":"safe"}}]
        }"#;
        let t = StubHttpTransport::with_response(200, body);
        let v = LlamaGuardProvider.classify(&cfg(), "hi", &t).unwrap();
        assert!(!v.is_failure());
    }

    #[test]
    fn deny_on_unsafe_with_categories() {
        let body = r#"{
            "choices":[{"message":{"content":"unsafe\nS1,S3"}}]
        }"#;
        let t = StubHttpTransport::with_response(200, body);
        let v = LlamaGuardProvider.classify(&cfg(), "hi", &t).unwrap();
        assert!(v.is_failure());
        assert_eq!(v.label.as_deref(), Some("S1"));
    }

    #[test]
    fn http_5xx_is_fail_closed() {
        let t = StubHttpTransport::with_response(502, "bad gateway");
        let err = LlamaGuardProvider.classify(&cfg(), "x", &t).unwrap_err();
        assert!(err.contains("HTTP 502"));
    }

    #[test]
    fn unknown_verdict_token_is_fail_closed() {
        let body = r#"{"choices":[{"message":{"content":"maybe"}}]}"#;
        let t = StubHttpTransport::with_response(200, body);
        let err = LlamaGuardProvider.classify(&cfg(), "x", &t).unwrap_err();
        assert!(err.contains("did not start with"));
    }

    #[test]
    fn missing_endpoint_is_fail_closed() {
        let mut c = cfg();
        c.endpoint = "".into();
        let t = StubHttpTransport::with_response(200, "{}");
        let err = LlamaGuardProvider.classify(&c, "x", &t).unwrap_err();
        assert!(err.contains("`endpoint` is required"));
    }
}
