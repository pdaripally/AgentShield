//! [`AutoWiredClassifierCaller`] — multiplexer that dispatches by
//! `configuration_id` to the right bundled provider.

use std::collections::HashMap;
use std::sync::Arc;

use crate::configurations::{ConfigurationType, ShieldConfiguration};
use crate::guard_policy_runtime::{ClassifierCaller, ClassifierVerdict};

use super::transport::{HttpTransport, ReqwestHttpTransport};
use super::verdict::ResolvedClassifierConfig;

/// Per-provider classifier dispatch. Each bundled provider implements
/// `classify` against the resolved snapshot + the shared transport.
pub(super) trait BundledProvider: Send + Sync {
    fn classify(
        &self,
        cfg: &ResolvedClassifierConfig,
        subject: &str,
        transport: &dyn HttpTransport,
    ) -> Result<ClassifierVerdict, String>;
}

/// Multiplexer that owns the resolved-config map keyed by
/// `configuration_id` and dispatches to the right provider on each
/// call.
pub struct AutoWiredClassifierCaller {
    configs: HashMap<String, (ResolvedClassifierConfig, Arc<dyn BundledProvider>)>,
    transport: Arc<dyn HttpTransport>,
}

impl AutoWiredClassifierCaller {
    /// Build a caller from the merged `configurations[]` block. Entries
    /// with an unsupported provider, missing endpoint/api_key, or
    /// disabled Cargo feature are skipped silently — those configuration
    /// ids fall through to the engine's fail-closed path when invoked.
    pub fn from_configurations(configurations: &[ShieldConfiguration]) -> Self {
        Self::from_configurations_with_transport(configurations, Arc::new(ReqwestHttpTransport))
    }

    /// Variant that lets tests inject a stub transport.
    pub fn from_configurations_with_transport(
        configurations: &[ShieldConfiguration],
        transport: Arc<dyn HttpTransport>,
    ) -> Self {
        let mut configs = HashMap::new();
        for cfg in configurations {
            if cfg.config_type != ConfigurationType::Classifier {
                continue;
            }
            let Some(resolved) = ResolvedClassifierConfig::from_configuration(cfg) else {
                continue;
            };
            let Some(provider) = build_provider(&resolved.provider) else {
                log::debug!(
                    target: "agent_shield::classifiers",
                    "classifier configuration `{}` uses unsupported provider `{}` — skipping (feature disabled or unknown)",
                    cfg.id,
                    resolved.provider
                );
                continue;
            };
            configs.insert(cfg.id.clone(), (resolved, provider));
        }
        Self { configs, transport }
    }

    pub fn has_any(&self) -> bool {
        !self.configs.is_empty()
    }
}

impl ClassifierCaller for AutoWiredClassifierCaller {
    fn classify(&self, configuration_id: &str, subject: &str) -> Result<ClassifierVerdict, String> {
        let Some((cfg, provider)) = self.configs.get(configuration_id) else {
            return Err(format!(
                "no resolved classifier configuration for id `{configuration_id}` (unsupported provider, missing api_key, or feature disabled)"
            ));
        };
        provider.classify(cfg, subject, self.transport.as_ref())
    }
}

fn build_provider(provider: &str) -> Option<Arc<dyn BundledProvider>> {
    match provider {
        #[cfg(feature = "aacs")]
        "aacs" | "azure_content_safety" | "microsoft.azure.content_safety" => {
            Some(Arc::new(super::aacs::AacsProvider))
        }
        #[cfg(feature = "lakera-guard")]
        "lakera_guard" | "lakera" => Some(Arc::new(super::lakera_guard::LakeraGuardProvider)),
        #[cfg(feature = "llama-guard")]
        "llama_guard" => Some(Arc::new(super::llama_guard::LlamaGuardProvider)),
        #[cfg(feature = "openai-moderation")]
        "openai_moderation" => Some(Arc::new(super::openai_moderation::OpenAiModerationProvider)),
        #[cfg(feature = "perspective")]
        "perspective" => Some(Arc::new(super::perspective::PerspectiveProvider)),
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::classifiers::transport::StubHttpTransport;

    #[test]
    fn unknown_id_returns_error() {
        let caller = AutoWiredClassifierCaller {
            configs: HashMap::new(),
            transport: Arc::new(StubHttpTransport::with_response(200, "{}")),
        };
        let err = caller.classify("nope", "hi").unwrap_err();
        assert!(err.contains("no resolved classifier configuration"));
    }

    #[test]
    fn skips_entries_without_provider() {
        let cfg = ShieldConfiguration {
            id: "x".into(),
            config_type: ConfigurationType::Classifier,
            default: None,
            provider: None,
            provider_config: None,
            endpoint: Some("http://x".into()),
            timeout: None,
            on_error: None,
            on_error_log: None,
            headers: HashMap::new(),
            model: None,
            max_tokens: None,
            api_key_env: None,
            metadata: None,
            threshold: None,
            method: None,
            category_thresholds: HashMap::new(),
            agent_id: None,
            tool: None,
        };
        let caller = AutoWiredClassifierCaller::from_configurations_with_transport(
            std::slice::from_ref(&cfg),
            Arc::new(StubHttpTransport::with_response(200, "{}")),
        );
        assert!(!caller.has_any());
    }
}
