//! Collection / set builtins (LANGUAGE.md §5.4).
//!
//! `count`, `sum`, `max`, `min`, `union`, `intersect`.

use std::collections::HashMap;

use super::super::ast::Expr;
use super::super::eval::{
    enum_aware_max_min, eval_expr, eval_results_equal, EvalContext, EvalResult,
};

pub(super) fn try_dispatch(
    name: &str,
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> Option<EvalResult> {
    let r = match name {
        "count" => count(args, ctx, bindings),
        "sum" => sum(args, ctx, bindings),
        "max" => max(args, ctx, bindings),
        "min" => min(args, ctx, bindings),
        "union" => union(args, ctx, bindings),
        "intersect" => intersect(args, ctx, bindings),
        _ => return None,
    };
    Some(r)
}

fn count(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    let a = eval_expr(&args[0], ctx, bindings);
    match a {
        EvalResult::List(items) => EvalResult::Number(items.len() as f64),
        EvalResult::Str(s) => EvalResult::Number(s.len() as f64),
        EvalResult::Map(m) => EvalResult::Number(m.len() as f64),
        _ => EvalResult::Null,
    }
}

fn sum(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    let a = eval_expr(&args[0], ctx, bindings);
    match a {
        EvalResult::List(items) => {
            let mut total = 0.0;
            for item in &items {
                match item.as_number() {
                    Some(n) => total += n,
                    None => return EvalResult::Null,
                }
            }
            EvalResult::Number(total)
        }
        _ => EvalResult::Null,
    }
}

fn max(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    // §7.4 — `max()` accepts either:
    //   - one argument: a non-empty array of numbers (reducer form), or
    //   - two scalar arguments: `max(a, b)` — datetime-aware, returns null
    //     on cross-type or non-comparable inputs.
    // The two-scalar form is required for §10.2 `update:` expressions
    // such as `max(@current, @incoming)`.
    match args.len() {
        1 => {
            let a = eval_expr(&args[0], ctx, bindings);
            match a {
                EvalResult::List(items) if !items.is_empty() => {
                    let mut max_val: Option<f64> = None;
                    for item in &items {
                        match item.as_number() {
                            Some(n) => max_val = Some(max_val.map_or(n, |m: f64| m.max(n))),
                            None => return EvalResult::Null,
                        }
                    }
                    max_val.map_or(EvalResult::Null, EvalResult::Number)
                }
                _ => EvalResult::Null,
            }
        }
        2 => {
            let a = eval_expr(&args[0], ctx, bindings);
            let b = eval_expr(&args[1], ctx, bindings);
            enum_aware_max_min(&a, &b, /*pick_larger*/ true, ctx)
        }
        _ => EvalResult::Null,
    }
}

fn min(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    match args.len() {
        1 => {
            let a = eval_expr(&args[0], ctx, bindings);
            match a {
                EvalResult::List(items) if !items.is_empty() => {
                    let mut min_val: Option<f64> = None;
                    for item in &items {
                        match item.as_number() {
                            Some(n) => min_val = Some(min_val.map_or(n, |m: f64| m.min(n))),
                            None => return EvalResult::Null,
                        }
                    }
                    min_val.map_or(EvalResult::Null, EvalResult::Number)
                }
                _ => EvalResult::Null,
            }
        }
        2 => {
            let a = eval_expr(&args[0], ctx, bindings);
            let b = eval_expr(&args[1], ctx, bindings);
            enum_aware_max_min(&a, &b, /*pick_larger*/ false, ctx)
        }
        _ => EvalResult::Null,
    }
}

fn union(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    // §7.4 — set-union of two arrays, deduplicated, preserving order:
    // a's elements first (in declaration order), then b's new elements.
    // Either argument MAY be null and is treated as the empty array.
    // Required by §10.2 `update:` expressions like
    // `union(@current, @incoming)`.
    if args.len() != 2 {
        return EvalResult::Null;
    }
    let a = eval_expr(&args[0], ctx, bindings);
    let b = eval_expr(&args[1], ctx, bindings);
    let coerce = |v: EvalResult| -> Option<Vec<EvalResult>> {
        match v {
            EvalResult::Null => Some(Vec::new()),
            EvalResult::List(items) => Some(items),
            _ => None,
        }
    };
    let (Some(av), Some(bv)) = (coerce(a), coerce(b)) else {
        return EvalResult::Null;
    };
    let mut out: Vec<EvalResult> = Vec::with_capacity(av.len() + bv.len());
    for item in av.into_iter().chain(bv) {
        if !out
            .iter()
            .any(|existing| eval_results_equal(existing, &item))
        {
            out.push(item);
        }
    }
    EvalResult::List(out)
}

fn intersect(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    // §7.4 / IFC — set-intersection of two arrays. Output preserves
    // the order of the FIRST argument (so `intersect(@current,
    // @incoming)` keeps the existing variable's declaration order)
    // and deduplicates. Either argument MAY be null and is treated
    // as the empty array — this matches `union`'s null-handling so
    // the two functions compose cleanly in `update:` expressions.
    //
    // The classic IFC pattern is a labels variable that uses
    // `update: 'intersect(@current, @incoming)'` so each tool
    // result can only NARROW the trust set, never widen it. Once a
    // label is dropped it cannot reappear within the lifetime.
    if args.len() != 2 {
        return EvalResult::Null;
    }
    let a = eval_expr(&args[0], ctx, bindings);
    let b = eval_expr(&args[1], ctx, bindings);
    let coerce = |v: EvalResult| -> Option<Vec<EvalResult>> {
        match v {
            EvalResult::Null => Some(Vec::new()),
            EvalResult::List(items) => Some(items),
            _ => None,
        }
    };
    let (Some(av), Some(bv)) = (coerce(a), coerce(b)) else {
        return EvalResult::Null;
    };
    let mut out: Vec<EvalResult> = Vec::with_capacity(av.len().min(bv.len()));
    for item in av {
        let in_b = bv.iter().any(|other| eval_results_equal(&item, other));
        let already = out
            .iter()
            .any(|existing| eval_results_equal(existing, &item));
        if in_b && !already {
            out.push(item);
        }
    }
    EvalResult::List(out)
}
