/// AST nodes produced by the expression parser.
#[derive(Debug, Clone, PartialEq)]
pub enum Expr {
    /// A literal value: string, number, bool, or null.
    Literal(LitValue),

    /// A simple identifier: `role`, `fraud_score`.
    Ident(String),

    /// Dotted access: `user.role`, `account.owner.region`.
    DottedAccess { root: Box<Expr>, path: Vec<String> },

    /// Binary operation: `a and b`, `x > 5`, `a + b`.
    BinaryOp {
        op: BinOp,
        left: Box<Expr>,
        right: Box<Expr>,
    },

    /// Unary operation: `not x`, `-5`.
    UnaryOp { op: UnOp, operand: Box<Expr> },

    /// Function call: `time.now()`, `contains(a, b)`, `regex.match(p, s)`.
    FnCall { name: String, args: Vec<Expr> },

    /// Ternary conditional: `cond ? then_expr : else_expr`.
    Ternary {
        condition: Box<Expr>,
        then_expr: Box<Expr>,
        else_expr: Box<Expr>,
    },

    /// List literal: `[1, 2, 3]`, `['admin', 'mod']`.
    List(Vec<Expr>),

    /// Index access: `arr[0]`, `map["key"]`.
    Index { object: Box<Expr>, index: Box<Expr> },

    /// Variable binding: `name := expr`.
    Assignment { name: String, value: Box<Expr> },

    /// Quantifier macro: `all|any|count_where(coll, var -> pred)`.
    /// Per LANGUAGE.md §5.8 the bound variable is scoped to the predicate only.
    Quantifier {
        kind: QuantifierKind,
        collection: Box<Expr>,
        var: String,
        predicate: Box<Expr>,
    },

    /// Variable metadata read: `var.@field` (LANGUAGE.md §4.7).
    /// Only valid on a bare variable identifier; the parser rejects
    /// `(expr).@field` at parse time. Reads MUST NOT trigger auto-resolution.
    MetaField { var: String, field: String },
}

/// Quantifier macro kinds.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum QuantifierKind {
    All,
    Any,
    CountWhere,
}

/// Literal values in expressions.
#[derive(Debug, Clone, PartialEq)]
pub enum LitValue {
    Str(String),
    Number(f64),
    Bool(bool),
    Null,
}

/// Binary operators, ordered by typical precedence grouping.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BinOp {
    // Logical (lowest precedence)
    Or,
    And,

    // Comparison
    Eq,
    Neq,
    Lt,
    Lte,
    Gt,
    Gte,

    // Collection membership
    In,

    // Arithmetic (highest precedence among binary)
    Add,
    Sub,
    Mul,
    Div,
    Mod,
}

/// Unary operators.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum UnOp {
    Not,
    Neg,
}
