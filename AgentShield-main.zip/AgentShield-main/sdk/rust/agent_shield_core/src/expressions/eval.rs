use super::ast::*;
use super::parser::parse;
use chrono::{DateTime, Datelike, Timelike, Utc};
use serde_json::Value;
use std::cell::RefCell;
use std::collections::HashMap;
use std::sync::Mutex;

use crate::constants::expressions::{MAX_PREDICATE_DEPTH, SCOPE_NAMESPACES};

fn is_scope_namespace(name: &str) -> bool {
    SCOPE_NAMESPACES.contains(&name)
}

/// Recognized fields in the `@`-metadata namespace (LANGUAGE.md §4.7,
/// SPECIFICATION.md §9.3.2). `key`, `deny_kind`, `source_reason`, and
/// `source_params` are added in v2.0.0-prototype.
const META_FIELDS: &[&str] = &[
    "status",
    "set_at",
    "expires_at",
    "source_kind",
    "set_by",
    "deny_reason",
    "key",
    "deny_kind",
    "source_reason",
    "source_params",
];

type NowFactory = Option<fn() -> DateTime<Utc>>;

// Injectable clock for deterministic testing.
static NOW_FACTORY: Mutex<NowFactory> = Mutex::new(None);

/// Override the clock used by `time.now()`. Pass `None` to reset to real time.
pub fn set_now_factory(factory: Option<fn() -> DateTime<Utc>>) {
    *NOW_FACTORY.lock().unwrap() = factory;
}

pub(super) fn now() -> DateTime<Utc> {
    match *NOW_FACTORY.lock().unwrap() {
        Some(f) => f(),
        None => Utc::now(),
    }
}

// ═══════════════════════════════════════════════════════════════
// Public hook traits and EvalContext
//
// `EvalContext` threads the optional hooks (status lookup, event
// firing, predicate name resolution, resolver auto-resolution) through
// the evaluator. Hook-less callers can build a context via
// [`EvalContext::from_attrs`] (or use the convenience [`evaluate`]
// helper); gating-site callers use [`evaluate_with`] with a fully
// populated context.
// ═══════════════════════════════════════════════════════════════

/// Lifecycle status of a declared variable (LANGUAGE.md §4.7).
/// Mirrors the runtime's variable-status enum, kept here to avoid a
/// circular dep between the expressions module and `variables`.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum VariableStatus {
    Unset,
    Resolved,
    Denied,
}

/// Variable status / metadata lookup. Implementations read from the runtime
/// store. All methods MUST NOT trigger auto-resolution (LANGUAGE.md §4.7).
pub trait StatusLookup {
    /// Return the current `@status` of a declared variable, or `None` if the
    /// variable name isn't declared.
    fn status(&self, var: &str) -> Option<VariableStatus>;
    /// Return a single `@<field>` reading. Recognized fields per
    /// LANGUAGE.md §4.7: `status`, `set_at`, `expires_at`, `source_kind`,
    /// `set_by`, `deny_reason`.
    fn meta(&self, var: &str, field: &str) -> Option<EvalResult>;
    /// Whether the variable name is declared in the merged config. Default
    /// implementation derives from `status()` returning `Some(_)`.
    /// Implementations SHOULD override when a separate authoritative
    /// declaration registry is available (LANGUAGE.md §5.10).
    fn is_declared(&self, var: &str) -> bool {
        self.status(var).is_some()
    }
}

/// Latched-event lookup for `event.fired(<id>)` (LANGUAGE.md §5.9).
pub trait EventFiredHook {
    fn fired(&self, event_id: &str) -> bool;
}

/// Predicate-name resolver (LANGUAGE.md §7). Returns the expression source
/// of a named predicate so the evaluator can sub-evaluate it. The body is
/// re-parsed each invocation; callers SHOULD memoize parsed ASTs at the
/// call site if hot-path performance matters.
pub trait PredicateLookup {
    fn body(&self, name: &str) -> Option<&str>;
}

/// Auto-resolution hook (LANGUAGE.md §11.1). Called only at gating sites
/// for variable reads that would otherwise be `null`. Returning `Some(v)`
/// means the resolver decided `allow` and produced `v`; returning `None`
/// means the resolver was unavailable or decided `deny`/`cancelled`.
pub trait ResolverHook {
    fn resolve(&self, var: &str) -> Option<Value>;
}

/// Evaluation context threading attrs and the optional hooks. Hook-less
/// callers build this via [`EvalContext::from_attrs`]; gating-site
/// callers attach hooks for predicate lookup, event firing, status
/// metadata, and auto-resolution.
pub struct EvalContext<'a> {
    pub attrs: &'a HashMap<String, Value>,
    pub status_lookup: Option<&'a dyn StatusLookup>,
    pub event_fired: Option<&'a dyn EventFiredHook>,
    pub predicates: Option<&'a dyn PredicateLookup>,
    pub is_gating_site: bool,
    pub resolver_hook: Option<&'a dyn ResolverHook>,
    /// Currently-resolving predicate names — used for cycle detection per
    /// LANGUAGE.md §11.3 and depth limit per §7.
    pub(crate) predicate_chain: RefCell<Vec<String>>,
    /// Per-evaluation memoization of variable resolutions (LANGUAGE.md §11.4).
    /// `None` represents a denied/cancelled resolution; `Some(EvalResult)`
    /// is a successful read (including `Some(EvalResult::Null)`). The cache
    /// is reset at every public `evaluate_with` entry so it never leaks
    /// across calls.
    pub(crate) resolved_cache: RefCell<HashMap<String, Option<EvalResult>>>,
}

impl<'a> EvalContext<'a> {
    /// Build a hook-less context. Matches the bare `evaluate(expr, attrs)`
    /// semantics: no auto-resolution, no predicates, no `@`-namespace
    /// hook, no `event.fired()` hook. Sugar functions fall back to
    /// value-based heuristics (see [`eval_var_status`]).
    pub fn from_attrs(attrs: &'a HashMap<String, Value>) -> Self {
        Self {
            attrs,
            status_lookup: None,
            event_fired: None,
            predicates: None,
            is_gating_site: false,
            resolver_hook: None,
            predicate_chain: RefCell::new(Vec::new()),
            resolved_cache: RefCell::new(HashMap::new()),
        }
    }
}

/// Evaluate an expression against a set of attributes.
/// Returns `false` on any error (fail-closed semantics).
pub fn evaluate(expr: &str, attrs: &HashMap<String, Value>) -> bool {
    let ctx = EvalContext::from_attrs(attrs);
    evaluate_with(expr, &ctx)
}

/// Evaluate an expression with a fully-built [`EvalContext`]. Gating
/// sites SHOULD use this entry point; hook-less callers can use the
/// [`evaluate`] convenience helper.
///
/// Predicate-boundary semantics (LANGUAGE.md §3.6): only `Bool(true)` becomes
/// `true`; every other final result — including `Bool(false)`, `Null`, and
/// every non-boolean variant (`Str`, `Number`, `List`, `Map`, `DateTime`,
/// `Duration`) — collapses to `false`. Truthiness coercion is preserved
/// inside operators (`and`/`or`/`not`/ternary), but the public boundary is
/// strict per spec.
pub fn evaluate_with(expr: &str, ctx: &EvalContext<'_>) -> bool {
    // Reset the per-evaluation memoization cache (P2.1 / LANGUAGE.md §11.4).
    ctx.resolved_cache.borrow_mut().clear();

    let ast = match parse(expr) {
        Ok(ast) => ast,
        Err(_) => return false,
    };
    let mut bindings: HashMap<String, EvalResult> = HashMap::new();
    matches!(eval_expr(&ast, ctx, &mut bindings), EvalResult::Bool(true))
}

/// Evaluate an expression and return the raw value.
///
/// Returns `None` when the expression source fails to parse. Returns
/// `Some(Value::Null)` when the expression evaluates to `null` (e.g. a
/// missing attribute under fail-closed semantics, a divide-by-zero, or any
/// other null-propagating path). callers (e.g., `kind: expression`
/// resolvers, resolver `context:` evaluation, `on_allow:` map evaluation)
/// use this entry point instead of [`evaluate_with`] when they need the
/// underlying typed value rather than a pure boolean fold.
pub fn evaluate_to_value(expr: &str, ctx: &EvalContext<'_>) -> Option<Value> {
    // Mirror `evaluate_with`: reset the per-evaluation memoization cache so
    // a reused EvalContext doesn't return a stale resolver-hook result
    // from an earlier call (P5.4 / LANGUAGE.md §11.4).
    ctx.resolved_cache.borrow_mut().clear();
    let ast = parse(expr).ok()?;
    let mut bindings: HashMap<String, EvalResult> = HashMap::new();
    Some(eval_result_to_value(&eval_expr(&ast, ctx, &mut bindings)))
}

/// Convert an internal [`EvalResult`] into a JSON value. `Duration` is
/// serialized as an ISO-8601 string. `DateTime` is serialized as RFC-3339.
///
/// Number representation: the evaluator works in f64, but JSON
/// distinguishes integer- and float-shaped numbers. To preserve type
/// shape across update: round-trips (e.g., `apply_update` on a counter
/// that increments by 1 should keep the JSON integer shape), we lower
/// integer-valued finite f64s to JSON integers. Non-integer or
/// non-finite values fall through to f64 with finite-only fallback.
fn eval_result_to_value(r: &EvalResult) -> Value {
    match r {
        EvalResult::Null => Value::Null,
        EvalResult::Bool(b) => Value::Bool(*b),
        EvalResult::Number(n) => {
            if n.is_finite()
                && n.fract() == 0.0
                && *n >= (i64::MIN as f64)
                && *n <= (i64::MAX as f64)
            {
                Value::Number(serde_json::Number::from(*n as i64))
            } else {
                serde_json::Number::from_f64(*n)
                    .map(Value::Number)
                    .unwrap_or(Value::Null)
            }
        }
        EvalResult::Str(s) => Value::String(s.clone()),
        EvalResult::DateTime(dt) => Value::String(dt.to_rfc3339()),
        EvalResult::Duration(d) => Value::String(format!("PT{}S", d.num_seconds())),
        EvalResult::List(items) => Value::Array(items.iter().map(eval_result_to_value).collect()),
        EvalResult::Map(map) => {
            let obj: serde_json::Map<String, Value> =
                map.iter().map(|(k, v)| (k.clone(), v.clone())).collect();
            Value::Object(obj)
        }
    }
}

/// Internal evaluation result that can represent any intermediate value.
///
/// This is `pub` (rather than `pub(crate)`) so the [`StatusLookup`] trait
/// can return `EvalResult` from `meta()` without leaking a private type.
/// Most callers should treat it as opaque.
#[derive(Debug, Clone)]
pub enum EvalResult {
    Bool(bool),
    Number(f64),
    Str(String),
    DateTime(DateTime<Utc>),
    Duration(chrono::Duration),
    List(Vec<EvalResult>),
    Map(HashMap<String, Value>),
    Null,
}

impl EvalResult {
    pub(super) fn is_null(&self) -> bool {
        matches!(self, EvalResult::Null)
    }

    pub(super) fn as_number(&self) -> Option<f64> {
        match self {
            EvalResult::Number(n) => Some(*n),
            _ => None,
        }
    }

    pub(super) fn as_str(&self) -> Option<&str> {
        match self {
            EvalResult::Str(s) => Some(s),
            _ => None,
        }
    }

    /// Compare two EvalResults for equality. Null == Null is true.
    /// Composite values (arrays, objects) compare element-wise / key-wise
    /// per spec §3.6.1; cross-type comparisons return false (no implicit
    /// coercion).
    fn eq_value(&self, other: &EvalResult) -> EvalResult {
        EvalResult::Bool(eval_results_equal(self, other))
    }

    /// Ordering comparison. Returns Null if either side is null or incomparable.
    fn compare(&self, other: &EvalResult) -> EvalResult {
        if self.is_null() || other.is_null() {
            return EvalResult::Null;
        }
        match (self, other) {
            (EvalResult::Number(a), EvalResult::Number(b)) => {
                EvalResult::Number(a.partial_cmp(b).map_or(0.0, |o| o as i8 as f64))
            }
            (EvalResult::Str(a), EvalResult::Str(b)) => EvalResult::Number(a.cmp(b) as i8 as f64),
            (EvalResult::DateTime(a), EvalResult::DateTime(b)) => {
                EvalResult::Number(a.cmp(b) as i8 as f64)
            }
            (EvalResult::Duration(a), EvalResult::Duration(b)) => {
                EvalResult::Number(a.cmp(b) as i8 as f64)
            }
            _ => EvalResult::Null,
        }
    }
}

/// Boolean coercion following the spec §3.6.1.2 table.
/// null/false/0/""/[]/{}  → false; everything else → true
fn to_truthy(val: &EvalResult) -> bool {
    match val {
        EvalResult::Null => false,
        EvalResult::Bool(b) => *b,
        EvalResult::Number(n) => n.abs() >= f64::EPSILON,
        EvalResult::Str(s) => !s.is_empty(),
        EvalResult::List(items) => !items.is_empty(),
        EvalResult::Map(map) => !map.is_empty(),
        EvalResult::DateTime(_) => true,
        EvalResult::Duration(_) => true,
    }
}

/// Enum-aware extension of [`scalar_max_min`]: when the active eval
/// context carries the `@__enum_domain__` sentinel (set by §10.2's
/// `apply_update` for `type: enum` variables), and both operands are
/// strings that are members of that domain, compare by member-index
/// order. Otherwise fall through to the normal scalar comparison.
///
/// The sentinel is the only mechanism the runtime has to communicate
/// "this comparison is happening under an enum-typed variable's
/// `update:` expression" without reshaping the whole expression-result
/// type to carry an enum-domain tag. It is invisible to authors —
/// `@__enum_domain__` is not a legal user identifier (§7.1 reserves
/// `@`-prefixed names for runtime use) and the sentinel is never
/// surfaced through any public API.
pub(super) fn enum_aware_max_min(
    a: &EvalResult,
    b: &EvalResult,
    pick_larger: bool,
    ctx: &EvalContext<'_>,
) -> EvalResult {
    if let (EvalResult::Str(sa), EvalResult::Str(sb)) = (a, b) {
        if let Some(Value::Array(members)) = ctx.attrs.get("@__enum_domain__") {
            let idx_a = members
                .iter()
                .position(|m| matches!(m, Value::String(s) if s == sa));
            let idx_b = members
                .iter()
                .position(|m| matches!(m, Value::String(s) if s == sb));
            if let (Some(ia), Some(ib)) = (idx_a, idx_b) {
                let pick_a = if pick_larger { ia >= ib } else { ia <= ib };
                return if pick_a { a.clone() } else { b.clone() };
            }
            // One or both values aren't in the domain → fail closed.
            return EvalResult::Null;
        }
    }
    scalar_max_min(a, b, pick_larger)
}

/// Two-scalar `max(a, b)` / `min(a, b)` per §7.4. Compares same-typed
/// scalars (`number`, `string`, `datetime`, `duration`); cross-type or
/// non-comparable inputs return `null` (fail-closed). On `null` /
/// `null`, returns `null`. Used by `update:` expressions like
/// `max(@current, @incoming)` over numbers, datetimes, or `enum` values.
///
/// Note: `enum` ordering by member-index is not yet enum-tag-aware in
/// the evaluator; until §10 enum lands, enum values flow as plain
/// strings and compare lexicographically. Once enums carry their
/// member-index, this function gains an enum-domain branch.
fn scalar_max_min(a: &EvalResult, b: &EvalResult, pick_larger: bool) -> EvalResult {
    use std::cmp::Ordering::*;
    let ord: Option<std::cmp::Ordering> = match (a, b) {
        (EvalResult::Null, EvalResult::Null) => return EvalResult::Null,
        (EvalResult::Null, _) | (_, EvalResult::Null) => return EvalResult::Null,
        (EvalResult::Number(x), EvalResult::Number(y)) => x.partial_cmp(y),
        (EvalResult::Str(x), EvalResult::Str(y)) => Some(x.cmp(y)),
        (EvalResult::DateTime(x), EvalResult::DateTime(y)) => Some(x.cmp(y)),
        (EvalResult::Duration(x), EvalResult::Duration(y)) => Some(x.cmp(y)),
        _ => None,
    };
    match ord {
        Some(Less) => {
            if pick_larger {
                b.clone()
            } else {
                a.clone()
            }
        }
        Some(Greater) => {
            if pick_larger {
                a.clone()
            } else {
                b.clone()
            }
        }
        Some(Equal) => a.clone(),
        None => EvalResult::Null,
    }
}

/// Deep equality for `union(a, b)` deduplication. Mirrors the
/// expression-language equality semantics: same-type scalars compared
/// by value; cross-type returns `false`. Composite equality is element-
/// wise over arrays and key-by-key over objects.
pub(super) fn eval_results_equal(a: &EvalResult, b: &EvalResult) -> bool {
    match (a, b) {
        (EvalResult::Null, EvalResult::Null) => true,
        (EvalResult::Bool(x), EvalResult::Bool(y)) => x == y,
        (EvalResult::Number(x), EvalResult::Number(y)) => (x.is_nan() && y.is_nan()) || x == y,
        (EvalResult::Str(x), EvalResult::Str(y)) => x == y,
        (EvalResult::DateTime(x), EvalResult::DateTime(y)) => x == y,
        (EvalResult::Duration(x), EvalResult::Duration(y)) => x == y,
        (EvalResult::List(x), EvalResult::List(y)) => {
            x.len() == y.len()
                && x.iter()
                    .zip(y.iter())
                    .all(|(xi, yi)| eval_results_equal(xi, yi))
        }
        (EvalResult::Map(x), EvalResult::Map(y)) => {
            x.len() == y.len()
                && x.iter().all(|(k, vx)| {
                    y.get(k)
                        .map(|vy| {
                            // Map values are JSON `Value`s; round-trip
                            // through `value_to_eval` for fair comparison.
                            eval_results_equal(&value_to_eval(vx), &value_to_eval(vy))
                        })
                        .unwrap_or(false)
                })
        }
        _ => false,
    }
}

pub(super) fn eval_expr(
    expr: &Expr,
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    match expr {
        Expr::Literal(lit) => eval_literal(lit),

        Expr::Ident(name) => {
            // Check variable bindings first, then attributes
            if let Some(val) = bindings.get(name) {
                return val.clone();
            }
            resolve_attr(name, ctx)
        }

        Expr::DottedAccess { root, path } => {
            let base = eval_expr(root, ctx, bindings);
            resolve_dotted(base, path)
        }

        Expr::BinaryOp { op, left, right } => eval_binary(*op, left, right, ctx, bindings),

        Expr::UnaryOp { op, operand } => {
            let val = eval_expr(operand, ctx, bindings);
            match op {
                UnOp::Not => {
                    // Fail-closed: `not null` → false (spec §3.6.1.2)
                    // Null is absent, not false. We don't negate absence.
                    if val.is_null() {
                        EvalResult::Bool(false)
                    } else {
                        EvalResult::Bool(!to_truthy(&val))
                    }
                }
                UnOp::Neg => match val.as_number() {
                    Some(n) => EvalResult::Number(-n),
                    None => EvalResult::Null,
                },
            }
        }

        Expr::FnCall { name, args } => super::builtins::eval_function(name, args, ctx, bindings),

        Expr::List(items) => {
            let vals: Vec<EvalResult> = items.iter().map(|i| eval_expr(i, ctx, bindings)).collect();
            EvalResult::List(vals)
        }

        Expr::Assignment { name, value } => {
            // Immutable binding: reject reassignment (spec §3.6.1.4)
            if bindings.contains_key(name) {
                return EvalResult::Null; // fail-closed: duplicate binding
            }
            let val = eval_expr(value, ctx, bindings);
            bindings.insert(name.clone(), val);
            // Return true (binding succeeded) — not the value itself.
            // The value is accessed via the binding name in subsequent expressions.
            // Returning the raw value would cause `;` (lowered to And) to
            // short-circuit on falsy values like 0, "", or [].
            EvalResult::Bool(true)
        }

        Expr::Ternary {
            condition,
            then_expr,
            else_expr,
        } => {
            let cond = eval_expr(condition, ctx, bindings);
            if to_truthy(&cond) {
                eval_expr(then_expr, ctx, bindings)
            } else {
                eval_expr(else_expr, ctx, bindings)
            }
        }

        Expr::Index { object, index } => {
            let obj = eval_expr(object, ctx, bindings);
            let idx = eval_expr(index, ctx, bindings);
            match (&obj, &idx) {
                (EvalResult::List(items), EvalResult::Number(n)) => {
                    let i = *n as i64;
                    if i < 0 {
                        EvalResult::Null
                    } else {
                        items.get(i as usize).cloned().unwrap_or(EvalResult::Null)
                    }
                }
                (EvalResult::Map(map), EvalResult::Str(key)) => {
                    map.get(key).map(value_to_eval).unwrap_or(EvalResult::Null)
                }
                _ => EvalResult::Null,
            }
        }

        Expr::Quantifier {
            kind,
            collection,
            var,
            predicate,
        } => eval_quantifier(*kind, collection, var, predicate, ctx, bindings),

        Expr::MetaField { var, field } => eval_meta_field(var, field, ctx),
    }
}

// ═══════════════════════════════════════════════════════════════
// Quantifier macros: all() / any() / count_where()  (LANGUAGE.md §5.8)
// ═══════════════════════════════════════════════════════════════

/// Evaluate a quantifier macro. Empty-array, null-collection, and
/// non-array rules follow LANGUAGE.md §5.8 exactly. The bound variable
/// is scoped to the predicate only — the previous binding (if any) is
/// saved and restored after iteration so the variable does not leak.
fn eval_quantifier(
    kind: QuantifierKind,
    collection: &Expr,
    var: &str,
    predicate: &Expr,
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    let coll = eval_expr(collection, ctx, bindings);

    // Null collection → fail-closed per spec table.
    if coll.is_null() {
        return match kind {
            QuantifierKind::All | QuantifierKind::Any => EvalResult::Bool(false),
            QuantifierKind::CountWhere => EvalResult::Null,
        };
    }

    let items = match coll {
        EvalResult::List(items) => items,
        // Non-array, non-null → false / null per spec.
        _ => {
            return match kind {
                QuantifierKind::All | QuantifierKind::Any => EvalResult::Bool(false),
                QuantifierKind::CountWhere => EvalResult::Null,
            };
        }
    };

    // Save any pre-existing binding so the macro's scope doesn't leak.
    let saved = bindings.remove(var);
    let mut count: u64 = 0;
    let mut short_circuit_result: Option<EvalResult> = None;

    // Snapshot the parent binding keys so we can discard any `:=`
    // assignments the predicate creates per iteration (LANGUAGE.md §5.8).
    let parent_keys: std::collections::HashSet<String> = bindings.keys().cloned().collect();

    for item in items {
        bindings.insert(var.to_string(), item);
        let pred = eval_expr(predicate, ctx, bindings);
        let truthy = !pred.is_null() && to_truthy(&pred);
        match kind {
            QuantifierKind::All => {
                if !truthy {
                    short_circuit_result = Some(EvalResult::Bool(false));
                    // Drop predicate-local bindings before breaking.
                    bindings.retain(|k, _| parent_keys.contains(k) || k == var);
                    break;
                }
            }
            QuantifierKind::Any => {
                if truthy {
                    short_circuit_result = Some(EvalResult::Bool(true));
                    bindings.retain(|k, _| parent_keys.contains(k) || k == var);
                    break;
                }
            }
            QuantifierKind::CountWhere => {
                if truthy {
                    count += 1;
                }
            }
        }
        // Per-iteration scope: drop any binding the predicate body created
        // via `:=` so it neither pollutes the next iteration nor leaks past
        // the quantifier (LANGUAGE.md §5.8).
        bindings.retain(|k, _| parent_keys.contains(k) || k == var);
    }

    // Restore prior binding (or remove the one we added).
    bindings.remove(var);
    if let Some(prev) = saved {
        bindings.insert(var.to_string(), prev);
    }

    if let Some(r) = short_circuit_result {
        return r;
    }
    match kind {
        // No element falsified the predicate → all() is `true`
        // (vacuous-truth on empty array per spec).
        QuantifierKind::All => EvalResult::Bool(true),
        // No element satisfied the predicate → any() is `false`.
        QuantifierKind::Any => EvalResult::Bool(false),
        QuantifierKind::CountWhere => EvalResult::Number(count as f64),
    }
}

// ═══════════════════════════════════════════════════════════════
// `@`-namespace metadata reads (LANGUAGE.md §4.7)
// ═══════════════════════════════════════════════════════════════

/// Evaluate `var.@field`. Reads the field via the registered
/// [`StatusLookup`] hook. With no hook, returns `'unset'` for `@status`
/// and `null` for the other fields. Unknown `@`-fields produce a
/// structured warning + `null`.
///
/// MUST NOT trigger auto-resolution under any circumstances.
fn eval_meta_field(var: &str, field: &str, ctx: &EvalContext<'_>) -> EvalResult {
    if !META_FIELDS.contains(&field) {
        log::warn!(
            target: "agent_shield::expressions",
            "unknown @-metadata field '{}' on variable '{}'; returning null",
            field,
            var
        );
        return EvalResult::Null;
    }

    if let Some(sl) = ctx.status_lookup {
        if let Some(val) = sl.meta(var, field) {
            // `@status` is documented to never return null; if a hook
            // implementation does, normalize to 'unset' (LANGUAGE.md §4.7).
            if field == "status" && val.is_null() {
                return EvalResult::Str("unset".to_string());
            }
            return val;
        }
    }

    // Transitional fallback (no hook registered): @status defaults to
    // 'unset'; everything else is null.
    if field == "status" {
        EvalResult::Str("unset".to_string())
    } else {
        EvalResult::Null
    }
}

fn eval_literal(lit: &LitValue) -> EvalResult {
    match lit {
        LitValue::Str(s) => EvalResult::Str(s.clone()),
        LitValue::Number(n) => EvalResult::Number(*n),
        LitValue::Bool(b) => EvalResult::Bool(*b),
        LitValue::Null => EvalResult::Null,
    }
}

/// Resolve a bare identifier per LANGUAGE.md §7 priority:
///   1. local binding (`:=`) / quantifier-bound (handled by caller via `bindings`)
///   2. session variable (in `ctx.attrs`)
///   3. predicate name (via [`PredicateLookup`])
///   4. not found → null (fail-closed)
///
/// At a gating site (`ctx.is_gating_site == true`) with a [`ResolverHook`]
/// registered, a session variable read whose `@status == 'unset'` triggers
/// auto-resolution per LANGUAGE.md §11.1. Reads of scope-namespace roots
/// (`tool`, `endpoint`, `agent`, `context`, `result`) MUST NOT
/// auto-resolve.
///
/// Each variable resolves at most once per `evaluate_with` call: results
/// are memoized in `ctx.resolved_cache` (LANGUAGE.md §11.4 / §11.5).
fn resolve_attr(name: &str, ctx: &EvalContext<'_>) -> EvalResult {
    let attr_present = ctx.attrs.contains_key(name);
    let attr_val = ctx.attrs.get(name);
    let attr_is_null = attr_val.map(|v| v.is_null()).unwrap_or(true);
    let scope_root = is_scope_namespace(name);

    // Per-evaluation memoization .
    if let Some(cached) = ctx.resolved_cache.borrow().get(name).cloned() {
        return match cached {
            Some(v) => v,
            None => EvalResult::Null,
        };
    }

    // Auto-resolve declared variables that are unset at gating sites.
    if ctx.is_gating_site && !scope_root {
        // Whether the variable is "unset" enough to trigger resolution:
        // - With a StatusLookup, the answer is authoritative — only
        //   `@status == 'unset'` triggers resolution. `Resolved` (even with
        //   a null value!) and `Denied` MUST NOT trigger.
        // - Without a StatusLookup (transitional path), fall back to
        //   the value-based heuristic.
        let should_resolve = match ctx.status_lookup {
            Some(sl) => {
                matches!(sl.status(name), Some(VariableStatus::Unset) | None) && attr_is_null
            }
            None => attr_is_null,
        };

        if should_resolve {
            if let Some(rh) = ctx.resolver_hook {
                let resolved = rh.resolve(name).map(|v| value_to_eval(&v));
                ctx.resolved_cache
                    .borrow_mut()
                    .insert(name.to_string(), resolved.clone());
                if let Some(r) = resolved {
                    return r;
                }
            }
        }
    }

    if attr_present {
        let r = value_to_eval(attr_val.unwrap());
        ctx.resolved_cache
            .borrow_mut()
            .insert(name.to_string(), Some(r.clone()));
        return r;
    }

    // Not declared as a session variable → try predicate lookup.
    if !scope_root {
        if let Some(pl) = ctx.predicates {
            if let Some(body) = pl.body(name) {
                let body_owned = body.to_string();
                return resolve_predicate(name, &body_owned, ctx);
            }
        }
    }

    ctx.resolved_cache
        .borrow_mut()
        .insert(name.to_string(), None);
    EvalResult::Null
}

/// Evaluate a named predicate body in a fresh local-binding scope, with
/// cycle detection (LANGUAGE.md §11.3) and depth limiting (§7).
///
/// Per spec §7, the value at the predicate-reference boundary MUST be a
/// boolean. Bodies that evaluate to a non-boolean, hit the cycle/depth
/// guard, or fail to parse are normalized to `Bool(false)` (fail-closed).
fn resolve_predicate(name: &str, body: &str, ctx: &EvalContext<'_>) -> EvalResult {
    {
        let chain = ctx.predicate_chain.borrow();
        if chain.iter().any(|n| n == name) {
            log::warn!(
                target: "agent_shield::expressions",
                "predicate cycle detected at '{}' (chain: {:?}); returning false",
                name,
                chain
            );
            return EvalResult::Bool(false);
        }
        if chain.len() >= MAX_PREDICATE_DEPTH {
            log::warn!(
                target: "agent_shield::expressions",
                "predicate depth limit ({}) exceeded at '{}'; returning false",
                MAX_PREDICATE_DEPTH,
                name
            );
            return EvalResult::Bool(false);
        }
    }

    let ast = match parse(body) {
        Ok(a) => a,
        Err(e) => {
            log::warn!(
                target: "agent_shield::expressions",
                "predicate '{}' failed to parse: {}; returning false",
                name,
                e
            );
            return EvalResult::Bool(false);
        }
    };

    ctx.predicate_chain.borrow_mut().push(name.to_string());
    // Predicate body evaluates in a *fresh* local-binding scope.
    let mut bindings: HashMap<String, EvalResult> = HashMap::new();
    let result = eval_expr(&ast, ctx, &mut bindings);
    ctx.predicate_chain.borrow_mut().pop();

    // Predicate body MUST be a boolean at the reference boundary (§7).
    // Anything else collapses to `false` (fail-closed).
    match result {
        EvalResult::Bool(b) => EvalResult::Bool(b),
        _ => EvalResult::Bool(false),
    }
}

pub(crate) fn value_to_eval(val: &Value) -> EvalResult {
    match val {
        Value::Null => EvalResult::Null,
        Value::Bool(b) => EvalResult::Bool(*b),
        Value::Number(n) => EvalResult::Number(n.as_f64().unwrap_or(0.0)),
        Value::String(s) => {
            // Try to parse as datetime
            if let Ok(dt) = s.parse::<DateTime<Utc>>() {
                EvalResult::DateTime(dt)
            } else {
                EvalResult::Str(s.clone())
            }
        }
        Value::Array(arr) => {
            let items: Vec<EvalResult> = arr.iter().map(value_to_eval).collect();
            EvalResult::List(items)
        }
        Value::Object(obj) => {
            let map: HashMap<String, Value> =
                obj.iter().map(|(k, v)| (k.clone(), v.clone())).collect();
            EvalResult::Map(map)
        }
    }
}

fn resolve_dotted(base: EvalResult, path: &[String]) -> EvalResult {
    let mut current = base;
    for field in path {
        current = match current {
            EvalResult::Map(ref map) => match map.get(field) {
                Some(val) => value_to_eval(val),
                None => return EvalResult::Null,
            },
            EvalResult::DateTime(dt) => match field.as_str() {
                "hour" => EvalResult::Number(dt.hour() as f64),
                "minute" => EvalResult::Number(dt.minute() as f64),
                "second" => EvalResult::Number(dt.second() as f64),
                "weekday" => EvalResult::Str(
                    match dt.weekday() {
                        chrono::Weekday::Mon => "Monday",
                        chrono::Weekday::Tue => "Tuesday",
                        chrono::Weekday::Wed => "Wednesday",
                        chrono::Weekday::Thu => "Thursday",
                        chrono::Weekday::Fri => "Friday",
                        chrono::Weekday::Sat => "Saturday",
                        chrono::Weekday::Sun => "Sunday",
                    }
                    .to_string(),
                ),
                "day" => EvalResult::Number(dt.day() as f64),
                "month" => EvalResult::Number(dt.month() as f64),
                "year" => EvalResult::Number(dt.year() as f64),
                _ => return EvalResult::Null,
            },
            EvalResult::Null => return EvalResult::Null, // Null short-circuit
            _ => return EvalResult::Null,
        };
    }
    current
}

fn eval_binary(
    op: BinOp,
    left: &Expr,
    right: &Expr,
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    // Short-circuit for AND/OR using truthy coercion
    match op {
        BinOp::And => {
            let l = eval_expr(left, ctx, bindings);
            if !to_truthy(&l) {
                return EvalResult::Bool(false);
            }
            let r = eval_expr(right, ctx, bindings);
            return EvalResult::Bool(to_truthy(&r));
        }
        BinOp::Or => {
            let l = eval_expr(left, ctx, bindings);
            if to_truthy(&l) {
                return EvalResult::Bool(true);
            }
            let r = eval_expr(right, ctx, bindings);
            return EvalResult::Bool(to_truthy(&r));
        }
        _ => {}
    }

    let l = eval_expr(left, ctx, bindings);
    let r = eval_expr(right, ctx, bindings);

    match op {
        BinOp::Eq => l.eq_value(&r),
        BinOp::Neq => {
            // Null-safe !=: if either operand is null, return false (fail-closed).
            // This prevents missing attributes from accidentally satisfying != checks.
            // null != null → false
            // null != 5   → false (was: true — security fix)
            // 5 != null   → false (was: true — security fix)
            // 5 != 3      → true  (normal case unchanged)
            if l.is_null() || r.is_null() {
                return EvalResult::Bool(false);
            }
            match l.eq_value(&r) {
                EvalResult::Bool(b) => EvalResult::Bool(!b),
                other => other,
            }
        }

        BinOp::Lt | BinOp::Lte | BinOp::Gt | BinOp::Gte => {
            let cmp = l.compare(&r);
            match cmp {
                EvalResult::Number(n) => {
                    let result = match op {
                        BinOp::Lt => n < 0.0,
                        BinOp::Lte => n <= 0.0,
                        BinOp::Gt => n > 0.0,
                        BinOp::Gte => n >= 0.0,
                        _ => unreachable!(),
                    };
                    EvalResult::Bool(result)
                }
                _ => EvalResult::Bool(false), // null comparison → false
            }
        }

        BinOp::In => eval_in(&l, &r),

        BinOp::Add => eval_arithmetic(&l, &r, |a, b| a + b),
        BinOp::Sub => eval_subtract(&l, &r),
        BinOp::Mul => eval_arithmetic(&l, &r, |a, b| a * b),
        BinOp::Div => {
            if let Some(b) = r.as_number() {
                if b.abs() < f64::EPSILON {
                    return EvalResult::Null; // Division by zero → null
                }
            }
            eval_arithmetic(&l, &r, |a, b| a / b)
        }
        BinOp::Mod => {
            if let Some(b) = r.as_number() {
                if b.abs() < f64::EPSILON {
                    return EvalResult::Null; // Modulo by zero → null
                }
            }
            eval_arithmetic(&l, &r, |a, b| a % b)
        }

        BinOp::And | BinOp::Or => unreachable!("handled above"),
    }
}

fn eval_in(needle: &EvalResult, haystack: &EvalResult) -> EvalResult {
    // Return Null (not Bool(false)) when either operand is null/missing.
    // This ensures `not ... in` fails closed: `not Null` → false.
    if needle.is_null() {
        return EvalResult::Null;
    }
    match haystack {
        EvalResult::List(items) => {
            for item in items {
                if let EvalResult::Bool(true) = needle.eq_value(item) {
                    return EvalResult::Bool(true);
                }
            }
            EvalResult::Bool(false)
        }
        _ => EvalResult::Null, // null/missing haystack → Null → fail-closed
    }
}

fn eval_arithmetic(left: &EvalResult, right: &EvalResult, op: fn(f64, f64) -> f64) -> EvalResult {
    match (left.as_number(), right.as_number()) {
        (Some(a), Some(b)) => EvalResult::Number(op(a, b)),
        _ => EvalResult::Null,
    }
}

fn eval_subtract(left: &EvalResult, right: &EvalResult) -> EvalResult {
    // DateTime - DateTime = Duration
    if let (EvalResult::DateTime(a), EvalResult::DateTime(b)) = (left, right) {
        return EvalResult::Duration(*a - *b);
    }
    // Number - Number
    eval_arithmetic(left, right, |a, b| a - b)
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;
    use std::sync::Mutex as StdMutex;

    fn attrs(pairs: &[(&str, Value)]) -> HashMap<String, Value> {
        pairs
            .iter()
            .map(|(k, v)| (k.to_string(), v.clone()))
            .collect()
    }

    // Serialize tests that use set_now_factory to avoid test interference
    static CLOCK_LOCK: StdMutex<()> = StdMutex::new(());

    // ═══════════════════════════════════════════════════════════════
    // SECURITY-CRITICAL: Fail-Closed Null/Undefined Tests
    // ═══════════════════════════════════════════════════════════════

    #[test]
    fn test_missing_attribute_equality_is_false() {
        assert!(!evaluate("x == 'hello'", &HashMap::new()));
    }

    #[test]
    fn test_missing_attribute_in_is_false() {
        assert!(!evaluate("x in ['admin', 'mod']", &HashMap::new()));
    }

    #[test]
    fn test_missing_attribute_neq_is_false() {
        // Null-safe !=: missing attribute (null) != 'restricted' → false (fail-closed)
        assert!(!evaluate("x != 'restricted'", &HashMap::new()));
    }

    #[test]
    fn test_missing_attribute_not_in_is_false() {
        // Fail-closed: `not x in [...]` where x is missing.
        // eval_in(Null, List) → Null, `not Null` → false (fail-closed).
        assert!(!evaluate(
            "not x in ['confidential', 'restricted']",
            &HashMap::new(),
        ));
    }

    #[test]
    fn test_null_not_in_list_with_guard() {
        // Recommended pattern for fail-closed with decomposed not:
        let a = attrs(&[("x", json!(null))]);
        assert!(!evaluate("not is_null(x) and not x in ['a', 'b']", &a));
    }

    #[test]
    fn test_literal_not_in_missing_attribute_is_false() {
        // Fail-closed: `not 'EU' in data_jurisdictions` where data_jurisdictions is missing.
        // eval_in('EU', Null) → Null (null haystack), `not Null` → false.
        assert!(!evaluate("not 'EU' in data_jurisdictions", &HashMap::new(),));
    }

    #[test]
    fn test_neq_with_null_value_is_false() {
        // Null-safe !=: null != 'restricted' → false (fail-closed)
        let a = attrs(&[("x", json!(null))]);
        assert!(!evaluate("x != 'restricted'", &a));
    }

    #[test]
    fn test_neq_with_present_values_works() {
        // Normal case still works
        let a = attrs(&[("x", json!("public"))]);
        assert!(evaluate("x != 'restricted'", &a));
        assert!(!evaluate("x != 'public'", &a));
    }

    #[test]
    fn test_not_in_with_present_values_works() {
        // Normal case: not (x in [...]) with present value
        let a = attrs(&[("x", json!("public"))]);
        assert!(evaluate("not x in ['confidential', 'restricted']", &a));
        assert!(!evaluate("not x in ['public', 'internal']", &a));
    }

    #[test]
    fn test_null_attribute_comparison_is_false() {
        let a = attrs(&[("account", json!(null))]);
        assert!(!evaluate("account == 'vip'", &a));
    }

    #[test]
    fn test_null_propagation_through_dotted_path() {
        let a = attrs(&[("account", json!(null))]);
        assert!(!evaluate("account.owner.region == 'US'", &a));
    }

    #[test]
    fn test_missing_intermediate_in_dotted_path() {
        let a = attrs(&[("user", json!({}))]);
        assert!(!evaluate("user.profile.name == 'test'", &a));
    }

    #[test]
    fn test_division_by_zero_fails_closed() {
        let a = attrs(&[("limit", json!(5))]);
        assert!(!evaluate("100 / (limit - limit) > 0", &a));
    }

    // ═══════════════════════════════════════════════════════════════
    // is_null() function (replacing IS NULL / IS NOT NULL)
    // ═══════════════════════════════════════════════════════════════

    #[test]
    fn test_is_null_on_missing() {
        assert!(evaluate("is_null(x)", &HashMap::new()));
    }

    #[test]
    fn test_is_null_on_present() {
        let a = attrs(&[("x", json!(5))]);
        assert!(!evaluate("is_null(x)", &a));
    }

    #[test]
    fn test_not_is_null_on_present() {
        let a = attrs(&[("x", json!("hello"))]);
        assert!(evaluate("not is_null(x)", &a));
    }

    #[test]
    fn test_not_is_null_on_missing() {
        assert!(!evaluate("not is_null(x)", &HashMap::new()));
    }

    #[test]
    fn test_eq_null_on_missing() {
        assert!(evaluate("x == null", &HashMap::new()));
    }

    #[test]
    fn test_not_is_null_on_present_value() {
        // Use not is_null() for explicit null checks.
        let a = attrs(&[("x", json!("hello"))]);
        assert!(evaluate("not is_null(x)", &a));
        // Null-safe !=: x != null → false (even when x is present)
        // Use `not is_null(x)` to check for non-null values.
        assert!(!evaluate("x != null", &a));
    }

    // ═══════════════════════════════════════════════════════════════
    // Ternary / Indexing / Conversions
    // ═══════════════════════════════════════════════════════════════

    #[test]
    fn test_ternary_true_branch() {
        let a = attrs(&[("x", json!(true))]);
        assert!(evaluate("x ? true : false", &a));
    }

    #[test]
    fn test_ternary_false_branch() {
        let a = attrs(&[("x", json!(false))]);
        assert!(!evaluate("x ? true : false", &a));
    }

    #[test]
    fn test_ternary_with_comparison() {
        let a = attrs(&[("score", json!(85))]);
        assert!(evaluate("score > 50 ? true : false", &a));
    }

    #[test]
    fn test_ternary_null_condition_takes_else() {
        assert!(!evaluate("x ? true : false", &HashMap::new()));
    }

    #[test]
    fn test_ternary_short_circuits() {
        let a = attrs(&[("x", json!(true)), ("y", json!(0))]);
        assert!(evaluate("x ? true : 1/y > 0", &a));
    }

    #[test]
    fn test_ternary_returns_value() {
        let a = attrs(&[("x", json!(true)), ("val", json!(42))]);
        assert!(evaluate("(x ? val : 0) == 42", &a));
    }

    #[test]
    fn test_index_array_first() {
        let a = attrs(&[("arr", json!([10, 20, 30]))]);
        assert!(evaluate("arr[0] == 10", &a));
    }

    #[test]
    fn test_index_array_last() {
        let a = attrs(&[("arr", json!([10, 20, 30]))]);
        assert!(evaluate("arr[2] == 30", &a));
    }

    #[test]
    fn test_index_array_oob_is_null() {
        let a = attrs(&[("arr", json!([10, 20, 30]))]);
        assert!(evaluate("is_null(arr[99])", &a));
    }

    #[test]
    fn test_index_negative_is_null() {
        let a = attrs(&[("arr", json!([10, 20, 30]))]);
        assert!(evaluate("is_null(arr[-1])", &a));
    }

    #[test]
    fn test_index_map_string_key() {
        let a = attrs(&[("obj", json!({"name": "alice"}))]);
        assert!(evaluate("obj['name'] == 'alice'", &a));
    }

    #[test]
    fn test_index_map_missing_key_is_null() {
        let a = attrs(&[("obj", json!({"name": "alice"}))]);
        assert!(evaluate("is_null(obj['age'])", &a));
    }

    #[test]
    fn test_index_null_object_is_null() {
        assert!(!evaluate("x[0] > 0", &HashMap::new()));
    }

    #[test]
    fn test_index_chained() {
        let a = attrs(&[("matrix", json!([[1, 2], [3, 4]]))]);
        assert!(evaluate("matrix[1][0] == 3", &a));
    }

    #[test]
    fn test_has_existing_key() {
        let a = attrs(&[("obj", json!({"name": "test"}))]);
        assert!(evaluate("has(obj, 'name')", &a));
    }

    #[test]
    fn test_has_missing_key() {
        let a = attrs(&[("obj", json!({"name": "test"}))]);
        assert!(!evaluate("has(obj, 'age')", &a));
    }

    #[test]
    fn test_has_null_valued_key() {
        let a = attrs(&[("obj", json!({"key": null}))]);
        assert!(evaluate("has(obj, 'key')", &a));
    }

    #[test]
    fn test_has_non_object() {
        let a = attrs(&[("x", json!(42))]);
        assert!(!evaluate("has(x, 'key')", &a));
    }

    #[test]
    fn test_integer_from_number() {
        let a = attrs(&[("x", json!(3.7))]);
        assert!(evaluate("integer(x) == 3", &a));
    }

    #[test]
    fn test_integer_from_string() {
        let a = attrs(&[("x", json!("42"))]);
        assert!(evaluate("integer(x) == 42", &a));
    }

    #[test]
    fn test_integer_from_float_string_is_null() {
        // Spec: integer("3.14") → null (only decimal integer strings accepted)
        let a = attrs(&[("x", json!("3.14"))]);
        assert!(evaluate("is_null(integer(x))", &a));
    }

    #[test]
    fn test_integer_from_invalid_string() {
        let a = attrs(&[("x", json!("hello"))]);
        assert!(evaluate("is_null(integer(x))", &a));
    }

    #[test]
    fn test_number_from_string() {
        let a = attrs(&[("x", json!("3.14"))]);
        assert!(evaluate("number(x) > 3", &a));
    }

    #[test]
    fn test_number_from_integer_string() {
        let a = attrs(&[("x", json!("42"))]);
        assert!(evaluate("number(x) == 42", &a));
    }

    #[test]
    fn test_string_from_number() {
        let a = attrs(&[("x", json!(42))]);
        assert!(evaluate("string(x) == '42'", &a));
    }

    #[test]
    fn test_string_from_null_is_null() {
        // Spec: string(null) → null, NOT "null"
        let a = attrs(&[("x", json!(null))]);
        assert!(evaluate("is_null(string(x))", &a));
    }

    #[test]
    fn test_boolean_strict_parse_true() {
        let a = attrs(&[("x", json!("true"))]);
        assert!(evaluate("boolean(x)", &a));
    }

    #[test]
    fn test_boolean_strict_parse_false() {
        let a = attrs(&[("x", json!("false"))]);
        assert!(!evaluate("boolean(x)", &a));
    }

    #[test]
    fn test_boolean_strict_parse_other_string_is_null() {
        // Spec: boolean("yes") → null
        let a = attrs(&[("x", json!("yes"))]);
        assert!(evaluate("is_null(boolean(x))", &a));
    }

    #[test]
    fn test_boolean_strict_parse_number_is_null() {
        // Spec: boolean(1) → null (not truthy coercion)
        let a = attrs(&[("x", json!(1))]);
        assert!(evaluate("is_null(boolean(x))", &a));
    }

    #[test]
    fn test_neq_null_fix_null_neq_value() {
        // Null-safe !=: null != 5 → false (fail-closed)
        let a = attrs(&[("x", json!(null))]);
        assert!(!evaluate("x != 5", &a));
    }

    #[test]
    fn test_neq_null_fix_value_neq_null() {
        // Null-safe !=: 5 != null → false (fail-closed)
        let a = attrs(&[("x", json!(5))]);
        assert!(!evaluate("x != null", &a));
    }

    #[test]
    fn test_neq_null_fix_null_neq_null() {
        let a = attrs(&[("x", json!(null))]);
        assert!(!evaluate("x != null", &a));
    }

    #[test]
    fn test_neq_null_fix_missing_neq_value() {
        // Null-safe !=: missing attribute (null) != 'restricted' → false (fail-closed)
        assert!(!evaluate("x != 'restricted'", &HashMap::new()));
    }

    // ═══════════════════════════════════════════════════════════════
    // Boolean Logic (with truthy coercion)
    // ═══════════════════════════════════════════════════════════════

    #[test]
    fn test_and_truth_table() {
        let tt = attrs(&[("a", json!(true)), ("b", json!(true))]);
        let tf = attrs(&[("a", json!(true)), ("b", json!(false))]);
        let ft = attrs(&[("a", json!(false)), ("b", json!(true))]);
        let ff = attrs(&[("a", json!(false)), ("b", json!(false))]);

        assert!(evaluate("a and b", &tt));
        assert!(!evaluate("a and b", &tf));
        assert!(!evaluate("a and b", &ft));
        assert!(!evaluate("a and b", &ff));
    }

    #[test]
    fn test_or_truth_table() {
        let tt = attrs(&[("a", json!(true)), ("b", json!(true))]);
        let tf = attrs(&[("a", json!(true)), ("b", json!(false))]);
        let ft = attrs(&[("a", json!(false)), ("b", json!(true))]);
        let ff = attrs(&[("a", json!(false)), ("b", json!(false))]);

        assert!(evaluate("a or b", &tt));
        assert!(evaluate("a or b", &tf));
        assert!(evaluate("a or b", &ft));
        assert!(!evaluate("a or b", &ff));
    }

    #[test]
    fn test_not() {
        assert!(!evaluate("not true", &HashMap::new()));
        assert!(evaluate("not false", &HashMap::new()));
    }

    #[test]
    fn test_nested_boolean() {
        let a = attrs(&[("a", json!(false)), ("b", json!(true)), ("c", json!(false))]);
        assert!(evaluate("(a or b) and not c", &a));
    }

    // ── Truthy/falsy coercion ───────────────────────────────────

    #[test]
    fn test_truthy_zero_is_false() {
        let a = attrs(&[("x", json!(0))]);
        assert!(!evaluate("x and true", &a));
    }

    #[test]
    fn test_truthy_nonzero_is_true() {
        let a = attrs(&[("x", json!(42))]);
        assert!(evaluate("x and true", &a));
    }

    #[test]
    fn test_truthy_empty_string_is_false() {
        let a = attrs(&[("x", json!(""))]);
        assert!(!evaluate("x and true", &a));
    }

    #[test]
    fn test_truthy_nonempty_string_is_true() {
        let a = attrs(&[("x", json!("hello"))]);
        assert!(evaluate("x and true", &a));
    }

    #[test]
    fn test_truthy_empty_array_is_false() {
        let a = attrs(&[("x", json!([]))]);
        assert!(!evaluate("x and true", &a));
    }

    #[test]
    fn test_truthy_nonempty_array_is_true() {
        let a = attrs(&[("x", json!([1, 2]))]);
        assert!(evaluate("x and true", &a));
    }

    #[test]
    fn test_truthy_empty_object_is_false() {
        let a = attrs(&[("x", json!({}))]);
        assert!(!evaluate("x and true", &a));
    }

    #[test]
    fn test_truthy_nonempty_object_is_true() {
        let a = attrs(&[("x", json!({"a": 1}))]);
        assert!(evaluate("x and true", &a));
    }

    // ═══════════════════════════════════════════════════════════════
    // String Operations (function-call syntax)
    // ═══════════════════════════════════════════════════════════════

    #[test]
    fn test_contains_function() {
        let a = attrs(&[("name", json!("this is a test case"))]);
        assert!(evaluate("contains(name, 'test')", &a));
        assert!(!evaluate("contains(name, 'xyz')", &a));
    }

    #[test]
    fn test_startswith_function() {
        let a = attrs(&[("path", json!("/api/v1/users"))]);
        assert!(evaluate("startswith(path, '/api')", &a));
        assert!(!evaluate("startswith(path, '/web')", &a));
    }

    #[test]
    fn test_endswith_function() {
        let a = attrs(&[("file", json!("report.pdf"))]);
        assert!(evaluate("endswith(file, '.pdf')", &a));
        assert!(!evaluate("endswith(file, '.doc')", &a));
    }

    #[test]
    fn test_regex_match_function() {
        // Single-quoted strings are raw: \d passes through literally
        let a = attrs(&[("ssn", json!("123-45-6789"))]);
        assert!(evaluate("regex.match('\\d{3}-\\d{2}-\\d{4}', ssn)", &a));

        let a2 = attrs(&[("ssn", json!("not-an-ssn"))]);
        assert!(!evaluate("regex.match('\\d{3}-\\d{2}-\\d{4}', ssn)", &a2));
    }

    #[test]
    fn test_regex_match_redos_protection() {
        let long_pattern = "a".repeat(501);
        let expr = format!("regex.match('{long_pattern}', x)");
        let a = attrs(&[("x", json!("test"))]);
        assert!(!evaluate(&expr, &a)); // Pattern >500 chars → false
    }

    #[test]
    fn test_regex_match_invalid_pattern() {
        let a = attrs(&[("x", json!("test"))]);
        assert!(!evaluate("regex.match('[invalid', x)", &a)); // Malformed → false
    }

    #[test]
    fn test_lower_function() {
        let a = attrs(&[("x", json!("HELLO"))]);
        // lower returns a string, we need to compare
        assert!(evaluate("lower(x) == 'hello'", &a));
    }

    #[test]
    fn test_upper_function() {
        let a = attrs(&[("x", json!("hello"))]);
        assert!(evaluate("upper(x) == 'HELLO'", &a));
    }

    // ═══════════════════════════════════════════════════════════════
    // Type-Checking Functions
    // ═══════════════════════════════════════════════════════════════

    #[test]
    fn test_is_string() {
        let a = attrs(&[("x", json!("hello"))]);
        assert!(evaluate("is_string(x)", &a));
        let a2 = attrs(&[("x", json!(42))]);
        assert!(!evaluate("is_string(x)", &a2));
    }

    #[test]
    fn test_is_number() {
        let a = attrs(&[("x", json!(42))]);
        assert!(evaluate("is_number(x)", &a));
        let a2 = attrs(&[("x", json!("hello"))]);
        assert!(!evaluate("is_number(x)", &a2));
    }

    #[test]
    fn test_is_boolean() {
        let a = attrs(&[("x", json!(true))]);
        assert!(evaluate("is_boolean(x)", &a));
        let a2 = attrs(&[("x", json!(42))]);
        assert!(!evaluate("is_boolean(x)", &a2));
    }

    #[test]
    fn test_is_array() {
        let a = attrs(&[("x", json!([1, 2]))]);
        assert!(evaluate("is_array(x)", &a));
        let a2 = attrs(&[("x", json!(42))]);
        assert!(!evaluate("is_array(x)", &a2));
    }

    #[test]
    fn test_is_object() {
        let a = attrs(&[("x", json!({"a": 1}))]);
        assert!(evaluate("is_object(x)", &a));
        let a2 = attrs(&[("x", json!(42))]);
        assert!(!evaluate("is_object(x)", &a2));
    }

    #[test]
    fn test_type_name() {
        let a = attrs(&[("x", json!("hello"))]);
        assert!(evaluate("type_name(x) == 'string'", &a));
        let a2 = attrs(&[("x", json!(42))]);
        assert!(evaluate("type_name(x) == 'number'", &a2));
        let a3 = attrs(&[("x", json!(null))]);
        assert!(evaluate("type_name(x) == 'null'", &a3));
    }

    // ═══════════════════════════════════════════════════════════════
    // Collection Functions
    // ═══════════════════════════════════════════════════════════════

    #[test]
    fn test_count_array() {
        let a = attrs(&[("x", json!([1, 2, 3]))]);
        assert!(evaluate("count(x) == 3", &a));
    }

    #[test]
    fn test_count_string() {
        let a = attrs(&[("x", json!("hello"))]);
        assert!(evaluate("count(x) == 5", &a));
    }

    #[test]
    fn test_count_object() {
        let a = attrs(&[("x", json!({"a": 1, "b": 2}))]);
        assert!(evaluate("count(x) == 2", &a));
    }

    #[test]
    fn test_count_null_fails_closed() {
        assert!(!evaluate("count(x) > 0", &HashMap::new()));
    }

    #[test]
    fn test_sum() {
        let a = attrs(&[("x", json!([1, 2, 3]))]);
        assert!(evaluate("sum(x) == 6", &a));
    }

    #[test]
    fn test_max() {
        let a = attrs(&[("x", json!([3, 1, 2]))]);
        assert!(evaluate("max(x) == 3", &a));
    }

    #[test]
    fn test_min() {
        let a = attrs(&[("x", json!([3, 1, 2]))]);
        assert!(evaluate("min(x) == 1", &a));
    }

    // §7.4 — two-scalar max(a, b) / min(a, b) for `update:` expressions.

    #[test]
    fn test_max_two_scalars_numbers() {
        let a = HashMap::new();
        assert!(evaluate("max(3, 7) == 7", &a));
        assert!(evaluate("max(7, 3) == 7", &a));
        assert!(evaluate("max(-1, -5) == -1", &a));
    }

    #[test]
    fn test_min_two_scalars_numbers() {
        let a = HashMap::new();
        assert!(evaluate("min(3, 7) == 3", &a));
        assert!(evaluate("min(-1, -5) == -5", &a));
    }

    #[test]
    fn test_max_two_scalars_strings_lex_order() {
        let a = HashMap::new();
        // String ordering is lexicographic per LANGUAGE.md §3.3 — until
        // §10 enums land, max() over strings uses code-point order.
        assert!(evaluate("max('public', 'restricted') == 'restricted'", &a));
        assert!(evaluate("min('public', 'restricted') == 'public'", &a));
    }

    #[test]
    fn test_max_min_cross_type_returns_null() {
        let a = HashMap::new();
        // Cross-type comparisons fail closed.
        assert!(!evaluate("max(5, 'x') == 5", &a));
        assert!(!evaluate("min(5, 'x') == 5", &a));
    }

    #[test]
    fn test_max_min_with_null_returns_null() {
        let a = attrs(&[("x", json!(null))]);
        // null propagates through scalar max/min — `null` folds to false.
        assert!(!evaluate("max(x, 5) == 5", &a));
        assert!(!evaluate("min(x, 5) == 5", &a));
    }

    // §7.4 — union(a, b)

    #[test]
    fn test_union_dedups_preserving_order() {
        let a = attrs(&[("x", json!([1, 2, 3])), ("y", json!([2, 3, 4, 5]))]);
        assert!(evaluate("union(x, y) == [1, 2, 3, 4, 5]", &a));
    }

    #[test]
    fn test_union_with_null_treated_as_empty() {
        let a = attrs(&[("x", json!(null)), ("y", json!([1, 2]))]);
        assert!(evaluate("union(x, y) == [1, 2]", &a));
        assert!(evaluate("union(y, x) == [1, 2]", &a));
        assert!(evaluate("union(x, x) == []", &a));
    }

    #[test]
    fn test_union_strings() {
        let a = attrs(&[("x", json!(["a", "b"])), ("y", json!(["b", "c"]))]);
        assert!(evaluate("union(x, y) == ['a', 'b', 'c']", &a));
    }

    #[test]
    fn test_union_non_array_returns_null() {
        let a = attrs(&[("x", json!("hello"))]);
        // null comparison folds to false in boolean context.
        assert!(!evaluate("union(x, [1]) == [1]", &a));
    }

    // §7.4 / IFC — intersect(a, b)

    #[test]
    fn test_intersect_keeps_only_common_elements() {
        let a = attrs(&[("x", json!([1, 2, 3])), ("y", json!([2, 3, 4]))]);
        assert!(evaluate("intersect(x, y) == [2, 3]", &a));
    }

    #[test]
    fn test_intersect_preserves_order_of_first_argument() {
        let a = attrs(&[("x", json!([3, 1, 2])), ("y", json!([1, 2, 3]))]);
        // First-arg order is preserved.
        assert!(evaluate("intersect(x, y) == [3, 1, 2]", &a));
        assert!(evaluate("intersect(y, x) == [1, 2, 3]", &a));
    }

    #[test]
    fn test_intersect_dedups_when_first_arg_has_duplicates() {
        let a = attrs(&[("x", json!([1, 1, 2, 2, 3])), ("y", json!([1, 3]))]);
        assert!(evaluate("intersect(x, y) == [1, 3]", &a));
    }

    #[test]
    fn test_intersect_with_null_yields_empty() {
        let a = attrs(&[("x", json!(null)), ("y", json!([1, 2]))]);
        assert!(evaluate("intersect(x, y) == []", &a));
        assert!(evaluate("intersect(y, x) == []", &a));
    }

    #[test]
    fn test_intersect_strings() {
        let a = attrs(&[
            ("x", json!(["public", "internal", "secret"])),
            ("y", json!(["internal", "trusted"])),
        ]);
        assert!(evaluate("intersect(x, y) == ['internal']", &a));
    }

    #[test]
    fn test_intersect_non_array_returns_null() {
        let a = attrs(&[("x", json!("hello"))]);
        assert!(!evaluate("intersect(x, [1]) == [1]", &a));
    }

    #[test]
    fn test_intersect_classic_ifc_narrowing() {
        // The canonical IFC monotone-narrowing pattern: each tool result
        // can only NARROW the trust set, never widen it.
        // Step 1: start with three labels.
        let a = attrs(&[
            ("current", json!(["public", "internal", "trusted"])),
            ("incoming", json!(["public", "trusted"])),
        ]);
        assert!(evaluate(
            "intersect(current, incoming) == ['public', 'trusted']",
            &a
        ));
        // Step 2: narrow further.
        let b = attrs(&[
            ("current", json!(["public", "trusted"])),
            ("incoming", json!(["public"])),
        ]);
        assert!(evaluate("intersect(current, incoming) == ['public']", &b));
        // Step 3: widening attempt (incoming has more) — output still
        // bounded by current.
        let c = attrs(&[
            ("current", json!(["public"])),
            ("incoming", json!(["public", "trusted", "internal"])),
        ]);
        assert!(evaluate("intersect(current, incoming) == ['public']", &c));
    }

    // §7.4 — object.merge_patch(a, b) per RFC 7396

    #[test]
    fn test_object_merge_patch_replaces_scalar() {
        let a = attrs(&[("x", json!({"a": 1, "b": 2})), ("y", json!({"b": 99}))]);
        // Verify field-by-field via object.get since object literals
        // aren't yet expression-language syntax.
        assert!(evaluate(
            "object.get(object.merge_patch(x, y), 'a', 0) == 1",
            &a
        ));
        assert!(evaluate(
            "object.get(object.merge_patch(x, y), 'b', 0) == 99",
            &a
        ));
    }

    #[test]
    fn test_object_merge_patch_null_deletes_key() {
        let a = attrs(&[("x", json!({"a": 1, "b": 2})), ("y", json!({"b": null}))]);
        assert!(evaluate("has(object.merge_patch(x, y), 'a')", &a));
        assert!(!evaluate("has(object.merge_patch(x, y), 'b')", &a));
        assert!(evaluate(
            "count(object.keys(object.merge_patch(x, y))) == 1",
            &a
        ));
    }

    #[test]
    fn test_object_merge_patch_recursive_object_merge() {
        let a = attrs(&[
            ("x", json!({"outer": {"a": 1, "b": 2}})),
            ("y", json!({"outer": {"b": 99, "c": 3}})),
        ]);
        // outer.a from x; outer.b replaced by y; outer.c added by y.
        assert!(evaluate(
            "object.get(object.merge_patch(x, y).outer, 'a', 0) == 1",
            &a
        ));
        assert!(evaluate(
            "object.get(object.merge_patch(x, y).outer, 'b', 0) == 99",
            &a
        ));
        assert!(evaluate(
            "object.get(object.merge_patch(x, y).outer, 'c', 0) == 3",
            &a
        ));
    }

    #[test]
    fn test_object_merge_patch_array_replaces_not_merges() {
        // RFC 7396: arrays in patch replace target arrays entirely.
        let a = attrs(&[
            ("x", json!({"items": [1, 2, 3]})),
            ("y", json!({"items": [9]})),
        ]);
        assert!(evaluate(
            "count(object.get(object.merge_patch(x, y), 'items', [])) == 1",
            &a
        ));
    }

    #[test]
    fn test_object_merge_patch_null_target_treated_as_empty() {
        let a = attrs(&[("x", json!(null)), ("y", json!({"a": 1}))]);
        assert!(evaluate(
            "object.get(object.merge_patch(x, y), 'a', 0) == 1",
            &a
        ));
    }

    // §7.4 — is_enum() stub
    #[test]
    fn test_is_enum_returns_false_until_enum_lands() {
        let a = attrs(&[("x", json!("public"))]);
        // Enum-tag awareness is not yet wired; is_enum is a contract
        // stub returning false. Enum support arrives in the §10 commit.
        assert!(evaluate("is_enum(x) == false", &a));
    }

    // ═══════════════════════════════════════════════════════════════
    // Object Functions
    // ═══════════════════════════════════════════════════════════════

    #[test]
    fn test_object_get_existing_key() {
        let a = attrs(&[("config", json!({"max_retries": 5}))]);
        assert!(evaluate("object.get(config, 'max_retries', 3) == 5", &a));
    }

    #[test]
    fn test_object_get_missing_key_returns_default() {
        let a = attrs(&[("config", json!({"other": 1}))]);
        assert!(evaluate("object.get(config, 'max_retries', 3) == 3", &a));
    }

    #[test]
    fn test_object_get_null_object_returns_default() {
        assert!(evaluate(
            "object.get(config, 'key', 0) == 0",
            &HashMap::new()
        ));
    }

    #[test]
    fn test_object_keys() {
        let a = attrs(&[("x", json!({"a": 1, "b": 2}))]);
        // object.keys returns an array; we can check count
        assert!(evaluate("count(object.keys(x)) == 2", &a));
    }

    // ═══════════════════════════════════════════════════════════════
    // Math Functions
    // ═══════════════════════════════════════════════════════════════

    #[test]
    fn test_abs() {
        let a = attrs(&[("x", json!(-5))]);
        assert!(evaluate("abs(x) == 5", &a));
    }

    #[test]
    fn test_round() {
        let a = attrs(&[("x", json!(3.7))]);
        assert!(evaluate("round(x) == 4", &a));
    }

    #[test]
    fn test_ceil() {
        let a = attrs(&[("x", json!(3.2))]);
        assert!(evaluate("ceil(x) == 4", &a));
    }

    #[test]
    fn test_floor() {
        let a = attrs(&[("x", json!(3.7))]);
        assert!(evaluate("floor(x) == 3", &a));
    }

    // ═══════════════════════════════════════════════════════════════
    // Modulo Operator
    // ═══════════════════════════════════════════════════════════════

    #[test]
    fn test_modulo() {
        let a = attrs(&[("x", json!(10))]);
        assert!(evaluate("x % 3 == 1", &a));
    }

    #[test]
    fn test_modulo_by_zero_fails_closed() {
        let a = attrs(&[("x", json!(10))]);
        assert!(!evaluate("x % 0 > 0", &a));
    }

    // ═══════════════════════════════════════════════════════════════
    // Semicolon Conjunction
    // ═══════════════════════════════════════════════════════════════

    #[test]
    fn test_semicolon_as_and() {
        let a = attrs(&[("x", json!(5)), ("y", json!(3))]);
        assert!(evaluate("x > 0; y > 0", &a));
        assert!(!evaluate("x > 10; y > 0", &a));
    }

    // ═══════════════════════════════════════════════════════════════
    // Variable Binding (:=)
    // ═══════════════════════════════════════════════════════════════

    #[test]
    fn test_variable_binding() {
        let a = attrs(&[("account", json!({"balance": 1000}))]);
        assert!(evaluate("bal := account.balance; bal > 0; bal < 50000", &a));
    }

    #[test]
    fn test_variable_binding_arithmetic() {
        let a = attrs(&[("x", json!(10)), ("rate", json!(1.5))]);
        assert!(evaluate("total := x * rate; total < 20", &a));
    }

    #[test]
    fn test_variable_binding_immutable() {
        // Reassigning a bound variable fails closed (spec §3.6.1.4: immutable)
        let a = attrs(&[("x", json!(10))]);
        assert!(!evaluate("v := x; v := x; v > 0", &a));
    }

    #[test]
    fn test_variable_binding_falsy_value_does_not_short_circuit() {
        // Binding a falsy value (0) must not short-circuit the ; chain.
        // The assignment succeeds; the subsequent condition evaluates independently.
        let a = attrs(&[("x", json!(0))]);
        assert!(evaluate("v := x; v == 0", &a));
    }

    // ═══════════════════════════════════════════════════════════════
    // Arithmetic
    // ═══════════════════════════════════════════════════════════════

    #[test]
    fn test_addition() {
        let a = attrs(&[("failed_attempts", json!(3))]);
        assert!(evaluate("failed_attempts + 1 > 3", &a));

        let a2 = attrs(&[("failed_attempts", json!(2))]);
        assert!(!evaluate("failed_attempts + 1 > 3", &a2));
    }

    #[test]
    fn test_no_implicit_type_coercion() {
        // String "5" != Number 5 — no JavaScript-style coercion
        let a = attrs(&[("x", json!("5"))]);
        assert!(!evaluate("x == 5", &a));
    }

    // ═══════════════════════════════════════════════════════════════
    // Collection / Set Operations
    // ═══════════════════════════════════════════════════════════════

    #[test]
    fn test_in_with_string_list() {
        let a = attrs(&[("role", json!("admin"))]);
        assert!(evaluate("role in ['admin', 'mod']", &a));

        let a2 = attrs(&[("role", json!("user"))]);
        assert!(!evaluate("role in ['admin', 'mod']", &a2));
    }

    #[test]
    fn test_not_in_decomposed() {
        let a = attrs(&[("role", json!("admin"))]);
        assert!(evaluate("not role in ['guest', 'banned']", &a));
    }

    #[test]
    fn test_string_in_array_attribute() {
        let a = attrs(&[("active_compliance_contexts", json!(["HIPAA", "SOX"]))]);
        assert!(evaluate("'HIPAA' in active_compliance_contexts", &a));
        assert!(!evaluate("'PCI' in active_compliance_contexts", &a));
    }

    #[test]
    fn test_object_get_replaces_has() {
        // Old: metadata HAS 'classification'
        // New: not is_null(object.get(metadata, 'classification', null))
        let a = attrs(&[("metadata", json!({"classification": "internal"}))]);
        assert!(evaluate(
            "not is_null(object.get(metadata, 'classification', null))",
            &a
        ));
        assert!(!evaluate(
            "not is_null(object.get(metadata, 'missing_key', null))",
            &a
        ));
    }

    #[test]
    fn test_object_get_null_value_returns_default() {
        let a = attrs(&[("metadata", json!({"present": "yes", "empty": null}))]);
        assert!(evaluate(
            "not is_null(object.get(metadata, 'present', null))",
            &a
        ));
        assert!(!evaluate(
            "not is_null(object.get(metadata, 'empty', null))",
            &a
        ));
        assert!(!evaluate(
            "not is_null(object.get(metadata, 'missing', null))",
            &a
        ));
    }

    // ═══════════════════════════════════════════════════════════════
    // Date/Time (injectable clock, Rego-namespaced)
    // ═══════════════════════════════════════════════════════════════

    #[test]
    fn test_time_now_hour_business_hours() {
        let _lock = CLOCK_LOCK.lock().unwrap();
        use chrono::TimeZone;

        // 14:00 UTC → within business hours
        set_now_factory(Some(|| {
            Utc.with_ymd_and_hms(2024, 1, 15, 14, 0, 0).unwrap()
        }));
        let in_hours = evaluate(
            "time.now().hour >= 9 and time.now().hour < 17",
            &HashMap::new(),
        );

        // 22:00 UTC → outside business hours
        set_now_factory(Some(|| {
            Utc.with_ymd_and_hms(2024, 1, 15, 22, 0, 0).unwrap()
        }));
        let out_hours = evaluate(
            "time.now().hour >= 9 and time.now().hour < 17",
            &HashMap::new(),
        );

        set_now_factory(None);

        assert!(in_hours);
        assert!(!out_hours);
    }

    #[test]
    fn test_time_now_weekday() {
        let _lock = CLOCK_LOCK.lock().unwrap();
        use chrono::TimeZone;
        // 2024-01-15 is a Monday
        set_now_factory(Some(|| {
            Utc.with_ymd_and_hms(2024, 1, 15, 12, 0, 0).unwrap()
        }));
        let is_monday = evaluate("time.now().weekday == 'Monday'", &HashMap::new());
        set_now_factory(None);
        assert!(is_monday);
    }

    #[test]
    fn test_time_weekday_function() {
        let _lock = CLOCK_LOCK.lock().unwrap();
        use chrono::TimeZone;
        set_now_factory(Some(|| {
            Utc.with_ymd_and_hms(2024, 1, 15, 12, 0, 0).unwrap()
        }));
        let is_monday = evaluate("time.weekday(time.now()) == 'Monday'", &HashMap::new());
        set_now_factory(None);
        assert!(is_monday);
    }

    #[test]
    fn test_time_clock_function() {
        let _lock = CLOCK_LOCK.lock().unwrap();
        use chrono::TimeZone;
        set_now_factory(Some(|| {
            Utc.with_ymd_and_hms(2024, 1, 15, 14, 30, 45).unwrap()
        }));
        // time.clock returns [h, m, s]; we can't easily index arrays yet
        // but we can verify it returns a non-empty list via count
        let result = evaluate("count(time.clock(time.now())) == 3", &HashMap::new());
        set_now_factory(None);
        assert!(result);
    }

    #[test]
    fn test_weekday_weekend_in_list() {
        let _lock = CLOCK_LOCK.lock().unwrap();
        use chrono::TimeZone;
        // 2024-01-20 is a Saturday
        set_now_factory(Some(|| {
            Utc.with_ymd_and_hms(2024, 1, 20, 12, 0, 0).unwrap()
        }));
        let is_weekend = evaluate(
            "time.now().weekday in ['Saturday', 'Sunday']",
            &HashMap::new(),
        );
        let is_weekday = evaluate("time.now().weekday == 'Monday'", &HashMap::new());
        set_now_factory(None);
        assert!(is_weekend);
        assert!(!is_weekday);
    }

    #[test]
    fn test_duration_comparison() {
        let _lock = CLOCK_LOCK.lock().unwrap();
        use chrono::TimeZone;
        set_now_factory(Some(|| Utc.with_ymd_and_hms(2024, 1, 1, 10, 0, 0).unwrap()));

        let a = attrs(&[("session_start", json!("2024-01-01T09:40:00Z"))]);
        // 20 minutes ago < 30 minutes → true
        let result = evaluate("time.now() - session_start < time.duration('30m')", &a);
        set_now_factory(None);
        assert!(result);
    }

    #[test]
    fn test_null_datetime_fails_closed() {
        // Missing session_start → arithmetic fails → comparison fails → false
        assert!(!evaluate(
            "time.now() - session_start < time.duration('30m')",
            &HashMap::new()
        ));
    }

    #[test]
    fn test_duration_units() {
        let _lock = CLOCK_LOCK.lock().unwrap();
        use chrono::TimeZone;
        set_now_factory(Some(|| Utc.with_ymd_and_hms(2024, 1, 1, 1, 0, 0).unwrap()));

        let base = "2024-01-01T00:00:00Z";
        let a = attrs(&[("t", json!(base))]);
        let r1 = evaluate("time.now() - t < time.duration('2h')", &a); // 1h < 2h
        let r2 = evaluate("time.now() - t < time.duration('30m')", &a); // 1h > 30m
        let r3 = evaluate("time.now() - t < time.duration('1d')", &a); // 1h < 1d
        set_now_factory(None);

        assert!(r1);
        assert!(!r2);
        assert!(r3);
    }

    // ═══════════════════════════════════════════════════════════════
    // Real-World: Bank Manager expressions
    // ═══════════════════════════════════════════════════════════════

    #[test]
    fn test_fraud_threshold_boundary() {
        let a50 = attrs(&[("fraud_score", json!(50))]);
        let a49 = attrs(&[("fraud_score", json!(49))]);
        assert!(evaluate("fraud_score >= 50", &a50)); // boundary: exactly 50
        assert!(!evaluate("fraud_score >= 50", &a49)); // one below
    }

    #[test]
    fn test_compound_transfer_guard() {
        let expr = "fraud_score < 75 and transaction_velocity < 10 and geographic_anomaly == false";

        // All conditions met
        let ok = attrs(&[
            ("fraud_score", json!(30)),
            ("transaction_velocity", json!(5)),
            ("geographic_anomaly", json!(false)),
        ]);
        assert!(evaluate(expr, &ok));

        // First condition fails
        let bad_fraud = attrs(&[
            ("fraud_score", json!(80)),
            ("transaction_velocity", json!(5)),
            ("geographic_anomaly", json!(false)),
        ]);
        assert!(!evaluate(expr, &bad_fraud));

        // Last condition fails
        let bad_geo = attrs(&[
            ("fraud_score", json!(30)),
            ("transaction_velocity", json!(5)),
            ("geographic_anomaly", json!(true)),
        ]);
        assert!(!evaluate(expr, &bad_geo));
    }

    #[test]
    fn test_sensitivity_in_list() {
        let expr = "account_sensitivity in ['vip', 'high_net_worth']";
        let a = attrs(&[("account_sensitivity", json!("vip"))]);
        assert!(evaluate(expr, &a));

        let a2 = attrs(&[("account_sensitivity", json!("standard"))]);
        assert!(!evaluate(expr, &a2));
    }

    // ═══════════════════════════════════════════════════════════════
    // Edge Cases
    // ═══════════════════════════════════════════════════════════════

    #[test]
    fn test_empty_expression_is_true() {
        assert!(evaluate("", &HashMap::new()));
    }

    #[test]
    fn test_null_equals_null() {
        let a = attrs(&[("x", json!(null))]);
        assert!(evaluate("x == null", &a));
    }

    #[test]
    fn test_parse_error_fails_closed() {
        assert!(!evaluate("a and and b", &HashMap::new()));
    }

    #[test]
    fn test_deeply_nested_dotted_access() {
        let a = attrs(&[("a", json!({"b": {"c": {"d": "found"}}}))]);
        assert!(evaluate("a.b.c.d == 'found'", &a));
    }

    // ═══════════════════════════════════════════════════════════════
    // Normative Null Propagation Table (Spec §3.6.1.2)
    // ═══════════════════════════════════════════════════════════════

    // --- not on null → false (fail-closed) ---

    #[test]
    fn test_not_missing_attribute_is_false() {
        // not <missing> → not null → false (fail-closed, spec §3.6.1.2)
        assert!(!evaluate("not x", &HashMap::new()));
    }

    #[test]
    fn test_not_null_arithmetic_is_false() {
        // not (null_arith) where null_arith = missing + 5 → null
        // not null → false (fail-closed)
        assert!(!evaluate("not (x + 5)", &HashMap::new()));
    }

    #[test]
    fn test_not_missing_eq_returns_true() {
        // not (x == 'restricted') where x is missing:
        // x == 'restricted' → false (fail-closed), not false → true
        // This is correct: the == already fail-closed, not inverts the boolean.
        assert!(evaluate("not (x == 'restricted')", &HashMap::new()));
    }

    // --- Comparison operators with null → false ---

    #[test]
    fn test_null_less_than_is_false() {
        assert!(!evaluate("x < 10", &HashMap::new()));
    }

    #[test]
    fn test_null_greater_than_is_false() {
        assert!(!evaluate("x > 10", &HashMap::new()));
    }

    #[test]
    fn test_null_less_than_eq_is_false() {
        assert!(!evaluate("x <= 10", &HashMap::new()));
    }

    #[test]
    fn test_null_greater_than_eq_is_false() {
        assert!(!evaluate("x >= 10", &HashMap::new()));
    }

    #[test]
    fn test_explicit_null_less_than_is_false() {
        let a = attrs(&[("x", json!(null))]);
        assert!(!evaluate("x < 10", &a));
    }

    #[test]
    fn test_explicit_null_greater_than_is_false() {
        let a = attrs(&[("x", json!(null))]);
        assert!(!evaluate("x > 10", &a));
    }

    // --- and with null operands → false ---

    #[test]
    fn test_null_and_true_is_false() {
        let a = attrs(&[("y", json!(true))]);
        assert!(!evaluate("x and y", &a));
    }

    #[test]
    fn test_true_and_null_is_false() {
        let a = attrs(&[("x", json!(true))]);
        assert!(!evaluate("x and y", &a));
    }

    #[test]
    fn test_null_and_false_is_false() {
        let a = attrs(&[("y", json!(false))]);
        assert!(!evaluate("x and y", &a));
    }

    #[test]
    fn test_null_and_null_is_false() {
        assert!(!evaluate("x and y", &HashMap::new()));
    }

    // --- or with null operands ---

    #[test]
    fn test_null_or_true_is_true() {
        let a = attrs(&[("y", json!(true))]);
        assert!(evaluate("x or y", &a));
    }

    #[test]
    fn test_true_or_null_is_true() {
        let a = attrs(&[("x", json!(true))]);
        assert!(evaluate("x or y", &a));
    }

    #[test]
    fn test_null_or_false_is_false() {
        let a = attrs(&[("y", json!(false))]);
        assert!(!evaluate("x or y", &a));
    }

    #[test]
    fn test_false_or_null_is_false() {
        let a = attrs(&[("x", json!(false))]);
        assert!(!evaluate("x or y", &a));
    }

    #[test]
    fn test_null_or_null_is_false() {
        assert!(!evaluate("x or y", &HashMap::new()));
    }

    // --- String operations with null → false ---

    #[test]
    fn test_null_contains_is_false() {
        assert!(!evaluate("contains(x, 'test')", &HashMap::new()));
    }

    #[test]
    fn test_null_startswith_is_false() {
        assert!(!evaluate("startswith(x, '/api')", &HashMap::new()));
    }

    #[test]
    fn test_null_endswith_is_false() {
        assert!(!evaluate("endswith(x, '.pdf')", &HashMap::new()));
    }

    #[test]
    fn test_null_regex_match_is_false() {
        assert!(!evaluate("regex.match('\\\\d+', x)", &HashMap::new()));
    }

    // --- is_null on explicit null value ---

    #[test]
    fn test_is_null_on_explicit_null_value() {
        let a = attrs(&[("x", json!(null))]);
        assert!(evaluate("is_null(x)", &a));
    }

    #[test]
    fn test_not_is_null_on_explicit_null_value() {
        let a = attrs(&[("x", json!(null))]);
        assert!(!evaluate("not is_null(x)", &a));
    }

    // --- Arithmetic with null → null → comparison false ---

    #[test]
    fn test_null_addition_is_false() {
        assert!(!evaluate("x + 5 > 0", &HashMap::new()));
    }

    #[test]
    fn test_null_subtraction_is_false() {
        assert!(!evaluate("10 - x > 0", &HashMap::new()));
    }

    // --- object.get with null target → returns default ---

    #[test]
    fn test_object_get_on_null_attribute_returns_default() {
        let a = attrs(&[("x", json!(null))]);
        assert!(evaluate("object.get(x, 'key', 0) == 0", &a));
    }

    #[test]
    fn test_double_ampersand_parity() {
        let a = attrs(&[("x", json!(true)), ("y", json!(false))]);
        assert_eq!(evaluate("x && y", &a), evaluate("x and y", &a));
    }

    #[test]
    fn test_double_pipe_parity() {
        let a = attrs(&[("x", json!(false)), ("y", json!(true))]);
        assert_eq!(evaluate("x || y", &a), evaluate("x or y", &a));
    }

    #[test]
    fn test_bang_parity() {
        let a = attrs(&[("x", json!(true))]);
        assert_eq!(evaluate("!x", &a), evaluate("not x", &a));
    }

    #[test]
    fn test_mixed_symbolic_and_keyword() {
        let a = attrs(&[("x", json!(true)), ("y", json!(false)), ("z", json!(true))]);
        assert_eq!(
            evaluate("x && !y || z", &a),
            evaluate("x and not y or z", &a)
        );
    }

    #[test]
    fn test_and_short_circuit_absorbs_error() {
        assert!(!evaluate("false && 1/0 > 0", &HashMap::new()));
    }

    #[test]
    fn test_or_short_circuit_absorbs_error() {
        let a = attrs(&[("x", json!(true))]);
        assert!(evaluate("x || 1/0 > 0", &a));
    }

    #[test]
    fn test_ternary_short_circuit_absorbs_error() {
        let a = attrs(&[("x", json!(true))]);
        assert!(evaluate("(x ? 42 : 1/0) == 42", &a));
    }

    #[test]
    fn test_expression_length_limit() {
        let long_expr = format!("x == '{}'", "a".repeat(4090));
        assert!(!evaluate(&long_expr, &HashMap::new()));
    }

    #[test]
    fn test_index_with_extension() {
        let a = attrs(&[("s", json!("a,b,c"))]);
        assert!(evaluate("split(s, ',')[1] == 'b'", &a));
    }

    #[test]
    fn test_has_with_ternary() {
        let a = attrs(&[("obj", json!({"name": "test"}))]);
        assert!(evaluate(
            "has(obj, 'name') ? obj['name'] == 'test' : false",
            &a
        ));
    }

    #[test]
    fn test_type_conversion_chain() {
        let a = attrs(&[("x", json!("42"))]);
        assert!(evaluate("integer(x) + 8 == 50", &a));
    }

    // ═══════════════════════════════════════════════════════════════
    // New type inspection functions: is_datetime, is_duration, is_integer
    // ═══════════════════════════════════════════════════════════════

    #[test]
    fn test_is_integer_true_for_whole_number() {
        let a = attrs(&[("x", json!(5))]);
        assert!(evaluate("is_integer(x)", &a));
    }

    #[test]
    fn test_is_integer_true_for_zero() {
        let a = attrs(&[("x", json!(0))]);
        assert!(evaluate("is_integer(x)", &a));
    }

    #[test]
    fn test_is_integer_false_for_fractional() {
        let a = attrs(&[("x", json!(5.5))]);
        assert!(!evaluate("is_integer(x)", &a));
    }

    #[test]
    fn test_is_integer_false_for_string() {
        let a = attrs(&[("x", json!("5"))]);
        assert!(!evaluate("is_integer(x)", &a));
    }

    #[test]
    fn test_is_integer_false_for_null() {
        assert!(!evaluate("is_integer(missing)", &HashMap::new()));
    }

    #[test]
    fn test_is_datetime_true_for_parsed_iso_string() {
        // ISO 8601 strings are auto-parsed to datetime by value_to_eval
        let a = attrs(&[("x", json!("2025-01-01T00:00:00Z"))]);
        assert!(evaluate("is_datetime(x)", &a));
    }

    #[test]
    fn test_is_datetime_false_for_plain_string() {
        let a = attrs(&[("x", json!("not a date"))]);
        assert!(!evaluate("is_datetime(x)", &a));
    }

    #[test]
    fn test_is_datetime_true_for_time_now() {
        assert!(evaluate("is_datetime(time.now())", &HashMap::new()));
    }

    #[test]
    fn test_is_duration_false_for_number() {
        let a = attrs(&[("x", json!(30))]);
        assert!(!evaluate("is_duration(x)", &a));
    }

    #[test]
    fn test_is_duration_true_for_time_duration() {
        assert!(evaluate(
            "is_duration(time.duration('30m'))",
            &HashMap::new()
        ));
    }

    // ═══════════════════════════════════════════════════════════════
    // object.values
    // ═══════════════════════════════════════════════════════════════

    #[test]
    fn test_object_values_returns_array() {
        let a = attrs(&[("obj", json!({"a": 1, "b": 2}))]);
        assert!(evaluate("is_array(object.values(obj))", &a));
    }

    #[test]
    fn test_object_values_count() {
        let a = attrs(&[("obj", json!({"a": 1, "b": 2, "c": 3}))]);
        assert!(evaluate("count(object.values(obj)) == 3", &a));
    }

    #[test]
    fn test_object_values_null_receiver() {
        assert!(evaluate("is_null(object.values(missing))", &HashMap::new()));
    }

    // ═══════════════════════════════════════════════════════════════
    // Renamed conversion functions: integer, number, boolean, string
    // ═══════════════════════════════════════════════════════════════

    #[test]
    fn test_integer_from_bool_true() {
        let a = attrs(&[("x", json!(true))]);
        assert!(evaluate("integer(x) == 1", &a));
    }

    #[test]
    fn test_integer_from_bool_false() {
        let a = attrs(&[("x", json!(false))]);
        assert!(evaluate("integer(x) == 0", &a));
    }

    #[test]
    fn test_integer_truncates_toward_zero_positive() {
        let a = attrs(&[("x", json!(3.9))]);
        assert!(evaluate("integer(x) == 3", &a));
    }

    #[test]
    fn test_integer_truncates_toward_zero_negative() {
        let a = attrs(&[("x", json!(-2.1))]);
        assert!(evaluate("integer(x) == -2", &a));
    }

    #[test]
    fn test_integer_null_returns_null() {
        assert!(evaluate("is_null(integer(missing))", &HashMap::new()));
    }

    #[test]
    fn test_number_from_bool() {
        let a = attrs(&[("x", json!(true))]);
        assert!(evaluate("number(x) == 1", &a));
    }

    #[test]
    fn test_number_identity() {
        let a = attrs(&[("x", json!(3.14))]);
        assert!(evaluate("number(x) == 3.14", &a));
    }

    #[test]
    fn test_number_from_invalid_string() {
        let a = attrs(&[("x", json!("hello"))]);
        assert!(evaluate("is_null(number(x))", &a));
    }

    #[test]
    fn test_number_null_returns_null() {
        assert!(evaluate("is_null(number(missing))", &HashMap::new()));
    }

    #[test]
    fn test_string_from_bool() {
        let a = attrs(&[("x", json!(true))]);
        assert!(evaluate("string(x) == 'true'", &a));
    }

    #[test]
    fn test_string_from_integer_number() {
        let a = attrs(&[("x", json!(42))]);
        assert!(evaluate("string(x) == '42'", &a));
    }

    #[test]
    fn test_string_from_float_number() {
        let a = attrs(&[("x", json!(3.14))]);
        assert!(evaluate("string(x) == '3.14'", &a));
    }

    #[test]
    fn test_string_from_array_is_null() {
        let a = attrs(&[("x", json!([1, 2, 3]))]);
        assert!(evaluate("is_null(string(x))", &a));
    }

    #[test]
    fn test_string_from_object_is_null() {
        let a = attrs(&[("x", json!({"a": 1}))]);
        assert!(evaluate("is_null(string(x))", &a));
    }

    #[test]
    fn test_boolean_from_bool_passthrough() {
        let a = attrs(&[("x", json!(true))]);
        assert!(evaluate("boolean(x) == true", &a));
    }

    #[test]
    fn test_boolean_false_passthrough() {
        let a = attrs(&[("x", json!(false))]);
        assert!(evaluate("boolean(x) == false", &a));
    }

    #[test]
    fn test_boolean_null_returns_null() {
        assert!(evaluate("is_null(boolean(missing))", &HashMap::new()));
    }

    // ═══════════════════════════════════════════════════════════════
    // coalesce()
    // ═══════════════════════════════════════════════════════════════

    #[test]
    fn test_coalesce_returns_first_non_null() {
        let a = attrs(&[("x", json!(null)), ("y", json!(42))]);
        assert!(evaluate("coalesce(x, y) == 42", &a));
    }

    #[test]
    fn test_coalesce_all_null() {
        let a = attrs(&[("x", json!(null)), ("y", json!(null))]);
        assert!(evaluate("is_null(coalesce(x, y))", &a));
    }

    #[test]
    fn test_coalesce_first_is_non_null() {
        let a = attrs(&[("x", json!("found")), ("y", json!("other"))]);
        assert!(evaluate("coalesce(x, y) == 'found'", &a));
    }

    #[test]
    fn test_coalesce_zero_is_not_null() {
        // 0 is falsy but not null — coalesce must return it
        let a = attrs(&[("x", json!(0)), ("y", json!(99))]);
        assert!(evaluate("coalesce(x, y) == 0", &a));
    }

    #[test]
    fn test_coalesce_empty_string_is_not_null() {
        let a = attrs(&[("x", json!("")), ("y", json!("fallback"))]);
        assert!(evaluate("coalesce(x, y) == ''", &a));
    }

    #[test]
    fn test_coalesce_three_args() {
        let a = attrs(&[("z", json!(99))]);
        assert!(evaluate("coalesce(missing_a, missing_b, z) == 99", &a));
    }

    #[test]
    fn test_coalesce_short_circuits() {
        // If coalesce short-circuits, the division by zero never executes
        let a = attrs(&[("x", json!(42))]);
        assert!(evaluate("coalesce(x, 1/0) == 42", &a));
    }

    #[test]
    fn test_coalesce_with_default_literal() {
        assert!(evaluate("coalesce(missing, 1000) == 1000", &HashMap::new()));
    }
}

// ═══════════════════════════════════════════════════════════════
// spec-parity tests (LANGUAGE.md §4.7, §5.4, §5.8, §5.9, §5.10, §7)
// ═══════════════════════════════════════════════════════════════

#[cfg(test)]
mod spec_parity_tests {
    use super::*;
    use serde_json::json;
    use std::collections::HashMap;

    fn attrs(pairs: &[(&str, Value)]) -> HashMap<String, Value> {
        pairs
            .iter()
            .map(|(k, v)| (k.to_string(), v.clone()))
            .collect()
    }

    // ── EvalContext::from_attrs round-trip ────────────────────────

    #[test]
    fn test_from_attrs_round_trip_truthy() {
        let a = attrs(&[("x", json!(5))]);
        let ctx = EvalContext::from_attrs(&a);
        assert!(evaluate_with("x > 3", &ctx));
    }

    #[test]
    fn test_from_attrs_no_hooks_means_no_predicates() {
        // Without a PredicateLookup hook, an unknown identifier is null.
        let a = HashMap::new();
        let ctx = EvalContext::from_attrs(&a);
        // `is_priv` is unknown → null → false in boolean context.
        assert!(!evaluate_with("is_priv", &ctx));
    }

    // ── object.entries (LANGUAGE.md §5.4) ─────────────────────────

    #[test]
    fn test_object_entries_count() {
        let a = attrs(&[("perms", json!({"alice": "admin", "bob": "user"}))]);
        assert!(evaluate("count(object.entries(perms)) == 2", &a));
    }

    #[test]
    fn test_object_entries_shape_via_quantifier() {
        let a = attrs(&[("perms", json!({"alice": "admin"}))]);
        // Each entry has both `key` and `value`.
        assert!(evaluate(
            "all(object.entries(perms), e -> has(e, 'key') and has(e, 'value'))",
            &a
        ));
    }

    #[test]
    fn test_object_entries_on_non_object_is_null() {
        let a = attrs(&[("x", json!(42))]);
        assert!(evaluate("is_null(object.entries(x))", &a));
    }

    #[test]
    fn test_object_entries_on_null_is_null() {
        assert!(evaluate(
            "is_null(object.entries(missing))",
            &HashMap::new()
        ));
    }

    // ── Quantifiers: all / any / count_where (LANGUAGE.md §5.8) ───

    #[test]
    fn test_all_truthy_predicate() {
        let a = attrs(&[("emails", json!(["a@x.com", "b@x.com", "c@x.com"]))]);
        assert!(evaluate("all(emails, e -> endswith(e, '@x.com'))", &a));
    }

    #[test]
    fn test_all_with_one_failure() {
        let a = attrs(&[("emails", json!(["a@x.com", "b@y.com"]))]);
        assert!(!evaluate("all(emails, e -> endswith(e, '@x.com'))", &a));
    }

    #[test]
    fn test_any_truthy_predicate() {
        let a = attrs(&[("emails", json!(["a@x.com", "b@y.com"]))]);
        assert!(evaluate("any(emails, e -> endswith(e, '@y.com'))", &a));
    }

    #[test]
    fn test_any_no_match() {
        let a = attrs(&[("emails", json!(["a@x.com", "b@x.com"]))]);
        assert!(!evaluate("any(emails, e -> endswith(e, '@y.com'))", &a));
    }

    #[test]
    fn test_count_where() {
        let a = attrs(&[("nums", json!([1, 2, 3, 4, 5]))]);
        assert!(evaluate("count_where(nums, n -> n > 2) == 3", &a));
    }

    #[test]
    fn test_all_on_empty_array_is_true() {
        let a = attrs(&[("xs", json!([]))]);
        // Vacuous truth.
        assert!(evaluate("all(xs, x -> x > 100)", &a));
    }

    #[test]
    fn test_any_on_empty_array_is_false() {
        let a = attrs(&[("xs", json!([]))]);
        assert!(!evaluate("any(xs, x -> x > 100)", &a));
    }

    #[test]
    fn test_count_where_on_empty_array_is_zero() {
        let a = attrs(&[("xs", json!([]))]);
        assert!(evaluate("count_where(xs, x -> x > 0) == 0", &a));
    }

    #[test]
    fn test_all_on_null_is_false() {
        // Null collection → all() → false (fail-closed).
        assert!(!evaluate("all(missing, x -> true)", &HashMap::new()));
    }

    #[test]
    fn test_any_on_null_is_false() {
        assert!(!evaluate("any(missing, x -> true)", &HashMap::new()));
    }

    #[test]
    fn test_count_where_on_null_is_null() {
        assert!(evaluate(
            "is_null(count_where(missing, x -> true))",
            &HashMap::new()
        ));
    }

    #[test]
    fn test_all_on_non_array_is_false() {
        let a = attrs(&[("x", json!(42))]);
        assert!(!evaluate("all(x, e -> true)", &a));
    }

    #[test]
    fn test_quantifier_short_circuits_all() {
        // Predicate on a value that would error (1/0 → null) — but it's
        // never reached because the first element falsifies.
        let a = attrs(&[("xs", json!([0, 1, 2]))]);
        // First element x=0: x > 0 is false → all() short-circuits to false
        // without evaluating later elements.
        assert!(!evaluate("all(xs, x -> x > 0)", &a));
    }

    #[test]
    fn test_quantifier_bound_var_does_not_leak() {
        // After the macro exits, `e` should be unbound, so `is_null(e)` holds.
        let a = attrs(&[("xs", json!(["a", "b"]))]);
        assert!(evaluate(
            "any(xs, e -> startswith(e, 'a')) and is_null(e)",
            &a
        ));
    }

    #[test]
    fn test_quantifier_var_shadows_session_attr() {
        // A bound var of the same name as a session attribute MUST shadow
        // within the predicate. After the macro, the original wins again.
        let a = attrs(&[("xs", json!([10, 20])), ("e", json!(99))]);
        // Inside predicate: e is the iter element; outside: e == 99.
        assert!(evaluate("any(xs, e -> e > 5) and e == 99", &a));
    }

    #[test]
    fn test_quantifier_with_object_entries() {
        // Spec example.
        let a = attrs(&[("perms", json!({"alice": "admin", "bob": "user"}))]);
        assert!(evaluate(
            "count_where(object.entries(perms), e -> e.value == 'admin') == 1",
            &a
        ));
    }

    #[test]
    fn test_quantifier_name_falls_through_to_function_call() {
        // `all` followed by `(arg)` (no comma + arrow) should be treated as
        // a regular function call. The name has no built-in matching the
        // single-arg form, so it returns null → false.
        // This verifies `all`/`any`/`count_where` are NOT reserved keywords.
        assert!(!evaluate("all(true)", &HashMap::new()));
    }

    // ── Variable status sugar (LANGUAGE.md §5.10) ─────────────────

    #[test]
    fn test_defined_no_hook_present_value() {
        let a = attrs(&[("x", json!("hello"))]);
        assert!(evaluate("defined(x)", &a));
    }

    #[test]
    fn test_defined_no_hook_null_value() {
        let a = attrs(&[("x", json!(null))]);
        assert!(!evaluate("defined(x)", &a));
    }

    #[test]
    fn test_defined_no_hook_missing() {
        assert!(!evaluate("defined(x)", &HashMap::new()));
    }

    #[test]
    fn test_unset_no_hook_missing() {
        assert!(evaluate("unset(x)", &HashMap::new()));
    }

    #[test]
    fn test_unset_no_hook_present() {
        let a = attrs(&[("x", json!(5))]);
        assert!(!evaluate("unset(x)", &a));
    }

    #[test]
    fn test_denied_no_hook_always_false() {
        let a = attrs(&[("x", json!("anything"))]);
        // Without a status hook there's no way to express denial; transitional
        // behavior is to always return false.
        assert!(!evaluate("denied(x)", &a));
    }

    #[test]
    fn test_present_no_hook_empty_string_is_false() {
        let a = attrs(&[("x", json!(""))]);
        assert!(!evaluate("present(x)", &a));
    }

    #[test]
    fn test_present_no_hook_empty_list_is_false() {
        let a = attrs(&[("x", json!([]))]);
        assert!(!evaluate("present(x)", &a));
    }

    #[test]
    fn test_present_no_hook_value_is_true() {
        let a = attrs(&[("x", json!("hello"))]);
        assert!(evaluate("present(x)", &a));
    }

    #[test]
    fn test_status_sugar_rejects_non_ident_arg() {
        // `defined(x.y)` is not a bare ident → false (fail-closed).
        let a = attrs(&[("x", json!({"y": 1}))]);
        assert!(!evaluate("defined(x.y)", &a));
    }

    #[test]
    fn test_status_sugar_with_hook() {
        struct Lookup;
        impl StatusLookup for Lookup {
            fn status(&self, var: &str) -> Option<VariableStatus> {
                match var {
                    "resolved_var" => Some(VariableStatus::Resolved),
                    "denied_var" => Some(VariableStatus::Denied),
                    "unset_var" => Some(VariableStatus::Unset),
                    _ => None,
                }
            }
            fn meta(&self, _var: &str, _field: &str) -> Option<EvalResult> {
                None
            }
        }
        let a = attrs(&[("resolved_var", json!("v"))]);
        let lookup = Lookup;
        let mut ctx = EvalContext::from_attrs(&a);
        ctx.status_lookup = Some(&lookup);

        assert!(evaluate_with("defined(resolved_var)", &ctx));
        assert!(evaluate_with("denied(denied_var)", &ctx));
        assert!(evaluate_with("unset(unset_var)", &ctx));
        // P2.6 / LANGUAGE.md §5.10: undeclared names return `false` for
        // every status sugar function, never `true` for `unset`.
        assert!(!evaluate_with("unset(unknown_var)", &ctx));
        assert!(!evaluate_with("defined(unknown_var)", &ctx));
        assert!(!evaluate_with("denied(unknown_var)", &ctx));
        assert!(!evaluate_with("present(unknown_var)", &ctx));
        assert!(!evaluate_with("denied(resolved_var)", &ctx));
    }

    // ── event.fired (LANGUAGE.md §5.9) ────────────────────────────

    #[test]
    fn test_event_fired_no_hook_returns_false() {
        // Fail-closed without a hook.
        assert!(!evaluate("event.fired('session.start')", &HashMap::new()));
    }

    #[test]
    fn test_event_fired_rejects_non_literal_arg() {
        let a = attrs(&[("eid", json!("session.start"))]);
        // Expression argument is rejected (fail-closed).
        assert!(!evaluate("event.fired(eid)", &a));
    }

    #[test]
    fn test_event_fired_rejects_unknown_namespace() {
        // Outside the closed namespace → false.
        assert!(!evaluate(
            "event.fired('not.a.real.event')",
            &HashMap::new()
        ));
    }

    #[test]
    fn test_event_fired_with_hook() {
        struct Hook;
        impl EventFiredHook for Hook {
            fn fired(&self, event_id: &str) -> bool {
                event_id == "session.start"
            }
        }
        let a = HashMap::new();
        let hook = Hook;
        let mut ctx = EvalContext::from_attrs(&a);
        ctx.event_fired = Some(&hook);

        assert!(evaluate_with("event.fired('session.start')", &ctx));
        assert!(!evaluate_with("event.fired('session.end')", &ctx));
    }

    // ── @-namespace (LANGUAGE.md §4.7) ────────────────────────────

    #[test]
    fn test_meta_status_default_is_unset() {
        // Without a hook, @status defaults to 'unset' (transitional).
        assert!(evaluate("missing.@status == 'unset'", &HashMap::new()));
    }

    #[test]
    fn test_meta_other_fields_default_null() {
        assert!(evaluate("is_null(missing.@set_at)", &HashMap::new()));
    }

    #[test]
    fn test_meta_with_hook() {
        struct Lookup;
        impl StatusLookup for Lookup {
            fn status(&self, _var: &str) -> Option<VariableStatus> {
                Some(VariableStatus::Resolved)
            }
            fn meta(&self, var: &str, field: &str) -> Option<EvalResult> {
                if var == "transfer" && field == "deny_reason" {
                    Some(EvalResult::Str("user_cancel".into()))
                } else if var == "transfer" && field == "status" {
                    Some(EvalResult::Str("denied".into()))
                } else {
                    None
                }
            }
        }
        let a = HashMap::new();
        let lookup = Lookup;
        let mut ctx = EvalContext::from_attrs(&a);
        ctx.status_lookup = Some(&lookup);

        assert!(evaluate_with(
            "transfer.@deny_reason == 'user_cancel'",
            &ctx
        ));
        assert!(evaluate_with("transfer.@status == 'denied'", &ctx));
    }

    #[test]
    fn test_meta_unknown_field_is_null() {
        // Unknown @-fields produce a structured warning + null. Closed set.
        // (Parser allows any ident after @; eval rejects unknowns.)
        let src = "is_null(x.@nonsense)";
        // We can't easily inject a hook with an unknown-field response and
        // also have the dispatch match; the field is rejected before the
        // hook is consulted. Verify the parse succeeds and eval returns null.
        assert!(evaluate(src, &HashMap::new()));
    }

    #[test]
    fn test_meta_namespace_only_on_bare_ident() {
        // The LHS of `.@field` must reduce to a bare identifier. A binary
        // op or function call as LHS is a parse error → `evaluate` returns
        // false (fail-closed).  A trailing `@`-field after a dotted path
        // (`x.y.@status`) is also rejected because the LHS is a
        // `DottedAccess`, not a bare `Ident`.
        assert!(!evaluate("(x + 1).@status == 'unset'", &HashMap::new()));
        assert!(!evaluate("x.y.@status == 'unset'", &HashMap::new()));
        // Sanity: bare-ident form still parses + evaluates.
        assert!(evaluate("x.@status == 'unset'", &HashMap::new()));
    }

    // ── Predicate name resolution (LANGUAGE.md §7, §11.3) ─────────

    struct PredMap<'a>(&'a HashMap<String, String>);
    impl<'a> PredicateLookup for PredMap<'a> {
        fn body(&self, name: &str) -> Option<&str> {
            self.0.get(name).map(|s| s.as_str())
        }
    }

    #[test]
    fn test_predicate_resolution_happy_path() {
        let a = attrs(&[("role", json!("admin"))]);
        let mut preds = HashMap::new();
        preds.insert("is_priv".to_string(), "role == 'admin'".to_string());
        let lookup = PredMap(&preds);
        let mut ctx = EvalContext::from_attrs(&a);
        ctx.predicates = Some(&lookup);

        assert!(evaluate_with("is_priv", &ctx));
    }

    #[test]
    fn test_predicate_used_inside_compound_expr() {
        let a = attrs(&[("role", json!("admin")), ("level", json!(5))]);
        let mut preds = HashMap::new();
        preds.insert("is_priv".to_string(), "role == 'admin'".to_string());
        let lookup = PredMap(&preds);
        let mut ctx = EvalContext::from_attrs(&a);
        ctx.predicates = Some(&lookup);

        assert!(evaluate_with("is_priv and level > 3", &ctx));
        assert!(!evaluate_with("is_priv and level > 10", &ctx));
    }

    #[test]
    fn test_predicate_cycle_returns_null() {
        // A → B → A. The cycle MUST be broken with null/false.
        let a = HashMap::new();
        let mut preds = HashMap::new();
        preds.insert("a".to_string(), "b".to_string());
        preds.insert("b".to_string(), "a".to_string());
        let lookup = PredMap(&preds);
        let mut ctx = EvalContext::from_attrs(&a);
        ctx.predicates = Some(&lookup);

        // Cycle break → null → false.
        assert!(!evaluate_with("a", &ctx));
    }

    #[test]
    fn test_predicate_depth_limit() {
        // Build a chain p0 -> p1 -> p2 -> ... longer than MAX_PREDICATE_DEPTH.
        let a = HashMap::new();
        let mut preds: HashMap<String, String> = HashMap::new();
        for i in 0..(MAX_PREDICATE_DEPTH + 2) {
            preds.insert(format!("p{}", i), format!("p{}", i + 1));
        }
        // Final one terminates with a literal true.
        preds.insert(format!("p{}", MAX_PREDICATE_DEPTH + 2), "true".to_string());
        let lookup = PredMap(&preds);
        let mut ctx = EvalContext::from_attrs(&a);
        ctx.predicates = Some(&lookup);

        // Depth limit kicks in → null/false rather than recursing forever.
        assert!(!evaluate_with("p0", &ctx));
    }

    #[test]
    fn test_predicate_local_binding_does_not_leak_into_body() {
        // Caller declares `x := 10`, predicate body refers to `x` — the
        // body MUST run in a fresh scope, so `x` resolves to null/false.
        let a = HashMap::new();
        let mut preds = HashMap::new();
        preds.insert("uses_x".to_string(), "x == 10".to_string());
        let lookup = PredMap(&preds);
        let mut ctx = EvalContext::from_attrs(&a);
        ctx.predicates = Some(&lookup);

        // Local binding should NOT propagate into predicate body.
        assert!(!evaluate_with("x := 10; uses_x", &ctx));
    }

    #[test]
    fn test_session_var_takes_priority_over_predicate() {
        // If a name exists in attrs, predicate lookup MUST be skipped.
        let a = attrs(&[("name", json!("admin"))]);
        let mut preds = HashMap::new();
        preds.insert("name".to_string(), "false".to_string());
        let lookup = PredMap(&preds);
        let mut ctx = EvalContext::from_attrs(&a);
        ctx.predicates = Some(&lookup);

        // Session var "admin" wins over predicate body "false".
        assert!(evaluate_with("name == 'admin'", &ctx));
    }

    // ── Auto-resolution gating-site behavior ──────────────────────

    #[test]
    fn test_resolver_hook_fires_only_at_gating_site() {
        struct Resolver;
        impl ResolverHook for Resolver {
            fn resolve(&self, var: &str) -> Option<Value> {
                if var == "x" {
                    Some(json!(42))
                } else {
                    None
                }
            }
        }
        let a = HashMap::new();
        let resolver = Resolver;

        // Non-gating site: resolver is NOT called → x is null → false.
        let mut non_gating = EvalContext::from_attrs(&a);
        non_gating.resolver_hook = Some(&resolver);
        assert!(!non_gating.is_gating_site);
        assert!(!evaluate_with("x == 42", &non_gating));

        // Gating site: resolver IS called → x resolves to 42.
        let mut gating = EvalContext::from_attrs(&a);
        gating.resolver_hook = Some(&resolver);
        gating.is_gating_site = true;
        assert!(evaluate_with("x == 42", &gating));
    }

    #[test]
    fn test_resolver_hook_skips_scope_namespaces() {
        struct Resolver;
        impl ResolverHook for Resolver {
            fn resolve(&self, _var: &str) -> Option<Value> {
                // If this fired, the test would falsely pass below.
                Some(json!({"name": "evil"}))
            }
        }
        let a = HashMap::new();
        let resolver = Resolver;
        let mut ctx = EvalContext::from_attrs(&a);
        ctx.is_gating_site = true;
        ctx.resolver_hook = Some(&resolver);

        // `@tool.*` MUST NOT auto-resolve, so tool stays null.
        assert!(!evaluate_with("@tool.name == 'evil'", &ctx));
    }

    #[test]
    fn test_resolver_hook_does_not_fire_in_quantifier_bound_var() {
        // The quantifier-bound variable shadows attrs and goes through
        // bindings. A read of the bound var MUST NOT reach the resolver.
        struct Resolver;
        impl ResolverHook for Resolver {
            fn resolve(&self, _var: &str) -> Option<Value> {
                Some(json!("HIJACKED"))
            }
        }
        let a = attrs(&[("xs", json!([1, 2, 3]))]);
        let resolver = Resolver;
        let mut ctx = EvalContext::from_attrs(&a);
        ctx.is_gating_site = true;
        ctx.resolver_hook = Some(&resolver);

        // `e` is the bound var; predicate uses it directly.
        assert!(evaluate_with("any(xs, e -> e == 2)", &ctx));
    }

    #[test]
    fn test_resolver_hook_does_not_replace_present_value() {
        struct Resolver;
        impl ResolverHook for Resolver {
            fn resolve(&self, _var: &str) -> Option<Value> {
                Some(json!("RESOLVED"))
            }
        }
        let a = attrs(&[("x", json!("preset"))]);
        let resolver = Resolver;
        let mut ctx = EvalContext::from_attrs(&a);
        ctx.is_gating_site = true;
        ctx.resolver_hook = Some(&resolver);

        // x already has a non-null value → resolver MUST NOT fire.
        assert!(evaluate_with("x == 'preset'", &ctx));
    }

    // ─── Review-amendment tests (P2.1 — P2.6) ─────────────────────

    /// P2.1: each variable resolves at most once per evaluate_with call.
    #[test]
    fn p2_1_resolver_called_once_per_evaluation() {
        use std::cell::Cell;
        struct CountingResolver {
            calls: Cell<u32>,
        }
        impl ResolverHook for CountingResolver {
            fn resolve(&self, _var: &str) -> Option<Value> {
                self.calls.set(self.calls.get() + 1);
                Some(json!(1))
            }
        }
        let a: HashMap<String, Value> = HashMap::new();
        let resolver = CountingResolver {
            calls: Cell::new(0),
        };
        let mut ctx = EvalContext::from_attrs(&a);
        ctx.is_gating_site = true;
        ctx.resolver_hook = Some(&resolver);

        // x is read three times; resolver MUST run once.
        let _ = evaluate_with("x == 1 or x == 2 or x == 3", &ctx);
        assert_eq!(resolver.calls.get(), 1);

        // A second evaluate_with call resets the cache.
        let _ = evaluate_with("x == 1", &ctx);
        assert_eq!(resolver.calls.get(), 2);
    }

    /// P2.1: a denied/cancelled resolution is also memoized.
    #[test]
    fn p2_1_denied_resolution_is_memoized() {
        use std::cell::Cell;
        struct DenyingResolver {
            calls: Cell<u32>,
        }
        impl ResolverHook for DenyingResolver {
            fn resolve(&self, _var: &str) -> Option<Value> {
                self.calls.set(self.calls.get() + 1);
                None
            }
        }
        let a: HashMap<String, Value> = HashMap::new();
        let resolver = DenyingResolver {
            calls: Cell::new(0),
        };
        let mut ctx = EvalContext::from_attrs(&a);
        ctx.is_gating_site = true;
        ctx.resolver_hook = Some(&resolver);

        let _ = evaluate_with("x == 1 or x == 2", &ctx);
        assert_eq!(resolver.calls.get(), 1);
    }

    /// P2.2: predicate boundary returns `false` for non-boolean final values.
    #[test]
    fn p2_2_boundary_strict_truthiness() {
        let a: HashMap<String, Value> = HashMap::new();
        // String, number, list: all collapse to false at the boundary.
        assert!(!evaluate("'allow'", &a));
        assert!(!evaluate("42", &a));
        assert!(!evaluate("[1]", &a));
        // Booleans pass through.
        assert!(evaluate("true", &a));
        assert!(!evaluate("false", &a));
        assert!(!evaluate("null", &a));
        // Comparisons produce Bool.
        assert!(evaluate("1 == 1", &a));
        // `or` and `and` are coerced to Bool internally so they still pass
        // through truthy as Bool(true) at the boundary; this is consistent
        // with §3.6 since the operator's output IS a boolean.
        assert!(evaluate("0 or 5", &a));
    }

    /// P2.3: with a StatusLookup, a resolver MUST NOT fire when
    /// `@status == 'resolved'` even if the value is null.
    #[test]
    fn p2_3_resolver_skipped_when_status_resolved() {
        use std::cell::Cell;
        struct CountingResolver {
            calls: Cell<u32>,
        }
        impl ResolverHook for CountingResolver {
            fn resolve(&self, _var: &str) -> Option<Value> {
                self.calls.set(self.calls.get() + 1);
                Some(json!("HOOK"))
            }
        }
        struct ResolvedLookup;
        impl StatusLookup for ResolvedLookup {
            fn status(&self, _var: &str) -> Option<VariableStatus> {
                Some(VariableStatus::Resolved)
            }
            fn meta(&self, _var: &str, _field: &str) -> Option<EvalResult> {
                None
            }
        }
        // x is null but @status == resolved.
        let a = attrs(&[("x", Value::Null)]);
        let resolver = CountingResolver {
            calls: Cell::new(0),
        };
        let lookup = ResolvedLookup;
        let mut ctx = EvalContext::from_attrs(&a);
        ctx.is_gating_site = true;
        ctx.resolver_hook = Some(&resolver);
        ctx.status_lookup = Some(&lookup);

        let _ = evaluate_with("x == 1", &ctx);
        assert_eq!(
            resolver.calls.get(),
            0,
            "resolver fired despite resolved status"
        );
    }

    /// P2.3: denied status also blocks the resolver.
    #[test]
    fn p2_3_resolver_skipped_when_status_denied() {
        use std::cell::Cell;
        struct CountingResolver {
            calls: Cell<u32>,
        }
        impl ResolverHook for CountingResolver {
            fn resolve(&self, _var: &str) -> Option<Value> {
                self.calls.set(self.calls.get() + 1);
                Some(json!("HOOK"))
            }
        }
        struct DeniedLookup;
        impl StatusLookup for DeniedLookup {
            fn status(&self, _var: &str) -> Option<VariableStatus> {
                Some(VariableStatus::Denied)
            }
            fn meta(&self, _var: &str, _field: &str) -> Option<EvalResult> {
                None
            }
        }
        let a: HashMap<String, Value> = HashMap::new();
        let resolver = CountingResolver {
            calls: Cell::new(0),
        };
        let lookup = DeniedLookup;
        let mut ctx = EvalContext::from_attrs(&a);
        ctx.is_gating_site = true;
        ctx.resolver_hook = Some(&resolver);
        ctx.status_lookup = Some(&lookup);

        let _ = evaluate_with("x == 1", &ctx);
        assert_eq!(resolver.calls.get(), 0);
    }

    /// P2.4: `:=` bindings inside a quantifier predicate don't leak out.
    #[test]
    fn p2_4_quantifier_local_bindings_do_not_leak() {
        let a = attrs(&[("xs", json!([1, 2, 3]))]);
        // `y` is bound only inside the predicate; outer `y` is undefined.
        // any() returns true (some element matched after binding `y`),
        // outer `y == 1` is `null == 1` → false at boundary.
        assert!(!evaluate("any(xs, x -> y := x; true) and y == 1", &a));
    }

    /// P2.4: predicate with `:=` plus body works without state pollution.
    #[test]
    fn p2_4_quantifier_local_bindings_work_inside_predicate() {
        let a = attrs(&[("xs", json!([1, 2, 3]))]);
        assert!(evaluate("any(xs, x -> y := x; y == 2)", &a));
    }

    /// P2.5: a predicate body that evaluates to a non-boolean string is
    /// coerced to `false` at the predicate-reference boundary (§7).
    #[test]
    fn p2_5_predicate_body_non_boolean_collapses_to_false() {
        struct Pred;
        impl PredicateLookup for Pred {
            fn body(&self, name: &str) -> Option<&str> {
                match name {
                    "is_priv" => Some("'yes'"),
                    _ => None,
                }
            }
        }
        let a: HashMap<String, Value> = HashMap::new();
        let pred = Pred;
        let mut ctx = EvalContext::from_attrs(&a);
        ctx.predicates = Some(&pred);
        // `is_priv` body is the string `'yes'` — non-boolean → false.
        assert!(!evaluate_with("is_priv", &ctx));
        assert!(!evaluate_with("is_priv and true", &ctx));
    }

    /// P2.5: predicate cycle returns `false`, not `null`.
    #[test]
    fn p2_5_predicate_cycle_collapses_to_false() {
        struct Pred;
        impl PredicateLookup for Pred {
            fn body(&self, name: &str) -> Option<&str> {
                match name {
                    "a" => Some("b"),
                    "b" => Some("a"),
                    _ => None,
                }
            }
        }
        let a: HashMap<String, Value> = HashMap::new();
        let pred = Pred;
        let mut ctx = EvalContext::from_attrs(&a);
        ctx.predicates = Some(&pred);
        assert!(!evaluate_with("a", &ctx));
    }

    /// P2.6: with a StatusLookup that knows only `x`, undeclared names
    /// return `false` for every sugar function.
    #[test]
    fn p2_6_undeclared_variable_status_returns_false() {
        struct Lookup;
        impl StatusLookup for Lookup {
            fn status(&self, var: &str) -> Option<VariableStatus> {
                match var {
                    "x" => Some(VariableStatus::Unset),
                    _ => None,
                }
            }
            fn meta(&self, _var: &str, _field: &str) -> Option<EvalResult> {
                None
            }
        }
        let a: HashMap<String, Value> = HashMap::new();
        let lookup = Lookup;
        let mut ctx = EvalContext::from_attrs(&a);
        ctx.status_lookup = Some(&lookup);

        // declared x: unset is true.
        assert!(evaluate_with("unset(x)", &ctx));
        // undeclared `typo`: every sugar fn is false.
        assert!(!evaluate_with("unset(typo)", &ctx));
        assert!(!evaluate_with("defined(typo)", &ctx));
        assert!(!evaluate_with("denied(typo)", &ctx));
        assert!(!evaluate_with("present(typo)", &ctx));
    }

    // ── P5.4: evaluate_to_value clears resolved_cache ────────────

    struct CountingHook {
        calls: std::cell::RefCell<usize>,
    }

    impl ResolverHook for CountingHook {
        fn resolve(&self, _var: &str) -> Option<Value> {
            *self.calls.borrow_mut() += 1;
            Some(json!(7))
        }
    }

    #[test]
    fn evaluate_to_value_clears_resolver_cache_between_calls() {
        // A reused EvalContext must NOT carry resolver-hook results across
        // top-level evaluate_to_value() invocations — mirrors evaluate_with's
        // behavior (LANGUAGE.md §11.4).
        let a = HashMap::new();
        let hook = CountingHook {
            calls: std::cell::RefCell::new(0),
        };
        let mut ctx = EvalContext::from_attrs(&a);
        ctx.is_gating_site = true;
        ctx.resolver_hook = Some(&hook);

        let v1 = evaluate_to_value("y", &ctx);
        assert_eq!(v1, Some(json!(7)));
        assert_eq!(*hook.calls.borrow(), 1);

        // Second call MUST clear the cache and re-invoke the hook.
        let v2 = evaluate_to_value("y", &ctx);
        assert_eq!(v2, Some(json!(7)));
        assert_eq!(
            *hook.calls.borrow(),
            2,
            "evaluate_to_value must clear resolved_cache between calls"
        );
    }
}
