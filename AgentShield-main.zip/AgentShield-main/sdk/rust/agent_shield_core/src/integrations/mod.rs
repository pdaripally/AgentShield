//! Shared runtime building blocks for framework integrations.
//!
//! Sub-modules here are reused by host-language hook integrations so
//! the integration-layer state machinery (session cache, request
//! lifecycle, lease counter, turn lifecycle, scratch K/V) has one
//! canonical implementation rather than being rebuilt per host.

pub mod hooks;
