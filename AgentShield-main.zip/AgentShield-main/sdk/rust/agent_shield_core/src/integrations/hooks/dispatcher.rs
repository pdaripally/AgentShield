//! [`StageDispatcher`] — composes
//! [`crate::GuardrailsSession::validate_*`] with the canonical
//! [`crate::shield_primitives::dispatch_stage_verdict`] and
//! [`crate::shield_primitives::dispatch_tool_verdict`] to produce
//! fully-decided stage results.
//!
//! The dispatcher is a thin façade over the existing core types — no
//! new policy logic lives here. Each stage method returns a wrapper
//! struct that pairs the canonical
//! [`crate::shield_primitives::VerdictDispatch`] /
//! [`crate::shield_primitives::ToolVerdictDispatch`] with the
//! post-mutation effective payload (Stage 3 `effective_params`,
//! Stage 4 `effective_output`). Stage 1 and Stage 5 carry only the
//! dispatch because their mutation is reflected in
//! [`crate::shield_primitives::DispatchAction::ProceedWithMutation`].

use serde_json::Value;

use crate::shield_primitives::{
    dispatch_stage_verdict, dispatch_tool_verdict, OnBlockPolicy, ShieldMode, ToolStage,
    ToolVerdictDispatch, VerdictDispatch,
};

use super::session::HookSession;

/// Stateless façade. Cheap to construct. Hosts typically build one
/// `StageDispatcher` per process and reuse it across hook callbacks.
#[derive(Default, Clone, Copy)]
pub struct StageDispatcher;

/// Stage 1 result.
#[derive(Debug, Clone)]
pub struct InputStageResult {
    /// Canonical verdict-handling decision.
    pub dispatch: VerdictDispatch,
}

/// Stage 5 result.
#[derive(Debug, Clone)]
pub struct OutputStageResult {
    /// Canonical verdict-handling decision. Stage 5 mutation is
    /// reflected here via
    /// [`crate::shield_primitives::DispatchAction::ProceedWithMutation`].
    pub dispatch: VerdictDispatch,
}

/// Stage 2 + 3 result.
#[derive(Debug, Clone)]
pub struct ToolCallStageResult {
    /// Canonical tool-verdict-handling decision.
    pub dispatch: ToolVerdictDispatch,
    /// Post-Stage-3 effective params. Equal to the input on
    /// no-mutation paths. Integrations apply this whenever
    /// `effective_params != input` (e.g., GHCP `modifiedArgs`,
    /// LiteLLM `function.arguments` rewrite), independent of
    /// `dispatch.action`.
    pub effective_params: Value,
}

/// Stage 4 result.
#[derive(Debug, Clone)]
pub struct ToolOutputStageResult {
    /// Canonical tool-verdict-handling decision.
    pub dispatch: ToolVerdictDispatch,
    /// Post-Stage-4 effective output. Equal to the input on
    /// no-mutation paths. Integrations with structured tool-result
    /// envelopes (GHCP `ToolResultObject`, OpenClaw `event.result`)
    /// apply this whenever `effective_output != input`. LiteLLM
    /// (flat string `role=tool.content`) can read the flat string
    /// view from `dispatch.action` as well.
    pub effective_output: Value,
}

impl StageDispatcher {
    /// Stage 1: validate user input. Returns a fully-decided
    /// [`InputStageResult`] composing the verdict + `policy` + `mode`
    /// via [`dispatch_stage_verdict`].
    pub fn validate_input(
        &self,
        sess: &HookSession,
        user_input: &str,
        mode: ShieldMode,
        policy: OnBlockPolicy,
    ) -> InputStageResult {
        let verdict = sess.session().validate_input(user_input);
        let dispatch = dispatch_stage_verdict(&verdict, policy, mode);
        InputStageResult { dispatch }
    }

    /// Stage 2 + 3: validate a tool call. Returns a
    /// [`ToolCallStageResult`] composing the verdict + `mode` via
    /// [`dispatch_tool_verdict`] with `ToolStage::Call`, plus the
    /// post-Stage-3 effective params.
    ///
    /// `params` is consumed and returned (possibly mutated) on the
    /// wrapper. `tool_call_id` is the §16.0 binding handle.
    pub fn validate_tool_call(
        &self,
        sess: &HookSession,
        tool_name: &str,
        mut params: Value,
        tool_call_id: &str,
        mode: ShieldMode,
        policy: OnBlockPolicy,
    ) -> ToolCallStageResult {
        let verdict = sess
            .session()
            .validate_tool_call(tool_name, &mut params, tool_call_id);
        let dispatch = dispatch_tool_verdict(&verdict, tool_name, ToolStage::Call, policy, mode);
        ToolCallStageResult {
            dispatch,
            effective_params: params,
        }
    }

    /// Stage 4: validate a tool output. Returns a
    /// [`ToolOutputStageResult`] composing the verdict + `mode` via
    /// [`dispatch_tool_verdict`] with `ToolStage::Output`, plus the
    /// post-Stage-4 effective output.
    ///
    /// `result` is consumed and returned (possibly mutated) on the
    /// wrapper. Structured envelopes survive intact — core's
    /// [`crate::GuardrailsSession::validate_tool_output`] already
    /// accepts `&mut Value`.
    pub fn validate_tool_output(
        &self,
        sess: &HookSession,
        tool_name: &str,
        mut result: Value,
        tool_call_id: &str,
        mode: ShieldMode,
        policy: OnBlockPolicy,
    ) -> ToolOutputStageResult {
        let verdict = sess
            .session()
            .validate_tool_output(tool_name, &mut result, tool_call_id);
        let dispatch = dispatch_tool_verdict(&verdict, tool_name, ToolStage::Output, policy, mode);
        ToolOutputStageResult {
            dispatch,
            effective_output: result,
        }
    }

    /// Stage 5: validate the assistant's final output. `content` is
    /// mutated in-place by core if the verdict applies a transform;
    /// callers should pass an owned mutable string and read it back
    /// when `dispatch.action` is
    /// [`crate::shield_primitives::DispatchAction::ProceedWithMutation`].
    pub fn validate_output(
        &self,
        sess: &HookSession,
        content: &mut String,
        mode: ShieldMode,
        policy: OnBlockPolicy,
    ) -> OutputStageResult {
        let verdict = sess.session().validate_output(content);
        let dispatch = dispatch_stage_verdict(&verdict, policy, mode);
        OutputStageResult { dispatch }
    }
}
