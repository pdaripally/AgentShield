//! [`HookSession`] — per-session lifecycle bookkeeping wrapping a
//! shared [`GuardrailsSession`].

use std::sync::atomic::AtomicUsize;
use std::sync::{Arc, Mutex};
use std::time::Instant;

use serde_json::Value;

use crate::runtime::{GuardrailsSession, RuntimeError};

/// Opaque, stashable token identifying an in-flight request.
///
/// Issued by [`HookSession::begin_request`], retired by
/// [`HookSession::end_request`]. Tokens are session-scoped and stale
/// tokens are invalidated via the registry's `in_flight_timeout`.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct RequestToken(pub u64);

/// Errors returned by [`HookSession::end_request`]. Both variants are
/// safe to log-and-continue (the failure-hook double-close path
/// relies on `NoRequestOpen` being non-fatal).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RequestStateError {
    /// Token does not match the currently-open request (already
    /// retired, never issued, or superseded after stale-token
    /// invalidation).
    Mismatch,
    /// No request was open when `end_request` was called.
    NoRequestOpen,
}

#[derive(Debug, Default)]
struct TurnState {
    /// Adapter scratch, cleared on `begin_turn` / `restart_turn`.
    /// Turn open/closed status is read directly from the underlying
    /// `GuardrailsSession::is_turn_active()` so callers that drive
    /// turn lifecycle through either the wrapper or the underlying
    /// session see consistent state.
    kv: std::collections::HashMap<String, Value>,
}

#[derive(Debug, Default)]
struct RequestState {
    current: Option<RequestToken>,
    started_at: Option<Instant>,
    /// Monotonic per-session token counter.
    next_token: u64,
}

/// Per-session state owned by [`super::SessionRegistry`].
///
/// Wraps one [`GuardrailsSession`] with state that must survive
/// across host hook callbacks: turn lifecycle, request token,
/// scratch K/V. The lease counter (`active_holders`) is bumped by
/// [`super::SessionRegistry::acquire`] and decremented on lease drop
/// so eviction can't free an entry that's about to be used.
///
/// Async serialisation of concurrent callbacks for the same session
/// id is the host's responsibility; the internal `std::sync::Mutex`
/// over `turn_state` / `request_state` makes the type itself
/// thread-safe for the data it owns.
pub struct HookSession {
    session: Arc<GuardrailsSession>,
    turn_state: Mutex<TurnState>,
    request_state: Mutex<RequestState>,
    pub(crate) active_holders: AtomicUsize,
    pub(crate) last_used_at: Mutex<Instant>,
}

impl HookSession {
    /// Construct from an existing [`GuardrailsSession`].
    /// [`super::SessionRegistry`] is the normal entry point.
    pub fn new(session: Arc<GuardrailsSession>) -> Self {
        Self {
            session,
            turn_state: Mutex::new(TurnState::default()),
            request_state: Mutex::new(RequestState::default()),
            active_holders: AtomicUsize::new(0),
            last_used_at: Mutex::new(Instant::now()),
        }
    }

    /// Borrow the underlying session. [`super::StageDispatcher`] is
    /// the normal way to drive stage validation; this accessor is
    /// for hosts that need direct access.
    pub fn session(&self) -> &Arc<GuardrailsSession> {
        &self.session
    }

    // ── Turn lifecycle ─────────────────────────────────────────

    /// Open a turn. Idempotent: a no-op if a turn is already open
    /// on the underlying session. Use [`Self::restart_turn`] to
    /// close-and-reopen.
    pub fn begin_turn(&self) -> Result<(), RuntimeError> {
        let mut state = self.turn_state.lock().expect("turn_state poisoned");
        if self.session.is_turn_active() {
            return Ok(());
        }
        self.session.begin_turn()?;
        state.kv.clear();
        Ok(())
    }

    /// Close any open turn and open a fresh one.
    pub fn restart_turn(&self) -> Result<(), RuntimeError> {
        let mut state = self.turn_state.lock().expect("turn_state poisoned");
        if self.session.is_turn_active() {
            self.session.end_turn()?;
        }
        self.session.begin_turn()?;
        state.kv.clear();
        Ok(())
    }

    /// Close the current turn. No-op if no turn is open.
    pub fn end_turn(&self) -> Result<(), RuntimeError> {
        let mut state = self.turn_state.lock().expect("turn_state poisoned");
        if !self.session.is_turn_active() {
            return Ok(());
        }
        self.session.end_turn()?;
        // Scratch is per-turn.
        state.kv.clear();
        Ok(())
    }

    /// `true` while a turn is open on the underlying session.
    pub fn turn_is_open(&self) -> bool {
        self.session.is_turn_active()
    }

    // ── Scratch K/V (turn-scoped) ──────────────────────────────

    /// Store `value` under `key`. Returns the previous value if
    /// `key` was already set. Returns `None` and stores nothing if
    /// no turn is open (the K/V is turn-scoped).
    pub fn turn_kv_set(&self, key: &str, value: Value) -> Option<Value> {
        let mut state = self.turn_state.lock().expect("turn_state poisoned");
        if !self.session.is_turn_active() {
            return None;
        }
        state.kv.insert(key.to_string(), value)
    }

    /// Read a scratch value. Returns `None` if not set.
    pub fn turn_kv_get(&self, key: &str) -> Option<Value> {
        let state = self.turn_state.lock().expect("turn_state poisoned");
        state.kv.get(key).cloned()
    }

    /// Remove a scratch value. Returns the removed value if any.
    pub fn turn_kv_remove(&self, key: &str) -> Option<Value> {
        let mut state = self.turn_state.lock().expect("turn_state poisoned");
        state.kv.remove(key)
    }

    /// Snapshot the keys currently in scratch.
    pub fn turn_kv_keys(&self) -> Vec<String> {
        let state = self.turn_state.lock().expect("turn_state poisoned");
        state.kv.keys().cloned().collect()
    }

    // ── Request lifecycle ──────────────────────────────────────

    /// Open a new request scope. Returns a [`RequestToken`] the
    /// caller MUST present to [`Self::end_request`] when the logical
    /// request completes (across however many hook callbacks).
    ///
    /// `in_flight_timeout`: when `Some(duration)` and the prior
    /// request has been open longer than `duration`, the prior token
    /// is invalidated and a fresh one is minted. `None` enforces
    /// strict one-request-at-a-time with no stale recovery.
    ///
    /// Calls [`GuardrailsSession::begin_request`] so spec
    /// `per_request` lifetimes reset.
    pub fn begin_request(
        &self,
        in_flight_timeout: Option<std::time::Duration>,
    ) -> Result<RequestToken, ConcurrencyError> {
        let mut state = self.request_state.lock().expect("request_state poisoned");

        if let Some(current) = state.current {
            let age = state
                .started_at
                .map(|t| t.elapsed())
                .unwrap_or_else(|| std::time::Duration::from_secs(0));
            match in_flight_timeout {
                Some(timeout) if age >= timeout => {
                    // Stale: invalidate the prior token and proceed.
                    // Best-effort close so per_request state doesn't
                    // accumulate.
                    let _ = self.session.end_request();
                    let _ = current;
                }
                _ => return Err(ConcurrencyError::AlreadyInFlight { age }),
            }
        }

        if let Err(e) = self.session.begin_request() {
            return Err(ConcurrencyError::SessionError(format!(
                "GuardrailsSession::begin_request failed: {e}"
            )));
        }

        state.next_token = state.next_token.wrapping_add(1);
        let token = RequestToken(state.next_token);
        state.current = Some(token);
        state.started_at = Some(Instant::now());
        Ok(token)
    }

    /// Retire a request token. See [`RequestStateError`] for the
    /// log-and-continue error variants.
    pub fn end_request(&self, token: RequestToken) -> Result<(), RequestStateError> {
        let mut state = self.request_state.lock().expect("request_state poisoned");
        match state.current {
            None => Err(RequestStateError::NoRequestOpen),
            Some(current) if current != token => Err(RequestStateError::Mismatch),
            Some(_) => {
                let _ = self.session.end_request();
                state.current = None;
                state.started_at = None;
                Ok(())
            }
        }
    }

    /// Retire whatever request is currently open without needing the
    /// token. Convenience for hosts that don't want to plumb the
    /// token across hook invocations. Returns
    /// [`RequestStateError::NoRequestOpen`] when no request is open
    /// (safe to log-and-continue).
    pub fn end_current_request(&self) -> Result<(), RequestStateError> {
        let mut state = self.request_state.lock().expect("request_state poisoned");
        match state.current {
            None => Err(RequestStateError::NoRequestOpen),
            Some(_) => {
                let _ = self.session.end_request();
                state.current = None;
                state.started_at = None;
                Ok(())
            }
        }
    }

    /// `true` while a request is open.
    pub fn request_is_open(&self) -> bool {
        self.request_state
            .lock()
            .expect("request_state poisoned")
            .current
            .is_some()
    }

    /// Age of the currently-open request, if any.
    pub fn request_age(&self) -> Option<std::time::Duration> {
        self.request_state
            .lock()
            .expect("request_state poisoned")
            .started_at
            .map(|t| t.elapsed())
    }

    // ── Resource-cycle pass-throughs ───────────────────────────

    /// Record successful tool execution per §10 resource cycle. The
    /// caller decides when execution actually succeeded; core cannot
    /// infer this from a policy verdict.
    pub fn record_tool_success(&self, tool_name: &str, result: &Value) -> Result<(), RuntimeError> {
        self.session.record_tool_success(tool_name, result)
    }

    /// Record failed tool execution per §10 resource cycle.
    pub fn record_tool_failure(&self, tool_name: &str, error: &str) -> Result<(), RuntimeError> {
        self.session.record_tool_failure(tool_name, error)
    }
}

/// Returned by [`HookSession::begin_request`] when a prior request is
/// in flight or the underlying session call fails.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ConcurrencyError {
    /// Another request is in flight and not yet stale. Integrations
    /// typically surface this as HTTP 409.
    AlreadyInFlight {
        /// How long the existing request has been open.
        age: std::time::Duration,
    },
    /// The underlying [`GuardrailsSession::begin_request`] failed.
    SessionError(String),
}

impl std::fmt::Display for ConcurrencyError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::AlreadyInFlight { age } => {
                write!(f, "another request is in flight (age={:?})", age)
            }
            Self::SessionError(msg) => write!(f, "session error: {msg}"),
        }
    }
}

impl std::error::Error for ConcurrencyError {}
