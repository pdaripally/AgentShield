//! Hook integration runtime: shared state machinery for host
//! integrations that expose pre/post hook surfaces.
//!
//! ## Public surface
//!
//! - [`SessionRegistry`] — bounded LRU of [`HookSession`]s with
//!   lease-aware eviction. Hosts call [`SessionRegistry::acquire`]
//!   once per hook callback and drop the returned [`SessionLease`]
//!   when done.
//! - [`HookSession`] — wraps a [`crate::GuardrailsSession`] with
//!   turn / request lifecycle, opaque [`RequestToken`] for cross-hook
//!   request scope, scratch K/V for adapter correlation state, and
//!   resource-cycle bookkeeping passthroughs.
//! - [`StageDispatcher`] — composes
//!   [`crate::GuardrailsSession::validate_*`] with
//!   [`crate::shield_primitives::dispatch_stage_verdict`] /
//!   [`crate::shield_primitives::dispatch_tool_verdict`] and returns
//!   stage-result wrappers carrying the dispatch decision plus the
//!   post-mutation effective payload.
//!
//! ## Out of scope
//!
//! Async serialisation of concurrent hook callbacks for the same
//! session id is the host's responsibility (e.g., `asyncio.Lock`
//! per session id in Python; Node's single-threaded event loop is
//! sufficient on its own). The eviction-protection lease counter is
//! the only synchronisation primitive owned here.

pub mod dispatcher;
pub mod registry;
pub mod session;

pub use dispatcher::{
    InputStageResult, OutputStageResult, StageDispatcher, ToolCallStageResult,
    ToolOutputStageResult,
};
pub use registry::{RegistryOptions, SessionLease, SessionRegistry, SessionRegistryError};
pub use session::{ConcurrencyError, HookSession, RequestStateError, RequestToken};
