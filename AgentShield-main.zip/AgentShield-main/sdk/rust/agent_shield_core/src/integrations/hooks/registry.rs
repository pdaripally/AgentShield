//! [`SessionRegistry`] — bounded LRU of [`HookSession`]s with
//! lease-aware eviction.
//!
//! One registry per host process. Hosts call
//! [`SessionRegistry::acquire`] once per hook callback to take a
//! [`SessionLease`] over the session keyed by `session_id`. The lease
//! bumps a counter so eviction can't reclaim the entry while in use;
//! dropping the lease decrements the counter and updates
//! `last_used_at`.
//!
//! ## What this does NOT do
//!
//! - Serialise concurrent hook callbacks for the same session id.
//!   Async serialization is a host-runtime concern (Python
//!   `asyncio.Lock`, Node single-threaded event loop); integrations
//!   that need it MUST add their own host-language lock around
//!   `acquire`. The registry itself is safe under concurrent acquire
//!   thanks to interior `std::sync::Mutex` over its state.
//!
//! ## Eviction rules
//!
//! When at capacity, [`SessionRegistry::acquire`] evicts the
//! least-recently-used entry subject to these constraints (in order):
//!
//! 1. The entry's lease counter (`active_holders`) must be zero —
//!    otherwise some other caller is currently using it.
//! 2. The entry must not be the one this `acquire` call just
//!    inserted (would evict the entry the caller is about to use).
//!
//! If no entry is evictable, the registry briefly exceeds capacity
//! and emits a warning log rather than corrupting state.

use std::collections::HashMap;
use std::sync::atomic::Ordering;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use crate::runtime::{GuardrailsRuntime, RequestContext, RuntimeError};

use super::session::HookSession;

/// Tuning knobs for [`SessionRegistry`].
#[derive(Debug, Clone)]
pub struct RegistryOptions {
    /// Maximum number of sessions cached simultaneously. Once
    /// exceeded, LRU eviction reclaims an entry (subject to the
    /// constraints in the module docs). Default 512.
    pub max_size: usize,
    /// Idle TTL. An entry whose `last_used_at` is older than `ttl` is
    /// eligible for eviction on the next [`SessionRegistry::acquire`]
    /// regardless of LRU order. Zero disables TTL eviction. Default
    /// 30 min.
    pub ttl: Duration,
    /// In-flight request timeout. Passed through to
    /// [`HookSession::begin_request`] for stale-token recovery
    /// (proxy crash leaves a request hanging). Default 5 min.
    pub in_flight_timeout: Duration,
}

impl Default for RegistryOptions {
    fn default() -> Self {
        Self {
            max_size: 512,
            ttl: Duration::from_secs(30 * 60),
            in_flight_timeout: Duration::from_secs(5 * 60),
        }
    }
}

/// Errors from [`SessionRegistry::acquire`].
#[derive(Debug)]
pub enum SessionRegistryError {
    /// Underlying [`GuardrailsRuntime::new_session`] failed (e.g.,
    /// missing host hook on a configuration that needs one).
    Runtime(RuntimeError),
}

impl std::fmt::Display for SessionRegistryError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Runtime(e) => write!(f, "{e}"),
        }
    }
}

impl std::error::Error for SessionRegistryError {}

impl From<RuntimeError> for SessionRegistryError {
    fn from(e: RuntimeError) -> Self {
        Self::Runtime(e)
    }
}

/// Bounded LRU of [`HookSession`]s, one per `session_id`.
///
/// Cloning is cheap (`Arc`-shared internals).
#[derive(Clone)]
pub struct SessionRegistry {
    inner: Arc<RegistryInner>,
}

struct RegistryInner {
    runtime: Arc<GuardrailsRuntime>,
    opts: RegistryOptions,
    state: Mutex<RegistryState>,
}

struct RegistryState {
    /// session_id → entry. `Arc<HookSession>` so an evicted entry
    /// stays alive for any lease still holding a strong ref.
    entries: HashMap<String, Arc<HookSession>>,
    /// LRU order. Front = least-recently-used. Strings rather than
    /// indices so map / list can drift safely.
    lru: std::collections::VecDeque<String>,
}

impl SessionRegistry {
    /// Construct a registry that builds sessions from `runtime` on
    /// cache miss.
    pub fn new(runtime: Arc<GuardrailsRuntime>, opts: RegistryOptions) -> Self {
        Self {
            inner: Arc::new(RegistryInner {
                runtime,
                opts,
                state: Mutex::new(RegistryState {
                    entries: HashMap::new(),
                    lru: std::collections::VecDeque::new(),
                }),
            }),
        }
    }

    /// Read-only view of the registry's configured options.
    pub fn options(&self) -> &RegistryOptions {
        &self.inner.opts
    }

    /// Acquire a lease on the [`HookSession`] for `session_id`. On
    /// cache miss, a fresh session is built with `ctx`. On cache hit
    /// `ctx` is dropped: the existing session's `RequestContext` is
    /// fixed at construction.
    ///
    /// The returned [`SessionLease`] bumps the entry's lease counter
    /// so eviction can't reclaim the session while it's held.
    pub fn acquire(
        &self,
        session_id: &str,
        ctx: RequestContext,
    ) -> Result<SessionLease, SessionRegistryError> {
        // The lease counter MUST be bumped while the registry state
        // mutex is held so a concurrent acquire on a different
        // session_id can't observe this entry as unheld between map
        // lookup and increment, and then evict it.
        let session = self.get_or_create(session_id, ctx)?;
        Ok(SessionLease { session })
    }

    fn get_or_create(
        &self,
        session_id: &str,
        ctx: RequestContext,
    ) -> Result<Arc<HookSession>, SessionRegistryError> {
        let mut state = self.inner.state.lock().expect("registry state poisoned");

        if let Some(existing) = state.entries.get(session_id).cloned() {
            // Bump counter while the registry mutex is still held.
            existing.active_holders.fetch_add(1, Ordering::SeqCst);
            // Touch LRU order: move to back.
            if let Some(pos) = state.lru.iter().position(|s| s == session_id) {
                state.lru.remove(pos);
            }
            state.lru.push_back(session_id.to_string());
            return Ok(existing);
        }

        // Cache miss — build a fresh session and bump the counter
        // BEFORE publishing it to the map. Publishing-with-counter
        // ensures eviction can never observe a freshly-inserted entry
        // as unheld.
        let raw = self.inner.runtime.new_session(ctx);
        let hook = Arc::new(HookSession::new(Arc::new(raw)));
        hook.active_holders.fetch_add(1, Ordering::SeqCst);
        state.entries.insert(session_id.to_string(), hook.clone());
        state.lru.push_back(session_id.to_string());

        // Evict if over capacity. The newly-inserted entry is
        // protected by both the just-inserted-id check AND its
        // already-incremented counter.
        if state.entries.len() > self.inner.opts.max_size {
            self.evict(&mut state, session_id);
        }

        // Opportunistic TTL sweep: any entry whose
        // `last_used_at` is older than `ttl` and which is not held
        // gets evicted. Cheap because the map is bounded.
        if !self.inner.opts.ttl.is_zero() {
            self.sweep_ttl(&mut state);
        }

        Ok(hook)
    }

    fn evict(&self, state: &mut RegistryState, just_inserted: &str) {
        // Walk LRU front-to-back, skipping entries that are
        // currently held / just inserted.
        let mut idx = 0;
        while idx < state.lru.len() {
            let candidate = state.lru[idx].clone();
            if candidate == just_inserted {
                idx += 1;
                continue;
            }
            let Some(entry) = state.entries.get(&candidate) else {
                // Stale LRU entry; drop and continue.
                state.lru.remove(idx);
                continue;
            };
            // Skip if any lease is alive.
            if entry.active_holders.load(Ordering::SeqCst) > 0 {
                idx += 1;
                continue;
            }
            // Best-effort close: end any open turn / request so spec
            // lifetimes wrap up cleanly. Ignore errors — eviction
            // proceeds regardless.
            let _ = entry.end_turn();
            state.entries.remove(&candidate);
            state.lru.remove(idx);
            return;
        }
        // Nothing was evictable. Briefly exceed capacity rather than
        // corrupt state. Operators see this in logs.
        log::warn!(
            target: "agent_shield::hooks",
            "SessionRegistry over capacity ({} entries) — no evictable entry found",
            state.entries.len()
        );
    }

    fn sweep_ttl(&self, state: &mut RegistryState) {
        let ttl = self.inner.opts.ttl;
        let mut idx = 0;
        while idx < state.lru.len() {
            let candidate = state.lru[idx].clone();
            let Some(entry) = state.entries.get(&candidate) else {
                state.lru.remove(idx);
                continue;
            };
            if entry.active_holders.load(Ordering::SeqCst) > 0 {
                idx += 1;
                continue;
            }
            let age = entry
                .last_used_at
                .lock()
                .expect("last_used_at poisoned")
                .elapsed();
            if age < ttl {
                // Since `lru` is front-old-to-back-new and this is
                // not held, every later entry is even younger; we
                // can stop early.
                break;
            }
            let _ = entry.end_turn();
            state.entries.remove(&candidate);
            state.lru.remove(idx);
            // Don't advance idx — `remove` already shifted.
        }
    }

    /// Number of currently-cached sessions. Test/observability only.
    pub fn len(&self) -> usize {
        self.inner
            .state
            .lock()
            .expect("registry state poisoned")
            .entries
            .len()
    }

    /// `true` when the registry holds no sessions.
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

/// RAII handle returned by [`SessionRegistry::acquire`]. Holds a
/// lease counter on the underlying [`HookSession`] so eviction can't
/// reclaim it while in use. Dropping the lease decrements the
/// counter and refreshes `last_used_at` for TTL eviction.
///
/// `SessionLease` implements `Deref<Target = HookSession>` so
/// integrations can call `lease.begin_turn()`, `lease.session()`,
/// etc., directly.
pub struct SessionLease {
    session: Arc<HookSession>,
}

impl SessionLease {
    /// Access the underlying [`HookSession`].
    pub fn session(&self) -> &Arc<HookSession> {
        &self.session
    }
}

impl std::ops::Deref for SessionLease {
    type Target = HookSession;

    fn deref(&self) -> &Self::Target {
        &self.session
    }
}

impl Drop for SessionLease {
    fn drop(&mut self) {
        // Refresh last_used_at so a long-running callback doesn't get
        // reaped on its way out.
        if let Ok(mut t) = self.session.last_used_at.lock() {
            *t = Instant::now();
        }
        // Decrement lease counter — the entry is now eligible for
        // eviction.
        self.session.active_holders.fetch_sub(1, Ordering::SeqCst);
    }
}
