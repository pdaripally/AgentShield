//! Closed event-namespace registry (§9.3) plus the `EventId` parser.
//!
//! Events are part of the schema everywhere `until_event:` and `event.fired()`
//! show up. The §9.3 namespace is closed: identifiers outside the listed
//! prefixes MUST cause a load-time error. Only `incident.<name>` admits
//! author-defined identifiers, and the name segment grammar is enforced here.

use std::str::FromStr;
use std::sync::OnceLock;

use regex::Regex;
use serde::{Deserialize, Serialize};

/// Errors raised by [`EventId::parse`].
#[derive(Debug, thiserror::Error, Clone)]
pub enum EventIdError {
    #[error("event identifier `{0}` does not match any closed-namespace prefix")]
    UnknownPrefix(String),

    #[error("event identifier `{0}` is malformed: {1}")]
    Malformed(String, String),

    #[error("event identifier `{0}` has invalid suffix `{1}`")]
    InvalidSuffix(String, String),

    #[error(
        "incident event identifier `{0}` does not match `^[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)*$`"
    )]
    InvalidIncidentName(String),
}

/// Per-resource event suffix: `tool.<name>.called|success|failure`.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum ToolEventKind {
    Called,
    Success,
    Failure,
}

impl ToolEventKind {
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Called => "called",
            Self::Success => "success",
            Self::Failure => "failure",
        }
    }

    pub fn parse(s: &str) -> Option<Self> {
        match s {
            "called" => Some(Self::Called),
            "success" => Some(Self::Success),
            "failure" => Some(Self::Failure),
            _ => None,
        }
    }
}

/// Per-guard-policy event suffix.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum GpEventKind {
    Activated,
    Deactivated,
    Passed,
    Failed,
}

impl GpEventKind {
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Activated => "activated",
            Self::Deactivated => "deactivated",
            Self::Passed => "passed",
            Self::Failed => "failed",
        }
    }

    pub fn parse(s: &str) -> Option<Self> {
        match s {
            "activated" => Some(Self::Activated),
            "deactivated" => Some(Self::Deactivated),
            "passed" => Some(Self::Passed),
            "failed" => Some(Self::Failed),
            _ => None,
        }
    }
}

/// `approval.<name>.<allow|deny|cancelled>` suffix.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum ApprovalEventKind {
    Allow,
    Deny,
    Cancelled,
}

impl ApprovalEventKind {
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Allow => "allow",
            Self::Deny => "deny",
            Self::Cancelled => "cancelled",
        }
    }

    pub fn parse(s: &str) -> Option<Self> {
        match s {
            "allow" => Some(Self::Allow),
            "deny" => Some(Self::Deny),
            "cancelled" => Some(Self::Cancelled),
            _ => None,
        }
    }
}

/// A single event identifier from the closed namespace (§9.3).
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub enum EventId {
    SessionStart,
    SessionEnd,
    TurnStart,
    TurnEnd,
    RequestStart,
    RequestEnd,
    Tool {
        name: String,
        kind: ToolEventKind,
    },
    Endpoint {
        pattern: String,
        kind: ToolEventKind,
    },
    Agent {
        name: String,
        kind: ToolEventKind,
    },
    VariableChanged {
        name: String,
    },
    GuardPolicy {
        name: String,
        kind: GpEventKind,
    },
    Approval {
        variable: String,
        kind: ApprovalEventKind,
    },
    Incident {
        name: String,
    },
    /// IFC audit events emitted by the runtime (proof-mandated
    /// observability for §lattice IFC). The closed sub-namespace:
    /// - `ifc.exposure_raised` — `record_*_success` joined a non-trivial
    ///   λ into the running exposure.
    /// - `ifc.exposure_cleared` — a scope reset wiped the running
    ///   exposure to ⊥.
    /// - `ifc.declassified` — a `declassify_to` action lowered the
    ///   running exposure (proof TC-5 audit boundary).
    /// - `ifc.egress_denied` — a Stage-3 or Stage-5 admit-test failed
    ///   (`exposure ⊄ μ(target)`).
    Ifc {
        kind: IfcEventKind,
    },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum IfcEventKind {
    ExposureRaised,
    ExposureCleared,
    Declassified,
    EgressDenied,
}

impl IfcEventKind {
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::ExposureRaised => "exposure_raised",
            Self::ExposureCleared => "exposure_cleared",
            Self::Declassified => "declassified",
            Self::EgressDenied => "egress_denied",
        }
    }
    pub fn parse(s: &str) -> Option<Self> {
        match s {
            "exposure_raised" => Some(Self::ExposureRaised),
            "exposure_cleared" => Some(Self::ExposureCleared),
            "declassified" => Some(Self::Declassified),
            "egress_denied" => Some(Self::EgressDenied),
            _ => None,
        }
    }
}

impl EventId {
    /// Parse an event identifier per §9.3. Returns an error for anything not
    /// in the closed namespace.
    pub fn parse(s: &str) -> std::result::Result<Self, EventIdError> {
        match s {
            "session.start" => return Ok(Self::SessionStart),
            "session.end" => return Ok(Self::SessionEnd),
            "turn.start" => return Ok(Self::TurnStart),
            "turn.end" => return Ok(Self::TurnEnd),
            "request.start" => return Ok(Self::RequestStart),
            "request.end" => return Ok(Self::RequestEnd),
            _ => {}
        }

        if let Some(rest) = s.strip_prefix("tool.") {
            let (name, suffix) = split_last_dot(rest, s)?;
            let kind = ToolEventKind::parse(&suffix)
                .ok_or_else(|| EventIdError::InvalidSuffix(s.to_string(), suffix.clone()))?;
            validate_resource_name(s, &name)?;
            return Ok(Self::Tool { name, kind });
        }

        if let Some(rest) = s.strip_prefix("agent.") {
            let (name, suffix) = split_last_dot(rest, s)?;
            let kind = ToolEventKind::parse(&suffix)
                .ok_or_else(|| EventIdError::InvalidSuffix(s.to_string(), suffix.clone()))?;
            validate_resource_name(s, &name)?;
            return Ok(Self::Agent { name, kind });
        }

        if let Some(rest) = s.strip_prefix("endpoint.") {
            // Endpoint patterns are arbitrary URI templates; validate just the
            // suffix.
            let (pattern, suffix) = split_last_dot(rest, s)?;
            let kind = ToolEventKind::parse(&suffix)
                .ok_or_else(|| EventIdError::InvalidSuffix(s.to_string(), suffix.clone()))?;
            if pattern.is_empty() {
                return Err(EventIdError::Malformed(
                    s.to_string(),
                    "endpoint pattern is empty".into(),
                ));
            }
            return Ok(Self::Endpoint { pattern, kind });
        }

        if let Some(rest) = s.strip_prefix("variable.") {
            let (name, suffix) = split_last_dot(rest, s)?;
            if suffix != "changed" {
                return Err(EventIdError::InvalidSuffix(s.to_string(), suffix));
            }
            validate_var_name(s, &name)?;
            return Ok(Self::VariableChanged { name });
        }

        if let Some(rest) = s.strip_prefix("guard_policy.") {
            let (name, suffix) = split_last_dot(rest, s)?;
            let kind = GpEventKind::parse(&suffix)
                .ok_or_else(|| EventIdError::InvalidSuffix(s.to_string(), suffix.clone()))?;
            if name.is_empty() {
                return Err(EventIdError::Malformed(
                    s.to_string(),
                    "guard_policy name is empty".into(),
                ));
            }
            return Ok(Self::GuardPolicy { name, kind });
        }

        if let Some(rest) = s.strip_prefix("approval.") {
            let (var, suffix) = split_last_dot(rest, s)?;
            let kind = ApprovalEventKind::parse(&suffix)
                .ok_or_else(|| EventIdError::InvalidSuffix(s.to_string(), suffix.clone()))?;
            validate_var_name(s, &var)?;
            return Ok(Self::Approval {
                variable: var,
                kind,
            });
        }

        if let Some(rest) = s.strip_prefix("incident.") {
            if !incident_name_re().is_match(rest) {
                return Err(EventIdError::InvalidIncidentName(s.to_string()));
            }
            return Ok(Self::Incident {
                name: rest.to_string(),
            });
        }

        if let Some(rest) = s.strip_prefix("ifc.") {
            let kind = IfcEventKind::parse(rest)
                .ok_or_else(|| EventIdError::InvalidSuffix(s.to_string(), rest.to_string()))?;
            return Ok(Self::Ifc { kind });
        }

        Err(EventIdError::UnknownPrefix(s.to_string()))
    }
}

fn split_last_dot(rest: &str, full: &str) -> std::result::Result<(String, String), EventIdError> {
    match rest.rsplit_once('.') {
        Some((a, b)) if !a.is_empty() && !b.is_empty() => Ok((a.to_string(), b.to_string())),
        _ => Err(EventIdError::Malformed(
            full.to_string(),
            "expected `<prefix>.<name>.<suffix>` form".into(),
        )),
    }
}

fn validate_resource_name(full: &str, name: &str) -> std::result::Result<(), EventIdError> {
    if name == "*" {
        return Ok(());
    }
    if name.is_empty() {
        return Err(EventIdError::Malformed(
            full.to_string(),
            "empty name".into(),
        ));
    }
    let bytes = name.as_bytes();
    let head_ok = bytes[0].is_ascii_alphabetic() || bytes[0] == b'_';
    let tail_ok = bytes
        .iter()
        .skip(1)
        .all(|b| b.is_ascii_alphanumeric() || *b == b'_');
    if !(head_ok && tail_ok) {
        return Err(EventIdError::Malformed(
            full.to_string(),
            format!("invalid resource name `{}`", name),
        ));
    }
    Ok(())
}

fn validate_var_name(full: &str, name: &str) -> std::result::Result<(), EventIdError> {
    if name.is_empty() {
        return Err(EventIdError::Malformed(
            full.to_string(),
            "empty name".into(),
        ));
    }
    let bytes = name.as_bytes();
    let head_ok = bytes[0].is_ascii_lowercase() || bytes[0] == b'_';
    let tail_ok = bytes
        .iter()
        .skip(1)
        .all(|b| b.is_ascii_lowercase() || b.is_ascii_digit() || *b == b'_');
    if !(head_ok && tail_ok) {
        return Err(EventIdError::Malformed(
            full.to_string(),
            format!("variable name `{}` must be snake_case", name),
        ));
    }
    Ok(())
}

fn incident_name_re() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| Regex::new(r"^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)*$").unwrap())
}

impl std::fmt::Display for EventId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::SessionStart => f.write_str("session.start"),
            Self::SessionEnd => f.write_str("session.end"),
            Self::TurnStart => f.write_str("turn.start"),
            Self::TurnEnd => f.write_str("turn.end"),
            Self::RequestStart => f.write_str("request.start"),
            Self::RequestEnd => f.write_str("request.end"),
            Self::Tool { name, kind } => write!(f, "tool.{}.{}", name, kind.as_str()),
            Self::Endpoint { pattern, kind } => write!(f, "endpoint.{}.{}", pattern, kind.as_str()),
            Self::Agent { name, kind } => write!(f, "agent.{}.{}", name, kind.as_str()),
            Self::VariableChanged { name } => write!(f, "variable.{}.changed", name),
            Self::GuardPolicy { name, kind } => {
                write!(f, "guard_policy.{}.{}", name, kind.as_str())
            }
            Self::Approval { variable, kind } => {
                write!(f, "approval.{}.{}", variable, kind.as_str())
            }
            Self::Incident { name } => write!(f, "incident.{}", name),
            Self::Ifc { kind } => write!(f, "ifc.{}", kind.as_str()),
        }
    }
}

impl FromStr for EventId {
    type Err = EventIdError;
    fn from_str(s: &str) -> std::result::Result<Self, EventIdError> {
        EventId::parse(s)
    }
}

impl Serialize for EventId {
    fn serialize<S: serde::Serializer>(&self, ser: S) -> std::result::Result<S::Ok, S::Error> {
        ser.serialize_str(&self.to_string())
    }
}

impl<'de> Deserialize<'de> for EventId {
    fn deserialize<D: serde::Deserializer<'de>>(de: D) -> std::result::Result<Self, D::Error> {
        let raw = String::deserialize(de)?;
        EventId::parse(&raw).map_err(serde::de::Error::custom)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_simple_lifecycle_events() {
        assert_eq!(
            EventId::parse("session.start").unwrap(),
            EventId::SessionStart
        );
        assert_eq!(EventId::parse("session.end").unwrap(), EventId::SessionEnd);
        assert_eq!(EventId::parse("turn.start").unwrap(), EventId::TurnStart);
        assert_eq!(EventId::parse("request.end").unwrap(), EventId::RequestEnd);
    }

    #[test]
    fn parses_tool_events() {
        let e = EventId::parse("tool.send_email.success").unwrap();
        assert_eq!(
            e,
            EventId::Tool {
                name: "send_email".into(),
                kind: ToolEventKind::Success,
            }
        );
        assert_eq!(e.to_string(), "tool.send_email.success");
    }

    #[test]
    fn parses_incident_events() {
        let e = EventId::parse("incident.threat_detected").unwrap();
        assert!(matches!(e, EventId::Incident { .. }));
        // Multi-segment.
        let e = EventId::parse("incident.security.p1").unwrap();
        assert_eq!(e.to_string(), "incident.security.p1");
    }

    #[test]
    fn rejects_unknown_prefix() {
        let err = EventId::parse("custom.foo").unwrap_err();
        assert!(matches!(err, EventIdError::UnknownPrefix(_)));
    }

    #[test]
    fn rejects_bad_incident_grammar() {
        // Uppercase head segment.
        assert!(matches!(
            EventId::parse("incident.Foo").unwrap_err(),
            EventIdError::InvalidIncidentName(_)
        ));
        // Trailing dot.
        assert!(EventId::parse("incident.").is_err());
    }

    #[test]
    fn rejects_bad_tool_suffix() {
        assert!(matches!(
            EventId::parse("tool.send.bogus").unwrap_err(),
            EventIdError::InvalidSuffix(_, _)
        ));
    }

    #[test]
    fn parses_guard_policy_events() {
        let e = EventId::parse("guard_policy.high_risk_gate.activated").unwrap();
        assert_eq!(
            e,
            EventId::GuardPolicy {
                name: "high_risk_gate".into(),
                kind: GpEventKind::Activated,
            }
        );
    }

    #[test]
    fn round_trips_via_display() {
        let inputs = [
            "session.start",
            "tool.send_email.failure",
            "agent.fraud_detection_agent.success",
            "endpoint./api/v1/users/{id}.called",
            "variable.balance.changed",
            "guard_policy.gate_x.passed",
            "approval.recipients.allow",
            "incident.tenant_lockdown",
        ];
        for s in inputs {
            let parsed = EventId::parse(s).unwrap_or_else(|e| panic!("{}: {}", s, e));
            assert_eq!(parsed.to_string(), s);
        }
    }
}
