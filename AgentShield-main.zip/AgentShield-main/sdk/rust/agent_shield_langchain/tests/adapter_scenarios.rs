//! Cross-language adapter-scenario harness — LangChain.
//!
//! See `sdk/rust/adapter_scenarios_common.rs` for the shared body.
//! Mirrors `tests/e2e/run_langchain.py` and
//! `tests/e2e/node/run-langchain.test.mjs` so all four languages
//! assert byte-equivalent behaviour over the same shared fixture.

use agent_shield_langchain::ShieldLangChainExt;

#[path = "../../adapter_scenarios_common.rs"]
mod common;

#[tokio::test(flavor = "current_thread")]
async fn shared_adapter_scenarios() {
    common::run_with("langchain", |b| b.with_langchain()).await;
}
