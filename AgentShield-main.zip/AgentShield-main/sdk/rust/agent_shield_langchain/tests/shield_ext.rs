//! Smoke tests for the LangChain `Shield` extension trait.

use std::path::PathBuf;

use agent_shield::{CoverageLevel, Shield};
use agent_shield_langchain::{ShieldLangChainExt, CAPABILITY_REPORT};

fn fixture() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("../../..")
        .join("tests/fixtures/smoke/minimal.guardrails.yaml")
}

#[test]
fn capability_report_const_has_expected_shape() {
    // Const has empty framework name; runtime helper fills it in.
    assert_eq!(CAPABILITY_REPORT.framework, "");
    assert_eq!(
        CAPABILITY_REPORT.tool_execution_validation,
        Some(CoverageLevel::Full)
    );
    assert_eq!(
        CAPABILITY_REPORT.streaming_output,
        Some(CoverageLevel::Partial)
    );
}

#[test]
fn with_langchain_installs_capability_report() {
    let shield = Shield::from_yaml(fixture())
        .with_langchain()
        .build()
        .expect("build");
    let report = shield.capabilities();
    assert_eq!(report.framework, "langchain");
    assert_eq!(
        report.tool_execution_validation,
        Some(CoverageLevel::Full),
        "langchain has Stage-3 mutation support"
    );
    assert_eq!(
        report.streaming_output,
        Some(CoverageLevel::Partial),
        "streaming hook is partial"
    );
    assert!(!report.notes.is_empty());
}
