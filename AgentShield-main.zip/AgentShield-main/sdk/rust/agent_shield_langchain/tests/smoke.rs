//! Smoke tests for the LangChain adapter.

use std::error::Error;
use std::path::PathBuf;
use std::sync::Arc;

use agent_shield_core::{GuardrailsRuntime, GuardrailsSession, RequestContext, RuntimeBuilder};
use agent_shield_langchain as guard;
use async_trait::async_trait;
use langchain_rust::tools::Tool;
use serde_json::{json, Value};

fn fixture_path() -> PathBuf {
    let manifest = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    manifest
        .join("../../..")
        .join("tests/fixtures/smoke/minimal.guardrails.yaml")
}

fn build_runtime() -> Arc<GuardrailsRuntime> {
    RuntimeBuilder::from_yaml(fixture_path())
        .unwrap()
        .build()
        .unwrap()
}

fn open_session(rt: &Arc<GuardrailsRuntime>) -> GuardrailsSession {
    rt.new_session(RequestContext::new("sess-1", "corr-1"))
}

/// Minimal echo tool used for the smoke tests.
struct EchoTool;

#[async_trait]
impl Tool for EchoTool {
    fn name(&self) -> String {
        "echo".into()
    }
    fn description(&self) -> String {
        "Echoes the input back.".into()
    }
    fn parameters(&self) -> Value {
        json!({
            "type": "object",
            "properties": {"msg": {"type": "string"}}
        })
    }
    async fn run(&self, input: Value) -> Result<String, Box<dyn Error>> {
        Ok(input.to_string())
    }
}

#[test]
fn protect_tool_blocks_when_unauthorized() {
    let rt = build_runtime();
    let s = open_session(&rt);
    let mut p = json!({"msg": "hi"});
    let v = guard::protect_tool(&s, "echo", &mut p, "call_1");
    assert!(!v.allowed);
}

#[test]
fn protect_tool_allows_when_authorized() {
    let rt = build_runtime();
    let s = open_session(&rt);
    s.set_variable("authorized", json!(true)).unwrap();
    let mut p = json!({"msg": "hi"});
    let v = guard::protect_tool(&s, "echo", &mut p, "call_1");
    assert!(v.allowed);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 1)]
async fn guarded_tool_blocks_unauthorized_call() {
    let rt = build_runtime();
    let inner: Arc<dyn Tool> = Arc::new(EchoTool);
    let guarded = guard::GuardedTool::new(inner, rt);
    let out = guarded.run(json!({"msg": "hi"})).await.unwrap();
    assert!(
        out.contains("blocked"),
        "expected blocked-tool message, got: {out}"
    );
}

#[test]
fn record_tool_success_emits_event() {
    use agent_shield_core::{EventId, ToolEventKind};
    let rt = build_runtime();
    let s = open_session(&rt);
    guard::record_tool_success(&s, "echo", &json!("ok")).unwrap();
    let id = EventId::Tool {
        name: "echo".into(),
        kind: ToolEventKind::Success,
    };
    assert!(rt.bus().fired_id(&id));
}

#[test]
fn guard_input_passes_clean_text() {
    let rt = build_runtime();
    let s = open_session(&rt);
    guard::guard_input(&s, "hello").expect("clean input passes");
}

#[tokio::test(flavor = "multi_thread", worker_threads = 1)]
async fn turn_guard_drives_validate_tool_call() {
    let rt = build_runtime();
    let s = open_session(&rt);
    s.set_variable("authorized", json!(true)).unwrap();
    let turn = guard::TurnGuard::begin(&s, "hello").expect("input passes");
    let mut p = json!({"msg": "hi"});
    let v = turn.validate_tool_call("echo", &mut p, "call_1");
    assert!(v.allowed);
    turn.end();
}
