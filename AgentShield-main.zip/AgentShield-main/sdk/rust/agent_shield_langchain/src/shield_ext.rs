//! `Shield`-builder extension trait for the LangChain Rust adapter.
//!
//! Exports a [`CAPABILITY_REPORT`] constant declaring the LangChain
//! adapter's per-stage coverage and a [`ShieldLangChainExt`] trait
//! that adds [`with_langchain`](ShieldLangChainExt::with_langchain) to
//! [`agent_shield::ShieldBuilder`].
//!
//! # Example (≤ 5 lines)
//!
//! ```no_run
//! # async fn ex() -> Result<(), Box<dyn std::error::Error>> {
//! use agent_shield::Shield;
//! use agent_shield_langchain::ShieldLangChainExt;
//! let shield = Shield::from_yaml(".guardrails.yaml").with_langchain().build()?;
//! # let _ = shield; Ok(()) }
//! ```

use std::sync::Arc;

use agent_shield::{CapabilityReport, CoverageLevel, ShieldBuilder, ToolWrapper};
use agent_shield_core::GuardrailsRuntime;
use langchain_rust::tools::Tool;

use crate::GuardedTool;

/// Honest capability report for the LangChain Rust adapter.
///
/// Tool-execution mutation (Stage 3) works because LangChain Rust's
/// tools accept the args as `serde_json::Value` and the wrapper
/// re-serializes mutated args before delegating. Streaming output is
/// marked `Partial` because LangChain Rust does not expose a chunk-
/// level hook the adapter can plug into; hosts that need streaming
/// redaction must drive [`agent_shield_core::StreamingGuard`]
/// themselves.
pub const CAPABILITY_REPORT: CapabilityReport = CapabilityReport {
    framework: String::new(),
    input_validation: Some(CoverageLevel::Full),
    state_validation: Some(CoverageLevel::Full),
    tool_authorization: Some(CoverageLevel::Full),
    tool_execution_validation: Some(CoverageLevel::Full),
    tool_output_validation: Some(CoverageLevel::Full),
    output_validation: Some(CoverageLevel::Full),
    streaming_output: Some(CoverageLevel::Partial),
    notes: Vec::new(),
};

fn report() -> CapabilityReport {
    CapabilityReport {
        framework: "langchain".to_string(),
        notes: vec![
            "streaming_output is partial: LangChain Rust does not expose a \
             chunk-level hook; drive StreamingGuard manually for chunk-level \
             redaction"
                .to_string(),
        ],
        ..CAPABILITY_REPORT
    }
}

/// Extension trait adding `with_langchain` to [`ShieldBuilder`].
pub trait ShieldLangChainExt {
    /// Install the LangChain capability report.
    fn with_langchain(self) -> Self;
}

impl ShieldLangChainExt for ShieldBuilder {
    fn with_langchain(self) -> Self {
        self.with_capability(report())
    }
}

// ── Pattern B ToolWrapper ───────────────────────────────────────────

/// `ToolWrapper` impl for LangChain Rust tools. Each tool is wrapped in
/// a [`crate::GuardedTool`] that opens a fresh session per `run` call.
pub struct LangChainToolWrapper;

impl ToolWrapper for LangChainToolWrapper {
    type Tool = Arc<dyn Tool>;
    type Wrapped = Arc<dyn Tool>;

    fn wrap(runtime: Arc<GuardrailsRuntime>, tool: Arc<dyn Tool>) -> Arc<dyn Tool> {
        Arc::new(GuardedTool::new(tool, runtime)) as Arc<dyn Tool>
    }
}
