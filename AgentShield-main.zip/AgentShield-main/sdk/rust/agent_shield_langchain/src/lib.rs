//! Agent Shield adapter for LangChain Rust.
//!
//! Provides guardrail validation for LangChain tool integrations.

#![allow(clippy::result_large_err)]

pub mod shield_ext;

pub use shield_ext::{LangChainToolWrapper, ShieldLangChainExt, CAPABILITY_REPORT};

use std::collections::HashMap;
use std::error::Error;
use std::sync::Arc;

use agent_shield_core::{
    synthetic_tool_call_id, GuardrailsRuntime, GuardrailsSession, RequestContext, RuntimeError,
    StageVerdict,
};
use async_trait::async_trait;
use langchain_rust::tools::Tool;
use serde_json::Value;

/// Stage 2+3 — guard a tool call against a session. Mutates
/// `params` in place. `tool_call_id` is REQUIRED per spec §16.0 and
/// MUST match the id passed to the paired Stage 4
/// [`protect_tool_output`]; pass the framework-supplied id when one
/// is available, or [`synthetic_tool_call_id`] otherwise.
pub fn protect_tool(
    session: &GuardrailsSession,
    tool_name: &str,
    params: &mut Value,
    tool_call_id: &str,
) -> StageVerdict {
    session.validate_tool_call(tool_name, params, tool_call_id)
}

/// Stage 4 — guard a tool result. `tool_call_id` MUST match the id
/// passed to the paired [`protect_tool`] call (§16.0).
pub fn protect_tool_output(
    session: &GuardrailsSession,
    tool_name: &str,
    result: &mut Value,
    tool_call_id: &str,
) -> StageVerdict {
    session.validate_tool_output(tool_name, result, tool_call_id)
}

/// Record a successful tool execution (§10.3 / §21).
pub fn record_tool_success(
    session: &GuardrailsSession,
    tool_name: &str,
    result: &Value,
) -> Result<(), RuntimeError> {
    session.record_tool_success(tool_name, result)
}

/// Record a failed tool execution.
pub fn record_tool_failure(
    session: &GuardrailsSession,
    tool_name: &str,
    error: &str,
) -> Result<(), RuntimeError> {
    session.record_tool_failure(tool_name, error)
}

/// Stage 1 — guard a user input string.
pub fn guard_input(session: &GuardrailsSession, text: &str) -> Result<(), StageVerdict> {
    let v = session.validate_input(text);
    if v.allowed {
        Ok(())
    } else {
        Err(v)
    }
}

/// Stage 5 — guard a final assistant string. Mutates in place.
pub fn guard_output(session: &GuardrailsSession, text: &mut String) -> StageVerdict {
    session.validate_output(text)
}

// ── GuardedTool ───────────────────────────────────────────────────

/// Wrapper that enforces guardrails around an inner LangChain
/// [`Tool`]. Implements [`Tool`] itself so it can be substituted
/// transparently in agent pipelines.
pub struct GuardedTool {
    inner: Arc<dyn Tool>,
    runtime: Arc<GuardrailsRuntime>,
}

impl GuardedTool {
    /// Wrap an existing tool. The wrapper opens a fresh
    /// [`GuardrailsSession`] per `run` call (with a fresh
    /// [`RequestContext`]). Hosts that need to share session state
    /// across multiple tool calls in a turn should drop this wrapper
    /// and use [`protect_tool`] / [`record_tool_success`] against a
    /// long-lived session.
    pub fn new(tool: Arc<dyn Tool>, runtime: Arc<GuardrailsRuntime>) -> Self {
        Self {
            inner: tool,
            runtime,
        }
    }
}

#[async_trait]
impl Tool for GuardedTool {
    fn name(&self) -> String {
        self.inner.name()
    }

    fn description(&self) -> String {
        self.inner.description()
    }

    fn parameters(&self) -> Value {
        self.inner.parameters()
    }

    async fn run(&self, input: Value) -> Result<String, Box<dyn Error>> {
        let name = self.inner.name();
        let session = self.runtime.new_session(RequestContext::default());

        // Build params — wrap non-object inputs into a synthetic map
        // so tools that accept scalars still see a stable shape.
        let mut params = match &input {
            Value::Object(_) => input.clone(),
            other => {
                let mut m = serde_json::Map::new();
                m.insert("input".into(), other.clone());
                Value::Object(m)
            }
        };

        // LangChain's Tool trait does not expose a stable per-call
        // handle, so synthesize a UUID for §16.0 binding. The same id
        // pairs Stage 3 and Stage 4 below.
        let tool_call_id = synthetic_tool_call_id();

        let verdict = session.validate_tool_call(&name, &mut params, &tool_call_id);
        if !verdict.allowed {
            return Ok(format_tool_block(
                &name,
                verdict.reason.as_deref().unwrap_or("blocked"),
            ));
        }

        // Run the inner tool with the (possibly transformed) params.
        let inner_input = if matches!(input, Value::Object(_)) {
            params.clone()
        } else {
            params.get("input").cloned().unwrap_or(Value::Null)
        };

        let raw = match self.inner.run(inner_input).await {
            Ok(text) => text,
            Err(e) => {
                if let Err(rec_err) = session.record_tool_failure(&name, &e.to_string()) {
                    log::warn!(target: "agent_shield::langchain", "record_tool_failure failed: {rec_err:?}");
                }
                return Ok(format_tool_error(&name, &e.to_string()));
            }
        };

        // Stage 4 + record success.
        let mut value = Value::String(raw.clone());
        let post = session.validate_tool_output(&name, &mut value, &tool_call_id);
        if !post.allowed {
            if let Err(e) = session.record_tool_failure(&name, "post-tool-blocked") {
                log::warn!(target: "agent_shield::langchain", "record_tool_failure failed: {e:?}");
            }
            return Ok(format_tool_output_block(
                &name,
                post.reason.as_deref().unwrap_or("blocked"),
            ));
        }
        if let Err(e) = session.record_tool_success(&name, &value) {
            log::warn!(target: "agent_shield::langchain", "record_tool_success failed: {e:?}");
        }
        Ok(value.as_str().map(|s| s.to_string()).unwrap_or(raw))
    }
}

/// Wrap a list of tools with guardrails. Each tool gets its own
/// [`GuardedTool`] sharing the supplied runtime.
pub fn protect_tools(
    runtime: Arc<GuardrailsRuntime>,
    tools: Vec<Arc<dyn Tool>>,
) -> Vec<Arc<dyn Tool>> {
    tools
        .into_iter()
        .map(|t| Arc::new(GuardedTool::new(t, runtime.clone())) as Arc<dyn Tool>)
        .collect()
}

// ── TurnGuard ───────────────────────────────────────────────────────

/// Per-turn guard — borrows a long-lived session and drives
/// `begin_turn` / `end_turn`.
pub struct TurnGuard<'a> {
    session: &'a GuardrailsSession,
    ended: std::cell::Cell<bool>,
}

impl<'a> TurnGuard<'a> {
    /// Begin a new turn against `session`, run Stage 1 against
    /// `user_input`, and return the guard. Returns `Err(verdict)` if
    /// Stage 1 blocks.
    pub fn begin(session: &'a GuardrailsSession, user_input: &str) -> Result<Self, StageVerdict> {
        if let Err(e) = session.begin_turn() {
            log::warn!(target: "agent_shield::langchain", "begin_turn failed: {e:?}");
        }
        let v = session.validate_input(user_input);
        if !v.allowed {
            if let Err(e) = session.end_turn() {
                log::warn!(target: "agent_shield::langchain", "end_turn failed: {e:?}");
            }
            return Err(v);
        }
        Ok(Self {
            session,
            ended: std::cell::Cell::new(false),
        })
    }

    /// Borrow the underlying session.
    pub fn session(&self) -> &GuardrailsSession {
        self.session
    }

    /// Stage 2+3 against the held session. `tool_call_id` is REQUIRED
    /// per spec §16.0; pair the same id with the matching
    /// [`Self::validate_tool_output`]. Use
    /// [`agent_shield_core::synthetic_tool_call_id`] when no native id
    /// is available.
    pub fn validate_tool_call(
        &self,
        name: &str,
        params: &mut Value,
        tool_call_id: &str,
    ) -> StageVerdict {
        self.session.validate_tool_call(name, params, tool_call_id)
    }

    /// Stage 4 against the held session. `tool_call_id` MUST match
    /// the id passed to the paired [`Self::validate_tool_call`] (§16.0).
    pub fn validate_tool_output(
        &self,
        name: &str,
        result: &mut Value,
        tool_call_id: &str,
    ) -> StageVerdict {
        self.session
            .validate_tool_output(name, result, tool_call_id)
    }

    /// Stage 5 against the held session.
    pub fn validate_output(&self, response: &mut String) -> StageVerdict {
        self.session.validate_output(response)
    }

    /// Explicitly end the turn. Idempotent — calling `end()` multiple
    /// times (or `end()` followed by `Drop`) only fires `turn.end`
    /// once.
    pub fn end(&self) {
        if !self.ended.replace(true) {
            if let Err(e) = self.session.end_turn() {
                log::warn!(target: "agent_shield::langchain", "end_turn failed: {e:?}");
            }
        }
    }
}

impl Drop for TurnGuard<'_> {
    fn drop(&mut self) {
        if !self.ended.replace(true) {
            if let Err(e) = self.session.end_turn() {
                log::warn!(target: "agent_shield::langchain", "end_turn (Drop) failed: {e:?}");
            }
        }
    }
}

/// Convert a JSON object into a plain `HashMap<String, Value>` for
/// hosts that already have a flat param-map representation.
pub fn params_from_value(v: Value) -> HashMap<String, Value> {
    match v {
        Value::Object(m) => m.into_iter().collect(),
        other => {
            let mut h = HashMap::new();
            h.insert("input".into(), other);
            h
        }
    }
}

// ── Internal helpers ────────────────────────────────────────────────

fn format_tool_block(tool_name: &str, reason: &str) -> String {
    format!("[Agent Shield] Tool '{}' blocked: {}", tool_name, reason)
}

fn format_tool_output_block(tool_name: &str, reason: &str) -> String {
    format!(
        "[Agent Shield] Tool '{}' output blocked: {}",
        tool_name, reason
    )
}

fn format_tool_error(tool_name: &str, error: &str) -> String {
    format!("[Agent Shield] Tool '{}' error: {}", tool_name, error)
}
