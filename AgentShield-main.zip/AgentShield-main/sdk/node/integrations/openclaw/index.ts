// Agent Shield plugin for OpenClaw.
//
// Hooks into OpenClaw's typed `api.on(...)` plugin surface to enforce
// the five Agent Shield validation stages. Built directly on
// `@microsoft/agent-shield`'s native binding via
// `HookSessionRegistry` / `StageDispatcher` — no per-integration
// state machinery is duplicated.
//
// ## Mapping
//
// | OpenClaw hook            | Agent Shield action                            |
// |--------------------------|------------------------------------------------|
// | `before_agent_run`       | Stage 1; begin turn + request                  |
// | `before_tool_call`       | Stage 2 + 3 (fail closed if no toolCallId)    |
// | `after_tool_call`        | record execution status into scratch          |
// | `tool_result_persist`    | Stage 4; record success/failure on cycle      |
// | `before_agent_reply`     | Stage 5 (hard block via synthetic reply)      |
// | `before_agent_finalize`  | Stage 5 soft remediation (revise instruction) |
// | `session_start`          | no-op (turn opens on before_agent_run)        |
// | `session_end`            | end request + turn                             |
//
// `before_agent_finalize` is treated as a soft-remediation hook
// because OpenClaw's `{ action: "revise" }` asks the harness for
// another model pass — the model can ignore the instruction.
// `before_agent_reply` is the fail-closed Stage 5 block path
// (synthetic reply substitution).
//
// Plugins consuming `before_agent_reply` / `before_agent_run` /
// `before_agent_finalize` MUST set
// `plugins.entries.<id>.hooks.allowConversationAccess: true` in the
// OpenClaw operator config per the OpenClaw SDK docs.

import {
  HookSession,
  HookSessionRegistry,
  StageDispatcher,
} from "../../native.js";
import type { Runtime } from "../../index.js";

/** Enforcement mode mirror of `agent_shield_core::shield_primitives::ShieldMode`. */
export type ShieldMode = "enforce" | "monitor";

/** On-block dispatch policy mirror of `OnBlockPolicy`. */
export type OnBlockPolicy =
  | "return_blocked"
  | "return_verdict"
  | "raise"
  | "custom";

export interface AgentShieldOpenClawOptions {
  runtime: Runtime;
  /** Default `"enforce"`. `"monitor"` records blocks without short-circuiting. */
  mode?: ShieldMode;
  /** Default `"return_blocked"`. */
  policy?: OnBlockPolicy;
  /** Registry tuning. Optional. */
  registry?: {
    maxSize?: number;
    ttlSeconds?: number;
    inFlightTimeoutSeconds?: number;
  };
}

interface ToolStatus {
  resultType: "success" | "failure";
  error?: string;
}

/**
 * Build the AgentShield plugin's hook handlers + lifecycle helpers.
 *
 * Returns an object you compose into your `definePluginEntry`
 * registration:
 *
 * ```ts
 * import { createAgentShieldOpenClawPlugin } from "@microsoft/agent-shield/openclaw";
 * import { definePluginEntry } from "openclaw/plugin-sdk/plugin-entry";
 *
 * const shield = createAgentShieldOpenClawPlugin({ runtime, mode: "enforce" });
 *
 * export default definePluginEntry({
 *   id: "agent-shield",
 *   name: "Agent Shield",
 *   register(api) {
 *     api.on("before_agent_run", shield.beforeAgentRun);
 *     api.on("before_tool_call", shield.beforeToolCall);
 *     api.on("after_tool_call", shield.afterToolCall);
 *     api.on("tool_result_persist", shield.toolResultPersist);
 *     api.on("before_agent_reply", shield.beforeAgentReply);
 *     api.on("before_agent_finalize", shield.beforeAgentFinalize);
 *     api.on("session_start", shield.sessionStart);
 *     api.on("session_end", shield.sessionEnd);
 *   },
 * });
 * ```
 */
export function createAgentShieldOpenClawPlugin(
  opts: AgentShieldOpenClawOptions,
) {
  const mode: ShieldMode = opts.mode ?? "enforce";
  const policy: OnBlockPolicy = opts.policy ?? "return_blocked";
  const registry = new HookSessionRegistry(opts.runtime.native, {
    maxSize: opts.registry?.maxSize ?? 512,
    ttlSeconds: opts.registry?.ttlSeconds ?? 1800,
    inFlightTimeoutSeconds: opts.registry?.inFlightTimeoutSeconds ?? 300,
  });
  const dispatcher = new StageDispatcher();

  // Per-session `(toolName, toolCallId)` → execution status, written
  // by `after_tool_call` and read by `tool_result_persist`. Map key
  // is the JSON-encoded tuple to keep it lookup-stable.
  const toolStatusBySession = new Map<string, Map<string, ToolStatus>>();
  // Per-session request token map (cross-hook scope).
  const requestTokens = new Map<string, number>();

  function sessionKey(ctx: any): string {
    const k =
      ctx?.sessionKey ??
      ctx?.sessionId ??
      ctx?.session_id ??
      ctx?.runId ??
      "anonymous";
    return String(k);
  }

  function withLease<T>(
    sid: string,
    body: (sess: HookSession) => T,
  ): T {
    const sess = registry.acquire(sid, { session_id: sid });
    try {
      return body(sess);
    } finally {
      sess.release();
    }
  }

  function stashStatus(sid: string, toolName: string, toolCallId: string, status: ToolStatus) {
    let m = toolStatusBySession.get(sid);
    if (!m) {
      m = new Map();
      toolStatusBySession.set(sid, m);
    }
    m.set(`${toolName}\u0000${toolCallId}`, status);
  }

  function popStatus(sid: string, toolName: string, toolCallId: string): ToolStatus | undefined {
    const m = toolStatusBySession.get(sid);
    if (!m) return undefined;
    const k = `${toolName}\u0000${toolCallId}`;
    const v = m.get(k);
    m.delete(k);
    return v;
  }

  return {
    /** Underlying registry exposed for tests / observability. */
    registry,

    /** Stage 1. Opens the turn + request scope before validating. */
    beforeAgentRun: async (event: any) => {
      const sid = sessionKey(event?.context ?? event);
      return withLease(sid, (sess) => {
        // If a prior run for this session never closed, restart the
        // turn so per-turn variables don't bleed.
        if (sess.turnIsOpen()) {
          sess.restartTurn();
        } else {
          sess.beginTurn();
        }
        // Close any leftover request token from a previous run that
        // wasn't cleanly retired (proxy crash / aborted run).
        const prior = requestTokens.get(sid);
        if (prior !== undefined) {
          sess.endRequest(prior);
          requestTokens.delete(sid);
        }
        const tok = sess.beginRequest();
        requestTokens.set(sid, tok);

        const prompt = String(event?.prompt ?? "");
        const result = dispatcher.validateInput(sess, prompt, mode, policy);
        return mapStage1Outcome(result, prompt);
      });
    },

    /** Stage 2 + 3. Fails closed when no toolCallId is supplied. */
    beforeToolCall: async (event: any) => {
      const sid = sessionKey(event?.context ?? event);
      const toolCallId = event?.toolCallId;
      if (!toolCallId) {
        return {
          block: true,
          blockReason:
            "Agent Shield: refusing tool call without a toolCallId (§16.0 binding requires a stable id).",
        };
      }
      return withLease(sid, (sess) => {
        const result = dispatcher.validateToolCall(
          sess,
          String(event?.toolName ?? ""),
          event?.params ?? {},
          String(toolCallId),
          mode,
          policy,
        );
        return mapToolCallOutcome(result, event?.params ?? {});
      });
    },

    /**
     * Observation-only. Records execution status keyed by
     * `(toolName, toolCallId)` so `tool_result_persist` can drive
     * `recordToolSuccess` / `recordToolFailure` after Stage 4
     * produces the final model-visible result.
     */
    afterToolCall: async (event: any) => {
      const sid = sessionKey(event?.context ?? event);
      const toolCallId = event?.toolCallId;
      if (!toolCallId) return undefined;
      const status: ToolStatus = event?.error
        ? { resultType: "failure", error: String(event.error) }
        : { resultType: "success" };
      stashStatus(sid, String(event?.toolName ?? ""), String(toolCallId), status);
      return undefined;
    },

    /** Stage 4. Decision hook — rewrites the persisted assistant message. */
    toolResultPersist: async (event: any) => {
      const sid = sessionKey(event?.context ?? event);
      const toolCallId = event?.toolCallId;
      if (!toolCallId) {
        return {
          block: true,
          blockReason:
            "Agent Shield: cannot validate tool output without a toolCallId.",
        };
      }
      return withLease(sid, (sess) => {
        const toolName = String(event?.toolName ?? "");
        const result = dispatcher.validateToolOutput(
          sess,
          toolName,
          event?.result ?? null,
          String(toolCallId),
          mode,
          policy,
        );

        // Drive resource-cycle recording from the after_tool_call
        // scratch (run order: before_tool_call → afterToolCall →
        // tool_result_persist). Falls back to "success" when no
        // status was observed (defensive default).
        const status = popStatus(sid, toolName, String(toolCallId));
        const blocked = result.dispatch.action.kind === "blocked";
        if (blocked || status?.resultType === "failure") {
          const reason = blocked
            ? (result.dispatch.action.kind === "blocked"
                ? (result.dispatch.action as any).message
                : "Stage 4 block")
            : (status?.error ?? "tool failed");
          try {
            sess.recordToolFailure(toolName, String(reason));
          } catch {
            // best-effort — resource-cycle bookkeeping must not
            // break the hook return.
          }
        } else if (result.dispatch.record_success) {
          try {
            sess.recordToolSuccess(toolName, result.effective_output);
          } catch {
            // ignore
          }
        }

        return mapToolOutputOutcome(result, event?.result ?? null);
      });
    },

    /** Stage 5 hard block. Returns a synthetic reply on block. */
    beforeAgentReply: async (event: any) => {
      const sid = sessionKey(event?.context ?? event);
      return withLease(sid, (sess) => {
        const content = String(event?.replyContent ?? event?.content ?? "");
        const result = dispatcher.validateOutput(sess, content, mode, policy);
        return mapStage5OutcomeHard(result, content);
      });
    },

    /**
     * Stage 5 soft remediation. Only used for the "rewrite final
     * answer" path — outright block goes through `before_agent_reply`.
     */
    beforeAgentFinalize: async (event: any) => {
      const sid = sessionKey(event?.context ?? event);
      return withLease(sid, (sess) => {
        const content = String(event?.finalContent ?? event?.content ?? "");
        const result = dispatcher.validateOutput(sess, content, mode, policy);
        return mapStage5OutcomeSoft(result, content);
      });
    },

    /** No-op. Turn opens on `before_agent_run`. */
    sessionStart: async (_event: any) => {
      return undefined;
    },

    /** Close request + turn for the session. */
    sessionEnd: async (event: any) => {
      const sid = sessionKey(event?.context ?? event);
      return withLease(sid, (sess) => {
        const tok = requestTokens.get(sid);
        if (tok !== undefined) {
          sess.endRequest(tok);
          requestTokens.delete(sid);
        }
        if (sess.turnIsOpen()) {
          sess.endTurn();
        }
        toolStatusBySession.delete(sid);
        return undefined;
      });
    },
  };
}

// ── Outcome mapping helpers ──────────────────────────────────────

function mapStage1Outcome(result: any, prompt: string) {
  const action = result.dispatch.action;
  if (action.kind === "proceed") {
    return undefined;
  }
  if (action.kind === "proceed_with_mutation") {
    // Stage 1 mutation: rewrite the user prompt before model input.
    // OpenClaw's before_agent_run only supports `{ outcome: "block"
    // | "pass" }` per current docs; for mutation we fall through to
    // "pass" with the mutated content carried as additional context.
    // Operators wanting strict rewrite can switch to enforce mode +
    // raise policy, which surfaces as block instead.
    return undefined;
  }
  if (result.dispatch.override_to_proceed) {
    // Monitor mode — record the block (observable via core's
    // ObservabilityProvider) and let the run proceed.
    return undefined;
  }
  return {
    outcome: "block",
    reason: "agent-shield-stage-1-block",
    message:
      "kind" in action && action.kind === "raise"
        ? (action as any).message
        : (action as any).message ??
          "blocked by policy (stage 1)",
  };
}

function mapToolCallOutcome(result: any, originalParams: any) {
  const action = result.dispatch.action;
  const params = result.effective_params;
  const out: any = {};
  // Apply mutation independent of dispatch action kind — params can
  // differ from input on no-action transforms.
  if (!deepEqual(params, originalParams)) {
    out.params = params;
  }
  if (action.kind === "blocked" && !result.dispatch.override_to_proceed) {
    out.block = true;
    out.blockReason = (action as any).message ?? "blocked by policy";
  }
  return Object.keys(out).length === 0 ? undefined : out;
}

function mapToolOutputOutcome(result: any, _originalOutput: any) {
  const action = result.dispatch.action;
  if (action.kind === "proceed" && !result.dispatch.record_block) {
    // No mutation needed.
    return undefined;
  }
  if (action.kind === "proceed_with_mutation") {
    // Rewrite the persisted tool result. OpenClaw shape: the hook
    // result owns the assistant message to persist.
    return {
      content: (action as any).value,
    };
  }
  if (action.kind === "blocked" && !result.dispatch.override_to_proceed) {
    return {
      content: (action as any).message ?? "tool output blocked by policy",
    };
  }
  return undefined;
}

function mapStage5OutcomeHard(result: any, original: string) {
  const action = result.dispatch.action;
  if (action.kind === "proceed") return undefined;
  if (action.kind === "proceed_with_mutation") {
    return { content: (action as any).value };
  }
  if (result.dispatch.override_to_proceed) return undefined;
  // Hard block — synthesise a refusal reply.
  return {
    content: (action as any).message ?? "blocked by policy (stage 5)",
  };
}

function mapStage5OutcomeSoft(result: any, _original: string) {
  const action = result.dispatch.action;
  if (action.kind === "proceed_with_mutation") {
    // Ask the harness for another pass with the mutated content as
    // the revision instruction.
    return {
      action: "revise",
      reason: "agent-shield-revision",
      retry: {
        instruction: (action as any).value,
        idempotencyKey: "agent-shield-stage-5-mutation",
        maxAttempts: 1,
      },
    };
  }
  // No revision needed (or block path is handled by
  // before_agent_reply).
  return undefined;
}

function deepEqual(a: any, b: any): boolean {
  if (a === b) return true;
  if (typeof a !== typeof b) return false;
  if (typeof a !== "object" || a === null || b === null) return false;
  if (Array.isArray(a) !== Array.isArray(b)) return false;
  const ka = Object.keys(a);
  const kb = Object.keys(b);
  if (ka.length !== kb.length) return false;
  for (const k of ka) {
    if (!deepEqual(a[k], b[k])) return false;
  }
  return true;
}
