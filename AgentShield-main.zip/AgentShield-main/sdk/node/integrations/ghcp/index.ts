// Agent Shield extension for the GHCP CLI (`@github/copilot-sdk`).
//
// Wraps `joinSession({ hooks, onEvent })` so the five Agent Shield
// stages run against GHCP's typed `SessionHooks` surface. Built
// directly on `@microsoft/agent-shield`'s native binding — no
// per-integration state machinery duplicated.
//
// ## Mapping
//
// | GHCP hook                  | Agent Shield action                          |
// |----------------------------|----------------------------------------------|
// | `onUserPromptSubmitted`    | Stage 1; begin turn + request                |
// | `onPreToolUse`             | Stage 2 + 3 (toolCallId from event stream)   |
// | `onPostToolUse`            | Stage 4 + record success/failure              |
// | `onSessionStart`           | no-op                                        |
// | `onSessionEnd`             | end request + turn                            |
// | `onErrorOccurred`          | recordToolFailure when errorContext is tool  |
//
// ## Tool-call-id correlation
//
// GHCP's `PreToolUseHookInput` / `PostToolUseHookInput` do not carry a
// `toolCallId`. The id is on the `assistant.message` session event
// under `data.toolRequests[*].toolCallId`. This extension subscribes
// to `assistant.message` via `onEvent`, maintains a per-session
// pending queue keyed on `(toolName, canonicalJSON(args))`, and
// resolves the id at `onPreToolUse` time.
//
// Failure modes (documented as known limitations of the GHCP hook
// surface):
// - Event not yet delivered: fail closed with a "timing race"
//   permissionDecision: "deny" so operators can recognise the
//   condition.
// - Identical parallel calls (same name, same canonical args): fail
//   closed with "ambiguous parallel tool calls; rerun".

import {
  HookSessionRegistry,
  StageDispatcher,
} from "../../native.js";
import type { Runtime } from "../../index.js";

export type ShieldMode = "enforce" | "monitor";
export type OnBlockPolicy =
  | "return_blocked"
  | "return_verdict"
  | "raise"
  | "custom";

export interface AgentShieldGhcpOptions {
  runtime: Runtime;
  mode?: ShieldMode;
  policy?: OnBlockPolicy;
  registry?: {
    maxSize?: number;
    ttlSeconds?: number;
    inFlightTimeoutSeconds?: number;
  };
}

interface PendingToolRequest {
  toolCallId: string;
  toolName: string;
  argsKey: string;
}

/**
 * Build GHCP `SessionHooks` + an `onEvent` subscriber that together
 * enforce Agent Shield. Returns:
 *
 * ```ts
 * const shield = createAgentShieldGhcpExtension({ runtime });
 *
 * await client.joinSession({
 *   sessionId,
 *   hooks: shield.hooks,
 *   onEvent: shield.onEvent,
 * });
 * ```
 *
 * The shared correlation state (assistant.message → toolCallId queue)
 * is owned by this extension instance, NOT held inside any Rust lock.
 * Both queue mutation (from `onEvent`) and queue reads (from the
 * hooks) run in Node's single-threaded event loop, so the queue is
 * protected by event-loop ordering without a Rust mutex.
 */
export function createAgentShieldGhcpExtension(opts: AgentShieldGhcpOptions) {
  const mode: ShieldMode = opts.mode ?? "enforce";
  const policy: OnBlockPolicy = opts.policy ?? "return_blocked";
  const registry = new HookSessionRegistry(opts.runtime.native, {
    maxSize: opts.registry?.maxSize ?? 512,
    ttlSeconds: opts.registry?.ttlSeconds ?? 1800,
    inFlightTimeoutSeconds: opts.registry?.inFlightTimeoutSeconds ?? 300,
  });
  const dispatcher = new StageDispatcher();

  // sessionId → pending tool requests, FIFO. Each entry records the
  // toolCallId we observed on `assistant.message` plus a canonical
  // (toolName, argsJson) key for matching by hook input.
  const pendingByCard = new Map<string, PendingToolRequest[]>();
  // sessionId → in-flight request token (cross-hook scope).
  const requestTokens = new Map<string, number>();

  function withLease<T>(sid: string, body: (sess: any) => T): T {
    const sess = registry.acquire(sid, { session_id: sid });
    try {
      return body(sess);
    } finally {
      sess.release();
    }
  }

  function argsCanonicalJson(args: unknown): string {
    // Stable JSON stringify with sorted object keys, so structurally
    // identical args produce identical keys regardless of insertion
    // order.
    return JSON.stringify(args, (_k, v) => {
      if (v && typeof v === "object" && !Array.isArray(v)) {
        return Object.keys(v)
          .sort()
          .reduce((acc: any, k) => {
            acc[k] = (v as any)[k];
            return acc;
          }, {});
      }
      return v;
    });
  }

  function popPending(
    sid: string,
    toolName: string,
    argsKey: string,
  ): { id: string; ambiguous: boolean } | null {
    const queue = pendingByCard.get(sid);
    if (!queue) return null;
    const matches = queue
      .map((q, i) => ({ q, i }))
      .filter(({ q }) => q.toolName === toolName && q.argsKey === argsKey);
    if (matches.length === 0) return null;
    if (matches.length > 1) return { id: "", ambiguous: true };
    const idx = matches[0].i;
    const entry = matches[0].q;
    queue.splice(idx, 1);
    return { id: entry.toolCallId, ambiguous: false };
  }

  return {
    /** Underlying registry exposed for tests / observability. */
    registry,

    /**
     * Subscribe to GHCP session events so we can recover toolCallIds
     * from `assistant.message.toolRequests` (the hook surface doesn't
     * carry them).
     */
    onEvent(event: any) {
      const sessionId = String(event?.sessionId ?? event?.data?.sessionId ?? "");
      if (!sessionId) return;
      if (event?.type !== "assistant.message") return;
      const requests = event?.data?.toolRequests;
      if (!Array.isArray(requests)) return;
      let queue = pendingByCard.get(sessionId);
      if (!queue) {
        queue = [];
        pendingByCard.set(sessionId, queue);
      }
      for (const req of requests) {
        if (!req?.toolCallId || !req?.name) continue;
        queue.push({
          toolCallId: String(req.toolCallId),
          toolName: String(req.name),
          argsKey: argsCanonicalJson(req.arguments ?? {}),
        });
      }
    },

    hooks: {
      /** Stage 1. */
      onUserPromptSubmitted: async (
        input: any,
        invocation: { sessionId: string },
      ) => {
        const sid = invocation.sessionId;
        return withLease(sid, (sess) => {
          // GHCP sessions can contain many user turns. Open a fresh
          // turn for each prompt; if a prior turn never closed (no
          // turn-end hook in GHCP), restart it so per-turn state
          // doesn't leak.
          if (sess.turnIsOpen()) {
            sess.restartTurn();
          } else {
            sess.beginTurn();
          }
          const prior = requestTokens.get(sid);
          if (prior !== undefined) {
            sess.endRequest(prior);
            requestTokens.delete(sid);
          }
          const tok = sess.beginRequest();
          requestTokens.set(sid, tok);

          // Drain any stale pending tool-requests from a prior turn.
          pendingByCard.set(sid, []);

          const prompt = String(input?.prompt ?? "");
          const result = dispatcher.validateInput(sess, prompt, mode, policy);
          return mapStage1Outcome(result, prompt);
        });
      },

      /** Stage 2 + 3. Recovers toolCallId from the pending queue. */
      onPreToolUse: async (
        input: any,
        invocation: { sessionId: string },
      ) => {
        const sid = invocation.sessionId;
        const toolName = String(input?.toolName ?? "");
        const argsKey = argsCanonicalJson(input?.toolArgs ?? {});
        const match = popPending(sid, toolName, argsKey);
        if (!match) {
          return {
            permissionDecision: "deny",
            permissionDecisionReason:
              "Agent Shield: assistant.message event with toolCallId not yet delivered when onPreToolUse fired. Retry.",
          };
        }
        if (match.ambiguous) {
          return {
            permissionDecision: "deny",
            permissionDecisionReason:
              "Agent Shield: ambiguous parallel tool calls (same toolName + args). Re-run with distinct args.",
          };
        }
        const toolCallId = match.id;
        return withLease(sid, (sess) => {
          const result = dispatcher.validateToolCall(
            sess,
            toolName,
            input?.toolArgs ?? {},
            toolCallId,
            mode,
            policy,
          );
          // Push the admitted toolCallId onto a per-toolName FIFO so
          // the matching onPostToolUse can correlate even when
          // multiple admitted calls to the same tool are in flight.
          // Stage 3 admit order matches Stage 4 completion order
          // under sequential execution; parallel execution that
          // re-orders is handled by the Stage 4 same-toolName
          // fail-closed branch. Monitor mode: blocked verdicts that
          // `override_to_proceed` still let the tool run, so they
          // MUST be queued — otherwise Stage 4 would unconditionally
          // fail closed and silently turn monitor mode into
          // enforcement.
          const action = result.dispatch.action;
          const admitted =
            action.kind !== "blocked" || result.dispatch.override_to_proceed;
          if (admitted) {
            const queueKey = `ghcp.pending_tool_call_ids.${toolName}`;
            const existing = sess.turnKvGet(queueKey);
            const queue = Array.isArray(existing) ? [...existing, toolCallId] : [toolCallId];
            sess.turnKvSet(queueKey, queue);
          }
          return mapToolCallOutcome(result, input?.toolArgs ?? {});
        });
      },

      /** Stage 4. */
      onPostToolUse: async (
        input: any,
        invocation: { sessionId: string },
      ) => {
        const sid = invocation.sessionId;
        const toolName = String(input?.toolName ?? "");
        // Recover the matching toolCallId from the per-toolName FIFO
        // queue written by onPreToolUse. When more than one call is
        // queued AND `toolResult` doesn't disambiguate, we fail
        // closed: GHCP's PostToolUseHookInput carries no
        // toolCallId, so we cannot reliably bind to a specific
        // Stage 3 admission.
        return withLease(sid, (sess) => {
          const queueKey = `ghcp.pending_tool_call_ids.${toolName}`;
          const queue = sess.turnKvGet(queueKey);
          if (!Array.isArray(queue) || queue.length === 0) {
            return {
              modifiedResult: {
                textResultForLlm:
                  "Agent Shield: Stage 4 could not bind to a prior Stage 3 invocation; rejecting.",
                resultType: "rejected",
              },
            };
          }
          if (queue.length > 1) {
            // Multiple admitted Stage 3 calls for this tool — we
            // cannot tell which result this is.
            return {
              modifiedResult: {
                textResultForLlm:
                  "Agent Shield: cannot disambiguate Stage 4 tool output among multiple in-flight calls to the same tool. GHCP's onPostToolUse does not expose toolCallId.",
                resultType: "rejected",
              },
            };
          }
          const toolCallId = String(queue[0]);
          // Consume the entry.
          sess.turnKvSet(queueKey, []);

          const toolResult = input?.toolResult;
          // Pass the structured envelope to core so Stage 4 policies
          // / populators can inspect `@result.resultType`,
          // `@result.error`, etc. Core's validate_tool_output already
          // takes a serde_json::Value.
          const structured =
            toolResult && typeof toolResult === "object"
              ? toolResult
              : { textResultForLlm: String(toolResult ?? ""), resultType: "success" };
          const result = dispatcher.validateToolOutput(
            sess,
            toolName,
            structured,
            toolCallId,
            mode,
            policy,
          );

          // Drive resource-cycle recording from GHCP's resultType.
          const blocked = result.dispatch.action.kind === "blocked";
          const failed =
            blocked ||
            (toolResult?.resultType &&
              toolResult.resultType !== "success");
          if (failed) {
            try {
              const reason = blocked
                ? ((result.dispatch.action as any).message ?? "Stage 4 block")
                : (toolResult?.error ?? toolResult?.resultType ?? "tool failed");
              sess.recordToolFailure(toolName, String(reason));
            } catch {
              // best-effort
            }
          } else if (result.dispatch.record_success) {
            try {
              sess.recordToolSuccess(toolName, result.effective_output);
            } catch {
              // best-effort
            }
          }

          return mapToolOutputOutcome(result, structured);
        });
      },

      /** No-op. Turn opens on `onUserPromptSubmitted`. */
      onSessionStart: async (_input: any, _invocation: any) => {
        return undefined;
      },

      /** Close request + turn. */
      onSessionEnd: async (_input: any, invocation: { sessionId: string }) => {
        const sid = invocation.sessionId;
        return withLease(sid, (sess) => {
          const tok = requestTokens.get(sid);
          if (tok !== undefined) {
            sess.endRequest(tok);
            requestTokens.delete(sid);
          }
          if (sess.turnIsOpen()) {
            sess.endTurn();
          }
          pendingByCard.delete(sid);
          return undefined;
        });
      },

      /** Drive `recordToolFailure` on tool-execution errors. */
      onErrorOccurred: async (
        input: any,
        invocation: { sessionId: string },
      ) => {
        if (input?.errorContext !== "tool_execution") return undefined;
        const sid = invocation.sessionId;
        return withLease(sid, (sess) => {
          // We don't know which tool failed at this hook — GHCP's
          // ErrorOccurredHookInput doesn't carry toolName. Skip
          // resource-cycle recording rather than guess; an operator
          // who needs precise telemetry should subscribe to
          // `tool.execution_complete` events instead.
          void sess;
          return undefined;
        });
      },
    },
  };
}

// ── Outcome mapping helpers ──────────────────────────────────────

function mapStage1Outcome(result: any, _prompt: string) {
  const action = result.dispatch.action;
  if (action.kind === "proceed") return undefined;
  if (action.kind === "proceed_with_mutation") {
    return { modifiedPrompt: (action as any).value };
  }
  if (result.dispatch.override_to_proceed) return undefined;
  // GHCP has no deny semantics on user prompts; rewrite the prompt
  // to a refusal note plus an additionalContext explaining the block.
  return {
    modifiedPrompt: `[Agent Shield] ${(action as any).message ?? "blocked"}`,
    additionalContext: (action as any).message ?? "blocked by policy",
  };
}

function mapToolCallOutcome(result: any, originalArgs: any) {
  const action = result.dispatch.action;
  if (action.kind === "blocked" && !result.dispatch.override_to_proceed) {
    return {
      permissionDecision: "deny",
      permissionDecisionReason: (action as any).message ?? "blocked by policy",
    };
  }
  const params = result.effective_params;
  if (!deepEqual(params, originalArgs)) {
    return { modifiedArgs: params };
  }
  return undefined;
}

function mapToolOutputOutcome(result: any, originalResult: any) {
  const action = result.dispatch.action;
  if (action.kind === "proceed" && !result.dispatch.record_block) {
    return undefined;
  }
  // Rebuild the structured ToolResultObject when a mutation or block
  // applies. The Stage 4 effective_output is the *structured* value
  // passed to core, so we preserve any rewritten `textResultForLlm`
  // / `details` it produced; if the original was a flat string we
  // wrap appropriately.
  const base = (originalResult && typeof originalResult === "object")
    ? originalResult
    : { textResultForLlm: String(originalResult ?? ""), resultType: "success" };
  if (action.kind === "proceed_with_mutation") {
    const effective = result.effective_output;
    const merged =
      effective && typeof effective === "object"
        ? { ...base, ...effective }
        : { ...base, textResultForLlm: String(effective ?? "") };
    return { modifiedResult: merged };
  }
  if (action.kind === "blocked" && !result.dispatch.override_to_proceed) {
    return {
      modifiedResult: {
        ...base,
        textResultForLlm: (action as any).message ?? "blocked by policy",
        resultType: "rejected",
      },
    };
  }
  return undefined;
}

function deepEqual(a: any, b: any): boolean {
  if (a === b) return true;
  if (typeof a !== typeof b) return false;
  if (typeof a !== "object" || a === null || b === null) return false;
  if (Array.isArray(a) !== Array.isArray(b)) return false;
  const ka = Object.keys(a);
  const kb = Object.keys(b);
  if (ka.length !== kb.length) return false;
  for (const k of ka) {
    if (!deepEqual(a[k], b[k])) return false;
  }
  return true;
}
