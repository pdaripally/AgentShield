// Verifies that the order of `.withClient(client)` and the adapter
// chooser (`.withLangchain()`, `.withOpenaiAgents()`, `.withAnthropic()`)
// is irrelevant: in both orderings the resulting Shield must have a
// usable LLM caller bound through that adapter's `llmCallerFactory`.
//
// Order-dependent fluent builders are landmines for customers, so this
// is a parity contract across all three adapters.

import { describe, it, expect } from 'vitest'
import * as path from 'node:path'

import { Shield } from '../index.js'

// Side-effect imports register the bundle installers on
// ShieldBuilder.prototype. Import all three so each `.with<Framework>()`
// is available regardless of the test order.
import '../adapters/langchain.js'
import '../adapters/openai_agents.js'
import '../adapters/anthropic_agents.js'

const REPO_ROOT = path.resolve(__dirname, '..', '..', '..')
const MINIMAL = path.join(
  REPO_ROOT,
  'tests',
  'fixtures',
  'smoke',
  'minimal.guardrails.yaml',
)

// Mock LangChain-style client: the adapter's caller factory just needs
// something to wrap; the produced caller is opaque, so any object will
// do for caller-binding observability.
const mockLangchainClient = {
  invoke: async (_input: unknown): Promise<unknown> => ({ content: 'ok' }),
  bindTools: (_tools: unknown[]): unknown => mockLangchainClient,
}

const mockOpenaiClient = {
  responses: {
    create: async (_args: unknown): Promise<unknown> => ({ output: [] }),
  },
}

const mockAnthropicClient = {
  messages: {
    create: async (_args: unknown): Promise<unknown> => ({
      content: [{ type: 'text', text: 'ok' }],
    }),
  },
}

describe('builder client/adapter ordering parity', () => {
  describe('LangChain adapter', () => {
    it('withClient(c).withLangchain() produces a bound LLM caller', () => {
      const builder = (Shield as unknown as typeof Shield)
        .fromYaml(MINIMAL)
        .withClient(mockLangchainClient)
        .withLangchain() as unknown as {
          _llmCaller: ((req: unknown) => unknown) | null
          _pendingLlmClient: unknown
          build: () => Shield
        }
      expect(typeof builder._llmCaller).toBe('function')
      expect(builder._pendingLlmClient).toBeNull()
      expect(builder.build()).toBeInstanceOf(Shield)
    }, 15_000)

    it('withLangchain().withClient(c) produces a bound LLM caller', () => {
      const builder = (Shield as unknown as typeof Shield)
        .fromYaml(MINIMAL)
        .withLangchain()
        .withClient(mockLangchainClient) as unknown as {
          _llmCaller: ((req: unknown) => unknown) | null
          _pendingLlmClient: unknown
          build: () => Shield
        }
      expect(typeof builder._llmCaller).toBe('function')
      expect(builder._pendingLlmClient).toBeNull()
      expect(builder.build()).toBeInstanceOf(Shield)
    })

    it('withLlm(c).withLangchain() (LangChain-flavoured alias) still works', () => {
      const builder = (Shield as unknown as typeof Shield)
        .fromYaml(MINIMAL)
        // withLlm is added by the langchain adapter
        .withLlm(mockLangchainClient)
        .withLangchain() as unknown as {
          _llmCaller: ((req: unknown) => unknown) | null
          _pendingLlmClient: unknown
        }
      expect(typeof builder._llmCaller).toBe('function')
      expect(builder._pendingLlmClient).toBeNull()
    })
  })

  describe('OpenAI Agents adapter', () => {
    it('withClient(c).withOpenaiAgents() produces a bound LLM caller', () => {
      const builder = (Shield as unknown as typeof Shield)
        .fromYaml(MINIMAL)
        .withClient(mockOpenaiClient)
        .withOpenaiAgents() as unknown as {
          _llmCaller: ((req: unknown) => unknown) | null
          _pendingLlmClient: unknown
          build: () => Shield
        }
      expect(typeof builder._llmCaller).toBe('function')
      expect(builder._pendingLlmClient).toBeNull()
      expect(builder.build()).toBeInstanceOf(Shield)
    })

    it('withOpenaiAgents().withClient(c) produces a bound LLM caller', () => {
      const builder = (Shield as unknown as typeof Shield)
        .fromYaml(MINIMAL)
        .withOpenaiAgents()
        .withClient(mockOpenaiClient) as unknown as {
          _llmCaller: ((req: unknown) => unknown) | null
          _pendingLlmClient: unknown
          build: () => Shield
        }
      expect(typeof builder._llmCaller).toBe('function')
      expect(builder._pendingLlmClient).toBeNull()
      expect(builder.build()).toBeInstanceOf(Shield)
    })
  })

  describe('Anthropic adapter', () => {
    it('withClient(c).withAnthropic() produces a bound LLM caller', () => {
      const builder = (Shield as unknown as typeof Shield)
        .fromYaml(MINIMAL)
        .withClient(mockAnthropicClient)
        .withAnthropic() as unknown as {
          _llmCaller: ((req: unknown) => unknown) | null
          _pendingLlmClient: unknown
          build: () => Shield
        }
      expect(typeof builder._llmCaller).toBe('function')
      expect(builder._pendingLlmClient).toBeNull()
      expect(builder.build()).toBeInstanceOf(Shield)
    })

    it('withAnthropic().withClient(c) produces a bound LLM caller', () => {
      const builder = (Shield as unknown as typeof Shield)
        .fromYaml(MINIMAL)
        .withAnthropic()
        .withClient(mockAnthropicClient) as unknown as {
          _llmCaller: ((req: unknown) => unknown) | null
          _pendingLlmClient: unknown
          build: () => Shield
        }
      expect(typeof builder._llmCaller).toBe('function')
      expect(builder._pendingLlmClient).toBeNull()
      expect(builder.build()).toBeInstanceOf(Shield)
    })
  })

  describe('edge cases', () => {
    it('withClient(c) without any adapter stashes the client', () => {
      const builder = (Shield as unknown as typeof Shield)
        .fromYaml(MINIMAL)
        .withClient(mockOpenaiClient) as unknown as {
          _llmCaller: ((req: unknown) => unknown) | null
          _pendingLlmClient: unknown
        }
      // No bundle installed => no caller yet, but the client is NOT
      // silently dropped: it's pending until an adapter is chosen.
      expect(builder._llmCaller).toBeNull()
      expect(builder._pendingLlmClient).toBe(mockOpenaiClient)
    })

    it('switching adapters after withClient rebinds against the latest bundle', () => {
      // First adapter sets bundle + rebinds; switching to another
      // adapter must rebind via the new factory (using the pending
      // slot semantics if the client wasn't reset).
      const b1 = (Shield as unknown as typeof Shield)
        .fromYaml(MINIMAL)
        .withClient(mockAnthropicClient)
        .withAnthropic() as unknown as {
          _llmCaller: ((req: unknown) => unknown) | null
        }
      const c1 = b1._llmCaller
      expect(typeof c1).toBe('function')

      // Re-binding via a fresh withClient on the same builder still
      // honours the currently-installed bundle.
      const rebound = (b1 as unknown as { withClient(c: unknown): unknown })
        .withClient(mockAnthropicClient) as unknown as {
          _llmCaller: ((req: unknown) => unknown) | null
        }
      expect(typeof rebound._llmCaller).toBe('function')
    })
  })
})
