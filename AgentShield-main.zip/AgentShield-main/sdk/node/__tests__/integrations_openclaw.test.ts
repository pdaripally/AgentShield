import { describe, it, expect } from 'vitest'
import * as path from 'path'
import { RuntimeBuilder } from '../index.js'
import { createAgentShieldOpenClawPlugin } from '../integrations/openclaw/index.js'

const FIXTURES = path.resolve(__dirname, '../../../tests/fixtures/smoke')
const MINIMAL = path.join(FIXTURES, 'minimal.guardrails.yaml')
// `redact.guardrails.yaml` only validates Stage 5 output; tool calls
// pass through cleanly so we can exercise the Stage 2/3 + Stage 4
// happy-path without setting up authorization variables.
const PERMISSIVE = path.join(FIXTURES, 'redact.guardrails.yaml')

describe('OpenClaw plugin', () => {
  it('exposes the canonical hook handlers', () => {
    const rt = RuntimeBuilder.fromYaml(MINIMAL).build()
    const shield = createAgentShieldOpenClawPlugin({ runtime: rt })
    expect(typeof shield.beforeAgentRun).toBe('function')
    expect(typeof shield.beforeToolCall).toBe('function')
    expect(typeof shield.afterToolCall).toBe('function')
    expect(typeof shield.toolResultPersist).toBe('function')
    expect(typeof shield.beforeAgentReply).toBe('function')
    expect(typeof shield.beforeAgentFinalize).toBe('function')
    expect(typeof shield.sessionStart).toBe('function')
    expect(typeof shield.sessionEnd).toBe('function')
  })

  it('Stage 1 allows clean prompts and returns undefined', async () => {
    const rt = RuntimeBuilder.fromYaml(MINIMAL).build()
    const shield = createAgentShieldOpenClawPlugin({ runtime: rt })
    const result = await shield.beforeAgentRun({
      context: { sessionId: 'oc-test-1' },
      prompt: 'hello',
    })
    expect(result).toBeUndefined()
  })

  it('Stage 2/3 requires a toolCallId (§16.0 binding)', async () => {
    const rt = RuntimeBuilder.fromYaml(MINIMAL).build()
    const shield = createAgentShieldOpenClawPlugin({ runtime: rt })
    await shield.beforeAgentRun({
      context: { sessionId: 'oc-test-2' },
      prompt: 'hi',
    })
    const result = await shield.beforeToolCall({
      context: { sessionId: 'oc-test-2' },
      toolName: 'echo',
      params: {},
      // toolCallId intentionally absent
    })
    expect(result).toMatchObject({ block: true })
    expect((result as any).blockReason).toContain('toolCallId')
  })

  it('Stage 2/3 allows with toolCallId; Stage 4 records success', async () => {
    const rt = RuntimeBuilder.fromYaml(PERMISSIVE).build()
    const shield = createAgentShieldOpenClawPlugin({ runtime: rt })
    const ctx = { context: { sessionId: 'oc-test-3' } }
    await shield.beforeAgentRun({ ...ctx, prompt: 'hi' })
    const r1 = await shield.beforeToolCall({
      ...ctx,
      toolName: 'echo',
      params: { msg: 'hi' },
      toolCallId: 'oc-call-1',
    })
    expect(r1).toBeUndefined()
    // after_tool_call observation (success)
    await shield.afterToolCall({
      ...ctx,
      toolName: 'echo',
      toolCallId: 'oc-call-1',
    })
    const r2 = await shield.toolResultPersist({
      ...ctx,
      toolName: 'echo',
      toolCallId: 'oc-call-1',
      result: 'hi back',
    })
    // Clean allow returns undefined (no rewrite).
    expect(r2).toBeUndefined()
    await shield.sessionEnd(ctx)
  })

  it('session_end cleans up request + turn', async () => {
    const rt = RuntimeBuilder.fromYaml(MINIMAL).build()
    const shield = createAgentShieldOpenClawPlugin({ runtime: rt })
    const ctx = { context: { sessionId: 'oc-test-4' } }
    await shield.beforeAgentRun({ ...ctx, prompt: 'hi' })
    await shield.sessionEnd(ctx)
    // Second sessionEnd is idempotent.
    await shield.sessionEnd(ctx)
  })
})
