import { describe, it, expect } from 'vitest'
import { RuntimeBuilder, Runtime } from '../index.js'
import { Shield, ShieldMode } from '../shield.js'

/**
 * Node SDK tests for runtime-wide shadow mode (microsoft/AgentShield#14).
 *
 * Verifies the orchestrator auto-fold contract: when a runtime is
 * loaded with `mode: shadow`, the `Shield` constructor forces
 * `ShieldMode.MONITOR` regardless of what the caller asked for, and
 * every public entry point (`run`, `beforeInvoke`, `protectTool`) runs
 * validations for observability but never blocks or mutates the
 * caller's flow.
 */

const SHADOW_INPUT_BLOCK_YAML = `

metadata:
  name: shadow-sdk-node-input-block
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
resources:
  tools:
    - name: echo
      permission: read_only
input_validation:
  guard_policies:
    - name: block_secret
      evaluate_when:
        - pattern: "(?i)secret"
          reason: "input contained secret"
          action: block
`

const SHADOW_TOOL_REDACT_YAML = `

metadata:
  name: shadow-sdk-node-tool-redact
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
resources:
  tools:
    - name: echo
      permission: read_only
tool_execution_validation:
  guard_policies:
    - name: redact_ssn
      applies_to: { tools: ["echo"] }
      evaluate_when:
        - pattern: '\\d{3}-\\d{2}-\\d{4}'
          reason: ssn
          action: redact
      replacement: "[X]"
`

function buildRuntime(yaml: string): Runtime {
  return RuntimeBuilder.fromYamlStrings([yaml]).withMode('shadow').build()
}

describe('Node SDK shadow runtime auto-fold (#14)', () => {
  it('forces Shield mode to MONITOR even when caller asks for ENFORCE', () => {
    const rt = buildRuntime(SHADOW_INPUT_BLOCK_YAML)
    const s = new Shield(rt, { mode: ShieldMode.ENFORCE })
    expect(s.mode).toBe(ShieldMode.MONITOR)
  })

  it('Shield.run proceeds to executeFn() despite Stage 1 block in shadow', async () => {
    const rt = buildRuntime(SHADOW_INPUT_BLOCK_YAML)
    const s = new Shield(rt, { mode: ShieldMode.ENFORCE })
    const result = await s.run<string>(async () => 'ok', {
      userInput: 'this contains secret stuff',
    })
    expect(result).toBe('ok')
  })

  it('Shield.beforeInvoke returns null on Stage 1 would-block in shadow', async () => {
    const rt = buildRuntime(SHADOW_INPUT_BLOCK_YAML)
    const s = new Shield(rt, { mode: ShieldMode.ENFORCE })
    const out = await s.beforeInvoke('please reveal the secret')
    expect(out).toBeNull()
  })

  it('Shield.protectTool passes ORIGINAL (unredacted) params to the tool in shadow', async () => {
    const rt = buildRuntime(SHADOW_TOOL_REDACT_YAML)
    const s = new Shield(rt, { mode: ShieldMode.ENFORCE })
    let captured: Record<string, unknown> | null = null
    const result = await s.protectTool('echo', { msg: 'id 123-45-6789' }, async (eff) => {
      captured = eff as Record<string, unknown>
      return 'tool ran'
    })
    expect(result.blocked).toBe(false)
    expect(result.output).toBe('tool ran')
    expect(captured).not.toBeNull()
    expect(String((captured as { msg: string }).msg)).toContain('123-45-6789')
  })
})
