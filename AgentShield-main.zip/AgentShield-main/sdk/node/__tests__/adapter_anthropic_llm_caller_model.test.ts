// LLM-caller model resolution tests for the Anthropic Agents Node adapter.
//
// Mirrors `adapter_openai_llm_caller_model.test.ts` (the parity
// contract — bumping one side without the other is a bug). Asserts
// that `.guardrails.yaml` `configurations[]` entries actually drive
// which model / max_tokens the Stage 1/3/5 LLM judge uses on the
// Anthropic side — i.e. that a
// `configurations: [{id: stage3-judge, type: llm, model: claude-3-7-sonnet}]`
// entry is *not* silently overridden by a hard-coded fallback.

import { afterAll, beforeAll, describe, it, expect } from 'vitest'
import * as fs from 'node:fs'
import * as path from 'node:path'
import { ConfigurationMissingModelError, RuntimeBuilder, Shield } from '../index.js'
import {
  ANTHROPIC_AGENTS_BUNDLE,
  DEFAULT_FALLBACK_MAX_TOKENS,
  install,
  makeLlmCaller,
} from '../adapters/anthropic_agents.js'

install()

const MULTI_CONFIG_YAML = `metadata:
  name: anthropic-llm-caller-model-fixture
  version: 0.1.0
  agent_shield_version: "2.0"
objective:
  goal: ["exercise configurations[] routing"]
  forbidden: ["bypass"]
configurations:
  - id: stage1-judge
    type: llm
    provider: anthropic.messages
    model: claude-3-7-sonnet-20250219
    max_tokens: 256
  - id: stage3-judge
    type: llm
    provider: anthropic.messages
    model: claude-3-5-haiku-latest
input_validation:
  guard_policies:
    - name: trivial_input_guard
      evaluate_when:
        - patterns: ["jailbreak"]
          reason: "jailbreak attempt"
      action: "block"
`

// Project-local temp dir (the agent runtime sandbox forbids /tmp).
//
// Each test file owns its own subdirectory under `.tmp-fixtures/`
// so the OpenAI and Anthropic suites can run in parallel without
// one's `afterAll` rmSync racing the other's `beforeAll` mkdirSync.
const FIXTURE_DIR = path.resolve(__dirname, '.tmp-fixtures', 'anthropic')
const FIXTURE_PATH = path.join(
  FIXTURE_DIR,
  'anthropic_llm_caller_model.guardrails.yaml',
)

beforeAll(() => {
  fs.mkdirSync(FIXTURE_DIR, { recursive: true })
  fs.writeFileSync(FIXTURE_PATH, MULTI_CONFIG_YAML, 'utf8')
})

afterAll(() => {
  try {
    // Only remove this suite's own subdirectory — the shared
    // `.tmp-fixtures/` parent is owned by neither suite.
    fs.rmSync(FIXTURE_DIR, { recursive: true, force: true })
  } catch {
    /* ignore */
  }
})

interface RecordedCall {
  model: string
  messages: unknown
  max_tokens?: number
  temperature?: number
  [key: string]: unknown
}

function makeFakeClient(): {
  client: {
    messages: { create: (args: any) => Promise<any> }
    beta?: { messages?: { toolRunner?: any } }
  }
  calls: RecordedCall[]
} {
  const calls: RecordedCall[] = []
  const client = {
    messages: {
      create: async (args: RecordedCall) => {
        calls.push(args)
        return {
          content: [{ type: 'text', text: 'ok' }],
        }
      },
    },
  }
  return { client, calls }
}

function buildRuntime(yaml: string) {
  return RuntimeBuilder.fromYamlStrings([yaml]).build()
}

// ────────────────────────────────────────────────────────────────────
// LLM-caller model selection (module-level `makeLlmCaller`)
// ────────────────────────────────────────────────────────────────────

describe('Anthropic makeLlmCaller — configurationResolver wiring', () => {
  it('uses the YAML-declared model + max_tokens for each configurationId', async () => {
    const rt = buildRuntime(MULTI_CONFIG_YAML)
    const { client, calls } = makeFakeClient()

    const caller = makeLlmCaller(client, {
      configurationResolver: (id) => rt.llmConfiguration(id ?? ''),
    })

    await caller({ configurationId: 'stage1-judge', prompt: 'is the input safe?' })
    await caller({ configurationId: 'stage3-judge', prompt: 'is the tool call safe?' })

    expect(calls).toHaveLength(2)
    expect(calls[0].model).toBe('claude-3-7-sonnet-20250219')
    expect(calls[0].max_tokens).toBe(256)
    expect(calls[1].model).toBe('claude-3-5-haiku-latest')
    // YAML has no `max_tokens` for stage3-judge => fall back to the
    // adapter default. The token budget is not security-sensitive
    // (unlike model selection), so defaulting it is acceptable —
    // Anthropic's Messages API rejects requests without max_tokens.
    expect(calls[1].max_tokens).toBe(DEFAULT_FALLBACK_MAX_TOKENS)
  })

  it('raises ConfigurationMissingModelError when no matching configuration', async () => {
    const rt = buildRuntime(MULTI_CONFIG_YAML)
    const { client, calls } = makeFakeClient()

    const caller = makeLlmCaller(client, {
      configurationResolver: (id) => rt.llmConfiguration(id ?? ''),
    })

    await expect(
      caller({ configurationId: 'not-in-yaml', prompt: 'judge me' }),
    ).rejects.toThrow(ConfigurationMissingModelError)

    expect(calls).toHaveLength(0)
  })

  it('raises when no resolver is wired', async () => {
    const { client, calls } = makeFakeClient()
    const caller = makeLlmCaller(client)
    await expect(
      caller({ configurationId: 'stage1-judge', prompt: 'prompt' }),
    ).rejects.toThrow(ConfigurationMissingModelError)
    expect(calls).toHaveLength(0)
  })

  it('raises when configurationId is null', async () => {
    const rt = buildRuntime(MULTI_CONFIG_YAML)
    const { client, calls } = makeFakeClient()

    const caller = makeLlmCaller(client, {
      configurationResolver: (id) => rt.llmConfiguration(id ?? ''),
    })

    await expect(
      caller({ configurationId: null, prompt: 'prompt' }),
    ).rejects.toThrow(ConfigurationMissingModelError)
    expect(calls).toHaveLength(0)
  })

  it('honours explicit `opts.maxTokens` as the fallback when YAML omits max_tokens', async () => {
    // The numeric max_tokens budget is NOT security-sensitive (unlike
    // model selection); customers may override the adapter default
    // via `opts.maxTokens` for caller-driven budget caps. Stage1 has
    // its own max_tokens in YAML and must NOT be overridden.
    const rt = buildRuntime(MULTI_CONFIG_YAML)
    const { client, calls } = makeFakeClient()

    const caller = makeLlmCaller(client, {
      configurationResolver: (id) => rt.llmConfiguration(id ?? ''),
      maxTokens: 4096,
    })

    await caller({ configurationId: 'stage1-judge', prompt: 'prompt' })
    await caller({ configurationId: 'stage3-judge', prompt: 'prompt' })

    expect(calls[0].max_tokens).toBe(256) // YAML wins
    expect(calls[1].max_tokens).toBe(4096) // opts override the default
  })

  it('raises (and records the resolver error) when the resolver throws', async () => {
    const { client, calls } = makeFakeClient()
    const adapterErrors: unknown[] = []

    const caller = makeLlmCaller(client, {
      configurationResolver: () => {
        throw new Error('boom')
      },
      recordAdapterError: (err) => adapterErrors.push(err),
    })

    await expect(
      caller({ configurationId: 'stage1-judge', prompt: 'prompt' }),
    ).rejects.toThrow(ConfigurationMissingModelError)

    expect(calls).toHaveLength(0)
    const messages = adapterErrors.map((e) =>
      e instanceof Error ? e.message : String(e),
    )
    expect(messages.some((m) => m.includes('configurationResolver raised'))).toBe(true)
    expect(messages.some((m) => m.includes('boom'))).toBe(true)
  })

  it('forwards optional scalar fields (temperature, top_p, stop_sequences) when present on the resolved configuration', async () => {
    // We don't put these fields in YAML because the loader's
    // `ShieldConfiguration` schema rejects unknown keys. Instead we
    // hand-roll the resolver to return them through the
    // `LlmConfiguration` open index signature — same shape the
    // resolver-side runtime would surface once those fields are
    // added to the spec, and the same code path the adapter exercises.
    const { client, calls } = makeFakeClient()
    const caller = makeLlmCaller(client, {
      configurationResolver: () => ({
        id: 'with-extras',
        type: 'llm',
        model: 'claude-3-5-haiku-latest',
        maxTokens: 128,
        temperature: 0.4,
        topP: 0.9,
        stopSequences: ['END_OF_JUDGMENT'],
      }),
    })

    await caller({ configurationId: 'with-extras', prompt: 'prompt' })
    expect(calls[0].model).toBe('claude-3-5-haiku-latest')
    expect(calls[0].max_tokens).toBe(128)
    expect(calls[0].temperature).toBe(0.4)
    expect(calls[0].top_p).toBe(0.9)
    expect(calls[0].stop_sequences).toEqual(['END_OF_JUDGMENT'])
  })
})

// ────────────────────────────────────────────────────────────────────
// ShieldBuilder integration — the resolver is wired through build()
// ────────────────────────────────────────────────────────────────────

describe('Anthropic ShieldBuilder wires the resolver through build()', () => {
  it('caller honours YAML configurations after build()', async () => {
    const { client, calls } = makeFakeClient()

    const builder = Shield.fromYaml(FIXTURE_PATH)
      .withAnthropic()
      .withClient(client)

    const boundCaller = (builder as unknown as {
      _llmCaller: ((req: unknown) => unknown) | null
    })._llmCaller
    expect(boundCaller).not.toBeNull()

    builder.build()
    const fn = boundCaller as (req: unknown) => Promise<string>
    await fn({ configurationId: 'stage1-judge', prompt: 'prompt' })
    await fn({ configurationId: 'stage3-judge', prompt: 'prompt' })

    expect(calls.at(-2)?.model).toBe('claude-3-7-sonnet-20250219')
    expect(calls.at(-2)?.max_tokens).toBe(256)
    expect(calls.at(-1)?.model).toBe('claude-3-5-haiku-latest')
  })

  it('client wired BEFORE withAnthropic() (pending-rebind path) also gets the resolver', async () => {
    const { client, calls } = makeFakeClient()

    const builder = Shield.fromYaml(FIXTURE_PATH)
      .withClient(client)
      .withAnthropic()

    builder.build()

    const fn = (
      builder as unknown as { _llmCaller: (req: unknown) => Promise<string> }
    )._llmCaller

    await fn({ configurationId: 'stage1-judge', prompt: 'prompt' })
    expect(calls[0].model).toBe('claude-3-7-sonnet-20250219')
    expect(calls[0].max_tokens).toBe(256)
  })
})

// Sanity — the ANTHROPIC_AGENTS_BUNDLE is what the prototype patch
// installs; confirm the factory it exposes wires the resolver
// through the adapter context.
describe('ANTHROPIC_AGENTS_BUNDLE.llmCallerFactory', () => {
  it('forwards ctx.configurationResolver to the caller closure', async () => {
    const { client, calls } = makeFakeClient()
    const calledIds: string[] = []
    const caller = ANTHROPIC_AGENTS_BUNDLE.llmCallerFactory!.makeCaller(client, {
      recordAdapterError: () => {},
      configurationResolver: (id) => {
        calledIds.push(String(id))
        if (id === 'stage1-judge') {
          return {
            id: 'stage1-judge',
            type: 'llm',
            model: 'claude-from-resolver',
            maxTokens: 99,
          }
        }
        return null
      },
    }) as (req: unknown) => Promise<string>

    await caller({ configurationId: 'stage1-judge', prompt: 'prompt' })
    expect(calledIds).toContain('stage1-judge')
    expect(calls[0].model).toBe('claude-from-resolver')
    expect(calls[0].max_tokens).toBe(99)
  })
})
