// LLM-caller model resolution tests for the OpenAI Agents Node adapter.
//
// Asserts that `.guardrails.yaml` `configurations[]` entries actually
// drive which model the Stage 1/3/5 LLM judge uses — i.e. that a
// `configurations: [{id: stage3-judge, type: llm, model: gpt-4o}]`
// entry is *not* silently overridden by a hard-coded fallback. See
// the `node-remove-hardcoded-model` task for context and the Python
// counterpart `tests/test_oai_agents_llm_caller_model.py` for the
// parity contract.

import { afterAll, beforeAll, describe, it, expect } from 'vitest'
import * as fs from 'node:fs'
import * as path from 'node:path'
import { ConfigurationMissingModelError, RuntimeBuilder, Shield } from '../index.js'
import {
  OPENAI_BUNDLE,
  install,
  makeLlmCaller,
} from '../adapters/openai_agents.js'

install()

// A minimal valid guardrails YAML with two distinct LLM configurations.
// The runtime doesn't have to actually route through these for the
// test — we only need the merged config to expose them via
// `runtime.llmConfiguration`.
const MULTI_CONFIG_YAML = `metadata:
  name: oai-llm-caller-model-fixture
  version: 0.1.0
  agent_shield_version: "2.0"
objective:
  goal: ["exercise configurations[] routing"]
  forbidden: ["bypass"]
configurations:
  - id: stage1-judge
    type: llm
    provider: openai.chat
    model: gpt-4o
    max_tokens: 256
  - id: stage3-judge
    type: llm
    provider: openai.chat
    model: gpt-4o-mini-with-context
input_validation:
  guard_policies:
    - name: trivial_input_guard
      evaluate_when:
        - patterns: ["jailbreak"]
          reason: "jailbreak attempt"
      action: "block"
`

// Use a project-local temp directory so we don't write under /tmp
// (forbidden by the agent runtime sandbox). `os.tmpdir()` is
// intentionally avoided.
//
// Each test file owns its own subdirectory under `.tmp-fixtures/`
// so the OpenAI and Anthropic suites can run in parallel without
// one's `afterAll` rmSync racing the other's `beforeAll` mkdirSync.
const FIXTURE_DIR = path.resolve(__dirname, '.tmp-fixtures', 'openai')
const FIXTURE_PATH = path.join(FIXTURE_DIR, 'oai_llm_caller_model.guardrails.yaml')

beforeAll(() => {
  fs.mkdirSync(FIXTURE_DIR, { recursive: true })
  fs.writeFileSync(FIXTURE_PATH, MULTI_CONFIG_YAML, 'utf8')
})

afterAll(() => {
  try {
    // Only remove this suite's own subdirectory — the shared
    // `.tmp-fixtures/` parent is owned by neither suite.
    fs.rmSync(FIXTURE_DIR, { recursive: true, force: true })
  } catch {
    /* ignore */
  }
})

interface RecordedCall {
  model: string
  messages: unknown
  max_tokens?: number
  [key: string]: unknown
}

function makeFakeClient(): {
  client: { chat: { completions: { create: (args: any) => Promise<any> } } }
  calls: RecordedCall[]
} {
  const calls: RecordedCall[] = []
  const client = {
    chat: {
      completions: {
        create: async (args: RecordedCall) => {
          calls.push(args)
          return {
            choices: [{ message: { content: 'ok' } }],
          }
        },
      },
    },
  }
  return { client, calls }
}

function buildRuntime(yaml: string) {
  return RuntimeBuilder.fromYamlStrings([yaml]).build()
}

// ────────────────────────────────────────────────────────────────────
// Runtime.llmConfiguration accessor
// ────────────────────────────────────────────────────────────────────

describe('Runtime.llmConfiguration', () => {
  it('returns the camelCased YAML configuration for a known id', () => {
    const rt = buildRuntime(MULTI_CONFIG_YAML)
    const cfg = rt.llmConfiguration('stage1-judge')
    expect(cfg).not.toBeNull()
    expect(cfg!.id).toBe('stage1-judge')
    expect(cfg!.type).toBe('llm')
    expect(cfg!.model).toBe('gpt-4o')
    // Snake-case `max_tokens` in YAML must surface as camel-case
    // `maxTokens` on the JS side — that's the contract adapters rely
    // on when assembling the kwargs they hand to the OpenAI SDK.
    expect(cfg!.maxTokens).toBe(256)
  })

  it('returns null for an unknown id', () => {
    const rt = buildRuntime(MULTI_CONFIG_YAML)
    expect(rt.llmConfiguration('does-not-exist')).toBeNull()
  })
})

// ────────────────────────────────────────────────────────────────────
// LLM-caller model selection (module-level `makeLlmCaller`)
// ────────────────────────────────────────────────────────────────────

describe('makeLlmCaller — configurationResolver wiring', () => {
  it('uses the YAML-declared model for each configurationId', async () => {
    const rt = buildRuntime(MULTI_CONFIG_YAML)
    const { client, calls } = makeFakeClient()

    const caller = makeLlmCaller(client, {
      configurationResolver: (id) => rt.llmConfiguration(id ?? ''),
    })

    await caller({ configurationId: 'stage1-judge', prompt: 'is the input safe?' })
    await caller({ configurationId: 'stage3-judge', prompt: 'is the tool call safe?' })

    expect(calls).toHaveLength(2)
    expect(calls[0].model).toBe('gpt-4o')
    // max_tokens from stage1-judge YAML entry must propagate through
    // as the SDK kwarg — that's how customers pin context-window /
    // cost ceilings per stage.
    expect(calls[0].max_tokens).toBe(256)
    expect(calls[1].model).toBe('gpt-4o-mini-with-context')
    // No max_tokens in YAML for stage3-judge => kwarg must NOT be set.
    expect(calls[1].max_tokens).toBeUndefined()
  })

  it('raises ConfigurationMissingModelError when no matching configuration', async () => {
    const rt = buildRuntime(MULTI_CONFIG_YAML)
    const { client, calls } = makeFakeClient()
    const adapterErrors: unknown[] = []

    const caller = makeLlmCaller(client, {
      configurationResolver: (id) => rt.llmConfiguration(id ?? ''),
      recordAdapterError: (err) => adapterErrors.push(err),
    })

    // A security library MUST NOT pick a model on the customer's
    // behalf — missing configuration raises a typed error rather
    // than silently falling back.
    await expect(
      caller({ configurationId: 'not-in-yaml', prompt: 'judge me' }),
    ).rejects.toThrow(ConfigurationMissingModelError)

    // The OpenAI client must not have been called.
    expect(calls).toHaveLength(0)
  })

  it('raises when no resolver is wired', async () => {
    const { client, calls } = makeFakeClient()
    const caller = makeLlmCaller(client)
    await expect(
      caller({ configurationId: 'stage1-judge', prompt: 'prompt' }),
    ).rejects.toThrow(ConfigurationMissingModelError)
    expect(calls).toHaveLength(0)
  })

  it('raises when configurationId is null', async () => {
    // No routing requested — there is no silent fallback. The
    // customer must declare the model in YAML or the caller raises.
    const { client, calls } = makeFakeClient()

    const caller = makeLlmCaller(client, {
      configurationResolver: () => null,
    })

    await expect(
      caller({ configurationId: null, prompt: 'prompt' }),
    ).rejects.toThrow(ConfigurationMissingModelError)
    await expect(
      caller({ configurationId: '' as unknown as null, prompt: 'prompt' }),
    ).rejects.toThrow(ConfigurationMissingModelError)

    expect(calls).toHaveLength(0)
  })

  it('raises when resolver returns null for a non-empty configurationId', async () => {
    // The genuine SRE signal: "customer asked for routing and didn't
    // get it." Surfaces as a typed error so silent model
    // mis-routing is impossible.
    const { client } = makeFakeClient()

    const caller = makeLlmCaller(client, {
      configurationResolver: () => null,
    })

    await expect(
      caller({ configurationId: 'unknown', prompt: 'prompt' }),
    ).rejects.toThrow(ConfigurationMissingModelError)
  })

  it('raises (and records the resolver error) when the resolver throws', async () => {
    const { client, calls } = makeFakeClient()
    const adapterErrors: unknown[] = []

    const caller = makeLlmCaller(client, {
      configurationResolver: () => {
        throw new Error('boom')
      },
      recordAdapterError: (err) => adapterErrors.push(err),
    })

    // A broken resolver is treated like "no entry" — typed error
    // and no silent fallback.
    await expect(
      caller({ configurationId: 'stage1-judge', prompt: 'prompt' }),
    ).rejects.toThrow(ConfigurationMissingModelError)

    expect(calls).toHaveLength(0)

    // The resolver exception is surfaced through observability so
    // SREs see a distinct signal beyond the missing-model error.
    const messages = adapterErrors.map((e) =>
      e instanceof Error ? e.message : String(e),
    )
    expect(messages.some((m) => m.includes('configurationResolver raised'))).toBe(true)
    expect(messages.some((m) => m.includes('boom'))).toBe(true)
  })
})

// ────────────────────────────────────────────────────────────────────
// ShieldBuilder integration — the resolver is wired through build()
// ────────────────────────────────────────────────────────────────────

describe('ShieldBuilder wires the resolver through build()', () => {
  it('caller honours YAML configurations after build()', async () => {
    const { client, calls } = makeFakeClient()

    const builder = Shield.fromYaml(FIXTURE_PATH)
      .withOpenaiAgents()
      .withClient(client)

    // Reach into the builder to grab the actually-wired LLM caller
    // (the same closure `RuntimeBuilder.registerLlmCaller` receives,
    // which is what the napi runtime invokes for every stage).
    const boundCaller = (builder as unknown as {
      _llmCaller: ((req: unknown) => unknown) | null
    })._llmCaller
    expect(boundCaller).not.toBeNull()

    builder.build()
    // After build() the holder is populated. Drive the bound caller
    // and confirm it now resolves through `Runtime.llmConfiguration`.
    const fn = boundCaller as (req: unknown) => Promise<string>
    await fn({ configurationId: 'stage1-judge', prompt: 'prompt' })
    await fn({ configurationId: 'stage3-judge', prompt: 'prompt' })

    expect(calls.at(-2)?.model).toBe('gpt-4o')
    expect(calls.at(-2)?.max_tokens).toBe(256)
    expect(calls.at(-1)?.model).toBe('gpt-4o-mini-with-context')
  })

  it('builder bound BEFORE build() raises; AFTER build() honours YAML', async () => {
    // Regression: the holder must NOT be populated pre-build() —
    // otherwise the runtime accessor would be called before the
    // runtime exists. Pre-build, the resolver returns null and the
    // caller raises ConfigurationMissingModelError (no silent
    // fallback).
    const { client, calls } = makeFakeClient()

    const builder = Shield.fromYaml(FIXTURE_PATH)
      .withOpenaiAgents()
      .withClient(client)

    const fn = (
      builder as unknown as {
        _llmCaller: (req: unknown) => Promise<string>
      }
    )._llmCaller

    // Pre-build call — holder is empty.
    await expect(
      fn({ configurationId: 'stage1-judge', prompt: 'prompt' }),
    ).rejects.toThrow(ConfigurationMissingModelError)

    builder.build()

    // Post-build call — holder dispatches through the runtime.
    await fn({ configurationId: 'stage1-judge', prompt: 'prompt' })
    expect(calls[0].model).toBe('gpt-4o')
  })

  it('client wired BEFORE withOpenaiAgents() (pending-rebind path) also gets the resolver', async () => {
    // Exercises `_pendingLlmClient` + `_rebindPendingLlmClient`:
    // bundle absent at `withClient()` time, so the client is
    // stashed; `withOpenaiAgents()` then rebinds through the
    // freshly-installed bundle's factory. The resolver must reach
    // the freshly-built closure exactly the same way.
    const { client, calls } = makeFakeClient()

    const builder = Shield.fromYaml(FIXTURE_PATH)
      .withClient(client)
      .withOpenaiAgents()

    builder.build()

    const fn = (
      builder as unknown as {
        _llmCaller: (req: unknown) => Promise<string>
      }
    )._llmCaller

    await fn({ configurationId: 'stage1-judge', prompt: 'prompt' })
    expect(calls[0].model).toBe('gpt-4o')
    expect(calls[0].max_tokens).toBe(256)
  })

  it('surfaces resolver lookup errors through observability providers', async () => {
    // Forces the resolver path to throw (by monkey-patching the
    // populated holder) and asserts the resulting adapter error
    // reaches every registered observability provider. Mirrors the
    // `recordAdapterError` invariant — the failure surfaces as a
    // distinct `adapter.llm_caller_error` signal *and* the call
    // raises ConfigurationMissingModelError because a broken
    // resolver is treated like "no entry".
    const { client, calls } = makeFakeClient()

    const events: Array<Record<string, unknown>> = []
    const provider = (e: unknown): void => {
      events.push(e as Record<string, unknown>)
    }

    const builder = Shield.fromYaml(FIXTURE_PATH)
      .withOpenaiAgents()
      .withClient(client)
      .withObservability(provider)

    builder.build()

    // Replace the resolver holder with one that throws — simulates
    // a corrupt runtime / accessor regression.
    ;(
      builder as unknown as {
        _configurationResolverLookup:
          | ((id: string) => unknown)
          | null
      }
    )._configurationResolverLookup = () => {
      throw new Error('synthetic resolver failure')
    }

    const fn = (
      builder as unknown as {
        _llmCaller: (req: unknown) => Promise<string>
      }
    )._llmCaller

    // The call must raise — a security library MUST NOT pick a
    // model when the resolver fails.
    await expect(
      fn({ configurationId: 'stage1-judge', prompt: 'prompt' }),
    ).rejects.toThrow(ConfigurationMissingModelError)

    expect(calls).toHaveLength(0)

    // And the adapter error must have flowed through observability.
    expect(events.length).toBeGreaterThan(0)
    const errorEvent = events.find(
      (e) => e.eventType === 'adapter.llm_caller_error',
    )
    expect(errorEvent).toBeDefined()
    const message = String(errorEvent?.message ?? '')
    expect(message).toContain('synthetic resolver failure')
  })
})

// Sanity — the OPENAI_BUNDLE is what the prototype patch installs;
// confirm the factory it exposes wires the resolver through the
// adapter context. (Defensive, in case install() is ever changed
// to construct a different bundle.)
describe('OPENAI_BUNDLE.llmCallerFactory', () => {
  it('forwards ctx.configurationResolver to the caller closure', async () => {
    const { client, calls } = makeFakeClient()
    const calledIds: string[] = []
    const caller = OPENAI_BUNDLE.llmCallerFactory!.makeCaller(client, {
      recordAdapterError: () => {},
      configurationResolver: (id) => {
        calledIds.push(String(id))
        if (id === 'stage1-judge') {
          return { id: 'stage1-judge', type: 'llm', model: 'gpt-from-resolver' }
        }
        return null
      },
    }) as (req: unknown) => Promise<string>

    await caller({ configurationId: 'stage1-judge', prompt: 'prompt' })
    expect(calledIds).toContain('stage1-judge')
    expect(calls[0].model).toBe('gpt-from-resolver')
  })
})

// ────────────────────────────────────────────────────────────────────
// Azure-OpenAI routing (§6.2)
// ────────────────────────────────────────────────────────────────────
//
// `model:` is the identifier passed verbatim to the provider SDK. On
// Azure OpenAI providers (`azure_openai` / `microsoft.azure.openai`)
// the SDK accepts a deployment name in its `model=` kwarg, so the
// customer simply puts the deployment name in `model:`. No special
// Azure branch in the adapter — `model:` is opaque to the runtime.

const AZURE_YAML = `metadata:
  name: oai-azure-fixture
  version: 0.1.0
  agent_shield_version: "2.0"
objective:
  goal: ["exercise Azure routing"]
  forbidden: ["bypass"]
configurations:
  - id: azure-judge
    type: llm
    provider: azure_openai
    model: my-gpt4o-deployment
  - id: openai-judge
    type: llm
    provider: openai.chat
    model: gpt-4o
input_validation:
  guard_policies:
    - name: trivial_input_guard
      evaluate_when:
        - patterns: ["jailbreak"]
          reason: "jailbreak attempt"
      action: "block"
`

describe('Azure-OpenAI routing', () => {
  // No `beforeAll` filesystem fixture — these tests drive
  // `buildRuntime` directly from in-memory YAML strings.

  it('Runtime.llmConfiguration surfaces model for Azure entry', () => {
    const rt = buildRuntime(AZURE_YAML)
    const cfg = rt.llmConfiguration('azure-judge')
    expect(cfg).not.toBeNull()
    // On Azure OpenAI, `model:` carries the deployment name — the
    // string the provider SDK accepts as the model identifier.
    expect(cfg!.model).toBe('my-gpt4o-deployment')
    expect(cfg!.provider).toBe('azure_openai')
  })

  it('caller sends YAML model verbatim on Azure providers', async () => {
    const rt = buildRuntime(AZURE_YAML)
    const { client, calls } = makeFakeClient()
    const caller = makeLlmCaller(client, {
      configurationResolver: (id) => rt.llmConfiguration(id ?? ''),
    })

    await caller({ configurationId: 'azure-judge', prompt: 'p' })

    expect(calls).toHaveLength(1)
    expect(calls[0].model).toBe('my-gpt4o-deployment')
  })

  it('caller sends YAML model verbatim on non-Azure provider entries', async () => {
    const rt = buildRuntime(AZURE_YAML)
    const { client, calls } = makeFakeClient()
    const caller = makeLlmCaller(client, {
      configurationResolver: (id) => rt.llmConfiguration(id ?? ''),
    })

    await caller({ configurationId: 'openai-judge', prompt: 'p' })
    expect(calls[0].model).toBe('gpt-4o')
  })

  it('caller accepts microsoft.azure.openai reverse-domain provider alias', async () => {
    const yaml = `metadata:
  name: rd
  version: 0.1.0
  agent_shield_version: "2.0"
objective:
  goal: ["x"]
  forbidden: ["bypass"]
configurations:
  - id: judge
    type: llm
    provider: microsoft.azure.openai
    model: my-deploy
input_validation:
  guard_policies:
    - name: trivial
      evaluate_when:
        - patterns: ["x"]
          reason: "x"
      action: "block"
`
    const rt = buildRuntime(yaml)
    const { client, calls } = makeFakeClient()
    const caller = makeLlmCaller(client, {
      configurationResolver: (id) => rt.llmConfiguration(id ?? ''),
    })
    await caller({ configurationId: 'judge', prompt: 'p' })
    expect(calls[0].model).toBe('my-deploy')
  })
})
