import { describe, it, expect } from 'vitest'
import * as path from 'path'

import { Shield } from '../shield.js'

/**
 * Verifies that {@link Shield.fromYaml} returns a builder whose
 * {@link ShieldBuilder.build} method consumes itself on success: a second
 * `build()` (and any subsequent `withX()` call) throws a structured error
 * naming the type, mirroring the Rust SDK's compile-time consume semantics.
 */

const FIXTURES = path.resolve(__dirname, '../../../tests/fixtures/smoke')
const MINIMAL = path.join(FIXTURES, 'minimal.guardrails.yaml')

const EXPECTED_MESSAGE =
  'ShieldBuilder.build() can only be called once. ' +
  'Call Shield.fromYaml(...) again to create a new builder.'

describe('ShieldBuilder consume-on-build', () => {
  it('first build() returns a working Shield', () => {
    const shield = Shield.fromYaml(MINIMAL).build()
    expect(shield).toBeInstanceOf(Shield)
  })

  it('second build() throws a structured error naming ShieldBuilder.build', () => {
    const builder = Shield.fromYaml(MINIMAL)
    builder.build()
    expect(() => builder.build()).toThrowError(EXPECTED_MESSAGE)
  })

  it('withMode() after build() throws the same structured error', () => {
    const builder = Shield.fromYaml(MINIMAL)
    builder.build()
    expect(() => builder.withMode('monitor')).toThrowError(EXPECTED_MESSAGE)
  })

  it('withOnBlock() after build() throws the same structured error', () => {
    const builder = Shield.fromYaml(MINIMAL)
    builder.build()
    expect(() => builder.withOnBlock('throw')).toThrowError(EXPECTED_MESSAGE)
  })

  it('a fresh fromYaml() produces an independent buildable builder', () => {
    const first = Shield.fromYaml(MINIMAL).build()
    expect(first).toBeInstanceOf(Shield)

    // Fresh from-yaml must always work — the consume flag is per-builder,
    // not global state.
    const second = Shield.fromYaml(MINIMAL).withMode('monitor').build()
    expect(second).toBeInstanceOf(Shield)
  })

  it('error message references the ShieldBuilder type by name', () => {
    const builder = Shield.fromYaml(MINIMAL)
    builder.build()
    let caught: unknown = null
    try {
      builder.build()
    } catch (err) {
      caught = err
    }
    expect(caught).toBeInstanceOf(Error)
    expect((caught as Error).message).toContain('ShieldBuilder.build()')
    expect((caught as Error).message).toContain('Shield.fromYaml(...)')
  })
})
