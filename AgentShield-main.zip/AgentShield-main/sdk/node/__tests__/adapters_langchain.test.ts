// Tests for the LangChain.js adapter (`adapters/langchain.js`).
//
// Mirrors the cross-language tests in
// `sdk/python/tests/test_adapters_langchain.py` and the Rust
// `agent_shield_langchain/tests/shield_ext.rs`. Verifies:
//
//   1. CapabilityReport shape
//   2. `withLangchain()` / `withLlm()` install on ShieldBuilder
//   3. Stage 1 block — agent never invoked
//   4. Stage 2 block — original tool's func never called
//   5. Stage 3 mutation — redacted params reach inner tool
//   6. Stage 4 redaction — tool output redacted before agent sees it
//   7. Stage 5 block — output blocked
//   8. Tool exception → recordToolFailure is called
//   9. Pattern B — protectTools preserves name/schema/lc_namespace
//  10. Pattern A — createLangchainAgent builds with wrapped tools

import { describe, it, expect, vi } from 'vitest'
import * as path from 'node:path'

import { DynamicStructuredTool } from '@langchain/core/tools'

import {
  RuntimeBuilder,
  Shield,
  ShieldBuilder,
  CapabilityReport,
  CoverageLevel,
} from '../index.js'

// Side-effect import: installs withLangchain() / withLlm() on
// ShieldBuilder, and createLangchainAgent / run on Shield.
import * as langchainAdapter from '../adapters/langchain.js'
const LANGCHAIN_BUNDLE = (langchainAdapter as any).LANGCHAIN_BUNDLE

// ─── Fixtures ───────────────────────────────────────────────────────

const FIXTURES_NODE = path.resolve(
  __dirname,
  '..',
  '..',
  '..',
  'tests',
  'fixtures',
  'smoke',
)
const FIXTURES_PY = path.resolve(
  __dirname,
  '..',
  '..',
  'python',
  'tests',
  'fixtures_smoke',
)
const MINIMAL = path.join(FIXTURES_NODE, 'minimal.guardrails.yaml')
const INPUT_BLOCK = path.join(FIXTURES_NODE, 'input-block.guardrails.yaml')
const TOOL_ARGS_REDACT = path.join(FIXTURES_PY, 'tool_args_redact.guardrails.yaml')

// Inline YAMLs for stages 2 / 4 / 5 / tool-exception. We avoid
// writing temp files by routing through `RuntimeBuilder.fromYamlStrings`.

const STAGE2_YAML = `
metadata:
  name: "stage2-block"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["block tool"]
  forbidden: ["allow tool"]
resources:
  tools:
    - name: "echo"
      description: "Echo helper."
      permission: "read_only"
state_validation:
  guard_policies:
    - name: "deny_echo"
      applies_to:
        tools: ["echo"]
      allowed_when: "false"
`

const STAGE4_YAML = `
metadata:
  name: "stage4-redact"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["scrub ssn from tool output"]
  forbidden: ["leak ssn"]
resources:
  tools:
    - name: "echo"
      description: "Echo helper."
      permission: "read_only"
post_tool_validation:
  guard_policies:
    - name: "redact_ssn_output"
      action: redact
      replacement: "[REDACTED]"
      evaluate_when:
        - pattern: "\\\\d{3}-\\\\d{2}-\\\\d{4}"
          reason: "SSN in tool output."
`

const STAGE5_YAML = `
metadata:
  name: "stage5-block"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["block forbidden output"]
  forbidden: ["leak FORBIDDEN"]
resources:
  tools:
    - name: "echo"
      description: "Echo helper."
      permission: "read_only"
output_validation:
  guard_policies:
    - name: "block_forbidden"
      action: block
      evaluate_when:
        - pattern: "FORBIDDEN"
          reason: "Output contained forbidden token."
`

const PASSTHROUGH_YAML = `
metadata:
  name: "passthrough"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["pass through every call"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "echo"
      description: "Echo helper."
      permission: "read_only"
`

const TOOL_EXC_YAML = `
metadata:
  name: "tool-exception"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test exception"]
  forbidden: ["x"]
resources:
  tools:
    - name: "boom"
      description: "always throws"
      permission: "read_only"
`

// ─── Helpers ────────────────────────────────────────────────────────

function shieldFromYamlString(text: string): Shield {
  const runtime = RuntimeBuilder.fromYamlStrings([text]).build()
  return new Shield(runtime as any, { bundle: LANGCHAIN_BUNDLE } as any)
}

function shieldFromPath(p: string): Shield {
  const runtime = RuntimeBuilder.fromYaml(p).build()
  return new Shield(runtime as any, { bundle: LANGCHAIN_BUNDLE } as any)
}

// ─── Tests ──────────────────────────────────────────────────────────

describe('LangChain adapter — capability report', () => {
  it('declares the documented per-stage coverage', () => {
    const rep = (langchainAdapter as any).capabilities as CapabilityReport
    expect(rep).toBeInstanceOf(CapabilityReport)
    expect(rep.framework).toBe('langchain')
    expect(rep.inputValidation).toBe(CoverageLevel.FULL)
    expect(rep.stateValidation).toBe(CoverageLevel.FULL)
    expect(rep.toolAuthorization).toBe(CoverageLevel.FULL)
    expect(rep.toolExecutionValidation).toBe(CoverageLevel.FULL)
    expect(rep.toolOutputValidation).toBe(CoverageLevel.FULL)
    expect(rep.outputValidation).toBe(CoverageLevel.FULL)
    expect(rep.streamingOutput).toBe(CoverageLevel.PARTIAL)
    expect(rep.notes.length).toBeGreaterThan(0)
    expect(rep.notes[0]).toMatch(/streaming/i)
    expect(rep.isFullCoverage()).toBe(false)
  })

  it('LANGCHAIN_BUNDLE wires all four capabilities', () => {
    expect(LANGCHAIN_BUNDLE.name).toBe('langchain')
    expect(typeof LANGCHAIN_BUNDLE.toolWrapper.extract).toBe('function')
    expect(typeof LANGCHAIN_BUNDLE.toolWrapper.invoke).toBe('function')
    expect(typeof LANGCHAIN_BUNDLE.toolWrapper.wrap).toBe('function')
    expect(typeof LANGCHAIN_BUNDLE.agentBoundary.run).toBe('function')
    expect(typeof LANGCHAIN_BUNDLE.agentBoundary.makeBlocked).toBe('function')
    expect(typeof LANGCHAIN_BUNDLE.streamingAdapter.stream).toBe('function')
    expect(typeof LANGCHAIN_BUNDLE.llmCallerFactory.makeCaller).toBe('function')
  })
})

describe('LangChain adapter — builder side effects', () => {
  it('installs withLangchain() on ShieldBuilder.prototype', () => {
    expect(typeof (ShieldBuilder.prototype as any).withLangchain).toBe(
      'function',
    )
  })

  it('installs withLlm() on ShieldBuilder.prototype', () => {
    expect(typeof (ShieldBuilder.prototype as any).withLlm).toBe('function')
  })

  it('Shield.fromYaml(...).withLangchain().build() returns a wired Shield', () => {
    const shield = (Shield as any)
      .fromYaml(MINIMAL)
      .withLangchain()
      .build() as Shield
    expect(shield).toBeInstanceOf(Shield)
    expect(shield.capabilities.framework).toBe('langchain')
  })

  it('withLlm() before withLangchain() defers the LLM until the bundle is bound', () => {
    const calls: string[] = []
    const fakeLlm = {
      invoke: async (msgs: any[]) => {
        calls.push(msgs[0].content)
        return { content: 'ok' }
      },
    }
    const shield = (Shield as any)
      .fromYaml(MINIMAL)
      .withLlm(fakeLlm)
      .withLangchain()
      .build()
    expect(shield).toBeInstanceOf(Shield)
    // Verifies `_pendingLlmClient` is now bound through the LangChain
    // caller factory.
    expect((shield as any).runtime).toBeDefined()
  })
})

describe('LangChain adapter — Stage 1 block', () => {
  it('blocks the input and never invokes the agent', async () => {
    const shield = shieldFromPath(INPUT_BLOCK)
    let agentCalled = false
    const fakeAgent = {
      invoke: async (_input: any) => {
        agentCalled = true
        return { output: 'should not happen', messages: [] }
      },
    }
    const guarded = shield.guard(fakeAgent)
    const result: any = await guarded.run('DENY_ME this request')
    expect(agentCalled).toBe(false)
    expect(result.output).toMatch(/\[GUARDRAIL BLOCK\]/)
    expect(result.messages).toBeDefined()
    expect(result.messages.length).toBe(1)
    // makeBlocked emits an AIMessage shape compatible with both
    // AgentExecutor (`{output}`) and LangGraph (`{messages}`).
    expect(typeof result.messages[0].content).toBe('string')
    expect(result.messages[0].content).toMatch(/\[GUARDRAIL BLOCK\]/)
  })
})

describe('LangChain adapter — Stage 2 block (tool authorization)', () => {
  it('blocks the tool call and never calls the original func', async () => {
    const shield = shieldFromYamlString(STAGE2_YAML)
    let originalCalled = false
    const tool = new DynamicStructuredTool({
      name: 'echo',
      description: 'echo helper',
      schema: {
        type: 'object',
        properties: { msg: { type: 'string' } },
      } as any,
      func: async (args: any) => {
        originalCalled = true
        return `direct: ${args.msg}`
      },
    })
    const wrapped = (await shield.protectTools([tool]))[0] as any
    const result = await wrapped.invoke({ msg: 'hello' })
    expect(originalCalled).toBe(false)
    expect(typeof result).toBe('string')
    expect(result).toMatch(/\[GUARDRAIL BLOCK\]/)
    expect(result).toMatch(/echo/)
  })
})

describe('LangChain adapter — Stage 3 mutation (params redaction)', () => {
  it('forwards the redacted params, not the originals, to the inner tool', async () => {
    const shield = shieldFromPath(TOOL_ARGS_REDACT)
    let receivedArgs: Record<string, unknown> | null = null
    const tool = new DynamicStructuredTool({
      name: 'echo',
      description: 'echo helper',
      schema: {
        type: 'object',
        properties: { msg: { type: 'string' } },
      } as any,
      func: async (args: any) => {
        receivedArgs = args
        return `echo: ${args.msg}`
      },
    })
    const wrapped = (await shield.protectTools([tool]))[0] as any
    const result = await wrapped.invoke({ msg: 'My SSN is 123-45-6789, please' })
    // The Stage 3 redact replaces the SSN with [REDACTED] BEFORE the
    // call reaches the tool — that's the security invariant.
    expect(receivedArgs).not.toBeNull()
    expect((receivedArgs as any).msg).not.toContain('123-45-6789')
    expect((receivedArgs as any).msg).toContain('[REDACTED]')
    expect(result).toContain('[REDACTED]')
    expect(result).not.toContain('123-45-6789')
  })
})

describe('LangChain adapter — Stage 4 redaction (tool output)', () => {
  it('redacts the tool output before the agent sees it', async () => {
    const shield = shieldFromYamlString(STAGE4_YAML)
    const tool = new DynamicStructuredTool({
      name: 'echo',
      description: 'echo helper',
      schema: {
        type: 'object',
        properties: { msg: { type: 'string' } },
      } as any,
      func: async () => 'Result: SSN 999-88-7777 found',
    })
    const wrapped = (await shield.protectTools([tool]))[0] as any
    const result = await wrapped.invoke({ msg: 'find' })
    expect(result).toContain('[REDACTED]')
    expect(result).not.toContain('999-88-7777')
  })
})

describe('LangChain adapter — Stage 5 block (output validation)', () => {
  it('blocks a forbidden agent output', async () => {
    const shield = shieldFromYamlString(STAGE5_YAML)
    const fakeAgent = {
      invoke: async (_input: any) => ({
        output: 'this contains FORBIDDEN content',
        messages: [{ content: 'this contains FORBIDDEN content' }],
      }),
    }
    const guarded = shield.guard(fakeAgent)
    const result: any = await guarded.run('hello')
    expect(result.output).toMatch(/\[GUARDRAIL BLOCK\]/)
    expect(result.output).toMatch(/FORBIDDEN|forbidden/i)
    expect(result.messages?.[0]?.content).toMatch(/\[GUARDRAIL BLOCK\]/)
  })
})

describe('LangChain adapter — tool exception path', () => {
  it('calls recordToolFailure when the underlying tool throws', async () => {
    const runtime = RuntimeBuilder.fromYamlStrings([TOOL_EXC_YAML]).build()
    // Spy: wrap newSession so we observe recordToolFailure calls. We
    // can't use vi.spyOn on the prototype directly because the napi
    // session is constructed per-call.
    const failures: Array<[string, string]> = []
    const realNewSession = runtime.newSession.bind(runtime)
    ;(runtime as any).newSession = (opts?: any) => {
      const sess = realNewSession(opts)
      const orig = sess.recordToolFailure.bind(sess)
      sess.recordToolFailure = ((name: string, err: string) => {
        failures.push([name, err])
        return orig(name, err)
      }) as any
      return sess
    }
    const shield = new Shield(runtime as any, {
      bundle: LANGCHAIN_BUNDLE,
    } as any)

    const boom = new DynamicStructuredTool({
      name: 'boom',
      description: 'always throws',
      schema: { type: 'object', properties: {} } as any,
      func: async () => {
        throw new Error('boom-error')
      },
    })
    const wrapped = (await shield.protectTools([boom]))[0] as any
    const result = await wrapped.invoke({})
    expect(failures.length).toBeGreaterThanOrEqual(1)
    expect(failures[0][0]).toBe('boom')
    expect(failures[0][1]).toMatch(/boom-error/)
    // Output is propagated as a [tool error] string (Stage 4 default).
    expect(typeof result).toBe('string')
    expect(result).toMatch(/boom/)
  })
})

describe('LangChain adapter — Pattern B (protectTools)', () => {
  it('preserves the LangChain tool shape (name/description/schema/lc_namespace)', async () => {
    const shield = shieldFromYamlString(PASSTHROUGH_YAML)
    const schema = {
      type: 'object',
      properties: { msg: { type: 'string' } },
      required: ['msg'],
    }
    const tool = new DynamicStructuredTool({
      name: 'echo',
      description: 'A helpful echo tool.',
      schema: schema as any,
      func: async ({ msg }: any) => `echo: ${msg}`,
    })
    const wrapped = (await shield.protectTools([tool]))[0] as any
    // Duck-type the LangChain tool shape rather than `instanceof
    // StructuredTool`. The adapter resolves @langchain/core via
    // `require()` while vitest loads the test file via ESM, so the
    // two import paths can yield distinct (but compatible) class
    // identities under the dual-package hazard.
    expect(wrapped.name).toBe('echo')
    expect(wrapped.description).toBe('A helpful echo tool.')
    expect(wrapped.schema).toBe(schema)
    expect(Array.isArray(wrapped.lc_namespace)).toBe(true)
    expect(typeof wrapped.invoke).toBe('function')
    expect(typeof wrapped.call).toBe('function')
    // Round-trip invoke proves the prototype chain still works.
    const r = await wrapped.invoke({ msg: 'hi' })
    expect(r).toBe('echo: hi')
  })
})

describe('LangChain adapter — Pattern A (createLangchainAgent)', () => {
  it('wraps tools and invokes the build callback with the wrapped list', async () => {
    const shield = shieldFromYamlString(PASSTHROUGH_YAML)
    const tool = new DynamicStructuredTool({
      name: 'echo',
      description: 'echo',
      schema: {
        type: 'object',
        properties: { msg: { type: 'string' } },
      } as any,
      func: async ({ msg }: any) => `direct: ${msg}`,
    })

    const buildSpy = vi.fn(async (wrappedTools: any[]) => {
      // The build callback would normally call createReactAgent here.
      // For the test we just return a stand-in object that exposes
      // the wrapped tools.
      return { tools: wrappedTools, invoke: async () => ({ output: 'ok' }) }
    })

    const agent = (await (shield as any).createLangchainAgent({
      tools: [tool],
      build: buildSpy,
    })) as any

    expect(buildSpy).toHaveBeenCalledOnce()
    const wrappedTools = buildSpy.mock.calls[0][0]
    expect(Array.isArray(wrappedTools)).toBe(true)
    expect(wrappedTools.length).toBe(1)
    expect(wrappedTools[0].name).toBe('echo')
    expect(wrappedTools[0]).not.toBe(tool) // separate wrapper
    expect(typeof wrappedTools[0].invoke).toBe('function')
    expect(Array.isArray(wrappedTools[0].lc_namespace)).toBe(true)
    expect(agent.tools.length).toBe(1)
  })

  it('shield.run(fn) is a callable convenience for Pattern B', async () => {
    const shield = shieldFromPath(MINIMAL)
    const r = await (shield as any).run(async () => 42)
    expect(r).toBe(42)
  })
})

// ─── Streaming adapter mode-respect tests ──────────────────────────

describe('LangChain streaming adapter — respects validator mode', () => {
  // Build a fake LangChain agent that yields a configured sequence of
  // chunks. The adapter calls `.stream(inputDict, config)` and iterates
  // the result, so we only need to implement that surface.
  function makeFakeAgent(chunks: ReadonlyArray<unknown>) {
    return {
      async stream() {
        async function* gen() {
          for (const c of chunks) yield c
        }
        return gen()
      },
    }
  }

  // Minimal validator stub. The adapter cares about:
  //   * `mode` (governs buffering)
  //   * `push(text)` / `finish()` returning `{payload, stopped, reason}`
  //   * `makeBlocked(reason)` / `applyRedaction(chunk, text)`
  function makeStubValidator(opts: {
    mode: 'on_complete' | 'per_chunk' | 'windowed'
    pushHandler?: (text: string) => {
      payload: string | null
      stopped: boolean
      reason: string | null
    }
    finishHandler?: () => {
      payload: string | null
      stopped: boolean
      reason: string | null
    }
  }) {
    const calls: { push: string[]; finish: number } = { push: [], finish: 0 }
    const validator = {
      get mode() {
        return opts.mode
      },
      async push(text: string) {
        calls.push.push(text)
        return (
          opts.pushHandler?.(text) ?? {
            payload: '',
            stopped: false,
            reason: null,
          }
        )
      },
      async finish() {
        calls.finish += 1
        return (
          opts.finishHandler?.() ?? {
            payload: '',
            stopped: false,
            reason: null,
          }
        )
      },
      makeBlocked: (msg: string) => ({ blocked: msg }),
      applyRedaction: (chunk: unknown, text: string) => ({ chunk, text }),
    }
    return { validator, calls }
  }

  it('OnComplete: buffers every text chunk and emits ONE final chunk at finish', async () => {
    const adapter = LANGCHAIN_BUNDLE.streamingAdapter
    const upstream = [
      { messages: [{ content: 'Hello ' }] },
      { messages: [{ content: 'world' }] },
      { messages: [{ content: '!' }] },
    ]
    const agent = makeFakeAgent(upstream)
    const { validator, calls } = makeStubValidator({
      mode: 'on_complete',
      finishHandler: () => ({ payload: 'Hello world!', stopped: false, reason: null }),
    })

    const emissions: unknown[] = []
    for await (const e of adapter.stream(agent, '', validator, {})) {
      emissions.push(e)
    }

    // Every text chunk was pushed through the engine for accumulation.
    expect(calls.push).toEqual(['Hello ', 'world', '!'])
    expect(calls.finish).toBe(1)
    // The consumer received exactly one emission — the validated final
    // payload (applyRedaction'd onto the last upstream chunk shape).
    expect(emissions.length).toBe(1)
    expect((emissions[0] as { text: string }).text).toBe('Hello world!')
  })

  it('OnComplete: holds back text chunks, passes metadata-only chunks promptly', async () => {
    const adapter = LANGCHAIN_BUNDLE.streamingAdapter
    // Metadata-only chunks have no text content.
    const meta1 = { messages: [{ content: '' }] }
    const meta2 = { messages: [{ content: '' }] }
    const upstream = [
      meta1,
      { messages: [{ content: 'Hello' }] },
      meta2,
      { messages: [{ content: ' world' }] },
    ]
    const agent = makeFakeAgent(upstream)
    const { validator, calls } = makeStubValidator({
      mode: 'on_complete',
      finishHandler: () => ({ payload: 'Hello world', stopped: false, reason: null }),
    })

    const emissions: unknown[] = []
    for await (const e of adapter.stream(agent, '', validator, {})) {
      emissions.push(e)
    }

    // Text-bearing chunks: pushed but not yielded mid-stream.
    expect(calls.push).toEqual(['Hello', ' world'])
    // Consumer saw the metadata chunks immediately + the single
    // terminal text emission == 3.
    expect(emissions.length).toBe(3)
    expect(emissions[0]).toBe(meta1)
    expect(emissions[1]).toBe(meta2)
    // Third emission is the validated terminal text (built via
    // applyRedaction over the last upstream chunk shape).
    expect((emissions[2] as { text: string }).text).toBe('Hello world')
  })

  it('OnComplete: Stop verdict emits a single blocked message and aborts', async () => {
    const adapter = LANGCHAIN_BUNDLE.streamingAdapter
    const upstream = [
      { messages: [{ content: 'safe ' }] },
      { messages: [{ content: 'BAD content' }] },
      { messages: [{ content: 'never seen' }] },
    ]
    const agent = makeFakeAgent(upstream)
    let pushIdx = 0
    const { validator } = makeStubValidator({
      mode: 'on_complete',
      pushHandler: (_text) => {
        pushIdx += 1
        if (pushIdx === 2) {
          return { payload: null, stopped: true, reason: 'policy violation' }
        }
        return { payload: '', stopped: false, reason: null }
      },
    })

    const emissions: unknown[] = []
    for await (const e of adapter.stream(agent, '', validator, {})) {
      emissions.push(e)
    }

    expect(emissions.length).toBe(1)
    expect((emissions[0] as { blocked: string }).blocked).toMatch(
      /policy violation/,
    )
  })

  it('PerChunk: emits engine payload (NOT raw chunk) mid-stream', async () => {
    // Engine returns `r.payload` as the authoritative safe-to-emit
    // slice — windowed and per_chunk modes hold back `overlap` bytes,
    // so the payload is generally a substring/suffix of the buffer,
    // not the latest raw chunk verbatim. The adapter MUST forward
    // `r.payload`, otherwise SDK consumers see content the engine
    // hasn't authorised (the bug fixed in
    // `streaming-windowed-payload-respect`). Even when the payload
    // happens to equal the chunk text (no redaction, overlap=0), the
    // adapter routes through `applyRedaction(chunk, payload)` so the
    // emitted shape carries the engine's authority — not a raw
    // upstream object that bypassed validation.
    const adapter = LANGCHAIN_BUNDLE.streamingAdapter
    const upstream = [
      { messages: [{ content: 'Hello' }] },
      { messages: [{ content: ' world' }] },
    ]
    const agent = makeFakeAgent(upstream)
    const { validator, calls } = makeStubValidator({
      mode: 'per_chunk',
      pushHandler: (text) => ({ payload: text, stopped: false, reason: null }),
      finishHandler: () => ({ payload: '', stopped: false, reason: null }),
    })

    const emissions: unknown[] = []
    for await (const e of adapter.stream(agent, '', validator, {})) {
      emissions.push(e)
    }

    expect(calls.push.length).toBe(2)
    expect(emissions.length).toBe(2)
    // applyRedaction(chunk, payload) shape used for every emission so
    // the engine's payload is the source of truth.
    expect(emissions[0]).toEqual({ chunk: upstream[0], text: 'Hello' })
    expect(emissions[1]).toEqual({ chunk: upstream[1], text: ' world' })
  })

  it('Windowed: buffered pushes (empty payload) emit nothing; non-empty payload reaches consumer verbatim', async () => {
    // In windowed mode the engine commonly returns `payload: ''` for
    // early chunks (still inside the overlap window) and a non-empty
    // cumulative payload once the window crosses. The SDK must NOT
    // emit anything for the buffered pushes — emitting the raw chunk
    // there is the bug from `streaming-windowed-payload-respect` and
    // would leak content the engine has not authorised.
    const adapter = LANGCHAIN_BUNDLE.streamingAdapter
    const upstream = [
      { messages: [{ content: 'first ' }] },
      { messages: [{ content: 'second ' }] },
      { messages: [{ content: 'third' }] },
    ]
    const agent = makeFakeAgent(upstream)
    let pushIdx = 0
    const { validator, calls } = makeStubValidator({
      mode: 'windowed',
      pushHandler: () => {
        pushIdx += 1
        if (pushIdx === 1) {
          // Buffered: payload empty.
          return { payload: '', stopped: false, reason: null }
        }
        if (pushIdx === 2) {
          // Window flushes a cumulative payload covering BOTH chunks
          // so far — note this is NOT equal to the latest raw chunk.
          return { payload: 'first second ', stopped: false, reason: null }
        }
        // Third push: the engine has rewritten the buffer (Replace),
        // payload differs from raw chunk.
        return { payload: 'third [REDACTED]', stopped: false, reason: null }
      },
      finishHandler: () => ({ payload: '', stopped: false, reason: null }),
    })

    const emissions: unknown[] = []
    for await (const e of adapter.stream(agent, '', validator, {})) {
      emissions.push(e)
    }

    expect(calls.push.length).toBe(3)
    // First push was buffered (empty payload) → no emission.
    // Second + third pushes carry non-empty payloads → exactly two
    // emissions, both engine-authoritative payloads (NOT raw chunks).
    expect(emissions.length).toBe(2)
    expect(emissions[0]).toEqual({ chunk: upstream[1], text: 'first second ' })
    expect(emissions[1]).toEqual({ chunk: upstream[2], text: 'third [REDACTED]' })
  })
})
