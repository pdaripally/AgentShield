import { describe, it, expect } from 'vitest'
import * as path from 'path'
import { RuntimeBuilder } from '../index.js'
import { createAgentShieldGhcpExtension } from '../integrations/ghcp/index.js'

const FIXTURES = path.resolve(__dirname, '../../../tests/fixtures/smoke')
const MINIMAL = path.join(FIXTURES, 'minimal.guardrails.yaml')
const PERMISSIVE = path.join(FIXTURES, 'redact.guardrails.yaml')

describe('GHCP extension', () => {
  it('exposes hooks + onEvent', () => {
    const rt = RuntimeBuilder.fromYaml(MINIMAL).build()
    const ext = createAgentShieldGhcpExtension({ runtime: rt })
    expect(typeof ext.onEvent).toBe('function')
    expect(typeof ext.hooks.onUserPromptSubmitted).toBe('function')
    expect(typeof ext.hooks.onPreToolUse).toBe('function')
    expect(typeof ext.hooks.onPostToolUse).toBe('function')
    expect(typeof ext.hooks.onSessionStart).toBe('function')
    expect(typeof ext.hooks.onSessionEnd).toBe('function')
    expect(typeof ext.hooks.onErrorOccurred).toBe('function')
  })

  it('Stage 1 allows clean prompts', async () => {
    const rt = RuntimeBuilder.fromYaml(MINIMAL).build()
    const ext = createAgentShieldGhcpExtension({ runtime: rt })
    const r = await ext.hooks.onUserPromptSubmitted(
      { prompt: 'hello' },
      { sessionId: 'gh-test-1' },
    )
    expect(r).toBeUndefined()
  })

  it('onPreToolUse fails closed when no assistant.message was seen', async () => {
    const rt = RuntimeBuilder.fromYaml(MINIMAL).build()
    const ext = createAgentShieldGhcpExtension({ runtime: rt })
    await ext.hooks.onUserPromptSubmitted(
      { prompt: 'hi' },
      { sessionId: 'gh-test-2' },
    )
    const r = await ext.hooks.onPreToolUse(
      { toolName: 'echo', toolArgs: { msg: 'hi' } },
      { sessionId: 'gh-test-2' },
    )
    expect((r as any).permissionDecision).toBe('deny')
    expect((r as any).permissionDecisionReason).toContain('not yet delivered')
  })

  it('correlates toolCallId from assistant.message and allows Stage 2/3', async () => {
    const rt = RuntimeBuilder.fromYaml(PERMISSIVE).build()
    const ext = createAgentShieldGhcpExtension({ runtime: rt })
    const sessionId = 'gh-test-3'
    await ext.hooks.onUserPromptSubmitted({ prompt: 'hi' }, { sessionId })

    // Simulate the assistant.message event carrying a toolRequests entry.
    ext.onEvent({
      type: 'assistant.message',
      sessionId,
      data: {
        toolRequests: [
          { toolCallId: 'tc-1', name: 'echo', arguments: { msg: 'hi' } },
        ],
      },
    })

    const r = await ext.hooks.onPreToolUse(
      { toolName: 'echo', toolArgs: { msg: 'hi' } },
      { sessionId },
    )
    // Clean allow returns undefined (no modifiedArgs, no deny).
    expect(r).toBeUndefined()
  })

  it('fails closed on ambiguous parallel tool calls', async () => {
    const rt = RuntimeBuilder.fromYaml(MINIMAL).build()
    const ext = createAgentShieldGhcpExtension({ runtime: rt })
    const sessionId = 'gh-test-4'
    await ext.hooks.onUserPromptSubmitted({ prompt: 'hi' }, { sessionId })

    // Two identical-arg pending entries.
    ext.onEvent({
      type: 'assistant.message',
      sessionId,
      data: {
        toolRequests: [
          { toolCallId: 'tc-A', name: 'echo', arguments: { msg: 'hi' } },
          { toolCallId: 'tc-B', name: 'echo', arguments: { msg: 'hi' } },
        ],
      },
    })

    const r = await ext.hooks.onPreToolUse(
      { toolName: 'echo', toolArgs: { msg: 'hi' } },
      { sessionId },
    )
    expect((r as any).permissionDecision).toBe('deny')
    expect((r as any).permissionDecisionReason).toContain('ambiguous')
  })

  it('Stage 4 fails closed when no Stage 3 binding was observed', async () => {
    const rt = RuntimeBuilder.fromYaml(MINIMAL).build()
    const ext = createAgentShieldGhcpExtension({ runtime: rt })
    const sessionId = 'gh-test-5'
    await ext.hooks.onUserPromptSubmitted({ prompt: 'hi' }, { sessionId })

    const r = await ext.hooks.onPostToolUse(
      {
        toolName: 'echo',
        toolArgs: {},
        toolResult: { textResultForLlm: 'hi back', resultType: 'success' },
      },
      { sessionId },
    )
    expect((r as any).modifiedResult).toBeDefined()
    expect((r as any).modifiedResult.resultType).toBe('rejected')
    expect((r as any).modifiedResult.textResultForLlm).toContain(
      'could not bind',
    )
  })

  it('happy path: assistant.message → onPreToolUse → onPostToolUse', async () => {
    const rt = RuntimeBuilder.fromYaml(PERMISSIVE).build()
    const ext = createAgentShieldGhcpExtension({ runtime: rt })
    const sessionId = 'gh-test-6'
    await ext.hooks.onUserPromptSubmitted({ prompt: 'hi' }, { sessionId })

    ext.onEvent({
      type: 'assistant.message',
      sessionId,
      data: {
        toolRequests: [
          { toolCallId: 'tc-6', name: 'echo', arguments: { msg: 'hi' } },
        ],
      },
    })

    await ext.hooks.onPreToolUse(
      { toolName: 'echo', toolArgs: { msg: 'hi' } },
      { sessionId },
    )
    const r = await ext.hooks.onPostToolUse(
      {
        toolName: 'echo',
        toolArgs: { msg: 'hi' },
        toolResult: { textResultForLlm: 'hi back', resultType: 'success' },
      },
      { sessionId },
    )
    // Clean allow: no modifiedResult emitted (undefined return).
    expect(r).toBeUndefined()

    await ext.hooks.onSessionEnd(null, { sessionId })
  })

  it('Stage 4 fails closed when multiple Stage 3 admits for same tool are in flight', async () => {
    const rt = RuntimeBuilder.fromYaml(PERMISSIVE).build()
    const ext = createAgentShieldGhcpExtension({ runtime: rt })
    const sessionId = 'gh-test-7'
    await ext.hooks.onUserPromptSubmitted({ prompt: 'hi' }, { sessionId })

    // Two distinct toolCalls for the same tool with DISTINCT args
    // (so the assistant.message → onPreToolUse correlation succeeds
    // for both — they admit cleanly via the pending queue).
    ext.onEvent({
      type: 'assistant.message',
      sessionId,
      data: {
        toolRequests: [
          { toolCallId: 'tc-A', name: 'echo', arguments: { msg: 'a' } },
          { toolCallId: 'tc-B', name: 'echo', arguments: { msg: 'b' } },
        ],
      },
    })
    await ext.hooks.onPreToolUse(
      { toolName: 'echo', toolArgs: { msg: 'a' } },
      { sessionId },
    )
    await ext.hooks.onPreToolUse(
      { toolName: 'echo', toolArgs: { msg: 'b' } },
      { sessionId },
    )
    // Now two admits are queued for 'echo'. onPostToolUse must fail
    // closed — GHCP doesn't expose toolCallId on the post hook and
    // we can't bind to the right Stage 3 admission.
    const r = await ext.hooks.onPostToolUse(
      {
        toolName: 'echo',
        toolArgs: { msg: 'a' },
        toolResult: { textResultForLlm: 'a back', resultType: 'success' },
      },
      { sessionId },
    )
    expect((r as any).modifiedResult).toBeDefined()
    expect((r as any).modifiedResult.resultType).toBe('rejected')
    expect((r as any).modifiedResult.textResultForLlm).toContain('disambiguate')
  })

  it('monitor mode: Stage 3 block is queued so Stage 4 does not unconditionally fail closed', async () => {
    // Use the minimal.guardrails.yaml fixture: it blocks `echo`
    // unless `authorized == true`. With mode: monitor, the dispatcher
    // returns `action: blocked, override_to_proceed: true`. The GHCP
    // integration MUST still queue the admit so the subsequent
    // onPostToolUse can correlate.
    const rt = RuntimeBuilder.fromYaml(MINIMAL).build()
    const ext = createAgentShieldGhcpExtension({ runtime: rt, mode: 'monitor' })
    const sessionId = 'gh-monitor-1'
    await ext.hooks.onUserPromptSubmitted({ prompt: 'hi' }, { sessionId })
    ext.onEvent({
      type: 'assistant.message',
      sessionId,
      data: {
        toolRequests: [
          { toolCallId: 'tc-mon-1', name: 'echo', arguments: { msg: 'x' } },
        ],
      },
    })
    // Stage 3 in monitor mode against a blocking fixture: result
    // should be `undefined` (allow through) per the override.
    const r1 = await ext.hooks.onPreToolUse(
      { toolName: 'echo', toolArgs: { msg: 'x' } },
      { sessionId },
    )
    expect(r1).toBeUndefined()

    // Stage 4 should NOT hard-reject with "could not bind"; the
    // admit-queue must have been written so the post-tool path
    // proceeds (it may still surface a monitor-mode block via the
    // existing Stage 4 verdict-handling, but it must not hard-fail
    // on missing binding).
    const r2 = await ext.hooks.onPostToolUse(
      {
        toolName: 'echo',
        toolArgs: { msg: 'x' },
        toolResult: { textResultForLlm: 'x back', resultType: 'success' },
      },
      { sessionId },
    )
    // The expected return is either undefined (no rewrite needed)
    // or a structured object that doesn't contain the
    // "could not bind" sentinel. The exact shape depends on
    // whether Stage 4 also blocks under the same fixture; either
    // outcome is acceptable, the "could not bind" hard-reject is
    // the bug we're regressing against.
    if (r2 && (r2 as any).modifiedResult) {
      expect((r2 as any).modifiedResult.textResultForLlm).not.toContain('could not bind')
    }
  })
})
