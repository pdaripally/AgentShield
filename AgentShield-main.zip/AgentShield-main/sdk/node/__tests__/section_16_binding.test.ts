import { describe, it, expect } from 'vitest'
import { RuntimeBuilder } from '../index.js'

/**
 * Cross-SDK parity tests for spec §16.0 invocation-bound verdict
 * semantics.
 *
 * The Rust core already exercises every §16.0 corner case in
 * `sdk/rust/agent_shield_core/tests/runtime.rs` (the `stage4_*`
 * tests). This file verifies that the **Node SDK surface** preserves
 * the same semantics — i.e. `invocationHash` /
 * `postValidationInvocationHash` cross the napi boundary correctly and
 * the `toolCallId` param on `validateToolCall` / `validateToolOutput`
 * actually drives the §16.0 binding cache.
 *
 * Mirror suites:
 *   - sdk/python/tests/test_section_16_binding.py
 *   - sdk/dotnet/tests/AgentShield.Tests/Section16BindingTests.cs
 */

const FIXTURE_YAML = `
metadata:
  name: "section-16-binding-parity"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test §16.0 invocation binding"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "send_email"
      description: "Send an email."
      permission: "execute"
post_tool_validation:
  guard_policies:
    - name: "result_recipient_must_match_call_recipient"
      evaluate_when:
        - expression: '@tool.params.recipient == @result.matched_recipient'
          reason: "§16.0: Stage 4 bound to the wrong invocation."
`

async function newSession() {
  const rt = RuntimeBuilder.fromYamlStrings([FIXTURE_YAML]).build()
  const s = rt.newSession({
    sessionId: 'sess-section16',
    correlationId: 'corr-section16',
  })
  await s.beginTurn()
  return s
}

describe('§16.0 invocation-bound verdicts (Node parity)', () => {
  it('Scenario 1: Stage 3 + Stage 4 with matching id surfaces non-null hashes', async () => {
    const s = await newSession()
    const call = await s.validateToolCall(
      'send_email',
      { recipient: 'alice@example.com', body: 'hi' },
      'call_alice_1',
    )
    expect(call.verdict.allowed).toBe(true)

    const out = await s.validateToolOutput(
      'send_email',
      { matched_recipient: 'alice@example.com', sent: true },
      'call_alice_1',
    )
    expect(out.verdict.allowed).toBe(true)
    expect(out.verdict.invocationHash).toBeTruthy()
    expect(out.verdict.postValidationInvocationHash).toBeTruthy()
  })

  it('Scenario 2: parallel same-name with distinct ids bind independently', async () => {
    const s = await newSession()

    const callA = await s.validateToolCall(
      'send_email',
      { recipient: 'alice@example.com', body: 'hi alice' },
      'call_alice_1',
    )
    expect(callA.verdict.allowed).toBe(true)

    const callB = await s.validateToolCall(
      'send_email',
      { recipient: 'bob@example.com', body: 'hi bob' },
      'call_bob_2',
    )
    expect(callB.verdict.allowed).toBe(true)

    // Stage 4 in OPPOSITE order: bob first, alice second.
    const outB = await s.validateToolOutput(
      'send_email',
      { matched_recipient: 'bob@example.com', sent: true },
      'call_bob_2',
    )
    expect(outB.verdict.allowed).toBe(true)

    const outA = await s.validateToolOutput(
      'send_email',
      { matched_recipient: 'alice@example.com', sent: true },
      'call_alice_1',
    )
    expect(outA.verdict.allowed).toBe(true)

    expect(outA.verdict.invocationHash).toBeTruthy()
    expect(outB.verdict.invocationHash).toBeTruthy()
    expect(outA.verdict.invocationHash).not.toBe(outB.verdict.invocationHash)
  })

  it('Scenario 3: Stage 4 with unknown id fails closed with no hash', async () => {
    const s = await newSession()
    const out = await s.validateToolOutput(
      'send_email',
      { matched_recipient: 'alice@example.com', sent: true },
      'never_validated_call_id',
    )
    expect(out.verdict.allowed).toBe(false)
    expect(out.verdict.policy).toBe('<binding>')
    expect(out.verdict.invocationHash).toBeNull()
  })

  it('Scenario 4: Stage 4 with mismatched explicit id fails closed with no hashes', async () => {
    const s = await newSession()
    await s.validateToolCall(
      'send_email',
      { recipient: 'alice@example.com', body: 'hi' },
      'call_alice_1',
    )
    const out = await s.validateToolOutput(
      'send_email',
      { matched_recipient: 'alice@example.com', sent: true },
      'call_alice_2',
    )
    expect(out.verdict.allowed).toBe(false)
    expect(out.verdict.policy).toBe('<binding>')
    expect(out.verdict.invocationHash).toBeNull()
    expect(out.verdict.postValidationInvocationHash).toBeNull()
  })
})
