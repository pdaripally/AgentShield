// Cross-language wire-shape golden fixture conformance for the Node SDK.
//
// Mirrors `sdk/python/tests/test_wire_fixtures.py` and
// `sdk/dotnet/tests/AgentShield.Tests/WireFixtureTests.cs`. All three
// run against the same fixtures under `tests/fixtures/wire/` and the
// same schemas under `spec/schemas/wire/`.

import { describe, expect, it } from 'vitest'
import * as fs from 'node:fs'
import * as path from 'node:path'
import Ajv from 'ajv'
import addFormats from 'ajv-formats'

const REPO_ROOT = path.resolve(__dirname, '..', '..', '..')
const SCHEMAS_DIR = path.join(REPO_ROOT, 'spec', 'schemas', 'wire')
const FIXTURES_DIR = path.join(REPO_ROOT, 'tests', 'fixtures', 'wire')

interface FixtureCase {
  shape: string
  fixturePath: string
  schemaPath: string
}

function listShapeDirs(): string[] {
  return fs
    .readdirSync(FIXTURES_DIR, { withFileTypes: true })
    .filter((d) => d.isDirectory())
    .map((d) => d.name)
    .sort()
}

function listFixtures(): FixtureCase[] {
  const out: FixtureCase[] = []
  for (const shape of listShapeDirs()) {
    const schemaPath = path.join(SCHEMAS_DIR, `${shape}.schema.json`)
    if (!fs.existsSync(schemaPath)) {
      throw new Error(
        `No schema for fixture shape ${shape}: ${schemaPath}`,
      )
    }
    const dir = path.join(FIXTURES_DIR, shape)
    const fixtures = fs
      .readdirSync(dir)
      .filter((f) => f.endsWith('.json'))
      .sort()
    for (const f of fixtures) {
      out.push({
        shape,
        fixturePath: path.join(dir, f),
        schemaPath,
      })
    }
  }
  return out
}

const fixtures = listFixtures()
const ajv = addFormats(new Ajv({ strict: false, allErrors: true }))

// Cache compiled validators by schema path so each schema is only
// added once (ajv rejects duplicate $id registrations).
const validatorCache = new Map<string, ReturnType<typeof ajv.compile>>()
function getValidator(schemaPath: string) {
  let v = validatorCache.get(schemaPath)
  if (!v) {
    const schema = JSON.parse(fs.readFileSync(schemaPath, 'utf8'))
    v = ajv.compile(schema)
    validatorCache.set(schemaPath, v)
  }
  return v
}

function* allKeys(obj: unknown): Generator<string> {
  if (obj && typeof obj === 'object' && !Array.isArray(obj)) {
    for (const key of Object.keys(obj as Record<string, unknown>)) {
      yield key
      yield* allKeys((obj as Record<string, unknown>)[key])
    }
  } else if (Array.isArray(obj)) {
    for (const item of obj) yield* allKeys(item)
  }
}

describe('Wire fixture conformance', () => {
  for (const { shape, fixturePath, schemaPath } of fixtures) {
    const id = `${shape}/${path.basename(fixturePath, '.json')}`

    describe(id, () => {
      const fixture = JSON.parse(fs.readFileSync(fixturePath, 'utf8'))
      const schema = JSON.parse(fs.readFileSync(schemaPath, 'utf8'))

      it('is a JSON object', () => {
        expect(fixture).toBeTypeOf('object')
        expect(Array.isArray(fixture)).toBe(false)
      })

      it('validates against the schema', () => {
        const validate = getValidator(schemaPath)
        const ok = validate(fixture)
        expect(
          ok,
          `${id}: ${JSON.stringify(validate.errors, null, 2)}`,
        ).toBe(true)
      })

      it('round-trips through JSON serialisation', () => {
        const reserialised = JSON.parse(JSON.stringify(fixture))
        const validate = getValidator(schemaPath)
        expect(validate(reserialised)).toBe(true)
      })

      it('uses snake_case keys (canonical wire format)', () => {
        for (const key of allKeys(fixture)) {
          // Reject any uppercase character — canonical wire is snake_case.
          expect(
            /[A-Z]/.test(key),
            `Key ${JSON.stringify(key)} in ${fixturePath} has uppercase ` +
              `characters (canonical wire format is snake_case)`,
          ).toBe(false)
        }
      })
    })
  }
})

describe('Wire fixture coverage', () => {
  it('every schema has at least one fixture', () => {
    const schemas = fs
      .readdirSync(SCHEMAS_DIR)
      .filter((f) => f.endsWith('.schema.json'))
    for (const f of schemas) {
      const shape = f.replace('.schema.json', '')
      const dir = path.join(FIXTURES_DIR, shape)
      expect(fs.existsSync(dir), `No fixtures dir for ${f}`).toBe(true)
      const fixtures = fs
        .readdirSync(dir)
        .filter((x) => x.endsWith('.json'))
      expect(fixtures.length, `No fixtures in ${dir}`).toBeGreaterThan(0)
    }
  })

  it('no orphan fixture directories', () => {
    for (const shape of listShapeDirs()) {
      const schemaPath = path.join(SCHEMAS_DIR, `${shape}.schema.json`)
      expect(
        fs.existsSync(schemaPath),
        `Fixture directory ${shape} has no matching schema`,
      ).toBe(true)
    }
  })
})
