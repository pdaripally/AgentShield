import { describe, it, expect } from 'vitest'
import * as path from 'path'
import {
  RuntimeBuilder,
  Runtime,
  Session,
  StreamingGuard,
  version,
  STAGE_OUTPUT,
  STAGE_POST_TOOL,
} from '../index.js'

/**
 * Node SDK boundary tests.
 *
 * Covers the same surface as the Rust integration tests in
 * `sdk/rust/agent_shield_core/tests/runtime.rs` but only at the napi
 * / JS facade level. The semantic correctness of the engine is
 * verified by the Rust test suite — these tests verify that the Node
 * bindings round-trip JSON, surface the JS API shape correctly, and
 * bridge TSFN callbacks for resolvers / observability / streaming.
 */

const FIXTURES = path.resolve(__dirname, '../../../tests/fixtures/smoke')
const MINIMAL = path.join(FIXTURES, 'minimal.guardrails.yaml')
const VARIABLES = path.join(FIXTURES, 'variables-and-events.guardrails.yaml')

function build(yamlPath: string = MINIMAL): Runtime {
  return RuntimeBuilder.fromYaml(yamlPath).build()
}

function newSession(rt: Runtime, opts?: object): Session {
  return rt.newSession(
    Object.assign(
      {
        sessionId: 'sess-test',
        correlationId: 'corr-test',
      },
      opts ?? {},
    ),
  )
}

// ────────────────────────────────────────────────────────────────────
// Construction
// ────────────────────────────────────────────────────────────────────

describe('RuntimeBuilder', () => {
  it('exposes version', () => {
    expect(typeof version()).toBe('string')
    expect(version().length).toBeGreaterThan(0)
  })

  it('loads from a single YAML file', () => {
    const rt = RuntimeBuilder.fromYaml(MINIMAL).build()
    expect(rt).toBeInstanceOf(Runtime)
    expect(rt.metadataName).toBe('smoke-minimal')
  })

  it('loads from a yaml chain (single file)', () => {
    const rt = RuntimeBuilder.fromYamlChain([MINIMAL]).build()
    expect(rt).toBeInstanceOf(Runtime)
  })

  it('loads the variables fixture', () => {
    const rt = RuntimeBuilder.fromYaml(VARIABLES).build()
    expect(rt.metadataName).toBe('smoke-variables-and-events')
  })

  it('throws on missing file', () => {
    expect(() => RuntimeBuilder.fromYaml('/nonexistent.yaml')).toThrow()
  })

  it('throws on empty chain', () => {
    expect(() => RuntimeBuilder.fromYamlChain([])).toThrow()
  })

  it('build() consumes the builder', () => {
    const b = RuntimeBuilder.fromYaml(MINIMAL)
    b.build()
    expect(() => b.build()).toThrow()
  })

  it('chains tool retry limit', () => {
    const b = RuntimeBuilder.fromYaml(MINIMAL).toolRetryLimit(7)
    expect(b).toBeInstanceOf(RuntimeBuilder)
    b.build()
  })

  it('chains streaming window', () => {
    const b = RuntimeBuilder.fromYaml(MINIMAL).streamingWindow({
      trigger: 'windowed',
      windowSize: 64,
      overlap: 8,
    })
    b.build()
  })
})

// ────────────────────────────────────────────────────────────────────
// Sessions and request context
// ────────────────────────────────────────────────────────────────────

describe('Runtime.newSession', () => {
  it('spawns a session with explicit context', () => {
    const rt = build()
    const s = rt.newSession({
      sessionId: 'sess-99',
      correlationId: 'corr-99',
      userId: 'alice',
      tenantId: 'acme',
      extensions: { region: 'EU' },
    })
    expect(s).toBeInstanceOf(Session)
  })

  it('spawns a session with no context', () => {
    const rt = build()
    const s = rt.newSession()
    expect(s).toBeInstanceOf(Session)
  })

  it('boundary turn ids start at 0', () => {
    const rt = build()
    const s = newSession(rt)
    expect(s.currentTurnId).toBe(0)
    expect(s.currentRequestId).toBe(0)
  })
})

// ────────────────────────────────────────────────────────────────────
// Variables
// ────────────────────────────────────────────────────────────────────

describe('Session variables', () => {
  it('set / read round-trip', () => {
    const rt = build()
    const s = newSession(rt)
    s.setVariable('authorized', true)
    const state = s.readVariable('authorized')
    expect(state).not.toBeNull()
    expect(state!.value).toBe(true)
    expect(state!.status).toBe('resolved')
  })

  it('reset clears a variable to unset', () => {
    const rt = build()
    const s = newSession(rt)
    s.setVariable('authorized', true)
    s.resetVariable('authorized')
    const state = s.readVariable('authorized')
    expect(state).not.toBeNull()
    expect(state!.status).toBe('unset')
  })

  it('readVariable returns null for unknown names', () => {
    const rt = build()
    const s = newSession(rt)
    const state = s.readVariable('does_not_exist')
    expect(state).toBeNull()
  })

  it('setVariable rejects unknown names', () => {
    const rt = build()
    const s = newSession(rt)
    expect(() => s.setVariable('does_not_exist', 1)).toThrow()
  })

  it('round-trips object values', () => {
    const rt = RuntimeBuilder.fromYaml(VARIABLES).build()
    const s = newSession(rt)
    s.setVariable('recipient_profile', {
      sensitivity: 'public',
      name: 'X',
    })
    const state = s.readVariable('recipient_profile')
    expect(state).not.toBeNull()
    expect((state!.value as any).name).toBe('X')
  })

  it('round-trips numeric values', () => {
    const rt = RuntimeBuilder.fromYaml(VARIABLES).build()
    const s = newSession(rt)
    s.setVariable('messages_sent', 42)
    const state = s.readVariable('messages_sent')
    expect(state!.value).toBe(42)
  })
})

// ────────────────────────────────────────────────────────────────────
// Events and boundaries
// ────────────────────────────────────────────────────────────────────

describe('Session events and boundaries', () => {
  it('begin/end turn advances the counter', () => {
    const rt = build()
    const s = newSession(rt)
    expect(s.beginTurn()).toBe(1)
    expect(s.currentTurnId).toBe(1)
    s.endTurn()
    // end_turn does not reset the counter
    expect(s.currentTurnId).toBe(1)
    expect(s.beginTurn()).toBe(2)
    s.endTurn()
  })

  it('begin/end request advances the counter', () => {
    const rt = build()
    const s = newSession(rt)
    expect(s.beginRequest()).toBe(1)
    s.endRequest()
    expect(s.beginRequest()).toBe(2)
    s.endRequest()
  })

  it('emitEvent accepts an incident id', () => {
    const rt = build()
    const s = newSession(rt)
    expect(() =>
      s.emitEvent('incident.threat_detected', { payload: { sev: 'high' } }),
    ).not.toThrow()
  })

  it('emitIncident is a convenience for incident.<name>', () => {
    const rt = build()
    const s = newSession(rt)
    expect(() => s.emitIncident('threat_detected', { sev: 'high' })).not.toThrow()
  })

  it('emitEvent rejects malformed event ids', () => {
    const rt = build()
    const s = newSession(rt)
    expect(() => s.emitEvent('not a valid event id')).toThrow()
  })

  it('clearEvent on a known id is OK', () => {
    const rt = build()
    const s = newSession(rt)
    s.emitEvent('incident.x')
    expect(() => s.clearEvent('incident.x')).not.toThrow()
  })

  it('end_turn without begin_turn is a no-op', () => {
    const rt = build()
    const s = newSession(rt)
    expect(() => s.endTurn()).not.toThrow()
  })
})

// ────────────────────────────────────────────────────────────────────
// Stage 1 — input validation
// ────────────────────────────────────────────────────────────────────

describe('Session.validateInput', () => {
  it('returns a StageVerdict object', async () => {
    const rt = build()
    const s = newSession(rt)
    const v = await s.validateInput('hello')
    expect(v).toHaveProperty('allowed')
    expect(v).toHaveProperty('action')
    expect(v).toHaveProperty('reason')
    expect(v).toHaveProperty('evaluateWhenIndex')
    expect(v).toHaveProperty('bypassedByAllowedWhen')
  })

  it('allows benign input by default', async () => {
    const rt = build()
    const s = newSession(rt)
    const v = await s.validateInput('how are you?')
    expect(v.allowed).toBe(true)
  })
})

// ────────────────────────────────────────────────────────────────────
// Stage 3 — tool / endpoint / agent calls
// ────────────────────────────────────────────────────────────────────

describe('Session.validateToolCall', () => {
  it('blocks unauthorized tool when state requires authorization', async () => {
    const rt = build()
    const s = newSession(rt)
    const r = await s.validateToolCall('echo', { msg: 'hi' }, 'call_1')
    // minimal fixture's `state_validation.echo_only_when_authorized`
    // triggers with `authorized == false` (default).
    expect(r.verdict.allowed).toBe(false)
    expect(r.verdict.policy).toBe('echo_only_when_authorized')
  })

  it('allows the tool when authorized', async () => {
    const rt = build()
    const s = newSession(rt)
    s.setVariable('authorized', true)
    const r = await s.validateToolCall('echo', { msg: 'hi' }, 'call_1')
    expect(r.verdict.allowed).toBe(true)
  })

  it('round-trips params with full fidelity', async () => {
    const rt = build()
    const s = newSession(rt)
    s.setVariable('authorized', true)
    const r = await s.validateToolCall('echo', {
      a: 1,
      b: ['x', 'y'],
      nested: { k: 'v' },
    }, 'call_1')
    expect(r.params).toEqual({ a: 1, b: ['x', 'y'], nested: { k: 'v' } })
  })

  it('returns verdict for endpoint calls', async () => {
    const rt = build()
    const s = newSession(rt)
    s.setVariable('authorized', true)
    const r = await s.validateEndpointCall('GET', '/health', null, 'call_1')
    expect(r.verdict).toHaveProperty('allowed')
  })

  it('returns verdict for agent calls', async () => {
    const rt = build()
    const s = newSession(rt)
    s.setVariable('authorized', true)
    const r = await s.validateAgentCall('summarizer', { query: 'hi' }, 'call_1')
    expect(r.verdict).toHaveProperty('allowed')
  })
})

// ────────────────────────────────────────────────────────────────────
// Stage 4 / Stage 5 — output validation
// ────────────────────────────────────────────────────────────────────

describe('Session.validateToolOutput / validateOutput', () => {
  it('Stage 4 returns { verdict, result }', async () => {
    const rt = build()
    const s = newSession(rt)
    // Prebind Stage 3 with the same id so Stage 4 has a binding.
    await s.validateToolCall('echo', {}, 'call_1')
    const r = await s.validateToolOutput('echo', { ok: true }, 'call_1')
    expect(r.verdict).toHaveProperty('allowed')
    expect(r.result).toEqual({ ok: true })
  })

  it('Stage 5 returns { verdict, response }', async () => {
    const rt = build()
    const s = newSession(rt)
    const r = await s.validateOutput('here is the answer')
    expect(r.verdict).toHaveProperty('allowed')
    expect(typeof r.response).toBe('string')
  })
})

// ────────────────────────────────────────────────────────────────────
// Resource cycle helpers
// ────────────────────────────────────────────────────────────────────

describe('Session resource cycle helpers', () => {
  it('recordToolSuccess does not throw', () => {
    const rt = build()
    const s = newSession(rt)
    expect(() => s.recordToolSuccess('echo', { ok: true })).not.toThrow()
  })
  it('recordToolFailure does not throw', () => {
    const rt = build()
    const s = newSession(rt)
    expect(() => s.recordToolFailure('echo', 'boom')).not.toThrow()
  })
  it('endpoint and agent record helpers do not throw', () => {
    const rt = build()
    const s = newSession(rt)
    expect(() => s.recordEndpointSuccess('/health', { ok: true })).not.toThrow()
    expect(() => s.recordEndpointFailure('/health', 'err')).not.toThrow()
    expect(() => s.recordAgentSuccess('a', {})).not.toThrow()
    expect(() => s.recordAgentFailure('a', 'err')).not.toThrow()
  })
})

// ────────────────────────────────────────────────────────────────────
// Streaming
// ────────────────────────────────────────────────────────────────────

describe('Session streaming', () => {
  it('streamingSession accepts a stage name', () => {
    const rt = build()
    const s = newSession(rt)
    const g = s.streamingSession('output')
    expect(g).toBeInstanceOf(StreamingGuard)
  })

  it('streamingSession accepts a stage number', () => {
    const rt = build()
    const s = newSession(rt)
    const g = s.streamingSession(STAGE_OUTPUT)
    expect(g).toBeInstanceOf(StreamingGuard)
  })

  it('streamingSession rejects unknown stage', () => {
    const rt = build()
    const s = newSession(rt)
    expect(() => s.streamingSession('weird' as any)).toThrow()
    expect(() => s.streamingSession(99 as any)).toThrow()
  })

  it('addChunk + finish round-trips a payload', async () => {
    const rt = build()
    const s = newSession(rt)
    const g = s.streamingSession('output')
    const r1 = await g.addChunk('hello ')
    expect(r1).toHaveProperty('action')
    const r2 = await g.finish()
    expect(['pass', 'replace', 'stop']).toContain(r2.action)
  })

  it('exposes STAGE_POST_TOOL / STAGE_OUTPUT constants', () => {
    expect(STAGE_POST_TOOL).toBe(4)
    expect(STAGE_OUTPUT).toBe(5)
    expect(StreamingGuard.POST_TOOL).toBe(4)
    expect(StreamingGuard.OUTPUT).toBe(5)
  })
})

// ────────────────────────────────────────────────────────────────────
// Host hooks — TSFN bridge
// ────────────────────────────────────────────────────────────────────

describe('RuntimeBuilder host hooks', () => {
  it('observability provider receives log events', async () => {
    const captured: any[] = []
    const rt = RuntimeBuilder.fromYaml(MINIMAL)
      .registerProvider((event) => {
        captured.push(event)
      })
      .build()
    const s = newSession(rt)
    s.beginTurn()
    await s.validateInput('hello')
    s.endTurn()
    // Synchronous TSFN dispatch is non-blocking — give the runtime a
    // tick to flush.
    await new Promise((r) => setTimeout(r, 50))
    expect(captured.length).toBeGreaterThan(0)
    const ev = captured[0]
    expect(ev).toHaveProperty('eventType')
    expect(ev).toHaveProperty('correlationId')
  })

  it('register* methods are chainable', () => {
    const rt = RuntimeBuilder.fromYaml(MINIMAL)
      .registerAgentResolver(() => ({ decision: 'deny' }))
      .registerLlmCaller(() => ({ decision: 'allow' }))
      .registerClassifierCaller(() => ({ score: 0, threshold: 0.5 }))
      .registerProvider(() => undefined)
      .build()
    expect(rt).toBeInstanceOf(Runtime)
  })

  it('kind: human suspends and resolveVariable returns null', async () => {
    // Under the refactored model, `kind: human` no longer accepts a
    // host callback — the runtime emits a canonical-tool-call signal
    // (`agent_shield.ask_human`) and the variable stays unset until
    // the agent calls that MCP tool. Direct resolveVariable() yields
    // null because the resolver suspended.
    const rt = RuntimeBuilder.fromYaml(VARIABLES).build()
    const s = newSession(rt)
    const v = await s.resolveVariable('send_authorized')
    expect(v).toBeNull()
  })
})

// ────────────────────────────────────────────────────────────────────
// JSON shape — verdict, variable state, etc.
// ────────────────────────────────────────────────────────────────────

describe('verdict shape', () => {
  it('uses camelCase keys throughout', async () => {
    const rt = build()
    const s = newSession(rt)
    const v = await s.validateInput('hello world')
    // None of the snake_case keys leak to the JS surface.
    expect(v).not.toHaveProperty('evaluate_when_index')
    expect(v).not.toHaveProperty('bypassed_by_allowed_when')
  })

  it('VariableState uses camelCase', () => {
    const rt = build()
    const s = newSession(rt)
    s.setVariable('authorized', true)
    const state = s.readVariable('authorized')!
    expect(state).toHaveProperty('setAt')
    expect(state).toHaveProperty('expiresAt')
    expect(state).not.toHaveProperty('set_at')
  })
})
