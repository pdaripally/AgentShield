/**
 * Cross-language integration test runner for Agent Shield (Node.js).
 *
 * Loads shared YAML test cases from ``tests/cases/`` and shared fixtures
 * from ``tests/fixtures/``, then runs each test case against the
 * Node.js bindings exposed via ``agent-shield`` (alias: ``sdk/node/index``).
 *
 * Usage::
 *
 *   node --test sdk/node/__tests__/integration_cases.test.mjs
 *
 * Requires::
 *
 *   - the napi module built into ``sdk/node/`` (RuntimeBuilder etc.)
 *   - Node.js >= 18 (built-in test runner)
 *
 * The harness recognizes the action / assertion vocabulary documented
 * in ``tests/cases/test-cases.schema.json``.
 */

import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const REPO_ROOT = path.resolve(__dirname, '../../..')
const CASES_DIR = path.join(REPO_ROOT, 'tests', 'cases')
const FIXTURES_DIR = path.join(REPO_ROOT, 'tests', 'fixtures')
const SDK_DIR = path.join(REPO_ROOT, 'sdk', 'node')

import { createRequire } from 'node:module'
const sdkRequire = createRequire(path.join(SDK_DIR, 'package.json'))
const { parse: parseYaml } = sdkRequire('yaml')

// ── Import the Node SDK ─────────────────────────────────────────
//
// `agent-shield` exports `RuntimeBuilder`, `Runtime`, `Session`. After
// `npm run build:wrapper` the TypeScript wrapper is compiled into
// `dist/index.js` (per the package's `main` field). We import that
// build output directly rather than the source `index.ts` so the test
// runs against exactly what consumers receive when they
// `require('agent-shield')`.
const sdkModule = await import(pathToFileURL(path.join(SDK_DIR, 'dist', 'index.js')).href)
const { RuntimeBuilder } = sdkModule

// ── Fixture resolution ─────────────────────────────────────────────

function findFixture(name) {
  const direct = path.join(FIXTURES_DIR, name)
  if (fs.existsSync(direct)) return direct
  const leaf = path.basename(name)
  for (const child of fs.readdirSync(FIXTURES_DIR)) {
    const candidate = path.join(FIXTURES_DIR, child, leaf)
    if (fs.existsSync(candidate)) return candidate
  }
  throw new Error(`Fixture not found: ${name}`)
}

function resolveFixturePaths(given) {
  return (given.fixtures || []).map((f) => findFixture(f))
}

// ── Test case loading ──────────────────────────────────────────────

function loadAllCases() {
  const cases = []
  const files = fs
    .readdirSync(CASES_DIR)
    .filter((f) => f.endsWith('.cases.yaml'))
    .sort()
  for (const file of files) {
    const content = fs.readFileSync(path.join(CASES_DIR, file), 'utf-8')
    const data = parseYaml(content)
    const suiteName = data.suite || path.basename(file, '.cases.yaml')
    for (const c of data.cases || []) {
      const caseId = `${suiteName}::${c.name || 'unnamed'}`
      c._suiteFixtures = data.fixtures
      c._suiteFixture = data.fixture
      cases.push({ id: caseId, case: c })
    }
  }
  return cases
}

function getGiven(testCase) {
  const given = { ...(testCase.given || {}) }
  if (!given.fixtures) {
    if (testCase._suiteFixtures) {
      given.fixtures = testCase._suiteFixtures
    } else if (testCase._suiteFixture) {
      const scenarioDir = path.join(FIXTURES_DIR, testCase._suiteFixture)
      if (fs.existsSync(scenarioDir) && fs.statSync(scenarioDir).isDirectory()) {
        given.fixtures = fs
          .readdirSync(scenarioDir)
          .filter((f) => f.endsWith('.guardrails.yaml'))
          .sort()
      }
    }
  }
  return given
}

// ── Reusable test stubs ────────────────────────────────────────────

class CallCounter {
  constructor() {
    this.calls = []
  }
  record(kind, variable, request) {
    this.calls.push({ kind, variable: variable || '', request: { ...request } })
  }
  wasCalled(variable, kind = null) {
    return this.calls.some(
      (c) => c.variable === variable && (kind === null || c.kind === kind),
    )
  }
}

function makeCannedResolver(kind, canned, counter) {
  return (request) => {
    const variable = request.variable ?? null
    const prompt = request.prompt ?? null
    counter.record(kind, variable, request)

    let entry = null
    if (variable != null) entry = canned[variable]
    if (!entry && prompt) {
      for (const v of Object.values(canned)) {
        if (v && typeof v === 'object' && v.prompt === prompt) {
          entry = v
          break
        }
      }
    }
    if (!entry) {
      const keys = Object.keys(canned)
      if (keys.length === 1) entry = canned[keys[0]]
    }
    if (!entry) {
      return {
        decision: 'deny',
        reason: `${kind} resolver: no canned response (variable=${variable})`,
      }
    }
    const out = { decision: entry.decision ?? 'deny' }
    if ('value' in entry) out.value = entry.value
    if (entry.set_variables || entry.setVariables) {
      out.set_variables = entry.set_variables ?? entry.setVariables
    }
    if (entry.reason !== undefined) out.reason = entry.reason
    return out
  }
}

// ── Runtime factory ────────────────────────────────────────────────

function buildRuntime(paths, given) {
  const canned = given.resolvers || {}
  const counter = new CallCounter()
  const captured = []

  let builder
  if (paths.length === 1) {
    builder = RuntimeBuilder.fromYaml(paths[0])
  } else {
    builder = RuntimeBuilder.fromYamlChain(paths)
  }

  builder = builder
    .registerProvider((event) => {
      captured.push(event)
    })
    .registerAgentResolver(makeCannedResolver('agent', canned, counter))
    .registerDelegateDispatcher(makeCannedResolver('delegate', canned, counter))
  // Note: `kind: human` is no longer a callback-bound resolver. It
  // dispatches through the canonical `agent_shield.ask_human` MCP tool
  // path, so there is no `registerHumanResolver` to call here. This
  // mirrors the Python harness (sdk/python/tests/test_integration_cases.py).

  // Default-allow LLM / classifier callers so guard policies that use
  // `llm:` / `classifier:` detection don't fail-closed for lack of a
  // registered caller in tests that don't specifically exercise them.
  try {
    builder = builder.registerLlmCaller(() => ({ decision: 'allow' }))
  } catch (_) {}
  try {
    builder = builder.registerClassifierCaller(() => ({
      score: 0.0,
      threshold: 0.5,
      flagged: false,
    }))
  } catch (_) {}

  const runtime = builder.build()
  return { runtime, captured, counter }
}

function openSession(runtime) {
  const session = runtime.newSession({
    sessionId: 'harness-session',
    correlationId: 'harness-correlation',
  })
  try {
    session.beginRequest()
  } catch (_) {}
  try {
    session.beginTurn()
  } catch (_) {}
  return session
}

// ── Action dispatch ────────────────────────────────────────────────

function getParams(action) {
  return { ...(action.params || {}) }
}

async function executeAction(session, action) {
  const verb = action.action || action.type
  const p = getParams(action)

  switch (verb) {
    case 'validate_input': {
      const text = p.input ?? action.input ?? ''
      return await session.validateInput(text)
    }
    case 'validate_tool_call': {
      const tool = p.tool_name ?? action.tool_name ?? ''
      const params = p.tool_params ?? action.tool_params ?? {}
      const toolCallId = p.tool_call_id ?? action.tool_call_id ?? 'case_invocation'
      return await session.validateToolCall(tool, params, toolCallId)
    }
    case 'validate_tool_output': {
      const tool = p.tool_name ?? action.tool_name ?? 'unknown_tool'
      const result =
        p.output !== undefined
          ? p.output
          : p.result !== undefined
          ? p.result
          : action.output !== undefined
          ? action.output
          : action.result
      const toolCallId = p.tool_call_id ?? action.tool_call_id ?? 'case_invocation'
      // §16.0 auto-prebind-on-fallback: standalone Stage-4 cases get a
      // Stage-3 admit on retry so their policy logic still runs.
      let outcome = await session.validateToolOutput(tool, result ?? null, toolCallId)
      if (outcome?.verdict?.allowed === false && outcome.verdict.policy === '<binding>') {
        const prebindParams = p.tool_params ?? action.tool_params ?? {}
        await session.validateToolCall(tool, prebindParams, toolCallId)
        outcome = await session.validateToolOutput(tool, result ?? null, toolCallId)
      }
      return outcome
    }
    case 'validate_endpoint_call': {
      const method = p.method ?? action.method ?? 'GET'
      const uri =
        p.path ?? p.uri ?? p.url ?? action.path ?? action.url ?? ''
      const body = p.body !== undefined ? p.body : p.query_params
      const toolCallId = p.tool_call_id ?? action.tool_call_id ?? 'case_invocation'
      return await session.validateEndpointCall(method, uri, body ?? null, toolCallId)
    }
    case 'validate_agent_call': {
      const agent = p.agent_name ?? action.agent_name ?? ''
      const params = p.agent_params ?? action.agent_params ?? {}
      const toolCallId = p.tool_call_id ?? action.tool_call_id ?? 'case_invocation'
      return await session.validateAgentCall(agent, params, toolCallId)
    }
    case 'validate_output': {
      const text = p.output ?? action.output ?? ''
      return await session.validateOutput(text)
    }
    case 'set_variable': {
      const name = p.name ?? action.name
      const value = p.value !== undefined ? p.value : action.value
      session.setVariable(name, value)
      return null
    }
    case 'reset_variable': {
      const name = p.name ?? action.name
      session.resetVariable(name)
      return null
    }
    case 'resolve_variable': {
      const name = p.name ?? action.name
      return await session.resolveVariable(name)
    }
    case 'emit_event': {
      const eventId = p.id ?? action.id
      session.emitEvent(eventId, {
        lifetime: p.lifetime,
        payload: p.payload,
      })
      return null
    }
    case 'clear_event': {
      const eventId = p.id ?? action.id
      session.clearEvent(eventId)
      return null
    }
    case 'emit_incident': {
      const name = p.name ?? action.name
      session.emitIncident(name, p.payload)
      return null
    }
    case 'begin_turn':
      return session.beginTurn()
    case 'end_turn':
      session.endTurn()
      return null
    case 'begin_request':
      return session.beginRequest()
    case 'end_request':
      session.endRequest()
      return null
    case 'record_tool_success': {
      const tool = p.tool_name ?? action.tool_name
      const result = p.result !== undefined ? p.result : action.result
      session.recordToolSuccess(tool, result ?? null)
      return null
    }
    case 'record_tool_failure': {
      const tool = p.tool_name ?? action.tool_name
      const error = p.error ?? action.error ?? ''
      session.recordToolFailure(tool, error)
      return null
    }
    case 'record_endpoint_success': {
      const pattern =
        p.pattern ?? p.uri ?? p.path ?? action.pattern ?? ''
      session.recordEndpointSuccess(pattern, p.result ?? null)
      return null
    }
    case 'record_endpoint_failure': {
      const pattern =
        p.pattern ?? p.uri ?? p.path ?? action.pattern ?? ''
      session.recordEndpointFailure(pattern, p.error ?? '')
      return null
    }
    case 'record_agent_success': {
      const agent = p.agent_name ?? action.agent_name
      session.recordAgentSuccess(agent, p.result ?? null)
      return null
    }
    case 'record_agent_failure': {
      const agent = p.agent_name ?? action.agent_name
      session.recordAgentFailure(agent, p.error ?? '')
      return null
    }
    default:
      throw new Error(`Unknown action verb: ${verb}`)
  }
}

// ── Verdict / text view extraction ─────────────────────────────────

function verdictView(result) {
  if (result == null) return { verdict: null, text: null }
  if ('allowed' in result && !('verdict' in result)) {
    return { verdict: result, text: null }
  }
  if ('verdict' in result) {
    let text = null
    for (const attr of ['response', 'result', 'params', 'body']) {
      if (typeof result[attr] === 'string') {
        text = result[attr]
        break
      }
    }
    return { verdict: result.verdict, text }
  }
  return { verdict: null, text: null }
}

// ── Assertion checking ─────────────────────────────────────────────

function eventIdMatches(event, expectedId) {
  if (event.eventId === expectedId) return true
  const attrs = event.attributes || {}
  return attrs['agent_shield.event.id'] === expectedId
}

function logEventMatches(event, want) {
  for (const [key, expected] of Object.entries(want)) {
    if (key === 'message_contains') {
      const actual = event.message ?? ''
      if (!actual.includes(expected)) return false
      continue
    }
    if (key === 'attributes') {
      const actualAttrs = event.attributes || {}
      for (const [ak, av] of Object.entries(expected || {})) {
        if (actualAttrs[ak] !== av) return false
      }
      continue
    }
    // top-level field — try camelCase first, fall back to snake_case.
    const camel = key.replace(/_([a-z])/g, (_, c) => c.toUpperCase())
    const actual = event[camel] !== undefined ? event[camel] : event[key]
    if (actual !== expected) return false
  }
  return true
}

function eventSummary(e) {
  return {
    eventType: e.eventType ?? e.event_type,
    stage: e.stage,
    guardPolicy: e.guardPolicy ?? e.guard_policy,
    category: e.category,
    eventId: e.eventId ?? e.event_id,
  }
}

function checkAssertions(session, result, expected, caseName, captured, counter) {
  if (!expected) return
  const { verdict, text } = verdictView(result)

  if ('allowed' in expected) {
    assert.ok(verdict, `[${caseName}] expected verdict but got ${result}`)
    assert.equal(
      verdict.allowed,
      expected.allowed,
      `[${caseName}] expected allowed=${expected.allowed}, got ${verdict.allowed} (action=${verdict.action}, reason=${verdict.reason})`,
    )
  }

  if ('expect_verdict_action' in expected) {
    assert.ok(verdict)
    assert.equal(
      verdict.action,
      expected.expect_verdict_action,
      `[${caseName}] expected action=${expected.expect_verdict_action}, got ${verdict.action}`,
    )
  }

  if ('expect_verdict_reason' in expected) {
    assert.ok(verdict)
    const reason = verdict.reason ?? ''
    assert.ok(
      reason.includes(expected.expect_verdict_reason),
      `[${caseName}] expected reason to contain '${expected.expect_verdict_reason}', got '${reason}'`,
    )
  }

  if ('expect_verdict_policy' in expected) {
    assert.ok(verdict)
    assert.equal(
      verdict.policy,
      expected.expect_verdict_policy,
      `[${caseName}] expected policy=${expected.expect_verdict_policy}, got ${verdict.policy}`,
    )
  }

  if ('text_contains' in expected) {
    const body = text ?? result?.output ?? result?.response ?? ''
    assert.ok(
      String(body).includes(expected.text_contains),
      `[${caseName}] expected output to contain '${expected.text_contains}', got '${body}'`,
    )
  }

  if ('text_not_contains' in expected) {
    const body = text ?? result?.output ?? result?.response ?? ''
    const items = Array.isArray(expected.text_not_contains)
      ? expected.text_not_contains
      : [expected.text_not_contains]
    for (const item of items) {
      assert.ok(
        !String(body).includes(item),
        `[${caseName}] expected output to NOT contain '${item}', got '${body}'`,
      )
    }
  }

  if ('expect_variable_status' in expected) {
    const cfg = expected.expect_variable_status
    const state = session.readVariable(cfg.name)
    const actual = state ? state.status : 'unset'
    assert.equal(
      actual,
      cfg.status,
      `[${caseName}] expected variable ${cfg.name} status=${cfg.status}, got ${actual}`,
    )
  }

  if ('expect_variable_value' in expected) {
    const cfg = expected.expect_variable_value
    const state = session.readVariable(cfg.name)
    const actual = state ? state.value : null
    if ('value' in cfg) {
      assert.deepStrictEqual(
        actual,
        cfg.value,
        `[${caseName}] expected variable ${cfg.name} value=${JSON.stringify(cfg.value)}, got ${JSON.stringify(actual)}`,
      )
    }
  }

  if ('expect_event_fired' in expected) {
    const eid = expected.expect_event_fired
    const fired = captured.some((ev) => eventIdMatches(ev, eid))
    assert.ok(fired, `[${caseName}] expected event '${eid}' to be fired`)
  }

  if ('expect_event_not_fired' in expected) {
    const eid = expected.expect_event_not_fired
    const fired = captured.some((ev) => eventIdMatches(ev, eid))
    assert.ok(!fired, `[${caseName}] expected event '${eid}' NOT to be fired`)
  }

  if ('expect_resolver_called' in expected) {
    const cfg = expected.expect_resolver_called
    assert.ok(
      counter.wasCalled(cfg.variable, cfg.kind ?? null),
      `[${caseName}] expected resolver call for variable '${cfg.variable}' (kind=${cfg.kind ?? '*'}); got calls=${JSON.stringify(counter.calls)}`,
    )
  }

  if ('expect_log_event' in expected) {
    const match = expected.expect_log_event
    const ok = captured.some((ev) => logEventMatches(ev, match))
    assert.ok(
      ok,
      `[${caseName}] expected log event matching ${JSON.stringify(match)}; saw ${JSON.stringify(captured.map(eventSummary))}`,
    )
  }
}

// ── Pre-state setup ─────────────────────────────────────────────────

function seedSession(session, given) {
  for (const [name, value] of Object.entries(given.variables || {})) {
    session.setVariable(name, value)
  }
  for (const entry of given.events || []) {
    if (typeof entry === 'string') {
      session.emitEvent(entry)
    } else {
      session.emitEvent(entry.id, {
        lifetime: entry.lifetime,
        payload: entry.payload,
      })
    }
  }
}

// ── Run all cases ──────────────────────────────────────────────────

const allCases = loadAllCases()

describe('Cross-language integration tests (Node.js)', () => {
  for (const { id, case: testCase } of allCases) {
    it(id, async (t) => {
      const given = getGiven(testCase)
      const fixtures = given.fixtures || []
      if (fixtures.length === 0) {
        t.skip('No fixtures defined')
        return
      }

      let paths
      try {
        paths = resolveFixturePaths(given)
      } catch (err) {
        t.skip(`Fixture not found: ${err.message}`)
        return
      }

      const { runtime, captured, counter } = buildRuntime(paths, given)
      const session = openSession(runtime)

      try {
        seedSession(session, given)

        if (testCase.when && testCase.then) {
          const result = await executeAction(session, testCase.when)
          checkAssertions(session, result, testCase.then, id, captured, counter)
          return
        }

        for (let i = 0; i < (testCase.steps || []).length; i++) {
          const step = testCase.steps[i]
          const stepName = `${id}[step ${i}]`
          const actionData = step.when || step
          const result = await executeAction(session, actionData)
          const expected = step.then || step.expected
          if (expected) {
            checkAssertions(session, result, expected, stepName, captured, counter)
          }
        }
      } finally {
        try {
          session.endTurn()
        } catch (_) {}
        try {
          session.endRequest()
        } catch (_) {}
      }
    })
  }
})
