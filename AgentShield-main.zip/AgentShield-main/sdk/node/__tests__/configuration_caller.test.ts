// Tests for `makeConfigurationCaller` — cross-SDK parity helper.
//
// Mirrors `sdk/python/tests/test_configuration_dispatcher.py` and the
// Rust core tests in `runtime/configuration_caller.rs`.

import { describe, expect, test } from 'vitest'

import { makeConfigurationCaller, type LlmRequest } from '../index.js'

function recording(label: string) {
  const calls: string[] = []
  const fn = (prompt: string) => {
    calls.push(prompt)
    return `${label}:${prompt}`
  }
  return Object.assign(fn, { calls })
}

function req(configurationId: string | null, prompt: string): LlmRequest {
  return { configurationId, prompt }
}

describe('makeConfigurationCaller — exact-match dispatch', () => {
  test('routes to registered caller by exact match', () => {
    const inputCaller = recording('input')
    const toolCaller = recording('tool')

    const dispatcher = makeConfigurationCaller({
      input_llm: inputCaller,
      tool_execution_llm: toolCaller,
    })

    expect(dispatcher(req('input_llm', 'hello'))).toBe('input:hello')
    expect(dispatcher(req('tool_execution_llm', 'calc'))).toBe('tool:calc')
    expect(inputCaller.calls).toEqual(['hello'])
    expect(toolCaller.calls).toEqual(['calc'])
  })

  test('substring match does NOT route', () => {
    const inputCaller = recording('input')
    const fallback = recording('default')

    const dispatcher = makeConfigurationCaller(
      { input_llm: inputCaller },
      { default: fallback },
    )

    // 'my_input_check' contains 'input' — substring would have matched in
    // the deprecated implementation. Exact match only.
    expect(dispatcher(req('my_input_check', 'hello'))).toBe('default:hello')
    expect(inputCaller.calls).toEqual([])
    expect(fallback.calls).toEqual(['hello'])
  })
})

describe('makeConfigurationCaller — default fallback', () => {
  test('default used for unknown id', () => {
    const fallback = recording('default')
    const dispatcher = makeConfigurationCaller({}, { default: fallback })
    expect(dispatcher(req('never_registered', 'x'))).toBe('default:x')
  })

  test('default used when configurationId is null', () => {
    const fallback = recording('default')
    const dispatcher = makeConfigurationCaller(
      { input_llm: recording('input') },
      { default: fallback },
    )
    expect(dispatcher(req(null, 'x'))).toBe('default:x')
  })

  test('no default — unknown id throws', () => {
    const dispatcher = makeConfigurationCaller({
      input_llm: recording('input'),
    })
    expect(() => dispatcher(req('unknown_id', 'x'))).toThrow(/no LLM caller registered/)
  })

  test('error lists known ids', () => {
    const dispatcher = makeConfigurationCaller({
      a: recording('a'),
      b: recording('b'),
    })
    expect(() => dispatcher(req('c', 'x'))).toThrow(/'a'.*'b'/)
  })
})

describe('makeConfigurationCaller — isolation', () => {
  test('callers map is copied — mutating source does not affect dispatcher', () => {
    const caller = recording('a')
    const callers: Record<string, (p: string) => unknown> = { a: caller }
    const dispatcher = makeConfigurationCaller(callers)
    // Mutate the source — dispatcher must still route.
    for (const k of Object.keys(callers)) delete callers[k]
    expect(dispatcher(req('a', 'x'))).toBe('a:x')
  })

  test('inherited Object.prototype keys do not match', () => {
    // Regression: `{ ...callers }['toString']` returns Object.prototype.toString
    // unless routing uses an own-property check. The dispatcher must treat
    // 'toString', 'constructor', 'hasOwnProperty', etc. as unknown ids.
    const dispatcher = makeConfigurationCaller({})
    for (const id of ['toString', 'constructor', 'hasOwnProperty', '__proto__']) {
      expect(() => dispatcher(req(id, 'x'))).toThrow(/no LLM caller registered/)
    }
  })
})
