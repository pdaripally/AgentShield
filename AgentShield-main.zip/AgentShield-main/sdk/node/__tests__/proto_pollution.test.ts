// Regression tests for the `Shield.prototype` prototype-pollution bug.
//
// History: the LangChain / OpenAI / Anthropic adapters all installed
// idempotent `Shield.prototype.run = ...`, `Shield.prototype.protectTool
// = ...`, and `Shield.BUNDLE = ...` patches at `require` time. The
// `if (!proto.run) ...` guard meant whichever adapter was loaded
// first WON, and `shield.run(fn)` quietly behaved differently
// depending on import order — a load-order security hazard.
//
// The fix moves canonical `run` and `protectTool` onto the base
// `Shield` class (`sdk/node/shield.js`) and forbids adapters from
// touching those names or `Shield.BUNDLE`. These tests pin that
// contract.

import { describe, it, expect } from 'vitest'
import * as path from 'node:path'

import {
  RuntimeBuilder,
  Shield,
  ShieldBuilder,
} from '../index.js'

const FIXTURES = path.resolve(
  __dirname,
  '..',
  '..',
  '..',
  'tests',
  'fixtures',
  'smoke',
)
const MINIMAL = path.join(FIXTURES, 'minimal.guardrails.yaml')

// Snapshot the canonical implementations BEFORE any adapter is
// (re-)loaded. This is the implementation a customer who never
// imports an adapter sees, and it must remain identical regardless
// of which adapters subsequently load.
const BASE_RUN_SOURCE = (Shield.prototype as any).run.toString()
const BASE_PROTECT_TOOL_SOURCE = (
  Shield.prototype as any
).protectTool.toString()

describe('Shield.prototype is owned by the base class', () => {
  it('Shield.run and Shield.protectTool are present without any adapter loaded', () => {
    expect(typeof (Shield.prototype as any).run).toBe('function')
    expect(typeof (Shield.prototype as any).protectTool).toBe('function')
  })

  it('Shield (base) constructs and runs Stage 1+5 with no adapter', async () => {
    // Construct Shield without any framework bundle. `shield.run(fn)`
    // is the framework-agnostic Stage 1+5 wrapper and MUST work.
    const runtime = RuntimeBuilder.fromYaml(MINIMAL).build()
    const shield = new (Shield as any)(runtime)
    const out = await (shield as any).run(async () => 'hello world', {
      userInput: 'hi',
    })
    expect(out).toBe('hello world')
  })

  it('shield.protectTool returns { blocked, output } shape (canonical Stage 2/3/4)', async () => {
    const runtime = RuntimeBuilder.fromYaml(MINIMAL).build()
    const shield = new (Shield as any)(runtime)
    const result = await (shield as any).protectTool(
      'echo',
      { msg: 'hi' },
      async (effective: Record<string, unknown>) => `pong:${effective.msg}`,
    )
    expect(typeof result).toBe('object')
    expect(typeof result.blocked).toBe('boolean')
    expect(typeof result.output).toBe('string')
  })
})

describe('Adapter load order does not pollute Shield.prototype', () => {
  it('loading langchain.js does not replace Shield.prototype.run', async () => {
    await import('../adapters/langchain.js')
    expect((Shield.prototype as any).run.toString()).toBe(BASE_RUN_SOURCE)
    expect((Shield.prototype as any).protectTool.toString()).toBe(
      BASE_PROTECT_TOOL_SOURCE,
    )
  })

  it('loading openai_agents.js does not replace Shield.prototype.run or protectTool', async () => {
    await import('../adapters/openai_agents.js')
    expect((Shield.prototype as any).run.toString()).toBe(BASE_RUN_SOURCE)
    expect((Shield.prototype as any).protectTool.toString()).toBe(
      BASE_PROTECT_TOOL_SOURCE,
    )
  })

  it('loading anthropic_agents.js does not replace Shield.prototype.run or protectTool', async () => {
    await import('../adapters/anthropic_agents.js')
    expect((Shield.prototype as any).run.toString()).toBe(BASE_RUN_SOURCE)
    expect((Shield.prototype as any).protectTool.toString()).toBe(
      BASE_PROTECT_TOOL_SOURCE,
    )
  })

  it('after loading langchain + openai, BOTH framework helpers are reachable', async () => {
    await import('../adapters/langchain.js')
    await import('../adapters/openai_agents.js')
    // Framework-specific helpers from each adapter coexist on the prototype.
    expect(typeof (Shield.prototype as any).createLangchainAgent).toBe(
      'function',
    )
    expect(typeof (Shield.prototype as any).runOpenaiAgent).toBe('function')
    expect(typeof (Shield.prototype as any).protectOpenaiTools).toBe(
      'function',
    )
    // And the base contract is still untouched.
    expect((Shield.prototype as any).run.toString()).toBe(BASE_RUN_SOURCE)
    expect((Shield.prototype as any).protectTool.toString()).toBe(
      BASE_PROTECT_TOOL_SOURCE,
    )
  })

  it('shield.run(fn) is identical regardless of which adapter loaded', async () => {
    // Fresh imports (cached). The string representation of the
    // function we'd dispatch through must be the same one we
    // snapshotted before any adapter loaded.
    await import('../adapters/langchain.js')
    await import('../adapters/openai_agents.js')
    await import('../adapters/anthropic_agents.js')

    const runtime = RuntimeBuilder.fromYaml(MINIMAL).build()
    const shield = new (Shield as any)(runtime)
    const out = await (shield as any).run(async () => 'final', {
      userInput: '',
    })
    expect(out).toBe('final')

    // And the textual identity check pins the prototype-pollution fix.
    expect((Shield.prototype as any).run.toString()).toBe(BASE_RUN_SOURCE)
    expect((Shield.prototype as any).protectTool.toString()).toBe(
      BASE_PROTECT_TOOL_SOURCE,
    )
  })
})

describe('Shield.BUNDLE is NOT set by adapter side effects', () => {
  it('Shield.BUNDLE is undefined on the base class even after adapters load', async () => {
    await import('../adapters/langchain.js')
    await import('../adapters/openai_agents.js')
    await import('../adapters/anthropic_agents.js')
    expect((Shield as any).BUNDLE).toBeUndefined()
  })

  it('Shield.fromYaml(MINIMAL).build() without .with<Framework>() yields a generic Shield', async () => {
    await import('../adapters/openai_agents.js')
    await import('../adapters/langchain.js')
    const shield = (Shield as any).fromYaml(MINIMAL).build()
    expect(shield).toBeInstanceOf(Shield)
    // No bundle → reading `.capabilities` is the explicit-error path.
    expect(() => (shield as any).capabilities).toThrow(
      /no capability bundle/i,
    )
    // The generic `run(fn)` still works, because it does not need a bundle.
    const out = await (shield as any).run(async () => 'hi')
    expect(out).toBe('hi')
  })

  it('Adding .withLangchain() upgrades the build to the LangChain bundle', async () => {
    await import('../adapters/langchain.js')
    const shield: any = (Shield as any)
      .fromYaml(MINIMAL)
      .withLangchain()
      .build()
    expect(shield.capabilities.framework).toBe('langchain')
  })

  it('Adding .withOpenaiAgents() upgrades the build to the OpenAI bundle', async () => {
    await import('../adapters/openai_agents.js')
    const shield: any = (Shield as any)
      .fromYaml(MINIMAL)
      .withOpenaiAgents()
      .build()
    expect(shield.capabilities.framework).toBe('openai_agents')
  })

  it('Adding .withAnthropic() upgrades the build to the Anthropic bundle', async () => {
    await import('../adapters/anthropic_agents.js')
    const shield: any = (Shield as any)
      .fromYaml(MINIMAL)
      .withAnthropic()
      .build()
    expect(shield.capabilities.framework).toBe('anthropic_agents')
  })
})

describe('Builder still exposes with<Framework> hooks', () => {
  it('ShieldBuilder.prototype carries withLangchain / withOpenaiAgents / withAnthropic', async () => {
    await import('../adapters/langchain.js')
    await import('../adapters/openai_agents.js')
    await import('../adapters/anthropic_agents.js')
    expect(typeof (ShieldBuilder.prototype as any).withLangchain).toBe(
      'function',
    )
    expect(typeof (ShieldBuilder.prototype as any).withOpenaiAgents).toBe(
      'function',
    )
    expect(typeof (ShieldBuilder.prototype as any).withAnthropic).toBe(
      'function',
    )
  })
})
