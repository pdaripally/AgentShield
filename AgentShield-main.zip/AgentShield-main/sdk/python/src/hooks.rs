//! PyO3 surface for [`agent_shield_core::integrations::hooks`].
//!
//! Exposes three classes on `agent_shield._native`:
//!
//! - [`PyHookSessionRegistry`] (`HookSessionRegistry`) — bounded
//!   session cache. `acquire(session_id, request_context)` returns
//!   a [`PyHookSession`].
//! - [`PyHookSession`] (`HookSession`) — wraps the live
//!   [`SessionLease`]. Supports `with sess:` via `__enter__` /
//!   `__exit__`; methods cover turn / request lifecycle, scratch
//!   K/V, and resource-cycle records. `release()` is idempotent.
//! - [`PyStageDispatcher`] (`StageDispatcher`) — stateless. Each
//!   stage method returns a Python dict with `dispatch` (the
//!   canonical wire shape from `shield_primitives`) plus, for
//!   Stages 2/3 and 4, the post-mutation effective payload.

use std::sync::Arc;
use std::time::Duration;

use pyo3::exceptions::{PyRuntimeError, PyValueError};
use pyo3::prelude::*;
use pyo3::types::PyDict;

type PyObject = Py<PyAny>;

use agent_shield_core::integrations::hooks::{
    ConcurrencyError, HookSession, RegistryOptions, RequestStateError, RequestToken, SessionLease,
    SessionRegistry, StageDispatcher,
};
use agent_shield_core::shield_primitives::{
    dispatch_outcome_to_wire, tool_dispatch_outcome_to_wire, OnBlockPolicy, ShieldMode,
};
use agent_shield_core::{GuardrailsRuntime, RequestContext};

use crate::{json_value_to_py, py_to_json_value};

// ─── Helpers: parse policy/mode strings ─────────────────────────────

fn parse_mode(s: &str) -> PyResult<ShieldMode> {
    ShieldMode::from_wire_str(s).ok_or_else(|| {
        PyValueError::new_err(format!(
            "unknown ShieldMode: {s:?} (expected \"enforce\" or \"monitor\")"
        ))
    })
}

fn parse_policy(s: &str) -> PyResult<OnBlockPolicy> {
    OnBlockPolicy::from_wire_str(s).ok_or_else(|| {
        PyValueError::new_err(format!(
            "unknown OnBlockPolicy: {s:?} (expected \"return_blocked\", \"return_verdict\", \"raise\", or \"custom\")"
        ))
    })
}

fn build_request_context(d: Option<&Bound<'_, PyDict>>) -> PyResult<RequestContext> {
    let mut ctx = RequestContext::default();
    if let Some(d) = d {
        if let Ok(Some(v)) = d.get_item("session_id") {
            if let Ok(s) = v.extract::<String>() {
                ctx.session_id = s;
            }
        }
        if let Ok(Some(v)) = d.get_item("correlation_id") {
            if let Ok(s) = v.extract::<String>() {
                ctx.correlation_id = s;
            }
        }
        if let Ok(Some(v)) = d.get_item("user_id") {
            if let Ok(s) = v.extract::<String>() {
                ctx.user_id = Some(s);
            }
        }
        if let Ok(Some(v)) = d.get_item("tenant_id") {
            if let Ok(s) = v.extract::<String>() {
                ctx.tenant_id = Some(s);
            }
        }
        if let Ok(Some(v)) = d.get_item("extensions") {
            if !v.is_none() {
                if let Ok(jv) = py_to_json_value(&v) {
                    ctx.extensions = jv;
                }
            }
        }
    }
    Ok(ctx)
}

// ─── HookSessionRegistry ───────────────────────────────────────────

#[pyclass(name = "HookSessionRegistry", module = "agent_shield._native")]
pub struct PyHookSessionRegistry {
    inner: SessionRegistry,
    in_flight_timeout: Duration,
}

#[pymethods]
impl PyHookSessionRegistry {
    /// Construct a registry around an existing `GuardrailsRuntime`.
    ///
    /// `runtime` must be the `_native.GuardrailsRuntime` instance
    /// returned by `RuntimeBuilder.build()`. Options keyword args:
    /// `max_size`, `ttl_seconds`, `in_flight_timeout_seconds`.
    #[new]
    #[pyo3(signature = (runtime, max_size=512, ttl_seconds=1800, in_flight_timeout_seconds=300))]
    fn new(
        runtime: &crate::PyGuardrailsRuntime,
        max_size: usize,
        ttl_seconds: u64,
        in_flight_timeout_seconds: u64,
    ) -> PyResult<Self> {
        let rt_arc: Arc<GuardrailsRuntime> = runtime.inner_arc();
        let in_flight_timeout = Duration::from_secs(in_flight_timeout_seconds);
        let opts = RegistryOptions {
            max_size,
            ttl: Duration::from_secs(ttl_seconds),
            in_flight_timeout,
        };
        Ok(Self {
            inner: SessionRegistry::new(rt_arc, opts),
            in_flight_timeout,
        })
    }

    /// Acquire a lease on the session keyed by `session_id`. Returns
    /// a `HookSession` instance that decrements the lease counter on
    /// `release()` or context-manager exit.
    #[pyo3(signature = (session_id, request_context=None))]
    fn acquire(
        &self,
        session_id: &str,
        request_context: Option<&Bound<'_, PyDict>>,
    ) -> PyResult<PyHookSession> {
        let ctx = build_request_context(request_context)?;
        let lease = self
            .inner
            .acquire(session_id, ctx)
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
        Ok(PyHookSession {
            inner: parking_lot::Mutex::new(Some(lease)),
            in_flight_timeout: self.in_flight_timeout,
        })
    }

    fn __len__(&self) -> usize {
        self.inner.len()
    }
}

// ─── HookSession ──────────────────────────────────────────────────

#[pyclass(name = "HookSession", module = "agent_shield._native")]
pub struct PyHookSession {
    /// `None` after explicit `release()` / `__exit__`. All methods
    /// raise `RuntimeError` when the lease has been released.
    inner: parking_lot::Mutex<Option<SessionLease>>,
    in_flight_timeout: Duration,
}

impl PyHookSession {
    fn with_lease<F, R>(&self, f: F) -> PyResult<R>
    where
        F: FnOnce(&SessionLease) -> PyResult<R>,
    {
        let guard = self.inner.lock();
        match guard.as_ref() {
            Some(lease) => f(lease),
            None => Err(PyRuntimeError::new_err(
                "HookSession has been released; acquire a fresh lease",
            )),
        }
    }
}

#[pymethods]
impl PyHookSession {
    /// Idempotent: no-op if a turn is already open.
    fn begin_turn(&self) -> PyResult<()> {
        self.with_lease(|l| {
            l.begin_turn()
                .map_err(|e| PyRuntimeError::new_err(e.to_string()))
        })
    }

    /// Close the current turn (if any) and open a fresh one.
    fn restart_turn(&self) -> PyResult<()> {
        self.with_lease(|l| {
            l.restart_turn()
                .map_err(|e| PyRuntimeError::new_err(e.to_string()))
        })
    }

    /// Close the current turn. No-op if no turn is open.
    fn end_turn(&self) -> PyResult<()> {
        self.with_lease(|l| {
            l.end_turn()
                .map_err(|e| PyRuntimeError::new_err(e.to_string()))
        })
    }

    fn turn_is_open(&self) -> PyResult<bool> {
        self.with_lease(|l| Ok(l.turn_is_open()))
    }

    /// Begin a request scope. Returns an opaque integer token the
    /// caller MUST present to `end_request` when the logical
    /// request completes (across however many hook callbacks).
    ///
    /// Raises `agent_shield._native.ConcurrencyError` (a subclass of
    /// `RuntimeError`) when another request is already in flight and
    /// not yet stale per the registry's `in_flight_timeout`.
    fn begin_request(&self) -> PyResult<u64> {
        self.with_lease(|l| {
            l.begin_request(Some(self.in_flight_timeout))
                .map(|t| t.0)
                .map_err(|e| match e {
                    ConcurrencyError::AlreadyInFlight { age } => PyRuntimeError::new_err(format!(
                        "another request is in flight for this session (age={:?})",
                        age
                    )),
                    ConcurrencyError::SessionError(msg) => PyRuntimeError::new_err(msg),
                })
        })
    }

    /// Retire a request token. Safe to call with a stale or already-
    /// retired token — returns a short string ("ok" | "mismatch" |
    /// "no_request_open") rather than raising, so the failure-hook
    /// double-call path doesn't need defensive try/except.
    fn end_request(&self, token: u64) -> PyResult<&'static str> {
        self.with_lease(|l| {
            Ok(match l.end_request(RequestToken(token)) {
                Ok(()) => "ok",
                Err(RequestStateError::Mismatch) => "mismatch",
                Err(RequestStateError::NoRequestOpen) => "no_request_open",
            })
        })
    }

    /// Retire whatever request is currently open. Convenience for
    /// hosts that don't want to plumb the token across hook
    /// invocations. Returns the same status strings as
    /// :py:meth:`end_request`. No-op when no request is open.
    fn end_current_request(&self) -> PyResult<&'static str> {
        self.with_lease(|l| {
            Ok(match l.end_current_request() {
                Ok(()) => "ok",
                Err(RequestStateError::NoRequestOpen) => "no_request_open",
                Err(RequestStateError::Mismatch) => "mismatch",
            })
        })
    }

    fn request_is_open(&self) -> PyResult<bool> {
        self.with_lease(|l| Ok(l.request_is_open()))
    }

    fn turn_kv_set(
        &self,
        py: Python<'_>,
        key: &str,
        value: &Bound<'_, PyAny>,
    ) -> PyResult<PyObject> {
        let val = py_to_json_value(value)?;
        self.with_lease(|l| {
            let prev = l.turn_kv_set(key, val);
            match prev {
                Some(v) => json_value_to_py(py, &v),
                None => Ok(py.None()),
            }
        })
    }

    fn turn_kv_get(&self, py: Python<'_>, key: &str) -> PyResult<PyObject> {
        self.with_lease(|l| match l.turn_kv_get(key) {
            Some(v) => json_value_to_py(py, &v),
            None => Ok(py.None()),
        })
    }

    fn turn_kv_remove(&self, py: Python<'_>, key: &str) -> PyResult<PyObject> {
        self.with_lease(|l| match l.turn_kv_remove(key) {
            Some(v) => json_value_to_py(py, &v),
            None => Ok(py.None()),
        })
    }

    fn turn_kv_keys(&self) -> PyResult<Vec<String>> {
        self.with_lease(|l| Ok(l.turn_kv_keys()))
    }

    fn record_tool_success(&self, tool_name: &str, result: &Bound<'_, PyAny>) -> PyResult<()> {
        let val = py_to_json_value(result)?;
        self.with_lease(|l| {
            l.record_tool_success(tool_name, &val)
                .map_err(|e| PyRuntimeError::new_err(e.to_string()))
        })
    }

    fn record_tool_failure(&self, tool_name: &str, error: &str) -> PyResult<()> {
        self.with_lease(|l| {
            l.record_tool_failure(tool_name, error)
                .map_err(|e| PyRuntimeError::new_err(e.to_string()))
        })
    }

    /// Drop the lease. Idempotent.
    fn release(&self) {
        let _ = self.inner.lock().take();
    }

    /// Return a `GuardrailsSession` Python object that shares the
    /// same underlying Rust session as this lease. Use this when
    /// existing code expects a `GuardrailsSession` for direct
    /// `validate_*` / `record_*` calls; turn / request lifecycle and
    /// stage dispatch should still go through the `HookSession` /
    /// `StageDispatcher` API.
    fn guardrails_session(&self) -> PyResult<crate::PyGuardrailsSession> {
        self.with_lease(|lease| {
            Ok(crate::PyGuardrailsSession::from_arc(
                lease.session().session().clone(),
            ))
        })
    }

    fn __enter__(slf: PyRef<'_, Self>) -> PyRef<'_, Self> {
        slf
    }

    #[pyo3(signature = (_exc_type=None, _exc=None, _tb=None))]
    fn __exit__(
        &self,
        _exc_type: Option<PyObject>,
        _exc: Option<PyObject>,
        _tb: Option<PyObject>,
    ) -> PyResult<bool> {
        self.release();
        Ok(false)
    }
}

/// Internal helper for the dispatcher: returns Python references to
/// the lease's inner [`HookSession`] so we can pass `&HookSession` to
/// the core dispatcher. Implemented as a method on the dispatcher
/// class rather than a free function so PyO3 type plumbing stays
/// straightforward.
fn with_session_ref<F, R>(sess: &PyHookSession, f: F) -> PyResult<R>
where
    F: FnOnce(&HookSession) -> PyResult<R>,
{
    sess.with_lease(|lease| f(lease.session()))
}

// ─── StageDispatcher ──────────────────────────────────────────────

#[pyclass(
    name = "StageDispatcher",
    module = "agent_shield._native",
    skip_from_py_object
)]
#[derive(Default, Clone, Copy)]
pub struct PyStageDispatcher;

#[pymethods]
impl PyStageDispatcher {
    #[new]
    fn new() -> Self {
        Self
    }

    /// Stage 1.
    ///
    /// Returns a dict `{"dispatch": <VerdictDispatch wire shape>}`.
    /// The dispatch wire shape mirrors `dispatch_outcome_to_wire` from
    /// `shield_primitives.rs`.
    #[pyo3(signature = (session, user_input, mode="enforce", policy="return_blocked"))]
    fn validate_input(
        &self,
        py: Python<'_>,
        session: &PyHookSession,
        user_input: &str,
        mode: &str,
        policy: &str,
    ) -> PyResult<PyObject> {
        let m = parse_mode(mode)?;
        let p = parse_policy(policy)?;
        let disp = StageDispatcher;
        let result = with_session_ref(session, |s| Ok(disp.validate_input(s, user_input, m, p)))?;
        let wire = dispatch_outcome_to_wire(&result.dispatch);
        let dict = PyDict::new(py);
        dict.set_item("dispatch", json_value_to_py(py, &wire)?)?;
        Ok(dict.into_pyobject(py)?.into_any().unbind())
    }

    /// Stages 2 + 3.
    ///
    /// `params` is consumed and the post-Stage-3 effective params are
    /// returned alongside the dispatch. Returns a dict
    /// `{"dispatch": ..., "effective_params": <serialised JSON>}`.
    #[pyo3(signature = (session, tool_name, params, tool_call_id, mode="enforce", policy="return_blocked"))]
    #[allow(clippy::too_many_arguments)]
    fn validate_tool_call(
        &self,
        py: Python<'_>,
        session: &PyHookSession,
        tool_name: &str,
        params: &Bound<'_, PyAny>,
        tool_call_id: &str,
        mode: &str,
        policy: &str,
    ) -> PyResult<PyObject> {
        let params_val = py_to_json_value(params)?;
        let m = parse_mode(mode)?;
        let p = parse_policy(policy)?;
        let disp = StageDispatcher;
        let result = with_session_ref(session, |s| {
            Ok(disp.validate_tool_call(s, tool_name, params_val, tool_call_id, m, p))
        })?;
        let wire = tool_dispatch_outcome_to_wire(&result.dispatch);
        let dict = PyDict::new(py);
        dict.set_item("dispatch", json_value_to_py(py, &wire)?)?;
        dict.set_item(
            "effective_params",
            json_value_to_py(py, &result.effective_params)?,
        )?;
        Ok(dict.into_pyobject(py)?.into_any().unbind())
    }

    /// Stage 4.
    ///
    /// `output` is the structured tool result; post-Stage-4 effective
    /// output is returned alongside the dispatch. Returns a dict
    /// `{"dispatch": ..., "effective_output": <serialised JSON>}`.
    #[pyo3(signature = (session, tool_name, output, tool_call_id, mode="enforce", policy="return_blocked"))]
    #[allow(clippy::too_many_arguments)]
    fn validate_tool_output(
        &self,
        py: Python<'_>,
        session: &PyHookSession,
        tool_name: &str,
        output: &Bound<'_, PyAny>,
        tool_call_id: &str,
        mode: &str,
        policy: &str,
    ) -> PyResult<PyObject> {
        let output_val = py_to_json_value(output)?;
        let m = parse_mode(mode)?;
        let p = parse_policy(policy)?;
        let disp = StageDispatcher;
        let result = with_session_ref(session, |s| {
            Ok(disp.validate_tool_output(s, tool_name, output_val, tool_call_id, m, p))
        })?;
        let wire = tool_dispatch_outcome_to_wire(&result.dispatch);
        let dict = PyDict::new(py);
        dict.set_item("dispatch", json_value_to_py(py, &wire)?)?;
        dict.set_item(
            "effective_output",
            json_value_to_py(py, &result.effective_output)?,
        )?;
        Ok(dict.into_pyobject(py)?.into_any().unbind())
    }

    /// Stage 5.
    ///
    /// `content` is the assistant's final text. Returns a dict
    /// `{"dispatch": ...}`. Stage 5 mutation is encoded in the
    /// dispatch wire shape via `ProceedWithMutation`.
    #[pyo3(signature = (session, content, mode="enforce", policy="return_blocked"))]
    fn validate_output(
        &self,
        py: Python<'_>,
        session: &PyHookSession,
        content: &str,
        mode: &str,
        policy: &str,
    ) -> PyResult<PyObject> {
        let m = parse_mode(mode)?;
        let p = parse_policy(policy)?;
        let disp = StageDispatcher;
        let mut buf = String::from(content);
        let result = with_session_ref(session, |s| Ok(disp.validate_output(s, &mut buf, m, p)))?;
        let wire = dispatch_outcome_to_wire(&result.dispatch);
        let dict = PyDict::new(py);
        dict.set_item("dispatch", json_value_to_py(py, &wire)?)?;
        Ok(dict.into_pyobject(py)?.into_any().unbind())
    }
}
