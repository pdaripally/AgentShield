//! Python bindings for Agent Shield (`agent_shield._native` module).
//!
//! Exposes the unified-resolver runtime API via PyO3.
//! Classes: `RuntimeBuilder`, `GuardrailsRuntime`, `GuardrailsSession`, `StreamingGuard`,
//! `HookSessionRegistry`, `HookSession`, `StageDispatcher`.

use std::collections::HashMap;
use std::path::Path;
use std::sync::Arc;

use pyo3::exceptions::{PyRuntimeError, PyValueError};
use pyo3::prelude::*;
use pyo3::types::{PyDict, PyList};

type PyObject = Py<PyAny>;

pub mod hooks;

use agent_shield_core::guard_policy_runtime::streaming::StreamingTrigger;
use agent_shield_core::resolver_runtime::{
    AgentResolveRequest, AgentResolver, DelegateDispatcher, DelegateRequest, ResolverRuntimeError,
};
use agent_shield_core::{
    Action, ClassifierCaller, ClassifierVerdict, CompiledPolicy, Extractor, GuardrailsConfig,
    GuardrailsRuntime, GuardrailsSession, Lifetime, LlmCaller, LlmResponse, ObsStage,
    ObservabilityProvider, RequestContext, ResolverDecision, ResolverResponse, RuntimeBuilder,
    RuntimeError, ShieldLogEvent, StreamChunkAction, StreamChunkResult, StreamingGuard,
};

// ─── Helper: serde_json::Value ↔ PyObject ───────────────────────────

pub(crate) fn json_value_to_py(py: Python<'_>, val: &serde_json::Value) -> PyResult<PyObject> {
    Ok(match val {
        serde_json::Value::Null => py.None(),
        serde_json::Value::Bool(b) => b.into_pyobject(py)?.to_owned().into_any().unbind(),
        serde_json::Value::Number(n) => {
            if let Some(i) = n.as_i64() {
                i.into_pyobject(py)?.to_owned().into_any().unbind()
            } else if let Some(u) = n.as_u64() {
                // u64 values larger than i64::MAX still fit in a Python
                // int losslessly via PyO3's u64 conversion. Preserved so
                // the JSON↔Python round-trip never silently downgrades
                // to f64.
                u.into_pyobject(py)?.to_owned().into_any().unbind()
            } else if let Some(f) = n.as_f64() {
                f.into_pyobject(py)?.to_owned().into_any().unbind()
            } else {
                py.None()
            }
        }
        serde_json::Value::String(s) => s.into_pyobject(py)?.into_any().unbind(),
        serde_json::Value::Array(arr) => {
            let list = PyList::empty(py);
            for item in arr {
                list.append(json_value_to_py(py, item)?)?;
            }
            list.into_pyobject(py)?.into_any().unbind()
        }
        serde_json::Value::Object(map) => {
            let dict = PyDict::new(py);
            for (k, v) in map {
                dict.set_item(k, json_value_to_py(py, v)?)?;
            }
            dict.into_pyobject(py)?.into_any().unbind()
        }
    })
}

pub(crate) fn py_to_json_value(obj: &Bound<'_, PyAny>) -> PyResult<serde_json::Value> {
    if obj.is_none() {
        Ok(serde_json::Value::Null)
    } else if let Ok(b) = obj.extract::<bool>() {
        Ok(serde_json::Value::Bool(b))
    } else if let Ok(i) = obj.extract::<i64>() {
        Ok(serde_json::Value::Number(i.into()))
    } else if let Ok(u) = obj.extract::<u64>() {
        // u64 values exceeding i64::MAX still fit losslessly. Try u64
        // before f64 so we never lose precision on a positive integer.
        Ok(serde_json::Value::Number(u.into()))
    } else if let Ok(f) = obj.extract::<f64>() {
        Ok(serde_json::json!(f))
    } else if let Ok(s) = obj.extract::<String>() {
        Ok(serde_json::Value::String(s))
    } else if let Ok(list) = obj.cast::<PyList>() {
        let mut arr = Vec::new();
        for item in list.iter() {
            arr.push(py_to_json_value(&item)?);
        }
        Ok(serde_json::Value::Array(arr))
    } else if let Ok(dict) = obj.cast::<PyDict>() {
        let mut map = serde_json::Map::new();
        for (k, v) in dict.iter() {
            let key: String = k.extract()?;
            map.insert(key, py_to_json_value(&v)?);
        }
        Ok(serde_json::Value::Object(map))
    } else {
        // Fallback: convert to string
        let s = obj.str()?.to_string();
        Ok(serde_json::Value::String(s))
    }
}

// ─── Helper conversions ─────────────────────────────────────────────

/// Convert any PyAny → serde_yaml::Value (used to deserialize Lifetime).
fn py_to_yaml_value(obj: &Bound<'_, PyAny>) -> PyResult<serde_yaml::Value> {
    let json = py_to_json_value(obj)?;
    let s = serde_json::to_string(&json)
        .map_err(|e| PyValueError::new_err(format!("serialize error: {e}")))?;
    serde_yaml::from_str::<serde_yaml::Value>(&s)
        .map_err(|e| PyValueError::new_err(format!("YAML parse error: {e}")))
}

fn parse_lifetime_internal(obj: &Bound<'_, PyAny>) -> PyResult<Lifetime> {
    let yv = py_to_yaml_value(obj)?;
    serde_yaml::from_value::<Lifetime>(yv)
        .map_err(|e| PyValueError::new_err(format!("invalid lifetime: {e}")))
}

/// Parse a lifetime value (string for the bare keyword form, dict for
/// the map / `for:` / `until_event:` forms) and return the canonical
/// representation as a Python value (string or dict).
///
/// Routes through `agent_shield_core::lifetime::parse_lifetime`, the
/// single canonical lifetime parser shared by every language SDK.
#[pyfunction]
#[pyo3(name = "parse_lifetime")]
fn py_parse_lifetime(py: Python<'_>, value: &Bound<'_, PyAny>) -> PyResult<PyObject> {
    let json = py_to_json_value(value)?;
    let lt = agent_shield_core::lifetime::parse_lifetime(json)
        .map_err(|e| PyValueError::new_err(format!("invalid lifetime: {e}")))?;
    let out = serde_json::to_value(&lt)
        .map_err(|e| PyValueError::new_err(format!("serialize lifetime: {e}")))?;
    json_value_to_py(py, &out)
}

// ─── Canonical verdict-handling decision (Stage 1/5 + tools) ────────

fn parse_policy_str(s: &str) -> PyResult<agent_shield_core::OnBlockPolicy> {
    agent_shield_core::OnBlockPolicy::from_wire_str(s)
        .ok_or_else(|| PyValueError::new_err(format!("unknown on_block policy: {s:?}")))
}

fn parse_mode_str(s: &str) -> PyResult<agent_shield_core::ShieldMode> {
    agent_shield_core::ShieldMode::from_wire_str(s)
        .ok_or_else(|| PyValueError::new_err(format!("unknown shield mode: {s:?}")))
}

fn verdict_dict_to_core(obj: &Bound<'_, PyAny>) -> PyResult<agent_shield_core::StageVerdict> {
    let json = py_to_json_value(obj)?;
    agent_shield_core::stage_verdict_from_wire(&json)
        .ok_or_else(|| PyValueError::new_err("malformed StageVerdict wire shape"))
}

/// Canonical Stage 1 / Stage 5 verdict-handling decision.
///
/// Routes through `agent_shield_core::dispatch_stage_verdict` so the
/// orchestrator decision is byte-equivalent across every SDK.
///
/// Args:
///   verdict: dict in the canonical `StageVerdict` wire shape (the
///     same dict :meth:`Session.validate_input` returns).
///   policy: on-block policy string ('return_blocked' | 'return_verdict'
///     | 'raise' | 'custom'). Defaults to 'return_blocked'.
///   mode: enforcement mode string ('enforce' | 'monitor'). Defaults to
///     'enforce'.
///
/// Returns a dict with keys `action` (`{kind, value?, message?}`),
/// `record_block` (bool), `override_to_proceed` (bool).
#[pyfunction]
#[pyo3(name = "dispatch_stage_verdict", signature = (verdict, policy="return_blocked", mode="enforce"))]
fn py_dispatch_stage_verdict(
    py: Python<'_>,
    verdict: &Bound<'_, PyAny>,
    policy: &str,
    mode: &str,
) -> PyResult<PyObject> {
    let v = verdict_dict_to_core(verdict)?;
    let p = parse_policy_str(policy)?;
    let m = parse_mode_str(mode)?;
    let outcome = agent_shield_core::dispatch_stage_verdict(&v, p, m);
    let json = agent_shield_core::dispatch_outcome_to_wire(&outcome);
    json_value_to_py(py, &json)
}

/// Canonical Stage 2/3/4 (tool-call) verdict-handling decision.
///
/// Args:
///   verdict: dict in the canonical `StageVerdict` wire shape.
///   tool_name: the tool name (rendered as `(tool: <name>)` suffix).
///   stage: 'call' for Stage 2/3 (pre-execute) or 'output' for Stage 4
///     (post-execute). Defaults to 'output'.
///   policy: on-block policy string. Defaults to 'return_blocked'.
///   mode: enforcement mode string. Defaults to 'enforce'.
///
/// Returns a dict with `action`, `record_failure`, `record_success`,
/// `override_to_proceed`.
#[pyfunction]
#[pyo3(name = "dispatch_tool_verdict", signature = (verdict, tool_name, stage="output", policy="return_blocked", mode="enforce"))]
fn py_dispatch_tool_verdict(
    py: Python<'_>,
    verdict: &Bound<'_, PyAny>,
    tool_name: &str,
    stage: &str,
    policy: &str,
    mode: &str,
) -> PyResult<PyObject> {
    let v = verdict_dict_to_core(verdict)?;
    let p = parse_policy_str(policy)?;
    let m = parse_mode_str(mode)?;
    let s = match stage {
        "call" | "Call" | "stage23" | "stage_23" => agent_shield_core::ToolStage::Call,
        "output" | "Output" | "stage4" | "stage_4" => agent_shield_core::ToolStage::Output,
        other => {
            return Err(PyValueError::new_err(format!(
                "unknown tool stage: {other:?}; expected 'call' or 'output'"
            )))
        }
    };
    let outcome = agent_shield_core::dispatch_tool_verdict(&v, tool_name, s, p, m);
    let json = agent_shield_core::tool_dispatch_outcome_to_wire(&outcome);
    json_value_to_py(py, &json)
}

/// Format a verdict as the canonical `[GUARDRAIL ACTION] reason`
/// string. Hands off to `agent_shield_core::format_block_message` so
/// every SDK produces byte-equivalent strings.
#[pyfunction]
#[pyo3(name = "format_block_message")]
fn py_format_block_message(verdict: &Bound<'_, PyAny>) -> PyResult<String> {
    let v = verdict_dict_to_core(verdict)?;
    Ok(agent_shield_core::format_block_message(&v))
}

fn map_runtime_error(e: RuntimeError) -> PyErr {
    PyRuntimeError::new_err(e.to_string())
}

/// Convert StageVerdict → Python dict.
fn stage_verdict_to_py(py: Python<'_>, v: &agent_shield_core::StageVerdict) -> PyResult<PyObject> {
    let dict = PyDict::new(py);
    dict.set_item("allowed", v.allowed)?;
    dict.set_item("action", v.action.map(|a| action_str(a).to_string()))?;
    dict.set_item("reason", v.reason.clone())?;
    dict.set_item("policy", v.policy.clone())?;
    dict.set_item("evaluate_when_index", v.evaluate_when_index)?;
    dict.set_item("bypassed_by_allowed_when", v.bypassed_by_allowed_when)?;
    dict.set_item("redaction", v.redaction.clone())?;
    dict.set_item("appended", v.appended.clone())?;
    dict.set_item("prepended", v.prepended.clone())?;
    dict.set_item(
        "pending_resolution",
        match &v.pending_resolution {
            Some(p) => {
                let pd = PyDict::new(py);
                pd.set_item("tool", p.tool.clone())?;
                pd.set_item("variable", p.variable.clone())?;
                pd.set_item("prompt", p.prompt.clone())?;
                pd.set_item("request_id", p.request_id.clone())?;
                pd.set_item("kind", p.kind)?;
                pd.into_pyobject(py)?.into_any().unbind()
            }
            None => py.None(),
        },
    )?;
    dict.set_item("invocation_hash", v.invocation_hash.clone())?;
    dict.set_item(
        "post_validation_invocation_hash",
        v.post_validation_invocation_hash.clone(),
    )?;
    Ok(dict.into_pyobject(py)?.into_any().unbind())
}

fn action_str(a: Action) -> &'static str {
    match a {
        Action::Block => "block",
        Action::Redact => "redact",
        Action::Warn => "warn",
        Action::Append => "append",
        Action::Prepend => "prepend",
        Action::DeclassifyTo => "declassify_to",
    }
}

/// String form of a [`LogAction`] — superset of [`Action`] with an
/// `allow` variant (§19.1).
fn log_action_str(a: agent_shield_core::observability::LogAction) -> &'static str {
    a.as_str()
}

fn stream_action_str(a: &StreamChunkAction) -> &'static str {
    match a {
        StreamChunkAction::Pass => "pass",
        StreamChunkAction::Replace => "replace",
        StreamChunkAction::Stop => "stop",
    }
}

fn stream_result_to_py(py: Python<'_>, r: &StreamChunkResult) -> PyResult<PyObject> {
    let dict = PyDict::new(py);
    dict.set_item("action", stream_action_str(&r.action))?;
    dict.set_item("payload", r.payload.clone())?;
    dict.set_item("reason", r.reason.clone())?;
    Ok(dict.into_pyobject(py)?.into_any().unbind())
}

fn shield_log_event_to_py(py: Python<'_>, e: &ShieldLogEvent) -> PyResult<PyObject> {
    let dict = PyDict::new(py);
    dict.set_item("timestamp", e.timestamp.to_rfc3339())?;
    dict.set_item("severity", e.severity.as_str())?;
    dict.set_item("event_type", e.event_type.as_str())?;
    dict.set_item("category", e.category.clone())?;
    dict.set_item("stage", e.stage.map(|s| s.as_str().to_string()))?;
    dict.set_item("action", e.action.map(|a| log_action_str(a).to_string()))?;
    dict.set_item("guard_policy", e.guard_policy.clone())?;
    dict.set_item("evaluate_when_index", e.evaluate_when_index)?;
    if let Some(ref r) = e.resource {
        let rd = PyDict::new(py);
        rd.set_item("kind", r.kind.as_str())?;
        rd.set_item("name", r.name.clone())?;
        dict.set_item("resource", rd)?;
    } else {
        dict.set_item("resource", py.None())?;
    }
    dict.set_item("variable", e.variable.clone())?;
    dict.set_item("event_id", e.event_id.clone())?;
    dict.set_item("correlation_id", e.correlation_id.clone())?;
    dict.set_item("session_id", e.session_id.clone())?;
    dict.set_item("user_id", e.user_id.clone())?;
    dict.set_item("tenant_id", e.tenant_id.clone())?;
    dict.set_item("mode", e.mode.map(|m| m.as_wire_str().to_string()))?;
    dict.set_item("enforced", e.enforced)?;
    dict.set_item("message", e.message.clone())?;
    let attrs = PyDict::new(py);
    for (k, v) in &e.attributes {
        attrs.set_item(k, json_value_to_py(py, v)?)?;
    }
    dict.set_item("attributes", attrs)?;
    Ok(dict.into_pyobject(py)?.into_any().unbind())
}

// ─── Python → ResolverResponse parser ────────────────────────────────

/// Parse a Python dict envelope `{decision, value?, set_variables?, reason?}`
/// into a Rust `ResolverResponse`. Unknown decisions fail closed (Deny).
///
/// Internally funnels the Python value through the canonical
/// [`agent_shield_core::parse_resolver_response_json`] parser, so every
/// language binding sees identical semantics for malformed input. Also
/// accepts JSON strings (some hosts return their HTTP response body
/// verbatim) and bare Python dicts equivalently.
fn py_dict_to_resolver_response(py: Python<'_>, obj: &PyObject) -> ResolverResponse {
    let bound = obj.bind(py);
    // Accept either a JSON-encoded string envelope (e.g. an HTTP body
    // bubbled up unchanged) or a Python dict / mapping. Anything else
    // (None, primitives, lists) is an envelope-shape error and must
    // fail closed per §11.3.
    let raw_json = if let Ok(s) = bound.extract::<String>() {
        s
    } else {
        match py_to_json_value(bound) {
            Ok(serde_json::Value::Object(map)) => {
                serde_json::to_string(&serde_json::Value::Object(map))
                    .unwrap_or_else(|_| "{}".into())
            }
            Ok(other) => {
                // Non-object (None, list, primitive). Pass through
                // verbatim so wire_shapes can produce a populated
                // Deny envelope with a useful reason.
                serde_json::to_string(&other).unwrap_or_else(|_| "null".into())
            }
            Err(_) => {
                return ResolverResponse {
                    decision: ResolverDecision::Deny,
                    value: None,
                    set_variables: HashMap::new(),
                    reason: Some("python resolver returned unconvertible envelope".into()),
                }
            }
        }
    };
    agent_shield_core::parse_resolver_response_json(&raw_json)
}

/// Build a §11.10 `resource: {kind, name, params?}` dict and attach it
/// to `d` under the key "resource". Also keeps the flat
/// `resource_kind` / `resource_name` keys so existing Python resolver
/// callbacks keep working unchanged. `params` is included only when
/// `resource_params` is `Some`.
fn add_resource_envelope(
    py: Python<'_>,
    d: &Bound<'_, PyDict>,
    kind: Option<agent_shield_core::ResourceKind>,
    name: Option<&String>,
    params: Option<&serde_json::Value>,
) -> PyResult<()> {
    d.set_item(
        "resource_kind",
        kind.map(|k| resource_kind_str(k).to_string()),
    )?;
    d.set_item("resource_name", name.cloned())?;
    let resource = PyDict::new(py);
    resource.set_item("kind", kind.map(|k| resource_kind_str(k).to_string()))?;
    resource.set_item("name", name.cloned())?;
    if let Some(p) = params {
        resource.set_item("params", json_value_to_py(py, p)?)?;
    }
    d.set_item("resource", resource)?;
    Ok(())
}

fn resource_kind_str(k: agent_shield_core::ResourceKind) -> &'static str {
    match k {
        agent_shield_core::ResourceKind::Tool => "tool",
        agent_shield_core::ResourceKind::Agent => "agent",
        agent_shield_core::ResourceKind::Endpoint => "endpoint",
    }
}

// ─── Hook bridges ────────────────────────────────────────────────────

struct PyAgentResolver {
    callable: PyObject,
}
unsafe impl Send for PyAgentResolver {}
unsafe impl Sync for PyAgentResolver {}

impl AgentResolver for PyAgentResolver {
    fn resolve(&self, req: AgentResolveRequest) -> ResolverResponse {
        Python::attach(|py| {
            let build = || -> PyResult<Bound<'_, PyDict>> {
                let d = PyDict::new(py);
                d.set_item("request_id", req.request_id.clone())?;
                d.set_item("variable", req.variable.clone())?;
                add_resource_envelope(
                    py,
                    &d,
                    req.resource_kind,
                    req.resource_name.as_ref(),
                    req.resource_params.as_ref(),
                )?;
                d.set_item("prompt", req.prompt.clone())?;
                d.set_item("reason", req.reason.clone())?;
                let ctx = PyDict::new(py);
                for (k, v) in &req.context {
                    ctx.set_item(k, json_value_to_py(py, v)?)?;
                }
                d.set_item("context", ctx)?;
                Ok(d)
            };
            let d = match build() {
                Ok(d) => d,
                Err(e) => {
                    log::error!("python agent resolver dict build failed: {}", e);
                    return ResolverResponse {
                        decision: ResolverDecision::Deny,
                        value: None,
                        set_variables: HashMap::new(),
                        reason: Some(format!("python agent resolver dict build failed: {}", e)),
                    };
                }
            };
            match self.callable.call1(py, (d,)) {
                Ok(out) => py_dict_to_resolver_response(py, &out),
                Err(e) => {
                    log::error!("python agent resolver error: {}", e);
                    ResolverResponse {
                        decision: ResolverDecision::Deny,
                        value: None,
                        set_variables: HashMap::new(),
                        reason: Some(format!("python agent resolver error: {}", e)),
                    }
                }
            }
        })
    }
}

struct PyDelegateDispatcher {
    callable: PyObject,
}
unsafe impl Send for PyDelegateDispatcher {}
unsafe impl Sync for PyDelegateDispatcher {}

impl DelegateDispatcher for PyDelegateDispatcher {
    fn dispatch(&self, req: DelegateRequest) -> Result<ResolverResponse, ResolverRuntimeError> {
        Python::attach(|py| {
            let build = || -> PyResult<Bound<'_, PyDict>> {
                let d = PyDict::new(py);
                d.set_item("request_id", req.request_id.clone())?;
                d.set_item("variable", req.variable.clone())?;
                let cfg = PyDict::new(py);
                cfg.set_item("id", req.configuration.id.clone())?;
                cfg.set_item(
                    "type",
                    format!("{:?}", req.configuration.config_type).to_lowercase(),
                )?;
                d.set_item("configuration", cfg)?;
                d.set_item("effective_timeout_ms", req.effective_timeout_ms)?;
                add_resource_envelope(
                    py,
                    &d,
                    req.resource_kind,
                    req.resource_name.as_ref(),
                    req.invocation_params.as_ref(),
                )?;
                d.set_item("prompt", req.prompt.clone())?;
                d.set_item("reason", req.reason.clone())?;
                let ctx = PyDict::new(py);
                for (k, v) in &req.context {
                    ctx.set_item(k, json_value_to_py(py, v)?)?;
                }
                d.set_item("context", ctx)?;
                // §11.12.1: forward the resolver's `lifetime:` hint as JSON so
                // the dispatcher can mint a per-call envelope verbatim.
                if let Some(lh) = &req.lifetime_hint {
                    if let Ok(lh_json) = serde_json::to_value(lh) {
                        d.set_item("lifetime", json_value_to_py(py, &lh_json)?)?;
                    }
                }
                Ok(d)
            };
            let d = match build() {
                Ok(d) => d,
                Err(e) => {
                    log::error!("python delegate dispatcher dict build failed: {}", e);
                    return Err(ResolverRuntimeError::Other {
                        kind: "delegate",
                        message: format!("python delegate dispatcher dict build failed: {}", e),
                    });
                }
            };
            match self.callable.call1(py, (d,)) {
                Ok(out) => Ok(py_dict_to_resolver_response(py, &out)),
                Err(e) => Err(ResolverRuntimeError::Other {
                    kind: "delegate",
                    message: format!("python delegate dispatcher error: {}", e),
                }),
            }
        })
    }
}

struct PyLlmCaller {
    callable: PyObject,
}
unsafe impl Send for PyLlmCaller {}
unsafe impl Sync for PyLlmCaller {}

impl LlmCaller for PyLlmCaller {
    fn call(&self, configuration_id: Option<&str>, prompt: &str) -> Result<LlmResponse, String> {
        Python::attach(|py| {
            let cfg = configuration_id.map(|s| s.to_string());
            let result = self
                .callable
                .call1(py, (cfg, prompt.to_string()))
                .map_err(|e| format!("python llm caller error: {}", e))?;
            // Funnel every shape (bare-word string, JSON string, or
            // Python dict) through the canonical wire_shapes parser in
            // agent_shield_core. This is the same parser the Node and
            // .NET bindings use — keeping it here means a malformed
            // host return CANNOT silently leak as `allow` in any one
            // language but not the others. (cf. the PyLlmCaller silent
            // fail-closed bug fixed in 31ae2c4: previously this bridge
            // had its own parser that handled bare strings + dicts but
            // not JSON strings; centralizing it is the structural fix.)
            let bound = result.bind(py);
            let raw_json = if let Ok(s) = bound.extract::<String>() {
                // String returns pass through verbatim — wire_shapes
                // accepts both bare-word and JSON-envelope strings.
                s
            } else {
                // Anything else (most commonly a Python dict): convert
                // to JSON via py_to_json_value and serialize. The
                // canonical parser then sees the same shape regardless
                // of how the host phrased its return.
                let val = py_to_json_value(bound).map_err(|e| {
                    format!("python llm caller returned unconvertible value: {}", e)
                })?;
                serde_json::to_string(&val)
                    .map_err(|e| format!("python llm caller serialization failed: {}", e))?
            };
            Ok(agent_shield_core::parse_llm_response_json(&raw_json))
        })
    }
}

struct PyClassifierCaller {
    callable: PyObject,
}
unsafe impl Send for PyClassifierCaller {}
unsafe impl Sync for PyClassifierCaller {}

impl ClassifierCaller for PyClassifierCaller {
    fn classify(&self, configuration_id: &str, subject: &str) -> Result<ClassifierVerdict, String> {
        Python::attach(|py| {
            let result = self
                .callable
                .call1(py, (configuration_id.to_string(), subject.to_string()))
                .map_err(|e| format!("python classifier error: {}", e))?;
            // Funnel through the canonical wire_shapes parser. String,
            // dict, or any JSON-shaped value collapse to the same
            // ClassifierVerdict — every binding agrees.
            let bound = result.bind(py);
            let raw_json = if let Ok(s) = bound.extract::<String>() {
                s
            } else {
                let val = py_to_json_value(bound).map_err(|e| {
                    format!("python classifier returned unconvertible value: {}", e)
                })?;
                serde_json::to_string(&val)
                    .map_err(|e| format!("python classifier serialization failed: {}", e))?
            };
            Ok(agent_shield_core::parse_classifier_verdict_json(&raw_json))
        })
    }
}

struct PyV2ObservabilityProvider {
    provider: PyObject,
}
unsafe impl Send for PyV2ObservabilityProvider {}
unsafe impl Sync for PyV2ObservabilityProvider {}

impl ObservabilityProvider for PyV2ObservabilityProvider {
    fn emit(&self, event: ShieldLogEvent) {
        // P12.3: log emit failures rather than swallowing them. Both
        // GIL-attach failures (unlikely, but possible during interpreter
        // shutdown) and exceptions raised inside the inner closure
        // surface here.
        let result = Python::try_attach(|py| -> PyResult<()> {
            let py_event = shield_log_event_to_py(py, &event)?;
            // Accept either a callable or an object with `.emit(event)`.
            let bound = self.provider.bind(py);
            if let Ok(method) = bound.getattr("emit") {
                method.call1((py_event,))?;
            } else {
                self.provider.call1(py, (py_event,))?;
            }
            Ok(())
        });
        match result {
            None => {
                log::error!("observability provider emit skipped: python interpreter not attached");
            }
            Some(Err(e)) => {
                log::error!("observability provider emit failed: {}", e);
            }
            Some(Ok(())) => {}
        }
    }

    fn shutdown(&self) {
        let result = Python::try_attach(|py| -> PyResult<()> {
            let bound = self.provider.bind(py);
            if let Ok(method) = bound.getattr("shutdown") {
                method.call0()?;
            }
            Ok(())
        });
        if let Some(Err(e)) = result {
            log::error!("observability provider shutdown failed: {}", e);
        }
    }
}

struct PyExtractor {
    callable: PyObject,
}
unsafe impl Send for PyExtractor {}
unsafe impl Sync for PyExtractor {}

impl Extractor for PyExtractor {
    fn extract(&self, raw: &serde_json::Value) -> Option<serde_json::Value> {
        Python::attach(|py| {
            let arg = match json_value_to_py(py, raw) {
                Ok(a) => a,
                Err(e) => {
                    log::warn!("python extractor input conversion failed: {}", e);
                    return None;
                }
            };
            match self.callable.call1(py, (arg,)) {
                Ok(out) => {
                    let bound = out.bind(py);
                    if bound.is_none() {
                        return None;
                    }
                    // Funnel through the canonical wire_shapes parser
                    // so every binding agrees on what counts as "skip
                    // this populator" vs. "structured payload".
                    let raw_json = if let Ok(s) = bound.extract::<String>() {
                        s
                    } else {
                        match py_to_json_value(bound) {
                            Ok(v) => serde_json::to_string(&v).ok()?,
                            Err(_) => return None,
                        }
                    };
                    agent_shield_core::parse_extractor_output_json(&raw_json)
                }
                Err(e) => {
                    log::warn!("python extractor error: {}", e);
                    None
                }
            }
        })
    }
}

// ─── PyRuntimeBuilder ──────────────────────────────────────────────

#[pyclass(name = "RuntimeBuilder", unsendable)]
pub struct PyRuntimeBuilder {
    inner: Option<RuntimeBuilder>,
}

#[pymethods]
impl PyRuntimeBuilder {
    #[staticmethod]
    fn from_yaml(path: &str) -> PyResult<Self> {
        let b = RuntimeBuilder::from_yaml(Path::new(path)).map_err(map_runtime_error)?;
        Ok(Self { inner: Some(b) })
    }

    #[staticmethod]
    fn from_yaml_chain(paths: Vec<String>) -> PyResult<Self> {
        let refs: Vec<&Path> = paths.iter().map(|p| Path::new(p.as_str())).collect();
        let b = RuntimeBuilder::from_yaml_chain(&refs).map_err(map_runtime_error)?;
        Ok(Self { inner: Some(b) })
    }

    #[staticmethod]
    fn from_yaml_strings(yamls: Vec<String>) -> PyResult<Self> {
        let refs: Vec<&str> = yamls.iter().map(|s| s.as_str()).collect();
        let b = RuntimeBuilder::from_yaml_strings(&refs).map_err(map_runtime_error)?;
        Ok(Self { inner: Some(b) })
    }

    #[staticmethod]
    fn from_compiled_policy(compiled: &PyCompiledPolicy) -> PyResult<Self> {
        let b = RuntimeBuilder::from_compiled_policy(compiled.inner.as_ref());
        Ok(Self { inner: Some(b) })
    }

    fn register_agent_resolver(&mut self, callable: PyObject) -> PyResult<()> {
        let b = self
            .inner
            .take()
            .ok_or_else(|| PyRuntimeError::new_err("Builder consumed"))?;
        let arc: Arc<dyn AgentResolver> = Arc::new(PyAgentResolver { callable });
        self.inner = Some(b.register_agent_resolver(arc));
        Ok(())
    }

    fn register_delegate_dispatcher(&mut self, callable: PyObject) -> PyResult<()> {
        let b = self
            .inner
            .take()
            .ok_or_else(|| PyRuntimeError::new_err("Builder consumed"))?;
        let arc: Arc<dyn DelegateDispatcher> = Arc::new(PyDelegateDispatcher { callable });
        self.inner = Some(b.register_delegate_dispatcher(arc));
        Ok(())
    }

    fn register_llm_caller(&mut self, callable: PyObject) -> PyResult<()> {
        let b = self
            .inner
            .take()
            .ok_or_else(|| PyRuntimeError::new_err("Builder consumed"))?;
        let arc: Arc<dyn LlmCaller> = Arc::new(PyLlmCaller { callable });
        self.inner = Some(b.register_llm_caller(arc));
        Ok(())
    }

    fn register_classifier_caller(&mut self, callable: PyObject) -> PyResult<()> {
        let b = self
            .inner
            .take()
            .ok_or_else(|| PyRuntimeError::new_err("Builder consumed"))?;
        let arc: Arc<dyn ClassifierCaller> = Arc::new(PyClassifierCaller { callable });
        self.inner = Some(b.register_classifier_caller(arc));
        Ok(())
    }

    fn register_observability_provider(&mut self, provider: PyObject) -> PyResult<()> {
        let b = self
            .inner
            .take()
            .ok_or_else(|| PyRuntimeError::new_err("Builder consumed"))?;
        let arc: Arc<dyn ObservabilityProvider> = Arc::new(PyV2ObservabilityProvider { provider });
        self.inner = Some(b.register_provider(arc));
        Ok(())
    }

    fn register_extractor(&mut self, name: &str, callable: PyObject) -> PyResult<()> {
        let b = self
            .inner
            .take()
            .ok_or_else(|| PyRuntimeError::new_err("Builder consumed"))?;
        let boxed: Box<dyn Extractor> = Box::new(PyExtractor { callable });
        self.inner = Some(b.register_extractor(name, boxed));
        Ok(())
    }

    fn tool_retry_limit(&mut self, n: usize) -> PyResult<()> {
        let b = self
            .inner
            .take()
            .ok_or_else(|| PyRuntimeError::new_err("Builder consumed"))?;
        self.inner = Some(b.tool_retry_limit(n));
        Ok(())
    }

    /// Set the runtime's effective enforcement mode (#14). Accepts
    /// `"active"` or `"shadow"`. The `AGENT_SHIELD_MODE` env var,
    /// when set, takes precedence over this call.
    fn with_mode(&mut self, mode: &str) -> PyResult<()> {
        let b = self
            .inner
            .take()
            .ok_or_else(|| PyRuntimeError::new_err("Builder consumed"))?;
        let m = agent_shield_core::shield_primitives::RuntimeMode::from_wire_str(mode).ok_or_else(
            || {
                PyRuntimeError::new_err(format!(
                    "with_mode: unknown mode {mode:?} (expected `active` or `shadow`)"
                ))
            },
        )?;
        self.inner = Some(b.with_mode(m));
        Ok(())
    }

    /// Declare host capability for sub-session IFC scope reset
    /// (proof TC-3). Required when the merged config declares
    /// `ifc.scope: per_turn` or `per_request`. Hosts that retain
    /// LLM context across these boundaries (LangChain memory,
    /// AutoGen group chats, persistent conversation IDs) MUST NOT
    /// call this with `True`.
    fn supports_context_reset(&mut self, supports: bool) -> PyResult<()> {
        let b = self
            .inner
            .take()
            .ok_or_else(|| PyRuntimeError::new_err("Builder consumed"))?;
        self.inner = Some(b.supports_context_reset(supports));
        Ok(())
    }

    fn build(&mut self) -> PyResult<PyGuardrailsRuntime> {
        let b = self
            .inner
            .take()
            .ok_or_else(|| PyRuntimeError::new_err("Builder consumed"))?;
        let rt = b.build().map_err(map_runtime_error)?;
        Ok(PyGuardrailsRuntime { inner: rt })
    }
}

// ─── PyGuardrailsRuntime ───────────────────────────────────────────

#[pyclass(name = "GuardrailsRuntime")]
pub struct PyGuardrailsRuntime {
    inner: Arc<GuardrailsRuntime>,
}

impl PyGuardrailsRuntime {
    /// Internal accessor used by the hooks pyo3 surface.
    pub(crate) fn inner_arc(&self) -> Arc<GuardrailsRuntime> {
        self.inner.clone()
    }
}

#[pymethods]
impl PyGuardrailsRuntime {
    #[pyo3(signature = (request_context=None))]
    fn new_session(
        &self,
        request_context: Option<&Bound<'_, PyDict>>,
    ) -> PyResult<PyGuardrailsSession> {
        let mut ctx = RequestContext::default();
        if let Some(d) = request_context {
            if let Ok(Some(v)) = d.get_item("session_id") {
                if let Ok(s) = v.extract::<String>() {
                    ctx.session_id = s;
                }
            }
            if let Ok(Some(v)) = d.get_item("correlation_id") {
                if let Ok(s) = v.extract::<String>() {
                    ctx.correlation_id = s;
                }
            }
            if let Ok(Some(v)) = d.get_item("user_id") {
                if let Ok(s) = v.extract::<String>() {
                    ctx.user_id = Some(s);
                }
            }
            if let Ok(Some(v)) = d.get_item("tenant_id") {
                if let Ok(s) = v.extract::<String>() {
                    ctx.tenant_id = Some(s);
                }
            }
            if let Ok(Some(v)) = d.get_item("extensions") {
                if !v.is_none() {
                    if let Ok(jv) = py_to_json_value(&v) {
                        ctx.extensions = jv;
                    }
                }
            }
        }
        let session = self.inner.new_session(ctx);
        Ok(PyGuardrailsSession {
            inner: Arc::new(session),
        })
    }

    fn metadata_name(&self) -> String {
        self.inner.config().metadata.name.clone()
    }

    fn variable_names(&self) -> Vec<String> {
        self.inner.variables().keys().cloned().collect()
    }

    /// Effective runtime mode (#14) — `"active"` or `"shadow"`.
    /// Sourced from `MergedConfig.mode`, which honours the YAML
    /// top-level `mode:` key with `AGENT_SHIELD_MODE` env override.
    fn mode(&self) -> &'static str {
        self.inner.mode().as_wire_str()
    }

    /// Look up a `configurations[]` entry by id (§6).
    ///
    /// Returns a dict mirroring the `ShieldConfiguration` fields for the
    /// resolved entry, or `None` if no entry matches. Used by adapter
    /// LLM-caller closures to honour the YAML's per-stage `model:` /
    /// `provider:` / `max_tokens:` selection rather than hard-coding a
    /// model name.
    fn llm_configuration(
        &self,
        py: Python<'_>,
        configuration_id: &str,
    ) -> PyResult<Option<PyObject>> {
        for c in &self.inner.config().configurations {
            if c.id == configuration_id {
                let d = PyDict::new(py);
                d.set_item("id", &c.id)?;
                d.set_item("type", c.config_type.as_str())?;
                if let Some(ref m) = c.model {
                    d.set_item("model", m)?;
                }
                if let Some(ref p) = c.provider {
                    d.set_item("provider", p)?;
                }
                if let Some(ref pc) = c.provider_config {
                    d.set_item("provider_config", json_value_to_py(py, pc)?)?;
                }
                if let Some(ref e) = c.endpoint {
                    d.set_item("endpoint", e)?;
                }
                if let Some(t) = c.timeout {
                    d.set_item("timeout", t)?;
                }
                if let Some(mt) = c.max_tokens {
                    d.set_item("max_tokens", mt)?;
                }
                if let Some(ref env) = c.api_key_env {
                    d.set_item("api_key_env", env)?;
                }
                if let Some(ref meta) = c.metadata {
                    d.set_item("metadata", json_value_to_py(py, meta)?)?;
                }
                if let Some(def) = c.default {
                    d.set_item("default", def)?;
                }
                return Ok(Some(d.into_pyobject(py)?.into_any().unbind()));
            }
        }
        Ok(None)
    }
}

// ─── PyGuardrailsSession ───────────────────────────────────────────

#[pyclass(name = "GuardrailsSession")]
pub struct PyGuardrailsSession {
    inner: Arc<GuardrailsSession>,
}

impl PyGuardrailsSession {
    /// Construct from an existing `Arc<GuardrailsSession>`. Used by
    /// the hooks pyo3 surface so a `HookSession` can hand back a
    /// Python `GuardrailsSession` that points at the same underlying
    /// core session.
    pub(crate) fn from_arc(inner: Arc<GuardrailsSession>) -> Self {
        Self { inner }
    }
}

#[pymethods]
impl PyGuardrailsSession {
    // ── Variable ops ────────────────────────────────────────────────

    fn set_variable(&self, name: &str, value: &Bound<'_, PyAny>) -> PyResult<()> {
        let json = py_to_json_value(value)?;
        let g = &*self.inner;
        g.set_variable(name, json).map_err(map_runtime_error)
    }

    fn reset_variable(&self, name: &str) -> PyResult<()> {
        let g = &*self.inner;
        g.reset_variable(name).map_err(map_runtime_error)
    }

    fn resolve_variable(&self, py: Python<'_>, name: &str) -> PyResult<Option<PyObject>> {
        let g = &*self.inner;
        let r = g.resolve_variable(name).map_err(map_runtime_error)?;
        match r {
            Some(v) => Ok(Some(json_value_to_py(py, &v)?)),
            None => Ok(None),
        }
    }

    fn read_variable(&self, py: Python<'_>, name: &str) -> PyResult<Option<PyObject>> {
        let g = &*self.inner;
        let st = match g.read_variable(name) {
            Some(s) => s,
            None => return Ok(None),
        };
        let dict = PyDict::new(py);
        dict.set_item("value", json_value_to_py(py, &st.value)?)?;
        let status = match st.status {
            agent_shield_core::VarStatus::Unset => "unset",
            agent_shield_core::VarStatus::Resolved => "resolved",
            agent_shield_core::VarStatus::Denied => "denied",
        };
        dict.set_item("status", status)?;
        dict.set_item("set_at", st.set_at.to_rfc3339())?;
        dict.set_item("expires_at", st.expires_at.map(|d| d.to_rfc3339()))?;
        dict.set_item("deny_reason", st.deny_reason.clone())?;
        dict.set_item("source_kind", st.source_kind.clone())?;
        dict.set_item("set_by", st.set_by.clone())?;
        Ok(Some(dict.into_pyobject(py)?.into_any().unbind()))
    }

    // ── Event ops ───────────────────────────────────────────────────

    #[pyo3(signature = (event_id, lifetime=None, payload=None))]
    fn emit_event(
        &self,
        event_id: &str,
        lifetime: Option<&Bound<'_, PyAny>>,
        payload: Option<&Bound<'_, PyAny>>,
    ) -> PyResult<()> {
        let lt = match lifetime {
            Some(v) if !v.is_none() => Some(parse_lifetime_internal(v)?),
            _ => None,
        };
        let pl = match payload {
            Some(v) if !v.is_none() => Some(py_to_json_value(v)?),
            _ => None,
        };
        let g = &*self.inner;
        g.emit_event(event_id, lt, pl).map_err(map_runtime_error)
    }

    fn clear_event(&self, event_id: &str) -> PyResult<()> {
        let g = &*self.inner;
        g.clear_event(event_id).map_err(map_runtime_error)
    }

    #[pyo3(signature = (name, payload=None))]
    fn emit_incident(&self, name: &str, payload: Option<&Bound<'_, PyAny>>) -> PyResult<()> {
        let pl = match payload {
            Some(v) if !v.is_none() => Some(py_to_json_value(v)?),
            _ => None,
        };
        let g = &*self.inner;
        g.emit_incident(name, pl).map_err(map_runtime_error)
    }

    // ── Boundary ops ────────────────────────────────────────────────

    fn begin_turn(&self) -> PyResult<u64> {
        let g = &*self.inner;
        g.begin_turn().map_err(map_runtime_error)
    }

    fn end_turn(&self) -> PyResult<()> {
        let g = &*self.inner;
        g.end_turn().map_err(map_runtime_error)
    }

    fn begin_request(&self) -> PyResult<u64> {
        let g = &*self.inner;
        g.begin_request().map_err(map_runtime_error)
    }

    fn end_request(&self) -> PyResult<()> {
        let g = &*self.inner;
        g.end_request().map_err(map_runtime_error)
    }

    fn current_turn_id(&self) -> u64 {
        self.inner.current_turn_id()
    }

    fn current_request_id(&self) -> u64 {
        self.inner.current_request_id()
    }

    // ── IFC ops (proof: docs/information-flow-control-proof.md) ─────

    /// Read the session's running IFC exposure as a sorted list of
    /// declared tag names. Empty list when IFC is disabled (no
    /// `ifc:` block) or when exposure is `⊥`.
    fn current_exposure(&self, py: Python<'_>) -> PyResult<PyObject> {
        let g = &*self.inner;
        let exposure = g.current_exposure();
        let names = g.runtime().config().ifc.universe.names_of(exposure);
        let list = pyo3::types::PyList::empty(py);
        for n in names {
            list.append(n)?;
        }
        Ok(list.into_pyobject(py)?.into_any().unbind())
    }

    /// Lower the running exposure to the supplied target tag set.
    /// Tags must be names declared in `ifc.tags`. Caller is
    /// responsible for the proof TC-5 pre-condition `target ⊆ E`;
    /// this method skips the structural check and is a TCB primitive
    /// for SDK-side declassifiers. Raises `ValueError` on unknown
    /// tag names.
    fn declassify_to(&self, target: Vec<String>) -> PyResult<()> {
        let g = &*self.inner;
        let universe = &g.runtime().config().ifc.universe;
        let set = universe
            .resolve(
                &target,
                agent_shield_core::errors::SourceLoc::default(),
                "<py>",
            )
            .map_err(|e| PyValueError::new_err(format!("declassify_to: {e}")))?;
        g.declassify_to(set);
        Ok(())
    }

    // ── Stage ops ───────────────────────────────────────────────────

    fn validate_input(&self, py: Python<'_>, input: &str) -> PyResult<PyObject> {
        let g = &*self.inner;
        let v = g.validate_input(input);
        stage_verdict_to_py(py, &v)
    }

    #[pyo3(signature = (tool, params, tool_call_id))]
    fn validate_tool_call(
        &self,
        py: Python<'_>,
        tool: &str,
        params: &Bound<'_, PyAny>,
        tool_call_id: &str,
    ) -> PyResult<(PyObject, PyObject)> {
        let mut json = py_to_json_value(params)?;
        let g = &*self.inner;
        let v = g.validate_tool_call(tool, &mut json, tool_call_id);
        let verdict = stage_verdict_to_py(py, &v)?;
        let new_params = json_value_to_py(py, &json)?;
        Ok((verdict, new_params))
    }

    #[pyo3(signature = (tool, result, tool_call_id))]
    fn validate_tool_output(
        &self,
        py: Python<'_>,
        tool: &str,
        result: &Bound<'_, PyAny>,
        tool_call_id: &str,
    ) -> PyResult<(PyObject, PyObject)> {
        let mut json = py_to_json_value(result)?;
        let g = &*self.inner;
        let v = g.validate_tool_output(tool, &mut json, tool_call_id);
        let verdict = stage_verdict_to_py(py, &v)?;
        let new_result = json_value_to_py(py, &json)?;
        Ok((verdict, new_result))
    }

    #[pyo3(signature = (method, uri, body, tool_call_id))]
    fn validate_endpoint_call(
        &self,
        py: Python<'_>,
        method: &str,
        uri: &str,
        body: &Bound<'_, PyAny>,
        tool_call_id: &str,
    ) -> PyResult<(PyObject, PyObject)> {
        let mut json = py_to_json_value(body)?;
        let g = &*self.inner;
        let v = g.validate_endpoint_call(method, uri, &mut json, tool_call_id);
        let verdict = stage_verdict_to_py(py, &v)?;
        let new_body = json_value_to_py(py, &json)?;
        Ok((verdict, new_body))
    }

    #[pyo3(signature = (agent, params, tool_call_id))]
    fn validate_agent_call(
        &self,
        py: Python<'_>,
        agent: &str,
        params: &Bound<'_, PyAny>,
        tool_call_id: &str,
    ) -> PyResult<(PyObject, PyObject)> {
        let mut json = py_to_json_value(params)?;
        let g = &*self.inner;
        let v = g.validate_agent_call(agent, &mut json, tool_call_id);
        let verdict = stage_verdict_to_py(py, &v)?;
        let new_params = json_value_to_py(py, &json)?;
        Ok((verdict, new_params))
    }

    fn validate_output(&self, py: Python<'_>, response: &str) -> PyResult<(PyObject, String)> {
        let mut s = response.to_string();
        let g = &*self.inner;
        let v = g.validate_output(&mut s);
        let verdict = stage_verdict_to_py(py, &v)?;
        Ok((verdict, s))
    }

    // ── Resource cycle helpers ─────────────────────────────────────

    fn record_tool_success(&self, tool: &str, result: &Bound<'_, PyAny>) -> PyResult<()> {
        let json = py_to_json_value(result)?;
        let g = &*self.inner;
        g.record_tool_success(tool, &json)
            .map_err(map_runtime_error)
    }

    fn record_tool_failure(&self, tool: &str, error: &str) -> PyResult<()> {
        let g = &*self.inner;
        g.record_tool_failure(tool, error)
            .map_err(map_runtime_error)
    }

    fn record_endpoint_success(
        &self,
        method: &str,
        pattern: &str,
        result: &Bound<'_, PyAny>,
    ) -> PyResult<()> {
        let json = py_to_json_value(result)?;
        let g = &*self.inner;
        g.record_endpoint_success(method, pattern, &json)
            .map_err(map_runtime_error)
    }

    fn record_endpoint_failure(&self, method: &str, pattern: &str, error: &str) -> PyResult<()> {
        let g = &*self.inner;
        g.record_endpoint_failure(method, pattern, error)
            .map_err(map_runtime_error)
    }

    fn record_agent_success(&self, agent: &str, result: &Bound<'_, PyAny>) -> PyResult<()> {
        let json = py_to_json_value(result)?;
        let g = &*self.inner;
        g.record_agent_success(agent, &json)
            .map_err(map_runtime_error)
    }

    fn record_agent_failure(&self, agent: &str, error: &str) -> PyResult<()> {
        let g = &*self.inner;
        g.record_agent_failure(agent, error)
            .map_err(map_runtime_error)
    }

    // ── Streaming ───────────────────────────────────────────────────

    /// Construct a streaming guard. `stage` accepts ordinal (4 or 5) or
    /// the string names "post_tool" / "output".
    fn streaming_session(&self, stage: &Bound<'_, PyAny>) -> PyResult<PyStreamingGuard> {
        let st = if let Ok(n) = stage.extract::<u8>() {
            match n {
                1 => ObsStage::Input,
                2 => ObsStage::State,
                3 => ObsStage::ToolExecution,
                4 => ObsStage::PostTool,
                5 => ObsStage::Output,
                _ => return Err(PyValueError::new_err("stage must be 1..=5 or name")),
            }
        } else if let Ok(s) = stage.extract::<String>() {
            ObsStage::parse(&s)
                .ok_or_else(|| PyValueError::new_err(format!("unknown stage `{s}`")))?
        } else {
            return Err(PyValueError::new_err("stage must be int or str"));
        };
        let g = &*self.inner;
        let guard = g.streaming_session(st);
        Ok(PyStreamingGuard {
            inner: parking_lot::Mutex::new(Some(guard)),
        })
    }
}

// ─── PyStreamingGuard ──────────────────────────────────────────────

#[pyclass(name = "StreamingGuard")]
pub struct PyStreamingGuard {
    inner: parking_lot::Mutex<Option<StreamingGuard>>,
}

#[pymethods]
impl PyStreamingGuard {
    fn push(&self, py: Python<'_>, chunk: &str) -> PyResult<PyObject> {
        let mut guard = self.inner.lock();
        let g = guard
            .as_mut()
            .ok_or_else(|| PyRuntimeError::new_err("StreamingGuard already finished"))?;
        let r = g.add_chunk(chunk);
        stream_result_to_py(py, &r)
    }

    fn finish(&self, py: Python<'_>) -> PyResult<PyObject> {
        let mut guard = self.inner.lock();
        let g = guard
            .as_mut()
            .ok_or_else(|| PyRuntimeError::new_err("StreamingGuard already finished"))?;
        let r = g.end_stream();
        stream_result_to_py(py, &r)
    }

    #[getter]
    fn buffer(&self) -> String {
        self.inner
            .lock()
            .as_ref()
            .map(|g| g.buffer().to_string())
            .unwrap_or_default()
    }

    #[getter]
    fn chunks_received(&self) -> usize {
        self.inner
            .lock()
            .as_ref()
            .map(|g| g.chunks_received())
            .unwrap_or(0)
    }

    #[getter]
    fn is_ended(&self) -> bool {
        self.inner
            .lock()
            .as_ref()
            .map(|g| g.is_ended())
            .unwrap_or(true)
    }

    /// Validation cadence as a string: ``"on_complete"`` /
    /// ``"windowed"`` / ``"per_chunk"``. Pure read accessor — never
    /// allocates a guard-side mutation. The Python adapter layer uses
    /// this to decide whether to forward upstream chunks to the
    /// customer in real time (``per_chunk`` / ``windowed``) or to
    /// buffer every chunk and emit only the final validated payload at
    /// :meth:`finish` (``on_complete``).
    #[getter]
    fn mode(&self) -> String {
        let raw = self
            .inner
            .lock()
            .as_ref()
            .map(|g| g.mode())
            .unwrap_or(StreamingTrigger::OnComplete);
        match raw {
            StreamingTrigger::OnComplete => "on_complete".into(),
            StreamingTrigger::Windowed => "windowed".into(),
            StreamingTrigger::PerChunk => "per_chunk".into(),
        }
    }
}

// ─── PyGuardrailsConfig / PyCompiledPolicy ──────────────────────────
//
// Thin PyO3 wrappers around `GuardrailsConfig` and `CompiledPolicy`
// from `agent_shield_core::config`. The Python facade in
// `agent_shield/config.py` collapses to a thin handle wrapper around
// these. `_NativeGuardrailsConfig` is immutable-by-convention: every
// fluent method clones the inner builder and returns a new instance.

#[pyclass(name = "_NativeGuardrailsConfig")]
pub struct PyGuardrailsConfig {
    inner: GuardrailsConfig,
}

fn map_config_error(e: agent_shield_core::ConfigError) -> PyErr {
    PyValueError::new_err(e.to_string())
}

#[pymethods]
impl PyGuardrailsConfig {
    #[staticmethod]
    fn load(path: &str) -> PyResult<Self> {
        Ok(Self {
            inner: GuardrailsConfig::load(path),
        })
    }

    #[staticmethod]
    fn from_string(yaml: &str) -> PyResult<Self> {
        Ok(Self {
            inner: GuardrailsConfig::from_string(yaml),
        })
    }

    #[staticmethod]
    fn from_value(py: Python<'_>, value: PyObject) -> PyResult<Self> {
        let v = py_to_json_value(value.bind(py))?;
        Ok(Self {
            inner: GuardrailsConfig::from_value(v),
        })
    }

    fn extend(&self, other: &PyGuardrailsConfig) -> PyResult<Self> {
        Ok(Self {
            inner: self.inner.clone().extend(other.inner.clone()),
        })
    }

    fn extend_path(&self, path: &str) -> PyResult<Self> {
        Ok(Self {
            inner: self.inner.clone().extend_path(path),
        })
    }

    fn extend_string(&self, yaml: &str) -> PyResult<Self> {
        Ok(Self {
            inner: self.inner.clone().extend_string(yaml),
        })
    }

    fn with_overrides(&self, py: Python<'_>, overrides: PyObject) -> PyResult<Self> {
        let v = py_to_json_value(overrides.bind(py))?;
        Ok(Self {
            inner: self.inner.clone().with_overrides(v),
        })
    }

    /// Append a policy-pack layer. `pack` may be a string (path to a
    /// YAML file) or a dict (typed value layer). Mirrors
    /// `GuardrailsConfig::with_policy_pack(Layer::*)`.
    fn with_policy_pack(&self, py: Python<'_>, pack: PyObject) -> PyResult<Self> {
        let bound = pack.bind(py);
        let layer = if let Ok(s) = bound.extract::<String>() {
            agent_shield_core::Layer::Path(std::path::PathBuf::from(s))
        } else {
            agent_shield_core::Layer::Object(py_to_json_value(bound)?)
        };
        Ok(Self {
            inner: self.inner.clone().with_policy_pack(layer),
        })
    }

    fn compile(&self) -> PyResult<PyCompiledPolicy> {
        let compiled = self.inner.compile().map_err(map_config_error)?;
        Ok(PyCompiledPolicy {
            inner: Arc::new(compiled),
        })
    }

    /// Compute the canonical digest without running validation. Used
    /// by the Python facade to support the `CompiledPolicy.digest`
    /// introspection path on chains that haven't been built into a
    /// runtime yet (partial overlays, layered tenant policies).
    fn digest(&self) -> PyResult<String> {
        self.inner.digest().map_err(map_config_error)
    }

    fn __len__(&self) -> usize {
        self.inner.len()
    }

    fn is_empty(&self) -> bool {
        self.inner.is_empty()
    }
}

#[pyclass(name = "_NativeCompiledPolicy")]
pub struct PyCompiledPolicy {
    inner: Arc<CompiledPolicy>,
}

#[pymethods]
impl PyCompiledPolicy {
    #[getter]
    fn digest(&self) -> &str {
        self.inner.digest()
    }

    fn __hash__(&self) -> u64 {
        use std::collections::hash_map::DefaultHasher;
        use std::hash::{Hash, Hasher};
        let mut h = DefaultHasher::new();
        self.inner.digest().hash(&mut h);
        h.finish()
    }

    fn __eq__(&self, other: &PyCompiledPolicy) -> bool {
        self.inner.digest() == other.inner.digest()
    }

    fn __repr__(&self) -> String {
        format!("_NativeCompiledPolicy(digest={})", self.inner.digest())
    }
}

// ─── Submodule registration ──────────────────────────────────────────

#[pymodule]
fn _native(parent: &Bound<'_, PyModule>) -> PyResult<()> {
    // Register classes directly on the module
    parent.add_class::<PyRuntimeBuilder>()?;
    parent.add_class::<PyGuardrailsRuntime>()?;
    parent.add_class::<PyGuardrailsSession>()?;
    parent.add_class::<PyStreamingGuard>()?;
    parent.add_class::<PyGuardrailsConfig>()?;
    parent.add_class::<PyCompiledPolicy>()?;
    parent.add_class::<hooks::PyHookSessionRegistry>()?;
    parent.add_class::<hooks::PyHookSession>()?;
    parent.add_class::<hooks::PyStageDispatcher>()?;

    parent.add_function(wrap_pyfunction!(py_parse_lifetime, parent)?)?;
    parent.add_function(wrap_pyfunction!(py_dispatch_stage_verdict, parent)?)?;
    parent.add_function(wrap_pyfunction!(py_dispatch_tool_verdict, parent)?)?;
    parent.add_function(wrap_pyfunction!(py_format_block_message, parent)?)?;

    Ok(())
}
