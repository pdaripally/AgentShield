"""LLM-caller model resolution tests for the Anthropic Agents adapter.

Asserts that ``.guardrails.yaml`` ``configurations[]`` entries actually
drive which model the Stage 1/3/5 LLM judge uses — i.e. that a
``configurations: [{id: stage3-judge, type: llm, model:
claude-3-5-sonnet-latest}]`` entry is *not* silently overridden by a
hard-coded fallback. Mirrors
``test_oai_agents_llm_caller_model.py``.
"""
from __future__ import annotations

from typing import Any, List, Optional
from unittest.mock import MagicMock

import pytest

from agent_shield import RuntimeBuilder
from agent_shield.adapters._capabilities import (
    ConfigurationMissingModelError,
)
from agent_shield.adapters.anthropic_agents import (
    _LlmCallerFactory,
    make_llm_caller,
)


# A minimal valid guardrails YAML with two distinct LLM configurations.
# The runtime doesn't have to actually route through these for the test
# — we only need the merged config to expose them via
# ``runtime.llm_configuration``.
_MULTI_CONFIG_YAML = """
metadata:
  name: anthropic-llm-caller-model-fixture
  version: 0.1.0
  agent_shield_version: "2.0"
objective:
  goal: ["exercise configurations[] routing"]
  forbidden: ["bypass"]
configurations:
  - id: stage1-judge
    type: llm
    provider: anthropic.messages
    model: claude-3-5-sonnet-latest
    max_tokens: 256
  - id: stage3-judge
    type: llm
    provider: anthropic.messages
    model: claude-3-haiku-20240307
input_validation:
  guard_policies:
    - name: trivial_input_guard
      evaluate_when:
        - patterns: ["jailbreak"]
          reason: "jailbreak attempt"
      action: "block"
"""


class _RecordingMessages:
    """Stand-in for ``client.messages`` that records every ``create`` call."""

    def __init__(self) -> None:
        self.calls: List[dict] = []

    def create(self, **kwargs: Any) -> Any:
        self.calls.append(kwargs)
        block = MagicMock()
        block.text = "ok"
        result = MagicMock()
        result.content = [block]
        return result


class _FakeAnthropicClient:
    """Minimal sync Anthropic-shaped client (no ``Async`` in the class name)."""

    def __init__(self) -> None:
        self.messages = _RecordingMessages()


def _build_runtime(yaml_str: str):
    import tempfile
    import os

    fd, path = tempfile.mkstemp(suffix=".yaml")
    try:
        with os.fdopen(fd, "w") as fh:
            fh.write(yaml_str)
        return RuntimeBuilder.from_yaml(path).build()
    finally:
        os.unlink(path)


# ───────────────────────────────────────────────────────────────────────
# Runtime.llm_configuration accessor


def test_llm_configuration_returns_yaml_model_for_known_id():
    rt = _build_runtime(_MULTI_CONFIG_YAML)
    cfg = rt.llm_configuration("stage1-judge")
    assert cfg is not None
    assert cfg["id"] == "stage1-judge"
    assert cfg["type"] == "llm"
    assert cfg["model"] == "claude-3-5-sonnet-latest"
    assert cfg.get("max_tokens") == 256


def test_llm_configuration_returns_none_for_unknown_id():
    rt = _build_runtime(_MULTI_CONFIG_YAML)
    assert rt.llm_configuration("does-not-exist") is None


# ───────────────────────────────────────────────────────────────────────
# LLM-caller model selection


def test_caller_uses_yaml_model_for_each_configuration_id():
    rt = _build_runtime(_MULTI_CONFIG_YAML)
    client = _FakeAnthropicClient()

    caller = make_llm_caller(client, configuration_resolver=rt.llm_configuration)

    caller("stage1-judge", "is the input safe?")
    caller("stage3-judge", "is the tool call safe?")

    messages = client.messages
    assert len(messages.calls) == 2
    assert messages.calls[0]["model"] == "claude-3-5-sonnet-latest"
    assert messages.calls[0]["max_tokens"] == 256
    assert messages.calls[1]["model"] == "claude-3-haiku-20240307"
    # No max_tokens declared for stage3-judge => fall back to the
    # adapter default. The token budget is not security-sensitive
    # (unlike model selection), so defaulting it is acceptable —
    # Anthropic's messages.create requires max_tokens.
    assert messages.calls[1]["max_tokens"] == (
        _LlmCallerFactory.DEFAULT_FALLBACK_MAX_TOKENS
    )


def test_caller_raises_when_no_matching_configuration():
    """Missing configuration: a security library MUST raise rather
    than silently picking a model on the customer's behalf."""
    rt = _build_runtime(_MULTI_CONFIG_YAML)
    client = _FakeAnthropicClient()

    caller = make_llm_caller(client, configuration_resolver=rt.llm_configuration)

    with pytest.raises(ConfigurationMissingModelError) as exc_info:
        caller("not-in-yaml", "judge me")

    assert "not-in-yaml" in str(exc_info.value)
    assert len(client.messages.calls) == 0


def test_caller_raises_when_no_resolver_wired():
    client = _FakeAnthropicClient()

    caller = make_llm_caller(client)

    with pytest.raises(ConfigurationMissingModelError):
        caller("stage1-judge", "prompt")

    assert len(client.messages.calls) == 0


def test_caller_raises_when_configuration_id_is_none():
    rt = _build_runtime(_MULTI_CONFIG_YAML)
    client = _FakeAnthropicClient()

    caller = make_llm_caller(client, configuration_resolver=rt.llm_configuration)

    with pytest.raises(ConfigurationMissingModelError) as exc_info:
        caller(None, "prompt")

    assert "<unset>" in str(exc_info.value)


def test_caller_raises_when_resolver_raises():
    """Resolver exceptions surface as ConfigurationMissingModelError;
    a broken resolver is treated the same as "no entry"."""
    client = _FakeAnthropicClient()

    def broken_resolver(_cid: Optional[str]) -> Optional[dict]:
        raise RuntimeError("boom")

    caller = make_llm_caller(client, configuration_resolver=broken_resolver)

    with pytest.raises(ConfigurationMissingModelError):
        caller("stage1-judge", "prompt")

    assert len(client.messages.calls) == 0


# ───────────────────────────────────────────────────────────────────────
# ShieldBuilder integration — the resolver is wired through build()


def test_shield_builder_wires_resolver_through_build(tmp_path):
    """Shield.from_yaml(...).with_client(...).build() => caller honours YAML.

    Reaches into ``ShieldBuilder`` to grab the actually-wired LLM caller
    (the same closure ``RuntimeBuilder.register_llm_caller`` receives,
    which is what the Rust runtime invokes for every stage). Drives the
    closure directly and asserts the model came from the YAML.
    """
    import agent_shield.adapters.anthropic_agents  # noqa: F401 — register bundle
    from agent_shield.adapters._shield import ShieldBuilder

    yaml_path = tmp_path / "guardrails.yaml"
    yaml_path.write_text(_MULTI_CONFIG_YAML)

    client = _FakeAnthropicClient()
    builder = (
        ShieldBuilder(str(yaml_path), auto_bind=False)
        .with_anthropic_agents()
        .with_client(client)
    )
    shield = builder.build()

    # The bound caller MUST already see the runtime's configurations by
    # the time the first stage runs — that's the whole point of the
    # resolver holder being filled in by build().
    bound_caller = builder._llm_caller  # noqa: SLF001 — test introspection
    assert bound_caller is not None

    bound_caller("stage1-judge", "prompt")
    bound_caller("stage3-judge", "prompt")

    messages = client.messages
    assert messages.calls[-2]["model"] == "claude-3-5-sonnet-latest"
    assert messages.calls[-2]["max_tokens"] == 256
    assert messages.calls[-1]["model"] == "claude-3-haiku-20240307"

    # Sanity-check the runtime accessor itself is reachable post-build.
    assert (
        shield.runtime.llm_configuration("stage1-judge")["model"]
        == "claude-3-5-sonnet-latest"
    )
