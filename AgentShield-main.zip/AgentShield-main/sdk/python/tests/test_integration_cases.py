"""
Cross-language integration test runner for Agent Shield (Python).

Loads shared YAML test cases from ``tests/cases/`` and shared fixtures from
``tests/fixtures/``, then runs each test case against the Python bindings
exposed via :mod:`agent_shield`.

Usage::

    pytest sdk/python/tests/test_integration_cases.py -v
    # or, from sdk/python/:
    pytest tests/test_integration_cases.py -v

Requires::

    - agent_shield._native  (Rust-backed native module via PyO3)
    - agent_shield          (Pythonic wrapper over the native module)

The harness recognizes the action / assertion vocabulary documented in
``tests/cases/test-cases.schema.json``.
"""
from __future__ import annotations

import inspect
import json
import os
import sys
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

import pytest
import yaml


# ── Locate shared fixtures ───────────────────────────────────────────────

REPO_ROOT = Path(__file__).resolve().parent.parent.parent.parent
CASES_DIR = REPO_ROOT / "tests" / "cases"
FIXTURES_DIR = REPO_ROOT / "tests" / "fixtures"


def _find_fixture(name: str) -> Path:
    """Search ``tests/fixtures/`` for a file by name or relative path."""
    direct = FIXTURES_DIR / name
    if direct.is_file():
        return direct
    leaf = Path(name).name
    for child in FIXTURES_DIR.iterdir():
        if child.is_dir():
            candidate = child / leaf
            if candidate.is_file():
                return candidate
    raise FileNotFoundError(f"Fixture not found: {name}")


def _resolve_fixture_paths(given: Dict[str, Any]) -> List[str]:
    return [str(_find_fixture(f)) for f in given.get("fixtures", [])]


# ── Reusable test stubs ──────────────────────────────────────────────────


class _CallCounter:
    """Track which resolver hooks were invoked and per-variable counts."""

    def __init__(self) -> None:
        self.calls: List[Tuple[str, str, Dict[str, Any]]] = []

    def record(self, kind: str, variable: Optional[str], request_dict: Dict[str, Any]) -> None:
        self.calls.append((kind, variable or "", dict(request_dict)))

    def was_called(self, variable: str, kind: Optional[str] = None) -> bool:
        for k, v, _ in self.calls:
            if v == variable and (kind is None or k == kind):
                return True
        return False


class _CannedResolver:
    """Stub resolver that consults a pre-canned `given.resolvers` map.

    Looks up the response by ``request.variable``. If the runtime didn't
    populate the variable name in the request envelope (some resolver
    request envelopes omit it for non-human kinds), falls back to matching
    by ``prompt`` text or — when there's only one canned entry — uses that
    entry as the response. Final fallback is a fail-closed deny.
    """

    def __init__(self, kind: str, canned: Dict[str, Dict[str, Any]], counter: _CallCounter) -> None:
        self._kind = kind
        self._canned = canned
        self._counter = counter

    def __call__(self, request: Any) -> Any:
        var = getattr(request, "variable", None)
        if var is None and isinstance(request, dict):
            var = request.get("variable")
        prompt = getattr(request, "prompt", None)
        if prompt is None and isinstance(request, dict):
            prompt = request.get("prompt")
        self._counter.record(self._kind, var, _request_to_dict(request))

        canned = None
        if var is not None:
            canned = self._canned.get(var)
        if canned is None and prompt:
            for k, v in self._canned.items():
                if isinstance(v, dict) and v.get("prompt") == prompt:
                    canned = v
                    break
        if canned is None and len(self._canned) == 1:
            canned = next(iter(self._canned.values()))

        if canned is None:
            return {
                "decision": "deny",
                "reason": f"{self._kind} resolver: no canned response (variable={var!r})",
            }
        out: Dict[str, Any] = {"decision": canned.get("decision", "deny")}
        if "value" in canned:
            out["value"] = canned["value"]
        if canned.get("set_variables"):
            out["set_variables"] = dict(canned["set_variables"])
        if "reason" in canned:
            out["reason"] = canned["reason"]
        return out


def _request_to_dict(request: Any) -> Dict[str, Any]:
    if isinstance(request, dict):
        return request
    out: Dict[str, Any] = {}
    for attr in ("request_id", "variable", "resource_kind", "resource_name", "prompt", "reason", "context"):
        if hasattr(request, attr):
            out[attr] = getattr(request, attr)
    return out


# ── Test case loading ────────────────────────────────────────────────────


def _load_all_cases() -> List[Tuple[str, Dict[str, Any]]]:
    cases: List[Tuple[str, Dict[str, Any]]] = []
    for yaml_file in sorted(CASES_DIR.glob("*.cases.yaml")):
        with open(yaml_file) as f:
            data = yaml.safe_load(f)
        suite_name = data.get("suite", yaml_file.stem)
        for case in data.get("cases", []):
            case_id = f"{suite_name}::{case.get('name', 'unnamed')}"
            case["_suite_fixture"] = data.get("fixture")
            case["_suite_fixtures"] = data.get("fixtures")
            cases.append((case_id, case))
    return cases


ALL_CASES = _load_all_cases()


def _get_given(case: Dict[str, Any]) -> Dict[str, Any]:
    given = dict(case.get("given", {}) or {})
    if "fixtures" not in given:
        if case.get("_suite_fixtures"):
            given["fixtures"] = case["_suite_fixtures"]
        elif case.get("_suite_fixture"):
            scenario_dir = FIXTURES_DIR / case["_suite_fixture"]
            if scenario_dir.is_dir():
                given["fixtures"] = [
                    f.name for f in sorted(scenario_dir.glob("*.guardrails.yaml"))
                ]
    return given


# ── Runtime factory ──────────────────────────────────────────────────────


def _build_runtime(paths: List[str], given: Dict[str, Any]):
    """Build a Runtime + capturing observability + canned resolvers."""
    # If `agent_shield` cannot be imported, the harness must fail, not skip.
    # Silent-skipping on import failure was masking v2 / v1 mismatches and
    # producing false-green CI runs (Node's harness fails hard via top-level
    # `await import` for the same reason — Python should match).
    from agent_shield import RuntimeBuilder, CapturingProvider  # type: ignore

    canned = (given.get("resolvers") or {})
    counter = _CallCounter()
    capture = CapturingProvider()

    if len(paths) == 1:
        builder = RuntimeBuilder.from_yaml(paths[0])
    else:
        builder = RuntimeBuilder.from_yaml_chain(paths)

    builder = builder.register_observability_provider(capture)
    # Register canned resolvers for the kinds that still accept a host
    # callback. `kind: human` is no longer a callback-bound resolver —
    # it dispatches through the canonical `agent_shield.ask_human` MCP
    # tool path.
    builder = builder.register_agent_resolver(_CannedResolver("agent", canned, counter))
    builder = builder.register_delegate_dispatcher(_CannedResolver("delegate", canned, counter))

    # Register default-allow LLM and classifier callers so guard policies that
    # use `llm:` or `classifier:` detection (and that the test does not
    # explicitly exercise) don't fail-closed for lack of a registered caller.
    # Tests that want to assert LLM-based blocking should override these
    # by re-registering on the runtime before the action runs (not yet
    # wired through the case schema).
    def _allow_llm(_cfg_id, _prompt):
        return {"decision": "allow"}

    def _allow_classifier(_cfg_id, _subject):
        return {"score": 0.0, "threshold": 0.5, "flagged": False}

    try:
        builder = builder.register_llm_caller(_allow_llm)
    except Exception:  # pragma: no cover — older builder may not have this hook
        pass
    try:
        builder = builder.register_classifier_caller(_allow_classifier)
    except Exception:  # pragma: no cover
        pass

    runtime = builder.build()
    return runtime, capture, counter


def _open_session(runtime):
    session = runtime.new_session(session_id="harness-session", correlation_id="harness-correlation")
    # Open boundaries so per_turn / per_request lifetimes engage.
    try:
        session.begin_request()
    except Exception:
        pass
    try:
        session.begin_turn()
    except Exception:
        pass
    return session


# ── Action dispatch ──────────────────────────────────────────────────────


def _params(action: Dict[str, Any]) -> Dict[str, Any]:
    return dict(action.get("params") or {})


def _execute_action(session: Any, action: Dict[str, Any]) -> Any:
    """Run one action against the session and return its result."""
    verb = action.get("action") or action.get("type")
    p = _params(action)

    if verb == "validate_input":
        text = p.get("input") or action.get("input") or ""
        return session.validate_input(text)
    if verb == "validate_tool_call":
        tool = p.get("tool_name") or action.get("tool_name") or ""
        params = p.get("tool_params") or action.get("tool_params") or {}
        tool_call_id = (
            p.get("tool_call_id")
            or action.get("tool_call_id")
            or "case_invocation"
        )
        return session.validate_tool_call(tool, params, tool_call_id=tool_call_id)
    if verb == "validate_tool_output":
        tool = p.get("tool_name") or action.get("tool_name") or "unknown_tool"
        result = p.get("output") if "output" in p else p.get("result")
        if result is None:
            result = action.get("output") if "output" in action else action.get("result")
        tool_call_id = (
            p.get("tool_call_id")
            or action.get("tool_call_id")
            or "case_invocation"
        )
        # §16.0 auto-prebind-on-fallback: Stage 4 binds against the
        # canonical invocation Stage 3 admitted. For standalone
        # validate_tool_output cases (no paired Stage 3 in the same
        # case), attempt Stage 4 first; if it fails-closed on
        # "<binding>", emit a Stage 3 admit and retry.
        outcome = session.validate_tool_output(tool, result, tool_call_id=tool_call_id)
        verdict = outcome.verdict if hasattr(outcome, "verdict") else outcome
        policy = getattr(verdict, "policy", None)
        allowed = getattr(verdict, "allowed", True)
        if (not allowed) and policy == "<binding>":
            prebind_params = p.get("tool_params") or action.get("tool_params") or {}
            session.validate_tool_call(tool, prebind_params, tool_call_id=tool_call_id)
            outcome = session.validate_tool_output(tool, result, tool_call_id=tool_call_id)
        return outcome
    if verb == "validate_endpoint_call":
        method = p.get("method") or action.get("method") or "GET"
        uri = p.get("path") or p.get("uri") or p.get("url") or action.get("path") or action.get("url") or ""
        body = p.get("body") if "body" in p else p.get("query_params")
        tool_call_id = (
            p.get("tool_call_id")
            or action.get("tool_call_id")
            or "case_invocation"
        )
        return session.validate_endpoint_call(method, uri, body or {}, tool_call_id=tool_call_id)
    if verb == "validate_agent_call":
        agent = p.get("agent_name") or action.get("agent_name") or ""
        params = p.get("agent_params") or action.get("agent_params") or {}
        tool_call_id = (
            p.get("tool_call_id")
            or action.get("tool_call_id")
            or "case_invocation"
        )
        return session.validate_agent_call(agent, params, tool_call_id=tool_call_id)
    if verb == "validate_output":
        text = p.get("output") or action.get("output") or ""
        return session.validate_output(text)
    if verb == "set_variable":
        name = p.get("name") or action.get("name")
        value = p.get("value") if "value" in p else action.get("value")
        session.set_variable(name, value)
        return None
    if verb == "reset_variable":
        name = p.get("name") or action.get("name")
        session.reset_variable(name)
        return None
    if verb == "resolve_variable":
        name = p.get("name") or action.get("name")
        return session.resolve_variable(name)
    if verb == "emit_event":
        event_id = p.get("id") or action.get("id")
        session.emit_event(event_id, lifetime=p.get("lifetime"), payload=p.get("payload"))
        return None
    if verb == "clear_event":
        event_id = p.get("id") or action.get("id")
        session.clear_event(event_id)
        return None
    if verb == "emit_incident":
        name = p.get("name") or action.get("name")
        session.emit_incident(name, p.get("payload"))
        return None
    if verb == "begin_turn":
        return session.begin_turn()
    if verb == "end_turn":
        session.end_turn()
        return None
    if verb == "begin_request":
        return session.begin_request()
    if verb == "end_request":
        session.end_request()
        return None
    if verb == "record_tool_success":
        tool = p.get("tool_name") or action.get("tool_name")
        result = p.get("result") if "result" in p else action.get("result")
        session.record_tool_success(tool, result)
        return None
    if verb == "record_tool_failure":
        tool = p.get("tool_name") or action.get("tool_name")
        error = p.get("error") or action.get("error") or ""
        session.record_tool_failure(tool, error)
        return None
    if verb == "record_endpoint_success":
        pattern = p.get("pattern") or p.get("uri") or p.get("path") or action.get("pattern", "")
        result = p.get("result")
        session.record_endpoint_success(pattern, result)
        return None
    if verb == "record_endpoint_failure":
        pattern = p.get("pattern") or p.get("uri") or p.get("path") or action.get("pattern", "")
        error = p.get("error") or ""
        session.record_endpoint_failure(pattern, error)
        return None
    if verb == "record_agent_success":
        agent = p.get("agent_name") or action.get("agent_name")
        result = p.get("result")
        session.record_agent_success(agent, result)
        return None
    if verb == "record_agent_failure":
        agent = p.get("agent_name") or action.get("agent_name")
        error = p.get("error") or ""
        session.record_agent_failure(agent, error)
        return None
    pytest.fail(f"Unknown action verb: {verb}", pytrace=False)


# ── Assertion checking ───────────────────────────────────────────────────


def _verdict_view(result: Any) -> Tuple[Optional[Any], Optional[str]]:
    """Extract a (verdict, transformed_text) pair from any outcome."""
    if result is None:
        return None, None
    # StageVerdict (validate_input) — exposes .allowed, .action, .reason, .policy.
    if hasattr(result, "allowed") and not hasattr(result, "verdict"):
        return result, None
    # Compound outcomes (validate_tool_call / output / etc.) wrap a verdict.
    if hasattr(result, "verdict"):
        verdict = result.verdict
        text = None
        for attr in ("response", "result", "params", "body"):
            if hasattr(result, attr):
                v = getattr(result, attr)
                if isinstance(v, str):
                    text = v
                    break
        return verdict, text
    return None, None


def _check_assertions(
    result: Any,
    expected: Dict[str, Any],
    case_name: str,
    capture: Any,
    counter: _CallCounter,
) -> None:
    if not expected:
        return

    verdict, text = _verdict_view(result)

    if "allowed" in expected:
        assert verdict is not None, f"[{case_name}] expected verdict but got {result!r}"
        assert verdict.allowed == expected["allowed"], (
            f"[{case_name}] expected allowed={expected['allowed']}, got {verdict.allowed} "
            f"(action={verdict.action}, reason={verdict.reason})"
        )

    if "expect_verdict_action" in expected:
        assert verdict is not None
        assert verdict.action == expected["expect_verdict_action"], (
            f"[{case_name}] expected action={expected['expect_verdict_action']}, "
            f"got {verdict.action}"
        )

    if "expect_verdict_reason" in expected:
        assert verdict is not None
        actual = verdict.reason or ""
        assert expected["expect_verdict_reason"] in actual, (
            f"[{case_name}] expected reason to contain {expected['expect_verdict_reason']!r}, "
            f"got {actual!r}"
        )

    if "expect_verdict_policy" in expected:
        assert verdict is not None
        assert verdict.policy == expected["expect_verdict_policy"], (
            f"[{case_name}] expected policy={expected['expect_verdict_policy']}, "
            f"got {verdict.policy}"
        )

    if "text_contains" in expected:
        body = text if text is not None else (
            getattr(result, "output", None)
            or (getattr(result, "response", None) if hasattr(result, "response") else None)
            or ""
        )
        assert expected["text_contains"] in (body or ""), (
            f"[{case_name}] expected output to contain {expected['text_contains']!r}; got {body!r}"
        )

    if "text_not_contains" in expected:
        body = text if text is not None else (
            getattr(result, "output", None)
            or (getattr(result, "response", None) if hasattr(result, "response") else None)
            or ""
        )
        items = expected["text_not_contains"]
        if isinstance(items, str):
            items = [items]
        for item in items:
            assert item not in (body or ""), (
                f"[{case_name}] expected output to NOT contain {item!r}; got {body!r}"
            )

    if "expect_variable_status" in expected:
        cfg = expected["expect_variable_status"]
        name = cfg["name"]
        want_status = cfg["status"]
        # `cfg` may also be in legacy shape: name + status keys.
        # `_session` is captured by closure for the harness — but we read
        # via the verdict scope. The session is provided via test args; we
        # rely on the harness having stashed it on the result object.
        sess = getattr(_check_assertions, "_session", None)
        assert sess is not None, "harness did not provide session for variable assertions"
        state = sess.read_variable(name)
        actual_status = state.status if state is not None else "unset"
        assert actual_status == want_status, (
            f"[{case_name}] expected variable {name!r} status={want_status}, "
            f"got {actual_status}"
        )

    if "expect_variable_value" in expected:
        cfg = expected["expect_variable_value"]
        name = cfg["name"]
        sess = getattr(_check_assertions, "_session", None)
        assert sess is not None, "harness did not provide session for variable assertions"
        state = sess.read_variable(name)
        actual = state.value if state is not None else None
        if "value" in cfg:
            assert actual == cfg["value"], (
                f"[{case_name}] expected variable {name!r} value={cfg['value']!r}, "
                f"got {actual!r}"
            )

    if "expect_event_fired" in expected:
        eid = expected["expect_event_fired"]
        fired = any(_event_id_matches(ev, eid) for ev in capture.events)
        assert fired, f"[{case_name}] expected event {eid!r} to be fired"

    if "expect_event_not_fired" in expected:
        eid = expected["expect_event_not_fired"]
        fired = any(_event_id_matches(ev, eid) for ev in capture.events)
        assert not fired, f"[{case_name}] expected event {eid!r} NOT to be fired"

    if "expect_resolver_called" in expected:
        cfg = expected["expect_resolver_called"]
        var = cfg["variable"]
        kind = cfg.get("kind")
        assert counter.was_called(var, kind), (
            f"[{case_name}] expected resolver call for variable {var!r} "
            f"(kind={kind}); got calls={counter.calls!r}"
        )

    if "expect_log_event" in expected:
        match = expected["expect_log_event"]
        ok = False
        for ev in capture.events:
            if not _log_event_matches(ev, match):
                continue
            ok = True
            break
        assert ok, (
            f"[{case_name}] expected log event matching {match!r}; "
            f"saw {[_event_summary(e) for e in capture.events]}"
        )


def _event_id_matches(event: Any, expected_id: str) -> bool:
    eid = getattr(event, "event_id", None)
    if eid == expected_id:
        return True
    # Some events surface the id only via attributes.
    attrs = getattr(event, "attributes", {}) or {}
    return attrs.get("agent_shield.event.id") == expected_id


def _log_event_matches(event: Any, match: Dict[str, Any]) -> bool:
    for key, want in match.items():
        if key == "message_contains":
            actual = getattr(event, "message", "") or ""
            if want not in actual:
                return False
            continue
        if key == "attributes":
            actual_attrs = getattr(event, "attributes", {}) or {}
            for ak, av in (want or {}).items():
                if actual_attrs.get(ak) != av:
                    return False
            continue
        actual = getattr(event, key, None)
        if actual != want:
            return False
    return True


def _event_summary(event: Any) -> Dict[str, Any]:
    return {
        "event_type": getattr(event, "event_type", None),
        "stage": getattr(event, "stage", None),
        "guard_policy": getattr(event, "guard_policy", None),
        "category": getattr(event, "category", None),
        "event_id": getattr(event, "event_id", None),
    }


# ── Pre-state setup (initial variables / events) ─────────────────────────


def _seed_session(session: Any, given: Dict[str, Any]) -> None:
    for name, value in (given.get("variables") or {}).items():
        session.set_variable(name, value)
    for entry in (given.get("events") or []):
        if isinstance(entry, str):
            session.emit_event(entry)
        else:
            session.emit_event(
                entry["id"],
                lifetime=entry.get("lifetime"),
                payload=entry.get("payload"),
            )


# ── Parametrized test ────────────────────────────────────────────────────


@pytest.mark.parametrize("case_id,case", ALL_CASES, ids=[c[0] for c in ALL_CASES])
def test_shared_case(case_id: str, case: Dict[str, Any]) -> None:
    given = _get_given(case)
    paths = _resolve_fixture_paths(given)
    if not paths:
        pytest.skip(f"No fixtures defined for case: {case_id}")

    runtime, capture, counter = _build_runtime(paths, given)
    session = _open_session(runtime)
    # Stash the session for assertion helpers that need to read variable
    # state by name.
    _check_assertions._session = session  # type: ignore[attr-defined]

    try:
        _seed_session(session, given)

        if "when" in case and "then" in case:
            result = _execute_action(session, case["when"])
            _check_assertions(result, case["then"], case_id, capture, counter)
            return

        for i, step in enumerate(case.get("steps") or []):
            step_name = f"{case_id}[step {i}]"
            action_data = step.get("when") or step
            result = _execute_action(session, action_data)
            expected = step.get("then") or step.get("expected")
            if expected:
                _check_assertions(result, expected, step_name, capture, counter)
    finally:
        try:
            session.end_turn()
        except Exception:
            pass
        try:
            session.end_request()
        except Exception:
            pass
        _check_assertions._session = None  # type: ignore[attr-defined]
