"""Shared fixtures for Agent Shield SDK tests.

After the standalone Python core deletion, fixtures that constructed
in-memory config objects are removed.  Tests should use YAML files
(from tests/fixtures/) or mock the Rust-backed runtime directly.

Prerequisites:
    pip install maturin pytest pyyaml
    cd sdk/python
    maturin develop --release
"""

from __future__ import annotations

import pytest

# ---------------------------------------------------------------------------
# Helper: build YAML from resource dicts
# ---------------------------------------------------------------------------

def make_guardrails_yaml(
    tmp_path,
    *,
    resources=None,
    input_validators=None,
    output_validators=None,
    post_tool_validators=None,
    attributes=None,
    states=None,
    objective_goal="Test agent",
    objective_forbidden=None,
    name="test-agent",
):
    """Build a guardrails YAML file from keyword arguments.

    Convenience helper for tests that need a config without authoring
    the full YAML by hand.
    """
    import yaml

    config = {
        "metadata": {"name": name, "version": "1.0.0"},
        "objective": {
            "goal": objective_goal,
            "forbidden": objective_forbidden or [],
        },
    }

    if resources is not None:
        tools = []
        for r in resources:
            if isinstance(r, dict):
                tools.append(r)
            else:
                raise TypeError(f"resource must be a dict, got {type(r)}")
        config["resources"] = {"tools": tools}

    if input_validators is not None:
        config["input_validation"] = {"validators": input_validators}

    if output_validators is not None:
        config["output_validation"] = {"validators": output_validators}

    if post_tool_validators is not None:
        config["post_tool_validation"] = {"validators": post_tool_validators}

    if attributes is not None:
        config["attributes"] = attributes

    if states is not None:
        config["state_validation"] = {"states": states}

    path = tmp_path / f"{name}.guardrails.yaml"
    path.write_text(yaml.dump(config, default_flow_style=False), encoding="utf-8")
    return str(path)
