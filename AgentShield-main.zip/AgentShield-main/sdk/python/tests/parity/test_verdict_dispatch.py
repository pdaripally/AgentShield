"""Cross-SDK verdict-dispatch parity test.

Reads the canonical fixture in ``tests/parity/verdict_dispatch_canonical.json``
and runs every (verdict, policy, mode) input through the canonical core
dispatcher (via the PyO3 binding). Each expected output is the
byte-equivalent payload every SDK MUST produce for the same input.

The Node, .NET, and Rust SDKs run the equivalent test against the same
fixture so the four SDKs stay byte-aligned on the orchestrator's
deterministic decisions.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from agent_shield._native import (
    dispatch_stage_verdict,
    dispatch_tool_verdict,
)


def _fixture_path() -> Path:
    here = Path(__file__).resolve()
    # tests/parity/verdict_dispatch_canonical.json at repo root
    repo_root = here.parents[4]
    return repo_root / "tests" / "parity" / "verdict_dispatch_canonical.json"


@pytest.fixture(scope="module")
def canonical():
    path = _fixture_path()
    if not path.exists():
        pytest.skip(f"canonical fixture missing at {path}")
    with path.open() as f:
        return json.load(f)


@pytest.mark.parametrize(
    "case",
    json.loads(_fixture_path().read_text())["stage_cases"]
    if _fixture_path().exists()
    else [],
    ids=lambda c: c["name"],
)
def test_stage_dispatch_matches_canonical(case):
    out = dispatch_stage_verdict(case["verdict"], case["policy"], case["mode"])
    expected = case["expected"]
    assert out["action"] == expected["action"], (
        f"action mismatch for {case['name']}: got {out['action']}, "
        f"want {expected['action']}"
    )
    assert out["record_block"] == expected["record_block"]
    assert out["override_to_proceed"] == expected["override_to_proceed"]


@pytest.mark.parametrize(
    "case",
    json.loads(_fixture_path().read_text())["tool_cases"]
    if _fixture_path().exists()
    else [],
    ids=lambda c: c["name"],
)
def test_tool_dispatch_matches_canonical(case):
    out = dispatch_tool_verdict(
        case["verdict"],
        case["tool_name"],
        case["stage"],
        case["policy"],
        case["mode"],
    )
    expected = case["expected"]
    assert out["action"] == expected["action"], (
        f"action mismatch for {case['name']}: got {out['action']}, "
        f"want {expected['action']}"
    )
    assert out["record_failure"] == expected["record_failure"]
    assert out["record_success"] == expected["record_success"]
    assert out["override_to_proceed"] == expected["override_to_proceed"]
