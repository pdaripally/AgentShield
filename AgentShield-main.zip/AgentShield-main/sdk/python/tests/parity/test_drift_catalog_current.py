"""CI-blocking freshness check for the cross-language drift catalog.

The drift catalog (``tests/parity/drift-catalog.json``) is a generated,
machine-readable snapshot of every cross-SDK divergence the parity
contracts know about. It must stay in sync with the canonical contracts
that produce it.

This test runs the generator and diffs its output against the checked-in
artifact. If the canonical contracts changed (someone added a new method
to ``shield_canonical_api.json`` or a new override to
``capability_canonical.json``) but did not regenerate the catalog, this
test fails with the exact command to fix it.

The ``generated_at`` field is normalized away — only material content is
diffed, so the test is reproducible and noise-free.
"""
from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

import pytest


REPO_ROOT = Path(__file__).resolve().parents[4]
PARITY_DIR = REPO_ROOT / "tests" / "parity"
CATALOG = PARITY_DIR / "drift-catalog.json"
GENERATOR = PARITY_DIR / "generate_drift_catalog.py"
SCHEMA = PARITY_DIR / "drift-catalog.schema.json"

_REGEN_CMD = "python3 tests/parity/generate_drift_catalog.py > tests/parity/drift-catalog.json"


def _import_generator():
    spec = importlib.util.spec_from_file_location(
        "agent_shield_drift_generator", GENERATOR
    )
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules.setdefault(spec.name, module)
    spec.loader.exec_module(module)
    return module


def _normalize(catalog: dict) -> dict:
    """Strip non-material fields so generation timestamps don't cause noise."""
    copy = dict(catalog)
    copy.pop("generated_at", None)
    return copy


@pytest.fixture(scope="module")
def fresh_catalog() -> dict:
    return _import_generator().build_catalog()


@pytest.fixture(scope="module")
def checked_in_catalog() -> dict:
    if not CATALOG.exists():
        pytest.fail(
            f"{CATALOG.relative_to(REPO_ROOT)} is missing — run: {_REGEN_CMD}"
        )
    with CATALOG.open(encoding="utf-8") as fh:
        return json.load(fh)


def test_drift_catalog_matches_canonicals(
    fresh_catalog: dict, checked_in_catalog: dict
) -> None:
    """The checked-in catalog must equal a fresh regeneration."""
    if _normalize(fresh_catalog) != _normalize(checked_in_catalog):
        # Build a focused diff so the failure message is actionable.
        diffs = []
        fresh_n = _normalize(fresh_catalog)
        checked_n = _normalize(checked_in_catalog)
        for key in sorted(set(fresh_n) | set(checked_n)):
            if fresh_n.get(key) != checked_n.get(key):
                diffs.append(key)
        pytest.fail(
            "drift catalog is out of date — fields differ: "
            f"{diffs}\n\nRun: {_REGEN_CMD}\nthen commit the result."
        )


def test_drift_catalog_input_hash_matches(
    fresh_catalog: dict, checked_in_catalog: dict
) -> None:
    """The catalog records the SHA-256 of its inputs; mismatch ⇒ stale."""
    fresh_hash = fresh_catalog["source_inputs"]["sha256"]
    checked_hash = checked_in_catalog["source_inputs"]["sha256"]
    assert fresh_hash == checked_hash, (
        "drift catalog source_inputs.sha256 is stale — "
        "the canonical JSONs changed without a catalog regeneration. "
        f"Run: {_REGEN_CMD}"
    )


def test_drift_catalog_schema_exists() -> None:
    """The companion JSON Schema must ship alongside the catalog."""
    assert SCHEMA.exists(), (
        f"{SCHEMA.relative_to(REPO_ROOT)} is missing; "
        "the drift catalog must declare a schema."
    )
    with SCHEMA.open(encoding="utf-8") as fh:
        schema = json.load(fh)
    assert schema.get("title", "").startswith("Agent Shield"), (
        "drift-catalog.schema.json title looks wrong"
    )


def test_drift_catalog_well_formed(checked_in_catalog: dict) -> None:
    """Smoke checks on the structural invariants the schema also enforces."""
    assert checked_in_catalog["languages"] == ["python", "node", "rust", "dotnet"]
    for entry in checked_in_catalog["shield_api"]:
        assert entry["surface"] in ("shield", "shield_builder")
        assert entry["drift_severity"] in ("high", "medium", "low")
        assert set(entry["languages"]) == {"python", "node", "rust", "dotnet"}
    for entry in checked_in_catalog["capability_reports"]:
        assert entry["drift_severity"] in ("high", "medium", "low")
        assert any(v.get("drift") for v in entry["languages"].values()), (
            f"capability entry without drift slipped into the catalog: {entry}"
        )


def test_no_high_severity_drift(checked_in_catalog: dict) -> None:
    """CI gate: every cross-SDK drift entry must be either resolved (low/
    medium) or explicitly flagged as ``intentional_asymmetry`` in the
    canonical file. New high-severity drift fails this test.

    To resolve a high-severity entry:

    1. Fix the gap in the SDK that's missing the method, OR
    2. Mark it as intentional in ``tests/parity/shield_canonical_api.json``
       by adding ``"intentional_asymmetry": true`` and an
       ``"asymmetry_reason"`` describing why the asymmetry is the right
       call (e.g. "Rust+.NET use per-framework helpers; Python+Node use
       the framework-bundle pattern").

    Then regenerate the catalog and re-run this test.
    """
    summary = checked_in_catalog["summary"]
    high_total = summary["totals"]["high"]
    if high_total == 0:
        return  # Nothing to do.

    high_entries: list[str] = []
    for entry in checked_in_catalog["shield_api"]:
        if entry["drift_severity"] == "high":
            high_entries.append(
                f"shield_api: {entry['surface']}.{entry['concept']}"
            )
    for entry in checked_in_catalog["capability_reports"]:
        if entry["drift_severity"] == "high":
            high_entries.append(
                f"capability: {entry['framework']}.{entry['stage']}"
            )
    for entry in checked_in_catalog["framework_naming"]:
        if entry["drift_severity"] == "high":
            high_entries.append(
                f"framework_naming: {entry['concept']}"
            )

    pytest.fail(
        f"Drift catalog has {high_total} high-severity entries:\n  - "
        + "\n  - ".join(high_entries)
        + "\n\nFix the gap in the SDK or mark the asymmetry as intentional "
        "in tests/parity/shield_canonical_api.json (see test docstring)."
    )
