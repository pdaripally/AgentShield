"""CapabilityReport conformance test for the Python SDK.

Loads each adapter bundle Python implements and asserts the bundle's
:class:`CapabilityReport` matches ``apply_overrides(canonical, 'python')``
from ``tests/parity/capability_canonical.json``.

Adding a new ``language_overrides.python`` entry in the canonical file
documents a new accepted divergence; removing one forces Python to align
with the canonical claim.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

import pytest


REPO_ROOT = Path(__file__).resolve().parents[4]
CANONICAL_PATH = REPO_ROOT / "tests" / "parity" / "capability_canonical.json"
LANG = "python"

_STAGE_FIELDS = (
    "input_validation",
    "state_validation",
    "tool_authorization",
    "tool_execution_validation",
    "tool_output_validation",
    "output_validation",
    "streaming_output",
)


@pytest.fixture(scope="module")
def canonical() -> dict:
    with open(CANONICAL_PATH, encoding="utf-8") as f:
        return json.load(f)


def _expected(canonical: dict, framework_key: str) -> Dict[str, Any]:
    """Canonical claim merged with this language's accepted overrides."""
    entry = canonical["frameworks"][framework_key]
    out = dict(entry["canonical"])
    overrides = entry.get("language_overrides", {}).get(LANG, {})
    for k, v in overrides.items():
        if k.startswith("$"):
            continue
        out[k] = v
    return out


def _adapter_capabilities() -> Dict[str, Any]:
    """Map framework-key → live CapabilityReport for every Python adapter."""
    from agent_shield.adapters.langchain import _BUNDLE as langchain_bundle
    from agent_shield.adapters.openai_agents import _BUNDLE as openai_bundle
    from agent_shield.adapters.anthropic_agents import (
        _BUNDLE as anthropic_bundle,
    )
    from agent_shield.adapters.semantic_kernel import (
        _BUNDLE as sk_bundle,
    )
    from agent_shield.adapters.autogen import _BUNDLE as autogen_bundle
    from agent_shield.adapters.crewai import _BUNDLE as crewai_bundle
    from agent_shield.mcp import _MCP_CAPABILITIES as mcp_report

    return {
        "langchain": langchain_bundle.capabilities,
        "openai_agents": openai_bundle.capabilities,
        "anthropic_agents": anthropic_bundle.capabilities,
        "semantic_kernel": sk_bundle.capabilities,
        "autogen": autogen_bundle.capabilities,
        "crewai": crewai_bundle.capabilities,
        "mcp": mcp_report,
    }


def _report_to_dict(report) -> Dict[str, str]:
    out: Dict[str, str] = {"framework": report.framework}
    for stage in _STAGE_FIELDS:
        level = getattr(report, stage)
        out[stage] = level.value if hasattr(level, "value") else str(level)
    return out


# Frameworks the canonical says Python implements.
@pytest.fixture(scope="module")
def python_frameworks(canonical) -> list[str]:
    return [
        fw
        for fw, entry in canonical["frameworks"].items()
        if LANG in entry["implemented_in"]
    ]


def test_every_implemented_framework_has_a_canonical_entry(
    canonical, python_frameworks,
):
    """Every Python adapter must show up in the canonical matrix."""
    live = set(_adapter_capabilities().keys())
    declared = set(python_frameworks)
    missing_from_canonical = live - declared
    assert not missing_from_canonical, (
        "Python ships adapter(s) with no canonical CapabilityReport claim: "
        f"{sorted(missing_from_canonical)}. Add an entry to "
        "tests/parity/capability_canonical.json or remove the adapter."
    )


@pytest.mark.parametrize(
    "framework",
    [
        "langchain",
        "openai_agents",
        "anthropic_agents",
        "semantic_kernel",
        "autogen",
        "crewai",
        "mcp",
    ],
)
def test_capability_matches_canonical(canonical, framework):
    expected = _expected(canonical, framework)
    actual = _report_to_dict(_adapter_capabilities()[framework])
    assert actual["framework"] == expected["framework"], (
        f"[{framework}] framework name drift: actual={actual['framework']!r} "
        f"expected={expected['framework']!r}. Either update the Python adapter "
        f"or move this divergence into language_overrides.python in "
        f"tests/parity/capability_canonical.json."
    )

    diffs = []
    for stage in _STAGE_FIELDS:
        if actual[stage] != expected[stage]:
            diffs.append(
                f"  {stage}: actual={actual[stage]!r} expected={expected[stage]!r}"
            )
    assert not diffs, (
        f"[{framework}] capability drift between Python and the canonical "
        f"matrix:\n" + "\n".join(diffs) + "\n"
        f"To accept this divergence, add the field to "
        f"`frameworks.{framework}.language_overrides.{LANG}` in "
        f"tests/parity/capability_canonical.json. To eliminate it, fix the "
        f"Python adapter at sdk/python/agent_shield/adapters/{framework}.py."
    )
