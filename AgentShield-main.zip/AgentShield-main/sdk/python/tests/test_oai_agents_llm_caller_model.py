"""LLM-caller model resolution tests for the OpenAI Agents adapter.

Asserts that ``.guardrails.yaml`` ``configurations[]`` entries actually
drive which model the Stage 1/3/5 LLM judge uses — i.e. that a
``configurations: [{id: stage3-judge, type: llm, model: gpt-4o}]`` entry
is *not* silently overridden by a hard-coded fallback. See the
``python-remove-hardcoded-model`` task for context.
"""
from __future__ import annotations

from typing import Any, List, Optional
from unittest.mock import MagicMock

import pytest

from agent_shield import RuntimeBuilder
from agent_shield.adapters.openai_agents import make_llm_caller


# A minimal valid guardrails YAML with two distinct LLM configurations.
# The runtime doesn't have to actually route through these for the test
# — we only need the merged config to expose them via
# ``runtime.llm_configuration``.
_MULTI_CONFIG_YAML = """
metadata:
  name: oai-llm-caller-model-fixture
  version: 0.1.0
  agent_shield_version: "2.0"
objective:
  goal: ["exercise configurations[] routing"]
  forbidden: ["bypass"]
configurations:
  - id: stage1-judge
    type: llm
    provider: openai.chat
    model: gpt-4o
    max_tokens: 256
  - id: stage3-judge
    type: llm
    provider: openai.chat
    model: gpt-4o-mini-with-context
input_validation:
  guard_policies:
    - name: trivial_input_guard
      evaluate_when:
        - patterns: ["jailbreak"]
          reason: "jailbreak attempt"
      action: "block"
"""


class _RecordingChatCompletions:
    """Stand-in for ``client.chat.completions`` that records every call."""

    def __init__(self) -> None:
        self.calls: List[dict] = []

    def create(self, **kwargs: Any) -> Any:
        self.calls.append(kwargs)
        msg = MagicMock()
        msg.content = "ok"
        choice = MagicMock()
        choice.message = msg
        result = MagicMock()
        result.choices = [choice]
        return result


class _FakeOpenAiClient:
    """Minimal sync OpenAI-shaped client (no ``Async`` in the class name)."""

    def __init__(self) -> None:
        self.chat = MagicMock()
        self.chat.completions = _RecordingChatCompletions()


def _build_runtime(yaml_str: str):
    import tempfile
    import os

    fd, path = tempfile.mkstemp(suffix=".yaml")
    try:
        with os.fdopen(fd, "w") as fh:
            fh.write(yaml_str)
        return RuntimeBuilder.from_yaml(path).build()
    finally:
        os.unlink(path)


# ───────────────────────────────────────────────────────────────────────
# Runtime.llm_configuration accessor


def test_llm_configuration_returns_yaml_model_for_known_id():
    rt = _build_runtime(_MULTI_CONFIG_YAML)
    cfg = rt.llm_configuration("stage1-judge")
    assert cfg is not None
    assert cfg["id"] == "stage1-judge"
    assert cfg["type"] == "llm"
    assert cfg["model"] == "gpt-4o"
    assert cfg.get("max_tokens") == 256


def test_llm_configuration_returns_none_for_unknown_id():
    rt = _build_runtime(_MULTI_CONFIG_YAML)
    assert rt.llm_configuration("does-not-exist") is None


# ───────────────────────────────────────────────────────────────────────
# LLM-caller model selection


def test_caller_uses_yaml_model_for_each_configuration_id():
    rt = _build_runtime(_MULTI_CONFIG_YAML)
    client = _FakeOpenAiClient()

    caller = make_llm_caller(client, configuration_resolver=rt.llm_configuration)

    caller("stage1-judge", "is the input safe?")
    caller("stage3-judge", "is the tool call safe?")

    completions = client.chat.completions
    assert len(completions.calls) == 2
    assert completions.calls[0]["model"] == "gpt-4o"
    assert completions.calls[0].get("max_tokens") == 256
    assert completions.calls[1]["model"] == "gpt-4o-mini-with-context"
    # No max_tokens in YAML for stage3-judge => kwarg must NOT be set.
    assert "max_tokens" not in completions.calls[1]


def test_caller_raises_when_no_matching_configuration():
    """Missing configuration: a security library MUST raise rather
    than silently picking a model on the customer's behalf."""
    from agent_shield.adapters._capabilities import ConfigurationMissingModelError

    rt = _build_runtime(_MULTI_CONFIG_YAML)
    client = _FakeOpenAiClient()

    caller = make_llm_caller(client, configuration_resolver=rt.llm_configuration)

    with pytest.raises(ConfigurationMissingModelError) as exc_info:
        caller("not-in-yaml", "judge me")

    assert "not-in-yaml" in str(exc_info.value)
    # The OpenAI client must not have been called.
    assert len(client.chat.completions.calls) == 0


def test_caller_raises_when_no_resolver_wired():
    """No resolver: every configurationId resolves to "missing" and
    raises. The customer either wires a resolver via Shield.build() or
    they don't get a model — there is no silent fallback."""
    from agent_shield.adapters._capabilities import ConfigurationMissingModelError

    client = _FakeOpenAiClient()

    caller = make_llm_caller(client)

    with pytest.raises(ConfigurationMissingModelError):
        caller("stage1-judge", "prompt")

    assert len(client.chat.completions.calls) == 0


def test_caller_raises_when_configuration_id_is_none():
    from agent_shield.adapters._capabilities import ConfigurationMissingModelError

    rt = _build_runtime(_MULTI_CONFIG_YAML)
    client = _FakeOpenAiClient()

    caller = make_llm_caller(client, configuration_resolver=rt.llm_configuration)

    with pytest.raises(ConfigurationMissingModelError) as exc_info:
        caller(None, "prompt")

    # The id appears as "<unset>" in the message.
    assert "<unset>" in str(exc_info.value)


def test_caller_raises_when_resolver_raises():
    """Resolver exceptions surface as ConfigurationMissingModelError;
    a broken resolver is treated the same as "no entry"."""
    from agent_shield.adapters._capabilities import ConfigurationMissingModelError

    client = _FakeOpenAiClient()

    def broken_resolver(_cid: Optional[str]) -> Optional[dict]:
        raise RuntimeError("boom")

    caller = make_llm_caller(client, configuration_resolver=broken_resolver)

    with pytest.raises(ConfigurationMissingModelError):
        caller("stage1-judge", "prompt")

    assert len(client.chat.completions.calls) == 0


# ───────────────────────────────────────────────────────────────────────
# ShieldBuilder integration — the resolver is wired through build()


def test_shield_builder_wires_resolver_through_build(tmp_path):
    """Shield.from_yaml(...).with_client(...).build() => caller honours YAML.

    Reaches into ``ShieldBuilder`` to grab the actually-wired LLM caller
    (the same closure ``RuntimeBuilder.register_llm_caller`` receives,
    which is what the Rust runtime invokes for every stage). Drives the
    closure directly and asserts the model came from the YAML.
    """
    import agent_shield.adapters.openai_agents  # noqa: F401 — register bundle
    from agent_shield.adapters._shield import ShieldBuilder

    yaml_path = tmp_path / "guardrails.yaml"
    yaml_path.write_text(_MULTI_CONFIG_YAML)

    client = _FakeOpenAiClient()
    builder = (
        ShieldBuilder(str(yaml_path), auto_bind=False)
        .with_openai_agents()
        .with_client(client)
    )
    shield = builder.build()

    # The bound caller MUST already see the runtime's configurations by
    # the time the first stage runs — that's the whole point of the
    # resolver holder being filled in by build().
    bound_caller = builder._llm_caller  # noqa: SLF001 — test introspection
    assert bound_caller is not None

    bound_caller("stage1-judge", "prompt")
    bound_caller("stage3-judge", "prompt")

    completions = client.chat.completions
    assert completions.calls[-2]["model"] == "gpt-4o"
    assert completions.calls[-1]["model"] == "gpt-4o-mini-with-context"

    # Sanity-check the runtime accessor itself is reachable post-build.
    assert shield.runtime.llm_configuration("stage1-judge")["model"] == "gpt-4o"


# ───────────────────────────────────────────────────────────────────────
# Azure-OpenAI routing (§6.2)
#
# `model:` is the identifier passed verbatim to the provider SDK. On
# Azure OpenAI providers (`azure_openai` / `microsoft.azure.openai`)
# the SDK accepts a deployment name in its `model=` kwarg, so the
# customer simply puts the deployment name in `model:`. No special
# Azure branch in the adapter — `model:` is opaque to the runtime.

_AZURE_YAML = """
metadata:
  name: oai-azure-fixture
  version: 0.1.0
  agent_shield_version: "2.0"
objective:
  goal: ["exercise Azure routing"]
  forbidden: ["bypass"]
configurations:
  - id: azure-judge
    type: llm
    provider: azure_openai
    model: my-gpt4o-deployment
  - id: openai-judge
    type: llm
    provider: openai.chat
    model: gpt-4o
input_validation:
  guard_policies:
    - name: trivial_input_guard
      evaluate_when:
        - patterns: ["jailbreak"]
          reason: "jailbreak attempt"
      action: "block"
"""


def test_runtime_surfaces_model_for_azure_entry():
    rt = _build_runtime(_AZURE_YAML)
    cfg = rt.llm_configuration("azure-judge")
    assert cfg is not None
    # On Azure OpenAI, `model:` carries the deployment name — the
    # string the provider SDK accepts as the model identifier.
    assert cfg["model"] == "my-gpt4o-deployment"
    assert cfg["provider"] == "azure_openai"


def test_caller_sends_yaml_model_for_azure_entry():
    rt = _build_runtime(_AZURE_YAML)
    client = _FakeOpenAiClient()
    caller = make_llm_caller(client, configuration_resolver=rt.llm_configuration)

    caller("azure-judge", "prompt")

    completions = client.chat.completions
    assert len(completions.calls) == 1
    # The YAML's `model:` flows through verbatim to the SDK kwarg.
    assert completions.calls[0]["model"] == "my-gpt4o-deployment"


def test_caller_sends_yaml_model_for_non_azure_entry():
    rt = _build_runtime(_AZURE_YAML)
    client = _FakeOpenAiClient()
    caller = make_llm_caller(client, configuration_resolver=rt.llm_configuration)

    caller("openai-judge", "prompt")

    completions = client.chat.completions
    assert completions.calls[0]["model"] == "gpt-4o"


def test_caller_accepts_reverse_domain_azure_provider():
    yaml = """
metadata:
  name: rd
  version: 0.1.0
  agent_shield_version: "2.0"
objective:
  goal: ["x"]
  forbidden: ["bypass"]
configurations:
  - id: judge
    type: llm
    provider: microsoft.azure.openai
    model: my-deploy
input_validation:
  guard_policies:
    - name: trivial
      evaluate_when:
        - patterns: ["x"]
          reason: "x"
      action: "block"
"""
    rt = _build_runtime(yaml)
    client = _FakeOpenAiClient()
    caller = make_llm_caller(client, configuration_resolver=rt.llm_configuration)
    caller("judge", "prompt")
    assert client.chat.completions.calls[0]["model"] == "my-deploy"
