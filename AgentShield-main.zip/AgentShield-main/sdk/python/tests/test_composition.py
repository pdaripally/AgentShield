"""Composition pattern tests for the Python adapters.

Verifies that for every adapter:

1. Importing the adapter installs ``with_<framework>`` on
   :class:`agent_shield.ShieldBuilder` and ``create_<framework>_agent``
   on :class:`agent_shield.Shield` (side-effect import).
2. ``Shield.from_yaml(path).with_<framework>().build()`` produces a
   working :class:`Shield` whose capability report matches the bundle.
"""
from __future__ import annotations

from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent.parent.parent
GLOBAL_FIXTURES = REPO_ROOT / "tests" / "fixtures"
MINIMAL = str(GLOBAL_FIXTURES / "smoke" / "minimal.guardrails.yaml")


# Each entry: (module_path, framework_method, framework_name)
_ADAPTERS = [
    ("agent_shield.adapters.langchain", "with_langchain", "langchain"),
    (
        "agent_shield.adapters.openai_agents",
        "with_openai_agents",
        "openai_agents",
    ),
    (
        "agent_shield.adapters.anthropic_agents",
        "with_anthropic_agents",
        "anthropic_agents",
    ),
    ("agent_shield.adapters.autogen", "with_autogen", "autogen"),
    ("agent_shield.adapters.crewai", "with_crewai", "crewai"),
    (
        "agent_shield.adapters.semantic_kernel",
        "with_semantic_kernel",
        "semantic_kernel",
    ),
]


@pytest.fixture(scope="module", params=_ADAPTERS, ids=[a[2] for a in _ADAPTERS])
def adapter(request):
    """Import the adapter module (side-effect installs methods)."""
    import importlib

    module_path, method_name, framework = request.param
    module = importlib.import_module(module_path)
    return module, method_name, framework


# ═══════════════════════════════════════════════════════════════════════════
# 1.  Side-effect import installs the with_<framework>() method
# ═══════════════════════════════════════════════════════════════════════════


class TestSideEffectInstall:
    def test_with_method_installed_on_shieldbuilder(self, adapter):
        """``with_<framework>`` is present on ShieldBuilder after import."""
        from agent_shield import ShieldBuilder

        _module, method_name, _framework = adapter
        assert hasattr(ShieldBuilder, method_name), (
            f"ShieldBuilder.{method_name} not installed by adapter import"
        )
        assert callable(getattr(ShieldBuilder, method_name))

    def test_create_agent_factory_installed_on_shield(self, adapter):
        """``create_<framework>_agent`` is present on Shield after import."""
        from agent_shield import Shield

        _module, _method, framework = adapter
        factory = f"create_{framework}_agent"
        assert hasattr(Shield, factory), (
            f"Shield.{factory} not installed by adapter import"
        )
        assert callable(getattr(Shield, factory))

    def test_shield_exported_from_top_level_package(self):
        """``from agent_shield import Shield`` works."""
        from agent_shield import Shield, ShieldBuilder

        assert Shield is not None
        assert ShieldBuilder is not None


# ═══════════════════════════════════════════════════════════════════════════
# 2.  Composition pattern produces a working Shield
# ═══════════════════════════════════════════════════════════════════════════


class TestComposition:
    def test_from_yaml_with_framework_build(self, adapter):
        """``Shield.from_yaml(path).with_<framework>().build()`` works."""
        from agent_shield import Shield

        _module, method_name, framework = adapter
        # `auto_bind=False` so the multi-adapter test session (multiple
        # adapter modules imported across the parametrised fixture)
        # doesn't trip the new AmbientBundleAmbiguityError on
        # construction; the explicit `with_<framework>()` call pins the
        # bundle deterministically.
        builder = Shield.from_yaml(MINIMAL, auto_bind=False)
        builder = getattr(builder, method_name)()
        shield = builder.build()
        assert shield is not None
        assert isinstance(shield, Shield)
        # Capability report carries the framework name
        assert shield.capabilities.framework == framework

    def test_capability_report_matches_bundle(self, adapter):
        """Capability report of composed Shield matches the bundle's."""
        from agent_shield import Shield

        module, method_name, _framework = adapter
        shield = getattr(
            Shield.from_yaml(MINIMAL, auto_bind=False), method_name,
        )().build()
        assert shield.capabilities is module._BUNDLE.capabilities

    def test_build_without_framework_succeeds_with_no_bundle_methods_unavailable(self):
        """``build()`` without a bundle now succeeds — the framework-agnostic
        methods (``run`` / ``protect_tool`` / ``before_invoke``) work on the
        resulting shield. Methods that need a bundle (``guard`` / ``protect_tools``
        / ``capabilities``) raise a clear error at call time, NOT at build time.

        Mirrors the Node SDK's behaviour where a null bundle is allowed.
        """
        from agent_shield import Shield
        from agent_shield.adapters import _bundle_registry

        # Force the auto-bind registry to be empty so this test can
        # exercise the genuine null-bundle path. (Other tests in the
        # session may have imported adapters; we snapshot here and
        # restore at the end so we don't perturb sibling tests.)
        previous = dict(_bundle_registry._REGISTERED)
        _bundle_registry.reset()
        try:
            shield = Shield.from_yaml(MINIMAL).build()

            # Bundle-requiring accessors fail with a clear message.
            with pytest.raises(RuntimeError, match="with_<framework>"):
                _ = shield.capabilities

            with pytest.raises(RuntimeError, match="with_<framework>"):
                shield.protect_tools([])

            with pytest.raises(RuntimeError, match="with_<framework>"):
                shield.guard(object())
        finally:
            _bundle_registry._REGISTERED.update(previous)

    def test_protect_tools_works_on_composed_shield(self, adapter):
        """``protect_tools([])`` returns an empty list on a composed shield.

        Smoke test that the bundle's tool wrapper is wired up correctly.
        """
        from agent_shield import Shield

        _module, method_name, _framework = adapter
        shield = getattr(
            Shield.from_yaml(MINIMAL, auto_bind=False), method_name,
        )().build()
        assert shield.protect_tools([]) == []


# ═══════════════════════════════════════════════════════════════════════════
# 3.  Client rebinding when client is set before with_<framework>()
# ═══════════════════════════════════════════════════════════════════════════


class TestClientRebinding:
    """Use openai_agents because its make_caller closure doesn't trigger
    the framework import on a sentinel client (langchain's does)."""

    def test_client_set_before_bundle_is_rebound(self):
        """Matches Node behaviour: client set first → re-bound on bundle."""
        from agent_shield import Shield
        from agent_shield.adapters import _bundle_registry

        # Reset so this test exercises the explicit `with_openai_agents()`
        # path rather than the auto-bind path that other imported adapters
        # may have set up.
        previous = dict(_bundle_registry._REGISTERED)
        _bundle_registry.reset()
        try:
            builder = Shield.from_yaml(MINIMAL)
            sentinel = object()
            builder.with_client(sentinel)
            assert builder._client is sentinel
            # No bundle imported / registered → caller has not been bound yet.
            assert builder._llm_caller is None

            # Attaching the bundle re-binds the buffered client through
            # the bundle's caller factory.
            builder.with_openai_agents()
            assert builder._llm_caller is not None
        finally:
            _bundle_registry._REGISTERED.update(previous)

    def test_client_set_after_bundle_is_bound(self):
        """Bundle first then client also wires the caller."""
        from agent_shield import Shield
        from agent_shield.adapters import _bundle_registry

        previous = dict(_bundle_registry._REGISTERED)
        _bundle_registry.reset()
        try:
            builder = Shield.from_yaml(MINIMAL).with_openai_agents()
            assert builder._llm_caller is None
            builder.with_client(object())
            assert builder._llm_caller is not None
        finally:
            _bundle_registry._REGISTERED.update(previous)



# ═══════════════════════════════════════════════════════════════════════════
# 4.  Bundle auto-binding via import side-effect (drops `with_<framework>()` ceremony)
# ═══════════════════════════════════════════════════════════════════════════


class TestBundleAutoBinding:
    """A single imported adapter module registers its bundle on the
    module-level registry; new ``ShieldBuilder`` instances pick it up
    automatically. Multiple imported adapters make auto-bind ambiguous
    and raise; customers disambiguate via ``auto_bind=False`` plus
    ``with_<framework>()``."""

    def test_auto_binding_happens_when_adapter_imported(self):
        from agent_shield import Shield
        from agent_shield.adapters import _bundle_registry

        # Snapshot then reset so this test exercises a clean single-adapter
        # state regardless of which other adapters sibling tests imported.
        previous = dict(_bundle_registry._REGISTERED)
        _bundle_registry.reset()
        try:
            # Importing an adapter must register a bundle. (Re-import is
            # a no-op against sys.modules so we re-register explicitly to
            # decouple from import order within the test session.)
            import agent_shield.adapters.openai_agents as oai_mod  # noqa: F401
            _bundle_registry.register(oai_mod._BUNDLE)

            assert _bundle_registry.active_bundle() is not None

            # New builder picks up the auto-bound bundle without any
            # `with_<framework>()` call.
            builder = Shield.from_yaml(MINIMAL)
            assert builder._bundle is not None

            # Build still works without the explicit ceremony.
            shield = builder.build()
            assert shield.capabilities is not None
        finally:
            _bundle_registry._REGISTERED.clear()
            _bundle_registry._REGISTERED.update(previous)

    def test_explicit_with_framework_overrides_auto_bound_bundle(self):
        from agent_shield import Shield
        from agent_shield.adapters import _bundle_registry

        previous = dict(_bundle_registry._REGISTERED)
        _bundle_registry.reset()
        try:
            # Start with a single adapter so auto-bind succeeds, then
            # verify explicit `with_<framework>()` overrides it.
            import agent_shield.adapters.openai_agents as oai_mod  # noqa: F401
            _bundle_registry.register(oai_mod._BUNDLE)

            builder = Shield.from_yaml(MINIMAL)
            assert builder._bundle is not None
            assert builder._bundle.name == "openai_agents"

            # Importing a second adapter and explicitly pinning it via
            # `with_<framework>()` overrides the auto-bound bundle.
            import agent_shield.adapters.anthropic_agents as anthr_mod  # noqa: F401
            _bundle_registry.register(anthr_mod._BUNDLE)

            builder.with_anthropic_agents()
            assert builder._bundle.name == "anthropic_agents"
        finally:
            _bundle_registry._REGISTERED.clear()
            _bundle_registry._REGISTERED.update(previous)
