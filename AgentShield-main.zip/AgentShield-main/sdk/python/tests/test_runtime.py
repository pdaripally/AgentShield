"""End-to-end tests for the Python SDK against the
:mod:`agent_shield` public surface."""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent.parent.parent
GLOBAL_FIXTURES = REPO_ROOT / "tests" / "fixtures"
LOCAL_FIXTURES = Path(__file__).resolve().parent / "fixtures_smoke"

MINIMAL = str(GLOBAL_FIXTURES / "smoke" / "minimal.guardrails.yaml")
VARS_AND_EVENTS = str(GLOBAL_FIXTURES / "smoke" / "variables-and-events.guardrails.yaml")
GUARD_POLICY_MERGE = str(GLOBAL_FIXTURES / "smoke" / "guard-policy-merge.guardrails.yaml")
APPROVAL = str(LOCAL_FIXTURES / "approval.guardrails.yaml")
# `redact` and `event_gate` were promoted to shared smoke fixtures so the
# cross-language conformance harness can reach them; the streaming tests
# below still consume `redact` from its new shared home.
REDACT = str(GLOBAL_FIXTURES / "smoke" / "redact.guardrails.yaml")


# ═══════════════════════════════════════════════════════════════════════════
# IMPORTS
# ═══════════════════════════════════════════════════════════════════════════


class TestPackageImports:
    """The public namespace is published cleanly."""

    def test_import_namespace(self):
        import agent_shield as sdk

        assert hasattr(sdk, "RuntimeBuilder")
        assert hasattr(sdk, "Runtime")
        assert hasattr(sdk, "Session")
        assert hasattr(sdk, "StageVerdict")
        assert hasattr(sdk, "Lifetime")

    def test_canonical_module_importable(self):
        # `agent_shield` is the canonical public module.
        import agent_shield

        assert hasattr(agent_shield, "RuntimeBuilder")
        assert hasattr(agent_shield, "Runtime")
        assert hasattr(agent_shield, "Session")

    def test_native_submodule_present(self):
        # All native classes live at the `_native` module root.
        import agent_shield._native as native

        assert hasattr(native, "RuntimeBuilder")
        assert hasattr(native, "GuardrailsRuntime")
        assert hasattr(native, "GuardrailsSession")
        assert hasattr(native, "StreamingGuard")

    def test_hook_protocols_exposed(self):
        from agent_shield import (
            AgentResolver,
            DelegateDispatcher,
            LlmCaller,
            ClassifierCaller,
            ObservabilityProvider,
        )

        assert AgentResolver is not None
        assert DelegateDispatcher is not None
        assert LlmCaller is not None
        assert ClassifierCaller is not None
        assert ObservabilityProvider is not None


# ═══════════════════════════════════════════════════════════════════════════
# RUNTIMEBUILDER
# ═══════════════════════════════════════════════════════════════════════════


class TestRuntimeBuilder:
    """Builder loads YAML and produces an immutable runtime."""

    def test_from_yaml_minimal(self):
        from agent_shield import RuntimeBuilder

        rt = RuntimeBuilder.from_yaml(MINIMAL).build()
        assert rt.metadata_name == "smoke-minimal"

    def test_from_yaml_variables_and_events(self):
        from agent_shield import RuntimeBuilder

        rt = RuntimeBuilder.from_yaml(VARS_AND_EVENTS).build()
        names = set(rt.variable_names)
        assert "send_authorized" in names
        assert "messages_sent" in names

    def test_from_yaml_guard_policy_merge(self):
        from agent_shield import RuntimeBuilder

        rt = RuntimeBuilder.from_yaml(GUARD_POLICY_MERGE).build()
        # The leaf wins for metadata.name even though both files declare it.
        assert "leaf" in rt.metadata_name

    def test_from_yaml_chain(self):
        from agent_shield import RuntimeBuilder

        # Chain of one is the same as from_yaml.
        rt = RuntimeBuilder.from_yaml_chain([MINIMAL]).build()
        assert rt.metadata_name == "smoke-minimal"

    def test_builder_is_consumed_by_build(self):
        from agent_shield import RuntimeBuilder

        builder = RuntimeBuilder.from_yaml(MINIMAL)
        builder.build()
        with pytest.raises(Exception):
            builder.build()

    def test_register_extractor(self):
        # extractor registration must not raise; the actual extraction is
        # exercised by populator tests in the Rust suite.
        from agent_shield import RuntimeBuilder

        rt = (
            RuntimeBuilder.from_yaml(MINIMAL)
            .register_extractor("test.identity", lambda v: v)
            .build()
        )
        assert rt.metadata_name == "smoke-minimal"


# ═══════════════════════════════════════════════════════════════════════════
# REQUEST CONTEXT / SESSION
# ═══════════════════════════════════════════════════════════════════════════


class TestSessionLifecycle:
    def _runtime(self, path: str = MINIMAL):
        from agent_shield import RuntimeBuilder

        return RuntimeBuilder.from_yaml(path).build()

    def test_default_request_context(self):
        rt = self._runtime()
        session = rt.new_session()
        # Default ids are auto-generated and non-empty.
        assert session.current_turn_id == 0

    def test_explicit_request_context(self):
        rt = self._runtime()
        session = rt.new_session(
            session_id="sess-42",
            correlation_id="corr-42",
            user_id="alice",
            tenant_id="acme",
            extensions={"region": "EU"},
        )
        assert session.current_turn_id == 0

    def test_begin_end_turn(self):
        rt = self._runtime()
        session = rt.new_session(session_id="s1", correlation_id="c1")
        assert session.begin_turn() == 1
        assert session.current_turn_id == 1
        session.end_turn()

    def test_multiple_turns(self):
        rt = self._runtime()
        session = rt.new_session(session_id="s1", correlation_id="c1")
        assert session.begin_turn() == 1
        session.end_turn()
        assert session.begin_turn() == 2

    def test_begin_end_request(self):
        rt = self._runtime()
        session = rt.new_session(session_id="s1", correlation_id="c1")
        assert session.begin_request() == 1
        session.end_request()

    def test_session_context_manager(self):
        rt = self._runtime()
        with rt.new_session(session_id="s1", correlation_id="c1") as session:
            session.begin_turn()
            session.begin_request()
            assert session.current_turn_id == 1


# ═══════════════════════════════════════════════════════════════════════════
# VARIABLE OPS
# ═══════════════════════════════════════════════════════════════════════════


class TestVariableOps:
    def _session(self):
        from agent_shield import RuntimeBuilder

        rt = RuntimeBuilder.from_yaml(MINIMAL).build()
        s = rt.new_session(session_id="s1", correlation_id="c1")
        s.begin_turn()
        return s

    def test_unknown_variable_raises(self):
        s = self._session()
        with pytest.raises(Exception):
            s.set_variable("nonexistent_var", True)

    def test_read_unknown_variable_returns_none(self):
        s = self._session()
        assert s.read_variable("nonexistent_var") is None

    def test_large_unsigned_int_roundtrip(self):
        # P12.5: u64 values larger than i64::MAX must round-trip through
        # the JSON↔Python conversion as a Python int (not silently
        # downgraded to a float). Python-typed surface concern (pyo3
        # numeric coercion) — kept in L3.
        from agent_shield import RuntimeBuilder

        rt = RuntimeBuilder.from_yaml(VARS_AND_EVENTS).build()
        s = rt.new_session(session_id="s1", correlation_id="c1")
        s.begin_turn()
        big = 2**63 + 7  # > i64::MAX, fits in u64
        s.set_variable("recipient_profile", {"id": big})
        state = s.read_variable("recipient_profile")
        assert state is not None
        assert state.value == {"id": big}
        # Verify the value did not get coerced to float.
        assert isinstance(state.value["id"], int)


# NOTE: variable round-trip / reset / object-value round-trip cases moved
# to tests/cases/state-transitions.cases.yaml — they assert spec-defined
# runtime behaviour that the cross-language harness covers identically.


# ═══════════════════════════════════════════════════════════════════════════
# STAGE VALIDATION
# ═══════════════════════════════════════════════════════════════════════════


class TestStageValidation:
    def _session(self, path: str = MINIMAL):
        from agent_shield import RuntimeBuilder

        rt = RuntimeBuilder.from_yaml(path).build()
        s = rt.new_session(session_id="s1", correlation_id="c1")
        s.begin_turn()
        return s

    def test_stage_verdict_truthiness(self):
        # Python `bool(verdict)` mirrors `verdict.allowed` — pure typed-surface
        # operator-overload concern, kept in L3.
        s = self._session()
        v = s.validate_input("hello")
        assert bool(v) == v.allowed


# NOTE: validate_input pass-through, validate_tool_call state block / allow,
# and validate_output pass-through cases moved to L2 (input-validation,
# tool-call, output-validation cases.yaml respectively). Same fixtures and
# spec-defined verdicts; the cross-language harness covers them across
# Python / Node / .NET.


# ═══════════════════════════════════════════════════════════════════════════
# REDACTION (Stage 5)
# ═══════════════════════════════════════════════════════════════════════════
# NOTE: Stage-5 redaction behaviour (replace-on-match, pass-through-on-miss)
# moved to tests/cases/output-validation.cases.yaml. Streaming Stage-5
# redaction stays in L3 below — it exercises the Python-only StreamingGuard
# context-manager surface, not the verdict semantics.


# ═══════════════════════════════════════════════════════════════════════════
# EVENTS / INCIDENTS
# ═══════════════════════════════════════════════════════════════════════════


class TestEventOps:
    def test_invalid_event_id_raises(self):
        # Python typed-surface concern: the binding must surface a Python
        # exception (not a silent failure) when given an invalid event id.
        # Spec-level event-flow behaviour — incident block/clear and
        # `until_event` lifetime expiry — moved to
        # tests/cases/state-transitions.cases.yaml.
        from agent_shield import RuntimeBuilder

        rt = RuntimeBuilder.from_yaml(MINIMAL).build()
        with rt.new_session(session_id="s1", correlation_id="c1") as session:
            with pytest.raises(Exception):
                session.emit_event("not a real event id 🚫")


# ═══════════════════════════════════════════════════════════════════════════
# RESOLVERS
# ═══════════════════════════════════════════════════════════════════════════


class TestHumanResolverCanonicalToolCall:
    """`kind: human` is a thin shim over `kind: tool` — it dispatches
    through the canonical `agent_shield.ask_human` MCP tool path. Tests
    verify the deny-with-pending-resolution flow."""

    def test_kind_human_emits_pending_resolution_on_deny(self):
        from agent_shield import RuntimeBuilder
        import tempfile
        import os

        # Use a fixture that DOES trigger auto-resolution: a bare
        # `send_authorized == true` expression (no `defined()` guard).
        # Per spec §11.5, that pattern auto-resolves the variable; the
        # `kind: human` resolver suspends and the verdict carries
        # `pending_resolution`.
        yaml = """
metadata:
  name: "py-test-pending-resolution"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["block until authorized"]
  forbidden: ["skip"]
resources:
  tools:
    - name: "send_message"
      description: "Send a message."
      permission: "execute"
variables:
  - name: "send_authorized"
    type: "boolean"
    on_demand_by:
      kind: "human"
      prompt: "Authorize sending message?"
    lifetime: "per_session"
state_validation:
  guard_policies:
    - name: "send_requires_authorization"
      applies_to:
        tools: ["send_message"]
      evaluate_when:
        - expression: "send_authorized == true"
          reason: "Send was not authorized for this call."
      action: "block"
"""
        with tempfile.NamedTemporaryFile(
            "w", suffix=".guardrails.yaml", delete=False
        ) as f:
            f.write(yaml)
            path = f.name
        try:
            rt = RuntimeBuilder.from_yaml(path).build()
            with rt.new_session(session_id="s1", correlation_id="c1") as session:
                session.begin_turn()
                blocked = session.validate_tool_call("send_message", {"msg": "hi"}, tool_call_id="call_1")
                assert blocked.verdict.allowed is False
                pending = blocked.verdict.pending_resolution
                assert pending is not None, "block must surface pending_resolution"
                assert pending["tool"] == "agent_shield.ask_human"
                assert pending["variable"] == "send_authorized"
                assert pending["kind"] == "human"
        finally:
            os.unlink(path)

    def test_kind_human_resolve_variable_returns_none(self):
        # Direct resolve_variable() suspends and yields None; the host's
        # job is to surface the pending_resolution to the agent and have
        # it call agent_shield.ask_human.
        from agent_shield import RuntimeBuilder

        rt = RuntimeBuilder.from_yaml(APPROVAL).build()
        with rt.new_session(session_id="s1", correlation_id="c1") as session:
            session.begin_turn()
            value = session.resolve_variable("send_authorized")
            assert value is None

    def test_bundled_auto_reject_provider_is_auto_wired_from_yaml(self):
        # Cross-language proof that bundled `kind: human` providers
        # work from YAML alone — no Python-side host registration. The
        # runtime builder in agent_shield_core auto-registers the
        # bundled handler when it sees `provider: auto_reject` in the
        # YAML, and Python (via PyO3 FFI) inherits that behavior for
        # free.
        import os
        import tempfile

        from agent_shield import RuntimeBuilder

        yaml = """
metadata:
  name: "py-bundled-auto-reject"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["only-when-approved"]
  forbidden: ["never"]
resources:
  tools:
    - name: "send_money"
      description: "send"
      permission: "execute"
variables:
  - name: "send_authorized"
    type: "boolean"
    on_demand_by:
      kind: "human"
      provider: "auto_reject"
      prompt: "Authorize send_money?"
state_validation:
  guard_policies:
    - name: "send_requires_approval"
      applies_to:
        tools: ["send_money"]
      evaluate_when:
        - expression: "send_authorized == true"
          reason: "send_money requires explicit approval"
      action: "block"
"""
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".yaml", delete=False
        ) as f:
            f.write(yaml)
            path = f.name

        try:
            # Deliberately no host-side `register_human_provider` —
            # proves the bundled provider is auto-wired by build().
            rt = RuntimeBuilder.from_yaml(path).build()
            with rt.new_session(session_id="s1", correlation_id="c1") as session:
                outcome = session.validate_tool_call("send_money", {"amount": 100}, tool_call_id="call_1")
                assert (
                    not outcome.verdict.allowed
                ), "auto-wired auto_reject must deny without host code"
                assert outcome.verdict.policy == "send_requires_approval"
        finally:
            os.unlink(path)


# ═══════════════════════════════════════════════════════════════════════════
# OBSERVABILITY
# ═══════════════════════════════════════════════════════════════════════════


class TestObservability:
    def test_capturing_provider_receives_events(self):
        from agent_shield import RuntimeBuilder
        from agent_shield.observability import CapturingProvider

        provider = CapturingProvider()
        rt = (
            RuntimeBuilder.from_yaml(MINIMAL)
            .register_observability_provider(provider)
            .build()
        )
        with rt.new_session(session_id="s1", correlation_id="c1") as session:
            session.begin_turn()
            session.validate_input("hello")
            session.set_variable("authorized", True)
            session.validate_tool_call("echo", {"msg": "hi"}, tool_call_id="call_1")
            session.end_turn()

        # We should have captured at least the resolver/var/state log events.
        assert len(provider.events) > 0
        # Spot-check a known field — severity is always populated.
        sample = provider.events[0]
        assert sample.severity in {"info", "low", "medium", "high", "critical"}
        assert sample.event_type

    def test_otel_genai_attributes_emitted_on_every_event(self):
        # Cross-language proof: every event surfaced through the
        # Python provider carries OTel GenAI semantic-convention
        # attributes (gen_ai.system="agent_shield",
        # gen_ai.operation.name=...). Block events also get
        # gen_ai.response.finish_reason="content_filter". This makes
        # AgentShield events show up in Phoenix / Logfire / Honeycomb /
        # Azure Monitor without any customer configuration.
        from agent_shield import RuntimeBuilder
        from agent_shield.observability import CapturingProvider

        cap = CapturingProvider()
        rt = (
            RuntimeBuilder.from_yaml(MINIMAL)
            .register_observability_provider(cap)
            .build()
        )
        with rt.new_session(session_id="s1", correlation_id="c1") as session:
            session.begin_turn()
            # Don't set authorized → tool call blocks.
            session.validate_tool_call("echo", {"msg": "hi"}, tool_call_id="call_1")
            session.end_turn()

        assert len(cap.events) > 0

        # gen_ai.system should be stamped on every emitted event.
        for ev in cap.events:
            attrs = ev.attributes
            assert (
                attrs.get("gen_ai.system") == "agent_shield"
            ), f"event {ev.event_type} missing gen_ai.system"
            assert (
                "gen_ai.operation.name" in attrs
            ), f"event {ev.event_type} missing gen_ai.operation.name"

        # At least one block event should carry the
        # content_filter finish_reason.
        block_events = [
            ev
            for ev in cap.events
            if ev.attributes.get("gen_ai.response.finish_reason")
            == "content_filter"
        ]
        assert (
            len(block_events) > 0
        ), "block events must carry gen_ai.response.finish_reason=content_filter"

    def test_callable_provider_accepted(self):
        from agent_shield import RuntimeBuilder
        from agent_shield.observability import ShieldLogEvent

        sink: List[ShieldLogEvent] = []
        rt = (
            RuntimeBuilder.from_yaml(MINIMAL)
            .register_observability_provider(sink.append)
            .build()
        )
        with rt.new_session(session_id="s1", correlation_id="c1") as session:
            session.begin_turn()
            session.set_variable("authorized", True)

        assert len(sink) > 0
        for ev in sink:
            assert isinstance(ev, ShieldLogEvent)


# ═══════════════════════════════════════════════════════════════════════════
# STREAMING
# ═══════════════════════════════════════════════════════════════════════════


class TestStreaming:
    def test_streaming_redacts_secret(self):
        from agent_shield import RuntimeBuilder

        rt = RuntimeBuilder.from_yaml(REDACT).build()
        with rt.new_session(session_id="s1", correlation_id="c1") as session:
            session.begin_turn()
            with session.streaming_session(stage=5) as guard:
                # On-complete cadence — no emission until finish().
                guard.push("Here is ")
                guard.push("the token SECRET-AB12CD34, careful.")
                final = guard.finish()
            assert "SECRET-AB12CD34" not in final.payload

    def test_streaming_session_str_alias(self):
        from agent_shield import RuntimeBuilder

        rt = RuntimeBuilder.from_yaml(REDACT).build()
        with rt.new_session(session_id="s1", correlation_id="c1") as session:
            session.begin_turn()
            with session.streaming_session(stage="output") as guard:
                guard.push("All clean text here.")
                final = guard.finish()
            assert "All clean text here." in final.payload

    def test_streaming_process_iterator(self):
        from agent_shield import RuntimeBuilder

        rt = RuntimeBuilder.from_yaml(REDACT).build()
        with rt.new_session(session_id="s1", correlation_id="c1") as session:
            session.begin_turn()
            chunks = ["part one ", "part two ", "part three"]
            with session.streaming_session(stage=5) as guard:
                output = "".join(guard.process(chunks))
            assert "part one" in output
            assert "part three" in output

    def test_streaming_buffer_property(self):
        from agent_shield import RuntimeBuilder

        rt = RuntimeBuilder.from_yaml(REDACT).build()
        with rt.new_session(session_id="s1", correlation_id="c1") as session:
            session.begin_turn()
            guard = session.streaming_session(stage=5)
            guard.push("abc")
            guard.push("def")
            assert "abcdef" in guard.buffer
            assert guard.chunks_received == 2
            guard.finish()
            assert guard.is_ended

    def test_streaming_mode_defaults_to_on_complete(self):
        from agent_shield import RuntimeBuilder

        rt = RuntimeBuilder.from_yaml(REDACT).build()
        with rt.new_session(session_id="s1", correlation_id="c1") as session:
            session.begin_turn()
            with session.streaming_session(stage=5) as guard:
                assert guard.mode == "on_complete"

    def test_streaming_on_complete_buffers_until_finish(self):
        # In on_complete mode the engine MUST NOT emit any payload until
        # finish() is called. Each push returns Pass(empty). The final
        # validated text is delivered as the single emission from
        # finish().
        from agent_shield import RuntimeBuilder

        rt = RuntimeBuilder.from_yaml(REDACT).build()
        with rt.new_session(session_id="s1", correlation_id="c1") as session:
            session.begin_turn()
            with session.streaming_session(stage=5) as guard:
                assert guard.mode == "on_complete"
                r1 = guard.push("Here is ")
                r2 = guard.push("the token SECRET-AB12CD34, careful.")
                # Every push returns Pass(empty payload) — nothing
                # safely emittable until finish() runs the full
                # validator.
                assert r1.action == "pass"
                assert r1.payload == ""
                assert r2.action == "pass"
                assert r2.payload == ""
                final = guard.finish()
            # Single emission at finish carries the validated
            # (redacted) text.
            assert "SECRET-AB12CD34" not in final.payload
            assert len(final.payload) > 0


# ═══════════════════════════════════════════════════════════════════════════
# RECORD HOOKS
# ═══════════════════════════════════════════════════════════════════════════


class TestResourceRecordHooks:
    def _session(self):
        from agent_shield import RuntimeBuilder

        rt = RuntimeBuilder.from_yaml(MINIMAL).build()
        s = rt.new_session(session_id="s1", correlation_id="c1")
        s.begin_turn()
        return s

    def test_record_tool_success(self):
        s = self._session()
        # Should not raise.
        s.record_tool_success("echo", {"out": "ok"})

    def test_record_tool_failure(self):
        s = self._session()
        s.record_tool_failure("echo", "boom")

    def test_record_endpoint_helpers(self):
        s = self._session()
        s.record_endpoint_success("GET", "/api/x", {"ok": True})
        s.record_endpoint_failure("GET", "/api/x", "boom")

    def test_record_agent_helpers(self):
        s = self._session()
        s.record_agent_success("subagent", {"ok": True})
        s.record_agent_failure("subagent", "boom")


# ═══════════════════════════════════════════════════════════════════════════
# LIFETIME HELPER
# ═══════════════════════════════════════════════════════════════════════════


class TestLifetimeHelper:
    def test_per_call(self):
        from agent_shield import Lifetime

        assert Lifetime.per_call().to_native() == "per_call"

    def test_per_session(self):
        from agent_shield import Lifetime

        assert Lifetime.per_session().to_native() == "per_session"

    def test_for_duration(self):
        from agent_shield import Lifetime

        assert Lifetime.for_duration("PT5M").to_native() == {"for": "PT5M"}

    def test_until_event_single(self):
        from agent_shield import Lifetime

        assert Lifetime.until_event("session.end").to_native() == {
            "until_event": "session.end"
        }

    def test_until_event_multi(self):
        from agent_shield import Lifetime

        v = Lifetime.until_event("session.end", "turn.end").to_native()
        assert v == {"until_event": ["session.end", "turn.end"]}

    def test_until_event_rejects_empty(self):
        # P12.6: empty event list must surface a Python ValueError
        # rather than reaching the loader (which rejects empty
        # `until_event` lists with a less-clear error).
        import pytest

        from agent_shield import Lifetime

        with pytest.raises(ValueError, match="at least one event id"):
            Lifetime.until_event()

    def test_map_form(self):
        from agent_shield import Lifetime

        v = Lifetime.map(allow="per_call", deny="per_session").to_native()
        assert v == {"allow": "per_call", "deny": "per_session"}


# ═══════════════════════════════════════════════════════════════════════════
# DATACLASS RESOLVER ENVELOPE
# ═══════════════════════════════════════════════════════════════════════════


class TestEnvelopes:
    def test_resolver_response_to_dict(self):
        from agent_shield.hooks import ResolverResponse

        r = ResolverResponse(decision="allow", value=42, reason="ok")
        d = r.to_dict()
        assert d["decision"] == "allow"
        assert d["value"] == 42
        assert d["reason"] == "ok"

    def test_resolver_response_set_variables(self):
        from agent_shield.hooks import ResolverResponse

        r = ResolverResponse(
            decision="allow", set_variables={"x": 1, "y": "two"}
        )
        d = r.to_dict()
        assert d["set_variables"] == {"x": 1, "y": "two"}

    def test_resolver_request_from_dict(self):
        from agent_shield.hooks import ResolverRequest

        req = ResolverRequest.from_dict(
            {
                "request_id": "abc",
                "variable": "v",
                "context": {"a": 1},
            }
        )
        assert req.request_id == "abc"
        assert req.variable == "v"
        assert req.context == {"a": 1}
