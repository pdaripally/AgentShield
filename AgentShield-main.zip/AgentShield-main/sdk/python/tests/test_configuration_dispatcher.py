"""Tests for :func:`agent_shield.make_configuration_caller`.

Covers exact-match routing for per-configuration LLM callers.
"""
from __future__ import annotations

import pytest

from agent_shield import make_configuration_caller


def _recording_caller(label: str):
    calls: list[str] = []

    def caller(prompt: str) -> str:
        calls.append(prompt)
        return f"{label}:{prompt}"

    caller.calls = calls  # type: ignore[attr-defined]
    return caller


class TestExactMatchDispatch:
    def test_exact_match_routes_to_registered_caller(self):
        input_caller = _recording_caller("input")
        tool_caller = _recording_caller("tool")

        dispatcher = make_configuration_caller(
            {"input_llm": input_caller, "tool_execution_llm": tool_caller},
        )

        assert dispatcher("input_llm", "hello") == "input:hello"
        assert dispatcher("tool_execution_llm", "calc") == "tool:calc"
        assert input_caller.calls == ["hello"]  # type: ignore[attr-defined]
        assert tool_caller.calls == ["calc"]  # type: ignore[attr-defined]

    def test_substring_match_does_NOT_route(self):
        """Substring hints (``"my_input_check"`` containing ``"input"``)
        must NOT route to the ``"input_llm"`` caller — exact match only.
        """
        input_caller = _recording_caller("input")
        fallback = _recording_caller("default")
        dispatcher = make_configuration_caller(
            {"input_llm": input_caller}, default=fallback,
        )

        # Substring would have matched in the deprecated implementation.
        result = dispatcher("my_input_check", "hello")
        assert result == "default:hello"
        assert input_caller.calls == []  # type: ignore[attr-defined]
        assert fallback.calls == ["hello"]  # type: ignore[attr-defined]


class TestDefaultFallback:
    def test_default_used_for_unknown_id(self):
        fallback = _recording_caller("default")
        dispatcher = make_configuration_caller(
            {}, default=fallback,
        )
        assert dispatcher("never_registered", "x") == "default:x"

    def test_default_used_when_configuration_id_is_none(self):
        fallback = _recording_caller("default")
        dispatcher = make_configuration_caller(
            {"input_llm": _recording_caller("input")}, default=fallback,
        )
        assert dispatcher(None, "x") == "default:x"

    def test_no_default_unknown_id_raises(self):
        dispatcher = make_configuration_caller(
            {"input_llm": _recording_caller("input")},
        )
        with pytest.raises(RuntimeError) as info:
            dispatcher("unknown_id", "x")
        msg = str(info.value)
        assert "no LLM caller registered" in msg
        assert "'input_llm'" in msg
        assert "'unknown_id'" in msg
        assert "no default provided" in msg

    def test_error_lists_known_ids(self):
        dispatcher = make_configuration_caller(
            {"a": _recording_caller("a"), "b": _recording_caller("b")},
        )
        with pytest.raises(RuntimeError) as info:
            dispatcher("c", "x")
        assert "'a'" in str(info.value)
        assert "'b'" in str(info.value)

    def test_error_renders_null_for_none_id(self):
        """Cross-SDK parity: a missing ``configuration_id`` must render as
        the literal ``null`` in the error message, not Python's native
        ``None``. Rust/.NET/Node all use ``null``; Python matches them
        here to keep the helper's error shape consistent across SDKs.
        """
        dispatcher = make_configuration_caller({})
        with pytest.raises(RuntimeError) as info:
            dispatcher(None, "x")
        assert "configuration_id=null" in str(info.value)


class TestDispatcherIsolation:
    def test_callers_mapping_is_copied(self):
        """Mutating the source mapping must not affect an already-built
        dispatcher."""
        caller = _recording_caller("a")
        callers = {"a": caller}
        dispatcher = make_configuration_caller(callers)
        callers.clear()
        # Dispatcher still routes — internal copy was taken.
        assert dispatcher("a", "x") == "a:x"

