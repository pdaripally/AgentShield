"""Consume-on-build tests for :class:`ShieldBuilder`.

Verifies that after a successful ``ShieldBuilder.build()`` call, the
builder is marked consumed and any subsequent method invocation
(``build()``, ``with_*()``) raises a structured :class:`RuntimeError`
with a clear, actionable message that names the type. Mirrors the Rust
SDK's compile-time consume semantics at runtime.
"""
from __future__ import annotations

from pathlib import Path

import pytest

# Import an adapter so ShieldBuilder gets the `with_langchain` method
# installed (composition pattern requires a bundle to be attached
# before `.build()`).
import agent_shield.adapters.langchain  # noqa: F401
from agent_shield import Shield, ShieldBuilder

REPO_ROOT = Path(__file__).resolve().parent.parent.parent.parent
MINIMAL = str(REPO_ROOT / "tests" / "fixtures" / "smoke" / "minimal.guardrails.yaml")

EXPECTED_MESSAGE = (
    "ShieldBuilder.build() can only be called once. "
    "Call Shield.from_yaml(...) again to create a new builder."
)


def _fresh_builder() -> ShieldBuilder:
    """Return a freshly-bound ShieldBuilder ready to be built."""
    # `auto_bind=False` so this test file does not depend on which other
    # adapters sibling tests imported into the bundle registry.
    return Shield.from_yaml(MINIMAL, auto_bind=False).with_langchain()


class TestConsumeOnBuild:
    def test_first_build_returns_working_shield(self) -> None:
        shield = _fresh_builder().build()
        assert isinstance(shield, Shield)

    def test_second_build_raises_runtime_error(self) -> None:
        builder = _fresh_builder()
        builder.build()
        with pytest.raises(RuntimeError) as excinfo:
            builder.build()
        assert str(excinfo.value) == EXPECTED_MESSAGE

    def test_with_mode_after_build_raises(self) -> None:
        builder = _fresh_builder()
        builder.build()
        with pytest.raises(RuntimeError) as excinfo:
            builder.with_mode("monitor")
        assert str(excinfo.value) == EXPECTED_MESSAGE

    def test_with_on_block_after_build_raises(self) -> None:
        builder = _fresh_builder()
        builder.build()
        with pytest.raises(RuntimeError) as excinfo:
            builder.with_on_block("throw")
        assert str(excinfo.value) == EXPECTED_MESSAGE

    def test_with_extension_after_build_raises(self) -> None:
        builder = _fresh_builder()
        builder.build()
        with pytest.raises(RuntimeError) as excinfo:
            builder.with_extension(lambda _b: None)
        assert str(excinfo.value) == EXPECTED_MESSAGE

    def test_bind_to_bundle_after_build_raises(self) -> None:
        """Adapter-installed ``with_<framework>()`` methods route through
        ``_bind_to_bundle`` so they too must reject post-build calls."""
        builder = _fresh_builder()
        builder.build()
        with pytest.raises(RuntimeError) as excinfo:
            # Re-binding via the public adapter method exercises
            # _bind_to_bundle, which is also gated by the consume flag.
            builder.with_langchain()
        assert str(excinfo.value) == EXPECTED_MESSAGE

    def test_fresh_from_yaml_produces_independent_builder(self) -> None:
        """A fresh ``Shield.from_yaml`` call always yields a usable builder.

        The consume flag is per-instance — the customer-facing escape hatch
        for "I built once and need a second Shield" is to call
        ``Shield.from_yaml(...)`` again.
        """
        first = _fresh_builder().build()
        assert isinstance(first, Shield)

        second = _fresh_builder().with_mode("monitor").build()
        assert isinstance(second, Shield)

    def test_error_message_names_the_type(self) -> None:
        builder = _fresh_builder()
        builder.build()
        with pytest.raises(RuntimeError) as excinfo:
            builder.build()
        msg = str(excinfo.value)
        assert "ShieldBuilder.build()" in msg
        assert "Shield.from_yaml(...)" in msg
