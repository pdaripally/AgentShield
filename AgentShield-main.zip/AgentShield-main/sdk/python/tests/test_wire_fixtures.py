"""Cross-language wire-shape golden fixture conformance.

Loads every fixture from ``tests/fixtures/wire/*/*.json`` and asserts:

1. The fixture itself validates against its schema in
   ``spec/schemas/wire/<shape>.schema.json``.
2. Re-serialising the parsed dict to JSON validates against the same
   schema (round-trip stability).
3. The shape is canonical — no SDK-specific casing leaked into the
   golden fixtures.

Phase 0 of the SDK minimisation plan: this is the cross-language drift
detection net. Equivalent test files exist in the Node SDK
(``__tests__/wire_fixtures.test.ts``) and the .NET SDK
(``WireFixtureTests.cs``); all three run against the same fixtures.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Iterator

import pytest


REPO_ROOT = Path(__file__).resolve().parent.parent.parent.parent
SCHEMAS_DIR = REPO_ROOT / "spec" / "schemas" / "wire"
FIXTURES_DIR = REPO_ROOT / "tests" / "fixtures" / "wire"


def _shape_dirs() -> list[Path]:
    return sorted(p for p in FIXTURES_DIR.iterdir() if p.is_dir())


def _fixture_paths() -> Iterator[tuple[str, Path, Path]]:
    for shape_dir in _shape_dirs():
        schema_path = SCHEMAS_DIR / f"{shape_dir.name}.schema.json"
        if not schema_path.exists():
            raise FileNotFoundError(
                f"No schema for fixture shape {shape_dir.name!r}: {schema_path}"
            )
        for fixture in sorted(shape_dir.glob("*.json")):
            yield shape_dir.name, fixture, schema_path


_FIXTURE_IDS = [
    f"{shape}/{fixture.stem}"
    for shape, fixture, _ in _fixture_paths()
]
_FIXTURE_PARAMS = list(_fixture_paths())


@pytest.mark.parametrize(
    "shape,fixture_path,schema_path",
    _FIXTURE_PARAMS,
    ids=_FIXTURE_IDS,
)
class TestWireFixtures:
    """Every fixture validates against its schema and round-trips."""

    def test_fixture_is_valid_json(self, shape, fixture_path, schema_path):
        with open(fixture_path) as f:
            data = json.load(f)
        # Top-level shape is always an object for our wire types.
        assert isinstance(data, dict), (
            f"{fixture_path} is not a JSON object"
        )

    def test_fixture_validates_against_schema(
        self, shape, fixture_path, schema_path,
    ):
        import jsonschema

        with open(schema_path) as f:
            schema = json.load(f)
        with open(fixture_path) as f:
            data = json.load(f)
        jsonschema.validate(data, schema)

    def test_fixture_round_trips(self, shape, fixture_path, schema_path):
        """Serialise → deserialise → re-validate. Stability check."""
        import jsonschema

        with open(schema_path) as f:
            schema = json.load(f)
        with open(fixture_path) as f:
            data = json.load(f)

        # Round-trip through JSON (serialise + parse).
        serialised = json.dumps(data, sort_keys=True)
        reparsed = json.loads(serialised)
        jsonschema.validate(reparsed, schema)

    def test_fixture_uses_snake_case(
        self, shape, fixture_path, schema_path,
    ):
        """The canonical wire format is snake_case. Catches accidental
        camelCase / PascalCase leakage from SDKs into golden fixtures."""
        with open(fixture_path) as f:
            data = json.load(f)

        for key in _all_keys(data):
            # Snake_case keys: lowercase letters, digits, underscores.
            # Reject any uppercase character.
            # Allow leading-letter only (no all-digit keys).
            assert key.islower() or "_" in key or key.isalpha(), (
                f"Key {key!r} in {fixture_path} is not snake_case"
            )
            assert not any(c.isupper() for c in key), (
                f"Key {key!r} in {fixture_path} has uppercase characters "
                f"(canonical wire format is snake_case)"
            )


def _all_keys(obj) -> Iterator[str]:
    """Recursively yield every dict key in a JSON document."""
    if isinstance(obj, dict):
        for key, value in obj.items():
            yield key
            yield from _all_keys(value)
    elif isinstance(obj, list):
        for item in obj:
            yield from _all_keys(item)


class TestFixtureCoverage:
    """Every wire shape has at least one fixture."""

    def test_every_schema_has_fixtures(self):
        for schema_path in sorted(SCHEMAS_DIR.glob("*.schema.json")):
            shape = schema_path.stem.replace(".schema", "")
            shape_dir = FIXTURES_DIR / shape
            assert shape_dir.is_dir(), (
                f"Schema {schema_path.name} has no fixtures directory "
                f"under {FIXTURES_DIR}"
            )
            fixtures = list(shape_dir.glob("*.json"))
            assert fixtures, (
                f"Schema {schema_path.name} has no fixtures in {shape_dir}"
            )

    def test_no_orphan_fixture_dirs(self):
        for shape_dir in _shape_dirs():
            schema_path = SCHEMAS_DIR / f"{shape_dir.name}.schema.json"
            assert schema_path.exists(), (
                f"Fixture directory {shape_dir.name} has no matching "
                f"schema at {schema_path}"
            )
