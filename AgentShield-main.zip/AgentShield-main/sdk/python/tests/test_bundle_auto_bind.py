"""Tests for ambient :class:`FrameworkBundle` auto-binding.

Covers the four documented scenarios:

* exactly one adapter imported → auto-bind succeeds,
* zero adapters imported → auto-bind is a no-op, ``build()`` raises
  the existing "no bundle bound" error path at access time,
* two adapters imported → ``Shield.from_yaml(...)`` raises
  :class:`agent_shield.AmbientBundleAmbiguityError` listing both
  adapter names,
* after ambiguity, ``Shield.from_yaml(..., auto_bind=False)
  .with_<framework>()`` explicitly resolves the ambiguity and
  ``build()`` succeeds.
"""
from __future__ import annotations

import importlib
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent.parent.parent
MINIMAL = str(REPO_ROOT / "tests" / "fixtures" / "smoke" / "minimal.guardrails.yaml")


@pytest.fixture
def clean_registry():
    """Snapshot and reset the bundle registry around each test so the
    parametrised state stays under test control."""
    from agent_shield.adapters import _bundle_registry

    snapshot = dict(_bundle_registry._REGISTERED)
    _bundle_registry.reset()
    try:
        yield _bundle_registry
    finally:
        _bundle_registry._REGISTERED.clear()
        _bundle_registry._REGISTERED.update(snapshot)


def _import_adapter(name: str):
    """Import an adapter module and re-register its bundle.

    The module-level ``_registry.register(_BUNDLE)`` runs only on the
    *first* import of an adapter module within a process. Re-importing
    after a registry reset is a no-op against the bundle dict, so this
    helper explicitly re-registers the bundle so each test sees the
    expected registration state.
    """
    from agent_shield.adapters import _bundle_registry

    module = importlib.import_module(f"agent_shield.adapters.{name}")
    _bundle_registry.register(module._BUNDLE)
    return module


class TestAutoBindOneAdapter:
    def test_single_import_auto_binds(self, clean_registry):
        from agent_shield import Shield

        _import_adapter("openai_agents")
        builder = Shield.from_yaml(MINIMAL)
        assert builder._bundle is not None
        assert builder._bundle.name == "openai_agents"
        shield = builder.build()
        assert shield.capabilities.framework == "openai_agents"


class TestAutoBindZeroAdapters:
    def test_no_adapter_imported_builder_constructs(self, clean_registry):
        """No adapter imported: builder constructs (auto-bind is a no-op),
        ``build()`` itself succeeds (null-bundle path is allowed), and
        the bundle-requiring accessors raise at call time."""
        from agent_shield import Shield

        # No adapter imported → registry empty → auto_bundle returns None.
        assert clean_registry.active_bundle() is None
        builder = Shield.from_yaml(MINIMAL)
        assert builder._bundle is None
        # `build()` succeeds (the null-bundle path is intentional —
        # framework-agnostic methods don't need a bundle); the existing
        # "no bundle bound" error fires only when a bundle-requiring
        # method is invoked.
        shield = builder.build()
        with pytest.raises(RuntimeError, match="with_<framework>"):
            _ = shield.capabilities


class TestAutoBindAmbiguous:
    def test_two_imports_raise_ambiguity_error(self, clean_registry):
        from agent_shield import AmbientBundleAmbiguityError, Shield

        _import_adapter("openai_agents")
        _import_adapter("anthropic_agents")
        with pytest.raises(AmbientBundleAmbiguityError) as info:
            Shield.from_yaml(MINIMAL)

        # Error message must list every imported adapter name and
        # surface the canonical disambiguation recipe.
        assert info.value.registered == ["anthropic_agents", "openai_agents"]
        msg = str(info.value)
        assert "'openai_agents'" in msg
        assert "'anthropic_agents'" in msg
        assert "auto_bind=False" in msg

    def test_explicit_with_framework_resolves_after_ambiguity(
        self, clean_registry,
    ):
        """With ``auto_bind=False`` the ambient lookup is bypassed; the
        explicit ``.with_<framework>()`` call pins a specific bundle
        and ``build()`` succeeds."""
        from agent_shield import Shield

        _import_adapter("openai_agents")
        _import_adapter("anthropic_agents")

        shield = (
            Shield.from_yaml(MINIMAL, auto_bind=False)
            .with_anthropic_agents()
            .build()
        )
        assert shield.capabilities.framework == "anthropic_agents"


class TestAmbientBundleAmbiguityErrorShape:
    def test_error_carries_sorted_registered_names(self, clean_registry):
        from agent_shield import AmbientBundleAmbiguityError

        _import_adapter("langchain")
        _import_adapter("openai_agents")
        _import_adapter("anthropic_agents")
        with pytest.raises(AmbientBundleAmbiguityError) as info:
            clean_registry.active_bundle()
        assert info.value.registered == [
            "anthropic_agents",
            "langchain",
            "openai_agents",
        ]
