"""Cross-SDK parity tests for spec §16.0 invocation-bound verdict semantics.

The Rust core already exercises every §16.0 corner case in
``sdk/rust/agent_shield_core/tests/runtime.rs`` (see ``stage4_*``
tests). These tests verify that the **Python SDK surface** preserves
the same semantics — i.e. ``invocation_hash`` /
``post_validation_invocation_hash`` cross the PyO3 boundary correctly
and the ``tool_call_id`` kwarg on ``validate_tool_call`` /
``validate_tool_output`` actually drives the §16.0 binding cache.

Mirror tests live in:

* ``sdk/node/__tests__/section_16_binding.test.mjs``
* ``sdk/dotnet/tests/AgentShield.Tests/Section16BindingTests.cs``

Each suite covers the same four scenarios so all four SDKs are
verified to honor the spec's invocation-binding invariants.
"""
from __future__ import annotations

from agent_shield import RuntimeBuilder


_FIXTURE_YAML = """
metadata:
  name: "section-16-binding-parity"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test §16.0 invocation binding"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "send_email"
      description: "Send an email."
      permission: "execute"
post_tool_validation:
  guard_policies:
    - name: "result_recipient_must_match_call_recipient"
      evaluate_when:
        - expression: '@tool.params.recipient == @result.matched_recipient'
          reason: "§16.0: Stage 4 bound to the wrong invocation."
"""


def _build_session():
    rt = RuntimeBuilder.from_yaml_strings([_FIXTURE_YAML]).build()
    sess = rt.new_session()
    sess.begin_turn()
    return sess


# ─────────────────────────────────────────────────────────────────────
# Scenario 1: happy path — Stage 3 then Stage 4 with matching id binds.
# Both verdicts MUST carry non-null invocation_hash &
# post_validation_invocation_hash.
# ─────────────────────────────────────────────────────────────────────


def test_section_16_stage3_then_stage4_with_id_binds():
    sess = _build_session()
    call = sess.validate_tool_call(
        "send_email",
        {"recipient": "alice@example.com", "body": "hi"},
        tool_call_id="call_alice_1",
    )
    assert call.verdict.allowed, "Stage 3 should pass — no Stage-3 policies"

    out = sess.validate_tool_output(
        "send_email",
        {"matched_recipient": "alice@example.com", "sent": True},
        tool_call_id="call_alice_1",
    )
    assert out.verdict.allowed, (
        f"§16.0: Stage 4 must bind to the recorded Stage-3 invocation; "
        f"verdict was: {out.verdict!r}"
    )
    assert out.verdict.invocation_hash, (
        "§16.0: Stage 4 must surface invocation_hash when bound to a "
        "Stage-3-admitted invocation"
    )
    assert out.verdict.post_validation_invocation_hash, (
        "§16.0: Stage 4 must surface post_validation_invocation_hash"
    )


# ─────────────────────────────────────────────────────────────────────
# Scenario 2: parallel same-name calls with distinct ids each bind to
# their own Stage-3 invocation, even when Stage 4 arrives in opposite
# order. The two invocation_hashes MUST differ.
# ─────────────────────────────────────────────────────────────────────


def test_section_16_parallel_same_name_distinct_ids_bind_independently():
    sess = _build_session()

    call_a = sess.validate_tool_call(
        "send_email",
        {"recipient": "alice@example.com", "body": "hi alice"},
        tool_call_id="call_alice_1",
    )
    assert call_a.verdict.allowed

    call_b = sess.validate_tool_call(
        "send_email",
        {"recipient": "bob@example.com", "body": "hi bob"},
        tool_call_id="call_bob_2",
    )
    assert call_b.verdict.allowed

    # Stage 4 in OPPOSITE order: bob first, alice second.
    out_b = sess.validate_tool_output(
        "send_email",
        {"matched_recipient": "bob@example.com", "sent": True},
        tool_call_id="call_bob_2",
    )
    assert out_b.verdict.allowed, (
        f"§16.0: bob Stage 4 must bind to call_bob_2 invocation; verdict was: {out_b.verdict!r}"
    )

    out_a = sess.validate_tool_output(
        "send_email",
        {"matched_recipient": "alice@example.com", "sent": True},
        tool_call_id="call_alice_1",
    )
    assert out_a.verdict.allowed, (
        f"§16.0: alice Stage 4 must bind to call_alice_1 invocation; verdict was: {out_a.verdict!r}"
    )

    hash_a = out_a.verdict.invocation_hash
    hash_b = out_b.verdict.invocation_hash
    assert hash_a and hash_b
    assert hash_a != hash_b, (
        "§16.0: distinct same-name invocations must hash to distinct "
        f"digests (got alice={hash_a!r}, bob={hash_b!r})"
    )


# ─────────────────────────────────────────────────────────────────────
# Scenario 3: Stage 4 with a tool_call_id that never had a Stage 3
# entry MUST fail closed. The deny verdict MUST NOT advertise an
# invocation_hash.
# ─────────────────────────────────────────────────────────────────────


def test_section_16_stage4_with_unknown_id_fails_closed():
    sess = _build_session()

    out = sess.validate_tool_output(
        "send_email",
        {"matched_recipient": "alice@example.com", "sent": True},
        tool_call_id="never_validated_call_id",
    )
    assert not out.verdict.allowed, (
        f"§16.0: Stage 4 with unknown tool_call_id must fail closed; verdict was: {out.verdict!r}"
    )
    assert out.verdict.policy == "<binding>", (
        f"§16.0: deny verdict policy should be '<binding>'; got {out.verdict.policy!r}"
    )
    assert out.verdict.invocation_hash is None, (
        "§16.0: fail-closed binding verdict must not advertise an invocation_hash"
    )


# ─────────────────────────────────────────────────────────────────────
# Scenario 4: Stage 4 with a DIFFERENT explicit id than the Stage 3
# admit MUST fail closed — there is no longer any synthetic fallback
# path when the binding key does not match.
# ─────────────────────────────────────────────────────────────────────


def test_section_16_stage4_with_mismatched_explicit_id_fails_closed():
    sess = _build_session()

    sess.validate_tool_call(
        "send_email",
        {"recipient": "alice@example.com", "body": "hi"},
        tool_call_id="call_alice_1",
    )
    out = sess.validate_tool_output(
        "send_email",
        {"matched_recipient": "alice@example.com", "sent": True},
        tool_call_id="call_alice_2",
    )
    assert not out.verdict.allowed, (
        f"§16.0: Stage 4 with mismatched tool_call_id must fail closed; verdict was: {out.verdict!r}"
    )
    assert out.verdict.policy == "<binding>"
    assert out.verdict.invocation_hash is None
    assert out.verdict.post_validation_invocation_hash is None
