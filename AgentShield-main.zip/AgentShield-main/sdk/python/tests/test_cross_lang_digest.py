"""Cross-language digest equivalence conformance.

For every guardrails YAML fixture, every Agent Shield SDK MUST produce
the same SHA-256 digest. This is the foundation contract that makes
``CompiledPolicy`` content-keyed cache keys work across Python / Node /
.NET (and Rust core) for SaaS / multi-tenant deployments.

The test loads the same fixture in Python, in Node (via subprocess),
and in Rust (via the test binary already built), then asserts the
three digests are byte-equal.

Skipped automatically if Node / Rust toolchains aren't available in
the env (so the test stays portable).
"""
from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent.parent.parent
NODE_DIR = REPO_ROOT / "sdk" / "node"
RUST_DIR = REPO_ROOT / "sdk" / "rust" / "agent_shield_core"
DOTNET = Path.home() / ".dotnet" / "dotnet"

FIXTURE = REPO_ROOT / "tests" / "fixtures" / "smoke" / "minimal.guardrails.yaml"


def _python_digest(path: Path) -> str:
    from agent_shield import GuardrailsConfig

    return GuardrailsConfig.load(str(path)).compile().digest


def _node_digest(path: Path) -> str:
    if shutil.which("node") is None:
        pytest.skip("node not installed")
    if not (NODE_DIR / "agent-shield.linux-x64-gnu.node").exists():
        pytest.skip("Node native binding not built — run `npm run build`")
    if not (NODE_DIR / "dist" / "config.js").exists():
        pytest.skip(
            "Node TS wrapper not built — run `npm run build:wrapper` in sdk/node"
        )
    code = (
        f"const {{GuardrailsConfig}} = require('./dist/config.js');"
        f"console.log(GuardrailsConfig.load({str(path)!r}).compile().digest);"
    )
    out = subprocess.run(
        ["node", "-e", code],
        cwd=NODE_DIR,
        capture_output=True,
        text=True,
        check=True,
    )
    return out.stdout.strip()


def _rust_digest(path: Path) -> str:
    if shutil.which("cargo") is None:
        pytest.skip("cargo not installed")
    # Pure-Python ctypes call against the prebuilt cdylib — avoids
    # cargo invocation overhead per test.
    so_path = RUST_DIR / "target" / "release" / "libagent_shield_core.so"
    if not so_path.exists():
        pytest.skip(
            "Rust core release cdylib not built — run "
            "`cargo build --release --lib`"
        )
    import ctypes

    lib = ctypes.CDLL(str(so_path))
    lib.shield_config_load.restype = ctypes.c_void_p
    lib.shield_config_load.argtypes = [
        ctypes.c_char_p,
        ctypes.POINTER(ctypes.c_char_p),
    ]
    lib.shield_config_compile.restype = ctypes.c_void_p
    lib.shield_config_compile.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_char_p),
    ]
    lib.shield_compiled_digest.restype = ctypes.c_char_p
    lib.shield_compiled_digest.argtypes = [ctypes.c_void_p]
    lib.shield_config_free.argtypes = [ctypes.c_void_p]
    lib.shield_compiled_free.argtypes = [ctypes.c_void_p]

    err = ctypes.c_char_p()
    cfg = lib.shield_config_load(str(path).encode(), ctypes.byref(err))
    assert cfg, f"shield_config_load failed: {err.value}"
    try:
        compiled = lib.shield_config_compile(cfg, ctypes.byref(err))
        assert compiled, f"shield_config_compile failed: {err.value}"
        try:
            digest = lib.shield_compiled_digest(compiled)
            return digest.decode()
        finally:
            lib.shield_compiled_free(compiled)
    finally:
        lib.shield_config_free(cfg)


@pytest.fixture(scope="module")
def python_digest() -> str:
    return _python_digest(FIXTURE)


class TestCrossLanguageDigest:
    """Same fixture → same digest in every SDK."""

    def test_python_node_digest_match(self, python_digest):
        node = _node_digest(FIXTURE)
        assert python_digest == node, (
            f"digest drift: python={python_digest!r} node={node!r}"
        )

    def test_python_rust_digest_match(self, python_digest):
        rust = _rust_digest(FIXTURE)
        assert python_digest == rust, (
            f"digest drift: python={python_digest!r} rust={rust!r}"
        )

    def test_digest_is_deterministic_across_invocations(self, python_digest):
        # Python wrapping should not introduce any ordering / state
        # that affects the digest across repeat calls.
        for _ in range(3):
            assert _python_digest(FIXTURE) == python_digest


class TestDigestStabilityProperties:
    """Properties the digest contract MUST hold."""

    def test_digest_is_64_char_hex(self, python_digest):
        import re
        assert re.fullmatch(r"[0-9a-f]{64}", python_digest), (
            f"digest is not lowercase 64-char hex: {python_digest!r}"
        )

    def test_digest_changes_with_content(self):
        from agent_shield import GuardrailsConfig

        a = GuardrailsConfig.load(str(FIXTURE)).compile().digest
        # Adding an overlay should change the digest.
        b = (
            GuardrailsConfig.load(str(FIXTURE))
            .with_overrides({
                "metadata": {"description": "different"},
            })
            .compile()
            .digest
        )
        assert a != b
