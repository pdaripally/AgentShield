"""LLM-caller cfg-plumbing tests for the CrewAI adapter.

Mirrors ``test_oai_agents_llm_caller_model.py`` /
``test_anthropic_agents_llm_caller_model.py`` /
``test_semantic_kernel.py``: asserts that ``.guardrails.yaml``
``configurations[]`` entries actually drive which model / kwargs the
Stage 1/3/5 LLM judge uses for each of the five LLM shapes the CrewAI
adapter accepts.
"""
from __future__ import annotations

import logging
import sys
from typing import Any, List, Optional

import pytest

from agent_shield import RuntimeBuilder
from agent_shield.adapters.crewai import (
    _LlmCallerFactory,
    _bind_langchain_overrides,
    _build_crewai_llm_override,
    _filter_litellm_kwargs,
    make_llm_caller,
)


# ───────────────────────────────────────────────────────────────────────
# Fixture YAML — two distinct LLM configurations
# ───────────────────────────────────────────────────────────────────────


_MULTI_CONFIG_YAML = """
metadata:
  name: crewai-llm-caller-model-fixture
  version: 0.1.0
  agent_shield_version: "2.0"
objective:
  goal: ["exercise configurations[] routing"]
  forbidden: ["bypass"]
configurations:
  - id: stage1-judge
    type: llm
    provider: openai.chat
    model: gpt-4o
    max_tokens: 256
  - id: stage3-judge
    type: llm
    provider: openai.chat
    model: gpt-4o-mini
input_validation:
  guard_policies:
    - name: trivial_input_guard
      evaluate_when:
        - patterns: ["jailbreak"]
          reason: "jailbreak attempt"
      action: "block"
"""


def _build_runtime(yaml_str: str):
    import os
    import tempfile

    fd, path = tempfile.mkstemp(suffix=".yaml")
    try:
        with os.fdopen(fd, "w") as fh:
            fh.write(yaml_str)
        return RuntimeBuilder.from_yaml(path).build()
    finally:
        os.unlink(path)


# ───────────────────────────────────────────────────────────────────────
# Litellm-string path (full cfg forwarding)
# ───────────────────────────────────────────────────────────────────────


class _RecordingCompletion:
    """Stand-in for ``litellm.completion`` that records every call."""

    def __init__(self) -> None:
        self.calls: List[dict] = []

    def __call__(self, **kwargs: Any) -> Any:
        self.calls.append(kwargs)

        class _Msg:
            content = "ok"

        class _Choice:
            message = _Msg()

        class _Result:
            choices = [_Choice()]

        return _Result()


@pytest.fixture
def patched_litellm(monkeypatch: pytest.MonkeyPatch):
    """Patch ``litellm.completion`` and freeze the supported-params
    list to a stable OpenAI-like set so the test isn't entangled with
    litellm's per-version provider data.
    """
    pytest.importorskip("litellm")
    import litellm

    rec = _RecordingCompletion()
    monkeypatch.setattr(litellm, "completion", rec)

    supported = {
        "max_tokens", "temperature", "top_p",
        "frequency_penalty", "presence_penalty", "stop", "api_base",
    }
    monkeypatch.setattr(
        litellm, "get_supported_openai_params",
        lambda **_kwargs: list(supported),
    )
    return rec


def test_litellm_string_path_plumbs_full_kwarg_set(
    patched_litellm: _RecordingCompletion,
) -> None:
    """The litellm string path must forward every cfg kwarg the
    adapter advertises (model + max_tokens + temperature + top_p +
    frequency_penalty + presence_penalty + stop + api_base) — and only
    those, omitting ``None`` values."""
    cfg = {
        "id": "stage1-judge",
        "type": "llm",
        "model": "gpt-4o",
        "max_tokens": 256,
        "temperature": 0.4,
        "top_p": 0.9,
        "frequency_penalty": 0.1,
        "presence_penalty": 0.2,
        "stop": ["END"],
        "api_base": "https://example.invalid/v1",
    }
    caller = make_llm_caller(
        "gpt-3.5-turbo",
        configuration_resolver=lambda _cid: cfg,
    )

    out = caller("stage1-judge", "hello")
    assert out == "ok"

    assert len(patched_litellm.calls) == 1
    call = patched_litellm.calls[0]
    assert call["model"] == "gpt-4o"
    assert call["max_tokens"] == 256
    assert call["temperature"] == 0.4
    assert call["top_p"] == 0.9
    assert call["frequency_penalty"] == 0.1
    assert call["presence_penalty"] == 0.2
    assert call["stop"] == ["END"]
    assert call["api_base"] == "https://example.invalid/v1"
    assert call["messages"] == [{"role": "user", "content": "hello"}]


def test_litellm_string_path_uses_yaml_model_per_configuration_id(
    patched_litellm: _RecordingCompletion,
) -> None:
    """Two different configuration_ids => two different models on the
    recorded ``litellm.completion`` calls."""
    rt = _build_runtime(_MULTI_CONFIG_YAML)
    caller = make_llm_caller(
        "gpt-3.5-turbo",
        configuration_resolver=rt.llm_configuration,
    )

    caller("stage1-judge", "is the input safe?")
    caller("stage3-judge", "is the tool call safe?")

    calls = patched_litellm.calls
    assert len(calls) == 2
    assert calls[0]["model"] == "gpt-4o"
    assert calls[0]["max_tokens"] == 256
    assert calls[1]["model"] == "gpt-4o-mini"
    # No ``max_tokens`` declared for stage3-judge => kwarg omitted.
    assert "max_tokens" not in calls[1]


def test_litellm_string_path_omits_none_kwargs(
    patched_litellm: _RecordingCompletion,
) -> None:
    """``None`` values in cfg must not appear as kwargs."""
    cfg = {
        "id": "stage1-judge",
        "type": "llm",
        "model": "gpt-4o",
        "max_tokens": None,
        "temperature": None,
        "top_p": 0.9,
    }
    caller = make_llm_caller(
        "gpt-4o", configuration_resolver=lambda _cid: cfg,
    )
    caller("stage1-judge", "prompt")

    call = patched_litellm.calls[0]
    assert "max_tokens" not in call
    assert "temperature" not in call
    assert call["top_p"] == 0.9


def test_litellm_string_path_filters_unsupported_kwargs(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``litellm.get_supported_openai_params`` returning a restricted
    list must filter cfg fields the provider doesn't honour."""
    pytest.importorskip("litellm")
    import litellm

    rec = _RecordingCompletion()
    monkeypatch.setattr(litellm, "completion", rec)
    monkeypatch.setattr(
        litellm, "get_supported_openai_params",
        # Minimal Ollama-style support list.
        lambda **_kw: ["max_tokens", "temperature", "stop"],
    )

    cfg = {
        "id": "stage1-judge",
        "type": "llm",
        "model": "ollama/llama2",
        "max_tokens": 64,
        "temperature": 0.1,
        "top_p": 0.9,
        "frequency_penalty": 0.1,
        "presence_penalty": 0.2,
    }
    caller = make_llm_caller(
        "ollama/llama2", configuration_resolver=lambda _cid: cfg,
    )
    caller("stage1-judge", "prompt")

    call = rec.calls[0]
    # Supported kwargs survive.
    assert call["max_tokens"] == 64
    assert call["temperature"] == 0.1
    # Unsupported kwargs filtered out.
    assert "top_p" not in call
    assert "frequency_penalty" not in call
    assert "presence_penalty" not in call


def test_litellm_string_path_resolver_lookup_failure_falls_back(
    patched_litellm: _RecordingCompletion, caplog: pytest.LogCaptureFixture,
) -> None:
    """A resolver that raises => caller still invokes litellm with the
    customer-supplied model string and no overrides."""
    def broken_resolver(_cid: Optional[str]) -> Optional[dict]:
        raise RuntimeError("boom")

    caller = make_llm_caller(
        "gpt-3.5-turbo", configuration_resolver=broken_resolver,
    )
    with caplog.at_level(logging.DEBUG, logger="agent_shield.crewai"):
        out = caller("stage1-judge", "prompt")

    assert out == "ok"
    call = patched_litellm.calls[0]
    assert call["model"] == "gpt-3.5-turbo"
    # No cfg overrides — only model + messages.
    assert set(call.keys()) == {"model", "messages"}


def test_litellm_string_path_fallback_debug_log_fires(
    patched_litellm: _RecordingCompletion, caplog: pytest.LogCaptureFixture,
) -> None:
    """Non-empty configuration_id + resolver returns None => DEBUG log."""
    caller = make_llm_caller(
        "gpt-3.5-turbo",
        configuration_resolver=lambda _cid: None,
    )
    with caplog.at_level(logging.DEBUG, logger="agent_shield.crewai"):
        caller("not-in-yaml", "prompt")

    fallback_logs = [
        r for r in caplog.records
        if "no `configurations[]` entry matched" in r.getMessage()
    ]
    assert fallback_logs, "fallback path must emit a DEBUG log"
    assert "not-in-yaml" in fallback_logs[0].getMessage()


def test_litellm_string_path_no_routing_requested_no_debug_log(
    patched_litellm: _RecordingCompletion, caplog: pytest.LogCaptureFixture,
) -> None:
    """``configuration_id`` is None / empty => *no* DEBUG log (it's a
    legitimate no-routing call, not an SRE signal). Mirrors the
    OAI / Anthropic / SK fixtures."""
    caller = make_llm_caller(
        "gpt-3.5-turbo",
        configuration_resolver=lambda _cid: None,
    )
    with caplog.at_level(logging.DEBUG, logger="agent_shield.crewai"):
        caller(None, "prompt")
        caller("", "prompt")

    fallback_logs = [
        r for r in caplog.records
        if "no `configurations[]` entry matched" in r.getMessage()
    ]
    assert not fallback_logs


# ───────────────────────────────────────────────────────────────────────
# crewai.LLM path (model_copy(update=...))
# ───────────────────────────────────────────────────────────────────────


def test_crewai_llm_path_clones_with_cfg_overrides() -> None:
    """``crewai.BaseLLM`` shape: cfg fields land on a per-call clone
    via ``model_copy(update={...})`` and the customer instance is not
    mutated. ``crewai.LLM(model=...)`` returns a provider subclass
    (e.g. ``OpenAICompletion``) — the adapter dispatches on
    ``BaseLLM``, the common pydantic base."""
    crewai = pytest.importorskip("crewai")
    LLM = crewai.LLM
    BaseLLM = crewai.BaseLLM

    original = LLM(model="gpt-3.5-turbo", temperature=0.0)
    # Sanity: the constructor returned a provider subclass, not LLM.
    assert isinstance(original, BaseLLM)

    seen: dict = {}

    def fake_call(self: Any, messages: Any, **_kwargs: Any) -> str:
        seen["model"] = self.model
        seen["temperature"] = self.temperature
        seen["max_tokens"] = self.max_tokens
        seen["top_p"] = self.top_p
        seen["messages"] = messages
        return "ok"

    # Patch ``.call`` on the concrete provider class the customer's
    # LLM resolved to so the clone returned by ``model_copy`` (same
    # class) routes into the stub instead of hitting OpenAI.
    concrete_cls = type(original)
    original_call = concrete_cls.call
    try:
        concrete_cls.call = fake_call  # type: ignore[method-assign]
        caller = make_llm_caller(
            original,
            configuration_resolver=lambda _cid: {
                "id": "stage1-judge",
                "type": "llm",
                "model": "gpt-4o",
                "max_tokens": 256,
                "temperature": 0.7,
                "top_p": 0.9,
            },
        )
        out = caller("stage1-judge", "prompt")
    finally:
        concrete_cls.call = original_call  # type: ignore[method-assign]

    assert out == "ok"
    assert seen["model"] == "gpt-4o"
    assert seen["temperature"] == 0.7
    assert seen["max_tokens"] == 256
    assert seen["top_p"] == 0.9

    # Customer's original instance is untouched.
    assert original.model == "gpt-3.5-turbo"
    assert original.temperature == 0.0
    assert original.max_tokens is None
    assert original.top_p is None


def test_crewai_llm_path_no_cfg_uses_original_instance() -> None:
    """No cfg => the original ``crewai.BaseLLM`` instance is used as-is."""
    crewai = pytest.importorskip("crewai")
    LLM = crewai.LLM

    original = LLM(model="gpt-4o", temperature=0.0)
    out = _build_crewai_llm_override(original, None)
    assert out is original

    out = _build_crewai_llm_override(original, {"id": "x", "type": "llm"})
    # Empty update => still the original instance.
    assert out is original


# ───────────────────────────────────────────────────────────────────────
# LangChain ``.invoke`` path (best-effort .bind)
# ───────────────────────────────────────────────────────────────────────


class _StubLangchainModel:
    """Mimics the surface the LangChain branch touches: ``.invoke`` +
    ``.bind`` (Runnable contract). Each call records its bind kwargs."""

    def __init__(self, bind_kwargs: Optional[dict] = None) -> None:
        self.bind_kwargs = bind_kwargs or {}
        self.invoke_calls: List[Any] = []

    def bind(self, **kwargs: Any) -> "_StubLangchainModel":
        merged = dict(self.bind_kwargs)
        merged.update(kwargs)
        return _StubLangchainModel(merged)

    def invoke(self, messages: Any) -> Any:
        self.invoke_calls.append(messages)

        class _Result:
            content = "ok"

        return _Result()


def _install_fake_langchain(monkeypatch: pytest.MonkeyPatch) -> None:
    """Provide a stub ``langchain_core.messages.HumanMessage`` so the
    test doesn't depend on a real LangChain install."""
    if "langchain_core.messages" in sys.modules:
        return

    class _HumanMessage:
        def __init__(self, content: str) -> None:
            self.content = content

    mod = type(
        "fake_messages_mod", (), {"HumanMessage": _HumanMessage},
    )
    parent = type("fake_lc_core", (), {})()
    monkeypatch.setitem(sys.modules, "langchain_core", parent)
    monkeypatch.setitem(sys.modules, "langchain_core.messages", mod)


def test_langchain_invoke_path_binds_cfg_kwargs(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A LangChain-shaped model that exposes ``.bind`` receives
    ``max_tokens`` + ``temperature`` from cfg via best-effort .bind."""
    _install_fake_langchain(monkeypatch)

    stub = _StubLangchainModel()
    captured: dict = {}

    # Record what bind() was called with.
    orig_bind = stub.bind

    def recording_bind(**kwargs: Any) -> Any:
        captured.update(kwargs)
        return orig_bind(**kwargs)

    stub.bind = recording_bind  # type: ignore[assignment]

    caller = make_llm_caller(
        stub,
        configuration_resolver=lambda _cid: {
            "id": "stage1-judge",
            "type": "llm",
            "model": "gpt-4o",  # NOT bound — pre-bound model is sacred.
            "max_tokens": 256,
            "temperature": 0.4,
        },
    )
    out = caller("stage1-judge", "prompt")
    assert out == "ok"

    assert captured == {"max_tokens": 256, "temperature": 0.4}
    # ``model`` is intentionally NOT bound on the LangChain shape.
    assert "model" not in captured


def test_bind_langchain_overrides_skips_when_no_bind_attr() -> None:
    """A LangChain-shaped model without ``.bind`` => no-op."""

    class _NoBind:
        def invoke(self, _messages: Any) -> Any:  # pragma: no cover
            return None

    stub = _NoBind()
    cfg = {"max_tokens": 256, "temperature": 0.4}
    out = _bind_langchain_overrides(stub, cfg)
    assert out is stub


# ───────────────────────────────────────────────────────────────────────
# ``.call`` no-op shape (non-crewai.LLM)
# ───────────────────────────────────────────────────────────────────────


def test_generic_call_shape_no_op_does_not_crash() -> None:
    """A custom LLM exposing only ``.call`` (and *not* an instance of
    ``crewai.LLM``) must still be callable through the adapter — cfg
    overrides are documented as a no-op for this shape."""

    class _GenericCallLLM:
        def __init__(self) -> None:
            self.calls: List[Any] = []

        def call(self, messages: Any) -> str:
            self.calls.append(messages)
            return "ok"

    stub = _GenericCallLLM()
    caller = make_llm_caller(
        stub,
        configuration_resolver=lambda _cid: {
            "id": "stage1-judge",
            "type": "llm",
            "model": "gpt-4o",
            "max_tokens": 256,
        },
    )
    out = caller("stage1-judge", "prompt")
    assert out == "ok"
    assert len(stub.calls) == 1


# ───────────────────────────────────────────────────────────────────────
# Bare-callable no-op shape
# ───────────────────────────────────────────────────────────────────────


def test_bare_callable_shape_no_op_does_not_crash() -> None:
    """``llm(prompt) -> str`` shape — no kwargs surface; documented
    no-op for cfg overrides. The adapter must still call it."""
    received: List[str] = []

    def my_llm(prompt: str) -> str:
        received.append(prompt)
        return "ok"

    caller = make_llm_caller(
        my_llm,
        configuration_resolver=lambda _cid: {
            "id": "stage1-judge",
            "type": "llm",
            "model": "gpt-4o",
            "max_tokens": 256,
        },
    )
    out = caller("stage1-judge", "prompt")
    assert out == "ok"
    assert received == ["prompt"]


# ───────────────────────────────────────────────────────────────────────
# _filter_litellm_kwargs unit tests
# ───────────────────────────────────────────────────────────────────────


def test_filter_litellm_kwargs_drops_none_and_unknown() -> None:
    cfg = {
        "model": "gpt-4o",            # not in the kwarg set — handled separately
        "max_tokens": 256,
        "temperature": None,           # dropped
        "top_p": 0.9,
        "id": "stage1-judge",         # arbitrary cfg metadata — dropped
        "api_key": "secret",           # security: never plumbed
    }
    out = _filter_litellm_kwargs(cfg, model=None)
    # model isn't in the kwarg list (the caller passes it as the
    # top-level ``model`` arg) and api_key is intentionally excluded.
    assert out == {"max_tokens": 256, "top_p": 0.9}


def test_filter_litellm_kwargs_empty_cfg() -> None:
    assert _filter_litellm_kwargs(None, model="gpt-4o") == {}
    assert _filter_litellm_kwargs({}, model="gpt-4o") == {}


# ───────────────────────────────────────────────────────────────────────
# ShieldBuilder integration — resolver wired through build()
# ───────────────────────────────────────────────────────────────────────


def test_shield_builder_wires_resolver_through_build(
    tmp_path, patched_litellm: _RecordingCompletion,
) -> None:
    """``Shield.from_yaml(...).with_crewai().with_client(...).build()``
    must produce a caller whose Stage-1 / Stage-3 invocations honour
    the YAML's per-configuration ``model``."""
    import agent_shield.adapters.crewai  # noqa: F401 — register bundle
    from agent_shield.adapters._shield import ShieldBuilder

    yaml_path = tmp_path / "guardrails.yaml"
    yaml_path.write_text(_MULTI_CONFIG_YAML)

    builder = (
        ShieldBuilder(str(yaml_path), auto_bind=False)
        .with_crewai()
        .with_client("gpt-3.5-turbo")
    )
    shield = builder.build()

    bound_caller = builder._llm_caller  # noqa: SLF001 — test introspection
    assert bound_caller is not None

    bound_caller("stage1-judge", "prompt")
    bound_caller("stage3-judge", "prompt")

    calls = patched_litellm.calls
    assert calls[-2]["model"] == "gpt-4o"
    assert calls[-2]["max_tokens"] == 256
    assert calls[-1]["model"] == "gpt-4o-mini"

    # Sanity-check the runtime accessor is reachable post-build.
    assert (
        shield.runtime.llm_configuration("stage1-judge")["model"] == "gpt-4o"
    )
