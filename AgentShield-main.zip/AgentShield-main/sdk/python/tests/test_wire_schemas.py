"""Conformance tests for canonical wire-shape JSON Schemas.

The schemas in ``spec/schemas/wire/*.schema.json`` are the public
compatibility contract for every shape that crosses the FFI boundary.
This suite proves that real Python runtime outputs validate against
each schema — so the canonical contract and the actual implementation
cannot drift unnoticed.

For every schema:

* The schema itself parses as a valid JSON Schema document.
* Real outputs from the runtime / adapters validate against it.
* (Where applicable) carefully constructed counterexamples FAIL
  validation, proving the schema is restrictive enough to be useful.
"""
from __future__ import annotations

import dataclasses
import json
from pathlib import Path
from typing import Any, Dict

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent.parent.parent
SCHEMAS_DIR = REPO_ROOT / "spec" / "schemas" / "wire"
GLOBAL_FIXTURES = REPO_ROOT / "tests" / "fixtures"
MINIMAL = str(GLOBAL_FIXTURES / "smoke" / "minimal.guardrails.yaml")


def _load_schema(name: str) -> Dict[str, Any]:
    path = SCHEMAS_DIR / f"{name}.schema.json"
    with open(path) as f:
        return json.load(f)


def _validator(schema: Dict[str, Any]):
    import jsonschema

    return jsonschema.Draft7Validator(schema)


# ───────────────────────────────────────────────────────────────────────────
# Schema-document validity (each schema is itself well-formed)
# ───────────────────────────────────────────────────────────────────────────


@pytest.mark.parametrize(
    "name",
    [
        "stage_verdict",
        "variable_state",
        "resolver_request",
        "resolver_response",
        "delegate_request",
        "llm_response",
        "classifier_verdict",
        "shield_log_event",
        "capability_report",
    ],
)
def test_schema_is_valid_json_schema(name: str):
    schema = _load_schema(name)
    # Construct a Draft 7 validator — fails if the schema is malformed.
    import jsonschema

    jsonschema.Draft7Validator.check_schema(schema)
    assert schema["$schema"] == "http://json-schema.org/draft-07/schema#"
    assert schema["$id"].startswith(
        "https://github.com/microsoft/AgentShield/spec/schemas/wire/"
    )


# ───────────────────────────────────────────────────────────────────────────
# Real Python outputs validate against their schemas
# ───────────────────────────────────────────────────────────────────────────


def _verdict_to_dict(v: Any) -> Dict[str, Any]:
    """Convert a StageVerdict into the canonical wire dict.

    The Python ``StageVerdict`` is a dataclass; ``dataclasses.asdict``
    produces a shape compatible with the wire schema (modulo Python's
    None ↔ JSON null mapping which the validator accepts).
    """
    return dataclasses.asdict(v)


class TestStageVerdictAgainstRuntime:
    """Real verdicts from Session.validate_* validate against the schema."""

    def test_validate_input_verdict(self):
        from agent_shield import RuntimeBuilder

        rt = RuntimeBuilder.from_yaml(MINIMAL).build()
        with rt.new_session() as session:
            session.begin_turn()
            verdict = session.validate_input("hello")
        d = _verdict_to_dict(verdict)
        _validator(_load_schema("stage_verdict")).validate(d)

    def test_validate_tool_call_verdict(self):
        from agent_shield import RuntimeBuilder

        rt = RuntimeBuilder.from_yaml(MINIMAL).build()
        with rt.new_session() as session:
            session.begin_turn()
            outcome = session.validate_tool_call("echo", {"msg": "hi"}, tool_call_id="call_1")
        d = _verdict_to_dict(outcome.verdict)
        _validator(_load_schema("stage_verdict")).validate(d)

    def test_validate_output_verdict(self):
        from agent_shield import RuntimeBuilder

        rt = RuntimeBuilder.from_yaml(MINIMAL).build()
        with rt.new_session() as session:
            session.begin_turn()
            outcome = session.validate_output("hello world")
        d = _verdict_to_dict(outcome.verdict)
        _validator(_load_schema("stage_verdict")).validate(d)


class TestStageVerdictCounterexamples:
    """The schema rejects malformed StageVerdicts."""

    def test_missing_allowed_field_rejected(self):
        from jsonschema import ValidationError

        v = _validator(_load_schema("stage_verdict"))
        with pytest.raises(ValidationError):
            v.validate({"reason": "blocked"})

    def test_invalid_action_rejected(self):
        from jsonschema import ValidationError

        v = _validator(_load_schema("stage_verdict"))
        with pytest.raises(ValidationError):
            v.validate({"allowed": True, "action": "explode"})

    def test_extra_fields_rejected(self):
        from jsonschema import ValidationError

        v = _validator(_load_schema("stage_verdict"))
        with pytest.raises(ValidationError):
            v.validate(
                {"allowed": True, "spurious_field": "nope"},
            )


class TestVariableStateAgainstRuntime:
    """Real variable states validate against the schema."""

    def test_unset_state(self):
        v = _validator(_load_schema("variable_state"))
        v.validate({"status": "unset"})

    def test_resolved_state(self):
        v = _validator(_load_schema("variable_state"))
        v.validate({
            "status": "resolved",
            "value": True,
            "set_at": "2026-05-06T20:00:00Z",
            "set_by": "host",
            "source_kind": "host",
        })

    def test_denied_state(self):
        v = _validator(_load_schema("variable_state"))
        v.validate({
            "status": "denied",
            "deny_reason": "user denied",
        })

    def test_invalid_status_rejected(self):
        from jsonschema import ValidationError

        v = _validator(_load_schema("variable_state"))
        with pytest.raises(ValidationError):
            v.validate({"status": "frozen"})


class TestResolverRequestResponseShapes:
    """Resolver request / response shapes validate."""

    def test_request_minimum(self):
        v = _validator(_load_schema("resolver_request"))
        v.validate({"request_id": "req-1"})

    def test_request_full(self):
        v = _validator(_load_schema("resolver_request"))
        v.validate({
            "request_id": "req-2",
            "variable": "send_authorized",
            "resource_kind": "tool",
            "resource_name": "send_message",
            "prompt": "Approve send?",
            "reason": "user policy",
            "context": {"foo": "bar"},
            "requested_key": "channel-42",
        })

    def test_response_allow(self):
        v = _validator(_load_schema("resolver_response"))
        v.validate({"decision": "allow", "value": True})

    def test_response_deny(self):
        v = _validator(_load_schema("resolver_response"))
        v.validate({"decision": "deny", "reason": "user denied"})

    def test_response_invalid_decision_rejected(self):
        from jsonschema import ValidationError

        v = _validator(_load_schema("resolver_response"))
        with pytest.raises(ValidationError):
            v.validate({"decision": "maybe"})


class TestDelegateRequestShape:
    """Delegate request envelope."""

    def test_delegate_minimum(self):
        v = _validator(_load_schema("delegate_request"))
        v.validate({
            "request_id": "del-1",
            "configuration": {"endpoint": "https://approve.example"},
            "effective_timeout_ms": 5000,
        })

    def test_delegate_full(self):
        v = _validator(_load_schema("delegate_request"))
        v.validate({
            "request_id": "del-2",
            "variable": "kyc",
            "configuration": {"endpoint": "https://kyc.example"},
            "effective_timeout_ms": 10000,
            "resource_kind": "tool",
            "resource_name": "request_kyc",
            "prompt": "Run KYC for user",
            "context": {"user_id": "u1"},
            "requested_key": "u1",
        })


class TestLlmResponseShape:
    def test_allow(self):
        v = _validator(_load_schema("llm_response"))
        v.validate({"decision": "allow", "reason": "ok"})

    def test_deny_with_redactions(self):
        v = _validator(_load_schema("llm_response"))
        v.validate({
            "decision": "deny",
            "reason": "PII detected",
            "redactions": [
                {"start": 0, "end": 5, "replacement": "[REDACTED]"},
            ],
        })


class TestClassifierVerdictShape:
    def test_score_below_threshold(self):
        v = _validator(_load_schema("classifier_verdict"))
        v.validate({"score": 0.1, "threshold": 0.5, "flagged": False})

    def test_score_above_threshold(self):
        v = _validator(_load_schema("classifier_verdict"))
        v.validate({
            "score": 0.95,
            "threshold": 0.5,
            "flagged": True,
            "categories": ["pii", "secrets"],
        })


class TestCapabilityReportShape:
    """Real capability reports from the adapters validate."""

    def test_openai_agents_report(self):
        from agent_shield.adapters.openai_agents import _BUNDLE

        rep = _BUNDLE.capabilities
        d = {
            "framework": rep.framework,
            "input_validation": rep.input_validation.value,
            "state_validation": rep.state_validation.value,
            "tool_authorization": rep.tool_authorization.value,
            "tool_execution_validation": rep.tool_execution_validation.value,
            "tool_output_validation": rep.tool_output_validation.value,
            "output_validation": rep.output_validation.value,
            "streaming_output": rep.streaming_output.value,
            "notes": list(rep.notes),
        }
        _validator(_load_schema("capability_report")).validate(d)

    def test_crewai_report_with_unsupported_streaming(self):
        from agent_shield.adapters.crewai import _BUNDLE

        rep = _BUNDLE.capabilities
        d = {
            "framework": rep.framework,
            "input_validation": rep.input_validation.value,
            "state_validation": rep.state_validation.value,
            "tool_authorization": rep.tool_authorization.value,
            "tool_execution_validation": rep.tool_execution_validation.value,
            "tool_output_validation": rep.tool_output_validation.value,
            "output_validation": rep.output_validation.value,
            "streaming_output": rep.streaming_output.value,
            "notes": list(rep.notes),
        }
        _validator(_load_schema("capability_report")).validate(d)
        assert d["streaming_output"] == "unsupported"

    def test_mcp_report(self):
        from agent_shield.mcp import MCPShield

        shield = MCPShield.from_yaml(MINIMAL).build()
        rep = shield.capabilities
        d = {
            "framework": rep.framework,
            "input_validation": rep.input_validation.value,
            "state_validation": rep.state_validation.value,
            "tool_authorization": rep.tool_authorization.value,
            "tool_execution_validation": rep.tool_execution_validation.value,
            "tool_output_validation": rep.tool_output_validation.value,
            "output_validation": rep.output_validation.value,
            "streaming_output": rep.streaming_output.value,
            "notes": list(rep.notes),
        }
        _validator(_load_schema("capability_report")).validate(d)


class TestShieldLogEventShape:
    """Real observability events validate."""

    def test_real_runtime_event(self):
        from agent_shield import RuntimeBuilder
        from agent_shield.observability import CapturingProvider

        cap = CapturingProvider()
        rt = (
            RuntimeBuilder.from_yaml(MINIMAL)
            .register_observability_provider(cap)
            .build()
        )
        with rt.new_session() as session:
            session.begin_turn()
            session.validate_input("hi")
            session.end_turn()

        assert len(cap.events) > 0
        v = _validator(_load_schema("shield_log_event"))
        for event in cap.events:
            d = {
                "event_type": event.event_type,
                "event_name": getattr(event, "event_name", None),
                "timestamp": event.timestamp,
                "session_id": getattr(event, "session_id", None),
                "correlation_id": getattr(event, "correlation_id", None),
                "stage": getattr(event, "stage", None),
                "attributes": dict(event.attributes),
            }
            v.validate(d)
