"""Semantic Kernel integration for Agent Shield guardrails.

Capability-based adapter that plugs into the framework-agnostic
:class:`~agent_shield.adapters._shield.Shield` orchestrator.

Semantic Kernel calls "tools" *functions* and exposes them through
``KernelFunction`` / ``KernelPlugin``; guarded variants are produced
via :func:`protect_functions` and :func:`protect_plugin`.

**Level 2 — Shield helper** (recommended)::

    from agent_shield import Shield
    import agent_shield.adapters.semantic_kernel  # side-effect import

    shield = (
        Shield.from_yaml("guardrails.yaml")
        .with_semantic_kernel()
        .with_client(kernel)
        .build()
    )
    funcs  = shield.protect_functions(funcs)
    plugin = shield.protect_plugin(plugin)
    agent  = shield.guard(agent)
"""
from __future__ import annotations

import asyncio
import atexit
import concurrent.futures
import logging
import uuid
from typing import Any, AsyncIterator, Callable, Optional

from agent_shield import Runtime, Session

from ._capabilities import (
    AdapterStageMutationError,
    AgentBoundary,
    CapabilityReport,
    CoverageLevel,
    FrameworkBundle,
    GuardedInvoke,
    LlmCallerFactory,
    StreamingAdapter,
    StreamingValidator,
    ToolMetadata,
    ToolWrapper,
)
from ._orchestration import guarded_tool
from ._shield import (
    GuardedRunner,
    Shield,
    ShieldBuilder,
    _protect_tools_via_wrapper,
)

logger = logging.getLogger("agent_shield.semantic_kernel")

# Shared thread pool for running async SK callers synchronously.
_SK_EXECUTOR = concurrent.futures.ThreadPoolExecutor(max_workers=1)
atexit.register(_SK_EXECUTOR.shutdown, wait=False)


# ---------------------------------------------------------------------------
# Capability 1 — LLM caller factory
# ---------------------------------------------------------------------------


class _LlmCallerFactory(LlmCallerFactory):
    """Adapt a Semantic Kernel ``Kernel`` to the runtime caller shape.

    The Rust validation engine invokes LLM callers synchronously; SK's
    chat completion service is async, so we drive it on a dedicated
    thread to avoid event-loop deadlocks.

    When the optional ``configuration_resolver`` is supplied, the
    produced caller plumbs the YAML's ``configurations[]`` entry into
    SK's service-specific ``PromptExecutionSettings`` subclass —
    discovered at call time via
    ``chat_service.get_prompt_execution_settings_class()`` (the
    ``ChatCompletionClientBase`` reflective API). This is the only
    portable way to set per-stage ``max_tokens`` / ``temperature`` /
    ``ai_model_id``: ``OpenAIChatPromptExecutionSettings``,
    ``AzureChatPromptExecutionSettings``,
    ``GoogleAIChatPromptExecutionSettings``, etc. all expose different
    field sets, but every concrete chat service knows which subclass
    fits its provider.

    If the resolver returns ``None`` (no matching entry), or
    introspection isn't available on the customer's chat service, the
    adapter falls back to the kernel's pre-bound default settings — a
    DEBUG log fires on the genuine SRE signal (non-empty
    ``configuration_id`` with no matching YAML entry) so customers can
    correlate stage routing with their kernel service configuration.
    """

    #: Documentation marker for the kernel's expected default chat
    #: service. The adapter does NOT enforce this — it surfaces only
    #: in the fallback DEBUG log.
    DEFAULT_FALLBACK_MODEL = "kernel-bound chat completion service"

    def make_caller(
        self,
        kernel: Any,
        *,
        configuration_resolver: Optional[
            Callable[[Optional[str]], Optional[dict]]
        ] = None,
    ) -> Callable[[Optional[str], str], str]:
        from semantic_kernel.contents import ChatHistory

        fallback_model = self.DEFAULT_FALLBACK_MODEL

        def caller(configuration_id: Optional[str], prompt: str) -> str:
            cfg: Optional[dict] = None
            if configuration_resolver is not None and configuration_id:
                try:
                    cfg = configuration_resolver(configuration_id)
                except Exception:
                    # Resolver lookup must never break the LLM caller —
                    # fall through to the documented fallback path.
                    logger.exception(
                        "semantic_kernel llm caller: configuration_resolver "
                        "raised for configuration_id=%r; falling back to "
                        "the kernel's pre-bound chat service (%r).",
                        configuration_id,
                        fallback_model,
                    )
                    cfg = None

            if cfg is None and configuration_id:
                # Only DEBUG-log on the genuine SRE signal — a stage
                # asked for routing and didn't get it. The "no
                # routing requested" case (configuration_id ``None``
                # / ``""``) is a legitimate fallback. Mirrors the
                # OpenAI / Anthropic Python adapters.
                logger.debug(
                    "semantic_kernel llm caller: no `configurations[]` "
                    "entry matched configuration_id=%r; invoking the "
                    "kernel's pre-bound chat service with default "
                    "PromptExecutionSettings.",
                    configuration_id,
                )

            async def _inner() -> str:
                chat_service = kernel.get_service(type="chat_completion")
                if chat_service is None:
                    chat_service = kernel.get_service()
                history = ChatHistory()
                history.add_user_message(prompt)

                # Approach A — discover the right
                # PromptExecutionSettings subclass via SK's
                # introspection API and apply the resolved cfg to it.
                # Falls back to the historic settings-less call shape
                # if introspection isn't available so stubs / mocks
                # that don't implement the API still work.
                settings = _build_prompt_execution_settings(
                    chat_service, cfg,
                )
                if settings is not None:
                    response = await chat_service.get_chat_message_contents(
                        history, settings=settings, kernel=kernel,
                    )
                else:
                    response = await chat_service.get_chat_message_contents(
                        history, kernel=kernel,
                    )
                return str(response[0])

            future = _SK_EXECUTOR.submit(lambda: asyncio.run(_inner()))
            return future.result()

        return caller


def _build_prompt_execution_settings(
    chat_service: Any, cfg: Optional[dict],
) -> Optional[Any]:
    """Build a service-specific ``PromptExecutionSettings`` instance.

    Uses SK's reflective ``get_prompt_execution_settings_class`` API
    to discover the right subclass for the customer's chat service
    (``OpenAIChatPromptExecutionSettings``,
    ``AzureChatPromptExecutionSettings``, …). Returns ``None`` if
    introspection isn't available (e.g. a stub service that doesn't
    expose the API) so callers fall back to the historic
    settings-less call shape.

    The mapping applied when ``cfg`` is non-empty:

    - ``cfg["model"]``        → ``settings.ai_model_id``
    - ``cfg["max_tokens"]``   → ``settings.max_tokens``
    - ``cfg["temperature"]``  → ``settings.temperature``

    Fields absent on the discovered settings subclass are skipped
    silently — different providers expose different field sets, and
    we don't want a missing attribute on one provider's settings
    class to break the LLM-judge code path.
    """
    get_cls = getattr(chat_service, "get_prompt_execution_settings_class", None)
    if get_cls is None or not callable(get_cls):
        return None
    try:
        settings_cls = get_cls()
        settings = settings_cls()
    except Exception:
        logger.debug(
            "semantic_kernel llm caller: failed to instantiate "
            "PromptExecutionSettings from chat service introspection; "
            "falling back to settings-less call.",
            exc_info=True,
        )
        return None

    if not cfg:
        return settings

    model = cfg.get("model")
    if model and hasattr(settings, "ai_model_id"):
        try:
            settings.ai_model_id = model
        except Exception:
            logger.debug(
                "semantic_kernel llm caller: refused ai_model_id=%r on %s",
                model, type(settings).__name__, exc_info=True,
            )

    max_tokens = cfg.get("max_tokens")
    if max_tokens is not None and hasattr(settings, "max_tokens"):
        try:
            settings.max_tokens = max_tokens
        except Exception:
            logger.debug(
                "semantic_kernel llm caller: refused max_tokens=%r on %s",
                max_tokens, type(settings).__name__, exc_info=True,
            )

    temperature = cfg.get("temperature")
    if temperature is not None and hasattr(settings, "temperature"):
        try:
            settings.temperature = temperature
        except Exception:
            logger.debug(
                "semantic_kernel llm caller: refused temperature=%r on %s",
                temperature, type(settings).__name__, exc_info=True,
            )

    return settings


# ---------------------------------------------------------------------------
# Capability 2 — Tool wrapper (KernelFunction monkey-patch)
# ---------------------------------------------------------------------------


class _ToolWrapper(ToolWrapper):
    """Wrap a Semantic Kernel ``KernelFunction`` with guarded
    ``_invoke_internal``.

    SK functions use metadata-driven dispatch — we cannot construct a
    new KernelFunction with arbitrary internals without losing the
    metadata. The wrapper builds a clone (``KernelFunction.from_method``
    if possible) and replaces its ``_invoke_internal`` with a closure
    that delegates to the orchestrator-provided ``guarded_invoke``.
    """

    def extract(self, tool: Any) -> ToolMetadata:
        return ToolMetadata(
            name=tool.name,
            description=getattr(tool, "description", tool.name),
            extras={
                "method": getattr(tool, "method", None),
                "metadata": getattr(tool, "metadata", None),
                "_invoke_internal": getattr(tool, "_invoke_internal", None),
            },
        )

    async def invoke(self, original: Any, params: dict) -> Any:
        # Direct invocation path used when callers go through the
        # orchestrator's ``invoke`` rather than the framework's
        # ``_invoke_internal`` dispatch (rare for SK, kept for parity).
        from semantic_kernel.functions import FunctionResult, KernelArguments

        # Build a stub context object that satisfies SK's _invoke_internal.
        context = _StubInvokeContext(KernelArguments(**params))
        original_invoke = self.extract(original).extras["_invoke_internal"]
        await original_invoke(context)
        return str(context.result) if context.result is not None else ""

    def wrap(
        self,
        original: Any,
        metadata: ToolMetadata,
        guarded_invoke: GuardedInvoke,
    ) -> Any:
        from semantic_kernel.functions import FunctionResult, KernelFunction

        method = metadata.extras.get("method")
        if method is not None:
            wrapped = KernelFunction.from_method(method=method)
        else:
            wrapped = original
        original_invoke = metadata.extras["_invoke_internal"]
        func_name = metadata.name

        async def _guarded_invoke_internal(context: Any) -> None:
            params = dict(context.arguments) if context.arguments else {}
            params.pop("kernel", None)

            async def _execute(effective_params: dict) -> str:
                if context.arguments is not None:
                    try:
                        for k in list(context.arguments.keys()):
                            if k == "kernel":
                                continue
                            if k in effective_params:
                                context.arguments[k] = effective_params[k]
                            else:
                                del context.arguments[k]
                        for k, v in effective_params.items():
                            if k not in context.arguments:
                                context.arguments[k] = v
                    except Exception as exc:  # noqa: BLE001
                        # Stage 3 may have produced effective_params that
                        # the SK arguments container can't accept (e.g.
                        # type-coerced redactions). Failing silently
                        # would run the tool with the *original* params
                        # and quietly defeat the Stage-3 transform —
                        # surface a typed error so the orchestrator can
                        # treat it as a Stage-3 block.
                        raise AdapterStageMutationError(
                            tool_name=func_name, cause=exc,
                        ) from exc
                await original_invoke(context)
                return str(context.result) if context.result is not None else ""

            # §16.0 binding — Semantic Kernel function-invocation site
            # has no upstream model call id available; mint a per-call
            # id so concurrent same-name invocations bind correctly.
            _call_id = uuid.uuid4().hex
            blocked, output = await guarded_tool(
                func_name, params, _execute,
                tool_call_id=_call_id,
            )

            current_output = (
                str(context.result) if context.result is not None else ""
            )
            if blocked or output != current_output:
                context.result = FunctionResult(
                    function=wrapped.metadata, value=output,
                )

        wrapped._invoke_internal = _guarded_invoke_internal
        return wrapped


class _StubInvokeContext:
    """Minimal context shape used by :meth:`_ToolWrapper.invoke`."""

    def __init__(self, arguments: Any) -> None:
        self.arguments = arguments
        self.result = None


# ---------------------------------------------------------------------------
# Capability 3 — Agent boundary (Stage 1 + Stage 5 around agent.invoke)
# ---------------------------------------------------------------------------


class _AgentBoundary(AgentBoundary):
    """Run a Semantic Kernel agent and reshape its result."""

    async def run(
        self, agent: Any, input_text: str, **kwargs: Any,
    ) -> Any:
        messages = kwargs.pop("messages", None)
        return await agent.invoke(messages, **kwargs)

    def extract_output(self, result: Any) -> Optional[str]:
        if isinstance(result, str):
            return result
        if hasattr(result, "content"):
            return str(result.content)
        if hasattr(result, "value"):
            return str(result.value)
        return str(result) if result else ""

    def apply_redaction(self, result: Any, redacted_text: str) -> Any:
        # SK doesn't have a single canonical result-dict shape; surface
        # the redacted text directly (matches the historic behaviour).
        return redacted_text

    def make_blocked(self, message: str) -> Any:
        return message


def _extract_user_input_from_messages(messages: Any) -> str:
    """Find the most recent user message in SK's message structures."""
    if isinstance(messages, str):
        return messages
    if hasattr(messages, "messages"):
        msg_list = messages.messages
    elif isinstance(messages, list):
        msg_list = messages
    else:
        return ""
    for msg in reversed(msg_list):
        if hasattr(msg, "role") and str(msg.role).lower() == "user":
            return str(getattr(msg, "content", ""))
        if isinstance(msg, dict) and msg.get("role", "").lower() == "user":
            return str(msg.get("content", ""))
    return ""


# ---------------------------------------------------------------------------
# Capability 4 — Streaming (unsupported in this adapter)
# ---------------------------------------------------------------------------


class _StreamingAdapter(StreamingAdapter):
    """SK streaming is left as a future improvement."""

    async def stream(
        self,
        agent: Any,
        input_text: str,
        validator: StreamingValidator,
        **kwargs: Any,
    ) -> AsyncIterator[Any]:
        raise NotImplementedError(
            "Semantic Kernel streaming adapter is not implemented"
        )
        yield  # pragma: no cover


# ---------------------------------------------------------------------------
# Bundle
# ---------------------------------------------------------------------------


class GuardedAgent(GuardedRunner):
    """SK-named guarded runner with ``invoke(messages, ...)`` shape."""

    async def invoke(  # type: ignore[override]
        self,
        messages: Any | None = None,
        *,
        user_input: str = "",
        **kwargs: Any,
    ) -> Any:
        """Invoke the agent with Stage 1 + Stage 5 validation."""
        if not user_input and messages is not None:
            user_input = _extract_user_input_from_messages(messages)
        return await self.run(user_input, messages=messages, **kwargs)


_BUNDLE = FrameworkBundle(
    name="semantic_kernel",
    llm_caller_factory=_LlmCallerFactory(),
    tool_wrapper=_ToolWrapper(),
    agent_boundary=_AgentBoundary(),
    streaming_adapter=None,
    capabilities=CapabilityReport(
        framework="semantic_kernel",
        streaming_output=CoverageLevel.UNSUPPORTED,
        notes=["streaming adapter not implemented"],
    ),
    guarded_runner_cls=GuardedAgent,
)


# ---------------------------------------------------------------------------
# Composition pattern — install with_semantic_kernel(),
# create_semantic_kernel_agent(), protect_functions, protect_plugin.
# ---------------------------------------------------------------------------


def _install() -> None:
    """Monkey-install :meth:`ShieldBuilder.with_semantic_kernel`,
    :meth:`Shield.create_semantic_kernel_agent`, and the SK-specific
    :meth:`Shield.protect_functions` / :meth:`Shield.protect_plugin`
    helpers."""

    def with_semantic_kernel(self: ShieldBuilder) -> ShieldBuilder:
        """Bind this builder to the Semantic Kernel framework bundle."""
        return self._bind_to_bundle(_BUNDLE)

    def shield_protect_functions(
        self: Shield,
        functions: list,
        user_input_getter: Callable[[], str] | None = None,
    ) -> list:
        """Wrap SK functions with Stages 2 + 3 + 4 enforcement."""
        return _protect_tools_via_wrapper(
            self.runtime, functions, self._bundle.tool_wrapper,
            user_input_getter, mode=self._mode,
        )

    def shield_protect_plugin(
        self: Shield,
        plugin: Any,
        user_input_getter: Callable[[], str] | None = None,
    ) -> Any:
        """Wrap all functions in a ``KernelPlugin`` with Stages 2 + 3 + 4."""
        from semantic_kernel.functions import KernelPlugin

        functions = list(plugin.functions.values())
        wrapped = shield_protect_functions(
            self, functions, user_input_getter=user_input_getter,
        )
        return KernelPlugin(
            name=plugin.name,
            description=getattr(plugin, "description", ""),
            functions=wrapped,
        )

    def create_semantic_kernel_agent(
        self: Shield,
        kernel: Any,
        plugins: list,
        *,
        system_prompt: str = "",
        service_id: str = "chat",
        **agent_kwargs: Any,
    ) -> Any:
        """Build a fully guarded Semantic Kernel agent in one call (Pattern A)."""
        from semantic_kernel.agents import ChatCompletionAgent

        for plugin in plugins:
            kernel.add_plugin(shield_protect_plugin(self, plugin))

        agent = ChatCompletionAgent(
            kernel=kernel,
            service_id=service_id,
            instructions=system_prompt,
            **agent_kwargs,
        )
        return self.guard(agent)

    setattr(ShieldBuilder, "with_semantic_kernel", with_semantic_kernel)
    setattr(Shield, "protect_functions", shield_protect_functions)
    setattr(Shield, "protect_plugin", shield_protect_plugin)
    setattr(
        Shield,
        "create_semantic_kernel_agent",
        create_semantic_kernel_agent,
    )


_install()

# Register this bundle as the auto-bind default for new ShieldBuilder instances.
from . import _bundle_registry as _registry  # noqa: E402
_registry.register(_BUNDLE)


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


def make_llm_caller(
    kernel: Any,
    configuration_resolver: Optional[
        Callable[[Optional[str]], Optional[dict]]
    ] = None,
) -> Callable[[Optional[str], str], str]:
    """Create an LLM caller from a Semantic Kernel ``Kernel``.

    Pass ``configuration_resolver=runtime.llm_configuration`` to honour
    per-stage ``model:`` / ``max_tokens:`` / ``temperature:`` selections
    declared in ``.guardrails.yaml``. See :class:`_LlmCallerFactory`
    for the discovery-based settings plumbing.
    """
    return _BUNDLE.llm_caller_factory.make_caller(
        kernel, configuration_resolver=configuration_resolver,
    )


def protect_functions(
    runtime: Runtime,
    functions: list,
    user_input_getter: Optional[Callable[[], str]] = None,
) -> list:
    """Wrap SK functions with Stages 2 + 3 + 4 enforcement."""
    return _protect_tools_via_wrapper(
        runtime, functions, _BUNDLE.tool_wrapper, user_input_getter,
    )


def protect_plugin(
    runtime: Runtime,
    plugin: Any,
    user_input_getter: Optional[Callable[[], str]] = None,
) -> Any:
    """Wrap all functions in a ``KernelPlugin`` with Stages 2 + 3 + 4."""
    from semantic_kernel.functions import KernelPlugin

    functions = list(plugin.functions.values())
    wrapped = protect_functions(runtime, functions, user_input_getter)
    return KernelPlugin(
        name=plugin.name,
        description=getattr(plugin, "description", ""),
        functions=wrapped,
    )


__all__ = [
    "GuardedAgent",
    "make_llm_caller",
    "protect_functions",
    "protect_plugin",
]
