"""Framework-specific adapters for Agent Shield.

Each adapter is a small set of capability implementations
(:class:`~._capabilities.LlmCallerFactory`,
:class:`~._capabilities.ToolWrapper`,
:class:`~._capabilities.AgentBoundary`,
:class:`~._capabilities.StreamingAdapter`) that plug into the
framework-agnostic :class:`~._shield.Shield` orchestrator. The
orchestrator owns stage sequencing, ``begin_turn`` / ``end_turn``
boundaries, redaction, ``record_tool_*`` bookkeeping, monitor mode,
on-block policy, and capability reporting; the adapter only owns the
framework-specific shape translation.

Available adapters — import the module to install its
``with_<framework>`` builder hook, then construct via composition::

    from agent_shield import Shield
    import agent_shield.adapters.langchain          # side-effect import
    import agent_shield.adapters.openai_agents
    import agent_shield.adapters.anthropic_agents
    import agent_shield.adapters.autogen
    import agent_shield.adapters.crewai
    import agent_shield.adapters.semantic_kernel

    shield = (
        Shield.from_yaml("guardrails.yaml")
        .with_langchain()
        .with_client(llm)
        .build()
    )

Capability primitives (for authoring new adapters)::

    from agent_shield.adapters import (
        FrameworkBundle, CapabilityReport, CoverageLevel,
        LlmCallerFactory, ToolWrapper, AgentBoundary, StreamingAdapter,
        Shield, ShieldBuilder, ShieldMode, AgentShieldBlocked,
    )
"""
from ._capabilities import (
    AgentBoundary,
    CapabilityReport,
    CoverageLevel,
    FrameworkBundle,
    LlmCallerFactory,
    StreamingAdapter,
    StreamingPushResult,
    StreamingValidator,
    ToolMetadata,
    ToolWrapper,
)
from ._shield import (
    AgentShieldBlocked,
    GuardedRunner,
    OnBlockPolicy,
    Shield,
    ShieldBuilder,
    ShieldMode,
)

__all__ = [
    "AgentBoundary",
    "AgentShieldBlocked",
    "CapabilityReport",
    "CoverageLevel",
    "FrameworkBundle",
    "GuardedRunner",
    "LlmCallerFactory",
    "OnBlockPolicy",
    "Shield",
    "ShieldBuilder",
    "ShieldMode",
    "StreamingAdapter",
    "StreamingPushResult",
    "StreamingValidator",
    "ToolMetadata",
    "ToolWrapper",
]

