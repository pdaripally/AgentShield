"""Anthropic SDK integration for Agent Shield guardrails.

Capability-based adapter that plugs into the framework-agnostic
:class:`~agent_shield.adapters._shield.Shield` orchestrator.

Anthropic differs from chat-completion-style frameworks in that there
is no long-lived "agent" object — each run constructs a
``BetaAsyncToolRunner`` from a client + tools + model + system. The
``GuardedRunner`` here is therefore stateful (it holds the client and
default tools/model/system) and ``boundary.run`` builds the per-run
tool runner inside ``_execute``.

**Level 2 — Shield helper** (recommended)::

    from agent_shield import Shield
    import agent_shield.adapters.anthropic_agents  # side-effect import

    shield = (
        Shield.from_yaml("guardrails.yaml")
        .with_anthropic_agents()
        .with_client(client)
        .build()
    )
    tools  = shield.protect_tools(tools)
    runner = shield.guard(client, tools=tools, model="claude-sonnet-4-20250514")
    result = await runner.run("What is the weather?")

**Level 3 — two-liner**::

    shield = (
        Shield.from_yaml("guardrails.yaml")
        .with_anthropic_agents()
        .with_client(client)
        .build()
    )
    runner = shield.create_anthropic_agents_agent(tools, system_prompt="...")
    result = await runner.run("What is the weather?")
"""
from __future__ import annotations

import logging
from typing import Any, AsyncIterator, Callable, Optional

from agent_shield import Runtime, Session

from ._capabilities import (
    AgentBoundary,
    CapabilityReport,
    ConfigurationMissingModelError,
    CoverageLevel,
    FrameworkBundle,
    GuardedInvoke,
    LlmCallerFactory,
    StreamingAdapter,
    StreamingValidator,
    ToolMetadata,
    ToolWrapper,
)
from ._shield import (
    GuardedRunner as _GenericGuardedRunner,
    Shield,
    ShieldBuilder,
    _protect_tools_via_wrapper,
)

logger = logging.getLogger("agent_shield.anthropic_agents")


# Lazy import — module imports cleanly even when ``anthropic`` is not
# installed; only call paths that need the real class do the import.
try:
    from anthropic.lib.tools import (
        BetaAsyncBuiltinFunctionTool as _BuiltinToolBase,
        ToolError as _ToolError,
    )
except ImportError:  # pragma: no cover
    _BuiltinToolBase = object  # type: ignore[misc,assignment]
    _ToolError = Exception  # type: ignore[misc,assignment]


# ---------------------------------------------------------------------------
# Capability 1 — LLM caller factory
# ---------------------------------------------------------------------------


class _LlmCallerFactory(LlmCallerFactory):
    """Adapt an Anthropic client (sync or async) to the runtime caller shape.

    The Rust validation engine invokes LLM callers synchronously, so an
    ``AsyncAnthropic`` client is paired with a sync clone of itself to
    avoid ``asyncio.run()`` inside a running loop.

    When the optional ``configuration_resolver`` is supplied, the
    produced caller looks up the YAML's ``configurations[]`` entry by
    ``configuration_id`` at call time and uses its ``model:`` /
    ``max_tokens:`` fields — so a ``.guardrails.yaml`` like
    ``configurations: [{id: stage3-judge, type: llm, model:
    claude-3-5-sonnet-latest}]`` actually drives that model.

    Model selection is **strict**: the resolved configuration MUST
    declare ``model:``. When ``model:`` is missing — or no matching
    entry exists — the caller raises
    :class:`ConfigurationMissingModelError` instead of silently
    falling back to a hard-coded SKU. The schema in
    ``spec/schema/guardrails.schema.json`` enforces this at load time.

    ``max_tokens`` is treated differently because the Anthropic
    Messages API rejects requests without it but the choice of *how
    many* tokens to allow is not security-sensitive. When the
    resolved configuration omits ``max_tokens:`` the caller falls
    back to :attr:`DEFAULT_FALLBACK_MAX_TOKENS` (1024 — the historical
    default) rather than raising.
    """

    #: Anthropic's ``messages.create`` requires ``max_tokens``; this is
    #: the fallback when the YAML configuration does not declare one.
    #: The numeric budget is not a security-sensitive choice (unlike
    #: model selection), so defaulting it is acceptable.
    DEFAULT_FALLBACK_MAX_TOKENS = 1024

    def make_caller(
        self,
        client: Any,
        configuration_resolver: Optional[
            Callable[[Optional[str]], Optional[dict]]
        ] = None,
    ) -> Callable[[Optional[str], str], str]:
        sync_client = client
        if hasattr(client, "_client") and "Async" in type(client).__name__:
            import anthropic  # pragma: no cover

            init_kwargs: dict = {"api_key": client.api_key}
            if hasattr(client, "base_url") and client.base_url:
                init_kwargs["base_url"] = str(client.base_url)
            sync_client = anthropic.Anthropic(**init_kwargs)

        fallback_max_tokens = self.DEFAULT_FALLBACK_MAX_TOKENS

        def caller(configuration_id: Optional[str], prompt: str) -> str:
            cfg: Optional[dict] = None
            if configuration_resolver is not None and configuration_id:
                try:
                    cfg = configuration_resolver(configuration_id)
                except Exception:
                    # Resolver lookup must never break the LLM caller with
                    # an internal error — surface the missing-model
                    # condition directly so SREs see a load-time-shaped
                    # message rather than a transport failure.
                    logger.exception(
                        "anthropic_agents llm caller: configuration_resolver "
                        "raised for configuration_id=%r",
                        configuration_id,
                    )
                    cfg = None

            if cfg is None or not cfg.get("model"):
                raise ConfigurationMissingModelError(configuration_id)
            model = cfg["model"]

            if cfg.get("max_tokens") is not None:
                max_tokens = cfg["max_tokens"]
            else:
                max_tokens = fallback_max_tokens

            kwargs: dict = {
                "model": model,
                "max_tokens": max_tokens,
                "messages": [{"role": "user", "content": prompt}],
            }
            if cfg.get("temperature") is not None:
                kwargs["temperature"] = cfg["temperature"]

            response = sync_client.messages.create(**kwargs)
            block = response.content[0] if response.content else None
            return getattr(block, "text", "") if block else ""

        return caller


# ---------------------------------------------------------------------------
# Capability 2 — Tool wrapper
# ---------------------------------------------------------------------------


class _ToolWrapper(ToolWrapper):
    """Wrap an Anthropic tool with a :class:`_GuardedAsyncTool` subclass.

    Anthropic's ``BetaAsyncToolRunner`` discovers tools by inheritance —
    the guarded tool must subclass the framework's builtin base. The
    wrapper builds a per-tool subclass whose ``call`` method dispatches
    through the orchestrator-provided ``guarded_invoke``.
    """

    def extract(self, tool: Any) -> ToolMetadata:
        return ToolMetadata(
            name=tool.name,
            description=getattr(tool, "description", tool.name),
            extras={"to_dict": getattr(tool, "to_dict", lambda: {})},
        )

    async def invoke(self, original: Any, params: dict) -> Any:
        return await original.call(input=params)

    def wrap(
        self,
        original: Any,
        metadata: ToolMetadata,
        guarded_invoke: GuardedInvoke,
    ) -> Any:
        return _GuardedAsyncTool(original, metadata, guarded_invoke)


class _GuardedAsyncTool(_BuiltinToolBase):  # type: ignore[misc]
    """Anthropic-shaped guarded tool.

    Subclasses ``BetaAsyncBuiltinFunctionTool`` so the
    ``BetaAsyncToolRunner`` recognises it as a callable tool. The
    ``call()`` override delegates to the orchestrator-provided
    ``guarded_invoke`` and translates orchestrator blocks into
    Anthropic's ``ToolError``.
    """

    def __init__(
        self,
        original: Any,
        metadata: ToolMetadata,
        guarded_invoke: GuardedInvoke,
    ) -> None:
        self._original = original
        self._metadata = metadata
        self._guarded_invoke = guarded_invoke

    @property
    def name(self) -> str:  # type: ignore[override]
        return self._metadata.name

    def to_dict(self) -> Any:
        return self._metadata.extras.get("to_dict", lambda: {})()

    async def call(self, *, input: Any) -> Any:  # type: ignore[override]
        params = dict(input) if input else {}
        output = await self._guarded_invoke(params, "")
        # The orchestrator returns the formatted block message as the
        # output text on a block; surface it as a ToolError so
        # Anthropic's runner treats it as a tool failure.
        if isinstance(output, str) and output.startswith("[GUARDRAIL"):
            raise _ToolError(output)
        return output


# ---------------------------------------------------------------------------
# Capability 3 — Agent boundary
# ---------------------------------------------------------------------------


class _AgentBoundary(AgentBoundary):
    """Build a per-run ``BetaAsyncToolRunner`` and execute it.

    The "agent" parameter for Anthropic is the async client; per-run
    parameters (``tools``, ``model``, ``system``) ride in via kwargs
    set by :class:`GuardedRunner`.
    """

    async def run(
        self, agent: Any, input_text: str, **kwargs: Any,
    ) -> Any:
        from anthropic.lib.tools import BetaAsyncToolRunner

        client = agent
        tools = kwargs.pop("tools", None) or []
        model = kwargs.pop("model", "claude-sonnet-4-20250514")
        system = kwargs.pop("system", None)

        runner_kwargs: dict[str, Any] = {
            "client": client,
            "model": model,
            "tools": tools,
            "messages": [{"role": "user", "content": input_text}],
        }
        if system:
            runner_kwargs["system"] = system
        if "max_tokens" not in kwargs:
            kwargs["max_tokens"] = 4096
        runner_kwargs.update(kwargs)
        runner = BetaAsyncToolRunner(**runner_kwargs)
        return await runner.get_final_message()

    def extract_output(self, result: Any) -> Optional[str]:
        return _extract_text(result)

    def apply_redaction(self, result: Any, redacted_text: str) -> Any:
        return _RedactedResult(result, redacted_text)

    def make_blocked(self, message: str) -> Any:
        return _BlockedResult(message)


def _extract_text(message: Any) -> str:
    """Concatenate text blocks from an Anthropic ``Message``."""
    if not hasattr(message, "content"):
        return str(message)
    parts: list[str] = []
    for block in message.content:
        if hasattr(block, "text"):
            parts.append(block.text)
    return "".join(parts)


class _BlockedResult:
    """Stand-in for a ``Message`` when input/output is blocked."""

    def __init__(self, message: str) -> None:
        self.final_output = message

    def __repr__(self) -> str:
        return f"BlockedResult({self.final_output!r})"


class _RedactedResult:
    """Wraps an Anthropic ``Message`` with redacted text output."""

    def __init__(self, original: Any, redacted_text: str) -> None:
        self._original = original
        self.final_output = redacted_text

    def __getattr__(self, name: str) -> Any:
        return getattr(self._original, name)

    def __repr__(self) -> str:
        return f"RedactedResult({self.final_output!r})"


# ---------------------------------------------------------------------------
# Capability 4 — Streaming adapter
# ---------------------------------------------------------------------------


class _StreamingAdapter(StreamingAdapter):
    """Anthropic streaming via ``get_final_message`` push.

    The Anthropic tool-runner returns a complete message rather than a
    token stream, so the "stream" is a single push of the final
    message's text through the validator. Adapters that move to true
    SSE streaming can revisit this once the framework exposes it.
    """

    async def stream(
        self,
        agent: Any,
        input_text: str,
        validator: StreamingValidator,
        **kwargs: Any,
    ) -> AsyncIterator[Any]:
        from anthropic.lib.tools import BetaAsyncToolRunner

        client = agent
        tools = kwargs.pop("tools", None) or []
        model = kwargs.pop("model", "claude-sonnet-4-20250514")
        system = kwargs.pop("system", None)

        runner_kwargs: dict[str, Any] = {
            "client": client,
            "model": model,
            "tools": tools,
            "messages": [{"role": "user", "content": input_text}],
        }
        if system:
            runner_kwargs["system"] = system
        if "max_tokens" not in kwargs:
            kwargs["max_tokens"] = 4096
        runner_kwargs.update(kwargs)
        runner = BetaAsyncToolRunner(**runner_kwargs)
        final = await runner.get_final_message()
        text = _extract_text(final)

        result = validator.push(text)
        if result.payload:
            yield result.payload
        if result.stopped:
            yield validator.make_blocked(
                result.reason or "Stage 5 streaming guard stopped the stream.",
            )
            return
        tail = validator.finish()
        if tail.stopped:
            yield validator.make_blocked(
                tail.reason or "Stage 5 streaming guard stopped the stream.",
            )
            return
        if tail.payload:
            yield tail.payload


# ---------------------------------------------------------------------------
# Bundle
# ---------------------------------------------------------------------------


class GuardedRunner(_GenericGuardedRunner):
    """Anthropic-named guarded runner with stateful per-run defaults.

    Holds the Anthropic client plus default ``tools`` / ``model`` /
    ``system``; each ``run()`` call may override them. The orchestrator
    framework runs the boundary's ``run()`` which builds and drives the
    underlying ``BetaAsyncToolRunner``.
    """

    def __init__(
        self,
        runtime: Runtime,
        client: Any,
        boundary: AgentBoundary,
        streaming: Optional[StreamingAdapter] = None,
        *,
        tools: list | None = None,
        model: str = "claude-sonnet-4-20250514",
        system: str | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(runtime, client, boundary, streaming, **kwargs)
        self._default_tools = tools or []
        self._default_model = model
        self._default_system = system

    @property
    def client(self) -> Any:
        return self._agent

    async def run(  # type: ignore[override]
        self,
        input_text: str,
        *,
        session: Session | None = None,
        tools: list | None = None,
        model: str | None = None,
        system: str | None = None,
        **kwargs: Any,
    ) -> Any:
        """Run with Stage 1 + Stage 5 enforcement."""
        return await super().run(
            input_text,
            session=session,
            tools=tools if tools is not None else self._default_tools,
            model=model or self._default_model,
            system=system if system is not None else self._default_system,
            **kwargs,
        )

    async def run_streamed(  # type: ignore[override]
        self,
        input_text: str,
        *,
        session: Session | None = None,
        tools: list | None = None,
        model: str | None = None,
        system: str | None = None,
        **kwargs: Any,
    ):
        """Stream with Stage 1 + Stage 5 enforcement."""
        async for emission in super().run_streamed(
            input_text,
            session=session,
            tools=tools if tools is not None else self._default_tools,
            model=model or self._default_model,
            system=system if system is not None else self._default_system,
            **kwargs,
        ):
            yield emission


_BUNDLE = FrameworkBundle(
    name="anthropic_agents",
    llm_caller_factory=_LlmCallerFactory(),
    tool_wrapper=_ToolWrapper(),
    agent_boundary=_AgentBoundary(),
    streaming_adapter=_StreamingAdapter(),
    capabilities=CapabilityReport(
        framework="anthropic_agents",
        # Anthropic's tool runner only exposes complete messages — true
        # token streaming is partial through this adapter.
        streaming_output=CoverageLevel.PARTIAL,
        notes=["streaming yields the full final message in one chunk"],
    ),
    guarded_runner_cls=GuardedRunner,
)


# ---------------------------------------------------------------------------
# Composition pattern — install with_anthropic_agents() and
# create_anthropic_agents_agent() at import time.
# ---------------------------------------------------------------------------


def _install() -> None:
    """Monkey-install :meth:`ShieldBuilder.with_anthropic_agents` and
    :meth:`Shield.create_anthropic_agents_agent`."""

    def with_anthropic_agents(self: ShieldBuilder) -> ShieldBuilder:
        """Bind this builder to the Anthropic Agents framework bundle."""
        return self._bind_to_bundle(_BUNDLE)

    def create_anthropic_agents_agent(
        self: Shield,
        tools: list,
        *,
        model: str,
        client: Any = None,
        system_prompt: str = "",
    ) -> Any:
        """Build a fully guarded Anthropic tool runner in one call (Pattern A).

        ``model`` is the *customer agent's* model — the Claude SKU that
        drives the agent's own reasoning loop. It is **required**: a
        security library MUST NOT pick a model on the customer's
        behalf. Note: composes through :meth:`Shield.protect_tools` and
        constructs the underlying client-bound runner. The Anthropic
        client must be supplied here or via ``with_client(...)``.
        """
        protected = self.protect_tools(tools)
        c = client if client is not None else self._client
        if c is None:
            raise ValueError(
                "create_anthropic_agents_agent requires an Anthropic client; "
                "pass client=... or set one via with_client(...)."
            )
        return self.guard(
            c,
            tools=protected,
            model=model,
            system=system_prompt,
        )

    setattr(ShieldBuilder, "with_anthropic_agents", with_anthropic_agents)
    setattr(
        Shield,
        "create_anthropic_agents_agent",
        create_anthropic_agents_agent,
    )


_install()

# Register this bundle as the auto-bind default for new ShieldBuilder instances.
from . import _bundle_registry as _registry  # noqa: E402
_registry.register(_BUNDLE)


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


def make_llm_caller(
    client: Any,
    configuration_resolver: Optional[
        Callable[[Optional[str]], Optional[dict]]
    ] = None,
) -> Callable[[Optional[str], str], str]:
    """Create an LLM caller from an Anthropic client.

    Module-level shortcut for :meth:`_LlmCallerFactory.make_caller`.
    Pass ``configuration_resolver=runtime.llm_configuration`` to honour
    the YAML's per-stage ``model:`` / ``max_tokens:`` selection. When
    the resolver returns a configuration without ``model:`` (or no
    matching entry at all) the caller raises
    :class:`ConfigurationMissingModelError`. Missing ``max_tokens:``
    falls back to :attr:`_LlmCallerFactory.DEFAULT_FALLBACK_MAX_TOKENS`
    (1024) — the token budget is not security-sensitive, unlike model
    selection, so defaulting it is acceptable.
    """
    return _BUNDLE.llm_caller_factory.make_caller(
        client, configuration_resolver=configuration_resolver,
    )


def protect_tools(
    runtime: Runtime,
    tools: list,
    user_input_getter: Optional[Callable[[], str]] = None,
) -> list:
    """Wrap Anthropic tools with Stages 2 + 3 + 4 enforcement."""
    return _protect_tools_via_wrapper(
        runtime, tools, _BUNDLE.tool_wrapper, user_input_getter,
    )


__all__ = [
    "GuardedRunner",
    "make_llm_caller",
    "protect_tools",
]
