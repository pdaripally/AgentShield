"""Shared orchestration helpers for the framework adapters.

These functions encapsulate the common Stage 1→5 and Stage 2→3→4
validation flows for the unified-resolver runtime
(:mod:`agent_shield`).  Framework-specific adapters supply hooks
for input/output extraction and blocked response formatting.

The helpers:

* Call :meth:`Session.begin_turn` / :meth:`Session.end_turn` around
  every guarded turn so the runtime sees turn boundaries.
* Use the verdict shapes (:class:`StageVerdict` /
  :class:`ToolCallOutcome` / :class:`ToolOutputOutcome`).
* Record tool results via :meth:`Session.record_tool_success` /
  :meth:`Session.record_tool_failure`.

Verdict-handling decisions (block message formatting, "what should the
orchestrator do for this verdict") are delegated to
:func:`agent_shield._native.dispatch_stage_verdict` and
:func:`agent_shield._native.dispatch_tool_verdict`. Those are the
canonical, byte-equivalent decisions every SDK shares; only the
async wiring (begin_turn → execute → end_turn / record_tool_*) lives
here.
"""
from __future__ import annotations

import contextvars
import logging
import uuid
from typing import Any, Awaitable, Callable, Optional

from agent_shield._native import (
    dispatch_stage_verdict as _native_dispatch_stage,
    dispatch_tool_verdict as _native_dispatch_tool,
    format_block_message as _native_format_block_message,
)

from ._capabilities import AdapterStageMutationError

logger = logging.getLogger("agent_shield")


# ---------------------------------------------------------------------------
# Per-turn ContextVars — set by guarded_turn, read by guarded_tool
# ---------------------------------------------------------------------------

current_session: contextvars.ContextVar = contextvars.ContextVar(
    "guardrail_session", default=None,
)
current_user_input: contextvars.ContextVar[str] = contextvars.ContextVar(
    "guardrail_user_input", default="",
)


# ---------------------------------------------------------------------------
# Verdict ↔ wire-shape bridge + canonical dispatch helpers
# ---------------------------------------------------------------------------

def _verdict_to_wire(verdict: Any) -> dict:
    """Convert a :class:`StageVerdict` dataclass to the canonical wire dict.

    Field names match the wire shape exactly so this is a 1:1 projection.
    Used as the input to the core dispatch FFI.
    """
    return {
        "allowed": getattr(verdict, "allowed", False),
        "action": getattr(verdict, "action", None),
        "reason": getattr(verdict, "reason", None),
        "policy": getattr(verdict, "policy", None),
        "evaluate_when_index": getattr(verdict, "evaluate_when_index", None),
        "bypassed_by_allowed_when": getattr(
            verdict, "bypassed_by_allowed_when", False,
        ),
        "redaction": getattr(verdict, "redaction", None),
        "appended": getattr(verdict, "appended", None),
        "prepended": getattr(verdict, "prepended", None),
    }


def _format_block_message(verdict: Any, *, prefix: str = "GUARDRAIL") -> str:
    """Build the canonical ``[GUARDRAIL ACTION] reason`` string.

    Thin bridge over :func:`agent_shield._native.format_block_message`
    so every SDK produces byte-equivalent strings. The ``prefix``
    parameter is preserved for back-compat but the canonical core
    formatter always emits ``GUARDRAIL``; non-default prefixes are
    rewritten on the result string.
    """
    msg = _native_format_block_message(_verdict_to_wire(verdict))
    if prefix != "GUARDRAIL" and msg.startswith("[GUARDRAIL "):
        msg = "[" + prefix + msg[len("[GUARDRAIL"):]
    return msg


def _dispatch_stage(
    verdict: Any,
    policy: str = "return_blocked",
    mode: str = "enforce",
) -> dict:
    """Canonical Stage 1 / Stage 5 verdict-handling decision.

    Returns the raw dict from the core dispatcher: ``{action: {kind,
    value?, message?}, record_block, override_to_proceed}``. Callers
    branch on ``action.kind`` to decide what to do.
    """
    return _native_dispatch_stage(_verdict_to_wire(verdict), policy, mode)


def _dispatch_tool(
    verdict: Any,
    tool_name: str,
    stage: str = "output",
    policy: str = "return_blocked",
    mode: str = "enforce",
) -> dict:
    """Canonical Stage 2/3/4 (tool-call) verdict-handling decision."""
    return _native_dispatch_tool(
        _verdict_to_wire(verdict), tool_name, stage, policy, mode,
    )


# ---------------------------------------------------------------------------
# guarded_turn — Stage 1 → execute → Stage 5 (with begin/end_turn)
# ---------------------------------------------------------------------------

async def guarded_turn(
    session: Any,
    user_input: str,
    execute: Callable[[], Awaitable[Any]],
    extract_output: Callable[[Any], Optional[str]],
    apply_redaction: Callable[[Any, str], Any],
    make_blocked: Callable[[str], Any],
) -> Any:
    """Execute a full guarded agent turn through the runtime.

    Order of operations::

        begin_turn()
            Stage 1 — validate_input(user_input)
            execute()
            Stage 5 — validate_output(extract_output(result))
        end_turn()

    The Stage 1 / Stage 5 decision (block vs proceed vs
    proceed-with-mutation) is delegated to the canonical core
    dispatcher; only the async wiring lives here.

    Args:
        session: A :class:`~agent_shield.Session`.
        user_input: The user's input text.
        execute: Async callable that runs the framework agent.
        extract_output: Extracts final text from the framework result.
        apply_redaction: Returns a modified result with redacted output.
        make_blocked: Creates a blocked response from a reason string.
    """
    session.begin_turn()
    try:
        # Stage 1
        verdict = session.validate_input(user_input or "")
        decision = _dispatch_stage(verdict)
        action = decision["action"]
        kind = action["kind"]
        if kind == "return_blocked":
            logger.warning(
                "[Stage 1] Input blocked (%s): %s",
                verdict.action, verdict.reason,
            )
            return make_blocked(action["message"])
        # Stage 1 has no mutation surface in the Python adapters, so a
        # `proceed_with_mutation` here would only fire on a future
        # `redact`-on-input rule. Fall through to proceed in that case;
        # the input is forwarded as-is because adapters don't expose
        # an "input mutator" hook.

        # Set context for tool closures
        session_token = current_session.set(session)
        input_token = current_user_input.set(user_input or "")
        try:
            result = await execute()
        finally:
            current_user_input.reset(input_token)
            current_session.reset(session_token)

        # Stage 5
        output_text = extract_output(result)
        if output_text and isinstance(output_text, str):
            outcome = session.validate_output(output_text)
            stage5 = _dispatch_stage(outcome.verdict)
            stage5_action = stage5["action"]
            stage5_kind = stage5_action["kind"]
            if stage5_kind == "return_blocked":
                logger.warning(
                    "[Stage 5] Output blocked: %s", outcome.verdict.reason,
                )
                return make_blocked(stage5_action["message"])
            if stage5_kind == "proceed_with_mutation":
                logger.info("[Stage 5] Output redacted before delivery")
                # Trust the runtime's `outcome.response` (the canonical
                # post-Stage-5 string) for the actual mutation; the
                # dispatcher's `value` is identical but extracted from
                # the verdict's redaction/appended/prepended field.
                result = apply_redaction(result, outcome.response)

        return result
    finally:
        try:
            session.end_turn()
        except Exception:  # noqa: BLE001 — best-effort end-of-turn
            logger.debug("end_turn() raised; ignoring", exc_info=True)


# ---------------------------------------------------------------------------
# Tool-call helpers — shared by sync and async paths
# ---------------------------------------------------------------------------

def _resolve_session(
    session: Any,
    runtime: Any,
    tool_name: str,
    create_warning: bool = True,
) -> Any:
    """Pick the session to use for a tool invocation.

    Resolution order:
    1. Explicit ``session`` parameter
    2. Ambient session from :data:`current_session` (set by :func:`guarded_turn`)
    3. Fresh session from ``runtime.new_session()`` (with warning)
    """
    if session is not None:
        return session
    sess = current_session.get(None)
    if sess is not None:
        return sess
    if runtime is None:
        raise RuntimeError(
            "guarded_tool requires a session (pass session= or runtime=, "
            "or call from within guarded_turn)"
        )
    if create_warning:
        logger.warning(
            "Tool '%s' invoked without ambient session — creating fresh "
            "session. State-dependent guardrails may not see prior context.",
            tool_name,
        )
    return runtime.new_session()


def _clean_params(params: Optional[dict]) -> dict:
    """Strip ``None`` values from params before validation.

    ``None`` entries can confuse the Stage 3 adversarial detector into
    flagging missing required inputs as parameter integrity issues.
    """
    if not params:
        return {}
    return {k: v for k, v in params.items() if v is not None}


def _execute_accepts_params(execute: Callable[..., Any]) -> bool:
    """Return ``True`` if ``execute`` accepts at least one positional arg.

    Falls back to ``False`` when the signature can't be inspected
    (e.g. some C-implemented callables) — preserves the legacy zero-arg
    behaviour for old callers.
    """
    import inspect

    try:
        sig = inspect.signature(execute)
    except (TypeError, ValueError):
        return False
    for p in sig.parameters.values():
        if p.kind in (
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            inspect.Parameter.VAR_POSITIONAL,
        ):
            return True
    return False


async def _invoke_execute(
    execute: Callable[..., Awaitable[Any]],
    effective_params: dict,
) -> Any:
    """Call ``execute`` with the Stage-3 *effective_params* if accepted.

    P12.5.3: framework adapters that pass a one-arg callable get the
    transformed params; legacy zero-arg callables keep working but
    forfeit Stage-3 transforms (only the orchestration helper itself
    can decide whether to pass them through).
    """
    if _execute_accepts_params(execute):
        return await execute(effective_params)
    return await execute()


def _invoke_execute_sync(
    execute: Callable[..., Any],
    effective_params: dict,
) -> Any:
    """Sync counterpart of :func:`_invoke_execute`."""
    if _execute_accepts_params(execute):
        return execute(effective_params)
    return execute()


def _adapter_mutation_block(
    tool_name: str, exc: AdapterStageMutationError,
) -> tuple[bool, str]:
    """Build the canonical block message for an adapter Stage-3 failure.

    Used when an adapter cannot honour Stage-3 ``redact`` / ``replace``
    transforms (e.g. it cannot mutate the framework's parameter
    container). Treated as a fail-closed Stage-3 block so a tool whose
    Stage-3 transform failed never runs with the un-transformed params.
    """
    reason = (
        f"Stage-3 transform failed for tool {tool_name}: {exc.cause}"
    )
    logger.warning(
        "[GUARDRAIL BLOCK] Tool '%s' blocked: %s", tool_name, reason,
    )
    verdict_wire = {
        "allowed": False,
        "action": "block",
        "reason": reason,
        "policy": None,
        "evaluate_when_index": None,
        "bypassed_by_allowed_when": False,
        "redaction": None,
        "appended": None,
        "prepended": None,
    }
    message = _native_format_block_message(verdict_wire)
    return True, message


async def guarded_tool(
    tool_name: str,
    params: dict,
    execute: Callable[..., Awaitable[Any]],
    user_input: str = "",
    *,
    session: Any = None,
    runtime: Any = None,
    tool_call_id: str | None = None,
) -> tuple[bool, str]:
    """Execute a guarded tool call through the runtime (async).

    Pipeline::

        Stage 2+3 — validate_tool_call(tool, params)
        execute(effective_params)
        Stage 4   — validate_tool_output(tool, output)
        record_tool_success / record_tool_failure

    The Stage 2/3/4 verdict-handling decision is delegated to the
    canonical :func:`agent_shield._native.dispatch_tool_verdict`; only
    the async wiring (executing the tool, recording resource-cycle
    events) lives here.

    *tool_call_id* — optional §16.0 binding handle. When passed,
    Stage 4 uses it to find the SAME canonical invocation Stage 3
    admitted, even under concurrent same-name calls. Adapters should
    pass the upstream model's tool-call id (OpenAI ``tool_call.id``,
    Anthropic ``tool_use.id``, LangChain ``tool_call_id``, etc.).
    Omitting the id mints a per-call UUIDv4; a stable model-supplied
    id is preferred where available so traces and incidents can be
    correlated end-to-end.

    Returns:
        ``(blocked, output)`` — when *blocked* is ``True`` the *output*
        is the block message that should be surfaced to the LLM agent.
    """
    sess = _resolve_session(session, runtime, tool_name)
    if not user_input:
        user_input = current_user_input.get("")

    cleaned = _clean_params(params)
    bound_id = tool_call_id or uuid.uuid4().hex

    # Stage 2 + 3
    call_outcome = sess.validate_tool_call(tool_name, cleaned, tool_call_id=bound_id)
    call_decision = _dispatch_tool(call_outcome.verdict, tool_name, stage="call")
    call_action = call_decision["action"]
    if call_action["kind"] == "blocked":
        verdict = call_outcome.verdict
        logger.warning(
            "[GUARDRAIL %s] Tool '%s' %sed: %s",
            (verdict.action or "block").upper(),
            tool_name,
            verdict.action or "block",
            verdict.reason,
        )
        return True, call_action["message"]

    # Use any mutated params produced by Stage 3 (e.g. coerced types).
    effective_params = (
        call_outcome.params if call_outcome.params is not None else cleaned
    )

    # Execute the underlying tool.
    try:
        raw_output = await _invoke_execute(execute, effective_params)
    except AdapterStageMutationError as ame:
        # The adapter could not apply Stage-3 param transforms; treat
        # as a fail-closed Stage-3 block. The tool did NOT run, so we
        # deliberately skip Stage 4 and do not record success/failure
        # on the resource cycle.
        return _adapter_mutation_block(tool_name, ame)
    except Exception as exc:  # noqa: BLE001 — bubble up via Stage 4
        logger.warning("Tool '%s' raised: %s", tool_name, exc)
        error_text = f"[tool error] {tool_name}: {exc}"
        try:
            sess.record_tool_failure(tool_name, str(exc))
        except Exception:  # noqa: BLE001
            logger.debug("record_tool_failure raised", exc_info=True)
        out_outcome = sess.validate_tool_output(
            tool_name, error_text, tool_call_id=bound_id,
        )
        # Stage 4 over the error text. Use the bare-stage dispatcher so
        # the tool-name suffix doesn't appear twice on the inner block
        # message (we already include the tool in the error_text).
        err_decision = _dispatch_stage(out_outcome.verdict)
        if err_decision["action"]["kind"] == "return_blocked":
            return True, err_decision["action"]["message"]
        return False, str(out_outcome.result)

    # Stage 4
    output_str = str(raw_output) if not isinstance(raw_output, str) else raw_output
    out_outcome = sess.validate_tool_output(
        tool_name, output_str, tool_call_id=bound_id,
    )
    out_decision = _dispatch_tool(out_outcome.verdict, tool_name, stage="output")
    out_action = out_decision["action"]
    if out_action["kind"] == "blocked":
        if out_decision["record_failure"]:
            try:
                sess.record_tool_failure(
                    tool_name, out_outcome.verdict.reason or "blocked",
                )
            except Exception:  # noqa: BLE001
                logger.debug("record_tool_failure raised", exc_info=True)
        return True, out_action["message"]

    # Stage 4 may have redacted the result.  Use whichever shape Stage 4
    # produced and record a success on the resource cycle.
    final = out_outcome.result if out_outcome.result is not None else output_str
    final_str = final if isinstance(final, str) else str(final)
    if out_decision["record_success"]:
        try:
            sess.record_tool_success(tool_name, final_str)
        except Exception:  # noqa: BLE001
            logger.debug("record_tool_success raised", exc_info=True)
    return False, final_str


def guarded_tool_sync(
    tool_name: str,
    params: dict,
    execute: Callable[[], Any],
    user_input: str = "",
    *,
    session: Any = None,
    runtime: Any = None,
    tool_call_id: str | None = None,
) -> tuple[bool, str]:
    """Synchronous variant of :func:`guarded_tool` for sync-only frameworks.

    Same session resolution and pipeline as :func:`guarded_tool`. See
    :func:`guarded_tool` for the *tool_call_id* parameter (§16.0
    binding).

    Returns:
        ``(blocked, output)`` — when *blocked* is ``True`` the *output*
        is the block message.
    """
    sess = _resolve_session(session, runtime, tool_name)
    if not user_input:
        user_input = current_user_input.get("")

    cleaned = _clean_params(params)
    bound_id = tool_call_id or uuid.uuid4().hex

    # Stage 2 + 3
    call_outcome = sess.validate_tool_call(tool_name, cleaned, tool_call_id=bound_id)
    call_decision = _dispatch_tool(call_outcome.verdict, tool_name, stage="call")
    call_action = call_decision["action"]
    if call_action["kind"] == "blocked":
        verdict = call_outcome.verdict
        logger.warning(
            "[GUARDRAIL %s] Tool '%s' %sed: %s",
            (verdict.action or "block").upper(),
            tool_name,
            verdict.action or "block",
            verdict.reason,
        )
        return True, call_action["message"]

    # P12.5.3: pass Stage-3 mutated params through to the framework
    # execute so redact/replace transforms reach the tool.
    effective_params = (
        call_outcome.params if call_outcome.params is not None else cleaned
    )

    # Execute the underlying tool.
    try:
        raw_output = _invoke_execute_sync(execute, effective_params)
    except AdapterStageMutationError as ame:
        # Fail-closed Stage-3 block — see guarded_tool() for rationale.
        return _adapter_mutation_block(tool_name, ame)
    except Exception as exc:  # noqa: BLE001
        logger.warning("Tool '%s' raised: %s", tool_name, exc)
        error_text = f"[tool error] {tool_name}: {exc}"
        try:
            sess.record_tool_failure(tool_name, str(exc))
        except Exception:  # noqa: BLE001
            logger.debug("record_tool_failure raised", exc_info=True)
        out_outcome = sess.validate_tool_output(
            tool_name, error_text, tool_call_id=bound_id,
        )
        err_decision = _dispatch_stage(out_outcome.verdict)
        if err_decision["action"]["kind"] == "return_blocked":
            return True, err_decision["action"]["message"]
        return False, str(out_outcome.result)

    output_str = str(raw_output) if not isinstance(raw_output, str) else raw_output
    out_outcome = sess.validate_tool_output(
        tool_name, output_str, tool_call_id=bound_id,
    )
    out_decision = _dispatch_tool(out_outcome.verdict, tool_name, stage="output")
    out_action = out_decision["action"]
    if out_action["kind"] == "blocked":
        if out_decision["record_failure"]:
            try:
                sess.record_tool_failure(
                    tool_name, out_outcome.verdict.reason or "blocked",
                )
            except Exception:  # noqa: BLE001
                logger.debug("record_tool_failure raised", exc_info=True)
        return True, out_action["message"]

    final = out_outcome.result if out_outcome.result is not None else output_str
    final_str = final if isinstance(final, str) else str(final)
    if out_decision["record_success"]:
        try:
            sess.record_tool_success(tool_name, final_str)
        except Exception:  # noqa: BLE001
            logger.debug("record_tool_success raised", exc_info=True)
    return False, final_str


# ---------------------------------------------------------------------------
# Stage 1 helper — pre-invoke check for adapters that don't run a full turn
# ---------------------------------------------------------------------------

def check_stage1(session: Any, user_input: Optional[str]) -> Optional[str]:
    """Run Stage 1 input validation only.

    Returns the formatted block message, or ``None`` when the input is
    allowed.  Designed for adapters whose ``before_invoke`` hook needs
    a yes/no answer ahead of the framework call.
    """
    if not user_input:
        return None
    verdict = session.validate_input(user_input)
    decision = _dispatch_stage(verdict)
    action = decision["action"]
    if action["kind"] == "return_blocked":
        return action["message"]
    return None


__all__ = [
    "current_session",
    "current_user_input",
    "guarded_turn",
    "guarded_tool",
    "guarded_tool_sync",
    "check_stage1",
]
