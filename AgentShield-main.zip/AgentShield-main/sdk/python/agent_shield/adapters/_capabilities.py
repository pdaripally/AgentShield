"""Capability interfaces that frameworks plug into.

The framework-agnostic ``Shield`` orchestrator (see :mod:`._shield`) drives
every guarded turn through these four capabilities. Each per-framework
adapter (``openai_agents``, ``langchain``, ``autogen``, ``crewai``,
``semantic_kernel``, ``anthropic_agents``) provides a ``FrameworkBundle``
that fills in the four capability implementations and is otherwise
indistinguishable from any other framework to the orchestrator.

The four capabilities cover what genuinely differs between frameworks:

* :class:`LlmCallerFactory` — turns a framework client into the runtime's
  ``(configuration_id, prompt) -> str`` shape.
* :class:`ToolWrapper` — extracts tool metadata from a framework tool
  object and rebuilds it after the orchestrator wraps the invocation.
* :class:`AgentBoundary` — extracts/redacts/re-packages the framework's
  agent run result so Stage 1 and Stage 5 can fire around the run.
* :class:`StreamingAdapter` — translates framework-specific streaming
  chunks into plain text for windowed Stage 5 enforcement.

Everything else — session resolution, stage sequencing, ``begin_turn`` /
``end_turn``, record_tool_success / record_tool_failure, on_block
policy, monitor mode — lives in :mod:`._shield` and is shared.

Capability reports
------------------

Frameworks may not expose every lifecycle stage. ``CapabilityReport``
makes the protection actually delivered by an adapter visible to the
customer at construction time, so "one-line integration" cannot silently
hide a 2-of-5 protection profile.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import (
    Any,
    AsyncIterator,
    Awaitable,
    Callable,
    List,
    Optional,
    Protocol,
    runtime_checkable,
)


# ---------------------------------------------------------------------------
# Tool metadata (framework-neutral shape)
# ---------------------------------------------------------------------------


@dataclass
class ToolMetadata:
    """Framework-neutral description of a tool.

    Adapters extract this from their framework's tool object so the
    orchestrator can describe the tool to the runtime (Stage 2/3) and so
    the wrapped tool keeps its original surface.
    """

    name: str
    description: str = ""
    params_schema: dict = field(default_factory=dict)
    extras: dict = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Coverage / capability reporting
# ---------------------------------------------------------------------------


class CoverageLevel(str, Enum):
    """How thoroughly a stage is covered by an adapter."""

    FULL = "full"
    PARTIAL = "partial"
    UNSUPPORTED = "unsupported"


@dataclass
class CapabilityReport:
    """Per-stage protection profile for a framework adapter.

    Surfaced from :attr:`Shield.capabilities` so callers can audit what
    an adapter actually protects without reading the source. The fields
    map 1:1 to the five-stage validation model.
    """

    framework: str
    input_validation: CoverageLevel = CoverageLevel.FULL
    state_validation: CoverageLevel = CoverageLevel.FULL
    tool_authorization: CoverageLevel = CoverageLevel.FULL
    tool_execution_validation: CoverageLevel = CoverageLevel.FULL
    tool_output_validation: CoverageLevel = CoverageLevel.FULL
    output_validation: CoverageLevel = CoverageLevel.FULL
    streaming_output: CoverageLevel = CoverageLevel.FULL
    notes: List[str] = field(default_factory=list)

    def is_full_coverage(self) -> bool:
        """True iff every stage is covered."""
        return all(
            getattr(self, f) is CoverageLevel.FULL
            for f in (
                "input_validation",
                "state_validation",
                "tool_authorization",
                "tool_execution_validation",
                "tool_output_validation",
                "output_validation",
                "streaming_output",
            )
        )


# ---------------------------------------------------------------------------
# Capability 1 — LLM caller factory (Stage-2/3/4 LLM dispatch)
# ---------------------------------------------------------------------------


@runtime_checkable
class LlmCallerFactory(Protocol):
    """Adapts a framework's LLM client to the runtime's caller shape.

    The Rust validation engine invokes LLM callers synchronously with
    the signature ``(configuration_id: Optional[str], prompt: str) -> str``.
    Frameworks vary in:

    * client class (sync vs async, model selection, base URL handling),
    * how to extract response text,
    * deadlock-avoidance when running on an event loop.

    Each framework's factory encapsulates that translation. When the
    optional ``configuration_resolver`` is supplied, the produced caller
    SHOULD use it to look up the ``configurations[]`` entry that the
    YAML routed this LLM call through, so per-stage ``model:`` /
    ``provider:`` / ``max_tokens:`` selection is honoured rather than
    silently hard-coded. The resolver takes a configuration id and
    returns a dict mirroring :meth:`Runtime.llm_configuration`, or
    ``None`` when no matching ``type: llm`` entry exists.
    """

    def make_caller(
        self,
        client: Any,
        configuration_resolver: Optional[
            Callable[[Optional[str]], Optional[dict]]
        ] = None,
    ) -> Callable[[Optional[str], str], str]:
        """Return a sync caller that the runtime can invoke."""
        ...


# ---------------------------------------------------------------------------
# Capability 2 — Tool wrapping (Stages 2 + 3 + 4)
# ---------------------------------------------------------------------------

GuardedInvoke = Callable[[dict, str], Awaitable[str]]
"""``(params, user_input) -> output_text`` — wired by the orchestrator.

The orchestrator runs Stage 2/3 on ``params``, calls the underlying tool
with the (possibly mutated) effective params, runs Stage 4 on the output,
records success or failure, and returns the final text.
"""


@runtime_checkable
class ToolWrapper(Protocol):
    """Extracts framework tool metadata, invokes originals, and wraps guarded calls.

    Stage 2/3/4 enforcement happens in the orchestrator. The wrapper's
    job is the framework-specific shape translation in three steps:

    * :meth:`extract` — pull ``(name, description, schema)`` out of the
      framework's tool object.
    * :meth:`invoke` — call the original framework tool with the
      (Stage-3-mutated) effective params and return its result. This
      isolates framework calling conventions (LangChain spreads kwargs;
      OpenAI takes a JSON envelope; SK uses ``invoke_async``; etc.) so
      the orchestrator never has to know about them.
    * :meth:`wrap` — produce a new framework tool whose body calls the
      orchestrator-provided ``guarded_invoke``, repackaging the
      framework's native call shape into the canonical
      ``(params, user_input) -> output_text`` signature.
    """

    def extract(self, tool: Any) -> ToolMetadata:
        """Return the framework-neutral metadata for ``tool``."""
        ...

    async def invoke(self, original: Any, params: dict) -> Any:
        """Invoke the framework's original tool with effective params."""
        ...

    def wrap(
        self,
        original: Any,
        metadata: ToolMetadata,
        guarded_invoke: GuardedInvoke,
    ) -> Any:
        """Build a framework tool whose body calls ``guarded_invoke``."""
        ...


# ---------------------------------------------------------------------------
# Capability 3 — Agent boundary (Stages 1 + 5 around an agent run)
# ---------------------------------------------------------------------------


@runtime_checkable
class AgentBoundary(Protocol):
    """Wraps the framework's agent run with Stage 1 + Stage 5.

    The orchestrator owns the stage sequencing (validate_input →
    execute → validate_output, with begin_turn/end_turn around it). The
    boundary owns the framework-specific bits the orchestrator cannot
    know:

    * how to invoke the framework's agent (``run``),
    * how to extract the final output text from the framework's result
      shape (``extract_output``),
    * how to splice a redacted output back into the framework's result
      shape (``apply_redaction``),
    * how to express "blocked" in the framework's result shape
      (``make_blocked``).
    """

    async def run(
        self, agent: Any, input_text: str, **kwargs: Any,
    ) -> Any:
        """Execute the framework agent and return its native result."""
        ...

    def extract_output(self, result: Any) -> Optional[str]:
        """Pull the final output text from the framework's result."""
        ...

    def apply_redaction(self, result: Any, redacted_text: str) -> Any:
        """Return ``result`` with its final output replaced by
        ``redacted_text``. May mutate in place and return ``result``."""
        ...

    def make_blocked(self, message: str) -> Any:
        """Build a framework-shaped result representing a block."""
        ...


# ---------------------------------------------------------------------------
# Capability 4 — Streaming adapter (framework-specific stream loop)
# ---------------------------------------------------------------------------


@runtime_checkable
class StreamingValidator(Protocol):
    """Helper passed to :meth:`StreamingAdapter.stream`.

    The orchestrator owns the underlying ``Session.streaming_session``
    pipeline; the validator exposes the operations the adapter needs to
    perform Stage-5 windowed enforcement without managing the session
    directly.
    """

    @property
    def mode(self) -> str:
        """Validation cadence configured on the underlying guard:
        ``"on_complete"`` / ``"windowed"`` / ``"per_chunk"``. Adapters
        SHOULD gate emission scheduling on this:

        - ``on_complete`` — buffer every text-bearing chunk through the
          guard and emit ONLY the final validated payload returned by
          :meth:`finish`. No text-bearing chunks reach the consumer
          before that.
        - ``per_chunk`` / ``windowed`` — emit validated chunks in real
          time.
        """
        ...

    def push(self, text: str) -> "StreamingPushResult":
        """Feed a chunk of text into the streaming guard."""
        ...

    def finish(self) -> "StreamingPushResult":
        """Drain the guard and return any tail safe payload."""
        ...

    def make_blocked(self, message: str) -> Any:
        """Build a framework-shaped result expressing a block (delegates
        to :meth:`AgentBoundary.make_blocked`)."""
        ...

    def apply_redaction(self, framework_chunk: Any, text: str) -> Any:
        """Splice safe text into a framework-shaped chunk (delegates to
        :meth:`AgentBoundary.apply_redaction`)."""
        ...


@dataclass
class StreamingPushResult:
    """Result of pushing text into a streaming validator."""

    payload: Optional[str]
    stopped: bool
    reason: Optional[str]


@runtime_checkable
class StreamingAdapter(Protocol):
    """Drives the framework's streaming loop with Stage-5 validation.

    Streaming flow control is genuinely framework-specific — some
    frameworks yield per-chunk text deltas, others buffer and emit a
    single final response, others use AsyncIterator of typed events.
    The orchestrator owns the safety primitives (windowing, blocking,
    redaction) and exposes them through :class:`StreamingValidator`;
    the adapter writes the loop in whatever shape its framework
    consumes.

    Adapters whose framework does not stream may set
    :attr:`FrameworkBundle.streaming_adapter` to ``None`` and reflect
    that in :class:`CapabilityReport`.
    """

    async def stream(
        self,
        agent: Any,
        input_text: str,
        validator: StreamingValidator,
        **kwargs: Any,
    ) -> AsyncIterator[Any]:
        """Drive the framework's streaming pipeline.

        Implementations should:

        1. Start the framework's streaming run.
        2. For each chunk: extract text, ``validator.push(text)``, and
           yield the validator-approved payload in the framework's
           native shape (or buffer until completion, depending on
           framework conventions).
        3. On ``result.stopped`` yield ``validator.make_blocked(reason)``
           and return.
        4. After the loop, drain ``validator.finish()`` and emit any
           tail payload.
        """
        ...


# ---------------------------------------------------------------------------
# Framework bundle — one of these per adapter
# ---------------------------------------------------------------------------


@dataclass
class FrameworkBundle:
    """The set of capabilities a framework adapter provides.

    Every framework adapter exports a singleton bundle and uses it to
    parameterise the framework-agnostic :class:`Shield` orchestrator.
    Frameworks that don't support a given capability set the field to
    ``None`` and reflect that in ``capabilities``.

    ``guarded_runner_cls`` lets adapters supply a framework-specific
    ``GuardedRunner`` subclass (e.g. one that exposes ``ainvoke`` /
    ``astream`` for LangChain or ``on_messages`` for AutoGen). When
    ``None`` the orchestrator uses the generic ``GuardedRunner``.
    """

    name: str
    llm_caller_factory: LlmCallerFactory
    tool_wrapper: Optional[ToolWrapper]
    agent_boundary: Optional[AgentBoundary]
    streaming_adapter: Optional[StreamingAdapter]
    capabilities: CapabilityReport
    guarded_runner_cls: Optional[type] = None


# ---------------------------------------------------------------------------
# Adapter-level exceptions
# ---------------------------------------------------------------------------


class ConfigurationMissingModelError(RuntimeError):
    """Raised when an LLM-caller adapter is asked to invoke a
    ``configurations[]`` entry that does not declare ``model:``.

    A security library MUST NOT pick a model on the customer's behalf.
    When the runtime resolves the configuration referenced by a guard
    policy's stage and finds an entry with no ``model:`` — or no
    matching entry at all — the LLM caller surfaces this typed
    exception instead of silently falling back to a hard-coded SKU
    (``gpt-4o-mini`` historically). The schema in
    ``spec/schema/guardrails.schema.json`` rejects entries missing
    ``model:`` at load time, so in normal operation this exception
    fires only when an out-of-band configuration source bypasses
    schema validation (programmatic config injection, partial extends
    merging) or when the runtime asks for a ``configuration_id`` that
    doesn't exist.

    Recovery: declare ``model: <name>`` on the offending
    ``configurations[]`` entry in ``.guardrails.yaml``. ``model:`` is
    the identifier passed verbatim to the provider SDK — a model name
    for direct OpenAI, a deployment name for Azure OpenAI, the
    provider-native identifier for Anthropic / Amazon Bedrock /
    Google Gemini / Vertex AI / Ollama / etc.

    Attributes:
        configuration_id: The ``configurations[].id`` the runtime asked
            for. ``None`` when the runtime did not supply an id.
    """

    def __init__(self, configuration_id: Optional[str]) -> None:
        self.configuration_id = configuration_id
        id_repr = configuration_id if configuration_id else "<unset>"
        super().__init__(
            f"LLM configuration {id_repr!r} is missing 'model'. Add "
            "'model: <name>' to the configurations[] entry in your "
            ".guardrails.yaml. 'model:' is passed verbatim to the "
            "provider SDK — a model name for direct OpenAI, a "
            "deployment name for Azure OpenAI."
        )


class AdapterStageMutationError(Exception):
    """Raised when an adapter cannot apply Stage-3 param transforms.

    Caught by the shared :mod:`._orchestration` helpers and surfaced
    as a fail-closed Stage-3 block so a Stage-3 ``redact`` / ``replace``
    transform that the adapter can't honour never silently devolves
    into running the tool with the un-transformed parameters.
    """

    def __init__(
        self,
        *,
        tool_name: str,
        cause: BaseException,
        stage: str = "tool_execution",
    ) -> None:
        super().__init__(
            f"Stage-{stage} transform failed for tool {tool_name!r}: {cause}"
        )
        self.tool_name = tool_name
        self.stage = stage
        self.cause = cause


class AmbientBundleAmbiguityError(RuntimeError):
    """Raised when ambient auto-binding of a :class:`FrameworkBundle` is ambiguous.

    The Python SDK auto-binds the framework bundle of an imported adapter
    module to every new :class:`ShieldBuilder` so the three-line drop-in::

        Shield.from_yaml(".guardrails.yaml").build()

    works without explicit ``with_<framework>()`` ceremony. When two or
    more adapter modules are imported into the same process, that
    auto-bind is ambiguous: silently picking one would change behaviour
    based on import order. To preserve fail-closed defaults the SDK
    refuses to guess.

    Recover by either calling ``with_<framework>()`` explicitly (passing
    ``auto_bind=False`` to ``Shield.from_yaml`` first to bypass the
    ambient lookup) or by limiting the process to a single adapter
    import.

    Attributes:
        registered: Sorted list of adapter bundle names registered when
            the ambiguity was detected.
    """

    def __init__(self, registered: List[str]) -> None:
        self.registered: List[str] = sorted(registered)
        adapters = ", ".join(repr(n) for n in self.registered)
        suggestions = " or ".join(
            f".with_{n}()" for n in self.registered
        )
        super().__init__(
            "Cannot auto-bind a FrameworkBundle: multiple adapter "
            f"modules are imported ({adapters}). Call "
            f"Shield.from_yaml(..., auto_bind=False).{suggestions[1:] if suggestions.startswith('.') else suggestions} "
            "to disambiguate, or import only one adapter module per "
            "process."
        )


__all__ = [
    "AdapterStageMutationError",
    "AgentBoundary",
    "AmbientBundleAmbiguityError",
    "CapabilityReport",
    "ConfigurationMissingModelError",
    "CoverageLevel",
    "FrameworkBundle",
    "GuardedInvoke",
    "LlmCallerFactory",
    "StreamingAdapter",
    "StreamingPushResult",
    "StreamingValidator",
    "ToolMetadata",
    "ToolWrapper",
]
