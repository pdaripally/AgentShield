"""LangChain integration for Agent Shield guardrails.

This adapter is a small set of capability implementations
(:class:`_LlmCallerFactory`, :class:`_ToolWrapper`, :class:`_AgentBoundary`,
:class:`_StreamingAdapter`) that plug into the framework-agnostic
:class:`~agent_shield.adapters._shield.Shield` orchestrator. Stage
sequencing, ``begin_turn`` / ``end_turn``, redaction, ``record_tool_*``,
``on_block`` policy, and monitor mode all live in the orchestrator.

Three usage levels:

**Level 1 — functions** (full control)::

    runtime = (
        RuntimeBuilder.from_yaml("guardrails.yaml")
        .register_llm_caller(make_llm_caller(my_llm))
        .build()
    )
    protected = protect_tools(runtime, tools)

**Level 2 — Shield helper** (recommended)::

    from agent_shield import Shield
    import agent_shield.adapters.langchain  # side-effect import

    shield = (
        Shield.from_yaml("guardrails.yaml")
        .with_langchain()
        .with_client(my_llm)
        .build()
    )
    tools  = shield.protect_tools(tools)
    agent  = shield.guard(create_agent(llm, tools, ...))

**Level 3 — two-liner** (most turnkey)::

    shield = (
        Shield.from_yaml("guardrails.yaml")
        .with_langchain()
        .with_client(my_llm)
        .build()
    )
    agent = shield.create_langchain_agent(llm, tools, system_prompt="...")
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, AsyncIterator, Callable, Optional

from agent_shield import Runtime, Session

from ._capabilities import (
    AgentBoundary,
    CapabilityReport,
    CoverageLevel,
    FrameworkBundle,
    GuardedInvoke,
    LlmCallerFactory,
    StreamingAdapter,
    StreamingValidator,
    ToolMetadata,
    ToolWrapper,
)
from ._shield import (
    GuardedRunner,
    Shield,
    ShieldBuilder,
    _protect_tools_via_wrapper,
)

logger = logging.getLogger("agent_shield.langchain")


# ---------------------------------------------------------------------------
# Capability 1 — LLM caller factory
# ---------------------------------------------------------------------------


class _LlmCallerFactory(LlmCallerFactory):
    """Adapt a LangChain ``BaseChatModel`` to the runtime caller shape.

    Uses ``llm.invoke([HumanMessage(...)])`` synchronously to avoid the
    deadlock that would happen if ``ainvoke`` were wrapped in
    ``asyncio.run()`` from a running loop.

    Unlike the OpenAI / Anthropic adapters, the model name is **not**
    set per-call here — LangChain's ``BaseChatModel`` is constructed
    by the customer with the model already bound (e.g.
    ``ChatOpenAI(model="gpt-4o")``), and there is no provider-agnostic
    way to swap it at invoke time. The ``configuration_resolver`` is
    therefore used best-effort: ``max_tokens`` and ``temperature`` from
    the YAML ``configurations[]`` entry are forwarded via
    ``llm.bind(...)`` when present, but model selection is left to the
    customer's pre-bound client. ``DEFAULT_FALLBACK_MODEL`` is a
    documentation marker for diagnostic logs only; it does not
    override the customer's bound model.
    """

    #: Documentation marker for the LangChain customer-supplied
    #: ``BaseChatModel``'s expected default. The adapter does NOT
    #: enforce this value — it surfaces only in the fallback DEBUG log
    #: so customers can correlate stage routing with their own model
    #: choice.
    DEFAULT_FALLBACK_MODEL = "customer-bound BaseChatModel"

    def make_caller(
        self,
        llm: Any,
        *,
        configuration_resolver: Optional[
            Callable[[Optional[str]], Optional[dict]]
        ] = None,
    ) -> Callable[[Optional[str], str], str]:
        from langchain_core.messages import HumanMessage

        fallback_model = self.DEFAULT_FALLBACK_MODEL

        def caller(configuration_id: Optional[str], prompt: str) -> str:
            cfg: Optional[dict] = None
            if configuration_resolver is not None and configuration_id:
                try:
                    cfg = configuration_resolver(configuration_id)
                except Exception:
                    # Resolver lookup must never break the LLM caller —
                    # fall through to the documented fallback path.
                    logger.exception(
                        "langchain llm caller: configuration_resolver "
                        "raised for configuration_id=%r; falling back to "
                        "the customer's pre-bound BaseChatModel (%r).",
                        configuration_id,
                        fallback_model,
                    )
                    cfg = None

            bind_kwargs: dict = {}
            if cfg is not None:
                if cfg.get("max_tokens") is not None:
                    bind_kwargs["max_tokens"] = cfg["max_tokens"]
                if cfg.get("temperature") is not None:
                    bind_kwargs["temperature"] = cfg["temperature"]
                # Note: cfg["model"] is intentionally NOT applied — see
                # the class docstring. LangChain's bind(model=...) is
                # not safely provider-agnostic, and swapping models on a
                # pre-constructed BaseChatModel would silently bypass
                # the customer's chosen provider config (API keys,
                # endpoints, deployment name, etc).
            else:
                logger.debug(
                    "langchain llm caller: no `configurations[]` entry "
                    "matched configuration_id=%r; invoking the customer's "
                    "pre-bound BaseChatModel without per-call overrides. "
                    "Declare `configurations: - {id: %s, type: llm, "
                    "max_tokens: ..., temperature: ...}` in "
                    "`.guardrails.yaml` to forward invocation params.",
                    configuration_id,
                    configuration_id or "<unset>",
                )

            target = llm.bind(**bind_kwargs) if bind_kwargs else llm
            response = target.invoke([HumanMessage(content=prompt)])
            return getattr(response, "content", str(response))

        return caller


# ---------------------------------------------------------------------------
# Capability 2 — Tool wrapper
# ---------------------------------------------------------------------------


class _ToolWrapper(ToolWrapper):
    """Translate between LangChain ``StructuredTool`` and the orchestrator shape.

    LangChain tools expose ``.coroutine`` (async) and/or ``.func`` (sync)
    plus ``ainvoke(args_dict)``. The wrapper builds a new
    ``StructuredTool`` whose coroutine flattens kwargs back into a
    params dict before handing off to the orchestrator-provided guarded
    invoker.
    """

    def extract(self, tool: Any) -> ToolMetadata:
        return ToolMetadata(
            name=tool.name,
            description=getattr(tool, "description", tool.name),
            params_schema=getattr(tool, "args_schema", None) or {},
            extras={
                "coroutine": tool.coroutine,
                "func": tool.func,
                "args_schema": getattr(tool, "args_schema", None),
            },
        )

    async def invoke(self, original: Any, params: dict) -> Any:
        # LangChain tools expose .coroutine (async) and .func (sync);
        # call the closer of the two so we don't pay the cost of
        # to_thread for tools that have an async path.
        coroutine = getattr(original, "coroutine", None)
        if coroutine is not None:
            return await coroutine(**params)
        func = getattr(original, "func", None)
        if func is not None:
            return await asyncio.to_thread(func, **params)
        # Fallback: the tool is its own callable.
        return await original.ainvoke(params)

    def wrap(
        self,
        original: Any,
        metadata: ToolMetadata,
        guarded_invoke: GuardedInvoke,
    ) -> Any:
        from langchain_core.tools import StructuredTool

        # The LangChain tool body receives kwargs (because StructuredTool
        # spreads args dict into kwargs at .ainvoke). We collapse back
        # to a params dict before dispatching to the orchestrator.
        async def _guarded_call(**kwargs: Any) -> str:
            return await guarded_invoke(kwargs, "")

        tool_kwargs: dict[str, Any] = {
            "name": metadata.name,
            "description": metadata.description,
            "coroutine": _guarded_call,
        }
        args_schema = metadata.extras.get("args_schema")
        if args_schema:
            tool_kwargs["args_schema"] = args_schema
        return StructuredTool(**tool_kwargs)


# ---------------------------------------------------------------------------
# Capability 3 — Agent boundary (Stage 1 + Stage 5 around ainvoke)
# ---------------------------------------------------------------------------


class _AgentBoundary(AgentBoundary):
    """Run a LangChain/LangGraph agent and reshape its result."""

    async def run(
        self, agent: Any, input_text: str, **kwargs: Any,
    ) -> Any:
        # LangChain agents take a dict-shaped input — the LangChain
        # GuardedAgent.ainvoke passes it through ``input_dict``. If
        # callers use ``GuardedRunner.run`` directly with a plain string
        # we wrap it into the canonical messages shape.
        input_dict = kwargs.pop("input_dict", None)
        config = kwargs.pop("config", None)
        if input_dict is None:
            input_dict = {"messages": [("human", input_text)]}
        return await agent.ainvoke(input_dict, config, **kwargs)

    def extract_output(self, result: Any) -> Optional[str]:
        return _extract_message_text(result)

    def apply_redaction(self, result: Any, redacted_text: str) -> Any:
        from langchain_core.messages import AIMessage

        messages = list(result.get("messages", []))
        if messages:
            messages[-1] = AIMessage(content=redacted_text)
        else:
            messages = [AIMessage(content=redacted_text)]
        return {**result, "messages": messages}

    def make_blocked(self, message: str) -> Any:
        from langchain_core.messages import AIMessage

        return {"messages": [AIMessage(content=message)]}


def _extract_message_text(response: Any) -> Optional[str]:
    """Return the content of the last message in a LangChain response."""
    if response is None or not isinstance(response, dict):
        return None
    messages = response.get("messages", [])
    if not messages:
        return None
    last = messages[-1]
    if hasattr(last, "content"):
        return str(last.content)
    if isinstance(last, dict):
        return str(last.get("content", ""))
    if isinstance(last, tuple) and len(last) >= 2:
        return str(last[1])
    return None


def _extract_user_input_from_dict(input_dict: dict[str, Any]) -> str:
    """Find the most recent human message text in a LangChain input dict."""
    messages = input_dict.get("messages", [])
    for msg in reversed(messages):
        if isinstance(msg, tuple) and len(msg) >= 2:
            if msg[0] in ("human", "user"):
                return str(msg[1])
        elif hasattr(msg, "type") and getattr(msg, "type") in ("human", "user"):
            return str(getattr(msg, "content", ""))
        elif isinstance(msg, dict) and msg.get("role") in ("human", "user"):
            return str(msg.get("content", ""))
    return ""


def _extract_chunk_text(chunk: Any) -> str:
    """Pull text out of a LangChain streaming chunk."""
    if not isinstance(chunk, dict):
        return ""
    messages = chunk.get("messages", [])
    if not messages:
        return ""
    last = messages[-1]
    if hasattr(last, "content"):
        return str(last.content)
    if isinstance(last, dict):
        return str(last.get("content", ""))
    return ""


# ---------------------------------------------------------------------------
# Capability 4 — Streaming adapter (LangChain buffers, yields once)
# ---------------------------------------------------------------------------


class _StreamingAdapter(StreamingAdapter):
    """LangChain streaming: buffer all safe chunks, emit a single final dict.

    LangChain's ``astream`` consumers expect a sequence of state-shaped
    dicts where the final one carries the full assistant message. Per-
    chunk safety still happens through the validator; we just collect
    safe payloads and yield once at the end so a Stage-5 redact policy
    never leaks unredacted partial content.
    """

    async def stream(
        self,
        agent: Any,
        input_text: str,
        validator: StreamingValidator,
        **kwargs: Any,
    ) -> AsyncIterator[Any]:
        from langchain_core.messages import AIMessage

        input_dict = kwargs.pop("input_dict", None)
        config = kwargs.pop("config", None)
        if input_dict is None:
            input_dict = {"messages": [("human", input_text)]}

        safe_parts: list[str] = []
        last_chunk: Any = None
        async for chunk in agent.astream(input_dict, config, **kwargs):
            last_chunk = chunk
            text = _extract_chunk_text(chunk)
            if not text:
                continue
            result = validator.push(text)
            if result.payload:
                safe_parts.append(result.payload)
            if result.stopped:
                yield validator.make_blocked(
                    result.reason or "Stage 5 streaming guard stopped the stream.",
                )
                return

        tail = validator.finish()
        if tail.stopped:
            yield validator.make_blocked(
                tail.reason or "Stage 5 streaming guard stopped the stream.",
            )
            return
        if tail.payload:
            safe_parts.append(tail.payload)

        final_text = "".join(safe_parts)
        if last_chunk and isinstance(last_chunk, dict) and "messages" in last_chunk:
            yield validator.apply_redaction(last_chunk, final_text)
        else:
            yield {"messages": [AIMessage(content=final_text)]}


# ---------------------------------------------------------------------------
# Bundle
# ---------------------------------------------------------------------------


class GuardedAgent(GuardedRunner):
    """LangChain-named wrapper around :class:`GuardedRunner`.

    Adds ``ainvoke`` / ``astream`` methods that take LangChain's
    dict-shaped input, extract the latest human message for Stage 1,
    and forward both to the boundary.

    When constructed directly (rather than through ``Shield.guard``),
    the LangChain :class:`AgentBoundary` from the bundle is supplied
    automatically so callers don't have to wire it.
    """

    def __init__(
        self,
        runtime: Runtime,
        agent: Any,
        boundary: "AgentBoundary | None" = None,
        streaming: Optional[StreamingAdapter] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            runtime,
            agent,
            boundary if boundary is not None else _BUNDLE.agent_boundary,
            streaming if streaming is not None else _BUNDLE.streaming_adapter,
            **kwargs,
        )

    async def ainvoke(  # type: ignore[override]
        self,
        input_dict: dict[str, Any],
        config: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Async invoke with Stage 1 + Stage 5 validation."""
        user_input = _extract_user_input_from_dict(input_dict)
        return await self.run(
            user_input,
            input_dict=input_dict,
            config=config,
            **kwargs,
        )

    async def astream(  # type: ignore[override]
        self,
        input_dict: dict[str, Any],
        config: dict[str, Any] | None = None,
        **kwargs: Any,
    ):
        """Async stream with Stage 1 + Stage 5 validation."""
        user_input = _extract_user_input_from_dict(input_dict)
        async for emission in self.run_streamed(
            user_input,
            input_dict=input_dict,
            config=config,
            **kwargs,
        ):
            yield emission


_BUNDLE = FrameworkBundle(
    name="langchain",
    llm_caller_factory=_LlmCallerFactory(),
    tool_wrapper=_ToolWrapper(),
    agent_boundary=_AgentBoundary(),
    streaming_adapter=_StreamingAdapter(),
    capabilities=CapabilityReport(
        framework="langchain",
        # Streaming chunk-level redaction covers AIMessageChunk text
        # but not tool_call deltas — see the streaming_adapter notes.
        # Full coverage is restored once the stream completes.
        streaming_output=CoverageLevel.PARTIAL,
    ),
    guarded_runner_cls=GuardedAgent,
)


# ---------------------------------------------------------------------------
# Composition pattern — install with_langchain() and create_langchain_agent()
# at import time so customers can do
#
#     from agent_shield import Shield
#     import agent_shield.adapters.langchain  # side-effect import
#     shield = Shield.from_yaml("guardrails.yaml").with_langchain().build()
#
# Matches the Node SDK's framework-bundle composition pattern.
# ---------------------------------------------------------------------------


def _install() -> None:
    """Monkey-install :meth:`ShieldBuilder.with_langchain` and
    :meth:`Shield.create_langchain_agent`."""

    def with_langchain(self: ShieldBuilder) -> ShieldBuilder:
        """Bind this builder to the LangChain framework bundle."""
        return self._bind_to_bundle(_BUNDLE)

    def create_langchain_agent(
        self: Shield,
        llm: Any,
        tools: list,
        *,
        system_prompt: str = "",
        checkpointer: Any = None,
        **agent_kwargs: Any,
    ) -> Any:
        """Build a fully guarded LangChain agent in one call (Pattern A)."""
        from langchain.agents import create_agent

        protected = self.protect_tools(tools)
        agent = create_agent(
            llm,
            protected,
            system_prompt=system_prompt,
            checkpointer=checkpointer,
            **agent_kwargs,
        )
        return self.guard(agent)

    setattr(ShieldBuilder, "with_langchain", with_langchain)
    setattr(Shield, "create_langchain_agent", create_langchain_agent)


_install()

# Register this bundle as the auto-bind default for new ShieldBuilder instances.
from . import _bundle_registry as _registry  # noqa: E402
_registry.register(_BUNDLE)


# ---------------------------------------------------------------------------
# Module-level helpers (Level 1 API)
# ---------------------------------------------------------------------------


def make_llm_caller(
    llm: Any,
    configuration_resolver: Optional[
        Callable[[Optional[str]], Optional[dict]]
    ] = None,
) -> Callable[[Optional[str], str], str]:
    """Create an LLM caller from a LangChain ``BaseChatModel``.

    Pass ``configuration_resolver=runtime.llm_configuration`` to honour
    the YAML's per-stage ``max_tokens:`` / ``temperature:`` selection
    via ``llm.bind(...)``. Model selection is left to the customer's
    pre-bound ``BaseChatModel`` — see :class:`_LlmCallerFactory` for
    rationale.
    """
    return _BUNDLE.llm_caller_factory.make_caller(
        llm, configuration_resolver=configuration_resolver,
    )


def protect_tools(
    runtime: Runtime,
    tools: list,
    user_input_getter: Optional[Callable[[], str]] = None,
) -> list:
    """Wrap LangChain tools with Stages 2 + 3 + 4 enforcement."""
    return _protect_tools_via_wrapper(
        runtime, tools, _BUNDLE.tool_wrapper, user_input_getter,
    )


__all__ = [
    "GuardedAgent",
    "make_llm_caller",
    "protect_tools",
]
