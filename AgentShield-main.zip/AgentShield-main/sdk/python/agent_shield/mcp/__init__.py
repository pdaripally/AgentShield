"""Agent Shield for MCP (Model Context Protocol) servers.

MCP servers are tool providers, not agent loops, so this integration is
a sibling to the framework adapters in :mod:`agent_shield.adapters`.
There is no Stage 1 input boundary or Stage 5 output boundary to
attach because the MCP server never sees a user-facing prompt or
assistant message — it only receives tool calls and returns tool
results.

Capability profile (always reported, see :attr:`MCPShield.capabilities`)::

    input_validation:           unsupported
    state_validation:           full
    tool_authorization:         full
    tool_execution_validation:  full
    tool_output_validation:     full
    output_validation:          unsupported
    streaming_output:           unsupported

Session scope
-------------

By default a single :class:`~agent_shield.Session` is held for the
lifetime of the :class:`MCPShield` instance — i.e. one session per MCP
connection. State predicates (variables set on a previous tool call)
therefore span subsequent tool calls on the same connection. Pass
``session_scope="call"`` to opt out and create a fresh session per
call (the legacy stateless behaviour).

Public API
----------

* :func:`shield_server` — wrap every tool registered on a FastMCP /
  generic MCP server with Stage 2 + 3 + 4 enforcement.
* :func:`protect_tool` / :func:`protect_tool_output` — manual stage
  validation helpers.
* :class:`MCPShield` — composable shield with capability report.
"""
from __future__ import annotations

import inspect
import logging
import uuid
from typing import Any, Callable, List, Literal, Optional, Union

from agent_shield import Runtime, RuntimeBuilder, Session
from agent_shield.adapters._capabilities import (
    CapabilityReport,
    CoverageLevel,
)
from agent_shield.adapters._orchestration import (
    _format_block_message,
    current_user_input,
    guarded_tool,
    guarded_tool_sync,
)

logger = logging.getLogger("agent_shield.mcp")

SessionScope = Literal["connection", "call"]


# ---------------------------------------------------------------------------
# Capability profile
# ---------------------------------------------------------------------------

_MCP_CAPABILITIES = CapabilityReport(
    framework="mcp",
    input_validation=CoverageLevel.UNSUPPORTED,
    state_validation=CoverageLevel.FULL,
    tool_authorization=CoverageLevel.FULL,
    tool_execution_validation=CoverageLevel.FULL,
    tool_output_validation=CoverageLevel.FULL,
    output_validation=CoverageLevel.UNSUPPORTED,
    streaming_output=CoverageLevel.UNSUPPORTED,
    notes=[
        "MCP is a tool-provider integration; no user-facing input or "
        "assistant-output boundary exists for Stage 1 / Stage 5 / "
        "streaming",
    ],
)


# ---------------------------------------------------------------------------
# Internal stage helpers — single implementation, reused by module-level
# helpers and the MCPShield methods.
# ---------------------------------------------------------------------------


def _do_protect_tool(
    session: Session, tool_name: str, args: dict, tool_call_id: str,
) -> tuple[bool, dict, Optional[str]]:
    if not tool_call_id:
        raise TypeError("tool_call_id is required and must be non-empty")
    cleaned = {k: v for k, v in (args or {}).items() if v is not None}
    outcome = session.validate_tool_call(tool_name, cleaned, tool_call_id=tool_call_id)
    if not outcome.verdict.allowed:
        return False, cleaned, _format_block_message(outcome.verdict)
    effective = outcome.params if outcome.params is not None else cleaned
    return True, effective, None


def _do_protect_tool_output(
    session: Session, tool_name: str, output: Any, tool_call_id: str,
    *, record: bool,
) -> tuple[bool, str, Optional[str]]:
    if not tool_call_id:
        raise TypeError("tool_call_id is required and must be non-empty")
    text = output if isinstance(output, str) else str(output)
    outcome = session.validate_tool_output(tool_name, text, tool_call_id=tool_call_id)
    if not outcome.verdict.allowed:
        if record:
            try:
                session.record_tool_failure(
                    tool_name, outcome.verdict.reason or "blocked",
                )
            except Exception:  # noqa: BLE001
                logger.debug("record_tool_failure raised", exc_info=True)
        return False, text, _format_block_message(outcome.verdict)
    final = outcome.result if outcome.result is not None else text
    final_str = final if isinstance(final, str) else str(final)
    if record:
        try:
            session.record_tool_success(tool_name, final_str)
        except Exception:  # noqa: BLE001
            logger.debug("record_tool_success raised", exc_info=True)
    return True, final_str, None


# ---------------------------------------------------------------------------
# Module-level helpers — for callers who don't want the MCPShield wrapper.
# These ALWAYS create a fresh session when ``session`` is None (the
# legacy per-call behaviour). Use :class:`MCPShield` for connection
# scoping.
# ---------------------------------------------------------------------------


async def protect_tool(
    runtime: Runtime,
    tool_name: str,
    args: dict,
    tool_call_id: str,
    *,
    session: Optional[Session] = None,
) -> tuple[bool, dict, Optional[str]]:
    """Stage 2 + 3 — guard an inbound MCP tool call.

    ``tool_call_id`` is REQUIRED (Section 16.0 mandatory binding):
    the same id MUST be threaded through the matching
    :func:`protect_tool_output` call so Stage 4 binds against the
    canonical invocation Stage 3 admitted. When the host framework
    does not surface a native id (e.g. raw MCP without a request id),
    mint one with ``uuid.uuid4().hex`` per call.

    Returns ``(allowed, effective_args, block_message)``.
    """
    sess = session if session is not None else runtime.new_session()
    return _do_protect_tool(sess, tool_name, args, tool_call_id)


async def protect_tool_output(
    runtime: Runtime,
    tool_name: str,
    output: Any,
    tool_call_id: str,
    *,
    session: Optional[Session] = None,
    record: bool = True,
) -> tuple[bool, str, Optional[str]]:
    """Stage 4 — guard an outbound MCP tool result.

    ``tool_call_id`` is REQUIRED and MUST match the id passed to the
    paired :func:`protect_tool` call (Section 16.0 mandatory binding).

    When ``record`` is True the resource cycle bookkeeping fires
    (``record_tool_success`` on allow, ``record_tool_failure`` on
    block).
    """
    sess = session if session is not None else runtime.new_session()
    return _do_protect_tool_output(
        sess, tool_name, output, tool_call_id, record=record,
    )


# ---------------------------------------------------------------------------
# MCPShield — composable shield for MCP servers
# ---------------------------------------------------------------------------


class MCPShield:
    """Composable shield for MCP servers.

    Holds a single long-lived :class:`Session` per MCP connection by
    default so state predicates span tool calls. Pass
    ``session_scope="call"`` to opt out and force a fresh session per
    call.
    """

    def __init__(
        self,
        runtime: Runtime,
        *,
        capabilities: CapabilityReport = _MCP_CAPABILITIES,
        session_scope: SessionScope = "connection",
    ) -> None:
        if session_scope not in ("connection", "call"):
            raise ValueError(
                f"session_scope must be 'connection' or 'call', "
                f"got {session_scope!r}",
            )
        self.runtime = runtime
        self._capabilities = capabilities
        self._session_scope: SessionScope = session_scope
        self._session: Optional[Session] = None

    @classmethod
    def from_yaml(cls, path: Union[str, List[str]]) -> "MCPShieldBuilder":
        """Create a builder from a single YAML file or a chain."""
        if isinstance(path, list):
            b = MCPShieldBuilder("")
            b._yaml_chain = list(path)
            return b
        return MCPShieldBuilder(path)

    @property
    def capabilities(self) -> CapabilityReport:
        return self._capabilities

    @property
    def session_scope(self) -> SessionScope:
        return self._session_scope

    @property
    def session(self) -> Optional[Session]:
        """The held connection session, or ``None`` when scope is ``"call"``.

        Lazily created on first access in connection mode. Use
        :meth:`reset_session` to drop it (e.g. for connection pooling).
        """
        if self._session_scope != "connection":
            return None
        if self._session is None:
            self._session = self.runtime.new_session()
        return self._session

    def reset_session(self) -> None:
        """Drop the held connection session.

        The next ``protect_tool`` / ``protect_tool_output`` call will
        lazily create a fresh session. No-op when ``session_scope`` is
        ``"call"``.
        """
        self._session = None

    def _resolve_session(self, explicit: Optional[Session]) -> Session:
        if explicit is not None:
            return explicit
        if self._session_scope == "connection":
            return self.session  # type: ignore[return-value]
        return self.runtime.new_session()

    async def protect_tool(
        self,
        tool_name: str,
        args: dict,
        tool_call_id: str,
        *,
        session: Optional[Session] = None,
    ) -> tuple[bool, dict, Optional[str]]:
        """Stage 2 + 3 validation for an inbound MCP tool call.

        ``tool_call_id`` is REQUIRED (Section 16.0). Reuse the same id
        when calling :meth:`protect_tool_output`.
        """
        return _do_protect_tool(
            self._resolve_session(session), tool_name, args, tool_call_id,
        )

    async def protect_tool_output(
        self,
        tool_name: str,
        output: Any,
        tool_call_id: str,
        *,
        session: Optional[Session] = None,
        record: bool = True,
    ) -> tuple[bool, str, Optional[str]]:
        """Stage 4 validation for an outbound MCP tool result.

        ``tool_call_id`` is REQUIRED and MUST match the id passed to
        the paired :meth:`protect_tool` call (Section 16.0).
        """
        return _do_protect_tool_output(
            self._resolve_session(session), tool_name, output, tool_call_id,
            record=record,
        )

    # ── Server / tool wrappers ───────────────────────────────────

    def protect_server(
        self, server: Any, *, on_block: str = "raise",
    ) -> Any:
        """Wrap every tool on ``server`` with Stage 2/3/4 enforcement.

        Supports any MCP server that exposes either a ``_tool_manager``
        with a ``_tools`` dict (FastMCP) or a top-level ``tools``
        registry.
        """
        registry = self._find_tool_registry(server)
        self._wrap_registry(registry, on_block=on_block)
        return server

    def protect_tools(
        self, tools: List[tuple], *, on_block: str = "raise",
    ) -> List[tuple]:
        """Wrap a list of ``(name, callable)`` pairs."""
        return [
            (name, self._wrap_callable(name, fn, on_block=on_block))
            for name, fn in tools
        ]

    @staticmethod
    def _find_tool_registry(server: Any) -> Any:
        tm = getattr(server, "_tool_manager", None)
        if tm is not None and hasattr(tm, "_tools"):
            return tm._tools
        if hasattr(server, "tools"):
            return server.tools
        raise TypeError(
            f"Cannot find tool registry on MCP server "
            f"{type(server).__name__!r}. Pass tools explicitly via "
            f"protect_tools().",
        )

    def _wrap_registry(self, registry: Any, *, on_block: str) -> None:
        items = (
            list(registry.items())
            if isinstance(registry, dict)
            else [(getattr(t, "name", None), t) for t in registry]
        )
        for name, tool in items:
            if name is None:
                continue
            fn = (
                getattr(tool, "fn", None)
                or getattr(tool, "func", None)
                or tool
            )
            if fn is None:
                continue
            wrapped = self._wrap_callable(name, fn, on_block=on_block)
            if hasattr(tool, "fn"):
                tool.fn = wrapped
            elif hasattr(tool, "func"):
                tool.func = wrapped
            elif isinstance(registry, dict):
                registry[name] = wrapped

    def _wrap_callable(
        self, tool_name: str, fn: Callable[..., Any], *, on_block: str,
    ) -> Callable[..., Any]:
        runtime = self.runtime

        if inspect.iscoroutinefunction(fn):
            async def _async(**kwargs: Any) -> Any:
                # §16.0 binding: MCP servers don't surface the upstream
                # client's request id at the tool boundary, so mint a
                # stable per-call id here so Stage 3 + Stage 4 bind
                # against the same canonical invocation.
                call_id = uuid.uuid4().hex
                blocked, output = await guarded_tool(
                    tool_name, kwargs,
                    execute=lambda eff: fn(**eff),
                    user_input=current_user_input.get(""),
                    runtime=runtime,
                    tool_call_id=call_id,
                )
                if blocked and on_block == "raise":
                    raise MCPGuardrailBlocked(tool_name, output)
                return output
            return _async

        def _sync(**kwargs: Any) -> Any:
            call_id = uuid.uuid4().hex
            blocked, output = guarded_tool_sync(
                tool_name, kwargs,
                execute=lambda eff: fn(**eff),
                user_input=current_user_input.get(""),
                runtime=runtime,
                tool_call_id=call_id,
            )
            if blocked and on_block == "raise":
                raise MCPGuardrailBlocked(tool_name, output)
            return output
        return _sync


# ---------------------------------------------------------------------------
# MCPShieldBuilder — fluent builder for MCPShield
# ---------------------------------------------------------------------------


class MCPShieldBuilder:
    """Fluent builder for :class:`MCPShield`."""

    def __init__(self, path: str) -> None:
        self._path = path
        self._yaml_chain: Optional[List[str]] = None
        self._observability_providers: list = []
        self._llm_caller: Optional[Callable] = None
        self._extra_register: list = []
        self._session_scope: SessionScope = "connection"

    def with_observability(
        self, provider: Any,
    ) -> "MCPShieldBuilder":
        """Register a single observability provider. Chain to register more."""
        self._observability_providers.append(provider)
        return self

    def with_llm_caller(
        self, caller: Callable[..., str],
    ) -> "MCPShieldBuilder":
        self._llm_caller = caller
        return self

    def with_extension(
        self, hook: Callable[[RuntimeBuilder], None],
    ) -> "MCPShieldBuilder":
        self._extra_register.append(hook)
        return self

    def with_session_scope(self, scope: SessionScope) -> "MCPShieldBuilder":
        """Override the default ``"connection"`` scope."""
        self._session_scope = scope
        return self

    def build(self) -> MCPShield:
        if self._yaml_chain is not None:
            builder = RuntimeBuilder.from_yaml_chain(self._yaml_chain)
        else:
            builder = RuntimeBuilder.from_yaml(self._path)
        for provider in self._observability_providers:
            builder.register_observability_provider(provider)
        if self._llm_caller is not None:
            builder.register_llm_caller(self._llm_caller)
        for hook in self._extra_register:
            hook(builder)
        return MCPShield(builder.build(), session_scope=self._session_scope)


# ---------------------------------------------------------------------------
# Convenience API
# ---------------------------------------------------------------------------


def shield_server(
    server: Any,
    config: Union[str, MCPShield],
    *,
    on_block: str = "raise",
) -> MCPShield:
    """Wrap an MCP server with Agent Shield in one call."""
    shield = (
        config if isinstance(config, MCPShield)
        else MCPShield.from_yaml(config).build()
    )
    shield.protect_server(server, on_block=on_block)
    return shield


class MCPGuardrailBlocked(Exception):
    """Raised when an MCP tool call is blocked by guardrails."""

    def __init__(self, tool_name: str, message: str) -> None:
        super().__init__(message)
        self.tool_name = tool_name
        self.message = message


__all__ = [
    "MCPGuardrailBlocked",
    "MCPShield",
    "MCPShieldBuilder",
    "SessionScope",
    "protect_tool",
    "protect_tool_output",
    "shield_server",
]
