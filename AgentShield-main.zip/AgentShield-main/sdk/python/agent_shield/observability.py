"""Observability provider abstract base.

The runtime delivers structured log events (§19) to every registered
provider via :meth:`ObservabilityProvider.emit`. Providers MAY override
:meth:`shutdown` to flush buffered backends.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from ._wire import from_wire_dict


@dataclass
class ShieldLogEvent:
    """Spec §19.2 structured log event delivered to providers.

    All fields mirror the Rust ``ShieldLogEvent`` shape. The runtime
    populates *typed* fields for every spec-defined dimension and uses
    :attr:`attributes` for the open-ended ``agent_shield.*`` namespace.
    """

    timestamp: str = ""
    severity: str = "info"
    event_type: str = "info"
    category: str = ""
    stage: Optional[str] = None
    action: Optional[str] = None
    guard_policy: Optional[str] = None
    evaluate_when_index: Optional[int] = None
    resource: Optional[Dict[str, Any]] = None
    variable: Optional[str] = None
    event_id: Optional[str] = None
    correlation_id: str = ""
    session_id: str = ""
    user_id: Optional[str] = None
    tenant_id: Optional[str] = None
    #: Effective runtime mode (#14): ``"active"`` / ``"shadow"`` /
    #: ``None`` (mode-unaware dispatcher).
    mode: Optional[str] = None
    #: Whether the action was applied (#14). ``True`` in active,
    #: ``False`` in shadow. ``None`` for ``action: allow``.
    enforced: Optional[bool] = None
    message: str = ""
    attributes: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ShieldLogEvent":
        return from_wire_dict(cls, d)


class ObservabilityProvider(ABC):
    """Abstract base class for observability backends (§19).

    Subclasses MUST implement :meth:`emit`. :meth:`shutdown` is optional;
    the default is a no-op.
    """

    @abstractmethod
    def emit(self, event: ShieldLogEvent) -> None: ...

    def shutdown(self) -> None:
        """Optional flush hook called at runtime/session disposal."""
        return None


class CapturingProvider(ObservabilityProvider):
    """In-memory provider — handy for tests and demos."""

    def __init__(self) -> None:
        self.events: List[ShieldLogEvent] = []
        self.shutdown_count = 0

    def emit(self, event: ShieldLogEvent) -> None:
        self.events.append(event)

    def shutdown(self) -> None:
        self.shutdown_count += 1


class _CallableProvider(ObservabilityProvider):
    """Adapter wrapping a plain callable as a provider."""

    def __init__(self, fn: Callable[[ShieldLogEvent], None]) -> None:
        self._fn = fn

    def emit(self, event: ShieldLogEvent) -> None:
        self._fn(event)


def make_provider(
    target: Any,
) -> ObservabilityProvider:
    """Coerce ``target`` into an :class:`ObservabilityProvider`.

    Accepts: an existing provider instance, an object with ``emit``
    (and optional ``shutdown``), or a plain callable taking a
    :class:`ShieldLogEvent`.
    """
    if isinstance(target, ObservabilityProvider):
        return target
    if hasattr(target, "emit") and callable(target.emit):
        return target  # duck-typed; the native bridge will accept it.
    if callable(target):
        return _CallableProvider(target)
    raise TypeError(
        f"observability provider must be an ObservabilityProvider, "
        f"have an 'emit' method, or be callable; got {type(target).__name__}"
    )


__all__ = [
    "ShieldLogEvent",
    "ObservabilityProvider",
    "CapturingProvider",
    "make_provider",
]
