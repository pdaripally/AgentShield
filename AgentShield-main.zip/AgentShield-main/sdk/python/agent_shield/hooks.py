"""Hook protocols and resolver envelope dataclasses for the API.

The host-implemented surfaces are deliberately small. Each hook is
defined here as both:

* a :class:`typing.Protocol` describing the shape any host implementation
  must satisfy, and
* (where applicable) a :class:`~dataclasses.dataclass` describing the
  request / response envelope.

Hosts may either implement the full protocol or pass a plain ``callable``
into the :class:`~agent_shield.runtime.RuntimeBuilder` registration
methods — both are accepted.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Literal, Optional, Protocol, Union, runtime_checkable

from ._wire import from_wire_dict


# ── Resolver envelope ───────────────────────────────────────────────────

ResolverDecision = Literal["allow", "deny", "cancelled"]


@dataclass
class ResolverRequest:
    """Envelope delivered to every resolver hook invocation (§11)."""

    request_id: str
    variable: Optional[str] = None
    resource_kind: Optional[str] = None
    resource_name: Optional[str] = None
    prompt: Optional[str] = None
    reason: Optional[str] = None
    context: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ResolverRequest":
        return from_wire_dict(cls, d)


@dataclass
class ResolverResponse:
    """Wire envelope returned by every resolver hook (§11.3).

    ``decision`` is required; ``value`` and ``set_variables`` are optional.
    Unknown / malformed envelopes are rejected fail-closed by the runtime.
    """

    decision: ResolverDecision
    value: Any = None
    set_variables: Dict[str, Any] = field(default_factory=dict)
    reason: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        out: Dict[str, Any] = {"decision": self.decision}
        if self.value is not None:
            out["value"] = self.value
        if self.set_variables:
            out["set_variables"] = dict(self.set_variables)
        if self.reason is not None:
            out["reason"] = self.reason
        return out


@dataclass
class DelegateRequest:
    """Envelope delivered to :class:`DelegateDispatcher` (§11.10.3)."""

    request_id: str
    variable: Optional[str] = None
    configuration: Dict[str, Any] = field(default_factory=dict)
    effective_timeout_ms: int = 0
    resource_kind: Optional[str] = None
    resource_name: Optional[str] = None
    prompt: Optional[str] = None
    reason: Optional[str] = None
    context: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "DelegateRequest":
        return from_wire_dict(cls, d)


# ── Protocols ────────────────────────────────────────────────────────────


@runtime_checkable
class AgentResolver(Protocol):
    """Host integration for ``kind: agent`` resolvers (§11.4)."""

    def resolve(self, request: ResolverRequest) -> ResolverResponse: ...


@runtime_checkable
class DelegateDispatcher(Protocol):
    """Host integration for ``kind: delegate`` resolvers (§11.10.3)."""

    def dispatch(self, request: DelegateRequest) -> ResolverResponse: ...


# Hook callables (alternative to Protocol implementations).
#
# `kind: human` (§11.11) is intentionally absent from this list. The
# runtime synthesises a canonical-tool-call signal for human resolvers
# (`tool: agent_shield.ask_human` on the deny verdict's
# ``pending_resolution`` field); the host registers an MCP tool under
# that name rather than implementing a callback. See
# ``examples/tools/ask-human-mcp-server`` for a reference server.
AgentResolverCallable = Callable[[ResolverRequest], ResolverResponse]
DelegateDispatcherCallable = Callable[[DelegateRequest], ResolverResponse]


# ── LLM / classifier ─────────────────────────────────────────────────────


@dataclass
class RedactionSpan:
    """Half-open ``[start, end)`` byte range over the input text, with an
    optional replacement string. Drives Stage-3 redact policies (§12.9):
    when a redact-mode policy receives spans from an LLM or classifier
    caller, the runtime substitutes ``replacement`` (default empty) for
    the matched slice of input.
    """

    start: int
    end: int
    replacement: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        out: Dict[str, Any] = {"start": self.start, "end": self.end}
        if self.replacement is not None:
            out["replacement"] = self.replacement
        return out


@dataclass
class LlmResponse:
    """Structured LLM caller response (§12.9.3).

    ``decision`` is the canonical allow / block flag. Any truthy value in
    ``bool_flags`` MUST be treated as ``block`` per §12.9.3. ``spans``
    drives Stage-3 redact policies — when populated and ``decision`` is
    ``"allow"``, the runtime applies each span to the input.
    """

    decision: Optional[Literal["allow", "block"]] = None
    confidence: Optional[float] = None
    reason: Optional[str] = None
    categories: List[str] = field(default_factory=list)
    bool_flags: Dict[str, bool] = field(default_factory=dict)
    spans: List[RedactionSpan] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        out: Dict[str, Any] = {}
        if self.decision is not None:
            out["decision"] = self.decision
        if self.confidence is not None:
            out["confidence"] = self.confidence
        if self.reason is not None:
            out["reason"] = self.reason
        if self.categories:
            out["categories"] = list(self.categories)
        if self.bool_flags:
            out["bool_flags"] = dict(self.bool_flags)
        if self.spans:
            out["spans"] = [s.to_dict() for s in self.spans]
        return out


@dataclass
class ClassifierVerdict:
    """Structured classifier response (§12.5.1).

    ``spans`` drives Stage-3 redact policies the same way as
    :class:`LlmResponse.spans`.
    """

    score: float = 0.0
    threshold: float = 0.0
    flagged: bool = False
    label: Optional[str] = None
    reason: Optional[str] = None
    spans: List[RedactionSpan] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        out: Dict[str, Any] = {
            "score": self.score,
            "threshold": self.threshold,
            "flagged": self.flagged,
        }
        if self.label is not None:
            out["label"] = self.label
        if self.reason is not None:
            out["reason"] = self.reason
        if self.spans:
            out["spans"] = [s.to_dict() for s in self.spans]
        return out


LlmCallable = Callable[[Optional[str], str], Union[LlmResponse, Dict[str, Any], str]]
ClassifierCallable = Callable[[str, str], Union[ClassifierVerdict, Dict[str, Any]]]


@runtime_checkable
class LlmCaller(Protocol):
    """Host integration for ``llm:`` detection entries."""

    def call(
        self, configuration_id: Optional[str], prompt: str
    ) -> Union[LlmResponse, Dict[str, Any], str]: ...


@runtime_checkable
class ClassifierCaller(Protocol):
    """Host integration for ``classifier:`` detection entries."""

    def classify(
        self, configuration_id: str, subject: str
    ) -> Union[ClassifierVerdict, Dict[str, Any]]: ...


__all__ = [
    "ResolverDecision",
    "ResolverRequest",
    "ResolverResponse",
    "DelegateRequest",
    "AgentResolver",
    "DelegateDispatcher",
    "AgentResolverCallable",
    "DelegateDispatcherCallable",
    "LlmResponse",
    "ClassifierVerdict",
    "LlmCallable",
    "ClassifierCallable",
    "LlmCaller",
    "ClassifierCaller",
]
