# Agent Shield wire-shape JSON Schemas

This directory contains **canonical JSON Schema artifacts** for every
data shape that crosses the FFI boundary between the Rust core and the
language SDKs (Python, Node, .NET).

These schemas are **the public wire contract** — they are the source of
truth for what crosses the boundary, not Rust serde annotations or any
single SDK's typed bindings. Per the architecture review, this is what
prevents the wire shapes from being downstream of one implementation:

> Wire shapes: canonical JSON Schema as a separate build artifact in
> `spec/schemas/`. Rust is one consumer, not the source of truth. Public
> compatibility contract is the schema, not Rust serde annotations.

## Schemas

| File                           | What it describes                              |
|--------------------------------|------------------------------------------------|
| `stage_verdict.schema.json`    | Verdict from every `validate_*` call          |
| `variable_state.schema.json`   | Snapshot of a variable's tracker entry        |
| `shield_log_event.schema.json` | Observability event shape                     |
| `resolver_request.schema.json` | Envelope delivered to every resolver hook     |
| `resolver_response.schema.json`| Envelope returned by every resolver hook      |
| `delegate_request.schema.json` | Envelope for delegate dispatcher              |
| `llm_response.schema.json`     | Envelope for `kind: llm` detection responses  |
| `classifier_verdict.schema.json`| Envelope for `kind: classifier` detection    |
| `capability_report.schema.json`| Adapter capability profile                    |

## Versioning

Each schema carries a `$id` pinned to the spec version. Adding a new
optional field is a non-breaking change; making a field required, removing
a field, or changing a field's type is a breaking change requiring a
spec-version bump.

## Conformance

Every SDK's wire-shape converter MUST produce / accept JSON that
validates against these schemas. The Python suite includes a conformance
test (`tests/test_wire_schemas.py`) that round-trips real runtime
outputs through `jsonschema` against each artifact.
