# Agent Shield Specification

**Version:** 2.0.0-alpha **Status:** Work in Progress **Last Updated:** 2026-05-04

---

## Abstract

Agent Shield is a runtime contract for securing AI agents. It defines a declarative, framework-agnostic guardrails file (`.guardrails.yaml`) that gates every tool call, endpoint call, and sub-agent invocation an agent attempts. This document specifies the file format, the five validation stages, the runtime enforcement semantics, and the behavioral contract the host agent MUST honor.

---

## Table of Contents

- [1. Introduction](#1-introduction)
- [2. The Agent Shield model](#2-the-agent-shield-model)
- [3. The guardrails file at a glance](#3-the-guardrails-file-at-a-glance)
- [4. `metadata`](#4-metadata)
- [5. `objective`](#5-objective)
- [6. `configurations`](#6-configurations)
- [7. Expression language](#7-expression-language)
- [8. `predicates`](#8-predicates)
- [9. Events and lifetimes](#9-events-and-lifetimes)
- [10. `variables`](#10-variables)
- [11. Resolvers](#11-resolvers)
- [12. Guard policies (shared contract)](#12-guard-policies-shared-contract)
- [13. `resources`](#13-resources)
- [14. `input_validation` (Stage 1)](#14-input_validation-stage-1)
- [15. `state_validation` (Stage 2)](#15-state_validation-stage-2)
- [16. `tool_execution_validation` (Stage 3)](#16-tool_execution_validation-stage-3)
- [17. `post_tool_validation` (Stage 4)](#17-post_tool_validation-stage-4)
- [18. `output_validation` (Stage 5)](#18-output_validation-stage-5)
- [19. Observability](#19-observability)
- [20. Agent contract](#20-agent-contract)
- [21. Runtime API (Default Implementation)](#21-runtime-api-default-implementation)

---
## 1. Introduction

### 1.1 What this specification provides

This specification defines the runtime contract for Agent Shield: a portable, framework-agnostic set of security controls layered around an AI agent. The contract is expressed as a declarative YAML file (`.guardrails.yaml`) read by an Agent Shield runtime that wraps and intercepts the agent's tool-calling surface. The runtime enforces five sequential validation stages on every interaction — input, state, tool execution, post-tool, and output.

Conforming runtimes ship today as in-process SDKs that wrap the host agent framework. The same `.guardrails.yaml` file MUST produce identical observable semantics across every conforming SDK and language. Out-of-process deployment shapes (sidecars, supervising proxies, gateways) are NOT part of the v1.0 conformance surface; they remain a future extension and a conforming v1.0 runtime is not required to support them.

### 1.2 Conformance

The keywords **MUST**, **MUST NOT**, **REQUIRED**, **SHALL**, **SHALL NOT**, **SHOULD**, **SHOULD NOT**, **RECOMMENDED**, **MAY**, and **OPTIONAL** in this document are to be interpreted as described in [RFC 2119][rfc2119] and [RFC 8174][rfc8174] when, and only when, they appear in all capitals.

[rfc2119]: https://www.rfc-editor.org/rfc/rfc2119
[rfc8174]: https://www.rfc-editor.org/rfc/rfc8174

A **conforming guardrails file** is one whose contents the JSON Schema at `spec/schema/guardrails.schema.json` validates.

### 1.3 File format conventions

- Guardrails files are YAML 1.2 documents.
- All YAML keys defined by this specification are **snake_case**. Implementations MUST reject unknown keys with a load-time error.
- Defaults are **fail-closed**: when a field controls a security gate and is omitted, the safer behavior is selected (typically `block`).
- Values that reference declared resources, variables, or configurations MUST resolve at load time; unresolved references MUST be a load-time error.
- File paths embedded in a guardrails file (e.g., prompt files, `extends:` targets) are resolved relative to the directory containing the YAML file that declares them.
- YAML examples in this document use **block style** for multi-key structures. Flow style (`{ ... }`) is reserved for genuine single-line values such as one-element arrays (`["*"]`).

---
## 2. The Agent Shield model

### 2.1 The five validation stages

Every agent interaction passes through five stages in fixed order:

| Stage | Name | Subject | Detection kinds | Example usage |
|-------|------|---------|-----------------|--------|
| **1** | Input validation | The user's raw input text | `pattern` / `llm` / `classifier` | Jailbreaks, PII, malicious content |
| **2** | State validation | The session state at gate-time | `expression` (deterministic only) | Wrong tool for current context, sensitivity restrictions, missing approvals |
| **3** | Tool execution validation | The proposed tool / agent / endpoint call's parameters | `pattern` / `llm` / `classifier` | Deceptive proposals, parameter manipulation, indirect prompt injection |
| **4** | Post-tool validation | The raw tool / endpoint / agent result | `pattern` / `llm` / `classifier` | PII in tool results, sensitive data leaks, injection payloads in tool output |
| **5** | Output validation | The agent's final response to the user | `pattern` / `llm` / `classifier` | PII leakage, hallucinated content, compliance violations |

A conforming runtime MUST execute the stages in the order above. A failure in any stage MUST short-circuit subsequent stages of that interaction. The `.guardrails.yaml` MAY declare any number of stages without causing runtime errors.

### 2.2 Agent Shield runtime intercepts and controls

The agent proposes a tool call; the runtime decides whether it is allowed. A conforming runtime MUST mediate every tool call, endpoint call, and sub-agent invocation. 

**Example flow** (no violations):

```
User: "Send email to john@example.com"

Stage 1: input validated         (no jailbreak detected)
Stage 2: state checks pass       (no policy restricts send_email)
Stage 3: tool execution validated (intent matches objective)
        ↓
        send_email(to="john@example.com")
        ↓
Stage 4: post-tool validation passes (no sensitive data in result)
        ↓ agent processes tool result
Stage 5: output validated        (no PII in response)
        ↓ response delivered to user
```

### 2.3 Security model and trust boundaries

Agent Shield is a **runtime mediation layer**, not a sandbox. A conforming runtime enforces guard policies only for activity that the host application routes through Agent Shield enforcement points. Host applications remain responsible for identity, backend authorization, tool credentials, infrastructure security, and tool implementation safety.

A conforming integration MUST satisfy these invariants:

- All governed tool calls, endpoint calls, and sub-agent invocations MUST pass through Agent Shield mediation before execution.
- The host application MUST NOT expose a parallel unguarded path for the same governed action.
- The subject validated by Agent Shield MUST be the same subject used by the host application unless the runtime explicitly transforms it and records that transformation in the verdict.
- Security-critical validation errors MUST block or require approval by default. A fail-open behavior MUST be explicit in policy, local to the affected guard or resolver, and logged.
- Unsupported policy versions, unknown guard actions, unknown guarded resource kinds, malformed resolver responses, and unknown mediated invocation shapes MUST fail closed unless an implementation explicitly documents a compatibility mode.
- User input, retrieved content, tool output, endpoint responses, sub-agent responses, and model output MUST be treated as untrusted data unless a trusted host component explicitly promotes them.
- Guard policy files and inherited parent files are security-critical configuration and MUST be protected from unauthorized modification by the deployment.
- Logs, telemetry, approval payloads, and resolver requests MUST be treated as potentially sensitive data flows.

The trusted computing base for Agent Shield enforcement includes the runtime, the selected SDK binding, host integration code that routes governed activity through the runtime, effective guard policy, resource registry, and deployment controls that protect files, secrets, network access, and process integrity. Optional classifiers, human approval services, delegate resolvers, observability sinks, package registries, and release artifacts become part of the trusted computing base when policy or operations rely on them.

These requirements are intentionally independent of deployment mode. Any conforming runtime — whether shipped as the in-process SDK described here, or as a future side-car or gateway implementation — MUST document which paths are mediated and which paths remain outside Agent Shield enforcement.

### 2.4 Core building blocks

The best way to understand Agent Shield is to understand the few concepts that
make up the model and how they fit together. Everything in the rest of the
spec is in service of one artifact — the **guard policy** — so that is where
to start.

#### 1. Guard policy

The unified enforcement primitive. The same schema applies at every stage, so
authoring and review are uniform.

- A guard policy declares **what** it gates (`applies_to`), **when** it is
  engaged (`active_if`), **what to variables to evaluate** (`evaluate_when`), an optional
  **bypass** (`allowed_when`), and **what to do on failure** (`action`).
- `action` is one of `block` / `warn` / `redact` / `append` / `prepend`.
- A guard policy decides via a **resolver**, the same mechanism used to fill
  variables (see §11).

#### 2. Resource

The catalog of things the agent can call and that Agent Shield gates: **tools**
(including MCP tools), **endpoints** (HTTP APIs), and **agents** (sub-agents
or delegates). Resources are *identity only* as behavior are  attached through
guard policies. A guard policy's `applies_to` selects from this catalog.

#### 3. Expression and predicate

A tight, Rego-inspired predicate language designed for single-line YAML.
Statically typed, with **fail-closed** semantics: missing variables evaluate
to `null`, which is `false` in boolean context. A **predicate** is a named,
reusable expression referenced from any other expression.

#### 4. Variable and event

Expressions read from **variables**: typed runtime state with a metadata
envelope (status, set-at, expires-at, source). Two flavors:

- *Runtime variables* — populated automatically by the runtime under
  read-only namespaces (`tool.*`, `endpoint.*`, `agent.*`, `context.*`,
  `result.*`).
- *Declared variables* — defined in YAML and mutated by resolvers or the
  host agent.

Each variable has a **lifetime** that controls when its value resets.
Transitions are driven by **events** drawn from a closed namespace
(`session.*`, `turn.*`, `request.*`, `tool.*`, `endpoint.*`, `agent.*`,
`variable.*`, `guard_policy.*`, `approval.*`, `incident.<name>`).

#### 5. Resolver

The uniform mechanism for filling a variable on demand or producing a guard
policy verdict (since a verdict is also a variable). Five kinds:

- `expression` — deterministic computation.
- `tool` — call a tool the agent already has.
- `human` — human-in-the-loop approval / step-up auth (`HumanResolver`).
- `delegate` — call an external API (fraud, IAM, compliance, custom
  classifier).
- `agent` — defer to another agent.

LLM judges (jailbreak / PII / task-adherence) and bring-your-own classifiers
are expressed as `delegate` resolvers pointing at a configured service.

#### 6. Runtime

What executes everything above. The runtime intercepts the host agent at the
five validation stages, evaluates predicates, mutates variables, dispatches
resolvers, and emits structured telemetry. It deploys **in-process** (Rust /
Python / Node / .NET SDK, framework adapters).

#### How the pieces fit together

```
        ┌──────────────┐
        │   Resource   │
        └──────┬───────┘
               │ selected by applies_to
               ▼
        ┌──────────────┐                  ┌──────────────┐
        │ Guard policy │ ◄── activates ── │    Event     │
        └──────┬───────┘                  └──────────────┘
               │ contains
               ▼
        ┌──────────────┐   references     ┌──────────────┐
        │  Expression  │ ──────────────►  │  Predicate   │
        └──────┬───────┘                  └──────┬───────┘
               │ reads from                      │ reads from
               └────────────────┬────────────────┘
                                ▼
                        ┌──────────────┐
                        │   Variable   │
                        └──────┬───────┘
                               │ populated by
                               ▼
                        ┌──────────────┐    uses    ┌──────────────┐
                        │   Resolver   │ ─────────► │Configuration │
                        └──────────────┘            └──────────────┘
```


---

## 3. The guardrails file at a glance

### 3.1 File discovery

The runtime MUST locate a guardrails file in the following order:

1. An explicit path supplied by the host application.
2. The current working directory: `.guardrails.yaml`, then `guardrails.yaml`.

### 3.2 Composability

A `.guardrails.yaml` file MAY declare an `extends:` list referencing other guardrails files. The runtime merges the chain in order — the first file is the base, each successive file is an additive overlay, and the file declaring `extends:` is the leaf.

**Additive-only invariant.** Each file in the chain MAY only **add** protections. It MUST NOT **remove** or **weaken** controls set by a prior file. Every section in §§4–19 specifies its own merge rule under a **Composability** subsection, but every rule respects this invariant.

**File discovery.** The runtime resolves `extends:` recursively (depth-first, left-to-right) and merges configurations sequentially. Implementations MUST support a chain depth of at least 10 levels. Diamond dependencies MUST be deduplicated. Circular references MUST produce a load-time error.

```yaml
extends:
  - ../org-policies/base.guardrails.yaml
  - ../mcp-server/tools.guardrails.yaml
```

**Order.** `extends:` entries MUST be merged left-to-right, with the declaring (leaf) file applied last. For `extends: [a.yaml, b.yaml]` the order is **a → b → leaf**. Reordering the list MAY change the merged result for fields whose merge rule is non-commutative (e.g., `last-wins`).

**Diamond.** When the same file is reachable through multiple paths, it MUST be loaded once and placed at its earliest position in the chain. If `a.yaml` and `b.yaml` both extend `common.yaml` and the leaf declares `extends: [a.yaml, b.yaml]`, the order is **common → a → b → leaf**.

`extends:` is consumed during loading and does not appear in the merged configuration. File paths in `extends:` are resolved relative to the declaring file's directory.

A common deployment pattern uses three tiers.

| Tier | Authored by | Scope |
|------|-------------|-------|
| Organization | CISO / central security | Non-negotiable controls (jailbreak detection, PII scanning, emergency lockouts). |
| Tools | MCP / platform teams | Reusable guard policies for a class of agent. Applied at the tool catalog. |
| Developer | Application developers | Application-specific rules layered on top. |

### 3.3 Top-level structure

A guardrails file is a YAML object with the following top-level keys, in the recommended order:

```yaml
# Identity ────────────────────────────────────────────────────────────
metadata:                    # §4   identification and versioning
objective:                   # §5   agent's stated goal + forbidden actions
configurations:              # §6   reusable external services

# Foundations (declared once, referenced everywhere) ──────────────────
predicates:                  # §8   reusable named boolean expressions
variables:                   # §10  runtime data + resolvers + lifetimes

# Stage 1 ──────────────────────────────────────────────────────────────
input_validation:            # §14  user-input guard policies

# Resources (referenced by Stages 2–4) ────────────────────────────────
resources:                   # §13  tools, endpoints, agents — identity only

# Stage 2-5 ───────────────────────────────────────────────────────────
state_validation:            # §15  state guard policies
tool_execution_validation:   # §16  proposed-call guard policies
post_tool_validation:        # §17  tool-result guard policies
output_validation:           # §18  agent-response guard policies
```

### 3.4 Structure ordering

The order mirrors the run-time execution order of the five validation stages, with `variables:`, `predicates:`, and `resources:` inserted at the points where they are first needed. It is the recommended authoring order. Implementations MUST accept any ordering; authors and tools creating guardrails files SHOULD use the order above.

---
## 4. `metadata`

```yaml
metadata:
  name: <string>                  # REQUIRED — unique identifier for this guardrails config
  version: <string>               # REQUIRED — semantic version of this file (semver 2.0.0)
  description: <string>           # OPTIONAL — human-readable purpose
  agent_shield_version: <string>  # OPTIONAL — spec version this file requires (see §4.1)
```

**Example:**

```yaml
metadata:
  name: "email-assistant"
  version: "1.0.0"
  description: "Manages user's email inbox"
  agent_shield_version: "2.0"
```

### 4.1 `agent_shield_version` — spec compatibility

`agent_shield_version` declares the **minimum spec version** the file requires. The value MUST be a valid [semver 2.0.0](https://semver.org) version string (`MAJOR.MINOR.PATCH`) or a `MAJOR.MINOR` shorthand (interpreted as `MAJOR.MINOR.0`).

**Compatibility range.** A declared version `X.Y.Z` is satisfied by any runtime spec version `R` such that:

- `R >= X.Y.Z`, AND
- `R` is in the **same compatibility band** as `X.Y.Z`:
  - When `MAJOR == 0` (draft / pre-stable): the band is `MAJOR.MINOR` — `R` MUST satisfy `>= X.Y.Z, < X.(Y+1).0`.
  - When `MAJOR >= 1` (stable): the band is `MAJOR` — `R` MUST satisfy `>= X.Y.Z, < (X+1).0.0`.

**Runtime check.** A conforming runtime MUST refuse to load a file whose declared `agent_shield_version` is not satisfied by the runtime's own spec version, with a load-time error that names both versions. When `agent_shield_version` is omitted, the runtime SHOULD log a warning and proceed; the behavior is implementation-defined and MAY be rejected.

### 4.2 Composability

`metadata` is **leaf-wins** for `name`, `version`, and `description` — the merged identity is exactly the leaf file's. Parent tiers' identity fields are discarded.

`agent_shield_version` is the exception: it is **most-restrictive wins** across the merged chain.

1. Each file in the `extends:` chain MAY declare its own `agent_shield_version`.
2. The merged requirement is the **maximum** of all declared values, ordered by semver precedence.
3. All declared values MUST fall within the same compatibility band (§4.1). A chain that mixes incompatible bands (e.g., a parent declaring `0.13.0` and a child declaring `1.0.0`, or a parent declaring `1.4.0` and a child declaring `2.0.0`) MUST produce a load-time error that names every offending file.
4. The runtime then checks the merged requirement against its own spec version per §4.1.

---
## 5. `objective`

The objective declares what the agent is supposed to do. The runtime uses `goal` and `forbidden` during Stage 3 (tool execution validation) to verify that proposed tool calls align with the agent's stated purpose.

```yaml
objective:
  goal:                    # REQUIRED — list of stated purposes for this tier
    - <string>
  forbidden:               # OPTIONAL — list of explicitly disallowed actions
    - <string>
```

A tier MUST declare at least one `goal` entry. Each entry SHOULD be a single self-contained natural-language statement; multi-purpose tiers SHOULD use multiple entries rather than concatenating them into one string.

**Example:**

```yaml
objective:
  goal:
    - "Help users triage and reply to inbox messages."
    - "Draft replies in a friendly, concise tone."
  forbidden:
    - "Send emails without user confirmation."
    - "Access other users' mailboxes."
```

### 5.1 Composability

`goal[]` and `forbidden[]` are both **concatenated** across the `extends:` chain. The merged structure MUST preserve **ancestry order** AND **authority attribution**: every merged entry MUST remain attributable to the tier that declared it, and merging MUST NOT flatten contributions into an anonymous list.

**Merge rule.** `goal[]` and `forbidden[]` are both **concat by tier, attribution preserved**: every tier MAY declare one or more entries; the merged objective preserves all of them in declaration order, ordered by ancestry, each tagged with its tier index, label, and (optionally) source. A child file MAY refine, narrow, or extend a parent's entries; it MUST NOT silently replace them.

When two tiers' goals or forbidden rules conflict, the higher-authority tier (lower `tier` index) SHOULD win. To help resolve these, the agent using Agent Shield SHOULD decline the action or defer to a human. Conflict resolution is implementation- and model-specific.

**Merged shape (canonical).** When the runtime merges an `extends:` chain, it SHOULD produce a Markdown rendering of the merged objective with the following structure:

1. A short preamble that states the authority ordering (see below).
2. One section per tier, in ancestry order (parents first, leaf last). Each section uses two headings — one for the tier's `goal` and one for the tier's `forbidden[]` — both tagged with the tier's authority index.
3. If used, authority indices MUST start at `0` for the highest-authority tier (the root parent) and increase by `1` for each subsequent tier. Every heading MUST carry its index, e.g. `(authority 0)`, `(authority 1)`, …
4. The heading label SHOULD be the contributing file's `metadata.name`. Implementations MAY substitute another label.
5. Tiers that contribute no `goal` or no `forbidden[]` MUST omit the corresponding heading.

**Recommended preamble.** Implementations SHOULD include a directive equivalent to:

> *Goals and forbidden rules are listed in descending order of authority, starting at `authority 0` (highest). When two sections conflict, the lower-numbered section wins. If a conflict cannot be resolved with confidence, decline the action and ask the user.*

**Source attribution.** Implementations MAY append a `*Source: <path>*` line under each heading.

**Example rendering** (chain: `org-baseline` → `mail-tools` → `email-assistant`):

```markdown
Goals and forbidden rules are listed in descending order of authority, starting at `authority 0` (highest). When two sections conflict, the lower-numbered section wins.
If a conflict cannot be resolved with confidence, decline the action and ask the user.

## org-baseline goal (authority 0)
- Operate strictly within the user's own mailbox.
- Never act on behalf of another user.

## org-baseline forbidden (authority 0)
- Send emails to recipients on the corporate deny-list.
- Disclose internal credentials, API keys, or secrets.

## mail-tools goal (authority 1)
- Use only the supplied mail and calendar tools.
- Decline any request that requires a non-listed capability.

## mail-tools forbidden (authority 1)
- Modify mailbox configuration or forwarding rules.
- Read or write items outside the user's own mailbox.

## email-assistant goal (authority 2)
- Help the user triage and reply to inbox messages.
- Draft replies in a friendly, concise tone.

## email-assistant forbidden (authority 2)
- Send any email without explicit user confirmation.
- Auto-archive or auto-delete messages without confirmation.
```

---
## 6. `configurations`

A **configuration** is a reusable, labeled definition of an external service the Agent Shield runtime calls into (an LLM, a classifier, an HTTP endpoint, an MCP server, or an A2A peer agent). Each entry has a unique `id`; other sections reference the entry by that `id` rather than restating provider, model, or endpoint details inline.

Configurations are NOT to be confused with **resources** (§13). Resources are the tools, endpoints, and sub-agents the agent itself can call, and which Agent Shield governs. Configurations are services Agent Shield *itself* calls into.

### 6.1 Configuration types

| `type` | Used for | Referenced from |
|--------|----------|-----------------|
| `llm` | Validator LLMs (Stages 1, 3, 4, 5) | `<stage>.configuration:`, guard-policy-level `evaluate_when[].llm.configuration:` |
| `classifier` | External ML classifier or content-moderation service | `<stage>.configuration:`, guard-policy `evaluate_when[].classifier.configuration:`, resolvers' `on_demand_by.configuration:` |
| `http_endpoint` | Generic JSON-over-HTTP delegate | Resolvers' `on_demand_by.configuration:` |
| `mcp_server` | MCP `tools/call` against a designated tool | Resolvers' `on_demand_by.configuration:` |
| `a2a_agent` | A2A message to a peer agent | Resolvers' `on_demand_by.configuration:` |

### 6.2 Schema

```yaml
configurations:
  - id: <string>                 # REQUIRED — unique within the merged file
    type: <llm|classifier|http_endpoint|mcp_server|a2a_agent>   # REQUIRED
    default: <bool>              # OPTIONAL — at most one entry per type may set true (llm/classifier only)
    provider: <reverse-domain>   # OPTIONAL — named provider (see §6.5)
    provider_config: <object>    # OPTIONAL — provider-specific config (see §6.5)
    endpoint: <url>              # required for classifier / http_endpoint / mcp_server / a2a_agent unless routing is satisfied by another means (registered provider, peer registry); see routing matrix below
    timeout: <int>               # OPTIONAL — milliseconds
    on_error: <block|allow>      # OPTIONAL — default: block
    on_error_log:                # OPTIONAL
      severity: <critical|high|medium|low|info>
      category: <string>
      message: <string>
    headers:                     # OPTIONAL — supports ${@env|@context|var.*} interpolation (§6.4)
      <name>: <value>

    # type: llm
    model: <string>              # REQUIRED for llm — see "`model:` semantics" below
    max_tokens: <int>            # OPTIONAL — additional provider-tunable kwargs (temperature, top_p, etc.) are applied opportunistically per §6.6
    api_key_env: <string>
    metadata: <any>

    # type: classifier
    threshold: <float>           # 0.0–1.0
    method: <GET|POST>           # default: POST

    # type: a2a_agent
    agent_id: <string>           # REQUIRED for a2a_agent

    # type: mcp_server
    tool: <string>               # REQUIRED for mcp_server — the MCP tool to call
```

Fields marked `REQUIRED` in the comments above MUST be present; their absence MUST produce a load-time error. Fields marked `OPTIONAL` MAY be omitted.

**Default selection.** When a `configurations` entry has `default: true`, it is used by any validation section that does not specify an explicit `configuration:` reference. At most one entry per `type` MUST be marked `default: true`; two or more entries of the same `type` with `default: true` MUST cause a load-time error. If no entry of a requested `type` is marked `default: true`, the runtime MUST treat the **first** entry of that `type` (in declaration order, after `extends:` merging) as the default. The `default:` flag is permitted only on entries of type `llm` or `classifier`; setting `default: true` on entries of type `http_endpoint`, `mcp_server`, or `a2a_agent` MUST produce a load-time error.

**Routing requirement (per type).** Every configuration entry MUST specify enough information for the runtime to dispatch a request. The required fields differ by `type:`:

| `type:` | Routing requirement |
|---------|--------------------|
| `llm` | `model:` REQUIRED. A `type: llm` entry without `model:` MUST cause a load-time schema error. |
| `classifier` | `endpoint:` OR a registered classifier provider. |
| `http_endpoint` | `endpoint:` REQUIRED. Named providers do NOT substitute for `endpoint:` on this type, because `http_endpoint` is the generic-HTTP delegate. |
| `mcp_server` | `tool:` REQUIRED, plus (`endpoint:` OR a registered MCP provider/server). |
| `a2a_agent` | `agent_id:` REQUIRED, plus (`endpoint:` OR a registered A2A provider OR a host-supplied A2A peer registry). |

Configurations missing the required routing fields for their type MUST be rejected at load time. The schema-level comment on `endpoint:` is illustrative; the normative requirements are the matrix above.

**`model:` semantics.** `model:` is the identifier passed to the provider SDK's model parameter. For direct OpenAI providers this is a model name (e.g. `gpt-4o`). For Azure OpenAI providers this is a deployment name (Azure deployment names are user-configured per resource). For Anthropic / Bedrock / Vertex / other providers this is the provider-native model identifier. The runtime treats `model:` as an opaque string and passes it through verbatim to the underlying SDK; it does not synthesize, prefix, or translate the value based on `provider:`.

**`timeout:` bounds.** `timeout:` MUST be a positive integer in milliseconds. Values of `0` or negative MUST cause a load-time error. The runtime MAY enforce an upper bound; values exceeding the runtime's bound MUST be capped to the bound and the runtime MUST emit a structured warning naming the configuration `id` and both values. The default when omitted is implementation-defined per §11.7.

**`on_error_log:` semantics.** `on_error_log:` is emitted when the configuration's `on_error:` policy is triggered (timeout, transport error, malformed response, etc.). When omitted, the runtime auto-emits at `severity: high, category: configuration_error` with a system-generated message identifying the configuration's `id` and the error kind.

**Resolution order** (first match wins):

1. Section-level or per-entry `configuration:` reference.
2. The default entry for the relevant `type`.
3. A constructor parameter supplied at runtime.

### 6.3 Request context

Every external call carries a **Request Context** supplied by the host at session creation. Implementations MUST support these well-known fields:

| Field | Type | Description |
|-------|------|-------------|
| `user_id` | `string \| null` | Authenticated user identifier |
| `tenant_id` | `string \| null` | Tenant / organization identifier |
| `session_id` | `string` | Unique session identifier (host-supplied or auto-generated) |
| `correlation_id` | `string` | Distributed-tracing correlation id |
| `extensions` | `object` | Host-supplied additional fields |

A provider that requires a missing context field MUST return a structured error; the runtime MUST then apply the configuration's `on_error:` policy.

### 6.4 String interpolation

Selected string fields in `configurations[]` support `${...}` interpolation. The available namespaces depend on the field; the rules below specify which namespaces apply to which fields. Three namespaces are defined:

| Namespace | Resolution time | Source | Example |
|-----------|-----------------|--------|---------|
| `@env` | Build time | Process environment variables | `${@env.API_KEY}` |
| `@context` | Per request | Request Context (§6.3) | `${@context.user_id}` |
| `var` | Per request | Session variables (§10) | `${var.data_sensitivity}` |

**The `@` sigil.** Interpolated names whose values are supplied by the runtime carry an `@` prefix (`@env`, `@context`, and — in resolver prompts (§11.4a) — `@tool` / `@endpoint` / `@agent`). The `var` namespace stays bare because it references author-declared session variables; the `var.` prefix exists only as the namespace selector required by `${...}` syntax. The `@`-rule is the same one used in expressions (§7.1): `@` marks runtime-bound identifiers; bare identifiers are author-owned.

**Interpolation is not expression evaluation.** The namespaces above appear only in string interpolation contexts. Configuration `${...}` interpolation does NOT support arbitrary expressions, function calls, arithmetic, predicates, or `${@result.*}`. The substituted value is always a single scalar (string / number / boolean) from the named source, stringified at the point of interpolation.

**Interpolation namespaces vs expression namespaces.** Several names appear in both surfaces but have different access syntax:

| Name | In `${...}` interpolation (this section) | In expressions (§7.5) |
|------|------------------------------------------|------------------------|
| Request Context | `${@context.user_id}` | `@context.user_id` (same underlying data; §7.5.4) |
| Session variable | `${var.<name>}` | `<name>` (bare; §10) |
| Process environment | `${@env.<NAME>}` | not available |
| Tool / endpoint / agent invocation | not available in configuration strings | `@tool.*` / `@endpoint.*` / `@agent.*` (§7.5.1–§7.5.3) |
| Parsed call result | not available | `@result.*` (§7.5.5) |

`${@env.*}` is interpolation-only because it represents build-time process state, not session state. `${var.*}` and `${@context.*}` interpolate the same data that expressions read; the prefixed `var.` / `@context.` form exists in interpolation because the leading `$` requires a namespace selector.

**Scope of application.**

- `${@env.*}`: resolved at build time in **all** string-typed fields of `configurations[]`, including `provider_config` string values, `headers`, and `endpoint`.
- `${@context.*}` and `${var.*}`: resolved per-request in `headers` and `endpoint` only. They MUST NOT be applied inside `provider_config` — named providers receive the Request Context object directly and access these values programmatically.
- None of the three namespaces are interpolated outside `configurations[]`. Resolver `prompt:` strings have their own interpolation surface (§11.4a). Stage-prompt template variables (`{tool_name}`, `{user_input}`, etc.) and log-message templates use a separate `{name}` syntax (§19.1) that draws from declared variables and runtime-supplied template variables, not from `${...}`.

**Missing values.** A missing `${@env.*}` at build time MUST produce a warning log and resolve to the empty string. A missing `${@context.*}` or `${var.*}` at request time MUST produce a warning log and resolve to the empty string. Empty resolved values in a header whose name matches `^(authorization|x-api-key|x-auth-token|cookie)$` (case-insensitive) MUST cause the call to fail with a structured error rather than transmit an unauthenticated request. Implementations MAY extend that header list deployment-side; they MUST NOT shrink it.

**Security constraints.**

- Values interpolated into URL paths MUST be percent-encoded.
- Values interpolated into HTTP headers MUST reject `\r`, `\n`, and null bytes — the call MUST fail rather than inject.
- `${var.*}` values originate from tool outputs and MAY be adversary-influenced; providers MUST NOT use them in SQL, shell commands, or other injection-prone contexts.
- `${@context.extensions.*}` values are host-supplied and MAY be tenant-controlled; the same injection-context restrictions apply.
- Authors SHOULD NOT interpolate `${var.*}` or `${@context.extensions.*}` into URL host components, scheme, or query parameters that the downstream service interprets as authority data. If a deployment requires this pattern, the host MUST validate the interpolated value against an allowlist before configuration.

### 6.5 Providers

A **provider** is a named implementation of an external-service integration, identified by reverse-domain string (e.g., `microsoft.azure.content_safety`, `openai.chat`). When `provider:` is present and registered, the provider handles auth, payload format, and response parsing; the runtime wraps it with common behavior (timeout, threshold comparison, `on_error` policy, observability).

**Provider initialization.**

1. **Registration.** The host registers provider factories on the runtime by name.
2. **Instantiation.** During `build()`, for each configuration entry with `provider:`, the runtime resolves the factory and calls it with `provider_config` (with `${@env.*}` already resolved). Factories return either a provider instance or an error.
3. **Invocation.** Per-request, the runtime calls the provider with input data and the call context.
4. **Wrapping.** The runtime applies timeout, classifier threshold, `on_error`, and observability around every provider call.

**Provider config validation.** Provider factories SHOULD validate their `provider_config:` payload at instantiation. Validation failures MUST be reported as load-time errors with the configuration entry's `id` and the specific field at fault. The runtime MUST NOT proceed with a partially-instantiated configuration entry.

**Unregistered provider names.** If `provider:` is present but unknown:

- If `endpoint:` is also present, fall back to a generic HTTP provider.
- Otherwise, fail at load time.

**Generic HTTP fallback.** When no `provider:` is named and `endpoint:` is present, the built-in generic HTTP provider applies, using `endpoint`, `headers` (with full interpolation), and a fixed body format.

**Well-known names** that conforming runtimes SHOULD support:

| Name | Type | Description |
|------|------|-------------|
| `anthropic.claude` | `llm` | Anthropic Claude models |
| `openai.chat` | `llm` | OpenAI chat completions |
| `microsoft.azure.openai` | `llm` | Azure OpenAI Service |
| `microsoft.azure.content_safety` | `classifier` | Azure AI Content Safety |

**Example (named provider):**

```yaml
configurations:
  - id: "fast-haiku"
    type: llm
    provider: "anthropic.claude"
    model: "claude-3-5-haiku-20241022"
    max_tokens: 500
    default: true

  - id: "content-safety"
    type: classifier
    provider: "microsoft.azure.content_safety"
    provider_config:
      category_thresholds:
        Hate: 2
        Violence: 2
    threshold: 0.8
    on_error: "block"
```

**Example (generic HTTP delegate):**

```yaml
configurations:
  - id: "compliance-api"
    type: http_endpoint
    endpoint: "https://compliance.internal/api/approve"
    timeout: 30000
    headers:
      Authorization: "Bearer ${@env.COMPLIANCE_TOKEN}"
      X-User-Id: "${@context.user_id}"
```

### 6.6 Provider compatibility and unsupported kwargs

The schema in §6.2 permits authors to declare provider-tunable knobs on a `type: llm` entry (e.g. `max_tokens`, `temperature`, `top_p`, `presence_penalty`, `frequency_penalty`, `stop`, `seed`, `response_format`). The set of fields each concrete provider/model accepts varies — Anthropic Claude rejects `presence_penalty` and `frequency_penalty`; Ollama-hosted models reject `seed` and `response_format` on many models; Azure OpenAI varies by deployment and API version. Authors MAY declare any of these fields without knowing the destination provider's compatibility table.

The runtime forwards fields the underlying provider/model accepts and silently drops fields it does not. Each dropped field MUST produce a DEBUG-level log entry that identifies the configuration `id`, the dropped field, and the provider/model context. Observability providers (§19) MAY additionally surface a structured event; the event shape is implementation-defined.

The runtime MUST NOT reject a configuration at load time on the suspicion that a declared field might be unsupported, and MUST NOT fail the call when a field is dropped — enumerating every (provider, model, API-version) tuple is not tractable, and the LLM call remains correct without the missing knob. Authors who require a specific knob to take effect SHOULD pair it with a `provider:` / `model:` known to honor it.

### 6.7 Composability

Configuration `id`s MUST be unique across the merged file chain. When two files declare entries with the same `id`, the merge is **last-wins per field** — the later file's non-null fields override the earlier file's. A later file MUST NOT change `type`. A later file MAY override `default: true` to `false` to demote a parent's default; it MUST NOT promote a non-default entry to default if doing so would conflict with another `default: true` entry of the same `type` already in the chain.

---
## 7. Expression language

The expression language is a Rego-inspired single-line predicate language used in every dynamic field of a guardrails file: (e.g. `active_if:`, `evaluate_when[].expression:`, `allowed_when:`). The full normative reference lives at [`expressions/LANGUAGE.md`](expressions/LANGUAGE.md); this chapter summarizes its surface and specifies the rules that are particular to its use inside `.guardrails.yaml`.

### 7.1 Data model

An expression evaluates to a single value. The values it reads come from four sources, distinguished by **who defines them, who writes them, how they are accessed, and their scope**:

| Source | Defined by | Access | Written by | Scope | § |
|--------|------------|--------|------------|-------|---|
| **Session variables** | Author, in the YAML `variables:` block | Bare name (e.g., `recipients`); status via `@`-namespace (`unset` / `resolved` / `denied`) | Populators, resolvers, runtime API, approval events — mutated over time | Authored `lifetime:` (default depends on writer; see §9.2) | §10 |
| **Predicates** | Author, in the YAML `predicates:` block | Bare name (e.g., `is_privileged`); read-only, evaluated lazily on each reference | The predicate's own expression body | Per reference; `lifetime:` MAY persist the result for its declared scope | §8 |
| **Runtime variables** | The runtime (closed list: `@tool`, `@endpoint`, `@agent`, `@context`, `@result`) | Always prefixed with `@` (e.g., `@tool.params.amount`); read-only; the `@` sigil cannot collide with author-declared names | The runtime, per call | The single call site | §7.5 |
| **Local variables** | The expression author, inline via `:=` | Bare name within the expression | The expression itself | The single expression evaluation | §7.3 |

**The `@` sigil.** A leading `@` marks every identifier whose value is **runtime-bound** to the current call, turn, or session and is not directly authored or freely mutable. Three shapes use it:

| Shape | Examples | Refers to |
|---|---|---|
| `@<namespace>.<path>` | `@tool.params.amount`, `@result.recipients`, `@context.user_id` | Runtime-bound namespace (§7.5) |
| `@<local>` | `@current`, `@incoming` | Runtime-bound merge locals inside `update:` (§10.2) |
| `<var>.@<field>` | `recipients.@status`, `kyc.@source_params` | Runtime-managed metadata on an author-declared variable (§10.3.2) |

Function calls in the runtime-bound namespace also carry `@` (e.g., `@event.fired(<id>)`, §7.4). Bare identifiers (no `@`, no dot prefix) are reserved for things the author owns and can mutate: session variables, predicates, and `:=` locals. The visual contrast lets a reader tell author state from runtime state at a glance.

**Read-priority rule.** Identifier resolution depends on shape:

- **`@`-prefixed** (e.g., `@tool.params.amount`, `@context.user_id`, `@current`) — always resolved against the runtime namespace (§7.5, §10.2). `@`-prefixed names cannot collide with the other sources.
- **Bare identifier** (no `@`, no dot) — resolved in this order:
  1. Local variable (`:=`).
  2. Session variable.
  3. Predicate (§8).

A session variable that shares a name with a predicate shadows it.

An **Event (§9)** is a named, momentary signal from a closed vocabulary, emitted automatically by the runtime (lifecycle, resource calls, variable mutations, guard-policy state changes). The host emits only the `turn.*` and `request.*` lifecycle events. Once fired, the runtime latches the event for the remainder of the session and it is observable from any expression via `@event.fired(<id>)`.

A **Lifetime (§9)** is the reset rule attached to a session variable's value or a stored predicate-variable result; it determines when a session variable's `@status` flips back to `unset`.

The remainder of this chapter specifies the syntax (§7.2–§7.4), the runtime variables in detail (§7.5), and a note on the `duration` type (§7.6). Auto-resolution — when a read of an `unset` session variable triggers its declared resolver — is a property of resolvers, specified in §11.5.

### 7.2 Design principles

- **Rego-familiar syntax** — lowercase keywords (`and`, `or`, `not`, `in`), function-call style for built-ins, `:=` for immutable local bindings, `;` as a conjunction sugar for `and`.
- **Strict typing** — no implicit cross-type coercion; mismatched types evaluate to `false` or `null`, never to a silently converted value.
- **Fail-closed null semantics** — missing variables evaluate to `null`, which folds into `false` in boolean contexts. This is a security invariant.
- **Left-to-right short-circuit** — `and` / `or` MUST evaluate the left operand first and skip the right when the result is determined; ternary MUST evaluate only the selected branch.
- **Predicate-only scope** — no packages, imports, modules, named rules, or multi-rule resolution. Every expression is a single self-contained value computation.

### 7.3 Types and operators

**Types** (LANGUAGE.md §3.1, plus the spec-level `enum` type defined below): `string`, `number`, `boolean`, `array`, `object`, `datetime`, `duration`, `enum`, `null`.


**Operators** — comparison (`==`, `!=`, `<`, `>`, `<=`, `>=`, `in`), logical (`and` / `&&`, `or` / `||`, `not` / `!`), arithmetic (`+`, `-`, `*`, `/`, `%`), ternary (`? :`), assignment (`:=`), indexing (`[]`), member access (`.`), and the conjunction sugar `;` (equivalent to `and`).

The full operator precedence table is normative in LANGUAGE.md §2.5; this chapter does not duplicate it. Authors writing complex expressions should consult that table.

### 7.4 Standard functions

A conforming runtime MUST provide the standard library defined in LANGUAGE.md §5, covering:

- **String** — `contains()`, `startswith()`, `endswith()`, `regex.match()`, `lower()`, `upper()`.
- **Type inspection** — `is_string()`, `is_number()`, `is_boolean()`, `is_null()`, `is_array()`, `is_object()`, `is_datetime()`, `is_duration()`, `is_integer()`, `is_enum()`, `type_name()`.
- **Collection** — `count()`, `sum()`, `max()`, `min()`, `union()`. `max()` and `min()` accept either a single collection (the existing reducer form) or two scalar arguments (`max(a, b)` / `min(a, b)`); on `enum` values both forms compare by member-index order. `union(a, b)` returns the set-union of two arrays, deduplicated, preserving the order of `a` followed by new elements from `b`; either argument MAY be `null`, in which case `null` is treated as the empty array.
- **Object** — `object.get()`, `object.keys()`, `object.values()`, `object.entries()`, `object.merge_patch()`, `has()`. `object.merge_patch(a, b)` deep-merges `b` into `a` per RFC 7396 (Merge Patch): `null` values in `b` delete the corresponding key in `a`; nested objects merge recursively; arrays and scalars in `b` replace the corresponding value in `a`.
- **Time** — `time.now()`, `time.duration()`, `time.clock()`. Datetime accessors (`.year`, `.month`, `.day`, `.hour`, `.minute`, `.second`, `.weekday`).
- **Math** — `abs()`, `round()`, `ceil()`, `floor()`.
- **Conversion** — `integer()`, `number()`, `string()`, `boolean()` (strict parses; return `null` on failure).
- **Quantifier macros** — `all(collection, var -> predicate)`, `any(collection, var -> predicate)`, `count_where(collection, var -> predicate)`.
- **Session-variable status sugar** — `defined()`, `unset()`, `denied()`, `present()`. These are pure metadata reads on session variables and MUST NOT trigger auto-resolution. The full equivalence table and read surface live alongside the status envelope in §10.3.4.

`@event.fired(<event_id>)` is also available wherever expressions are evaluated; it tests whether the named event from the closed namespace (§9.3) has been emitted in the current session. The leading `@` marks `event` as a runtime-bound namespace (§7.1).

### 7.5 Runtime variables

Beyond session variables and local variables, expressions may also reference five **runtime variables** (so named because the runtime, not the author, supplies them per call). Each is an object value, **read-only**, bound at the appropriate scope per call (not declared in the guardrails file), and **always accessed through an `@`-prefixed namespace** (`@tool.params.amount`, `@context.user_id`) — the leading `@` is the syntactic marker for runtime-bound data, so these names cannot collide with session variables or local variables.

| Runtime variable | Bound to | Defined in |
|-----------------|----------|------------|
| `@tool.*` | The proposed tool call (when the runtime is gating an invocation of a tool resource) | §7.5.1 |
| `@endpoint.*` | The proposed endpoint call (when the runtime is gating an invocation of an endpoint resource) | §7.5.2 |
| `@agent.*` | The proposed sub-agent call (when the runtime is gating an invocation of an agent resource) | §7.5.3 |
| `@context.*` | The host-supplied Request Context (§6.3) | §7.5.4 |
| `@result.*` | The parsed result of a completed call | §7.5.5 |

**Security invariant.** Reads from `@tool.*`, `@endpoint.*`, `@agent.*`, `@context.*`, and `@result.*` MUST NOT trigger resolver auto-resolution. Auto-resolution fires only on reads of declared session variables whose `@status == 'unset'` and whose declaration carries `on_demand_by:` (§11.5).

**Type rules.** All five runtime variables return JSON-compatible values (string, number, boolean, array, object, `null`). Missing keys return `null`. Identifiers that are not valid bare names require bracket access: `@tool.params["x-custom-header"]`.

#### 7.5.1 `@tool.*`

`@tool.*` is bound when the runtime is gating an invocation of a `resources.tools[]` entry.

| Field | Type | Description |
|-------|------|-------------|
| `@tool.name` | `string` | The actual tool name being invoked (the agent-supplied identifier), not the matched resource declaration. For invocations of unlisted tools matched by a `"*"` catch-all, this is the unlisted tool's identifier. |
| `@tool.matched_resource_name` | `string` | The `resources.tools[].name` entry that matched this invocation. Equals `@tool.name` for direct-name matches; equals `"*"` when matched by the catch-all entry. |
| `@tool.params` | `object` | Per-call argument payload as supplied by the agent. All keys the agent provided are visible, including any not declared on the resource. |
| `@tool.params.<key>` | `any` | A single argument; missing keys return `null`. |
| `@tool.permission` | `string \| null` | From the matched `resources.tools[].permission` (`read_only` / `read_write` / `execute` / `destructive`). |
| `@tool.description` | `string \| null` | From the matched resource declaration. |
| `@tool.protocol` | `string \| null` | From the matched resource declaration. |

#### 7.5.2 `@endpoint.*`

`@endpoint.*` is bound when the runtime is gating an invocation of a `resources.endpoints[]` entry (or an unlisted endpoint matched by a guard policy's `applies_to.endpoints[]`).

| Field | Type | Description |
|-------|------|-------------|
| `@endpoint.method` | `string` | HTTP method, uppercase. |
| `@endpoint.uri` | `string` | The full request URI. |
| `@endpoint.path` | `string` | The URI path component. |
| `@endpoint.path_params` | `object` | Parameters extracted from the matched URI template (e.g., `{account_id}` becomes `@endpoint.path_params.account_id`). |
| `@endpoint.query_params` | `object` | Query-string parameters; values are string or array-of-string. |
| `@endpoint.params` | `object` | Decoded request body when present, else `{}`. |
| `@endpoint.description` | `string \| null` | From the resource declaration. |

#### 7.5.3 `@agent.*`

`@agent.*` is bound when the runtime is gating an invocation of a `resources.agents[]` entry (a sub-agent call).

| Field | Type | Description |
|-------|------|-------------|
| `@agent.name` | `string` | The actual sub-agent identifier being invoked. For invocations matched by `"*"` catch-all, this is the unlisted sub-agent's identifier. |
| `@agent.matched_resource_name` | `string` | The `resources.agents[].name` entry that matched this invocation. Equals `@agent.name` for direct-name matches; equals `"*"` when matched by the catch-all entry. |
| `@agent.params` | `object` | Payload passed to the sub-agent. |
| `@agent.description` | `string \| null` | From the matched resource declaration. |

#### 7.5.4 `@context.*`

`@context.*` is the host-supplied **Request Context** (§6.3), surfaced to expressions as a read-only namespace. Fields are immutable for the duration of the request / turn / session that bound them.

| Field | Type | Description |
|-------|------|-------------|
| `@context.user_id` | `string \| null` | Authenticated user identifier; `null` when unauthenticated. |
| `@context.tenant_id` | `string \| null` | Tenant / organization identifier; `null` when single-tenant. |
| `@context.session_id` | `string` | Unique session identifier (REQUIRED to be present). |
| `@context.correlation_id` | `string` | Distributed-tracing correlation id (REQUIRED to be present). |
| `@context.extensions` | `object` | Host-supplied additional fields (defaults to `{}`). |
| `@context.extensions.<key>` | `any \| null` | Field within `extensions`; missing keys return `null`. |

The well-known fields `@context.user_id` and `@context.tenant_id` SHOULD be hashed or redacted in logs by deployment policy when they encode regulated identifiers.

#### 7.5.5 `@result.*`

`@result.*` is the parsed result object of the populating tool, endpoint, or agent invocation. It is bound only in `populated_by[].expression:` declared with `phase: after` (the default; see §10.5).

`@result.*` is read-only. It is NOT available in `active_if:`, `evaluate_when[].expression:`, `allowed_when:`, predicate bodies referenced from gating sites, resolver `context:`, resolver `on_allow:`, or any other expression context. Implementations MUST surface a load-time error when `@result.*` appears outside `populated_by[].expression:`.

#### 7.5.6 Availability matrix

Every expression context binds at most one **resource-bound namespace** — whichever of `@tool.*` / `@endpoint.*` / `@agent.*` matches the resource kind the runtime is gating (or populating) — plus zero or more of `@context.*` and `@result.*`. Referencing a namespace not bound for the current context MUST be a load-time error.

Legend: ✓ = available; ✗ = MUST NOT appear (load-time error); "matching kind" = only the namespace whose kind matches the resource being gated; "inherited" = takes the binding of the call site that references the predicate.

| Context | Resource-bound namespace | `@context.*` | `@result.*` |
|---|:---:|:---:|:---:|
| `active_if:`, `evaluate_when[].expression:`, `allowed_when:` on a state or content guard policy bound to a resource | ✓ (matching kind) | ✓ | ✗ |
| `evaluate_when[].expression:` / `allowed_when:` on Stage 1 (`input_validation`) or Stage 5 (`output_validation`) | ✗ | ✓ | ✗ |
| `populated_by[].expression:` (`phase: after`) | ✓ (matching kind) | ✓ | ✓ (matching kind) |
| `populated_by[].expression:` (`phase: before`) | ✓ (matching kind) | ✓ | ✗ |
| Predicate body | inherited | ✓ | inherited |
| Resolver `context:`, `on_allow:` map values, `prompt:` interpolation | ✓ when invocation-bound (matching kind) | ✓ | ✗ |
| Configuration string interpolation (`headers:` / `endpoint:`, §6.4) | ✗ (interpolation only, not expression eval) | ✓ | ✗ |

**Predicate bodies** inherit the namespace bindings of the call site that references them. A predicate that reads `@tool.*` MUST NOT be referenced from a context that does not bind `@tool.*`. Implementations MUST validate predicate references at load time: every reference to a predicate that reads `@tool.*` / `@endpoint.*` / `@agent.*` / `@result.*` MUST come from a context that binds the same namespace, or the load MUST fail with an error naming the predicate, the offending reference site, and the missing namespace.

A read of an in-scope namespace whose underlying value is missing returns `null`; the read MUST NOT raise an evaluation error.

#### 7.5.7 `@`-metadata — session-variable status envelope

The `@`-metadata surface (`<var>.@<field>`) exposes the per-session-variable status & metadata envelope (§10.3.2) and is available in **every** expression context. It is read-only: implementations MUST reject `:=` assignments to `@`-fields and MUST reject resolver `set_variables:` keys that name them. Reading `@`-fields never triggers auto-resolution. Full semantics are in LANGUAGE.md §4.7.

The `@` after the dot (rather than at the head of the identifier) reflects the unifying rule of §7.1: the runtime-managed half of an identifier always carries `@`. Compare:

- `kyc.status` — reads the `status` field of the user-declared variable `kyc` (author-owned value).
- `kyc.@status` — reads the runtime-managed lifecycle status of the variable `kyc` (`unset` / `resolved` / `denied`).

The two never collide: object-field keys cannot begin with `@`, and the spec reserves the `@`-prefixed namespace on every variable for the metadata envelope.

#### 7.5.8 Vendor namespaces

Implementations MAY expose additional read-only namespaces for stage-specific contexts. Any such addition MUST be documented and MUST NOT shadow user-defined identifiers or any namespace listed above.

### 7.6 Note on the `duration` type

`duration` is a first-class **expression value** (produced by `time.duration()` and by datetime arithmetic) and is fully usable in comparisons and arithmetic. It is NOT a declarable `variables[].type:` (the §10.1 `type:` field accepts: `string` / `number` / `boolean` / `array` / `object` / `datetime` / `enum`). Authors who need to persist a duration in a variable should store it as the originating `datetime` (and compute the duration on read) or as a number of milliseconds.

---
## 8. `predicates`

A **predicate** is a named, reusable boolean expression. Predicates are referenced by name from any expression context — `active_if:`, `evaluate_when[].expression:`, `allowed_when:`, `populated_by[].expression:`, resolver `context:`, and resolver `on_allow:`. They are the DRY mechanism for shared boolean logic.

```yaml
predicates:
  is_privileged: "user_role == 'admin'"
```

### 8.1 Schema

```yaml
predicates:
  <name>: <expression>          # bare form
  <name>:                       # object form
    expression: <expression>
    lifetime: <lifetime_spec>   # OPTIONAL — persists the result for the declared lifetime (§9)
```

Each key is a predicate name (snake_case). The value is either a bare expression string or an object that adds a `lifetime:` to persist the result.

### 8.2 Resolution semantics

- Predicate names are resolved during expression evaluation. When the evaluator encounters an identifier that does not match a session variable or local binding, it MUST check the `predicates` map. If found, the predicate body is evaluated as a sub-expression.
- A predicate body MUST evaluate to `boolean` or `null`. Non-boolean results MUST be coerced to `false` (fail-closed).
- Predicates MAY reference other predicates. Circular references MUST produce a load-time error.
- The maximum predicate reference depth a conforming runtime MUST support is 10.
- Predicates are evaluated **lazily** — only when referenced.
- **Resolution priority:** local binding (`:=`) > session variable > predicate name. A predicate name that collides with a variable name is shadowed by the variable.
- Predicate bodies MAY read variables that have an `on_demand_by:`. Auto-resolution propagates by call site (§11.5).

### 8.3 `lifetime:` semantics for predicates

When `lifetime:` is set, the runtime stores the boolean result keyed by the predicate name; the stored result MUST be cleared when its lifetime expires (§9).

### 8.4 Composability

- **Concat across files**: each tier adds its own predicates.
- **Same-name redefinition is a load-time error.** A child tier MUST NOT redefine a parent's predicate.

### 8.5 Example

```yaml
predicates:
  is_privileged: "user_role == 'admin' or (user_role == 'manager' and department == 'security')"
  is_sensitive: "data_sensitivity in ['confidential', 'restricted']"
  high_value: "@tool.params.amount >= 10000"

  document_is_internal:
    expression: "document.sensitivity in ['internal', 'confidential', 'restricted']"
    lifetime:
      until_event:
        - tool.read_document.success
        - variable.document.changed
```

---
## 9. Events and lifetimes

A **lifetime** is the reset rule attached to a piece of session state — a session variable's value or a stored predicate-variable result. The grammar (§9.1) is fixed: `per_call`, `per_turn`, `per_session`, `per_request`, `for: <duration>`, and `until_event: <event_id>`.

An **event** is a named, momentary signal from a closed vocabulary (§9.3). Most events are emitted automatically by the runtime — session / turn / request lifecycle, resource calls, variable mutations, guard-policy state changes. The host emits `turn.*` and `request.*` events explicitly to mark host-defined scopes (§21). Once emitted, an event latches for the remainder of the session: `@event.fired(<id>)` returns `true` until the latch is cleared (§9.4).

Events answer **"has this happened at any point in the current session?"** They do not represent ongoing state — for stateful flags, use a session variable (§10) whose `lifetime:` controls when it auto-clears.

`until_event:` is where the two meet — an event is the condition a variable's lifetime waits on.

### 9.1 Lifetime grammar

A lifetime declares when its carrier — a session variable's value or a stored predicate-variable result — resets. The grammar has two forms: a **bare form** that applies one rule to every outcome, and a **map form** (variables only) that gives `allow`, `deny`, and `cancelled` outcomes their own rules.

#### 9.1.1 Bare form

```yaml
lifetime: per_call            # cleared at the end of the current resource invocation
lifetime: per_turn            # cleared at the end of the current agent turn
lifetime: per_session         # cleared at session end
lifetime: per_request         # cleared at the end of the current host-defined request scope

lifetime:
  for: "3h"                   # cleared at @set_at + duration
lifetime:
  for: "PT1H30M"              # ISO-8601 also accepted

lifetime:
  until_event: <event_id>
lifetime:
  until_event:
    - <event_id>
    - <event_id>

# Shorthand: a bare event id, or a list of them, is sugar for `until_event:`.
lifetime: <event_id>          # ≡ lifetime: { until_event: <event_id> }
lifetime:
  - <event_id>                # ≡ lifetime: { until_event: [<event_id>, ...] }
  - <event_id>
```

The bare form applies one rule to **every** outcome, regardless of whether the variable is `resolved` or `denied`.

**Bare form is literal-only.** A bare-form `lifetime:` value MUST be one of the literal forms above. Expressions are NOT permitted at the bare-form site, because the bare form applies to every outcome and the runtime locals available at write time differ between outcomes (see §9.1.2). Authors who need value-dependent or outcome-dependent lifetimes use the §9.1.2 map form, which permits expressions per branch.

**`for: <duration>`** accepts any duration literal `time.duration()` (§7) accepts in the expression language. The runtime MUST parse the literal at load time; invalid literals MUST be a load-time error. For variables, `@expires_at` (§10.3.2) MUST equal `@set_at + duration` while the variable is live. The runtime MUST treat the variable as expired no later than the next gating evaluation that occurs at or after `time.now() >= @expires_at`. Implementations MAY proactively expire via timer; they MUST NOT delay expiry beyond the next gating evaluation.

**Event-id shorthand.** When `lifetime:` is a bare string matching the §9.3 closed namespace, or a YAML sequence of such strings, the runtime MUST treat it as `until_event:` with that identifier (or list). Identifiers that fail closed-namespace validation MUST be a load-time error, identical to long-form `until_event:`.

#### 9.1.2 Map form (variables only)

When `allow`, `deny`, and `cancelled` outcomes need different lifetimes, declare them explicitly. Each branch is a **lifetime spec**: any §9.1.1 bare form (literal), or an `expression:`-keyed object (§9.1.2.1) that evaluates to one at write time.

```yaml
lifetime:
  allow: <lifetime_spec>      # REQUIRED
  deny:  <lifetime_spec>      # REQUIRED
  cancelled: <lifetime_spec>  # OPTIONAL — defaults to the `deny:` lifetime
```

A `<lifetime_spec>` MUST be exactly one of the shapes below; any other value MUST be a load-time error.

| Shape under `allow:` / `deny:` / `cancelled:` | Interpreted as |
|---|---|
| Bare keyword scalar (`per_call`, `per_turn`, `per_session`, `per_request`) | Literal keyword form (§9.1.1) |
| Bare event-id scalar from the §9.3 closed namespace | `until_event:` shorthand (§9.1.1) |
| Bare YAML sequence of event-id scalars | `until_event:` list shorthand (§9.1.1) |
| Object with `for:` key | Literal `for:` form (§9.1.1) |
| Object with `until_event:` key | Literal `until_event:` form (§9.1.1) |
| Object with `expression:` key | Expression form, evaluated at write time per §9.1.2.1 |

The `expression:`-key marker matches the same convention used by predicates (§8.1) and `evaluate_when[]` (§12.5.1): when a field accepts both a literal and an expression, the expression is carried under an `expression:` key so the parser never needs to consult a literal vocabulary to disambiguate.

The map form is rejected on predicates — predicates are not multi-outcome.

The map form is the canonical shape for "yes once, no for the session" patterns:

```yaml
# A "yes" must be re-confirmed each call; a "no" sticks until session end.
lifetime:
  allow: per_call
  deny: session.end           # event-id shorthand for `until_event: session.end`

# Long form, equivalent to the above:
lifetime:
  allow: per_call
  deny:
    until_event:
      - session.end

# A "yes" lasts three hours; a "no" sticks until the operator clears the
# `incident_active` variable (which fires `variable.incident_active.changed`).
lifetime:
  allow:
    for: "3h"
  deny: variable.incident_active.changed
```

##### 9.1.2.1 Expression form

A branch declared as an object with an `expression:` key carries an **expression** (§7) instead of a literal lifetime. The expression evaluates **once at write time**, after the variable's `update:` has run and the new value is stored, and produces the effective lifetime for that single write. The lifetime instance it returns fixes `@expires_at` (§10.3.2) and is captured in audit logs as `effective_lifetime` (§11.9).

```yaml
lifetime:
  allow:
    expression: "@incoming == 'allow_always' ? 'per_session' : 'per_call'"
  deny: per_session
```

The `expression:` key is the sole syntactic marker for the expression form. A bare scalar branch value MUST match one of the literal shapes in §9.1.2's table; runtimes MUST NOT promote a non-matching scalar into an expression.

**Available scope** (matches `update:` per §10.2):

| Identifier | Value |
|---|---|
| `@incoming` | The value just stored on the variable (after `update:` has run). On the `deny:` and `cancelled:` branches, `@incoming` is `null`. |
| `@current` | The variable's prior stored value (or `null` if previously `unset`). |
| Declared session variables | Read-only, by bare name. |
| Predicates (§8) | Read-only, by bare name. |

The expression MUST NOT reference invocation-bound namespaces (`@tool.*`, `@endpoint.*`, `@agent.*`, `@result.*`) or `@context.*`. Implementations MUST surface a load-time error when these namespaces appear inside the `expression:` form. Auto-resolution (§11.5) MUST NOT fire — the `expression:` form is not a gating site.

**Permitted return values.** The `expression:` form MUST return one of:

| Return value | Interpreted as |
|---|---|
| String matching a §9.1.1 keyword (`per_call`, `per_turn`, `per_session`, `per_request`) | That bare-form lifetime |
| String matching the §9.3 closed event namespace | `{ until_event: <that id> }` (per §9.1.1 event-id shorthand) |
| `duration` value (§7.6) | `{ for: <that duration> }` |
| `{ for: <duration> }` map | That `for:` lifetime |
| `{ until_event: <id> | [<id>, ...] }` map | That `until_event:` lifetime |

Any other return value (including `null`, type-incompatible scalars, malformed maps, or unknown event ids) MUST cause the runtime to fall back to the per-kind default lifetime in §9.2 and emit a structured warning naming the variable, the branch, and the offending value. This fail-soft posture matches §10.2's policy on type-incompatible `update:` results: a lifetime mistake degrades to the safe default rather than failing the gate.

**Outcome dispatch.** Only the branch that matches the resolver's outcome is evaluated. On `allow`, only `allow:` evaluates; on `deny`, only `deny:` evaluates; on `cancelled`, only `cancelled:` (or, when omitted, `deny:`) evaluates.

##### 9.1.2.2 Examples

**Tri-state human approval** — value-conditional persistence collapses to one variable:

```yaml
- name: send_mail_decision
  type: enum
  members: [allow_once, allow_always]
  on_demand_by: { kind: human, prompt: "Authorize sending mail to ${@tool.params.to}?" }
  lifetime:
    allow:
      expression: "@incoming == 'allow_always' ? 'per_session' : 'per_call'"
    deny:
      until_event:
        - session.end
```

**Resolver-supplied duration** — the value carries the duration directly:

```yaml
- name: temporary_grant
  type: object   # { mode: string, minutes: number }
  on_demand_by: { kind: human, prompt: "Approve for how long?" }
  lifetime:
    allow:
      expression: |
        @incoming.mode == 'permanent'
          ? 'per_session'
          : @incoming.minutes * time.duration('1m')
    deny: per_session
```

The `expression:` body returns a `duration` value, which is interpreted as `{ for: <duration> }` per the return-value table above.

**Cross-variable logic** — admin gets a longer window:

```yaml
predicates:
  is_admin: "user_role == 'admin'"

variables:
  - name: send_mail_decision
    type: enum
    members: [allow_once, allow_always]
    on_demand_by: { kind: human, prompt: "..." }
    lifetime:
      allow:
        expression: |
          is_admin and @incoming == 'allow_always' ? 'per_session' :
          @incoming == 'allow_always'              ? { for: '15m' } :
                                                      'per_call'
      deny: per_session
```

#### 9.1.3 Expiry semantics

When a variable's lifetime expires, the runtime transitions `@status` from `resolved` (or from `denied`) back to `unset` and clears the value. Predicate lifetime expiry clears the stored boolean result, forcing recomputation on the next reference.

### 9.2 Defaults when omitted

| Carrier | Default `lifetime:` |
|---------|---------------------|
| Variable resolved by `kind: tool` | None (persists at `@status == 'resolved'` until cleared by `reset_by:`, host-side reset, or a subsequent write). |
| Variable resolved by `kind: human`, `kind: delegate`, or `kind: agent` | `per_session`. |
| Variable resolved by `kind: expression` | Recomputed on every read — no stored result. |
| Predicate without `lifetime:` | Recomputed on every reference. |

Guard policies do NOT carry a `lifetime:` field. To bound a guard policy's activation, use `active_if:` referencing `@event.fired()` (§12) or a session variable.

### 9.3 Event namespace

The runtime operates a single in-memory event bus. The namespace is **closed** — every event identifier comes from the table below; identifiers outside the table MUST cause a load-time error when used in `until_event:` or `@event.fired()` (§7).

| Event identifier | When emitted |
|------------------|--------------|
| `session.start` | Runtime startup |
| `session.end` | Runtime shutdown / session disposal |
| `turn.start` | Beginning of an agent turn (host-driven) |
| `turn.end` | End of an agent turn (host-driven) |
| `request.start` | Beginning of a request scope (host-driven) |
| `request.end` | End of a request scope (host-driven) |
| `tool.<name>.called` | Tool invoked, before result is observed (exactly once per call) |
| `tool.<name>.success` | Tool execution succeeded (after `populated_by:` writes have applied) |
| `tool.<name>.failure` | Tool execution failed or was blocked at gating |
| `endpoint.<id>.called` / `.success` / `.failure` | As above, for endpoint resources. `<id>` is the endpoint's `pattern` after percent-decoding and normalization. |
| `agent.<name>.called` / `.success` / `.failure` | As above, for sub-agent resources. |
| `variable.<name>.changed` | Variable value mutated and accepted by the variable's `update:` expression (§10.2). |
| `guard_policy.<name>.activated` | Guard policy transitioned from inactive to active |
| `guard_policy.<name>.deactivated` | Guard policy transitioned from active to inactive |
| `guard_policy.<name>.passed` | Guard policy was active for an invocation and its `evaluate_when:` chain passed (no failure or all failures bypassed via `allowed_when:`). |
| `guard_policy.<name>.failed` | Guard policy was active for an invocation and at least one `evaluate_when:` entry failed and was not bypassed. |
| `incident.resolution_loop` | The `kind: tool` resolution loop bound was exceeded (§11.10.2). |

The `<name>` portion is the matching resource or guard-policy `name:`; it is bound to identifiers declared elsewhere in the file (or `"*"` catch-all entries) and is not author-defined at the event level. Hosts MUST NOT introduce new event identifiers; the only events a host actively emits are `turn.*` and `request.*` (§21).

**Default lifetime.** Every event in the closed namespace latches with **`per_session`** semantics. The latch persists until cleared by `session.end` or by `clear_event(<id>)` (§9.4). Consequently `@event.fired(<id>)` answers "has this happened at any point in the current session?", not "is it happening now."

### 9.4 Latching and clearing

Once an event is emitted, it remains observable to `@event.fired(<id>)` (§7) for the remainder of the session. Re-emissions of the same identifier do not change the latched flag (the event is already fired). Two operations clear a latched event:

1. `session.end` clears all latched events.
2. `clear_event(<id>)` on the runtime API (§21) clears the named event.

The `until_event:` lifetime form is independent of the latched flag — it triggers on every fresh emission of the named event, and `clear_event()` does NOT itself produce an `until_event:` trigger.

### 9.5 Ordering guarantees

Within a single resource call, the runtime MUST emit:

- `<resource_kind>.<name>.called` strictly **before** any `variable.<name>.changed` event produced by a populator.
- `<resource_kind>.<name>.success` strictly **after** all `variable.<name>.changed` events for that call.
- `guard_policy.<name>.passed` / `.failed` events for each gating evaluation strictly **before** the corresponding `<resource_kind>.<name>.called` (the verdict precedes the call).
- Guard-policy `activated` / `deactivated` events emitted during the state re-evaluation that immediately follows the call MUST come after `<resource_kind>.<name>.success` and before `turn.end`.

---
## 10. `variables`

A **session variable** (declared at the top level under `variables:`) is a typed, named wrapper around an expression-language value (§7.3) that **persists across calls** within a session. Each one carries:

- a **value** of its declared type (§10.1),
- a **status** — `unset` / `resolved` / `denied` (§10.3.1),
- and an `@`-**metadata envelope** (§10.3.2) the runtime maintains.

Session variables are the persistent substrate every guard policy reads from. Their value and `@status` are mutated by five distinct writers:

| Writer | Style | Defined on the variable as | Specified in |
|--------|-------|----------------------------|--------------|
| **Populator** | Push — fires when a named resource executes (tool / endpoint / agent) ; writes a value derived from the call's payload. | `populated_by[]` | §10.5 |
| **Resolver** | Pull — fires on demand when a gating expression reads the variable while `@status == 'unset'`; returns a wire envelope (`decision`, `value`, `set_variables`, `reason`). | `on_demand_by:` | §11 |
| **Resetter** | Clear — fires when a named resource executes; sets the variable back to `unset`. | `reset_by[]` | §10.6 |
| **Runtime API** | Direct host write via `set_variable()` / `reset_variable()`. The host MAY supply a `reason:` and an override `lifetime:` per call (§21). | (no declaration; host-driven) | §21 |

A session variable MAY also declare a **lifetime** (§9.1) that ages its value out automatically.

Session variables are declared at the top level of the guardrails file:

```yaml
variables:
  - name: <string>
    type: <string|number|boolean|array|object|datetime|enum>
    # ... see §10.1
```

### 10.1 Schema

```yaml
variables:
  - name: <string>             # REQUIRED — unique identifier
    type: <string|number|boolean|array|object|datetime|enum>   # REQUIRED
    members: [<string>, ...]   # REQUIRED for type: enum; ordered low → high; ≥ 2 unique entries
    description: <string>      # OPTIONAL
    default: <value>           # OPTIONAL — initial value at session start (status: resolved)
    key: <expression>          # OPTIONAL — binding-key expression (§10.4)
    update: <expression>       # OPTIONAL — merge expression evaluated on each write while @status == 'resolved'; default: "@incoming" (§10.2)
    lifetime: <lifetime_spec>  # OPTIONAL — see §9.1
    on_demand_by: <resolver>   # OPTIONAL — inline resolver (§11)
    populated_by:              # OPTIONAL — populator entries (§10.5)
      - kind: <tool|endpoint|agent>   # REQUIRED — discriminator
        name: <string>                # for kind: tool / kind: agent
        pattern: <pattern>            # for kind: endpoint
        methods: [<method>]           # for kind: endpoint
        phase: <before|after>         # OPTIONAL — default: after
        expression: <expr>
        extractor: <reverse-domain>
    reset_by:                  # OPTIONAL — resetter entries (§10.6)
      - kind: <tool|endpoint|agent>   # REQUIRED — discriminator
        name: <string>                # for kind: tool / kind: agent
        pattern: <pattern>            # for kind: endpoint
        methods: [<method>]           # for kind: endpoint
        phase: <before|after>         # REQUIRED — no default
```

**`default`** initializes the variable to the given value at session start with `@status == 'resolved'`. The value MUST be type-compatible (and, for `type: enum`, MUST be one of `members:`). Variables without a `default:` start with `@status == 'unset'` and value `null`. `default:` is a session-init hint only; it is NOT re-applied after a `reset_by:` fires or after a host-side reset.

**`datetime`** values are ISO-8601 timestamps. The runtime MUST parse them into native datetime objects. The standard-library `max()` / `min()` functions (used inside `update:` expressions per §10.2) compare `datetime` values chronologically.

**`enum`** is a closed string domain (§7.3). The required `members:` list both enumerates the legal values and defines the ordering used by `max()` / `min()` and the `<` / `<=` / `>` / `>=` operators. `members:` is part of the variable's stable contract: child files MUST NOT redeclare a parent's variable, so they cannot extend or reorder its `members:` list (§10.9). Comparison ergonomics are defined in §7.3.

**Boolean-flag shorthand.** A variable declared with only a `name:` (no `type:`) MUST be interpreted as `type: boolean` with `default: false`. This is the canonical shape for host-driven flags such as lockdowns, freezes, and out-of-band approvals; the host raises and lowers the flag through `set_variable()` / `reset_variable()` (§21).

```yaml
variables:
  - { name: lockdown_active }                          # ≡ type: boolean, default: false
  - { name: incident_active, lifetime: { for: "30m" } } # boolean flag that auto-clears after 30 minutes
```

### 10.2 The `update:` expression

When a write transitions a variable that is already `@status == 'resolved'`, the runtime evaluates the variable's `update:` expression to produce the value that gets stored. `update:` is a single-line expression (§7) with two implicit identifiers bound during evaluation:

| Identifier | Value |
|---|---|
| `@current` | The variable's currently stored value. |
| `@incoming` | The candidate value the writer (populator, resolver, runtime API) wants to write. |

The `@` prefix marks `current` and `incoming` as runtime-bound merge locals (§7.1) — the runtime supplies their values per write, not the author. The expression's result is what gets stored, subject to the variable's declared `type:` (and `members:`, when `type: enum`).

**Default.** When `update:` is omitted, the runtime behaves as if `update: "@incoming"` were declared: every write replaces the previous value.

**When `update:` is evaluated.** `update:` runs **only** when the existing `@status == 'resolved'`. On `unset` and `denied`, the incoming value is accepted unconditionally and the variable transitions to `resolved`. This rule generalizes the legacy "first write bypasses policy" behavior; it ensures a variable that has never been set, or was just denied and re-armed, can always accept a fresh value.

**Type compatibility.** The result of `update:` MUST be type-compatible with the variable's declared `type:`. Type-incompatible results MUST be dropped with a structured warning, leaving the existing value unchanged. For `type: enum`, the result MUST be one of `members:`; non-member results are likewise dropped with a structured warning.

**Available scope.** `update:` can read `@current`, `@incoming`, declared session variables, and predicates. It MUST NOT reference invocation-bound namespaces (`@tool.*`, `@endpoint.*`, `@agent.*`, `@result.*`) or `@context.*` — `update:` is a merge function over variable state, not a value source. Implementations MUST surface a load-time error when these namespaces appear inside an `update:` expression.

**Name collisions.** Because `@current` and `@incoming` live in the runtime namespace (§7.1), they cannot collide with author-declared identifiers. Authors MAY freely name a session variable, predicate, or `:=` local `current` or `incoming`; the bare names refer to the author-declared identifier and the `@`-prefixed forms refer to the runtime locals.

**Auto-resolution.** Reads of `unset` session variables inside `update:` MUST NOT trigger resolver auto-resolution; `update:` is not a gating site (§11.5). They evaluate to `null` and propagate as usual.

#### 10.2.1 Common update patterns

The standard-library functions `max()`, `min()`, `union()`, and `object.merge_patch()` (§7.4) cover the patterns that earlier drafts of this specification encoded as a closed `update_policy:` enum.

| Pattern | `update:` expression | Notes |
|---|---|---|
| Replace (default) | `"@incoming"` (or omit) | Last write wins. |
| Ratchet up over `enum` | `"max(@current, @incoming)"` | Sensitivity / classification levels. |
| Ratchet down over `enum` | `"min(@current, @incoming)"` | |
| Ratchet over numbers / datetimes | `"max(@current, @incoming)"` / `"min(@current, @incoming)"` | Natural numeric / chronological order. |
| Set-union into an array | `"union(@current, @incoming)"` | Dedups; preserves order. Authors who push a single scalar MUST wrap it: `"union(@current, [@incoming])"`. |
| Deep-merge an object | `"object.merge_patch(@current, @incoming)"` | RFC 7396 semantics. |
| Counter / accumulator | `"@current + @incoming"` | Each populator writes the increment; `update:` adds it. |
| First-write-wins | `"@current"` | Once set, never overwritten by subsequent writes (until the variable is reset). |
| Clamp | `"min(max(@current + @incoming, 0), 100)"` | Compose freely. |

#### 10.2.2 Worked examples

**Sensitivity ratchet (`enum` + `max`).**

```yaml
variables:
  - name: data_sensitivity
    type: enum
    members: [public, internal, confidential, restricted]
    default: public
    update: "max(@current, @incoming)"
```

Reads can compare against bare member literals (§7.3): `data_sensitivity >= 'confidential'` evaluates by member-index order.

**Set-union (array + `union`).**

```yaml
variables:
  - name: data_jurisdictions
    type: array
    default: []
    update: "union(@current, @incoming)"
```

**Per-call counter (number + addition).**

```yaml
variables:
  - name: send_count_today
    type: number
    default: 0
    update: "@current + @incoming"
    populated_by:
      - kind: tool
        name: send_email
        phase: before
        expression: 1   # writer pushes the increment; update: sums it.
```

The populator's job is to compute the increment; the variable's `update:` defines the accumulation. This separation lets multiple populators (e.g., `send_email` and `send_email_external`) feed the same counter without duplicating the merge logic.

**First-write-wins / immutable-after-set.**

```yaml
variables:
  - name: initial_role
    type: string
    update: "@current"   # ignore subsequent writes once @status == 'resolved'
```

**Clamp (compose freely).**

```yaml
variables:
  - name: risk_score
    type: number
    default: 0
    update: "min(max(@current + @incoming, 0), 100)"
```

**Compound object merge.** When one object variable carries multiple fields with different merge behaviors, the merge is expressed inline. Wrapping the per-field expressions in `object.merge_patch(@current, …)` preserves any fields the populator did not produce; the inner `coalesce()` calls (§7.4) tolerate partial-update populators where `@incoming` carries only a subset of fields.

```yaml
variables:
  - name: document
    type: object
    default: { sensitivity: "public", jurisdictions: [], trusted: false }
    update: |
      object.merge_patch(@current, {
        "sensitivity":   max(@current.sensitivity,
                             coalesce(@incoming.sensitivity, @current.sensitivity)),
        "jurisdictions": union(@current.jurisdictions,
                               coalesce(@incoming.jurisdictions, [])),
        "trusted":       coalesce(@incoming.trusted, @current.trusted)
      })
    populated_by:
      - kind: tool
        name: read_document
        expression: "@result"
```

Authors who do not need partial-update tolerance MAY omit `coalesce()` and use a literal object directly.

**Cross-field dependent merge.** The expression form makes computations across fields straightforward:

```yaml
variables:
  - name: incident
    type: object
    default: { severity: 0, alerts: [], escalated: false }
    update: |
      {
        "severity":  max(@current.severity, @incoming.severity),
        "alerts":    union(@current.alerts, @incoming.alerts),
        "escalated": @current.escalated or
                     max(@current.severity, @incoming.severity) >= 8
      }
```

`escalated` is computed from the *merged* `severity`, not from either operand alone.

**Splitting a multi-field object into separate variables.** When the fields of a logical object never need to be read together, the canonical alternative is to declare each field as its own variable (with its own type, `update:`, and populators). Reads change shape (`document.sensitivity` becomes `document_sensitivity`), but each variable becomes self-contained and the populator block does not have to know about unrelated sibling fields. The choice between one object with an inline `update:` and N independent variables is an authoring style decision, not a semantic one.

**Object nesting limit.** Implementations MUST support **at least 10 levels** of object nesting in:

1. Variable values (reads, writes, `populated_by:`, resolver-supplied values).
2. `@result.*` access in `populated_by[].expression:` evaluation.
3. The result of `update:` expressions, including `object.merge_patch()` applications.

Configurations that exceed this limit are implementation-defined and MAY be rejected.

### 10.3 Status and metadata envelope

Every declared session variable carries an envelope: its current value plus runtime-maintained metadata. Bare-identifier reads (e.g., `recipients`) return the value. Metadata is queryable through a parallel `@`-namespace and through sugar functions (§10.3.4).

#### 10.3.1 Status enum

| Status | Meaning | Triggers auto-resolution? |
|--------|---------|---------------------------|
| `unset` | No recorded value. Initial state for variables without `default:`. Result of `reset_by:`, host-side reset, or lifetime expiry. | **Yes** — if `on_demand_by:` is declared, the next read in a gating expression fires the resolver. |
| `resolved` | Value populated by a resolver, an expression evaluation, a `populated_by:` write, or the runtime API. Value MAY be any type-compatible value, including `null`. | No |
| `denied` | A resolver chain's final outcome was `deny` or `cancelled`. `@deny_kind` distinguishes the two; `@source_reason` holds the resolver's `reason` text. Intermediate `deny` / `cancelled` decisions rescued by a subsequent `fallback:` MUST NOT cause this transition; only the chain's final outcome does (§11.3a, §11.6). | No |

A `null` **value** with `@status == 'resolved'` is distinct from a variable with `@status == 'unset'`. The runtime MUST distinguish them.

**Fail-closed reads.** Reading a variable whose `@status == 'unset'` MUST evaluate to `null`, which folds into `false` for boolean purposes. Implementations MUST NOT silently coerce `null` into any other value. Gating sites (`evaluate_when[].expression:` and `allowed_when:`) MAY first trigger auto-resolution per §11.5; non-gating sites SHALL NOT.

#### 10.3.2 Metadata fields

The metadata is read-only from policy expressions. Writing to a metadata field MUST be a load-time error.

| Field | Type | Set when |
|-------|------|----------|
| `@status` | `unset` \| `resolved` \| `denied` | Always reflects the current state. Never `null`. |
| `@key` | any \| null | The key under which the current read or write resolved. `null` when the variable is not declared with `key:` (§10.4), or when `key:` evaluated to `null` at the current site. |
| `@set_at` | datetime \| null | When the variable last transitioned to `resolved`. `null` while `unset` or `denied`. |
| `@expires_at` | datetime \| null | When the lifetime will expire. Set to `@set_at + duration` for `for: <duration>` lifetimes; `null` for `per_call` / `per_turn` / `per_session` / `per_request` and `until_event:` lifetimes (those are bounded by scope or event, not by wall-clock time), and `null` when no `lifetime:` is declared. |
| `@source_kind` | string \| null | Writer kind that last produced the value: `human` / `delegate` / `agent` / `expression` / `tool` (resolver kinds), `populator`, or `host_api`. `null` only when the variable has never transitioned to `resolved` or `denied`. |
| `@set_by` | string \| null | Identifier of the resolver, populator, or tool that last set the variable. `null` for host runtime API writes. |
| `@deny_kind` | `'deny'` \| `'cancelled'` \| null | Set when `@status == 'denied'`. `cancelled` indicates explicit user cancellation (§11.3a); `deny` indicates a deterministic denial. `null` while `@status != 'denied'`. |
| `@source_reason` | string \| null | Free-form audit text supplied by the writer — the resolver's `reason:`, the host's `set_variable(name, value, { reason })` argument, or an implementation-default string. `null` when no reason was supplied. |
| `@source_params` | object \| null | Snapshot of the resource-bound namespace (`@tool.params`, `@endpoint.path_params` + `@endpoint.query_params` + `@endpoint.params`, or `@agent.params`) at the writer's call site, captured at the moment the variable last transitioned to `resolved` via a populator or resolver. `null` for host runtime API writes and while `@status != 'resolved'`. Read-only and never triggers auto-resolution. For `endpoint` writers, `@source_params` is the merged object `{ path: <path_params>, query: <query_params>, body: <params> }`. |

#### 10.3.3 Status transitions

| Trigger | From | To |
|---------|------|----|
| Session start, variable has `default:` | (initial) | `resolved` |
| Session start, no `default:` | (initial) | `unset` |
| Any write (resolver `value:` / `set_variables:`, runtime API, `populated_by:`) | any | `resolved` |
| `reset_by:` (any phase), host-side reset | any | `unset` |
| Resolver chain's final outcome is `deny` or `cancelled` (no fallback rescued) | any | `denied` |
| Lifetime expires (bare form) | `resolved` or `denied` | `unset` |
| Lifetime expires (map form, `allow:` branch) | `resolved` | `unset` |
| Lifetime expires (map form, `deny:` or `cancelled:` branch) | `denied` | `unset` |

#### 10.3.4 Two read surfaces (and the status sugar)

Every session variable has two parallel read surfaces. The `@`-namespace is the primitive form; the four **status sugar** functions are aliases over the common predicates:

| Sugar function | Equivalent primitive | Returns |
|----------------|----------------------|---------|
| `defined(x)` | `x.@status == 'resolved'` | boolean |
| `unset(x)` | `x.@status == 'unset'` | boolean |
| `denied(x)` | `x.@status == 'denied'` | boolean |
| `present(x)` | `defined(x) and x != null` | boolean |

```yaml
allowed_when: "recipients.@status == 'resolved'"   # primitive
allowed_when: "defined(recipients)"                # sugar — same meaning
allowed_when: "denied(recipients)"                 # @status == 'denied'
allowed_when: "unset(recipients)"                  # @status == 'unset'
allowed_when: "present(recipients)"                # resolved AND not null
```

Each sugar function takes a **bare session-variable identifier** as its single argument. Both read surfaces are first-class — implementations MUST support them equivalently. Reads through either surface MUST NOT trigger resolver auto-resolution; they are pure metadata reads. Full function semantics are defined in [`expressions/LANGUAGE.md`](expressions/LANGUAGE.md) §5.9.

### 10.4 Binding keys (`key:`)

A variable MAY declare a `key:` expression. When present, the variable is a **per-key store** rather than a single slot: every value, status, and metadata field in §10.3.2 is scoped to the key under which it was last written. A read against a key that has no stored entry MUST evaluate as `@status == 'unset'` with value `null`.

Binding keys are a security primitive. They eliminate a class of attack in which a value populated for one set of call parameters is reused by a subsequent gate that concerns a different set of call parameters (e.g., participant lists for one channel reused by a send to another channel). Without a binding key, the runtime cannot distinguish "this value is fresh for the call I am gating now" from "this value was produced by an unrelated earlier call." A keyed variable makes that distinction structural rather than discretionary.

#### 10.4.1 Schema

```yaml
variables:
  - name: <string>
    type: <type>
    key: <expression>          # OPTIONAL — re-evaluated at every read and write
```

`key:` MUST be a single-line expression (§7). It MAY reference any namespace bound at the evaluation site — typically `@tool.params.*`, `@endpoint.path_params.*`, `@endpoint.params.*`, `@agent.params.*`, `@context.*`, or any session variable.

#### 10.4.2 Resolution

- The `key:` expression is **re-evaluated lazily** at every read and every write against the runtime-variable namespace bound at that site (§7.5).
- A `null` key at any site MUST be treated as **unset**: reads return `@status == 'unset'` and value `null`; writes (populator, resolver `value:` / `set_variables:`, runtime API) MUST be rejected with a structured warning and not stored.
- Keys are compared by **value equality**. Composite keys (objects, arrays) MUST be compared by deep equality after canonical ordering of object keys.

#### 10.4.3 Write-time semantics

When a populator (§10.5), resolver (§11), or `set_variable()` runtime API call (§21) writes a keyed variable, the runtime evaluates `key:` against the **writer's bound namespace** and stores the new `(value, status, metadata, lifetime)` tuple under that key. Host runtime API calls supply the key explicitly via the optional `key:` argument to `set_variable()` / `reset_variable()` (§21). Existing entries under the same key are merged per the variable's `update:` expression (§10.2); entries under other keys are not affected.

#### 10.4.4 Read-time semantics

Reads (bare-identifier reads and `@`-metadata reads through the surfaces in §10.3.4) evaluate `key:` against the **reader's bound namespace** and look up the resulting key. A missing key entry MUST read as `@status == 'unset'` with value `null`. Auto-resolution (§11.5) fires per the existing rules; the resolved key is supplied to the resolver as `requested_key` in the request payload (§11.5).

#### 10.4.5 Lifetime, reset, and events

- **Lifetime.** Each per-key entry has an independent lifetime instance. Lifetime expiry transitions only that key's entry to `unset`; other keys' entries are unaffected.
- **`reset_by:`.** A `reset_by[]` entry on a keyed variable resets only the key matched at the resetter's call site. To clear every key, declare a host-side reset via `reset_variable()` (§21).
- **`variable.<name>.changed` events.** Events emitted for keyed variables MUST include the key in the event payload (e.g., `{ key: <value> }`). The closed event identifier itself does not encode the key.

#### 10.4.6 Writer / reader convention

`key:` is a single expression evaluated at both write sites and read sites. Authors are responsible for ensuring the expression evaluates to the same logical identifier across every resource that reads or writes the variable. The most common pattern is to rely on a shared parameter name (e.g., `@tool.params.channel_id` works at every tool that names its channel argument `channel_id`).

When the reader's namespace cannot compute the same key — for example, a guard policy applies to a tool whose parameters do not name the keying field — `key:` evaluates to `null` at the read site, the lookup misses, `@status` reads as `unset`, and the gate fails closed. This is the security-correct behavior; authors who need to cross namespaces SHOULD either align parameter names across the tool surface or split the variable into one per namespace.

#### 10.4.7 Load-time validation

- The `key:` expression MUST NOT reference the variable being declared (direct or transitive). Implementations MUST detect this at load time and produce an error.
- The `key:` expression MUST be valid against §7.5's availability matrix. Identifiers that are never bound at any site that reads or writes the variable MUST produce a load-time warning naming the variable, the expression, and the unreachable identifier.

#### 10.4.8 Worked example

```yaml
variables:
  - name: "channel_participants"
    type: array
    key: "@tool.params.channel_id"
    on_demand_by:
      kind: tool
      name: "get_channel_participants"
    populated_by:
      - kind: tool
        name: "get_channel_participants"
        expression: "@result.participants"
    lifetime:
      for: "5m"

state_validation:
  guard_policies:
    - name: "dlp_internal_doc_external_channel"
      applies_to:
        tools: [ "send_slack_message" ]
      active_if: "document.sensitivity in ['internal','confidential','restricted']"
      evaluate_when:
        - expression: "all(channel_participants, p -> endswith(p.email, '@microsoft.com'))"
          reason: "Internal documents may only be sent to channels whose participants are all @microsoft.com."
```

When `get_channel_participants(channel_id="C-A")` succeeds, the populator stores the participants under key `"C-A"`. A subsequent `send_slack_message(channel_id="C-B")` evaluates the gate's `evaluate_when:` against key `"C-B"` — which has no stored entry — so `channel_participants` reads as `unset` and the gate fails closed (or fires the resolver, which then signals the agent to fetch the participants of `"C-B"`).

### 10.5 `populated_by[]` — push from resource execution

`populated_by:` declares **resources whose execution writes a value into this variable**. It is the execution-driven, push-style populator. Each entry uses a `kind:` discriminator (`tool`, `endpoint`, or `agent`) to identify the resource, plus an optional `phase:`, an optional `expression:` value source, and an optional `extractor:`.

```yaml
populated_by:
  - kind: <tool|endpoint|agent> # REQUIRED — discriminator
    name: <string>              # for kind: tool / kind: agent
    pattern: <pattern>          # for kind: endpoint
    methods: [<method>]         # for kind: endpoint
    phase: <before|after>        # OPTIONAL — default: after
    expression: <expr>           # OPTIONAL — value to write; @result.* is bound (phase: after only)
    extractor: <reverse-domain>  # OPTIONAL — replaces the default JSON extractor for this populator only
```

#### 10.5.1 Resource targeting

Each `populated_by[]` entry MUST declare a `kind:` value (`tool`, `endpoint`, or `agent`) and the identity fields appropriate for that kind. Missing or invalid combinations MUST be a load-time error.

| `kind:` | Identity fields | Matches |
|---------|-----------------|---------|
| `tool` | `name: <string>` (exact name, or `"*"` for the catch-all) | a single declared tool, or the catch-all |
| `endpoint` | `pattern: <string>` + `methods: [<method>]` | URI template / glob, plus method list — as in §13.4 |
| `agent` | `name: <string>` (exact name, or `"*"` for the catch-all) | a single declared sub-agent, or the catch-all |

#### 10.5.2 Phase

`phase:` selects when the populator fires relative to the call:

| `phase:` | When it fires | `@result.*` bound? | Use for |
|----------|--------------|-------------------|---------|
| `before` | When the call is **about to execute** (gating has passed; before the call is dispatched). Fires regardless of whether the call ultimately succeeds. | No | Counters that increment on attempt; pre-call snapshots; rate-limit accounting. |
| `after` (default) | When the call **succeeds**. Fires after gating, after the call returns. | Yes (parsed result) | Binding result fields to variables; post-call timestamps; success counters. |

`phase: before` MUST NOT see `@result.*` (the call has not executed yet). Using `@result.*` from a `phase: before` `expression:` MUST be a load-time error.

#### 10.5.3 Value derivation

When the populator fires, the runtime parses the relevant payload through the populator's `extractor:` if present, otherwise through the default JSON extractor (for `phase: after`; for `phase: before` there is no payload). Then:

| Fields present | Behavior |
|----------------|----------|
| `expression:` omitted | Default lookup — read `@result.<variable_name>` (`phase: after` only). For `phase: before`, this form is a no-op write that records that the populator fired; expressions that need to compute a value MUST use `expression:`. Missing key on `phase: after` → structured warning, mutation skipped. |
| `expression: <expr>` | Evaluate the expression against the current variable state. For `phase: after`, `@result.*` is bound — use `expression: @result.<dot.path>` to bind a specific result field. The returned value is what gets written. A missing read inside the expression returns `null` (§7.5.6); writing `null` flows through the variable's `update:` expression like any other value. |

The resulting value is applied through `set_variable()`, subject to the variable's `update:` expression (§10.2).

A variable MAY have multiple `populated_by:` entries naming different resources (or different phases of the same resource); each entry fires independently. A populator MUST NOT block the call. If the call errored, was blocked at gating, or did not execute, no `phase: after` populator fires; `phase: before` populators fire only after gating has passed.

**Independence from `on_demand_by:`.** `populated_by:` and `on_demand_by:` are independent. A variable MAY declare both. When the same resource is named by both (e.g., `kind: tool` with the same `name:` in each), the runtime MUST treat the two declarations as one logical population.

### 10.6 `reset_by[]` — clear before or after a call

`reset_by:` declares **resource calls that clear this variable** to `@status == 'unset'`. The schema mirrors `populated_by[]`'s resource-targeting fields:

```yaml
reset_by:
  - kind: <tool|endpoint|agent> # REQUIRED — discriminator
    name: <string>              # for kind: tool / kind: agent
    pattern: <pattern>          # for kind: endpoint
    methods: [<method>]         # for kind: endpoint
    phase: <before|after>        # REQUIRED — no default
```

| `phase:` | When it fires | Use for |
|----------|--------------|---------|
| `before` | Before gating runs for that call | One-shot inputs that MUST be re-collected per call (a stale list cannot pass the gate). |
| `after` | After the call succeeds (after `populated_by:` for that call) | Per-call permissions that the next caller MUST re-acquire. |

`reset_by:` MUST NOT block the call. `phase: before` fires regardless of whether the call ultimately succeeds. `phase: after` fires only on success.

A variable MAY declare multiple `reset_by:` entries. `reset_by:` and `lifetime:` are independent and combinable: a `lifetime: per_session` variable with a `reset_by:` entry will be cleared by the named call **and** at session end, whichever comes first.

### 10.7 `lifetime:`

See §9.1 for the lifetime grammar. A session variable's `lifetime:` declares when its value goes stale. After expiry, the runtime transitions `@status` from `resolved` (or from `denied`, per the lifetime form) back to `unset` and clears the value.

The map form `lifetime: { allow:, deny:, cancelled?: }` lets resolved and denied outcomes have different durations — for example, "an authorization stays valid for one call; a denial sticks until session end." See §9.1.2.

### 10.8 Tool / endpoint / agent call lifecycle

Each call advances through the phases below. The three rightmost columns are the three tracks the runtime maintains in parallel: **conditions evaluated** (expressions the runtime reads), **variables changed** (writes to session-variable value and `@status`), and **events emitted** (signals appended to the closed namespace defined in §9.3). Ordering invariants between events are normative in §9.5; this table is the per-phase summary.

| # | Phase | Conditions evaluated | Variables changed | Events emitted |
|---|-------|---------------------|-------------------|----------------|
| 1 | Pre-call reset | — | For each `reset_by[]` entry matching this resource with `phase: before`: `@status` → `unset`, value → `null`. For keyed variables (§10.4) the reset MUST clear only the entry whose key matches `key:` evaluated against the resetter's bound namespace. | `variable.<name>.changed` per reset (payload includes the cleared `key` for keyed variables). |
| 2 | Gating | For each guard policy whose `applies_to` matches: `active_if` → each `evaluate_when[].expression` → `allowed_when`. Auto-resolution (§11.5) MAY fire on reads of `unset` variables at gating sites and re-enter this row after the mutation lands. For keyed variables, the `key:` expression is re-evaluated at every read against the gated call's bound namespace. | Auto-resolved variables flip per resolver outcome: `allow` → `resolved`, `deny` / `cancelled` → `denied`. Keyed-variable mutations apply only to the requested key (§11.5). | `guard_policy.<name>.passed` or `guard_policy.<name>.failed` per active guard policy. On a `failed` verdict the call is rejected and the lifecycle advances directly to row 5b. |
| 3 | Pre-call populate | — | For each `populated_by[]` entry matching this resource with `phase: before`: `expression:` (or no-op default) is evaluated and written via the variable's `update:` expression; `@status` → `resolved`. Keyed-variable writes are stored under `key:` evaluated against the populator's bound namespace. `@result.*` is NOT bound. | `<kind>.<name>.called`, then `variable.<name>.changed` per populator write (payload includes the written `key` for keyed variables). |
| 4 | Execute | — | — | — |
| 5a | Post-call (success) | — | For each `populated_by[]` entry matching this resource with `phase: after`: value derived from the parsed result (default lookup `@result.<variable_name>` or `expression:`) is written via the variable's `update:` expression; `@status` → `resolved`. Keyed-variable writes are stored under `key:` evaluated against the populator's bound namespace. Then for each `reset_by[]` entry matching this resource with `phase: after`: `@status` → `unset`, value → `null` (keyed: only the matching key entry). | `variable.<name>.changed` per write and per reset, then `<kind>.<name>.success`. |
| 5b | Post-call (failure / blocked) | — | None of the `phase: after` populators or resetters fire. | `<kind>.<name>.failure`. |
| 6 | State re-evaluation | For each guard policy: `active_if` is re-evaluated. | — | `guard_policy.<name>.activated` / `guard_policy.<name>.deactivated` on each transition. |

Within each phase, mutations apply in declaration order.

### 10.9 Composability

Variables are owned by the declaring tier. The merge rule is:

- **Concat across files**: each tier adds its own variables to the merged list.
- **Same-name redefinition is a load-time error.** A child tier MUST NOT redefine a parent's variable.

This makes variables a **stable contract** — once a parent declares `data_sensitivity` with a `type:` (and `members:`, when `type: enum`) and an `update:` expression, no descendant can change the type, the membership / ordering, or the merge expression. Authors who need different semantics MUST declare a new variable with a different name.

### 10.10 Worked example: `resolved_recipients`

```yaml
variables:
  - name: "resolved_recipients"
    type: "array"
    description: "Resolved email addresses for the current send."
    # Read-driven: if a gate references this while unset, the runtime fires
    # the resolver below.
    on_demand_by:
      kind: tool
      name: "mail_resolve_recipients"
    # Write-driven: when mail_resolve_recipients succeeds, populate from
    # @result.recipients.
    populated_by:
      - kind: tool
        name: "mail_resolve_recipients"
        expression: "@result.recipients"
    # Cleared after a successful send so the next caller is forced through
    # mail_resolve_recipients again.
    reset_by:
      - kind: tool
        name: "mail_send"
        phase: after
    lifetime: per_call
```

A reader of the variable's definition sees its complete population and reset behavior — pull, push, and reset — without scanning any other section.

### 10.11 Worked example: endpoint-driven population

This pattern shows the variable owning its own population for non-tool resources — binding a result field from an endpoint or sub-agent into a variable without spreading population logic across multiple sections.

```yaml
variables:
  - name: "credit_score"
    type: number
    populated_by:
      - kind: endpoint
        pattern: "/api/v1/credit-check/{customer_id}"
        methods: [GET]
        # Default lookup reads @result.credit_score (variable name matches field name).

  - name: "fraud_risk_score"
    type: number
    populated_by:
      - kind: agent
        name: "fraud_detection_agent"
        # Default lookup reads @result.fraud_risk_score.

  - name: "send_count_today"
    type: number
    default: 0
    populated_by:
      - kind: tool
        name: "send_email"
        phase: before
        expression: "send_count_today + 1"
```

### 10.12 Worked example: keyed variable with explicit freshness audit

This pattern combines `key:` (§10.4) with `@source_params` (§10.3.2) to enforce both a per-key store and an explicit author-readable assertion that the stored value was produced for the parameters of the current call. The keyed lookup is the primary security control; the `@source_params` predicate is defense-in-depth that surfaces clearly in audit logs and failure reasons.

```yaml
variables:
  # KYC result, keyed by customer.
  - name: "kyc"
    type: object
    key: "@tool.params.customer_id"
    populated_by:
      - kind: endpoint
        pattern: "/api/v1/kyc/{customer_id}"
        methods: [GET]
        expression: "@result"
    lifetime:
      for: "24h"

state_validation:
  guard_policies:
    - name: "wire_requires_fresh_kyc_for_this_customer"
      applies_to:
        tools: [ "wire_transfer" ]
      evaluate_when:
        # 1. Primary: keyed lookup. The runtime evaluates `key:` at this
        #    reader site as `@tool.params.customer_id`; a mismatched or
        #    unfetched customer reads as @status == 'unset'.
        - expression: "kyc.status == 'approved'"
          reason: "KYC is not approved for this customer (or has not been fetched in the last 24h)."

        # 2. Defense-in-depth: prove the stored KYC was produced for *this*
        #    customer. Redundant given key:, but the audit trail wants the
        #    assertion explicit.
        - expression: "kyc.@source_params.path.customer_id == @tool.params.customer_id"
          reason: "Stored KYC was produced for a different customer."
```

The `@source_params` snapshot for an `endpoint` populator is the merged object `{ path: <path_params>, query: <query_params>, body: <params> }` (§10.3.2). For a `tool` or `agent` populator it is the call's `params` object. Authors who want a freshness check across two tools that name the same logical id differently can use `@source_params` to assert equivalence without aligning parameter names.

---
## 11. Resolvers

### 11.0 Approval binding and replay prevention

> Although nested under §11 for numbering, this section is normative for every approval surface in the spec, including the human-resolver wire envelope (§11.6), the `on_demand_by:` cache (§11.5), and any custom delegate that implements the resolver contract. It is placed here as the first subsection of §11 because resolvers are the canonical site for approval issuance.

Any resolver or approval flow that authorizes an invocation-bound action MUST bind the decision to the exact action context reviewed by the approver. The bound context MUST include the variable or guard policy that requested approval, resource kind, resource name, canonical invocation hash when an invocation is active, requested key when present, session or request scope, and a fresh approval nonce.

The approval nonce MUST be unpredictable. Implementations MUST use a cryptographic random source (for example a v4 UUID or equivalent CSPRNG-backed token) so that an attacker observing prior approvals — through logs, side channels, or compromised approval queues — cannot forge a nonce for a pending request. Predictable nonces such as timestamp-plus-counter values MUST NOT be used; uniqueness alone does not satisfy the binding requirement.

Implementations that cache approval decisions MUST key the cache by the bound action context. A cached approval or denial MUST NOT apply to a materially different tool, endpoint, agent, parameter set, invocation hash, requested key, policy context, user/session scope, or time window. Replaying an approval outside its bound context MUST fail closed.

Approval delegates and human providers SHOULD surface the canonical invocation hash and nonce to downstream approval systems.

### 11.1 What a resolver is

A **resolver** is a uniform mechanism for filling a variable on demand. The contract has two layers:

- **The wire envelope** (§11.3) — the JSON object every resolver invocation produces. This is **Pure Specification**: every conforming runtime, every delegate, and every host channel MUST honor it byte-for-byte.
- **The integration mechanism** — how each `kind:` actually fulfills the envelope. Some mechanisms are entirely local to the runtime (`expression`, `tool`); others cross a process or network boundary (`delegate`, `agent`, `human`). The mechanisms that cross a boundary have a **Default Implementation** (§11.11–§11.12) that the reference SDK ships with and that third-party delegates target for interoperability.

### 11.2 Where it lives

A resolver is declared inline at the data site that needs it — typically `variables[].on_demand_by:`. Resolvers are NOT a top-level YAML block.

### 11.3 The wire envelope

> **Pure Specification.** Every resolver invocation, regardless of `kind:`, MUST produce a value with this shape. External resolvers return it directly; local kinds are synthesized into it by the runtime (§11.10).

```json
{
  "decision": "allow" | "deny" | "cancelled",
  "value": <typed value matching the target variable, or null>,
  "set_variables": { "<name>": <value>, "..." },
  "reason": "<human-readable explanation>"
}
```

| Field | Description |
|-------|-------------|
| `decision` | The outcome. `allow` → store for the lifetime determined by the variable's `lifetime:` (§9.1, §11.8). `deny` → reject the gate with `reason`. `cancelled` → see §11.3a (fallback-eligible; distinguishable from plain `deny` via `@deny_kind` on the bound variable). The value MUST be exactly one of the listed lowercase strings. Implementations MUST NOT case-fold or trim whitespace; responses with non-conforming `decision` values MUST be treated as `error_kind: invalid_response`. |
| `value` | The value to set on the target variable. MUST be type-compatible with the variable's declared type, or `null`. The runtime applies the variable's `update:` expression (§10.2). |
| `set_variables` | Optional additional variable mutations the resolver wants to apply. Each name MUST appear in `variables[]`. Unknown names MUST produce a warning and be dropped (the rest of the envelope still applies). Type-incompatible values MUST produce a structured warning and be dropped without changing the variable. Values whose `update:` expression yields a no-op (e.g., `max(@current, @incoming)` returning `@current` because `@incoming` is lower) leave the variable unchanged, consistent with §10.2. |
| `reason` | Human-readable explanation included in audit logs and (on `deny` / `cancelled`) in the gating message returned to the agent. |

**Application order on `allow`:** the resolver's `value:` is applied first; `set_variables:` is applied after; the resolver's `on_allow:` map (declared in YAML, §11.4) is applied last. Mutations apply only on `allow`. While a stored decision is live, the runtime MUST NOT re-apply `value:`, `set_variables:`, or `on_allow:`.

**Lifetime is YAML-controlled.** The resolver's response carries no `lifetime:` field. Persistence is determined by the target variable's `lifetime:` (§9.1), which MAY use the `expression:` form (§9.1.2.1) to compute a value-conditional lifetime against `@incoming` at write time. This keeps the decision "how long does this allow last?" with the policy author rather than the resolver, narrowing the resolver trust surface to value writes only. Resolvers that need to communicate a duration can encode it in the value itself (e.g., a `duration` field on an object value) and have the variable's `lifetime.allow.expression:` read it back.

### 11.3a `decision: cancelled` semantics

The §11.3 `decision` enum includes one non-`allow` outcome that differs from plain `deny`: `cancelled`. The rules below describe what happens when a resolver chain's **final outcome** (after every fallback link has been exhausted) is `cancelled`. Intermediate decisions in a fallback chain do NOT trigger these rules; only the final outcome does.

**`cancelled` (final outcome).** `cancelled` is intended for explicit user cancellation:

1. The variable transitions to `@status == 'denied'` with `@deny_kind == 'cancelled'` and `@source_reason` set to the chain's final `reason:`.
2. The active gate is rejected with the final `reason:`.
3. The runtime MUST emit `<resource_kind>.<name>.failure` for the gated resource (matching §9.5 ordering rules) and the §11.9 `resolution_invoked` audit event for each resolver that fired.
4. Subsequent gates in the same turn that would auto-resolve the same variable MUST short-circuit on the `denied` status without re-prompting.
5. `cancelled` SHOULD NOT be used for transient errors; for errors, return through the `on_error:` pathway (§11.7) instead.

`cancelled` and `deny` produce identical state transitions when no fallback intervenes. The distinction is preserved on the variable via `@deny_kind`, surfaced in the §11.9 audit log, and typically carried in the `reason:` text (user-supplied cancellation message vs deterministic policy reason).

**Mixed fallback chains.** A chain whose primary returns `cancelled` and whose fallback returns `allow` MUST land in `@status == 'resolved'` with no trace of the cancellation on the variable; intermediate cancellations are visible only in the per-resolver §11.9 audit log. The chain's final non-`allow` outcome (whichever link last produced one) determines `@deny_kind` per the rules above.

**Per-call expiry.** A resolver returning `cancelled` MAY want the rejection to apply only to the current invocation (the user clicked abort once but the system should re-prompt next time). This is expressed through the variable's `lifetime:` map form (§9.1.2): set `cancelled: per_call` (or `deny: per_call`) so the denial expires immediately. The decision enum itself is fixed at three values; per-outcome duration is the lifetime's job.

### 11.4 `on_allow:` declarative bridge

A resolver MAY declare an `on_allow:` map — additional variable mutations applied when the decision is `allow`. Map values are expressions evaluated against the variable state at the time of the resolver response.

```yaml
variables:
  - name: "recipient_verified"
    type: boolean
    on_demand_by:
      kind: human
      prompt: "Confirm the recipient is intended for this message."
      context:
        recipient: "current_recipient"   # expression
      on_allow:
        approval_count: "approval_count + 1"
        last_approved_at: "time.now()"
    lifetime: per_session
```

### 11.4a Resolver `prompt:` interpolation

`kind: human`, `kind: agent`, and `kind: delegate` resolvers MAY interpolate runtime values into the `prompt:` string using `${...}` syntax. This is a separate surface from the configuration-string interpolation defined in §6.4.

```yaml
on_demand_by:
  kind: human
  prompt: "Authorize wire transfer of ${@tool.params.amount} to ${@tool.params.to}?"
```

**Available namespaces** in resolver `prompt:` interpolation:

| Form | Source |
|------|--------|
| `${@context.<key>}` | Request Context (§6.3); same data as the `@context.*` expression namespace |
| `${var.<name>}` | Declared session variables (§10); same data as bare-name expression reads |
| `${@tool.<path>}` / `${@endpoint.<path>}` / `${@agent.<path>}` | The current invocation's runtime-bound namespaces (§7.5.1–§7.5.3); only available when the gate is invocation-bound |

The `@` sigil applies to runtime-supplied identifiers (`@context`, `@tool`, `@endpoint`, `@agent`); `var` stays bare because it references author-declared session variables (§7.1).

`${@env.*}` MUST NOT appear in resolver prompts (build-time process state is not appropriate for runtime user-facing prompts). `${@result.*}` MUST NOT appear (no result has been produced yet at the moment a resolver is invoked).

**Substitution.** Each `${path}` reference is replaced with the stringified value at the point of interpolation. Missing-value behavior is split by namespace:

- **`${@context.<key>}` and `${var.<name>}`:** A missing value emits a structured warning and resolves to the empty string, mirroring §6.4. This is permissive because these values are session-scoped and an absence often reflects an unauthenticated or unconfigured session, not a structural bug.
- **`${@tool.*}`, `${@endpoint.*}`, `${@agent.*}`:** A missing value (the named field is not bound on the current invocation, or the path resolves to `null`) MUST cause the resolver invocation to fail with `error_kind: invalid_response` and route through the resolver's `on_error:` policy. Prompt interpolation does not distinguish "field absent" from "field present with explicit `null`" for invocation-bound namespaces; both produce a resolver-side failure. Authors who need to display nullable invocation-bound values MUST guard the prompt with a presence check in `evaluate_when:` before the resolver fires (so the gate never reaches the resolver when the field is absent), or substitute a different prompt-friendly variable. An ambiguous prompt to a human approver (e.g., "Authorize wire transfer of $ to ?" with empty substitutions) is a security hazard; fail-closed is the default.

Authors who legitimately want a permissive substitution for an invocation-bound field SHOULD validate the field in `evaluate_when:` before reaching the resolver (gate on the field's presence) so the prompt is never reached with the field absent.

Resolver prompt interpolation does NOT trigger auto-resolution of `${var.<name>}` references; reads of `unset` variables resolve to the empty string with a warning. (Auto-resolution fires only on the two gating sites listed in §11.5; resolver prompts are downstream of those sites and cannot themselves be the trigger.)

**Sensitivity.** When a sensitive variable's value would be substituted into a resolver prompt, the host's redaction policy applies. The Pure Specification requirement is that the substitution mechanism MUST allow the host to inspect the substituted prompt before delivery so deployment-level redaction can be applied.

**Optional `prompt:` for `kind: delegate`.** When a `kind: delegate` resolver omits `prompt:` (which is optional per §11.10), the §11.12.1 request body's `"prompt"` field MUST be set to `null` (not the empty string and not absent), to signal explicitly to the delegate that no human-facing prompt is intended.

### 11.5 Auto-resolution semantics

Auto-resolution fires when an expression at one of the **two gating sites** below reads a variable whose `@status == 'unset'` and whose declaration includes `on_demand_by:`.

> **The two gating sites:** `evaluate_when[].expression:` on a guard policy, and `allowed_when:` on a guard policy. Predicate bodies fire too, **transitively**, when the predicate is itself referenced from one of these sites.

When auto-resolution fires, the runtime MUST:

1. **Suspend** evaluation of the gating expression.
2. **Invoke** the resolver with the declared `kind` and protocol.
3. **Apply** the response. The chain's final outcome (after exhausting `fallback:` per §11.6) determines the transition:
   - `allow` → apply `value`, `set_variables`, and `on_allow:` via `set_variable()` (target → `resolved`). The stored decision's lifetime is determined by, in priority order: (1) the variable's `lifetime.allow:` (literal form, or `expression:` form evaluated against `@incoming`, per §9.1.2), (2) the variable's bare `lifetime:` literal (§9.1.1), (3) the per-kind default in §9.2.
   - `deny` (final) → target → `denied` with `@deny_kind == 'deny'` and `@source_reason` set.
   - `cancelled` (final) → target → `denied` with `@deny_kind == 'cancelled'` and `@source_reason` set (§11.3a).
4. **Resume or terminate** based on the final outcome. If the final outcome is `allow`, resume evaluation of the gating expression with the now-resolved variable. If the final outcome is `deny` or `cancelled`, terminate the current gate immediately with the final `reason:`; do NOT resume the gating expression for this invocation.

**Keyed variables (§10.4).** When the target variable declares `key:`, the runtime MUST resolve the key at the gating-site read **before** invoking the resolver, and MUST pass it to the resolver as `requested_key` in the resolver's request payload. The resolver's response MUST be applied **under that key**: the resolver's `value:` (and any `set_variables:` whose target is itself a keyed variable) MUST be stored against the requested key, regardless of any subsequent populator writes that may use a different key. If `key:` evaluates to `null` at the gating site, auto-resolution MUST NOT fire — the read evaluates as `@status == 'unset'` and the gate fails closed.

Auto-resolution MUST NOT fire for:

- A read outside the two gating sites listed above (notably: `active_if:`, `populated_by[].expression:`, configuration interpolation, log-message interpolation, resolver `context:`, resolver `on_allow:`).
- A variable with `@status == 'resolved'` and value `null` (the `null` is a deliberate value).
- A variable with `@status == 'denied'` (re-prompting within the lifetime would breach the user's commitment).
- A variable without a declared `on_demand_by:`.

Auto-resolution MUST emit a structured audit-log event regardless of decision. This is a security invariant — silent resolver invocations are forbidden.

**Worked example: predicate transitivity.**

```yaml
predicates:
  needs_approval: "data_sensitivity in ['restricted'] and not approval_granted"
```

When `needs_approval` is referenced from `evaluate_when[].expression: "needs_approval"`, both `data_sensitivity` and `approval_granted` MAY auto-resolve if they declare `on_demand_by:`. When the same predicate is referenced from `active_if: "needs_approval"`, neither auto-resolves; reads of `unset` variables fold to `null`, the predicate evaluates to `false`, and the guard policy stays inactive. The propagation is per-call-site, not per-predicate.

**Cycle detection.** At load time the runtime MUST construct the directed graph of variable → resolver dependencies and reject configurations that contain a cycle. For each `kind: expression` variable, every identifier in its body that names a variable with `on_demand_by:` is an outgoing edge. For each `kind: human|delegate|agent` variable, every identifier in `context:` and `on_allow:` values that names a variable with `on_demand_by:` is an outgoing edge. Cycles MUST be reported with the path.

### 11.6 Fallback chains

Any resolver MAY declare a `fallback:` field whose value is itself a resolver (same shape, including its own optional `fallback:`). The chain is invoked when:

- The primary resolver returns `decision: "deny"` or `decision: "cancelled"`.
- The primary resolver errors **and** `on_error: use_fallback` is set.
- A `kind: expression` resolver evaluates to `null` or `false`.

The chain is evaluated left-to-right. The first resolver to return `allow` wins. If every link rejects, the gate is rejected with the **last** resolver's `reason:` and the per-decision rules of §11.3a apply (using the final non-`allow` decision in the chain to determine state transitions and event emission).

**Fallback exhaustion and per-link errors.** A resolver error at any link in the chain is first mapped through that link's `on_error:` policy (§11.7). The mapped result then participates in the chain as the link's outcome:

- `on_error: block` → the link's outcome is a synthetic `deny`. The chain continues to the next link if one exists (because `deny` is fallback-eligible per the trigger list above); otherwise `deny` is the chain's final outcome.
- `on_error: allow` → the link's outcome is a synthetic `allow` with `value: null`. The chain terminates with `allow` (subject to the §11.7 caveats about `null` and lifetime semantics).
- `on_error: use_default` → if the variable has a `default:`, the link's outcome is a synthetic `allow` with the default value; otherwise behaves as `block`.
- `on_error: use_fallback` → the chain continues to the next link. If no next link exists, this behaves as `block` (synthetic final `deny`).

This means a chain can be exhausted either by every link rejecting through normal `decision:` returns or by every link erroring through `on_error: block` / `use_fallback`-with-no-next. In either case, the §11.3a final-outcome rules apply.

**Chain depth.** Implementations MUST support a fallback chain depth of at least 5. Implementations MAY enforce a higher depth limit; configurations exceeding the runtime's limit MUST be rejected at load time with an error naming the variable.

### 11.7 `on_error:` semantics

When the resolver itself fails (timeout, transport error, malformed response, classifier desugaring failure), `on_error:` decides:

| Value | Semantics |
|-------|----------|
| `block` (default) | Treat the resolver as `decision: "deny"`. Fail-closed. |
| `allow` | Treat the resolver as `decision: "allow"` with `value: null`. See note below. |
| `use_fallback` | If `fallback:` is declared, invoke it; otherwise behave as `block`. |
| `use_default` | If the variable has `default:` declared, use the declared default value; otherwise behave as `block`. |

**`on_error: allow` semantics.**

1. The synthesized envelope writes `value: null` to the target variable; the value follows the variable's `update:` and `lifetime:` semantics like any other write.
2. For variables whose `update:` interprets `null` as a non-permissive value (e.g., a boolean variable using the default `update: "@incoming"`, where the next read yields `null` and folds to `false`), `on_error: allow` MUST NOT be read as "let the gate pass." It means "treat the resolver as having returned no useful value."
3. Authors who want errors to be permissively allowed downstream SHOULD declare a `default:` on the variable and use `on_error: use_default` rather than `on_error: allow`.
4. `on_error: allow` is appropriate primarily when the variable's truth condition tolerates `null` (e.g., a number variable used in `count > threshold` where `null > threshold` evaluates to `false`).
5. Operators choosing `on_error: allow` SHOULD pair it with `audit.severity: high` and a meaningful `reason:`.
6. Operators choosing `on_error: use_default` with a permissive default MUST consider the security implications: a permissive default applied silently on resolver error can be the difference between a fail-closed system and a fail-open one.

There is no implicit fallback to a human resolver — hosts that want one MUST declare it explicitly via `fallback:`.

**Default timeouts (Default Implementation).** The reference runtime ships with the following per-kind default timeouts. Substitute runtimes MAY use different defaults; the Pure Specification requirement is only that **every kind has a finite timeout** and that timeout failures are routed through the `on_error:` policy above.

| Resolver kind | Default timeout (ms) |
|---------------|---------------------|
| `human` | host-defined; runtimes MUST require a host-supplied timeout |
| `delegate` (`http_endpoint`) | 30 000 |
| `delegate` (`mcp_server`, `a2a_agent`, `classifier`) | 30 000 |
| `agent` | 60 000 |

**Effective timeout resolution.** When a `kind: delegate` resolver dispatches to a configuration entry, the effective timeout is the most-specific declared value, in priority order:

1. The resolver's `timeout_ms:` (if declared on the `on_demand_by:` block).
2. The configuration entry's `timeout:` (if declared in `configurations[]`).
3. The per-kind default in the table above.

Per-resolver `timeout_ms:` overrides the default for non-delegate kinds.

### 11.8 Decision lifetime

The lifetime that governs a stored allow-decision is determined entirely by the target variable's `lifetime:` declaration (§9.1), evaluated at write time. When `lifetime.allow:` is in literal form (§9.1.1), that literal applies. When `lifetime.allow:` is in the `expression:` form (§9.1.2.1), the expression evaluates against `@incoming` (the value the resolver just wrote) and produces the effective lifetime for this single write. The wire envelope (§11.3) carries no `lifetime:` field; resolvers communicate persistence indirectly by encoding it in the value, which the YAML expression reads back.

A variable resolved by a `human` / `delegate` / `agent` resolver persists for exactly as long as the effective lifetime says, and no longer:

| Lifetime | Semantics |
|----------|------------------|
| `per_call` | No persistence. Every invocation MUST re-run the resolver. |
| `per_turn` | Persists until the host signals end-of-turn. |
| `per_session` | Persists for the lifetime of the runtime session. |
| `per_request` | Persists for the lifetime of one host-defined request scope. |
| `for: <duration>` | Persists for the declared wall-clock duration from the resolver response. |
| `until_event: <id>` | Persists until the named event fires. |
| Map form `{ allow:, deny:, cancelled?: }` | The matching outcome's branch lifetime applies (§9.1.2). |

Lifetime semantics for resolver decisions are governed by §11.3 (no re-application of `value:` / `set_variables:` / `on_allow:` while live). To force a fresh resolver invocation on every call, declare `lifetime: per_call` (or set the matching branch in the map form). Resolver errors during a stale-or-absent lookup follow §11.7.

### 11.9 Audit fields

Every resolver invocation MUST emit a structured log event with `event_type: resolution_invoked`. The event MUST include the §19.2 base fields AND the resolver-specific fields below:

| Field | Meaning |
|-------|---------|
| `resolver_name` | The variable whose `on_demand_by:` triggered the invocation |
| `kind` | The resolver kind |
| `lifetime` | The lifetime declared on the variable, normalized. For literal forms, the literal; for the `expression:` form (§9.1.2.1), an opaque source marker (e.g., `"<expression>"`) so the audit log records that an expression governs persistence without leaking the expression body. |
| `effective_lifetime` | The lifetime actually applied to this write — the literal value, or the resolved value of the `expression:` form, normalized. `null` on a non-`allow` outcome. |
| `decision` | The decision returned, or `null` on error |
| `latency_ms` | Wall-clock time |
| `error_kind` | (only on error) `timeout` / `transport` / `invalid_response` / `cycle` / etc. |
| `category` | Default `resolver`; overridable via `audit.category` |
| `severity` | Default `info`; on error defaults to `high`; overridable via `audit.severity` |

The default severities above override the §19.1 auto-emit defaults for resolver invocations specifically. Resolvers MAY emit additional implementation-defined fields under the `agent_shield.resolver.<key>` attribute prefix per §19.3.

### 11.10 The five kinds

Each kind has the same envelope contract (§11.3) but a different integration mechanism. The table below summarizes; per-kind schema follows.

| Kind | Integration mechanism | Marker |
|------|----------------------|--------|
| `delegate` | Cross-process call routed through a `configurations[]` entry. The protocol-to-envelope adapters live in §11.12. | Envelope: Pure Specification. Adapters: Default Implementation. |
| `agent` | Structured `resolution_request` to the calling agent via the SDK's host channel. The host returns the envelope. | Envelope: Pure Specification. Channel transport: Default Implementation. |
| `human` | Interactive confirmation collected from the host operator. The reference runtime ships a built-in callback registry; see §11.11. | Envelope: Pure Specification. UI / callback shape: Default Implementation. |
| `expression` | Runtime evaluates an inline expression and synthesizes the envelope locally. No external call. | Pure Specification (synthesis rule fixed). |
| `tool` | One-way `resolution_needed` signal to the calling agent. The runtime MUST NOT invoke the tool. The next gate retry sees the variable populated by the tool's `populated_by:` if the agent called it. | Pure Specification (signal contract fixed). |

**Per-kind field matrix.** Each kind accepts a fixed set of YAML fields. Extra fields MUST cause a load-time error.

| Field | `tool` | `human` | `delegate` | `expression` | `agent` |
|-------|:------:|:-------:|:----------:|:------------:|:-------:|
| `kind` (REQUIRED) | ✓ | ✓ | ✓ | ✓ | ✓ |
| `name` (target tool name) | **REQUIRED** | — | — | — | — |
| `prompt` (instruction text) | — | **REQUIRED** | OPTIONAL | — | **REQUIRED** |
| `configuration` (configurations entry id) | — | — | **REQUIRED** | — | — |
| `expression` (inline expression) | — | — | — | **REQUIRED** | — |
| `context` (map of expressions) | — | OPTIONAL | OPTIONAL | — | OPTIONAL |
| `on_allow` (additional `set_variables`) | — | OPTIONAL | OPTIONAL | — | OPTIONAL |
| `on_error` (failure policy) | — | OPTIONAL | OPTIONAL | — | OPTIONAL |
| `audit` (logging overrides) | — | OPTIONAL | OPTIONAL | — | OPTIONAL |
| `fallback` (chained resolver) | — | OPTIONAL | OPTIONAL | OPTIONAL | OPTIONAL |
| `timeout_ms` | — | OPTIONAL | OPTIONAL | — | OPTIONAL |

The `kind: agent` resolver does NOT declare a `name:` because it targets the host channel of the calling agent, not a specific named agent. To target a specific peer agent, use `kind: delegate` against a `configurations[]` entry of `type: a2a_agent`.

**Configuration entry pairing.** Resolvers that reference a `configurations[]` entry by `id` must match the configuration's `type:`. Routing requirements per type are normative in §6.2's routing matrix; the table below summarizes for resolver authors:

| Resolver kind | Required configuration `type:` | Required configuration fields (per §6.2) |
|---------------|-------------------------------|-------------------------------|
| `delegate` (HTTP) | `http_endpoint` | `endpoint:` |
| `delegate` (MCP) | `mcp_server` | `tool:` plus (`endpoint:` OR registered MCP provider) |
| `delegate` (A2A) | `a2a_agent` | `agent_id:` plus (`endpoint:` OR registered A2A provider OR host-supplied A2A peer registry) |
| `delegate` (classifier) | `classifier` | `endpoint:` OR registered classifier provider, plus `threshold:` |
| `human` | (none, host-resolved) | — |
| `agent` | (none, host-channel-resolved) | — |
| `expression` | (none) | — |
| `tool` | (none, but `name:` MUST match a `resources.tools[].name`) | — |

A resolver whose `configuration:` references a configuration entry of the wrong `type:` MUST be a load-time error. A resolver whose configuration entry is missing required routing fields MUST also be a load-time error (per §6.2).

#### 11.10.1 `kind: expression`

The runtime evaluates the inline `expression:` against the current variable state and synthesizes `{ decision: "allow", value: <evaluated>, set_variables: {}, reason: "" }`. If the expression evaluates to `null` or `false`, the runtime MUST treat it as `decision: "deny"` and fall through to `fallback:` if declared. No external dispatch, no stored decision, no audit-log entry beyond the standard auto-resolution event.

**Error handling.** Syntax errors in the `expression:` MUST cause a load-time error. Runtime evaluation errors (limit exceeded per LANGUAGE.md §6, missing referenced predicate, type mismatch propagation, divide-by-zero) MUST be treated as `decision: "deny"` with `reason: "expression evaluation error: <details>"` and routed through `fallback:` if declared. The runtime MUST NOT silently substitute a default value or coerce the error into `allow`.

#### 11.10.2 `kind: tool`

The runtime emits a `resolution_needed` signal naming the tool (the resolver's `name:` field) and the target variable. The active gate fails with a `resolution_needed` reason and the calling agent is expected to call the named tool, whose `populated_by:` then fills the variable; the next gate evaluation succeeds. **The runtime MUST NOT invoke the tool itself.** There is no synchronous response and no envelope — the `resolution_needed` signal is the contract.

When the target variable declares `key:` (§10.4), the `resolution_needed` signal payload MUST include `requested_key: <value>` so the agent knows which key the gate was probing. The runtime MUST NOT mark the variable resolved until a subsequent `populated_by:` write under the matching key lands; populator writes whose key differs from the requested key MUST be stored under their own key (they may legitimately satisfy a different concurrent gate) and MUST NOT satisfy the pending read.

**Resolution loop bound.** When the runtime emits `resolution_needed` for the same `(variable, originating_invocation)` more than `N` times in a single turn, the runtime MUST escalate: it MUST emit `incident.resolution_loop` and MUST refuse the gated invocation for the rest of the turn. The threshold MUST be configurable per deployment; conforming runtimes MUST support at least `N >= 5` to accommodate workflows that need multiple intermediate tool calls before the variable is filled. The RECOMMENDED default is `N = 3`. Implementations MAY count only retries with no intervening attempt to call the named resolution tool (i.e., the loop count resets when the agent calls the named tool, even if the call doesn't fill the variable). This bound exists because the runtime cannot enforce the agent's compliance with the `resolution_needed` signal (§20.1); without a bound, an agent that ignores the signal and retries the original call would loop indefinitely.

#### 11.10.3 `kind: delegate`

The runtime dispatches to the named entry in `configurations[]` (`type: http_endpoint`, `mcp_server`, `a2a_agent`, or `classifier`) using its protocol adapter. Each adapter converts the protocol's native response into the wire envelope. **The envelope (§11.3) is Pure Specification; the per-protocol adapters are Default Implementation and live in §11.12.**

#### 11.10.4 `kind: agent`

The runtime emits a structured `resolution_request` to the calling agent via the SDK's host channel. The host supplies the wire envelope back, drawn from its own memory, sign-in context, conversation, or any auxiliary mechanism. **The envelope is Pure Specification; the channel transport (in-process callback, IPC, RPC) is Default Implementation.**

The runtime/host integration MUST cause exactly one §11.9 `resolution_invoked` audit event to be emitted for the invocation. The host response MUST be validated against the §11.3 envelope strictly (no case-folding, no whitespace trimming on `decision`; type checks on `value`); failures fall through the resolver's `on_error:` policy. The effective timeout of §11.7 applies to the host's response time.

#### 11.10.5 `kind: human`

The runtime invokes the **built-in human resolver** (§11.11) with the resolver's `prompt:` and `context:`. The host's response is mapped into the wire envelope.

### 11.11 Built-in human resolver (Default Implementation)

> **(Default Implementation)** Substitute runtimes MAY implement the human channel differently — a web UI, a chat-app sidebar, a CLI prompt, an email round-trip — as long as the host receives the per-request fields below and returns the wire envelope (§11.3). The reference SDK exposes this surface through `register_human_resolver(callback)` (§21).

The runtime presents the host with at least the following per-request fields:

| Field | Type | Description |
|-------|------|-------------|
| `request_id` | string (UUID) | Unique identifier for this resolver invocation |
| `variable` | string | The variable being resolved |
| `requested_key` | any \| null | The key under which the resolver's response will be stored, when the variable declares `key:` (§10.4); `null` for non-keyed variables. |
| `resource` | object | `{ kind: "tool"\|"agent"\|"endpoint", name: string, params: object }` of the gated resource |
| `prompt` | string | The resolver's `prompt:`, with all `${@context.*}`, `${var.*}`, and `${@tool|@endpoint|@agent.*}` references interpolated per §11.4a |
| `reason` | string | The triggering `evaluate_when[].reason`, when available |
| `context` | object | Active guard policies, variable snapshot, plus any `context:` map values evaluated as expressions |

The host MUST respond with the wire envelope (§11.3). The per-request field set is Pure Specification — every host integration MUST receive at least these fields, regardless of the UI surface chosen.

### 11.12 Delegate protocol mappings (Default Implementation)

> **(Default Implementation)** This subsection defines the request/response shapes the reference runtime uses when dispatching a `kind: delegate` resolver to each `configurations[]` adapter. Substitute runtimes MAY use different shapes; **third-party delegates that wish to interoperate with the reference SDK MUST implement the shapes below.** The Pure Specification requirement is only that whatever shape is used, the response is converted into the §11.3 wire envelope.

#### 11.12.1 `http_endpoint`

The runtime POSTs a JSON request body to the configured `endpoint:` URL. Headers and URL interpolation follow §6.4.

**Request body:**

```json
{
  "request_id": "uuid",
  "variable": "<target variable name>",
  "requested_key": <any | null>,
  "resource": {
    "kind": "tool" | "agent" | "endpoint",
    "name": "<resource identifier>",
    "params": { "...": "..." }
  },
  "prompt": "<resolver prompt, interpolated>",
  "reason": "<triggering evaluate_when[].reason, when available>",
  "context": {
    "active_guard_policies": ["<name>", "..."],
    "variables": { "<name>": <value>, "...": "..." },
    "extra": { "...": "..." }
  },
  "lifetime": "per_call" | "per_turn" | "per_session" | "per_request" | { "for": "<duration>" } | { "until_event": ["<event_id>", "..."] } | { "allow": <spec>, "deny": <spec>, "cancelled": <spec> }
}
```

`requested_key` MUST be present whenever the target variable declares `key:` (§10.4); it carries the value the runtime resolved for `key:` at the gating-site read. When the target variable does not declare `key:`, `requested_key` MUST be `null`.

**Response body:** the wire envelope (§11.3) verbatim.

**Error mapping.** HTTP status codes map to `error_kind` as follows:

| Status | `error_kind` |
|--------|--------------|
| Connection failure / DNS / TCP reset | `transport` |
| Timeout (per §11.7 default or `timeout_ms:` override) | `timeout` |
| 4xx, 5xx | `invalid_response` |
| 2xx with body that is not valid JSON | `invalid_response` |
| 2xx with valid JSON missing `decision`, with `decision` not a string, or with `decision` not exactly one of the §11.3 enum values | `invalid_response` |

All non-2xx responses and all 2xx responses that fail envelope validation are routed through the resolver's `on_error:` policy (§11.7).

#### 11.12.2 `mcp_server`

The runtime issues an MCP `tools/call` against the tool named by the configuration's `tool:` field on the configured MCP server. The `arguments` object passed to `tools/call` is the same JSON document defined for `http_endpoint` (§11.12.1).

**Result parsing.** The tool's structured `content` array is searched for the first text-typed entry whose contents parse as JSON conforming to the wire envelope. If none is found, the response is treated as `error_kind: invalid_response`.

#### 11.12.3 `a2a_agent`

The runtime sends an A2A message to the peer identified by the configuration's `agent_id:`. The message body is the same JSON document defined for `http_endpoint` (§11.12.1). The peer agent's reply MUST be a JSON document conforming to the wire envelope; otherwise the response is treated as `error_kind: invalid_response`.

#### 11.12.4 `classifier`

`kind: delegate` against a `type: classifier` configuration follows the per-protocol shape its named provider declares (§6.5) and the runtime **desugars** the classifier's structured verdict into the wire envelope:

| Classifier output | Envelope mapping |
|-------------------|------------------|
| `score >= threshold` (where `threshold` is the configuration's `threshold:`) | `{ decision: "deny", value: false, reason: "<classifier label or score>" }` |
| `score < threshold` | `{ decision: "allow", value: true, reason: "<classifier label or score>" }` |
| Provider returns a structured boolean detection (e.g., `{contains_pii: true}`) | `true` → `deny`, `false` → `allow`. |
| Malformed response, missing score, or threshold not configured | `error_kind: invalid_response`; routed through `on_error:`. |

The desugaring is a Default Implementation behavior; runtimes MAY expose hooks to customize the mapping for a given configuration.

### 11.13 Composability

Resolvers are part of variables. Their merge rule follows the variable rule: same-name redefinition is a load-time error (§10.9). To change a resolver, declare a new variable with a different name.

Because resolvers are part of variables, no field of a parent's resolver (including `fallback:`, `timeout_ms:`, `on_error:`, `audit:`, `prompt:`, `context:`, `on_allow:`) MAY be modified by a child file.

**Composing additional checks at the gate layer.** Authors who want a child tier to add additional verification on top of a parent's variable cannot deepen the parent's `fallback:` chain. Instead, the child SHOULD compose at the gate layer:

```yaml
# parent declares verified_recipient with kind: human resolver

# child adds extra verification by introducing a new variable
variables:
  - name: child_secondary_verification
    type: boolean
    on_demand_by:
      kind: delegate
      configuration: child_verifier_service

state_validation:
  guard_policies:
    - name: send_email_dual_verification
      applies_to: { tools: [send_email] }
      evaluate_when:
        - expression: "verified_recipient"
          reason: "Recipient verification required."
        - expression: "child_secondary_verification"
          reason: "Secondary verification required."
```

This composes both resolvers at the gate layer rather than chaining them as fallbacks. The parent's resolver fires when its variable is read; the child's resolver fires when its variable is read; both must succeed for the gate to pass. The semantics are explicit and visible at the policy site rather than hidden in resolver-chain ordering.

**Gate-layer composition is AND, not OR.** Gate-layer composition adds a stricter check; it cannot emulate fallback-chain alternation. An expression like `parent_var or child_var` does NOT rescue a denied parent: when the read of `parent_var` triggers auto-resolution and the resolver returns `deny` / `cancelled`, the gating expression terminates with the resolver's `reason:` per §11.5 step 4. The `or` short-circuit never reaches `child_var`. Authors who genuinely need alternative approval paths MUST encode them inside a single resolver's `fallback:` chain at the tier that owns the variable. If that tier is parent-locked (per the same-name-redefinition rule above), the alternative path cannot be expressed as an extension of that variable's chain; the child tier MUST instead define a new variable and a new policy whose resolver encodes the desired alternation, and decide at the gate layer whether to use the parent's variable, the child's variable, or both.

### 11.14 End-to-end example: `wire_transfer_authorized`

```yaml
variables:
  - name: "wire_transfer_authorized"
    type: boolean
    on_demand_by:
      kind: human
      prompt: "Authorize wire transfer of ${@tool.params.amount} to ${@tool.params.to}?"
      on_allow:
        approval_count: "approval_count + 1"
        last_approval_at: "time.now()"
    lifetime:
      allow: per_call
      deny: per_session   # "no" persists for the rest of the session

state_validation:
  guard_policies:
    - name: "wire_transfer_authorization"
      applies_to:
        tools:
          - wire_transfer
      evaluate_when:
        - expression: "wire_transfer_authorized == true"
          reason: "Wire transfers require per-call user authorization."
```

### 11.15 End-to-end example: tri-state human approval

When a single human prompt has more than two outcomes that need different persistence (e.g., "allow once", "allow always", "decline"), the resolver returns one envelope per response and the variable's `lifetime.allow:` `expression:` form (§9.1.2.1) reads `@incoming` to decide how long the decision lasts.

```yaml
variables:
  - name: "send_mail_decision"
    type: enum
    members: [allow_once, allow_always]
    on_demand_by:
      kind: human
      prompt: "Authorize sending mail to ${@tool.params.to}?"
    lifetime:
      allow:
        # @incoming is the just-written value.
        expression: "@incoming == 'allow_always' ? 'per_session' : 'per_call'"
      deny:
        until_event:
          - session.end       # a "no" sticks for the session

state_validation:
  guard_policies:
    - name: "send_mail_authorization"
      applies_to:
        tools:
          - send_mail
      evaluate_when:
        - expression: "send_mail_decision in ['allow_once', 'allow_always']"
          reason: "Sending mail requires user authorization."
```

The host's three reply buttons map to one resolver envelope each:

| Reply | Envelope | Stored lifetime |
|-------|----------|-----------------|
| Allow once | `{"decision":"allow", "value":"allow_once"}` | `per_call` (`expression:` form returned `'per_call'`) |
| Allow always | `{"decision":"allow", "value":"allow_always"}` | `per_session` (`expression:` form returned `'per_session'`) |
| Decline | `{"decision":"deny", "reason":"User declined."}` | `until_event: [session.end]` (literal `deny:` branch) |

The resolver carries no persistence information — the value alone is sufficient, and the YAML expression at the variable declaration reads it back to choose the lifetime. The persistence rule lives where the policy author declares it, audited via `effective_lifetime` (§11.9).

### 11.16 Global failure semantics

Security-critical failures MUST fail closed unless a local policy explicitly declares a weaker behavior and the implementation documents that compatibility mode. The following table is normative for conforming runtimes:

| Failure condition | Required default behavior |
|---|---|
| Guardrails file does not validate, references unknown resources, or uses an unsupported `agent_shield_version` | Load-time error; runtime MUST NOT enforce a partially loaded policy |
| Unknown guard action, resolver kind, resource kind, lifecycle event, variable type, or wire decision value | Load-time error when statically known; otherwise block or deny at runtime |
| Missing or malformed resolver response decision | Deny/cancel the resolver result and record the parse failure reason |
| Missing or malformed LLM judge response decision | Treat as block/fail for the affected validator |
| Human approval timeout, EOF, unrecognized response, or unregistered provider | Deny/cancel the approval request |
| Delegate/classifier transport timeout or unavailable provider | Apply the configuration's `on_error`; if omitted, block or require approval for security-critical gates |
| Unknown mediated invocation shape from a framework adapter | Do not execute the invocation under Agent Shield approval; fail closed or mark the path unsupported before execution |
| Streaming buffer limit exceeded or stream finalization fails | Stop emitting unvalidated content and block the stream unless policy explicitly accepted partial-output risk |
| Observability sink failure | MUST NOT convert a block/deny into allow; MAY continue enforcement while recording local diagnostics |

A fail-open behavior MUST be explicit, scoped to the affected guard/resolver/configuration, and observable in logs. Implementations MUST NOT silently convert parse errors, unavailable dependencies, or unknown runtime shapes into allow decisions for governed actions.

## 12. Guard policies (shared contract)

A **guard policy** is the single gating surface the Agent Shield runtime exposes. Every gate the runtime enforces — the deterministic state checks at Stage 2 and the content checks at Stages 1, 3, 4, and 5 — is expressed as a guard policy. There is one schema; this chapter is its complete definition. Stage chapters (§14–§18) reference back to this chapter and add only stage-specific subjects and template variables.

### 12.1 Concept

A guard policy is a **named gate** with five conceptual phases:

```
applies_to    ─── what calls does this gate?
active_if     ─── is the gate engaged for this call?     (filter; no resolution)
evaluate_when ─── what must hold for the call to pass?   (gate; resolution fires)
allowed_when  ─── may a failure be bypassed?             (override; resolution fires)
action        ─── what to do on failure (block / redact / warn)
```

The naming convention maps directly onto this shape: `_when:` fields are decisional sites where auto-resolution may fire; `_if:` fields are observational filters where it never does.

A guard policy comes in two flavors that differ only in which detection kinds they accept inside `evaluate_when:`:

| Flavor | Stages | Detection kinds | Action modes |
|--------|--------|-----------------|--------------|
| **State guard policy** | Stage 2 | `expression` only | `block` / `warn` |
| **Content guard policy** | Stages 1, 3, 4, 5 | `expression` / `pattern` / `patterns` / `llm` / `classifier` | `block` / `redact` / `warn` / `append` / `prepend` (§12.7 stage rules) |

Both flavors share the same outer schema. A guard policy is registered under the `guard_policies:` list of the stage it applies to.

### 12.2 Schema

```yaml
guard_policies:
  - name: <string>                        # REQUIRED — unique within the merged file
    description: <string>                 # OPTIONAL

    # ── Selector ─────────────────────────────────────────────────────
    applies_to:                           # required for state guard policies;
                                          # optional for content guard policies on Stages 3 & 4;
                                          # rejected on Stages 1 & 5.
      tools:
        - <name>                          # exact name, or "*"
      agents:
        - <name>                          # exact name, or "*"
      endpoints:
        - pattern: <pattern>
          methods:
            - <method>                    # or "*"

    # ── Engagement ───────────────────────────────────────────────────
    active_if: <expression>               # OPTIONAL; default: always active.
                                          # NO auto-resolution.

    # ── Gate ─────────────────────────────────────────────────────────
    evaluate_when:                        # OPTIONAL; list; AND-joined; first
                                          # failure determines the verdict.
                                          # AUTO-RESOLUTION fires on `expression:` entries.
                                          # Omit ⇒ guard policy always blocks when active.
      - expression: <expression>          # exactly one of:
                                          #   expression / pattern / patterns / llm / classifier
                                          # per entry.
        pattern: <regex>
        patterns:
          - <regex>
        llm:
          prompt: <string>                # path or inline
          configuration: <id>             # OPTIONAL
        classifier:
          configuration: <id>             # REQUIRED
        reason: <string>                  # REQUIRED on each entry
        action: <block|redact|warn|append|prepend>   # OPTIONAL; overrides guard-policy-level action
        replacement: <string>             # OPTIONAL; only valid when action: redact
        text: <string>                    # OPTIONAL; REQUIRED when action: append or prepend (§12.7)
        paths:                            # OPTIONAL; REQUIRED for Stage-3 append/prepend
          - <dot.path>
        log:
          severity: <critical|high|medium|low|info>
          category: <string>

    # ── Bypass ───────────────────────────────────────────────────────
    allowed_when: <expression>            # OPTIONAL; bypass on failure.
                                          # AUTO-RESOLUTION fires.

    # ── Outcome ──────────────────────────────────────────────────────
    action: <block|redact|warn|append|prepend>   # OPTIONAL; default: block.
                                          # Per-entry `action:` overrides this.
    reason: <string>                      # OPTIONAL; only valid when no `evaluate_when:`.
                                          # Used for the "always block when active" form.
    replacement: <string>                 # OPTIONAL; only valid when action: redact.
                                          # Per-entry `replacement:` overrides this.

    # ── Observability ────────────────────────────────────────────────
    log:                                  # emitted on every applicable invocation
      severity: <critical|high|medium|low|info>
      category: <string>
      message: <string>
```

A guard policy with neither `evaluate_when:` nor a guard-policy-level `reason:` MUST produce a load-time warning — it has no observable effect.

### 12.3 The selector — `applies_to:`

`applies_to:` is a struct of three lists, all individually optional. The guard policy MUST declare at least one non-empty list when `applies_to:` is required for the stage. Selectors are **explicit name lists only** — there are no tag selectors, no glob-over-names, no expression-driven selection.

| Field | Entries | Semantics |
|-------|---------|-----------|
| `applies_to.tools[]` | tool name (string) — MUST match a `resources.tools[].name`, or the literal `"*"` | Guard policy applies when the runtime is gating an invocation of one of these tools. `"*"` matches every tool, including unlisted ones. |
| `applies_to.agents[]` | agent name (string) — MUST match a `resources.agents[].name`, or `"*"` | Guard policy applies when the runtime is gating a sub-agent invocation. |
| `applies_to.endpoints[]` | object `{ pattern, methods }` | Guard policy applies when the URI + method match. Same matching rules as §13.4 (exact > parameterized > glob; method-exact > method-wildcard). The pattern does NOT have to be declared as a `resources.endpoints[]` entry. |

A name listed in `applies_to.tools[]` MUST resolve to a declared tool (or be `"*"`); unresolved names produce a load-time error. The same applies to `applies_to.agents[]`. Endpoint refs in `applies_to.endpoints[]` are first-class selectors and MAY refer to undeclared endpoints.

A single guard policy's lists are **OR'd**: the guard policy applies if the resource being gated matches any one of the listed entries.

#### 12.3.1 Stage rules for `applies_to:`

| Stage | Subject | `applies_to:` |
|-------|---------|---------------|
| 1 (`input_validation`) | User input text | **rejected** (no resource bound) |
| 2 (`state_validation`) | Session state | **required** |
| 3 (`tool_execution_validation`) | Proposed call params | optional; defaults to "all calls" |
| 4 (`post_tool_validation`) | Call result | optional; defaults to "all calls" |
| 5 (`output_validation`) | Agent response text | **rejected** (per-turn response, not per-resource) |

### 12.4 Engagement — `active_if:`

`active_if:` is the engagement filter. A guard policy is **active** when its `active_if:` evaluates to truthy (or is absent, in which case the guard policy is statically active for the entire session). This is the only field that decides whether the gate participates in the current invocation; `evaluate_when:` decides whether the call passes once participation is decided.

| Form | Behavior |
|------|----------|
| omitted | Always active. The guard policy participates in every invocation that matches `applies_to:`. |
| `active_if: <expression>` | Active when the expression evaluates truthy. Re-evaluated after every variable mutation, every event emission, and at the start of each new invocation that matches `applies_to:`. |

**No auto-resolution.** `active_if:` MUST NOT trigger resolver auto-resolution (§11.5). When `active_if:` references a variable whose `@status == 'unset'`, the read MUST evaluate to `null`, and the activation predicate folds that into `false` (the guard policy stays inactive). This is the security invariant — pre-filters fire on every relevant invocation, and firing resolvers from them would prompt humans (or call delegates) for guard policies the current call does not even concern.

**Activation events.** Per state-re-evaluation tick, the runtime MUST:

1. Re-evaluate every `active_if:` expression.
2. On a transition from inactive to active, emit `guard_policy.<name>.activated` (§9.3).
3. On a transition from active to inactive, emit `guard_policy.<name>.deactivated`.

These events latch like any other event in the closed namespace and are observable from `@event.fired()`.

**Observing events from `active_if:`.** Activation expressions MAY reference events through the `@event.fired(<event_id>)` built-in. For example, a guard policy that activates the first time the agent reads a sensitive document and stays active for the rest of the session:

```yaml
active_if: "@event.fired('tool.read_sensitive_document.success')"
```

For stateful flags that need to be raised AND lowered (e.g., a threat-response lockdown the operator can lift), declare a session variable and reference it directly — the host raises the flag with `set_variable()` and lowers it with `reset_variable()` (§21):

```yaml
active_if: "lockdown_active"   # boolean session variable
```

There is no separate `lifetime:` on guard policies. Every form of "this gate is active for X duration" is expressible through `active_if:` referencing variables, predicates, or events.

### 12.5 The gate — `evaluate_when:`

`evaluate_when:` is a list of detection entries the call must satisfy. The list is **AND-joined**: every entry must pass for the call to pass. The first failing entry determines the verdict — the runtime stops on the first failure and uses that entry's `reason:` and `action:` (or the guard-policy-level defaults).

A guard policy with no `evaluate_when:` declared is the "always block when active" form: the guard policy unconditionally enforces its `action:` (default `block`) and `reason:` whenever `active_if:` is true.

#### 12.5.1 Detection kinds

Each entry MUST contain exactly one of the following detection fields. Declaring more than one, or none, MUST be a load-time error.

| Field | Kind | Subject of comparison | Stages |
|-------|------|----------------------|--------|
| `expression: <expr>` | Expression | Truthy ⇒ pass, falsey ⇒ fail. Auto-resolution fires. | All stages |
| `pattern: <regex>` | Regex (single) | Match ⇒ fail. Subject = the stage's content text. | 1, 3, 4, 5 |
| `patterns: [<regex>, ...]` | Regex list | Any match ⇒ fail. Shares one `reason:` for all patterns in the list. | 1, 3, 4, 5 |
| `llm: { prompt:, configuration?: }` | LLM | LLM verdict (§12.7.3) `BLOCK` ⇒ fail; `ALLOW` ⇒ pass. | 1, 3, 4, 5 |
| `classifier: { configuration: }` | Classifier | Score ≥ threshold ⇒ fail. | 1, 3, 4, 5 |

**Polarity note.** `expression:` is a **predicate** — truthy means "passes." All other detection kinds are **detectors** — a positive detection means "this content is a violation, fail." Each polarity matches its domain: regex blocklists detect violations, expressions assert preconditions. The shared abstraction is the verdict (`pass` / `fail`), not the polarity of the check itself.

#### 12.5.2 Per-entry attribution

Each entry carries its own `reason:` (REQUIRED) and optional `action:`, `replacement:`, and `log:`. This gives the audit log per-entry attribution: when a guard policy fails, the runtime knows exactly which entry tripped and reports its `reason:` to the agent.

```yaml
guard_policies:
  - name: "wire_transfer_safety"
    applies_to:
      tools:
        - wire_transfer
    active_if: "@tool.params.amount >= 10000"
    evaluate_when:
      - expression: "@tool.params.amount < 50000"
        reason: "Amount exceeds per-transaction ceiling."
      - expression: "wire_transfer_authorized == true"
        reason: "Per-call user authorization required."
      - expression: "kyc_verified == true"
        reason: "KYC not verified — flagged for review."
        action: warn                      # this entry warns instead of blocking
        log:
          severity: high
          category: kyc
```

#### 12.5.3 Auto-resolution within `evaluate_when:`

When an `expression:` entry references a variable whose `@status == 'unset'` and whose declaration includes `on_demand_by:`, auto-resolution fires per §11.5. The runtime suspends evaluation, invokes the resolver, applies the response, and re-evaluates the entry. If the resolver returns `deny`, the entry's expression evaluates against `@status == 'denied'` (typically false), and the entry's `reason:` becomes the gate's deny reason.

Auto-resolution does NOT fire on the other detection kinds (`pattern`, `llm`, `classifier`) because they are detectors, not predicates over variables. They operate on the stage's content subject, not on the variable state.

### 12.6 The bypass — `allowed_when:`

`allowed_when:` is a guard-policy-level bypass: when any `evaluate_when:` entry fails, the runtime evaluates `allowed_when:` once. If it evaluates truthy, the failure is **suppressed** and the call passes as if no entry had failed.

| Behavior | When |
|----------|------|
| Not declared | Failures stand; the guard policy enforces its action. |
| Declared, evaluates truthy after a failure | Failure suppressed; the guard policy passes; downstream stages run normally. |
| Declared, evaluates falsey / null / denied | Failure stands; the guard policy enforces its action. |

`allowed_when:` is **guard-policy-wide**. It bypasses *whichever* entry failed, not a specific entry. Authors who want per-entry bypass should split the entries into separate guard policies.

**Auto-resolution fires** on `allowed_when:` reads of `unset` variables with `on_demand_by:` (§11.5). This is the canonical "block unless approved" pattern: a `pattern:` entry detects PII; `allowed_when:` references a `pii_disclosure_approved` variable whose `on_demand_by: { kind: human }` resolver prompts the user; on `allow`, the redaction or block is suppressed.

```yaml
guard_policies:
  - name: "pii_block"
    evaluate_when:
      - pattern: '\b\d{3}-\d{2}-\d{4}\b'
        reason: "SSN detected."
      - pattern: '\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b'
        reason: "Credit card detected."
    allowed_when: "pii_disclosure_approved"
```

`allowed_when:` MAY also reference `@event.fired(<event_id>)` to bypass enforcement based on session-scoped signals (e.g., a prior approval event).

### 12.7 Action modes — `block`, `redact`, `warn`, `append`, `prepend`

A guard policy's `action:` declares what happens when an entry fails (and `allowed_when:` does not bypass it). The effective action for a failure is:

1. The failing entry's `action:`, if declared.
2. Otherwise, the guard policy's top-level `action:`, if declared.
3. Otherwise, `block` (the fail-closed default).

| Mode | Behavior |
|------|----------|
| `block` (default) | The subject is rejected. The call does not proceed. Downstream stages do not run. The agent (or, for `output_validation`, the user) receives the entry's `reason:`. |
| `redact` | Matched substrings in the subject are replaced with the entry's `replacement:` (or the guard policy's, or — for content stages — the validator's default). The rewritten subject continues through downstream stages. **Content guard policies only.** |
| `warn` | The subject is forwarded unchanged. The runtime emits a structured log event at `severity: high` (or as configured by the entry's `log:`) and continues with downstream stages. The agent receives no block message. |
| `append` | The entry's `text:` value is appended to the subject. The rewritten subject continues through downstream stages. **Content guard policies only.** Stage-3 use requires `paths:`; Stage 5 is unconstrained; Stages 1 and 4 are rejected at load time (see below). |
| `prepend` | The entry's `text:` value is prepended to the subject. Otherwise identical to `append`. |

**`redact:` constraints.**

- Only valid on detection kinds that produce **character-level spans**: `pattern`, `patterns`, `llm` (when the response includes `spans[]`), and `classifier` (when the provider produces structured per-span offsets). Declaring `action: redact` on an `expression:` entry MUST be a load-time error — expressions are predicates over state, not text scanners.
- Only valid in content guard policies (Stages 1, 3, 4, 5).
- A `replacement:` value is required, taken in priority order from: the entry's `replacement:`, the guard-policy-level `replacement:`, then a stage default if specified.

**`warn:` semantics.**

- A warn-mode failure logs at `severity: high` by default. The entry's or guard policy's `log:` overrides.
- Warn does NOT short-circuit. Subsequent `evaluate_when:` entries continue to run; subsequent guard policies continue to run; downstream stages run. The cumulative effect is "audit but don't gate."
- Warn is the canonical idiom for shadow-rolling out a new gate before flipping it to block.

**`append:` and `prepend:` constraints and shape.**

```yaml
guard_policies:
  - name: "regulatory_disclaimer"
    action: append
    evaluate_when:
      - expression: "@tool.name == 'send_email_external'"
        text: "\n\n---\nThis message was generated with AI assistance. Investment advice contained herein is not a substitute for licensed professional counsel."
        reason: "Regulatory disclaimer required on outbound advisory mail."
        paths:
          - "@tool.params.body"
```

- Permitted in **content guard policies only** (Stages 1, 3, 4, 5). Declaring `action: append` or `action: prepend` on a state guard policy (Stage 2) MUST be a load-time error.
- Permitted on **any** detection kind (`pattern`, `patterns`, `llm`, `classifier`, `expression`). Unlike `redact:`, append/prepend do not require character-level spans — they target a whole field or the whole subject.
- The entry MUST declare a `text:` value. The text MAY include `{variable}` and `{@tool.params.<name>}` template references resolved per §12.9.2.
- **Stage-1 and Stage-4: rejected.** Stage 1 has no rendered subject for which appending or prepending is meaningful (it is a pre-resource stage). Stage 4 transforms would diverge the tool result the agent sees from the parsed result feeding `populated_by:` extractors — the spec forbids this divergence to keep audit trails coherent.
- **Stage-3: paths required.** When append/prepend is used in `tool_execution_validation`, the entry MUST declare `paths:` listing the dotted paths into `@tool.params` / `@endpoint.params` / `@agent.params` whose values receive the text. Each listed path MUST resolve to a string-typed parameter; non-string targets MUST be a load-time error.
- **Stage-5: unconstrained.** When append/prepend is used in `output_validation`, the subject is the agent's response text itself; `paths:` MUST NOT be declared.
- Append/prepend is **mutually exclusive** with `redact:` on the same entry. A single entry MUST declare exactly one of: `replacement:`, `text:` (with `action: append`), or `text:` (with `action: prepend`).
- A failing entry's `text:` is applied unconditionally on each match. Multiple failing entries with append actions concatenate in declaration order; mixing a block action and an append action in one `evaluate_when:` resolves to the block (block always wins).

**Mixing actions in one `evaluate_when:` list.** A single guard policy MAY declare entries with different actions. When multiple entries fail, the runtime applies each entry's effective action independently in declaration order: a warn entry logs and continues; a block entry stops the gate and applies its `reason:`; a redact entry rewrites and continues; an append/prepend entry rewrites and continues. **A block decision short-circuits subsequent entries.** Redactions are applied before transforms (append/prepend) on the same subject so the appended text is never itself redacted.

### 12.8 Span production for `redact`

A redact-mode entry MUST produce **character-level spans** identifying which substrings to rewrite. Each detection kind produces spans differently:

- `pattern` / `patterns` — every regex match is a span.
- `llm` — the validator MUST return a `spans[]` array in its response (§12.9.3). An empty or absent `spans[]` is a no-op (nothing is rewritten and no enforcement event fires).
- `classifier` — the configured classifier MUST return per-span offsets through its provider response. Classifiers whose providers emit only a global score (no per-span offsets) MUST NOT be used in redact mode; doing so MUST be a load-time configuration error.

**All entries see the original subject.** Each redact-mode entry reads spans against the **original** subject; the value forwarded downstream is the original subject with each span replaced by the entry's `replacement:`. This makes their decisions independent of entry ordering and of each other.

Overlapping matches across entries are resolved in an implementation-defined manner, but results MUST be deterministic for a given input and configuration.

### 12.9 Content-guard-policy specifics

This subsection applies only to content guard policies (Stages 1, 3, 4, 5).

#### 12.9.1 Configuration linkage

- `expression:` and `pattern:` / `patterns:` MUST NOT declare `configuration:`.
- `llm:` and `classifier:` MAY declare `configuration:` referencing an entry in `configurations:` (§6) whose `type:` matches the detection kind. Type mismatches MUST be a load-time error.
- When `configuration:` is omitted on an `llm` or `classifier` entry, resolution falls back to the stage-level `configuration:`, then to the `default: true` entry of the matching `type:` (§6.2).

#### 12.9.2 Prompt format for `llm:`

A `prompt:` value is one of:

- **File reference** — a single-line string treated as a path relative to the directory containing the guardrails YAML file (e.g., `"jailbreak_v1.md"`).
- **Inline prompt** — a multi-line YAML literal block scalar (`|`).

The runtime distinguishes the two by checking whether the value contains newlines. If a single-line value cannot be resolved as a file, the runtime MUST log a warning and use the value as the prompt text directly.

The runtime substitutes the following **canonical** template variables before sending the prompt; each stage MAY define additional stage-specific variables (see §14, §16, §17, §18).

| Variable | Description |
|----------|-------------|
| `{user_input}` | The raw user input for the current turn |
| `{objective}` | Newline-separated list from `objective.goal` |
| `{forbidden}` | Newline-separated list from `objective.forbidden` |

**Substitution rules.**

1. Variable names are **case-sensitive**.
2. Undefined variables MUST be replaced with the empty string.
3. Multi-line values preserve formatting.

#### 12.9.3 LLM response format

`llm:` entries MUST receive structured JSON. The minimum schema:

```json
{
  "decision": "ALLOW" | "BLOCK",
  "confidence": 0.0,
  "reason": "<short explanation>",
  "categories": ["<tag>", "..."],
  "spans": [
    { "start": <int>, "end": <int>, "replacement": "<string>" }
  ]
}
```

A response MAY substitute a boolean detection field (e.g., `contains_pii`, `is_jailbreak`) for `decision`; if any such field is `true`, the runtime MUST treat the response as `BLOCK`.

**`spans[]`** is consumed only by redact-mode entries. Each entry identifies a half-open character range `[start, end)` into the **original** subject. `start` and `end` MUST be non-negative integers with `start < end <= len(subject)`. The optional per-span `replacement:` overrides the entry's `replacement:` for that span only.

**Parsing rules.**

1. For block-mode and warn-mode entries: a missing `decision` field MUST be treated as `BLOCK`; a `decision` value other than `ALLOW` or `BLOCK` MUST be treated as `BLOCK`. `spans[]` is ignored.
2. For redact-mode entries: `decision` is ignored; `spans[]` drives the rewrite. An empty or absent `spans[]` is a no-op for that entry (no rewrites are applied and no enforcement event fires). Any span whose offsets are out of range, non-integer, or overlap a previously consumed span in the same response MUST be discarded with a structured warning; remaining well-formed spans MUST still be applied.
3. Malformed JSON MUST trigger the entry's `on_error:` policy (default `block`).
4. The full LLM response MUST be logged for audit.

### 12.10 Execution semantics

For each guard policy whose `applies_to:` matches the call, in declaration order:

1. **Skip** if the guard policy has an `active_if:` that evaluates falsey, null, or denied. No log entry, no detection runs, no auto-resolution.
2. **Evaluate `evaluate_when:` entries in declaration order.** Implementations MAY run independent entries in parallel for performance, but the *visible* verdict-resolution order MUST be declaration order.
3. **For each entry:**
   a. Run the entry's detection.
   b. If detection produces no failure signal, continue to the next entry.
   c. If detection produces a failure signal:
      - Evaluate the guard policy's `allowed_when:` (if declared). Auto-resolution fires here.
      - If `allowed_when:` evaluates truthy, **suppress this failure** and continue to the next entry. The guard policy still passes overall if all subsequent entries pass.
      - Otherwise, apply the entry's effective action: `block` → terminate the gate with this entry's `reason:`; `redact` → record the spans for downstream rewriting and continue; `warn` → log and continue; `append` / `prepend` → record the inserted text and the target paths for downstream rewriting and continue.
4. **Block wins.** If any block-mode entry triggered (after step 3), the call is rejected and every redaction, append, and prepend computed by other entries is discarded.
5. **Otherwise, apply transforms in fixed order:**
   a. **Apply redactions first.** Each redact-mode entry's spans replace the matching substrings of the original subject.
   b. **Apply prepends, then appends, in declaration order.** Each `prepend` entry's `text:` is inserted at the beginning of the target (the whole subject for Stage 5; each path for Stage 3); each `append` entry's `text:` is inserted at the end. Multiple appends concatenate in declaration order; multiple prepends stack so the last-declared prepend ends up at the very front.
   c. The transformed subject (if any transforms were recorded) is forwarded to the next stage. Hosts MUST execute the transformed invocation, not the original; integration code that mutates parameters between gating and execution is forbidden.
6. **Emit a verdict event.** After step 4 or 5 resolves the guard policy's overall verdict, the runtime MUST emit `guard_policy.<name>.failed` if a block-mode entry triggered (step 4), or `guard_policy.<name>.passed` otherwise (including when all failures were bypassed via `allowed_when:`, when only `warn`/`redact`/`append`/`prepend` entries triggered, and when no entry triggered at all). Skipped guard policies (step 1) emit neither event.

**All detection entries see the original subject** for content stages, never a partially redacted or transformed version. Decisions are independent of entry ordering and of each other; only the transform-application step is order-sensitive.

**Object subjects.** When the subject is a structured object (Stage 3's tool / endpoint / agent parameters), `pattern:` and `patterns:` entries are applied independently to each string-valued field; non-string fields pass through unchanged. `append` / `prepend` entries with `paths:` target only the listed string-valued fields. The downstream consumer receives the transformed object.

**Re-validation of transformed Stage-3 subjects.** Stage-3 `append` / `prepend` mutates parameters that earlier guard policies in the same Stage-3 evaluation may have already inspected. Implementations MUST treat the transformed parameters as the canonical invocation: any Stage-2 approval already obtained against the original parameters remains valid for the transformed invocation, and downstream Stages 3, 4, and 5 see the transformed parameters. Authors who need a transformed invocation re-validated against earlier Stage-3 policies SHOULD split the transforms into a later guard policy or into Stage 5.

**Scoping.** When `applies_to:` is declared on a content guard policy (Stages 3 and 4), the guard policy runs only if the resource matches the selector.

### 12.11 Worked examples

#### 12.11.1 State guard policy — single-gate

```yaml
guard_policies:
  - name: "send_email_requires_authorization"
    applies_to:
      tools:
        - send_email
    evaluate_when:
      - expression: "send_email_authorized == true"
        reason: "Per-call email send authorization required."
```

#### 12.11.2 State guard policy — multi-gate with mixed actions

```yaml
guard_policies:
  - name: "wire_transfer_safety"
    applies_to:
      tools:
        - wire_transfer
    active_if: "@tool.params.amount >= 10000"
    evaluate_when:
      - expression: "@tool.params.amount < 50000"
        reason: "Amount exceeds per-transaction ceiling."
      - expression: "wire_transfer_authorized == true"
        reason: "Per-call user authorization required."
      - expression: "kyc_verified == true"
        reason: "KYC not verified — flagged for review."
        action: warn
        log:
          severity: high
          category: kyc
```

#### 12.11.3 Always-block lockdown (no `evaluate_when:`)

A boolean session variable acts as the lockdown flag; the host raises it via `set_variable("lockdown_active", true)` and lowers it via `reset_variable("lockdown_active")` (§21).

```yaml
variables:
  - name: lockdown_active
    type: boolean
    default: false

state_validation:
  guard_policies:
    - name: "threat_response_lockdown"
      applies_to:
        tools:
          - send_email_external
          - upload_to_cloud
          - post_to_slack
        endpoints:
          - pattern: "/api/v1/external/**"
            methods:
              - "*"
      active_if: "lockdown_active"
      reason: "Threat-response lockdown engaged."
      log:
        severity: critical
        category: incident_response
        message: "Blocked {tool} during lockdown."
```

#### 12.11.4 Content guard policy — redact with per-pattern attribution

```yaml
post_tool_validation:
  configuration: "fast-haiku"
  guard_policies:
    - name: "pii_redact"
      action: redact
      replacement: "[REDACTED]"
      evaluate_when:
        - pattern: '\b\d{3}-\d{2}-\d{4}\b'
          reason: "SSN detected."
        - pattern: '\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b'
          reason: "Credit card detected."
```

#### 12.11.5 Content guard policy — block-unless-approved

```yaml
post_tool_validation:
  guard_policies:
    - name: "pii_block_unless_approved"
      evaluate_when:
        - patterns:
            - '\b\d{3}-\d{2}-\d{4}\b'
            - '\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b'
          reason: "PII detected in tool result."
      allowed_when: "pii_disclosure_approved"
```

When the pattern matches, the runtime evaluates `allowed_when:`. The first reference to `pii_disclosure_approved` while `@status == 'unset'` triggers auto-resolution and prompts the host. A truthy result suppresses the block; a `denied` result lets the block stand.

#### 12.11.6 Content guard policy — warn-mode rollout

```yaml
post_tool_validation:
  guard_policies:
    - name: "deep_pii_warn"
      active_if: "data_sensitivity in ['confidential', 'restricted']"
      evaluate_when:
        - llm:
            prompt: "pii_v1.md"
          reason: "Possible nuanced PII surfaced."
          action: warn
```

The expensive LLM only runs when sensitivity is high; failures log without blocking, suitable for shadow rollout.

### 12.12 Composability

When two files declare guard policies with the **same `name:`**, the policies merge:

| Field | Merge rule |
|-------|-----------|
| `name` | Match key (must equal). |
| `description` | Last-wins. |
| `applies_to.tools[]` / `applies_to.agents[]` / `applies_to.endpoints[]` | Concat + dedup (additive across files; child files MAY add resources to a parent's guard policy; cannot remove). |
| `active_if` | **Earliest non-null wins. Child redefinition is a load-time error.** A parent's engagement predicate is immutable so descendants cannot silently broaden the set of invocations the gate runs against. |
| `evaluate_when[]` | Concat in file load order. The merged list is evaluated in declaration order. Mode (`expression` / `pattern` / `patterns` / `llm` / `classifier`) is per-entry; entries do not merge across files. |
| `allowed_when` | **Most-restrictive wins via AND-merge**. When two tiers declare `allowed_when:`, the merged condition is `parent_expr and child_expr` — both expressions MUST permit the bypass. A child file therefore cannot weaken a parent's bypass condition; it can only narrow it. |
| `action` (top-level) | Last-wins. |
| `reason` (top-level, with no `evaluate_when:`) | Last-wins. |
| `replacement` (top-level) | Last-wins. |
| `log` | Last-wins per leaf field; categories concat + dedup. |

Same-name composition is the layering mechanism: an organization-level YAML defines a guard policy with the canonical `evaluate_when:` list, and a developer-level file extends it by adding tools to `applies_to.tools[]` without restating the gate. To **override** a parent's guard policy entirely, declare a new guard policy with a different `name:`.

---
## 13. `resources`

### 13.1 Principle: identity only

A resource entry declares **what the agent can call** — its name, what it does, what privilege class it represents, and which transport governs it. A resource does NOT declare gates, populator hooks, or activation conditions.

- All gating lives in guard policies (§12).
- All variable populators and resetters live on the variable definition (§10.5–§10.6).

The runtime never invokes the agent's resources on the agent's behalf. A conforming runtime MUST NOT call any tool, endpoint, or sub-agent declared in resources: (§13). The runtime's only actions on a proposed call are to allow it, block it, redact or transform its inputs, or signal that the agent SHOULD call a different tool first (the kind: tool resolver, §11.10.2). When a resolver of kind: human / delegate / agent participates in gating, the runtime calls its own configured external services (§6) — not the agent's resources — and the verdict returns to the agent, which remains the sole party that issues resource invocations. This separation is the core invariant: the agent never bypasses a stage by issuing the call directly, and the runtime never bypasses the agent by issuing a resource call on its own.

This separation has three concrete effects: resource entries stay small, gates that span multiple resources are written once, and the populator and resetter behavior of every variable is local to the variable's own definition.

### 13.2 Resource types

| Type | Group key | Matcher |
|------|-----------|---------|
| `tool` | `resources.tools[]` | `name` (exact match) |
| `endpoint` | `resources.endpoints[]` | `pattern` + `methods` |
| `agent` | `resources.agents[]` | `name` (exact match) |

### 13.3 Per-type schema

```yaml
resources:
  tools:
    - name: <string>                                          # REQUIRED — unique, or "*" (catch-all)
      description: <string>
      permission: <read_only|read_write|execute|destructive>  # advisory metadata; surfaced to Stage 3
      protocol: <string>                                      # informational tag (e.g., "mcp", "a2a", "http")
      on_error: <allow|block>
      on_error_log:
        severity: <critical|high|medium|low|info>
        category: <string>
        message: <string>

  endpoints:
    - pattern: <string>                                       # REQUIRED — URI template / glob
      methods:                                                # REQUIRED, or ["*"]
        - <HTTP method>
      description: <string>
      on_error: <allow|block>
      on_error_log: { ... }

  agents:
    - name: <string>                                          # REQUIRED — unique, or "*"
      description: <string>
      on_error: <allow|block>
      on_error_log: { ... }
```

**`permission`** (tools only) is advisory metadata. It is surfaced to the Stage 3 validator LLM via the `{tool_permission}` template variable so the LLM can apply stricter scrutiny to higher-privilege tools.

**`protocol`** is a free-form informational tag. The runtime MUST surface it in audit logs but MUST NOT enforce on it.

**`on_error` / `on_error_log`** govern the runtime's behavior when the underlying call errors. `on_error: block` (the default) prevents downstream stages from running. `on_error: allow` lets execution proceed (best-effort resources).

### 13.4 Endpoint matchers

`endpoint.pattern` supports three matching modes, evaluated in priority order:

1. **Exact** — `/api/v1/accounts/summary`
2. **Parameterized** — `/api/v1/accounts/{account_id}` (RFC 6570 Level 1; `{param}` matches exactly one path segment, no slashes)
3. **Glob** — `/api/v1/external/**` (`**` matches zero or more remaining segments)

**Specificity** is defined as `count(literal segments) − count(parameter segments)`; larger values are more specific.

**Tie-breaking.** When multiple patterns match a URL, the runtime selects in this order:

1. **Mode wins:** exact > parameterized > glob.
2. **Within the same mode, higher specificity wins** (e.g., `/api/v1/users/{id}/posts` beats `/api/v1/users/{id}` for the URL `/api/v1/users/42/posts`).
3. **At equal specificity within the same mode, the entry declared first in merged-file load order wins.**

`methods:` is a list of HTTP methods or `["*"]` for all methods. Method comparison is case-insensitive. Method-exact wins over `["*"]`.

### 13.5 Wildcard / catch-all entries

- `tools[].name: "*"` is a catch-all identity entry for tools the agent discovers at runtime.
- `agents[].name: "*"` is the same for agents.
- `endpoints[].pattern: "**"` with `methods: ["*"]` is the same for endpoints.

Guard policies whose `applies_to:` selectors include `"*"` (tools/agents) or `{ pattern: "**", methods: ["*"] }` (endpoints) govern unlisted resources. Endpoints MAY also be governed by guard policy alone, without a corresponding `resources.endpoints[]` entry — declare a resource entry only when you need `description:` or `on_error:`.

### 13.6 Composability

- Entries are additive: each tier appends its own resources to the merged list.
- When two files declare resources with the same identity (`name` for tools/agents; `pattern + methods` for endpoints):
  - `description`: **last-wins**.
  - `permission`: **last-wins**, but the merged value MUST NOT broaden — implementations MUST surface a load-time error if a child file weakens permission relative to a parent.
  - `protocol`: **must-match** — child files declaring a different `protocol` produce a load-time error.

### 13.7 Examples

**Tool:**

```yaml
resources:
  tools:
    - name: "send_email"
      description: "Send an email message"
      permission: "execute"
      protocol: "mcp"
```

**Endpoint:**

```yaml
resources:
  endpoints:
    - pattern: "/api/v1/payments/{payment_id}"
      methods:
        - POST
      description: "Execute a payment"
```

**Agent:**

```yaml
resources:
  agents:
    - name: "fraud_detection_agent"
      description: "Sub-agent specialized in fraud detection"
```

---
## 14. `input_validation` (Stage 1)

`input_validation` MUST run before any other stage of the interaction and MUST gate the user's raw input text. Its purpose is to detect and reject prompts like jailbreak attempts, PII, malicious patterns, and policy-violating content before they enter the agent's context.

The block uses content guard policies (§12). This chapter specifies only what is unique to `input_validation`.

| Property | Value |
|----------|-------|
| **Subject** | The user's raw input text |
| **Pipeline position** | First stage; runs before resources are selected |
| **`applies_to:`** | NOT permitted (no resource is yet bound) |
| **Detection kinds in `evaluate_when:`** | `expression` / `pattern` / `patterns` / `llm` / `classifier` |
| **Action modes** | `block` (default) / `redact` / `warn` (§12.7) |
| **Template variables** | Canonical set only (§12.9.2) |

### 14.1 Schema

```yaml
input_validation:
  configuration: <id>          # OPTIONAL — references a configurations entry (default if omitted)
  guard_policies:
    - name: <string>
      # ... per §12 schema, with `applies_to:` rejected
```

### 14.2 Example

```yaml
input_validation:
  configuration: "fast-haiku"
  guard_policies:
    - name: "jailbreak_regex"
      evaluate_when:
        - pattern: "ignore.*(?:previous|all|prior).*(?:instructions|rules|guidelines)"
          reason: "Jailbreak attempt detected (regex)."

    - name: "jailbreak_llm"
      evaluate_when:
        - llm:
            prompt: "jailbreak_v1.md"
          reason: "Jailbreak attempt detected (LLM)."

    - name: "content_moderation"
      evaluate_when:
        - classifier:
            configuration: "content-safety"
          reason: "Content moderation failure."

    - name: "ssn_redact"
      action: redact
      replacement: "[SSN REDACTED]"
      evaluate_when:
        - pattern: '\b\d{3}-\d{2}-\d{4}\b'
          reason: "SSN detected in user input."
```

## 15. `state_validation` (Stage 2)

`state_validation` runs after Stage 1 succeeds and gates the call against the runtime's session state. Its detection kind is restricted to `expression` — Stage 2 is the deterministic stage. The block uses state guard policies (§12).

| Property | Value |
|----------|-------|
| **Subject** | The session state at gate-time (variables, predicates, events) |
| **Pipeline position** | After Stage 1; before Stage 3; runs once per resource invocation |
| **`applies_to:`** | **Required** on every guard policy |
| **Detection kinds in `evaluate_when:`** | `expression` only |
| **Action modes** | `block` (default) / `warn` (`redact` is rejected — there is no text to redact) |

### 15.1 Schema

```yaml
state_validation:
  guard_policies:
    - name: <string>
      applies_to:                     # REQUIRED
        tools: [...]
        agents: [...]
        endpoints: [...]
      # ... per §12 schema, expression-only detection
```

### 15.2 Example

```yaml
state_validation:
  guard_policies:
    - name: "send_email_requires_authorization"
      applies_to:
        tools:
          - send_email
      evaluate_when:
        - expression: "send_email_authorized == true"
          reason: "Per-call email send authorization required."

    - name: "no_sensitive_egress"
      description: "Disable egress while sensitive data is in context."
      applies_to:
        tools:
          - send_email_external
          - upload_to_cloud
        endpoints:
          - pattern: "/api/v1/external/**"
            methods:
              - "*"
      active_if: "data_sensitivity in ['confidential', 'restricted']"
      reason: "Egress is disabled while sensitive data is in context."
      log:
        severity: high
        category: "sensitivity"
        message: "Blocked {tool} during sensitive context."

    - name: "threat_response_lockdown"
      applies_to:
        tools:
          - send_email_external
          - upload_to_cloud
          - post_to_slack
        endpoints:
          - pattern: "/api/v1/external/**"
            methods:
              - "*"
      active_if: "lockdown_active"   # session variable, raised/lowered by host
      reason: "Threat-response lockdown engaged."
      log:
        severity: critical
        category: "incident_response"
        message: "Lockdown engaged."
```

---
## 16. `tool_execution_validation` (Stage 3)

`tool_execution_validation` inspects the agent's **proposed call** before it executes. It catches attacks that bypass deterministic rules: subtle prompt injections, social engineering, parameter manipulation, and **indirect prompt injection** (where untrusted data returned by prior calls embeds instructions that manipulate the agent).

The block uses content guard policies (§12). This chapter specifies only what is unique to `tool_execution_validation`.

| Property | Value |
|----------|-------|
| **Subject** | String-valued fields of the proposed call's parameters |
| **Pipeline position** | After Stage 2 gating succeeds; before the call executes |
| **`applies_to:`** | Permitted at both block and per-policy level |
| **Detection kinds in `evaluate_when:`** | `expression` / `pattern` / `patterns` / `llm` / `classifier` |
| **Action modes** | `block` (default) / `redact` / `warn` |
| **Template variables** | Canonical set (§12.9.2) plus the stage-specific variables in §16.1 |

> **Note on naming.** This stage retains the name "tool execution validation" because it is the canonical second-LLM review point. For endpoint and agent resources the same stage applies — the validator receives the resource type, identifier, and parameters.

### 16.0 Canonical invocation binding

> Although nested under §16 for numbering, this section is normative for every invocation-bound stage: `state_validation` (§15), `tool_execution_validation` (§16), and `post_tool_validation` (§17). It is placed here as the first subsection of §16 because Stage 3 is the canonical second-LLM review point and the most common site for invocation-binding regressions.

A runtime MUST construct a canonical invocation object before evaluating any invocation-bound stage (`state_validation`, `tool_execution_validation`, or `post_tool_validation`). The canonical object MUST include the resource kind, resource identity, matched resource identity when known, method and URI for endpoints, path parameters, query parameters, and structured invocation parameters or payload.

Canonical invocation serialization MUST recursively sort JSON object keys before hashing. Implementations MUST reject or normalize duplicate object keys before constructing the canonical object; they MUST NOT allow duplicate-key ambiguity to affect policy decisions. The canonical invocation hash is SHA-256 over the canonical JSON bytes, encoded as lowercase hexadecimal.

A safe wrapper MUST execute the same invocation whose canonical hash was validated. If Stage 3 intentionally transforms parameters through `redact`, `append`, or `prepend`, the verdict MUST expose both the pre-validation invocation hash and the post-validation invocation hash. The host MUST execute the post-validation invocation and MUST NOT execute a later-mutated invocation under the prior verdict. For `post_tool_validation`, the runtime MUST bind the same canonical invocation that Stage 3 admitted; binding a tool-name-only synthetic invocation MUST NOT be treated as satisfying this requirement.

**Stable per-invocation handle.** To make the binding above enforceable across stages and across same-name concurrent invocations within a turn, every invocation-bound stage call MUST carry a stable per-invocation handle (the `tool_call_id` parameter on the SDK surface and `invocation_handle` on the wire). The handle is the binding key the runtime uses to pair Stage 3 admissions with Stage 4 outputs; a Stage 4 call whose handle does not match a Stage 3 admission MUST fail closed with a binding-missing verdict and MUST NOT fall back to a synthetic invocation.

Hosts SHOULD propagate the model-supplied call identifier when one exists (OpenAI `tool_call_id`, Anthropic `tool_use_id`, MCP request id, rig `internal_call_id`, and equivalents). When the host framework does not natively expose a stable identifier at the validation site, the adapter MUST synthesize one (for example a UUIDv4 generated at the call site) that is unique within the turn. Synthetic identifiers are equivalent to model-supplied identifiers for the binding contract; the runtime MUST NOT distinguish between them. Conforming SDK surfaces MUST require the handle as a non-optional parameter on validate functions; surfaces that admit a "no-id" call path violate this section.

Approval requests, audit events, and adapter verdicts SHOULD carry the canonical invocation hash whenever they refer to an invocation-bound decision. Conforming non-Rust SDK surfaces MUST propagate the `invocation_hash` and `post_validation_invocation_hash` fields across the FFI boundary so host integrations can read them off the verdict; stripping these fields at the language boundary MUST be treated as a contract violation, not optional ergonomics.

### 16.1 Stage-specific template variables

In addition to the canonical variables of §12.9.2, LLM-based entries in `tool_execution_validation` receive:

| Variable | Description |
|----------|-------------|
| `{tool_name}` | Name of the proposed call (tool / endpoint / agent identifier) |
| `{tool_params}` | JSON-serialized call parameters |
| `{tool_permission}` | The tool's declared `permission:` (advisory) |
| `{tool_description}` | The tool's declared `description:` |
| `{variables}` | Current session variables as JSON |
| `{active_guard_policies}` | Comma-separated list of currently active guard-policy names (or `"(none)"`) |
| `{prior_checks_summary}` | Plain-English summary of automated checks already applied to this call |

`{prior_checks_summary}` describes which deterministic checks (Stage 2 guard policies) have already passed for this call. This enables the validator LLM to focus on threats that deterministic rules cannot catch — injection, social engineering, parameter manipulation — rather than re-evaluating already-enforced conditions.

**`{user_input}` enrichment — tool result provenance markers.** `tool_execution_validation` MUST enrich `{user_input}` by appending boundary-marked prior tool results from the current user turn so the validator LLM can distinguish trusted user input from untrusted tool-returned data:

```
<user's original input text>

## START TOOL RESPONSE: <tool_name> ##
<tool result content, truncated to an implementation-defined maximum>
## END TOOL RESPONSE: <tool_name> ##
```

If no tools have executed in the current turn, `{user_input}` contains only the raw user text. Tool results MUST be appended in execution order and SHOULD be truncated to a reasonable maximum (e.g., 2000 characters each).

### 16.2 Runtime Context block (Default Implementation)

> **(Default Implementation)** Substitute runtimes MAY use a different layout for the appended context block. The Pure Specification requirement is that **every template variable named in §16.1 MUST be made available to the LLM**, either through the prompt's own `{var}` references or through an appended block. The format below is the layout the reference runtime ships with.

The reference runtime appends the following block to the end of every `tool_execution_validation` LLM-detection prompt (after any user-supplied template substitution):

```
## Runtime Context

Tool: {tool_name}
Description: {tool_description}
Permission: {tool_permission}
Parameters:
{tool_params}

Active guard policies: {active_guard_policies}
Variables:
{variables}

## Prior Automated Checks
{prior_checks_summary}
```

Implementations that diverge from this layout SHOULD document their replacement clearly so prompt authors can target it.

### 16.3 Schema

```yaml
tool_execution_validation:
  configuration: <id>          # OPTIONAL — references a configurations entry (default if omitted)
  applies_to:                  # OPTIONAL — block-level scoping; per §12.3
    tools: [...]
    agents: [...]
    endpoints: [...]
  guard_policies:
    - name: <string>
      # ... per §12 schema, with `applies_to:` accepted at per-policy level too
```

### 16.4 Example

```yaml
tool_execution_validation:
  configuration: "strong-sonnet"
  guard_policies:
    - name: "task_adherence"
      evaluate_when:
        - llm:
            prompt: "task_adherence_v1.md"
          reason: "Proposed call deviates from stated objective."

    - name: "content_safety"
      evaluate_when:
        - classifier:
            configuration: "content-safety"
          reason: "Content moderation failure on proposed call parameters."

    - name: "secret_scrub"
      action: redact
      replacement: "[SECRET REDACTED]"
      evaluate_when:
        - pattern: '(?i)\b(?:api[_-]?key|token|bearer)\s*[:=]\s*\S+'
          reason: "Secret-like value detected in parameters."
```

---
## 17. `post_tool_validation` (Stage 4)

`post_tool_validation` inspects the **raw result returned by a call** before the agent processes it. It catches:

- **Indirect prompt injection** — instructions embedded in tool output that would manipulate the agent.
- **Sensitive data leaks** — PII, secrets, or restricted data returned in call results.

The block uses content guard policies (§12). This chapter specifies only what is unique to `post_tool_validation`.

| Property | Value |
|----------|-------|
| **Subject** | The raw call result text (tool / endpoint / agent) |
| **Pipeline position** | After the call executes; after `populated_by:` writes; before the agent processes the result |
| **`applies_to:`** | Permitted at both block and per-policy level |
| **Detection kinds in `evaluate_when:`** | `expression` / `pattern` / `patterns` / `llm` / `classifier` |
| **Action modes** | `block` (default) / `redact` / `warn` |
| **Template variables** | Canonical set (§12.9.2) plus the stage-specific variables in §17.1 |

Per-stage ordering: `populated_by:` (phase: after) → `reset_by phase: after` → `post_tool_validation`. See the lifecycle diagram in §10.8. Variables are extracted from the **raw** (unsanitized) call output — preserving data fidelity for state management — while the agent sees only the sanitized version.

### 17.1 Stage-specific template variables

In addition to the canonical variables of §12.9.2, LLM-based entries in `post_tool_validation` receive:

| Variable | Description |
|----------|-------------|
| `{tool_output}` | The raw call result being validated |
| `{tool_name}` | Name of the resource that produced this output |
| `{tool_params}` | JSON-serialized parameters that were passed to the call |
| `{variables}` | Current session variables as JSON |
| `{active_guard_policies}` | Comma-separated list of currently active guard-policy names |

### 17.2 Schema

```yaml
post_tool_validation:
  configuration: <id>
  applies_to:                  # OPTIONAL — block-level scoping
    tools: [...]
    agents: [...]
    endpoints: [...]
  guard_policies:
    - name: <string>
      # ... per §12 schema
```

### 17.3 Example

```yaml
post_tool_validation:
  configuration: "fast-haiku"
  guard_policies:
    - name: "ssn_redact"
      action: redact
      replacement: "[SSN REDACTED]"
      evaluate_when:
        - pattern: '\b\d{3}-\d{2}-\d{4}\b'
          reason: "SSN in tool result."

    - name: "sensitive_content"
      evaluate_when:
        - llm:
            prompt: "tool_output_sensitive_data_v1.md"
          reason: "Sensitive content surfaced by tool."
```

### 17.4 Block-unless-approved pattern

The canonical way to gate a call result on a human (or delegate / agent) confirmation is to declare a boolean variable in `variables[]` whose `on_demand_by:` invokes the resolver, then reference it from `allowed_when:` on the guard policy. Persistence of the decision is the variable's `lifetime:`; stickiness on a "no" is the per-outcome `lifetime:` map form (§9.1.2). No separate approval action is needed.

```yaml
variables:
  - name: "pii_disclosure_approved"
    type: "boolean"
    on_demand_by:
      kind: human
      prompt: "Tool returned PII. Approve disclosure to the agent?"
    lifetime:
      allow: per_session
      deny: per_session   # one rejection sticks for the whole session

post_tool_validation:
  guard_policies:
    - name: "pii_block"
      allowed_when: "pii_disclosure_approved"
      evaluate_when:
        - pattern: '\b\d{3}-\d{2}-\d{4}\b'
          reason: "PII detected in tool result."
```

When `pii_block`'s `evaluate_when:` matches, the runtime evaluates `allowed_when:`. The first reference to `pii_disclosure_approved` while `@status == 'unset'` triggers auto-resolution (§11.5) and prompts the host operator. A truthy result suppresses the block; a `denied` result lets the block stand.

---
## 18. `output_validation` (Stage 5)

`output_validation` inspects the agent's final response **before** it is delivered to the user. It catches:

- **PII leakage** — the agent reads a document containing SSNs or credit cards and includes them in its response.
- **Sensitive data exfiltration** — restricted content surfaced to the user.
- **Hallucination** — claims not grounded in tool results.
- **Compliance filtering** — content that regulatory or policy requirements forbid reaching end users.

The block uses content guard policies (§12). This chapter specifies only what is unique to `output_validation`.

| Property | Value |
|----------|-------|
| **Subject** | The agent's response text |
| **Pipeline position** | Final stage; runs on the per-turn agent response after every call invocation has completed |
| **`applies_to:`** | NOT permitted (the response is not attributable to a single resource) |
| **Detection kinds in `evaluate_when:`** | `expression` / `pattern` / `patterns` / `llm` / `classifier` |
| **Action modes** | `block` (default) / `redact` / `warn` |
| **Template variables** | Canonical set (§12.9.2) plus the stage-specific variables in §18.1 |

### 18.1 Stage-specific template variables

In addition to the canonical variables of §12.9.2, LLM-based entries in `output_validation` receive:

| Variable | Description |
|----------|-------------|
| `{agent_output}` | The agent's complete response text being validated |
| `{variables}` | Current session variables as JSON |
| `{active_guard_policies}` | Comma-separated list of currently active guard-policy names |

### 18.2 Schema

```yaml
output_validation:
  configuration: <id>          # OPTIONAL
  guard_policies:
    - name: <string>
      # ... per §12 schema, with `applies_to:` rejected
```

### 18.3 Example

```yaml
output_validation:
  configuration: "fast-haiku"
  guard_policies:
    - name: "pii_redact"
      action: redact
      replacement: "[REDACTED]"
      evaluate_when:
        - pattern: '\b\d{3}-\d{2}-\d{4}\b'
          reason: "SSN in agent output."
        - pattern: '\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b'
          reason: "Credit card in agent output."

    - name: "hallucination_check"
      evaluate_when:
        - llm:
            prompt: "output_hallucination_v1.md"
          reason: "Possible hallucination — claims not grounded in tool results."
```

---
## 19. Observability

Logging is **orthogonal to enforcement**. Every stage MAY emit structured log events; gating decisions are made independently of whether a log was configured.

### 19.1 The `log:` block

```yaml
log:
  severity: <critical|high|medium|low|info>   # default: medium
  category: <string>                           # free-form routing/filtering tag
  message: <string>                            # supports {variable} interpolation
```

**Severity levels.**

| Level | Meaning |
|-------|---------|
| `critical` | Immediate human attention required |
| `high` | Security event — potential threat or policy violation |
| `medium` | Policy enforcement action taken |
| `low` | Notable but expected event |
| `info` | Diagnostic / audit information |

**Resolution rules.**

- Per-entry `log:` (inside `evaluate_when[]`) overrides guard-policy-level `log:`.
- Guard-policy-level `log:` overrides stage-level `log:`.
- Stage-level `log:` serves as a default for all guard policies in that stage.
- When no `log:` is present, enforcement actions auto-emit at:
  - `medium` for `block` and `redact`.
  - `high` for `warn` (warn defaults louder so shadow rollouts are visible).
  - `allow` (a successful pass) emits nothing unless an explicit `log:` block is present.
- A failure suppressed by `allowed_when:` (§12.6) is logged as `allow` for the guard policy and accompanied by the standard auto-resolution audit event (§11.9) for any resolver fired during the bypass evaluation.

### 19.2 Structured event schema

Every log event emitted by the runtime MUST contain at minimum:

```json
{
  "timestamp": "<ISO-8601>",
  "event_type": "validation_triggered | guard_policy_activated | guard_policy_deactivated | call_blocked | resolution_invoked",
  "agent_id": "<from metadata.name>",
  "stage": "input | state | tool_execution | post_tool | output",
  "action": "allow | block | redact | warn",
  "severity": "<level>",
  "category": "<from log.category>",
  "message": "<from log.message, with {variable} interpolation>",
  "tool": "<resource identifier when applicable>",
  "guard_policy": "<guard-policy name when applicable>",
  "evaluate_when_index": "<integer index of the failing entry, when applicable>"
}
```

### 19.3 Semantic attribute namespace

Implementations MUST use the `agent_shield.*` attribute namespace for structured log metadata:

| Attribute | Type | Description |
|-----------|------|-------------|
| `agent_shield.stage` | string | Validation stage |
| `agent_shield.category` | string | From `log.category` |
| `agent_shield.action` | string | Enforcement decision (`allow` / `block` / `redact` / `warn`) |
| `agent_shield.severity` | string | From `log.severity` |
| `agent_shield.tool` | string | Resource identifier |
| `agent_shield.guard_policy` | string | Guard-policy name |
| `agent_shield.evaluate_when_index` | int | Index of the failing `evaluate_when[]` entry, when applicable |
| `agent_shield.agent_id` | string | From `metadata.name` |

### 19.4 Default logging semantics

The canonical rule for emit-on-decision is defined in §19.1. This subsection adds the cross-stage events that are always emitted regardless of any per-guard-policy `log:` configuration:

- Resolver invocations emit a mandatory audit-log event regardless of decision (§11.9).
- The closed-namespace events listed in §19.5 are always emitted.

### 19.5 Required log events

A conforming runtime MUST log:

- Resource calls (every invocation: tool, endpoint, agent).
- Guard-policy activations and deactivations.
- Gating decisions (allow / block / redact / warn).
- Resolver invocations (with `kind`, `lifetime`, `decision`, `latency_ms`, and — on error — the error kind).
- Every event from the closed event namespace (§9.3).

### 19.6 Composability

When multiple tiers define `log:` for the same entry:

- **Severity:** highest wins (cannot be weakened by later tiers).
- **Categories:** concat + dedup.
- **Messages:** later tiers override.

---
## 20. Agent contract

Agent Shield is a runtime contract between three actors: **the policy author** (who writes guardrails YAML), **the runtime** (the SDK that enforces it), and **the agent** (the LLM-powered host). Sections 1–19 specify what the runtime MUST do. This section specifies the obligations of the agent.

### 20.1 Honoring resolver decisions

When the runtime returns a `block` (or `deny` / `cancelled`) decision for a tool call, agent invocation, or endpoint call, the agent MUST NOT retry the same call with identical parameters in the same turn. The agent MAY retry after taking a remediating action that the runtime exposed as a resolution path — typically by calling the tool that the `reason:` text indicated. Runtimes MAY enforce per-resource retry limits and convert further attempts into emergency-state activations.

### 20.2 Honoring lifetimes

A variable's `lifetime:` is runtime-managed session state. Agents MUST NOT assume a `per_session` resolver decision will persist across runtime restarts, nor that a `per_call` decision will persist into the next call. Agents MUST treat the variable snapshot delivered with each gating decision as authoritative for the current call only.

### 20.3 Honoring resolver lifetimes

Resolvers MAY complete asynchronously (especially `human` and HTTP `delegate` kinds). When the runtime suspends a gating evaluation pending a resolver response, the agent SHOULD wait for the runtime's resumption signal rather than re-issuing the call. Re-issuing the call enqueues a duplicate evaluation and MAY double-count rate limits.

### 20.4 Honoring reasons and skill hints

When an `evaluate_when[].reason:` or resolver `reason:` describes a remediation path ("call `verify_recipient` first"), agents SHOULD attempt that remediation before re-issuing the original call. Hosts that integrate Agent Shield with skill-style routing systems MUST surface the runtime's `reason:` text in the agent's prompt context.

### 20.5 Honoring warn-mode signals

A guard policy that runs in `warn` mode does NOT block the call, but the runtime emits a high-severity log entry. Agents SHOULD surface the warning's `reason:` to downstream auditing or to the user when appropriate. Treating warn entries as silent passes defeats the staged-rollout pattern they exist to support.

---
## 21. Runtime API (Default Implementation)

Agent Shield runtimes SHOULD expose the following host-callable operations. Runtimes MAY rename, re-shape, or re-package these calls as long as they expose the observable contract (variable status envelope, event emission and clearing, the resolver wire envelope, guard-policy enforcement modes).

The names below are examples. Sections §3–§20 refer to this table whenever they say "via the runtime API".

| Operation | Purpose | Defined in |
|-----------|---------|-----------|
| `set_variable(name, value, options?)` | Apply a value to a declared variable, subject to its `update:` expression (§10.2). Transitions `@status` to `resolved`. The optional `options` map carries `key:` (REQUIRED when the variable declares `key:` (§10.4)), `reason:` (free-form audit text recorded in `@source_reason`), and `lifetime:` (override of the variable's declared lifetime for this write only; same grammar as §9.1). | §10 |
| `reset_variable(name, options?)` | Clear a declared variable to `@status == 'unset'` and `value: null`. The optional `options` map carries `key:` (when the variable declares `key:`; clears only that key entry; omitted ⇒ clears every key entry of the variable). | §10 |
| `resolve_variable(name)` | Synchronously invoke the variable's declared resolver and apply the returned envelope. | §11 |
| `emit_event(event_id)` | Emit a host-driven lifecycle event from the closed namespace. Permitted identifiers are `turn.start`, `turn.end`, `request.start`, and `request.end`; any other identifier MUST be a load-time or runtime error. | §9 |
| `clear_event(event_id)` | Clear a previously latched event so `@event.fired(<id>)` returns `false` again. | §9 |
| `register_provider(name, factory)` | Register a named provider implementation (§6) before `build()`. | §6 |
| `register_human_resolver(callback)` | Register the callback that fulfills `kind: human` resolver invocations. | §11 |

Calls MAY be synchronous or asynchronous. Runtimes MAY layer additional helpers on top of these primitives.

---

## License

This specification is licensed under MIT.
