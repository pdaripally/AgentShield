# Agent Shield Expression Language

This document defines the core Agent Shield Expression Language used by `evaluate_when[].expression:`, `allowed_when:`, and `active_if:` guardrail predicates. The key words **MUST**, **MUST NOT**, **SHOULD**, **SHOULD NOT**, and **MAY** are to be interpreted as described in RFC 2119.

Agent Shield expressions are deliberately optimized for single-line YAML predicates. They are designed to fail closed when data is missing or invalid.

All YAML keys referenced by expressions SHOULD use `snake_case`.

## Design Principles

### Lowercase keyword operators

The language uses lowercase keyword operators (`and`, `or`, `not`, `in`), function-call syntax for built-ins, and `:=` for immutable local bindings.

### Strict typing

The language has explicit runtime types and does not perform implicit cross-type coercion. Type mismatches evaluate to `false` or `null`, never to a silently converted value.

### Fail-closed null semantics

Missing variables evaluate to `null`. `null` is falsy, propagates through arithmetic, and never accidentally grants access. This is a security invariant.

### Predicate-only scope

The language is a single-expression predicate language. It has no package system, imports, named rules, module-level evaluation, or multi-rule resolution.

## 1. Overview

The Agent Shield Expression Language is a predicate language for runtime guardrail conditions. It is optimized for concise policy expressions embedded in YAML, such as:

```yaml
allowed_when: "data_sensitivity == 'restricted' and user_clearance in ['admin', 'elevated']"
active_if: "time.now().weekday in ['Saturday', 'Sunday']"
```

Expressions MAY produce intermediate non-boolean values, but guardrail evaluation ultimately uses truthy/falsy coercion.

### 1.1 Multi-line expressions

Because `allowed_when` and `active_if` values are YAML strings, authors MAY use
YAML block scalars (`|`) to split long expressions across multiple lines. The
tokenizer treats newlines as whitespace, so `;` (equivalent to `and`) separates
conditions naturally:

```yaml
allowed_when: |
  not is_null(data_sensitivity);
  data_sensitivity != 'restricted';
  user_clearance == 'manager' or data_sensitivity == 'public'
```

This is semantically identical to the single-line form:

```yaml
allowed_when: "not is_null(data_sensitivity) and data_sensitivity != 'restricted' and (user_clearance == 'manager' or data_sensitivity == 'public')"
```

## 2. Operators and Syntax

### 2.1 Canonical operators

The canonical logical operators are the word forms:

- `and`
- `or`
- `not`

The following aliases are equivalent and MUST use the same precedence and semantics:

- `&&` == `and`
- `||` == `or`
- `!` == `not`
- `;` == `and`

Examples:

```yaml
allowed_when: "user_clearance == 'admin' && fraud_score < 75"
allowed_when: "!is_null(document_owner) || emergency_override == true"
allowed_when: "bal := account.balance; bal > 0; bal < daily_limit"
```

Word forms SHOULD be preferred in examples and policy authoring.

### 2.2 Ternary operator

The language defines a ternary conditional operator:

```text
condition ? when_true : when_false
```

Rules (**MUST**):

- Ternary MUST short-circuit; implementations MUST NOT evaluate the unselected branch.
- Ternary MUST be right-associative.
- Ternary MUST have lower precedence than `or` and higher precedence than `:=`.

Examples:

```yaml
allowed_when: "risk_score > 90 ? false : true"
allowed_when: "is_null(limit) ? default_limit : limit"
allowed_when: "a ? b : c ? d : e"   # parses as a ? b : (c ? d : e)
```

### 2.3 Indexing

The language defines postfix indexing with `[]`.

Rules (**MUST**):

- `array[index]` reads a zero-based array element.
- The index expression MUST evaluate to an integer-valued `number`.
- Negative or out-of-bounds array access MUST return `null`.
- `object['key']` reads an object member by string key.
- Missing object keys MUST return `null`.
- Indexing a non-array, non-object, or using the wrong key type MUST return `null`.

Unlike CEL, Agent Shield returns `null` rather than raising an evaluation error.

Examples:

```yaml
allowed_when: "active_compliance_contexts[0] == 'HIPAA'"
allowed_when: "account['owner'] == 'alice'"
allowed_when: "object.get(account, 'owner', null) == account['owner']"
```

### 2.4 Member access and calls

Dot access is left-associative and MAY chain arbitrarily:

```yaml
allowed_when: "account.owner.region == 'US'"
allowed_when: "time.now().hour >= 9 and time.now().hour < 18"
```

Postfix operations MUST bind tighter than every infix operator.

### 2.5 Operator precedence

Implementations MUST observe the following precedence, highest to lowest:

| Level | Operators | Associativity |
| --- | --- | --- |
| 1 | `()`, function calls, `.`, `[]` | postfix / grouping |
| 2 | unary `-` | right |
| 3 | `*`, `/`, `%` | left |
| 4 | `+`, `-` | left |
| 5 | `==`, `!=`, `<`, `>`, `<=`, `>=`, `in` | non-associative |
| 6 | `not`, `!` | right |
| 7 | `and`, `&&`, `;` | left |
| 8 | `or`, `||` | left |
| 9 | `? :` | right |
| 10 | `:=` | right |

Examples:

```text
a + b * c            -> a + (b * c)
not x in ['a', 'b']  -> not (x in ['a', 'b'])
a or b and c         -> a or (b and c)
x := cond ? a : b    -> x := (cond ? a : b)
```

### 2.6 Membership operator (`in`)

The `in` operator tests whether a value is a member of a collection. It is a comparison-level operator (precedence level 5, non-associative).

Rules (**MUST**):

- `x in array` — `true` if `x` is strictly equal (`==`) to any element in the array.
- `x in object` — `true` if `x` is strictly equal (`==`) to any **value** in the object. 
- `null in collection` — `null` (fail-closed: missing needle never matches).
- `x in null` — `null` (fail-closed: missing collection never matches).
- `x in non_collection` — `null` for any type other than `array` or `object` (fail-closed).
- `in` MUST use strict equality (`==` semantics): no cross-type coercion.
- The `null` return (rather than `false`) ensures that `not x in collection` fails closed when either operand is missing, because `not null` evaluates to `false`.

`x in obj` checks whether `x` appears among the object's values — it does NOT check keys. Policy authors who need key-existence checks SHOULD use `has(obj, key)`.

Examples:

```yaml
# Array membership
allowed_when: "user_clearance in ['admin', 'manager']"
allowed_when: "'EU' in data_jurisdictions"

# Object value membership
allowed_when: "'critical' in alert_levels"          # true if any value in alert_levels equals 'critical'
allowed_when: "user_id in session_owners"           # true if user_id matches any value in session_owners

# Key existence — use has(), not in
allowed_when: "has(account, 'fraud_score')"         # checks whether 'fraud_score' key exists
```

```text
'a' in ['a', 'b', 'c']            -> true
'd' in ['a', 'b', 'c']            -> false
3 in {'x': 1, 'y': 3}             -> true   (3 is a value)
'x' in {'x': 1, 'y': 3}           -> false  ('x' is a key, not a value)
null in ['a', 'b']                -> null   (fail-closed)
'a' in null                       -> null   (fail-closed)
not null in ['a']                 -> false  (not null → false)
not 'd' in ['a', 'b']             -> true   (not false → true)
```

## 3. Type System

### 3.1 Runtime types

Implementations MUST support exactly nine runtime types:

- `string`
- `number`
- `boolean`
- `array`
- `object`
- `datetime`
- `duration`
- `enum`
- `null`

`type_name(x)` MUST return one of those strings. Implementations MUST NOT introduce additional runtime types.

### 3.2 Numbers

The language uses IEEE 754 `f64` for all numeric values.

Rules:

- Integer literals MUST be represented as `number`.
- Integer values MUST be exact through `2^53`.
- Numeric overflow MAY produce IEEE 754 infinity.
- Division by zero MUST return `null`.
- Modulo by zero MUST return `null`.

Examples:

```yaml
allowed_when: "api_cost_accumulated + estimated_cost < 1000"
allowed_when: "request_count % 100 == 0"
```

### 3.3 Strings

### 3.3 Strings

Strings are sequences of valid Unicode code points. Implementations MUST reject lone UTF-16 surrogate code points (U+D800–U+DFFF); a string containing a surrogate MUST be treated as an evaluation error that produces `null`.

String literals have two forms:

- Single-quoted strings MUST be treated as raw literals; no escape processing is performed.
- Double-quoted strings MUST support escape sequences.

Supported double-quoted escapes (**MUST**):

- `\\` — backslash
- `\"` — double quote
- `\0` — null character (U+0000)
- `\n` — line feed (U+000A)
- `\t` — horizontal tab (U+0009)
- `\r` — carriage return (U+000D)
- `\xHH` — two hex digits, denoting a Unicode code point (U+0000–U+00FF)
- `\uHHHH` — four hex digits, denoting a Unicode code point in the Basic Multilingual Plane (U+0000–U+FFFF)
- `\UHHHHHHHH` — eight hex digits, denoting any Unicode code point (U+0000–U+10FFFF)

Hex digits in escape sequences MUST be case-insensitive.

A backslash followed by any character not listed above MUST be a parse error. Implementations MUST reject the expression rather than silently passing through the invalid escape. This is required by the fail-closed security posture.

Unicode surrogate code points (U+D800–U+DFFF) MUST NOT be expressible via `\u` or `\U` escapes; such escapes MUST be a parse error.

#### String comparison and ordering

String comparison MUST use lexicographic ordering of Unicode code points (numeric value). Implementations MUST NOT perform Unicode normalization (NFC, NFD, NFKC, NFKD) or locale-sensitive collation. Two strings are equal if and only if they contain the same sequence of code points.

#### String length

`count(str)` MUST return the number of Unicode code points in the string, not the number of bytes. Functions that accept index arguments (`charAt`, `indexOf`, `substring`, etc.) MUST use code-point-based indexing.

Examples:

```yaml
allowed_when: "department == 'risk_ops'"
allowed_when: 'message == "line1\nline2"'
allowed_when: 'path == "C:\\docs\\policy.txt"'
allowed_when: "region == '\u00C9milie'"
```

### 3.4 Datetime and duration

`time.now()` returns `datetime`. `time.duration()` returns `duration`.

Implementations MUST apply the following arithmetic and comparison rules:

- `datetime - datetime` MUST produce `duration`
- `datetime + duration` MUST produce `datetime`
- `datetime - duration` MUST produce `datetime`
- `duration + duration` MUST produce `duration`
- `duration - duration` MUST produce `duration`
- `duration * number` MUST produce `duration`
- `number * duration` MUST produce `duration`
- `duration / number` MUST produce `duration`
- `duration / duration` MUST produce `number`
- `datetime` and `duration` values MAY be compared with values of the same type
- Mixed-type datetime/duration comparisons MUST return `false`

Examples:

```yaml
allowed_when: "time.now() - session_start < time.duration('30m')"
allowed_when: "document_expires_at - time.duration('7d') > time.now()"
allowed_when: "time.duration('2h') > time.duration('30m')"
```

### 3.4a Enums

`enum` is a closed string domain with declaration-order ranking. The
type is **declared on a session variable** (Specification §10.1) via:

```yaml
- name: data_sensitivity
  type: enum
  members: [public, internal, confidential, restricted]   # low → high
```

`enum` values are stored as strings, and equality (`==`, `!=`) and `in`
operate on the underlying string value. The value of each operation differs
from a plain `string` only on the relational operators `<`, `<=`, `>`, `>=`,
and on the `max()` / `min()` reducers and binary forms (§5.3):

- Relational operators on two `enum` values from the same domain
  (i.e., declared with the same `members:` list, member-for-member, in the
  same order) MUST compare by **member index**, not by lexicographic order.
- A bare `string` literal that is a member of an `enum` variable's
  `members:` list MUST be coerced to that domain when compared against the
  variable; the comparison is then by member index.
- A bare `string` literal that is **not** a member, or a comparison between
  two `enum` values whose `members:` lists differ, MUST evaluate to
  `null` (and folds to `false` in boolean contexts).

Writes that would store a value outside the variable's `members:` list MUST
be rejected as type-incompatible (Specification §10.2). `type_name(x)` on an
`enum` value MUST return `"enum"`. `is_enum(x)` (§5.2)
returns `true` only for values stored under an `enum`-typed variable.

Examples:

```yaml
# Member-index ordering, NOT lexicographic
allowed_when: "data_sensitivity >= 'confidential'"

# Cross-domain comparison fails closed
# (data_sensitivity members differ from clearance_level members)
allowed_when: "data_sensitivity <= clearance_level"

# Non-member literals fail closed
# 'top_secret' is not in members → comparison evaluates to null → gate denied
allowed_when: "data_sensitivity < 'top_secret'"
```

### 3.5 Cross-type behavior

Cross-type comparisons MUST return `false`, not an error.

```text
5 == '5'     -> false
5 < '10'     -> false
null < 10    -> false
```

Arithmetic with `null` MUST return `null`.

```text
null + 5     -> null
"hello" + 5 -> null
```

### 3.6 Boolean coercion

The language uses truthy/falsy coercion in boolean contexts (e.g., operands of `and`, `or`, `not`, and the condition of a ternary).

The following values MUST be treated as falsy:

- `null`
- `false`
- `0`
- `""`
- `[]`
- `{}`

All other values MUST be treated as truthy within intermediate expression evaluation.

**Guardrail predicate boundary rule**: At the top-level evaluation of a guardrail predicate (`allowed_when:`, `active_if:`, `evaluate_when[].expression:`), the final result MUST be of type `boolean` or `null`. Any other type (including non-empty strings, non-zero numbers, non-empty arrays, or objects) MUST be treated as `false` (fail-closed). This prevents bare non-boolean expressions — such as a string literal — from accidentally granting access.

Examples:

```text
not []       -> true
0 or 5       -> true  (intermediate: 5 is truthy)
'' and true  -> false
```

Guardrail predicate boundary examples:

```text
# These evaluate to boolean — behave as expected
allowed_when: "role == 'admin'"          -> true or false
allowed_when: "is_null(field)"           -> true or false

# These produce non-boolean final values — fail closed to false
allowed_when: "'I can do this'"          -> false  (string, not boolean)
allowed_when: "42"                       -> false  (number, not boolean)
allowed_when: "is_null(x) ? 'yes' : 'no'" -> false (string result, not boolean)
```

## 4. Evaluation Semantics

### 4.1 Evaluation order

Evaluation MUST proceed left-to-right unless a construct explicitly short-circuits.

### 4.2 Short-circuiting

Implementations MUST short-circuit:

- `and` / `&&` / `;` when the left operand is falsy
- `or` / `||` when the left operand is truthy
- ternary by evaluating only the selected branch

This rule is mandatory because short-circuiting is part of the security model and observable behavior.

Examples:

```text
false and (1 / 0 > 0)   -> false
true or regex.match('(', value) -> true
is_null(x) ? 0 : x / y  -> 0 when x is null
```

### 4.3 Null and failure behavior

Rules (**MUST**):

- Missing variables MUST evaluate to `null`.
- `null` MUST be falsy.
- Arithmetic with `null` MUST return `null`.
- Invalid regular expressions MUST return `false`.
- Cross-type comparison MUST return `false`.
- Evaluation failures MUST resolve to `null` or `false`; implementations MUST NOT raise runtime errors to callers.

> **Note on variable status.** A variable's value-coerced view is `null` for both `@status == 'unset'` (no value ever recorded) and `@status == 'resolved'` with a stored `null` value. The two cases are distinguishable only via the metadata namespace (`@status`) or the status sugar functions (`defined()`, `unset()`, `denied()`, `present()`) — see §4.7 and §5.9. The boolean coercion of the value alone does not preserve that distinction; expressions that need to discriminate MUST use the metadata namespace.

### 4.4 Equality and inequality

`==` follows standard equality rules. `!=` uses **null-safe** semantics for fail-closed security.

Rules (**MUST**):

- `null == null` → `true`
- `null == X` (where X is non-null) → `false`
- `null != null` → `false`
- `null != X` (where X is non-null) → `false` (null-safe: missing data never satisfies `!=`)
- `X != null` (where X is non-null) → `false` (null-safe: use `not is_null(X)` to test for non-null)
- For two non-null values, `!=` MUST be the logical negation of `==`

This is a **CHANGE** from the prior behavior where `!=` was unconditionally the logical negation of `==`. The prior behavior caused `null != 'restricted'` to evaluate to `true`, which accidentally allowed access when variables were missing. The new behavior aligns with Rego's undefined-fails-the-rule semantics: missing data MUST NOT satisfy any comparison.

**Migration note**: expressions like `x != 'restricted'` are now safe without a preceding `not is_null(x)` guard. Use `not is_null(x)` when you specifically need to test that a variable is present.

```text
null == null -> true
null == 5    -> false
null != null -> false
null != 5    -> false
5 != null    -> false
5 == '5'     -> false
5 != 3       -> true
'a' != 'b'   -> true
'a' != 'a'   -> false
```

### 4.5 Datetime accessors

Implementations MUST support the following datetime accessors:

| Accessor | Result |
| --- | --- |
| `.year` | four-digit year |
| `.month` | `1..12` |
| `.day` | `1..31` |
| `.hour` | `0..23` |
| `.minute` | `0..59` |
| `.second` | `0..59` |
| `.weekday` | `Monday`..`Sunday` |

Examples:

```yaml
active_if: "time.now().weekday in ['Saturday', 'Sunday']"
active_if: "time.now().hour < 8 or time.now().hour > 18"
allowed_when: "account.created_at.year < time.now().year"
```

### 4.6 Identifier kinds and runtime namespaces

Every identifier in an expression is either **bare** (no leading sigil, no namespace prefix) or **`@`-prefixed**. The two surfaces are syntactically distinct and resolve to different sources.

#### 4.6.1 Bare identifiers

Bare identifiers are author-declared names. They resolve, in order, to:

1. **Local binding** created with `:=` in the current expression.
2. **Quantifier variable** bound by `->` in the current `all()` / `any()` / `count_where()` scope (§5.8).
3. **Session variable** declared in the top-level `variables:` block (Specification §10).
4. **Predicate** declared in the top-level `predicates:` block (Specification §8).
5. **Not found** — evaluates to `null` (fail-closed).

A bare-identifier read of a session variable returns the variable's stored **value** (not its metadata envelope). To read a value while the variable is `@status == 'unset'` and a resolver is declared, see §11.

#### 4.6.2 `@`-prefixed identifiers (runtime namespaces)

Identifiers prefixed with `@` are **runtime-bound**: their values are supplied per call by the runtime and are read-only. The `@` sigil prevents collision with author-declared bare names — implementations MUST NOT enter `@`-prefixed identifiers into the bare-identifier resolution chain above.

Specification §7.5 defines five runtime namespaces:

| Namespace | Bound to | Available in |
| --- | --- | --- |
| `@tool.*` | The proposed tool call's params + identity (Specification §7.5.1) | Contexts gating a tool resource |
| `@endpoint.*` | The proposed endpoint call's URI / method / params (Specification §7.5.2) | Contexts gating an endpoint resource |
| `@agent.*` | The proposed sub-agent call's params + identity (Specification §7.5.3) | Contexts gating a sub-agent resource |
| `@context.*` | The host-supplied Request Context (Specification §7.5.4) | Every expression context |
| `@result.*` | The parsed result of a completed call (Specification §7.5.5) | Only inside `populated_by[].expression:` with `phase: after` |

Two `@`-prefixed **merge locals** are bound only inside `update:` expressions (Specification §10.2):

| Local | Value |
| --- | --- |
| `@current` | The variable's currently stored value at the moment of the write. |
| `@incoming` | The candidate value the writer (populator, resolver, runtime API) wants to write. |

The runtime-supplied event predicate is also `@`-prefixed:

| Form | Result |
| --- | --- |
| `@event.fired(<event_id>)` | `true` if the named event from the closed namespace (Specification §9.3) has been emitted in the current session; `false` otherwise. |

Rules (**MUST**):

- `@`-prefixed identifiers MUST be read-only. Assignment via `:=` (e.g., `@tool.params := ...`, `@current := ...`) MUST be a parse error.
- Resolvers MUST NOT return `@`-prefixed names in `set_variables` (Specification §11.3).
- A read of an `@`-prefixed namespace not bound for the current evaluation context (e.g., `@result.*` inside `allowed_when:`) MUST be a build-time error per Specification §7.5.6.
- A read of an in-scope `@`-namespace whose underlying field is missing MUST return `null` and MUST NOT raise an evaluation error. Standard fail-closed semantics from §4.3 then apply.
- `@`-prefixed namespaces MUST NOT trigger resolver auto-resolution (Specification §11.5). Auto-resolution fires only on bare-identifier reads of session variables.
- `@event.fired()` MUST always return a boolean (never `null`); identifiers that fail closed-namespace validation (Specification §9.3) MUST be a build-time error.

Rules (**SHOULD**):

- Implementations SHOULD log a structured warning at severity `low` when an `@result.*` field reference resolves to `null` because the JSON path is missing. This helps authors detect tool-output drift without changing fail-closed semantics.

Examples:

```yaml
# @tool.* + author-declared session variables in the same expression
allowed_when: "@tool.params.amount < daily_limit and not denied(transfer_authorized)"

# @result.* inside a populator (phase: after — the default)
populated_by:
  - kind: tool
    name: read_account
    expression: "@result.account.classification"

# @current / @incoming inside update: (Specification §10.2)
variables:
  - name: data_sensitivity
    type: enum
    members: [public, internal, confidential, restricted]
    default: public
    update: "max(@current, @incoming)"

# @event.fired() observable from any expression context
active_if: "@event.fired('tool.read_sensitive_document.success')"

# @context.* read by any expression
allowed_when: "@context.user_id in admin_users"
```

### 4.7 Variable metadata namespace (`<name>.@`)

Every declared session variable carries lifecycle metadata in addition to its stored value (see Specification §10.3.2). Expressions read this metadata through the `@`-prefixed surface **after the dot** on a variable identifier — `recipients.@status`, `kyc.@source_params`. This is distinct from the head-position `@`-namespaces of §4.6.2 (`@tool.*`, `@current`, etc.): the `@` after the dot marks the runtime-managed metadata of an author-declared variable, while a leading `@` marks an entirely runtime-bound namespace.

The `<name>.@` surface is **read-only** — `@`-fields MUST NOT appear on the left-hand side of `:=`, and resolvers MUST NOT return them in `set_variables`.

Recognized metadata fields (matching Specification §10.3.2):

| Field | Type | Meaning |
| --- | --- | --- |
| `<name>.@status` | string | One of `'unset'`, `'resolved'`, `'denied'`. Always returns one of these three strings — never `null`. |
| `<name>.@key` | any \| null | The key under which the current read or write resolved when the variable declares `key:` (Specification §10.4); `null` for non-keyed variables or when `key:` evaluated to `null` at the current site. |
| `<name>.@set_at` | datetime \| null | When the variable last entered `resolved` (`null` while `unset` or `denied`). |
| `<name>.@expires_at` | datetime \| null | When the variable will expire per `lifetime:` (`null` for `per_call` / `per_turn` / `per_session` / `per_request` / `until_event:` lifetimes, or when no `lifetime:` is declared). |
| `<name>.@source_kind` | string \| null | Writer kind that produced the current value: `'human'` / `'delegate'` / `'agent'` / `'expression'` / `'tool'` (resolver kinds), `'populator'`, or `'host_api'`. `null` only when the variable has never transitioned to `resolved` or `denied`. |
| `<name>.@set_by` | string \| null | Identifier of the resolver, populator, or tool that last set the variable. `null` for host runtime API writes that did not supply a label. |
| `<name>.@deny_kind` | string \| null | When `@status == 'denied'`, one of `'deny'` (deterministic denial) or `'cancelled'` (explicit user cancellation, Specification §11.3a). `null` while `@status != 'denied'`. |
| `<name>.@source_reason` | string \| null | Free-form audit text supplied by the writer — the resolver's `reason:`, the host's `set_variable(name, value, { reason })` argument, or an implementation-default string. `null` when no reason was supplied. |
| `<name>.@source_params` | object \| null | Snapshot of the resource-bound namespace (`@tool.params`, the merged `{path, query, body}` for endpoints, or `@agent.params`) at the writer's call site, captured at the moment the variable last transitioned to `resolved` via a populator or resolver. `null` for host runtime API writes and while `@status != 'resolved'`. |

Rules (**MUST**):

- The `<name>.@` surface MUST be available in every expression context (`allowed_when`, `active_if`, predicate bodies, resolver `context:` and `on_allow:` expressions, `populated_by[].expression:`). It is **not** scoped like `@result.*`.
- The `<name>.@` surface MUST be read-only. Any attempt to bind, mutate, or extract a metadata field via `:=` or via a resolver's `set_variables` MUST be a parse-time error.
- A `<name>.@` access on a variable that has never been declared MUST be a build-time error (the variable's declaration is the source of truth).
- A `<name>.@` access on a declared variable whose `@status == 'unset'` MUST return:
  - `'unset'` for `@status` (never `null`),
  - `null` for `@key`, `@set_at`, `@expires_at`, `@source_kind`, `@set_by`, `@deny_kind`, `@source_reason`, `@source_params`.
- `@status` MUST always return one of the three string literals — never `null`. Comparisons such as `foo.@status == 'unset'` therefore have well-defined results regardless of whether `foo` has ever been resolved.
- Unknown `@`-fields (anything not listed above) MUST be a build-time error to keep the namespace closed.
- Reading `<name>.@`-metadata MUST NOT trigger auto-resolution. The runtime auto-resolves only when an expression reads the **value** of a variable (bare identifier) whose `@status == 'unset'` and whose declaration has an `on_demand_by:` block (Specification §11.5).

Rules (**SHOULD**):

- Implementations SHOULD treat `<name>.@`-fields as a closed set; vendor-specific extensions belong in `EXTENSIONS.md` and MUST NOT collide with the names above.

Examples:

```yaml
# Audit / log routing — react to status without forcing re-resolution
log:
  message: "transfer denied by user; reason={transfer_authorized.@source_reason}"

# Distinguish user cancellation from deterministic denial
allowed_when: "transfer_authorized.@deny_kind != 'cancelled'"

# Gate on freshness
allowed_when: "transfer_authorized == true and time.now() - transfer_authorized.@set_at < time.duration('5m')"

# Distinguish "never asked" from "asked and got null"
allowed_when: "user_clearance.@status == 'resolved' and user_clearance != null"

# Defense-in-depth: prove the stored KYC was produced for THIS customer
allowed_when: "kyc.@source_params.path.customer_id == @tool.params.customer_id"
```

For most policy gates, prefer the sugar functions in §5.9 — `defined(x)`, `unset(x)`, `denied(x)`, `present(x)` — which are equivalent to common `@status` checks and read more naturally.

## 5. Standard Functions

Implementations MUST provide the following standard functions.

### 5.1 String functions

| Function | Signature | Result |
| --- | --- | --- |
| `contains(str, substr)` | `(string, string) -> boolean` | substring test |
| `startswith(str, prefix)` | `(string, string) -> boolean` | prefix test |
| `endswith(str, suffix)` | `(string, string) -> boolean` | suffix test |
| `regex.match(pattern, str)` | `(string, string) -> boolean` | regex match |
| `lower(str)` | `(string) -> string` | lowercase copy |
| `upper(str)` | `(string) -> string` | uppercase copy |

`count(str)` is defined in §5.3 (Collection functions) and also operates on strings: it returns the number of Unicode code points (not bytes). Functions that accept index arguments (`charAt`, `indexOf`, `substring`, etc.) use code-point-based indexing; see EXTENSIONS.md for their full signatures.

Rules (**MUST**):

- Wrong arity or wrong types MUST fail closed.
- `regex.match()` MUST return `false` for an invalid pattern.
- `regex.match()` MUST reject patterns longer than `500` characters by returning `false`.
- Implementations MUST use RE2-compatible (linear-time) regex semantics.

Examples:

```yaml
allowed_when: "contains(email, '@company.com')"
allowed_when: "regex.match('^\\d{3}-\\d{2}-\\d{4}$', ssn)"
```

### 5.2 Type inspection functions

| Function | Signature | Result |
| --- | --- | --- |
| `is_string(x)` | `(any) -> boolean` | value is a string |
| `is_number(x)` | `(any) -> boolean` | value is a number |
| `is_boolean(x)` | `(any) -> boolean` | value is a boolean |
| `is_null(x)` | `(any) -> boolean` | value is null or missing |
| `is_array(x)` | `(any) -> boolean` | value is an array |
| `is_object(x)` | `(any) -> boolean` | value is an object |
| `is_datetime(x)` | `(any) -> boolean` | value is a datetime |
| `is_duration(x)` | `(any) -> boolean` | value is a duration |
| `is_integer(x)` | `(any) -> boolean` | value is an integer-valued number |
| `is_enum(x)` | `(any) -> boolean` | value is stored under an `enum`-typed variable (§3.4a) |
| `type_name(x)` | `(any) -> string` | runtime type name |

Rules (**MUST**):

- Type inspection functions MUST accept values of any type, including `null`.
- `is_null(x)` MUST return `true` for both explicit `null` values and missing variables.
- `is_datetime(x)` MUST return `true` only for `datetime` values. String representations of dates MUST return `false`.
- `is_duration(x)` MUST return `true` only for `duration` values. String representations of durations MUST return `false`.
- `is_integer(x)` MUST return `true` when `x` is a `number` with no fractional part (e.g., `5.0` → `true`, `5.5` → `false`). Non-number values MUST return `false`, including `null`.
- Type inspection functions MUST NOT return `null`; they MUST always return a `boolean` (or `string` for `type_name`).

Examples:

```yaml
allowed_when: "is_number(amount) and amount < 10000"
allowed_when: "type_name(value) == 'duration'"
allowed_when: "is_datetime(session_start) and time.now() - session_start < time.duration('1h')"
allowed_when: "is_integer(retry_count) and retry_count < 5"
```

### 5.3 Collection functions

| Function | Signature | Result |
| --- | --- | --- |
| `count(collection)` | `(array|string|object) -> number` | size or length |
| `sum(array)` | `(array) -> number` | numeric sum |
| `max(array)` | `(array) -> number|null` | maximum numeric element |
| `min(array)` | `(array) -> number|null` | minimum numeric element |
| `max(a, b)` | `(comparable, comparable) -> any|null` | binary maximum |
| `min(a, b)` | `(comparable, comparable) -> any|null` | binary minimum |
| `union(a, b)` | `(array, array) -> array` | set-union, deduplicated, order-preserving |

Rules (**MUST**):

- `count()` on a `string` MUST return the number of Unicode code points (not bytes).
- `count()` on a non-collection or `null` argument MUST return `null`.
- `sum()`, `max()`, and `min()` on a non-array or `null` argument MUST return `null`.
- `sum()` of non-numeric array elements MUST return `null`.
- `max()` and `min()` of an empty array MUST return `null`.
- The binary forms `max(a, b)` and `min(a, b)` MUST accept any two values of comparable type:
  - Two `number` values are compared numerically.
  - Two `datetime` values are compared chronologically.
  - Two `duration` values are compared by total length.
  - Two `enum` values from the same domain are compared by member index (§3.4a).
  - Two `string` values are compared lexicographically by Unicode code point.
  - Cross-type comparisons (including two `enum` values from different domains, or an `enum` value paired with a non-member `string` literal) MUST return `null` (§3.4a, §3.5).
- `union(a, b)` MUST return the set-union of two arrays: every element of `a` followed by every element of `b` that is not equal (per §3.5 equality) to a previously included element. Element order MUST be stable (`a`-order first, then new-from-`b`-order).
- `union(a, b)` MUST treat a `null` argument as the empty array `[]` (so `union(null, [1,2])` is `[1,2]` and `union([1], null)` is `[1]`).
- `union(a, b)` on a non-array, non-null argument MUST return `null`.

Examples:

```yaml
allowed_when: "count(data_jurisdictions) <= 3"
allowed_when: "sum(costs) < budget_limit"
allowed_when: "max(current_score, incoming_score) >= 80"
allowed_when: "count(union(approved_regions, requested_regions)) <= 5"
```

### 5.4 Object functions

| Function | Signature | Result |
| --- | --- | --- |
| `object.get(obj, key, default)` | `(object, string, any) -> any` | member value or default |
| `object.keys(obj)` | `(object) -> array` | object keys |
| `object.values(obj)` | `(object) -> array` | object values |
| `object.entries(obj)` | `(object) -> array` | array of `{"key": k, "value": v}` objects |
| `object.merge_patch(a, b)` | `(object, object) -> object` | RFC 7396 deep merge of `b` into `a` |
| `has(obj, key)` | `(object, string) -> boolean` | key exists, even if null-valued |

Rules (**MUST**):

- `object.get()` MUST return `default` when the key is missing or the stored value is `null`.
- `has()` MUST return `true` when the key exists, even if its value is `null`.
- `has()` is the canonical field-existence test.
- `has()` on a non-object receiver MUST return `false`.
- `object.keys()` on a non-object or `null` argument MUST return `null`.
- `object.values()` MUST return values in the same order as `object.keys()`. On a non-object or `null` argument it MUST return `null`.
- `object.entries()` MUST return an array of objects, each with exactly two keys: `"key"` (the property name as a string) and `"value"` (the property value). Entries MUST be in the same order as `object.keys()`. On a non-object or `null` argument it MUST return `null`.
- `object.merge_patch(a, b)` MUST implement [RFC 7396 JSON Merge Patch](https://www.rfc-editor.org/rfc/rfc7396) semantics: the result is `a` with every key in `b` applied as follows — if `b[k]` is `null`, the key `k` is removed from the result; if both `a[k]` and `b[k]` are objects, they are merged recursively; otherwise `b[k]` replaces `a[k]`.
- `object.merge_patch()` MUST return `null` when either argument is not an object.
- `object.merge_patch()` is non-mutating; both inputs MUST remain unchanged.

Examples:

```yaml
allowed_when: "has(account, 'fraud_score')"
allowed_when: "object.get(account, 'fraud_score', 0) < 75"
allowed_when: "any(object.entries(role_assignments), e -> e.key in team_members and e.value == 'admin')"
allowed_when: "all(object.entries(config), e -> not is_null(e.value))"
```

### 5.5 Time functions

| Function | Signature | Result |
| --- | --- | --- |
| `time.now()` | `() -> datetime` | current UTC datetime |
| `time.duration(str)` | `(string) -> duration` | parsed duration |
| `time.clock(datetime)` | `(datetime) -> array` | `[hour, minute, second]` |

Rules:

- `time.duration()` MUST accept `s`, `m`, `h`, and `d` unit suffixes.
- `time.now()` SHOULD be injectable for testing.
- The weekday of a datetime is accessed via the `.weekday` accessor (see §4.5), not a standalone function.

Examples:

```yaml
allowed_when: "time.now() - session_start < time.duration('30m')"
active_if: "time.now().weekday in ['Saturday', 'Sunday']"
```

### 5.6 Math functions

| Function | Signature | Result |
| --- | --- | --- |
| `abs(x)` | `(number) -> number` | absolute value |
| `round(x)` | `(number) -> number` | nearest integer |
| `ceil(x)` | `(number) -> number` | ceiling |
| `floor(x)` | `(number) -> number` | floor |

Rules (**MUST**):

- Math functions MUST return `null` when the argument is not a `number`.
- Math functions MUST return `null` when the argument is `null`.
- Math functions MUST NOT raise runtime errors.

### 5.7 Conversion functions

| Function | Signature | Result |
| --- | --- | --- |
| `integer(x)` | `(any) -> number|null` | integer-valued number |
| `number(x)` | `(any) -> number|null` | numeric value |
| `string(x)` | `(any) -> string|null` | string form |
| `boolean(x)` | `(any) -> boolean|null` | boolean form |

Rules (**MUST**):

- Conversions MUST return `null` on failure.
- Conversions MUST NOT raise runtime errors.
- This differs from CEL, which commonly raises conversion errors.

#### Conversion rules by input type

`integer(x)` (**MUST**):

| Input | Result |
| --- | --- |
| `number` (integer-valued) | the same value |
| `number` (fractional) | truncated toward zero (e.g. `integer(3.9)` → `3`, `integer(-2.1)` → `-2`) |
| `string` (decimal integer) | parsed value (e.g. `integer("42")` → `42`) |
| `string` (decimal float) | `null` — use `integer(number(s))` for explicit truncation |
| `string` (other) | `null` |
| `boolean` | `true` → `1`, `false` → `0` |
| `null` | `null` |
| other types | `null` |

`number(x)` (**MUST**):

| Input | Result |
| --- | --- |
| `number` | the same value |
| `string` (numeric) | parsed value (e.g. `number("3.14")` → `3.14`, `number("42")` → `42.0`) |
| `string` (other) | `null` |
| `boolean` | `true` → `1.0`, `false` → `0.0` |
| `null` | `null` |
| other types | `null` |

`string(x)` (**MUST**):

| Input | Result |
| --- | --- |
| `string` | the same value |
| `number` | decimal representation (e.g. `string(42)` → `"42"`, `string(3.14)` → `"3.14"`) |
| `boolean` | `"true"` or `"false"` |
| `null` | `null` — NOT the string `"null"` |
| `array` | `null` |
| `object` | `null` |
| `datetime` | ISO 8601 UTC representation (e.g. `"2025-01-15T09:30:00Z"`) |
| `duration` | duration string (e.g. `"30m"`, `"2h"`) |

`boolean(x)` (**MUST**):

| Input | Result |
| --- | --- |
| `boolean` | the same value |
| `string` `"true"` | `true` |
| `string` `"false"` | `false` |
| `string` (other) | `null` — NOT truthiness coercion |
| `number` | `null` — use truthiness coercion in boolean context instead |
| `null` | `null` |
| other types | `null` |

`boolean()` is a strict parse, not a truthiness coercion. Policy authors who want truthiness semantics SHOULD use the value directly in a boolean context (e.g., `value and ...`) rather than `boolean(value)`.

Examples:

```yaml
allowed_when: "integer(object.get(headers, 'x-retry-count', '0')) < 3"
allowed_when: "boolean(emergency_override)"
allowed_when: "number(object.get(result, 'score', '0')) > 0.95"
allowed_when: "string(status_code) == '200'"
```

### 5.8 Quantifier macros

Quantifier macros evaluate a predicate expression against each element of a collection. They use function-call syntax with an arrow (`->`) binding:

| Macro | Syntax | Result |
| --- | --- | --- |
| `all(collection, var -> predicate)` | `(array, ident -> expr) -> boolean` | `true` if `predicate` is `true` for **every** element |
| `any(collection, var -> predicate)` | `(array, ident -> expr) -> boolean` | `true` if `predicate` is `true` for **at least one** element |
| `count_where(collection, var -> predicate)` | `(array, ident -> expr) -> number` | count of elements where `predicate` is `true` |

The `var -> predicate` form is a **binding expression**: the identifier before `->` declares a scoped variable name that binds to each element during iteration; the expression after `->` is the predicate. The predicate MAY reference the bound variable, all session variables, and any other expression language feature (dot-access, function calls, operators, local bindings).

Rules (**MUST**):

- `all()` on an empty array MUST return `true` (vacuous truth).
- `any()` on an empty array MUST return `false`.
- `count_where()` on an empty array MUST return `0`.
- `all()` on a `null` collection MUST return `false` (fail-closed).
- `any()` on a `null` collection MUST return `false` (fail-closed).
- `count_where()` on a `null` collection MUST return `null` (fail-closed).
- `all()` on a non-array, non-null argument MUST return `false`.
- `any()` on a non-array, non-null argument MUST return `false`.
- `all()` MUST short-circuit: stop iteration on the first `false` predicate result.
- `any()` MUST short-circuit: stop iteration on the first `true` predicate result.
- The bound variable MUST be scoped to the predicate expression only. It MUST NOT leak into the enclosing expression scope or into session variables.
- If the bound variable name shadows an existing variable or local binding, the bound variable takes precedence within the predicate (innermost scope wins).
- The predicate expression is evaluated using standard truthiness coercion (§3.6). A predicate that evaluates to `null` is treated as `false`.
- Quantifier macros MUST be subject to the same evaluation step counter and timeout limits as other expressions (§6).
- Implementations MUST limit the collection size to the list literal element limit (§6, currently 1024). Collections exceeding this limit MUST cause `all()` / `any()` / `count_where()` to return `false` (fail-closed) rather than raising an error.

**Parsing:** `all`, `any`, and `count_where` are recognized as macro invocations when followed by `(`. They are NOT reserved keywords — a variable named `all`, `any`, or `count_where` is valid and is resolved by context (variable lookup vs. function call). The `->` token inside the macro is the binding operator; it MUST NOT be used outside of quantifier macro invocations.

Examples:

```yaml
# All channel members are Microsoft employees
allowed_when: "all(channel.member_emails, e -> endswith(e, '@microsoft.com'))"

# Any member is external
allowed_when: "any(channel.members, m -> not endswith(m.email, '@microsoft.com'))"

# All jurisdictions are in the allowed set
allowed_when: "all(document.jurisdictions, j -> j in ['US', 'CA', 'UK'])"

# Combined predicate: all members are verified AND have internal email
allowed_when: "all(channel.members, m -> m.verified == true and endswith(m.email, '@microsoft.com'))"

# Nested dot-access on object array elements
allowed_when: "any(approvals, a -> a.level == 'executive' and a.granted == true)"

# Count high-value transactions — block if more than 3
allowed_when: "count_where(transactions, t -> t.amount > 10000) <= 3"

# Count admin permissions using object.entries
allowed_when: "count_where(object.entries(permissions), e -> e.value == 'admin') == 1"

# Vacuous truth: no jurisdictions means no EU restriction triggered
allowed_when: "all(data_jurisdictions, j -> j != 'EU')"
```

### 5.9 Variable status functions

These four sugar functions read the variable status metadata defined in §4.7 (`<name>.@status`) and return a boolean. They take a **bare variable identifier** as their single argument and MUST NOT be used with arbitrary expressions.

| Function | Signature | Result |
| --- | --- | --- |
| `defined(x)` | `(variable) -> boolean` | `true` iff `x.@status == 'resolved'` (regardless of stored value, including `null`). |
| `unset(x)` | `(variable) -> boolean` | `true` iff `x.@status == 'unset'`. Equivalent to `not defined(x) and not denied(x)`. |
| `denied(x)` | `(variable) -> boolean` | `true` iff `x.@status == 'denied'`. |
| `present(x)` | `(variable) -> boolean` | `true` iff `x.@status == 'resolved'` **and** the stored value is not `null`. Equivalent to `defined(x) and x != null`. |

Rules (**MUST**):

- The argument MUST be a bare variable identifier (e.g., `defined(user_clearance)`). Implementations MUST raise a build-time error for arbitrary expressions (e.g., `defined(user_clearance and other)`) and for any `@`-prefixed runtime identifier (e.g., `defined(@tool.params.foo)`, `defined(@result.x)`, `defined(@current)`).
- The argument MUST be the name of a variable declared under the top-level `variables:` block (Specification §10). Predicate names, local bindings (`:=`), quantifier-bound names (`->`), and any `@`-prefixed runtime identifier (§4.6.2) MUST be rejected at build time.
- These functions MUST NOT trigger auto-resolution. They are pure metadata reads — calling `defined(foo)` on a variable with `@status == 'unset'` and a declared `on_demand_by:` MUST NOT invoke the resolver.
- These functions MUST always return a boolean — never `null`, even when the variable has never been written.

Rules (**SHOULD**):

- Authors SHOULD prefer these sugar functions over raw `@status` comparisons in `allowed_when` and `active_if` for readability. The raw form remains available when the policy needs to check multiple metadata fields together.

Examples:

```yaml
# Block until the user has explicitly approved the transfer
allowed_when: "defined(transfer_authorized) and transfer_authorized == true"

# Trigger a resolver only the first time; allow once denied is sticky
allowed_when: "not denied(account_takeover_risk) and account_takeover_risk == 'low'"

# Force a fresh mail_resolve_recipients call after each successful send
# (in combination with `reset_by:` on resolved_recipients targeting mail_send phase: after)
allowed_when: "present(resolved_recipients)"

# Distinguish "user said null is fine" from "user has not been asked"
allowed_when: "defined(user_email) or user_role == 'guest'"
```

## 6. Limits

Implementations MUST support at least the following limits:

| Limit | Minimum required support |
| --- | --- |
| Expression length | 4096 characters |
| Nesting depth | 32 |
| List literal elements | 1024 |
| Function arguments | 16 |
| Local bindings | 16 |
| Evaluation step counter | 10,000 |
| Evaluation timeout | 100 ms |

Implementations MAY enforce stricter operational limits above these minimum conformance thresholds.

## 7. Predicate Name Resolution

Expressions MAY reference named predicates defined in the top-level `predicates:` section of the guardrails YAML (see Specification §8). Predicate resolution is part of bare-identifier evaluation; `@`-prefixed identifiers (§4.6.2) never enter this chain because they resolve to runtime namespaces by syntactic shape.

**Resolution order** for bare identifiers (first match wins; same as §4.6.1):

1. **Local binding** — an identifier bound by `:=` in the current expression.
2. **Quantifier variable** — an identifier bound by `->` in the current `all()`/`any()`/`count_where()` scope.
3. **Session variable** — a variable declared in the top-level `variables:` block (Specification §10).
4. **Predicate name** — a key in the top-level `predicates:` map.
5. **Not found** — evaluates to `null` (fail-closed).

When a predicate name is resolved at step 4, the runtime evaluates the predicate's expression body as a sub-expression. The result is used in place of the identifier.

Rules (**MUST**):

- Predicate bodies are evaluated in a **fresh scope** — local bindings from the calling expression are NOT visible inside the predicate body. Session variables and other predicates are visible.
- Predicate evaluation MUST be subject to the same step counter and timeout limits as the enclosing expression. Predicate evaluation steps count toward the caller's budget.
- Circular predicate references (A → B → A) MUST be detected at build time and rejected as a configuration error.
- The maximum predicate reference depth is 10. Exceeding this limit MUST return `false` (fail-closed).
- A predicate body that evaluates to a non-boolean value MUST be treated as `false` at the point of reference, consistent with the guardrail predicate boundary rule (§3.6).

Examples:

```yaml
predicates:
  is_privileged: "user_role == 'admin' or (user_role == 'manager' and department == 'security')"
  is_sensitive: "data_sensitivity in ['confidential', 'restricted']"

# In an expression:
allowed_when: "is_privileged and not is_sensitive"
# Equivalent to:
allowed_when: "(user_role == 'admin' or (user_role == 'manager' and department == 'security')) and not (data_sensitivity in ['confidential', 'restricted'])"
```

## 8. Excluded Features

The following features are out of scope for this language revision. Implementations MUST NOT provide them as part of the core expression language:

- timezone-aware operations beyond UTC-normalized datetime handling
- a `bytes` type
- object/map literal `{}` syntax
- string concatenation with `+`
- a `uint` type
- a static type checker
- comprehension macros beyond `all`, `any`, and `count_where` (e.g., `filter`, `map`, `exists_one`)

## 9. Grammar

The following EBNF grammar is normative. Implementations MUST accept all well-formed programs matching this grammar and MUST reject programs that do not.

`IDENT` is an unprefixed identifier (the standard `[A-Za-z_][A-Za-z0-9_]*` shape). `AT_IDENT` is an `@`-prefixed identifier, lexically `"@" IDENT`. The two are distinct tokens: a leading `@` introduces a runtime-bound identifier (§4.6.2) and a `.AT_IDENT` postfix introduces variable metadata access (§4.7).

```ebnf
Expr           = Assignment { ";" Assignment } ;
Assignment     = IDENT ":=" Ternary | Ternary ;
Ternary        = Or ["?" Ternary ":" Ternary] ;
Or             = And { ("or" | "||") And } ;
And            = Not { ("and" | "&&" | ";") Not } ;
Not            = ("not" | "!") Not | Comparison ;
Comparison     = Addition [ RelOp Addition ] ;
RelOp          = "==" | "!=" | "<" | ">" | "<=" | ">=" | "in" ;
Addition       = Multiplication { ("+" | "-") Multiplication } ;
Multiplication = UnaryMinus { ("*" | "/" | "%") UnaryMinus } ;
UnaryMinus     = "-" UnaryMinus | Postfix ;
Postfix        = Primary { "." IDENT ["(" [ExprList] ")"]
                         | "." AT_IDENT
                         | "[" Expr "]" } ;
Primary        = IDENT ["(" [ExprList] ")"]
               | AT_IDENT
               | Quantifier
               | "(" Expr ")"
               | "[" [ExprList] "]"
               | LITERAL ;
Quantifier     = ("all" | "any" | "count_where") "(" Expr "," IDENT "->" Expr ")" ;
ExprList       = Expr { "," Expr } ;
LITERAL        = NUMBER | STRING | BOOL | NULL ;
```

Grammar notes:

- `AT_IDENT` at `Primary` covers head-position runtime namespaces and merge locals: `@tool`, `@endpoint`, `@agent`, `@context`, `@result`, `@current`, `@incoming`, `@event`. Function-call form (e.g., `@event.fired(<id>)`) is parsed as `AT_IDENT` at `Primary` followed by `.IDENT "(" ... ")"` at `Postfix`.
- `"." AT_IDENT` at `Postfix` covers variable metadata access (e.g., `recipients.@status`, `kyc.@source_params`). Metadata fields are not callable; the production deliberately omits the optional `"(" [ExprList] ")"`.
- Assignment via `:=` MUST target a bare `IDENT`. Implementations MUST reject `:=` against an `AT_IDENT` (the `@`-namespace is read-only, §4.6.2 / §4.7).

## 10. Practical Guidance

### 10.1 Null-safe `!=`

The `!=` operator is null-safe: if either operand is `null`, the result is `false`. This means simple inequality checks are safe without explicit null guards:

```yaml
# Safe — blocks when data_sensitivity is null OR is 'restricted'
allowed_when: "data_sensitivity != 'restricted'"

# Also safe — null is not in the list, so `in` returns null, `not null` → false
allowed_when: "not data_sensitivity in ['confidential', 'restricted']"
```

### 10.2 When to use explicit null checks

Use `is_null()` when you need to distinguish absent data from present data, or when using operators other than `!=` where null behavior differs:

```yaml
# Null check needed: null < 75 → false (safe), but you may want to explicitly
# allow an unset value during an early pipeline phase
allowed_when: "is_null(fraud_score) or fraud_score < 75"

# Null check needed: presence matters separately from the value
allowed_when: "has(account, 'fraud_score') and object.get(account, 'fraud_score', 0) < 75"
```

### 10.3 Variable defaults

For variables with ordered sensitivity levels, declare a `default` to eliminate null entirely:

```yaml
variables:
  - name: "data_sensitivity"
    type: "enum"
    members: ["public", "internal", "confidential", "restricted"]
    default: "restricted"          # most restrictive — fail-closed by design
    update: "max(@current, @incoming)"
```

With a default, the variable is never null and expressions become maximally concise:

```yaml
allowed_when: "data_sensitivity != 'restricted'"
```

Absent data SHOULD never accidentally satisfy a sensitive predicate.

## 11. Interaction with Resolvers and Lifetimes

Specification §11 defines five resolver kinds — `tool`, `human`, `delegate`,
`expression`, `agent` — that can populate a variable's value on demand.
Specification §9 defines lifetimes that bound how long a resolved value
persists. This section describes how the expression evaluator interacts with
both.

### 11.1 Reads can trigger auto-resolution

When an expression at one of the **two gating sites** (Specification §11.5 —
`evaluate_when[].expression:` and `allowed_when:`, plus predicate bodies
referenced transitively from those sites) reads a variable whose
`@status == 'unset'`, the evaluator MUST consult the variable's declared
`on_demand_by:` (if any) before treating the read as `null`. Auto-resolution
proceeds as follows:

1. If the variable has no `on_demand_by:`, the read returns `null` (existing
   fail-closed semantics from §10.1 and §10.2 apply unchanged).
2. If the variable has an `on_demand_by:`, the resolver runs synchronously from
   the evaluator's perspective. The resolver returns a unified envelope
   `{decision, value, set_variables, reason}` (Specification §11.3).
3. The chain's final outcome (after exhausting any `fallback:` per
   Specification §11.6) determines what the expression sees:
   - `allow` → the resolved `value` is bound to the variable (subject to
     `lifetime:`) and the expression continues with that value.
   - `deny` (final) → the variable transitions to `@status == 'denied'` with
     `@deny_kind == 'deny'`; the gating expression terminates immediately
     with the resolver's `reason:` (Specification §11.5 step 4).
   - `cancelled` (final) → as for `deny`, but with `@deny_kind == 'cancelled'`
     (Specification §11.3a). Hosts MUST surface the cancellation rather than
     silently deny.

Auto-resolution MUST NOT fire on reads of `@`-prefixed runtime namespaces
(§4.6.2) or on reads through the `<name>.@` metadata surface (§4.7); it
applies only to bare-identifier reads of session variables at the two gating
sites listed above.

Resolver invocation is invisible to the expression author. From inside an
`allowed_when:` expression, a variable either has a usable value or has
terminated the gate; the evaluator decides whether running a resolver was
appropriate.

### 11.2 Memoization and per-call expiry

When a resolver returns `allow`, its `value` (and any `set_variables` entries)
are stored for the duration declared by the variable's `lifetime:`
(Specification §9, §11.8). While the stored decision is live, repeated reads
of the variable MUST NOT re-invoke the resolver — the expression evaluator
treats the stored value as if it were the variable's current value, and the
runtime MUST NOT re-apply `value:` / `set_variables:` / `on_allow:` for
subsequent reads (Specification §11.3).

To force a fresh resolver invocation on every call, declare
`lifetime: per_call` (or use the map form `lifetime: { allow: per_call, ... }`
for per-outcome control, Specification §9.1.2). The legacy `allow_once` /
`deny_once` decision values are NOT part of the v2 envelope; per-outcome
expiry is expressed exclusively through `lifetime:`.

### 11.3 Cycle detection

Because resolvers can contain `expression`-kind sources (which in turn
reference other variables that may have resolvers), there is a risk of
cycles such as `attr_a.source → expression referencing attr_b → resolver →
expression referencing attr_a`. Implementations MUST detect cycles at load
time and reject the configuration; runtime cycle handling is a defense in
depth — a repeat visit during a single evaluation MUST yield `null` for that
read (NOT loop). Cycle breaking is logged as a structured event
(Specification §11.5).

### 11.4 Determinism within a single evaluation

Within the evaluation of a single `allowed_when:` / `active_if:` /
`evaluate_when[].expression:` expression, each variable MUST resolve at most
once. Subsequent reads of the same variable within the same expression MUST
observe the value chosen by the first read. This guarantees that boolean
short-circuit and ternary evaluation produce stable results.

### 11.5 Side-effect ordering for `set_variables`

When a resolver returns a non-empty `set_variables` map, those writes apply
AFTER the current expression finishes evaluating. The triggering expression
sees the resolver's primary `value` (bound to the requested variable) but
DOES NOT see the side-effect variable updates. This prevents an expression
from producing inconsistent intermediate state.

Subsequent expressions in the same gate (e.g., a later `evaluate_when[]`
entry on the same call) DO observe the side-effect updates.

### 11.6 Expression-kind resolvers

Resolvers with `kind: expression` are evaluated using the same grammar
described in this document. They MUST be:

- Pure (no I/O, no `time.now()` inside cached resolvers — see §11.2).
- Deterministic given their variable inputs.
- Fail-closed (a `null` or `false` result becomes `decision: deny` with no
  value, not `decision: allow` with `value: null` — Specification §11.10.1).

The cached value of an `expression`-kind resolver is invalidated according
to the variable's `lifetime:`, just like any other resolver kind.