# Expression Language Extension Functions

## 1. Overview

This document defines the extension function set for the Agent Shield expression language. These functions complement the core language defined in `spec/expressions/LANGUAGE.md`.

Extension functions are **deployment-opt-in**: a deployment **MAY** choose whether to expose them to authored policies. However, all conforming implementations **MUST** implement this extension set so deployments can enable it consistently across SDKs and runtimes.

Unless otherwise stated, extension functions follow the shared core semantics from `spec/expressions/LANGUAGE.md`:

- Function-call syntax **MUST** be used. Receiver-style syntax is not part of this specification.
- The core type system and truthiness rules from `LANGUAGE.md` §3 **MUST** apply unchanged.
- Null propagation **MUST** apply: if any required input argument is `null`, the function result **MUST** be `null`.
- Invalid input types **MUST** produce `null` rather than raising an error.
- Implementations **SHOULD** apply the same fail-closed behavior across interpreters, compilers, and policy tooling.

### 1.1 Common null-propagation examples

```rego
trim(null)                      // => null
split(null, ",")               // => null
sort(null)                      // => null
regex.extract("[0-9]+", null)  // => null
```

---

## 2. String Extensions

String extensions operate on string values and **MUST** use the signatures in this section.

### 2.1 String extension functions

| Function | Signature | Description | Examples |
|---|---|---|---|
| `charAt(s, i)` | `(string, number) -> string` | Returns the character at index `i`. Out-of-bounds indexes **MUST** return `null`. | `charAt("abc", 1) => "b"`<br>`charAt("abc", 9) => null`<br>`charAt(null, 0) => null` |
| `indexOf(s, sub)` | `(string, string) -> number` | Returns the first index of `sub` in `s`. If not found, implementations **MUST** return `-1`. | `indexOf("banana", "na") => 2`<br>`indexOf("banana", "zz") => -1`<br>`indexOf(null, "a") => null` |
| `lastIndexOf(s, sub)` | `(string, string) -> number` | Returns the last index of `sub` in `s`. If not found, implementations **MUST** return `-1`. | `lastIndexOf("banana", "na") => 4`<br>`lastIndexOf("banana", "zz") => -1`<br>`lastIndexOf(null, "a") => null` |
| `join(arr, sep)` | `(array, string) -> string` | Joins array elements using `sep`. If any element is not a string, the result **MUST** be `null`. | `join(["a", "b", "c"], ":") => "a:b:c"`<br>`join(["a", 1], ":") => null`<br>`join(null, ":") => null` |
| `split(s, sep)` | `(string, string) -> array` | Splits `s` using `sep`. | `split("a,b,c", ",") => ["a", "b", "c"]`<br>`split("abc", "|") => ["abc"]`<br>`split(null, ",") => null` |
| `substring(s, start, end)` | `(string, number, number) -> string` | Returns the substring from `start` to `end` (exclusive). Out-of-bounds indexes **MUST** be clamped to the string bounds. | `substring("agent", 1, 4) => "gen"`<br>`substring("agent", -5, 99) => "agent"`<br>`substring(null, 0, 1) => null` |
| `trim(s)` | `(string) -> string` | Removes leading and trailing Unicode whitespace. Implementations MUST use the Unicode whitespace definition. | `trim("  hello  ") => "hello"`<br>`trim("\tshield\n") => "shield"`<br>`trim(null) => null` |
| `replace(s, old, new)` | `(string, string, string) -> string` | Replaces all occurrences of `old` with `new`. Implementations MUST replace every non-overlapping occurrence. | `replace("a-b-a", "a", "x") => "x-b-x"`<br>`replace("agent", "z", "x") => "agent"`<br>`replace(null, "a", "b") => null` |
| `reverse_string(s)` | `(string) -> string` | Reverses the characters in `s`. The reversal MUST operate on Unicode code points. | `reverse_string("abc") => "cba"`<br>`reverse_string("") => ""`<br>`reverse_string(null) => null` |
| `quote(s)` | `(string) -> string` | Returns a quoted string literal form of `s`, including surrounding quotes and escaping of internal quotes and control characters. | `quote("hello") => "\"hello\""`<br>`quote("a\"b") => "\"a\\\"b\""`<br>`quote(null) => null` |
| `format(fmt, args)` | `(string, array) -> string` | Formats output using a printf-style format string. Precision **MUST** be capped at `100`, and the final output **MUST NOT** exceed `4096` characters. Exceeding either limit **MUST** return `null`. | `format("hello %s", ["world"]) => "hello world"`<br>`format("%0.2f", [3.14159]) => "3.14"`<br>`format(null, []) => null` |

### 2.2 Additional string requirements

- All string indexing and length operations MUST use Unicode code-point-based positions, consistent with `LANGUAGE.md` §3.3.
- Index arguments **SHOULD** be interpreted as zero-based indexes.
- `substring()` clamping **MUST NOT** permit out-of-range panics or equivalent runtime faults.
- `quote()` **SHOULD** produce an escaped representation suitable for logs, debugging, and deterministic comparisons.
- Implementations **MAY** reject unsupported or malformed `format()` directives by returning `null`.

---

## 3. List Extensions

List extensions operate on arrays and **MUST** use the signatures in this section.

### 3.1 List extension functions

| Function | Signature | Description | Examples |
|---|---|---|---|
| `sort(arr)` | `(array) -> array` | Sorts all elements. Numeric arrays **MUST** be sorted numerically; string arrays **MUST** be sorted lexicographically. Mixed-type arrays **MUST** return `null`. | `sort([3, 1, 2]) => [1, 2, 3]`<br>`sort(["b", "a"]) => ["a", "b"]`<br>`sort([1, "a"]) => null`<br>`sort(null) => null` |
| `distinct(arr)` | `(array) -> array` | Removes duplicate elements while preserving first-seen order. | `distinct([1, 2, 1, 3]) => [1, 2, 3]`<br>`distinct(["a", "a", "b"]) => ["a", "b"]`<br>`distinct(null) => null` |
| `flatten(arr)` | `(array) -> array` | Flattens nested arrays by exactly one level. Non-array elements **MUST** remain as-is. | `flatten([[1, 2], [3]]) => [1, 2, 3]`<br>`flatten([1, [2, 3], 4]) => [1, 2, 3, 4]`<br>`flatten(null) => null` |
| `slice(arr, start, end)` | `(array, number, number) -> array` | Returns the sub-array from `start` to `end` (exclusive). Out-of-bounds indexes **MUST** be clamped. | `slice([1, 2, 3, 4], 1, 3) => [2, 3]`<br>`slice([1, 2, 3], -2, 99) => [1, 2, 3]`<br>`slice(null, 0, 1) => null` |
| `reverse_list(arr)` | `(array) -> array` | Reverses array order. | `reverse_list([1, 2, 3]) => [3, 2, 1]`<br>`reverse_list([]) => []`<br>`reverse_list(null) => null` |
| `range(start, end)` | `(number, number) -> array` | Generates the integer sequence `[start, end)`. The generated result **MUST NOT** exceed `64` elements. If it would, the function **MUST** return `null`. | `range(2, 5) => [2, 3, 4]`<br>`range(4, 4) => []`<br>`range(0, 100) => null`<br>`range(null, 3) => null` |

### 3.2 Additional list requirements

- `distinct()` equality **SHOULD** follow the core equality semantics from `spec/expressions/LANGUAGE.md` §4.4.
- `flatten()` **MUST NOT** recursively flatten beyond one level.
- `range()` **MUST** generate integer values only; non-integer numeric inputs **SHOULD** return `null`.
- `slice()` clamping **MUST** prevent negative indexing from escaping the valid array bounds.

---

## 4. Regex Extensions

Regex extensions use the same pattern model as the core `regex.match()` function.

### 4.1 Regex extension functions

All regex extension functions (**MUST**):

- **MUST** use RE2-compatible semantics.
- **MUST** reject patterns longer than `500` characters by returning `null`.
- **MUST** follow the same null-propagation and invalid-input handling rules as the core language.

| Function | Signature | Description | Examples |
|---|---|---|---|
| `regex.replace(pattern, s, replacement)` | `(string, string, string) -> string` | Replaces all matches of `pattern` in `s` with `replacement`. | `regex.replace("[0-9]+", "a1b22", "#") => "a#b#"`<br>`regex.replace("x", "abc", "y") => "abc"`<br>`regex.replace("[", "abc", "x") => null`<br>`regex.replace(null, "abc", "x") => null` |
| `regex.extract(pattern, s)` | `(string, string) -> string` | Returns the first match of `pattern` in `s`. If no match exists, implementations **MUST** return `null`. | `regex.extract("[0-9]+", "id=42") => "42"`<br>`regex.extract("z+", "abc") => null`<br>`regex.extract(null, "abc") => null` |
| `regex.extract_all(pattern, s)` | `(string, string) -> array` | Returns all non-overlapping matches of `pattern` in `s`. | `regex.extract_all("[0-9]+", "a1b22c333") => ["1", "22", "333"]`<br>`regex.extract_all("z+", "abc") => []`<br>`regex.extract_all(null, "abc") => null` |

### 4.2 Additional regex requirements

- Invalid patterns **MUST** return `null`.
- Implementations **SHOULD NOT** expose regex features that are incompatible with RE2 semantics.
- `regex.extract_all()` **MUST** return matches in encounter order.

---

## 5. Data Interchange Extensions

Data interchange extensions support working with structured data that arrives as text, such as JSON payloads from tool calls, API responses, or resource content.

### 5.1 Data interchange functions

| Function | Signature | Description | Examples |
|---|---|---|---|
| `parse_json(s)` | `(string) -> any` | Parses a JSON string into a runtime value. Returns `null` on invalid JSON. | `parse_json('{"a":1}') => {"a": 1}`<br>`parse_json('[1,2,3]') => [1, 2, 3]`<br>`parse_json('"hello"') => "hello"`<br>`parse_json('42') => 42`<br>`parse_json('invalid') => null`<br>`parse_json(null) => null` |
| `to_json(x)` | `(any) -> string\|null` | Serializes a runtime value to a compact JSON string. | `to_json({"a": 1}) => '{"a":1}'`<br>`to_json([1, 2]) => '[1,2]'`<br>`to_json("hello") => '"hello"'`<br>`to_json(null) => 'null'` |

### 5.2 Data interchange requirements

- `parse_json()` input **MUST** be limited to `65536` characters. Inputs exceeding this limit **MUST** return `null`.
- `parse_json()` **MUST** reject duplicate object keys by returning `null`.
- `parse_json()` nesting depth **MUST** be limited to `32` levels. Deeper nesting **MUST** return `null`.
- `parse_json()` **MUST** map JSON types to runtime types as follows:

| JSON type | Runtime type |
|---|---|
| `string` | `string` |
| `number` | `number` |
| `boolean` | `boolean` |
| `null` | `null` |
| `array` | `array` |
| `object` | `object` |

- `to_json()` **MUST** produce deterministic output: object keys **MUST** be sorted lexicographically.
- `to_json()` output **MUST** be limited to `65536` characters. Exceeding this limit **MUST** return `null`.
- `to_json()` on `datetime` and `duration` values **MUST** serialize as JSON strings using the same format as `string()` (ISO 8601 for datetime, duration notation for duration).
- `to_json()` **MUST NOT** return `null` for any valid runtime value within limits — in contrast to `parse_json()`, which returns `null` for invalid input.

### 5.3 Data interchange examples

```rego
// Parse a JSON text response and inspect its structure
parsed := parse_json(response_text); has(parsed, 'status') and parsed.status == 'success'

// Check a JSON array result has expected element count
count(parse_json(items_json)) <= 100

// Round-trip serialization for logging or comparison
to_json(parse_json('{"a":1}')) == '{"a":1}'
```

---

## 6. URI Extensions

URI extensions support safe inspection of URIs without manual string splitting or fragile regex patterns.

### 6.1 URI extension functions

All URI extension functions **MUST** follow RFC 3986 parsing rules.

| Function | Signature | Description | Examples |
|---|---|---|---|
| `uri.scheme(s)` | `(string) -> string\|null` | Returns the URI scheme (lowercase). Returns `null` if no valid scheme is present. | `uri.scheme('https://example.com/path') => "https"`<br>`uri.scheme('file:///tmp/a.txt') => "file"`<br>`uri.scheme('not-a-uri') => null`<br>`uri.scheme(null) => null` |
| `uri.host(s)` | `(string) -> string\|null` | Returns the host component (lowercase). Returns `null` if no authority is present. | `uri.host('https://Example.COM:8080/path') => "example.com"`<br>`uri.host('file:///tmp/a.txt') => ""`<br>`uri.host(null) => null` |
| `uri.port(s)` | `(string) -> number\|null` | Returns the port number. Returns `null` if no explicit port is present. | `uri.port('https://example.com:8080/path') => 8080`<br>`uri.port('https://example.com/path') => null`<br>`uri.port(null) => null` |
| `uri.path(s)` | `(string) -> string\|null` | Returns the decoded path component. | `uri.path('https://example.com/a/b?q=1') => "/a/b"`<br>`uri.path('https://example.com/a%20b') => "/a b"`<br>`uri.path(null) => null` |
| `uri.query(s)` | `(string) -> string\|null` | Returns the raw query string (without leading `?`). Returns `null` if no query is present. | `uri.query('https://example.com/a?q=1&r=2') => "q=1&r=2"`<br>`uri.query('https://example.com/a') => null`<br>`uri.query(null) => null` |

### 6.2 URI requirements

- URI functions **MUST NOT** attempt network access or URI resolution.
- Scheme and host **MUST** be normalized to lowercase for comparison safety.
- `uri.path()` **MUST** percent-decode the path component.
- `uri.query()` **MUST NOT** percent-decode the query string (callers may use `split()` and `replace()` for further parsing).
- Input strings longer than `4096` characters **MUST** return `null`.
- Non-string inputs **MUST** return `null`.

### 6.3 URI examples

```rego
// Allow only HTTPS resource access
uri.scheme(resource_uri) == 'https'

// Restrict tool access to specific hosts
uri.host(resource_uri) in ['api.internal.com', 'storage.internal.com']

// Validate path prefix
startswith(uri.path(resource_uri), '/api/v2/')
```

---

## 7. Null Handling Extensions

### 7.1 Null handling functions

| Function | Signature | Description | Examples |
|---|---|---|---|
| `coalesce(a, b, ...)` | `(any, any, ...) -> any` | Returns the first non-`null` argument. If all arguments are `null`, returns `null`. | `coalesce(null, 'default') => "default"`<br>`coalesce(null, null, 42) => 42`<br>`coalesce('found', 'other') => "found"`<br>`coalesce(null, null) => null`<br>`coalesce(0, 99) => 0`<br>`coalesce('', 'fallback') => ""` |

### 7.2 Null handling requirements

- `coalesce()` **MUST** accept two or more arguments, up to the standard function argument limit (16).
- `coalesce()` **MUST** short-circuit: once a non-`null` argument is found, subsequent arguments **MUST NOT** be evaluated.
- `coalesce()` tests for `null` only — falsy non-null values such as `0`, `""`, `false`, `[]`, and `{}` are NOT treated as null and **MUST** be returned.
- `coalesce()` with fewer than two arguments **MUST** be a parse error.

### 7.3 Null handling examples

```rego
// Provide a default for an optional field
limit := coalesce(custom_limit, org_limit, 1000)

// Safe navigation through optional nested structures
owner := coalesce(object.get(resource, 'owner', null), 'unassigned')

// Chain defaults from multiple sources (e.g., tool result > config > hardcoded)
timeout := coalesce(tool_timeout, config_timeout, 30)
```

---

## 8. Security Considerations

Implementations **MUST** preserve the expression language's fail-closed posture when enabling extensions.

- All regex patterns **MUST** be limited to `500` characters to reduce ReDoS risk.
- `format()` precision **MUST** be capped at `100` and output length **MUST** be capped at `4096` characters to limit memory and CPU abuse.
- `range()` **MUST** be limited to `64` generated elements.
- `parse_json()` input **MUST** be limited to `65536` characters and `32` levels of nesting depth.
- `to_json()` output **MUST** be limited to `65536` characters.
- URI function inputs **MUST** be limited to `4096` characters.
- All functions **MUST** return `null` on invalid input, unsupported types, malformed patterns, or limit violations.
- Implementations **SHOULD** avoid implicit stringification in `join()` and `format()` because silent coercion can hide policy authoring errors.
- The `+` operator **MUST NOT** be used for string concatenation in this language. Policy authors **SHOULD** use `join()` where concatenation is required.

### 8.1 Security examples

```rego
format("%.5000f", [1.23])       // => null  (precision cap exceeded)
range(0, 1000)                  // => null  (result exceeds 64 elements)
regex.extract("<501-char pattern>", "aaa") // => null  (pattern too long)
join(["user:", null], "")     // => null  (null propagation)
parse_json("<65537-char input>") // => null  (input size limit exceeded)
parse_json('{"a":{"b":{"c":...}}}')  // => null  (nesting depth exceeded at 32+)
```

---

## 9. Conformance Notes

A conforming implementation:

1. **MUST** implement all extension functions defined in this document.
2. **MUST** preserve the core type system, null propagation, and fail-closed behavior defined in `spec/expressions/LANGUAGE.md`.
3. **MUST** apply the security limits defined in §8 consistently across interpreters, evaluators, and compiled execution paths.
4. **MAY** gate availability of these functions behind deployment configuration, feature flags, or policy-version controls.
5. **SHOULD** document which deployments expose the extension set so policy behavior remains predictable across environments.
