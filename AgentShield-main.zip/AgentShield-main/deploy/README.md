# Deploying Agent Shield

Agent Shield is an **in-process SDK**. The host application embeds the
language binding (`agent_shield` for Rust, `agent_shield` for Python,
`@microsoft/agent-shield` for Node, `Microsoft.AgentShield` for .NET) and
routes every governed input, tool call, tool output, and final response
through the SDK before it reaches the model, the tool, or the user.

There is no standalone "Agent Shield proxy" or sidecar process. The
runtime enforcement points are the SDK call sites in the host's agent
loop. This intentional design removes a class of bypass paths (network
hops, sidecar restarts, mesh misconfiguration) and keeps the `tool_call`
→ `tool_output` binding (spec §16.0) inside a single process boundary.

## Kubernetes reference architecture

For a production-grade Kubernetes deployment that pairs the SDK with
Istio for mesh-level mTLS, identity, and traffic controls, see:

- [`docs/istio-sdk-reference-architecture.md`](../docs/istio-sdk-reference-architecture.md)
  — narrative architecture and threat model
- [`deploy/kubernetes/istio-sdk-reference/`](kubernetes/istio-sdk-reference/)
  — kustomize manifests and a `setup-kind-istio.sh` smoke test

The reference architecture deploys the host agent with the SDK linked
in-process and uses Istio for the things Istio is good at (mTLS between
services, identity propagation, authorization policies, telemetry).
Agent Shield handles the things the SDK is good at (policy evaluation,
state tracking, approval gating, output redaction).
