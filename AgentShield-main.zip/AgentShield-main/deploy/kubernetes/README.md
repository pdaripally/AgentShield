# Agent Shield on Kubernetes

Agent Shield is an in-process SDK; there is no standalone proxy to
deploy. To run a host agent that links the Agent Shield SDK on
Kubernetes with mesh-level mTLS and identity, use the reference
architecture:

- [`istio-sdk-reference/`](istio-sdk-reference/) — kustomize manifests,
  Istio peer/destination policies, and a `setup-kind-istio.sh` smoke
  test that brings up a local `kind` cluster with Istio installed and
  runs the reference deployment end to end.

See [`docs/istio-sdk-reference-architecture.md`](../../docs/istio-sdk-reference-architecture.md)
for the narrative architecture, trust boundaries, and threat model.
