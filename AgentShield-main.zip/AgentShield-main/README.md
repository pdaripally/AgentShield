# Agent Shield

**An open specification and reference implementation for securing agentic AI systems**

[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Spec](https://img.shields.io/badge/spec-v2.0.0--alpha-blue)](spec/SPECIFICATION.md)
[![Status](https://img.shields.io/badge/status-alpha-orange)](#)

---

## 🛡️ What is Agent Shield?

Agent Shield is an open specification and reference SDK and runtime for **security controls on AI agents**. It defines guardrails as a portable, declarative YAML contract that gates every tool call, endpoint call, and sub-agent invocation an agent attempts, **enforced outside the model**. Agent Shield is a mediation layer, not a sandbox; see [`docs/security-model.md`](docs/security-model.md) for trust boundaries and integration requirements.

The same `.guardrails.yaml` file works across LangChain, AutoGen, OpenAI Agents SDK, CrewAI, Anthropic Agents SDK, and [LiteLLM Proxy](docs/integrations/litellm-proxy.md). Security teams can review one contract; developers integrate with a short framework wrapper around an `.guardrails.yaml` file (see the [SDK quick-starts](#sdk-quick-starts) below for the minimal shape per language); the runtime enforces everything automatically.

> **The model picks the action, and Agent Shield controls it. That decision is based on deterministic and probabilistic rules the model can't talk its way around.**

### The problem

AI agents read untrusted content (emails, documents, MCP tool outputs) and take real actions (send messages, move money, change configurations). Traditional defenses leave critical gaps:

| Approach | What it does | Why it fails |
|---|---|---|
| **System prompt** | "Please don't send sensitive data" | Advisory. The model decides whether to comply. |
| **Input classifiers** | Scan input for known jailbreak patterns | Probabilistic, narrow scope. |
| **Output classifiers** | Scan response for PII / toxicity | Too late — the tool already executed. |
| **Per-framework hooks** | LangChain `on_tool_start`, code filters | Custom code, locked to one framework, no portability. |

### The solution

![Agent Shield](/docs/assets/images/Agent%20shield.png)

A single `.guardrails.yaml` declares the agent's objective, forbidden behaviors, configured providers, **variables** (typed runtime state with metadata), **predicates** (named expressions), **events and lifetimes**, **resolvers** (the unified gate), **guard policies** (the unified enforcement primitive), and the resource catalog. The runtime enforces it deterministically across five validation stages. The same file is reviewed by security, version-controlled, and reused across frameworks and deployments.

---

## The model in one paragraph

Every gating decision runs through one of five **validation stages** — Input, State, Tool execution, Post-tool, Output — using the same `guard_policies[]` schema. The runtime evaluates a Rego-inspired predicate language over typed **variables**, emits **events**, and dispatches **resolvers** (`expression`, `human`, `tool`, `delegate`, `agent`) to produce allow/deny verdicts. The same contract gates MCP tools, HTTP endpoints, and sub-agents.

![Agent Shield](/docs/assets/images/5%20stages.jpg)

> For the full model — stage semantics, core building blocks, runtime intercepts, and the resolver / guard-policy contract — see [`spec/SPECIFICATION.md` §2](spec/SPECIFICATION.md#2-the-agent-shield-model).

---


## What does a policy looks like. 

Here is shortened version of an example YAML file. This policy gates outbound email based on the sensitivity of of a document. A `data_sensitivity` variable starts at public and is ratcheted up — never down — each time Get_Document_Content runs for the rest of the session. Two guards watch every sendMail call: if an internal document is in scope, the runtime pauses and asks the human to `allow_once`, `allow_always`, or `decline`; the answer's lifetime is derived from the choice. If a protected document is in scope, no prompt is shown but the rule must satisfy that at most ten recipients across To/Cc/Bcc combined, and every To recipient must be a @microsoft.com address. Anything that fails either gate is blocked and logged.

```yaml

variables:
  - name: "data_sensitivity"
    type: enum
    members: ["public", "internal", "protected"]
    default: "public"
    update: "max(@current, @incoming)"
    populated_by:
      - kind: tool
        name: "Get_Document_Content"

  # The human resolver fires on the first read while @status == 'unset'.
  - name: "internal_send_decision"
    type: enum
    members: ["allow_once", "allow_always"]
    on_demand_by:
      kind: human
      prompt: >-
        The agent wants to email an INTERNAL document via sendMail.
        Subject: ${@tool.params.subject}
        Reply with one of:
          allow_once   — permit this single send,
          allow_always — permit every internal-document send for the
                         rest of this session,
          decline      — block this send and stop asking for the rest
                         of this session.
      context:
        sensitivity: "data_sensitivity"
      on_error: block
    lifetime:
      allow: "@incoming == 'allow_always' ? 'per_session' : 'per_call'"
      deny:
        until_event:
          - session.end

state_validation:
  guard_policies:
    # ── Internal document → sendMail needs human approval. ─────────
    # The first read of `internal_send_decision` while @status ==
    # 'unset' triggers auto-resolution (§11.5) and fires the human
    # resolver. 
    - name: "internal_doc_send_gate"
      applies_to:
        tools: ["mcp_MailTools_graph_mail_sendMail"]
      active_if: "is_internal"
      evaluate_when:
        - expression: "internal_send_decision in ['allow_once', 'allow_always']"
          reason: >-
            Sending an internal document requires human approval. The
            user either declined or has not yet approved this send.
    # ── Protected document → strict recipient allowlist + count. ──
    # Recipients live in the sendMail call's parameters (§Work IQ
    # Mail MCP). 
    - name: "protected_doc_send_gate"
      applies_to:
        tools: ["mcp_MailTools_graph_mail_sendMail"]
      active_if: "is_protected"
      evaluate_when:
        - expression: >-
            count(coalesce(@tool.params.toRecipients,  []))
            + count(coalesce(@tool.params.ccRecipients,  []))
            + count(coalesce(@tool.params.bccRecipients, []))
            <= 10;
            all(coalesce(@tool.params.toRecipients,  []), r -> endswith(r.emailAddress.address, '@microsoft.com'))
      reason: >-
            Protected documents may be emailed to at most 10
            recipients in total (toRecipients + ccRecipients + bccRecipients)
            and may only be emailed to @microsoft.com
            recipients.
      log:
        severity: high|medium|low
        category: "..."
        message: "..."
```

---

## Composability

A `.guardrails.yaml` can `extends:` other files. The merger is additive and intended to never weaken a policy. A common pattern is a three-tier chain would be:

```
organization.guardrails.yaml      # CISO baseline
   └─ extends: tools.guardrails.yaml      # platform tool catalog
         └─ extends: developer.guardrails.yaml  # app-specific overrides
```

Arbitrary chains are supported. The runtime resolves the chain at load time and validates compatibility against `metadata.agent_shield_version`.

---

##  SDK quick-starts

Each SDK exposes the same per-session contract: a `RuntimeBuilder*` (load YAML, register callbacks, build), an immutable `Runtime` (mint sessions), and a `Session` (per-conversation; thread-affined). All snippets below load [`tests/fixtures/smoke/minimal.guardrails.yaml`](tests/fixtures/smoke/minimal.guardrails.yaml) and demonstrate Stages 1, 2, and 5 end-to-end.

> **Detailed walkthroughs** — see [QUICKSTART.md](QUICKSTART.md) for installation, framework adapter integration, and demo run instructions.

<details open>
<summary><b>Rust</b></summary>

```toml
# Cargo.toml — crates are consumed via git tag, not crates.io.
# Substitute the version of the release you want (e.g., v0.13.0-alpha.1).
[dependencies]
agent_shield_core = { git = "https://github.com/microsoft/AgentShield", tag = "v<version>" }
serde_json = "1"
tokio = { version = "1", features = ["rt", "macros"] }
```

```rust
use agent_shield_core::{RuntimeBuilder, RequestContext};

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let runtime = RuntimeBuilder::from_yaml(
        "tests/fixtures/smoke/minimal.guardrails.yaml",
    )?
    .build()?;

    let ctx = RequestContext::new("session-1", "corr-1");
    let session = runtime.new_session(ctx);

    session.begin_turn()?;
    let input_v = session.validate_input("hello, please echo me");
    if !input_v.allowed { eprintln!("Stage 1 blocked: {:?}", input_v.reason); }

    // Authorize via host API; in production a HumanResolver would do this.
    session.set_variable("authorized", serde_json::json!(true))?;

    let mut params = serde_json::json!({ "msg": "hi" });
    let tool_v = session.validate_tool_call("echo", &mut params);
    println!("Stage 2 allowed = {}", tool_v.allowed);

    let mut response = String::from("echoed: hi");
    let out_v = session.validate_output(&mut response);
    println!("Stage 5 allowed = {}, response = {}", out_v.allowed, response);
    session.end_turn()?;
    Ok(())
}
```

</details>

<details open>
<summary><b>Python</b></summary>

```bash
pip install agent-shield  # 0.13.x
```

```python
from agent_shield import RuntimeBuilder

runtime = (
    RuntimeBuilder.from_yaml("tests/fixtures/smoke/minimal.guardrails.yaml")
    .build()
)

with runtime.new_session(session_id="s-1", correlation_id="c-1") as session:
    session.begin_turn()

    input_verdict = session.validate_input("hello, please echo me")
    if not input_verdict:
        print("Stage 1 blocked:", input_verdict.reason)

    # Authorize via host API; in production a HumanResolver would do this.
    session.set_variable("authorized", True)

    tool_outcome = session.validate_tool_call("echo", {"msg": "hi"})
    print("Stage 2 allowed =", bool(tool_outcome))

    out = session.validate_output("echoed: hi")
    print("Stage 5 allowed =", bool(out), "response =", out.response)
```

</details>

<details open>
<summary><b>Node.js / TypeScript</b></summary>

```bash
npm install @microsoft/agent-shield   # 0.13.x — surface
```

```ts
import { RuntimeBuilder } from "@microsoft/agent-shield";

async function main() {
  const runtime = RuntimeBuilder
    .fromYaml("tests/fixtures/smoke/minimal.guardrails.yaml")
    .build();

  const session = runtime.newSession({ sessionId: "s-1", correlationId: "c-1" });
  session.beginTurn();

  const inputV = await session.validateInput("hello, please echo me");
  if (!inputV.allowed) console.log("Stage 1 blocked:", inputV.reason);

  // Authorize via host API; in production a HumanResolver would do this.
  session.setVariable("authorized", true);

  const tool = await session.validateToolCall("echo", { msg: "hi" });
  console.log("Stage 2 allowed =", tool.verdict.allowed);

  const out = await session.validateOutput("echoed: hi");
  console.log("Stage 5 allowed =", out.verdict.allowed, "response =", out.response);

  session.endTurn();
}

main().catch(console.error);
```

</details>

<details open>
<summary><b>.NET</b></summary>

```bash
dotnet add package AgentShield
```

```csharp
using System.Text.Json;
using AgentShield;

using var runtime = RuntimeBuilder
    .FromYaml("tests/fixtures/smoke/minimal.guardrails.yaml")
    .Build();

using var session = runtime.NewSession(new RequestContext("session-1", "corr-1"));
session.BeginTurn();

var inputV = session.ValidateInput("hello, please echo me");
if (!inputV.Allowed) Console.WriteLine($"Stage 1 blocked: {inputV.Reason}");

// Authorize via host API; in production an IHumanResolver would do this.
session.SetVariable("authorized", JsonDocument.Parse("true").RootElement);

var (toolV, _) = session.ValidateToolCall(
    "echo",
    JsonDocument.Parse("""{"msg":"hi"}""").RootElement);
Console.WriteLine($"Stage 2 allowed = {toolV.Allowed}");

var (outV, response) = session.ValidateOutput("echoed: hi");
Console.WriteLine($"Stage 5 allowed = {outV.Allowed}, response = {response}");
session.EndTurn();
```

</details>


---

## Frameworks and deployments

The runtime is framework-agnostic. The Python adapters wrap the runtime under a stable framework-shaped surface:

| SDKs | Frameworks (Python adapters) | Deployments |
|---|---|---|
| ✅ [Python](sdk/python/) | ✅ [LangChain](sdk/python/agent_shield/adapters/) | ✅ [Istio + SDK reference](deploy/kubernetes/istio-sdk-reference/) |
| ✅ [Node.js](sdk/node/) | ✅ [AutoGen](sdk/python/agent_shield/adapters/) | ✅ [LiteLLM Proxy](docs/integrations/litellm-proxy.md) |
| ✅ [.NET](sdk/dotnet/) | ✅ [Semantic Kernel](sdk/python/agent_shield/adapters/) | |
| ✅ [Rust](sdk/rust/) | ✅ [OpenAI Agents SDK](sdk/python/agent_shield/adapters/) | |
| | ✅ [CrewAI](sdk/python/agent_shield/adapters/) | |
| | ✅ [Anthropic Agents SDK](sdk/python/agent_shield/adapters/) | |

Agent Shield is an in-process SDK; the runtime enforcement points are the SDK call sites in the host's agent loop. For the production-grade Kubernetes deployment model that pairs the SDK with Istio for mesh-level mTLS and identity, see [docs/istio-sdk-reference-architecture.md](docs/istio-sdk-reference-architecture.md). For enforcing the same `.guardrails.yaml` at a LiteLLM Proxy boundary (zero changes to client agents), see [docs/integrations/litellm-proxy.md](docs/integrations/litellm-proxy.md).

Rust adapters live alongside the core crate (`agent_shield_anthropic`, `agent_shield_openai`, `agent_shield_langchain`, `agent_shield_rig`, `agent_shield_mcp`).

---

## Demos

End-to-end runnable demos with mock MCP servers ship in [`examples/agents/`](examples/agents/). Each demo's `demo.py` is one script with a `--framework {langchain,anthropic}` flag — same `guardrails.yaml`, same scenarios, same verdicts across both backends. Use `--scenarios all` for a scripted side-by-side guarded ↔ unguarded run.

| Demo | What it shows | README |
|---|---|---|
| **Bank Manager** | All 5 stages — VIP transfer approvals, social engineering, prompt injection in tool memos, account enumeration, composable YAML tiers | [README](examples/agents/bank-manager/README.md) |
| **Document DLP** | Sensitivity ratchets, jurisdiction tracking, graduated email policy, output PII redaction | [README](examples/agents/document-dlp/README.md) |

Reference YAML configurations (no demo code) — IFC, endpoint governance, channel governance, classifier wirings — live in [`examples/policies/`](examples/policies/). The full `examples/` map is in [`examples/README.md`](examples/README.md).

---

## Documentation

- **[QUICKSTART.md](QUICKSTART.md)** — install, integrate, run a demo in 5 minutes.
- **[docs/getting-started/init.md](docs/getting-started/init.md)** — `agent-shield init`: LLM-driven `.guardrails.yaml` designer.
- **[docs/architecture.md](docs/architecture.md)** — runtime architecture: stages, sessions, event bus, resolver runtime.
- **[docs/security-model.md](docs/security-model.md)** — security model: trust boundaries, fail-closed semantics, threat model.
- **[docs/adapter-mediated-paths.md](docs/adapter-mediated-paths.md)** — adapter coverage: mediated paths, unsupported paths, and bypass assumptions.
- **[docs/pluggable-moderation.md](docs/pluggable-moderation.md)** — bundled moderation classifier providers (AACS, Lakera, Llama Guard, OpenAI Moderation, Perspective).
- **[docs/istio-sdk-reference-architecture.md](docs/istio-sdk-reference-architecture.md)** — deploy SDK-integrated agents in Istio with ConfigMaps, mTLS, and OTel wiring.
- **[docs/integrations/litellm-proxy.md](docs/integrations/litellm-proxy.md)** — enforce a `.guardrails.yaml` at a LiteLLM Proxy boundary (stage map, threat model, streaming behaviour).
- **[spec/SPECIFICATION.md](spec/SPECIFICATION.md)** — the canonical, normative spec (v2.0.0-alpha).
- **[spec/expressions/LANGUAGE.md](spec/expressions/LANGUAGE.md)** — the Agent Shield expression language.
- **[spec/schema/guardrails.schema.json](spec/schema/guardrails.schema.json)** — JSON Schema for `.guardrails.yaml` files.
- **[CHANGELOG.md](CHANGELOG.md)** — release notes.

---

## ❓ FAQ

### How is this different from framework guardrail hooks?

Framework hooks (LangChain `on_tool_start`, SK filters, OpenAI Agents SDK guardrails) tell you *where* to put security logic. Agent Shield is a specification for *what* that logic should be. They're complementary: Agent Shield integrates through framework hooks, but the value is in a standardized, auditable, portable security model that sits above any single framework.

### How is this different from putting safety rules in the system prompt?

System prompts are advisory. Stage 2 state validation is deterministic (predicate evaluation over typed variables), and Stage 3 tool-execution validation runs in a separate context that the agent can't manipulate. No amount of prompt manipulation bypasses a `guard_policy: { action: block }`.

### What's the relationship to MCP?

MCP defines how agents talk to tools. Agent Shield defines what agents are allowed to do with those tools. The two are complementary; the `mcp_server` configuration type and the wildcard `name: "*"` resource entry make MCP-tool governance a first-class case.

---

## 📄 License

MIT — see [LICENSE](LICENSE).

## 🤝 Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). This project has adopted the [Microsoft Open Source Code of Conduct](https://opensource.microsoft.com/codeofconduct/).

## 🔒 Security

To report a security vulnerability, please see [SECURITY.md](SECURITY.md).

---

## 🙏 Acknowledgments

Inspired by:
- [Model Context Protocol (MCP)](https://modelcontextprotocol.io) — standardizing agent-tool communication.
- [Apache Iceberg](https://iceberg.apache.org) — open table-format specification as a precedent for portable, declarative contracts.
- OpenClaw security research — real-world agent vulnerabilities.

---

Built with ❤️ for safer AI agents.
