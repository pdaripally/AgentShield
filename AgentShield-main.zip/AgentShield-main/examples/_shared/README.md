# `_shared/` — cross-example demo plumbing

Owns the framework-agnostic boilerplate every agent demo would
otherwise duplicate. Importing from `_shared` lets each agent's
`demo.py` stay focused on the **Agent Shield integration code**, not
on env handling, MCP wiring, REPL plumbing, or per-framework LLM
construction.

## What `_shared/` owns

| Module | Surface | What it does |
|---|---|---|
| [`env.py`](env.py) | `getenv` / `mask` | Env-var hygiene — strip whitespace, treat empty as unset, mask credentials in logs. |
| [`mcp.py`](mcp.py) | `MCPConnection` / `mcp_result_to_str` / `mcp_banking_server_command` | Async MCP stdio context manager + tool-result coercion + the absolute-path command for the bundled banking MCP server. |
| [`llm.py`](llm.py) | `build_langchain_llm` / `build_anthropic_client` | Per-framework LLM client construction from `LLM_PROVIDER` env vars. Provider routing (OpenAI / Azure / Gemini / Ollama / Anthropic / Bedrock) lives here. |
| [`frameworks.py`](frameworks.py) | `SUPPORTED_FRAMEWORKS` / `install_adapters` / `build_llm_for` / `shield_with` / `build_agent_for` / `build_tools_for` / `AgentRunner` | The framework-dispatch shim. This is what makes `--framework {langchain,anthropic}` a CLI flag instead of a directory. |
| [`repl.py`](repl.py) | `run_repl` | Interactive REPL skeleton with `before_invoke` (Stage-1) and `on_new_session` (`/newSession`) hooks. |
| [`scenarios.py`](scenarios.py) | `Scenario` / `ScenarioCatalog` / `run_scenarios` | Side-by-side guarded ↔ unguarded scenario runner. |
| [`runner.py`](runner.py) | `parse_args` / `setup_args` | Shared CLI flags (`--framework`, `--scenarios`, `--request`, `--debug`). |

## What each agent demo owns

The integration code itself, plus the agent-specific bits:

| In each agent demo | What it owns |
|---|---|
| `demo.py` | The `Shield.from_yaml(...).build()` integration. The `--framework` dispatch, the MCP server choice, the system prompt. ~150 lines. |
| `scenarios.py` | The `ScenarioCatalog` — the concrete user prompts that drive the policy through each Agent Shield stage. |
| `mcp_server.py` (or `mcp_servers/`) | The mock tool servers the agent talks to. |
| `guardrails.yaml` (+ `extends:` chain) | The Agent Shield contract being demonstrated. |
| `prompts/` | The agent-specific LLM detector prompts. |

## How to add a new agent demo

1. Create `examples/agents/<name>/`.
2. Write `guardrails.yaml`, `prompts/`, `mcp_server.py`, `scenarios.py`.
3. Copy `examples/agents/bank-manager/demo.py` and adapt.
4. Add an entry to `examples/README.md` and `examples/agents/README.md`.

The framework-specific shape lives in `_shared/frameworks.py`. New
agent demos get LangChain + Anthropic support for free.

## How to add a new framework

1. Add the framework name to `SUPPORTED_FRAMEWORKS` in
   [`frameworks.py`](frameworks.py).
2. Implement the `build_llm_for` / `shield_with` / `build_agent_for`
   / `build_tools_for` / `_anthropic_tools_from_session`-style branch.
3. Update `install_adapters()` to preload
   `agent_shield.adapters.<framework>`.

Every agent demo picks up the new framework automatically via the
`--framework` flag.
