# Examples

A map of every example in this directory, organised by what you're
trying to do.

## Start here

If you only run one thing: **[`agents/bank-manager/`](agents/bank-manager/)**.
It demonstrates all five Agent Shield validation stages on a realistic
bank-manager support agent, with scripted scenarios that drive the
policy through both adversarial and benign user prompts. The
guarded-vs-unguarded side-by-side output shows you exactly what each
stage catches.

```bash
pip install -r examples/agents/bank-manager/requirements.txt
export OPENAI_API_KEY=sk-...
python examples/agents/bank-manager/demo.py --scenarios all
```

## Layout

```
examples/
├── README.md                          (this file)
│
├── _shared/                           cross-example demo plumbing
│   └── README.md                      what _shared owns vs what each demo owns
│
├── agents/                            ★ runnable end-to-end agent demos
│   ├── README.md
│   ├── bank-manager/                  headline 5-stage demo
│   └── document-dlp/                  data loss prevention demo
│
├── policies/                          ★ reference YAML configurations
│   ├── README.md                      catalog with explanations
│   ├── ifc-email-assistant.yaml       information-flow control pattern
│   ├── endpoint-governance.yaml       HTTP endpoint allowlist
│   ├── azure-content-safety.yaml      classifier wiring (Azure)
│   ├── lakera-guard.yaml              classifier wiring (Lakera)
│   ├── llama-guard.yaml               classifier wiring (Llama Guard)
│   ├── openai-moderation.yaml         classifier wiring (OpenAI)
│   ├── perspective-api.yaml           classifier wiring (Perspective)
│   └── channel-governance/            per-channel content policies
│
├── prompts/                           ★ shared LLM detector prompts
│   ├── README.md
│   ├── jailbreak.md
│   ├── pii_detection.md
│   ├── social_engineering.md
│   ├── sensitive_data.md
│   └── task_adherence.md
│
└── tools/                             ★ tool / MCP-server reference impls
    ├── README.md
    └── ask-human-mcp-server/          canonical agent_shield.ask_human MCP
```

## What goes where

| If you want… | Look at |
|---|---|
| A runnable demo with the integration code in plain view | [`agents/bank-manager/demo.py`](agents/bank-manager/demo.py) |
| Side-by-side guarded vs. unguarded output for a real LLM | `python agents/bank-manager/demo.py --scenarios all` |
| The same YAML running against LangChain *and* Anthropic | `--framework langchain` / `--framework anthropic` on either agent demo |
| The 3-tier composability story (CISO + MCP-dev + app-dev tiers) | [`agents/bank-manager/`](agents/bank-manager/) — `bank-base`, `bank-mcp-template`, `guardrails.yaml` |
| Information-flow control with formal proof | [`policies/ifc-email-assistant.yaml`](policies/ifc-email-assistant.yaml) + [`docs/information-flow-control-proof.md`](../docs/information-flow-control-proof.md) |
| Wiring an external classifier (Azure / Lakera / Llama Guard / OpenAI / Perspective) | [`policies/`](policies/) |
| Per-channel governance policies (Slack / Discord / WhatsApp / Signal / Telegram / iMessage / Google Chat) | [`policies/channel-governance/`](policies/channel-governance/) |
| The canonical `agent_shield.ask_human` MCP tool reference impl | [`tools/ask-human-mcp-server/`](tools/ask-human-mcp-server/) |
| The shared LLM detector prompts every agent demo uses | [`prompts/`](prompts/) |

## Conventions

* **One `demo.py` per agent**, not one per framework. The
  `--framework {langchain,anthropic}` flag dispatches through
  [`_shared/frameworks.py`](_shared/frameworks.py) so the same YAML
  enforces against both backends.
* **Reference YAMLs are flat under `policies/`** — no per-policy
  directory. Each file is independently loadable; the `README.md`
  index explains what each one teaches.
* **Shared LLM detector prompts** live at the top level under
  `prompts/`. Agent demos reference them via `prompt_path:
  "../../prompts/<name>.md"` (resolved relative to the declaring
  YAML's directory per spec §1.3).
* **Per-agent assets** (scenarios, mock MCP servers, agent-specific
  prompts) live inside the agent's directory.

## Validating any policy file

```bash
# JSON Schema validation (catches misspellings, shape errors)
python -m jsonschema -i examples/policies/<file>.yaml \
    spec/schema/guardrails.schema.json

# Full loader validation (resolves references, expressions, prompt_path:)
cargo run -p agent_shield_core --example validate -- examples/policies/<file>.yaml
```
