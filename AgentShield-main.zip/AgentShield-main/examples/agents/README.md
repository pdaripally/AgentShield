# Runnable agent demos

End-to-end Agent Shield demos with real LLMs, mock MCP tool servers,
and scripted scenarios. Each demo's `demo.py` is one script that
takes `--framework {langchain,anthropic}`, `--scenarios all` (or a
specific scenario name), `--request "<one-shot>"`, or no flag for
the interactive REPL.

| Demo | What it shows |
|---|---|
| [`bank-manager/`](bank-manager/) | All 5 validation stages on a banking agent: account lookup, transfers, admin gates, fraud detection, prompt injection in transaction memos, social engineering, account enumeration, VIP escalation. |
| [`document-dlp/`](document-dlp/) | Data Loss Prevention — sensitivity ratchets, jurisdiction tracking, graduated email policy, wildcard policies, output PII redaction. Three MCP servers (SharePoint / SQLite / email). |

## What's the same across both

The integration code. Both demos invoke:

```python
llm = build_llm_for(args.framework)
shield = (
    shield_with(args.framework, Shield.from_yaml("guardrails.yaml"))
    .with_client(llm)
    .build()
)
guarded_tools = shield.protect_tools(raw_tools)
```

That's it. Three real lines. Everything around it (MCP wiring, env
loading, REPL, scenario runner, framework dispatch) lives in
[`../_shared/`](../_shared/).

## What's different

The mock tool surface (1 banking MCP server vs. 3 document MCP
servers), the system prompt, the `guardrails.yaml` contract, and the
scenario catalog.

## Conventions

- One `demo.py` per agent.
- `--framework {langchain,anthropic}` is the runtime dispatch — no
  per-framework directories. Same YAML enforces against both backends.
- Scenarios are declared in `scenarios.py` as `Scenario` instances and
  surfaced via `--scenarios all` / `--scenarios <name>`.
- `--scenarios` mode runs both the guarded and unguarded agent on the
  same input and prints the side-by-side comparison.
