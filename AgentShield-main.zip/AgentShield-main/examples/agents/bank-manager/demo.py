#!/usr/bin/env python3
"""Bank Manager — Agent Shield headline demo.

ONE script, two frameworks, three modes. Demonstrates the
``Shield.from_yaml(...).with_<framework>().build()`` integration in
five lines, with all of the MCP / env / REPL / scenario plumbing
abstracted into ``examples/_shared/``.

Usage:

    # Interactive REPL with the guarded agent (default framework: langchain)
    python demo.py

    # Same, but driving Anthropic's Agents SDK
    python demo.py --framework anthropic

    # Run all scripted scenarios end-to-end and print the
    # guarded ↔ unguarded side-by-side
    python demo.py --scenarios all

    # Run a single scenario by name
    python demo.py --scenarios ceo_fraud_social_engineering

    # Run one ad-hoc request
    python demo.py --request "Transfer $500 from ACC-1003 to ACC-1001"

The bank's full enforcement story lives in:
    bank-base.guardrails.yaml             (CISO tier)
    bank-mcp-template.guardrails.yaml     (MCP-dev tier)
    guardrails.yaml                       (app tier; this is the leaf)

The 3-tier extends-chain demonstrates §4.2 composability.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import anyio

# Pull in the cross-example demo plumbing.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))
from _shared import (
    MCPConnection,
    build_agent_for,
    build_llm_for,
    build_native_agent_for,
    build_tools_for,
    install_adapters,
    mcp_banking_server_command,
    parse_args,
    run_repl,
    run_scenarios,
    setup_args,
    shield_with,
    wrap_guarded_for,
)

# Pull in this demo's scripted scenarios.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from scenarios import CATALOG  # noqa: E402

# Make the SDK importable without installing it.
sys.path.insert(
    0,
    str(
        Path(__file__).resolve().parent.parent.parent.parent
        / "sdk" / "python" / "src"
    ),
)
from agent_shield import Runtime, Shield  # noqa: E402


SYSTEM_PROMPT = (
    "You are a bank manager support assistant. You help bank managers with "
    "customer account inquiries, transaction research, and transfer operations. "
    "Always follow proper banking procedures: verify accounts before operations, "
    "prepare transfers before executing them, and obtain customer approval "
    "before finalizing any money movement. Never move funds without explicit "
    "customer acknowledgement. For admin operations like account freezing, "
    "you must enable admin mode first."
)

GUARDRAILS_YAML = str(Path(__file__).resolve().parent / "guardrails.yaml")


async def main() -> None:
    args = parse_args(
        description="Bank Manager — Agent Shield headline demo",
        extra_args=[
            (
                "--banking-command",
                dict(
                    default=os.getenv("BANKING_MCP_COMMAND") or "",
                    help=(
                        "Override the banking MCP server command "
                        "(default: bundled mcp_server.py via the active "
                        "interpreter, resolved by absolute path so cwd "
                        "doesn't matter)."
                    ),
                ),
            ),
        ],
    )
    setup_args(args)
    Runtime.configure_logging()
    install_adapters()

    banking_command = (args.banking_command or "").strip() or mcp_banking_server_command()
    print(f"[Config] banking MCP : {banking_command}")

    async with MCPConnection("banking", banking_command) as bank:
        if bank.session is None:
            raise RuntimeError("Failed to initialize the Banking MCP session")

        raw_tools = await build_tools_for(args.framework, bank.session)
        print(f"[Tools] loaded: {[t.name for t in raw_tools]}")

        # ── The integration code. Five real lines. ──────────────────────
        llm = build_llm_for(args.framework)
        shield = (
            shield_with(
                args.framework,
                Shield.from_yaml(GUARDRAILS_YAML, auto_bind=False),
            )
            .with_client(llm)
            .build()
        )
        guarded_tools = shield.protect_tools(raw_tools)               # Stages 2 + 3 + 4
        guarded_native = build_native_agent_for(
            args.framework, llm, guarded_tools, SYSTEM_PROMPT,
        )
        guarded_runner = shield.guard(                                # Stages 1 + 5
            guarded_native, tools=guarded_tools, system=SYSTEM_PROMPT,
        ) if args.framework == "anthropic" else shield.guard(guarded_native)
        # ────────────────────────────────────────────────────────────────

        unguarded = build_agent_for(
            args.framework, llm, raw_tools, SYSTEM_PROMPT, debug=args.debug,
        )
        guarded = wrap_guarded_for(
            args.framework, guarded_runner,
            tools=guarded_tools, system_prompt=SYSTEM_PROMPT,
        )

        if args.scenarios is not None:
            scenarios = CATALOG.select(args.scenarios)
            await run_scenarios(
                scenarios=scenarios,
                unguarded_invoke=unguarded.ainvoke,
                guarded_invoke=guarded.ainvoke,
                before_invoke=None,  # Stage 1 already enforced inside `guarded.ainvoke`
            )
            return

        await run_repl(
            invoke=guarded.ainvoke,
            before_invoke=None,  # Stage 1 already enforced inside `guarded.ainvoke`
            on_new_session=guarded.new_session,
            banner=(
                "Bank Manager Assistant ready (guarded). "
                "Type your request, /newSession, or 'quit' to exit."
            ),
            single_request=args.request,
        )


if __name__ == "__main__":
    anyio.run(main)
