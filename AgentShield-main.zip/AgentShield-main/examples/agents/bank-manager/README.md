# Bank Manager — Agent Shield headline demo

A bank-manager support agent with account lookup, transfers, admin
tools, and **all 5 Agent Shield validation stages** enforced
end-to-end. The demo ships with a mock banking MCP server (no real
bank backend required) and a catalog of scripted scenarios that drive
the policy through realistic adversarial and benign user prompts.

This is the headline demo for Agent Shield. If you only run one
example, run this one.

## Quick start

```bash
# From the repo root
pip install -r examples/agents/bank-manager/requirements.txt

# Set your LLM credentials — see examples/agents/bank-manager/.env.example
export OPENAI_API_KEY=sk-...

# Run the full guarded ↔ unguarded scenario catalog (LangChain)
python examples/agents/bank-manager/demo.py --scenarios all

# Same, but driving Anthropic's Agents SDK
python examples/agents/bank-manager/demo.py --framework anthropic --scenarios all

# Interactive REPL with the guarded agent
python examples/agents/bank-manager/demo.py
```

## What this demonstrates

| Scenario | Stages | What you see |
|---|---|---|
| `benign_account_lookup` | S1 + S3 | Vanilla read of a non-VIP account passes cleanly. The unguarded and guarded outputs match. |
| `vip_transfer_requires_approval` | S2 | VIP account transfer triggers Stage-2 escalation; unguarded executes the transfer, guarded refuses without an approval token. |
| `ceo_fraud_social_engineering` | S1 + S3 | Caller claims to be the CEO. Stage-1 social-engineering LLM and Stage-3 task-adherence reviewer both raise. |
| `prompt_injection_in_memo` | S3 | Memo carries a tool-output prompt injection. Stage-3 catches it before `create_transfer` fires. |
| `account_enumeration_probe` | S3 | Suspiciously broad sweep across multiple accounts. Stage-3 reasoning about agent objective refuses. |
| `ssn_in_input` | S1 | Stage-1 PII regex catches an SSN in the user prompt before it reaches the agent. |
| `freeze_account_requires_admin_mode` | S2 | `freeze_account` is gated by a state variable; without admin mode the Stage-2 state guard refuses. |

Each scenario surfaces the side-by-side output so you can see exactly
which stage caught what and why.

## How Agent Shield wires in

`demo.py`'s **shield-integration code is three real lines**:

```python
llm = build_llm_for(args.framework)
shield = (
    shield_with(args.framework, Shield.from_yaml("guardrails.yaml"))
    .with_client(llm)
    .build()
)
guarded_tools = shield.protect_tools(raw_tools)
```

That is the customer's diff: open `examples/agents/bank-manager/demo.py`
and look for the boxed comment block titled "The integration code."

The framework choice is a **CLI flag** (`--framework langchain` or
`--framework anthropic`), dispatched through
`examples/_shared/frameworks.py`. There is no per-framework directory.
The same `guardrails.yaml` enforces in both backends, with the same
verdicts, on the same scenarios.

Everything else (MCP wiring, env hygiene, REPL loop, scenario
runner) lives in `examples/_shared/` and is consumed verbatim.

## Composable guardrails — three tiers

The guardrails file is a 3-tier `extends:` chain. This is the
canonical demonstration of §4.2 composability — three personas with
zero coordination, all enforced together:

| File | Persona | What it owns |
|---|---|---|
| `bank-base.guardrails.yaml` | CISO | Enterprise base — jailbreak, PII, social-engineering screening; tool-execution review. |
| `bank-mcp-template.guardrails.yaml` | MCP developer | Banking-tool tier — tool definitions, state-machine, approval gates. |
| `guardrails.yaml` (leaf) | App developer | Manager-support tier — fraud detection, VIP escalation, drift detection. |

Run-time `agent_shield_core::load_chain` merges them additively
(per-stage `guard_policies[]` concat; same-name policies merge field-
by-field; `active_if:` is immutable across the chain). Read each tier
top to bottom to see how the policy assembles.

## MCP server

`mcp_server.py` is a mock banking server speaking the FastMCP
protocol. It exposes 7 tools:

| Tool | Description |
|---|---|
| `read_account` | Read account details |
| `read_transaction_history` | Get transaction history |
| `prepare_transfer` | Stage a pending transfer (computes fraud score) |
| `request_customer_approval` | Get a customer approval token |
| `create_transfer` | Execute a transfer (requires the approval token) |
| `freeze_account` | Freeze an account (requires admin mode) |
| `enable_admin_mode` | Enable a 5-minute admin window |

The bundled server is launched automatically by `demo.py` via
`examples/_shared/mcp.py`. Override with `--banking-command "..."` or
`BANKING_MCP_COMMAND=...` to point at your own MCP server.

## Logging

Set `AGENT_SHIELD_LOG_LEVEL` to control verbosity (default `INFO`):

| Level | What you see |
|---|---|
| `DEBUG` | Raw LLM responses, prompt rendering, full validation traces |
| `INFO` | Stage outcomes (allowed / blocked), tool validation results |
| `WARNING` | Fail-closed events, missing prompts, unparseable responses |
| `ERROR` | Critical failures only |

## Files

```
.
├── README.md                                 (this file)
├── .env.example                              (env-var template)
├── requirements.txt                          (Python deps)
├── demo.py                                   ★ the demo entry point
├── scenarios.py                              scripted scenarios → expected verdicts
├── mcp_server.py                             mock banking MCP server
├── bank-base.guardrails.yaml                 CISO tier
├── bank-mcp-template.guardrails.yaml         MCP-dev tier
├── guardrails.yaml                           app tier (leaf)
└── prompts/                                  bank-specific LLM detector prompts
    ├── account_takeover.md
    ├── context_poisoning.md
    ├── drift.md
    └── task_adherence.md
```

Cross-example LLM detector prompts (jailbreak, social engineering, PII,
sensitive data, generic task adherence) live at `examples/prompts/`
and are referenced from `bank-base.guardrails.yaml` via
`prompt_path: ../../prompts/<name>.md`.
