# `agent_shield.ask_human` reference MCP server

This is a **reference implementation** of the canonical
`agent_shield.ask_human` MCP tool. The Agent Shield runtime emits a
`pending_resolution` on a stage verdict (and an
`incident.resolution_needed` event on the bus) whenever a guard policy
denies because of an unset variable resolved by a `kind: human`
resolver. The verdict tells the agent which tool to call (always
`agent_shield.ask_human`), which variable is being probed, and what
prompt to surface to the human operator.

The agent's LLM is expected to call this MCP tool with the rendered
prompt. The tool collects the human's decision and returns it as a
canonical resolver-response envelope (§11.3). The host's runtime should
configure the variable's `populated_by:` to write the tool's response
into the variable. The agent then retries the original tool call — the
gate now sees the variable as `@status == 'resolved'` and lets it
through.

Per the spec author's intent (`spec/SPECIFICATION.md` §11.11), the YAML
syntax stays the same:

```yaml
on_demand_by:
  kind: human
  prompt: "Approve sending mail to ${@tool.params.to}?"
```

Customers don't touch tool wiring. The runtime synthesises the
`agent_shield.ask_human` call internally and the host runs an MCP
server like this one to let a human respond.

## Why an MCP tool, not a special FFI callback?

The previous Agent Shield design exposed a `HumanResolver` trait /
`IHumanResolver` interface across all four SDKs (Rust, Python, Node,
.NET). That meant every host had to write a special callback that lived
outside the agent's tool channel.

The current design folds human-in-the-loop into the agent's existing
tool channel. The agentic loop already knows how to react to a deny
("call the tool the verdict named, then retry"); the same machinery
that handles `kind: tool` resolvers works for `kind: human` resolvers.
This is consistent with Roni's framing in the design conversation:
"`kind: human` is a thin shim over `kind: tool`."

## Running the server

```bash
cd examples/tools/ask-human-mcp-server
pip install -r requirements.txt
python server.py
```

The server speaks MCP over stdio and exposes a single tool:

```python
agent_shield.ask_human(prompt: str, variable: str | None = None) -> str
```

The return value is a JSON-encoded resolver response envelope:

```json
{
  "decision": "allow" | "deny" | "cancelled",
  "value": <true|false|null|string|number>,
  "reason": "<optional reason>"
}
```

The server reads the human's decision from stdin (terminal mode) by
default. Set `ASK_HUMAN_AUTO_APPROVE=1` for non-interactive testing.

## Wiring into a demo

In `agents/bank-manager`, register this server alongside
the banking MCP server. Example (Python OpenAI Agents adapter):

```python
from agents.mcp import MCPServerStdio

ask_human = MCPServerStdio(
    params={
        "command": "python",
        "args": ["examples/tools/ask-human-mcp-server/server.py"],
    },
    name="agent_shield.ask_human",
)
banking = MCPServerStdio(
    params={"command": "python", "args": ["mcp_banking_server.py"]},
    name="banking",
)

agent = Agent(
    name="bank-manager",
    instructions=BANK_MANAGER_INSTRUCTIONS,
    mcp_servers=[ask_human, banking],
    tools=[],
)
```

When a guard policy denies with a `pending_resolution` pointing at
`agent_shield.ask_human`, the agent's LLM picks up the new tool name
from the deny reason and invokes it; the human's response populates the
variable; the next gate evaluation passes.

## Loop bound

The runtime applies the same `tool_retry_limit` (default `3`) used for
`kind: tool` resolvers. If the agent keeps calling
`agent_shield.ask_human` without the variable getting populated (e.g.
the human keeps cancelling, or the populator is misconfigured), the
runtime emits `incident.resolution_loop` and treats the resolution as
`cancelled` for the rest of the turn.
