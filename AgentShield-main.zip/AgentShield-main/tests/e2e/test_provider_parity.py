"""Cross-provider parity test for the auto-wired LLM caller.

The auto-wired LLM caller in ``sdk/rust/agent_shield_core/src/runtime/llm_auto.rs``
routes ``configurations[].provider`` values to per-provider HTTP shapes.
This test asserts the **observable parity** end of that:

* Any of the supported `provider:` strings — short or reverse-domain —
  loads cleanly through ``RuntimeBuilder.from_yaml_strings``.
* When the host installs its own ``register_llm_caller`` (the
  customer-facing escape hatch and the canonical Bedrock path), the
  same canonical mocked response folds into the *identical* verdict
  envelope regardless of provider name. This protects against future
  drift where, e.g., an Ollama configuration accidentally takes a
  different fail-closed code path than an OpenAI one.

The unit-level transport-shape tests (which assert that Gemini sends
Bearer auth + the OpenAI body shape, Ollama sends no auth header
on the loopback default, etc.) live in
``sdk/rust/agent_shield_core/src/runtime/llm_auto.rs`` because they
need access to the private ``HttpTransport`` seam. This module is
the public-API-level companion.

Run with:
    pytest -q tests/e2e/test_provider_parity.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

# Ensure the local sdk/python wins over any installed copy.
_REPO_ROOT = Path(__file__).resolve().parent.parent.parent
_SDK_PYTHON = _REPO_ROOT / "sdk" / "python"
if _SDK_PYTHON.is_dir():
    sys.path.insert(0, str(_SDK_PYTHON))

from agent_shield import _native  # noqa: E402


# Every supported (provider, model) pair the auto-wired caller MUST
# accept. Includes both short-form aliases and the spec §6.5
# reverse-domain forms. Bedrock is included because the YAML loader
# must accept the provider name; the host-installed caller drives the
# actual gating (which the test does anyway via register_llm_caller).
PROVIDER_FIXTURES: list[tuple[str, str, str]] = [
    # (label, provider, model)
    ("openai_short", "openai", "gpt-4o-mini"),
    ("openai_revdomain", "openai.chat", "gpt-4o-mini"),
    ("azure_short", "azure", "gpt-4o-mini-deployment"),
    ("azure_revdomain", "microsoft.azure.openai", "gpt-4o-mini-deployment"),
    ("anthropic_short", "anthropic", "claude-3-5-sonnet-20241022"),
    ("anthropic_revdomain", "anthropic.claude", "claude-3-5-sonnet-20241022"),
    ("gemini_short", "gemini", "gemini-1.5-pro"),
    ("gemini_revdomain", "google.gemini", "gemini-1.5-pro"),
    ("ollama_short", "ollama", "llama3.1"),
    ("ollama_revdomain", "meta.ollama", "llama3.1"),
    ("bedrock_short", "bedrock", "anthropic.claude-3-5-sonnet-20241022-v2:0"),
    (
        "bedrock_revdomain",
        "amazon.bedrock",
        "anthropic.claude-3-5-sonnet-20241022-v2:0",
    ),
]


def _yaml_for(provider: str, model: str) -> str:
    """Build a minimal one-policy YAML that gates on Stage-3 ``llm:``.

    Every provider gets the same shape so any per-provider divergence
    in load-time behaviour surfaces as a clear delta. ``api_key_env``
    is set to a name that may not be set in the test environment —
    the host-installed mock caller (``register_llm_caller``) bypasses
    HTTP entirely so the env var value never matters.
    """
    return f"""
metadata:
  name: provider_parity
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["assist customer"]
  forbidden: ["leak secrets"]
resources:
  tools:
    - name: t
      description: "test tool"
      permission: read_only
configurations:
  - id: gate
    type: llm
    default: true
    provider: {provider!r}
    model: {model!r}
    api_key_env: AS_PARITY_TEST_KEY_NEVER_SET
    max_tokens: 200
tool_execution_validation:
  configuration: gate
  guard_policies:
    - name: gate_tool
      applies_to:
        tools: ["t"]
      evaluate_when:
        - llm:
            configuration: gate
            prompt: "ignored"
          reason: "blocked"
      action: block
"""


@pytest.mark.parametrize(
    "label, provider, model",
    PROVIDER_FIXTURES,
    ids=[label for label, _p, _m in PROVIDER_FIXTURES],
)
def test_provider_yaml_loads(label: str, provider: str, model: str) -> None:
    """Every supported provider name MUST load through the YAML
    front-end without error.

    The schema does not enum-restrict ``provider:`` (it is an opaque
    reverse-domain string per spec §6.5), so this test is mainly a
    smoke check that no other layer between the schema and the
    auto-wired caller chokes on the new names.
    """
    yaml = _yaml_for(provider, model)
    builder = _native.RuntimeBuilder.from_yaml_strings([yaml])
    # Install a stub caller so the verdict path doesn't depend on any
    # real HTTP transport.
    builder.register_llm_caller(lambda _cfg, _prompt: '{"decision": "BLOCK"}')
    rt = builder.build()
    session = rt.new_session()
    verdict, _params = session.validate_tool_call("t", {})
    # Sanity check: BLOCK response → tool denied.
    assert not verdict["allowed"], (
        f"{label}: expected BLOCK verdict from stub caller, got "
        f"allowed={verdict['allowed']!r}"
    )


def test_verdict_envelope_identical_across_providers() -> None:
    """Given an identical mocked LLM response, the verdict envelope
    MUST be identical regardless of which provider name is in the
    YAML.

    This is the *minimum* parity guarantee. It does NOT prove that
    the per-provider HTTP transport shapes are correct — those are
    asserted by the unit tests under
    ``sdk/rust/agent_shield_core/src/runtime/llm_auto.rs`` that hook
    a recording transport into the auto-wired caller. This test
    proves the *public-API surface* (which is what customers see)
    does not branch on provider name once a host caller is installed.
    """
    canonical_response = (
        '{"decision": "BLOCK", "reason": "policy violation", '
        '"categories": ["pii"], "confidence": 0.97}'
    )

    envelopes: dict[str, tuple] = {}
    for label, provider, model in PROVIDER_FIXTURES:
        yaml = _yaml_for(provider, model)
        builder = _native.RuntimeBuilder.from_yaml_strings([yaml])
        builder.register_llm_caller(lambda _cfg, _prompt, _r=canonical_response: _r)
        rt = builder.build()
        session = rt.new_session()
        verdict, _ = session.validate_tool_call("t", {})

        # Project to the fields that the public API guarantees stable.
        # Free-form / implementation-defined fields (e.g. timing,
        # internal correlation ids) are deliberately omitted.
        envelopes[label] = (
            verdict["allowed"],
            verdict.get("action"),
            tuple(verdict.get("reasons") or ()),
        )

    # Every entry must match the first.
    reference_label, reference_value = next(iter(envelopes.items()))
    for label, value in envelopes.items():
        assert value == reference_value, (
            f"verdict envelope diverged: {reference_label}={reference_value!r} "
            f"vs {label}={value!r}"
        )
