"""E2E test runner for the OpenAI Agents SDK adapter .

Loads shared adapter scenarios from adapter-scenarios.yaml and exercises
the ``protect_tools``, ``GuardedAgent``, and ``validate_input`` code paths
using the OpenAI Agents SDK types.

Usage:
    pytest tests/e2e/run_openai_agents.py -v
"""
from __future__ import annotations

import json
from unittest.mock import MagicMock

import pytest

pytest.importorskip("agents")

from agents import FunctionTool
from agent_shield import RuntimeBuilder
from agent_shield.adapters.openai_agents import GuardedAgent, protect_tools, _BlockedResult
from agent_shield.adapters._orchestration import current_session

from conftest import SpyToolRecord, fixture_path, load_scenarios, make_inline_fixture, PII_RESPONSE, build_v2_runtime

# ── Capabilities supported by this adapter ──────────────────────────────────

ADAPTER_CAPABILITIES = {"guarded_agent"}

ALL_SCENARIOS = load_scenarios(ADAPTER_CAPABILITIES)


# ── Helpers ─────────────────────────────────────────────────────────────────


def _make_spy_function_tool(name, spy, response="ok"):
    """Create a FunctionTool that records calls via *spy* and returns *response*."""
    async def _invoke(ctx, input_json):
        params = json.loads(input_json) if input_json else {}
        spy.record(**params)
        return response

    return FunctionTool(
        name=name,
        description=f"Test tool: {name}",
        params_json_schema={"type": "object", "properties": {}},
        on_invoke_tool=_invoke,
    )


def _tool_response(tool_spec):
    """Resolve the effective response string for a tool spec dict."""
    if tool_spec.get("response_pii"):
        return PII_RESPONSE
    if "response_sensitivity" in tool_spec:
        return json.dumps({"sensitivity": tool_spec["response_sensitivity"]})
    return tool_spec.get("response", "ok")


def _create_runtime(scenario, tmp_path):
    """Build a ``Runtime`` and session from the scenario's fixture reference."""
    if "fixture_inline" in scenario:
        path = make_inline_fixture(scenario["fixture_inline"], tmp_path)
    else:
        path = fixture_path(scenario["fixture"])
    runtime = build_v2_runtime(path)
    session = runtime.new_session()
    session.begin_turn()
    for var, value in scenario.get("setup", {}).get("variables", {}).items():
        session.set_variable(var, value)
    return runtime, session


# ── Assertion helpers ───────────────────────────────────────────────────────


def _assert_expected(result_str, spy, expected):
    """Run common assertions against a tool invocation result."""
    if "tool_invoked" in expected:
        if expected["tool_invoked"]:
            assert spy.was_called, "Expected tool to be invoked"
        else:
            assert not spy.was_called, "Expected tool NOT to be invoked"

    if "result" in expected:
        assert result_str == expected["result"]

    if "result_contains" in expected:
        assert expected["result_contains"] in result_str, (
            f"Expected result to contain {expected['result_contains']!r}, got {result_str!r}"
        )

    if "result_contains_lower" in expected:
        assert expected["result_contains_lower"] in result_str.lower(), (
            f"Expected result (lowered) to contain {expected['result_contains_lower']!r}"
        )

    if "result_not_contains" in expected:
        assert expected["result_not_contains"] not in result_str, (
            f"Expected result NOT to contain {expected['result_not_contains']!r}"
        )


# ── Scenario handlers ──────────────────────────────────────────────────────


async def _handle_simple_tool(scenario, tmp_path):
    """Handle scenarios with a single ``tool`` key."""
    runtime, session = _create_runtime(scenario, tmp_path)
    token = current_session.set(session)
    try:
        tool_spec = scenario["tool"]
        spy = SpyToolRecord()
        response = _tool_response(tool_spec)
        tool = _make_spy_function_tool(tool_spec["name"], spy, response)
        protected = protect_tools(runtime, [tool])
        result = await protected[0].on_invoke_tool(None, "{}")
        _assert_expected(result, spy, scenario["expected"])
    finally:
        current_session.reset(token)
        try:
            session.end_turn()
        except Exception:  # noqa: BLE001
            pass


async def _handle_validate_input(scenario, tmp_path):
    """Handle scenarios with a ``validate_input`` key."""
    runtime, session = _create_runtime(scenario, tmp_path)
    try:
        text = scenario["validate_input"]
        vr = session.validate_input(text)
        expected = scenario["expected"]

        if "allowed" in expected:
            assert vr.allowed == expected["allowed"], (
                f"Expected allowed={expected['allowed']}, got {vr.allowed}"
            )

        if "action" in expected:
            assert vr.action == expected["action"], (
                f"Expected action={expected['action']!r}, got {vr.action!r}"
            )
    finally:
        try:
            session.end_turn()
        except Exception:  # noqa: BLE001
            pass


async def _handle_steps(scenario, tmp_path):
    """Handle multi-step scenarios with sequential actions."""
    runtime, session = _create_runtime(scenario, tmp_path)
    token = current_session.set(session)
    try:
        spies: dict[str, SpyToolRecord] = {}
        protected_cache: dict[str, object] = {}

        for idx, step in enumerate(scenario["steps"], start=1):
            action = step["action"]

            if action == "invoke_tool":
                tool_spec = step["tool"]
                tool_name = tool_spec["name"]
                response = _tool_response(tool_spec)

                spy = SpyToolRecord()
                spies[tool_name] = spy
                tool = _make_spy_function_tool(tool_name, spy, response)
                protected = protect_tools(runtime, [tool])
                protected_cache[tool_name] = protected[0]

                result = await protected[0].on_invoke_tool(None, "{}")
                if "expected" in step:
                    _assert_expected(result, spy, step["expected"])

            elif action == "check_variable":
                value = session.resolve_variable(step["variable"])
                assert value == step["expected_value"], (
                    f"Variable {step['variable']!r}: expected {step['expected_value']!r}, "
                    f"got {value!r}"
                )

            elif action == "set_variable":
                session.set_variable(step["variable"], step["value"])

            elif action == "validate_tool_call":
                tool_name = step["tool_name"]
                outcome = session.validate_tool_call(tool_name, tool_call_id=f"call_{idx}")
                expected = step["expected"]
                if "allowed" in expected:
                    assert outcome.verdict.allowed == expected["allowed"], (
                        f"validate_tool_call({tool_name!r}): "
                        f"expected allowed={expected['allowed']}, got {outcome.verdict.allowed}"
                    )

            elif action == "reset_variable":
                session.reset_variable(step["variable"])

            else:
                pytest.fail(f"Unknown step action: {action!r}")
    finally:
        current_session.reset(token)
        try:
            session.end_turn()
        except Exception:  # noqa: BLE001
            pass


async def _handle_guarded_agent(scenario, tmp_path):
    """Handle scenarios with a ``guarded_agent`` key."""
    runtime, session = _create_runtime(scenario, tmp_path)
    token = current_session.set(session)
    try:
        ga_spec = scenario["guarded_agent"]
        expected = scenario["expected"]

        mock_agent = MagicMock()
        mock_agent.name = "test-agent"
        mock_agent.instructions = "be helpful"
        mock_agent.tools = []
        mock_agent.model = "gpt-4o-mini"

        guarded = GuardedAgent(runtime, mock_agent)
        result = await guarded.run(ga_spec["input"])

        if expected.get("agent_invoked") is False:
            assert isinstance(result, _BlockedResult), (
                f"Expected _BlockedResult, got {type(result).__name__}"
            )

        if "result_contains" in expected:
            output = result.final_output if hasattr(result, "final_output") else str(result)
            assert expected["result_contains"] in output, (
                f"Expected result to contain {expected['result_contains']!r}, got {output!r}"
            )
    finally:
        current_session.reset(token)
        try:
            session.end_turn()
        except Exception:  # noqa: BLE001
            pass


# ── Main parametrised test ──────────────────────────────────────────────────


@pytest.mark.asyncio
@pytest.mark.parametrize("scenario", ALL_SCENARIOS, ids=[s["name"] for s in ALL_SCENARIOS])
async def test_scenario(scenario, tmp_path):
    """Run a single adapter scenario against the OpenAI Agents SDK adapter."""
    if "tool" in scenario:
        await _handle_simple_tool(scenario, tmp_path)
    elif "validate_input" in scenario:
        await _handle_validate_input(scenario, tmp_path)
    elif "steps" in scenario:
        await _handle_steps(scenario, tmp_path)
    elif "guarded_agent" in scenario:
        await _handle_guarded_agent(scenario, tmp_path)
    else:
        pytest.skip(f"No handler for scenario: {scenario['name']}")
