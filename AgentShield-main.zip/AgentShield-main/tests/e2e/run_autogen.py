"""E2E test runner for the AutoGen adapter .

Loads shared scenarios from adapter-scenarios.yaml, filters by
capabilities (AutoGen supports basic tool wrapping only — no
guarded_agent, agent_loop, or streaming), and exercises
``protect_tools`` + the ``Runtime`` through every applicable
scenario type.
"""
from __future__ import annotations

import json

import pytest

autogen_core = pytest.importorskip("autogen_core")

from autogen_core import CancellationToken
from autogen_core.tools import FunctionTool

from agent_shield import RuntimeBuilder
from agent_shield.adapters._orchestration import current_session
from agent_shield.adapters.autogen import protect_tools

from conftest import (
    SpyToolRecord,
    fixture_path,
    load_scenarios,
    make_inline_fixture,
    PII_RESPONSE,
    build_v2_runtime,
)

# ── AutoGen capabilities ────────────────────────────────────────────────────

CAPABILITIES: set[str] = set()

# ── Helpers ─────────────────────────────────────────────────────────────────


def _make_spy_function_tool(name, spy, response="ok"):
    async def _func():
        spy.record()
        return response

    return FunctionTool(_func, name=name, description=f"Test tool: {name}")


def _tool_response(tool_spec):
    """Resolve the effective response string from a tool spec dict."""
    if tool_spec.get("response_pii"):
        return PII_RESPONSE
    if "response_sensitivity" in tool_spec:
        return json.dumps({"sensitivity": tool_spec["response_sensitivity"]})
    return tool_spec.get("response", "ok")


def _resolve_fixture(scenario, tmp_path):
    """Return the guardrails YAML path for a scenario."""
    if "fixture_inline" in scenario:
        return make_inline_fixture(scenario["fixture_inline"], tmp_path)
    return fixture_path(scenario["fixture"])


def _apply_setup(session, setup):
    """Apply optional ``setup`` block (pre-set variables, etc.)."""
    if not setup:
        return
    for var_name, var_value in setup.get("variables", {}).items():
        session.set_variable(var_name, var_value)


def _assert_expected(result_str, spy, expected):
    """Run common assertion checks against a tool result string."""
    if "tool_invoked" in expected:
        assert spy.was_called == expected["tool_invoked"]

    if "result" in expected:
        assert result_str == expected["result"]

    if "result_contains" in expected:
        assert expected["result_contains"] in result_str

    if "result_not_contains" in expected:
        assert expected["result_not_contains"] not in result_str

    if "result_contains_lower" in expected:
        assert expected["result_contains_lower"] in result_str.lower()


# ── Scenario loading ────────────────────────────────────────────────────────

_scenarios = load_scenarios(CAPABILITIES)


# ── Tests ───────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "scenario",
    [s for s in _scenarios if "tool" in s],
    ids=[s["name"] for s in _scenarios if "tool" in s],
)
async def test_simple_tool(scenario, tmp_path):
    """Scenario with a single tool invocation."""
    config_path = _resolve_fixture(scenario, tmp_path)
    runtime = build_v2_runtime(config_path)
    session = runtime.new_session()
    session.begin_turn()

    _apply_setup(session, scenario.get("setup"))

    token = current_session.set(session)
    try:
        spy = SpyToolRecord()
        tool_spec = scenario["tool"]
        response = _tool_response(tool_spec)
        tool = _make_spy_function_tool(tool_spec["name"], spy, response)

        protected = protect_tools(runtime, [tool])
        result = await protected[0].run_json({}, CancellationToken())
        result_str = str(result)

        _assert_expected(result_str, spy, scenario["expected"])
    finally:
        current_session.reset(token)
        try:
            session.end_turn()
        except Exception:  # noqa: BLE001
            pass


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "scenario",
    [s for s in _scenarios if "validate_input" in s],
    ids=[s["name"] for s in _scenarios if "validate_input" in s],
)
async def test_validate_input(scenario, tmp_path):
    """Scenario that validates user input (Stage 1)."""
    config_path = _resolve_fixture(scenario, tmp_path)
    runtime = build_v2_runtime(config_path)
    session = runtime.new_session()
    session.begin_turn()
    try:
        result = session.validate_input(scenario["validate_input"])
        expected = scenario["expected"]

        if "allowed" in expected:
            assert result.allowed == expected["allowed"]

        if "action" in expected:
            assert result.action == expected["action"]
    finally:
        try:
            session.end_turn()
        except Exception:  # noqa: BLE001
            pass


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "scenario",
    [s for s in _scenarios if "steps" in s],
    ids=[s["name"] for s in _scenarios if "steps" in s],
)
async def test_steps(scenario, tmp_path):
    """Multi-step scenario with sequential actions."""
    config_path = _resolve_fixture(scenario, tmp_path)
    runtime = build_v2_runtime(config_path)
    session = runtime.new_session()
    session.begin_turn()

    _apply_setup(session, scenario.get("setup"))

    token = current_session.set(session)
    try:
        for idx, step in enumerate(scenario["steps"], start=1):
            action = step["action"]

            if action == "invoke_tool":
                spy = SpyToolRecord()
                tool_spec = step["tool"]
                response = _tool_response(tool_spec)
                tool = _make_spy_function_tool(tool_spec["name"], spy, response)

                protected = protect_tools(runtime, [tool])
                result = await protected[0].run_json({}, CancellationToken())
                result_str = str(result)

                if "expected" in step:
                    _assert_expected(result_str, spy, step["expected"])

            elif action == "check_variable":
                value = session.resolve_variable(step["variable"])
                assert value == step["expected_value"]

            elif action == "set_variable":
                session.set_variable(step["variable"], step["value"])

            elif action == "validate_tool_call":
                outcome = session.validate_tool_call(step["tool_name"], tool_call_id=f"call_{idx}")
                if "expected" in step:
                    if "allowed" in step["expected"]:
                        assert outcome.verdict.allowed == step["expected"]["allowed"]

            elif action == "reset_variable":
                session.reset_variable(step["variable"])

            else:
                pytest.fail(f"Unknown step action: {action}")
    finally:
        current_session.reset(token)
        try:
            session.end_turn()
        except Exception:  # noqa: BLE001
            pass
