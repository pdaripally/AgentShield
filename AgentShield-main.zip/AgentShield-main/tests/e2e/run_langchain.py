"""E2E runner: LangChain adapter ."""
from __future__ import annotations

import json
from typing import Any

import pytest

lc = pytest.importorskip("langchain_core")

from langchain_core.messages import AIMessage, HumanMessage, ToolMessage  # noqa: E402
from langchain_core.tools import StructuredTool  # noqa: E402

from agent_shield import RuntimeBuilder  # noqa: E402
from agent_shield.adapters._orchestration import current_session  # noqa: E402
from agent_shield.adapters.langchain import GuardedAgent, protect_tools  # noqa: E402

from conftest import (  # noqa: E402
    SpyToolRecord,
    fixture_path,
    load_scenarios,
    make_inline_fixture,
    PII_RESPONSE,
    make_langchain_mock_llm,
    build_v2_runtime,
)

# ---------------------------------------------------------------------------
# Capabilities & scenario loading
# ---------------------------------------------------------------------------

CAPABILITIES = {"guarded_agent", "agent_loop"}
ALL_SCENARIOS = load_scenarios(CAPABILITIES)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_spy_tool(
    name: str, spy: SpyToolRecord, response: str = "ok",
) -> StructuredTool:
    """Create a LangChain StructuredTool that records invocations."""

    def _func(**kwargs: Any) -> str:
        spy.record(**kwargs)
        return response

    return StructuredTool.from_function(
        func=_func, name=name, description=f"Test tool: {name}",
    )


def _tool_response(scenario_tool: dict) -> str:
    """Resolve the effective response string for a tool spec."""
    if scenario_tool.get("response_pii"):
        return PII_RESPONSE
    sensitivity = scenario_tool.get("response_sensitivity")
    if sensitivity is not None:
        return json.dumps({"sensitivity": sensitivity})
    return scenario_tool.get("response", "ok")


def _build_runtime(scenario: dict, tmp_path):
    """Construct a Runtime and session from either ``fixture`` or ``fixture_inline``."""
    if "fixture_inline" in scenario:
        path = make_inline_fixture(scenario["fixture_inline"], tmp_path)
    else:
        path = fixture_path(*scenario["fixture"].split("/"))
    runtime = build_v2_runtime(path)
    session = runtime.new_session()
    session.begin_turn()
    for var, value in scenario.get("setup", {}).get("variables", {}).items():
        session.set_variable(var, value)
    return runtime, session


def _assert_expected(result: str, expected: dict, spy: SpyToolRecord | None = None):
    """Run common assertions driven by an ``expected`` block."""
    if spy is not None:
        if "tool_invoked" in expected:
            if expected["tool_invoked"]:
                assert spy.was_called, "Expected tool to be invoked"
            else:
                assert not spy.was_called, "Expected tool NOT to be invoked"
    if "result" in expected:
        assert result == expected["result"]
    if "result_contains" in expected:
        assert expected["result_contains"] in result
    if "result_contains_lower" in expected:
        assert expected["result_contains_lower"] in result.lower()
    if "result_not_contains" in expected:
        assert expected["result_not_contains"] not in result
    if "allowed" in expected:
        # handled by caller — kept here for completeness
        pass
    if "action" in expected:
        pass


# ---------------------------------------------------------------------------
# Scenario dispatchers
# ---------------------------------------------------------------------------


async def _run_simple_tool(scenario: dict, tmp_path):
    """Handle scenarios with a top-level ``tool`` key."""
    runtime, session = _build_runtime(scenario, tmp_path)
    token = current_session.set(session)
    try:
        spy = SpyToolRecord()
        tool_spec = scenario["tool"]
        response = _tool_response(tool_spec)
        tool = _make_spy_tool(tool_spec["name"], spy, response=response)
        protected = protect_tools(runtime, [tool])
        result = await protected[0].ainvoke({})
        _assert_expected(result, scenario["expected"], spy)
    finally:
        current_session.reset(token)
        try:
            session.end_turn()
        except Exception:  # noqa: BLE001
            pass


async def _run_validate_input(scenario: dict, tmp_path):
    """Handle scenarios with a ``validate_input`` key."""
    runtime, session = _build_runtime(scenario, tmp_path)
    try:
        vr = session.validate_input(scenario["validate_input"])
        expected = scenario["expected"]
        if "allowed" in expected:
            assert vr.allowed == expected["allowed"]
        if "action" in expected:
            assert vr.action == expected["action"]
    finally:
        try:
            session.end_turn()
        except Exception:  # noqa: BLE001
            pass


async def _run_steps(scenario: dict, tmp_path):
    """Handle scenarios with a ``steps`` key (sequential actions)."""
    runtime, session = _build_runtime(scenario, tmp_path)
    token = current_session.set(session)
    try:
        protected_cache: dict[str, tuple[StructuredTool, SpyToolRecord]] = {}

        for idx, step in enumerate(scenario["steps"], start=1):
            action = step["action"]

            if action == "invoke_tool":
                tool_spec = step["tool"]
                name = tool_spec["name"]
                response = _tool_response(tool_spec)
                spy = SpyToolRecord()
                tool = _make_spy_tool(name, spy, response=response)
                protected = protect_tools(runtime, [tool])
                result = await protected[0].ainvoke({})
                protected_cache[name] = (protected[0], spy)
                _assert_expected(result, step.get("expected", {}), spy)

            elif action == "check_variable":
                value = session.resolve_variable(step["variable"])
                assert value == step["expected_value"], (
                    f"Variable {step['variable']!r}: "
                    f"expected {step['expected_value']!r}, got {value!r}"
                )

            elif action == "set_variable":
                session.set_variable(step["variable"], step["value"])

            elif action == "validate_tool_call":
                outcome = session.validate_tool_call(step["tool_name"], {}, tool_call_id=f"call_{idx}")
                expected = step.get("expected", {})
                if "allowed" in expected:
                    assert outcome.verdict.allowed == expected["allowed"]

            elif action == "reset_variable":
                session.reset_variable(step["variable"])

            else:
                pytest.fail(f"Unknown step action: {action}")
    finally:
        current_session.reset(token)
        try:
            session.end_turn()
        except Exception:  # noqa: BLE001
            pass


async def _run_guarded_agent(scenario: dict, tmp_path):
    """Handle scenarios with a ``guarded_agent`` key."""
    runtime, session = _build_runtime(scenario, tmp_path)
    token = current_session.set(session)
    try:
        ga_spec = scenario["guarded_agent"]
        expected = scenario["expected"]

        agent_invoked = False

        class MockAgent:
            async def ainvoke(self, input_dict, config=None, **kwargs):
                nonlocal agent_invoked
                agent_invoked = True
                return {"messages": [AIMessage(content="Agent response")]}

        guarded = GuardedAgent(runtime, MockAgent())
        result = await guarded.ainvoke(
            {"messages": [HumanMessage(content=ga_spec["input"])]},
        )

        if "agent_invoked" in expected:
            if expected["agent_invoked"]:
                assert agent_invoked, "Expected agent to be invoked"
            else:
                assert not agent_invoked, "Expected agent NOT to be invoked"

        messages = result.get("messages", [])
        result_text = messages[-1].content if messages else ""

        if "result_contains" in expected:
            assert expected["result_contains"] in result_text
        if "result_not_contains" in expected:
            assert expected["result_not_contains"] not in result_text
    finally:
        current_session.reset(token)
        try:
            session.end_turn()
        except Exception:  # noqa: BLE001
            pass


async def _run_agent_loop(scenario: dict, tmp_path):
    """Handle scenarios with an ``agent_loop`` key."""
    runtime, session = _build_runtime(scenario, tmp_path)
    token = current_session.set(session)
    try:
        loop_spec = scenario["agent_loop"]
        expected = scenario["expected"]

        # Build spy tools
        spies: dict[str, SpyToolRecord] = {}
        tools: list[StructuredTool] = []
        for ts in loop_spec["tools"]:
            spy = SpyToolRecord()
            spies[ts["name"]] = spy
            response = _tool_response(ts)
            tools.append(_make_spy_tool(ts["name"], spy, response=response))

        protected = protect_tools(runtime, tools)

        # Create mock LLM with scripted responses and bind protected tools
        llm = make_langchain_mock_llm(loop_spec["llm_responses"])
        bound_llm = llm.bind_tools(protected)

        # Run the message loop
        messages: list = [HumanMessage(content="run")]

        for _turn in range(len(loop_spec["llm_responses"]) + 1):
            ai_response = bound_llm.invoke(messages)
            messages.append(ai_response)

            if not ai_response.tool_calls:
                break

            for tc in ai_response.tool_calls:
                # Find the matching protected tool
                matched = [t for t in protected if t.name == tc["name"]]
                if matched:
                    tool_result = await matched[0].ainvoke(tc.get("args", {}))
                else:
                    tool_result = f"Unknown tool: {tc['name']}"
                messages.append(ToolMessage(content=str(tool_result), tool_call_id=tc["id"]))

        # Collect tool messages for assertions
        tool_messages = [m for m in messages if isinstance(m, ToolMessage)]

        # Per-tool assertions
        if "per_tool" in expected:
            for tool_name, tool_expected in expected["per_tool"].items():
                spy = spies.get(tool_name)
                # Find tool messages for this specific tool
                tc_ids_for_tool = []
                for m in messages:
                    if isinstance(m, AIMessage) and m.tool_calls:
                        for tc in m.tool_calls:
                            if tc["name"] == tool_name:
                                tc_ids_for_tool.append(tc["id"])
                tool_msgs = [
                    m for m in tool_messages if m.tool_call_id in tc_ids_for_tool
                ]
                result_text = tool_msgs[0].content if tool_msgs else ""

                if spy and "tool_invoked" in tool_expected:
                    if tool_expected["tool_invoked"]:
                        assert spy.was_called, f"Expected {tool_name} to be invoked"
                    else:
                        assert not spy.was_called, f"Expected {tool_name} NOT to be invoked"
                if "result" in tool_expected:
                    assert result_text == tool_expected["result"]
                if "result_contains" in tool_expected:
                    assert tool_expected["result_contains"] in result_text
        else:
            # Global tool assertions
            all_tool_text = " ".join(m.content for m in tool_messages)
            any_invoked = any(s.was_called for s in spies.values())

            if "tool_invoked" in expected:
                if expected["tool_invoked"]:
                    assert any_invoked, "Expected at least one tool to be invoked"
                else:
                    assert not any_invoked, "Expected no tool to be invoked"
            if "tool_messages_contain" in expected:
                assert expected["tool_messages_contain"] in all_tool_text
            if "tool_messages_not_contain" in expected:
                assert expected["tool_messages_not_contain"] not in all_tool_text
    finally:
        current_session.reset(token)
        try:
            session.end_turn()
        except Exception:  # noqa: BLE001
            pass


async def _run_streaming(scenario: dict, tmp_path):
    """Handle scenarios with a ``streaming`` key."""
    runtime, session = _build_runtime(scenario, tmp_path)
    token = current_session.set(session)
    try:
        stream_spec = scenario["streaming"]
        expected = scenario["expected"]

        agent_invoked = False
        agent_responses = stream_spec.get("agent_responses", [])

        class MockStreamAgent:
            async def ainvoke(self, input_dict, config=None, **kwargs):
                nonlocal agent_invoked
                agent_invoked = True
                return {"messages": [AIMessage(content="Agent response")]}

            async def astream(self, input_dict, config=None, **kwargs):
                nonlocal agent_invoked
                agent_invoked = True
                for resp in agent_responses:
                    yield {"messages": [AIMessage(content=resp)]}

        guarded = GuardedAgent(runtime, MockStreamAgent())
        chunks = []
        async for chunk in guarded.astream(
            {"messages": [HumanMessage(content=stream_spec["input"])]},
        ):
            chunks.append(chunk)

        if "agent_invoked" in expected:
            if expected["agent_invoked"]:
                assert agent_invoked, "Expected agent to be invoked"
            else:
                assert not agent_invoked, "Expected agent NOT to be invoked"

        # Flatten chunk text for assertions
        all_text_parts = []
        for chunk in chunks:
            msgs = chunk.get("messages", [])
            for m in msgs:
                content = m.content if hasattr(m, "content") else str(m)
                all_text_parts.append(content)
        all_text = " ".join(all_text_parts)

        if "result_contains" in expected:
            assert expected["result_contains"] in all_text
        if "result_not_contains" in expected:
            assert expected["result_not_contains"] not in all_text
        if "chunk_count" in expected:
            assert len(chunks) == expected["chunk_count"]
        if "chunks_contain" in expected:
            for needle in expected["chunks_contain"]:
                assert needle in all_text, f"Expected {needle!r} in streamed output"
    finally:
        current_session.reset(token)
        try:
            session.end_turn()
        except Exception:  # noqa: BLE001
            pass


# ---------------------------------------------------------------------------
# Main parametrized test
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "scenario", ALL_SCENARIOS, ids=[s["name"] for s in ALL_SCENARIOS],
)
async def test_scenario(scenario, tmp_path):
    """Dispatch each adapter scenario to the appropriate handler."""
    if "tool" in scenario:
        await _run_simple_tool(scenario, tmp_path)
    elif "validate_input" in scenario:
        await _run_validate_input(scenario, tmp_path)
    elif "steps" in scenario:
        await _run_steps(scenario, tmp_path)
    elif "guarded_agent" in scenario:
        await _run_guarded_agent(scenario, tmp_path)
    elif "agent_loop" in scenario:
        await _run_agent_loop(scenario, tmp_path)
    elif "streaming" in scenario:
        await _run_streaming(scenario, tmp_path)
    else:
        pytest.skip("unsupported scenario type")
