"""AgentDojo benchmark harness for Agent Shield e2e tests.

Wires the ETH Zürich AgentDojo prompt-injection benchmark
(https://github.com/ethz-spylab/agentdojo) into ``tests/e2e/`` so we can
measure attack success rate (ASR) and benign task success rate with and
without a ``.guardrails.yaml`` enforcing Agent Shield's runtime checks.

See ``tests/e2e/agentdojo_bench/README.md`` for usage and design rationale.
"""

from .pipeline import (
    ScriptedLLM,
    ShieldedAgentDojoPipeline,
    ShieldedToolsExecutor,
    build_pipeline,
    run_attacked_pairs,
)
from .runner import SuiteSummary, run_suite

__all__ = [
    "ScriptedLLM",
    "ShieldedAgentDojoPipeline",
    "ShieldedToolsExecutor",
    "SuiteSummary",
    "build_pipeline",
    "run_attacked_pairs",
    "run_suite",
]
