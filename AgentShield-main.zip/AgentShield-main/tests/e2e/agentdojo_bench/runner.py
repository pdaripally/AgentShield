"""Run AgentDojo suites through Agent Shield in ``raw`` and ``shielded`` modes.

Public entry points:

* :func:`run_suite` — executes one suite × one mode and returns a
  :class:`SuiteSummary` with benign utility, attacked utility, and attack
  success rate.
* :func:`summary_markdown` — renders a list of summaries as a Markdown
  table for ``$GITHUB_STEP_SUMMARY`` / human-readable output.
* :func:`write_summary_json` — persists a :class:`SuiteSummary` as JSON.

A small ``__main__`` CLI is provided for the nightly job.

Stable pipeline naming
----------------------

AgentDojo caches task results by ``(pipeline.name, suite, user_task,
attack, injection_task)``. We always pass a distinct
``pipeline.name = f"agent-shield-{mode}-{llm}-{suite}-{attack}-v1"`` and
``force_rerun=True`` so cached log files cannot silently invalidate
measurements when modes are compared.
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Sequence

from agentdojo.agent_pipeline.base_pipeline_element import BasePipelineElement
from agentdojo.attacks.attack_registry import load_attack
from agentdojo.benchmark import (
    benchmark_suite_with_injections,
    benchmark_suite_without_injections,
)
from agentdojo.logging import OutputLogger
from agentdojo.task_suite.load_suites import get_suite

from agent_shield import RuntimeBuilder

from .pipeline import ScriptedLLM, build_pipeline, run_attacked_pairs

logger = logging.getLogger("agent_shield.agentdojo.runner")

# Suite name → starter policy filename.
_POLICIES_DIR = Path(__file__).resolve().parent / "policies"


@dataclass
class SuiteSummary:
    """Aggregate result of running one suite in one mode."""

    suite: str
    mode: str
    llm: str
    llm_mode: str
    attack: str
    benchmark_version: str
    benign_utility: float
    attacked_utility: float
    attack_success_rate: float
    n_benign: int
    n_attacked: int
    benign_per_task: dict[str, bool] = field(default_factory=dict)
    attacked_security_per_task: dict[str, bool] = field(default_factory=dict)
    attacked_utility_per_task: dict[str, bool] = field(default_factory=dict)

    def to_json(self) -> dict[str, Any]:
        return asdict(self)


def _policy_path(suite_name: str) -> Path:
    p = _POLICIES_DIR / f"{suite_name}.guardrails.yaml"
    if not p.exists():
        raise FileNotFoundError(
            f"No starter policy found for suite '{suite_name}': {p}"
        )
    return p


def _build_shield_runtime(suite_name: str):
    """Build an Agent Shield :class:`Runtime` from the per-suite policy.

    The starter policies use no LLM-backed guard policies, so we don't
    register an LLM caller here — Stage 4 redaction is purely
    regex-based.
    """
    return RuntimeBuilder.from_yaml(str(_policy_path(suite_name))).build()


def _mean(values: Sequence[bool]) -> float:
    if not values:
        return 0.0
    return sum(1 for v in values if v) / float(len(values))


# The realistic policy's threat-archetype pattern bank covers these
# attack families generically (LLM-targeting tags, ignore-previous
# language, leading TODO). Other attacks (e.g. the DoS family) succeed
# via different mechanisms and are out of scope unless the policy is
# extended; we keep the allow-list explicit.
_SUPPORTED_ATTACKS = {
    "important_instructions",
    "important_instructions_no_user_name",
    "important_instructions_no_model_name",
    "important_instructions_no_names",
    "tool_knowledge",
    "direct",
    "ignore_previous",
    "system_message",
}


def _load_attack(attack_name: str, suite, pipeline):
    if attack_name not in _SUPPORTED_ATTACKS:
        raise ValueError(
            f"Unsupported attack {attack_name!r}. The realistic policy's "
            "pattern bank covers the `important_instructions` family, "
            "`tool_knowledge`, `direct`, `ignore_previous`, and "
            "`system_message`. Other attacks (DoS variants etc.) succeed "
            "via different mechanisms and are out of scope unless the "
            "pattern bank is extended. See "
            "tests/e2e/agentdojo_bench/README.md."
        )
    return load_attack(attack_name, suite, pipeline)


def run_suite(
    *,
    suite_name: str,
    mode: str,
    llm: str = "scripted",
    llm_mode: str = "marker_compliant",
    benchmark_version: str = "v1.2.2",
    user_tasks: Sequence[str] | None = None,
    injection_tasks: Sequence[str] | None = None,
    attack_name: str = "important_instructions",
    logdir: Path | None = None,
    force_rerun: bool = True,
    openai_model: str | None = None,
    anthropic_model: str | None = None,
) -> SuiteSummary:
    """Run one ``(suite, mode)`` and return a :class:`SuiteSummary`.

    Args:
        suite_name: ``banking`` / ``slack`` / ``workspace`` / ``travel``.
        mode: ``raw`` (stock AgentDojo) or ``shielded`` (gated through
            ``.guardrails.yaml``).
        llm: ``scripted`` / ``openai`` / ``anthropic``.
        llm_mode: Only meaningful for ``llm == "scripted"`` —
            ``"marker_compliant"`` (the scripted LLM follows injections
            only when it sees a marker in tool output) or
            ``"attacker_puppet"`` (the scripted LLM follows the active
            injection deterministically). Use ``attacker_puppet`` to
            test that the Stage-2 latch defends against worst-case
            "LLM is already compromised" attacks.
        user_tasks: Optional restriction to specific user-task IDs.
        injection_tasks: Optional restriction to specific injection-task IDs.
        attack_name: AgentDojo attack name. Starter policies currently
            support the ``important_instructions`` family
            (``important_instructions``,
            ``important_instructions_no_user_name``,
            ``important_instructions_no_model_name``,
            ``important_instructions_no_names``), plus
            ``tool_knowledge``, ``direct``, ``ignore_previous``, and
            ``system_message``.
        logdir / force_rerun: passed to AgentDojo's benchmark loop.
    """
    suite = get_suite(benchmark_version, suite_name)

    llm_element = _build_llm_element(
        llm,
        suite=suite,
        llm_mode=llm_mode,
        openai_model=openai_model,
        anthropic_model=anthropic_model,
    )

    shield_runtime = _build_shield_runtime(suite_name) if mode == "shielded" else None
    model_tag = _llm_model_tag(llm, openai_model=openai_model, anthropic_model=anthropic_model)
    pipeline_name = (
        f"agent-shield-{mode}-{model_tag}-{llm_mode}-{suite_name}-{attack_name}-v1"
    )
    # Realistic policies declare ``untrusted_instruction_detected`` with
    # ``default: false``; the current SDK does not auto-materialize
    # defaults at session start, so seed it here. Harmless for any
    # other variable (set_variable raises only if undeclared, which we
    # catch in ShieldedAgentDojoPipeline).
    seed_variables = (
        {"untrusted_instruction_detected": False} if mode == "shielded" else None
    )
    pipeline = build_pipeline(
        suite=suite,
        mode=mode,
        llm=llm_element,
        shield_runtime=shield_runtime,
        pipeline_name=pipeline_name,
        seed_variables=seed_variables,
    )

    attack = _load_attack(attack_name, suite, pipeline)

    # AgentDojo's TraceLogger expects an active Logger context.
    with OutputLogger(str(logdir) if logdir else None):
        # 1) Benign utility.
        benign = benchmark_suite_without_injections(
            pipeline,
            suite,
            logdir=logdir,
            force_rerun=force_rerun,
            user_tasks=user_tasks,
            benchmark_version=benchmark_version,
        )
        benign_utility_map = {
            ut: bool(v) for (ut, _ij), v in benign["utility_results"].items()
        }

        # 2) Attacked utility + ASR.
        # The ``attacker_puppet`` ScriptedLLM mode needs to know which
        # injection is active for each ``(user_task, injection_task)``
        # pair. AgentDojo's stock benchmark loop doesn't expose a
        # per-pair hook, so we drive the loop ourselves in that case.
        # ``marker_compliant`` and provider-LLM runs go through the
        # stock benchmark loop unchanged.
        if isinstance(llm_element, ScriptedLLM) and llm_element.llm_mode == "attacker_puppet":
            effective_user_tasks = list(
                user_tasks or suite.user_tasks.keys()
            )
            effective_inj_tasks = list(
                injection_tasks or suite.injection_tasks.keys()
            )
            util_pairs, sec_pairs = run_attacked_pairs(
                suite=suite,
                pipeline=pipeline,
                llm=llm_element,
                attack=attack,
                user_tasks=effective_user_tasks,
                injection_tasks=effective_inj_tasks,
            )
            attacked = {
                "utility_results": util_pairs,
                "security_results": sec_pairs,
                "injection_tasks_utility_results": {},
            }
        else:
            attacked = benchmark_suite_with_injections(
                pipeline,
                suite,
                attack=attack,
                logdir=logdir,
                force_rerun=force_rerun,
                user_tasks=user_tasks,
                injection_tasks=injection_tasks,
                verbose=False,
                benchmark_version=benchmark_version,
            )
    attacked_util = {
        f"{ut}|{ij}": bool(v) for (ut, ij), v in attacked["utility_results"].items()
    }
    attacked_sec = {
        f"{ut}|{ij}": bool(v) for (ut, ij), v in attacked["security_results"].items()
    }

    return SuiteSummary(
        suite=suite_name,
        mode=mode,
        llm=llm,
        llm_mode=llm_mode,
        attack=attack_name,
        benchmark_version=benchmark_version,
        benign_utility=_mean(list(benign_utility_map.values())),
        attacked_utility=_mean(list(attacked_util.values())),
        attack_success_rate=_mean(list(attacked_sec.values())),
        n_benign=len(benign_utility_map),
        n_attacked=len(attacked_sec),
        benign_per_task=benign_utility_map,
        attacked_utility_per_task=attacked_util,
        attacked_security_per_task=attacked_sec,
    )


def _llm_model_tag(
    llm: str,
    *,
    openai_model: str | None,
    anthropic_model: str | None,
) -> str:
    """Return a substring that AgentDojo's ``MODEL_NAMES`` will recognize.

    AgentDojo's ``ImportantInstructionsAttack`` looks up the model name by
    substring match against ``pipeline.name``; absent that we cannot
    construct the attack. ``scripted`` maps to ``local``.

    For ``--llm openai`` against Azure OpenAI, the deployment name
    (e.g. ``gpt-4.1-mini``) is not in AgentDojo's ``MODEL_NAMES``, so we
    substitute a known-recognized substring (``gpt-4o-mini-2024-07-18``).
    The real API call still uses the deployment name via the Azure
    client — this rewrite only affects the human-readable pipeline
    identifier used by the attack scaffold.
    """
    if llm == "scripted":
        return "local"
    if llm == "openai":
        # When the Azure fallback path will be taken at LLM construction
        # time (no OPENAI_API_KEY but Azure vars set), AgentDojo won't
        # recognize the Azure deployment name; force a known canonical
        # substring so ``ImportantInstructionsAttack`` can resolve the
        # model family. The precedence here MUST match
        # ``_build_llm_element``'s OpenAI vs Azure decision.
        openai_key = os.environ.get("OPENAI_API_KEY")
        azure_endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
        azure_key = os.environ.get("AZURE_OPENAI_API_KEY")
        will_use_azure = not openai_key and azure_endpoint and azure_key
        if will_use_azure:
            return "gpt-4o-mini-2024-07-18"
        return openai_model or "gpt-4o-mini-2024-07-18"
    if llm == "anthropic":
        return anthropic_model or "claude-3-haiku-20240307"
    return llm


def _build_llm_element(
    llm: str,
    *,
    suite,
    llm_mode: str = "marker_compliant",
    openai_model: str | None,
    anthropic_model: str | None,
) -> BasePipelineElement:
    if llm == "scripted":
        return ScriptedLLM(suite, llm_mode=llm_mode)
    if llm == "openai":
        from agentdojo.agent_pipeline.llms.openai_llm import OpenAILLM

        # Provider precedence when ``--llm openai`` is selected:
        #
        #   1. If ``OPENAI_API_KEY`` is set, use the direct OpenAI client.
        #      The user (or workflow) explicitly opted into OpenAI.
        #   2. Otherwise, if both ``AZURE_OPENAI_ENDPOINT`` and
        #      ``AZURE_OPENAI_API_KEY`` are set, fall back to Azure OpenAI
        #      via the ``AzureOpenAI`` client (API-compatible with
        #      AgentDojo's ``OpenAILLM``, which only needs
        #      ``client.chat.completions.create(model=...)``).
        #   3. Otherwise raise — no provider is configured.
        openai_key = os.environ.get("OPENAI_API_KEY")
        azure_endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
        azure_key = os.environ.get("AZURE_OPENAI_API_KEY")
        if not openai_key and azure_endpoint and azure_key:
            from openai import AzureOpenAI

            # Allow ``--openai-model`` to double as the Azure deployment
            # name when callers rely on the documented Azure-only flow but
            # have not exported ``AZURE_OPENAI_DEPLOYMENT`` separately.
            azure_deployment = os.environ.get("AZURE_OPENAI_DEPLOYMENT")
            deployment = azure_deployment or openai_model
            if not deployment:
                raise ValueError(
                    "--openai-model or AZURE_OPENAI_DEPLOYMENT required "
                    "when using Azure OpenAI"
                )
            api_version = (
                os.environ.get("AZURE_OPENAI_API_VERSION")
                or "2024-12-01-preview"
            )
            client = AzureOpenAI(
                azure_endpoint=azure_endpoint,
                api_key=azure_key,
                api_version=api_version,
            )
            # On Azure the ``model`` parameter is the deployment name.
            return OpenAILLM(client, deployment)

        if not openai_model:
            raise ValueError("--openai-model required when --llm=openai")
        from openai import OpenAI

        return OpenAILLM(OpenAI(), openai_model)
    if llm == "anthropic":
        if not anthropic_model:
            raise ValueError("--anthropic-model required when --llm=anthropic")
        from agentdojo.agent_pipeline.llms.anthropic_llm import AnthropicLLM
        from anthropic import Anthropic

        return AnthropicLLM(Anthropic(), anthropic_model)
    raise ValueError(f"unknown --llm {llm!r}")


# ---------------------------------------------------------------------------
# Output helpers
# ---------------------------------------------------------------------------


def summary_markdown(summaries: Sequence[SuiteSummary]) -> str:
    """Render a list of summaries as a GitHub-flavored Markdown table."""
    lines = [
        "| suite | mode | llm | llm_mode | attack | benign util | attacked util | ASR | n_benign | n_attacked |",
        "|---|---|---|---|---|---:|---:|---:|---:|---:|",
    ]
    for s in summaries:
        lines.append(
            f"| {s.suite} | {s.mode} | {s.llm} | {s.llm_mode} | {s.attack} "
            f"| {s.benign_utility:.2f} | {s.attacked_utility:.2f} "
            f"| {s.attack_success_rate:.2f} | {s.n_benign} | {s.n_attacked} |"
        )
    return "\n".join(lines)


def write_summary_json(summary: SuiteSummary, out_dir: Path) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    path = (
        out_dir
        / f"{summary.suite}-{summary.mode}-{summary.llm}-{summary.llm_mode}-{summary.attack}.json"
    )
    path.write_text(
        json.dumps(summary.to_json(), indent=2, sort_keys=True),
        encoding="utf-8",
    )
    return path


# ---------------------------------------------------------------------------
# CLI (used by the nightly job)
# ---------------------------------------------------------------------------


def _main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Run AgentDojo through Agent Shield (raw vs shielded)."
    )
    parser.add_argument(
        "--suite",
        action="append",
        default=[],
        choices=["banking", "slack", "workspace", "travel"],
        help="Suites to run (repeatable). Default: banking only.",
    )
    parser.add_argument(
        "--mode",
        action="append",
        default=[],
        choices=["raw", "shielded"],
        help="Modes to run (repeatable). Default: both.",
    )
    parser.add_argument(
        "--llm",
        default="scripted",
        choices=["scripted", "openai", "anthropic"],
    )
    parser.add_argument(
        "--llm-mode",
        action="append",
        default=[],
        choices=["marker_compliant", "attacker_puppet"],
        help=(
            "ScriptedLLM mode (repeatable). Default: marker_compliant only. "
            "Use attacker_puppet to test the Stage-2 latch against worst-"
            "case 'LLM is already compromised' attacks."
        ),
    )
    parser.add_argument("--openai-model", default=os.environ.get("OPENAI_MODEL"))
    parser.add_argument("--anthropic-model", default=os.environ.get("ANTHROPIC_MODEL"))
    parser.add_argument(
        "--attack",
        action="append",
        default=[],
        choices=sorted(_SUPPORTED_ATTACKS),
        help=(
            "AgentDojo attack family (repeatable). Default: "
            "important_instructions only. The realistic policy's pattern "
            "bank handles the listed families uniformly."
        ),
    )
    parser.add_argument("--benchmark-version", default="v1.2.2")
    parser.add_argument(
        "--out",
        default="tests/e2e/agentdojo_bench/results",
        help="Directory to write JSON summaries into.",
    )
    parser.add_argument("--user-task", action="append", default=[])
    parser.add_argument("--injection-task", action="append", default=[])
    parser.add_argument("--logdir", default=None)
    args = parser.parse_args(argv)

    suites = args.suite or ["banking"]
    modes = args.mode or ["raw", "shielded"]
    llm_modes = args.llm_mode or ["marker_compliant"]
    attacks = args.attack or ["important_instructions"]
    out_dir = Path(args.out)

    summaries: list[SuiteSummary] = []
    for suite_name in suites:
        for mode in modes:
            for llm_mode in llm_modes:
                for attack_name in attacks:
                    logger.info(
                        "agentdojo: running suite=%s mode=%s llm=%s "
                        "llm_mode=%s attack=%s",
                        suite_name, mode, args.llm, llm_mode, attack_name,
                    )
                    s = run_suite(
                        suite_name=suite_name,
                        mode=mode,
                        llm=args.llm,
                        llm_mode=llm_mode,
                        benchmark_version=args.benchmark_version,
                        user_tasks=args.user_task or None,
                        injection_tasks=args.injection_task or None,
                        attack_name=attack_name,
                        logdir=Path(args.logdir) if args.logdir else None,
                        openai_model=args.openai_model,
                        anthropic_model=args.anthropic_model,
                    )
                    write_summary_json(s, out_dir)
                    summaries.append(s)

    md = summary_markdown(summaries)
    print(md)
    step_summary = os.environ.get("GITHUB_STEP_SUMMARY")
    if step_summary:
        with open(step_summary, "a", encoding="utf-8") as fh:
            fh.write("\n## AgentDojo benchmark\n\n")
            fh.write(md)
            fh.write("\n")
    return 0


if __name__ == "__main__":
    sys.exit(_main())
