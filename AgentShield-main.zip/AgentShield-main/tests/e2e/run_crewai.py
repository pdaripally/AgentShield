"""E2E test runner for the CrewAI adapter .

Parametrised over the shared adapter-scenarios.yaml.  CrewAI tools are
synchronous, so every invocation uses plain ``_run()`` calls.
"""
from __future__ import annotations

import json

import pytest

crewai = pytest.importorskip("crewai")

from crewai.tools import BaseTool

from agent_shield import Runtime, RuntimeBuilder
from agent_shield.adapters._orchestration import current_session
from agent_shield.adapters.crewai import GuardedAgent, protect_tools

from conftest import (
    SpyToolRecord,
    fixture_path,
    load_scenarios,
    make_inline_fixture,
    PII_RESPONSE,
    build_v2_runtime,
)

# ── Capabilities supported by the CrewAI adapter ─────────────────────────
CAPABILITIES = {"guarded_agent"}

# ── Scenario loading ─────────────────────────────────────────────────────
SCENARIOS = load_scenarios(CAPABILITIES)


def _scenario_id(scenario: dict) -> str:
    return scenario["name"]


# ── Spy tool factory ─────────────────────────────────────────────────────


def _make_spy_tool_class(tool_name, spy, response="ok"):
    _spy = spy
    _response = response
    _name = tool_name

    class SpyTool(BaseTool):
        name: str = _name
        description: str = f"Test tool: {_name}"

        def _run(self, **kwargs):
            _spy.record(**kwargs)
            return _response

    return SpyTool()


# ── Helpers ──────────────────────────────────────────────────────────────


def _build_runtime(scenario: dict, tmp_path):
    """Create a Runtime and session from the scenario's fixture config."""
    if "fixture_inline" in scenario:
        config_path = make_inline_fixture(scenario["fixture_inline"], tmp_path)
    else:
        config_path = fixture_path(scenario["fixture"])
    runtime = build_v2_runtime(config_path)
    session = runtime.new_session()
    session.begin_turn()

    setup = scenario.get("setup", {})
    for var_name, var_value in setup.get("variables", {}).items():
        session.set_variable(var_name, var_value)

    return runtime, session


def _tool_response(tool_spec: dict) -> str:
    """Determine the response string for a tool spec."""
    if tool_spec.get("response_pii"):
        return PII_RESPONSE
    if "response_sensitivity" in tool_spec:
        return json.dumps({"sensitivity": tool_spec["response_sensitivity"]})
    return tool_spec.get("response", "ok")


def _check_tool_expected(result, spy: SpyToolRecord, expected: dict) -> None:
    """Assert tool invocation expectations."""
    result_str = str(result)

    if "tool_invoked" in expected:
        if expected["tool_invoked"]:
            assert spy.was_called, (
                f"Tool should have been invoked but wasn't. Result: {result_str}"
            )
        else:
            assert not spy.was_called, "Tool should NOT have been invoked but was."

    if "result" in expected:
        assert result_str == expected["result"], (
            f"Expected result {expected['result']!r}, got {result_str!r}"
        )

    if "result_contains" in expected:
        assert expected["result_contains"] in result_str, (
            f"Expected result to contain {expected['result_contains']!r}, "
            f"got {result_str!r}"
        )

    if "result_contains_lower" in expected:
        assert expected["result_contains_lower"] in result_str.lower(), (
            f"Expected result (lowered) to contain "
            f"{expected['result_contains_lower']!r}, got {result_str.lower()!r}"
        )

    if "result_not_contains" in expected:
        assert expected["result_not_contains"] not in result_str, (
            f"Expected result NOT to contain {expected['result_not_contains']!r}, "
            f"got {result_str!r}"
        )


# ── Test ─────────────────────────────────────────────────────────────────


@pytest.mark.parametrize("scenario", SCENARIOS, ids=_scenario_id)
def test_scenario(scenario: dict, tmp_path) -> None:
    """Run a single adapter-scenario against the CrewAI adapter."""
    runtime, session = _build_runtime(scenario, tmp_path)
    expected = scenario.get("expected", {})

    token = current_session.set(session)
    try:
        # ── Type 1: Simple tool invocation ────────────────────────────
        if "tool" in scenario:
            tool_spec = scenario["tool"]
            spy = SpyToolRecord()
            response = _tool_response(tool_spec)
            raw_tool = _make_spy_tool_class(tool_spec["name"], spy, response)

            protected = protect_tools(runtime, [raw_tool])
            result = protected[0]._run()

            _check_tool_expected(result, spy, expected)
            return

        # ── Type 2: Input validation ──────────────────────────────────
        if "validate_input" in scenario:
            text = scenario["validate_input"]
            vr = session.validate_input(text)

            if "allowed" in expected:
                assert vr.allowed == expected["allowed"], (
                    f"Expected allowed={expected['allowed']}, got {vr.allowed} "
                    f"(action={vr.action}, reason={vr.reason})"
                )
            if "action" in expected:
                assert vr.action == expected["action"], (
                    f"Expected action={expected['action']!r}, got {vr.action!r}"
                )
            return

        # ── Type 3: Steps (sequential actions) ────────────────────────
        if "steps" in scenario:
            _run_steps(runtime, session, scenario["steps"])
            return

        # ── Type 4: GuardedAgent ──────────────────────────────────────
        if "guarded_agent" in scenario:

            class MockAgent:
                role = "test"
                goal = "test"
                backstory = "test"

            guarded = GuardedAgent(runtime, MockAgent())
            input_text = scenario["guarded_agent"]["input"]
            result = guarded.validate_input(input_text)

            if expected.get("agent_invoked") is False:
                assert result is not None, (
                    "Expected input to be blocked but it was allowed"
                )
                if "result_contains" in expected:
                    assert expected["result_contains"] in result, (
                        f"Expected result to contain "
                        f"{expected['result_contains']!r}, got {result!r}"
                    )
            else:
                assert result is None, (
                    f"Expected input to be allowed but got: {result!r}"
                )
            return

        pytest.fail(f"Unrecognised scenario type: {scenario['name']}")
    finally:
        current_session.reset(token)
        try:
            session.end_turn()
        except Exception:  # noqa: BLE001
            pass


def _run_steps(runtime: Runtime, session, steps: list[dict]) -> None:
    """Execute a sequence of step actions against the runtime/session."""
    for idx, step in enumerate(steps, start=1):
        action = step["action"]

        if action == "invoke_tool":
            tool_spec = step["tool"]
            spy = SpyToolRecord()
            response = _tool_response(tool_spec)
            raw_tool = _make_spy_tool_class(tool_spec["name"], spy, response)

            protected = protect_tools(runtime, [raw_tool])
            result = protected[0]._run()

            if "expected" in step:
                _check_tool_expected(result, spy, step["expected"])

        elif action == "check_variable":
            var_name = step["variable"]
            expected_value = step["expected_value"]
            actual = session.resolve_variable(var_name)
            assert actual == expected_value, (
                f"Variable {var_name!r}: expected {expected_value!r}, "
                f"got {actual!r}"
            )

        elif action == "set_variable":
            session.set_variable(step["variable"], step["value"])

        elif action == "validate_tool_call":
            tool_name = step["tool_name"]
            outcome = session.validate_tool_call(tool_name, tool_call_id=f"call_{idx}")
            if "expected" in step:
                exp = step["expected"]
                if "allowed" in exp:
                    assert outcome.verdict.allowed == exp["allowed"], (
                        f"validate_tool_call({tool_name!r}): "
                        f"expected allowed={exp['allowed']}, got {outcome.verdict.allowed}"
                    )

        elif action == "reset_variable":
            session.reset_variable(step["variable"])

        else:
            pytest.fail(f"Unknown step action: {action!r}")
