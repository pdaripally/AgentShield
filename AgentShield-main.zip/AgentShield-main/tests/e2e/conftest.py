"""Shared infrastructure for adapter e2e runners.

Provides:
  - ``REPO_ROOT``, ``FIXTURES_DIR``, ``fixture_path()``
  - ``SpyToolRecord``
  - ``load_scenarios()``
  - ``make_inline_fixture()``
  - ``make_langchain_mock_llm()``  (ScriptedLLM)
  - ``PII_RESPONSE`` constant
  - pytest markers: ``integration``, ``tier1``
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any, Iterator, Optional, Sequence

# Ensure the migration repo's agent_shield (with the sub-tree) wins
# over any pip-installed agent_shield.pth pointing elsewhere.
_REPO_ROOT = Path(__file__).resolve().parent.parent.parent
_SDK_PYTHON = _REPO_ROOT / "sdk" / "python"
if _SDK_PYTHON.is_dir():
    sys.path.insert(0, str(_SDK_PYTHON))

import pytest
import yaml

# ── Path helpers ────────────────────────────────────────────────────────────

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
FIXTURES_DIR = REPO_ROOT / "tests" / "fixtures"
SCENARIOS_PATH = Path(__file__).resolve().parent.parent / "cases" / "adapter-scenarios.yaml"


def fixture_path(*parts: str) -> str:
    """Resolve a path relative to tests/fixtures/ and return as string."""
    path = FIXTURES_DIR.joinpath(*parts)
    if not path.exists():
        raise FileNotFoundError(f"Fixture not found: {path}")
    return str(path)


# ── Spy Tool infrastructure ────────────────────────────────────────────────


class SpyToolRecord:
    """Records invocations of a spy tool for assertion in tests."""

    def __init__(self) -> None:
        self.call_count: int = 0
        self.calls: list[dict[str, Any]] = []

    def record(self, **kwargs: Any) -> None:
        self.call_count += 1
        self.calls.append(kwargs)

    @property
    def was_called(self) -> bool:
        return self.call_count > 0

    @property
    def last_call(self) -> dict[str, Any] | None:
        return self.calls[-1] if self.calls else None

    def reset(self) -> None:
        self.call_count = 0
        self.calls.clear()


# ── PII response constant ─────────────────────────────────────────────────

PII_RESPONSE = json.dumps({
    "customer_name": "Jane Doe",
    "ssn": "123-45-6789",
    "balance": 50000,
})


# ── Scenario loader ───────────────────────────────────────────────────────


def load_scenarios(capabilities: set[str] | None = None) -> list[dict]:
    """Load adapter-scenarios.yaml and filter by adapter capabilities.

    Scenarios with a ``capabilities`` key are only returned if the adapter
    declares support for all required capabilities.
    """
    with open(SCENARIOS_PATH) as f:
        data = yaml.safe_load(f)

    caps = capabilities or set()
    selected = []
    for s in data["scenarios"]:
        required = set(s.get("capabilities", []))
        if required and not required.issubset(caps):
            continue
        selected.append(s)
    return selected


# ── Inline fixture builder ─────────────────────────────────────────────────

_inline_counter = 0


def make_inline_fixture(spec: dict, tmp_path: Path) -> str:
    """Build a guardrails YAML file from an inline scenario spec.

    The spec keys are passed through to the schema:

    * ``name`` — becomes ``metadata.name``
    * ``resources`` — list of tool entries placed under ``resources.tools``
      (each tool may include ``state_validation`` policies via the
      ``guard_policies`` top-level key on the spec)
    * ``variables`` — list of variable declarations
    * ``state_validation`` — full ``state_validation`` block (passed through)
    * ``input_validation`` / ``tool_execution_validation`` /
      ``post_tool_validation`` / ``output_validation`` — any of which are
      passed through verbatim
    """
    global _inline_counter
    _inline_counter += 1

    config: dict[str, Any] = {
        "metadata": {
            "name": spec["name"],
            "version": "2.0.0",
            "agent_shield_version": "2.0",
        },
        "objective": {"goal": ["E2E test"], "forbidden": []},
    }

    if "resources" in spec:
        config["resources"] = {"tools": spec["resources"]}

    if "variables" in spec:
        config["variables"] = spec["variables"]

    for passthrough in (
        "configurations",
        "state_validation",
        "input_validation",
        "tool_execution_validation",
        "post_tool_validation",
        "output_validation",
    ):
        if passthrough in spec:
            config[passthrough] = spec[passthrough]

    path = tmp_path / f"{spec['name']}-{_inline_counter}.guardrails.yaml"
    path.write_text(yaml.dump(config, default_flow_style=False), encoding="utf-8")
    return str(path)


# ── LangChain Mock LLM ─────────────────────────────────────────────────────


def make_langchain_mock_llm(responses: list[dict[str, Any]]):
    """Create a deterministic LangChain BaseChatModel that returns scripted responses.

    Each entry in ``responses`` is a dict with either:
      - ``{"content": "plain text response"}`` — returns a text AIMessage
      - ``{"tool_calls": [{"name": "...", "args": {...}}]}`` — returns tool call(s)
      - ``{"content": "...", "tool_calls": [...]}`` — both

    Responses are consumed in order. If the sequence is exhausted, returns
    a final "No more scripted responses" message.
    """
    from langchain_core.language_models.chat_models import BaseChatModel
    from langchain_core.messages import AIMessage, BaseMessage
    from langchain_core.outputs import ChatGeneration, ChatResult

    class ScriptedLLM(BaseChatModel):
        """Deterministic LLM that replays scripted responses."""

        responses: list[dict[str, Any]] = []
        _call_index: int = 0
        _bound_tools: list[Any] = []

        model_config = {"arbitrary_types_allowed": True}

        @property
        def _llm_type(self) -> str:
            return "scripted-mock"

        def bind_tools(
            self,
            tools: Sequence[Any],
            **kwargs: Any,
        ) -> "ScriptedLLM":
            bound = ScriptedLLM(responses=self.responses)
            bound._call_index = self._call_index
            bound._bound_tools = list(tools)
            return bound

        def _generate(
            self,
            messages: list[BaseMessage],
            stop: Optional[list[str]] = None,
            run_manager: Any = None,
            **kwargs: Any,
        ) -> ChatResult:
            if self._call_index >= len(self.responses):
                msg = AIMessage(content="No more scripted responses.")
                return ChatResult(generations=[ChatGeneration(message=msg)])

            spec = self.responses[self._call_index]
            self._call_index += 1

            content = spec.get("content", "")
            tool_calls = spec.get("tool_calls", [])

            lc_tool_calls = []
            for i, tc in enumerate(tool_calls):
                lc_tool_calls.append({
                    "name": tc["name"],
                    "args": tc.get("args", {}),
                    "id": tc.get("id", f"call_{i}"),
                    "type": "tool_call",
                })

            msg = AIMessage(
                content=content,
                tool_calls=lc_tool_calls,
            )
            return ChatResult(generations=[ChatGeneration(message=msg)])

        @property
        def _identifying_params(self) -> dict[str, Any]:
            return {"responses": self.responses}

    return ScriptedLLM(responses=responses)


# ── Common pytest markers ──────────────────────────────────────────────────

integration = pytest.mark.integration
tier1 = pytest.mark.tier1


# ── runtime helpers ─────────────────────────────────────────────────────


def make_allow_all_llm_caller():
    """Return a LLM caller that always returns ``{"decision": "allow"}``.

    Used by adapter runners so Stage-1/3/5 LLM-backed guard policies in the
    shared fixtures don't block tools that the test scenarios expect to
    succeed.  Real e2e runs with framework LLMs should override this.
    """

    def _call(configuration_id: Optional[str], prompt: str) -> dict:
        return {"decision": "allow"}

    return _call


def build_v2_runtime(yaml_path: str, *, allow_all_llm: bool = True):
    """Build a :class:`Runtime` from a guardrails YAML.

    Registers a permissive LLM caller by default so tool-execution and
    output-validation Stage-3/5 LLM policies allow tools through during
    smoke tests.  Pass ``allow_all_llm=False`` to opt out.
    """
    from agent_shield import RuntimeBuilder  # local import: optional dep

    builder = RuntimeBuilder.from_yaml(yaml_path)
    if allow_all_llm:
        builder = builder.register_llm_caller(make_allow_all_llm_caller())
    return builder.build()
