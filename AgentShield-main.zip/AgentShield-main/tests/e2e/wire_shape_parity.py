"""Cross-language wire-shape conformance test.

Exercises the canonical Rust-core parsers via every binding's public
surface and asserts they produce identical typed shapes for a battery
of canonical inputs. This is the test that would have caught the
PyLlmCaller silent fail-closed bug (commit 31ae2c4) before it shipped.

Run with:
    pytest -q tests/e2e/wire_shape_parity.py

Only the Python binding is exercised end-to-end here; for Node/.NET,
the same canonical inputs are duplicated in their own native test
suites — keeping every binding honest against the same matrix.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import pytest

# ── Ensure the local sdk/python wins over any installed copy ────────
_REPO_ROOT = Path(__file__).resolve().parent.parent.parent
_SDK_PYTHON = _REPO_ROOT / "sdk" / "python"
if _SDK_PYTHON.is_dir():
    sys.path.insert(0, str(_SDK_PYTHON))

import agent_shield  # noqa: E402  (after sys.path mutation)
from agent_shield import _native  # noqa: E402


# ── Canonical input matrix ──────────────────────────────────────────

# Every entry is `(label, host_return_value, expected_folded_decision)`.
# `host_return_value` is what the host's LLM caller returns to the
# binding's bridge — string, dict, or anything in between. The folded
# decision is what the runtime's gating logic consumes.
LLM_INPUTS: list[tuple[str, Any, str]] = [
    # Bare-word strings — every case the language SDKs encountered in
    # the wild before the central parser landed.
    ("bare_lowercase_allow", "allow", "allow"),
    ("bare_uppercase_block", "BLOCK", "block"),
    ("bare_titlecase_allow", "Allow", "allow"),
    ("bare_with_whitespace", "  allow  \n", "allow"),
    ("bare_pass_alias", "pass", "allow"),
    ("bare_fail_alias", "fail", "block"),
    # JSON envelope strings — the OpenAI / Anthropic / LangChain default.
    # The exact shape that triggered the silent fail-closed bug.
    ("json_envelope_uppercase_decision", '{"decision": "ALLOW"}', "allow"),
    ("json_envelope_lowercase_decision", '{"decision": "block"}', "block"),
    (
        "json_envelope_with_reason",
        '{"decision": "block", "reason": "PII detected", "confidence": 0.9}',
        "block",
    ),
    # JSON shape with truthy bool override (§12.9.3 ¶2)
    (
        "json_truthy_bool_overrides_allow",
        '{"decision": "allow", "is_jailbreak": true}',
        "block",
    ),
    # Python dict shape — what bindings used to require historically.
    ("dict_allow", {"decision": "allow"}, "allow"),
    ("dict_block_with_categories", {"decision": "block", "categories": ["pii"]}, "block"),
    (
        "dict_with_top_level_bool",
        {"decision": "allow", "contains_pii": True},
        "block",
    ),
    # Fail-closed inputs — every binding MUST agree these are Block.
    ("empty_string", "", "block"),
    ("whitespace_only", "   ", "block"),
    ("malformed_json", "not JSON", "block"),
    ("unknown_decision", '{"decision": "maybe"}', "block"),
    ("missing_decision", '{"confidence": 0.9}', "block"),
    ("array_root", "[1, 2, 3]", "block"),
    ("empty_dict", {}, "block"),
]


def _make_runtime_with_llm(callback) -> Any:
    """Build a runtime that gates Stage-3 on the given LLM callback."""
    yaml = """
metadata: {name: parity, version: "0.1.0", agent_shield_version: "2.0"}
objective: {goal: ["x"], forbidden: ["y"]}
resources:
  tools:
    - {name: t, description: t, permission: read_only}
configurations:
  - id: gate
    type: llm
    default: true
    provider: test
    model: test-model
    api_key_env: TEST_API_KEY
tool_execution_validation:
  configuration: gate
  guard_policies:
    - name: gate_tool
      applies_to:
        tools: ["t"]
      evaluate_when:
        - llm:
            configuration: gate
            prompt: "ignored"
          reason: "blocked"
      action: block
"""
    builder = _native.RuntimeBuilder.from_yaml_strings([yaml])
    builder.register_llm_caller(callback)
    return builder.build()


@pytest.mark.parametrize("label, host_return, expected", LLM_INPUTS, ids=lambda x: x if isinstance(x, str) else None)
def test_llm_parser_parity_python(label: str, host_return: Any, expected: str) -> None:
    """Same canonical input → same folded decision in Python binding."""

    def cb(_cfg, _prompt):
        return host_return

    rt = _make_runtime_with_llm(cb)
    session = rt.new_session()
    verdict, _params = session.validate_tool_call("t", {}, "call_1")
    actual = "allow" if verdict["allowed"] else "block"
    assert actual == expected, (
        f"input {label!r}: expected folded decision {expected!r}, got {actual!r}; "
        f"host returned {host_return!r}"
    )


def test_unit_parser_handles_full_matrix() -> None:
    """Direct unit test against the canonical Rust parser via FFI.

    Catches any divergence between the Python bridge and the canonical
    Rust parser that the runtime gating tests above might mask.
    """
    for label, host_return, expected in LLM_INPUTS:

        def cb(_cfg, _prompt, _hr=host_return):
            return _hr

        rt = _make_runtime_with_llm(cb)
        session = rt.new_session()
        verdict, _ = session.validate_tool_call("t", {}, "call_1")
        actual = "allow" if verdict["allowed"] else "block"
        assert actual == expected, f"input {label!r}: {host_return!r} → {actual} (want {expected})"


def test_resolver_envelope_parity_python() -> None:
    """Resolver bridge agrees with the canonical wire-shape parser.

    Covers JSON-string returns, dict returns, and the fail-closed
    shapes that previously had to be hand-rolled per binding. Uses
    `kind: agent` because that is the canonical host-callback resolver
    under the refactored design (`kind: human` no longer goes through
    a callback — it dispatches through the canonical
    `agent_shield.ask_human` MCP tool path).

    We assert at the runtime-gating level: an `allow` decision with
    `value: true` opens the gate; everything else keeps the gate
    closed (per §11.3 + §9.4 fail-closed semantics — a `deny`,
    `cancelled`, or malformed envelope all leave the variable unset
    or denied, and the predicate `gate == true` then evaluates to
    false-via-null per the spec's null-propagation rule).
    """
    cases: list[tuple[str, Any, str]] = [
        # `allow` with value=True opens the gate — proves the bridge
        # routes through wire_shapes successfully.
        ("dict_allow_with_value", {"decision": "allow", "value": True}, "allow"),
        # JSON-string return shape (the OpenAI/Anthropic default) —
        # the bug class fix proves these now work.
        (
            "json_string_allow_with_value",
            '{"decision": "allow", "value": true}',
            "allow",
        ),
        # Allow but no value: variable stays unset → predicate fails.
        ("dict_allow_no_value", {"decision": "allow"}, "deny"),
        # Deny → variable.@status = denied → predicate fails.
        ("dict_deny", {"decision": "deny"}, "deny"),
        ("dict_cancelled", {"decision": "cancelled"}, "deny"),
        # Fail-closed cases.
        ("malformed_json_string", "not JSON", "deny"),
        ("missing_decision", {"value": True}, "deny"),
        ("none_return", None, "deny"),
        ("list_return", [1, 2, 3], "deny"),
        ("string_random", "garbage", "deny"),
    ]

    yaml_template = """
metadata: {name: rparity, version: "0.1.0", agent_shield_version: "2.0"}
objective: {goal: ["x"], forbidden: ["y"]}
resources:
  tools:
    - {name: t, description: t, permission: read_only}
variables:
  - name: gate
    type: boolean
    description: "Approval gate."
    on_demand_by:
      kind: agent
      prompt: "approve?"
    lifetime: per_call
tool_execution_validation:
  guard_policies:
    - name: gate_tool
      applies_to:
        tools: ["t"]
      evaluate_when:
        - expression: "gate == true"
          reason: "blocked"
      action: block
"""

    for label, host_return, expected in cases:
        def cb(_req, _hr=host_return):
            return _hr

        builder = _native.RuntimeBuilder.from_yaml_strings([yaml_template])
        builder.register_agent_resolver(cb)
        rt = builder.build()
        session = rt.new_session()
        verdict, _ = session.validate_tool_call("t", {}, "call_1")
        actual = "allow" if verdict["allowed"] else "deny"
        assert actual == expected, (
            f"resolver case {label!r}: {host_return!r} → {actual} (want {expected})"
        )

    for label, host_return, expected in cases:
        def cb(_req, _hr=host_return):
            return _hr

        builder = _native.RuntimeBuilder.from_yaml_strings([yaml_template])
        builder.register_agent_resolver(cb)
        rt = builder.build()
        session = rt.new_session()
        verdict, _ = session.validate_tool_call("t", {}, "call_1")
        actual = "allow" if verdict["allowed"] else "deny"
        assert actual == expected, (
            f"resolver case {label!r}: {host_return!r} → {actual} (want {expected})"
        )


def test_pyllmcaller_bug_class_cannot_recur() -> None:
    """The exact shape that triggered commit 31ae2c4's silent fail-closed
    bug now flows through the canonical parser unchanged."""
    # Before 31ae2c4: bare-word + dict paths worked, JSON-string didn't.
    # After this refactor: every shape funnels through one parser.
    for raw in (
        '{"decision": "ALLOW"}',  # the literal bug-trigger shape
        '{"decision": "Allow", "confidence": 0.95}',
        '"allow"',  # double-encoded bare word
    ):
        def cb(_cfg, _prompt, _r=raw):
            return _r

        rt = _make_runtime_with_llm(cb)
        session = rt.new_session()
        verdict, _ = session.validate_tool_call("t", {}, "call_1")
        assert verdict["allowed"], (
            f"PyLlmCaller bug class regressed: host returned {raw!r} "
            f"but runtime did not honor the allow"
        )

    # And the inverse: malformed input MUST still fail closed.
    for raw in ("garbage {{{", "", "   ", "[1,2,3]", '{"no_decision": true}'):
        def cb(_cfg, _prompt, _r=raw):
            return _r

        rt = _make_runtime_with_llm(cb)
        session = rt.new_session()
        verdict, _ = session.validate_tool_call("t", {}, "call_1")
        assert not verdict["allowed"], (
            f"fail-closed regressed: host returned {raw!r} and runtime allowed"
        )
