/**
 * Shared helpers for Node.js adapter e2e runners.
 *
 * Runtimes are built via `RuntimeBuilder.fromYaml(...)`, sessions are
 * explicit, and the runtime verbs (`setVariable`, `validateInput`,
 * `validateToolCall`, `validateToolOutput`, `recordToolSuccess`, etc.)
 * are exercised directly.
 *
 * The framework-shaped adapters (anthropic / openai / langchain /
 * vercel-ai / copilot-sdk) are not exposed from the Node SDK, so each
 * adapter test runner emulates the framework's call shape inline on
 * top of the runtime session API. The behavioral contract — tool
 * gating, output redaction, the "[GUARDRAIL …]" sentinel string for
 * blocked invocations — is what the shared `adapter-scenarios.yaml`
 * cases verify.
 */
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { fileURLToPath } from "node:url";
import { createRequire } from "node:module";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const REPO_ROOT = path.resolve(__dirname, "../../..");
export const FIXTURES_DIR = path.join(REPO_ROOT, "tests", "fixtures");
export const SCENARIOS_PATH = path.join(__dirname, "..", "cases", "adapter-scenarios.yaml");
const SDK_DIR = path.join(REPO_ROOT, "sdk", "node");

// Resolve yaml from the SDK's node_modules.
const sdkRequire = createRequire(path.join(SDK_DIR, "package.json"));
const YAML = sdkRequire("yaml");

// ── SDK imports — SDK facade ──────────────────────────────────────────

const sdkPath = path.join(SDK_DIR, "index.js");
const sdk = await import(sdkPath);
export const { RuntimeBuilder, Runtime, Session, StreamingGuard } = sdk;

// ── Path helpers ─────────────────────────────────────────────────────

/**
 * Resolve a fixture path. Returns null when the fixture is not present
 * (P16a periodically reorganizes tests/fixtures/) so callers can skip
 * gracefully rather than crash on import-time fixture lookups.
 */
export function fixturePath(...parts) {
  const p = path.join(FIXTURES_DIR, ...parts);
  return fs.existsSync(p) ? p : null;
}

export function fixturePathRequired(...parts) {
  const p = fixturePath(...parts);
  if (p == null) throw new Error(`Fixture not found: ${parts.join("/")}`);
  return p;
}

// ── Scenario loading ─────────────────────────────────────────────────

export function loadScenarios(capabilities) {
  const content = fs.readFileSync(SCENARIOS_PATH, "utf-8");
  const data = YAML.parse(content);
  const caps = capabilities || new Set();
  return data.scenarios.filter((s) => {
    const required = new Set(s.capabilities || []);
    if (required.size === 0) return true;
    for (const r of required) {
      if (!caps.has(r)) return false;
    }
    return true;
  });
}

// ── PII response constant ────────────────────────────────────────────

export const PII_RESPONSE = JSON.stringify({
  customer_name: "Jane Doe",
  ssn: "123-45-6789",
  balance: 50000,
});

// ── Spy tool infrastructure ──────────────────────────────────────────

export class SpyTool {
  constructor() {
    this.callCount = 0;
    this.calls = [];
  }
  record(args) {
    this.callCount++;
    this.calls.push(args);
  }
  get wasCalled() {
    return this.callCount > 0;
  }
  reset() {
    this.callCount = 0;
    this.calls = [];
  }
}

// ── Tool response resolution ─────────────────────────────────────────

export function toolResponse(toolSpec) {
  if (toolSpec.response_pii) return PII_RESPONSE;
  if (toolSpec.response_sensitivity != null) {
    return JSON.stringify({ data_sensitivity: toolSpec.response_sensitivity });
  }
  return toolSpec.response || "ok";
}

// ── Inline fixture builder () ───────────────────────────────

let inlineCounter = 0;

export function makeInlineFixture(spec) {
  inlineCounter++;
  const config = {
    metadata: {
      name: spec.name,
      version: "1.0.0",
      agent_shield_version: "1.0",
    },
    objective: { goal: ["E2E test"], forbidden: [] },
  };
  // Translate v1 vocabulary surfaced by `adapter-scenarios.yaml` into :
  //   - resources[].action      → resources[].permission
  //   - resources[].requires[]  → top-level guard_policies[]
  //   - attributes              → variables
  // The scenarios YAML still uses v1 keywords for ergonomic reasons (it
  // is shared with the Python runner which P16b is converting); translate
  // at fixture-build time so we don't have to mutate the shared file.
  if (spec.resources) {
    const tools = [];
    const guardPolicies = [];
    for (const r of spec.resources) {
      const out = { ...r };
      if ("action" in out && !("permission" in out)) {
        //         // splits this into the spec'd permission tier. Map the legacy
        // 'allow' to the closest variant — read-only — which is the
        // most permissive non-destructive permission.
        const v2Permission =
          out.action === "allow" ? "read_only" : out.action;
        out.permission = v2Permission;
        delete out.action;
      }
      if (Array.isArray(out.requires)) {
        let i = 0;
        for (const req of out.requires) {
          // Legacy form: { allowed_when, else, reason }. Translate to canonical
          // guard policy: block when allowed_when is false.
          const expr = req.allowed_when ?? req.expression;
          if (typeof expr === "string") {
            guardPolicies.push({
              name: `${out.name}_requires_${i++}`,
              applies_to: { tools: [out.name] },
              evaluate_when: [
                { expression: `not (${expr})`, reason: req.reason ?? "" },
              ],
              action: req.else ?? "block",
            });
          }
        }
        delete out.requires;
      }
      tools.push(out);
    }
    config.resources = { tools };
    if (guardPolicies.length > 0) {
      // Tool-level requires gate the *state* before tool execution; the spec
      // exposes this surface under state_validation.guard_policies.
      config.state_validation = { guard_policies: guardPolicies };
    }
  }
  if (spec.attributes) config.variables = spec.attributes;
  if (spec.variables) config.variables = spec.variables;

  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "e2e-node-"));
  const fpath = path.join(
    tmpDir,
    `${spec.name}-${inlineCounter}.guardrails.yaml`,
  );
  fs.writeFileSync(fpath, YAML.stringify(config), "utf-8");
  return {
    path: fpath,
    cleanup: () => fs.rmSync(tmpDir, { recursive: true, force: true }),
  };
}

// ── Runtime + session bootstrap ──────────────────────────────────────

/**
 * Build a runtime + session for `scenario`. Returns:
 *   - `{ runtime, session, cleanup }` on success;
 *   - `null` when the referenced fixture is missing (caller should skip).
 */
export async function buildRuntime(scenario) {
  let yamlPath;
  let cleanup;
  if (scenario.fixture_inline) {
    const f = makeInlineFixture(scenario.fixture_inline);
    yamlPath = f.path;
    cleanup = f.cleanup;
  } else {
    yamlPath = fixturePath(...scenario.fixture.split("/"));
    if (yamlPath == null) return null;
  }

  let runtime;
  try {
    runtime = RuntimeBuilder.fromYaml(yamlPath).build();
  } catch (e) {
    cleanup?.();
    throw e;
  }

  const session = runtime.newSession();
  const setupAttrs = (scenario.setup && scenario.setup.attributes) || {};
  for (const [k, v] of Object.entries(setupAttrs)) {
    session.setVariable(k, v);
  }

  const dispose = () => {
    cleanup?.();
  };
  return { runtime, session, cleanup: dispose };
}

// ── Assertion helpers ────────────────────────────────────────────────

export function assertExpected(result, expected, spy) {
  const resultStr = String(result);
  if (spy != null && "tool_invoked" in expected) {
    if (expected.tool_invoked) {
      if (!spy.wasCalled) throw new Error("Expected tool to be invoked");
    } else {
      if (spy.wasCalled) throw new Error("Expected tool NOT to be invoked");
    }
  }
  if ("result" in expected) {
    if (resultStr !== expected.result) {
      throw new Error(
        `Expected result "${expected.result}", got "${resultStr}"`,
      );
    }
  }
  if ("result_contains" in expected) {
    if (!resultStr.includes(expected.result_contains)) {
      throw new Error(
        `Expected result to contain "${expected.result_contains}", got "${resultStr}"`,
      );
    }
  }
  if ("result_contains_lower" in expected) {
    if (!resultStr.toLowerCase().includes(expected.result_contains_lower)) {
      throw new Error(
        `Expected result.lower to contain "${expected.result_contains_lower}", got "${resultStr.toLowerCase()}"`,
      );
    }
  }
  if ("result_not_contains" in expected) {
    if (resultStr.includes(expected.result_not_contains)) {
      throw new Error(
        `Expected result NOT to contain "${expected.result_not_contains}"`,
      );
    }
  }
}

// ── Framework-shaped tool execution against the runtime session ──────────

/**
 * Run a guarded tool call against a runtime session, mirroring what every
 * framework adapter does:
 *   1. validateToolCall — Stage 2 + 3 gating.
 *   2. If allowed → invoke `handler()` and recordToolSuccess.
 *   3. validateToolOutput — Stage 4 redaction / blocking.
 *   4. Surface either the (possibly redacted) result or a "[GUARDRAIL …]"
 *      sentinel string the shared scenarios assert on.
 *
 * Returns the string the framework adapter would have surfaced to the model.
 */
export async function runGuardedTool(session, toolName, params, handler, spy) {
  await session.beginTurn();
  try {
    const toolCallId = "call-1";
    const callResult = await session.validateToolCall(toolName, params ?? {}, toolCallId);
    if (!callResult.verdict.allowed) {
      return `[GUARDRAIL ${(callResult.verdict.action ?? "block").toUpperCase()}] Tool "${toolName}" blocked: ${callResult.verdict.reason ?? "denied"}`;
    }

    let raw;
    try {
      raw = await handler();
      if (spy) spy.record(params ?? {});
    } catch (e) {
      session.recordToolFailure(toolName, String(e));
      throw e;
    }

    const outResult = await session.validateToolOutput(toolName, raw, toolCallId);
    if (!outResult.verdict.allowed) {
      return `[GUARDRAIL ${(outResult.verdict.action ?? "block").toUpperCase()}] Tool "${toolName}" output blocked: ${outResult.verdict.reason ?? "denied"}`;
    }

    // Stage 4 may have redacted the raw value — surface the post-validation
    // body. recordToolSuccess receives the (possibly transformed) result so
    // downstream stages observe the same view as the model.
    const surfaced = outResult.result ?? raw;
    session.recordToolSuccess(toolName, surfaced);
    return typeof surfaced === "string" ? surfaced : JSON.stringify(surfaced);
  } finally {
    await session.endTurn();
  }
}

/**
 * Read a variable's current value via the read API. Returns
 * `undefined` when the variable is unset / unknown so tests can compare
 * against scalar expected values.
 */
export function readVariable(session, name) {
  const st = session.readVariable(name);
  if (st == null) return undefined;
  if (st.status !== "resolved") return undefined;
  return st.value;
}
