/**
 * E2E runner: Vercel AI SDK-style tool gating against the SDK surface.
 */

import { describe, it, expect } from "vitest";

import {
  loadScenarios,
  SpyTool,
  toolResponse,
  buildRuntime,
  assertExpected,
  readVariable,
  runGuardedTool,
} from "./helpers.mjs";

const CAPABILITIES = new Set();
const scenarios = loadScenarios(CAPABILITIES);

async function runSimpleTool(scenario) {
  const built = await buildRuntime(scenario);
  if (built == null) return;
  const { session, cleanup } = built;
  try {
    const spy = new SpyTool();
    const spec = scenario.tool;
    const response = toolResponse(spec);
    const result = await runGuardedTool(
      session,
      spec.name,
      {},
      async () => response,
      spy,
    );
    assertExpected(result, scenario.expected, spy);
  } finally {
    cleanup?.();
  }
}

async function runValidateInput(scenario) {
  const built = await buildRuntime(scenario);
  if (built == null) return;
  const { session, cleanup } = built;
  try {
    const verdict = await session.validateInput(scenario.validate_input);
    if ("allowed" in scenario.expected) {
      expect(verdict.allowed).toBe(scenario.expected.allowed);
    }
    if ("action" in scenario.expected) {
      expect(verdict.action).toBe(scenario.expected.action);
    }
  } finally {
    cleanup?.();
  }
}

async function runSteps(scenario) {
  const built = await buildRuntime(scenario);
  if (built == null) return;
  const { session, cleanup } = built;
  try {
    for (const [idx, step] of scenario.steps.entries()) {
      const action = step.action;
      if (action === "invoke_tool") {
        const spec = step.tool;
        const response = toolResponse(spec);
        const spy = new SpyTool();
        const result = await runGuardedTool(
          session,
          spec.name,
          {},
          async () => response,
          spy,
        );
        assertExpected(result, step.expected || {}, spy);
      } else if (action === "check_attribute") {
        const value = readVariable(session, step.attribute);
        expect(value).toBe(step.expected_value);
      } else if (action === "set_attribute") {
        session.setVariable(step.attribute, step.value);
      } else if (action === "validate_tool_call") {
        const r = await session.validateToolCall(step.tool_name, {}, `call-${idx + 1}`);
        if (step.expected && "allowed" in step.expected) {
          expect(r.verdict.allowed).toBe(step.expected.allowed);
        }
      } else if (action === "reset") {
        // no-op  — see Anthropic runner
      } else {
        throw new Error(`Unknown step action: ${action}`);
      }
    }
  } finally {
    cleanup?.();
  }
}

describe("Vercel AI-style adapter e2e ", () => {
  for (const scenario of scenarios) {
    it(scenario.name, async () => {
      if ("tool" in scenario) {
        await runSimpleTool(scenario);
      } else if ("validate_input" in scenario) {
        await runValidateInput(scenario);
      } else if ("steps" in scenario) {
        await runSteps(scenario);
      }
    });
  }
});
