/**
 * E2E runner: Copilot SDK-style hooks against the SDK surface.
 *
 * The legacy Copilot SDK adapter exposed `onPreToolUse` / `onPostToolUse`
 * hooks that mapped onto Stage 2/3 + Stage 4 validation respectively.
 * The same gating is achievable with the session API directly;
 * the test runner shape mirrors what `createHooks` would have produced.
 */

import { describe, it, expect } from "vitest";

import {
  loadScenarios,
  SpyTool,
  toolResponse,
  buildRuntime,
  readVariable,
  runGuardedTool,
} from "./helpers.mjs";

// Copilot SDK: tool-level only, no guarded_agent / agent_loop / streaming.
const CAPABILITIES = new Set();
const scenarios = loadScenarios(CAPABILITIES);

// ── Scenario runners ─────────────────────────────────────────────────

async function runSimpleTool(scenario) {
  const built = await buildRuntime(scenario);
  if (built == null) return;
  const { session, cleanup } = built;
  try {
    const spy = new SpyTool();
    const spec = scenario.tool;
    const response = toolResponse(spec);
    const result = await runGuardedTool(
      session,
      spec.name,
      {},
      async () => response,
      spy,
    );

    const expected = scenario.expected;
    if ("tool_invoked" in expected) {
      expect(spy.wasCalled).toBe(!!expected.tool_invoked);
    }
    if ("result" in expected) {
      expect(String(result)).toBe(expected.result);
    }
    if ("result_contains" in expected) {
      expect(String(result)).toContain(expected.result_contains);
    }
    if ("result_contains_lower" in expected) {
      expect(String(result).toLowerCase()).toContain(
        expected.result_contains_lower,
      );
    }
    if ("result_not_contains" in expected) {
      expect(String(result)).not.toContain(expected.result_not_contains);
    }
  } finally {
    cleanup?.();
  }
}

async function runValidateInput(scenario) {
  const built = await buildRuntime(scenario);
  if (built == null) return;
  const { session, cleanup } = built;
  try {
    const verdict = await session.validateInput(scenario.validate_input);
    if ("allowed" in scenario.expected) {
      expect(verdict.allowed).toBe(scenario.expected.allowed);
    }
    if ("action" in scenario.expected) {
      expect(verdict.action).toBe(scenario.expected.action);
    }
  } finally {
    cleanup?.();
  }
}

async function runSteps(scenario) {
  const built = await buildRuntime(scenario);
  if (built == null) return;
  const { session, cleanup } = built;
  try {
    for (const [idx, step] of scenario.steps.entries()) {
      const action = step.action;

      if (action === "invoke_tool") {
        const spec = step.tool;
        const response = toolResponse(spec);
        const spy = new SpyTool();
        const result = await runGuardedTool(
          session,
          spec.name,
          {},
          async () => response,
          spy,
        );

        const expected = step.expected || {};
        if ("tool_invoked" in expected) {
          expect(spy.wasCalled).toBe(!!expected.tool_invoked);
        }
        if ("result_contains" in expected) {
          expect(String(result)).toContain(expected.result_contains);
        }
      } else if (action === "check_attribute") {
        const value = readVariable(session, step.attribute);
        expect(value).toBe(step.expected_value);
      } else if (action === "set_attribute") {
        session.setVariable(step.attribute, step.value);
      } else if (action === "validate_tool_call") {
        const r = await session.validateToolCall(step.tool_name, {}, `call-${idx + 1}`);
        if (step.expected && "allowed" in step.expected) {
          expect(r.verdict.allowed).toBe(step.expected.allowed);
        }
      } else if (action === "reset") {
        // no-op  — see Anthropic runner
      } else {
        throw new Error(`Unknown step action: ${action}`);
      }
    }
  } finally {
    cleanup?.();
  }
}

describe("Copilot SDK-style adapter e2e ", () => {
  for (const scenario of scenarios) {
    it(scenario.name, async () => {
      if ("tool" in scenario) {
        await runSimpleTool(scenario);
      } else if ("validate_input" in scenario) {
        await runValidateInput(scenario);
      } else if ("steps" in scenario) {
        await runSteps(scenario);
      }
    });
  }
});
