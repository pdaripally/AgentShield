"""E2E scenario runner for the Semantic Kernel adapter .

Reads ``adapter-scenarios.yaml`` and wires each scenario into real
Semantic Kernel function / GuardedAgent machinery via
``agent_shield.adapters.semantic_kernel``.

Capabilities declared: ``{"guarded_agent"}``
(no ``agent_loop`` or ``streaming``).

Usage:
    pytest tests/e2e/run_semantic_kernel.py -v
"""
from __future__ import annotations

import json

import pytest

sk = pytest.importorskip("semantic_kernel")

from semantic_kernel import Kernel  # noqa: E402
from semantic_kernel.functions import KernelFunction, kernel_function  # noqa: E402

from agent_shield import Runtime, RuntimeBuilder  # noqa: E402
from agent_shield.adapters._orchestration import current_session  # noqa: E402
from agent_shield.adapters.semantic_kernel import (  # noqa: E402
    GuardedAgent,
    protect_functions,
    _AgentBoundary as _SKAgentBoundary,
)

from conftest import (  # noqa: E402
    PII_RESPONSE,
    SpyToolRecord,
    fixture_path,
    load_scenarios,
    make_inline_fixture,
    build_v2_runtime,
)

# ---------------------------------------------------------------------------
# Capabilities & scenario loading
# ---------------------------------------------------------------------------

SK_CAPABILITIES: set[str] = {"guarded_agent"}

_scenarios = load_scenarios(capabilities=SK_CAPABILITIES)


def _scenario_id(scenario: dict) -> str:
    return scenario["name"]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_spy_kernel_function(
    name: str, spy: SpyToolRecord, response: str = "ok",
) -> KernelFunction:
    """Create a KernelFunction that records invocations to a SpyToolRecord."""

    async def _func(x: str = "default") -> str:
        spy.record(x=x)
        return response

    decorated = kernel_function(_func, name=name, description=f"Test tool: {name}")
    return KernelFunction.from_method(method=decorated)


def _tool_response(tool_spec: dict) -> str:
    """Derive the string response a spy tool should return for *tool_spec*."""
    if tool_spec.get("response_pii"):
        return PII_RESPONSE
    if "response_sensitivity" in tool_spec:
        return json.dumps({"sensitivity": tool_spec["response_sensitivity"]})
    return tool_spec.get("response", "ok")


def _build_runtime(scenario: dict, tmp_path):
    """Build a :class:`Runtime` and session from a scenario's fixture reference."""
    if "fixture_inline" in scenario:
        path = make_inline_fixture(scenario["fixture_inline"], tmp_path)
    else:
        path = fixture_path(*scenario["fixture"].split("/"))

    runtime = build_v2_runtime(path)
    session = runtime.new_session()
    session.begin_turn()

    for var, value in scenario.get("setup", {}).get("variables", {}).items():
        session.set_variable(var, value)

    return runtime, session


# ---------------------------------------------------------------------------
# Assertion helpers
# ---------------------------------------------------------------------------


def _assert_expected(expected: dict, *, result_str: str | None, spy: SpyToolRecord | None):
    """Run the common assertion block driven by the ``expected`` dict."""

    if "tool_invoked" in expected:
        assert spy is not None
        if expected["tool_invoked"]:
            assert spy.was_called, "Expected tool to be invoked"
        else:
            assert not spy.was_called, "Expected tool NOT to be invoked"

    if "result" in expected and result_str is not None:
        assert expected["result"] in result_str

    if "result_contains" in expected and result_str is not None:
        assert expected["result_contains"] in result_str

    if "result_contains_lower" in expected and result_str is not None:
        assert expected["result_contains_lower"] in result_str.lower()

    if "result_not_contains" in expected and result_str is not None:
        assert expected["result_not_contains"] not in result_str

    if "allowed" in expected:
        pass  # handled inline by the caller (validate_input path)


# ---------------------------------------------------------------------------
# Step executors (for multi-step scenarios)
# ---------------------------------------------------------------------------


async def _run_step(step: dict, runtime: Runtime, session, step_index: int):
    """Execute a single step inside a multi-step scenario.

    Returns ``(result_str, spy)`` when the step produces a result, or
    ``(None, None)`` for structural steps like ``set_variable`` / ``reset_variable``.
    """
    action = step["action"]

    if action == "invoke_tool":
        tool_spec = step["tool"]
        spy = SpyToolRecord()
        response = _tool_response(tool_spec)
        func = _make_spy_kernel_function(tool_spec["name"], spy, response=response)
        protected = protect_functions(runtime, [func])
        result = await protected[0].invoke(Kernel())
        result_str = str(result)

        if "expected" in step:
            _assert_expected(step["expected"], result_str=result_str, spy=spy)

        return result_str, spy

    if action == "check_variable":
        value = session.resolve_variable(step["variable"])
        assert value == step["expected_value"], (
            f"Expected variable {step['variable']!r} == {step['expected_value']!r}, got {value!r}"
        )
        return None, None

    if action == "set_variable":
        session.set_variable(step["variable"], step["value"])
        return None, None

    if action == "validate_tool_call":
        outcome = session.validate_tool_call(step["tool_name"], tool_call_id=f"call_{step_index}")
        if "expected" in step:
            if "allowed" in step["expected"]:
                assert outcome.verdict.allowed == step["expected"]["allowed"]
        return None, None

    if action == "reset_variable":
        session.reset_variable(step["variable"])
        return None, None

    raise ValueError(f"Unknown step action: {action}")


# ---------------------------------------------------------------------------
# Main parametrized test
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
@pytest.mark.parametrize("scenario", _scenarios, ids=_scenario_id)
async def test_scenario(scenario: dict, tmp_path):
    """Data-driven e2e test for every applicable adapter scenario."""

    runtime, session = _build_runtime(scenario, tmp_path)

    token = current_session.set(session)
    try:
        # ------------------------------------------------------------------
        # Simple tool scenario (has a top-level ``tool`` key)
        # ------------------------------------------------------------------
        if "tool" in scenario:
            tool_spec = scenario["tool"]
            spy = SpyToolRecord()
            response = _tool_response(tool_spec)
            func = _make_spy_kernel_function(tool_spec["name"], spy, response=response)

            protected = protect_functions(runtime, [func])
            result = await protected[0].invoke(Kernel())
            result_str = str(result)

            _assert_expected(scenario["expected"], result_str=result_str, spy=spy)
            return

        # ------------------------------------------------------------------
        # Input validation (``validate_input`` key)
        # ------------------------------------------------------------------
        if "validate_input" in scenario:
            decision = session.validate_input(scenario["validate_input"])
            expected = scenario["expected"]

            if "allowed" in expected:
                assert decision.allowed == expected["allowed"]
            if "action" in expected:
                assert decision.action == expected["action"]
            return

        # ------------------------------------------------------------------
        # Multi-step scenario (``steps`` key)
        # ------------------------------------------------------------------
        if "steps" in scenario:
            for idx, step in enumerate(scenario["steps"], start=1):
                await _run_step(step, runtime, session, idx)
            return

        # ------------------------------------------------------------------
        # GuardedAgent scenario (``guarded_agent`` key)
        # ------------------------------------------------------------------
        if "guarded_agent" in scenario:
            agent_was_called = False

            class MockAgent:
                async def invoke(self, messages=None, **kwargs):
                    nonlocal agent_was_called
                    agent_was_called = True
                    return "I should not appear"

            guarded = GuardedAgent(runtime, MockAgent(), _SKAgentBoundary())
            response = await guarded.invoke(
                user_input=scenario["guarded_agent"]["input"],
            )
            result_str = str(response)

            expected = scenario["expected"]
            if "agent_invoked" in expected:
                if expected["agent_invoked"]:
                    assert agent_was_called, "Expected agent to be invoked"
                else:
                    assert not agent_was_called, "Expected agent NOT to be invoked"

            if "result_contains" in expected:
                assert expected["result_contains"] in result_str
            return

        pytest.fail(f"Scenario {scenario['name']!r} has no recognised handler key")
    finally:
        current_session.reset(token)
        try:
            session.end_turn()
        except Exception:  # noqa: BLE001
            pass
