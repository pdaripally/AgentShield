"""E2E tests for the LiteLLM Proxy guardrail integration.

These tests drive ``AgentShieldLiteLLMGuardrail`` directly via its
async hook methods with synthesised request/response shapes — no
Docker, no real LiteLLM Proxy boot, runs in CI. Coverage matches the
deliverables in ``docs/integrations/litellm-proxy.md``:

* Stage 1: input block (raise HTTPException) and allow pass-through.
* Stage 2/3: tool-call block (drop tool_calls + rewrite to assistant
  block) and Stage-3 mutation (redact tool arguments in place).
* Stage 4: tool-output block via ``tool_call_id`` correlation and
  fail-closed behavior for unknown ``tool_call_id``.
* Stage 5: output redact rewrites response content.
* Stage 5 only fires on final responses (no tool_calls).
* Streaming: buffered allow path replays chunks; buffered block path
  emits a single replacement chunk; chunked tool-call arguments are
  reassembled across many deltas (including parallel calls keyed by
  ``index``).
* Turn lifecycle: user → assistant(tool_calls) → tool → assistant(final)
  runs as a single Agent-Shield turn (one ``begin_turn`` / one
  ``end_turn``).
* Per-session async lock prevents interleaving.

The test file lives under ``tests/e2e/`` (alongside other adapter
runners) and skips cleanly if ``litellm`` is not installed.
"""
from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

import pytest

litellm = pytest.importorskip("litellm")
fastapi = pytest.importorskip("fastapi")

from fastapi import HTTPException
from litellm.types.utils import (
    ChatCompletionMessageToolCall,
    Choices,
    Function,
    Message,
    ModelResponse,
    ModelResponseStream,
    StreamingChoices,
    Delta,
)

# Make sdk/python importable when run via plain pytest.
_REPO_ROOT = Path(__file__).resolve().parent.parent.parent
_SDK_PYTHON = _REPO_ROOT / "sdk" / "python"
if _SDK_PYTHON.is_dir():
    sys.path.insert(0, str(_SDK_PYTHON))

from agent_shield import Runtime, RuntimeBuilder  # noqa: E402
from agent_shield.integrations.litellm_proxy import (  # noqa: E402
    AgentShieldLiteLLMGuardrail,
)

FIXTURE = (
    _REPO_ROOT
    / "tests"
    / "fixtures"
    / "litellm-proxy"
    / "litellm-proxy-test.guardrails.yaml"
)


# ── helpers ────────────────────────────────────────────────────────────


def build_guardrail(**kwargs) -> AgentShieldLiteLLMGuardrail:
    """Build a fresh guardrail bound to the test fixture."""
    runtime: Runtime = RuntimeBuilder.from_yaml(str(FIXTURE)).build()
    return AgentShieldLiteLLMGuardrail(runtime=runtime, **kwargs)


def make_messages(role: str, content: str, **extra):
    """Convenience for synthesising an OpenAI-Chat messages list."""
    return [{"role": role, "content": content, **extra}]


def make_response(content: str, *, tool_calls=None, finish_reason="stop"):
    """Build a ``ModelResponse`` with one choice."""
    return ModelResponse(
        choices=[
            Choices(
                message=Message(
                    content=content, role="assistant", tool_calls=tool_calls,
                ),
                finish_reason=finish_reason,
                index=0,
            ),
        ],
        model="test-model",
    )


def make_tool_call(call_id: str, name: str, args_dict: dict):
    return ChatCompletionMessageToolCall(
        id=call_id,
        type="function",
        function=Function(name=name, arguments=json.dumps(args_dict)),
    )


async def collect(aiter):
    out = []
    async for c in aiter:
        out.append(c)
    return out


async def chunk_stream(chunks):
    for c in chunks:
        yield c


# ── Stage 1 ────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_stage1_blocks_known_bad_input():
    guard = build_guardrail()
    data = {
        "messages": make_messages("user", "hello DENY_INPUT world"),
        "metadata": {"agent_shield_session_id": "s-stage1-block"},
    }
    with pytest.raises(HTTPException) as exc:
        await guard.async_pre_call_hook(
            user_api_key_dict=None, cache=None, data=data, call_type="completion",
        )
    assert exc.value.status_code == 400
    assert "DENY_INPUT" in exc.value.detail


@pytest.mark.asyncio
async def test_stage1_allows_clean_input():
    guard = build_guardrail()
    data = {
        "messages": make_messages("user", "what's the weather?"),
        "metadata": {"agent_shield_session_id": "s-stage1-allow"},
    }
    result = await guard.async_pre_call_hook(
        user_api_key_dict=None, cache=None, data=data, call_type="completion",
    )
    # Data is passed through unmutated on allow.
    assert result is data
    assert result["messages"][0]["content"] == "what's the weather?"


@pytest.mark.asyncio
async def test_stage1_redact_mutates_user_message_before_forwarding():
    """An `input_validation` redact policy must rewrite the upstream
    request's last role=user message content so the upstream model
    sees the redacted text, not the original."""
    guard = build_guardrail()
    data = {
        "messages": make_messages("user", "hello MUTATE-XYZ world"),
        "metadata": {"agent_shield_session_id": "s-stage1-redact"},
    }
    result = await guard.async_pre_call_hook(
        user_api_key_dict=None, cache=None, data=data, call_type="completion",
    )
    forwarded = result["messages"][-1]["content"]
    assert "MUTATE-XYZ" not in forwarded
    assert "[REDACTED-INPUT]" in forwarded
    entry = guard._sessions.get_or_create("s-stage1-redact")
    assert entry.turn_open is True



# ── Stage 2/3 ──────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_stage_2_3_blocks_forbidden_tool():
    guard = build_guardrail()
    # Open the turn with a clean input first.
    await guard.async_pre_call_hook(
        user_api_key_dict=None,
        cache=None,
        data={
            "messages": make_messages("user", "do something"),
            "metadata": {"agent_shield_session_id": "s-stage23-block"},
        },
        call_type="completion",
    )

    response = make_response(
        content="",
        tool_calls=[make_tool_call("call_1", "danger_tool", {"x": 1})],
        finish_reason="tool_calls",
    )
    rewritten = await guard.async_post_call_success_hook(
        data={
            "messages": make_messages("user", "do something"),
            "metadata": {"agent_shield_session_id": "s-stage23-block"},
        },
        user_api_key_dict=None,
        response=response,
    )
    assert rewritten is not None
    # tool_calls dropped, content carries block string, finish_reason==stop
    assert rewritten.choices[0].message.tool_calls in (None, [])
    assert rewritten.choices[0].finish_reason == "stop"
    assert "danger_tool" in (rewritten.choices[0].message.content or "")


@pytest.mark.asyncio
async def test_stage3_mutation_rewrites_arguments():
    guard = build_guardrail()
    sid = "s-stage3-mutate"
    await guard.async_pre_call_hook(
        user_api_key_dict=None,
        cache=None,
        data={
            "messages": make_messages("user", "use echo_tool"),
            "metadata": {"agent_shield_session_id": sid},
        },
        call_type="completion",
    )
    response = make_response(
        content="",
        tool_calls=[
            make_tool_call(
                "call_42", "echo_tool", {"msg": "see SECRET-DEADBEEF here"},
            ),
        ],
        finish_reason="tool_calls",
    )
    result = await guard.async_post_call_success_hook(
        data={
            "messages": [],
            "metadata": {"agent_shield_session_id": sid},
        },
        user_api_key_dict=None,
        response=response,
    )
    # Tool call still present (allow path), arguments rewritten.
    calls = result.choices[0].message.tool_calls
    assert calls and len(calls) == 1
    args = json.loads(calls[0].function.arguments)
    assert "SECRET-DEADBEEF" not in args.get("msg", "")
    # Pending-tool-calls map populated for Stage 4 correlation.
    entry = guard._sessions.get_or_create(sid)
    assert entry.pending_tool_calls == {"call_42": "echo_tool"}


# ── Stage 4 ────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_stage4_blocks_tool_output_via_call_id_correlation():
    guard = build_guardrail()
    sid = "s-stage4-block"
    # Stage 1
    await guard.async_pre_call_hook(
        user_api_key_dict=None,
        cache=None,
        data={
            "messages": make_messages("user", "fetch"),
            "metadata": {"agent_shield_session_id": sid},
        },
        call_type="completion",
    )
    # Stage 2/3 (allowed tool call)
    response = make_response(
        content="",
        tool_calls=[make_tool_call("c-1", "echo_tool", {"q": "data"})],
        finish_reason="tool_calls",
    )
    await guard.async_post_call_success_hook(
        data={"messages": [], "metadata": {"agent_shield_session_id": sid}},
        user_api_key_dict=None,
        response=response,
    )
    # Stage 4 — tool result coming back with a leak sentinel
    next_messages = [
        {"role": "user", "content": "fetch"},
        {"role": "assistant", "content": "", "tool_calls": [
            {"id": "c-1", "type": "function",
             "function": {"name": "echo_tool", "arguments": "{\"q\":\"data\"}"}},
        ]},
        {"role": "tool", "tool_call_id": "c-1",
         "content": "result with LEAK_SENTINEL inside"},
    ]
    data = {
        "messages": next_messages,
        "metadata": {"agent_shield_session_id": sid},
    }
    result = await guard.async_pre_call_hook(
        user_api_key_dict=None, cache=None, data=data, call_type="completion",
    )
    # Replace policy (default): the tool message's content is rewritten
    # with the canonical block string (which begins with [GUARDRAIL ...]).
    assert result["messages"][-1]["role"] == "tool"
    blocked = result["messages"][-1]["content"]
    assert blocked.startswith("[GUARDRAIL ")
    assert "LEAK_SENTINEL" in blocked  # block reason carries the sentinel
    assert "echo_tool" in blocked      # block message names the tool


@pytest.mark.asyncio
async def test_stage4_unknown_tool_call_id_fails_closed():
    """A trailing role=tool whose tool_call_id is unknown (not in
    pending_tool_calls and not in validated_tool_messages) is
    fail-closed at Stage 4 by content-replacement (default
    stage4_on_block='replace')."""
    guard = build_guardrail()
    sid = "s-stage4-unknown"
    await guard.async_pre_call_hook(
        user_api_key_dict=None,
        cache=None,
        data={
            "messages": make_messages("user", "fetch"),
            "metadata": {"agent_shield_session_id": sid},
        },
        call_type="completion",
    )
    await guard.async_post_call_success_hook(
        data={"messages": [], "metadata": {"agent_shield_session_id": sid}},
        user_api_key_dict=None,
        response=make_response(content="ok", finish_reason="stop"),
    )
    # Force the entry's turn open again so we hit the
    # "unknown tool_call_id" branch (not the "no open turn" path).
    entry = guard._sessions.get_or_create(sid)
    entry.session.begin_turn()
    entry.turn_open = True

    # No Stage 2/3 step → pending_tool_calls is empty.
    data = {
        "messages": [
            {"role": "user", "content": "fetch"},
            {"role": "tool", "tool_call_id": "c-bogus",
             "content": "result"},
        ],
        "metadata": {"agent_shield_session_id": sid},
    }
    result = await guard.async_pre_call_hook(
        user_api_key_dict=None, cache=None, data=data, call_type="completion",
    )
    blocked = result["messages"][-1]["content"]
    assert blocked.startswith("[GUARDRAIL ")
    assert "unknown tool_call_id" in blocked.lower()


@pytest.mark.asyncio
async def test_stage4_raise_policy_returns_http_400():
    guard = build_guardrail(stage4_on_block="raise")
    sid = "s-stage4-raise"
    await guard.async_pre_call_hook(
        user_api_key_dict=None,
        cache=None,
        data={
            "messages": make_messages("user", "fetch"),
            "metadata": {"agent_shield_session_id": sid},
        },
        call_type="completion",
    )
    await guard.async_post_call_success_hook(
        data={"messages": [], "metadata": {"agent_shield_session_id": sid}},
        user_api_key_dict=None,
        response=make_response(
            content="",
            tool_calls=[make_tool_call("c-1", "echo_tool", {})],
            finish_reason="tool_calls",
        ),
    )
    with pytest.raises(HTTPException):
        await guard.async_pre_call_hook(
            user_api_key_dict=None, cache=None,
            data={
                "messages": [
                    {"role": "user", "content": "fetch"},
                    {"role": "tool", "tool_call_id": "c-1",
                     "content": "LEAK_SENTINEL"},
                ],
                "metadata": {"agent_shield_session_id": sid},
            },
            call_type="completion",
        )


@pytest.mark.asyncio
async def test_stage4_fails_closed_when_no_open_turn():
    """Trailing tool messages on a fresh session (e.g. after proxy
    restart or LRU eviction) are caught by _stage4_tool_outputs's
    "no open turn" guard and have their content replaced with the
    canonical block string."""
    guard = build_guardrail()
    sid = "s-stage4-no-turn"
    data = {
        "messages": [
            {"role": "user", "content": "fetch"},
            {"role": "tool", "tool_call_id": "c-1",
             "content": "any content"},
        ],
        "metadata": {"agent_shield_session_id": sid},
    }
    result = await guard.async_pre_call_hook(
        user_api_key_dict=None, cache=None, data=data, call_type="completion",
    )
    blocked = result["messages"][-1]["content"]
    assert blocked.startswith("[GUARDRAIL ")
    assert "c-1" in blocked


@pytest.mark.asyncio
async def test_stage4_records_tool_success_on_allow():
    """Stage 4 allow path records a tool success on the resource cycle.

    Without this, per-session lifetimes that gate on tool completion
    (e.g. `until_event: 'tool.<name>.completed'`) would never fire.
    """
    guard = build_guardrail()
    sid = "s-stage4-record"
    await guard.async_pre_call_hook(
        user_api_key_dict=None, cache=None,
        data={"messages": make_messages("user", "fetch"),
              "metadata": {"agent_shield_session_id": sid}},
        call_type="completion",
    )
    await guard.async_post_call_success_hook(
        data={"messages": [], "metadata": {"agent_shield_session_id": sid}},
        user_api_key_dict=None,
        response=make_response(
            content="",
            tool_calls=[make_tool_call("c-1", "echo_tool", {"q": "ok"})],
            finish_reason="tool_calls",
        ),
    )
    # Spy on record_tool_success / record_tool_failure.
    entry = guard._sessions.get_or_create(sid)
    calls = []
    entry.session.record_tool_success = lambda *a, **k: calls.append(("success", a, k))
    entry.session.record_tool_failure = lambda *a, **k: calls.append(("failure", a, k))
    await guard.async_pre_call_hook(
        user_api_key_dict=None, cache=None,
        data={
            "messages": [
                {"role": "user", "content": "fetch"},
                {"role": "assistant", "content": "", "tool_calls": [
                    {"id": "c-1", "type": "function", "function": {
                        "name": "echo_tool", "arguments": "{\"q\":\"ok\"}",
                    }},
                ]},
                {"role": "tool", "tool_call_id": "c-1", "content": "fine"},
            ],
            "metadata": {"agent_shield_session_id": sid},
        },
        call_type="completion",
    )
    assert any(c[0] == "success" for c in calls), (
        f"expected a record_tool_success call; got {calls!r}"
    )


# ── Stage 5 ────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_stage5_redacts_secret_token():
    guard = build_guardrail()
    sid = "s-stage5-redact"
    await guard.async_pre_call_hook(
        user_api_key_dict=None,
        cache=None,
        data={
            "messages": make_messages("user", "say something"),
            "metadata": {"agent_shield_session_id": sid},
        },
        call_type="completion",
    )
    response = make_response(
        content="here is SECRET-ABCDEF1234 for you",
        tool_calls=None,
        finish_reason="stop",
    )
    rewritten = await guard.async_post_call_success_hook(
        data={"messages": [], "metadata": {"agent_shield_session_id": sid}},
        user_api_key_dict=None,
        response=response,
    )
    out = rewritten.choices[0].message.content
    assert "SECRET-ABCDEF1234" not in out
    # Stage 5 only fires on final responses, and closing the turn
    # clears pending_tool_calls.
    entry = guard._sessions.get_or_create(sid)
    assert entry.turn_open is False


@pytest.mark.asyncio
async def test_stage5_does_not_fire_on_tool_call_response():
    """Assistant responses carrying tool_calls are intermediate — Stage 5
    must NOT redact them. Only Stage 2/3 fires on this shape.
    """
    guard = build_guardrail()
    sid = "s-stage5-skip"
    await guard.async_pre_call_hook(
        user_api_key_dict=None,
        cache=None,
        data={
            "messages": make_messages("user", "ok"),
            "metadata": {"agent_shield_session_id": sid},
        },
        call_type="completion",
    )
    # A tool-call response that ALSO carries content containing a
    # SECRET token: Stage 5 should not touch it (the LLM may continue
    # the turn with a tool call).
    response = make_response(
        content="prefix SECRET-XYZ suffix",
        tool_calls=[make_tool_call("cx", "echo_tool", {"q": "ok"})],
        finish_reason="tool_calls",
    )
    rewritten = await guard.async_post_call_success_hook(
        data={"messages": [], "metadata": {"agent_shield_session_id": sid}},
        user_api_key_dict=None,
        response=response,
    )
    # Content untouched — Stage 5 skipped.
    assert "SECRET-XYZ" in (rewritten.choices[0].message.content or "")


# ── Turn lifecycle ─────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_turn_spans_multiple_litellm_calls():
    """user → assistant(tool_calls) → tool → assistant(final) is ONE turn."""
    guard = build_guardrail()
    sid = "s-turn-lifecycle"
    md = {"agent_shield_session_id": sid}

    # Request 1: user message → Stage 1 opens the turn.
    await guard.async_pre_call_hook(
        user_api_key_dict=None,
        cache=None,
        data={"messages": [{"role": "user", "content": "hi"}], "metadata": md},
        call_type="completion",
    )
    entry = guard._sessions.get_or_create(sid)
    assert entry.turn_open is True

    # Response 1: assistant tool_calls → Stage 2/3, turn stays open.
    await guard.async_post_call_success_hook(
        data={"messages": [], "metadata": md},
        user_api_key_dict=None,
        response=make_response(
            content="",
            tool_calls=[make_tool_call("c1", "echo_tool", {"q": "x"})],
            finish_reason="tool_calls",
        ),
    )
    assert entry.turn_open is True
    assert entry.pending_tool_calls == {"c1": "echo_tool"}

    # Request 2: tool result → Stage 4, turn still open.
    await guard.async_pre_call_hook(
        user_api_key_dict=None,
        cache=None,
        data={
            "messages": [
                {"role": "user", "content": "hi"},
                {"role": "assistant", "content": "", "tool_calls": [
                    {"id": "c1", "type": "function", "function": {
                        "name": "echo_tool", "arguments": "{}",
                    }},
                ]},
                {"role": "tool", "tool_call_id": "c1", "content": "ok"},
            ],
            "metadata": md,
        },
        call_type="completion",
    )
    assert entry.turn_open is True

    # Response 2: assistant final content → Stage 5 closes the turn.
    await guard.async_post_call_success_hook(
        data={"messages": [], "metadata": md},
        user_api_key_dict=None,
        response=make_response(
            content="all done", tool_calls=None, finish_reason="stop",
        ),
    )
    assert entry.turn_open is False
    assert entry.pending_tool_calls == {}


# ── Streaming ──────────────────────────────────────────────────────────


def _stream_text_chunks(text_pieces, *, chunk_id="cmpl-1"):
    """Build a list of ModelResponseStream chunks from text pieces."""
    chunks = []
    for piece in text_pieces:
        chunks.append(
            ModelResponseStream(
                id=chunk_id,
                model="test-model",
                choices=[StreamingChoices(
                    index=0, delta=Delta(content=piece), finish_reason=None,
                )],
            )
        )
    # Final stop chunk.
    chunks.append(
        ModelResponseStream(
            id=chunk_id,
            model="test-model",
            choices=[StreamingChoices(
                index=0, delta=Delta(content=None), finish_reason="stop",
            )],
        )
    )
    return chunks


@pytest.mark.asyncio
async def test_streaming_allow_replays_chunks():
    guard = build_guardrail()
    sid = "s-stream-allow"
    md = {"agent_shield_session_id": sid}
    await guard.async_pre_call_hook(
        user_api_key_dict=None, cache=None,
        data={"messages": [{"role": "user", "content": "hi"}], "metadata": md},
        call_type="completion",
    )
    pieces = ["hello", " ", "world"]
    upstream = _stream_text_chunks(pieces)
    out = await collect(
        guard.async_post_call_streaming_iterator_hook(
            user_api_key_dict=None,
            response=chunk_stream(upstream),
            request_data={"metadata": md},
        )
    )
    # Allow path → byte-equivalent replay (same chunk count + ids).
    assert len(out) == len(upstream)
    assembled = "".join(
        (c.choices[0].delta.content or "") for c in out
    )
    assert assembled == "hello world"


@pytest.mark.asyncio
async def test_streaming_block_emits_replacement_chunk():
    guard = build_guardrail()
    sid = "s-stream-block"
    md = {"agent_shield_session_id": sid}
    await guard.async_pre_call_hook(
        user_api_key_dict=None, cache=None,
        data={"messages": [{"role": "user", "content": "hi"}], "metadata": md},
        call_type="completion",
    )
    pieces = ["here is ", "SECRET-ABCDEF", " ok"]
    upstream = _stream_text_chunks(pieces, chunk_id="cmpl-replace-me")
    out = await collect(
        guard.async_post_call_streaming_iterator_hook(
            user_api_key_dict=None,
            response=chunk_stream(upstream),
            request_data={"metadata": md},
        )
    )
    # Stage-5 redact path emits a single replacement chunk that no
    # longer contains the secret token.
    assert len(out) == 1
    chunk = out[0]
    assert getattr(chunk, "id", None) == "cmpl-replace-me"
    assert chunk.choices[0].finish_reason == "stop"
    assert "SECRET-ABCDEF" not in (chunk.choices[0].delta.content or "")


@pytest.mark.asyncio
async def test_streaming_assembles_chunked_tool_calls():
    """A single tool-call's argument string can arrive split across
    many deltas; the assembler must re-coalesce by ``index``."""
    guard = build_guardrail()
    sid = "s-stream-tools"
    md = {"agent_shield_session_id": sid}
    await guard.async_pre_call_hook(
        user_api_key_dict=None, cache=None,
        data={"messages": [{"role": "user", "content": "go"}], "metadata": md},
        call_type="completion",
    )

    def _tc_delta(idx, *, id=None, name=None, arg_piece=None):
        fn = {}
        if name is not None:
            fn["name"] = name
        if arg_piece is not None:
            fn["arguments"] = arg_piece
        d = {"index": idx}
        if id is not None:
            d["id"] = id
        if fn:
            d["type"] = "function"
            d["function"] = fn
        return d

    chunks = [
        ModelResponseStream(id="x", model="m", choices=[StreamingChoices(
            index=0,
            delta=Delta(content=None, tool_calls=[
                _tc_delta(0, id="a", name="echo_tool",
                          arg_piece="{\"q\":\"hello "),
            ]),
            finish_reason=None,
        )]),
        ModelResponseStream(id="x", model="m", choices=[StreamingChoices(
            index=0,
            delta=Delta(content=None, tool_calls=[
                _tc_delta(0, arg_piece="world\"}"),
            ]),
            finish_reason=None,
        )]),
        ModelResponseStream(id="x", model="m", choices=[StreamingChoices(
            index=0,
            delta=Delta(content=None),
            finish_reason="tool_calls",
        )]),
    ]
    out = await collect(
        guard.async_post_call_streaming_iterator_hook(
            user_api_key_dict=None,
            response=chunk_stream(chunks),
            request_data={"metadata": md},
        )
    )
    # Allow path (no SECRET in args, echo_tool is allowed) → replay.
    assert len(out) == len(chunks)
    # And the guardrail tracked the (reassembled) tool call.
    entry = guard._sessions.get_or_create(sid)
    assert entry.pending_tool_calls == {"a": "echo_tool"}


@pytest.mark.asyncio
async def test_streaming_stage3_mutation_emits_reconstructed_chunk():
    """When Stage 3 rewrites a streamed tool call's arguments, the
    guardrail MUST NOT replay the original chunks (which would leak
    the unmutated argument string to the agent). Instead a single
    reconstructed tool-call chunk carrying the mutated arguments is
    emitted."""
    guard = build_guardrail()
    sid = "s-stream-mut"
    md = {"agent_shield_session_id": sid}
    await guard.async_pre_call_hook(
        user_api_key_dict=None, cache=None,
        data={"messages": [{"role": "user", "content": "go"}], "metadata": md},
        call_type="completion",
    )
    # echo_tool with arguments containing SECRET-X — Stage 3 redacts
    # the arg into [REDACTED].
    def _tc_delta(idx, *, id=None, name=None, arg_piece=None):
        fn = {}
        if name is not None:
            fn["name"] = name
        if arg_piece is not None:
            fn["arguments"] = arg_piece
        d = {"index": idx}
        if id is not None:
            d["id"] = id
        if fn:
            d["type"] = "function"
            d["function"] = fn
        return d

    chunks = [
        ModelResponseStream(id="m1", model="m", choices=[StreamingChoices(
            index=0,
            delta=Delta(content=None, tool_calls=[
                _tc_delta(0, id="ax", name="echo_tool",
                          arg_piece="{\"msg\":\"see SECRET-X here\"}"),
            ]),
            finish_reason=None,
        )]),
        ModelResponseStream(id="m1", model="m", choices=[StreamingChoices(
            index=0, delta=Delta(content=None), finish_reason="tool_calls",
        )]),
    ]
    out = await collect(
        guard.async_post_call_streaming_iterator_hook(
            user_api_key_dict=None,
            response=chunk_stream(chunks),
            request_data={"metadata": md},
        )
    )
    # ONE replacement chunk — NOT the original chunks replayed.
    assert len(out) == 1
    chunk = out[0]
    tcs = chunk.choices[0].delta.tool_calls
    assert tcs and len(tcs) == 1
    args = json.loads(tcs[0].function.arguments)
    assert "SECRET-X" not in args.get("msg", "")
    assert chunk.choices[0].finish_reason == "tool_calls"


@pytest.mark.asyncio
async def test_malformed_function_shape_does_not_crash():
    """A response with `tool_calls[*].function` as a non-dict (raw
    upstream junk) must fail closed cleanly, not raise
    AttributeError on `fn.get('name')`. The same shape can appear
    on the pre-scan and on the main validation loop."""
    guard = build_guardrail()
    sid = "s-malformed-fn"
    md = {"agent_shield_session_id": sid}
    await guard.async_pre_call_hook(
        user_api_key_dict=None, cache=None,
        data={"messages": make_messages("user", "go"), "metadata": md},
        call_type="completion",
    )
    response = {
        "choices": [{
            "index": 0,
            "finish_reason": "tool_calls",
            "message": {
                "role": "assistant",
                "content": "",
                "tool_calls": [
                    {"id": "c1", "type": "function",
                     "function": "not-a-dict"},
                ],
            },
        }],
    }
    # Must not raise — the existing missing-function.name fail-closed
    # path handles it once the shape has been normalised.
    out = await guard.async_post_call_success_hook(
        data={"messages": [], "metadata": md},
        user_api_key_dict=None,
        response=response,
    )
    out_dict = out if isinstance(out, dict) else out.model_dump()
    tcs = out_dict["choices"][0]["message"].get("tool_calls")
    assert tcs in (None, []), (
        f"expected tool_calls dropped on block; got {tcs!r}"
    )
    blocked = out_dict["choices"][0]["message"].get("content") or ""
    assert blocked.startswith("[GUARDRAIL ")



@pytest.mark.asyncio
async def test_synthesised_tool_call_id_written_back_to_response():
    """If the upstream model emits a tool call without an `id`, the
    integration synthesises one to satisfy the Section 16.0 binding
    requirement — but the synthesised id MUST also be written back to
    the outgoing response, so the agent's later role=tool reply
    carries the same id Stage 4 will correlate against."""
    guard = build_guardrail()
    sid = "s-synth-tcid"
    md = {"agent_shield_session_id": sid}
    await guard.async_pre_call_hook(
        user_api_key_dict=None, cache=None,
        data={"messages": make_messages("user", "go"), "metadata": md},
        call_type="completion",
    )
    response = {
        "choices": [{
            "index": 0,
            "finish_reason": "tool_calls",
            "message": {
                "role": "assistant",
                "content": "",
                "tool_calls": [
                    {
                        "id": None,
                        "type": "function",
                        "function": {
                            "name": "echo_tool",
                            "arguments": "{\"q\": \"hi\"}",
                        },
                    },
                ],
            },
        }],
    }
    out = await guard.async_post_call_success_hook(
        data={"messages": [], "metadata": md},
        user_api_key_dict=None,
        response=response,
    )
    out_dict = out if isinstance(out, dict) else out.model_dump()
    written_id = out_dict["choices"][0]["message"]["tool_calls"][0]["id"]
    assert isinstance(written_id, str) and written_id, (
        f"expected a written-back synth id; got {written_id!r}"
    )
    assert written_id.startswith("agent-shield-litellm-tc-")
    entry = guard._sessions.get_or_create(sid)
    assert entry.pending_tool_calls == {written_id: "echo_tool"}



    """If the upstream model emits a tool call without an `id`, the
    integration synthesises one to satisfy the Section 16.0 binding
    requirement — but the synthesised id MUST also be written back to
    the outgoing response, so the agent's later role=tool reply
    carries the same id Stage 4 will correlate against."""
    guard = build_guardrail()
    sid = "s-synth-tcid"
    md = {"agent_shield_session_id": sid}
    await guard.async_pre_call_hook(
        user_api_key_dict=None, cache=None,
        data={"messages": make_messages("user", "go"), "metadata": md},
        call_type="completion",
    )
    response = {
        "choices": [{
            "index": 0,
            "finish_reason": "tool_calls",
            "message": {
                "role": "assistant",
                "content": "",
                "tool_calls": [
                    {
                        "id": None,
                        "type": "function",
                        "function": {
                            "name": "echo_tool",
                            "arguments": "{\"q\": \"hi\"}",
                        },
                    },
                ],
            },
        }],
    }
    out = await guard.async_post_call_success_hook(
        data={"messages": [], "metadata": md},
        user_api_key_dict=None,
        response=response,
    )
    out_dict = out if isinstance(out, dict) else out.model_dump()
    written_id = out_dict["choices"][0]["message"]["tool_calls"][0]["id"]
    assert isinstance(written_id, str) and written_id, (
        f"expected a written-back synth id; got {written_id!r}"
    )
    assert written_id.startswith("agent-shield-litellm-tc-")
    entry = guard._sessions.get_or_create(sid)
    assert entry.pending_tool_calls == {written_id: "echo_tool"}


@pytest.mark.asyncio
async def test_streaming_synthesised_tool_call_id_emits_reconstructed_chunk():
    """Streaming variant: when a chunked tool call lacks an id, the
    integration must NOT replay the original chunks (which would
    deliver an id-less tool call to the agent). It must emit a
    reconstructed chunk carrying the synthesised id."""
    guard = build_guardrail()
    sid = "s-stream-synth"
    md = {"agent_shield_session_id": sid}
    await guard.async_pre_call_hook(
        user_api_key_dict=None, cache=None,
        data={"messages": make_messages("user", "go"), "metadata": md},
        call_type="completion",
    )

    def _tc_delta(idx, *, name=None, arg_piece=None):
        fn = {}
        if name is not None:
            fn["name"] = name
        if arg_piece is not None:
            fn["arguments"] = arg_piece
        d = {"index": idx}
        if fn:
            d["type"] = "function"
            d["function"] = fn
        return d

    chunks = [
        ModelResponseStream(id="m1", model="m", choices=[StreamingChoices(
            index=0,
            delta=Delta(content=None, tool_calls=[
                _tc_delta(0, name="echo_tool", arg_piece="{\"q\":\"hi\"}"),
            ]),
            finish_reason=None,
        )]),
        ModelResponseStream(id="m1", model="m", choices=[StreamingChoices(
            index=0, delta=Delta(content=None), finish_reason="tool_calls",
        )]),
    ]
    out = await collect(
        guard.async_post_call_streaming_iterator_hook(
            user_api_key_dict=None,
            response=chunk_stream(chunks),
            request_data={"metadata": md},
        )
    )
    assert len(out) == 1
    tcs = out[0].choices[0].delta.tool_calls
    assert tcs and len(tcs) == 1
    assert isinstance(tcs[0].id, str) and tcs[0].id.startswith(
        "agent-shield-litellm-tc-",
    )


@pytest.mark.asyncio
async def test_malformed_tool_call_arguments_fails_closed():
    """A tool call whose `function.arguments` is not valid JSON must
    fail closed — forwarding the malformed string would bypass any
    argument-level Stage 3 policy."""
    guard = build_guardrail()
    sid = "s-malformed"
    md = {"agent_shield_session_id": sid}
    await guard.async_pre_call_hook(
        user_api_key_dict=None, cache=None,
        data={"messages": [{"role": "user", "content": "go"}], "metadata": md},
        call_type="completion",
    )
    response = ModelResponse(
        choices=[Choices(
            message=Message(content="", role="assistant", tool_calls=[
                ChatCompletionMessageToolCall(
                    id="c1", type="function",
                    function=Function(
                        name="echo_tool",
                        arguments="not-valid-json{{",
                    ),
                ),
            ]),
            finish_reason="tool_calls", index=0,
        )],
        model="m",
    )
    out = await guard.async_post_call_success_hook(
        data={"messages": [], "metadata": md},
        user_api_key_dict=None,
        response=response,
    )
    # Block path: tool_calls dropped, content carries the block string.
    assert out.choices[0].message.tool_calls in (None, [])
    assert "malformed" in (out.choices[0].message.content or "").lower()
    assert out.choices[0].finish_reason == "stop"



    """A tool call whose `function.arguments` is not valid JSON must
    fail closed — forwarding the malformed string would bypass any
    argument-level Stage 3 policy."""
    guard = build_guardrail()
    sid = "s-malformed"
    md = {"agent_shield_session_id": sid}
    await guard.async_pre_call_hook(
        user_api_key_dict=None, cache=None,
        data={"messages": [{"role": "user", "content": "go"}], "metadata": md},
        call_type="completion",
    )
    response = ModelResponse(
        choices=[Choices(
            message=Message(content="", role="assistant", tool_calls=[
                ChatCompletionMessageToolCall(
                    id="c1", type="function",
                    function=Function(
                        name="echo_tool",
                        arguments="not-valid-json{{",
                    ),
                ),
            ]),
            finish_reason="tool_calls", index=0,
        )],
        model="m",
    )
    out = await guard.async_post_call_success_hook(
        data={"messages": [], "metadata": md},
        user_api_key_dict=None,
        response=response,
    )
    # Block path: tool_calls dropped, content carries the block string.
    assert out.choices[0].message.tool_calls in (None, [])
    assert "malformed" in (out.choices[0].message.content or "").lower()
    assert out.choices[0].finish_reason == "stop"


# ── Concurrency ────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_concurrent_same_session_pre_calls_are_rejected():
    """Two concurrent pre_calls on the same session id: one succeeds,
    the other is fail-closed-rejected with HTTP 409.

    The per-session lock serialises the hook bodies, but a turn spans
    pre_call → upstream → post_call. The in-flight token prevents a
    second pre_call from interleaving while the first request's
    post_call hasn't fired.
    """
    guard = build_guardrail()
    sid = "s-concurrency"
    md = {"agent_shield_session_id": sid}

    outcomes = {}

    async def one(label):
        try:
            await guard.async_pre_call_hook(
                user_api_key_dict=None,
                cache=None,
                data={
                    "messages": [
                        {"role": "user", "content": f"hi from {label}"},
                    ],
                    "metadata": dict(md),
                },
                call_type="completion",
            )
            outcomes[label] = "ok"
        except HTTPException as exc:
            outcomes[label] = ("blocked", exc.status_code)

    await asyncio.gather(one("A"), one("B"))
    # Exactly one succeeded; the other got HTTP 409 with the
    # concurrent-in-flight reason.
    statuses = list(outcomes.values())
    assert statuses.count("ok") == 1, (
        f"expected exactly one success; got {outcomes!r}"
    )
    blocked = [s for s in statuses if s != "ok"]
    assert len(blocked) == 1
    assert blocked[0] == ("blocked", 409)


@pytest.mark.asyncio
async def test_concurrent_distinct_sessions_both_proceed():
    """Concurrent requests on DIFFERENT session ids both succeed —
    the in-flight token is per-session."""
    guard = build_guardrail()
    finished = []

    async def one(sid_local):
        await guard.async_pre_call_hook(
            user_api_key_dict=None,
            cache=None,
            data={
                "messages": [{"role": "user", "content": "hi"}],
                "metadata": {"agent_shield_session_id": sid_local},
            },
            call_type="completion",
        )
        finished.append(sid_local)

    await asyncio.gather(one("session-A"), one("session-B"))
    assert set(finished) == {"session-A", "session-B"}


@pytest.mark.asyncio
async def test_in_flight_token_cleared_on_failure_hook():
    """Without async_post_call_failure_hook the in-flight token from
    a failed upstream call would persist until it timed out, blocking
    every subsequent request on the same session id with 409.

    Verify the failure hook clears the token so the next request
    proceeds cleanly.
    """
    guard = build_guardrail()
    sid = "s-failure-clear"
    md = {"agent_shield_session_id": sid}

    # First request opens the in-flight cycle.
    await guard.async_pre_call_hook(
        user_api_key_dict=None, cache=None,
        data={"messages": make_messages("user", "go"), "metadata": dict(md)},
        call_type="completion",
    )
    entry = guard._sessions.get_or_create(sid)
    assert entry.in_flight_token is not None

    # Upstream errors → failure hook fires → token cleared.
    await guard.async_post_call_failure_hook(
        request_data={"metadata": dict(md)},
        original_exception=RuntimeError("upstream timeout"),
        user_api_key_dict=None,
    )
    assert entry.in_flight_token is None

    # Next request proceeds cleanly.
    await guard.async_pre_call_hook(
        user_api_key_dict=None, cache=None,
        data={"messages": make_messages("user", "retry"), "metadata": dict(md)},
        call_type="completion",
    )
    assert entry.in_flight_token is not None  # new token


@pytest.mark.asyncio
async def test_concurrent_409_does_not_clobber_active_request_state():
    """A 409 raised by _begin_in_flight for a SECOND same-session
    request must NOT call _safe_end_turn / _clear_in_flight on the
    entry. Doing so would clobber the first (legitimate) request's
    turn + token, breaking the in-flight protection it was supposed
    to provide.
    """
    guard = build_guardrail()
    sid = "s-409-no-clobber"
    md = {"agent_shield_session_id": sid}

    # First request opens the in-flight cycle.
    await guard.async_pre_call_hook(
        user_api_key_dict=None, cache=None,
        data={"messages": make_messages("user", "first"),
              "metadata": dict(md)},
        call_type="completion",
    )
    entry = guard._sessions.get_or_create(sid)
    assert entry.turn_open is True
    first_token = entry.in_flight_token
    assert first_token is not None

    # Second request — should raise 409 BUT must not touch the
    # first request's state.
    with pytest.raises(HTTPException) as exc:
        await guard.async_pre_call_hook(
            user_api_key_dict=None, cache=None,
            data={"messages": make_messages("user", "second"),
                  "metadata": dict(md)},
            call_type="completion",
        )
    assert exc.value.status_code == 409
    assert entry.turn_open is True, (
        "first request's open turn must survive the 409 rejection"
    )
    assert entry.in_flight_token == first_token, (
        f"first request's token must survive the 409; "
        f"was {first_token!r}, now {entry.in_flight_token!r}"
    )



# ── Session-id resolution ─────────────────────────────────────────────


def test_session_id_resolution_priority():
    """``metadata.agent_shield_session_id`` > ``litellm_session_id`` > ``user``."""
    cls = AgentShieldLiteLLMGuardrail
    assert cls._resolve_session_id(
        {"metadata": {"agent_shield_session_id": "X"},
         "litellm_session_id": "Y", "user": "Z"},
    ) == "X"
    assert cls._resolve_session_id(
        {"litellm_session_id": "Y", "user": "Z"},
    ) == "Y"
    assert cls._resolve_session_id({"user": "Z"}) == "Z"
    assert cls._resolve_session_id({}).startswith("litellm-proxy-")


def test_session_id_fallback_is_persisted_into_metadata():
    """When the resolver mints a fresh UUID it must persist it back
    into ``data["metadata"]["agent_shield_session_id"]`` so subsequent
    hooks for the same LiteLLM HTTP request resolve the same session.

    Without this, Stage 1 (`pre_call`) and Stages 2/3/5 (`post_call`)
    would run against independent random session ids — the Stage 1
    turn would orphan and the post-call hook would hit the
    "no open turn" guard.
    """
    cls = AgentShieldLiteLLMGuardrail

    # No prior session fields → resolver mints + persists.
    data = {"messages": [{"role": "user", "content": "hi"}]}
    sid1 = cls._resolve_session_id(data)
    assert data["metadata"]["agent_shield_session_id"] == sid1
    sid2 = cls._resolve_session_id(data)
    assert sid1 == sid2, (
        f"second resolve must return the persisted id, got {sid1!r} vs {sid2!r}"
    )

    # Existing non-dict metadata gets replaced by a dict carrying the id.
    data = {"messages": [], "metadata": "not-a-dict"}
    sid3 = cls._resolve_session_id(data)
    assert isinstance(data["metadata"], dict)
    assert data["metadata"]["agent_shield_session_id"] == sid3


@pytest.mark.asyncio
async def test_multi_choice_request_is_rejected():
    """A request with `n > 1` is fail-closed-blocked at pre_call.

    The guardrail only validates choices[0] of the response (both
    non-streaming and streaming paths), so allowing n > 1 would
    silently leak unvalidated content from choices[1..N-1]. v1 of the
    integration refuses these requests at the edge rather than
    forwarding them.
    """
    guard = build_guardrail()
    data = {
        "messages": make_messages("user", "anything"),
        "n": 3,
        "metadata": {"agent_shield_session_id": "s-multi"},
    }
    with pytest.raises(HTTPException) as exc:
        await guard.async_pre_call_hook(
            user_api_key_dict=None, cache=None, data=data,
            call_type="completion",
        )
    assert exc.value.status_code == 400
    assert "n > 1" in exc.value.detail
    assert "n=3" in exc.value.detail


@pytest.mark.asyncio
async def test_n_equals_1_and_missing_n_are_allowed():
    """n=1 (explicit or omitted) is the normal path and must work."""
    guard = build_guardrail()
    for body in (
        {"messages": make_messages("user", "ok"),
         "metadata": {"agent_shield_session_id": "s-n1-explicit"},
         "n": 1},
        {"messages": make_messages("user", "ok"),
         "metadata": {"agent_shield_session_id": "s-n1-implicit"}},
    ):
        result = await guard.async_pre_call_hook(
            user_api_key_dict=None, cache=None, data=body,
            call_type="completion",
        )
        assert result is body


def test_multi_choice_guard_ignores_non_int_n():
    """Garbage `n` values (string, None, non-numeric) don't crash the
    guard — they fall through as if `n` were absent. The post-call
    path will then see whatever the upstream returned; if the model
    interprets the bad value as n>1 and returns multiple choices,
    Stage 5 still only inspects choices[0]. This is the same fail-open
    surface as a client that lies about the request shape; documented
    in docs/integrations/litellm-proxy.md.
    """
    cls = AgentShieldLiteLLMGuardrail
    # Should not raise.
    cls._reject_multi_choice({"n": "not-a-number"})
    cls._reject_multi_choice({"n": None})
    cls._reject_multi_choice({})


@pytest.mark.asyncio
async def test_post_call_blocks_multi_choice_response():
    """If a response arrives with len(choices) > 1 — either because
    the operator registered post_call-only (so the pre_call guard
    didn't fire) or because the upstream returned more choices than
    requested — the post-call hook must fail closed by rewriting
    the response into a single-choice block message.
    """
    guard = build_guardrail()
    sid = "s-postcall-multichoice"
    md = {"agent_shield_session_id": sid}

    response = ModelResponse(
        choices=[
            Choices(
                message=Message(content="benign", role="assistant"),
                finish_reason="stop", index=0,
            ),
            Choices(
                message=Message(content="LEAK SECRET-ABCDEF",
                                role="assistant"),
                finish_reason="stop", index=1,
            ),
        ],
        model="m",
    )

    rewritten = await guard.async_post_call_success_hook(
        data={"messages": make_messages("user", "go"), "metadata": md},
        user_api_key_dict=None,
        response=response,
    )

    # Now has exactly one choice, content is the block string, no
    # leak of choices[1]'s SECRET token.
    assert len(rewritten.choices) == 1
    blocked = rewritten.choices[0].message.content or ""
    assert "SECRET-ABCDEF" not in blocked
    assert blocked.startswith("[GUARDRAIL ")
    assert rewritten.choices[0].finish_reason == "stop"


@pytest.mark.asyncio
async def test_streaming_blocks_multi_choice_response():
    """Streaming variant: if any upstream chunk carries len(choices)
    > 1 or a choice with index > 0, the buffered assembler flags
    saw_extra_choices and the hook emits a single block chunk."""
    guard = build_guardrail()
    sid = "s-stream-multichoice"
    md = {"agent_shield_session_id": sid}
    await guard.async_pre_call_hook(
        user_api_key_dict=None, cache=None,
        data={"messages": make_messages("user", "go"), "metadata": md},
        call_type="completion",
    )
    # Two parallel choices on the same chunk — providers that
    # multiplex n>1 into one stream do this.
    chunks = [
        ModelResponseStream(id="m1", model="m", choices=[
            StreamingChoices(
                index=0, delta=Delta(content="benign"),
                finish_reason=None,
            ),
            StreamingChoices(
                index=1, delta=Delta(content="LEAK SECRET-X"),
                finish_reason=None,
            ),
        ]),
        ModelResponseStream(id="m1", model="m", choices=[
            StreamingChoices(
                index=0, delta=Delta(content=None), finish_reason="stop",
            ),
        ]),
    ]
    out = await collect(
        guard.async_post_call_streaming_iterator_hook(
            user_api_key_dict=None,
            response=chunk_stream(chunks),
            request_data={"metadata": md},
        )
    )
    assert len(out) == 1, "expected a single block chunk; got {len(out)}"
    chunk = out[0]
    content = chunk.choices[0].delta.content or ""
    assert "SECRET-X" not in content
    assert content.startswith("[GUARDRAIL ")
    assert chunk.choices[0].finish_reason == "stop"


@pytest.mark.asyncio
async def test_no_session_id_pre_and_post_resolve_same_session():
    """End-to-end variant of the persistence test: a pre_call + post_call
    sequence on a `data` dict with no session fields must hit the
    same `_Entry` in the session cache, so the post-call hook sees
    the open turn left by Stage 1.
    """
    guard = build_guardrail()
    data = {"messages": [{"role": "user", "content": "hi"}]}
    await guard.async_pre_call_hook(
        user_api_key_dict=None, cache=None, data=data, call_type="completion",
    )
    # Resolver persisted an id; cache has exactly one entry with turn_open=True.
    assert len(guard._sessions) == 1
    sid = data["metadata"]["agent_shield_session_id"]
    entry = guard._sessions.get_or_create(sid)
    assert entry.turn_open is True

    # post_call uses the same `data` dict (same Python object) — LiteLLM
    # is consistent about this across the request lifecycle.
    await guard.async_post_call_success_hook(
        data=data,
        user_api_key_dict=None,
        response=make_response(content="hello", finish_reason="stop"),
    )
    # Still one cache entry; the same one we opened in pre_call; turn
    # closed by Stage 5.
    assert len(guard._sessions) == 1
    assert guard._sessions.get_or_create(sid).turn_open is False



    """End-to-end variant of the persistence test: a pre_call + post_call
    sequence on a `data` dict with no session fields must hit the
    same `_Entry` in the session cache, so the post-call hook sees
    the open turn left by Stage 1.
    """
    guard = build_guardrail()
    data = {"messages": [{"role": "user", "content": "hi"}]}
    await guard.async_pre_call_hook(
        user_api_key_dict=None, cache=None, data=data, call_type="completion",
    )
    # Resolver persisted an id; cache has exactly one entry with turn_open=True.
    assert len(guard._sessions) == 1
    sid = data["metadata"]["agent_shield_session_id"]
    entry = guard._sessions.get_or_create(sid)
    assert entry.turn_open is True

    # post_call uses the same `data` dict (same Python object) — LiteLLM
    # is consistent about this across the request lifecycle.
    await guard.async_post_call_success_hook(
        data=data,
        user_api_key_dict=None,
        response=make_response(content="hello", finish_reason="stop"),
    )
    # Still one cache entry; the same one we opened in pre_call; turn
    # closed by Stage 5.
    assert len(guard._sessions) == 1
    assert guard._sessions.get_or_create(sid).turn_open is False


@pytest.mark.asyncio
async def test_stage5_fires_on_empty_final_response():
    """A final assistant response with `content=""` must still run
    Stage 5. Stage-5 policies that gate on session state (rather than
    on regex matches against the text) need to fire even when the
    model emits an empty completion. The core decides the verdict."""
    guard = build_guardrail()
    sid = "s-stage5-empty"
    await guard.async_pre_call_hook(
        user_api_key_dict=None, cache=None,
        data={"messages": make_messages("user", "say nothing"),
              "metadata": {"agent_shield_session_id": sid}},
        call_type="completion",
    )

    # Spy validate_output to confirm it's called for empty content.
    entry = guard._sessions.get_or_create(sid)
    seen: list = []
    real = entry.session.validate_output
    def spy(text):
        seen.append(text)
        return real(text)
    entry.session.validate_output = spy

    await guard.async_post_call_success_hook(
        data={"messages": [], "metadata": {"agent_shield_session_id": sid}},
        user_api_key_dict=None,
        response=make_response(content="", finish_reason="stop"),
    )
    assert seen == [""], (
        f"expected validate_output('') exactly once; got {seen!r}"
    )
    # Turn still closes cleanly.
    assert guard._sessions.get_or_create(sid).turn_open is False



@pytest.mark.asyncio
async def test_session_cache_delegates_eviction_protection_to_rust_core():
    """The cache mechanics that used to live in this Python module
    (lease counter, locked-entry skip, just-inserted-entry skip)
    moved to ``agent_shield_core::integrations::hooks`` and are
    covered there by ``sdk/rust/agent_shield_core/tests/hooks_integration.rs``
    (``registry_lru_eviction_when_over_capacity``,
    ``registry_eviction_skips_held_entries``,
    ``registry_lease_counter_is_visible_inside_critical_section``).

    This smoke test verifies the Python ``SessionCache`` wrapper still
    delegates to that Rust registry: an entry whose lease is held
    cannot be reclaimed before the lease drops, so a follow-up
    ``acquire`` on the same session id sees the same underlying
    session.
    """
    from agent_shield.integrations.litellm_proxy._session_cache import (
        SessionCache,
    )
    cache = SessionCache(_minimal_runtime(), max_size=1, ttl_seconds=0)
    held = cache.get_or_create("S")
    held.session.begin_turn()
    # Force overflow: the held entry must NOT be evicted.
    other = cache.get_or_create("X")
    # The same session id resolves to the same underlying session
    # state (turn still open from the held entry).
    again = cache.get_or_create("S")
    assert again.turn_open, "held entry must survive overflow"
    held.hook.release()
    other.hook.release()
    again.hook.release()


def _minimal_runtime():
    """Build the smallest valid runtime for cache tests."""
    from agent_shield import RuntimeBuilder
    import os, tempfile
    yaml = """
metadata:
  name: \"litellm-cache-test\"
  version: \"0.1.0\"
  agent_shield_version: \"2.0\"
objective:
  goal: [\"t\"]
  forbidden: [\"n\"]
resources:
  tools:
    - name: \"echo\"
      description: \"e\"
      permission: \"read_only\"
"""
    fd, path = tempfile.mkstemp(suffix=".yaml")
    try:
        with os.fdopen(fd, "w") as f:
            f.write(yaml)
        return RuntimeBuilder.from_yaml(path).build()
    finally:
        try: os.unlink(path)
        except OSError: pass
