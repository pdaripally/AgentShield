"""End-to-end test for the canonical `agent_shield.ask_human` flow.

Covers the deny → tool-call → resolve loop that replaces the legacy
``HumanResolver`` host callback. The flow under test:

1. A guard policy denies because a ``kind: human`` resolver is unset.
2. The deny verdict carries a ``pending_resolution`` field that names
   the canonical MCP tool ``agent_shield.ask_human`` and the
   variable / prompt / request_id triple.
3. The agent is expected to call that tool; we mock the call by
   directly writing the human's response into the variable.
4. Retrying the original tool succeeds.
5. If the agent loops without ever populating the variable, the
   runtime emits ``incident.resolution_loop`` once the per-turn
   retry bound is exhausted.
"""
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(REPO_ROOT / "sdk" / "python"))

import pytest

from agent_shield import RuntimeBuilder
from agent_shield.observability import CapturingProvider


YAML = """
metadata:
  name: "ask-human-flow"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["block until authorized"]
  forbidden: ["skip authorization"]
resources:
  tools:
    - name: "send_message"
      description: "Send a message."
      permission: "execute"
variables:
  - name: "send_authorized"
    type: "boolean"
    on_demand_by:
      kind: "human"
      prompt: "Approve sending message?"
    lifetime: "per_session"
state_validation:
  guard_policies:
    - name: "send_requires_authorization"
      applies_to:
        tools: ["send_message"]
      evaluate_when:
        - expression: "send_authorized == true"
          reason: "Send was not authorized."
      action: "block"
"""


def _build():
    cap = CapturingProvider()
    with tempfile.NamedTemporaryFile(
        "w", suffix=".guardrails.yaml", delete=False
    ) as f:
        f.write(YAML)
        path = f.name
    try:
        rt = (
            RuntimeBuilder.from_yaml(path)
            .register_observability_provider(cap)
            .build()
        )
        return rt, cap
    finally:
        os.unlink(path)


def test_deny_carries_pending_resolution_for_canonical_tool():
    rt, _ = _build()
    with rt.new_session(session_id="s1", correlation_id="c1") as session:
        session.begin_turn()
        outcome = session.validate_tool_call(
            "send_message", {"to": "alice@example.com"}, tool_call_id="call_1"
        )
        assert outcome.verdict.allowed is False, "send must block until authorized"
        pending = outcome.verdict.pending_resolution
        assert pending is not None, "deny verdict must carry pending_resolution"
        assert pending["tool"] == "agent_shield.ask_human"
        assert pending["variable"] == "send_authorized"
        assert pending["kind"] == "human"
        assert pending["prompt"] == "Approve sending message?"
        assert pending["request_id"]  # non-empty


def test_after_human_responds_the_retry_succeeds():
    """Mock the agent calling agent_shield.ask_human and the tool's
    populator writing the response."""
    rt, _ = _build()
    with rt.new_session(session_id="s2", correlation_id="c2") as session:
        session.begin_turn()
        # First attempt blocks.
        first = session.validate_tool_call(
            "send_message", {"to": "alice@example.com"}, tool_call_id="call_1"
        )
        assert first.verdict.allowed is False
        # The host's MCP server `agent_shield.ask_human` returns
        # `{decision: allow, value: true}`. The runtime's host writes
        # this back through the populator (here we shortcut by writing
        # the variable directly via the host API, which is the same
        # tracker write `populated_by:` would perform).
        session.set_variable("send_authorized", True)
        # Retry — the gate now passes.
        second = session.validate_tool_call(
            "send_message", {"to": "alice@example.com"}, tool_call_id="call_2"
        )
        assert second.verdict.allowed is True


def test_resolution_loop_fires_when_agent_doesnt_populate():
    """Per spec §11.10.2, the runtime bounds the retry loop at
    ``tool_retry_limit`` (default 3) per (turn, variable, tool). Once
    exhausted, an ``incident.resolution_loop`` event fires and the
    resolver is suppressed for the rest of the turn."""
    rt, cap = _build()
    with rt.new_session(session_id="s3", correlation_id="c3") as session:
        session.begin_turn()
        # Drive the agent's "retry without populating" loop by issuing
        # the same tool call repeatedly. Each call resuspends the
        # resolver until the retry bound is hit.
        for idx in range(5):  # > DEFAULT_TOOL_RETRY_LIMIT (3)
            outcome = session.validate_tool_call(
                "send_message",
                {"to": "alice@example.com"},
                tool_call_id=f"call_{idx + 3}",
            )
            assert outcome.verdict.allowed is False

        # The runtime emits the incidents through the observability
        # dispatcher with ``event_type == "incident_emitted"`` and the
        # specific incident name surfaced through the message or
        # attributes payload.
        incidents = [
            ev for ev in cap.events
            if ev.event_type == "incident_emitted"
        ]
        assert any(
            "resolution_loop" in (ev.message or "")
            or "resolution_loop" in str(ev.attributes or {})
            for ev in incidents
        ), (
            "expected an incident.resolution_loop emission; got: "
            f"{[(ev.event_type, ev.message, ev.attributes) for ev in incidents]}"
        )


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
