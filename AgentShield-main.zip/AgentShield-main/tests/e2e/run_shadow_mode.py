"""E2E runner for the runtime-wide shadow / active mode (microsoft/AgentShield#14).

Runs the same scenario in both modes and asserts:

* `Runtime.mode` reflects the YAML `mode:` key;
* the active run blocks at Stage 1 (verdict.allowed = false);
* the shadow run emits a Stage 1 block event tagged
  `mode: shadow, enforced: false`;
* Stage 3 redact mutates `params` in active mode and leaves them
  untouched in shadow.

Deeper coverage (resolver / approval suppression, multi-policy Stage 3
parity, populator extractor parity) lives in
`sdk/rust/agent_shield_core/tests/shadow_mode.rs`. This runner is the
framework-agnostic Python surface check and intentionally exercises
just the cross-language Runtime / Session API.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any

# Mirror conftest.py's sys.path injection so this file works whether
# pytest auto-discovers conftest or not.
_REPO_ROOT = Path(__file__).resolve().parent.parent.parent
_SDK_PYTHON = _REPO_ROOT / "sdk" / "python"
if _SDK_PYTHON.is_dir():
    sys.path.insert(0, str(_SDK_PYTHON))

import pytest

# Mark the file's tests as integration: they require the native
# `agent_shield._native` extension to be built. CI catches that via
# the cross-language workflow.
try:
    import agent_shield  # noqa: F401  (proves native is loadable)
except ImportError as e:  # pragma: no cover - environment-shape guard
    pytest.skip(f"agent_shield native not built: {e}", allow_module_level=True)

from agent_shield import RuntimeBuilder
from agent_shield.observability import ShieldLogEvent


# ─────────────────────────────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────────────────────────────────────────

INPUT_BLOCK_TEMPLATE = """

metadata:
  name: shadow-mode-input-test
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
resources:
  tools:
    - name: echo
      permission: read_only
input_validation:
  guard_policies:
    - name: block_secret
      evaluate_when:
        - pattern: "(?i)secret"
          reason: "input contained secret"
          action: block
"""


TOOL_REDACT_TEMPLATE = """

metadata:
  name: shadow-mode-redact-test
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
resources:
  tools:
    - name: echo
      permission: read_only
tool_execution_validation:
  guard_policies:
    - name: redact_ssn
      applies_to: { tools: ["echo"] }
      evaluate_when:
        - pattern: '\\d{3}-\\d{2}-\\d{4}'
          reason: ssn
          action: redact
      replacement: "[X]"
"""


class _Capture:
    """Minimal in-memory observability provider for assertions."""

    def __init__(self) -> None:
        self.events: list[ShieldLogEvent] = []

    def emit(self, ev: ShieldLogEvent) -> None:
        self.events.append(ev)

    def shutdown(self) -> None:
        pass


def _build(yaml_text: str, capture: _Capture, *, mode: str = "active"):
    return (
        RuntimeBuilder.from_yaml_strings([yaml_text])
        .with_mode(mode)
        .register_observability_provider(capture)
        .build()
    )


# ─────────────────────────────────────────────────────────────────────
# Tests
# ─────────────────────────────────────────────────────────────────────


def test_runtime_mode_reflects_builder_value() -> None:
    cap = _Capture()
    rt_active = _build(INPUT_BLOCK_TEMPLATE, cap, mode="active")
    cap2 = _Capture()
    rt_shadow = _build(INPUT_BLOCK_TEMPLATE, cap2, mode="shadow")
    assert rt_active.mode == "active"
    assert rt_shadow.mode == "shadow"


def test_input_block_active_denies_verdict() -> None:
    cap = _Capture()
    rt = _build(INPUT_BLOCK_TEMPLATE, cap, mode="active")
    sess = rt.new_session(session_id="sess-active")
    verdict = sess.validate_input("this is a secret thing")
    assert not verdict.allowed
    assert verdict.reason is not None


def test_shadow_mode_logs_block_with_enforced_false() -> None:
    cap = _Capture()
    rt = _build(INPUT_BLOCK_TEMPLATE, cap, mode="shadow")
    sess = rt.new_session(session_id="sess-shadow")
    _ = sess.validate_input("this is a secret thing")

    # Find the block event in the capture. Audit events from core stamp
    # both `mode` and `enforced` on every action-bearing entry.
    block_events = [
        e for e in cap.events
        if getattr(e, "action", None) == "block"
        and getattr(e, "guard_policy", None) == "block_secret"
    ]
    assert block_events, f"no block event captured (saw: {[e.event_type for e in cap.events]})"

    ev = block_events[0]
    # Python SDK wraps native events as ShieldLogEvent; both `mode` and
    # `enforced` are present as attributes.
    assert getattr(ev, "mode", None) == "shadow"
    assert getattr(ev, "enforced", None) is False


def test_shadow_tool_redact_still_emits_active_equivalent_verdict() -> None:
    # Core no longer gates mutation in shadow — the SDK orchestrator
    # (`Shield.protect_tool` MONITOR auto-fold) is responsible for
    # discarding mutated params. Direct `Session.validate_tool_call`
    # callers see the same mutated params as active. What core does
    # promise is that the *verdict shape* in shadow matches active
    # so the audit trail records identical decisions.
    cap_shadow = _Capture()
    rt_shadow = _build(TOOL_REDACT_TEMPLATE, cap_shadow, mode="shadow")
    sess_s = rt_shadow.new_session(session_id="sess-shadow")
    outcome_s = sess_s.validate_tool_call(
        "echo", {"msg": "id is 123-45-6789, thanks"}, tool_call_id="call-shadow-1"
    )

    cap_active = _Capture()
    rt_active = _build(TOOL_REDACT_TEMPLATE, cap_active, mode="active")
    sess_a = rt_active.new_session(session_id="sess-active")
    outcome_a = sess_a.validate_tool_call(
        "echo", {"msg": "id is 123-45-6789, thanks"}, tool_call_id="call-active-1"
    )

    assert outcome_s.verdict.allowed == outcome_a.verdict.allowed
    assert outcome_s.verdict.action == outcome_a.verdict.action


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
