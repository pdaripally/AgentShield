"""E2E test runner for the Anthropic Agents SDK adapter .

Reads shared scenarios from ``adapter-scenarios.yaml`` and exercises the
Anthropic-specific adapter surface: ``protect_tools``, ``GuardedRunner``,
and ``_BlockedResult``.

Key Anthropic difference: blocked tools **raise ``ToolError``** instead of
returning a string.
"""
from __future__ import annotations

import json

import pytest

anthropic_mod = pytest.importorskip("anthropic")

from unittest.mock import AsyncMock, MagicMock  # noqa: E402

from anthropic.lib.tools import ToolError  # noqa: E402

from agent_shield import RuntimeBuilder  # noqa: E402
from agent_shield.adapters.anthropic_agents import (  # noqa: E402
    GuardedRunner,
    _BlockedResult,
    protect_tools,
)
from agent_shield.adapters._orchestration import current_session  # noqa: E402

from conftest import (  # noqa: E402
    PII_RESPONSE,
    SpyToolRecord,
    fixture_path,
    load_scenarios,
    make_inline_fixture,
    build_v2_runtime,
)

# ── Capabilities supported by this adapter ──────────────────────────────────

CAPABILITIES: set[str] = {"guarded_agent"}

SCENARIOS = load_scenarios(CAPABILITIES)


# ── Helpers ─────────────────────────────────────────────────────────────────


def _make_spy_tool(name, spy, response="ok"):
    tool = MagicMock()
    tool.name = name
    tool.to_dict.return_value = {
        "name": name,
        "description": f"Test tool: {name}",
        "input_schema": {"type": "object", "properties": {}},
    }

    async def _call(*, input):
        params = dict(input) if input else {}
        spy.record(**params)
        return response

    tool.call = AsyncMock(side_effect=_call)
    return tool


def _tool_response(spec: dict) -> str:
    """Derive the tool response string from a scenario tool spec."""
    if spec.get("response_pii"):
        return PII_RESPONSE
    if "response_sensitivity" in spec:
        return json.dumps({"sensitivity": spec["response_sensitivity"]})
    return spec.get("response", "ok")


def _make_runtime(scenario: dict, tmp_path):
    """Build a Runtime and session from a scenario's fixture spec."""
    if "fixture_inline" in scenario:
        path = make_inline_fixture(scenario["fixture_inline"], tmp_path)
    else:
        path = fixture_path(scenario["fixture"])
    runtime = build_v2_runtime(path)
    session = runtime.new_session()
    session.begin_turn()
    setup = scenario.get("setup", {})
    for var, value in setup.get("variables", {}).items():
        session.set_variable(var, value)
    return runtime, session


# ── Tests ───────────────────────────────────────────────────────────────────


def _scenario_ids() -> list[str]:
    return [s["name"] for s in SCENARIOS]


def _is_simple_tool(s: dict) -> bool:
    return "tool" in s and "steps" not in s and "guarded_agent" not in s


def _is_validate_input(s: dict) -> bool:
    return "validate_input" in s


def _is_steps(s: dict) -> bool:
    return "steps" in s


def _is_guarded_agent(s: dict) -> bool:
    return "guarded_agent" in s


# ── Simple tool scenarios ───────────────────────────────────────────────────


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "scenario",
    [s for s in SCENARIOS if _is_simple_tool(s)],
    ids=[s["name"] for s in SCENARIOS if _is_simple_tool(s)],
)
async def test_simple_tool(scenario, tmp_path):
    runtime, session = _make_runtime(scenario, tmp_path)
    token = current_session.set(session)
    try:
        spy = SpyToolRecord()
        tool_spec = scenario["tool"]
        response = _tool_response(tool_spec)
        raw_tool = _make_spy_tool(tool_spec["name"], spy, response=response)
        protected = protect_tools(runtime, [raw_tool])
        expected = scenario["expected"]

        if not expected.get("tool_invoked", True):
            # Blocked tool: must raise ToolError
            with pytest.raises(ToolError) as exc_info:
                await protected[0].call(input={})
            assert not spy.was_called
            if "result_contains" in expected:
                assert expected["result_contains"] in str(exc_info.value)
            if "result_contains_lower" in expected:
                assert expected["result_contains_lower"] in str(exc_info.value).lower()
        else:
            # Allowed tool
            result = await protected[0].call(input={})
            assert spy.was_called
            if "result" in expected:
                assert result == expected["result"]
            if "result_contains" in expected:
                assert expected["result_contains"] in str(result)
            if "result_not_contains" in expected:
                assert expected["result_not_contains"] not in str(result)
    finally:
        current_session.reset(token)
        try:
            session.end_turn()
        except Exception:  # noqa: BLE001
            pass


# ── Input validation scenarios ──────────────────────────────────────────────


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "scenario",
    [s for s in SCENARIOS if _is_validate_input(s)],
    ids=[s["name"] for s in SCENARIOS if _is_validate_input(s)],
)
async def test_validate_input(scenario, tmp_path):
    runtime, session = _make_runtime(scenario, tmp_path)
    try:
        result = session.validate_input(scenario["validate_input"])
        expected = scenario["expected"]

        if "allowed" in expected:
            assert result.allowed is expected["allowed"]
        if "action" in expected:
            assert result.action == expected["action"]
    finally:
        try:
            session.end_turn()
        except Exception:  # noqa: BLE001
            pass


# ── Multi-step scenarios ────────────────────────────────────────────────────


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "scenario",
    [s for s in SCENARIOS if _is_steps(s)],
    ids=[s["name"] for s in SCENARIOS if _is_steps(s)],
)
async def test_steps(scenario, tmp_path):
    runtime, session = _make_runtime(scenario, tmp_path)
    token = current_session.set(session)
    try:
        for idx, step in enumerate(scenario["steps"], start=1):
            action = step["action"]

            if action == "invoke_tool":
                spy = SpyToolRecord()
                tool_spec = step["tool"]
                response = _tool_response(tool_spec)
                raw_tool = _make_spy_tool(tool_spec["name"], spy, response=response)
                protected = protect_tools(runtime, [raw_tool])
                expected = step.get("expected", {})

                if not expected.get("tool_invoked", True):
                    with pytest.raises(ToolError) as exc_info:
                        await protected[0].call(input={})
                    assert not spy.was_called
                    if "result_contains" in expected:
                        assert expected["result_contains"] in str(exc_info.value)
                    if "result_contains_lower" in expected:
                        assert expected["result_contains_lower"] in str(
                            exc_info.value
                        ).lower()
                else:
                    result = await protected[0].call(input={})
                    assert spy.was_called
                    if "result" in expected:
                        assert result == expected["result"]
                    if "result_contains" in expected:
                        assert expected["result_contains"] in str(result)
                    if "result_not_contains" in expected:
                        assert expected["result_not_contains"] not in str(result)

            elif action == "check_variable":
                value = session.resolve_variable(step["variable"])
                assert value == step["expected_value"], (
                    f"Variable {step['variable']!r}: "
                    f"expected {step['expected_value']!r}, got {value!r}"
                )

            elif action == "set_variable":
                session.set_variable(step["variable"], step["value"])

            elif action == "validate_tool_call":
                outcome = session.validate_tool_call(step["tool_name"], tool_call_id=f"call_{idx}")
                expected = step.get("expected", {})
                if "allowed" in expected:
                    assert outcome.verdict.allowed is expected["allowed"]

            elif action == "reset_variable":
                session.reset_variable(step["variable"])

            else:
                pytest.fail(f"Unknown step action: {action!r}")
    finally:
        current_session.reset(token)
        try:
            session.end_turn()
        except Exception:  # noqa: BLE001
            pass


# ── GuardedAgent scenarios ──────────────────────────────────────────────────


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "scenario",
    [s for s in SCENARIOS if _is_guarded_agent(s)],
    ids=[s["name"] for s in SCENARIOS if _is_guarded_agent(s)],
)
async def test_guarded_agent(scenario, tmp_path):
    runtime, session = _make_runtime(scenario, tmp_path)
    token = current_session.set(session)
    try:
        from agent_shield.adapters.anthropic_agents import _AgentBoundary

        mock_client = MagicMock()
        guarded = GuardedRunner(
            runtime,
            mock_client,
            _AgentBoundary(),
            tools=[],
            model="claude-sonnet-4-20250514",
        )
        input_text = scenario["guarded_agent"]["input"]
        result = await guarded.run(input_text)
        expected = scenario["expected"]

        if not expected.get("agent_invoked", True):
            assert isinstance(result, _BlockedResult)
            if "result_contains" in expected:
                assert expected["result_contains"] in result.final_output
    finally:
        current_session.reset(token)
        try:
            session.end_turn()
        except Exception:  # noqa: BLE001
            pass
