# smoke fixtures

These small hand-rolled fixtures exercise just enough of the spec to
keep the Rust core compiling and tests passing through the migration phases
P1–P10. They are NOT meant to demonstrate every feature — see
`tests/fixtures/comprehensive/` (migrated in P16) for that.

## Files

| File | Exercises |
|------|-----------|
| `minimal.guardrails.yaml` | Smallest valid file: metadata, objective list, identity-only resource, single Stage-2 guard policy, default-true variable. |
| `variables-and-events.guardrails.yaml` | Variable status envelope, lifetime map form, `populated_by[]` / `reset_by[]`, human resolver via `on_demand_by:`, `event.fired()` in `active_if`, `incident.<name>` host-emitted event, status-sugar functions. |
| `guard-policy-merge.guardrails.yaml` + `.parent.guardrails.yaml` | `extends:` chain, additive guard-policy merging, `allowed_when` AND-merge, parent-immutable `active_if`. |
| `redact.guardrails.yaml` | Stage-5 `action: redact` with a regex pattern. Used by cross-language output-validation cases and by Python streaming tests. |
| `event_gate.guardrails.yaml` | Host-emitted `incident.<name>` event gating a tool via `active_if: event.fired(...)`. Used by cross-language event-flow cases. |

## Why these?

Once the loader lands in P1 the existing v1 test fixtures will fail to
load. These three fixtures give us a small green test substrate covering
the highest-risk machinery so each phase boundary (P1 loader, P2
expressions, P3 events/lifetimes, P4 variables, P5 resolvers, P6 guard
policies) has narrow, fast verification without waiting on the much larger
fixture migration in P16.
