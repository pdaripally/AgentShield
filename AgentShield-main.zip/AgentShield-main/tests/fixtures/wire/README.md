# Cross-language wire-shape golden fixtures

This directory holds **golden JSON fixtures** for every shape that
crosses the Agent Shield FFI boundary. Each language SDK validates
that its serialisation / deserialisation round-trips these fixtures,
ensuring the canonical wire contract (defined in
`spec/schemas/wire/*.schema.json`) doesn't drift unnoticed.

## Layout

```
tests/fixtures/wire/
├── stage_verdict/
│   ├── allow.json        ← every Allow verdict shape
│   ├── allow_with_warn.json
│   ├── allow_with_redact.json
│   ├── block.json
│   └── ...
├── variable_state/
├── resolver_request/
├── resolver_response/
├── delegate_request/
├── llm_response/
├── classifier_verdict/
├── shield_log_event/
└── capability_report/
```

Every fixture is a JSON document conforming to the matching schema
under `spec/schemas/wire/`. Field names are snake_case (the canonical
wire format); SDKs may expose them under language-idiomatic naming
(camelCase for Node, PascalCase for .NET, snake_case for Python) but
the wire contract is uniform.

## How fixtures are exercised

* **Rust core** (`agent_shield_core::tests::wire_fixtures`): every
  fixture deserialises into the matching Rust struct AND every Rust
  struct serialises back to JSON that validates against the same
  schema.
* **Python SDK** (`tests/test_wire_fixtures.py`): every fixture loads
  through the SDK's typed wrappers and round-trips back to canonical
  JSON.
* **Node SDK** (`__tests__/wire_fixtures.test.ts`): same.
* **.NET SDK** (`WireFixtureTests.cs`): same.

## Adding fixtures

When a wire shape gains a new field:

1. Add the field to the relevant `spec/schemas/wire/*.schema.json`.
2. Add at least one fixture exercising the new field (and at least
   one that omits it if optional).
3. Run all four conformance suites — every SDK must round-trip the
   new fixture cleanly.

## Conformance contract

A SDK is wire-conformant iff:

1. It deserialises every fixture without error.
2. It re-serialises the deserialised value to canonical JSON that
   validates against the matching schema.
3. The re-serialised JSON is byte-equal to the input fixture (modulo
   whitespace), once both have been canonicalised (sorted keys,
   no insignificant whitespace).

(3) is the strongest property. (1) and (2) are the minimum.
