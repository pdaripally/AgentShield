﻿import json
import re
from pathlib import Path


_STAGE_COLUMN_BY_KEY = {
    "input_validation": "Input",
    "state_validation": "State",
    "tool_authorization": "Tool Authorization",
    "tool_execution_validation": "Tool Execution",
    "tool_output_validation": "Tool Output",
    "output_validation": "Output",
    "streaming_output": "Streaming",
}

# Mapping from canonical capability values (in capability_canonical.json) to
# the title-cased forms the doc table uses. Anything outside this set in
# either source is treated as unknown and surfaced by the test.
_CAPABILITY_TITLE = {
    "full": "Full",
    "partial": "Partial",
    "unsupported": "Unsupported",
}


def _parse_markdown_table(doc_text: str):
    """Parse the single GFM table under the ## Matrix heading and return
    (headers, rows) where rows is a list of dicts keyed by header name.

    The parser is intentionally simple — it locates the header row (which
    starts with `| Adapter |`), then consumes contiguous `|`-delimited
    data rows.
    """
    lines = doc_text.splitlines()
    header_idx = None
    for i, line in enumerate(lines):
        if line.lstrip().startswith("| Adapter "):
            header_idx = i
            break
    assert header_idx is not None, "could not find capability table header in doc"

    headers = [c.strip() for c in lines[header_idx].strip().strip("|").split("|")]
    rows = []
    # Skip the header-separator row (`|---|---|...`) immediately after.
    for line in lines[header_idx + 2 :]:
        if not line.lstrip().startswith("|"):
            break
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) != len(headers):
            continue
        rows.append(dict(zip(headers, cells)))
    return headers, rows


def _framework_name_from_cell(cell: str) -> str:
    """Cell uses Markdown inline code, e.g. `` `crewai` ``. Strip backticks."""
    return cell.strip().strip("`").strip()


def _expected_capability_values(framework_entry: dict, stage_key: str) -> set:
    """Compute the set of capability values (lowercase strings) that the
    doc cell for this (framework, stage) MUST cover — the canonical
    value plus any per-language override for that stage in
    `implemented_in`, plus any `pattern_variants[stage_key]` entries
    that document additional adapter patterns surfaced in the docs.
    Anything the doc shows beyond this set indicates drift from the
    canonical contract.
    """
    canonical = framework_entry["canonical"][stage_key]
    values = {canonical}
    overrides = framework_entry.get("language_overrides", {}) or {}
    for lang in framework_entry.get("implemented_in", []):
        per_lang = overrides.get(lang) or {}
        if stage_key in per_lang:
            values.add(per_lang[stage_key])
    pattern_variants = framework_entry.get("pattern_variants", {}) or {}
    for variant in pattern_variants.get(stage_key, []) or []:
        values.add(variant)
    return values


def test_adapter_mediated_paths_doc_covers_canonical_frameworks():
    root = Path(__file__).resolve().parents[2]
    canonical = json.loads(
        (root / "tests" / "parity" / "capability_canonical.json").read_text(
            encoding="utf-8"
        )
    )
    doc = (root / "docs" / "adapter-mediated-paths.md").read_text(encoding="utf-8")
    missing = [
        framework
        for framework in canonical["frameworks"]
        if f"`{framework}`" not in doc
    ]
    assert not missing, f"docs/adapter-mediated-paths.md missing frameworks: {missing}"


def test_adapter_mediated_paths_doc_states_bypass_rules():
    root = Path(__file__).resolve().parents[2]
    doc = (root / "docs" / "adapter-mediated-paths.md").read_text(encoding="utf-8").lower()
    for phrase in [
        "parallel unguarded",
        "unknown framework tool-call shapes",
        "validate-only apis are not sufficient",
        "unsupported / bypass paths",
    ]:
        assert phrase in doc


def test_adapter_mediated_paths_doc_cells_match_canonical_capabilities():
    """Each per-stage cell in the matrix MUST cover the canonical
    capability plus any per-language override for the languages listed
    in `implemented_in`. The doc may use annotations like
    ``Full/Partial by SDK`` to express drift; the test treats those as
    a set of capability words and verifies the set equals the canonical
    + override set for that (framework, stage) pair.

    This is the regression test for the §16 P0 review finding that the
    matrix can silently drift from `capability_canonical.json` cell by
    cell, defeating the purpose of having a canonical source of truth.
    """
    root = Path(__file__).resolve().parents[2]
    canonical = json.loads(
        (root / "tests" / "parity" / "capability_canonical.json").read_text(
            encoding="utf-8"
        )
    )
    doc = (root / "docs" / "adapter-mediated-paths.md").read_text(encoding="utf-8")

    _, rows = _parse_markdown_table(doc)
    rows_by_framework = {_framework_name_from_cell(r["Adapter"]): r for r in rows}

    missing_rows = [fw for fw in canonical["frameworks"] if fw not in rows_by_framework]
    assert not missing_rows, (
        f"docs/adapter-mediated-paths.md is missing rows for: {missing_rows}"
    )

    failures = []
    for framework, entry in canonical["frameworks"].items():
        row = rows_by_framework[framework]
        for stage_key, column_name in _STAGE_COLUMN_BY_KEY.items():
            cell = row.get(column_name, "")
            # Extract every capability word from the cell, ignoring
            # annotation glue like "by SDK" / "by pattern" / "/".
            tokens = re.split(r"[\s/]+", cell)
            cell_values = set()
            for tok in tokens:
                tok_norm = tok.strip().lower()
                if not tok_norm:
                    continue
                if tok_norm in _CAPABILITY_TITLE:
                    cell_values.add(tok_norm)
            expected = _expected_capability_values(entry, stage_key)

            unknown_capabilities = {v for v in expected if v not in _CAPABILITY_TITLE}
            if unknown_capabilities:
                failures.append(
                    f"{framework}.{stage_key}: canonical/override uses unknown "
                    f"capability value(s) {sorted(unknown_capabilities)}; update "
                    f"_CAPABILITY_TITLE if the spec adds new tiers"
                )
                continue
            if cell_values != expected:
                failures.append(
                    f"{framework} row, '{column_name}' column = `{cell}` → cell "
                    f"capability set {sorted(cell_values)} != expected "
                    f"{sorted(expected)} (canonical[{stage_key}] + "
                    f"language_overrides for {entry.get('implemented_in')})"
                )

    assert not failures, "doc/canonical cell drift:\n  - " + "\n  - ".join(failures)


def test_adapter_mediated_paths_doc_implemented_sdks_match_canonical():
    """The `Implemented SDKs` column MUST name exactly the languages in
    `implemented_in` (case-insensitive, comma-separated). Catches
    regressions like the original `mcp` row claiming "Rust/proxy
    patterns" when canonical lists `python, node, dotnet`.
    """
    root = Path(__file__).resolve().parents[2]
    canonical = json.loads(
        (root / "tests" / "parity" / "capability_canonical.json").read_text(
            encoding="utf-8"
        )
    )
    doc = (root / "docs" / "adapter-mediated-paths.md").read_text(encoding="utf-8")
    _, rows = _parse_markdown_table(doc)
    rows_by_framework = {_framework_name_from_cell(r["Adapter"]): r for r in rows}

    # Display-name mapping: canonical uses lowercase short ids, the doc
    # uses friendlier capitalization.
    canonical_to_display = {
        "python": "python",
        "node": "node",
        "rust": "rust",
        "dotnet": ".net",
    }

    failures = []
    for framework, entry in canonical["frameworks"].items():
        cell = rows_by_framework[framework].get("Implemented SDKs", "")
        cell_tokens = {
            t.strip().lower() for t in cell.split(",") if t.strip()
        }
        expected_tokens = {
            canonical_to_display[lang] for lang in entry.get("implemented_in", [])
        }
        if cell_tokens != expected_tokens:
            failures.append(
                f"{framework}: 'Implemented SDKs' = `{cell}` → tokens "
                f"{sorted(cell_tokens)} != canonical implemented_in "
                f"{sorted(expected_tokens)}"
            )
    assert not failures, "implemented-SDKs drift:\n  - " + "\n  - ".join(failures)

