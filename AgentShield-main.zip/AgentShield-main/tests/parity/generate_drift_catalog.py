#!/usr/bin/env python3
"""Generate the cross-language drift catalog from the canonical parity contracts.

The catalog is a SUMMARY artifact derived from the two canonical JSONs in
this directory:

* ``shield_canonical_api.json`` — declares every public Shield/ShieldBuilder
  method, the languages it must exist in, and the per-language alias.
* ``capability_canonical.json`` — declares every framework's canonical
  CapabilityReport plus the per-language overrides documenting accepted
  divergence.

Both canonical files are themselves the source of truth that the existing
per-SDK parity tests (``sdk/{python,node,rust,dotnet}/.../parity_*``)
assert against the live SDKs. So flattening them here is equivalent to
reflecting on the SDKs — but cheaper, language-agnostic, and stable.

The catalog has a fixed schema (``drift-catalog.schema.json``) and is
checked into the repo. The companion test
(``sdk/python/tests/parity/test_drift_catalog_current.py``) regenerates
it on every test run and CI-fails if the checked-in copy diverges.

Usage::

    python3 tests/parity/generate_drift_catalog.py > tests/parity/drift-catalog.json
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
SHIELD_CANONICAL = HERE / "shield_canonical_api.json"
CAPABILITY_CANONICAL = HERE / "capability_canonical.json"
SCHEMA_REL = "./drift-catalog.schema.json"

LANGUAGES: tuple[str, ...] = ("python", "node", "rust", "dotnet")
STAGES: tuple[str, ...] = (
    "input_validation",
    "state_validation",
    "tool_authorization",
    "tool_execution_validation",
    "tool_output_validation",
    "output_validation",
    "streaming_output",
)
# Higher-permission claims (left) overclaim relative to lower (right).
CLAIM_ORDER: dict[str, int] = {"unsupported": 0, "partial": 1, "full": 2}


def _load(path: Path) -> dict:
    with path.open(encoding="utf-8") as fh:
        return json.load(fh)


def _shield_method_entries(canonical: dict) -> list[dict]:
    """Flatten every Shield/ShieldBuilder method into a per-language matrix."""
    out: list[dict] = []
    for surface, methods in (
        ("shield", canonical["shield_methods"]),
        ("shield_builder", canonical["shield_builder_methods"]),
    ):
        for m in methods:
            must_exist = set(m["must_exist_in"])
            aliases = m.get("aliases", {})
            intentional = bool(m.get("intentional_asymmetry", False))
            languages = {}
            for lang in LANGUAGES:
                exists = lang in must_exist
                languages[lang] = {
                    "exists": exists,
                    "name": aliases.get(lang) if exists else None,
                }
            severity = _shield_method_severity(
                must_exist, aliases, intentional_asymmetry=intentional,
            )
            entry = {
                "surface": surface,
                "concept": m["name"],
                "kind": m["kind"],
                "canonical_doc": m["doc"],
                "languages": languages,
                "drift_severity": severity,
            }
            if intentional:
                entry["intentional_asymmetry"] = True
                if "asymmetry_reason" in m:
                    entry["asymmetry_reason"] = m["asymmetry_reason"]
            out.append(entry)
    out.sort(key=lambda e: (e["surface"], e["concept"]))
    return out


def _shield_method_severity(
    must_exist: set[str],
    aliases: dict[str, str],
    *,
    intentional_asymmetry: bool = False,
) -> str:
    """Score Shield/ShieldBuilder method drift.

    * ``high``   — method missing in at least one language but present in others
                   (functional capability gap).
    * ``medium`` — present in every language but the alias is not a uniform
                   case-insensitive transform of the canonical name (true name
                   drift, not just naming convention).
    * ``low``    — present in every language with a uniform name (just casing),
                   OR an asymmetry explicitly marked ``intentional_asymmetry``
                   in the canonical file (per-language API-shape choices that
                   were considered and accepted).
    """
    missing = set(LANGUAGES) - must_exist
    if missing and must_exist:
        # Asymmetric, but only flag as high if it's not explicitly accepted.
        if intentional_asymmetry:
            return "low"
        return "high"
    # All four languages have the method — check for true name drift.
    canonical_names = {n.lower().replace("_", "") for n in aliases.values() if n}
    if len(canonical_names) > 1:
        return "medium"
    return "low"


def _capability_entries(canonical: dict) -> list[dict]:
    """Flatten every (framework, stage) tuple into a drift entry."""
    out: list[dict] = []
    frameworks = canonical["frameworks"]
    for fw_name in sorted(frameworks):
        fw = frameworks[fw_name]
        impl_in = set(fw["implemented_in"])
        canonical_report = fw["canonical"]
        overrides = fw.get("language_overrides", {})

        # framework name claim is itself a (framework, stage="framework") tuple
        # because Rust/.NET diverge on it.
        for stage in ("framework", *STAGES):
            canonical_claim = canonical_report.get(stage)
            if canonical_claim is None:
                continue
            languages: dict[str, Any] = {}
            for lang in LANGUAGES:
                if lang not in impl_in:
                    languages[lang] = {
                        "implemented": False,
                        "claim": None,
                        "drift": False,
                    }
                    continue
                lang_overrides = overrides.get(lang, {})
                actual_claim = lang_overrides.get(stage, canonical_claim)
                drift = actual_claim != canonical_claim
                lang_entry: dict[str, Any] = {
                    "implemented": True,
                    "claim": actual_claim,
                    "drift": drift,
                }
                if (
                    drift
                    and actual_claim in CLAIM_ORDER
                    and canonical_claim in CLAIM_ORDER
                ):
                    lang_entry["direction"] = (
                        "overclaims"
                        if CLAIM_ORDER[actual_claim] > CLAIM_ORDER[canonical_claim]
                        else "underclaims"
                    )
                languages[lang] = lang_entry

            if not any(v.get("drift") for v in languages.values()):
                continue  # no drift on this (framework, stage) — skip
            out.append(
                {
                    "framework": fw_name,
                    "stage": stage,
                    "canonical_claim": canonical_claim,
                    "languages": languages,
                    "drift_severity": _capability_severity(stage, languages),
                }
            )
    out.sort(key=lambda e: (e["framework"], e["stage"]))
    return out


def _capability_severity(stage: str, languages: dict[str, dict]) -> str:
    """Score capability drift.

    * ``high``   — a language *overclaims* (says ``full`` when canonical is
                   weaker). Security-relevant: customers may rely on coverage
                   the SDK does not actually deliver.
    * ``medium`` — a language *underclaims* (says ``unsupported``/``partial``
                   when canonical is stronger). Safe but inaccurate.
    * ``low``    — naming-only drift (``stage == "framework"``).
    """
    if stage == "framework":
        return "low"
    for lang_entry in languages.values():
        if lang_entry.get("direction") == "overclaims":
            return "high"
    return "medium"


def _framework_naming_entries(capability_canonical: dict) -> list[dict]:
    out = []
    for entry in capability_canonical["drift_catalog"].get("framework_name", []):
        languages = {lang: entry["values"].get(lang) for lang in LANGUAGES}
        out.append(
            {
                "framework_concept": entry["concept"],
                "languages": languages,
                "drift_severity": "low",
            }
        )
    out.sort(key=lambda e: e["framework_concept"])
    return out


def _missing_adapter_entries(capability_canonical: dict) -> list[dict]:
    out = []
    for entry in capability_canonical["drift_catalog"].get(
        "missing_implementations", []
    ):
        out.append(
            {
                "framework": entry["framework"],
                "missing_in": sorted(entry["missing_in"]),
                "rationale": entry.get("rationale"),
            }
        )
    out.sort(key=lambda e: e["framework"])
    return out


def _hash_inputs() -> str:
    h = hashlib.sha256()
    for path in (SHIELD_CANONICAL, CAPABILITY_CANONICAL):
        h.update(path.read_bytes())
    return h.hexdigest()


def _summary(
    shield_api: list[dict],
    capability_reports: list[dict],
    framework_naming: list[dict],
    missing_adapters: list[dict],
) -> dict:
    def by_severity(items: list[dict]) -> dict:
        out = {"high": 0, "medium": 0, "low": 0}
        for item in items:
            sev = item.get("drift_severity", "low")
            out[sev] = out.get(sev, 0) + 1
        return out

    return {
        "shield_api": by_severity(shield_api),
        "capability_reports": by_severity(capability_reports),
        "framework_naming": by_severity(framework_naming),
        "missing_adapters": {"count": len(missing_adapters)},
        "totals": {
            "high": (
                by_severity(shield_api)["high"]
                + by_severity(capability_reports)["high"]
            ),
            "medium": (
                by_severity(shield_api)["medium"]
                + by_severity(capability_reports)["medium"]
            ),
            "low": (
                by_severity(shield_api)["low"]
                + by_severity(capability_reports)["low"]
                + by_severity(framework_naming)["low"]
            ),
        },
    }


def build_catalog() -> dict:
    shield_canonical = _load(SHIELD_CANONICAL)
    capability_canonical = _load(CAPABILITY_CANONICAL)

    shield_api = _shield_method_entries(shield_canonical)
    capability_reports = _capability_entries(capability_canonical)
    framework_naming = _framework_naming_entries(capability_canonical)
    missing_adapters = _missing_adapter_entries(capability_canonical)

    return {
        "$schema": SCHEMA_REL,
        "generated_at": _dt.datetime.now(_dt.timezone.utc)
        .replace(microsecond=0)
        .isoformat()
        .replace("+00:00", "Z"),
        "source_inputs": {
            "shield_canonical_api.json": shield_canonical.get("version", "?"),
            "capability_canonical.json": capability_canonical.get("version", "?"),
            "sha256": _hash_inputs(),
        },
        "languages": list(LANGUAGES),
        "summary": _summary(
            shield_api, capability_reports, framework_naming, missing_adapters
        ),
        "shield_api": shield_api,
        "capability_reports": capability_reports,
        "framework_naming": framework_naming,
        "missing_adapters": missing_adapters,
    }


def main() -> int:
    catalog = build_catalog()
    json.dump(catalog, sys.stdout, indent=2, sort_keys=False)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
