// Cross-language Shield/ShieldBuilder method-parity test for the Node SDK.
//
// Asserts every canonical method declared with `must_exist_in: [..., 'node', ...]`
// in `tests/parity/shield_canonical_api.json` is present on the live `Shield`
// and `ShieldBuilder` classes under the Node alias.
//
// See `tests/parity/README.md` for the full architecture.
//
// Run with:
//   cd sdk/node && node --test ../../tests/parity/test_shield_api_node.mjs

import { test } from 'node:test'
import assert from 'node:assert/strict'
import * as fs from 'node:fs'
import * as path from 'node:path'
import { fileURLToPath } from 'node:url'
import { createRequire } from 'node:module'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const REPO_ROOT = path.resolve(__dirname, '..', '..')
const CANONICAL_PATH = path.join(REPO_ROOT, 'tests', 'parity', 'shield_canonical_api.json')
const LANG = 'node'

// Load the SDK from sdk/node/dist — the TypeScript wrapper emits .js
// files there. createRequire anchored at a real file in dist/ resolves
// `./shield.js`, `./adapters/*.js`, etc. against the build output.
const require = createRequire(path.join(REPO_ROOT, 'sdk', 'node', 'dist', 'index.js'))
const { Shield, ShieldBuilder } = require('./shield.js')
// Side-effect imports that monkey-install with<Framework>() / run<Framework>Agent().
require('./adapters/langchain.js')
require('./adapters/openai_agents.js')
require('./adapters/anthropic_agents.js')

const canonical = JSON.parse(fs.readFileSync(CANONICAL_PATH, 'utf-8'))

/**
 * Public method / accessor / static names on `cls`. Walks the prototype
 * chain (skipping Object), the static side, and the constructor's `this.X =`
 * assignments (the same source-text probe trick the Python test uses, since
 * instance fields aren't visible on the prototype).
 */
function publicMembers(cls) {
  const seen = new Set()
  let p = cls.prototype
  while (p && p !== Object.prototype) {
    for (const n of Object.getOwnPropertyNames(p)) {
      if (n === 'constructor' || n.startsWith('_')) continue
      seen.add(n)
    }
    p = Object.getPrototypeOf(p)
  }
  for (const n of Object.getOwnPropertyNames(cls)) {
    if (['length', 'name', 'prototype'].includes(n)) continue
    if (n.startsWith('_')) continue
    seen.add(n)
  }
  // Probe constructor source for `this.foo = ...`
  try {
    const src = cls.toString()
    for (const m of src.matchAll(/this\.([a-zA-Z][a-zA-Z0-9_]*)\s*=/g)) {
      const name = m[1]
      if (!name.startsWith('_')) seen.add(name)
    }
  } catch {
    // best-effort
  }
  return seen
}

function requiredMethods(key) {
  return canonical[key].filter((m) => m.must_exist_in.includes(LANG))
}

test('Shield has every canonical method under its Node alias', () => {
  const members = publicMembers(Shield)
  const missing = []
  for (const entry of requiredMethods('shield_methods')) {
    const alias = entry.aliases[LANG]
    if (!members.has(alias)) {
      missing.push({ name: entry.name, alias })
    }
  }
  assert.deepEqual(
    missing,
    [],
    `Shield is missing ${missing.length} canonical method(s) under their Node ` +
      `aliases: ${JSON.stringify(missing)}. Either add the method to ` +
      `sdk/node/shield.js Shield class or remove '${LANG}' from ` +
      `\`must_exist_in\` in tests/parity/shield_canonical_api.json (and ` +
      `document the drift in \`drift_catalog.method_drift\`).`,
  )
})

test('ShieldBuilder has every canonical method under its Node alias', () => {
  const members = publicMembers(ShieldBuilder)
  const missing = []
  for (const entry of requiredMethods('shield_builder_methods')) {
    const alias = entry.aliases[LANG]
    if (!members.has(alias)) {
      missing.push({ name: entry.name, alias })
    }
  }
  assert.deepEqual(
    missing,
    [],
    `ShieldBuilder is missing ${missing.length} canonical method(s) under ` +
      `their Node aliases: ${JSON.stringify(missing)}. Either add the method ` +
      `to sdk/node/shield.js ShieldBuilder class or remove '${LANG}' from ` +
      `\`must_exist_in\` in tests/parity/shield_canonical_api.json.`,
  )
})

test('No undeclared Node-only public methods on Shield/ShieldBuilder', () => {
  const canonicalShield = new Set(
    canonical.shield_methods
      .filter((e) => LANG in e.aliases)
      .map((e) => e.aliases[LANG]),
  )
  const canonicalBuilder = new Set(
    canonical.shield_builder_methods
      .filter((e) => LANG in e.aliases)
      .map((e) => e.aliases[LANG]),
  )
  const declaredExt = canonical.language_specific_extensions[LANG]
  const extShield = new Set(declaredExt.shield ?? [])
  const extBuilder = new Set(declaredExt.shield_builder ?? [])

  const shieldActual = publicMembers(Shield)
  const builderActual = publicMembers(ShieldBuilder)

  const undeclaredShield = [...shieldActual].filter(
    (n) => !canonicalShield.has(n) && !extShield.has(n),
  )
  const undeclaredBuilder = [...builderActual].filter(
    (n) => !canonicalBuilder.has(n) && !extBuilder.has(n),
  )

  const msgParts = []
  if (undeclaredShield.length) {
    msgParts.push(
      `Shield has ${undeclaredShield.length} undeclared public method(s): ` +
        JSON.stringify(undeclaredShield.sort()),
    )
  }
  if (undeclaredBuilder.length) {
    msgParts.push(
      `ShieldBuilder has ${undeclaredBuilder.length} undeclared public method(s): ` +
        JSON.stringify(undeclaredBuilder.sort()),
    )
  }
  assert.deepEqual(
    msgParts,
    [],
    'Undeclared public surface in Node — every public method must be either ' +
      'in `shield_methods`/`shield_builder_methods` (cross-language canonical) ' +
      'or in `language_specific_extensions.node` (Node-only) in ' +
      'tests/parity/shield_canonical_api.json. Found:\n  - ' +
      msgParts.join('\n  - '),
  )
})
