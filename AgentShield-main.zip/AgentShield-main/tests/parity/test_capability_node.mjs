// Cross-language CapabilityReport conformance test for the Node SDK.
//
// Loads each adapter bundle the Node SDK ships and asserts the live
// `CapabilityReport` matches `applyOverrides(canonical, 'node')` from
// `tests/parity/capability_canonical.json`. Adding an entry to
// `language_overrides.node` documents an accepted divergence; removing one
// forces Node to align.
//
// Run with:
//   cd sdk/node && node --test ../../tests/parity/test_capability_node.mjs

import { test } from 'node:test'
import assert from 'node:assert/strict'
import * as fs from 'node:fs'
import * as path from 'node:path'
import { fileURLToPath } from 'node:url'
import { createRequire } from 'node:module'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const REPO_ROOT = path.resolve(__dirname, '..', '..')
const CANONICAL_PATH = path.join(
  REPO_ROOT,
  'tests',
  'parity',
  'capability_canonical.json',
)
const LANG = 'node'

const require = createRequire(path.join(REPO_ROOT, 'sdk', 'node', 'dist', 'index.js'))

const STAGE_FIELDS = [
  'inputValidation',
  'stateValidation',
  'toolAuthorization',
  'toolExecutionValidation',
  'toolOutputValidation',
  'outputValidation',
  'streamingOutput',
]

const CAMEL_TO_SNAKE = {
  inputValidation: 'input_validation',
  stateValidation: 'state_validation',
  toolAuthorization: 'tool_authorization',
  toolExecutionValidation: 'tool_execution_validation',
  toolOutputValidation: 'tool_output_validation',
  outputValidation: 'output_validation',
  streamingOutput: 'streaming_output',
}

const canonical = JSON.parse(fs.readFileSync(CANONICAL_PATH, 'utf-8'))

function expectedFor(frameworkKey) {
  const entry = canonical.frameworks[frameworkKey]
  const out = { ...entry.canonical }
  const overrides = (entry.language_overrides ?? {})[LANG] ?? {}
  for (const [k, v] of Object.entries(overrides)) {
    if (k.startsWith('$')) continue
    out[k] = v
  }
  return out
}

function reportToWireDict(report) {
  // Node CapabilityReport stores stages on the instance as camelCase strings.
  // Translate to snake_case wire keys for canonical comparison.
  const out = { framework: report.framework }
  for (const k of STAGE_FIELDS) {
    out[CAMEL_TO_SNAKE[k]] = report[k]
  }
  return out
}

function adapterCapabilities() {
  const langchain = require('./adapters/langchain.js')
  const openai = require('./adapters/openai_agents.js')
  const anthropic = require('./adapters/anthropic_agents.js')
  const mcpModule = require('./mcp.js')
  // MCP only exposes the report through an MCPShield instance — there is
  // no module-level export. Instantiate with a sentinel runtime so the
  // capabilities getter is reachable. We never actually use the runtime.
  const mcpShield = new mcpModule.MCPShield(/* runtime */ null)
  return {
    langchain: langchain.capabilities,
    openai_agents: openai.OPENAI_CAPABILITIES,
    anthropic_agents: anthropic.ANTHROPIC_AGENTS_CAPABILITIES,
    mcp: mcpShield.capabilities,
  }
}

const NODE_FRAMEWORKS = Object.entries(canonical.frameworks)
  .filter(([, entry]) => entry.implemented_in.includes(LANG))
  .map(([fw]) => fw)

test('Every Node adapter has a canonical CapabilityReport entry', () => {
  const live = new Set(Object.keys(adapterCapabilities()))
  const declared = new Set(NODE_FRAMEWORKS)
  const missing = [...live].filter((fw) => !declared.has(fw))
  assert.deepEqual(
    missing,
    [],
    `Node ships adapter(s) with no canonical claim: ${JSON.stringify(
      missing,
    )}. Add an entry to tests/parity/capability_canonical.json.`,
  )
})

for (const framework of NODE_FRAMEWORKS) {
  test(`CapabilityReport matches canonical (${framework})`, () => {
    const reports = adapterCapabilities()
    if (!(framework in reports)) {
      assert.fail(
        `Node adapter for framework=${framework} is declared in ` +
          `capability_canonical.json but not loaded in this test. Add the ` +
          `require() at the top of test_capability_node.mjs or remove ` +
          `'${LANG}' from \`implemented_in\`.`,
      )
    }
    const expected = expectedFor(framework)
    const actual = reportToWireDict(reports[framework])
    assert.equal(
      actual.framework,
      expected.framework,
      `[${framework}] framework name drift: actual=${JSON.stringify(
        actual.framework,
      )} expected=${JSON.stringify(
        expected.framework,
      )}. Either update the Node adapter or move this divergence into ` +
        `language_overrides.${LANG} in capability_canonical.json.`,
    )
    const diffs = []
    for (const k of STAGE_FIELDS) {
      const wireKey = CAMEL_TO_SNAKE[k]
      if (actual[wireKey] !== expected[wireKey]) {
        diffs.push(
          `  ${wireKey}: actual=${JSON.stringify(
            actual[wireKey],
          )} expected=${JSON.stringify(expected[wireKey])}`,
        )
      }
    }
    assert.deepEqual(
      diffs,
      [],
      `[${framework}] capability drift between Node and the canonical matrix:\n` +
        diffs.join('\n') +
        `\nTo accept this divergence, add the field to ` +
        `\`frameworks.${framework}.language_overrides.${LANG}\` in ` +
        `tests/parity/capability_canonical.json.`,
    )
  })
}
