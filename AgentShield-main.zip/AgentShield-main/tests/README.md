# Agent Shield — Cross-Language Test Infrastructure

## Overview

This directory contains **shared test fixtures and test cases** that assert
identical behavior across all Agent Shield SDK implementations (Rust, Python,
Node.js, .NET). Every language binding must produce the same validation
outcomes given the same guardrails configuration and input scenario.

## Directory Structure

```
tests/
├── fixtures/                  # Shared guardrails YAML configs and wire-format JSON
│   ├── bank-manager/          # Banking scenario (base + overlay)
│   ├── document-agent/        # DLP / data classification scenario
│   ├── endpoint-governance/   # HTTP endpoint access control scenario
│   ├── extends/               # Composable-config (extends:) chains
│   ├── smoke/                 # Minimal .guardrails.yaml fixtures every loader must accept
│   └── wire/                  # Canonical JSON snapshots of every C ABI wire shape
├── cases/                     # Test case definitions (YAML)
│   ├── input-validation.cases.yaml
│   ├── tool-call.cases.yaml
│   ├── state-transitions.cases.yaml
│   ├── output-validation.cases.yaml
│   ├── config-merging.cases.yaml
│   ├── adapter-scenarios.yaml
│   ├── comprehensive-spec.cases.yaml
│   └── test-cases.schema.json
│                              # Per-language runners live with each SDK
│                              # (sdk/python/tests/test_integration_cases.py,
│                              #  sdk/node/__tests__/integration_cases.test.mjs,
│                              #  sdk/rust/agent_shield_core/tests/integration_cases.rs,
│                              #  sdk/dotnet/tests/AgentShield.Tests/IntegrationCaseTests.cs)
│                              # so each toolchain runs them natively.
├── parity/                    # Drift catalog + canonical Shield API / capability /
│                              # verdict-dispatch fixtures with per-language conformance
├── e2e/                       # Full-stack adapter scenarios driven from the harness
└── README.md                  # This file
```

**Each language's cross-language runner lives in that SDK's own test tree** —
this directory is the shared source of truth (cases + fixtures + parity
contracts), but every runner is owned by, and runs natively under, its
SDK's toolchain. The benefits are uniform `pytest` / `dotnet test` /
`cargo test` / `node --test` ergonomics per SDK and zero scaffolding in
`tests/`.

All four runners load from the same `tests/cases/` and `tests/fixtures/` so
the parity contract holds end-to-end.

## Test Case Format

Each `.cases.yaml` file defines a **suite** of test cases. Every case follows a
`given → when → then` structure:

```yaml
suite: <suite-name>
description: <what this suite verifies>

cases:
  - name: <human-readable test name>
    description: <optional detail>

    given:                          # Setup
      fixtures:                     # YAML guardrails to load
        - bank-manager/bank-base.guardrails.yaml
        - bank-manager/bank-manager-assistant.guardrails.yaml
      attributes:                   # Pre-set runtime attributes
        user_clearance: "manager"
        data_sensitivity: "public"
      approval_handler:             # Optional: mock resolver decision
        decision: allow             # allow | deny | cancelled (per spec §11.3)

    when:                           # Action to perform
      action: validate_tool_call    # See "Action Types" below
      params:                       # Action-specific parameters
        tool_name: send_email
        tool_params:
          to: "user@example.com"

    then:                           # Expected outcome
      allowed: false
      action: block
      reason_contains: "confidential"  # Substring match on reason
      stage: tool_requires
```

### Action Types

| Action | Params | Description |
|--------|--------|-------------|
| `validate_input` | `input` | Run input validation pipeline |
| `validate_tool_call` | `tool_name`, `tool_params` | Run tool authorization pipeline |
| `validate_output` | `output` | Run output validation pipeline |
| `set_attribute` | `name`, `value` | Set a runtime attribute |
| `get_active_states` | — | Query active states |

### Assertion Fields

| Field | Type | Description |
|-------|------|-------------|
| `allowed` | bool | Whether the action was permitted |
| `action` | string | Action taken: allow, block, redact, cancelled, disabled |
| `reason_contains` | string | Substring that must appear in the reason |
| `stage` | string | Validation stage that produced the result |
| `validator` | string | Name of the validator that triggered |
| `text_contains` | string | For redaction: substring in modified text |
| `text_not_contains` | string | For redaction: substring must NOT appear |
| `active_states` | list | Expected active state names |
| `active_states_includes` | string | Single state that must be active |
| `active_states_excludes` | string | Single state that must NOT be active |

### Multi-Step Scenarios

For scenarios requiring multiple sequential operations, use a `steps` array
instead of a single `when`/`then`:

```yaml
  - name: "attribute update activates state"
    given:
      fixtures:
        - bank-manager/bank-manager-assistant.guardrails.yaml
    steps:
      - when:
          action: set_attribute
          params: { name: data_sensitivity, value: "confidential" }
      - when:
          action: get_active_states
        then:
          active_states_includes: "high_sensitivity_mode"
      - when:
          action: validate_tool_call
          params: { tool_name: send_email, tool_params: {} }
        then:
          allowed: false
```

## Running Tests

```bash
# Rust — integration_cases.rs in the core crate's tests/ dir
cd sdk/rust/agent_shield_core && cargo test --test integration_cases

# Python — test_integration_cases.py in the SDK's tests/ dir
pip install -e sdk/python
cd sdk/python && pytest tests/test_integration_cases.py -v

# Node — integration_cases.test.mjs in the SDK's __tests__/ dir
cd sdk/node && npm install && npm run build
node --test __tests__/integration_cases.test.mjs

# .NET — IntegrationCaseTests.cs in AgentShield.Tests
cd sdk/dotnet/tests/AgentShield.Tests && dotnet test
```

Each SDK's CI job (see `.github/workflows/integration.yml`) invokes the
appropriate command above and uploads the case-by-case results.

## Adding Test Cases

1. Add cases to the appropriate `.cases.yaml` file (or create a new one).
2. Run **all four** language test suites to verify consistency.
3. If a case requires a new fixture, add it to `tests/fixtures/`.
4. If the case adds a new action verb or assertion, update
   `tests/cases/test-cases.schema.json` and add the verb to all four runners
   so unknown verbs continue to fail loudly rather than skip silently.
