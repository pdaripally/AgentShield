#!/usr/bin/env bash
# Patch SDK version from a release tag (e.g., vX.Y.Z-alpha.N → X.Y.Z-alpha.N).
# Python gets PEP 440 normalization (alpha→a, beta→b, rc→rc).
# Usage: ./patch-version.sh <version>
# Outputs: PY_VERSION (PEP 440 normalized) written to $GITHUB_OUTPUT if available.
#
# Sources of truth (one per ecosystem):
#   Rust    Cargo.toml                                [workspace.package].version
#   .NET    sdk/dotnet/src/Directory.Build.props      <AgentShieldVersion>
#   Python  sdk/python/pyproject.toml                 version (PEP 440 form)
#   Node    sdk/node/package.json                     version
#
# Every other manifest inherits from one of these four files, so the script
# only patches these four. The post-patch verifier confirms every shipping
# manifest resolved to the expected version; if a new manifest is added that
# doesn't inherit, the verifier will fail loud at patch time instead of three
# jobs later in a downstream build.
set -euo pipefail

VERSION="${1:?Usage: patch-version.sh <version>}"

REPO_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"

# PEP 440 normalization: X.Y.Z-alpha.N → X.Y.ZaN, X.Y.Z-beta.N → X.Y.ZbN, X.Y.Z-rc.N → X.Y.ZrcN
PY_VERSION=$(echo "$VERSION" | sed -E \
  -e 's/-alpha\.?/a/' \
  -e 's/-beta\.?/b/' \
  -e 's/-rc\.?/rc/')

echo "Patching version to: ${VERSION} (Python: ${PY_VERSION})"

# Export PY_VERSION for CI usage (e.g., in release body filenames)
if [ -n "${GITHUB_OUTPUT:-}" ]; then
  echo "py_version=${PY_VERSION}" >> "$GITHUB_OUTPUT"
fi

# Portable in-place sed (works on both GNU and macOS/BSD)
_sed_i() {
  sed -i.bak "$@" && rm -f "${@: -1}.bak"
}

# ── Node (package.json) ──────────────────────────────────────────
NODE_PKG="${REPO_ROOT}/sdk/node/package.json"
if [ -f "$NODE_PKG" ]; then
  NODE_PKG="$NODE_PKG" PKG_VERSION="$VERSION" node -e "
    const fs = require('fs');
    const pkg = JSON.parse(fs.readFileSync(process.env.NODE_PKG, 'utf8'));
    pkg.version = process.env.PKG_VERSION;
    fs.writeFileSync(process.env.NODE_PKG, JSON.stringify(pkg, null, 2) + '\n');
  "
  echo "  ✓ sdk/node/package.json → ${VERSION}"
fi

# ── Python (pyproject.toml) — uses PEP 440 version ──────────────
PYPROJECT="${REPO_ROOT}/sdk/python/pyproject.toml"
if [ -f "$PYPROJECT" ]; then
  _sed_i "s/^version = \".*\"/version = \"${PY_VERSION}\"/" "$PYPROJECT"
  echo "  ✓ sdk/python/pyproject.toml → ${PY_VERSION}"
fi

# ── .NET (single source of truth: Directory.Build.props) ────────
#
# Every shipping csproj under sdk/dotnet/src/ inherits <Version> from
# <AgentShieldVersion> in sdk/dotnet/src/Directory.Build.props, so we
# only need to patch the DBP. Test projects under sdk/dotnet/tests/
# are unaffected (no DBP, and their csprojs set IsPackable=false with
# no <Version> field).
DBP="${REPO_ROOT}/sdk/dotnet/src/Directory.Build.props"
if [ -f "$DBP" ]; then
  _sed_i "s|<AgentShieldVersion>.*</AgentShieldVersion>|<AgentShieldVersion>${VERSION}</AgentShieldVersion>|" "$DBP"
  echo "  ✓ sdk/dotnet/src/Directory.Build.props → ${VERSION}"
fi

# ── Rust workspace ──────────────────────────────────────────────
#
# Every Rust crate (sdk/rust/*, sdk/node, sdk/python) inherits its
# version from [workspace.package].version in the workspace root
# Cargo.toml. We patch ONE line. Inter-crate deps are path-only (no
# version field) so no inter-crate version pinning is needed — the
# whole class of "did we patch agent_shield_anthropic's dep spec?"
# bugs disappears structurally.
WORKSPACE_CARGO="${REPO_ROOT}/Cargo.toml"
if [ -f "$WORKSPACE_CARGO" ]; then
  # Match the version line under [workspace.package] — the file also
  # contains `[workspace]` and `[profile.release]`, neither of which
  # has a `version =` field, but be defensive and match only the
  # workspace.package section by anchoring on its preceding line.
  _sed_i "/^\[workspace\.package\]/,/^\[/ s/^version = \".*\"/version = \"${VERSION}\"/" "$WORKSPACE_CARGO"
  echo "  ✓ Cargo.toml [workspace.package] → ${VERSION}"
fi

# ── Post-patch verification ──────────────────────────────────────
#
# Scan every shipping manifest and assert each version field matches
# either ${VERSION} (canonical) or ${PY_VERSION} (Python's PEP 440
# normalized form). Any mismatch is a silent bug in this script — exit
# loud with a clear list of stale paths so the cause is visible at the
# patch step, not three jobs later in cargo check / npm pack / dotnet pack.
echo ""
echo "Verifying post-patch state..."

STALE=()

# Match a `version = "X.Y.Z"` line OR an XML `<TagName>X.Y.Z</TagName>` element
# and capture the value. Tolerates either format and a missing match (under
# `set -euo pipefail`, an empty grep would otherwise kill the script before we
# could record the diagnostic).
_check() {
  local file="$1" expected="$2" pattern="$3"
  if [ ! -f "$file" ]; then return 0; fi
  local raw actual
  raw=$(grep -oE "$pattern" "$file" | head -1 || true)
  if [ -z "$raw" ]; then
    STALE+=("${file#"${REPO_ROOT}/"}: no match for ${pattern} (format drift?)")
    return 0
  fi
  actual=$(printf '%s' "$raw" | sed -E "s/.*\"([^\"]+)\".*/\1/; s|.*>([^<]+)<.*|\1|")
  if [ "$actual" != "$expected" ]; then
    STALE+=("${file#"${REPO_ROOT}/"}: got '${actual}', expected '${expected}'")
  fi
}

# Reject any Rust member crate that doesn't inherit version from the workspace.
# Future-proofs against someone adding a new crate with a literal version field;
# without this check the verifier would happily pass while shipping a
# wrong-versioned artifact.
_check_inherits_workspace_version() {
  local file="$1"
  if [ ! -f "$file" ]; then return 0; fi
  if ! grep -qE '^version\.workspace = true' "$file"; then
    STALE+=("${file#"${REPO_ROOT}/"}: missing 'version.workspace = true' (literal version field would not be patched)")
  fi
  # Also flag any inter-crate dep that pins a literal version — those should
  # be path-only under the current workspace policy.
  if grep -qE '^agent_shield[a-z_]* = \{ version' "$file"; then
    STALE+=("${file#"${REPO_ROOT}/"}: inter-crate dep pins a literal 'version =' (workspace policy is path-only)")
  fi
}

# Reject any shipping .NET csproj that carries its own <Version> instead of
# inheriting from Directory.Build.props.
_check_csproj_inherits_dbp() {
  local file="$1"
  if [ ! -f "$file" ]; then return 0; fi
  if grep -qE '<Version>[^$<]+</Version>' "$file"; then
    STALE+=("${file#"${REPO_ROOT}/"}: literal <Version> field present (should inherit \$(AgentShieldVersion) from Directory.Build.props)")
  fi
}

# Node package.json: real JSON parse, exact match
if [ -f "$NODE_PKG" ]; then
  NODE_VERSION_ACTUAL=$(NODE_PKG="$NODE_PKG" node -e "
    const fs = require('fs');
    process.stdout.write(JSON.parse(fs.readFileSync(process.env.NODE_PKG, 'utf8')).version);
  ")
  if [ "$NODE_VERSION_ACTUAL" != "$VERSION" ]; then
    STALE+=("sdk/node/package.json: got '${NODE_VERSION_ACTUAL}', expected '${VERSION}'")
  fi
fi

# Python pyproject.toml: PEP 440 form
_check "$PYPROJECT" "$PY_VERSION" '^version = "[^"]+"'

# .NET: single source of truth in Directory.Build.props
_check "$DBP" "$VERSION" '<AgentShieldVersion>[^<]+</AgentShieldVersion>'

# Rust: single source of truth in workspace root Cargo.toml
_check "$WORKSPACE_CARGO" "$VERSION" '^version = "[^"]+"'

# Every Rust member crate must inherit from the workspace.
while IFS= read -r member_cargo; do
  _check_inherits_workspace_version "$member_cargo"
done < <(find "${REPO_ROOT}/sdk/rust" "${REPO_ROOT}/sdk/node" "${REPO_ROOT}/sdk/python" \
  -maxdepth 2 -name 'Cargo.toml' 2>/dev/null)

# Every shipping .NET csproj must inherit from Directory.Build.props.
while IFS= read -r csproj; do
  _check_csproj_inherits_dbp "$csproj"
done < <(find "${REPO_ROOT}/sdk/dotnet/src" -name '*.csproj' 2>/dev/null)

if [ "${#STALE[@]}" -gt 0 ]; then
  echo "::error::patch-version.sh: ${#STALE[@]} manifest(s) failed verification."
  echo "Stale or non-inheriting manifests:"
  for entry in "${STALE[@]}"; do
    echo "  - ${entry}"
  done
  exit 1
fi

echo "  ✓ all manifests verified at ${VERSION} (Python: ${PY_VERSION})"
echo "Done."
