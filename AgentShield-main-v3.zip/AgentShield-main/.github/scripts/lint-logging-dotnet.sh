#!/usr/bin/env bash
# Agent Shield — .NET logging lint (grep fallback).
#
# Flags `_logger.LogInformation` / `LogWarning` / `LogError` /
# `LogCritical` (and `Logger.Log*` static patterns) call sites in
# `sdk/dotnet/src/**/*.cs` whose argument list interpolates a token
# from `.github/scripts/sensitive-names.txt`
# (case-insensitive, separator-insensitive substring).
#
# As of v0.13.0-alpha.1 the .NET SDK has zero `_logger.Log*` call
# sites in production code (operational state goes through
# `IObservabilityProvider` callbacks per docs/logging-style-guide.md
# Rule 7). This script exists as a forward-looking gate so the next
# contributor who adds a logger call doesn't accidentally include
# tool args / PII at info+.
#
# Exits 0 if no violations, 1 otherwise.
#
# Allowed exceptions:
#   - bin/, obj/
#   - tests/**
#   - examples/**

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
SCAN_ROOT="${1:-$REPO_ROOT/sdk/dotnet/src}"
SENSITIVE_FILE="$SCRIPT_DIR/sensitive-names.txt"
DEFAULT_SCAN_ROOT="$REPO_ROOT/sdk/dotnet/src"

if [[ ! -f "$SENSITIVE_FILE" ]]; then
  echo "lint-logging-dotnet.sh: sensitive-names.txt not found at $SENSITIVE_FILE" >&2
  exit 2
fi

normalize_for_match() {
  tr '[:upper:]' '[:lower:]' | tr -d '_-'
}

mapfile -t SENSITIVE_TOKENS < <(grep -vE '^\s*(#|$)' "$SENSITIVE_FILE" | normalize_for_match)
LOG_CALL_PATTERN='\.Log(Information|Warning|Error|Critical)\('

if [[ ${#SENSITIVE_TOKENS[@]} -eq 0 ]]; then
  echo "lint-logging-dotnet.sh: sensitive-names.txt is empty after stripping comments" >&2
  exit 2
fi

VIOLATIONS=0

find_args=(
  "$SCAN_ROOT"
  -type f
  -name '*.cs'
  ! -path '*/bin/*'
  ! -path '*/obj/*'
)

if [[ "$(cd "$SCAN_ROOT" && pwd)" == "$DEFAULT_SCAN_ROOT" ]]; then
  find_args+=(
    ! -path '*/tests/*'
    ! -path '*/examples/*'
  )
fi

mapfile -t FILES < <(find "${find_args[@]}")

for f in "${FILES[@]}"; do
  while IFS= read -r match; do
    line_no="${match%%:*}"
    line_content="${match#*:}"
    trimmed="${line_content#"${line_content%%[![:space:]]*}"}"
    if [[ "$trimmed" == //* ]]; then
      continue
    fi
    normalized_line="$(printf '%s' "$line_content" | normalize_for_match)"
    for token in "${SENSITIVE_TOKENS[@]}"; do
      if [[ -n "$token" && "$normalized_line" == *"$token"* ]]; then
        echo "BUCKET-D: $f:$line_no"
        echo "  $line_content"
        VIOLATIONS=$((VIOLATIONS + 1))
        break
      fi
    done
  done < <(grep -nE "$LOG_CALL_PATTERN" "$f" || true)
done

if [[ $VIOLATIONS -gt 0 ]]; then
  echo
  echo "lint-logging-dotnet.sh: $VIOLATIONS violation(s) found."
  echo "See docs/logging-style-guide.md for the rules."
  exit 1
fi

echo "lint-logging-dotnet.sh: clean ($SCAN_ROOT)"
exit 0
