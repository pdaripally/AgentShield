#!/usr/bin/env bash
# Agent Shield — Rust logging lint
#
# Flags `log::info!` / `log::warn!` / `log::error!` (and `tracing::info!`
# / `warn!` / `error!` if used) call sites in `sdk/rust/**/*.rs` whose
# first argument or interpolated identifiers match a token in
# `.github/scripts/sensitive-names.txt` (case-insensitive,
# separator-insensitive substring).
#
# Exits 0 if no violations, 1 otherwise. Designed to run in CI; also
# usable locally:
#
#   bash .github/scripts/lint-logging.sh
#
# Optional first arg: a path to scan instead of `sdk/rust/`. Used by
# the regression-fixture tests under `tests/regression-fixtures/rust/`.
#
# Allowed exceptions (per docs/logging-style-guide.md):
#   - examples/**
#   - tests/** and sdk/*/tests/**
#   - sdk/rust/agent_shield_core/src/approval/console.rs
#   - sdk/rust/agent_shield_core/src/classifiers/auto.rs (debug-only)
#   - sdk/rust/agent_shield/src/observability/{azure_monitor,cloudwatch}.rs
#
# Limitations: pure grep — does not parse Rust. Catches the common
# pattern `log::info!(target: "...", "tool args: {}", tool_args)` but
# can miss arbitrary indirection like `let x = tool_args; log::info!("{x}")`.
# That tradeoff is acceptable; the runtime no-PII sentinel test is the
# defense-in-depth backstop.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
SENSITIVE_FILE="$SCRIPT_DIR/sensitive-names.txt"
DEFAULT_SCAN_ROOT="$REPO_ROOT/sdk/rust"
SCAN_ROOT="${1:-$DEFAULT_SCAN_ROOT}"

if [[ ! -f "$SENSITIVE_FILE" ]]; then
  echo "lint-logging.sh: sensitive-names.txt not found at $SENSITIVE_FILE" >&2
  exit 2
fi

normalize_for_match() {
  tr '[:upper:]' '[:lower:]' | tr -d '_-'
}

mapfile -t SENSITIVE_TOKENS < <(grep -vE '^\s*(#|$)' "$SENSITIVE_FILE" | normalize_for_match)

if [[ ${#SENSITIVE_TOKENS[@]} -eq 0 ]]; then
  echo "lint-logging.sh: sensitive-names.txt is empty after stripping comments" >&2
  exit 2
fi

# Match `log::info!(...)` / `log::warn!(...)` / `log::error!(...)` /
# `info!(...)` / `warn!(...)` / `error!(...)` / `tracing::info!(...)` etc.
LOG_CALL_PATTERN='(log::|tracing::)?(info|warn|error)!\('

VIOLATIONS=0

# Find all .rs files under the scan root, excluding allowed paths.
find_args=(
  "$SCAN_ROOT"
  -type f
  -name '*.rs'
  ! -path '*/target/*'
  ! -path "$REPO_ROOT/sdk/rust/agent_shield_core/src/approval/console.rs"
  ! -path "$REPO_ROOT/sdk/rust/agent_shield_core/src/classifiers/auto.rs"
  ! -path "$REPO_ROOT/sdk/rust/agent_shield/src/observability/azure_monitor.rs"
  ! -path "$REPO_ROOT/sdk/rust/agent_shield/src/observability/cloudwatch.rs"
)

if [[ "$(cd "$SCAN_ROOT" && pwd)" == "$DEFAULT_SCAN_ROOT" ]]; then
  find_args+=(
    ! -path '*/tests/*'
    ! -path '*/examples/*'
  )
fi

mapfile -t FILES < <(find "${find_args[@]}")

for f in "${FILES[@]}"; do
  # Find lines matching the log-call pattern, then check if any
  # sensitive token appears on the same logical line. (We approximate
  # "logical line" by reading the raw line; for multi-line log calls
  # we'd need a Rust parser, which is out of scope for this lint.)
  while IFS= read -r match; do
    # match shape: "<lineno>:<line content>"
    line_no="${match%%:*}"
    line_content="${match#*:}"

    # Skip commented-out lines (best-effort: trimmed start is `//`).
    trimmed="${line_content#"${line_content%%[![:space:]]*}"}"
    if [[ "$trimmed" == //* ]]; then
      continue
    fi

    normalized_line="$(printf '%s' "$line_content" | normalize_for_match)"
    for token in "${SENSITIVE_TOKENS[@]}"; do
      if [[ -n "$token" && "$normalized_line" == *"$token"* ]]; then
        echo "BUCKET-D: $f:$line_no"
        echo "  $line_content"
        VIOLATIONS=$((VIOLATIONS + 1))
        break
      fi
    done
  done < <(grep -nE "$LOG_CALL_PATTERN" "$f" || true)
done

if [[ $VIOLATIONS -gt 0 ]]; then
  echo
  echo "lint-logging.sh: $VIOLATIONS violation(s) found."
  echo "See docs/logging-style-guide.md for the rules."
  exit 1
fi

echo "lint-logging.sh: clean ($SCAN_ROOT)"
exit 0
