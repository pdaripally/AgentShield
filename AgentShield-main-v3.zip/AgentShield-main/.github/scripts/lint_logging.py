#!/usr/bin/env python3
"""Agent Shield — Python logging lint.

AST-aware lint that flags `logger.info` / `logger.warning` /
`logger.error` (and `logging.*` module-level equivalents) call sites
in `sdk/python/**/*.py` whose argument list references
an identifier whose name appears in `.github/scripts/sensitive-names.txt`
(case-insensitive, separator-insensitive substring).

Exits 0 if no violations, 1 otherwise. Designed to run in CI; also
usable locally:

    python .github/scripts/lint_logging.py
    python .github/scripts/lint_logging.py path/to/scan

Optional first argument: a path to scan instead of `sdk/python/`.
Used by the regression-fixture tests under
`tests/regression-fixtures/python/`.

Allowed exceptions (per docs/logging-style-guide.md):
  - examples/**
  - tests/** and sdk/python/tests/**

Limitations: AST-level — catches identifier references but not
arbitrary indirection (`x = tool_args; logger.info("%s", x)`). The
runtime no-PII sentinel test is the defense-in-depth backstop.
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
REPO_ROOT = SCRIPT_DIR.parent.parent
DEFAULT_SCAN = REPO_ROOT / "sdk" / "python"
SENSITIVE_FILE = SCRIPT_DIR / "sensitive-names.txt"

# logger.<level>(...) and logging.<level>(...) at info+ levels.
INFO_PLUS_LEVELS = {"info", "warning", "warn", "error", "critical"}


def normalize_name(value: str) -> str:
    return value.lower().replace("_", "").replace("-", "")


def load_sensitive_tokens() -> list[str]:
    if not SENSITIVE_FILE.exists():
        sys.exit(f"lint_logging.py: sensitive-names.txt not found at {SENSITIVE_FILE}")
    tokens: list[str] = []
    for raw in SENSITIVE_FILE.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        normalized = normalize_name(line)
        if normalized:
            tokens.append(normalized)
    if not tokens:
        sys.exit("lint_logging.py: sensitive-names.txt is empty after stripping comments")
    return tokens


def is_excluded(path: Path, scan_root: Path) -> bool:
    """Path components RELATIVE to the scan root that disqualify a file
    from being linted. We exclude `__pycache__` always, and exclude
    `tests` / `examples` only when they appear *under* the scan root
    (so the default `sdk/python/` scan skips its own tests but an
    explicit `tests/regression-fixtures/python` scan does NOT skip
    itself just because the word `tests` appears in the path)."""
    try:
        rel_parts = set(path.relative_to(scan_root).parts)
    except ValueError:
        rel_parts = set(path.parts)
    if "__pycache__" in rel_parts:
        return True
    if "tests" in rel_parts or "examples" in rel_parts:
        return True
    return False


def find_python_files(scan_root: Path) -> list[Path]:
    return [p for p in scan_root.rglob("*.py") if not is_excluded(p, scan_root)]


def is_info_plus_log_call(call: ast.Call) -> bool:
    """Return True if `call` is a `<name>.<level>(...)` at info+."""
    if not isinstance(call.func, ast.Attribute):
        return False
    if call.func.attr.lower() not in INFO_PLUS_LEVELS:
        return False
    # Heuristic: target name suggests a logger. Accept `logger`,
    # `_logger`, `logging`, or anything ending in `_logger` /
    # `_log`. Reject things like `requests.warn(...)`.
    if not isinstance(call.func.value, ast.Name):
        return False
    target = call.func.value.id.lower()
    return (
        target == "logger"
        or target == "_logger"
        or target == "logging"
        or target.endswith("_logger")
        or target.endswith("_log")
    )


def collect_referenced_names(call: ast.Call) -> set[str]:
    """Collect every identifier name referenced anywhere in the call's
    arguments. Includes attribute chains (`obj.attr.subattr` →
    {"obj","attr","subattr"}) and f-string interpolations."""
    names: set[str] = set()
    for arg in list(call.args) + [kw.value for kw in call.keywords]:
        for node in ast.walk(arg):
            if isinstance(node, ast.Name):
                names.add(normalize_name(node.id))
            elif isinstance(node, ast.Attribute):
                names.add(normalize_name(node.attr))
            elif isinstance(node, ast.FormattedValue):
                # f"...{x.y}..." — walk the embedded expression.
                for sub in ast.walk(node.value):
                    if isinstance(sub, ast.Name):
                        names.add(normalize_name(sub.id))
                    elif isinstance(sub, ast.Attribute):
                        names.add(normalize_name(sub.attr))
    return names


def scan_file(path: Path, sensitive_tokens: list[str]) -> list[tuple[int, str]]:
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"))
    except (SyntaxError, UnicodeDecodeError) as e:
        return [(0, f"PARSE-ERROR: {e}")]

    violations: list[tuple[int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if not is_info_plus_log_call(node):
            continue
        names = collect_referenced_names(node)
        # Substring match: any sensitive token contained in any
        # referenced name.
        for name in names:
            if any(token in name for token in sensitive_tokens):
                # Reconstruct a brief snippet of the offending line.
                line = path.read_text(encoding="utf-8").splitlines()[node.lineno - 1].strip()
                violations.append((node.lineno, line))
                break  # one violation per call is enough
    return violations


def main(argv: list[str]) -> int:
    sensitive_tokens = load_sensitive_tokens()
    scan_root = Path(argv[1]).resolve() if len(argv) > 1 else DEFAULT_SCAN
    if not scan_root.exists():
        sys.exit(f"lint_logging.py: scan root does not exist: {scan_root}")

    total_violations = 0
    for f in find_python_files(scan_root):
        for lineno, line in scan_file(f, sensitive_tokens):
            rel = f.relative_to(REPO_ROOT) if f.is_relative_to(REPO_ROOT) else f
            print(f"BUCKET-D: {rel}:{lineno}")
            print(f"  {line}")
            total_violations += 1

    if total_violations:
        print(f"\nlint_logging.py: {total_violations} violation(s) found.")
        print("See docs/logging-style-guide.md for the rules.")
        return 1

    print(f"lint_logging.py: clean ({scan_root})")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
