---
name: ci-verification
description: 'Mirror the GitHub Actions CI workflows locally before pushing. Use when finishing a feature, before a final push, after large refactors, splitting PRs, or whenever you want to catch CI failures locally. The skill is enforced by a pre-push git hook — failing the hook is the failure signal.'
---

# CI Verification

## Read this first

Verification is **enforced by a git pre-push hook**, not by a checklist
you remember to run. The agent contract is:

1. **Install the hook once per clone** (Step 0 below).
2. **Push normally.** The hook runs the right scoped verification
   automatically.
3. **If the hook fails, fix what it found.** Do not use
   `git push --no-verify`. (See *Bypass policy* at the bottom.)

The hook calls a single driver script —
`.github/skills/ci-verification/verify.sh` — which is the canonical
entry point. If you want to run verification manually (before pushing,
after a rebase, between commits, …), call that script directly. The
hook calls it for you on push.

You should not be invoking individual `cargo test -p <crate>` commands
ad-hoc. Past failures came from agents trying to substitute a "fast
equivalent" for the canonical command and accidentally narrowing the
test scope. The driver script is the canonical command; don't roll
your own.

## Step 0: Install the hook (once per clone)

```bash
git config core.hooksPath .githooks
```

This is per-clone, not per-repo. The first action of any session
working in this repo MUST be to run that line. It is idempotent; if
already set, it's a no-op.

Verify:

```bash
test "$(git config core.hooksPath)" = ".githooks" && echo "hook armed"
```

If it prints `hook armed`, you're good.

## Running verification manually

```bash
.github/skills/ci-verification/verify.sh           # full suite
.github/skills/ci-verification/verify.sh rust      # rust only
.github/skills/ci-verification/verify.sh python    # python only
.github/skills/ci-verification/verify.sh node      # node only
.github/skills/ci-verification/verify.sh dotnet    # .NET only
```

The script:

* Verifies all six toolchains (`cargo`, `rustfmt`, `node`, `npm`,
  `dotnet`, `python3`) are reachable. Fails loudly if any are missing.
* Checks the local branch is not behind `origin/main`. Requires network
  access to fetch `origin/main`; **fails if the fetch fails** (set
  `SKIP_REBASE_CHECK=1` to bypass in offline environments). CI runs against
  the merge result, not your branch in isolation; the rebase check
  catches "passes locally, fails in CI because main moved" failures.
* Runs the scoped suite (`fmt` + `clippy` + `cargo test --workspace
  --all-features` + Python + Node + .NET + demo syntax as relevant).
* **Asserts every expected test binary actually executed.** This is
  the load-bearing manifest check. `cargo test --workspace` can
  silently skip a test binary if a feature flag combination filters
  it out; the manifest check enumerates every `tests/*.rs` file
  across all Rust crates, counts how many times each filename appears
  (because multiple crates can have same-named integration tests such
  as `smoke.rs`), and verifies the cargo output contains at least that
  many `Running tests/<name>.rs` lines per name. If the actual count
  for any name falls below the expected count, the run fails.

If the manifest check trips, **do not paper over it**. It means one
of:

* A new test binary was added but is being excluded by a feature
  combination (fix the feature gating).
* The cargo invocation in `verify.sh` regressed (fix the script).
* You ran the wrong scope by accident (re-run with `all`).

## What `verify.sh all` runs

This is the full set, in order. Every step must exit 0.

1. **Toolchain check** — all six tools present.
2. **Rebase check** — branch is on top of `origin/main`. Fails if
   `origin/main` cannot be fetched (use `SKIP_REBASE_CHECK=1` to
   skip in offline environments).
3. **Rust:**
   * `cargo fmt --all -- --check`
   * `cargo clippy --workspace --all-features -- -D warnings`
   * `cargo check -p agent_shield_core --no-default-features`
     (no-default-features check would feature-unify under
     `--workspace` and could hide a minimal-feature bug)
   * `cargo check --workspace --all-features`
   * `cargo test --workspace --all-features`
   * **Manifest check** — every Rust integration test binary executed.
4. **Python:**
   * `pytest sdk/python/tests/`
   * `pytest tests/e2e/` (run from `sdk/python` so imports resolve)
   * `pytest sdk/python/tests/test_integration_cases.py` (cross-
     language harness)
5. **Node:**
   * `npm install` (always, to detect lockfile/dependency drift)
   * `npm run build` (napi-rs native binding)
   * `npm run build:wrapper` (TypeScript emit)
   * `npx tsc -p tsconfig.json --noEmit` (strict type check, sources)
   * `npx tsc -p tsconfig.tests.json --noEmit` (strict type check,
     including tests — tests run against compiled JS and won't surface
     test-file type errors without this)
   * `npm test` (vitest)
   * Parity tests against `tests/parity/`.
   * Integration cases harness.
6. **.NET:**
   * `cargo build --release -p agent_shield_core` (P/Invoke target)
   * For every `.csproj` under `sdk/dotnet/tests/`: build, copy the
     native library next to the test binary (P/Invoke load path doesn't
     include `target/release`; on Windows the copy is mandatory and
     failures are fatal), run with the appropriate linker env var
     (`LD_LIBRARY_PATH` on Linux, `DYLD_LIBRARY_PATH` on macOS; no
     env override on Windows since the DLL is copied next to the binary).
     The library name is also OS-aware (`.so` / `.dylib` / `.dll`).
7. **Demo syntax** — every `examples/**/demo/**/*.py` parses with
   `ast.parse`.

## Common failure modes and how to handle them

### Toolchain missing

The script tries `~/.dotnet`, `~/.cargo/bin`. If something's still
missing, install it before proceeding. Do not skip the step.

### Branch behind `origin/main`

```bash
git fetch origin main
git rebase origin/main
```

Re-run verification after rebasing. CI runs against the merge result,
so this is a real failure, not a false positive.

### Compiler / linter warnings

`cargo clippy -- -D warnings` treats warnings as errors. Fix the
warning. "Pre-existing" is not an excuse — see the next section.

### "It was broken before I touched it"

Verify by checking out the base branch (or the merge-base with
`origin/main`) and running the same command. If it was genuinely
broken there too, **you still fix it in your PR**. The repo invariant
is "CI is green on `main`." A red CI on `main` is everyone's problem
and the right time to fix it is the next push.

The only exception is when the failure is in code that's actively
being fixed in a parallel PR — in that case, rebase onto the fix once
it lands. Note the dependency in your PR description.

### "Verification takes too long"

Time cost lands at push time, not commit time, so it's amortized
across however many commits you batched. Scoped runs (`verify.sh
rust` etc.) are 1-2 minutes; full runs with cold cargo cache can be
5-10. Warm cargo cache cuts that dramatically. If a particular run is
unexpectedly slow, investigate before opting out.

## Bypass policy

`git push --no-verify` bypasses the hook entirely. It is **not**
allowed unless **all** of the following are true:

1. The push is to a branch you own (not a shared / release branch).
2. The push is explicitly a WIP push that is **not** going up for
   review yet — e.g., backing up work-in-progress to your remote
   before context-switching.
3. You will not open or update a PR off this commit until you have
   re-pushed after a successful local verification.

If you cannot honestly say all three, do not use `--no-verify`. The
right answer to "the hook is failing on my final push" is to fix what
it found, not to skip it.

When a future verification run discovers that the head of a PR was
pushed with `--no-verify`, the reviewer will treat that as a process
violation regardless of whether CI happens to pass.

### Hook-level opt-outs

Two narrowly-scoped env var bypasses exist for legitimate edge cases.
Unlike `--no-verify`, these still run most of the verification:

| Variable | What it skips | When to use |
|---|---|---|
| `SKIP_REBASE_CHECK=1` | The driver's `git fetch origin main` + ahead-of-main check. | Offline environments where the fetch genuinely cannot succeed. |
| `SKIP_WORKTREE_CHECK=1` | The hook's check that the working tree matches `HEAD`. | Rare cases where the agent has audited the uncommitted divergence and the push is explicitly a WIP backup. |

Both should appear in commit / PR notes when used so reviewers can
audit. Using them silently is the same kind of process violation as
`--no-verify`.

## Why this design

(For future maintainers: don't undo any of this without re-reading
the failure analysis it was built from.)

* **The hook is non-negotiable.** Past agents skipped verification by
  rationalizing "this change couldn't break X" and running a narrower
  scope than the canonical one. The hook removes that judgement call:
  push runs the canonical script or it doesn't push.

* **No "quick smoke test" section.** Earlier versions of this skill
  had one. It became the path of least resistance and gave agents
  permission to declare verification done after running a strict
  subset of the checks. Even with explicit warnings ("not for final
  commits"), agents pattern-matched to the smoke command. Removed.

* **A single driver, not a checklist.** Per-crate `cargo test -p`
  invocations look interchangeable but aren't — `--lib` skips
  integration tests, missing `--all-features` hides feature-gated
  regressions, missing `--workspace` hides cross-crate breakage. The
  driver script encodes the canonical invocations once.

* **Manifest check is mandatory.** "All tests passed" without
  enumerating *which* tests passed is the failure mode that hid the
  `perf_baseline_snapshot` regression from at least one previous
  agent. The driver asserts every expected `tests/*.rs` binary
  appeared in the cargo output. Adding a test file picks it up
  automatically; nothing else needs to change.

* **Rebase check up front.** Branches sitting on unmerged base
  branches pass locally and fail in CI. The check forces the agent to
  rebase before relying on local verification.

* **Scope detection in the hook is conservative.** Anything outside
  the documented "doc / spec / example only" set triggers full
  verification. The cost of a false positive (re-running an unchanged
  scope) is small; the cost of a false negative (skipping a scope
  that turns out to matter) is the thing this whole skill exists to
  prevent.

* **`sdk/python/src/*` and `sdk/node/src/*` trigger Rust verification
  too.** Those directories host pyo3 / napi-rs crates that are Rust
  workspace members. A change to `sdk/python/src/lib.rs` or
  `sdk/node/src/lib.rs` must run `cargo fmt`, `cargo clippy
  --workspace`, and `cargo test --workspace` as well as the language
  SDK tests. The hook mirrors `.github/workflows/rust.yml` which
  fires Rust CI on those paths.

* **`sdk/rust/agent_shield_core/*` and root `Cargo.{toml,lock}` fan
  out to every SDK.** That crate defines the cross-language FFI /
  ABI / wire-shape surface that Python (pyo3), Node (napi-rs), and
  .NET (P/Invoke) all consume. A change there can silently break
  any SDK on the wire even though the Rust workspace builds and
  tests pass. The hook routes those paths to all four scopes so
  every SDK rebuilds and tests against the new core, mirroring the
  cross-language integration workflow.

* **Every push scopes against `$REMOTE/main`, not the previous remote
  tip.** A subtle bypass: if a PR branch already contains unverified
  code (the hook wasn't installed when an earlier commit was pushed),
  a later docs-only push would see no code diff against the previous
  remote tip and skip verification entirely, blessing the
  already-pushed code without ever running the suite. Scoping every
  push against the merge-base with `main` closes that hole.

* **Pushed ref must match the checked-out HEAD.** Verification runs
  against the current worktree. If the user pushes a ref whose tip
  differs from `HEAD` (`git push origin other-branch` while
  `main` is checked out, for example), the suite would test the
  wrong commit. The hook checks `local_sha` against `git rev-parse
  HEAD` for every pushed non-delete ref and fails closed on
  mismatch.

* **Demo Python scripts under `examples/**/demo/**/*.py` are gated.**
  Other paths under `examples/`, `spec/`, `docs/`, and standalone
  `*.md` files skip verification — they're prose / config only.
  Demo Python scripts, however, are syntax-checked by
  `verify.sh demo-syntax`, and the hook routes demo-only changes
  to that scope so a broken `examples/foo/demo/run.py` can't ship
  through a docs-only push.

* **Worktree-vs-commit drift is rejected.** The driver runs cargo /
  npm / dotnet / pytest against the current working tree, not the
  commit being pushed. Two failure modes are covered:
  * Modified tracked files: an agent could stage half of a fix and
    push, letting the unstaged half mask a regression in the
    committed half.
  * Untracked non-ignored files: a new source file under
    `sdk/rust/.../src/` that cargo picks up via globs, or a new
    test-support module, would make local verification pass without
    being present on the pushed commit.

  The hook checks both before invoking the driver (`git diff-index
  --quiet HEAD --` for tracked changes and `git ls-files --others
  --exclude-standard` for untracked files) and fails closed when
  either is dirty. `SKIP_WORKTREE_CHECK=1` provides an explicit
  opt-out for the rare WIP-backup case.

## Key files

| File | Role |
|------|------|
| `.githooks/pre-push` | Git pre-push hook. Detects scope from the diff against `$REMOTE/main` (where `$REMOTE` is the push remote, defaulting to `origin`) and invokes the driver. Every push, including incremental docs-only ones, scopes against the merge-base with `main` — not against the previous remote tip — so an existing PR branch can't have unverified code blessed by a later docs-only push. |
| `.github/skills/ci-verification/verify.sh` | Canonical verification driver. Single entry point. |
| `.github/skills/ci-verification/SKILL.md` | This document. |
| `.github/workflows/rust.yml` | CI workflow this skill mirrors (Rust). |
| `.github/workflows/integration.yml` | CI workflow this skill mirrors (cross-language). |
