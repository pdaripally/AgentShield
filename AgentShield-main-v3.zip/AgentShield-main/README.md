# Agent Shield

**Open specification and reference implementation for runtime security controls on AI agents.**

[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Spec](https://img.shields.io/badge/spec-v2.0.0--alpha-blue)](spec/SPECIFICATION.md)
[![Status](https://img.shields.io/badge/status-alpha-orange)](#)

Agent Shield enforces a portable `.guardrails.yaml` contract across agent inputs, state checks, tool calls, tool results, and final outputs. It is a mediation layer, not a sandbox; see [`docs/security-model.md`](docs/security-model.md).

The same contract works across LangChain, AutoGen, OpenAI Agents SDK, CrewAI, Anthropic Agents SDK, Semantic Kernel, MCP servers, Rust Rig, .NET middleware, and [LiteLLM Proxy](docs/integrations/litellm-proxy.md). Start with [QUICKSTART.md](QUICKSTART.md).

> [!IMPORTANT]
> Agent Shield ships today as an **in-process SDK** (Python, Node, .NET, Rust) plus an optional **LiteLLM Proxy guardrail** for OpenAI-compatible chat traffic. It does **not** ship a generic HTTP gateway, standalone Kubernetes sidecar, Helm chart, or official gateway image. See [`docs/roadmap/deployment-surfaces.md`](docs/roadmap/deployment-surfaces.md).

## The model

Every decision runs through one of five validation stages using the same `guard_policies[]` schema: Input, State, Tool execution, Post-tool, and Output. The runtime evaluates typed **variables**, named **predicates**, **events/lifetimes**, and **resolvers** (`expression`, `human`, `tool`, `delegate`, `agent`) to produce allow/deny/mutate verdicts.

![Agent Shield stages](/docs/assets/images/5%20stages.jpg)

For the full contract, see [`spec/SPECIFICATION.md`](spec/SPECIFICATION.md) and the [expression language](spec/expressions/LANGUAGE.md).

## Policy sketch

```yaml
variables:
  - name: data_sensitivity
    type: enum
    members: [public, internal, protected]
    default: public
    populated_by:
      - kind: tool
        name: Get_Document_Content
  - name: internal_send_decision
    type: enum
    members: [allow_once, allow_always]
    on_demand_by:
      kind: human
      prompt: "Approve emailing INTERNAL content to ${@tool.params.toRecipients}?"
state_validation:
  guard_policies:
    - name: internal_doc_send_gate
      applies_to: { tools: [mcp_MailTools_graph_mail_sendMail] }
      active_if: "data_sensitivity == 'internal'"
      evaluate_when:
        - expression: "internal_send_decision in ['allow_once', 'allow_always']"
          reason: "Sending an internal document requires human approval."
      action: block
```

## Install today

Public registry packages are not live yet. Use source installs from this repo:

```bash
git clone https://github.com/microsoft/AgentShield.git
cd AgentShield
pip install -e sdk/python
# Node: cd sdk/node && npm install && npm run build && npm run build:wrapper
# .NET: add ProjectReference entries under sdk/dotnet/src/
# Rust: use git/path dependencies to sdk/rust crates
```

See [QUICKSTART §2](QUICKSTART.md#2-install-the-sdk) for full install commands.

## Integrate

| Framework | Adapter surface |
|---|---|
| LangChain | Python `shield.guard(agent)` · Node `shield.guard(agent)` |
| OpenAI Agents SDK | Python helper · Node `shield.runOpenaiAgent({...})` |
| Anthropic Agents SDK | Python helper · Node `shield.runAnthropicAgent({...})` |
| AutoGen | Python team/agent helpers · .NET middleware |
| CrewAI | Python `protect_tools(...)` + native `Crew` + `guard_crew(...)` |
| Semantic Kernel | Python adapter · .NET `IAutoFunctionInvocationFilter` |
| Microsoft.Extensions.AI | .NET `UseAgentShield()` / `GuardedChatClient` |
| Rust Rig | `GuardedRigTool` + `run_rig` / `with_rig_session` |
| MCP servers | Python / Node server wrappers · Rust `agent_shield_mcp` helpers |

Python LangChain:

```python
from agent_shield import Shield
import agent_shield.adapters.langchain

shield = Shield.from_yaml(".guardrails.yaml").with_langchain().with_client(my_llm).build()
guarded = shield.guard(my_agent)
result = await guarded.ainvoke(user_input)
```

Node OpenAI Agents:

```typescript
import OpenAI from 'openai'
import { Shield } from '@microsoft/agent-shield'
import '@microsoft/agent-shield/adapters/openai_agents'

const shield = await Shield.fromYaml('.guardrails.yaml').withOpenaiAgents().build()
const text = await shield.runOpenaiAgent({
  client: new OpenAI(), model: 'gpt-4o-mini', tools, dispatchToolCall,
  messages: [{ role: 'user', content: 'user input' }],
})
```

Pattern A / B / C details live in [QUICKSTART §4](QUICKSTART.md#4-integrate-with-your-framework) and each SDK README.

### Pending-resolution envelope

When a resolver needs external input, the verdict carries a `pending_resolution` envelope. Field names are stable; casing follows each SDK.

| Canonical field | Python | Node / TypeScript | Direction |
|---|---|---|---|
| `kind` | `kind` | `kind` | Pending → host |
| `request_id` | `request_id` | `requestId` | Pending → host |
| `tool` | `tool` | `tool` | Pending → host |
| `variable` | `variable` | `variable` | Pending → host |
| `prompt` | `prompt` | `prompt` | Pending → host |
| `set_variables` | `set_variables` | `setVariables` | Host → resolver response |

## Streaming safety

Do not wrap streaming chunks manually around `shield.run` / `Shield.RunAsync`. Stage 5 needs full output context; per-chunk validation cannot compute correct redaction spans, and post-hoc validation leaks raw chunks before redaction. Use a shipped streaming adapter, disable streaming, use LiteLLM buffer mode, or emit sentinel-only progress. Matrix: [`docs/adapter-mediated-paths.md`](docs/adapter-mediated-paths.md). Runbook: [`docs/runbooks/incident-streaming-leak.md`](docs/runbooks/incident-streaming-leak.md).

## Demos

| Demo | What it shows |
|---|---|
| [Bank Manager](examples/agents/bank-manager/README.md) | VIP transfer approvals, social engineering, prompt injection in tool memos, account enumeration |
| [Document DLP](examples/agents/document-dlp/README.md) | Sensitivity ratchets, email policy, output PII redaction |
| [AutoGen Azure](examples/autogen_team_quickstart_azure.md) | Shared sessions and final-output redaction in a multi-agent team |
| [CrewAI Azure](examples/crewai_invoice_quickstart_azure.md) | Tool wrapping + guarded crew for a multi-agent invoice flow |
| [LangChain Azure](examples/langchain_quickstart_azure.md) | Smallest Azure OpenAI adapter quickstart |

## Documentation

- [Quickstart](QUICKSTART.md)
- [`agent-shield init`](docs/getting-started/init.md)
- [Architecture](docs/architecture.md)
- [Security model](docs/security-model.md)
- [Adapter mediated paths](docs/adapter-mediated-paths.md)
- [Framework compatibility](docs/FRAMEWORK_COMPAT.md)
- [SDK parity](docs/SDK_PARITY.md)
- [Post-tool limits](docs/POST_TOOL_LIMITS.md)
- [Pluggable moderation providers](docs/pluggable-moderation.md)
- [LiteLLM Proxy integration](docs/integrations/litellm-proxy.md)
- [MCP integration](docs/integrations/mcp.md)
- [Kubernetes/Istio reference](docs/istio-sdk-reference-architecture.md)
- [Deployment roadmap](docs/roadmap/deployment-surfaces.md)
- [Specification](spec/SPECIFICATION.md)
- [Expression language](spec/expressions/LANGUAGE.md)
- [JSON Schema](spec/schema/guardrails.schema.json)
- [Changelog](CHANGELOG.md)

## FAQ

### How is this different from framework guardrail hooks?

Framework hooks tell you where to insert code. Agent Shield defines the portable policy contract and runtime semantics enforced through those hooks.

### How is this different from a system prompt?

System prompts are advisory. Agent Shield evaluates deterministic policy outside the model at state and tool boundaries.

### What's the relationship to MCP?

MCP defines how agents call tools. Agent Shield defines what those calls are allowed to do.

## License

MIT — see [LICENSE](LICENSE).

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). This project follows the [Microsoft Open Source Code of Conduct](https://opensource.microsoft.com/codeofconduct/).

## Security

Report vulnerabilities via [SECURITY.md](SECURITY.md). Operator references: [production checklist](docs/PRODUCTION_DEPLOYMENT.md), [security model](docs/security-model.md), and [runbooks](docs/runbooks/).

## Acknowledgments

Inspired by [Model Context Protocol](https://modelcontextprotocol.io), [Apache Iceberg](https://iceberg.apache.org), and OpenClaw security research.
