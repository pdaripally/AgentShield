<!-- BEGIN MICROSOFT SECURITY.MD V1.0.0 BLOCK -->

## Security

Microsoft takes the security of our software products and services seriously, which
includes all source code repositories in our GitHub organizations.

**Please do not report security vulnerabilities through public GitHub issues.**

For security reporting information, locations, contact information, and policies,
please review the latest guidance for Microsoft repositories at
[https://aka.ms/SECURITY.md](https://aka.ms/SECURITY.md).

<!-- END MICROSOFT SECURITY.MD BLOCK -->

## Preferred reporting channel

Please use **GitHub Security Advisories private reporting** for this repository whenever possible. If that path is unavailable, use the Microsoft security reporting address listed from the canonical guidance above as the backup channel.

Do **not** open public GitHub issues for suspected vulnerabilities.

## Triage expectations

- We aim to acknowledge new reports within **72 hours**.
- We aim to provide an initial assessment within **7 calendar days**.
- If we need more time, we will keep the reporter updated on status and next steps.

## Coordinated disclosure

Our default coordinated-disclosure target is **90 days** from acknowledgement. We may shorten or extend that window when there is active exploitation, a dependency fix we do not control, or a coordinated ecosystem release that needs additional time.

## Supported versions

AgentShield is an alpha-stage open specification and reference implementation; release cadence is fast and the spec is still evolving. The following support windows apply for security fixes:

| Version stream | Status | Receives security fixes |
| --- | --- | --- |
| `main` | Active development | Yes — fixed in the next release |
| Latest published minor (`v0.<N>.x`) | Supported | Yes — patch release within the disclosure window where feasible |
| Previous minor (`v0.<N-1>.x`) | Best-effort | Backports only for High/Critical findings, at maintainer discretion |
| Older minors (`< v0.<N-1>`) | End of support | No |

Patch releases for security fixes are tagged as `v0.<N>.<P+1>` and ship through the normal release pipeline (signed, attested, scanned) described in `RELEASING.md`. Pre-release tags (`-alpha`, `-rc`) do not receive backports independently — upgrade to the latest `v0.<N>.x` line.

If you need security support on a stream listed as End of support, please raise the question in your security report and we will respond with a concrete migration path.

## Severity handling and SLA

We use the following severity guidance to set response targets. Severity is assigned by the maintainers in consultation with the reporter; reporters can propose a starting severity and we will respond with our assessment.

| Severity | Examples | Target fix window |
| --- | --- | --- |
| Critical | Pre-auth remote code execution; silent disabling of fail-closed enforcement; verdict tampering; cross-session secret leakage | 7 calendar days from confirmation |
| High | Auth bypass on approval/binding paths; resolver-trust bypass; redaction bypass that exposes raw classifier or approval payloads | 30 calendar days |
| Medium | Denial-of-service via spec-legal but adversarial input that exceeds the documented `limits:` defaults; logging-lint regressions that surface sensitive content at info level | 60 calendar days |
| Low | Cosmetic information disclosure; defense-in-depth gaps with no demonstrated exploit path | Next regular release |

We will keep the reporter updated against the relevant target. If we expect to miss it, we will say so before the deadline and propose a revised plan.

## Embargo expectations

By default, we ask reporters to keep details of a confirmed vulnerability private until the coordinated-disclosure window described above closes — typically 90 days from acknowledgement, or earlier on Critical issues. We will:

- Coordinate the public advisory wording with the reporter.
- Credit the reporter in the GitHub Security Advisory and the release notes (unless the reporter prefers to remain anonymous).
- Notify downstream packagers and known large deployments before the public advisory where the issue's severity warrants it.

We do not require an NDA. If the reporter needs to inform a small set of additional people (e.g., their own security team or a downstream product team) during the embargo, please tell us and we will treat that as part of the coordinated process. Independent public disclosure during the embargo without prior coordination is discouraged because it puts users at risk; if you choose to publish, we ask for at least 72 hours' notice so we can prepare a fix and advisory.

## Advisory / CVE workflow

Once a fix is ready or the embargo window closes, we will:

1. Publish a [GitHub Security Advisory](https://docs.github.com/en/code-security/security-advisories) on the AgentShield repository, using the reporter's preferred credit.
2. Request a CVE identifier through GitHub's CVE Numbering Authority for issues that meet [CVE assignment criteria](https://www.cve.org/ResourcesSupport/AllResources/CNARules#section_8_cve_id_assignment) — generally Medium severity or higher, or any issue affecting a published release.
3. Reference the advisory + CVE in the patch release's `CHANGELOG.md` and release notes.
4. For Critical / High issues, post a brief notice to the repository's discussions / release-notes feed so deployments without GitHub Advisory subscriptions can find it.

For dependency vulnerabilities that have no AgentShield-specific exploit path, we generally cite the upstream advisory rather than minting a new CVE.

## Safe harbor

We support good-faith security research conducted to help protect users, data, and services. If you act in good faith, avoid privacy violations, avoid destructive actions, and promptly report what you find through the channels above, we will not pursue action solely because of that research.

## Out of scope for this repository

The following are generally out of scope for AgentShield repository triage unless they demonstrate a vulnerability in this repo's own code or release process:

- Denial-of-service created solely by deliberately expensive but spec-legal resolver or policy configurations.
- Vulnerabilities that exist only in a third-party dependency with no AgentShield-specific exploit path; please also report those to the dependency maintainer.
- Findings that rely on a host application bypassing the documented mediated path or disabling its own authentication/authorization controls.
- Vulnerabilities in downstream tools, MCP servers, model providers, or customer deployments that AgentShield does not own.