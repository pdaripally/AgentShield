#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
import tomllib
import xml.etree.ElementTree as ET
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
EXPECTED = {
    "repository": "https://github.com/microsoft/AgentShield",
    "homepage": "https://github.com/microsoft/AgentShield",
    "documentation": "https://github.com/microsoft/AgentShield",
    "license": "MIT",
    "description": "Agent Shield reference SDK and integrations for policy-based security controls on AI agents",
}


def resolve_workspace_value(package: dict, workspace: dict, key: str):
    value = package.get(key)
    if isinstance(value, dict) and value.get("workspace") is True:
        return workspace.get(key)
    return value


def check_rust(errors: list[str]) -> None:
    workspace = tomllib.loads((REPO_ROOT / "Cargo.toml").read_text())["workspace"]["package"]
    manifests = [
        REPO_ROOT / "sdk/node/Cargo.toml",
        REPO_ROOT / "sdk/python/Cargo.toml",
        *sorted((REPO_ROOT / "sdk/rust").glob("*/Cargo.toml")),
    ]
    for path in manifests:
        package = tomllib.loads(path.read_text())["package"]
        actual = {
            "repository": resolve_workspace_value(package, workspace, "repository"),
            "homepage": resolve_workspace_value(package, workspace, "homepage"),
            "documentation": package.get("documentation"),
            "license": resolve_workspace_value(package, workspace, "license"),
            "description": package.get("description"),
        }
        for key, expected in EXPECTED.items():
            if actual.get(key) != expected:
                errors.append(f"{path.relative_to(REPO_ROOT)}: expected {key}={expected!r}, got {actual.get(key)!r}")


def check_python(errors: list[str]) -> None:
    project = tomllib.loads((REPO_ROOT / "sdk/python/pyproject.toml").read_text())["project"]
    actual = {
        "repository": project["urls"]["Repository"],
        "homepage": project["urls"]["Homepage"],
        "documentation": project["urls"]["Documentation"],
        "license": project["license"],
        "description": project["description"],
    }
    for key, expected in EXPECTED.items():
        if actual.get(key) != expected:
            errors.append(f"sdk/python/pyproject.toml: expected {key}={expected!r}, got {actual.get(key)!r}")


def check_node(errors: list[str]) -> None:
    package = json.loads((REPO_ROOT / "sdk/node/package.json").read_text())
    actual = {
        "repository": package["repository"]["url"],
        "homepage": package["homepage"],
        "documentation": package["documentation"],
        "license": package["license"],
        "description": package["description"],
    }
    for key, expected in EXPECTED.items():
        if actual.get(key) != expected:
            errors.append(f"sdk/node/package.json: expected {key}={expected!r}, got {actual.get(key)!r}")


def check_dotnet(errors: list[str]) -> None:
    props_root = ET.parse(REPO_ROOT / "sdk/dotnet/src/Directory.Build.props").getroot()
    props = next(iter(props_root.findall("PropertyGroup")))
    shared = {child.tag: (child.text or "").strip() for child in props}
    actual = {
        "repository": shared.get("RepositoryUrl"),
        "homepage": shared.get("PackageProjectUrl"),
        "documentation": shared.get("PackageProjectUrl"),
        "license": shared.get("PackageLicenseExpression"),
        "description": shared.get("Description"),
    }
    for key, expected in EXPECTED.items():
        if actual.get(key) != expected:
            errors.append(f"sdk/dotnet/src/Directory.Build.props: expected {key}={expected!r}, got {actual.get(key)!r}")
    for path in sorted((REPO_ROOT / "sdk/dotnet/src").glob("*/**/*.csproj")):
        root = ET.parse(path).getroot()
        for prop in ("Description", "PackageProjectUrl", "RepositoryUrl", "PackageLicenseExpression"):
            for elem in root.findall(f".//{prop}"):
                value = (elem.text or "").strip()
                expected = {
                    "Description": EXPECTED["description"],
                    "PackageProjectUrl": EXPECTED["homepage"],
                    "RepositoryUrl": EXPECTED["repository"],
                    "PackageLicenseExpression": EXPECTED["license"],
                }[prop]
                if value != expected:
                    errors.append(f"{path.relative_to(REPO_ROOT)}: expected {prop}={expected!r}, got {value!r}")


def main() -> int:
    errors: list[str] = []
    check_rust(errors)
    check_python(errors)
    check_node(errors)
    check_dotnet(errors)
    if errors:
        print("Package metadata drift detected:", file=sys.stderr)
        for error in errors:
            print(f"- {error}", file=sys.stderr)
        return 1
    print("Package metadata is normalized across Rust, Python, Node, and .NET manifests")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
