#!/usr/bin/env bash
# update-pr-stack.sh — re-derive the 14 stacked PR branches from the canonical
# integration branch.
#
# Each PR branch ("pr/NN-slug") points at exactly one commit on top of its
# predecessor:
#   pr/01-spec-schema        ← commit 1, base origin/main
#   pr/02-core-loader        ← commit 2, base pr/01-spec-schema
#   ...
#   pr/14-cli-meta           ← commit 14, base pr/13-sdk-dotnet
#
# Whenever the integration branch is rewritten (rebase, fixup, force-push from
# elsewhere), run this script to re-point all 14 PR branches at the new SHAs.
# It then prints `git push` commands ready to paste — it never pushes for you.

set -euo pipefail

SOURCE="${SOURCE_BRANCH:-integration/open-prs-squashed}"
BASE="${BASE_BRANCH:-origin/main}"

NAMES=(
  "01-spec-schema"
  "02-core-loader"
  "03-core-runtime"
  "04-core-expressions"
  "05-core-resolvers"
  "06-core-ffi"
  "07-core-tests-runtime"
  "08-core-tests-resolvers"
  "09-sdk-rust"
  "10-sdk-python-binding"
  "11-sdk-python-tests"
  "12-sdk-node"
  "13-sdk-dotnet"
  "14-cli-meta"
)

if ! git rev-parse --verify --quiet "$SOURCE" >/dev/null; then
  echo "fatal: source branch '$SOURCE' not found" >&2
  exit 1
fi
if ! git rev-parse --verify --quiet "$BASE" >/dev/null; then
  echo "fatal: base ref '$BASE' not found (try: git fetch origin)" >&2
  exit 1
fi

mapfile -t COMMITS < <(git log --reverse --pretty=format:%H "${BASE}..${SOURCE}")

if [ "${#COMMITS[@]}" -ne "${#NAMES[@]}" ]; then
  echo "fatal: expected ${#NAMES[@]} commits on ${SOURCE} above ${BASE}, found ${#COMMITS[@]}" >&2
  echo "       (the stack must have exactly ${#NAMES[@]} commits to map onto the named branches)" >&2
  exit 1
fi

echo "Re-pointing PR branches from ${SOURCE} (base: ${BASE}):"
for i in "${!COMMITS[@]}"; do
  branch="pr/${NAMES[$i]}"
  git branch -f "$branch" "${COMMITS[$i]}"
  printf "  %s -> %s\n" "${COMMITS[$i]:0:10}" "$branch"
done

echo
echo "To publish (force-with-lease, one branch per PR):"
for name in "${NAMES[@]}"; do
  printf "  git push origin pr/%s --force-with-lease\n" "$name"
done

echo
echo "PR base mapping (set when opening each PR):"
echo "  pr/${NAMES[0]} -> base: ${BASE#origin/}"
for ((i = 1; i < ${#NAMES[@]}; i++)); do
  printf "  pr/%s -> base: pr/%s\n" "${NAMES[$i]}" "${NAMES[$((i - 1))]}"
done
