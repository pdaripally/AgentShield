#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

DISALLOWED = re.compile(r"\b(?:AGPL|GPL|LGPL)\b", re.IGNORECASE)
PERMISSIVE_ALTERNATIVE = re.compile(r"\b(?:MIT|Apache|BSD|ISC|Zlib|MPL|CC0)\b", re.IGNORECASE)


def normalize_text(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, (list, tuple, set)):
        return ", ".join(normalize_text(v) for v in value)
    return str(value)


def is_disallowed(license_text: str) -> bool:
    normalized = normalize_text(license_text)
    if not DISALLOWED.search(normalized):
        return False

    upper = re.sub(r"\s+", " ", normalized.upper()).strip()
    if re.search(r"\bAND\b", upper):
        return True

    options = [segment.strip(" ()") for segment in re.split(r"\bOR\b", upper) if segment.strip(" ()")]
    if not options:
        return True
    return not any(PERMISSIVE_ALTERNATIVE.search(option) and not DISALLOWED.search(option) for option in options)


def check_cargo(path: Path, errors: list[str]) -> None:
    data = json.loads(path.read_text())
    for item in data:
        license_text = normalize_text(item.get("license"))
        if is_disallowed(license_text):
            errors.append(f"cargo:{item.get('name')} -> {license_text}")


def check_pip(path: Path, errors: list[str]) -> None:
    data = json.loads(path.read_text())
    for item in data:
        license_text = normalize_text(item.get("License"))
        if is_disallowed(license_text):
            errors.append(f"python:{item.get('Name')} -> {license_text}")


def check_node(path: Path, errors: list[str]) -> None:
    data = json.loads(path.read_text())
    for package_name, item in data.items():
        license_text = normalize_text(item.get("licenses"))
        if is_disallowed(license_text):
            errors.append(f"node:{package_name} -> {license_text}")


def extract_dotnet_entries(data: object):
    if isinstance(data, list):
        for item in data:
            yield from extract_dotnet_entries(item)
    elif isinstance(data, dict):
        if any(key.lower().startswith("license") for key in data):
            yield data
        for value in data.values():
            yield from extract_dotnet_entries(value)


def check_dotnet(path: Path, errors: list[str]) -> None:
    text = path.read_text().strip()
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        if is_disallowed(text):
            errors.append(f"dotnet:{path.name} -> matched disallowed license text")
        return
    for item in extract_dotnet_entries(data):
        name = item.get("PackageName") or item.get("Name") or item.get("ProjectName") or "unknown"
        license_text = normalize_text(item.get("LicenseType") or item.get("License") or item.get("LicenseUrl"))
        if is_disallowed(license_text):
            errors.append(f"dotnet:{name} -> {license_text}")


def main(argv: list[str]) -> int:
    if len(argv) != 5:
        print("usage: check_licenses.py <cargo.json> <pip.json> <node.json> <dotnet.json>", file=sys.stderr)
        return 2
    cargo_path, pip_path, node_path, dotnet_path = [Path(arg) for arg in argv[1:]]
    errors: list[str] = []
    check_cargo(cargo_path, errors)
    check_pip(pip_path, errors)
    check_node(node_path, errors)
    check_dotnet(dotnet_path, errors)
    if errors:
        print("Disallowed licenses detected:", file=sys.stderr)
        for error in errors:
            print(f"- {error}", file=sys.stderr)
        return 1
    print("No GPL-family licenses detected in audited dependencies")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
