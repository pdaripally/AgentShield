# Releasing Agent Shield

This document is the single source of truth for cutting a release of Agent Shield. It is the workflow contract between contributors, the publish pipeline, and downstream consumers.

> **Release-artifact scope rule: this is a private repository, and no release artifact is published to a public registry or transparency log.** What that does and does not mean:
>
> **What it means.** No build output of this repo (Python wheels, npm tarballs, NuGet packages, Rust crates, .NET native libs, SBOMs) reaches PyPI, npm, NuGet.org, crates.io, the public Sigstore Rekor log, or any other public distribution channel. Release assets stay inside this repo's private GitHub surfaces: the tag's release page and the workflow run's artifact storage.
>
> **What it does not mean.** The build itself still resolves dependencies from upstream registries (crates.io, npm, PyPI, NuGet.org, the GitHub Actions marketplace, rustup distribution servers). Doing otherwise would require fully air-gapped mirrors, which is out of scope. The boundary this document enforces is on outbound artifact publishing, not on inbound dependency resolution.
>
> Concretely, the release pipeline today:
>
> - Uploads packaged release assets to private GitHub Releases on tag pushes, and to `actions/upload-artifact@v4` for workflow-run retention inside this repo.
> - Generates repo-wide SBOMs via Syft in both CycloneDX JSON and SPDX JSON before the final release-artifact attestation step.
> - Generates **private GitHub artifact attestations** for both build provenance (`actions/attest-build-provenance`) and the CycloneDX SBOM (`actions/attest-sbom`). On private repos those attestations stay in GitHub's managed attestation store rather than the public Sigstore Rekor log.
> - Keeps registry-scoped permissions off; the final publish job only elevates to `contents: write`, `id-token: write`, and `attestations: write` so it can upload private release assets and attestations. It still does **not** grant `packages: write`, because nothing is pushed to a public package registry.
> - Every workspace member crate sets `publish = false` (inherited from `[workspace.package].publish` in the root `Cargo.toml`) so `cargo publish` is refused at the manifest level even if a contributor runs it locally.
> - `sdk/node/package.json` sets `"private": true` so `npm publish` is refused even if a contributor runs it locally.

## What this release certifies

Only the following conformance IDs are release-certifiable in this branch. The release-claim gate blocks a tag unless every listed ID passes in Rust, Python, Node, and .NET, and unless no extra or missing IDs appear in this section.

- conformance: spec-16-canonical-invocation.case-01, spec-16-canonical-invocation.case-02, spec-16-canonical-invocation.case-03, spec-16-canonical-invocation.case-04, spec-16-canonical-invocation.case-05, spec-9.1-lifetime-grammar.case-01

Cases marked `pending: true` in `tests/conformance/cases/` are tracked for future releases but are **not** certified by this release. Those pending IDs currently cover runtime surfaces still owned by PR2 (`telemetry_policy`, `limits`, resolver transport/schema/signature, streamed incidents), PR3 adapter mediation/bypass evidence, and the IFC reimplementation.

---

## 1. Tag and trigger

The `Build & Upload SDKs` workflow (`.github/workflows/publish.yml`) is triggered by either:

- A `git push` of a tag matching `v*.*.*` (with optional `-(alpha|beta|rc).N`)
- A `workflow_dispatch` invocation with a `version` input matching the same regex

Tag format (enforced by the workflow's resolve-version step):

```
v{N}.{N}.{N}                   # stable
v{N}.{N}.{N}-alpha.{N}         # alpha
v{N}.{N}.{N}-beta.{N}          # beta
v{N}.{N}.{N}-rc.{N}            # release candidate
```

Anything else fails the resolve-version regex with a clear error.

The tag determines the version stamp on every artifact via `.github/scripts/patch-version.sh`. The script is the single source of truth for keeping every manifest in sync at release time — see §3 for what it touches.

### Cutting a release

Substitute the version you're cutting (`X.Y.Z[-alpha.N | -beta.N | -rc.N]`) for `<version>` below.

```bash
# After merging the last PR you want in the release:
git checkout main && git pull --ff-only
git tag -a v<version> -m "v<version>

<one-line summary>

<bullet list of PRs / changes since the previous tag>"
git push origin v<version>
```

The workflow runs automatically. Watch it with:

```bash
gh run watch $(gh run list --workflow=publish.yml --limit 1 --json databaseId --jq '.[0].databaseId')
```

Or manually dispatch without creating a tag:

```bash
gh workflow run publish.yml -f version=<version>
```

### Consuming the artifacts

For tag-triggered releases, download the private GitHub release assets:

```bash
gh release download v<version> --pattern 'agent_shield-*.whl'               -D dist
gh release download v<version> --pattern 'agent_shield-*.tar.gz'            -D dist      # Python sdist
gh release download v<version> --pattern 'microsoft-agent-shield-*.tgz'     -D pkg
gh release download v<version> --pattern 'AgentShield*.nupkg'               -D packages
gh release download v<version> --pattern 'agent-shield-rust-sdk-*.tar.gz'   -D rust
gh release download v<version> --pattern 'agentshield-sbom-*.json'          -D sbom
```

Workflow artifacts remain available for manual `workflow_dispatch` runs:

```bash
gh run list --workflow=publish.yml --limit 1                              # find run id
gh run download <run-id> -n python-sdk-<version>  -D dist                 # Python
gh run download <run-id> -n node-sdk-<version>    -D pkg                  # Node
gh run download <run-id> -n dotnet-sdk-<version>  -D packages             # .NET
gh run download <run-id> -n rust-sdk-<version>    -D rust                 # Rust source bundle
gh run download <run-id> -n agentshield-sbom-cyclonedx.json -D sbom       # CycloneDX SBOM
gh run download <run-id> -n agentshield-sbom-spdx.json      -D sbom       # SPDX SBOM
```

Filename shapes (the dry-run job asserts these on every PR):

| Ecosystem | Artifact |
|---|---|
| Python | `agent_shield-<pep440-version>-cp311-abi3-{manylinux,win}_*.whl` (one per platform) + sdist. `-alpha.N` / `-beta.N` / `-rc.N` collapses to `aN` / `bN` / `rcN` in the wheel filename per PEP 440. |
| Node | `microsoft-agent-shield-<version>.tgz` (one tarball, three `.node` binaries inside) |
| .NET | `AgentShield.<version>.nupkg` plus six sister NuGet packages (.AI / .Anthropic / .AutoGen / .MCP / .OpenAI / .SemanticKernel) |
| Rust | `agent-shield-rust-sdk-<version>.tar.gz` (workspace source bundle used for release evidence) |
| SBOM | `agentshield-sbom-cyclonedx.json` and `agentshield-sbom-spdx.json` |

Each artifact and SBOM stays inside this repository. On tag pushes the publish workflow also attaches them to the private GitHub release page. Provenance and SBOM attestations are stored privately in GitHub's attestation store; nothing is pushed to a public transparency log or public package registry.

---

## 2. Version policy

We use semver-style versioning, currently in the 0.x.y series.

- **Stable**: `vN.N.N`. Currently not used — every release so far has been a prerelease.
- **Prerelease cadence**: `vN.N.N-alpha.K` → `-beta.K` → `-rc.K` → `vN.N.N`. The `K` counter resets on each new base `N.N.N`. Walkthrough using a hypothetical `vX.Y.Z` base:
  - `vX.Y.Z-alpha.1`, `vX.Y.Z-alpha.2`, ...
  - When ready: `vX.Y.Z-rc.1`, then `vX.Y.Z`.
  - Next cycle: `vX.(Y+1).0-alpha.1` (alpha counter resets to 1).

The base version (`N.N.N`) tracks the manifests at HEAD; the prerelease suffix is the rolling counter. **Do not** tag a stale base version when the source tree's manifests have moved on — that creates skew between manifest version and shipped version (`patch-version.sh` would silently demote every manifest to the tag's base). The resolve-version regex permits it; discipline forbids it.

### When to bump which component

| Change | Bump |
|---|---|
| Bug fix, no API change | next prerelease counter (alpha.K → alpha.K+1) |
| API addition, source-compatible | bump base patch (X.Y.Z → X.Y.(Z+1)), reset counter to alpha.1 |
| Breaking change | bump base minor (X.Y.* → X.(Y+1).0), reset counter to alpha.1 |
| API freeze for release | progress alpha → beta, or beta → rc |
| Ship | drop the prerelease suffix entirely |

We stay in the 0.x.y series until the spec hits v1.0 and we have at least one external consumer running on a stable tag in production. There is no calendar deadline; readiness over schedule.

### Prerelease channel discipline (forward-looking)

Today every prerelease and every stable tag uploads to the same artifact area, distinguished only by the version suffix. **Before going to public registries**, the project must define and document:

- **PyPI**: prereleases are accepted but hidden from default `pip install <package>` resolutions; consumers must opt in with `pip install <package> --pre`. The PEP 440 form already encodes this (`0.13.0a1` is a prerelease; `0.13.0` is not).
- **npm**: use `npm dist-tag` — `next` for prereleases, `latest` only on stable tags. `npm install @microsoft/agent-shield` then resolves to the latest stable; alphas require `@next` or an explicit version.
- **NuGet**: prereleases require `--prerelease` on `dotnet add package` or a `<Version>` with `-alpha`/`-beta`/`-rc` in the consumer's csproj.
- **crates.io**: not currently planned. If pursued, `cargo add` consumers must explicitly opt in to prereleases (`agent_shield_core = "0.13.0-alpha.1"` works, `"0.13"` does not — Cargo's prerelease rules apply).

The decision points are: when do we go to public registries, and do we ship the alpha series there at all? Both are deferred until at least one stable tag is cut.

---

## 3. Sources of truth (what `patch-version.sh` touches)

The release script edits exactly **four** files — one per ecosystem:

| Ecosystem | File | Property |
|---|---|---|
| Rust | `Cargo.toml` | `[workspace.package].version` |
| .NET | `sdk/dotnet/src/Directory.Build.props` | `<AgentShieldVersion>` |
| Python | `sdk/python/pyproject.toml` | `version` (PEP 440 form) |
| Node | `sdk/node/package.json` | `version` |

Every other manifest in the repo inherits from one of these four:

- All 9 Rust crates use `version.workspace = true`.
- All 7 shipping .NET csprojs use `<Version>$(AgentShieldVersion)</Version>` via `Directory.Build.props` MSBuild property propagation.

If you add a new crate or csproj, **make it inherit**. Don't carry a literal version in the new manifest. The script's post-patch verifier scans every shipping manifest and fails loud at patch time if a version field doesn't match the target.

The script also normalizes for Python's PEP 440: `0.13.0-alpha.1` becomes `0.13.0a1` for `pyproject.toml`. All other ecosystems use the canonical form.

### Dry-run on every PR

`.github/workflows/release-dry-run.yml` runs `patch-version.sh` with a shaped-but-fake version (`99.99.99-rc.99`) on every PR that touches a manifest or the script itself, then exercises the real `cargo check` / `dotnet pack` / `maturin build` / `npm pack` paths. **Every bug we hit cutting v0.13.0-alpha.1** (adapter-dep specs, Node tarball duplication, sister-csproj version skew) would have failed this workflow at PR time. Don't disable it.

---

## 4. Lockfile policy

The repo commits exactly two lockfiles:

- **`Cargo.lock` at the repo root.** Single workspace lockfile covering every Rust crate (sdk/rust/* + sdk/node + sdk/python). The workspace conversion in this PR replaced 9 per-crate lockfiles with this one; the Python wheel, Node native, and .NET native lib now resolve transitive deps consistently.
- **`sdk/python/uv.lock`.** Pure-Python deps only (PyYAML, framework adapters); not touched by `patch-version.sh` because uv re-resolves on `uv sync`.

We do **not** commit:

- Per-crate `Cargo.lock` files (deleted; the workspace lockfile covers them).
- `sdk/node/package-lock.json` is currently committed but only Node's own dev/peer deps drive it; the Rust dep graph is captured by the root `Cargo.lock`.

`patch-version.sh` does not regenerate `Cargo.lock` — Cargo re-resolves automatically when manifests change at build time, and the workspace `path` deps mean inter-crate version pins are not part of the lockfile. If a release-time `cargo build` reveals a lockfile out-of-sync error, that's a signal that an external dep version constraint changed and the lockfile needs `cargo update` — fix in a follow-on PR, not in the release tag.

---

## 5. Pre-flight checklist

Before pushing a tag:

- [ ] Every PR you want in the release is merged to `main`.
- [ ] CI is green on `main` (Rust CI, Cross-Language Integration Tests, Release Pipeline Dry-Run on the last PR that triggered it).
- [ ] Run the dry-run locally as a paranoia check. Substitute the version at HEAD for `<canonical>`:
  ```bash
  bash .github/scripts/patch-version.sh 99.99.99-rc.99    # exercise the fake-version path
  cargo check --workspace --all-features                  # workspace builds clean
  bash .github/scripts/patch-version.sh <canonical>       # reset manifests
  git restore Cargo.lock                                  # cargo check above bumped the lockfile
  git diff --exit-code                                    # → exit 0 means worktree is clean
  ```
- [ ] The previous release's smoke-tests passed (the `smoke-test-{python,node,dotnet}` jobs in `publish.yml`). Re-running the dry-run is cheaper than discovering a regression in production.
- [ ] You have a tag message ready summarizing PRs since the last tag.

After pushing the tag:

- [ ] Watch the publish run (`gh run watch`). If anything fails, **do not delete the tag silently** — leave it, push a fix-up commit to main, and cut the next prerelease counter (alpha.K → alpha.K+1). Re-cutting the same tag is a footgun.

## 5.1 Required release gates

A release candidate is not ready to tag unless the following checks are green on the exact commit being released:

- `release-claim-gate.yml` — the tag-time release blocker. It runs the four conformance runners, verifies `tests/conformance/coverage.md` is current, and verifies this document's certified claim list.
- `codeql.yml` — required pre-tag analysis for Rust, Python, JavaScript/TypeScript, and C#.
- `sca.yml` — required pre-tag dependency-vulnerability scan (`cargo audit`, `pip-audit`, `npm audit --audit-level=high`, `.NET` vulnerable-package check, plus a Grype scan of the generated CycloneDX SBOM with `severity-cutoff: high` and `fail-build: true`).
- `secret-scan.yml` — required pre-tag repository secret scan.
- `license-scan.yml` — required pre-tag GPL-incompatible dependency check.
- Existing build/test gates (`rust.yml`, `integration.yml`, `release-dry-run.yml`, `governance-check.yml`).

Two tag-triggered workflows run the release-claim verification: `release-claim-gate.yml` (the dedicated gate) and `publish.yml`'s `release-claim` job (which gates the actual publish step). Both must pass before any artifact is published. The other workflows are required to be green on the branch head before tagging (for example through branch protection on `main` and local `ci-verification` before the tag is pushed); they are not re-run automatically by `publish.yml`.

Run `.github/skills/ci-verification/verify.sh` before pushing a branch or tag. It is the local dry-run entry point for these gates.

## 5.2 Private provenance, SBOMs, and artifact attestations

Tag releases remain private to this repository, but the final `Publish release assets` job in `.github/workflows/publish.yml` now emits both **GitHub artifact attestations** and release SBOMs before attaching the release asset set to the tag. This gives the release pipeline signed provenance plus dependency inventory without publishing artifacts to public registries or the public Rekor log.

Release evidence now covers:

- Python wheels and sdists.
- Node tarballs.
- .NET NuGet packages.
- A Rust workspace source bundle generated for release evidence, even though Rust consumers still install from git tags rather than crates.io.
- `agentshield-sbom-cyclonedx.json` and `agentshield-sbom-spdx.json`, generated by the `Generate SBOM (CycloneDX JSON)` and `Generate SBOM (SPDX JSON)` steps.

The publish job then:

- Attests the CycloneDX SBOM against `release-artifacts/*` via `actions/attest-sbom@v1`.
- Attests build provenance for the same `release-artifacts/*` set via `actions/attest-build-provenance@v2`.
- Uploads the SDK packages, Rust source bundle, and both SBOM files to the private GitHub release page on tag builds.

You can verify the private attestations for any downloaded release artifact with GitHub CLI:

```bash
gh attestation verify <downloaded-artifact> \
  --repo microsoft/AgentShield \
  --signer-workflow microsoft/AgentShield/.github/workflows/publish.yml \
  --source-ref refs/tags/v<version> \
  --predicate-type https://cyclonedx.org/bom   # SBOM attestation

gh attestation verify <downloaded-artifact> \
  --repo microsoft/AgentShield \
  --signer-workflow microsoft/AgentShield/.github/workflows/publish.yml \
  --source-ref refs/tags/v<version>            # build provenance attestation
```

Vulnerability policy remains fail-closed: `.github/workflows/sca.yml` generates `agentshield-sca-sbom-cyclonedx.json` and scans it with Grype. Any vulnerability at `high` or `critical` severity (`severity-cutoff: high`) fails the workflow (`fail-build: true`).

What this does **not** do today:

- It does not publish to PyPI, npm, NuGet.org, or crates.io.
- It does not rely on public-registry provenance features such as `npm publish --provenance` because no public publish step exists in this repo.
- It does not sign first-party container images, because this repository currently ships deployment manifests rather than a container-image build pipeline.

---

## 6. Future work (deferred, in order of likely value)

These are tracked decisions, not scheduled deliverables.

1. **`release-please` for automated changelog + version-bump PRs.** [google/release-please](https://github.com/googleapis/release-please) reads conventional commits, opens a release PR with manifest bumps + a generated `CHANGELOG.md`, and tags on merge. Native multi-language support (Cargo, npm, pyproject, NuGet via plugin). Removes the human-in-the-loop "remember to update X" step. Considered for v0.13 cycle; deferred because the current tag-driven flow is working and `release-please`'s value compounds once we have a steady release cadence (multiple alphas per week, not one a month).

2. **Stop committing `sdk/node/package-lock.json`.** It captures Node's own dev/peer deps which dependabot updates routinely; the Rust dep graph (the actual reproducibility surface) is captured by the root `Cargo.lock`. Removing the npm lockfile reduces dependabot noise and simplifies the lockfile policy section above.

3. **Real TOML/XML parsers in `patch-version.sh`.** The script currently uses `sed` for TOML and XML, with a verifier that catches mismatches. With the workspace conversion, the patch surface is small enough that this is fine, but if any of the four edited files grows in complexity (multi-line `<Version>`, conditional MSBuild property groups, TOML inline tables for version), switch to `tomlq` (from `kislyuk/yq`) and `xmlstarlet` respectively. Tracked as low-priority cleanup.

4. **Public-registry publishing.** When the project decides to ship to PyPI / npm / NuGet.org, this document needs:
   - A "publishing credentials" section (OIDC trust to GitHub Actions, no long-lived tokens).
   - The prerelease channel discipline section (§2) becomes binding instead of aspirational.
   - A "yanking a bad release" section per registry.
   - Possibly a separate `publish-to-registries.yml` workflow gated on a release-approval check.
   - **`publish = false` removed** from `[workspace.package]` (currently blocks any `cargo publish` at the manifest level).
   - **`"private": true` removed** from `sdk/node/package.json` (currently blocks `npm publish`).

5. **Public-registry provenance.** The repo now emits private GitHub artifact attestations. If the project later publishes to public registries, this section needs to describe ecosystem-specific provenance (`npm publish --provenance`, trusted publishing for PyPI, public NuGet signing/distribution choices, and any public transparency-log posture) rather than the current private-only attestation flow.

6. **Repo-wide `cargo deny` / `cargo audit` step** in the publish workflow. We already have dependabot scanning; `cargo deny` would enforce a license allowlist and known-vuln deny at release time. Cheap to add; deferred until at least one stable release.
