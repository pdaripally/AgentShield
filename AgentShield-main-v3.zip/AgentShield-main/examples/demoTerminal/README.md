# Split-screen demo TUI

Side-by-side Textual TUI that runs **two** example agents as subprocesses —
typically the same agent unguarded on the left and Agent-Shield-guarded on
the right — so you can fire the same prompt at both and watch the runtime
catch attacks in real time.

Each prompt typed into the bottom prompt bar gets piped into both
subprocesses' stdin. The subprocesses are the same `demo.py` files in
`examples/agents/*/` you can run standalone; the launcher just wires them
into the two panes and routes `/left`, `/right`, `/both` prefixes.

## Install

From the repo root:

```bash
python3 -m venv .venv
source .venv/bin/activate
source "$HOME/.cargo/env"            # Rust toolchain for the SDK build
pip install -e "sdk/python[all]"
pip install -r examples/demoTerminal/requirements.txt
```

## Configure

Put Azure OpenAI (or OpenAI) creds in either `.env` in this directory or
in the repo root. See `examples/_shared/env.py` for the variables read.

```bash
cd examples/demoTerminal
set -a && source .env && set +a
export LLM_PROVIDER=azure              # or "openai"
export AGENT_SHIELD_LOG_LEVEL=ERROR    # quiet the warning chatter during a demo
```

## Run

```bash
# Bank-manager agent — unguarded ↔ guarded
python split_demo.py --preset bank-manager

# Document-DLP agent — unguarded ↔ guarded
python split_demo.py --preset sensitive-docs

# Or arbitrary scripts
python split_demo.py path/to/left.py path/to/right.py -- --framework langchain
```

## Prompt prefixes

| Prefix          | Behavior                                                   |
| --------------- | ---------------------------------------------------------- |
| _(no prefix)_   | Send to **both** panes                                     |
| `/both <text>`  | Send to both panes                                         |
| `/left <text>`  | Send only to the LEFT (unguarded) pane                     |
| `/right <text>` | Send only to the RIGHT (guarded) pane                      |
| `/newSession`   | Reset both agents (clear history + reload YAML configs)    |
| `/clear`        | Clear both output panes                                    |
| `/quit`         | Terminate both processes and exit                          |

## How presets work

Each preset launches the same `demo.py` twice — once with `--no-shield`
(left pane, unguarded) and once without (right pane, guarded). The
`--no-shield` flag is defined in `examples/_shared/runner.py` and
implemented in each agent's `demo.py`; it only affects interactive REPL
mode, not `--scenarios` runs.

This means the two panes share **one** codebase, **one** YAML
configuration, and **one** LLM client. The only difference is whether
Stage 1–5 enforcement is in the call path.

## Framework selection

`--framework langchain` is the default. The presets format `{framework}`
into the script path, but the script doesn't actually vary by
framework — what varies is the `--framework` flag passed through to the
agent. To run against a different framework:

```bash
python split_demo.py --preset bank-manager --framework openai_agents
```
