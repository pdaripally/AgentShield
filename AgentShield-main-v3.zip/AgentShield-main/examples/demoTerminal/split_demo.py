"""Split-pane terminal demo — run two agents side-by-side.

Launch a guarded and unguarded demo in a rich split-screen TUI so you
can send the same prompt to both and instantly compare their behaviour.

Usage
-----
    python split_demo.py <left_script> <right_script> [-- extra_args]
    python split_demo.py --preset sensitive-docs
    python split_demo.py --preset bank-manager

Input commands
--------------
    /both <text>   Send to BOTH panes  (default when no prefix is given)
    /left <text>   Send only to the LEFT (unguarded) pane
    /right <text>  Send only to the RIGHT (guarded) pane
    /newSession    Reset both agents (clear history + reload YAML configs)
    /clear         Clear both output panes
    /quit          Terminate both processes and exit
"""

from __future__ import annotations

import argparse
import asyncio
import os
import re
import sys
from pathlib import Path

from rich.text import Text
from textual import on
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.widgets import Footer, Header, Input, RichLog, Static


# ── Constants ───────────────────────────────────────────────────────────

HEADER_LEFT = "\U0001f513  UNGUARDED"
HEADER_RIGHT = "\U0001f6e1\ufe0f  GUARDED"

_ANSI_RE = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")

# Pattern matching debug / system output lines
_SYSTEM_LINE_RE = re.compile(
    r"^\[.+?\]"          # [Config], [LLM], [Tools], [Stage 2], etc.
    r"|^\s{2,}\S"        # Indented continuation lines (debug details)
    r"|^> $"             # Bare prompt
    r"|^\u2014\s"        # Separator (— process exited —)
)

PRESETS: dict[str, dict] = {
    "sensitive-docs": {
        "script": "../agents/document-dlp/demo.py",
        "left_args": ["--no-shield", "--framework", "{framework}"],
        "right_args": ["--framework", "{framework}"],
        "left_label": "\U0001f513  UNGUARDED \u2014 Document DLP",
        "right_label": "\U0001f6e1\ufe0f  GUARDED \u2014 Document DLP",
    },
    "bank-manager": {
        "script": "../agents/bank-manager/demo.py",
        "left_args": ["--no-shield", "--framework", "{framework}"],
        "right_args": ["--framework", "{framework}"],
        "left_label": "\U0001f513  UNGUARDED \u2014 Bank Manager",
        "right_label": "\U0001f6e1\ufe0f  GUARDED \u2014 Bank Manager",
    },
}


# ── Helpers ─────────────────────────────────────────────────────────────

def strip_ansi(text: str) -> str:
    """Remove ANSI escape sequences so Textual renders clean text."""
    return _ANSI_RE.sub("", text)


def _style_output_line(line: str) -> Text:
    """Apply distinct styling to differentiate agent answers from debug info."""
    stripped = line.strip()
    if not stripped:
        return Text("")
    if (
        "[GUARDRAIL" in stripped
        or stripped.startswith("[ERROR")
        or stripped.startswith("[WARNING] agent_shield")
    ):
        return Text(line, style="bold red")
    # Session reset messages
    if stripped.startswith("[Session]") or stripped.startswith("[Guardrails] Reloaded"):
        return Text(line, style="bold yellow")
    # Debug / system info — dim
    if _SYSTEM_LINE_RE.match(line):
        return Text(line, style="dim")
    # Agent answer — bold with green bar
    t = Text()
    t.append("\u2502 ", style="bold green")
    t.append(line, style="bold bright_white")
    return t


# ── Subprocess wrapper ──────────────────────────────────────────────────

class DemoProcess:
    """Manages an async subprocess running one demo agent."""

    def __init__(self, script: str, extra_args: list[str], label: str) -> None:
        self.script = os.path.abspath(script)
        self.cwd = os.path.dirname(self.script)
        self.extra_args = extra_args
        self.label = label
        self.process: asyncio.subprocess.Process | None = None

    async def start(self) -> None:
        env = os.environ.copy()
        env["PYTHONUNBUFFERED"] = "1"
        # Suppress noisy library loggers unless the user explicitly set levels
        env.setdefault("AGENT_SHIELD_LOG_LEVEL", "WARNING")
        self.process = await asyncio.create_subprocess_exec(
            sys.executable, "-u", self.script, *self.extra_args,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            cwd=self.cwd,
            env=env,
        )

    async def send(self, text: str) -> None:
        if self.process and self.process.stdin and not self.process.stdin.is_closing():
            self.process.stdin.write(f"{text}\n".encode())
            await self.process.stdin.drain()

    async def stop(self) -> None:
        if self.process is None:
            return
        # Send 'quit' first so the demo can shut down cleanly
        try:
            if self.process.stdin and not self.process.stdin.is_closing():
                self.process.stdin.write(b"quit\n")
                await self.process.stdin.drain()
                self.process.stdin.close()
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        try:
            await asyncio.wait_for(self.process.wait(), timeout=4)
        except asyncio.TimeoutError:
            try:
                self.process.terminate()
            except ProcessLookupError:
                pass
            try:
                await asyncio.wait_for(self.process.wait(), timeout=2)
            except asyncio.TimeoutError:
                self.process.kill()


# ── Textual CSS ─────────────────────────────────────────────────────────

APP_CSS = """
Screen {
    layout: vertical;
}

#panels {
    height: 1fr;
}

#left-panel, #right-panel {
    width: 1fr;
    height: 100%;
}

#left-panel {
    border: heavy $error;
}

#right-panel {
    border: heavy $success;
}

.panel-header {
    dock: top;
    text-align: center;
    padding: 0 1;
    text-style: bold;
    height: 1;
}

#left-panel .panel-header {
    background: $error-darken-2;
    color: $text;
}

#right-panel .panel-header {
    background: $success-darken-2;
    color: $text;
}

#left-output, #right-output {
    height: 1fr;
    scrollbar-size: 1 1;
}

#hint {
    height: 1;
    text-align: center;
    color: $text-muted;
    padding: 0 1;
}

#input-bar {
    height: 3;
    padding: 0 1;
}
"""


# ── Textual App ─────────────────────────────────────────────────────────

class SplitDemoApp(App):
    """Side-by-side agent demo TUI."""

    TITLE = "Agent Shield \u2014 Split Demo"
    CSS = APP_CSS
    BINDINGS = [
        Binding("ctrl+l", "clear_logs", "Clear", show=True),
    ]

    def __init__(
        self,
        left_script: str,
        right_script: str,
        left_args: list[str] | None = None,
        right_args: list[str] | None = None,
        left_label: str = HEADER_LEFT,
        right_label: str = HEADER_RIGHT,
    ) -> None:
        super().__init__()
        self.left = DemoProcess(left_script, left_args or [], left_label)
        self.right = DemoProcess(right_script, right_args or [], right_label)
        self._left_label = left_label
        self._right_label = right_label
        self._tasks: list[asyncio.Task] = []

    # ── Layout ───────────────────────────────────────────────────────

    def compose(self) -> ComposeResult:
        yield Header()
        with Horizontal(id="panels"):
            with Vertical(id="left-panel"):
                yield Static(self._left_label, classes="panel-header")
                yield RichLog(id="left-output", wrap=True, auto_scroll=True)
            with Vertical(id="right-panel"):
                yield Static(self._right_label, classes="panel-header")
                yield RichLog(id="right-output", wrap=True, auto_scroll=True)
        yield Static(
            "  /both \u2022 /left \u2022 /right \u2022 /newSession  (default: /both)   "
            "/exit quit   Ctrl+L clear",
            id="hint",
        )
        yield Input(
            placeholder="/both <input>  |  /left <input>  |  /right <input>",
            id="input-bar",
        )

    # ── Lifecycle ────────────────────────────────────────────────────

    async def on_mount(self) -> None:
        self.query_one("#input-bar", Input).focus()

        left_log = self.query_one("#left-output", RichLog)
        right_log = self.query_one("#right-output", RichLog)

        left_log.write(Text("Starting process\u2026", style="dim italic"))
        right_log.write(Text("Starting process\u2026", style="dim italic"))

        try:
            await self.left.start()
        except Exception as exc:
            left_log.write(Text(f"FAILED to start: {exc}", style="bold red"))
            return

        try:
            await self.right.start()
        except Exception as exc:
            right_log.write(Text(f"FAILED to start: {exc}", style="bold red"))
            return

        self._tasks.append(
            asyncio.create_task(self._pipe_output(self.left, "left-output"))
        )
        self._tasks.append(
            asyncio.create_task(self._pipe_output(self.right, "right-output"))
        )

    async def _pipe_output(self, proc: DemoProcess, widget_id: str) -> None:
        """Read subprocess stdout and stream it into the corresponding RichLog."""
        widget = self.query_one(f"#{widget_id}", RichLog)
        assert proc.process is not None and proc.process.stdout is not None
        reader = proc.process.stdout
        buffer = ""

        while True:
            # Read with a short timeout so partial lines (prompts) are flushed
            try:
                data = await asyncio.wait_for(reader.read(4096), timeout=0.20)
            except asyncio.TimeoutError:
                if buffer:
                    widget.write(_style_output_line(buffer))
                    buffer = ""
                continue

            if not data:
                # EOF — process ended
                if buffer:
                    widget.write(_style_output_line(buffer))
                widget.write(Text("\u2014 process exited \u2014", style="dim"))
                break

            buffer += strip_ansi(data.decode("utf-8", errors="replace"))

            # Emit every complete line; keep any trailing partial in buffer
            while "\n" in buffer:
                line, buffer = buffer.split("\n", 1)
                widget.write(_style_output_line(line))

    # ── Cleanup ──────────────────────────────────────────────────────

    async def _cleanup(self) -> None:
        for task in self._tasks:
            if not task.done():
                task.cancel()
        await self.left.stop()
        await self.right.stop()

    async def action_quit(self) -> None:
        await self._cleanup()
        self.exit()

    def action_clear_logs(self) -> None:
        self.query_one("#left-output", RichLog).clear()
        self.query_one("#right-output", RichLog).clear()

    # ── Input handling ───────────────────────────────────────────────

    @on(Input.Submitted, "#input-bar")
    async def handle_input(self, event: Input.Submitted) -> None:
        raw = event.value.strip()
        event.input.value = ""
        if not raw:
            return

        left_log = self.query_one("#left-output", RichLog)
        right_log = self.query_one("#right-output", RichLog)

        # Meta commands
        if raw.lower() in ("/quit", "/exit"):
            await self.action_quit()
            return
        if raw.lower() == "/clear":
            self.action_clear_logs()
            return
        if raw.lower() == "/newsession":
            self.action_clear_logs()
            left_log.write(Text("\U0001f504 New session starting\u2026", style="bold yellow"))
            right_log.write(Text("\U0001f504 New session starting\u2026", style="bold yellow"))
            await self.left.send("/newSession")
            await self.right.send("/newSession")
            return

        # Determine target
        target = "both"
        text = raw
        lower = raw.lower()

        if lower.startswith("/left "):
            target = "left"
            text = raw[6:]
        elif lower.startswith("/right "):
            target = "right"
            text = raw[7:]
        elif lower.startswith("/both "):
            target = "both"
            text = raw[6:]

        if not text.strip():
            return

        echo = Text(f"\u25b6 {text}", style="bold cyan")

        if target in ("both", "left"):
            left_log.write(echo)
            await self.left.send(text)

        if target in ("both", "right"):
            right_log.write(echo)
            await self.right.send(text)


# ── CLI ──────────────────────────────────────────────────────────────────

def resolve_preset(name: str, framework: str = "langchain") -> dict[str, object]:
    """Resolve a preset name to absolute script paths + per-side args."""
    preset = PRESETS[name]
    base = os.path.dirname(os.path.abspath(__file__))
    script = os.path.normpath(os.path.join(base, preset["script"].format(framework=framework)))
    left_args = [a.format(framework=framework) for a in preset["left_args"]]
    right_args = [a.format(framework=framework) for a in preset["right_args"]]
    return {
        "left_script": script,
        "right_script": script,
        "left_args": left_args,
        "right_args": right_args,
        "left_label": preset["left_label"],
        "right_label": preset["right_label"],
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run two agent demos side-by-side in a split TUI.",
        epilog=(
            "Any arguments after '--' are forwarded to both demo scripts.\n\n"
            "Examples:\n"
            "  python split_demo.py --preset sensitive-docs\n"
            "  python split_demo.py --preset bank-manager\n"
            "  python split_demo.py path/to/demo_agent.py path/to/demo_agent_guarded.py\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "left", nargs="?", default=None,
        help="Path to the LEFT (unguarded) demo script",
    )
    parser.add_argument(
        "right", nargs="?", default=None,
        help="Path to the RIGHT (guarded) demo script",
    )
    parser.add_argument(
        "--preset", choices=list(PRESETS.keys()),
        help="Use a built-in preset instead of specifying scripts manually",
    )
    parser.add_argument("--left-label", default=None, help="Header label for the left pane")
    parser.add_argument("--right-label", default=None, help="Header label for the right pane")
    parser.add_argument(
        "--framework",
        default="langchain",
        choices=["langchain", "semantic_kernel", "openai_agents", "crewai", "autogen"],
        help="Which framework's demo to run (default: langchain)",
    )

    args, extra = parser.parse_known_args()
    if extra and extra[0] == "--":
        extra = extra[1:]

    # Resolve scripts + per-side args
    left_args: list[str] = []
    right_args: list[str] = []
    if args.preset:
        resolved = resolve_preset(args.preset, framework=args.framework)
        left_script = resolved["left_script"]
        right_script = resolved["right_script"]
        left_args = list(resolved["left_args"]) + list(extra)
        right_args = list(resolved["right_args"]) + list(extra)
        left_label = args.left_label or resolved["left_label"]
        right_label = args.right_label or resolved["right_label"]
    elif args.left and args.right:
        left_script = os.path.abspath(args.left)
        right_script = os.path.abspath(args.right)
        left_args = list(extra)
        right_args = list(extra)
        left_label = args.left_label or HEADER_LEFT
        right_label = args.right_label or HEADER_RIGHT
    else:
        parser.error(
            "Provide either --preset or both <left> and <right> script paths."
        )

    for label, path in [("Left", left_script), ("Right", right_script)]:
        if not os.path.isfile(path):
            parser.error(f"{label} script not found: {path}")

    app = SplitDemoApp(
        left_script=left_script,
        right_script=right_script,
        left_args=left_args,
        right_args=right_args,
        left_label=left_label,
        right_label=right_label,
    )

    try:
        app.run()
    finally:
        # Best-effort cleanup for abnormal exits (event loop is gone here)
        for proc in [app.left, app.right]:
            if proc.process and proc.process.returncode is None:
                try:
                    proc.process.terminate()
                except (ProcessLookupError, OSError):
                    pass


if __name__ == "__main__":
    main()
