# AutoGen + Azure OpenAI team quickstart

Runnable AutoGen AgentChat 0.7 + Azure OpenAI example: Intake → KYC → Account agents share one Agent Shield session and one `.guardrails.yaml` contract.

## Files

| File | Role |
| ---- | ---- |
| `autogen_team_quickstart_azure.py` | Three-agent team and scenario driver |
| `autogen_team_quickstart_azure.guardrails.yaml` | Guardrails contract |

## 1. Install

```bash
pip install -e "sdk/python[autogen]"
pip install "autogen-agentchat" "autogen-ext[openai]" "autogen-core"
```

For `agent-shield init --provider azure`, also install:

```bash
pip install -e "cli[azure]"
```

## 2. Configure Azure OpenAI

```ini
AZURE_OPENAI_ENDPOINT=https://<your-resource>.openai.azure.com/
AZURE_OPENAI_API_KEY=<key>
AZURE_OPENAI_DEPLOYMENT=<your-deployment-name>
AZURE_OPENAI_API_VERSION=2024-12-01-preview

# Optional AACS Stage 1 classifier.
AZURE_CONTENT_SAFETY_ENDPOINT=https://<resource>.cognitiveservices.azure.com/
AZURE_CONTENT_SAFETY_KEY=<key>
```

Custom Azure deployment names need explicit `model_info`:

```python
from autogen_core.models import ModelInfo
from autogen_ext.models.openai import AzureOpenAIChatCompletionClient

model_client = AzureOpenAIChatCompletionClient(
    model=os.getenv("AZURE_OPENAI_DEPLOYMENT"),
    azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT"),
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-12-01-preview"),
    model_info=ModelInfo(
        vision=False, function_calling=True, json_output=True,
        family="unknown", structured_output=True,
    ),
)
```

## 3. Run

```bash
python examples/autogen_team_quickstart_azure.py
```

Scenarios:

- `benign_personal` — KYC succeeds and the final reply is Stage-5-redacted.
- `business_tier_requires_approval` — Stage 2 returns a `pending_resolution` before `create_account` runs.
- `cross_customer_blocked_at_stage1` — Stage 1 blocks before the team starts.

## 4. Guard the team, not each handoff

Stage 5 redaction rewrites agent output. In a multi-agent team, redacting the Intake → KYC handoff removes the SSN before `verify_identity` can run. Use the team helper so Stage 5 runs only on the final customer-facing message:

```python
from autogen_agentchat.agents import AssistantAgent
from autogen_agentchat.conditions import MaxMessageTermination, TextMentionTermination
from autogen_agentchat.teams import RoundRobinGroupChat

intake = AssistantAgent(name="intake_agent", tools=intake_tools, model_client=mc, ...)
kyc = AssistantAgent(name="kyc_agent", tools=kyc_tools, model_client=mc, ...)
account = AssistantAgent(name="account_agent", tools=account_tools, model_client=mc, ...)

raw_team = RoundRobinGroupChat(
    participants=[intake, kyc, account],
    termination_condition=TextMentionTermination("TERMINATE") | MaxMessageTermination(12),
)

guarded_team = shield.create_autogen_team(raw_team)
result = await guarded_team.run(task="Onboard new customer...")
```

The helper owns one shared session, wraps participant tools for Stages 2/3/4, runs Stage 1 once on the task text, and runs Stage 5 once on the final team response.

The YAML still blocks SSN-shaped arguments at Stage 3 so only `verify_identity` can receive the SSN:

```yaml
tool_execution_validation:
  guard_policies:
    - name: "ssn_only_to_verify_identity"
      applies_to: { tools: ["*"] }
      evaluate_when:
        - expression: "tool.name == 'verify_identity' or not arg_looks_like_ssn"
          reason: "SSN-shaped argument is only permitted on verify_identity."
      action: "block"
```

## 5. Shared-session fallback

If you cannot use `BaseGroupChat`, point every guarded runner at the same session:

```python
intake = shield.create_autogen_agent(model, intake_tools, name="intake_agent")
kyc = shield.create_autogen_agent(model, kyc_tools, name="kyc_agent")
account = shield.create_autogen_agent(model, account_tools, name="account_agent")

shared = intake._session
kyc._session = shared
account._session = shared
```

## 6. Human approval surface

When `business_account_requires_approval` blocks, the verdict carries:

```python
{
    "kind": "human",
    "tool": "agent_shield.ask_human",
    "variable": "business_account_authorized",
    "prompt": "Approve creating a BUSINESS-tier account for this customer?",
    "request_id": "...",
}
```

Route the prompt to your UI, then resume by setting the variable:

```python
shared_session.set_variable("business_account_authorized", True)
```

For a bare-core loop, see [`human_approval_quickstart.py`](human_approval_quickstart.py).

## 7. Coverage

```python
CapabilityReport(
    framework="autogen",
    input_validation=FULL,
    state_validation=PARTIAL,
    tool_authorization=PARTIAL,
    tool_execution_validation=PARTIAL,
    tool_output_validation=PARTIAL,
    streaming_output=UNSUPPORTED,
)
```

Stages 2–4 are partial because they cover tools wrapped through the adapter. AutoGen streaming is unsupported; use buffered/final-response paths. Details: [`sdk/python/agent_shield/adapters/autogen/MEDIATION.md`](../sdk/python/agent_shield/adapters/autogen/MEDIATION.md).

## Troubleshooting

- **`ImportError: cannot import name 'AzureOpenAIChatCompletionClient'`** or **tiktoken missing** — install `pip install "autogen-ext[openai]"`.
- **`model_info is required`** — add the `ModelInfo(...)` block shown above for custom Azure deployment names.
- **`kyc_token=unset`** — use `shield.create_autogen_team(...)` or share `_session` across runners.
- **KYC saw `[SSN REDACTED]`** — Stage 5 is redacting upstream handoffs. Run Stage 5 only on the final response and rely on the Stage 3 SSN tool-arg gate.
- **`classifier_wiring_missing`** — rebuild `sdk/python` with the AACS feature enabled in the native module.
- **`agent-shield init --provider azure` needs `openai`** — install `pip install -e "cli[azure]"`.
