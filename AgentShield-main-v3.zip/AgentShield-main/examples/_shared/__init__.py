"""Cross-example demo plumbing for the agent demos under `examples/agents/`.

This package owns the "boilerplate" so each agent demo can stay focused
on the *Agent Shield integration code itself*, not on env handling, MCP
wiring, REPL plumbing, or framework-specific LLM construction.

Public surface (re-exported here, defined in submodules):

* ``getenv`` / ``mask`` — env-var hygiene helpers.
* ``MCPConnection`` / ``mcp_result_to_str`` — async MCP stdio context
  manager and result coercion.
* ``build_llm_for(framework)`` — construct the framework's chat client
  from ``LLM_PROVIDER`` env vars.
* ``shield_with(framework, builder)`` — call the right
  ``Shield.from_yaml(...).with_<framework>()`` adapter for the chosen
  framework. Lets `demo.py` stay framework-agnostic.
* ``build_agent_for(framework, ...)`` — construct the framework-native
  agent / runner, returning an object exposing the unified
  ``ainvoke(input)`` interface the REPL / scenario runner consume.
* ``run_repl`` — interactive REPL skeleton with `before_invoke` /
  `on_new_session` hooks.
* ``run_scenarios`` — scripted side-by-side guarded ↔ unguarded runner.
* ``parse_args`` / ``setup_args`` — shared CLI flags (``--framework``,
  ``--scenarios``, ``--request``, ``--debug``).
* ``Scenario`` / ``ScenarioCatalog`` — typed scripted scenarios for
  the agent demos.

The framework-agnostic claim — same `.guardrails.yaml`, same scenarios,
same verdicts across LangChain / Anthropic Agents SDK — is delivered
*here*, in this package: each agent demo's ``demo.py`` takes a
``--framework`` flag that dispatches through `build_llm_for` /
`shield_with` / `build_agent_for`, with no per-framework directories
duplicating MCP and REPL plumbing.
"""

from .env import getenv, mask
from .frameworks import (
    SUPPORTED_FRAMEWORKS,
    AgentRunner,
    build_agent_for,
    build_llm_for,
    build_native_agent_for,
    build_tools_for,
    install_adapters,
    shield_with,
    wrap_guarded_for,
)
from .mcp import MCPConnection, mcp_banking_server_command, mcp_result_to_str
from .repl import run_repl
from .scenarios import Scenario, ScenarioCatalog, run_scenarios
from .runner import parse_args, setup_args

__all__ = [
    "AgentRunner",
    "MCPConnection",
    "SUPPORTED_FRAMEWORKS",
    "Scenario",
    "ScenarioCatalog",
    "build_agent_for",
    "build_llm_for",
    "build_native_agent_for",
    "build_tools_for",
    "getenv",
    "install_adapters",
    "mask",
    "mcp_banking_server_command",
    "mcp_result_to_str",
    "parse_args",
    "run_repl",
    "run_scenarios",
    "setup_args",
    "shield_with",
    "wrap_guarded_for",
]
