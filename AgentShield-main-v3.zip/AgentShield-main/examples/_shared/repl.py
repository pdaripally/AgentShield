"""Interactive REPL skeleton for the agent demos.

Drives the read-prompt-print loop or the one-shot ``--request`` flow.
The agent demo supplies an ``invoke`` coroutine; this module owns the
input loop, the ``/newSession`` handler, and the Stage-1
``before_invoke`` hook (the guarded variant of each demo passes
``shield.before_invoke`` here).
"""
from __future__ import annotations

import functools
from typing import Awaitable, Callable

import anyio

__all__ = ["run_repl"]


async def run_repl(
    *,
    invoke: Callable[[str], Awaitable[str]],
    before_invoke: Callable[[str], Awaitable[str | None]] | None = None,
    on_new_session: Callable[[], None] | None = None,
    banner: str,
    single_request: str | None,
) -> None:
    """Drive the REPL loop or one-shot ``--request`` flow.

    ``invoke`` runs one request end-to-end. ``before_invoke`` is the
    optional Stage-1 hook (Agent Shield input validation in the
    guarded demo). ``on_new_session`` runs when the user types
    ``/newSession`` so the framework adapter can reset its state.
    """
    if single_request is not None:
        if before_invoke is not None:
            block_msg = await before_invoke(single_request)
            if block_msg is not None:
                print(f"\n{block_msg}")
                return
        print(await invoke(single_request))
        return

    print(f"\n{banner}\n")
    while True:
        try:
            user_input = await anyio.to_thread.run_sync(
                functools.partial(input, "> "), abandon_on_cancel=True,
            )
        except EOFError:
            break
        user_input = user_input.strip()
        if not user_input:
            continue
        if user_input.lower() in ("quit", "exit", "q"):
            break

        if user_input.lower() == "/newsession":
            if on_new_session is not None:
                on_new_session()
            print("[Session] New session started — history and state cleared.\n")
            continue

        if before_invoke is not None:
            block_msg = await before_invoke(user_input)
            if block_msg is not None:
                print(f"\n{block_msg}\n")
                continue

        print(await invoke(user_input))
        print()
