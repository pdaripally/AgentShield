"""Per-framework LLM construction.

Each agent demo's ``demo.py`` calls ``build_llm_for(framework)``;
the function picks the right SDK + env-var routing. Provider routing
is by ``LLM_PROVIDER`` env var (within a framework). Framework choice
is by argparse ``--framework`` (across frameworks).

LangChain branch (provider one of: openai / azure / gemini / ollama)
returns a ``ChatOpenAI`` / ``AzureChatOpenAI``.

Anthropic branch (provider one of: anthropic / bedrock) returns an
``AsyncAnthropic`` / ``AsyncAnthropicBedrock``.
"""
from __future__ import annotations

import os
from typing import Any

from .env import getenv, mask

__all__ = [
    "build_langchain_llm",
    "build_anthropic_client",
    "get_anthropic_model",
]


def _normalize_ollama_base_url(value: str) -> str:
    """Make an ``OLLAMA_HOST`` value safe to feed to ``ChatOpenAI(base_url=...)``.

    ``ChatOpenAI`` always appends ``/chat/completions``; we strip a
    trailing one if present and ensure the result ends in ``/v1`` so
    the final URL is exactly one ``/v1/chat/completions``.
    """
    trimmed = value.rstrip("/")
    if trimmed.endswith("/chat/completions"):
        trimmed = trimmed[: -len("/chat/completions")].rstrip("/")
    if trimmed.endswith("/v1"):
        return trimmed
    return f"{trimmed}/v1"


def build_langchain_llm():
    """Build a LangChain ``ChatOpenAI`` / ``AzureChatOpenAI``.

    Recognised providers (via ``LLM_PROVIDER``):

    * ``openai`` (default) — ``OPENAI_API_KEY`` + ``OPENAI_MODEL``.
    * ``azure``  — ``AZURE_OPENAI_ENDPOINT`` + ``AZURE_OPENAI_API_KEY``
      + ``AZURE_OPENAI_DEPLOYMENT``.
    * ``gemini`` — Google AI Studio's OpenAI-compatible endpoint;
      ``GEMINI_API_KEY`` + ``GEMINI_MODEL``.
    * ``ollama`` — local Ollama OpenAI-compatible endpoint; ``OLLAMA_HOST``
      + ``OLLAMA_MODEL``.
    """
    from langchain_openai import AzureChatOpenAI, ChatOpenAI  # local import

    provider = (os.getenv("LLM_PROVIDER") or "openai").strip().lower() or "openai"

    if provider == "azure":
        endpoint = getenv("AZURE_OPENAI_ENDPOINT")
        api_key = getenv("AZURE_OPENAI_API_KEY")
        deployment = getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4o-mini")
        api_version = getenv("AZURE_OPENAI_API_VERSION", "2024-12-01-preview")
        print(
            f"[LLM] provider=azure  endpoint={endpoint or '(not set)'}"
            f"  deployment={deployment}  api_version={api_version}"
            f"  api_key={mask(api_key)}"
        )
        if not endpoint or not api_key:
            raise RuntimeError(
                "Azure provider requires AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY."
            )
        return AzureChatOpenAI(
            azure_endpoint=endpoint,
            api_key=api_key,
            azure_deployment=deployment,
            api_version=api_version,
        )

    if provider == "gemini":
        api_key = getenv("GEMINI_API_KEY") or getenv("GOOGLE_API_KEY")
        model = getenv("GEMINI_MODEL", "gemini-1.5-pro")
        base_url = getenv(
            "GEMINI_BASE_URL",
            "https://generativelanguage.googleapis.com/v1beta/openai",
        )
        print(
            f"[LLM] provider=gemini  model={model}"
            f"  base_url={base_url}  api_key={mask(api_key)}"
        )
        if not api_key:
            raise RuntimeError(
                "Gemini provider requires GEMINI_API_KEY (or GOOGLE_API_KEY)."
            )
        return ChatOpenAI(model=model, base_url=base_url, api_key=api_key)

    if provider == "ollama":
        model = getenv("OLLAMA_MODEL", "llama3.1")
        host = (getenv("OLLAMA_HOST", "http://localhost:11434") or "").rstrip("/")
        base_url = _normalize_ollama_base_url(host)
        api_key = getenv("OLLAMA_API_KEY", "ollama")
        print(
            f"[LLM] provider=ollama  model={model}  base_url={base_url}"
            f"  api_key={'(loopback)' if api_key == 'ollama' else mask(api_key)}"
        )
        return ChatOpenAI(model=model, base_url=base_url, api_key=api_key)

    api_key = getenv("OPENAI_API_KEY")
    model = getenv("OPENAI_MODEL", "gpt-4o-mini")
    base_url = getenv("OPENAI_BASE_URL")
    print(
        f"[LLM] provider=openai  model={model}"
        f"  base_url={base_url or '(default)'}  api_key={mask(api_key)}"
    )
    if not api_key:
        raise RuntimeError("OpenAI provider requires OPENAI_API_KEY.")
    return ChatOpenAI(model=model, base_url=base_url, api_key=api_key)


def get_anthropic_model() -> str:
    """Pick an Anthropic model id appropriate for the active provider."""
    provider = (os.getenv("LLM_PROVIDER") or "anthropic").strip().lower() or "anthropic"
    if provider == "bedrock":
        return (
            getenv("BEDROCK_ANTHROPIC_MODEL")
            or getenv("ANTHROPIC_MODEL")
            or "anthropic.claude-3-5-sonnet-20241022-v2:0"
        )
    return getenv("ANTHROPIC_MODEL", "claude-sonnet-4-20250514") or "claude-sonnet-4-20250514"


def build_anthropic_client() -> Any:
    """Build an ``AsyncAnthropic`` / ``AsyncAnthropicBedrock`` client.

    Recognised providers (via ``LLM_PROVIDER``):

    * ``anthropic`` (default) — direct Anthropic API. Reads
      ``ANTHROPIC_API_KEY``.
    * ``bedrock`` — Anthropic-on-Amazon-Bedrock. AWS SigV4 from the
      standard botocore chain.
    """
    from anthropic import AsyncAnthropic  # local import

    provider = (os.getenv("LLM_PROVIDER") or "anthropic").strip().lower() or "anthropic"

    if provider == "bedrock":
        from anthropic import AsyncAnthropicBedrock  # lazy import

        # Whitespace-only AWS credentials are a footgun: getenv treats
        # them as unset, but botocore reads `os.environ` directly. Refuse
        # to start in that state to avoid confusing partial-credentials
        # errors from deep inside the AWS SDK.
        for cred_name in (
            "AWS_ACCESS_KEY_ID",
            "AWS_SECRET_ACCESS_KEY",
            "AWS_SESSION_TOKEN",
        ):
            raw = os.environ.get(cred_name)
            if raw is not None and raw != "" and not raw.strip():
                raise RuntimeError(
                    f"Bedrock provider: env var {cred_name} is set to "
                    "whitespace-only. Unset it (or set it to an empty "
                    "string) so the botocore default credential chain "
                    "(~/.aws/credentials, instance metadata, SSO) can "
                    "be used instead."
                )

        region = getenv("AWS_REGION") or getenv("AWS_DEFAULT_REGION") or "us-east-1"
        access_key = getenv("AWS_ACCESS_KEY_ID")
        secret_key = getenv("AWS_SECRET_ACCESS_KEY")
        session_token = getenv("AWS_SESSION_TOKEN")
        both_keys_set = access_key is not None and secret_key is not None
        only_one_set = (access_key is None) ^ (secret_key is None)
        print(
            f"[Client] provider=bedrock  region={region}"
            f"  aws_access_key_id={mask(access_key)}"
        )
        if only_one_set:
            which_set = (
                "AWS_ACCESS_KEY_ID" if access_key is not None else "AWS_SECRET_ACCESS_KEY"
            )
            which_missing = (
                "AWS_SECRET_ACCESS_KEY" if access_key is not None else "AWS_ACCESS_KEY_ID"
            )
            raise RuntimeError(
                f"Bedrock provider has {which_set} set but "
                f"{which_missing} is missing. Set both env vars, or unset "
                "both (or set them to empty strings) and rely on the "
                "default botocore credential chain."
            )
        if not both_keys_set:
            print(
                "[Client] Bedrock: no AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY "
                "in the environment. Falling back to the default botocore "
                "credential chain (~/.aws/credentials, instance metadata, SSO)."
            )
            return AsyncAnthropicBedrock(aws_region=region)
        return AsyncAnthropicBedrock(
            aws_region=region,
            aws_access_key=access_key,
            aws_secret_key=secret_key,
            aws_session_token=session_token,
        )

    api_key = getenv("ANTHROPIC_API_KEY")
    print(f"[Client] provider=anthropic  api_key={mask(api_key)}")
    if not api_key:
        raise RuntimeError("Anthropic SDK requires ANTHROPIC_API_KEY.")
    return AsyncAnthropic(api_key=api_key)
