"""Framework dispatch — the ``--framework`` flag's runtime side.

Each agent demo's ``demo.py`` calls these to build the framework's LLM
client, install the right ``Shield.with_<framework>()`` adapter, and
construct a framework-native agent that exposes a unified
``ainvoke(input)`` interface. This is what makes the framework choice
a CLI flag rather than a directory.

Public surface:

* ``SUPPORTED_FRAMEWORKS`` — the keys ``--framework`` accepts.
* ``install_adapters()`` — preload every supported framework adapter
  (cheap; needed so ``Shield.with_<framework>()`` is wired regardless
  of which the user chose at the CLI).
* ``build_llm_for(framework)`` — chat client for the chosen framework.
* ``shield_with(framework, builder)`` — call the right
  ``ShieldBuilder.with_<framework>()`` adapter.
* ``build_agent_for(framework, llm, tools, system_prompt)`` — returns
  an ``AgentRunner`` exposing ``ainvoke(input) -> str`` and
  ``new_session()`` for ``/newSession`` REPL support.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Sequence

from .llm import build_anthropic_client, build_langchain_llm, get_anthropic_model
from .mcp import mcp_result_to_str

SUPPORTED_FRAMEWORKS: tuple[str, ...] = ("langchain", "anthropic")

__all__ = [
    "AgentRunner",
    "SUPPORTED_FRAMEWORKS",
    "build_agent_for",
    "build_llm_for",
    "build_native_agent_for",
    "build_tools_for",
    "install_adapters",
    "shield_with",
    "wrap_guarded_for",
]


# ---------------------------------------------------------------------------
# Framework-agnostic agent interface
# ---------------------------------------------------------------------------


@dataclass
class AgentRunner:
    """Unified agent interface the REPL / scenario runner consumes.

    Wraps a framework-native agent / runner so callers can drive it
    without knowing which framework is underneath.

    ``ainvoke(input)`` runs one turn and returns the agent's text
    reply. ``new_session()`` resets per-turn state (e.g. checkpointer
    for LangChain, message history for Anthropic) — called by the REPL
    when the user types ``/newSession``.
    """
    framework: str
    invoke: Callable[[str], Awaitable[str]]
    reset: Callable[[], None]
    raw: Any

    async def ainvoke(self, user_input: str) -> str:
        return await self.invoke(user_input)

    def new_session(self) -> None:
        self.reset()


# ---------------------------------------------------------------------------
# Adapter preloading
# ---------------------------------------------------------------------------


def install_adapters() -> None:
    """Preload every supported framework's Shield adapter module.

    The Shield builder picks the adapter via the side-effect of
    importing ``agent_shield.adapters.<framework>``. We load all
    supported frameworks so ``--framework <name>`` works at CLI time
    regardless of which one the user chose.
    """
    import agent_shield.adapters.langchain  # noqa: F401
    import agent_shield.adapters.anthropic_agents  # noqa: F401


# ---------------------------------------------------------------------------
# LLM construction dispatch
# ---------------------------------------------------------------------------


def build_llm_for(framework: str) -> Any:
    """Return the chat client for the chosen framework."""
    if framework == "langchain":
        return build_langchain_llm()
    if framework == "anthropic":
        return build_anthropic_client()
    raise ValueError(
        f"unknown framework {framework!r}; expected one of {SUPPORTED_FRAMEWORKS}"
    )


# ---------------------------------------------------------------------------
# Shield builder dispatch
# ---------------------------------------------------------------------------


def shield_with(framework: str, builder: Any) -> Any:
    """Call ``builder.with_<framework>()`` for the chosen framework."""
    if framework == "langchain":
        return builder.with_langchain()
    if framework == "anthropic":
        return builder.with_anthropic_agents()
    raise ValueError(
        f"unknown framework {framework!r}; expected one of {SUPPORTED_FRAMEWORKS}"
    )


# ---------------------------------------------------------------------------
# Agent runner construction
# ---------------------------------------------------------------------------


def build_agent_for(
    framework: str,
    llm: Any,
    tools: Sequence[Any],
    system_prompt: str,
    *,
    debug: bool = False,
) -> AgentRunner:
    """Build a framework-native agent / runner wrapped in `AgentRunner`.

    The returned `AgentRunner` exposes ``ainvoke(text) -> str`` and
    drives the framework directly — use this for the *unguarded*
    baseline. For the guarded variant, build the native agent the
    same way, hand it to ``shield.guard(...)``, then convert the
    result with ``wrap_guarded_for(framework, guarded, ...)``.
    """
    if framework == "langchain":
        return _build_langchain_agent(llm, list(tools), system_prompt, debug=debug)
    if framework == "anthropic":
        return _build_anthropic_agent(llm, list(tools), system_prompt, debug=debug)
    raise ValueError(
        f"unknown framework {framework!r}; expected one of {SUPPORTED_FRAMEWORKS}"
    )


def build_native_agent_for(
    framework: str,
    llm: Any,
    tools: Sequence[Any],
    system_prompt: str,
) -> Any:
    """Build the framework-native agent / client tuple ``shield.guard()`` consumes.

    LangChain returns an ``AgentExecutor``-like object you'd pass to
    ``shield.guard(agent)`` directly. Anthropic returns the
    ``AsyncAnthropic`` client itself; ``shield.guard(client, tools=...,
    model=..., system=...)`` builds the runner around it.
    """
    if framework == "langchain":
        from langgraph.checkpoint.memory import MemorySaver
        from langchain.agents import create_agent

        return create_agent(
            llm, list(tools), system_prompt=system_prompt, checkpointer=MemorySaver()
        )
    if framework == "anthropic":
        # Anthropic Agents SDK doesn't expose a "build agent" surface; the
        # client is what `shield.guard` wraps, with tools / model / system
        # passed as runner kwargs.
        return llm
    raise ValueError(
        f"unknown framework {framework!r}; expected one of {SUPPORTED_FRAMEWORKS}"
    )


def wrap_guarded_for(
    framework: str,
    guarded: Any,
    *,
    tools: Sequence[Any] = (),
    model: str | None = None,
    system_prompt: str = "",
) -> AgentRunner:
    """Wrap the framework-specific object returned by ``shield.guard(...)``
    in the unified `AgentRunner` shape so the REPL / scenario runner
    can drive it without knowing the framework.
    """
    if framework == "langchain":
        return _wrap_guarded_langchain(guarded)
    if framework == "anthropic":
        return _wrap_guarded_anthropic(
            guarded, tools=list(tools), model=model, system_prompt=system_prompt,
        )
    raise ValueError(
        f"unknown framework {framework!r}; expected one of {SUPPORTED_FRAMEWORKS}"
    )


def _wrap_guarded_langchain(guarded: Any) -> AgentRunner:
    """`shield.guard(langchain_agent)` returns a ``GuardedAgent``
    (defined in ``agent_shield.adapters.langchain``) whose
    ``ainvoke({"messages": [...]}, config=...)`` runs Stage 1 + Stage 5
    around the underlying LangChain agent."""

    config: dict[str, Any] = {"configurable": {"thread_id": "session"}}

    async def invoke(user_input: str) -> str:
        try:
            result = await guarded.ainvoke(
                {"messages": [("human", user_input)]}, config=config,
            )
        except* Exception as eg:
            for exc in eg.exceptions:
                print(f"\n[ERROR] {type(exc).__name__}: {exc}")
            raise
        # Guarded result might be a `_BlockedResult` (override carries
        # the block message) or a normal LangChain dict.
        override = getattr(result, "_final_output_override", None)
        if override:
            return override
        if isinstance(result, dict) and "messages" in result:
            return result["messages"][-1].content
        if hasattr(result, "final_output"):
            return result.final_output
        return str(result)

    def reset() -> None:
        config["configurable"]["thread_id"] = f"session_{id(guarded)}_reset"

    return AgentRunner(
        framework="langchain",
        invoke=invoke,
        reset=reset,
        raw=guarded,
    )


def _wrap_guarded_anthropic(
    guarded: Any,
    *,
    tools: list[Any],
    model: str | None,
    system_prompt: str,
) -> AgentRunner:
    """`shield.guard(client, tools=..., model=..., system=...)` returns
    an Anthropic-flavoured ``GuardedRunner`` whose
    ``run(input_text)`` runs Stage 1 + Stage 5 around the underlying
    ``BetaAsyncToolRunner``."""
    if model is None:
        model = get_anthropic_model()

    async def invoke(user_input: str) -> str:
        try:
            result = await guarded.run(user_input)
        except Exception as e:
            return f"[ERROR] {type(e).__name__}: {e}"
        return _anthropic_final_text(result)

    def reset() -> None:
        # Anthropic GuardedRunner is stateless across runs by default.
        pass

    return AgentRunner(
        framework="anthropic",
        invoke=invoke,
        reset=reset,
        raw=guarded,
    )


def _build_langchain_agent(
    llm: Any,
    tools: list[Any],
    system_prompt: str,
    *,
    debug: bool,
) -> AgentRunner:
    from langgraph.checkpoint.memory import MemorySaver
    from langchain.agents import create_agent
    from langchain_core.callbacks import BaseCallbackHandler
    from langchain_core.outputs import LLMResult

    class _Debug(BaseCallbackHandler):
        def on_llm_start(self, serialized: dict, messages: list, **_: Any) -> None:
            print("\n[DEBUG] LLM request:")
            for msg_list in messages:
                items = [msg_list] if isinstance(msg_list, str) else msg_list
                for msg in items:
                    role = getattr(msg, "type", type(msg).__name__)
                    content = str(getattr(msg, "content", msg))
                    print(
                        f"  [{role}] {content[:300]}{'...' if len(content) > 300 else ''}"
                    )

        def on_llm_end(self, response: LLMResult, **_: Any) -> None:
            print("\n[DEBUG] LLM response:")
            for gen_list in response.generations:
                for gen in gen_list:
                    text = getattr(gen, "text", None) or str(getattr(gen, "message", gen))
                    preview = text[:300] + "..." if len(text) > 300 else text
                    print(f"  {preview}")

        def on_llm_error(self, error: Exception, **_: Any) -> None:
            print(f"\n[DEBUG] LLM error: {type(error).__name__}: {error}")

    callbacks = [_Debug()] if debug else []
    state: dict[str, Any] = {}

    def _build() -> None:
        agent = create_agent(
            llm, tools, system_prompt=system_prompt, checkpointer=MemorySaver()
        )
        state["agent"] = agent
        state["config"] = {
            "configurable": {"thread_id": f"session_{id(agent)}"},
            "callbacks": callbacks,
        }

    _build()

    async def invoke(user_input: str) -> str:
        try:
            result = await state["agent"].ainvoke(
                {"messages": [("human", user_input)]}, config=state["config"],
            )
        except* Exception as eg:
            for exc in eg.exceptions:
                print(f"\n[ERROR] {type(exc).__name__}: {exc}")
            raise
        return result["messages"][-1].content

    return AgentRunner(
        framework="langchain",
        invoke=invoke,
        reset=_build,
        raw=state,
    )


def _build_anthropic_agent(
    client: Any,
    tools: list[Any],
    system_prompt: str,
    *,
    debug: bool,
) -> AgentRunner:
    from anthropic.lib.tools import BetaAsyncToolRunner

    model = get_anthropic_model()
    state: dict[str, Any] = {"messages": []}

    async def invoke(user_input: str) -> str:
        if debug:
            print(f"[DEBUG] User input: {user_input}")
        try:
            tr = BetaAsyncToolRunner(
                client=client,
                model=model,
                tools=tools,
                messages=[{"role": "user", "content": user_input}],
                system=system_prompt,
                max_tokens=4096,
            )
            result = await tr.get_final_message()
        except Exception as e:
            return f"[ERROR] {type(e).__name__}: {e}"
        return _anthropic_final_text(result)

    def reset() -> None:
        state["messages"] = []

    return AgentRunner(
        framework="anthropic",
        invoke=invoke,
        reset=reset,
        raw={"client": client, "model": model, "tools": tools},
    )


def _anthropic_final_text(result: Any) -> str:
    """Extract the final text from an Anthropic ``Message`` / Shield-wrapped result."""
    if hasattr(result, "final_output"):
        return result.final_output
    if hasattr(result, "content"):
        parts = []
        for block in result.content:
            if hasattr(block, "text"):
                parts.append(block.text)
        if parts:
            return "".join(parts)
    return str(result)


# ---------------------------------------------------------------------------
# MCP → framework-native tool builders
# ---------------------------------------------------------------------------


async def build_tools_for(framework: str, session: Any) -> list[Any]:
    """Convert MCP tool schemas into framework-native tools.

    Returned tools are already callable against the live MCP session
    (each closes over ``session``). The agent demo passes the result
    to ``shield.protect_tools(...)`` and then to ``build_agent_for``.
    """
    if framework == "langchain":
        return await _langchain_tools_from_session(session)
    if framework == "anthropic":
        return await _anthropic_tools_from_session(session)
    raise ValueError(
        f"unknown framework {framework!r}; expected one of {SUPPORTED_FRAMEWORKS}"
    )


async def _langchain_tools_from_session(session: Any) -> list[Any]:
    from langchain_core.tools import StructuredTool
    from pydantic import Field, create_model

    type_map: dict[str, type] = {
        "string": str,
        "integer": int,
        "boolean": bool,
        "number": float,
        "array": list,
        "object": dict,
    }
    tools: list[Any] = []
    for mcp_tool in (await session.list_tools()).tools:
        schema = mcp_tool.inputSchema or {}
        properties = schema.get("properties", {})
        required = set(schema.get("required", []))

        fields: dict[str, Any] = {}
        for prop_name, prop_schema in properties.items():
            py_type = type_map.get(prop_schema.get("type", "string"), str)
            desc = prop_schema.get("description", "")
            if prop_name in required:
                fields[prop_name] = (py_type, Field(description=desc))
            else:
                fields[prop_name] = (
                    py_type | None,
                    Field(default=None, description=desc),
                )

        args_model = create_model(f"{mcp_tool.name}Args", **fields) if fields else None

        async def _call(_session=session, _name=mcp_tool.name, **kwargs: Any) -> str:
            return mcp_result_to_str(await _session.call_tool(_name, kwargs))

        tool_kwargs: dict[str, Any] = dict(
            name=mcp_tool.name,
            description=mcp_tool.description or mcp_tool.name,
            coroutine=_call,
        )
        if args_model:
            tool_kwargs["args_schema"] = args_model
        tools.append(StructuredTool(**tool_kwargs))
    return tools


async def _anthropic_tools_from_session(session: Any) -> list[Any]:
    class _MCPTool:
        """Adapter: MCP tool → ``BetaAsyncBuiltinFunctionTool`` interface."""

        def __init__(self, name: str, description: str, schema: dict, sess: Any) -> None:
            self._name = name
            self._description = description
            self._schema = schema
            self._session = sess

        @property
        def name(self) -> str:
            return self._name

        def to_dict(self) -> dict:
            return {
                "name": self._name,
                "description": self._description,
                "input_schema": self._schema,
            }

        async def call(self, *, input: Any) -> str:
            params = dict(input) if input else {}
            return mcp_result_to_str(await self._session.call_tool(self._name, params))

    tools: list[Any] = []
    for mcp_tool in (await session.list_tools()).tools:
        schema = mcp_tool.inputSchema or {"type": "object", "properties": {}}
        tools.append(
            _MCPTool(
                name=mcp_tool.name,
                description=mcp_tool.description or mcp_tool.name,
                schema=schema,
                sess=session,
            )
        )
    return tools
