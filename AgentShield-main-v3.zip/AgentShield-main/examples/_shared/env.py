"""Env-var hygiene helpers.

`os.getenv(name, default)` returns the literal env-var value when the
var is set, even if it's empty or whitespace-only. That makes
copy-pasted `.env` shapes like ``OPENAI_API_KEY=""`` slip past
truthiness guards and reach downstream constructors as nonsense
values. This module centralises the treatment.
"""
from __future__ import annotations

import os

__all__ = ["getenv", "mask"]


def getenv(name: str, default: str | None = None) -> str | None:
    """Return a stripped env var value or ``default`` when unset / empty."""
    raw = os.getenv(name)
    if raw is None:
        return default
    stripped = raw.strip()
    return stripped if stripped else default


def mask(value: str | None) -> str:
    """Render a credential safely for logging."""
    if not value:
        return "(not set)"
    return value[:4] + "****" + value[-4:] if len(value) > 8 else "****"
