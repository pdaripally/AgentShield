"""Scripted scenarios for guarded ↔ unguarded side-by-side runs.

Each agent demo declares a `ScenarioCatalog` of named `Scenario`s with:

* ``input`` — the user prompt to send to both the guarded and
  unguarded agent.
* ``intent`` — short human-readable label for the catalog listing.
* ``stages`` — which Agent Shield stages this scenario is intended to
  exercise (informational only; surfaced in the side-by-side output).
* ``expect_block`` — whether the guarded agent SHOULD refuse this
  prompt (bool). When True, the runner highlights an unguarded "ran
  freely" vs guarded "blocked" comparison.

The runner drives both agents, prints the side-by-side, and reports a
summary. It does NOT assert; the verdicts are surfaced for human
inspection so the demo functions as a demonstration, not a test.

The TEST suite already pins the runtime's verdict semantics; this is
about *seeing* what the policy catches in a real LLM context.
"""
from __future__ import annotations

import textwrap
from dataclasses import dataclass, field
from typing import Awaitable, Callable

__all__ = ["Scenario", "ScenarioCatalog", "run_scenarios"]


@dataclass
class Scenario:
    """One scripted user prompt + expectation."""
    name: str
    input: str
    intent: str
    stages: tuple[str, ...] = field(default_factory=tuple)
    expect_block: bool = False


@dataclass
class ScenarioCatalog:
    """Named collection of `Scenario`s + lookup helper."""
    scenarios: list[Scenario]

    def by_name(self, name: str) -> Scenario:
        for s in self.scenarios:
            if s.name == name:
                return s
        names = ", ".join(s.name for s in self.scenarios)
        raise KeyError(f"unknown scenario {name!r}; available: {names}")

    def names(self) -> list[str]:
        return [s.name for s in self.scenarios]

    def select(self, requested: list[str] | None) -> list[Scenario]:
        """Resolve ``--scenarios <name|all>`` to a list of `Scenario`s."""
        if requested is None or requested == [] or requested == ["all"]:
            return list(self.scenarios)
        return [self.by_name(n) for n in requested]


# ---------------------------------------------------------------------------
# Side-by-side runner
# ---------------------------------------------------------------------------


_BAR = "─" * 78


def _wrap(text: str, width: int = 76) -> str:
    return textwrap.fill(text, width=width, replace_whitespace=False)


async def run_scenarios(
    *,
    scenarios: list[Scenario],
    unguarded_invoke: Callable[[str], Awaitable[str]],
    guarded_invoke: Callable[[str], Awaitable[str]],
    before_invoke: Callable[[str], Awaitable[str | None]] | None = None,
) -> None:
    """Run each scenario through both agents and print the side-by-side."""
    print()
    print(_BAR)
    print(f"  {len(scenarios)} scenario(s) — guarded ↔ unguarded side-by-side")
    print(_BAR)

    for i, s in enumerate(scenarios, 1):
        stages = ("[" + " · ".join(s.stages) + "]") if s.stages else ""
        print()
        print(_BAR)
        print(f"  ({i}/{len(scenarios)})  {s.name}  {stages}")
        print(f"  intent: {s.intent}")
        print(_BAR)
        print()
        print("  USER →")
        print(textwrap.indent(_wrap(s.input), "    "))
        print()

        # Unguarded.
        try:
            unguarded_out = await unguarded_invoke(s.input)
        except Exception as e:
            unguarded_out = f"[ERROR] {type(e).__name__}: {e}"
        print("  UNGUARDED ←")
        print(textwrap.indent(_wrap(unguarded_out), "    "))
        print()

        # Guarded — give the Stage-1 input check a chance to fire first.
        guarded_out: str
        if before_invoke is not None:
            block_msg = await before_invoke(s.input)
            if block_msg is not None:
                guarded_out = f"[STAGE 1 BLOCK] {block_msg}"
            else:
                try:
                    guarded_out = await guarded_invoke(s.input)
                except Exception as e:
                    guarded_out = f"[ERROR] {type(e).__name__}: {e}"
        else:
            try:
                guarded_out = await guarded_invoke(s.input)
            except Exception as e:
                guarded_out = f"[ERROR] {type(e).__name__}: {e}"

        # Tag the guarded outcome with what we expected.
        was_blocked = (
            guarded_out.startswith(("[STAGE", "[BLOCK", "[ERROR", "[GUARDRAIL"))
            or "BLOCK" in guarded_out[:64].upper()
        )
        if s.expect_block and was_blocked:
            tag = "✓ guarded blocked as expected"
        elif s.expect_block and not was_blocked:
            tag = "✗ guarded did NOT block (expected to)"
        elif not s.expect_block and was_blocked:
            tag = "? guarded blocked (not expected — review)"
        else:
            tag = "✓ guarded passed (as expected)"

        print(f"  GUARDED ←   {tag}")
        print(textwrap.indent(_wrap(guarded_out), "    "))
        print()

    print(_BAR)
    print("  done.")
    print(_BAR)
