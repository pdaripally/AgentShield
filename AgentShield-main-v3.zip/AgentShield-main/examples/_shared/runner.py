"""Shared CLI flags + post-parse setup for the agent demos.

The flags here are the cross-demo surface (``--framework``,
``--scenarios``, ``--request``, ``--debug``). Per-demo flags
(e.g. ``--banking-command``) are added on top inside each demo's
``demo.py``.
"""
from __future__ import annotations

import argparse

from .env import getenv
from .frameworks import SUPPORTED_FRAMEWORKS

__all__ = ["parse_args", "setup_args"]


def parse_args(
    *,
    description: str,
    extra_args: list[tuple[str, dict]] | None = None,
) -> argparse.Namespace:
    """Parse the shared demo CLI surface plus any per-demo extras."""
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument(
        "--framework",
        choices=SUPPORTED_FRAMEWORKS,
        default=getenv("AGENT_SHIELD_DEMO_FRAMEWORK", "langchain"),
        help=(
            "Which agent framework to drive. Default: langchain "
            "(or $AGENT_SHIELD_DEMO_FRAMEWORK)."
        ),
    )
    parser.add_argument(
        "--scenarios",
        nargs="*",
        metavar="NAME",
        help=(
            "Run scripted scenarios end-to-end and print the guarded ↔ "
            "unguarded side-by-side. Use `--scenarios all` for the full "
            "catalog or `--scenarios <name1> <name2>` for a subset. "
            "Omit to enter the interactive REPL instead."
        ),
    )
    parser.add_argument(
        "--request",
        default=None,
        help=(
            "Single request to run then exit. Mutually exclusive with "
            "--scenarios; omit both to enter the interactive REPL."
        ),
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Print each LLM request and response.",
    )
    parser.add_argument(
        "--no-shield",
        action="store_true",
        help=(
            "Drive the unguarded agent in REPL / --request mode. Only "
            "affects interactive modes — --scenarios always runs the "
            "unguarded ↔ guarded side-by-side. Used by the split-screen "
            "TUI in examples/demoTerminal/ to run the left pane."
        ),
    )
    if extra_args is not None:
        for name, kwargs in extra_args:
            parser.add_argument(name, **kwargs)
    return parser.parse_args()


def setup_args(args: argparse.Namespace) -> None:
    """Surface the chosen config back to the operator at startup."""
    print(f"[Config] framework: {args.framework}")
    if args.scenarios is not None:
        sel = "all" if args.scenarios == [] or "all" in args.scenarios else " · ".join(args.scenarios)
        print(f"[Config] scenarios: {sel}")
    elif args.request is not None:
        print(f"[Config] request: {args.request[:80]}{'…' if len(args.request) > 80 else ''}")
    else:
        print(f"[Config] mode: interactive REPL")
    if args.no_shield and args.scenarios is None:
        print("[Config] shield: OFF (unguarded)")
