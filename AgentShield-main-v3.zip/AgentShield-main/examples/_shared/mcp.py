"""MCP stdio connection + tool-result coercion.

`MCPConnection` is an async context manager wrapping the
mcp Python SDK's stdio client. `mcp_result_to_str` flattens the wire
shape of an MCP `CallToolResult` to the single string body the agent
tool channel expects.

`mcp_banking_server_command()` returns the absolute command to launch
the bundled banking MCP server (used by the bank-manager demo).
Resolving via `__file__` and `sys.executable` makes the command
cwd-independent — `python demo.py` works regardless of which directory
the user launched from.
"""
from __future__ import annotations

import json
import shlex
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from mcp.client.session import ClientSession
from mcp.client.stdio import StdioServerParameters, stdio_client

from .env import getenv

__all__ = [
    "MCPConnection",
    "mcp_banking_server_command",
    "mcp_result_to_str",
]


_REPO_ROOT = Path(__file__).resolve().parent.parent.parent
_BANKING_MCP_SCRIPT = (
    _REPO_ROOT / "examples" / "agents" / "bank-manager" / "mcp_server.py"
)


def mcp_banking_server_command() -> str:
    """Absolute command to launch the bundled banking MCP server.

    Honors a ``BANKING_MCP_COMMAND`` env override (with env-hygiene
    treatment).
    """
    override = getenv("BANKING_MCP_COMMAND")
    if override:
        return override
    return f"{shlex.quote(sys.executable)} {shlex.quote(str(_BANKING_MCP_SCRIPT))}"


@dataclass
class MCPConnection:
    """Async context manager for an MCP stdio server connection."""

    name: str
    command: str
    session: ClientSession | None = None
    _client_cm: Any | None = None
    _session_cm: Any | None = None

    async def __aenter__(self) -> "MCPConnection":
        cmd_parts = shlex.split(self.command)
        if not cmd_parts:
            raise ValueError(f"Empty command for MCP server: {self.name}")
        params = StdioServerParameters(command=cmd_parts[0], args=cmd_parts[1:])
        self._client_cm = stdio_client(params)
        read, write = await self._client_cm.__aenter__()
        self._session_cm = ClientSession(read, write)
        self.session = await self._session_cm.__aenter__()
        await self.session.initialize()
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        if self._session_cm is not None:
            try:
                await self._session_cm.__aexit__(exc_type, exc, tb)
            except Exception:
                pass
        if self._client_cm is not None:
            try:
                await self._client_cm.__aexit__(exc_type, exc, tb)
            except Exception:
                pass


def mcp_result_to_str(result: Any) -> str:
    """Coerce an MCP `CallToolResult`-like object to a string."""
    if hasattr(result, "content"):
        content = result.content
        if isinstance(content, list):
            return "\n".join(
                item.text if hasattr(item, "text") else str(item) for item in content
            )
        if isinstance(content, dict):
            return json.dumps(content)
        return str(content)
    return json.dumps(result, default=str)
