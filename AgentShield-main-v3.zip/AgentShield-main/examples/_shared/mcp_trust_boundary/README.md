# MCP trust-boundary fixtures

This directory contains illustrative `.guardrails.yaml` fragments that
exercise each resolver-trust-boundary failure mode the runtime
enforces. Each fixture is independently loadable — `agent-shield init`
can load them, the cross-language conformance harness consumes them
as input, and the integration tests in
`sdk/rust/agent_shield_core/tests/resolver_trust_boundary.rs` mirror
the same scenarios in Rust unit form.

The fixtures are **not** runnable agents — they're minimal policy
files that demonstrate the YAML wire shape and the load-time / runtime
enforcement contract.

## Fixtures

| File | What it exercises |
|------|-------------------|
| `https_required.guardrails.yaml` | `http://` non-localhost endpoint → load-time error |
| `localhost_opt_in.guardrails.yaml` | `http://localhost` with `transport.allow_unencrypted_local: true` → accepted |
| `localhost_no_opt_in.guardrails.yaml` | `http://localhost` without opt-in → load-time error |
| `trust_anchors_malformed.guardrails.yaml` | Malformed PEM in `transport.trust_anchors` → load-time error |
| `timeout_over_cap.guardrails.yaml` | `timeout: 600000` (10min) → load-time error (cap 300_000 ms) |
| `retry_over_cap.guardrails.yaml` | `retry.max_attempts: 99` → load-time error (cap 5) |
| `response_schema.guardrails.yaml` | Resolver with `response_schema:` — runtime enforces schema |
| `response_signature.guardrails.yaml` | Resolver with `response_signature:` — runtime enforces JWS |
| `signed_response_required_but_missing.guardrails.yaml` | Resolver declares `response_signature:`; host responds without a JWS token → `resolver_signature_invalid` |
| `schema_violation_no_overridable.guardrails.yaml` | Resolver declares both `response_schema:` and `on_error: allow`; schema violation must still fail closed |

## Coverage matrix

| Failure mode | Load-time | Runtime |
|--------------|-----------|---------|
| HTTPS required | ✓ | — |
| Localhost opt-in | ✓ | — |
| Self-signed cert (PEM malformed) | ✓ | (TLS handshake at runtime) |
| Timeout over 300s cap | ✓ | — |
| Retry attempts over cap | ✓ | — |
| Response schema violation | ✓ (compile schema) | ✓ (validate envelope) |
| Response signature missing | — | ✓ (deny with `resolver_signature_invalid`) |
| Response signature invalid | — | ✓ (deny with `resolver_signature_invalid`) |

The "—" entries mean the failure cannot be observed at that stage:
self-signed certs only fail at the actual TLS handshake, and
response-content failures cannot be detected without an actual
response.
