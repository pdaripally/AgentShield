"""End-to-end `kind: human` approval flow.

When a `.guardrails.yaml` guards a tool with a variable resolved by a
`kind: human` resolver, the runtime suspends the call and surfaces a
structured ``pending_resolution`` shape on the block verdict. The host
is responsible for showing the prompt to a human (UI, chat, CLI, etc.),
collecting the answer, and writing it back into the variable so the
next gate evaluation sees the resolved value.

This script demonstrates the canonical ask → approve → resume loop
without any framework adapter — just the core `Session` API. It is the
minimal reproducer for what `examples/tools/ask-human-mcp-server/`
automates over MCP and what every framework adapter (LangChain,
OpenAI Agents, Anthropic, MCP) routes internally.

Key contract:

- Block verdict's ``pending_resolution`` carries
  ``{tool, variable, prompt, request_id, kind}``.
- The ``tool`` is always ``agent_shield.ask_human`` for ``kind: human``.
- The host resolves by calling ``session.set_variable(<variable>, <value>)``
  with the human's answer. The variable's lifetime (per the spec
  default for ``kind: human``, ``per_session`` — see the spec) keeps the
  approval live for subsequent gate evaluations.
- Re-validating the same tool call after the variable is set produces
  an ``allowed=True`` verdict.

Run with::

    python examples/human_approval_quickstart.py

No LLM, no MCP server, no framework dependency required.
"""

from __future__ import annotations

import os
import tempfile
from typing import Any, Dict

from agent_shield import RuntimeBuilder


GUARDRAILS_YAML = """
metadata:
  name: "human-approval-quickstart"
  version: "0.1.0"
  agent_shield_version: "2.0"

objective:
  goal:
    - "Send email only after explicit human approval."
  forbidden:
    - "Send email without confirmation."

resources:
  tools:
    - name: "send_email"
      description: "Send an email to an external recipient."
      permission: "execute"

variables:
  # Approval flag is unset by default. A read while @status == 'unset'
  # at a gating site fires the resolver and suspends the call with a
  # structured pending_resolution surface.
  - name: "send_email_authorized"
    type: "boolean"
    on_demand_by:
      kind: "human"
      prompt: "Approve sending email to ${@tool.params.to}?"
    # `kind: human` defaults to per_session; spelling
    # it out here for the reader.
    lifetime: "per_session"

state_validation:
  guard_policies:
    - name: "send_email_requires_approval"
      applies_to:
        tools: ["send_email"]
      # Bare `var == true` triggers auto-resolution on the unset
      # variable. Wrapping in `defined(var)` would NOT
      # auto-resolve and would silently let the call through.
      evaluate_when:
        - expression: "send_email_authorized == true"
          reason: "Sending email requires explicit user confirmation"
      action: "block"
"""


def simulated_ui_ask(pending: Dict[str, Any]) -> bool:
    """Stand-in for whatever UI surface your host uses.

    In a real deployment this is a chat prompt, a Slack DM, a web
    modal, a CLI question, an email round-trip — anything that
    eventually returns the human's yes/no decision.

    The structured ``pending`` shape (spec /) carries
    everything the UI needs: the variable being resolved, the
    interpolated prompt, the request_id for audit correlation, and
    the canonical tool name (``agent_shield.ask_human``) for hosts
    that route through MCP.
    """
    print("──────────────────────────────────────────────────────")
    print(f"  pending_resolution.tool       = {pending['tool']}")
    print(f"  pending_resolution.variable   = {pending['variable']}")
    print(f"  pending_resolution.prompt     = {pending['prompt']}")
    print(f"  pending_resolution.request_id = {pending['request_id']}")
    print(f"  pending_resolution.kind       = {pending['kind']}")
    print("──────────────────────────────────────────────────────")
    # Simulated approval — in a real UI this is `input(...)`,
    # `chat.send(...)`, etc.
    return True


def main() -> None:
    with tempfile.NamedTemporaryFile(
        "w", suffix=".guardrails.yaml", delete=False
    ) as f:
        f.write(GUARDRAILS_YAML)
        yaml_path = f.name

    try:
        runtime = RuntimeBuilder.from_yaml(yaml_path).build()
        with runtime.new_session(
            session_id="quickstart", correlation_id="corr-1"
        ) as session:
            session.begin_turn()

            params = {"to": "alice@example.com", "subject": "Hi", "body": "Hello!"}

            # ── 1. Initial attempt — Stage 2 blocks. ────────────────
            initial = session.validate_tool_call(
                "send_email", params, tool_call_id="call-1"
            )
            assert initial.verdict.allowed is False, (
                "First call must block — `send_email_authorized` is unset."
            )
            pending = initial.verdict.pending_resolution
            assert pending is not None, (
                "kind: human block MUST surface pending_resolution; "
                "if you see None here, the verdict was dropped before "
                "reaching your code — file an issue against the SDK."
            )

            print("[1] First call BLOCKED. Verdict:")
            print(f"      allowed = {initial.verdict.allowed}")
            print(f"      reason  = {initial.verdict.reason}")
            print("      pending_resolution (full shape):\n")

            # ── 2. Surface to the human, get an answer. ─────────────
            approved = simulated_ui_ask(pending)

            # ── 3. Write the answer back. ───────────────────────────
            # `set_variable` is the canonical resume API on the
            # Session. The host MAY also let the agent call
            # `agent_shield.ask_human` as an MCP tool — that path
            # uses the same end-state (a populator write to the
            # variable). See spec and
            # examples/tools/ask-human-mcp-server/ for the MCP route.
            session.set_variable(pending["variable"], approved)
            print(f"[2] Human {'APPROVED' if approved else 'DENIED'} — "
                  f"`{pending['variable']}` is now {approved!r}.")

            # ── 4. Re-validate. The gate now passes. ────────────────
            resumed = session.validate_tool_call(
                "send_email", params, tool_call_id="call-2"
            )
            print("[3] Re-validating send_email:")
            print(f"      allowed = {resumed.verdict.allowed}")
            print(f"      reason  = {resumed.verdict.reason}")
            assert resumed.verdict.allowed is True, (
                "After human approval was written into the variable, "
                "the gate MUST pass."
            )

            print("\n✓ End-to-end ask → approve → resume loop succeeded.")
    finally:
        os.unlink(yaml_path)


if __name__ == "__main__":
    main()
