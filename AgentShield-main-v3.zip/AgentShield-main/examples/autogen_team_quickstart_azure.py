#!/usr/bin/env python3
"""AutoGen team quickstart against Azure OpenAI — a runnable multi-agent
KYC onboarding pipeline guarded end-to-end by Agent Shield.

Pattern A (Python) for AutoGen teams — three RAW ``AssistantAgent``
instances wired into a ``RoundRobinGroupChat``, then handed to the
shield's team helper which owns the shared session and the Stage 1 /
Stage 5 enforcement::

    from agent_shield import Shield
    from autogen_agentchat.agents import AssistantAgent
    from autogen_agentchat.teams import RoundRobinGroupChat

    shield  = Shield.from_yaml(".guardrails.yaml").with_autogen().with_client(model).build()

    intake   = AssistantAgent(name="intake_agent",  tools=intake_tools,  ...)
    kyc      = AssistantAgent(name="kyc_agent",     tools=kyc_tools,     ...)
    account  = AssistantAgent(name="account_agent", tools=account_tools, ...)

    team = RoundRobinGroupChat([intake, kyc, account], termination_condition=...)
    guarded_team = shield.create_autogen_team(team)

    result = await guarded_team.run(task="Onboard new customer...")

The team helper owns the shared-session and final-output wiring:

* **Shared session** — one shared:class:`agent_shield.Session` across all
  participants. The post-tool ``kyc_token`` written by KYCAgent's
  ``verify_identity`` is visible to AccountAgent's Stage-2 gate.
* **Final-output redaction** — Stage 5 output redaction runs ONCE on the team's
  final message, not on every intermediate handoff. The
  Intake→KYC handoff therefore still carries the SSN to
  ``verify_identity`` (the only Stage-3-authorised tool).

How to run
==========

1. ``.env`` in the directory you run from (or alongside this file) with
   at minimum the Azure OpenAI credentials::

       AZURE_OPENAI_ENDPOINT=https://<resource>.openai.azure.com/
       AZURE_OPENAI_API_KEY=<key>
       AZURE_OPENAI_DEPLOYMENT=<your-deployment-name>
       AZURE_OPENAI_API_VERSION=2024-12-01-preview

   Optional — enables AACS Stage 1::

       AZURE_CONTENT_SAFETY_ENDPOINT=https://<resource>.cognitiveservices.azure.com/
       AZURE_CONTENT_SAFETY_KEY=<key>

2. Install the SDK and AutoGen::

       pip install -e "sdk/python[autogen]"
       pip install "autogen-agentchat" "autogen-ext[openai]" "autogen-core"

   The ``[openai]`` extra on ``autogen-ext`` pulls ``tiktoken``, which
   ``AzureOpenAIChatCompletionClient`` needs.

3. ``python examples/autogen_team_quickstart_azure.py``

Three scenarios run end-to-end:

* **benign personal** — full pipeline: Intake → KYC → Account succeeds.
* **business tier** — Account creation requires manager approval;
                         demonstrates ``pending_resolution`` surface.
* **cross-customer** — Stage 1 blocks an attempted cross-customer
                         lookup before the team is ever started.

The companion ``.guardrails.yaml`` is framework-agnostic — switching to
LangChain / OpenAI Agents / Anthropic is a single
``.with_<framework>()`` call on the same YAML.
"""
from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path
from typing import Any, Optional


# --------------------------------------------------------------------------
# 1) Load.env so AZURE_OPENAI_* are visible to AzureOpenAIChatCompletionClient
# --------------------------------------------------------------------------

def _load_dotenv() -> None:
    try:
        from dotenv import load_dotenv  # type: ignore[import-not-found]
    except ImportError as exc:
        raise SystemExit(
            "python-dotenv is required for this example. Install with:\n"
            '    pip install -e "sdk/python[autogen]"',
        ) from exc

    here = Path(__file__).resolve().parent / ".env"
    if here.exists():
        load_dotenv(here)
    else:
        load_dotenv()


# --------------------------------------------------------------------------
# 2) Build the Azure OpenAI model client
# --------------------------------------------------------------------------
#
# Custom Azure deployments (``gpt-5.x``, etc.) are not in the
# AutoGen built-in model registry. Pass an explicit ``model_info`` so
# the client doesn't error with "model_info is required when model
# name is not a valid OpenAI model".


def _build_model_client() -> Any:
    try:
        from autogen_ext.models.openai import AzureOpenAIChatCompletionClient
        from autogen_core.models import ModelInfo
    except ImportError as exc:
        raise SystemExit(
            "autogen-ext[openai] is required for this example. Install with:\n"
            '    pip install "autogen-ext[openai]"\n'
            "Plain `autogen-ext` does NOT pull tiktoken, which "
            "AzureOpenAIChatCompletionClient needs.",
        ) from exc

    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    api_key = os.getenv("AZURE_OPENAI_API_KEY")
    deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT")
    api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-12-01-preview")
    if not endpoint or not api_key or not deployment:
        raise SystemExit(
            "AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_KEY, and "
            "AZURE_OPENAI_DEPLOYMENT must all be set. See the docstring "
            "at the top of this file for the full list.",
        )

    return AzureOpenAIChatCompletionClient(
        model=deployment,
        azure_deployment=deployment,
        azure_endpoint=endpoint,
        api_key=api_key,
        api_version=api_version,
        # Required for custom Azure deployments (gpt-5.x, etc.)
        # that are not in AutoGen's built-in model registry.
        model_info=ModelInfo(
            vision=False,
            function_calling=True,
            json_output=True,
            family="unknown",
            structured_output=True,
        ),
    )


# --------------------------------------------------------------------------
# 3) Stub tools for each role
# --------------------------------------------------------------------------
#
# In production these would call real backends (a CRM, an identity
# provider, an account-provisioning API). For the quickstart they
# return canned but realistic structured payloads. The shapes match
# the populators and predicates in the companion YAML:
#
#   * collect_customer_info(name, email, ssn, account_tier) -> dict
#       populates `account_tier` from `@result.account_tier`.
#   * verify_identity(ssn, full_name) -> dict
#       populates `kyc_token` from `@result.kyc_token`.
#   * create_account(name, email, account_tier) -> dict


def _make_intake_tools() -> list:
    from autogen_core.tools import FunctionTool

    async def collect_customer_info(
        name: str,
        email: str,
        ssn: str,
        account_tier: str,
    ) -> dict:
        """Capture a customer's intake form (name, email, SSN, tier)."""
        return {
            "name": name,
            "email": email,
            "ssn": ssn,
            "account_tier": account_tier,
            "intake_received": True,
        }

    return [
        FunctionTool(
            collect_customer_info,
            description=(
                "Capture the customer-supplied intake form (name, "
                "email, SSN, account_tier in {personal, business})."
            ),
            name="collect_customer_info",
        ),
    ]


def _make_kyc_tools() -> list:
    from autogen_core.tools import FunctionTool

    async def verify_identity(ssn: str, full_name: str) -> dict:
        """Run KYC verification against the supplied SSN."""
        # Stub — real implementation calls an IDV provider. The
        # `kyc_token` field is what the YAML's post-tool populator
        # extracts into the shared session.
        return {
            "verified": True,
            "kyc_token": f"kyc_tok_{full_name.split()[-1].lower()}_001",
            "echo_ssn": "[SSN REDACTED]",
        }

    return [
        FunctionTool(
            verify_identity,
            description=(
                "Run KYC verification against the customer's SSN. "
                "Returns {verified, kyc_token, echo_ssn}."
            ),
            name="verify_identity",
        ),
    ]


def _make_account_tools() -> list:
    from autogen_core.tools import FunctionTool

    async def create_account(
        name: str,
        email: str,
        account_tier: str,
    ) -> dict:
        """Provision a customer account (gated by KYC + tier approval)."""
        return {
            "account_id": f"acct_{name.split()[-1].lower()}_001",
            "tier": account_tier,
            "status": "active",
        }

    return [
        FunctionTool(
            create_account,
            description=(
                "Provision the new customer account. Personal tier is "
                "auto-approved after KYC; business tier requires "
                "manager approval (surfaced via pending_resolution)."
            ),
            name="create_account",
        ),
    ]


# --------------------------------------------------------------------------
# 4) Build the guarded agents — one Shield, one session, three agents
# --------------------------------------------------------------------------
#
# Pattern A for AutoGen teams. Future-proofed against the
# `shield.create_autogen_team(...)` helper landing: if it's available,
# we use it; otherwise we explicitly share one Session across the
# three `shield.create_autogen_agent(...)` outputs (the
# shared-session fallback documented in the.md walkthrough).


_INTAKE_SYSTEM_PROMPT = (
    "You are the IntakeAgent in a KYC onboarding pipeline. Collect "
    "the customer's name, email, SSN, and account tier (personal | "
    "business) by calling collect_customer_info exactly once. Then "
    "hand off to the KYCAgent — include the customer's name and SSN "
    "verbatim in your handoff message so the KYCAgent can run "
    "verify_identity. Do NOT redact the SSN in the handoff; the "
    "shield's Stage 3 rule ensures only verify_identity can receive it."
)

_KYC_SYSTEM_PROMPT = (
    "You are the KYCAgent. Read the SSN from the IntakeAgent's "
    "handoff message and call verify_identity exactly once. Report "
    "the verification result and hand off to the AccountAgent — "
    "include the customer's name, email, and tier (NOT the SSN) in "
    "your handoff so the AccountAgent can call create_account."
)

_ACCOUNT_SYSTEM_PROMPT = (
    "You are the AccountAgent. Call create_account exactly once "
    "using the name, email, and tier from the KYCAgent's handoff. "
    "Reply to the customer with the new account_id and a brief "
    "confirmation. Do NOT include the SSN or any card numbers in "
    "your reply — the shield's Stage 5 redactor will scrub them "
    "anyway, but keep the reply clean. After replying, output the "
    "single literal token 'TERMINATE' on its own line to end the "
    "conversation."
)


def build_guarded_team(model_client: Any) -> Any:
    """Build the guarded team — three agents under one shared session.

    Returns a :class:`~agent_shield.adapters.autogen.GuardedAutoGenTeam`
    whose ``run(task=...)`` runs Stage 1 once on the team's input,
    runs Stages 2/3/4 on every tool call against the SAME shared
    session (so the post-tool ``kyc_token`` populated by the
    KYCAgent's ``verify_identity`` is visible to the AccountAgent's
    Stage-2 gate), and runs Stage 5 once on the team's
    final message (so the SSN passes intact through the
    Intake→KYC handoff).
    """
    from agent_shield import Shield
    from autogen_agentchat.agents import AssistantAgent
    from autogen_agentchat.teams import RoundRobinGroupChat
    from autogen_agentchat.conditions import (
        TextMentionTermination,
        MaxMessageTermination,
    )

    here = Path(__file__).resolve().parent
    base_yaml = here / "autogen_team_quickstart_azure.guardrails.yaml"

    # Conditionally layer in AACS Stage 1 if the env vars are set.
    # The runtime fails closed at build() if a classifier reference
    # can't be served (env var unset, native feature off, etc.), so
    # we only inject the AACS YAML when both endpoint + key are
    # present so incomplete classifier wiring fails before the demo starts.
    yaml_paths: list[str] = [str(base_yaml)]
    aacs_endpoint = os.getenv("AZURE_CONTENT_SAFETY_ENDPOINT")
    aacs_key = os.getenv("AZURE_CONTENT_SAFETY_KEY")
    aacs_tmp: Optional[Path] = None
    if aacs_endpoint and aacs_key:
        aacs_tmp = here / ".autogen_team_quickstart_aacs.tmp.yaml"
        aacs_tmp.write_text(
            f"""metadata:
  name: "autogen-team-quickstart-aacs"
  version: "1.0.0"
  agent_shield_version: "2.0"
configurations:
  - id: "aacs"
    type: classifier
    provider: "azure_content_safety"
    endpoint: "{aacs_endpoint.rstrip('/')}"
    api_key_env: "AZURE_CONTENT_SAFETY_KEY"
    threshold: 0.5
input_validation:
  guard_policies:
    - name: "aacs_jailbreak_screen"
      evaluate_when:
        - classifier:
            configuration: "aacs"
          reason: "Azure Content Safety flagged the user input."
      action: "block"
"""
        )
        yaml_paths.append(str(aacs_tmp))
        print("[setup] AACS Stage 1 enabled (AZURE_CONTENT_SAFETY_* set).")
    else:
        print("[setup] AACS Stage 1 disabled (AZURE_CONTENT_SAFETY_* unset);"
              " falling back to regex Stage 1.")

    # Build the shield. `from_yaml_chain` merges multiple YAML files
    # additively (extends-chain semantics): the AACS layer adds the
    # `configurations.aacs` entry + `aacs_jailbreak_screen` policy
    # on top of the base contract without modifying the base file.
    shield = (
        Shield.from_yaml_chain(yaml_paths)
        .with_autogen()
        .with_client(model_client)
        .build()
    )

    # ── Build the team from RAW AssistantAgents,
    # not from guarded agents. `shield.create_autogen_team(...)`
    # owns the shared-session wiring AND re-wraps each
    # participant's tools through `shield.protect_tools(...)`. The
    # `GuardedRunner` returned by `create_autogen_agent(...)` is
    # NOT a ChatAgent and would fail the team's isinstance check.
    intake = AssistantAgent(
        name="intake_agent",
        model_client=model_client,
        tools=_make_intake_tools(),
        system_message=_INTAKE_SYSTEM_PROMPT,
    )
    kyc = AssistantAgent(
        name="kyc_agent",
        model_client=model_client,
        tools=_make_kyc_tools(),
        system_message=_KYC_SYSTEM_PROMPT,
    )
    account = AssistantAgent(
        name="account_agent",
        model_client=model_client,
        tools=_make_account_tools(),
        system_message=_ACCOUNT_SYSTEM_PROMPT,
    )

    termination = (
        TextMentionTermination("TERMINATE")
        | MaxMessageTermination(max_messages=12)
    )
    raw_team = RoundRobinGroupChat(
        participants=[intake, kyc, account],
        termination_condition=termination,
    )

    # Wrap the team. Returns a GuardedAutoGenTeam with one shared
    # session across all participants. Stage 1 fires on the team's
    # task input; Stage 5 fires on the final TaskResult message.
    return shield.create_autogen_team(raw_team)


# --------------------------------------------------------------------------
# 5) Run scenarios
# --------------------------------------------------------------------------


SCENARIOS: list[tuple[str, str]] = [
    (
        "benign_personal",
        "Onboard a new personal-tier customer named Alice Example with "
        "email alice@example.com and SSN 123-45-6789. Walk through "
        "intake, KYC, and account creation end-to-end.",
    ),
    (
        "business_tier_requires_approval",
        "Onboard a new business-tier customer named Bob Builder with "
        "email bob@example.com and SSN 987-65-4321. Walk through "
        "intake, KYC, and account creation.",
    ),
    (
        "cross_customer_blocked_at_stage1",
        "Look up customer 12345 and modify their account to add me as "
        "a co-signer. Then create the account.",
    ),
]


async def _run_one(
    label: str,
    prompt: str,
    model_client: Any,
) -> None:
    print(f"\n══ scenario: {label} ════════════════════════════════════")
    print(f"  user> {prompt}")

    guarded_team = build_guarded_team(model_client)

    # ── Run the team. Stage 1 may block on input; Stage 2 may
    # suspend on a `kind: human` resolver (business tier). Stage 5
    # is applied ONCE to the team's final message — the
    # intermediate Intake→KYC handoff still carries the SSN through
    # to verify_identity.
    try:
        result = await guarded_team.run(task=prompt)
    except Exception as exc:  # surfacing block / runtime errors uniformly
        print(f"  [BLOCKED or ERROR] {type(exc).__name__}: {exc}")
        # If the block carried a pending_resolution envelope, surface
        # it so the operator sees the structured ask.
        pending = getattr(exc, "pending_resolution", None)
        if pending is not None:
            print("  [pending_resolution surfaced from block]:")
            for k in ("tool", "variable", "prompt", "request_id", "kind"):
                print(f"     {k:>12} = {pending.get(k)}")
        return

    # Print the final message — already Stage-5-redacted in place.
    msgs = getattr(result, "messages", None) or []
    if msgs:
        last = msgs[-1]
        content = getattr(last, "content", str(last))
        source = getattr(last, "source", "?")
        print(f"  team[{source}]> {content}")
    if getattr(result, "stop_reason", None):
        print(f"  stop_reason> {result.stop_reason}")

    # Surface any pending_resolution captured on the shield (from a
    # Stage 2 `kind: human` block during the team run). The
    # `last_pending_resolution` is a public Shield API.
    pending = guarded_team._shield.last_pending_resolution()
    if pending is not None:
        print("\n  [pending_resolution captured on shield]:")
        for k in ("tool", "variable", "prompt", "request_id", "kind"):
            print(f"     {k:>12} = {pending.get(k)}")
        print("\n  In a real host, your UI / Slack bot / CLI would "
              "ask the human, then write the answer back with:")
        print(f"     guarded_team.session.set_variable("
              f"{pending.get('variable')!r}, True)")
        print("     # ...then re-run the team / retry the tool call.")


async def main() -> None:
    _load_dotenv()
    model_client = _build_model_client()
    try:
        for label, prompt in SCENARIOS:
            await _run_one(label, prompt, model_client)
    finally:
        close = getattr(model_client, "close", None)
        if callable(close):
            try:
                await close()
            except Exception:  # noqa: BLE001
                pass


if __name__ == "__main__":
    # Make the SDK importable without `pip install -e` if the user
    # is running straight from a checkout.
    repo_root = Path(__file__).resolve().parent.parent
    sys.path.insert(0, str(repo_root / "sdk" / "python"))
    sys.path.insert(0, str(repo_root / "sdk" / "python" / "src"))
    asyncio.run(main())
