# Tool reference implementations

## DEMO ONLY

These tool references illustrate integration patterns and require additional hardening before production use.


Reference implementations of tool / MCP-server surfaces that Agent
Shield depends on or interoperates with.

| Entry | What it is |
|---|---|
| [`ask-human-mcp-server/`](ask-human-mcp-server/) | Reference MCP server implementing the canonical `agent_shield.ask_human` tool. The Agent Shield runtime emits a `pending_resolution` whenever a guard policy denies because of an unset variable resolved by a `kind: human` resolver; the agent calls `agent_shield.ask_human` with the variable name + prompt, and this server's response routes back into the runtime as the resolver's value. |
