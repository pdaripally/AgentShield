"""Reference `agent_shield.ask_human` MCP server.

Exposes a single tool — ``agent_shield.ask_human`` — that prompts a
human operator on stdin and returns a canonical Agent Shield resolver
response envelope.

This is the host-side counterpart to the runtime's
``pending_resolution`` deny path. When a guard policy denies because a
``kind: human`` resolver hasn't run yet, the StageVerdict's
``pending_resolution`` field names this tool. The agent's LLM is
expected to call it with the rendered prompt; the tool's answer
populates the variable; the agent retries the original tool and the
gate passes.

The server is intentionally minimal: terminal in / terminal out, no
web UI. Hosts that want a richer surface (Slack, web button, ticketing
system) should swap this implementation while keeping the tool name and
return shape stable.
"""

from __future__ import annotations

import json
import os
import sys
from typing import Any

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("agent_shield.ask_human")


_AUTO_APPROVE = os.environ.get("ASK_HUMAN_AUTO_APPROVE", "0") == "1"


def _read_decision() -> tuple[str, Any, str | None]:
    """Prompt the operator and return ``(decision, value, reason)``.

    ``decision`` is one of ``"allow"`` / ``"deny"`` / ``"cancelled"``.
    The ``value`` is what the runtime will write into the target
    variable when the decision is ``allow``. By spec §11.11 default,
    a ``kind: human`` resolver that doesn't return an explicit ``value``
    yields ``true`` for boolean variables — we follow that convention
    here.
    """
    if _AUTO_APPROVE:
        return ("allow", True, "auto-approved (ASK_HUMAN_AUTO_APPROVE=1)")

    print("\n[agent_shield.ask_human]", file=sys.stderr)
    print("  (a)llow   — allow this request", file=sys.stderr)
    print("  (b)lock   — deny this request", file=sys.stderr)
    print("  (c)ancel  — cancel the operation", file=sys.stderr)
    print("  Decision: ", end="", file=sys.stderr, flush=True)

    raw = sys.stdin.readline().strip().lower()
    if raw in ("a", "allow", "y", "yes", "o", "once"):
        return ("allow", True, None)
    if raw in ("c", "cancel", "cancelled"):
        return ("cancelled", None, "cancelled by human operator")
    return ("deny", None, "denied by human operator")


@mcp.tool(name="agent_shield.ask_human")
def ask_human(prompt: str, variable: str | None = None) -> str:
    """Prompt a human operator and return the response as a JSON string.

    Parameters
    ----------
    prompt:
        The fully-interpolated prompt produced by the Agent Shield
        runtime. Surfaced verbatim to the human.
    variable:
        Optional name of the target Agent Shield variable. Surfaced for
        operator context only — the runtime knows the binding from the
        deny verdict.

    Returns
    -------
    A JSON-encoded resolver response envelope (§11.3) with shape::

        {"decision": "allow"|"deny"|"cancelled",
         "value": <any>,
         "reason": <string|null>}

    The host runtime is expected to feed this envelope back to the
    runtime via the variable's ``populated_by:`` configuration — the
    canonical setting writes ``value`` directly into the target
    variable.
    """
    print(f"\n[ask_human] prompt: {prompt}", file=sys.stderr)
    if variable:
        print(f"[ask_human] variable: {variable}", file=sys.stderr)

    decision, value, reason = _read_decision()
    return json.dumps(
        {"decision": decision, "value": value, "reason": reason},
        ensure_ascii=False,
    )


if __name__ == "__main__":
    mcp.run()
