#!/usr/bin/env python3
"""Sensitive Documents (DLP) — Agent Shield demo.

ONE script, two frameworks, three modes. Same shape as the
bank-manager demo, with three MCP servers wired in (SharePoint,
SQLite, Email).

Usage:

    # Interactive REPL with the guarded agent
    python demo.py

    # Drive Anthropic's Agents SDK
    python demo.py --framework anthropic

    # Run all scripted scenarios end-to-end and print the
    # guarded ↔ unguarded side-by-side
    python demo.py --scenarios all

    # Run a single scenario by name
    python demo.py --scenarios restricted_then_email_blocked

    # Run one ad-hoc request
    python demo.py --request "Read the Q3 revenue report"
"""
from __future__ import annotations

import os
import shlex
import sys
from pathlib import Path

import anyio

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))
from _shared import (
    MCPConnection,
    build_agent_for,
    build_llm_for,
    build_native_agent_for,
    build_tools_for,
    install_adapters,
    parse_args,
    run_repl,
    run_scenarios,
    setup_args,
    shield_with,
    wrap_guarded_for,
)

sys.path.insert(0, str(Path(__file__).resolve().parent))
from scenarios import CATALOG  # noqa: E402

sys.path.insert(
    0,
    str(
        Path(__file__).resolve().parent.parent.parent.parent
        / "sdk" / "python" / "src"
    ),
)
from agent_shield import Runtime, Shield  # noqa: E402


HERE = Path(__file__).resolve().parent
GUARDRAILS_YAML = str(HERE / "guardrails.yaml")
SAMPLE_DOCS = HERE / "sample_docs"
PYTHON = sys.executable

SYSTEM_PROMPT = (
    "You are a document research assistant. You help users read, search, and "
    "act on sensitive corporate documents through SharePoint, SQLite, and email "
    "tools. Always respect document sensitivity labels and jurisdiction. Never "
    "share restricted documents with external recipients."
)


def _default_command(server_name: str, *extra_args: str) -> str:
    """Absolute command for one of this demo's bundled MCP servers."""
    server = HERE / "mcp_servers" / f"{server_name}.py"
    parts = [shlex.quote(PYTHON), shlex.quote(str(server)), *extra_args]
    return " ".join(parts)


async def main() -> None:
    args = parse_args(
        description="Sensitive Documents (DLP) — Agent Shield demo",
        extra_args=[
            (
                "--sharepoint-command",
                dict(
                    default=os.getenv("SHAREPOINT_MCP_COMMAND") or "",
                    help="Override the SharePoint MCP server command.",
                ),
            ),
            (
                "--sqlite-db",
                dict(
                    default=os.getenv("SQLITE_DB") or str(HERE / "demo.db"),
                    help="Path to the SQLite DB the SQLite/email MCP servers use.",
                ),
            ),
        ],
    )
    setup_args(args)
    Runtime.configure_logging()
    install_adapters()

    sharepoint_cmd = (args.sharepoint_command or "").strip() or _default_command(
        "sharepoint", "--root", str(SAMPLE_DOCS)
    )
    sqlite_cmd = _default_command("sqlite", "--db", args.sqlite_db)
    email_cmd = _default_command("email", "--db", args.sqlite_db)
    print(f"[Config] sharepoint MCP : {sharepoint_cmd}")
    print(f"[Config] sqlite     MCP : {sqlite_cmd}")
    print(f"[Config] email      MCP : {email_cmd}")

    async with (
        MCPConnection("sharepoint", sharepoint_cmd) as sp,
        MCPConnection("sqlite", sqlite_cmd) as db,
        MCPConnection("email", email_cmd) as mail,
    ):
        for conn in (sp, db, mail):
            if conn.session is None:
                raise RuntimeError(f"Failed to initialize {conn.name} MCP session")

        raw_tools: list = []
        for conn in (sp, db, mail):
            raw_tools.extend(await build_tools_for(args.framework, conn.session))
        print(f"[Tools] loaded: {[t.name for t in raw_tools]}")

        # ── The integration code. Five real lines. ──────────────────────
        llm = build_llm_for(args.framework)
        shield = (
            shield_with(
                args.framework,
                Shield.from_yaml(GUARDRAILS_YAML, auto_bind=False),
            )
            .with_client(llm)
            .build()
        )
        guarded_tools = shield.protect_tools(raw_tools)               # Stages 2 + 3 + 4
        guarded_native = build_native_agent_for(
            args.framework, llm, guarded_tools, SYSTEM_PROMPT,
        )
        guarded_runner = shield.guard(                                # Stages 1 + 5
            guarded_native, tools=guarded_tools, system=SYSTEM_PROMPT,
        ) if args.framework == "anthropic" else shield.guard(guarded_native)
        # ────────────────────────────────────────────────────────────────

        unguarded = build_agent_for(
            args.framework, llm, raw_tools, SYSTEM_PROMPT, debug=args.debug,
        )
        guarded = wrap_guarded_for(
            args.framework, guarded_runner,
            tools=guarded_tools, system_prompt=SYSTEM_PROMPT,
        )

        if args.scenarios is not None:
            scenarios = CATALOG.select(args.scenarios)
            await run_scenarios(
                scenarios=scenarios,
                unguarded_invoke=unguarded.ainvoke,
                guarded_invoke=guarded.ainvoke,
                before_invoke=None,
            )
            return

        await run_repl(
            invoke=(unguarded if args.no_shield else guarded).ainvoke,
            before_invoke=None,
            on_new_session=(unguarded if args.no_shield else guarded).new_session,
            banner=(
                "Document DLP assistant ready (UNGUARDED — no shield). "
                "Type your request, /newSession, or 'quit' to exit."
                if args.no_shield else
                "Document DLP assistant ready (guarded). "
                "Type your request, /newSession, or 'quit' to exit."
            ),
            single_request=args.request,
        )


if __name__ == "__main__":
    anyio.run(main)
