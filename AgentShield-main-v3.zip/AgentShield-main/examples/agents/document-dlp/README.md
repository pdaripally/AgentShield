# Sensitive Documents (DLP) — Agent Shield demo

## DEMO ONLY

This demo is designed for local experimentation and omits production authn/authz, network, and secret-management controls.


A document-research agent demonstrating **Data Loss Prevention** with
sensitivity ratchets, jurisdiction tracking, graduated email policy,
wildcard policies, and output PII redaction. The demo connects to
three mock MCP servers (SharePoint, SQLite, email) so it runs with
zero external dependencies.

Same shape as `bank-manager/`: one `demo.py`, `--framework
{langchain,anthropic}`, `--scenarios all` for the side-by-side run,
or interactive REPL by default.

## Quick start

```bash
# From the repo root
pip install -r examples/agents/document-dlp/requirements.txt

# Set your LLM credentials — see examples/agents/document-dlp/.env.example
export OPENAI_API_KEY=sk-...

# Run the full guarded ↔ unguarded scenario catalog
python examples/agents/document-dlp/demo.py --scenarios all

# Same, against Anthropic's Agents SDK
python examples/agents/document-dlp/demo.py --framework anthropic --scenarios all

# Interactive REPL with the guarded agent
python examples/agents/document-dlp/demo.py
```

## What this demonstrates

| Scenario | Stages | What you see |
|---|---|---|
| `benign_public_doc_read` | S1 | Public-sensitivity doc reads cleanly. |
| `restricted_then_email_blocked` | S2 | Reading a restricted doc and then attempting to email — Stage-2 ratchet refuses the email. |
| `session_contamination_ratchet` | S2 | Once any restricted data is read in a session, even subsequent emails of public content are refused — ratchet is sticky. |
| `document_injection_attack` | S3 | Document body carries a tool-output injection. Stage-3 catches it. |
| `jailbreak_input` | S1 | Stage-1 regex catches an obvious jailbreak before the agent sees it. |
| `eu_jurisdiction_blocks_save` | S2 | EU-tagged data attempting a non-EU operation triggers Stage-2 jurisdiction guard. |
| `sensitivity_relabel_attack` | S1 + S2 | User attempts to relabel sensitivity. Stage-1 regex + Stage-2 ratchet both refuse — sensitivity can only ratchet up. |

## Files

```
.
├── README.md                  (this file)
├── .env.example               env-var template
├── requirements.txt           Python deps
├── demo.py                    ★ the demo entry point
├── scenarios.py               scripted scenarios → expected verdicts
├── guardrails.yaml            Agent Shield contract
├── prompts/
│   └── task_adherence.md      DLP-specific Stage-3 LLM prompt
├── mcp_servers/
│   ├── sharepoint.py          mock SharePoint MCP server
│   ├── sqlite.py              SQLite MCP server
│   └── email.py               mock email MCP server (writes to SQLite)
├── sample_docs/               canned documents for the SharePoint server
└── document_metadata.txt      metadata about sample_docs/
```
