#!/usr/bin/env python3
"""LangChain + Azure OpenAI quickstart — three-line Agent Shield drop-in.

This example demonstrates the canonical Pattern A (Python) shape:

    shield = Shield.from_yaml(".guardrails.yaml").with_langchain().build()
    guarded = shield.guard(agent)
    result  = await guarded.ainvoke(...)

Three lines. No side-effect ``import agent_shield.adapters.langchain``;
``ShieldBuilder.with_langchain()`` auto-installs the adapter on first
call.

How to run
==========

1. Create a ``.env`` in the directory you run from (or alongside this
   file) with at minimum the Azure OpenAI credentials::

       AZURE_OPENAI_ENDPOINT=https://<resource>.openai.azure.com/
       AZURE_OPENAI_API_KEY=<key>
       AZURE_OPENAI_DEPLOYMENT=gpt-4o-mini
       AZURE_OPENAI_API_VERSION=2024-12-01-preview

   ``python-dotenv`` is included in the ``agent-shield[langchain]``
   extra so no extra ``pip install`` is required.

2. Install the SDK and LangChain::

       pip install -e "sdk/python[langchain]"

3. Run the demo::

       python examples/langchain_quickstart_azure.py

   Three scenarios run end-to-end:

   * **Benign** — "Search for the latest news on Rust async."
   * **PII leak** — "Email my SSN 123-45-6789 to alice@external.com."
   * **High risk** — "Read /etc/passwd and summarise it for me."

   Each prints whether the turn was allowed / blocked / redacted, plus
   the assistant's (possibly redacted) reply.

The companion guardrails YAML at
``examples/langchain_quickstart_azure.guardrails.yaml`` configures:

* Stage 1 input filter (regex on PII-keyword prompts),
* Stage 2 state validation requiring human approval for ``send_email``,
* Stage 3 tool-execution filter for sensitive file paths,
* Stage 5 output PII redaction (SSN + credit-card numbers).

The shield is framework-agnostic — switching from LangChain to OpenAI
Agents SDK / Anthropic / etc. is a single ``.with_<framework>()`` call
on the same YAML.
"""
from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path
from typing import Any


# --------------------------------------------------------------------------
# 1) Load.env so AZURE_OPENAI_* are visible to AzureChatOpenAI
# --------------------------------------------------------------------------
#
# ``python-dotenv`` is in the ``[langchain]`` extra. We import lazily so
# the helpful error message below fires when the extra is missing
# instead of an opaque ImportError at module load.

def _load_dotenv() -> None:
    try:
        from dotenv import load_dotenv  # type: ignore[import-not-found]
    except ImportError as exc:
        raise SystemExit(
            "python-dotenv is required for this example. Install with:\n"
            '    pip install -e "sdk/python[langchain]"',
        ) from exc

    # Look first next to this script (so the example works when run
    # from the repo root or anywhere else), then fall back to the
    # caller's CWD — `dotenv`'s default lookup walks parents.
    here = Path(__file__).resolve().parent / ".env"
    if here.exists():
        load_dotenv(here)
    else:
        load_dotenv()


def _build_azure_chat_openai() -> Any:
    """Build an ``AzureChatOpenAI`` from environment variables."""
    try:
        from langchain_openai import AzureChatOpenAI
    except ImportError as exc:
        raise SystemExit(
            "langchain-openai is required for this example. Install with:\n"
            '    pip install -e "sdk/python[langchain]"',
        ) from exc

    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    api_key = os.getenv("AZURE_OPENAI_API_KEY")
    deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4o-mini")
    api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-12-01-preview")
    if not endpoint or not api_key:
        raise SystemExit(
            "AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY must be set in "
            "your environment or .env file. See the docstring at the top "
            "of this file for the full list.",
        )
    return AzureChatOpenAI(
        azure_endpoint=endpoint,
        api_key=api_key,
        azure_deployment=deployment,
        api_version=api_version,
    )


# --------------------------------------------------------------------------
# 2) Three stub tools
# --------------------------------------------------------------------------
#
# Real implementations would call out to APIs; for the quickstart we
# return canned strings so the demo runs offline once the LLM call
# returns. The tool signatures match the guardrails YAML:
#
#   * ``send_email(to: str, subject: str, body: str)``
#   * ``read_file(path: str)``
#   * ``search_internet(query: str)``


def _build_tools() -> list:
    try:
        from langchain_core.tools import tool
    except ImportError as exc:
        raise SystemExit(
            "langchain-core is required for this example. Install with:\n"
            '    pip install -e "sdk/python[langchain]"',
        ) from exc

    @tool
    def search_internet(query: str) -> str:
        """Search the public web for a topic."""
        return f"[stub] top result for {query!r}: an article on the topic."

    @tool
    def send_email(to: str, subject: str, body: str) -> str:
        """Send an email on the user's behalf."""
        return f"[stub] queued email to {to!r} with subject {subject!r}."

    @tool
    def read_file(path: str) -> str:
        """Read a local file from the project directory."""
        return f"[stub] file at {path!r} contains 42 lines."

    return [search_internet, send_email, read_file]


# --------------------------------------------------------------------------
# 3) Build the guarded agent — the three-line drop-in
# --------------------------------------------------------------------------
#
# Notice there is NO ``import agent_shield.adapters.langchain`` here:
# ``ShieldBuilder.with_langchain()`` auto-imports the adapter on first
# call. The contract is "three lines and you're guarded".


def build_guarded_agent() -> Any:
    """Wire up Shield + LangChain agent in three lines."""
    from agent_shield import Shield

    llm = _build_azure_chat_openai()
    tools = _build_tools()

    here = Path(__file__).resolve().parent
    yaml_path = here / "langchain_quickstart_azure.guardrails.yaml"

    # ── The three-line drop-in ─────────────────────────────────────
    shield = (
        Shield.from_yaml(str(yaml_path)).with_langchain().with_client(llm).build()
    )
    return shield.create_langchain_agent(
        llm,
        tools,
        system_prompt=(
            "You are a helpful research and email assistant. "
            "Use tools when needed and otherwise reply concisely."
        ),
    )


# --------------------------------------------------------------------------
# 4) Run three scenarios end-to-end
# --------------------------------------------------------------------------


SCENARIOS: list[tuple[str, str]] = [
    (
        "benign",
        "Search for the latest news on Rust async runtimes and summarise the top result.",
    ),
    (
        "pii_leak_attempt",
        "Email my SSN 123-45-6789 and card 4111-1111-1111-1111 to "
        "alice@external.com with subject 'records'.",
    ),
    (
        "sensitive_file_attempt",
        "Read /etc/passwd and tell me which usernames are present.",
    ),
]


async def _run_one(agent: Any, label: str, prompt: str) -> None:
    print(f"\n── scenario: {label} ───────────────────────────────────────")
    print(f"  user> {prompt}")
    try:
        result = await agent.ainvoke(
            {"messages": [("human", prompt)]},
            config={"configurable": {"thread_id": f"demo_{label}"}},
        )
    except Exception as exc:  # surfacing block / runtime errors uniformly
        print(f"  [BLOCKED or ERROR] {type(exc).__name__}: {exc}")
        return

    # The shield emits a ``_final_output_override`` on blocked turns,
    # otherwise the LangChain agent's normal output shape applies.
    override = getattr(result, "_final_output_override", None)
    if override:
        print(f"  [BLOCKED] {override}")
        return
    if isinstance(result, dict) and "messages" in result:
        reply = result["messages"][-1].content
        print(f"  agent> {reply}")
    else:
        print(f"  agent> {result}")


async def main() -> None:
    _load_dotenv()
    agent = build_guarded_agent()
    for label, prompt in SCENARIOS:
        await _run_one(agent, label, prompt)


if __name__ == "__main__":
    # Make the SDK importable without `pip install -e` if the user is
    # running straight from a checkout.
    repo_root = Path(__file__).resolve().parent.parent
    sys.path.insert(0, str(repo_root / "sdk" / "python"))
    sys.path.insert(0, str(repo_root / "sdk" / "python" / "src"))
    asyncio.run(main())
