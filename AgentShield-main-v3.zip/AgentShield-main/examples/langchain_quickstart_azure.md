# LangChain + Azure OpenAI quickstart

A complete, runnable end-to-end Agent Shield example for the LangChain +
Azure OpenAI combination. The Python file is the **shortest possible**
guarded-agent shape; this page tells you how to run it and what to
expect.

## Files

| File | Role |
| ---- | ---- |
| `langchain_quickstart_azure.py` | The three-line drop-in + 3 scripted scenarios |
| `langchain_quickstart_azure.guardrails.yaml` | The shield's `.guardrails.yaml` contract |
| `langchain_quickstart_azure.md` | This walkthrough |

## 1. Install

```bash
pip install -e "sdk/python[langchain]"
```

The `[langchain]` extra pulls a compatible range of LangChain
(`langchain>=0.3,<2.0`) plus `langchain-openai` and `python-dotenv`
for `.env` loading. Both LangChain 0.3.x and 1.x are supported; the
adapter picks the right agent-construction API at runtime.

## 2. Configure Azure OpenAI

Create a `.env` file next to the example (or in any parent directory):

```ini
AZURE_OPENAI_ENDPOINT=https://<your-resource>.openai.azure.com/
AZURE_OPENAI_API_KEY=<key>
AZURE_OPENAI_DEPLOYMENT=gpt-4o-mini
AZURE_OPENAI_API_VERSION=2024-12-01-preview
```

The example loads it with `python-dotenv` automatically; no shell
exports needed.

## 3. Run

```bash
python examples/langchain_quickstart_azure.py
```

You'll see three scenarios scroll by, each labelled with its outcome:

* `benign` — the model uses `search_internet` and replies with a summary.
* `pii_leak_attempt` — Stage 1 blocks the prompt **before** the model is
  invoked, with reason `Prompt requests emailing/forwarding PII or
  credentials.` Any SSN-/card-shaped strings that slip through (e.g.
  fabricated examples in the model's reply) are scrubbed by the Stage 5
  redactor.
* `sensitive_file_attempt` — the model proposes `read_file` with
  `/etc/passwd`; Stage 3 denies the tool call with `Reading from
  secret/system paths is not permitted.` Depending on the model, the
  conversation either ends with a refusal message or surfaces the block
  reason directly.

## 4. The three-line drop-in

The whole shield wiring is:

```python
from agent_shield import Shield

shield = (
    Shield.from_yaml("examples/langchain_quickstart_azure.guardrails.yaml")
    .with_langchain()
    .with_client(llm)
    .build()
)
agent = shield.create_langchain_agent(llm, tools, system_prompt="...")
```

No side-effect `import agent_shield.adapters.langchain` is required —
`ShieldBuilder.with_langchain()` lazy-imports the adapter on first
call.

If you'd rather build the agent yourself (Pattern B — wrap-up-front),
that's also three lines:

```python
shield = Shield.from_yaml(...).with_langchain().with_client(llm).build()
tools = shield.protect_tools(tools)
agent = shield.guard(create_agent(llm, tools, system_prompt="..."))
```

## 5. Customising the contract

Edit `langchain_quickstart_azure.guardrails.yaml` and re-run. The same
YAML enforces identically when you swap `with_langchain()` for
`with_openai_agents()`, `with_anthropic_agents()`, etc. — the contract
is framework-portable.

## Troubleshooting

* **`AttributeError: 'ShieldBuilder' object has no attribute 'with_langchain'`** —
  you're on an old SDK build that pre-dates the lazy-import fallback.
  Either upgrade to `agent-shield>=0.13.1` or add `import
  agent_shield.adapters.langchain` before the builder call.
* **`ImportError: cannot import name 'AgentExecutor' from 'langchain.agents'`** —
  you have LangChain 1.x and your own code uses the 0.x agent shape.
  Either downgrade with `pip install "langchain<1"` or migrate to
  `langchain.agents.create_agent`. The Agent Shield adapter itself
  supports both versions; the friction is only with code that
  hard-codes the 0.x import.
* **`python-dotenv is required for this example`** — re-install with
  the extra: `pip install -e "sdk/python[langchain]"`.
