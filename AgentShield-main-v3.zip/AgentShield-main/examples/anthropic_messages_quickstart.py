"""End-to-end Anthropic Messages API quickstart.

Customers writing the *standard* Anthropic Messages API call::

    from anthropic import Anthropic
    client = Anthropic()

    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1024,
        tools=[{
            "name": "lookup_customer",
            "description": "Look up customer details by ID",
            "input_schema": {
                "type": "object",
                "properties": {"customer_id": {"type": "string"}},
                "required": ["customer_id"],
            },
        }],
        messages=[{"role": "user", "content": user_message}],
    )

— that is, with **tool dicts** rather than ``BetaAsyncBuiltinFunctionTool``
objects — used to trip ``Shield.protect_tools(tools)`` with
``AttributeError: 'dict' object has no attribute 'name'``. The fix
adds a dict-aware surface that pairs each tool dict with a
``dispatch`` callable and routes every tool call through Stages
2 + 3 + 4 of the AgentShield validation pipeline.

There are two surfaces, both demonstrated below:

1. ``Shield.run_anthropic_agent(...)`` — Pattern A runner: owns the
   ``messages.create()`` → tool-dispatch → ``messages.create()`` loop
   end-to-end with Stages 1 → 2 → 3 → 4 → 5 enforced.

2. ``Shield.protect_anthropic_tools(tools, dispatch)`` — Pattern B
   primitive: returns a guarded dispatcher that the customer wires
   into their own ``messages.create()`` loop. Use this when you need
   to customise the loop (logging, retry, tracing) but still want
   every tool call guarded.

Cross-SDK invariant: on a Stage 2/3 ``kind: human``
block the structured ``pending_resolution`` is exposed via
``Shield.last_pending_resolution()`` so the host can drive the
human-approval UI *without* substring-matching the
``[GUARDRAIL ...]`` block message.

Run (no live API call required — a stub client is used by default)::

    python examples/anthropic_messages_quickstart.py

To run against a real Anthropic API:

    pip install anthropic
    export ANTHROPIC_API_KEY=...
    python examples/anthropic_messages_quickstart.py --live
"""
from __future__ import annotations

import argparse
import asyncio
import os
import sys
import tempfile
from typing import Any

from agent_shield import Shield
import agent_shield.adapters.anthropic_agents  # noqa: F401  side-effect


# ---------------------------------------------------------------------------
# .guardrails.yaml — the contract drives every adapter; same YAML works
# for LangChain, OpenAI Agents, MCP, etc..
# ---------------------------------------------------------------------------


GUARDRAILS_YAML = """
metadata:
  name: "anthropic-messages-quickstart"
  version: "0.1.0"
  description: "Quickstart for client.messages.create() with dict tools."
  agent_shield_version: "2.0"

objective:
  goal:
    - "Answer customer support questions by looking up account details."
  forbidden:
    - "Reveal raw SSNs, account numbers, or other PII to the agent."

resources:
  tools:
    - name: lookup_customer
      description: "Look up customer details by ID."
      permission: read_only

tool_execution_validation:
  guard_policies:
    - name: redact_pii_from_tool_args
      applies_to: { tools: ["lookup_customer"] }
      action: redact
      replacement: "[PII]"
      evaluate_when:
        - patterns:
            - '\\b\\d{3}-\\d{2}-\\d{4}\\b'
          reason: "SSN-shaped value in tool arguments."
"""


# ---------------------------------------------------------------------------
# Customer tool — plain Python callable, the way Anthropic tutorials do it.
# ---------------------------------------------------------------------------


def lookup_customer(customer_id: str) -> dict[str, Any]:
    """Look up customer details by ID. (Toy example.)"""
    catalog = {
        "c-42": {"name": "Acme Inc", "id": "c-42", "tier": "enterprise"},
        "c-7":  {"name": "Globex",   "id": "c-7",  "tier": "starter"},
    }
    return catalog.get(customer_id, {"error": f"unknown customer {customer_id}"})


TOOLS = [
    {
        "name": "lookup_customer",
        "description": "Look up customer details by ID.",
        "input_schema": {
            "type": "object",
            "properties": {"customer_id": {"type": "string"}},
            "required": ["customer_id"],
        },
    },
]


# ---------------------------------------------------------------------------
# Dispatch callable — maps tool name + LLM params to the Python callable.
# ---------------------------------------------------------------------------


_HANDLERS = {
    "lookup_customer": lookup_customer,
}


def dispatch(name: str, params: dict) -> Any:
    """Run the named tool with the LLM-supplied params.

    The contract: ``dispatch(name, params)`` returns the tool's result
    (sync) or an awaitable that resolves to the tool's result. The
    guarded dispatcher returned from
    :meth:`Shield.protect_anthropic_tools` wraps this with Stages
    2 + 3 + 4; the customer never has to plumb the stages by hand.
    """
    fn = _HANDLERS.get(name)
    if fn is None:
        raise KeyError(f"no handler for tool: {name!r}")
    return fn(**(params or {}))


# ---------------------------------------------------------------------------
# Stub Anthropic client — drives the example without an API key. Replace
# with ``from anthropic import Anthropic; client = Anthropic()`` for live use.
# ---------------------------------------------------------------------------


class _StubToolUse:
    type = "tool_use"

    def __init__(self, id, name, input):
        self.id, self.name, self.input = id, name, input


class _StubText:
    type = "text"

    def __init__(self, text): self.text = text


class _StubMessage:
    def __init__(self, content, stop_reason):
        self.content = content
        self.stop_reason = stop_reason


class _StubMessages:
    def __init__(self):
        self._turn = 0

    def create(self, **kwargs):
        self._turn += 1
        if self._turn == 1:
            return _StubMessage(
                content=[_StubToolUse("tu_1", "lookup_customer",
                                      {"customer_id": "c-42"})],
                stop_reason="tool_use",
            )
        return _StubMessage(
            content=[_StubText(
                "The customer c-42 is Acme Inc (enterprise tier)."
            )],
            stop_reason="end_turn",
        )


class _StubAnthropic:
    def __init__(self): self.messages = _StubMessages()


def _make_client(live: bool):
    if live:
        from anthropic import Anthropic  # noqa: WPS433
        return Anthropic()
    return _StubAnthropic()


# ---------------------------------------------------------------------------
# Surface 1 — Shield.run_anthropic_agent(...): full Pattern A runner.
# ---------------------------------------------------------------------------


async def demo_run_anthropic_agent(shield: Shield, client: Any) -> None:
    print("=== Surface 1: shield.run_anthropic_agent(...) ===")
    print()
    print("One call drives the entire messages.create() → dispatch loop")
    print("with Stage 1 / 2 / 3 / 4 / 5 enforcement applied.")
    print()

    result = await shield.run_anthropic_agent(
        client=client,
        model="claude-sonnet-4-20250514",
        tools=TOOLS,
        dispatch=dispatch,
        messages=[
            {"role": "user", "content": "Who is customer c-42?"},
        ],
        max_tokens=1024,
    )

    text = ""
    for block in getattr(result, "content", []) or []:
        text += getattr(block, "text", "")
    print(f"Final assistant text: {text or result!r}")
    print()

    # Structured pending_resolution surface. None here because
    # no kind:human resolver fired.
    pending = shield.last_pending_resolution()
    print(f"shield.last_pending_resolution() → {pending!r}")
    print()


# ---------------------------------------------------------------------------
# Surface 2 — Shield.protect_anthropic_tools(...): bring-your-own loop.
# ---------------------------------------------------------------------------


async def demo_protect_anthropic_tools(shield: Shield, client: Any) -> None:
    print("=== Surface 2: shield.protect_anthropic_tools(tools, dispatch) ===")
    print()
    print("Returns a guarded dispatcher that you wire into your own")
    print("messages.create() loop. Use this when you need to customise")
    print("the loop (logging, retry, tracing) but still want every tool")
    print("call guarded.")
    print()

    guarded_dispatch = shield.protect_anthropic_tools(TOOLS, dispatch)

    # The customer's own loop — exactly what the bug-report shape was.
    # Establish an ambient session so the guarded tool sees one
    # (fail-closed by default).
    from agent_shield.adapters._orchestration import current_session

    sess = shield.runtime.new_session()
    sess.begin_turn()
    token = current_session.set(sess)
    try:
        convo: list = [{"role": "user", "content": "Who is c-42?"}]
        for _ in range(5):  # tool-loop with a sane cap
            response = client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=1024,
                tools=TOOLS,
                messages=convo,
            )
            if response.stop_reason != "tool_use":
                break
            convo.append({"role": "assistant", "content": list(response.content)})
            tool_results: list = []
            for block in response.content:
                if getattr(block, "type", None) != "tool_use":
                    continue
                out = await guarded_dispatch(block.name, dict(block.input))
                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": block.id,
                    "content": out if isinstance(out, str) else str(out),
                })
            convo.append({"role": "user", "content": tool_results})
    finally:
        current_session.reset(token)
        sess.end_turn()

    text = "".join(
        getattr(b, "text", "") for b in (response.content or [])
    )
    print(f"Final assistant text: {text or response!r}")
    print()
    pending = shield.last_pending_resolution()
    print(f"shield.last_pending_resolution() → {pending!r}")
    print()


# ---------------------------------------------------------------------------
# Entry point.
# ---------------------------------------------------------------------------


async def amain(live: bool) -> int:
    yaml_path = _write_yaml()
    try:
        shield = (
            Shield.from_yaml(yaml_path, auto_bind=False)
            .with_anthropic_agents()
            .build()
        )
        client = _make_client(live)
        await demo_run_anthropic_agent(shield, client)
        # Stub messages are consumed by the first demo; rebuild for the
        # second demo so it has a fresh scripted response sequence.
        if not live:
            client = _make_client(live)
        await demo_protect_anthropic_tools(shield, client)
        return 0
    finally:
        os.unlink(yaml_path)


def _write_yaml() -> str:
    f = tempfile.NamedTemporaryFile(mode="w", suffix=".guardrails.yaml", delete=False)
    f.write(GUARDRAILS_YAML)
    f.close()
    return f.name


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--live", action="store_true",
        help="Use a real Anthropic client (requires anthropic + ANTHROPIC_API_KEY)",
    )
    args = parser.parse_args()
    sys.exit(asyncio.run(amain(live=args.live)))
