# CrewAI + Azure OpenAI invoice-processor quickstart

Runnable CrewAI + Azure OpenAI example: three native CrewAI agents process an invoice under one Agent Shield `.guardrails.yaml` contract.

## Files

| File | Role |
| ---- | ---- |
| `crewai_invoice_quickstart_azure.py` | Three-agent crew and scenario driver |
| `crewai_invoice_quickstart_azure.guardrails.yaml` | Guardrails contract |

## 1. Install

```bash
pip install -e "sdk/python[crewai]"
pip install "crewai[azure-ai-inference]" crewai-tools
```

For `agent-shield init --provider azure`, also install:

```bash
pip install -e "cli[azure]"
```

## 2. Configure Azure OpenAI

```ini
AZURE_OPENAI_ENDPOINT=https://<your-resource>.openai.azure.com/
AZURE_OPENAI_API_KEY=<key>
AZURE_OPENAI_DEPLOYMENT=<your-deployment-name>
AZURE_OPENAI_API_VERSION=2024-12-01-preview

# Optional AACS Stage 1 classifier. Set both vars or leave both unset.
AZURE_CONTENT_SAFETY_ENDPOINT=https://<resource>.cognitiveservices.azure.com/
AZURE_CONTENT_SAFETY_KEY=<key>
```

Azure `gpt-5.x` deployments reject `max_tokens`; the example uses `max_completion_tokens` on `crewai.LLM(...)`.

## 3. Run

```bash
python examples/crewai_invoice_quickstart_azure.py
```

Scenarios:

- `benign_small_invoice` — intake, fraud review, and payment approval succeed.
- `large_amount_requires_approval` — Stage 2 returns a `pending_resolution` before `approve_payment` runs.
- `prompt_injection_blocked_at_stage1` — Stage 1 blocks before CrewAI starts.

## 4. Supported CrewAI composition

Use native CrewAI `Agent` / `Task` / `Crew` objects, wrap tools with Agent Shield, then guard the assembled crew:

```python
from agent_shield import Shield
import agent_shield.adapters.crewai  # side-effect import
from crewai import Agent, Crew, Process, Task

shield = (
    Shield.from_yaml(".guardrails.yaml")
    .with_crewai()
    .with_client(llm)
    .build()
)

extract_tool, fraud_tool, approve_tool = shield.protect_tools([
    ExtractInvoiceFieldsTool(),
    CheckFraudRiskTool(),
    ApprovePaymentTool(),
])

intake = Agent(role="InvoiceIntakeAgent", tools=[extract_tool], llm=llm, ...)
fraud = Agent(role="FraudReviewAgent", tools=[fraud_tool], llm=llm, ...)
approval = Agent(role="PaymentApprovalAgent", tools=[approve_tool], llm=llm, ...)

crew = Crew(
    agents=[intake, fraud, approval],
    tasks=[intake_task, fraud_task, approval_task],
    process=Process.sequential,
)

result = shield.guard_crew(crew).kickoff(inputs={"raw_invoice": "..."})
```

`GuardedCrew.kickoff(...)` owns one shared session. Variables populated by intake and fraud tools (`vendor`, `amount`, `invoice_id`, `fraud_score`) are visible to the approval gate.

## 5. Human approval surface

When `large_payment_requires_manager_approval` blocks, read the pending request and resume by setting the requested variable:

```python
pending = shield.last_pending_resolution()
# pending = {"kind": "human", "tool": "agent_shield.ask_human",
#            "variable": "large_payment_authorized", "prompt": "...",
#            "request_id": "..."}

guarded_crew._session.set_variable(pending["variable"], True)
```

For a bare-core ask → approve → resume loop, see [`human_approval_quickstart.py`](human_approval_quickstart.py).

## 6. Cross-vendor Stage 3 enforcement

Approval tools should expose the destination as an explicit argument:

```python
class ApprovePaymentTool(BaseTool):
    name: str = "approve_payment"
    args_schema: type[BaseModel] = _ApproveArgs  # invoice_id, amount, vendor

    def _run(self, invoice_id: str, amount: float, vendor: str) -> dict:
        ...
```

Then Stage 3 can compare live tool-call args against variables extracted earlier:

```yaml
predicates:
  approval_vendor_matches_extracted: >-
    @tool.params.vendor == vendor

tool_execution_validation:
  guard_policies:
    - name: "approve_payment_vendor_arg_matches_extracted"
      applies_to: { tools: ["approve_payment"] }
      evaluate_when:
        - expression: "approval_vendor_matches_extracted"
          reason: "approve_payment vendor arg must match the extracted invoice vendor."
      action: "block"
```

Without a `vendor` parameter, the shield cannot see the actual payment destination.

## 7. Coverage

```python
CapabilityReport(
    framework="crewai",
    input_validation=FULL,
    state_validation=FULL,
    tool_authorization=FULL,
    tool_execution_validation=FULL,
    tool_output_validation=FULL,
    output_validation=FULL,
    streaming_output=UNSUPPORTED,
)
```

Register every CrewAI tool through `shield.protect_tools(...)`. Tools attached directly to a CrewAI `Agent` are not guarded. CrewAI has no streaming kickoff API, so Stage 5 runs once on the final `CrewOutput`.

## Troubleshooting

- **`ImportError: Azure AI Inference native provider not available`** — install `pip install "crewai[azure-ai-inference]"`.
- **`AttributeError: 'Agent' object has no attribute 'get'`** when constructing `Task(agent=...)` — use the `protect_tools` + native `Agent` + `guard_crew` recipe above.
- **`Decision: Approved` after the approval tool was blocked** — require the approval agent to emit `Queued for manual review` when the tool did not run, and parse the final `Decision:` line in the host.
- **`fraud_score=unset`** — the populator path must match the tool result. This example's fraud tool returns `{score, flags}`, so YAML reads `@result.score`.
- **Stage 3 vendor mismatch never fires** — add `vendor` to the approval tool schema and `_run` signature.
- **Azure rejects `max_tokens`** — use `max_completion_tokens`.
- **AACS disabled unexpectedly** — set both `AZURE_CONTENT_SAFETY_ENDPOINT` and `AZURE_CONTENT_SAFETY_KEY`.
