# Shared LLM detector prompts

## DEMO ONLY

These prompts are demonstration/reference material and are not a substitute for production validation or red-teaming.


LLM detector prompts referenced by multiple example policies via
`prompt_path:`. Each is a UTF-8 markdown file containing a single
prompt template in the §12.9.2 format — the LLM is asked to classify
the subject text and return a structured JSON verdict.

| File | Used by | Catches |
|---|---|---|
| [`jailbreak.md`](jailbreak.md) | bank-manager, office | "ignore previous instructions" / "you are now …" / role hijack patterns |
| [`pii_detection.md`](pii_detection.md) | bank-manager | SSNs, account numbers, government IDs in user input |
| [`social_engineering.md`](social_engineering.md) | bank-manager | Authority appeals, urgency manipulation, impersonation |
| [`sensitive_data.md`](sensitive_data.md) | (reserved) | Sensitive-data classification (general purpose) |
| [`task_adherence.md`](task_adherence.md) | bank-manager (Stage-3 baseline) | Tool calls misaligned with stated objective |

## How to reference one

From a YAML inside `examples/agents/<name>/`:

```yaml
- llm:
    prompt_path: "../../prompts/jailbreak.md"
  reason: "Jailbreak attempt detected."
```

Path resolution is relative to the declaring YAML's directory per
spec §1.3.

## Adding a new shared prompt

1. Drop the markdown file here.
2. Index it in the table above.
3. Reference from the relevant YAMLs via
   `prompt_path: "../../prompts/<name>.md"`.

For agent-specific prompts (e.g. "task adherence for a banking
agent"), prefer co-locating under `agents/<name>/prompts/` — only
genuinely cross-agent prompts belong here.
