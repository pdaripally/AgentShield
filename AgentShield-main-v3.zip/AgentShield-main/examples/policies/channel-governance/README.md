# Channel governance policies

## DEMO ONLY

These YAMLs are reference patterns only and must be reviewed and adapted before production use.


Per-channel policy YAMLs governing how an agent is allowed to compose,
send, and react to messages on each platform. Each file is independently
loadable; `popular-channels.yaml` composes the common subset for an
organisation that needs the same baseline across multiple channels.

| Channel | File |
|---|---|
| Slack | [`slack.yaml`](slack.yaml) |
| Discord | [`discord.yaml`](discord.yaml) |
| WhatsApp | [`whatsapp.yaml`](whatsapp.yaml) |
| Signal | [`signal.yaml`](signal.yaml) |
| Telegram | [`telegram.yaml`](telegram.yaml) |
| iMessage | [`imessage.yaml`](imessage.yaml) |
| Google Chat | [`google-chat.yaml`](google-chat.yaml) |
| Common subset | [`popular-channels.yaml`](popular-channels.yaml) |

Use as starting points. Drop the relevant file into your project,
adjust thresholds and approval gates to match your environment, and
either `extends:` it from your application policy or load it
standalone via `agent_shield_core::load_chain`.
