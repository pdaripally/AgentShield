# `agent-shield-cli`

CLI tooling for [Agent Shield](https://github.com/microsoft/AgentShield).

> **Distribution name vs. command name.** This package's PyPI
> distribution name is `agent-shield-cli` (matches the file
> `cli/pyproject.toml`), but it installs **two** equivalent
> command-line entry points:
>
> ```bash
> agent-shield --help        # canonical
> agent-shield-cli --help    # alias for first-run discoverability
> ```
>
> Both shell into the same callable. Docs and examples use
> `agent-shield`; the `agent-shield-cli` alias exists only so the
> obvious "guess the package name is the command name" path is not
> a dead end on first install.

Today ships:

- **`agent-shield init`** — an LLM-driven conversational
  `.guardrails.yaml` designer that primes a frontier LLM with the
  Agent Shield v2 spec and an inline house-style skeleton, then
  walks you through producing a working schema-valid policy
  tailored to your specific agent.

## Install

> **Source install today.** Neither `agent-shield-cli` nor the
> transitive `agent-shield` runtime SDK is published on PyPI yet —
> `pip install "agent-shield-cli[openai]"` 404s. Install from this
> repo. The runtime SDK is a maturin-built native extension, so a
> working **Rust toolchain** (`rustc` / `cargo` 1.78+, install via
> [rustup](https://rustup.rs/)) is required.

```bash
git clone https://github.com/microsoft/AgentShield.git
cd AgentShield

# The CLI declares `agent-shield>=0.13.0,<0.14` as a normal
# PyPI dependency. Until that package is published, install the
# runtime SDK editable from this checkout *first*, then install the
# CLI — pip will satisfy the version constraint against the local
# editable install instead of trying to resolve it from PyPI.
pip install -e sdk/python                # required first
pip install -e "cli[openai]"             # or [anthropic], [azure]
```

Skipping the first step yields:

```
ERROR: Could not find a version that satisfies the requirement
       agent-shield>=0.13.0,<0.14 ...
ERROR: No matching distribution found for agent-shield>=0.13.0,<0.14
```

which is pip telling you the SDK isn't on PyPI yet — install it
editable first and the CLI install resolves cleanly.

<details>
<summary><strong>When public packages ship</strong> (not yet runnable — this command 404s today)</summary>

```bash
pip install "agent-shield-cli[openai]"      # or [anthropic], [azure]
```

</details>

## Usage

See [`docs/getting-started/init.md`](https://github.com/microsoft/AgentShield/blob/main/docs/getting-started/init.md)
for the full walkthrough.

```bash
export OPENAI_API_KEY=sk-...

agent-shield init \
  --provider openai \
  --model gpt-5 \
  --openai-tools tools.json \
  --describe "Customer support bot. Refunds up to \$500, profile lookups, email replies."
```

## Layout

- `agent_shield_cli/` — Python package, entry point
- `agent_shield_cli/init/` — the `init` subcommand
- `agent_shield_cli/init/_data/` — bundled spec, schema, and
  expression-language reference (git-ignored, materialised at
  install time by `cli/_build_backend.py` from canonical
  `<repo>/spec/`)
- `_build_backend.py` — custom PEP 517 build backend that wraps
  setuptools to copy canonical spec content into `_data/` before
  the wheel/sdist is built
- `tests/` — pytest suite, mocked LLM caller, no live API calls

## Relationship to `agent-shield`

This package is **separate** from the runtime SDK (`agent-shield`).
Customers who only want runtime enforcement install `agent-shield`
and never see the CLI. Customers who want to design policies install
`agent-shield-cli`, which transitively brings in `agent-shield` for
the validator surface.

That separation keeps the runtime SDK install footprint small and
avoids comingling design-time tooling with the hot path.
