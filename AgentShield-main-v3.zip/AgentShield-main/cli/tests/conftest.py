"""Shared fixtures for the init test suite."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
import yaml

from ._support import make_action


@pytest.fixture
def openai_tools_json(tmp_path: Path) -> Path:
    p = tmp_path / "openai-tools.json"
    p.write_text(
        json.dumps(
            [
                {
                    "type": "function",
                    "function": {
                        "name": "get_customer",
                        "description": "Read a customer profile",
                        "parameters": {},
                    },
                },
                {
                    "type": "function",
                    "function": {
                        "name": "refund_order",
                        "description": "Issue a refund",
                        "parameters": {},
                    },
                },
            ]
        ),
        encoding="utf-8",
    )
    return p


@pytest.fixture
def mcp_manifest_json(tmp_path: Path) -> Path:
    p = tmp_path / "mcp-tools.json"
    p.write_text(
        json.dumps(
            {
                "tools": [
                    {"name": "search_db", "description": "Query the DB", "inputSchema": {}},
                ]
            }
        ),
        encoding="utf-8",
    )
    return p


@pytest.fixture
def anthropic_tools_json(tmp_path: Path) -> Path:
    p = tmp_path / "anthropic-tools.json"
    p.write_text(
        json.dumps([{"name": "list_files", "description": "List files", "input_schema": {}}]),
        encoding="utf-8",
    )
    return p


@pytest.fixture
def mcp_allowlist_yaml(tmp_path: Path) -> Path:
    p = tmp_path / "mcp-allowlist.yaml"
    p.write_text(
        yaml.safe_dump({"enforcement": "warn", "known": ["github"]}),
        encoding="utf-8",
    )
    return p


@pytest.fixture
def make_action_fn():
    return make_action
