"""Tests for ``agent-shield init``. Mocks the LLM caller — no live API calls."""
