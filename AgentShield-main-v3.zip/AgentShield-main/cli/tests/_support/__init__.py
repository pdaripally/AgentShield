"""Shared helpers for CLI tests."""

from __future__ import annotations

import json
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Deque, Dict, List, Sequence
from unittest import mock

import yaml

MINIMAL_CONFIG: Dict[str, object] = {
    "metadata": {"name": "p", "version": "0.1.0", "agent_shield_version": "2.0"},
    "objective": {"goal": ["help"]},
}


@dataclass
class MockLlmCaller:
    script: List[str]
    name: str = "mock"
    model: str = "mock-1"
    transcript: List[Dict[str, object]] = field(default_factory=list)
    cursor: int = 0

    def chat(self, messages: Sequence[Dict[str, str]]) -> str:
        if self.cursor >= len(self.script):
            raise AssertionError(
                f"mock LLM ran out of scripted responses (turn {self.cursor + 1}); "
                f"the agent kept asking. Last messages: "
                f"{[m.get('role') for m in messages[-3:]]}"
            )
        response = self.script[self.cursor]
        self.cursor += 1
        last_user_content = next(
            (m.get("content") for m in reversed(messages) if m.get("role") == "user"),
            None,
        )
        self.transcript.append(
            {
                "n_messages": len(messages),
                "last_role": messages[-1].get("role") if messages else None,
                "last_user_content": last_user_content,
                "response": response,
            }
        )
        return response


def make_action(action: str, **fields: Any) -> str:
    return json.dumps({"action": action, **fields})


def io_pair(inputs: Sequence[str]) -> tuple[Callable[[str], str], Callable[[str], None], List[str]]:
    queue: Deque[str] = deque(inputs)
    captured: List[str] = []

    def input_fn(_prompt: str) -> str:
        if not queue:
            return ""
        return queue.popleft()

    def output_fn(text: str) -> None:
        captured.append(text)

    return input_fn, output_fn, captured


def patch_build_caller(caller: object):
    return mock.patch("agent_shield_cli.init._command.build_caller", return_value=caller)


def write_yaml(path: Path, data: Dict[str, object]) -> None:
    path.write_text(yaml.safe_dump(data), encoding="utf-8")
