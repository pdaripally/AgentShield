from __future__ import annotations
from pathlib import Path
from unittest import mock
import yaml
from agent_shield_cli import main
from agent_shield.config import GuardrailsConfig
from .._support import MockLlmCaller, make_action
_command_smoke_VALID_YAML = yaml.safe_dump({'metadata': {'name': 'demo', 'version': '0.1.0', 'agent_shield_version': '2.0'}, 'objective': {'goal': ['help']}, 'resources': {'tools': [{'name': 'get_customer', 'permission': 'read_only'}, {'name': 'refund_order', 'permission': 'destructive'}]}, 'input_validation': {'guard_policies': [{'name': 'jailbreak', 'evaluate_when': [{'pattern': 'ignore.*instructions', 'reason': 'jb'}]}]}})

def _command_smoke_patch_builder(script):
    return mock.patch('agent_shield_cli.init._command.build_caller', return_value=MockLlmCaller(script=script))

def test_cli_non_interactive_writes_validated_yaml(tmp_path: Path, openai_tools_json: Path) -> None:
    out = tmp_path / '.guardrails.yaml'
    with _command_smoke_patch_builder([make_action('done', yaml=_command_smoke_VALID_YAML, summary='ok')]):
        rc = main(['init', '--provider', 'openai', '--model', 'gpt-5', '--api-key', 'test-key', '--describe', 'Customer support bot.', '--openai-tools', str(openai_tools_json), '--output', str(out), '--non-interactive'])
    assert rc == 0
    assert out.exists()
    compiled = GuardrailsConfig.load(str(out)).compile()
    _ = compiled._native_handle

def test_cli_requires_provider_and_model(tmp_path: Path, monkeypatch) -> None:
    for k in ('AGENT_SHIELD_PROVIDER', 'AGENT_SHIELD_MODEL', 'AZURE_OPENAI_ENDPOINT', 'AZURE_OPENAI_KEY', 'AZURE_OPENAI_API_KEY', 'AZURE_OPENAI_DEPLOYMENT', 'OPENAI_API_KEY', 'ANTHROPIC_API_KEY'):
        monkeypatch.delenv(k, raising=False)
    monkeypatch.setattr('agent_shield_cli.init._command.load_credentials_env', lambda _path: (None, []))
    rc = main(['init', '--non-interactive', '--describe', 'x', '--output', str(tmp_path / 'x.yaml')])
    assert rc == 2

def test_cli_non_interactive_requires_describe(tmp_path: Path) -> None:
    rc = main(['init', '--provider', 'openai', '--model', 'gpt-5', '--non-interactive', '--output', str(tmp_path / 'x.yaml')])
    assert rc == 2

def test_cli_dry_run_does_not_write(tmp_path: Path, capsys, openai_tools_json: Path) -> None:
    out = tmp_path / '.guardrails.yaml'
    with _command_smoke_patch_builder([make_action('done', yaml=_command_smoke_VALID_YAML, summary='ok')]):
        rc = main(['init', '--provider', 'openai', '--model', 'gpt-5', '--api-key', 'test-key', '--describe', 'x', '--openai-tools', str(openai_tools_json), '--output', str(out), '--non-interactive', '--dry-run'])
    assert rc == 0
    assert not out.exists()
    captured = capsys.readouterr()
    assert 'metadata:' in captured.out

def test_cli_refuses_overwrite_without_force(tmp_path: Path, openai_tools_json: Path) -> None:
    out = tmp_path / '.guardrails.yaml'
    out.write_text('existing: yes\n', encoding='utf-8')
    rc = main(['init', '--provider', 'openai', '--model', 'gpt-5', '--api-key', 'test-key', '--describe', 'x', '--openai-tools', str(openai_tools_json), '--output', str(out), '--non-interactive'])
    assert rc != 0
    assert out.read_text(encoding='utf-8') == 'existing: yes\n'

def test_cli_from_path_rejects_self_cycle(tmp_path: Path, openai_tools_json: Path) -> None:
    parent = tmp_path / 'policy.yaml'
    parent.write_text(yaml.safe_dump({'metadata': {'name': 'p', 'version': '0.1.0', 'agent_shield_version': '2.0'}, 'objective': {'goal': ['h']}}), encoding='utf-8')
    rc = main(['init', '--provider', 'openai', '--model', 'gpt-5', '--api-key', 'test-key', '--describe', 'x', '--openai-tools', str(openai_tools_json), '--from', str(parent), '--output', str(parent), '--non-interactive'])
    assert rc == 2

def test_cli_propagates_llm_error(tmp_path: Path, openai_tools_json: Path) -> None:
    from agent_shield_cli.init._llm import LlmError
    with mock.patch('agent_shield_cli.init._command.build_caller', side_effect=LlmError('the `openai` package is required')):
        rc = main(['init', '--provider', 'openai', '--model', 'gpt-5', '--describe', 'x', '--openai-tools', str(openai_tools_json), '--output', str(tmp_path / 'x.yaml'), '--non-interactive'])
    assert rc == 1

def test_cli_azure_provider_defaults_model_from_azure_openai_deployment(tmp_path: Path, openai_tools_json: Path, monkeypatch) -> None:
    out = tmp_path / '.guardrails.yaml'
    empty_env = tmp_path / 'empty.env'
    empty_env.write_text('')
    monkeypatch.setenv('AZURE_OPENAI_DEPLOYMENT', 'gpt-5.4-prod-deployment')
    monkeypatch.delenv('AGENT_SHIELD_MODEL', raising=False)
    monkeypatch.delenv('AGENT_SHIELD_PROVIDER', raising=False)
    captured: dict[str, object] = {}

    def fake_build(*, provider: str, model: str, api_key=None):
        captured['provider'] = provider
        captured['model'] = model
        return MockLlmCaller(script=[make_action('done', yaml=_command_smoke_VALID_YAML, summary='ok')])
    with mock.patch('agent_shield_cli.init._command.build_caller', side_effect=fake_build):
        rc = main(['init', '--provider', 'azure', '--api-key', 'test-key', '--env-file', str(empty_env), '--describe', 'Customer support bot.', '--openai-tools', str(openai_tools_json), '--output', str(out), '--non-interactive'])
    assert rc == 0, f'expected rc=0; captured={captured}'

def test_cli_azure_provider_without_deployment_env_still_fails(tmp_path: Path, openai_tools_json: Path, monkeypatch) -> None:
    empty_env = tmp_path / 'empty.env'
    empty_env.write_text('')
    monkeypatch.delenv('AGENT_SHIELD_MODEL', raising=False)
    monkeypatch.delenv('AGENT_SHIELD_PROVIDER', raising=False)
    monkeypatch.delenv('AZURE_OPENAI_DEPLOYMENT', raising=False)
    rc = main(['init', '--provider', 'azure', '--env-file', str(empty_env), '--describe', 'Customer support bot.', '--openai-tools', str(openai_tools_json), '--output', str(tmp_path / 'x.yaml'), '--non-interactive'])
    assert rc == 2

def test_cli_explicit_model_wins_over_azure_deployment(tmp_path: Path, openai_tools_json: Path, monkeypatch) -> None:
    out = tmp_path / '.guardrails.yaml'
    empty_env = tmp_path / 'empty.env'
    empty_env.write_text('')
    monkeypatch.setenv('AZURE_OPENAI_DEPLOYMENT', 'should-be-ignored')
    monkeypatch.delenv('AGENT_SHIELD_MODEL', raising=False)
    captured: dict[str, object] = {}

    def fake_build(*, provider: str, model: str, api_key=None):
        captured['model'] = model
        return MockLlmCaller(script=[make_action('done', yaml=_command_smoke_VALID_YAML, summary='ok')])
    with mock.patch('agent_shield_cli.init._command.build_caller', side_effect=fake_build):
        rc = main(['init', '--provider', 'azure', '--model', 'explicit-model', '--api-key', 'test-key', '--env-file', str(empty_env), '--describe', 'Customer support bot.', '--openai-tools', str(openai_tools_json), '--output', str(out), '--non-interactive'])
    assert rc == 0
    assert captured.get('model') == 'explicit-model'
from typing import List, Sequence, Union
import pytest
import yaml
from agent_shield_cli.init._llm import _base as _llm_base
_retry_draft_VALID_YAML = yaml.safe_dump({'metadata': {'name': 'demo', 'version': '0.1.0', 'agent_shield_version': '2.0'}, 'objective': {'goal': ['help']}, 'resources': {'tools': [{'name': 'get_customer', 'permission': 'read_only'}, {'name': 'refund_order', 'permission': 'destructive'}]}, 'input_validation': {'guard_policies': [{'name': 'jailbreak', 'evaluate_when': [{'pattern': 'ignore.*instructions', 'reason': 'jb'}]}]}})
_retry_draft_INVALID_YAML_TEXT = 'metadata:\n  name: bad\n  version: 0.1.0\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["test"]\ninput_validation:\n  guard_policies:\n    - name: bad\n      evaluate_when:\n        - pattern: "(?i)(ignore\\s+previous)"\n          reason: bad-escape\n'

class _retry_draft_Fake429(Exception):
    status_code = 429
    response = None

    def __str__(self) -> str:
        return f'HTTP {self.status_code} Too Many Requests'

def _retry_draft_wrapped_429() -> 'Exception':
    from agent_shield_cli.init._llm import LlmError
    return LlmError('Azure OpenAI request failed: HTTP 429 Too Many Requests', status_code=429)

class _retry_draft_Fake429WithRetryAfter(Exception):

    def __init__(self, retry_after: float) -> None:
        super().__init__('HTTP 429 Too Many Requests')
        self.status_code = 429

        class _Resp:

            def __init__(self, ra: float) -> None:
                self.status_code = 429
                self.headers = {'retry-after': str(ra)}
        self.response = _Resp(retry_after)

class _retry_draft_ScriptedExceptionCaller:

    def __init__(self, script: Sequence[Union[str, BaseException]]) -> None:
        self.script: List[Union[str, BaseException]] = list(script)
        self.cursor = 0
        self.name = 'scripted'
        self.model = 'scripted-1'

    def chat(self, messages):
        if self.cursor >= len(self.script):
            raise AssertionError(f'scripted caller ran out (turn {self.cursor + 1}); last roles: {[m.get("role") for m in messages[-3:]]}')
        entry = self.script[self.cursor]
        self.cursor += 1
        if isinstance(entry, BaseException):
            raise entry
        return entry

def test_backoff_retries_on_429_then_succeeds(monkeypatch) -> None:
    sleeps: List[float] = []
    monkeypatch.setattr(_llm_base, '_sleep', sleeps.append)
    call_count = {'n': 0}

    def call():
        call_count['n'] += 1
        if call_count['n'] == 1:
            raise _retry_draft_Fake429()
        return 'ok'
    out = _llm_base.chat_with_backoff(call)
    assert out == 'ok'
    assert sleeps == [1.0]
    assert call_count['n'] == 2

def test_backoff_honors_retry_after_header(monkeypatch) -> None:
    sleeps: List[float] = []
    monkeypatch.setattr(_llm_base, '_sleep', sleeps.append)
    call_count = {'n': 0}

    def call():
        call_count['n'] += 1
        if call_count['n'] == 1:
            raise _retry_draft_Fake429WithRetryAfter(7.0)
        return 'ok'
    _llm_base.chat_with_backoff(call)
    assert sleeps == [7.0]

def test_backoff_retry_after_ceiling(monkeypatch) -> None:
    sleeps: List[float] = []
    monkeypatch.setattr(_llm_base, '_sleep', sleeps.append)
    call_count = {'n': 0}

    def call():
        call_count['n'] += 1
        if call_count['n'] == 1:
            raise _retry_draft_Fake429WithRetryAfter(99999.0)
        return 'ok'
    _llm_base.chat_with_backoff(call)
    assert sleeps == [_llm_base._RETRY_AFTER_CEILING_S]

def test_backoff_gives_up_after_full_schedule(monkeypatch) -> None:
    sleeps: List[float] = []
    monkeypatch.setattr(_llm_base, '_sleep', sleeps.append)

    def call():
        raise _retry_draft_Fake429()
    with pytest.raises(_retry_draft_Fake429):
        _llm_base.chat_with_backoff(call)
    assert sleeps == [1.0, 2.0, 4.0, 8.0]

def test_backoff_does_not_retry_non_transient(monkeypatch) -> None:
    sleeps: List[float] = []
    monkeypatch.setattr(_llm_base, '_sleep', sleeps.append)

    class _Auth4xx(Exception):
        status_code = 401

    def call():
        raise _Auth4xx()
    with pytest.raises(_Auth4xx):
        _llm_base.chat_with_backoff(call)
    assert sleeps == []

def test_backoff_progress_callback_per_retry(monkeypatch) -> None:
    monkeypatch.setattr(_llm_base, '_sleep', lambda _s: None)
    seen: List[str] = []
    call_count = {'n': 0}

    def call():
        call_count['n'] += 1
        if call_count['n'] <= 2:
            raise _retry_draft_Fake429()
        return 'ok'
    _llm_base.chat_with_backoff(call, progress=seen.append)
    assert len(seen) == 2
    assert 'HTTP 429' in seen[0]
    assert 'retry 1/4' in seen[0]
    assert 'retry 2/4' in seen[1]

def test_backoff_env_override(monkeypatch) -> None:
    monkeypatch.setenv('AGENT_SHIELD_LLM_MAX_RETRIES', '2')
    sleeps: List[float] = []
    monkeypatch.setattr(_llm_base, '_sleep', sleeps.append)

    def call():
        raise _retry_draft_Fake429()
    with pytest.raises(_retry_draft_Fake429):
        _llm_base.chat_with_backoff(call)
    assert sleeps == [1.0, 2.0]

def _retry_draft_patch_builder(caller):
    return mock.patch('agent_shield_cli.init._command.build_caller', return_value=caller)

def test_failure_writes_invalid_yaml_as_draft_with_rate_limit_cause(tmp_path: Path, openai_tools_json: Path, monkeypatch) -> None:
    monkeypatch.setattr(_llm_base, '_sleep', lambda _s: None)
    caller = _retry_draft_ScriptedExceptionCaller(script=[make_action('done', yaml=_retry_draft_INVALID_YAML_TEXT, summary='oops'), _retry_draft_wrapped_429()])
    out = tmp_path / '.guardrails.yaml'
    with _retry_draft_patch_builder(caller):
        rc = main(['init', '--provider', 'openai', '--model', 'gpt-5', '--api-key', 'test-key', '--describe', 'x', '--openai-tools', str(openai_tools_json), '--output', str(out), '--non-interactive'])
    assert rc == 1
    assert not out.exists(), 'must not write final file on failure'
    draft = tmp_path / '.guardrails.yaml.draft'
    body = draft.read_text(encoding='utf-8')
    assert 'agent-shield init draft' in body
    assert 'failure_kind: rate_limit' in body
    assert '(?i)(ignore\\s+previous)' in body or 'ignore' in body

def test_failure_classification_distinguishes_rate_limit_from_validation(tmp_path: Path, openai_tools_json: Path, monkeypatch, capsys) -> None:
    monkeypatch.setattr(_llm_base, '_sleep', lambda _s: None)
    last_invalid = _retry_draft_INVALID_YAML_TEXT.replace('name: bad', 'name: still-bad')
    caller = MockLlmCaller(script=[make_action('done', yaml=_retry_draft_INVALID_YAML_TEXT, summary='v1'), make_action('done', yaml=last_invalid, summary='v2')])
    out = tmp_path / '.guardrails.yaml'
    with _retry_draft_patch_builder(caller):
        rc = main(['init', '--provider', 'openai', '--model', 'gpt-5', '--api-key', 'test-key', '--describe', 'x', '--openai-tools', str(openai_tools_json), '--output', str(out), '--non-interactive'])
    assert rc == 1
    err = capsys.readouterr().err
    assert 'cause: model could not produce' in err.lower() or 'validation' in err.lower()
    draft = tmp_path / '.guardrails.yaml.draft'
    assert draft.exists()
    body = draft.read_text(encoding='utf-8')
    assert 'failure_kind: validation_exhausted' in body
    assert 'name: still-bad' in body
    assert 'name: bad\n' not in body

def test_backoff_recovery_then_valid_yaml_writes_final_no_draft(tmp_path: Path, openai_tools_json: Path, monkeypatch) -> None:
    sleeps: List[float] = []
    monkeypatch.setattr(_llm_base, '_sleep', sleeps.append)
    from agent_shield_cli.init._llm._openai import OpenAiCaller

    class _Resp:

        def __init__(self, text: str) -> None:

            class _M:

                def __init__(self, t: str) -> None:
                    self.content = t

            class _C:

                def __init__(self, t: str) -> None:
                    self.message = _M(t)
            self.choices = [_C(text)]
    valid_action = make_action('done', yaml=_retry_draft_VALID_YAML, summary='ok')
    create_calls = {'n': 0}

    def fake_create(**kwargs):
        create_calls['n'] += 1
        if create_calls['n'] == 1:
            raise _retry_draft_Fake429()
        return _Resp(valid_action)
    caller = OpenAiCaller.__new__(OpenAiCaller)
    caller.model = 'gpt-5'
    caller.name = 'openai'

    class _Client:

        class chat:

            class completions:
                create = staticmethod(fake_create)
    caller._client = _Client()
    out = tmp_path / '.guardrails.yaml'
    with mock.patch('agent_shield_cli.init._command.build_caller', return_value=caller):
        rc = main(['init', '--provider', 'openai', '--model', 'gpt-5', '--api-key', 'test-key', '--describe', 'x', '--openai-tools', str(openai_tools_json), '--output', str(out), '--non-interactive'])
    assert rc == 0, f'expected success after provider-level backoff; sleeps={sleeps}'
    assert out.exists()
    assert sleeps == [1.0], 'backoff must sleep the first schedule delay'
    assert create_calls['n'] == 2, 'should have retried exactly once'
    draft = tmp_path / '.guardrails.yaml.draft'
    assert not draft.exists(), 'no draft when the final file was written'

def test_dry_run_failure_prints_draft_to_stderr_no_file(tmp_path: Path, openai_tools_json: Path, monkeypatch, capsys) -> None:
    monkeypatch.setattr(_llm_base, '_sleep', lambda _s: None)
    caller = MockLlmCaller(script=[make_action('done', yaml=_retry_draft_INVALID_YAML_TEXT, summary='v1'), make_action('done', yaml=_retry_draft_INVALID_YAML_TEXT, summary='v2')])
    out = tmp_path / '.guardrails.yaml'
    with _retry_draft_patch_builder(caller):
        rc = main(['init', '--provider', 'openai', '--model', 'gpt-5', '--api-key', 'test-key', '--describe', 'x', '--openai-tools', str(openai_tools_json), '--output', str(out), '--non-interactive', '--dry-run'])
    assert rc == 1
    assert not (tmp_path / '.guardrails.yaml.draft').exists()
    err = capsys.readouterr().err
    assert '--- BEGIN DRAFT ---' in err
    assert '--- END DRAFT ---' in err

def test_draft_write_failure_falls_back_to_stderr(tmp_path: Path, openai_tools_json: Path, monkeypatch, capsys) -> None:
    monkeypatch.setattr(_llm_base, '_sleep', lambda _s: None)
    caller = MockLlmCaller(script=[make_action('done', yaml=_retry_draft_INVALID_YAML_TEXT, summary='v1'), make_action('done', yaml=_retry_draft_INVALID_YAML_TEXT, summary='v2')])
    out = tmp_path / '.guardrails.yaml'
    real_open = open

    def boom_open(path, *args, **kwargs):
        if str(path).endswith('.draft'):
            raise OSError('simulated disk-full')
        return real_open(path, *args, **kwargs)
    with _retry_draft_patch_builder(caller), mock.patch('agent_shield_cli.init._command.open', boom_open, create=True):
        rc = main(['init', '--provider', 'openai', '--model', 'gpt-5', '--api-key', 'test-key', '--describe', 'x', '--openai-tools', str(openai_tools_json), '--output', str(out), '--non-interactive'])
    assert rc == 1
    err = capsys.readouterr().err
    assert 'could not write draft' in err
    assert '--- BEGIN DRAFT ---' in err
    assert '--- END DRAFT ---' in err

def test_no_draft_when_model_emitted_no_yaml(tmp_path: Path, openai_tools_json: Path, monkeypatch, capsys) -> None:
    monkeypatch.setattr(_llm_base, '_sleep', lambda _s: None)
    asks = [make_action('ask', question='?') for _ in range(5)]
    caller = MockLlmCaller(script=asks)
    out = tmp_path / '.guardrails.yaml'
    with _retry_draft_patch_builder(caller):
        rc = main(['init', '--provider', 'openai', '--model', 'gpt-5', '--api-key', 'test-key', '--describe', 'x', '--openai-tools', str(openai_tools_json), '--output', str(out), '--non-interactive', '--max-turns', '3'])
    assert rc == 1
    assert not (tmp_path / '.guardrails.yaml.draft').exists()
    err = capsys.readouterr().err
    assert 'no draft to save' in err

def test_classify_recognises_typed_status_code() -> None:
    exc = _retry_draft_Fake429()
    status, retry_after = _llm_base.classify_http_exception(exc)
    assert status == 429
    assert retry_after is None

def test_classify_recognises_5xx() -> None:

    class _5xx(Exception):
        status_code = 503
    status, retry_after = _llm_base.classify_http_exception(_5xx())
    assert status == 503
    assert retry_after is None

def test_classify_rejects_non_transient_4xx() -> None:

    class _Auth(Exception):
        status_code = 401
    status, _ = _llm_base.classify_http_exception(_Auth())
    assert status is None

def test_classify_string_fallback() -> None:
    exc = RuntimeError('upstream said: error code: 429 Too Many Requests')
    status, _ = _llm_base.classify_http_exception(exc)
    assert status == 429
import re
import yaml
_done_retry_VALID_YAML = yaml.safe_dump({'metadata': {'name': 'demo', 'version': '0.1.0', 'agent_shield_version': '2.0'}, 'objective': {'goal': ['help']}, 'resources': {'tools': [{'name': 'get_customer', 'permission': 'read_only'}]}})
_done_retry_INVALID_YAML = yaml.safe_dump({'metadata': {'name': 'demo', 'version': '0.1.0', 'agent_shield_version': '2.0'}, 'objective': {'goal': ['help']}, 'resources': {'tools': [{'name': True, 'permission': 'read_only'}]}})

def _done_retry_patch_builder(script):
    return mock.patch('agent_shield_cli.init._command.build_caller', return_value=MockLlmCaller(script=script))

def _done_retry_run_init(tmp_path: Path, openai_tools_json: Path, script) -> tuple[int, str, Path]:
    out = tmp_path / '.guardrails.yaml'
    with _done_retry_patch_builder(script):
        rc = main(['init', '--provider', 'openai', '--model', 'gpt-5', '--api-key', 'test-key', '--describe', 'Customer support bot.', '--openai-tools', str(openai_tools_json), '--output', str(out), '--non-interactive'])
    return (rc, out)

def test_done_retry_success_emits_no_top_level_failure_marker(tmp_path: Path, capsys, openai_tools_json: Path) -> None:
    rc, out = _done_retry_run_init(tmp_path, openai_tools_json, [make_action('done', yaml=_done_retry_INVALID_YAML, summary='oops'), make_action('done', yaml=_done_retry_VALID_YAML, summary='fixed')])
    assert rc == 0, 'self-correct succeeded; CLI must exit 0'
    assert out.exists(), 'final valid file must land at the intended path'
    captured = capsys.readouterr()
    combined = captured.out + captured.err
    top_level_x = re.search('(?m)^✗', combined)
    assert top_level_x is None, 'top-level ✗ failure marker must not appear before a successful write; combined stdout+stderr was:\n' + combined
    assert '✔ wrote' in captured.err, 'successful write line missing'

def test_done_retry_success_intermediate_notice_is_indented(tmp_path: Path, capsys, openai_tools_json: Path) -> None:
    rc, _ = _done_retry_run_init(tmp_path, openai_tools_json, [make_action('done', yaml=_done_retry_INVALID_YAML, summary='oops'), make_action('done', yaml=_done_retry_VALID_YAML, summary='fixed')])
    assert rc == 0
    captured = capsys.readouterr()
    stdout = captured.out
    assert re.search('(?m)^  ✗ done payload did not validate', stdout), f'expected indented self-correct notice for the failed first done.\nstdout was:\n{stdout}'

def test_done_retry_exhausted_exits_nonzero_and_writes_draft(tmp_path: Path, capsys, openai_tools_json: Path) -> None:
    rc, out = _done_retry_run_init(tmp_path, openai_tools_json, [make_action('done', yaml=_done_retry_INVALID_YAML, summary='first try'), make_action('done', yaml=_done_retry_INVALID_YAML, summary='still wrong')])
    assert rc != 0, 'final validation failure must yield non-zero exit'
    assert not out.exists(), 'invalid YAML must not land at the intended path'
    draft = out.with_suffix(out.suffix + '.draft')
    body = draft.read_text(encoding='utf-8')
    assert 'permission: read_only' in body
    stderr = capsys.readouterr().err
    assert '✗ aborted:' in stderr
    assert 'schema-valid YAML' in stderr
    assert '✔ wrote' not in stderr
