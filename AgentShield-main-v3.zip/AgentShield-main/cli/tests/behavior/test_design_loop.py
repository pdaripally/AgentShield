from __future__ import annotations
from collections import deque
from typing import Deque, List
import yaml
from agent_shield_cli.init._design_agent import run_design_loop
from .._support import MockLlmCaller, make_action
_design_agent_MINIMAL_VALID_YAML = yaml.safe_dump({'metadata': {'name': 'p', 'version': '0.1.0', 'agent_shield_version': '2.0'}, 'objective': {'goal': ['test']}, 'input_validation': {'guard_policies': [{'name': 'j', 'evaluate_when': [{'pattern': 'ignore.*instructions', 'reason': 'jb'}]}]}})
_design_agent_INVALID_YAML = yaml.safe_dump({'metadata': {'name': 'p', 'version': '0.1.0', 'agent_shield_version': '2.0'}, 'objective': {'goal': ['t']}, 'state_validation': {'guard_policies': [{'name': 'bad', 'reason': 'no applies_to'}]}})

def _design_agent_io_pair(inputs: List[str]) -> tuple:
    q: Deque[str] = deque(inputs)
    captured: List[str] = []

    def in_fn(prompt: str) -> str:
        if not q:
            return ''
        return q.popleft()

    def out_fn(text: str) -> None:
        captured.append(text)
    return (in_fn, out_fn, captured)

def test_happy_path_non_interactive() -> None:
    caller = MockLlmCaller(script=[make_action('done', yaml=_design_agent_MINIMAL_VALID_YAML, summary='ok')])
    in_fn, out_fn, _ = _design_agent_io_pair([])
    result = run_design_loop(caller=caller, system_prompt='<system>', non_interactive=True, input_fn=in_fn, output_fn=out_fn)
    assert result.final_yaml is not None
    assert not result.aborted
    assert result.final_data['metadata']['name'] == 'p'

def test_happy_path_with_ask_propose_done() -> None:
    caller = MockLlmCaller(script=[make_action('ask', question='What domain?'), make_action('propose', yaml=_design_agent_MINIMAL_VALID_YAML, explanation='Initial draft.'), make_action('done', yaml=_design_agent_MINIMAL_VALID_YAML, summary='shipped')])
    in_fn, out_fn, captured = _design_agent_io_pair(['banking support', 'a'])
    result = run_design_loop(caller=caller, system_prompt='<system>', input_fn=in_fn, output_fn=out_fn)
    assert result.final_yaml is not None
    assert result.turns == 3
    assert any(('```yaml' in c for c in captured))
    assert caller.cursor == 3

def test_self_correct_recovers_after_one_validation_failure() -> None:
    caller = MockLlmCaller(script=[make_action('propose', yaml=_design_agent_INVALID_YAML, explanation='bad first'), make_action('propose', yaml=_design_agent_MINIMAL_VALID_YAML, explanation='fixed'), make_action('done', yaml=_design_agent_MINIMAL_VALID_YAML, summary='ok')])
    in_fn, out_fn, captured = _design_agent_io_pair(['a'])
    result = run_design_loop(caller=caller, system_prompt='<system>', input_fn=in_fn, output_fn=out_fn)
    assert result.final_yaml is not None
    assert any(('validation attempt 1' in c for c in captured))

def test_three_strikes_falls_to_user_fallback() -> None:
    caller = MockLlmCaller(script=[make_action('propose', yaml=_design_agent_INVALID_YAML, explanation='bad'), make_action('propose', yaml=_design_agent_INVALID_YAML, explanation='still bad'), make_action('propose', yaml=_design_agent_INVALID_YAML, explanation='still bad'), make_action('done', yaml=_design_agent_INVALID_YAML, summary='giving up')])
    in_fn, out_fn, captured = _design_agent_io_pair(['abort'])
    result = run_design_loop(caller=caller, system_prompt='<system>', input_fn=in_fn, output_fn=out_fn)
    assert result.aborted
    assert 'invalid' in result.abort_reason or 'abort' in result.abort_reason.lower()

def test_skip_proposal_moves_on() -> None:
    caller = MockLlmCaller(script=[make_action('propose', yaml=_design_agent_MINIMAL_VALID_YAML, explanation='A'), make_action('done', yaml=_design_agent_MINIMAL_VALID_YAML, summary='ok')])
    in_fn, out_fn, _ = _design_agent_io_pair(['s'])
    result = run_design_loop(caller=caller, system_prompt='<system>', input_fn=in_fn, output_fn=out_fn)
    assert result.final_yaml is not None

def test_refine_passes_user_feedback_to_model() -> None:
    caller = MockLlmCaller(script=[make_action('propose', yaml=_design_agent_MINIMAL_VALID_YAML, explanation='A'), make_action('done', yaml=_design_agent_MINIMAL_VALID_YAML, summary='ok')])
    feedback_text = 'add a Stage 4 PII redaction policy'
    in_fn, out_fn, _ = _design_agent_io_pair(['r', feedback_text])
    result = run_design_loop(caller=caller, system_prompt='<system>', input_fn=in_fn, output_fn=out_fn)
    assert result.final_yaml is not None
    assert not result.aborted
    feedback_seen = any((entry.get('last_user_content') and feedback_text in entry['last_user_content'] for entry in caller.transcript))
    assert feedback_seen, f'User feedback {feedback_text!r} was not found in any LLM call; transcript: {caller.transcript}'

def test_invalid_json_is_recovered_by_retry_prompt() -> None:
    caller = MockLlmCaller(script=['this is just text, not JSON', make_action('done', yaml=_design_agent_MINIMAL_VALID_YAML, summary='ok')])
    in_fn, out_fn, _ = _design_agent_io_pair([])
    result = run_design_loop(caller=caller, system_prompt='<system>', non_interactive=True, input_fn=in_fn, output_fn=out_fn)
    assert result.final_yaml is not None

def test_max_turns_caps_runaway() -> None:
    script = [make_action('ask', question=f'q{i}?') for i in range(10)]
    caller = MockLlmCaller(script=script)
    in_fn, out_fn, _ = _design_agent_io_pair(['answer'] * 10)
    result = run_design_loop(caller=caller, system_prompt='<system>', max_turns=5, input_fn=in_fn, output_fn=out_fn)
    assert result.aborted
    assert 'max_turns' in result.abort_reason

def test_non_interactive_rejects_ask() -> None:
    caller = MockLlmCaller(script=[make_action('ask', question='what?'), make_action('done', yaml=_design_agent_MINIMAL_VALID_YAML, summary='ok')])
    in_fn, out_fn, _ = _design_agent_io_pair([])
    result = run_design_loop(caller=caller, system_prompt='<system>', non_interactive=True, input_fn=in_fn, output_fn=out_fn)
    assert result.final_yaml is not None
    assert caller.cursor == 2
from pathlib import Path
import yaml
from agent_shield.config import GuardrailsConfig
_extends_budget_VALID_CHILD_NO_EXTENDS = yaml.safe_dump({'metadata': {'name': 'c', 'version': '0.1.0', 'agent_shield_version': '2.0'}, 'objective': {'goal': ['help']}})

def _extends_budget_make_parent(tmp_path: Path) -> Path:
    p = tmp_path / 'parent.yaml'
    p.write_text(yaml.safe_dump({'metadata': {'name': 'p', 'version': '0.1.0', 'agent_shield_version': '2.0'}, 'objective': {'goal': ['help']}, 'input_validation': {'guard_policies': [{'name': 'parent_jb', 'evaluate_when': [{'pattern': 'evil', 'reason': 'parent guard'}]}]}}), encoding='utf-8')
    return p

def test_extends_is_injected_when_parent_present(tmp_path: Path) -> None:
    parent = _extends_budget_make_parent(tmp_path)
    caller = MockLlmCaller(script=[make_action('done', yaml=_extends_budget_VALID_CHILD_NO_EXTENDS, summary='ok')])
    result = run_design_loop(caller=caller, system_prompt='<system>', parent_path=parent, non_interactive=True)
    assert result.final_data is not None
    extends = result.final_data.get('extends')
    assert isinstance(extends, list) and len(extends) == 1
    assert Path(extends[0]).resolve() == parent.resolve()

def test_extends_overrides_bad_model_extends(tmp_path: Path) -> None:
    parent = _extends_budget_make_parent(tmp_path)
    bad_extends_yaml = yaml.safe_dump({'extends': ['/some/wrong/path.yaml'], 'metadata': {'name': 'c', 'version': '0.1.0', 'agent_shield_version': '2.0'}, 'objective': {'goal': ['help']}})
    caller = MockLlmCaller(script=[make_action('done', yaml=bad_extends_yaml, summary='ok')])
    result = run_design_loop(caller=caller, system_prompt='<system>', parent_path=parent, non_interactive=True)
    assert result.final_data is not None
    extends = result.final_data['extends']
    assert len(extends) == 1
    assert Path(extends[0]).resolve() == parent.resolve()

def test_max_turns_caps_self_correct_loop() -> None:
    _INVALID_YAML = yaml.safe_dump({'metadata': {'name': 'p', 'version': '0.1.0', 'agent_shield_version': '2.0'}, 'objective': {'goal': ['help']}, 'state_validation': {'guard_policies': [{'name': 'bad', 'reason': 'missing applies_to'}]}})
    caller = MockLlmCaller(script=[make_action('propose', yaml=_INVALID_YAML, explanation='bad'), make_action('propose', yaml=_INVALID_YAML, explanation='bad'), make_action('propose', yaml=_INVALID_YAML, explanation='bad')])
    result = run_design_loop(caller=caller, system_prompt='<system>', max_turns=1, non_interactive=True)
    assert result.aborted
    assert caller.cursor == 1
    assert 'max_turns' in result.abort_reason

def test_post_write_layered_config_compiles(tmp_path: Path) -> None:
    from agent_shield_cli.init._emit import emit_yaml
    parent = _extends_budget_make_parent(tmp_path)
    caller = MockLlmCaller(script=[make_action('done', yaml=_extends_budget_VALID_CHILD_NO_EXTENDS, summary='ok')])
    result = run_design_loop(caller=caller, system_prompt='<system>', parent_path=parent, non_interactive=True)
    assert result.final_data is not None
    import os
    rel = os.path.relpath(parent.resolve(), start=tmp_path.resolve()).replace(os.sep, '/')
    result.final_data['extends'] = [rel]
    out = tmp_path / 'child.yaml'
    out.write_text(emit_yaml(result.final_data), encoding='utf-8')
    compiled = GuardrailsConfig.load(str(out)).compile()
    _ = compiled._native_handle
    child_text = out.read_text(encoding='utf-8')
    assert 'extends:' in child_text
    assert 'parent.yaml' in child_text
