from __future__ import annotations
import argparse
from pathlib import Path
import pytest
from agent_shield_cli.init._command import add_init_parser

def _init_parser_build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog='agent-shield')
    subparsers = parser.add_subparsers(dest='command')
    add_init_parser(subparsers)
    return parser

def test_init_parser_accepts_tool_schema_path():
    parser = _init_parser_build_parser()
    args = parser.parse_args(['init', '--tool-schema', 'x.json', '--non-interactive'])
    assert args.tool_schema == Path('x.json')
    assert args.tool_schema_inline is None
    assert args.endpoint == []

def test_init_parser_accepts_tool_schema_inline():
    parser = _init_parser_build_parser()
    args = parser.parse_args(['init', '--tool-schema-inline', '{"foo": "bar"}', '--non-interactive'])
    assert args.tool_schema_inline == '{"foo": "bar"}'
    assert args.tool_schema is None

def test_init_parser_accepts_single_endpoint():
    parser = _init_parser_build_parser()
    args = parser.parse_args(['init', '--endpoint', 'https://kyc.contoso.com/v1', '--non-interactive'])
    assert args.endpoint == ['https://kyc.contoso.com/v1']

def test_init_parser_endpoint_is_repeatable():
    parser = _init_parser_build_parser()
    args = parser.parse_args(['init', '--endpoint', 'kyc.contoso.com', '--endpoint', 'audit.northwind.invalid', '--non-interactive'])
    assert args.endpoint == ['kyc.contoso.com', 'audit.northwind.invalid']

def test_init_parser_accepts_all_three_together():
    parser = _init_parser_build_parser()
    args = parser.parse_args(['init', '--tool-schema', 'schema.json', '--tool-schema-inline', '{}', '--endpoint', 'h1', '--endpoint', 'h2', '--describe', 'demo agent', '--non-interactive', '--dry-run'])
    assert args.tool_schema == Path('schema.json')
    assert args.tool_schema_inline == '{}'
    assert args.endpoint == ['h1', 'h2']
    assert args.describe == 'demo agent'
    assert args.non_interactive is True
    assert args.dry_run is True

def test_init_parser_defaults_when_flags_absent():
    parser = _init_parser_build_parser()
    args = parser.parse_args(['init', '--non-interactive'])
    assert args.tool_schema is None
    assert args.tool_schema_inline is None
    assert args.endpoint == []

def test_init_parser_rejects_unknown_flag():
    parser = _init_parser_build_parser()
    with pytest.raises(SystemExit):
        parser.parse_args(['init', '--nope', 'x'])
import os
from typing import Iterator
from unittest import mock
from agent_shield_cli import main
from agent_shield_cli.init._dotenv import _ALLOWED_KEYS, discover_env_file, load_credentials_env

@pytest.fixture
def clean_env(monkeypatch: pytest.MonkeyPatch) -> Iterator[dict]:
    env: dict = {}
    yield env

def test_loader_parses_simple_keys(tmp_path: Path, clean_env: dict) -> None:
    envfile = tmp_path / '.env'
    envfile.write_text('AZURE_OPENAI_API_KEY=top-secret\nAZURE_OPENAI_ENDPOINT=https://example.openai.azure.com\nOPENAI_API_KEY=sk-test\n', encoding='utf-8')
    path, keys = load_credentials_env(envfile, environ=clean_env)
    assert path == envfile
    assert set(keys) == {'AZURE_OPENAI_API_KEY', 'AZURE_OPENAI_ENDPOINT', 'OPENAI_API_KEY'}
    assert clean_env['AZURE_OPENAI_API_KEY'] == 'top-secret'
    assert clean_env['OPENAI_API_KEY'] == 'sk-test'

def test_loader_handles_quotes_and_export_prefix(tmp_path: Path, clean_env: dict) -> None:
    envfile = tmp_path / '.env'
    envfile.write_text('# header comment\n\nexport AZURE_OPENAI_API_KEY="quoted-value"\nANTHROPIC_API_KEY=\'single-quoted\'\n', encoding='utf-8')
    _, keys = load_credentials_env(envfile, environ=clean_env)
    assert clean_env['AZURE_OPENAI_API_KEY'] == 'quoted-value'
    assert clean_env['ANTHROPIC_API_KEY'] == 'single-quoted'
    assert set(keys) == {'AZURE_OPENAI_API_KEY', 'ANTHROPIC_API_KEY'}

def test_loader_never_overwrites_existing_env(tmp_path: Path, clean_env: dict) -> None:
    envfile = tmp_path / '.env'
    envfile.write_text('AZURE_OPENAI_API_KEY=from-file\n', encoding='utf-8')
    clean_env['AZURE_OPENAI_API_KEY'] = 'from-shell'
    path, keys = load_credentials_env(envfile, environ=clean_env)
    assert path == envfile
    assert clean_env['AZURE_OPENAI_API_KEY'] == 'from-shell'
    assert keys == []

def test_loader_drops_unallowed_keys(tmp_path: Path, clean_env: dict) -> None:
    envfile = tmp_path / '.env'
    envfile.write_text('AZURE_OPENAI_API_KEY=ok\nDATABASE_URL=postgres://example\nPRIVATE_SSH_KEY=should-not-leak\n', encoding='utf-8')
    _, keys = load_credentials_env(envfile, environ=clean_env)
    assert 'AZURE_OPENAI_API_KEY' in clean_env
    assert 'DATABASE_URL' not in clean_env
    assert 'PRIVATE_SSH_KEY' not in clean_env
    assert set(keys) <= _ALLOWED_KEYS

def test_loader_silent_when_no_env_anywhere(tmp_path: Path, clean_env: dict) -> None:
    path, keys = load_credentials_env(None, cwd=tmp_path, environ=clean_env)
    assert path is None
    assert keys == []
    assert clean_env == {}

def test_loader_explicit_missing_file_raises(tmp_path: Path, clean_env: dict) -> None:
    missing = tmp_path / 'absent.env'
    with pytest.raises(FileNotFoundError):
        load_credentials_env(missing, environ=clean_env)

def test_discover_prefers_cwd_then_git_root(tmp_path: Path) -> None:
    root = tmp_path / 'repo'
    (root / '.git').mkdir(parents=True)
    sub = root / 'src'
    sub.mkdir()
    root_env = root / '.env'
    root_env.write_text('AZURE_OPENAI_API_KEY=root\n', encoding='utf-8')
    assert discover_env_file(None, cwd=sub) == root_env
    sub_env = sub / '.env'
    sub_env.write_text('AZURE_OPENAI_API_KEY=sub\n', encoding='utf-8')
    assert discover_env_file(None, cwd=sub) == sub_env

def test_loader_silently_skips_malformed_lines(tmp_path: Path, clean_env: dict) -> None:
    envfile = tmp_path / '.env'
    envfile.write_text('this is not a kv line\n=missing-key\nAZURE_OPENAI_API_KEY=good\nANOTHER=ok-but-not-allowed\n', encoding='utf-8')
    _, keys = load_credentials_env(envfile, environ=clean_env)
    assert clean_env == {'AZURE_OPENAI_API_KEY': 'good'}
    assert keys == ['AZURE_OPENAI_API_KEY']

def _dotenv_patch_builder_observe(captured: dict):

    def fake_build_caller(*, provider: str, model: str, api_key=None):
        captured['AZURE_OPENAI_API_KEY'] = os.environ.get('AZURE_OPENAI_API_KEY')
        captured['AZURE_OPENAI_ENDPOINT'] = os.environ.get('AZURE_OPENAI_ENDPOINT')
        captured['api_key_arg'] = api_key
        from agent_shield_cli.init._llm import LlmError
        raise LlmError('stopped after credential check (test stub)')
    return mock.patch('agent_shield_cli.init._command.build_caller', side_effect=fake_build_caller)

def test_cli_autoloads_env_from_cwd(tmp_path: Path, openai_tools_json: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv('AZURE_OPENAI_API_KEY', raising=False)
    monkeypatch.delenv('AZURE_OPENAI_ENDPOINT', raising=False)
    monkeypatch.chdir(tmp_path)
    (tmp_path / '.env').write_text('AZURE_OPENAI_API_KEY=loaded-from-cwd-env\nAZURE_OPENAI_ENDPOINT=https://example.openai.azure.com\n', encoding='utf-8')
    captured: dict = {}
    with _dotenv_patch_builder_observe(captured):
        rc = main(['init', '--provider', 'azure', '--model', 'gpt-5', '--describe', 'demo', '--openai-tools', str(openai_tools_json), '--output', str(tmp_path / '.guardrails.yaml'), '--non-interactive'])
    assert rc == 1
    assert captured['AZURE_OPENAI_API_KEY'] == 'loaded-from-cwd-env'
    assert captured['AZURE_OPENAI_ENDPOINT'] == 'https://example.openai.azure.com'

def test_cli_does_not_overwrite_preset_env(tmp_path: Path, openai_tools_json: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv('AZURE_OPENAI_API_KEY', 'preset-by-shell')
    monkeypatch.delenv('AZURE_OPENAI_ENDPOINT', raising=False)
    monkeypatch.chdir(tmp_path)
    (tmp_path / '.env').write_text('AZURE_OPENAI_API_KEY=loaded-from-file\n', encoding='utf-8')
    captured: dict = {}
    with _dotenv_patch_builder_observe(captured):
        main(['init', '--provider', 'azure', '--model', 'gpt-5', '--describe', 'demo', '--openai-tools', str(openai_tools_json), '--output', str(tmp_path / '.guardrails.yaml'), '--non-interactive'])
    assert captured['AZURE_OPENAI_API_KEY'] == 'preset-by-shell'

def test_cli_explicit_env_file_takes_precedence(tmp_path: Path, openai_tools_json: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv('AZURE_OPENAI_API_KEY', raising=False)
    monkeypatch.chdir(tmp_path)
    (tmp_path / '.env').write_text('AZURE_OPENAI_API_KEY=from-cwd\n', encoding='utf-8')
    explicit = tmp_path / 'creds.env'
    explicit.write_text('AZURE_OPENAI_API_KEY=from-explicit\n', encoding='utf-8')
    captured: dict = {}
    with _dotenv_patch_builder_observe(captured):
        main(['init', '--provider', 'azure', '--model', 'gpt-5', '--describe', 'demo', '--openai-tools', str(openai_tools_json), '--output', str(tmp_path / '.guardrails.yaml'), '--non-interactive', '--env-file', str(explicit)])
    assert captured['AZURE_OPENAI_API_KEY'] == 'from-explicit'

def test_cli_missing_explicit_env_file_errors(tmp_path: Path, openai_tools_json: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv('AZURE_OPENAI_API_KEY', raising=False)
    monkeypatch.chdir(tmp_path)
    rc = main(['init', '--provider', 'azure', '--model', 'gpt-5', '--describe', 'demo', '--openai-tools', str(openai_tools_json), '--output', str(tmp_path / '.guardrails.yaml'), '--non-interactive', '--env-file', str(tmp_path / 'missing.env')])
    assert rc == 1
import pytest
from agent_shield_cli.init._command import InferredProvider, infer_provider_from_env

def _provider_inference_clear_provider_env(monkeypatch: pytest.MonkeyPatch) -> None:
    for k in ('AZURE_OPENAI_ENDPOINT', 'AZURE_OPENAI_KEY', 'AZURE_OPENAI_API_KEY', 'AZURE_OPENAI_DEPLOYMENT', 'OPENAI_API_KEY', 'ANTHROPIC_API_KEY', 'AGENT_SHIELD_PROVIDER', 'AGENT_SHIELD_MODEL'):
        monkeypatch.delenv(k, raising=False)

def test_azure_openai_triple_infers_azure_provider(monkeypatch: pytest.MonkeyPatch) -> None:
    _provider_inference_clear_provider_env(monkeypatch)
    monkeypatch.setenv('AZURE_OPENAI_ENDPOINT', 'https://example.openai.azure.com')
    monkeypatch.setenv('AZURE_OPENAI_KEY', 'k')
    monkeypatch.setenv('AZURE_OPENAI_DEPLOYMENT', 'gpt-4.1-mini')
    inferred = infer_provider_from_env(provider=None, model=None)
    assert inferred is not None
    assert inferred.provider == 'azure'
    assert inferred.model == 'gpt-4.1-mini'

def test_azure_openai_triple_accepts_api_key_alias(monkeypatch: pytest.MonkeyPatch) -> None:
    _provider_inference_clear_provider_env(monkeypatch)
    monkeypatch.setenv('AZURE_OPENAI_ENDPOINT', 'https://example.openai.azure.com')
    monkeypatch.setenv('AZURE_OPENAI_API_KEY', 'k')
    monkeypatch.setenv('AZURE_OPENAI_DEPLOYMENT', 'gpt-4.1-mini')
    inferred = infer_provider_from_env(provider=None, model=None)
    assert inferred is not None
    assert inferred.provider == 'azure'
    assert inferred.model == 'gpt-4.1-mini'

def test_azure_partial_triple_does_not_infer(monkeypatch: pytest.MonkeyPatch) -> None:
    _provider_inference_clear_provider_env(monkeypatch)
    monkeypatch.setenv('AZURE_OPENAI_ENDPOINT', 'https://example.openai.azure.com')
    assert infer_provider_from_env(provider=None, model=None) is None

def test_openai_key_infers_openai(monkeypatch: pytest.MonkeyPatch) -> None:
    _provider_inference_clear_provider_env(monkeypatch)
    monkeypatch.setenv('OPENAI_API_KEY', 'k')
    inferred = infer_provider_from_env(provider=None, model=None)
    assert inferred is not None
    assert inferred.provider == 'openai'
    assert inferred.model is None

def test_anthropic_key_infers_anthropic(monkeypatch: pytest.MonkeyPatch) -> None:
    _provider_inference_clear_provider_env(monkeypatch)
    monkeypatch.setenv('ANTHROPIC_API_KEY', 'k')
    inferred = infer_provider_from_env(provider=None, model=None)
    assert inferred is not None
    assert inferred.provider == 'anthropic'
    assert inferred.model is None

def test_azure_triple_wins_over_anthropic_key(monkeypatch: pytest.MonkeyPatch) -> None:
    _provider_inference_clear_provider_env(monkeypatch)
    monkeypatch.setenv('AZURE_OPENAI_ENDPOINT', 'https://example.openai.azure.com')
    monkeypatch.setenv('AZURE_OPENAI_KEY', 'k')
    monkeypatch.setenv('AZURE_OPENAI_DEPLOYMENT', 'gpt-4.1-mini')
    monkeypatch.setenv('ANTHROPIC_API_KEY', 'ak')
    monkeypatch.setenv('OPENAI_API_KEY', 'ok')
    inferred = infer_provider_from_env(provider=None, model=None)
    assert inferred is not None
    assert inferred.provider == 'azure'
    assert inferred.model == 'gpt-4.1-mini'

def test_openai_wins_over_anthropic_when_both_keys_present(monkeypatch: pytest.MonkeyPatch) -> None:
    _provider_inference_clear_provider_env(monkeypatch)
    monkeypatch.setenv('OPENAI_API_KEY', 'ok')
    monkeypatch.setenv('ANTHROPIC_API_KEY', 'ak')
    inferred = infer_provider_from_env(provider=None, model=None)
    assert inferred is not None
    assert inferred.provider == 'openai'

def test_explicit_provider_overrides_inference(monkeypatch: pytest.MonkeyPatch) -> None:
    _provider_inference_clear_provider_env(monkeypatch)
    monkeypatch.setenv('AZURE_OPENAI_ENDPOINT', 'https://example.openai.azure.com')
    monkeypatch.setenv('AZURE_OPENAI_KEY', 'k')
    monkeypatch.setenv('AZURE_OPENAI_DEPLOYMENT', 'gpt-4.1-mini')
    assert infer_provider_from_env(provider='openai', model=None) is None

def test_no_inferable_env_returns_none(monkeypatch: pytest.MonkeyPatch) -> None:
    _provider_inference_clear_provider_env(monkeypatch)
    assert infer_provider_from_env(provider=None, model=None) is None

def test_inferred_provider_is_frozen_dataclass() -> None:
    p = InferredProvider(provider='azure', model='gpt-4.1-mini')
    with pytest.raises(Exception):
        p.provider = 'openai'

def test_run_init_uses_inferred_provider_when_flag_absent(monkeypatch: pytest.MonkeyPatch, tmp_path) -> None:
    _provider_inference_clear_provider_env(monkeypatch)
    monkeypatch.setenv('AZURE_OPENAI_ENDPOINT', 'https://example.openai.azure.com')
    monkeypatch.setenv('AZURE_OPENAI_KEY', 'k')
    monkeypatch.setenv('AZURE_OPENAI_DEPLOYMENT', 'gpt-4.1-mini')
    monkeypatch.delenv('AGENT_SHIELD_PROVIDER', raising=False)
    monkeypatch.delenv('AGENT_SHIELD_MODEL', raising=False)
    captured: dict = {}

    def _fake_caller(*, provider, model, api_key):
        captured['provider'] = provider
        captured['model'] = model
        from agent_shield_cli.init._llm import LlmError
        raise LlmError('stub-caller-stop')
    monkeypatch.setattr('agent_shield_cli.init._command.build_caller', _fake_caller)
    import argparse
    from agent_shield_cli.init._command import run_init
    args = argparse.Namespace(output=tmp_path / 'out.yaml', describe='Healthcare patient-intake assistant.', mcp=[], openai_tools=None, anthropic_tools=None, from_path=None, provider=None, model=None, api_key=None, env_file=None, non_interactive=True, max_turns=1, force=False, dry_run=False, tool_schema=None, tool_schema_inline=None, endpoint=[])
    rc = run_init(args)
    assert rc == 1
    assert captured['provider'] == 'azure'
    assert captured['model'] == 'gpt-4.1-mini'

def test_run_init_emits_inference_notice(monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture, tmp_path) -> None:
    _provider_inference_clear_provider_env(monkeypatch)
    monkeypatch.setenv('AZURE_OPENAI_ENDPOINT', 'https://example.openai.azure.com')
    monkeypatch.setenv('AZURE_OPENAI_KEY', 'sk-secret-do-not-leak')
    monkeypatch.setenv('AZURE_OPENAI_DEPLOYMENT', 'gpt-4.1-mini')

    def _fake_caller(*, provider, model, api_key):
        from agent_shield_cli.init._llm import LlmError
        raise LlmError('stub-caller-stop')
    monkeypatch.setattr('agent_shield_cli.init._command.build_caller', _fake_caller)
    import argparse
    from agent_shield_cli.init._command import run_init
    args = argparse.Namespace(output=tmp_path / 'out.yaml', describe='A test.', mcp=[], openai_tools=None, anthropic_tools=None, from_path=None, provider=None, model=None, api_key=None, env_file=None, non_interactive=True, max_turns=1, force=False, dry_run=False, tool_schema=None, tool_schema_inline=None, endpoint=[])
    run_init(args)
    msg = capsys.readouterr().err
    assert 'inferred provider=azure' in msg
    assert 'model=gpt-4.1-mini' in msg
    assert 'sk-secret-do-not-leak' not in msg
import yaml
from agent_shield_cli.init import _command
from .._support import MockLlmCaller, make_action
_tty_VALID_YAML = yaml.safe_dump({'metadata': {'name': 'demo', 'version': '0.1.0', 'agent_shield_version': '2.0'}, 'objective': {'goal': ['help']}, 'resources': {'tools': [{'name': 'get_customer', 'permission': 'read_only'}]}, 'input_validation': {'guard_policies': [{'name': 'jailbreak', 'evaluate_when': [{'pattern': 'ignore.*instructions', 'reason': 'jb'}]}]}})

def _tty_patch_builder(script):
    return mock.patch('agent_shield_cli.init._command.build_caller', return_value=MockLlmCaller(script=script))

def test_tty_stdin_no_autoflip_no_notice(tmp_path: Path, openai_tools_json: Path, monkeypatch, capsys) -> None:
    monkeypatch.setattr(_command, '_stdin_is_interactive', lambda: True)
    out = tmp_path / '.guardrails.yaml'
    with _tty_patch_builder([make_action('done', yaml=_tty_VALID_YAML, summary='ok')]):
        rc = main(['init', '--provider', 'openai', '--model', 'gpt-5', '--api-key', 'test-key', '--describe', 'x', '--openai-tools', str(openai_tools_json), '--output', str(out), '--non-interactive'])
    assert rc == 0
    err = capsys.readouterr().err
    assert 'stdin is not a TTY' not in err

def test_non_tty_stdin_auto_enables_non_interactive(tmp_path: Path, openai_tools_json: Path, monkeypatch, capsys) -> None:
    monkeypatch.setattr(_command, '_stdin_is_interactive', lambda: False)
    out = tmp_path / '.guardrails.yaml'
    with _tty_patch_builder([make_action('done', yaml=_tty_VALID_YAML, summary='ok')]):
        rc = main(['init', '--provider', 'openai', '--model', 'gpt-5', '--api-key', 'test-key', '--describe', 'x', '--openai-tools', str(openai_tools_json), '--output', str(out)])
    assert rc == 0, 'non-TTY without --non-interactive must auto-flip and proceed'
    assert out.exists()
    err = capsys.readouterr().err
    assert 'stdin is not a TTY' in err
    assert 'non-interactive' in err

def test_non_tty_stdin_without_describe_fast_fails(tmp_path: Path, openai_tools_json: Path, monkeypatch, capsys) -> None:
    monkeypatch.setattr(_command, '_stdin_is_interactive', lambda: False)
    out = tmp_path / '.guardrails.yaml'
    rc = main(['init', '--provider', 'openai', '--model', 'gpt-5', '--api-key', 'test-key', '--openai-tools', str(openai_tools_json), '--output', str(out)])
    assert rc == 2
    err = capsys.readouterr().err
    assert 'stdin is not a TTY' in err
    assert '--describe' in err
    assert not out.exists()

def test_explicit_non_interactive_skips_auto_detect_notice(tmp_path: Path, openai_tools_json: Path, monkeypatch, capsys) -> None:
    monkeypatch.setattr(_command, '_stdin_is_interactive', lambda: False)
    out = tmp_path / '.guardrails.yaml'
    with _tty_patch_builder([make_action('done', yaml=_tty_VALID_YAML, summary='ok')]):
        rc = main(['init', '--provider', 'openai', '--model', 'gpt-5', '--api-key', 'test-key', '--describe', 'x', '--openai-tools', str(openai_tools_json), '--output', str(out), '--non-interactive'])
    assert rc == 0
    err = capsys.readouterr().err
    assert 'stdin is not a TTY' not in err

def test_stdin_is_interactive_handles_none_stdin(monkeypatch) -> None:
    monkeypatch.setattr('sys.stdin', None)
    assert _command._stdin_is_interactive() is False

def test_stdin_is_interactive_handles_isatty_oserror(monkeypatch) -> None:

    class _BrokenStdin:

        def isatty(self):
            raise OSError('bad file descriptor')
    monkeypatch.setattr('sys.stdin', _BrokenStdin())
    assert _command._stdin_is_interactive() is False
import yaml
from agent_shield_cli.init._context import DesignContext, _summarize_schema, build_system_prompt
from agent_shield_cli.init._sources import LoadedSources, ToolEntry
from agent_shield_cli.init._validate import parent_tool_names
_file_safety_VALID_YAML = yaml.safe_dump({'metadata': {'name': 'v', 'version': '0.1.0', 'agent_shield_version': '2.0'}, 'objective': {'goal': ['h']}})

def test_force_overwrite_preserves_prior_on_post_write_failure(tmp_path: Path, openai_tools_json: Path) -> None:
    out = tmp_path / '.guardrails.yaml'
    prior_bytes = b"# user's hand-written config\nmetadata: {name: existing}\n"
    out.write_bytes(prior_bytes)
    from agent_shield_cli.init import _command as cmd
    fake = mock.Mock(side_effect=cmd.ValidationError('simulated post-write failure'))
    with mock.patch.object(cmd, 'validate_on_disk', fake), mock.patch.object(cmd, 'build_caller', return_value=MockLlmCaller(script=[make_action('done', yaml=_file_safety_VALID_YAML, summary='ok')])):
        rc = main(['init', '--provider', 'openai', '--model', 'gpt-5', '--api-key', 'test', '--describe', 'x', '--openai-tools', str(openai_tools_json), '--output', str(out), '--non-interactive', '--force'])
    assert rc != 0
    assert out.read_bytes() == prior_bytes
    leftovers = list(tmp_path.glob('.*.agent-shield-init.tmp'))
    assert leftovers == [], f'unexpected staging leftovers: {leftovers}'

def test_force_overwrite_preserves_prior_when_sibling_tmp_exists(tmp_path: Path, openai_tools_json: Path) -> None:
    out = tmp_path / '.guardrails.yaml'
    out.write_bytes(b'# prior\n')
    legacy_staging = tmp_path / '.guardrails.yaml.agent-shield-init.tmp'
    legacy_staging.write_bytes(b'unrelated content the user wants to keep')
    from agent_shield_cli.init import _command as cmd
    with mock.patch.object(cmd, 'build_caller', return_value=MockLlmCaller(script=[make_action('done', yaml=_file_safety_VALID_YAML, summary='ok')])):
        rc = main(['init', '--provider', 'openai', '--model', 'gpt-5', '--api-key', 'test', '--describe', 'x', '--openai-tools', str(openai_tools_json), '--output', str(out), '--non-interactive', '--force'])
    assert rc == 0
    assert legacy_staging.read_bytes() == b'unrelated content the user wants to keep'

def test_written_file_uses_0644_for_new_files(tmp_path: Path, openai_tools_json: Path) -> None:
    import stat
    out = tmp_path / '.guardrails.yaml'
    from agent_shield_cli.init import _command as cmd
    with mock.patch.object(cmd, 'build_caller', return_value=MockLlmCaller(script=[make_action('done', yaml=_file_safety_VALID_YAML, summary='ok')])):
        rc = main(['init', '--provider', 'openai', '--model', 'gpt-5', '--api-key', 'test', '--describe', 'x', '--openai-tools', str(openai_tools_json), '--output', str(out), '--non-interactive'])
    assert rc == 0
    mode = stat.S_IMODE(out.stat().st_mode)
    assert mode == 420, f'expected 0o644 for new files, got {oct(mode)}'

def test_init_refuses_overwrite_if_file_appears_during_design(tmp_path: Path, openai_tools_json: Path) -> None:
    out = tmp_path / '.guardrails.yaml'
    from agent_shield_cli.init import _command as cmd

    class _CreateFileMidLoop:
        name = 'mock'
        model = 'mock'

        def __init__(self) -> None:
            self.calls = 0

        def chat(self, messages):
            self.calls += 1
            if self.calls == 1:
                out.write_bytes(b'# someone else got here first\n')
            return make_action('done', yaml=_file_safety_VALID_YAML, summary='ok')
    with mock.patch.object(cmd, 'build_caller', return_value=_CreateFileMidLoop()):
        rc = main(['init', '--provider', 'openai', '--model', 'gpt-5', '--api-key', 'test', '--describe', 'x', '--openai-tools', str(openai_tools_json), '--output', str(out), '--non-interactive'])
    assert rc != 0
    assert out.read_bytes() == b'# someone else got here first\n'

def test_init_preflights_invalid_output_parent(tmp_path: Path, openai_tools_json: Path) -> None:
    block = tmp_path / 'blocker'
    block.write_bytes(b'not a directory')
    bad_output = block / 'subdir' / 'child.yaml'
    from agent_shield_cli.init import _command as cmd
    fake_caller = mock.Mock()
    with mock.patch.object(cmd, 'build_caller', return_value=fake_caller):
        rc = main(['init', '--provider', 'openai', '--model', 'gpt-5', '--api-key', 'test', '--describe', 'x', '--openai-tools', str(openai_tools_json), '--output', str(bad_output), '--non-interactive'])
    assert rc != 0
    fake_caller.chat.assert_not_called()

def test_init_refuses_clobber_of_dangling_symlink(tmp_path: Path, openai_tools_json: Path) -> None:
    import os as _os
    out = tmp_path / '.guardrails.yaml'
    out.symlink_to(tmp_path / 'does-not-exist')
    assert not out.exists()
    assert _os.path.lexists(out)
    from agent_shield_cli.init import _command as cmd
    with mock.patch.object(cmd, 'build_caller', return_value=MockLlmCaller(script=[make_action('done', yaml=_file_safety_VALID_YAML, summary='ok')])):
        rc = main(['init', '--provider', 'openai', '--model', 'gpt-5', '--api-key', 'test', '--describe', 'x', '--openai-tools', str(openai_tools_json), '--output', str(out), '--non-interactive'])
    assert rc != 0
    assert out.is_symlink()

def test_overwrite_preserves_existing_target_mode(tmp_path: Path, openai_tools_json: Path) -> None:
    import os
    import stat
    out = tmp_path / '.guardrails.yaml'
    out.write_bytes(b'# prior\n')
    os.chmod(out, 416)
    from agent_shield_cli.init import _command as cmd
    with mock.patch.object(cmd, 'build_caller', return_value=MockLlmCaller(script=[make_action('done', yaml=_file_safety_VALID_YAML, summary='ok')])):
        rc = main(['init', '--provider', 'openai', '--model', 'gpt-5', '--api-key', 'test', '--describe', 'x', '--openai-tools', str(openai_tools_json), '--output', str(out), '--non-interactive', '--force'])
    assert rc == 0
    mode = stat.S_IMODE(out.stat().st_mode)
    assert mode == 416, f'expected 0o640 (inherited from prior file), got {oct(mode)}'

def test_summarize_schema_renders_params() -> None:
    schema = {'type': 'object', 'properties': {'amount': {'type': 'number'}, 'currency': {'type': 'string'}, 'reason': {'type': ['string', 'null']}}, 'required': ['amount']}
    summary = _summarize_schema(schema)
    assert 'amount*: number' in summary
    assert 'currency: string' in summary
    assert 'reason: string|null' in summary

def test_summarize_schema_empty_inputs() -> None:
    assert _summarize_schema(None) == ''
    assert _summarize_schema({}) == ''
    assert _summarize_schema({'type': 'object'}) == ''
    assert _summarize_schema({'type': 'object', 'properties': {}}) == ''

def test_system_prompt_includes_tool_params() -> None:
    ctx = DesignContext.from_inputs(sources=LoadedSources(tools=[ToolEntry(name='refund_order', description='Refund.', source_label='openai_function', input_schema={'type': 'object', 'properties': {'amount': {'type': 'number'}}, 'required': ['amount']})]), description='bank bot', parent_path=None, parent_tool_names=[])
    prompt = build_system_prompt(ctx)
    assert 'params: {amount*: number}' in prompt

def test_sanitization_applies_to_user_describe() -> None:
    ctx = DesignContext.from_inputs(sources=LoadedSources(tools=[ToolEntry(name='x')]), description='Stop prompt injection attacks and jailbreak attempts.', parent_path=None, parent_tool_names=[])
    prompt = build_system_prompt(ctx)
    assert 'prompt injection' not in prompt
    assert 'jailbreak' not in prompt
    assert 'untrusted-input attack' in prompt
    assert 'input-attack' in prompt

def test_sanitization_applies_to_tool_descriptions() -> None:
    ctx = DesignContext.from_inputs(sources=LoadedSources(tools=[ToolEntry(name='t1', description='Detects jailbreak attempts in user input.', source_label='openai_function')]), description='bot', parent_path=None, parent_tool_names=[])
    prompt = build_system_prompt(ctx)
    assert 'jailbreak' not in prompt

def test_tool_names_are_NOT_sanitized(tmp_path: Path) -> None:
    parent = tmp_path / 'p.yaml'
    parent.write_text(yaml.safe_dump({'metadata': {'name': 'p', 'version': '0.1.0', 'agent_shield_version': '2.0'}, 'objective': {'goal': ['g']}, 'resources': {'tools': [{'name': 'legacy_jailbreak_log'}]}}), encoding='utf-8')
    ctx = DesignContext.from_inputs(sources=LoadedSources(tools=[ToolEntry(name='jailbreak_detector', description='(description goes through sanitizer)', source_label='openai_function')]), description='bot', parent_path=parent, parent_tool_names=['legacy_jailbreak_log'])
    prompt = build_system_prompt(ctx)
    assert 'jailbreak_detector' in prompt
    assert 'legacy_jailbreak_log' in prompt

def test_tool_param_names_are_NOT_sanitized() -> None:
    ctx = DesignContext.from_inputs(sources=LoadedSources(tools=[ToolEntry(name='t', description='', source_label='openai_function', input_schema={'type': 'object', 'properties': {'jailbreak_score': {'type': 'number'}}})]), description='bot', parent_path=None, parent_tool_names=[])
    prompt = build_system_prompt(ctx)
    assert 'jailbreak_score: number' in prompt

def test_sanitization_applies_to_source_notes() -> None:
    ctx = DesignContext.from_inputs(sources=LoadedSources(tools=[ToolEntry(name='x')], notes=['Stripped a jailbreak filter from input.']), description='bot', parent_path=None, parent_tool_names=[])
    prompt = build_system_prompt(ctx)
    assert 'jailbreak' not in prompt

def _file_safety_write(p: Path, data: dict) -> None:
    p.write_text(yaml.safe_dump(data), encoding='utf-8')

def test_parent_tool_names_walks_extends_chain(tmp_path: Path) -> None:
    gp = tmp_path / 'gp.yaml'
    _file_safety_write(gp, {'metadata': {'name': 'gp', 'version': '0.1.0', 'agent_shield_version': '2.0'}, 'objective': {'goal': ['g']}, 'resources': {'tools': [{'name': 'gp_tool'}]}})
    p = tmp_path / 'p.yaml'
    _file_safety_write(p, {'extends': ['gp.yaml'], 'metadata': {'name': 'p', 'version': '0.1.0', 'agent_shield_version': '2.0'}, 'objective': {'goal': ['g']}, 'resources': {'tools': [{'name': 'p_tool'}]}})
    names = parent_tool_names(p)
    assert 'p_tool' in names
    assert 'gp_tool' in names

def test_parent_tool_names_handles_cyclic_extends(tmp_path: Path) -> None:
    a = tmp_path / 'a.yaml'
    b = tmp_path / 'b.yaml'
    _file_safety_write(a, {'extends': ['b.yaml'], 'metadata': {'name': 'a', 'version': '0.1.0', 'agent_shield_version': '2.0'}, 'objective': {'goal': ['g']}, 'resources': {'tools': [{'name': 'a_tool'}]}})
    _file_safety_write(b, {'extends': ['a.yaml'], 'metadata': {'name': 'b', 'version': '0.1.0', 'agent_shield_version': '2.0'}, 'objective': {'goal': ['g']}, 'resources': {'tools': [{'name': 'b_tool'}]}})
    try:
        parent_tool_names(a)
    except Exception:
        pass
