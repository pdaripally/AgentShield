"""Agent Shield command-line surface.

The ``agent-shield`` console script dispatches into this package.
Today the only subcommand is ``agent-shield init`` — a conversational
``.guardrails.yaml`` designer that delegates to an LLM (#15).
"""
from __future__ import annotations

from ._entry import main

__all__ = ["main"]
