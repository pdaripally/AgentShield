"""Small shared helpers for source parsers."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import yaml

from ._models import SourceParseError


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except FileNotFoundError as exc:
        raise SourceParseError(f"source file not found: {path}") from exc
    except OSError as exc:
        raise SourceParseError(f"failed to read {path}: {exc}") from exc


def parse_json(path: Path) -> Any:
    try:
        return json.loads(read_text(path))
    except json.JSONDecodeError as exc:
        raise SourceParseError(f"{path}: not valid JSON ({exc})") from exc


def parse_yaml(path: Path) -> Any:
    try:
        return yaml.safe_load(read_text(path))
    except yaml.YAMLError as exc:
        raise SourceParseError(f"{path}: not valid YAML ({exc})") from exc


__all__ = ["parse_json", "parse_yaml", "read_text"]
