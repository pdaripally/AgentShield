"""MCP source parsing.

Two shapes are recognised:

1. **MCP ``tools/list`` manifest** — JSON or YAML object with a top-level
   ``tools:`` array of ``{name, description, inputSchema}``.

2. **MCP allowlist** — YAML with ``known:``/``blocked:``/``enforcement:``
   keys (the shape of ``mcp-allowlist.yaml`` at repo root). Surfaces
   server names as a hint; no tool rows are emitted.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from ._models import ParsedMcp, SourceParseError, ToolEntry
from ._util import parse_json, parse_yaml


def load_mcp(path: Path) -> ParsedMcp:
    suffix = path.suffix.lower()
    data: Any = parse_json(path) if suffix == ".json" else parse_yaml(path)

    if not isinstance(data, dict):
        raise SourceParseError(
            f"{path}: expected a top-level JSON/YAML object with `tools:` "
            f"or `known:` (got {type(data).__name__})"
        )

    if "known" in data or "blocked" in data or "enforcement" in data:
        known = data.get("known")
        if known is not None and not isinstance(known, list):
            raise SourceParseError(
                f"{path}: `known` must be a list of server name strings, "
                f"got {type(known).__name__!r}"
            )
        servers = [str(s) for s in (known or [])]
        return ParsedMcp(
            tools=[],
            servers=servers,
            notes=[
                f"{path}: detected MCP allowlist (server names); no tool "
                f"entries emitted."
            ],
        )

    raw_tools = data.get("tools")
    if not isinstance(raw_tools, list):
        raise SourceParseError(
            f"{path}: missing a `tools:` array. Provide an MCP "
            f"`tools/list` response or an MCP allowlist YAML."
        )

    out = []
    for idx, item in enumerate(raw_tools):
        if not isinstance(item, dict):
            raise SourceParseError(f"{path}: tools[{idx}] is not an object")
        name = item.get("name")
        if not isinstance(name, str) or not name:
            raise SourceParseError(
                f"{path}: tools[{idx}] is missing a non-empty `name`"
            )
        description = item.get("description") or ""
        if not isinstance(description, str):
            description = ""
        schema = item.get("inputSchema") or item.get("input_schema")
        out.append(
            ToolEntry(
                name=name,
                description=description.strip(),
                source_label="mcp",
                input_schema=schema if isinstance(schema, dict) else None,
            )
        )

    return ParsedMcp(tools=out, servers=[], notes=[])


__all__ = ["load_mcp"]
