"""OpenAI function-call JSON parser.

Accepts every common wrapping:

- ``[{"type": "function", "function": {"name", "description", "parameters"}}, ...]``
- ``{"tools": [...]}`` wrapped form
- ``{"functions": [...]}`` (legacy)
- A bare array of ``{"name", "description", "parameters"}`` (legacy)
"""
from __future__ import annotations

from pathlib import Path
from typing import List

from ._models import SourceParseError, ToolEntry
from ._util import parse_json


def load_openai_tools(path: Path) -> List[ToolEntry]:
    data = parse_json(path)

    if isinstance(data, dict):
        if isinstance(data.get("tools"), list):
            items = data["tools"]
        elif isinstance(data.get("functions"), list):
            items = data["functions"]
        else:
            raise SourceParseError(
                f"{path}: expected `tools:` or `functions:` array"
            )
    elif isinstance(data, list):
        items = data
    else:
        raise SourceParseError(
            f"{path}: top-level must be an array or an object"
        )

    out: List[ToolEntry] = []
    for idx, item in enumerate(items):
        if not isinstance(item, dict):
            raise SourceParseError(f"{path}: entry {idx} is not an object")
        if item.get("type") == "function" and isinstance(item.get("function"), dict):
            fn = item["function"]
        else:
            fn = item
        name = fn.get("name")
        if not isinstance(name, str) or not name:
            raise SourceParseError(
                f"{path}: entry {idx} is missing a non-empty `name`"
            )
        description = fn.get("description") or ""
        if not isinstance(description, str):
            description = ""
        params = fn.get("parameters")
        out.append(
            ToolEntry(
                name=name,
                description=description.strip(),
                source_label="openai_function",
                input_schema=params if isinstance(params, dict) else None,
            )
        )

    return out


__all__ = ["load_openai_tools"]
