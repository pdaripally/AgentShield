"""Anthropic tool JSON parser."""
from __future__ import annotations

from pathlib import Path
from typing import List

from ._models import SourceParseError, ToolEntry
from ._util import parse_json


def load_anthropic_tools(path: Path) -> List[ToolEntry]:
    data = parse_json(path)
    if isinstance(data, list):
        items = data
    elif isinstance(data, dict) and isinstance(data.get("tools"), list):
        items = data["tools"]
    else:
        raise SourceParseError(
            f"{path}: expected an array or {{\"tools\": [...]}}"
        )

    out: List[ToolEntry] = []
    for idx, item in enumerate(items):
        if not isinstance(item, dict):
            raise SourceParseError(f"{path}: entry {idx} is not an object")
        name = item.get("name")
        if not isinstance(name, str) or not name:
            raise SourceParseError(
                f"{path}: entry {idx} is missing a non-empty `name`"
            )
        description = item.get("description") or ""
        if not isinstance(description, str):
            description = ""
        schema = item.get("input_schema")
        out.append(
            ToolEntry(
                name=name,
                description=description.strip(),
                source_label="anthropic_tool",
                input_schema=schema if isinstance(schema, dict) else None,
            )
        )

    return out


__all__ = ["load_anthropic_tools"]
