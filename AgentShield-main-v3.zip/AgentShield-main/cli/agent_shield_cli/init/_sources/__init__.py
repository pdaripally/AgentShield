"""Tool-definition source parsers for ``agent-shield init``."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from ._anthropic import load_anthropic_tools
from ._mcp import load_mcp
from ._models import ParsedMcp, SourceParseError, ToolEntry
from ._openai import load_openai_tools


@dataclass
class LoadedSources:
    tools: List[ToolEntry] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)
    mcp_servers: List[str] = field(default_factory=list)


def load_tools(
    *,
    mcp_paths: List[Path],
    openai_path: Optional[Path],
    anthropic_path: Optional[Path],
) -> LoadedSources:
    """Parse every requested source and merge into one :class:`LoadedSources`.

    Tools are deduplicated by ``name`` — first occurrence wins, with a
    note appended so the user sees which collision was dropped.
    """
    out = LoadedSources()
    seen: Dict[str, str] = {}

    def _accept(entries: List[ToolEntry], label: str) -> None:
        for entry in entries:
            if entry.name in seen:
                out.notes.append(
                    f"skipped duplicate tool '{entry.name}' from {label} "
                    f"(already provided by {seen[entry.name]})"
                )
                continue
            seen[entry.name] = label
            out.tools.append(entry)

    for path in mcp_paths:
        parsed = load_mcp(path)
        _accept(parsed.tools, f"--mcp {path}")
        out.mcp_servers.extend(parsed.servers)
        out.notes.extend(parsed.notes)

    if openai_path is not None:
        _accept(load_openai_tools(openai_path), f"--openai-tools {openai_path}")
    if anthropic_path is not None:
        _accept(
            load_anthropic_tools(anthropic_path),
            f"--anthropic-tools {anthropic_path}",
        )

    return out


__all__ = [
    "LoadedSources",
    "ParsedMcp",
    "SourceParseError",
    "ToolEntry",
    "load_anthropic_tools",
    "load_mcp",
    "load_openai_tools",
    "load_tools",
]
