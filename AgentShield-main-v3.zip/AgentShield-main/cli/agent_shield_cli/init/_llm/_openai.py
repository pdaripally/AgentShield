"""OpenAI provider for the design agent.

Uses the official ``openai`` client (already an optional extra in
``pyproject.toml``). The caller blocks until the full assistant turn
is returned — the orchestrator parses one complete JSON action per turn.

Transient HTTP failures (429 + 5xx) are retried with exponential
backoff via ``chat_with_backoff``; the final wrapped ``LlmError``
preserves ``status_code`` so the CLI orchestrator can classify a
rate-limit abort separately from a generic LLM error.
"""
from __future__ import annotations

import os
import sys
from typing import Dict, List, Optional

from ._base import LlmError, chat_with_backoff, classify_http_exception


class OpenAiCaller:
    """OpenAI chat-completion caller."""

    name = "openai"

    def __init__(self, *, model: str, api_key: Optional[str] = None) -> None:
        try:
            from openai import OpenAI  # type: ignore[import-not-found]
        except ImportError as exc:  # pragma: no cover - install-time error path
            raise LlmError(
                "the `openai` Python package is required for "
                "`--provider openai`. Install with `pip install agent-shield[openai]` "
                "or `pip install openai`."
            ) from exc

        key = api_key or os.environ.get("OPENAI_API_KEY")
        if not key:
            raise LlmError(
                "OpenAI provider selected but no API key found. Set "
                "OPENAI_API_KEY in the environment or pass --api-key."
            )
        self.model = model
        self._client = OpenAI(api_key=key)

    def chat(self, messages: List[Dict[str, str]]) -> str:
        def _do() -> object:
            return self._client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=0.2,
                # JSON-mode keeps the LLM output parseable. The design
                # agent's contract is "one JSON object per turn"; this
                # is the cheapest way to enforce it server-side.
                response_format={"type": "json_object"},
            )

        try:
            response = chat_with_backoff(_do, progress=_progress)
        except Exception as exc:
            status, retry_after = classify_http_exception(exc)
            raise LlmError(
                f"OpenAI request failed: {exc}",
                status_code=status,
                retry_after=retry_after,
            ) from exc

        try:
            return response.choices[0].message.content or ""
        except (IndexError, AttributeError) as exc:
            raise LlmError(f"OpenAI response had no content: {exc}") from exc


def _progress(line: str) -> None:
    print(f"  ⓘ {line}", file=sys.stderr, flush=True)


__all__ = ["OpenAiCaller"]
