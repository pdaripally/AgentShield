"""Anthropic provider for the design agent.

Uses the official ``anthropic`` client (already an optional extra in
``pyproject.toml``). Translates the OpenAI-style ``messages`` shape
into Anthropic's split ``system`` + ``messages`` API and returns the
assistant's full text reply.

Transient HTTP failures (429 + 5xx) are retried with exponential
backoff via ``chat_with_backoff``; the final wrapped ``LlmError``
preserves ``status_code`` so the CLI orchestrator can classify a
rate-limit abort separately from a generic LLM error.
"""
from __future__ import annotations

import os
import sys
from typing import Dict, List, Optional

from ._base import LlmError, chat_with_backoff, classify_http_exception


class AnthropicCaller:
    """Anthropic Messages API caller."""

    name = "anthropic"

    def __init__(self, *, model: str, api_key: Optional[str] = None) -> None:
        try:
            from anthropic import Anthropic  # type: ignore[import-not-found]
        except ImportError as exc:  # pragma: no cover
            raise LlmError(
                "the `anthropic` Python package is required for "
                "`--provider anthropic`. Install with "
                "`pip install agent-shield[anthropic]` or `pip install anthropic`."
            ) from exc

        key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not key:
            raise LlmError(
                "Anthropic provider selected but no API key found. Set "
                "ANTHROPIC_API_KEY in the environment or pass --api-key."
            )
        self.model = model
        self._client = Anthropic(api_key=key)

    def chat(self, messages: List[Dict[str, str]]) -> str:
        # Anthropic separates the system prompt; concatenate any
        # system-role entries from the front of `messages`.
        system_parts: List[str] = []
        rest: List[Dict[str, str]] = []
        for entry in messages:
            if entry.get("role") == "system":
                system_parts.append(entry.get("content", ""))
            else:
                rest.append(entry)
        system_prompt = "\n\n".join(p for p in system_parts if p)

        try:
            response = chat_with_backoff(
                lambda: self._client.messages.create(
                    model=self.model,
                    system=system_prompt or None,
                    messages=rest,
                    max_tokens=4096,
                    temperature=0.2,
                ),
                progress=_progress,
            )
        except Exception as exc:
            status, retry_after = classify_http_exception(exc)
            raise LlmError(
                f"Anthropic request failed: {exc}",
                status_code=status,
                retry_after=retry_after,
            ) from exc

        try:
            # Anthropic returns a list of content blocks; we only use text.
            chunks = [
                block.text
                for block in response.content
                if getattr(block, "type", None) == "text"
            ]
            return "".join(chunks)
        except (IndexError, AttributeError) as exc:
            raise LlmError(f"Anthropic response had no text: {exc}") from exc


def _progress(line: str) -> None:
    print(f"  ⓘ {line}", file=sys.stderr, flush=True)


__all__ = ["AnthropicCaller"]
