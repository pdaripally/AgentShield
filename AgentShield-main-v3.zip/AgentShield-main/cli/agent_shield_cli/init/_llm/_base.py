"""LLM caller protocol + provider factory.

Provider modules build on the ``chat_with_backoff`` helper here so a
single transient-failure policy (HTTP 429 + 5xx, with optional
``Retry-After``) covers OpenAI, Azure OpenAI, and Anthropic uniformly.
``_sleep`` is module-scope so tests can monkeypatch it to a recorder
without actually delaying the suite.
"""
from __future__ import annotations

import os
import time
from typing import Callable, Dict, List, Optional, Protocol, Tuple, TypeVar


class LlmError(RuntimeError):
    """Raised when the LLM call fails (network, auth, quota, malformed response).

    Carries an optional ``status_code`` so the orchestrator can
    distinguish rate-limit / server-error / auth-failure paths without
    pattern-matching on the message string. ``retry_after`` is the
    server-suggested delay in seconds if the underlying SDK exposed one.
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: Optional[int] = None,
        retry_after: Optional[float] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.retry_after = retry_after


class LlmCaller(Protocol):
    """Minimal blocking chat-completion interface."""

    name: str  # provider label, e.g. "openai" / "anthropic" / "mock"
    model: str

    def chat(self, messages: List[Dict[str, str]]) -> str:
        """Send ``messages`` and return the assistant's complete text reply.

        ``messages`` follows the OpenAI shape: a list of
        ``{"role": "system" | "user" | "assistant", "content": str}``.
        Providers may adapt as needed; the orchestrator treats the
        return value as opaque text and parses it for JSON actions.
        """
        ...


def build_caller(*, provider: str, model: str, api_key: str | None = None) -> LlmCaller:
    """Construct a caller for the given provider.

    Raises ``LlmError`` with a clear message when the provider library
    is missing or credentials are absent.
    """
    if provider == "openai":
        from ._openai import OpenAiCaller

        return OpenAiCaller(model=model, api_key=api_key)
    if provider == "anthropic":
        from ._anthropic import AnthropicCaller

        return AnthropicCaller(model=model, api_key=api_key)
    if provider == "azure":
        from ._azure import AzureOpenAiCaller

        return AzureOpenAiCaller(model=model, api_key=api_key)
    raise LlmError(f"unsupported provider: {provider!r}")


# ─── Transient-failure backoff (transient-failure retry) ─────────────────────────────
#
# A single 429 on the self-correct retry used to abort the whole CLI
# run. The fix is a small exponential-backoff wrapper that every
# provider calls around its HTTP request. Retryable = HTTP 429 or any
# 5xx. Non-retryable failures bubble up immediately, preserving the
# existing auth/4xx error paths.
#
# Delays are intentionally short (1s → 2s → 4s → 8s, ~15s worst-case)
# so interactive `agent-shield init` doesn't feel hung. A
# ``Retry-After`` header from the server overrides the schedule, up to
# ``_RETRY_AFTER_CEILING_S`` (so a hostile/misconfigured 99999s header
# can't pin the CLI). Operators can override the retry count via
# ``AGENT_SHIELD_LLM_MAX_RETRIES``.

_DEFAULT_RETRY_DELAYS: Tuple[float, ...] = (1.0, 2.0, 4.0, 8.0)
_RETRY_AFTER_CEILING_S: float = 60.0
_RETRY_AFTER_FLOOR_S: float = 0.0

# Hook for tests: monkeypatch to capture sleep durations without
# delaying the suite.
_sleep: Callable[[float], None] = time.sleep


def _retry_delays() -> Tuple[float, ...]:
    """Build the per-attempt sleep schedule.

    Reads ``AGENT_SHIELD_LLM_MAX_RETRIES`` to let ops grow / shrink the
    retry count without redeploying. Caps growth at the existing
    schedule's last step (8s) — past ~15-30s a customer is better
    served by re-running than by waiting.
    """
    raw = os.environ.get("AGENT_SHIELD_LLM_MAX_RETRIES")
    if raw is None:
        return _DEFAULT_RETRY_DELAYS
    try:
        n = int(raw)
    except ValueError:
        return _DEFAULT_RETRY_DELAYS
    if n <= 0:
        return ()
    if n <= len(_DEFAULT_RETRY_DELAYS):
        return _DEFAULT_RETRY_DELAYS[:n]
    extra = (_DEFAULT_RETRY_DELAYS[-1],) * (n - len(_DEFAULT_RETRY_DELAYS))
    return _DEFAULT_RETRY_DELAYS + extra


_T = TypeVar("_T")


def classify_http_exception(
    exc: BaseException,
) -> Tuple[Optional[int], Optional[float]]:
    """Best-effort extraction of (status_code, retry_after_seconds).

    Inspects attributes the openai / anthropic SDKs expose
    (``status_code``, ``response.status_code``, ``response.headers``)
    before falling back to a string scan for ``429`` / ``5xx``. Returns
    ``(None, None)`` if nothing retryable is found — the caller must
    not retry in that case.
    """
    status: Optional[int] = None
    raw_status = getattr(exc, "status_code", None)
    if isinstance(raw_status, int):
        status = raw_status
    if status is None:
        response = getattr(exc, "response", None)
        if response is not None:
            rs = getattr(response, "status_code", None)
            if isinstance(rs, int):
                status = rs
    if status is None:
        text = str(exc)
        for code in (429, 500, 502, 503, 504):
            if (
                f" {code} " in text
                or text.endswith(f" {code}")
                or f"code: {code}" in text
                or f"code:{code}" in text
            ):
                status = code
                break

    if status is None:
        return (None, None)
    if status != 429 and not (500 <= status < 600):
        return (None, None)

    retry_after: Optional[float] = None
    response = getattr(exc, "response", None)
    headers = getattr(response, "headers", None) if response is not None else None
    if headers is not None:
        try:
            raw = headers.get("retry-after") or headers.get("Retry-After")
        except Exception:
            raw = None
        if raw is not None:
            try:
                retry_after = float(raw)
            except (TypeError, ValueError):
                retry_after = None
    if retry_after is not None:
        retry_after = max(_RETRY_AFTER_FLOOR_S, min(retry_after, _RETRY_AFTER_CEILING_S))
    return (status, retry_after)


def chat_with_backoff(
    call: Callable[[], _T],
    *,
    classify: Callable[
        [BaseException], Tuple[Optional[int], Optional[float]]
    ] = classify_http_exception,
    progress: Optional[Callable[[str], None]] = None,
) -> _T:
    """Run ``call()`` with exponential backoff on transient failures.

    ``classify`` returns ``(status_code, retry_after)`` for retryable
    HTTP errors; anything else bubbles up immediately. ``progress``
    receives a one-line stderr-suitable string per retry so the CLI
    never falls silent during a 15-second wait (silence reads as a hang).
    """
    delays = _retry_delays()
    last_exc: Optional[BaseException] = None
    for attempt in range(len(delays) + 1):  # attempt 0 = initial call
        try:
            return call()
        except BaseException as exc:  # noqa: BLE001 — re-raised or retried below
            last_exc = exc
            status, retry_after = classify(exc)
            if status is None or attempt >= len(delays):
                raise
            sleep_for = retry_after if retry_after is not None else delays[attempt]
            if progress is not None:
                progress(
                    f"transient LLM failure (HTTP {status}); "
                    f"retry {attempt + 1}/{len(delays)} in {sleep_for:.1f}s"
                )
            _sleep(sleep_for)
    # Unreachable: the loop body always returns or raises.
    assert last_exc is not None
    raise last_exc


__all__ = [
    "LlmCaller",
    "LlmError",
    "build_caller",
    "chat_with_backoff",
    "classify_http_exception",
]
