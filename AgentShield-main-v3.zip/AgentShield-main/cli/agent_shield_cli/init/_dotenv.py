"""Minimal ``.env`` auto-loader for ``agent-shield init`` (credential auto-loading).

Customers commonly keep `AZURE_OPENAI_*` / `OPENAI_API_KEY` /
`ANTHROPIC_API_KEY` etc. in a `.env` file at the repo root. The demos
under ``examples/*/`` pick this up automatically; the CLI did not,
which forced an unnecessary ``source .env`` step. This module closes
that gap.

Design constraints:

* Only credentials we know about are honoured (`_ALLOWED_KEYS`). The
  loader never imports unrelated keys from the developer's ``.env``.
* Already-set ``os.environ`` values win — exported shell vars override
  the file, matching ``python-dotenv``'s ``override=False`` behaviour.
* Lookup order: explicit ``--env-file`` → ``./.env`` in cwd →
  ``<git-root>/.env``. First file that exists wins. Missing files are
  silently skipped (no errors).
* No dependency on ``python-dotenv``; only ``KEY=VALUE`` lines are
  parsed (with optional ``export `` prefix and single/double quotes).
  Shell features (``$VAR`` interpolation, command substitution, etc.)
  are intentionally NOT supported — credential files should not need
  them.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Iterable, Optional, Tuple


_ALLOWED_KEYS: frozenset[str] = frozenset(
    {
        "OPENAI_API_KEY",
        "ANTHROPIC_API_KEY",
        "AZURE_OPENAI_API_KEY",
        "AZURE_OPENAI_ENDPOINT",
        "AZURE_OPENAI_API_VERSION",
        "AZURE_OPENAI_DEPLOYMENT",
        "AZURE_CONTENT_SAFETY_KEY",
        "AZURE_CONTENT_SAFETY_ENDPOINT",
    }
)


def _git_root(start: Path) -> Optional[Path]:
    """Walk upward from ``start`` looking for ``.git``. Returns None if
    not inside a git checkout. We do a directory walk instead of
    shelling out to ``git`` so the CLI stays usable without git
    installed."""
    cur = start.resolve()
    for candidate in (cur, *cur.parents):
        if (candidate / ".git").exists():
            return candidate
    return None


def _parse_env_file(text: str) -> Iterable[Tuple[str, str]]:
    """Yield ``(key, value)`` pairs from a ``.env`` file body.

    Accepts:
      KEY=value
      KEY="value"
      KEY='value'
      export KEY=value
      # comment lines and blank lines are ignored
    Lines that don't match ``KEY=VALUE`` are silently skipped — we do
    not want a stray malformed line to abort credential loading.
    """
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export ") :].lstrip()
        if "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip()
        if not key:
            continue
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
            value = value[1:-1]
        yield key, value


def discover_env_file(
    explicit: Optional[Path],
    cwd: Optional[Path] = None,
) -> Optional[Path]:
    """Resolve which ``.env`` file to load, per credential auto-loading.

    Order: ``explicit`` → ``<cwd>/.env`` → ``<git-root>/.env``.
    Returns ``None`` if no file is found. If ``explicit`` is given but
    missing, that's a hard error the caller surfaces — we still return
    the path so the caller can ``stat`` and decide.
    """
    if explicit is not None:
        return explicit
    base = Path(cwd) if cwd is not None else Path.cwd()
    local = base / ".env"
    if local.is_file():
        return local
    root = _git_root(base)
    if root is not None:
        repo_env = root / ".env"
        if repo_env.is_file() and repo_env.resolve() != local.resolve():
            return repo_env
    return None


def load_credentials_env(
    explicit: Optional[Path] = None,
    *,
    cwd: Optional[Path] = None,
    environ: Optional[dict] = None,
) -> Tuple[Optional[Path], list[str]]:
    """Load credential-family keys from a ``.env`` into ``environ``.

    Returns ``(path_used, keys_set)``:
      * ``path_used`` is the resolved ``.env`` path, or ``None`` if no
        file was found.
      * ``keys_set`` is the subset of ``_ALLOWED_KEYS`` actually set by
        this call (i.e. previously unset in ``environ``).

    Pre-existing values in ``environ`` are NEVER overwritten. Keys
    outside ``_ALLOWED_KEYS`` are dropped, so an unrelated secret in
    ``.env`` cannot accidentally leak into the CLI process.

    If ``explicit`` is provided and the file does not exist, raises
    ``FileNotFoundError`` — the caller asked for a specific file.
    """
    env = environ if environ is not None else os.environ
    path = discover_env_file(explicit, cwd=cwd)
    if path is None:
        return None, []
    if not path.is_file():
        if explicit is not None:
            raise FileNotFoundError(f"--env-file not found: {path}")
        return None, []

    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return None, []

    set_keys: list[str] = []
    for key, value in _parse_env_file(text):
        if key not in _ALLOWED_KEYS:
            continue
        if key in env and env[key]:
            continue
        env[key] = value
        set_keys.append(key)
    return path, set_keys
