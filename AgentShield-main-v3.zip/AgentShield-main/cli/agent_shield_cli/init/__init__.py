"""``agent-shield init`` — agentic ``.guardrails.yaml`` designer.

The user provides tool definitions, a short description, and an LLM
provider. The CLI primes an LLM with the v2 spec, schema, and curated
examples, then runs a turn loop: the model asks clarifying questions,
proposes config increments, and finally writes a complete policy.

Every proposal goes through the Rust loader before being merged or
written. See ``_design_agent.py`` for the loop and ``_context.py``
for the priming.
"""
from __future__ import annotations

from ._command import add_init_parser, run_init

__all__ = ["add_init_parser", "run_init"]
