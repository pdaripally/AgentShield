"""``agent-shield init`` — CLI orchestrator.

Wires together:

  arg parsing → source loading → context building → LLM caller →
  design loop → emit & write
"""
from __future__ import annotations

import argparse
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from ._context import DesignContext, build_system_prompt
from ._design_agent import run_design_loop
from ._dotenv import load_credentials_env
from ._emit import emit_yaml
from ._llm import LlmError, build_caller
from ._sources import SourceParseError, load_tools
from ._validate import (
    ValidationContext,
    ValidationError,
    interpolate_env_placeholders,
    multi_agent_disclosure_warnings,
    parent_tool_names,
    validate_aacs_env_preflight,
    validate_no_replace_with_endpoint,
    validate_on_disk,
)


def add_init_parser(subparsers: argparse._SubParsersAction) -> argparse.ArgumentParser:
    p = subparsers.add_parser(
        "init",
        help="Design a `.guardrails.yaml` with an LLM-driven conversation.",
        description=(
            "Agentic `.guardrails.yaml` designer. Primes an LLM with the v2 "
            "spec, schema, and curated examples; the model asks clarifying "
            "questions and proposes config increments validated against the "
            "Rust loader before being written."
        ),
    )
    p.add_argument(
        "--output",
        "-o",
        type=Path,
        default=Path(".guardrails.yaml"),
        help="Output path (default: ./.guardrails.yaml).",
    )
    p.add_argument(
        "--describe",
        default="",
        help=(
            "1-2 sentence description of the agent (role, data classes "
            "handled, deployment surface). Primes the LLM."
        ),
    )

    # ── tool sources ────────────────────────────────────────────────
    p.add_argument(
        "--mcp",
        action="append",
        default=[],
        type=Path,
        metavar="PATH",
        help="MCP source file (tools/list JSON or allowlist YAML). Repeatable.",
    )
    p.add_argument(
        "--openai-tools", type=Path, metavar="PATH",
        help="OpenAI function-call JSON file.",
    )
    p.add_argument(
        "--anthropic-tools", type=Path, metavar="PATH",
        help="Anthropic tool JSON file.",
    )
    p.add_argument(
        "--from",
        dest="from_path",
        type=Path,
        metavar="PATH",
        help=(
            "Extend an existing `.guardrails.yaml` — the output starts "
            "with `extends: [<this file>]` and only adds new tools / "
            "policies. The parent file is never modified."
        ),
    )

    # ── LLM provider ────────────────────────────────────────────────
    p.add_argument(
        "--provider",
        choices=("openai", "anthropic", "azure"),
        required=False,
        help="LLM provider (also reads $AGENT_SHIELD_PROVIDER).",
    )
    p.add_argument(
        "--model",
        required=False,
        help="Provider-specific model name (also reads $AGENT_SHIELD_MODEL).",
    )
    p.add_argument(
        "--api-key",
        default=None,
        help=(
            "API key override "
            "(default: $OPENAI_API_KEY / $ANTHROPIC_API_KEY / $AZURE_OPENAI_API_KEY)."
        ),
    )
    p.add_argument(
        "--env-file",
        type=Path,
        default=None,
        metavar="PATH",
        help=(
            "Path to a `.env` file with provider credentials "
            "(`AZURE_OPENAI_*`, `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, "
            "and — for AACS Stage 1 — BOTH "
            "`AZURE_CONTENT_SAFETY_ENDPOINT` and "
            "`AZURE_CONTENT_SAFETY_KEY`). Defaults to ./.env then "
            "<git-root>/.env if either exists. Pre-set environment "
            "variables always win — the file never overwrites them."
        ),
    )

    # ── interaction control ────────────────────────────────────────
    p.add_argument(
        "--non-interactive",
        action="store_true",
        help=(
            "Run without user turns: the LLM gets one shot with --describe + "
            "tools, must emit `done` directly. Requires --describe."
        ),
    )
    p.add_argument(
        "--max-turns",
        type=int,
        default=30,
        help="Hard cap on assistant turns (default: 30).",
    )
    p.add_argument(
        "--force",
        action="store_true",
        help="Overwrite the output file if it exists.",
    )
    p.add_argument(
        "--dry-run",
        action="store_true",
        help="Print the final YAML to stdout instead of writing.",
    )

    # ── RULE 16 + RULE 17 escape hatches ───────────────────
    # Optional sidecars that ground the post-generation validators
    # against reality: `--tool-schema(-inline)` declares each tool's
    # `params:` / `returns:` so RULE 16 can reject hallucinated
    # `@result.<field>` populators, and `--endpoint` whitelists host
    # substrings the operator has confirmed are legitimate (otherwise
    # RULE 17 rejects placeholder-looking URLs like `*.invalid` /
    # `contoso.com`).
    p.add_argument(
        "--tool-schema",
        type=Path,
        metavar="PATH",
        default=None,
        help=(
            "JSON sidecar mapping tool names to declared `params:` / "
            "`returns:` shapes. Enables RULE 16 (schema-grounded validation): the validator "
            "rejects `@result.<field>` populator expressions whose "
            "field isn't listed in the tool's declared `returns:`."
        ),
    )
    p.add_argument(
        "--tool-schema-inline",
        default=None,
        metavar="JSON",
        help=(
            "Inline alternative to --tool-schema — the schema body as a "
            "JSON string (RULE 16)."
        ),
    )
    p.add_argument(
        "--endpoint",
        action="append",
        default=[],
        metavar="URL_OR_HOST",
        help=(
            "Whitelist a host the operator has confirmed is real. "
            "Escape-hatch for RULE 17, which otherwise rejects "
            "placeholder-looking endpoints (e.g. `*.invalid`, "
            "`contoso.com`, `localhost`) anywhere under `configurations[]` "
            "or `resources.{endpoints,delegates,http_endpoints}[]`. "
            "Accepts a URL or bare host substring; repeatable."
        ),
    )
    return p


def run_init(args: argparse.Namespace) -> int:
    # ── auto-load.env so credentials sitting in./.env or
    #    <git-root>/.env are visible without an explicit `source.env`
    #    (credential auto-loading). Honoured for credential-family keys only; pre-set env
    #    vars always win. ──────────────────────────────────────────────
    try:
        env_path, env_keys = load_credentials_env(args.env_file)
    except FileNotFoundError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    if env_path is not None and env_keys:
        print(f"Loaded credentials from {env_path}", file=sys.stderr)

    # Surface AACS environment status before starting the design loop.
    #
    # The previous CLI only complained about AACS env wiring *after*
    # the design loop, via `validate_aacs_intent_satisfied`, and only
    # when the brief used AACS vocabulary ("AACS", "jailbreak",
    # "prompt injection"). A customer who set `AZURE_CONTENT_SAFETY_KEY`
    # but forgot the endpoint, AND whose brief was a finance / health /
    # regulated-domain use case ("don't help with financial crime")
    # without the magic AACS words, would see no warning at all — the
    # CLI silently shipped regex-only Stage 1 (often too narrow) and
    # the customer never knew AACS was on the table.
    #
    # Surface AACS env-pair status loud and clear, BEFORE any LLM
    # tokens are spent, naming BOTH env var names in every shape so a
    # half-configured `.env` is fixable in one round-trip.
    _emit_aacs_env_status(file=sys.stderr)

    # ── resolve provider config ────────────────────────────────────
    provider = args.provider or os.environ.get("AGENT_SHIELD_PROVIDER")
    model = args.model or os.environ.get("AGENT_SHIELD_MODEL")

    # provider inference — when neither `--provider` nor `$AGENT_SHIELD_PROVIDER`
    # is supplied, infer the provider from the credential-family env
    # vars actually present. The the classifier-fallback case customer hit a dead-end: their
    # `.env` had AZURE_OPENAI_ENDPOINT + AZURE_OPENAI_KEY +
    # AZURE_OPENAI_DEPLOYMENT but the CLI still failed with
    # "--provider and --model are required" because Azure deployment inference's
    # deployment-as-model default only activates AFTER
    # `--provider azure` is supplied. Inferring the provider
    # closes that loop: the docs' copy-pasteable command works
    # without the customer needing to know about `--provider azure`.
    if not provider:
        inferred = infer_provider_from_env(provider=provider, model=model)
        if inferred is not None:
            provider = inferred.provider
            if not model and inferred.model:
                model = inferred.model
            print(
                f"  ⓘ inferred provider={inferred.provider}"
                + (f" model={inferred.model}" if inferred.model else "")
                + " from environment (provider inference).",
                file=sys.stderr,
            )

    # Azure deployment inference — when the customer points the CLI at Azure and has
    # `AZURE_OPENAI_DEPLOYMENT` set (the deployment-name env var
    # that every Azure-aware adapter consumes) but didn't pass
    # `--model`, default the model to the deployment name. This
    # mirrors what every other Azure-aware SDK does and removes the
    # surprising "you set everything and it still demands --model"
    # friction the customer hit. Pre-set `--model` /
    # `AGENT_SHIELD_MODEL` always win — this only fills the gap.
    if not model and (provider or "").lower() == "azure":
        deployment = os.environ.get("AZURE_OPENAI_DEPLOYMENT")
        if deployment:
            model = deployment
            print(
                f"  ⓘ --model defaulted to AZURE_OPENAI_DEPLOYMENT "
                f"({deployment}) (Azure deployment inference).",
                file=sys.stderr,
            )
    if not provider or not model:
        print(
            "error: --provider and --model are required (or set "
            "AGENT_SHIELD_PROVIDER / AGENT_SHIELD_MODEL).",
            file=sys.stderr,
        )
        return 2

    if args.non_interactive and not args.describe:
        print(
            "error: --non-interactive requires --describe to give the LLM "
            "enough context to proceed without questions.",
            file=sys.stderr,
        )
        return 2

    # non-interactive shell detection — auto-detect non-interactive shell.
    #
    # When the CLI is invoked from automation (CI, agent harness,
    # subprocess, `< /dev/null`), the design loop's "[a]ccept /
    # [r]efine / [s]kip >" prompt has no human on the other end and
    # `input()` hangs until the parent kills the process. Default to
    # `--non-interactive` whenever stdin is not a TTY so the same
    # command works in both shells without an extra flag.
    #
    # Honors AgentShield's "sensible defaults > flags" principle: the
    # right behavior happens by default, the customer doesn't have to
    # know to ask for it. We print a one-line notice so the behavior
    # isn't invisible (silent mode-switches are surprising).
    if not args.non_interactive and not _stdin_is_interactive():
        print(
            "  ⓘ stdin is not a TTY; running in --non-interactive mode "
            "(non-interactive shell detection).",
            file=sys.stderr,
        )
        args.non_interactive = True
        if not args.describe:
            print(
                "error: non-interactive runs require --describe so the "
                "LLM has enough context to proceed without questions. "
                "Re-run with --describe \"<one-or-two-sentence brief>\".",
                file=sys.stderr,
            )
            return 2

    out_path: Path = args.output
    parent_path: Optional[Path] = args.from_path

    # ── same-file UX guard ─────────────────────────────────────────
    if parent_path is not None:
        try:
            same = out_path.resolve() == parent_path.resolve()
        except OSError:
            same = False
        if same:
            print(
                "error: --from and --output resolve to the same path "
                "(would create an extends self-cycle). Choose a different "
                "--output.",
                file=sys.stderr,
            )
            return 2
        if not parent_path.exists():
            print(f"error: --from path not found: {parent_path}", file=sys.stderr)
            return 1

    if os.path.lexists(out_path) and not args.force and not args.dry_run:
        print(
            f"error: {out_path} already exists. Pass --force to overwrite, "
            f"or --dry-run to preview.",
            file=sys.stderr,
        )
        return 1

    # Preflight the output parent so we never spend LLM tokens on a
    # run that can't write its result. --dry-run does not write, so
    # this check is skipped in that mode.
    if not args.dry_run:
        try:
            out_path.parent.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            print(
                f"error: cannot create output directory {out_path.parent}: "
                f"{exc}",
                file=sys.stderr,
            )
            return 1

    # ── parse sources ──────────────────────────────────────────────
    try:
        sources = load_tools(
            mcp_paths=list(args.mcp or []),
            openai_path=args.openai_tools,
            anthropic_path=args.anthropic_tools,
        )
    except SourceParseError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    # ── tool-schema sidecar (RULE 16) ──────────────────────
    # Optional. When supplied, the schema augments the source loader's
    # ToolEntry.input_schema with declared `params:` and populates
    # ToolEntry.output_schema with declared `returns:`, letting the
    # post-generation validator reject hallucinated `@result.<field>`
    # populator expressions. When NOT supplied the CLI emits a
    # non-fatal warning telling the customer that their generated
    # YAML's `@result.<field>` references won't be checked.
    try:
        tool_schema = _load_tool_schema(
            path=getattr(args, "tool_schema", None),
            inline=getattr(args, "tool_schema_inline", None),
        )
    except _ToolSchemaError as exc:
        print(f"error: --tool-schema: {exc}", file=sys.stderr)
        return 1
    if tool_schema:
        sources.tools = _merge_tool_schema(sources.tools, tool_schema)

    # ── parent introspection (force-compile to catch a broken parent
    #    upfront, before the LLM bills any tokens) ──────────────────
    existing_tool_names: List[str] = []
    if parent_path is not None:
        try:
            existing_tool_names = parent_tool_names(parent_path)
        except ValidationError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 1

    # ── build context ──────────────────────────────────────────────
    # Collect credential-family env vars actually present (post-`.env`
    # merge). The DesignContext threads these into the system prompt
    # so the LLM grounds RULE 6 / RULE 7 decisions against reality,
    # and `_build_validation_context` re-collects the same set so the
    # post-generation validators stay in lockstep.
    available_env_keys = sorted(
        k for k in _CREDENTIAL_ENV_KEYS if os.environ.get(k)
    )
    try:
        ctx = DesignContext.from_inputs(
            sources=sources,
            description=args.describe,
            parent_path=parent_path,
            parent_tool_names=existing_tool_names,
            available_env_keys=available_env_keys,
        )
        system_prompt = build_system_prompt(ctx)
    except FileNotFoundError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    # ── construct caller ──────────────────────────────────────────
    try:
        caller = build_caller(provider=provider, model=model, api_key=args.api_key)
    except LlmError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    # ── banner ────────────────────────────────────────────────────
    print(
        f"agent-shield init — {provider} / {model}\n"
        f"  tools: {len(sources.tools)} | "
        f"parent: {parent_path or '(none)'} | "
        f"output: {out_path}{' (dry-run)' if args.dry_run else ''}",
        file=sys.stderr,
    )
    if sources.notes:
        for note in sources.notes:
            print(f"  ⓘ {note}", file=sys.stderr)

    # RULE 16 — surface the no-schema warning early so the
    # customer sees it before the LLM starts billing tokens. The
    # warning is non-fatal; the design loop runs either way.
    if not tool_schema:
        print(
            "  ⚠ warning: no --tool-schema supplied. Generated "
            "`@result.<field>` expressions are not validated against "
            "your tool's actual return shape — the YAML may carry "
            "hallucinated field names that silently leave variables "
            "`unset` at runtime. Pass `--tool-schema <path-to-json>` "
            "(or `--tool-schema-inline '<json>'`) to enable RULE 16 "
            "validation, or expect to hand-edit the generated YAML. "
            "(RULE 16.)",
            file=sys.stderr,
        )

    # ── build earlier semantic check validation context ──────────────────────────────
    # We pull declared tool parameter names from the source loader's
    # `input_schema` so the post-generation validators can reject
    # `@tool.params.<unknown>` references (unbound tool-parameter references). The brief
    # text powers the approval-modeling, path-traversal, and
    # action-verb checks.
    validation_context = _build_validation_context(
        ctx,
        tool_schema_provided=bool(tool_schema),
        endpoint_overrides=list(getattr(args, "endpoint", None) or []),
    )

    # ── AACS pre-flight env-var check ─────────────────────────────────────────────
    # The post-generation `validate_aacs_intent_satisfied` raises the
    # same diagnostic at the end of `run_design_loop`. Customers hit
    # by the AACS pre-flight case spent 10–15s of Azure tokens generating a YAML draft
    # that was destined to be rejected on the missing env pair.
    # Lift the env check to a pre-flight: when the brief asks for
    # AACS / jailbreak / content-safety intent but the env pair is
    # not set, abort before the LLM is called at all. The "what to
    # add to.env" hint is unchanged.
    try:
        validate_aacs_env_preflight(validation_context)
    except ValidationError as exc:
        print(f"\n✗ {exc}", file=sys.stderr)
        return 1

    # ── design loop ───────────────────────────────────────────────
    result = run_design_loop(
        caller=caller,
        system_prompt=system_prompt,
        parent_path=parent_path,
        non_interactive=args.non_interactive,
        max_turns=args.max_turns,
        validation_context=validation_context,
    )
    if result.aborted or result.final_yaml is None:
        print(f"\n✗ aborted: {result.abort_reason}", file=sys.stderr)
        _emit_failure_classification(result, file=sys.stderr)
        # draft persistence: always surface the model's last YAML draft so the
        # customer can inspect / hand-edit. `--dry-run` only prints to
        # stderr (no filesystem writes); the normal path writes the
        # draft next to the would-be output.
        _persist_or_dump_draft(
            result=result,
            out_path=out_path,
            provider=provider,
            model=model,
            dry_run=args.dry_run,
        )
        return 1

    # ── re-write extends to a path relative to the on-disk output,
    #    if --from was used. The design agent injects an absolute path
    #    so validation works regardless of cwd; we make the final
    #    on-disk reference portable. ──────────────────────────────
    if parent_path is not None and isinstance(result.final_data, dict):
        rel = _relative_for_extends(parent_path, out_path)
        result.final_data["extends"] = [rel]

    # ── multi-agent disclosure: surface a warning if the brief describes a multi-
    #    agent / handoff flow but the generated YAML carries no
    #    delegate / `kind: agent` shape. The check is advisory (does
    #    not abort); auto-generation of delegate resolver bodies is
    #    deferred — wrong agent names cause more grief than the
    #    missing resolver. See RULE 15 in `_context.py`.
    if isinstance(result.final_data, dict):
        warnings = multi_agent_disclosure_warnings(
            result.final_data, validation_context
        )
        for warning in warnings:
            print(f"  ⚠ warning: {warning}", file=sys.stderr)

    # ── endpoint env-var interpolation: env-var interpolation + REPLACE_WITH failsafe ──────
    # The design loop's per-turn validation already substitutes
    # `${env.X}` placeholders and rejects `REPLACE_WITH` URLs (see
    # `_run_semantic_checks`), but defense-in-depth: re-run them on
    # the final dict here so the on-disk write path stays correct
    # even if a caller bypasses the design loop (e.g. embeds
    # `validate_on_disk` after a manual emit).
    if isinstance(result.final_data, dict):
        interpolate_env_placeholders(result.final_data)
        try:
            validate_no_replace_with_endpoint(
                result.final_data, validation_context
            )
        except ValidationError as exc:
            print(
                f"error: refusing to write YAML with placeholder "
                f"endpoint (endpoint env-var interpolation):\n  ↳ {exc}",
                file=sys.stderr,
            )
            return 1

    # ── re-emit through the comment-aware emitter (for spec-section
    #    headers + round-trip safety) ───────────────────────────────
    try:
        text = emit_yaml(
            result.final_data,
            header_notes=[f"Designed with {provider}/{model}."],
        )
    except RuntimeError as exc:
        print(f"error: emitter failed: {exc}", file=sys.stderr)
        return 1

    if args.dry_run:
        sys.stdout.write(text)
    else:
        # Atomic write: stage the candidate next to the destination,
        # validate it on disk, only swap into place if it compiles.
        # This protects an existing target file (the common --force
        # case) from being clobbered by an LLM-produced YAML that
        # fails the post-write smoke check.
        #
        # The staging path is created with exclusive flags
        # (O_CREAT | O_EXCL) under a unique name so we never overwrite
        # a sibling that happens to share the staging suffix, and
        # concurrent invocations targeting the same --output do not
        # race for the same temp path.
        import tempfile

        try:
            fd, staging_str = tempfile.mkstemp(
                prefix=f".{out_path.name}.",
                suffix=".agent-shield-init.tmp",
                dir=str(out_path.parent),
            )
            staging = Path(staging_str)
        except OSError as exc:
            print(
                f"error: could not create staging file in {out_path.parent}: {exc}",
                file=sys.stderr,
            )
            return 1

        try:
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    f.write(text)
            except OSError as exc:
                print(f"error: could not write staging file: {exc}", file=sys.stderr)
                return 1

            # mkstemp defaults to 0o600; we want the generated file to
            # have ordinary readable permissions (so build / deploy
            # processes that previously read.guardrails.yaml still
            # can). If the destination already exists, preserve its
            # mode on overwrite. Otherwise use 0o644, which matches
            # what `open(path, "w").write(...)` would produce on the
            # default POSIX umask of 022 (the previous CLI behaviour).
            # We intentionally do NOT read+restore the process umask
            # to compute this — umask is process-global, and toggling
            # it would race against any concurrent file creation in
            # the same process (which happens if a caller embeds
            # agent_shield_cli.main in a larger Python service).
            try:
                if out_path.exists() and not out_path.is_symlink():
                    target_mode = out_path.stat().st_mode & 0o7777
                else:
                    target_mode = 0o644
                os.chmod(staging, target_mode)
            except OSError:
                # Best-effort: some filesystems (e.g. FAT on Windows)
                # ignore chmod. Don't fail the run over permission
                # metadata.
                pass

            try:
                validate_on_disk(staging)
            except ValidationError as exc:
                print(
                    "error: post-write validation failed (final config did "
                    f"not compile on disk):\n  ↳ {exc}",
                    file=sys.stderr,
                )
                return 1

            # Recheck no-clobber just before the swap. The initial
            # check at the top of run_init can be minutes old by the
            # time the LLM conversation finishes; another process
            # could have created the file in between. With --force the
            # user has opted into overwrite; without it, we refuse.
            if not args.force and os.path.lexists(out_path):
                print(
                    f"error: {out_path} appeared during the design "
                    "conversation. Re-run with --force if you intend to "
                    "overwrite, or choose a different --output.",
                    file=sys.stderr,
                )
                return 1

            # os.replace is atomic on POSIX and Windows; replaces target
            # only if validation passed, preserving the prior file bytes
            # up to this point.
            os.replace(staging, out_path)
        finally:
            # In any error path that left the staging file behind, drop
            # it so we don't accumulate cruft on repeated invocations.
            if staging.exists():
                try:
                    staging.unlink()
                except OSError:
                    pass

        print(f"\n✔ wrote {out_path} ({result.turns} turn(s))", file=sys.stderr)
        print(
            "  Next: review the inline comments, refine objective.forbidden "
            "for your specific risks, and run your test suite against the "
            "new file.",
            file=sys.stderr,
        )
    return 0


__all__ = ["InferredProvider", "add_init_parser", "infer_provider_from_env", "run_init"]


def _build_validation_context(
    ctx: DesignContext,
    *,
    tool_schema_provided: bool = False,
    endpoint_overrides: Optional[List[str]] = None,
) -> ValidationContext:
    """Pack the design context's brief + tool schemas into the shape
    the post-generation validators consume.

    The brief text drives the approval / path-traversal / verb-match
    checks; the tool-parameter index drives the unbound-field check.
    Tools whose source file did not carry a JSON schema (or carried
    one with no ``properties``) are *omitted* from the index — the
    validator skips those rather than false-firing on tools whose
    parameter shape we don't know.

    The credential-family ``env_keys`` (post-``.env``-merge from
    :func:`load_credentials_env`, then OR'd with anything pre-set in
    the current ``os.environ``) lets the placeholder URL / agent-vs-delegate / AACS classifier configuration validators
    ground their checks: ``kind: agent`` is only a meaningful
    suggestion when at least one agent-capable LLM credential is
    present, and the AACS classifier endpoint check only fires when
    ``AZURE_CONTENT_SAFETY_KEY`` is actually available to bind to.

    The ``tool_result_index`` is built from ``ToolEntry.output_schema``
    (populated by ``--tool-schema``); it drives RULE 16. The
    ``endpoint_overrides`` list (from ``--endpoint``) carries host
    substrings the customer has authorized, suppressing RULE 17 for
    those hosts.
    """
    index: dict[str, frozenset[str]] = {}
    result_index: dict[str, frozenset[str]] = {}
    for t in ctx.tools:
        schema = t.input_schema
        if isinstance(schema, dict):
            props = schema.get("properties")
            if isinstance(props, dict) and props:
                names = frozenset(k for k in props.keys() if isinstance(k, str))
                if names:
                    index[t.name] = names

        out_schema = getattr(t, "output_schema", None)
        if isinstance(out_schema, dict):
            out_props = out_schema.get("properties")
            if isinstance(out_props, dict) and out_props:
                out_names = frozenset(
                    k for k in out_props.keys() if isinstance(k, str)
                )
                if out_names:
                    result_index[t.name] = out_names

    # Credential-family env keys actually present in the running
    # process. We pull from os.environ (which by this point includes
    # anything the.env loader merged in) and intersect with the
    # known credential allowlist so we never leak unrelated env into
    # the validators' decision surface.
    env_keys = frozenset(
        k for k in _CREDENTIAL_ENV_KEYS if os.environ.get(k)
    )

    # Allowed endpoint hosts — extract host substring from each
    # `--endpoint` value, lower-case. The validator does substring
    # matching so users can pass either a full URL or a bare host.
    allowed_hosts = frozenset(
        host for e in (endpoint_overrides or [])
        if (host := _extract_host_substring(e))
    )
    return ValidationContext(
        brief_text=ctx.description or "",
        tool_param_index=index,
        env_keys=env_keys,
        tool_result_index=result_index,
        tool_schema_provided=tool_schema_provided,
        allowed_endpoint_hosts=allowed_hosts,
    )


def _extract_host_substring(raw: str) -> str:
    """Extract a lower-cased host fragment from a `--endpoint` value.

    Accepts a full URL (``https://api.example.com:8443/path``) or a
    bare host (``api.example.com``). Bare-host inputs are returned
    verbatim (lower-cased). For URLs we use ``urllib.parse`` and
    fall back to the leading segment up to ``/`` if parsing fails.
    """
    if not isinstance(raw, str) or not raw.strip():
        return ""
    raw = raw.strip()
    if "://" in raw:
        try:
            from urllib.parse import urlparse
            parsed = urlparse(raw)
            host = parsed.hostname or parsed.netloc
            if host:
                return host.lower()
        except (ValueError, AttributeError):
            pass
    return raw.split("/", 1)[0].split(":", 1)[0].lower()


# ─── Tool-schema sidecar loader (RULE 16) ──────────────────


class _ToolSchemaError(ValueError):
    """Raised on a malformed ``--tool-schema`` sidecar."""


def _load_tool_schema(
    *, path: Optional[Path], inline: Optional[str]
) -> Dict[str, Dict[str, Dict[str, Any]]]:
    """Parse the tool-schema sidecar(s) into a normalized dict.

    Returns a mapping ``{tool_name: {"params": {field: type},
    "returns": {field: type}}}``. Both inputs are optional; when
    neither is supplied the result is an empty dict.

    File and inline JSON are merged with the file winning on
    conflicting tool names (the file is the authoritative ground
    truth; inline overrides are for quick one-liners and tests).
    """
    import json

    merged: Dict[str, Dict[str, Dict[str, Any]]] = {}

    def _parse_blob(blob: str, source: str) -> None:
        try:
            data = json.loads(blob)
        except json.JSONDecodeError as exc:
            raise _ToolSchemaError(
                f"{source}: not valid JSON: {exc}"
            ) from exc
        if not isinstance(data, dict):
            raise _ToolSchemaError(
                f"{source}: top-level must be an object mapping "
                f"tool names to their {{params, returns}} schemas"
            )
        for tool_name, body in data.items():
            if not isinstance(tool_name, str) or not tool_name:
                raise _ToolSchemaError(
                    f"{source}: tool name must be a non-empty string "
                    f"(saw {tool_name!r})"
                )
            if not isinstance(body, dict):
                raise _ToolSchemaError(
                    f"{source}: entry for `{tool_name}` must be an "
                    f"object (saw {type(body).__name__})"
                )
            params = body.get("params") or body.get("parameters") or {}
            returns = body.get("returns") or body.get("return") or {}
            if not isinstance(params, dict):
                raise _ToolSchemaError(
                    f"{source}: `{tool_name}.params` must be an "
                    f"object mapping field-name -> type"
                )
            if not isinstance(returns, dict):
                raise _ToolSchemaError(
                    f"{source}: `{tool_name}.returns` must be an "
                    f"object mapping field-name -> type"
                )
            merged[tool_name] = {
                "params": {str(k): v for k, v in params.items()},
                "returns": {str(k): v for k, v in returns.items()},
            }

    if inline is not None and inline.strip():
        _parse_blob(inline, "--tool-schema-inline")
    if path is not None:
        try:
            blob = path.read_text(encoding="utf-8")
        except OSError as exc:
            raise _ToolSchemaError(f"{path}: {exc}") from exc
        _parse_blob(blob, str(path))

    return merged


def _merge_tool_schema(
    tools, schema: Dict[str, Dict[str, Dict[str, Any]]]
):
    """Return a new tool list with ``input_schema`` / ``output_schema``
    augmented from the sidecar.

    For each declared tool we synthesize a minimal JSON-Schema-shaped
    dict (``{type: object, properties: {field: {type: ...}}}``) for
    both params and returns so the downstream prompt rendering
    (``_summarize_schema``) and the validators
    (``tool_param_index`` / ``tool_result_index``) see the new
    fields. Tools that already carry an ``input_schema`` with
    ``properties`` keep theirs; the sidecar only fills the gap.

    Tools in the sidecar that are NOT in the loaded source list are
    appended as new ``ToolEntry`` instances with
    ``source_label="tool-schema"`` so the LLM still sees them in
    the prompt's "Tools available to the agent" block.
    """
    from ._sources._models import ToolEntry

    out: List[Any] = []
    seen: set[str] = set()

    def _wrap_props(fields: Dict[str, Any]) -> Optional[dict]:
        if not isinstance(fields, dict) or not fields:
            return None
        properties: Dict[str, Dict[str, Any]] = {}
        for name, type_token in fields.items():
            type_str = type_token if isinstance(type_token, str) else "any"
            properties[name] = {"type": type_str}
        return {"type": "object", "properties": properties}

    for t in tools:
        entry_schema = schema.get(t.name)
        if entry_schema is None:
            out.append(t)
            seen.add(t.name)
            continue

        params_props = _wrap_props(entry_schema.get("params") or {})
        returns_props = _wrap_props(entry_schema.get("returns") or {})

        new_input = t.input_schema
        if params_props and not (
            isinstance(new_input, dict)
            and isinstance(new_input.get("properties"), dict)
            and new_input["properties"]
        ):
            new_input = params_props
        new_output = t.output_schema if t.output_schema else returns_props

        out.append(
            ToolEntry(
                name=t.name,
                description=t.description,
                source_label=t.source_label or "tool-schema",
                input_schema=new_input,
                output_schema=new_output,
            )
        )
        seen.add(t.name)

    for tool_name, entry_schema in schema.items():
        if tool_name in seen:
            continue
        params_props = _wrap_props(entry_schema.get("params") or {})
        returns_props = _wrap_props(entry_schema.get("returns") or {})
        out.append(
            ToolEntry(
                name=tool_name,
                description="",
                source_label="tool-schema",
                input_schema=params_props,
                output_schema=returns_props,
            )
        )

    return out


# Mirrors `_dotenv._ALLOWED_KEYS`. Kept local rather than imported
# so the validator's notion of "what counts as credentials" stays
# tied to the CLI's intent (the.env allowlist is about what we are
# willing to *load*; here we're scoring what is *available*).
_CREDENTIAL_ENV_KEYS: frozenset[str] = frozenset(
    {
        "OPENAI_API_KEY",
        "ANTHROPIC_API_KEY",
        "AZURE_OPENAI_API_KEY",
        "AZURE_OPENAI_ENDPOINT",
        "AZURE_OPENAI_API_VERSION",
        "AZURE_OPENAI_DEPLOYMENT",
        "AZURE_CONTENT_SAFETY_KEY",
        "AZURE_CONTENT_SAFETY_ENDPOINT",
    }
)


def _emit_aacs_env_status(*, file=None) -> None:
    """Print a one-line AACS env-pair status banner.

    Three states, named so the customer can tell at a glance whether
    AACS Stage 1 will be on the table for this run:

      * BOTH ``AZURE_CONTENT_SAFETY_ENDPOINT`` and
        ``AZURE_CONTENT_SAFETY_KEY`` are set →
        "ⓘ AACS Stage 1 available: AZURE_CONTENT_SAFETY_* env vars
        detected — the design agent will be told to emit a Stage 1
        classifier."
      * EXACTLY ONE is set → warning naming BOTH env var names and
        explicitly stating AACS requires both.
        A half-configured `.env` can otherwise leave the
        customer set the key, the warning quietly named only the
        missing endpoint as part of validator failure, and the
        customer didn't realise AACS was completely off the table.
      * NEITHER is set → one-line hint that AACS is the preferred
        Stage 1 prompt-injection / content-safety path so the
        customer knows the regex-only fallback they're about to get
        is the second-best shape.

    ``file`` defaults to ``sys.stderr`` resolved at call time (not
    module-load time), so pytest's ``capsys`` fixture — which swaps
    ``sys.stderr`` per-test — captures the output correctly.
    """
    if file is None:
        file = sys.stderr

    have_endpoint = bool(os.environ.get("AZURE_CONTENT_SAFETY_ENDPOINT"))
    have_key = bool(os.environ.get("AZURE_CONTENT_SAFETY_KEY"))

    if have_endpoint and have_key:
        print(
            "  ⓘ AACS Stage 1 available: AZURE_CONTENT_SAFETY_ENDPOINT "
            "and AZURE_CONTENT_SAFETY_KEY env vars detected — the "
            "design agent will be instructed to emit a Stage 1 "
            "`provider: microsoft.azure.content_safety` classifier.",
            file=file,
        )
        return

    if have_endpoint or have_key:
        present = (
            "AZURE_CONTENT_SAFETY_KEY" if have_key
            else "AZURE_CONTENT_SAFETY_ENDPOINT"
        )
        missing = (
            "AZURE_CONTENT_SAFETY_ENDPOINT" if have_key
            else "AZURE_CONTENT_SAFETY_KEY"
        )
        print(
            f"  ⚠ warning: {present} is set but {missing} is not. "
            f"AACS requires BOTH `AZURE_CONTENT_SAFETY_ENDPOINT` and "
            f"`AZURE_CONTENT_SAFETY_KEY` to be present — setting only "
            f"one leaves AACS Stage 1 unconfigured and falls back to "
            f"regex-only Stage 1. Add the missing "
            f"value to your `.env` to enable AACS.",
            file=file,
        )
        return

    print(
        "  ⓘ AACS not configured (neither AZURE_CONTENT_SAFETY_ENDPOINT "
        "nor AZURE_CONTENT_SAFETY_KEY in env). Stage 1 will fall back "
        "to a regex bank — consider enabling Azure AI Content Safety "
        "for production use cases (set both env vars in your `.env`).",
        file=file,
    )


# ─── provider inference — Provider inference from environment ──────────────────


@dataclass(frozen=True)
class InferredProvider:
    """Provider+model inferred from the host's credential-family env.

    ``provider`` is the lower-case provider identifier the CLI's
    ``--provider`` flag accepts (``azure`` / ``openai`` /
    ``anthropic``). ``model`` is None for providers where we cannot
    derive a model name from env alone (OpenAI / Anthropic); the
    customer must still supply ``--model`` or ``AGENT_SHIELD_MODEL``
    in those cases. For Azure, ``model`` is populated from
    ``AZURE_OPENAI_DEPLOYMENT`` — the Azure deployment inference default — so the
    full provider+model pair can come from env alone when the
    customer has the complete Azure OpenAI triple set.
    """

    provider: str
    model: Optional[str]


def infer_provider_from_env(
    *,
    provider: Optional[str],
    model: Optional[str],
) -> Optional[InferredProvider]:
    """Pick a (provider, model) pair from process env when the user
    has not supplied ``--provider`` (provider inference).

    Precedence (deterministic):

      1. **azure** — when ``AZURE_OPENAI_ENDPOINT`` AND ``AZURE_OPENAI_DEPLOYMENT``
         AND at least one of ``AZURE_OPENAI_KEY`` / ``AZURE_OPENAI_API_KEY``
         are all set. The Azure triple is a deliberate three-variable
         intent signal, so it outranks single-key providers when
         multiple are configured. Model defaults to the deployment
         name (matches Azure deployment inference's behavior once `--provider azure` is
         set).
      2. **openai** — when ``OPENAI_API_KEY`` is set.
      3. **anthropic** — when ``ANTHROPIC_API_KEY`` is set.

    Returns ``None`` when:

      * ``provider`` was supplied explicitly (caller wins; this
        helper is a fallback, not an override).
      * No inferable env is set.

    The function does not touch ``model``: a model can still be
    inferred even when this returns None (e.g. Azure deployment inference's
    ``AZURE_OPENAI_DEPLOYMENT`` -> --model fallback inside
    ``run_init``).
    """
    if provider:
        # Caller (CLI flag / `$AGENT_SHIELD_PROVIDER`) wins.
        return None

    have_az_endpoint = bool(os.environ.get("AZURE_OPENAI_ENDPOINT"))
    have_az_key = bool(
        os.environ.get("AZURE_OPENAI_API_KEY")
        or os.environ.get("AZURE_OPENAI_KEY")
    )
    az_deployment = os.environ.get("AZURE_OPENAI_DEPLOYMENT")
    if have_az_endpoint and have_az_key and az_deployment:
        return InferredProvider(provider="azure", model=az_deployment)

    if os.environ.get("OPENAI_API_KEY"):
        return InferredProvider(provider="openai", model=None)

    if os.environ.get("ANTHROPIC_API_KEY"):
        return InferredProvider(provider="anthropic", model=None)

    return None


def _stdin_is_interactive() -> bool:
    """True iff the process can plausibly prompt the user (non-interactive shell detection).

    Wrapped as a module-level helper so tests can monkeypatch it
    without faking ``sys.stdin``. ``stdin.isatty()`` raises on some
    detached-stdin shapes (``sys.stdin is None`` under embedded
    interpreters); fall back to ``False`` on any failure — the
    fail-closed direction here is "assume non-interactive", which
    matches the bug's fix direction.
    """
    try:
        stdin = sys.stdin
        if stdin is None:
            return False
        return bool(stdin.isatty())
    except (AttributeError, ValueError, OSError):
        return False


def _relative_for_extends(parent: Path, child: Path) -> str:
    """Path string for the child's ``extends:`` entry.

    Resolves both sides, expresses the parent relative to the child's
    directory, and forces forward slashes for portability. Falls back
    to an absolute path on Windows cross-drive ``ValueError``.
    """
    child_dir = child.parent.resolve()
    parent_abs = parent.resolve()
    try:
        rel = os.path.relpath(parent_abs, start=child_dir)
    except ValueError:
        rel = str(parent_abs)
    return rel.replace(os.sep, "/")


# ─── Failure-path draft persistence (transient-failure retry + draft persistence) ────────────────
#
# When `agent-shield init` aborts (rate-limit, validation-exhausted,
# user-aborted, …), the customer used to get nothing — no YAML on
# disk, no draft, nothing to hand-edit. The fix here:
#
# 1. Write the model's most recent YAML proposal to `<out>.draft` so
#    the customer can inspect / fix / re-validate manually.
# 2. Print a one-line cause classification so the customer can decide
#    between "retry in a minute" and "loosen --describe".
# 3. If even the draft write fails, dump between fenced markers on
#    stderr so the customer can copy-paste — losing model output to
#    a secondary failure repeats the draft persistence sin.
# 4. `--dry-run` skips the file write (semantics: no filesystem
#    touches at all) but still dumps to stderr.

_DRAFT_BEGIN = "--- BEGIN DRAFT ---"
_DRAFT_END = "--- END DRAFT ---"


def _emit_failure_classification(result, *, file) -> None:
    """One-line, human-readable hint on what to do next."""
    kind = result.failure_kind
    if kind == "rate_limit":
        print(
            "cause: rate-limited by the model provider after backoff. "
            "Wait a minute and re-run with --force.",
            file=file,
        )
    elif kind == "validation_exhausted":
        print(
            "cause: model could not produce schema-valid YAML within "
            "the self-correct budget. Inspect the draft and hand-edit, "
            "or re-run with a more specific --describe.",
            file=file,
        )
    elif kind == "budget_exhausted":
        print(
            "cause: hit --max-turns before reaching `done`. Re-run with "
            "a larger --max-turns, or tighten --describe.",
            file=file,
        )
    elif kind == "llm_error":
        print(
            "cause: model provider returned a non-retryable error. "
            "Check credentials, deployment / model name, and quota.",
            file=file,
        )
    elif kind == "invariant_failed":
        print(
            "cause: model violated the action protocol. Re-run; if it "
            "recurs, file a CLI bug with the draft attached.",
            file=file,
        )
    # `user_aborted` and unknown kinds: no extra line; the abort
    # reason already explains it.


def _persist_or_dump_draft(
    *,
    result,
    out_path: Path,
    provider: str,
    model: str,
    dry_run: bool,
) -> None:
    """Persist the model's last YAML (or dump it to stderr if writing fails).

    The draft file lives next to ``out_path`` with a ``.draft`` suffix
    appended to its full name (``.guardrails.yaml`` →
    ``.guardrails.yaml.draft``). Permissions match the orchestrator's
    final-file convention (umask-respecting 0o644 by default); the
    draft and the final file carry the same class of content (the
    customer's brief, tool names, prompts), so asymmetric perms would
    be misleading.

    Drafts are always overwritten — they are diagnostic output, not
    user content; the customer cares about the *last* failure, and
    numbered drafts (``.draft.1`` / ``.draft.2``) would just create
    cleanup debt.
    """
    yaml_text = result.last_yaml
    if not yaml_text:
        print(
            "  ⓘ no draft to save — model never produced a YAML proposal.",
            file=sys.stderr,
        )
        return

    header = _draft_header(result, provider=provider, model=model)
    body = header + yaml_text
    if not body.endswith("\n"):
        body += "\n"

    if dry_run:
        # --dry-run on a failing config is exactly when the diagnostic
        # matters most. Dump between fenced markers so the customer can
        # copy-paste into a file and edit.
        sys.stderr.write(f"\n{_DRAFT_BEGIN}\n{body}{_DRAFT_END}\n")
        sys.stderr.flush()
        return

    draft_path = Path(str(out_path) + ".draft")
    try:
        draft_path.parent.mkdir(parents=True, exist_ok=True)
        # Use module-level ``open`` (not ``draft_path.open``) so the failure
        # path remains mockable by tests that need to simulate a disk-full
        # or permission-denied draft write. ``Path.open`` would bypass any
        # patch on this module's ``open`` reference.
        with open(draft_path, "w", encoding="utf-8") as f:
            f.write(body)
    except OSError as exc:
        # Secondary failure: do not lose the YAML. Echo to stderr.
        print(
            f"  ⓘ could not write draft to {draft_path}: {exc}\n"
            f"  ⓘ dumping draft to stderr instead:",
            file=sys.stderr,
        )
        sys.stderr.write(f"\n{_DRAFT_BEGIN}\n{body}{_DRAFT_END}\n")
        sys.stderr.flush()
        return

    print(
        f"  ⓘ saved last draft to {draft_path}. Inspect and hand-edit.",
        file=sys.stderr,
    )


def _draft_header(result, *, provider: str, model: str) -> str:
    """Top-of-draft comment block explaining what this file is.

    Kept short on purpose: timestamp + classification + abort reason.
    The customer who comes back to this file Friday afternoon should
    understand in three seconds why it's there and what state it's in.
    """
    import datetime

    ts = datetime.datetime.now().astimezone().isoformat(timespec="seconds")
    kind = result.failure_kind or "unknown"
    reason = (result.abort_reason or "").replace("\n", " ").strip()
    return (
        f"# agent-shield init draft — NOT VALIDATED, hand-edit before use.\n"
        f"# generated_at: {ts}\n"
        f"# provider/model: {provider}/{model}\n"
        f"# failure_kind: {kind}\n"
        f"# abort_reason: {reason}\n"
        f"#\n"
        f"# This is the most recent YAML the model emitted before the\n"
        f"# CLI aborted. It may be syntactically invalid or fail schema\n"
        f"# validation. Fix it by hand, then run:\n"
        f"#   python -c \"from agent_shield import RuntimeBuilder; "
        f"RuntimeBuilder.from_yaml('<this-file>').build()\"\n"
        f"# to confirm it loads, or move it into place as your\n"
        f"# .guardrails.yaml when ready.\n"
        f"\n"
    )
