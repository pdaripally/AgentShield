"""Allow ``python -m agent_shield_cli`` to invoke the CLI."""
from __future__ import annotations

import sys

from ._entry import main

if __name__ == "__main__":
    sys.exit(main())
