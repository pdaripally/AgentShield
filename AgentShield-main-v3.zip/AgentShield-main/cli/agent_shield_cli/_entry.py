"""Top-level argparse dispatcher for the ``agent-shield`` console script.

Subcommands register explicitly here — no plugin discovery, no
dependency surface beyond ``argparse``.
"""
from __future__ import annotations

import argparse
import sys
from typing import List, Optional

from .init._command import add_init_parser, run_init


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="agent-shield",
        description=(
            "Agent Shield command-line tools. Today: `agent-shield init` — "
            "an LLM-driven `.guardrails.yaml` designer."
        ),
    )
    parser.add_argument(
        "--version",
        action="store_true",
        help="Print the installed agent-shield version and exit.",
    )
    sub = parser.add_subparsers(dest="command", metavar="<command>")
    add_init_parser(sub)
    return parser


def main(argv: Optional[List[str]] = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.version:
        try:
            from importlib.metadata import version

            print(version("agent-shield"))
        except Exception:
            print("unknown")
        return 0

    if args.command == "init":
        return run_init(args)

    parser.print_help(sys.stderr)
    return 2


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
