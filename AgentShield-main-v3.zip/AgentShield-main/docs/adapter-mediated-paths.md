# Adapter Mediated Paths

This document is the human-readable mediated-path matrix for Agent Shield adapters. It complements `tests/parity/capability_canonical.json`, which is the machine-checked capability matrix. A path listed as **mediated** is routed through Agent Shield before the host framework executes or emits the guarded operation. A path listed as **unsupported** or **outside scope** MUST NOT be treated as protected by Agent Shield.

Coverage levels:

- **Full**: the adapter mediates the path for the supported framework versions when the documented integration pattern is used.
- **Partial**: the adapter mediates only some paths or requires a specific pattern. The notes identify what remains unsupported.
- **Unsupported**: the adapter does not mediate this path. Hosts must use another integration mode, such as explicit SDK calls or a framework hook with full coverage.

## Universal Integration Rules

- All governed tool calls, endpoint calls, and sub-agent invocations must flow through the documented adapter or SDK wrapper path before execution.
- Hosts must not keep parallel unguarded tool functions registered for the same governed action.
- Unknown framework tool-call shapes, callback orders, or streaming modes must fail closed or be documented as unsupported before execution.
- Validate-only APIs are not sufficient for consequential actions unless the host executes the exact canonical invocation that was validated.

## ⚠️ DANGER: hand-rolled streaming wrappers are unsafe

**Custom streaming wrappers around AgentShield are unsafe by construction.** Stage 5 redaction requires the *full output context* to compute redaction spans — per-chunk Stage 5 cannot work (substrings cannot be classified until enough surrounding text has been seen), and per-stream-finalize Stage 5 emits raw chunks to the client *before* redaction runs (the leak has already shipped over the wire by the time the final pass returns).

Only an adapter that owns chunk emission — so it can buffer, validate, and *then* emit the safe-to-emit slice — can stream safely. The matrix below identifies which adapter / framework combinations have such an adapter and which do not.

**When AgentShield does not yet ship a streaming adapter for your framework, you have three safe options:**

1. **Disable streaming** and use the buffer-mode response. Stage 5 sees the full output and redaction is correct.
2. **Use the [LiteLLM Proxy plugin](integrations/litellm-proxy.md)**, which enforces Stage 5 in buffer-mode at the gateway (latency trade-off documented in the Streaming section of that page).
3. **Implement a sentinel-only stream**: emit a heartbeat / progress token, run the real LLM call to completion, then reveal the validated output after Stage 5 returns.

**What does NOT work:**

- `async for chunk in agent.run_stream(...): yield chunk` inside a Python `shield.run` / `shield.run_with_session` thunk followed by a post-hoc Stage 5 pass — the raw chunks have already left the SDK boundary.
- The Node / TypeScript equivalent: a custom async iterator that forwards chunks before `shield.run` completes.
- Any pattern that calls `validate_output` / `validateOutput` per chunk and emits the chunk independently — Stage 5 spans cannot be computed reliably on partial buffers.

See [`runbooks/incident-streaming-leak.md`](runbooks/incident-streaming-leak.md) for the incident response runbook when a stream is suspected to have leaked.

## Per-adapter coverage summary

`✓ tested` in the table below means the path is exercised by the current adapter/conformance suites (for example `sdk/python/tests/test_capability_conformance.py`, `sdk/node/__tests__/adapters_*.test.ts`, `sdk/dotnet/tests/AgentShield.Tests/AdapterScenariosTests.cs`, and `sdk/rust/agent_shield/tests/{shield,smoke,parity_*}.rs`). It does **not** imply that every framework exposes every bypass-path incident today; those gaps are called out explicitly in the notes column and per-adapter `MEDIATION.md` files.

| Adapter | MEDIATION | Stage 1 input | Stage 3 tool params | Stage 4 tool results | Stage 5 output | Streaming | Approvals (`kind: human`, `decision: cancelled`) | IFC variable subtypes | `incident.stream_aborted` honored | Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| Python / LangChain | [MEDIATION](../sdk/python/agent_shield/adapters/langchain/MEDIATION.md) | ✓ tested | ✓ tested | ✓ tested | ✓ tested | partial: buffered final-message streaming | ✓ tested | ✓ tested | ✓ tested | Wraps `StructuredTool` + guarded agent boundary. |
| Python / OpenAI Agents | [MEDIATION](../sdk/python/agent_shield/adapters/openai_agents/MEDIATION.md) | ✓ tested | ✓ tested | ✓ tested | ✓ tested | partial: text deltas only | ✓ tested | ✓ tested | ✓ tested | Native guardrail helpers plus wrapped tools. |
| Python / Anthropic | [MEDIATION](../sdk/python/agent_shield/adapters/anthropic_agents/MEDIATION.md) | ✓ tested | ✓ tested | ✓ tested | ✓ tested | partial: buffered final-message path | ✓ tested | ✓ tested | ✓ tested | Built around `BetaAsyncToolRunner`. |
| Python / Semantic Kernel | [MEDIATION](../sdk/python/agent_shield/adapters/semantic_kernel/MEDIATION.md) | ✓ tested | ✓ tested | ✓ tested | ✓ tested | not supported | ✓ tested | ✓ tested | not supported | Streaming intentionally unsupported on Python. |
| Python / AutoGen | [MEDIATION](../sdk/python/agent_shield/adapters/autogen/MEDIATION.md) | ✓ tested | partial: framework hook limits | partial: framework hook limits | ✓ tested | not supported | ✓ tested | ✓ tested | not supported | Buffered helper exists but is not a conformance claim. |
| Python / CrewAI | [MEDIATION](../sdk/python/agent_shield/adapters/crewai/MEDIATION.md) | ✓ tested | ✓ tested | ✓ tested | ✓ tested | not supported | ✓ tested | ✓ tested | not supported | Crew tool wrapping only. |
| Python / MCP | [MEDIATION](../sdk/python/agent_shield/mcp/MEDIATION.md) | not supported | ✓ tested | ✓ tested | not supported | not supported | ✓ tested | ✓ tested | not supported | In-process MCP helper surface only. |
| Node / LangChain | [MEDIATION](../sdk/node/adapters/langchain/MEDIATION.md) | ✓ tested | ✓ tested | ✓ tested | ✓ tested | partial: text chunks only | ✓ tested | ✓ tested | ✓ tested | `createLangchainAgent(...)` and tool wrapping. |
| Node / OpenAI Agents | [MEDIATION](../sdk/node/adapters/openai_agents/MEDIATION.md) | ✓ tested | ✓ tested | ✓ tested | ✓ tested | partial: text deltas only | ✓ tested | ✓ tested | ✓ tested | Pattern A and Pattern B surfaces. |
| Node / Anthropic | [MEDIATION](../sdk/node/adapters/anthropic_agents/MEDIATION.md) | ✓ tested | ✓ tested | ✓ tested | ✓ tested | partial: text-delta streaming only | ✓ tested | ✓ tested | ✓ tested | Guarded tool runner plus streamed text bridge. |
| Node / MCP | [MEDIATION](../sdk/node/mcp/MEDIATION.md) | not supported | ✓ tested | ✓ tested | not supported | not supported | ✓ tested | ✓ tested | not supported | In-process helper surface only. |
| .NET / Microsoft.Extensions.AI | [MEDIATION](../sdk/dotnet/src/AgentShield.AI/MEDIATION.md) | ✓ tested | not supported | not supported | ✓ tested | partial: Stage-5 chat streaming only | ✓ tested | ✓ tested | ✓ tested | `DelegatingChatClient` middleware. |
| .NET / Anthropic | [MEDIATION](../sdk/dotnet/src/AgentShield.Anthropic/MEDIATION.md) | ✓ tested | ✓ tested | ✓ tested | ✓ tested | partial: text blocks only | ✓ tested | ✓ tested | ✓ tested | Helper-owned Anthropic loop. |
| .NET / AutoGen | [MEDIATION](../sdk/dotnet/src/AgentShield.AutoGen/MEDIATION.md) | ✓ tested | partial: framework hook limits | partial: framework hook limits | ✓ tested | not supported | ✓ tested | ✓ tested | not supported | `IMiddleware` integration. |
| .NET / MCP | [MEDIATION](../sdk/dotnet/src/AgentShield.MCP/MEDIATION.md) | not supported | ✓ tested | ✓ tested | not supported | not supported | ✓ tested | ✓ tested | not supported | `MCPShield` helper surface. |
| .NET / Semantic Kernel | [MEDIATION](../sdk/dotnet/src/AgentShield.SemanticKernel/MEDIATION.md) | ✓ tested | ✓ tested | ✓ tested | ✓ tested | partial: shared StreamingGuard emits on policy stop | ✓ tested | ✓ tested | ✓ tested | `IAutoFunctionInvocationFilter`. |
| Rust / Anthropic | [MEDIATION](../sdk/rust/agent_shield_anthropic/MEDIATION.md) | ✓ tested | ✓ tested | ✓ tested | ✓ tested | partial: buffered `stream_complete` path | ✓ tested | ✓ tested | ✓ tested | Raw-schema Anthropic helper crate. |
| Rust / LangChain | [MEDIATION](../sdk/rust/agent_shield_langchain/MEDIATION.md) | ✓ tested | ✓ tested | ✓ tested | ✓ tested | partial: host-driven streaming via shared core guard | ✓ tested | ✓ tested | ✓ tested | Pattern B / explicit wrapper only. |
| Rust / OpenAI | [MEDIATION](../sdk/rust/agent_shield_openai/MEDIATION.md) | ✓ tested | ✓ tested | ✓ tested | ✓ tested | partial: buffered `stream_complete` path | ✓ tested | ✓ tested | ✓ tested | Explicit helper crate. |
| Rust / MCP | [MEDIATION](../sdk/rust/agent_shield_mcp/MEDIATION.md) | not supported | ✓ tested | ✓ tested | not supported | not supported | ✓ tested | ✓ tested | not supported | Session-oriented helper crate. |
| Rust / Rig | [MEDIATION](../sdk/rust/agent_shield_rig/MEDIATION.md) | ✓ tested | partial: hook path, full with Pattern B | partial: hook path, full with Pattern B | ✓ tested | partial: hook/path limits | ✓ tested | ✓ tested | partial: missing Rig stream callback bridge | `GuardedRigTool` is the full-coverage path. |

## Matrix

| Adapter | Implemented SDKs | Input | State | Tool Authorization | Tool Execution | Tool Output | Output | Streaming | Mediated paths | Unsupported / bypass paths |
|---|---|---:|---:|---:|---:|---:|---:|---:|---|---|
| `langchain` | Python, Node, Rust | Full | Full | Full | Full | Full | Full | Partial | Wrapped/instrumented LangChain tool invocation and final output paths exposed by the adapter. | Direct calls to original tools, custom callbacks not installed through the adapter, and framework streaming chunks beyond documented partial coverage. |
| `openai_agents` | Python, Node, Rust, .NET | Full | Full/Partial by SDK | Full/Partial by SDK | Full/Partial by SDK | Full/Partial by SDK | Full | Partial/Unsupported by SDK | Adapter-owned OpenAI agent loop or documented wrapped tool dispatch path. | Direct OpenAI SDK calls, manually executed tool calls outside the adapter, and unsupported streaming modes. |
| `anthropic_agents` | Python, Node, Rust, .NET | Full | Full | Full | Full | Full | Full | Partial | Adapter-mediated Anthropic tool-use loop and guarded output path. | Direct Anthropic SDK tool execution and unwrapped streaming consumers. |
| `semantic_kernel` | Python, .NET | Full | Full | Full | Full | Full | Full | Full/Unsupported by SDK | Semantic Kernel function invocation filters or documented adapter-owned execution path. | Direct kernel function calls that bypass filters; Python streaming is unsupported per capability overrides. |
| `autogen` | Python, .NET | Full | Partial | Partial | Partial | Partial | Full | Unsupported | Documented AutoGen guarded agent/tool hooks. | Tool paths not exposed through AutoGen hooks and all streaming output paths. |
| `crewai` | Python | Full | Full | Full | Full | Full | Full | Unsupported | CrewAI adapter-wrapped tools and agent output path. | Direct tool calls and unsupported streaming chunks. |
| `rig` | Rust | Full | Partial/Full by pattern | Partial/Full by pattern | Partial/Full by pattern | Partial/Full by pattern | Full | Partial | Rig adapter hooks; full coverage requires the documented wrap-tools-up-front pattern. | Hook-only partial coverage paths and direct tool execution. |
| `microsoft.extensions.ai` | .NET | Full | Partial | Partial | Partial | Partial | Full | Full | Documented .NET middleware/filter path. | Direct service calls and streaming output paths. |
| `mcp` | Python, Node, .NET | Unsupported | Full | Full | Full | Full | Unsupported | Unsupported | In-process MCP server tool-call paths wrapped via the `MCPShield` SDK helpers (`shield_server` / `protect_server` / `protectTools` / `ProtectTool` / `ProtectToolOutput`). | MCP servers reachable directly by the agent or host outside the wrapped tool registry. |

## Adapter Review Checklist

For every adapter release, reviewers should verify:

- The adapter capability report still matches `tests/parity/capability_canonical.json`.
- The adapter tests cover each path marked Full or Partial.
- Unsupported paths fail closed or are impossible to call through the guarded API.
- Documentation names the exact framework versions tested.
- Streaming behavior is described as buffering, validated chunking, or unsupported.
- The adapter exposes the canonical invocation hash or equivalent decision binding where tool execution is mediated.
- Every shipped adapter has a per-adapter `MEDIATION.md` with wrap sites, unsupported paths, streaming notes, and unknown-shape handling.
