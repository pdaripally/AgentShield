﻿# Agent Shield Mission & Security Model

This document describes the security model for Agent Shield: what it protects, which components are trusted, which attacker capabilities are in scope, and which residual risks remain after Agent Shield enforcement.

Agent Shield is a runtime security governance layer for agentic systems. It enforces a portable `.guardrails.yaml` contract across supported enforcement paths and agent execution stages. This security model applies only when applications route governed inputs, tool calls, tool outputs, and final responses through Agent Shield SDKs or wrappers.

## Security Objectives

Agent Shield is designed to add security and safety guarantees to autonomous agents. The goal is to maintain agent utility while enforcing security guarantees for consequential actions.

The primary security objectives are:

- **Pre-action enforcement**: evaluate policy before mediated tool calls or governed actions execute.
- **Deterministic controls**: enforce policy predicates that do not depend on LLM judgment for cases that require exact behavior.
- **Defense in depth**: combine deterministic policy, classifiers, reviewer models, post-tool checks, output validation, and human approval.
- **Portable governance**: keep security policy in a reviewable contract that can travel across supported runtimes and deployment modes.
- **Auditable decisions**: expose enough structured information to understand why a runtime decision allowed, blocked, or requested approval.
  **Fail-closed enforcement**: prefer blocking or requiring approval when security-critical validation cannot complete safely.
  - **Session isolation**: keep per-conversation state isolated unless the host application explicitly shares state.

## Protected Assets

Agent Shield is intended to protect the following assets when applications route agent activity through supported enforcement points:

- **Tool authority**: permissions to call tools, APIs, MCP servers, plugins, business workflows, or infrastructure operations.
- **Sensitive data**: user data, documents, retrieved content, tool outputs, credentials, PII, regulated data, and business-confidential information.
- **Policy intent**: the semantics of the `.guardrails.yaml` contract and any inherited or referenced policy configuration.
- **Approval decisions**: human or delegated approvals that authorize sensitive operations.
- **Runtime state**: session attributes used by guardrail predicates, resource requirements, and validation stages.
- **Audit evidence**: logs and observability events used to reconstruct security decisions.
 - **Decision integrity**: the binding between the validated action, approval decision, executed tool call, and emitted audit event

## Principals And Components

Agent Shield deployments commonly include these principals and components:

- **End user**: benign, malicious, or compromised user who provides prompts, data, or requests to the agent.
- **Application developer**: integrates Agent Shield SDKs or wrappers into an agent application.
- **Policy author/security reviewer**: writes and approves `.guardrails.yaml` contracts.
- **Host application**: owns the agent loop, tool registry, credentials, runtime configuration, and business authorization checks.
- **Agent framework**: LangChain, AutoGen, CrewAI, OpenAI Agents, Anthropic, Semantic Kernel, Vercel AI, Copilot SDK, or another framework adapter.
- **LLM provider/model**: produces agent reasoning, tool calls, or final output.
- **Tools and MCP servers**: perform actions or return content to the agent.
- **Agent Shield runtime**: evaluates guardrail policy and produces allow, block, or approval decisions.
- **External classifiers/reviewer models**: optional services used for content or action classification.
- **Approval service/operator**: human or service that grants or denies sensitive actions.
- **Observability backend**: receives logs, metrics, traces, or audit events.
- **Deployment platform**: local process, container, or Kubernetes cluster that hosts the agent and the in-process Agent Shield SDK.
 - **Backend services**: application APIs, databases, queues, payment systems, ticketing systems, cloud APIs, or other systems reached by tools.
- **Build and release systems**: CI/CD workflows, package registries, container registries, and signing infrastructure that produce trusted Agent Shield artifacts.

## Trust Boundaries

Agent Shield must be integrated at the boundaries where untrusted content enters the agent loop and where the agent attempts to perform actions. Untrusted content crossing any boundary must be treated as data, not authority-bearing instruction, unless a trusted component explicitly promotes it.

Key trust boundaries are:

- **User to application**: user prompts and uploaded content are untrusted.
- **Retrieved/tool content to agent context**: documents, API responses, database rows, web pages, and MCP tool outputs are untrusted unless explicitly trusted by the host application.
- **LLM to host application**: model outputs, tool-call requests, and structured arguments are untrusted until validated.
- **Agent to tools**: proposed tool calls cross from advisory model output into real application authority and must be mediated.
- **Application to external classifiers**: classifier requests may disclose prompt or tool data to another service.
- **Application to approval service**: approval requests may disclose sensitive action context and must be authenticated and integrity-protected by the host deployment.
- **Runtime to observability backend**: logs and events may contain security- or privacy-sensitive metadata.
- **Policy file to runtime**: `.guardrails.yaml` is security-critical input and must be protected from unauthorized modification.
- **SDK to host platform**: filesystem, network, process, and credential access are ultimately controlled by the deployment environment.
- **Developer/operator to policy repository**: policy changes cross into security-critical configuration and require review.
- **CI/CD to released artifacts**: build outputs become trusted runtime components for downstream users.
- **Framework adapter to framework runtime**: adapter assumptions can break when framework APIs or tool-call semantics change.
- **Tool to backend service**: tools cross into business systems where backend authorization must still be enforced.

## Trusted Computing Base

The trusted computing base (TCB) is the set of components that must behave correctly for Agent Shield enforcement to hold. If a TCB component is malicious or compromised, Agent Shield may be bypassed or weakened.

Always in the TCB:

- The Agent Shield runtime and selected language bindings.
- The host application integration code that routes governed agent activity through Agent Shield before execution or disclosure.
- The `.guardrails.yaml` policy and any inherited or referenced configuration.
- The tool registry and adapter code that binds validated tool calls to executed operations.
- The deployment platform controls that protect files, secrets, network access, and runtime process integrity.

Conditionally in the TCB:

- External classifiers or reviewer models when their result influences allow, block, or approval decisions.
- Approval services and human operators when approval can authorize sensitive actions.
- Observability backends when logs or events are used as audit evidence.
- CI/CD systems, package registries, container registries, signing infrastructure, and release artifacts when deploying published Agent Shield packages or images.

## Attacker Model

Agent Shield assumes attackers may be external users, malicious insiders, compromised user accounts, or malicious content authors whose content is retrieved by the agent.

Attackers may control or influence:

- User prompts and chat history.
- User identities or sessions that are valid at the application layer but malicious or compromised.
- Documents, emails, web pages, database rows, search results, or retrieved context consumed by the agent.
- Tool and MCP server outputs consumed by the agent.
- Tool-call arguments proposed by the LLM.
- Final model output shown to users or passed to downstream systems.
- Outputs, errors, timing, and metadata returned through channels the attacker is authorized to observe.
- Network availability of optional external classifiers or approval callbacks.
- Runtime workload through large inputs, malformed policies, pathological expressions, excessive streaming chunks, or repeated validation requests.

Agent Shield does not assume attackers can directly modify the Agent Shield runtime, trusted host application code, approved policy files, deployment controls, or tool implementations. Those scenarios are treated as host, platform, or supply-chain compromise and require separate controls.

## In-Scope Threats

Agent Shield is intended to help mitigate these threats when enforcement points are correctly integrated.

### Prompt Injection

An attacker embeds instructions in user input or retrieved content that attempt to override system, developer, or policy intent.

Agent Shield mitigations include input validation, post-tool validation, output validation, classifier hooks, reviewer models, and deterministic state/resource policy. Prompt-injection detection is best-effort; security-critical restrictions should be represented as deterministic policy wherever possible.

### Cross-Prompt Injection

An attacker places malicious instructions in tool output, documents, email, webpages, MCP responses, or other retrieved content that later influences model behavior or tool calls. This includes instructions that persist across turns through memory, summaries, cached retrieved content, or session state.

Agent Shield mitigations include post-tool validation, output validation, streaming validation, and policies that restrict which tools remain available after sensitive or untrusted content is observed.

### Tool Abuse

An attacker induces the model to call a tool that is not allowed for the current objective, state, resource requirements, sensitivity level, or principal. Tool abuse includes calling the wrong tool, calling a tool at the wrong time, using unsafe parameters, or using the wrong principal's authority.

Agent Shield mitigations include allowed-tool policy, resource requirements, tool execution validation, deterministic predicates, and human approval.

### Confused Deputy

An attacker causes an agent with legitimate authority to perform an action on behalf of untrusted content or a different user intent.

Agent Shield mitigations include objective-bound tool validation, state/resource checks, approval gates, and explicit tool rules. Agent Shield can reduce confused-deputy risk, but it cannot infer all business authorization constraints unless those constraints are expressed in policy or enforced by backend services. The host application remains responsible for principal identity and business authorization.

### Sensitive Data Exfiltration

An attacker attempts to cause sensitive data to leave through model responses, tool parameters, external service calls, logs, approval payloads, or telemetry.

Agent Shield mitigations include output validation, post-tool validation, sensitivity state, classifier hooks, and policy-based tool restrictions. Allowed tools can still become exfiltration channels if their parameters are not policy-scoped and backend-authorized. Host applications must still apply least-privilege tool credentials and data minimization.

### Parameter Tampering

An attacker attempts to modify tool parameters after review or approval, such as changing an approved transfer amount or recipient.

Agent Shield mitigations require integration patterns that bind validation and approval to the exact tool name, parameters, session, policy, and state that are executed. Integrations should avoid validate-then-mutate flows. Safe wrappers should validate an immutable invocation and execute that same invocation.

### Unsafe Or Unexpected Tool Output

A tool returns malicious instructions, secrets, invalid data, oversized content, malformed structured output, schema-confusing output, or content that changes the session risk level or attempts to modify future instructions.

Agent Shield mitigations include post-tool validation, streaming validation, state updates, and output validation before disclosure.

### Classifier Or Reviewer Failure

An external classifier, reviewer model, or moderation backend returns an error, times out, produces an uncertain result, returns a malformed response, suffers a provider outage, returns a low-confidence result, or is adversarially influenced.

Agent Shield policies should define fail-closed behavior for security-critical checks. Deployments should use timeouts, retries, circuit breakers, and explicit `on_error` behavior.

### Denial Of Service

An attacker attempts to exhaust runtime resources using large prompts, large tool outputs, deeply nested policies, pathological expressions, excessive streaming chunks, slow classifiers, approval callback failures, or repeated expensive validation requests. For hosted classifiers or LLM reviewers, denial of service also includes cost exhaustion from repeated or oversized validation requests.

Agent Shield mitigations include bounded buffers, input limits, timeouts, and deployment-level rate limiting. Deployments must configure resource limits and backpressure.

### Framework Adapter Drift

A supported agent framework changes tool-call schemas, streaming behavior, callback order, or execution semantics in a way that causes the Agent Shield adapter to miss or mishandle enforcement.

Agent Shield mitigations include fail-closed wrappers, adapter compatibility tests, pinned supported version, and documented integration invariants.

### Approval Spoofing Or Replay

An attacker attempts to forge, replay, or reuse an approval for a different tool, parameter set, session, user, policy version, or time window.

Agent Shield mitigations require approval binding, expiration, nonce/freshness, audit logging, and authenticated approval channels.

## Out-Of-Scope Threats And Non-Goals

Agent Shield does not by itself protect against:

- Direct tool execution that bypasses Agent Shield wrappers or sessions.
- A malicious or compromised host application that ignores runtime decisions.
- A malicious or compromised tool implementation that performs unauthorized side effects internally.
- A malicious or negligent policy author who intentionally approves weak guardrails.
- A compromised deployment platform, filesystem, container runtime, Kubernetes cluster, CI/CD system, or package registry.
- Unauthorized modification of `.guardrails.yaml` when the deployment does not protect policy files.
- Confidentiality from external classifiers, reviewer models, approval services, or observability backends that the deployment explicitly configures to receive data.
- Exfiltration through side channels outside mediated model/tool/runtime paths.
- Business authorization failures inside application APIs or backend services.
- Complete correctness or honesty of the LLM provider or external classifier. Agent Shield treats those outputs as untrusted inputs unless policy explicitly chooses to trust them.
- General LLM factual correctness or hallucination unless the result violates configured policy.
- Unsafe business workflow design, such as tools that perform irreversible side effects without backend authorization, idempotency, or compensating controls.
- Retrospective prevention of side effects that already occurred before post-tool validation.
- Compliance certification by itself. Agent Shield can provide controls and evidence, but compliance depends on the full system and operating process.
- Telemetry Leakage: Agent Shield does not provide any guarantees to secure telemetry leakage.

## Security Guarantees

When the host application correctly integrates Agent Shield and routes relevant activity through supported enforcement points, the runtime is expected to provide these guarantees when configured and invoked through supported enforcement paths:

- **Input validation**: configured input validators run before mediated user input is passed to the agent/model.
- **State and resource validation**: configured predicates are evaluated using session state before governed actions that depend on them.
- **Tool execution validation**: mediated tool calls are evaluated before the corresponding tool is executed.
- **Human approval gating**: safe wrappers do not execute actions requiring approval until approval is granted for the reviewed action context.
- **Post-tool validation**: configured post-tool validators can evaluate mediated tool outputs before they are fed back into the agent loop or disclosed downstream.
- **Output validation**: configured output validators run before mediated final responses are returned to users or downstream consumers.
- **Fail-closed policy intent**: security-critical validation errors are intended to block or require approval rather than silently allow execution. Any configurable fail-open behavior should be explicit and documented.
- **Session isolation**: per-session state should not leak across conversations except through explicit host application behavior.
- **Decision observability**: runtime decisions can produce structured events suitable for audit, subject to redaction and sink configuration.

These guarantees apply only to supported runtime paths. Applications must not interpret Agent Shield as a sandbox for arbitrary code or as a replacement for tool-level authorization.

## Required Integration Invariants

To preserve the security model, integrations must satisfy these invariants:

- All governed tool calls must flow through Agent Shield mediation before execution.
- The application must not expose parallel unguarded tool paths for governed actions.
- The tool name and parameters validated by Agent Shield must be the same tool name and parameters executed by the host application.
- Approval decisions must be scoped to the reviewed action and must not be reused for materially different parameters, users, sessions, policies, or tools.
- Runtime decisions should be associated with the policy version or policy hash used to make the decision.
- Guardrail policy files must be protected from unauthorized modification.
- Security-relevant validation errors must fail closed unless a policy explicitly chooses a weaker behavior for a non-critical check.
- Approval and classifier callbacks must authenticate the service they communicate with and validate response shape.
- Streaming integrations must not emit unvalidated chunks unless the deployment explicitly accepts partial-output leakage risk.
- Logs, telemetry, approval payloads, and classifier requests must be treated as potentially sensitive data flows.
- Host applications must enforce identity, authorization, rate limits, and least-privilege credentials for the tools they expose to agents.

## Residual Risks

Even with correct integration, residual risks remain:

- Classifiers and reviewer models can make false-positive or false-negative decisions.
- Deterministic policies may be incomplete or incorrectly authored.
- Tool side effects may occur before post-tool validation detects unsafe output.
- Streaming validation can trade off latency, completeness, and leakage risk depending on configuration.
- Covert channels can exist in allowed outputs, timing, metadata, or tool parameters.
- New framework versions can change adapter behavior and reduce mediation coverage if compatibility tests do not catch drift.
- Observability and approval systems can become sensitive data aggregation points.
- Availability failures in classifiers, approval services, or telemetry systems can affect agent operation.
- Human approvers can make mistakes, experience approval fatigue, or approve maliciously framed requests.
- Complex policies can be misconfigured in ways that appear secure but leave gaps.
- Operators may incorrectly treat Agent Shield as a sandbox rather than a mediation layer.
- Latency or cost pressure may cause deployments to weaken classifiers, approvals, or validation stages.

## Threat-To-Control Matrix

| Threat | Primary controls | Required integration assumption | Residual risk |
|--------|------------------|---------------------------------|---------------|
| Prompt injection | Input validation, classifiers, deterministic policy | Governed user input is routed through Agent Shield before model use | Classifier false negatives; incomplete policy |
| Cross-prompt injection | Post-tool validation, output validation, state updates | Tool and retrieved content passes through post-tool or equivalent validation | Hidden instructions may survive if not detected |
| Tool abuse | Tool execution validation, allowed tools, resource requirements | All governed tool calls go through Agent Shield before execution | Direct tool calls can bypass mediation |
| Confused deputy | Objective-bound policy, approval, state/resource checks | Host app supplies correct user/session context and enforces backend authorization | Host app must enforce user identity and backend authorization |
| Data exfiltration | Output/post-tool validation, sensitivity state, tool restrictions | Sensitive data flows are labeled or detectable and logs/callbacks are controlled | Covert channels and telemetry leakage remain possible |
| Parameter tampering | Validate-and-execute wrappers, approval binding, audit | Executed invocation is identical to validated/approved invocation | Separate validation/execution can create TOCTOU risk |
| Classifier failure | `on_error` policy, timeouts, fail-closed behavior | Security-critical classifier errors block or require approval | Availability impact; false confidence in weak classifiers |
| External classifier compromise | Defense in depth, deterministic policy, provider governance | Classifier output is not the sole control for critical deterministic restrictions | False allow/block decisions may occur |
| Policy tampering | File permissions, code review, provenance/signing outside runtime | Deployment protects effective policy files and inherited configs | Runtime cannot protect already-modified policy files |
| Approval spoofing or replay | Approval binding, expiration, nonce/freshness, audit | Approval channel is authenticated and approvals are scoped to exact action context | Weak approval binding can authorize unintended actions |
| Framework adapter drift | Compatibility tests, pinned versions, fail-closed wrappers | Deployed framework versions are covered by adapter tests | Framework changes can reduce mediation coverage |
| Direct bypass | Safe wrappers, integration review | No parallel unguarded tool path exists for governed actions | Host app can still bypass if incorrectly integrated |
| DoS | Size limits, buffer bounds, timeouts, rate limits | Deployment configures resource quotas and backpressure | Resource or cost exhaustion remains possible |
| Telemetry leakage | Redaction, minimization, sink controls | Observability sinks are approved and access-controlled | Logs may still reveal sensitive metadata |

## Production Readiness Checklist

Before using Agent Shield for production enforcement, verify the following items.

### Integration

- The host application cannot execute governed tools outside Agent Shield.
- The application does not expose parallel unguarded tool paths for governed actions.
- Framework adapter versions are covered by compatibility tests for the exact framework versions deployed.
- Streaming integrations do not emit unvalidated chunks unless partial-output leakage risk is explicitly accepted.

### Policy

- `.guardrails.yaml` is reviewed, versioned, and protected from unauthorized modification.
- Security-critical failures block or require approval rather than silently allowing execution.
- Runtime decisions record or can be correlated with the policy version or policy hash used to make the decision.
- Policy rollback and emergency disable procedures have been tested.

### Data Handling

- Tool credentials are least privilege and scoped to the application's business authorization model.
- Logs and telemetry are redacted and routed to approved sinks.
- Secret and PII redaction has been tested with representative prompts, tool parameters, and tool outputs.
- External classifier, reviewer, approval, and observability providers are approved for the sensitivity of data they receive.

### Deployment

- Deployment endpoints use authentication, authorization, TLS or mTLS, rate limits, and resource limits.
- External classifier, reviewer, approval, and observability integrations have timeouts and explicit failure behavior.
- Approval and classifier callbacks authenticate the service they communicate with and validate response shape.
- Resource quotas and backpressure are configured for large prompts, tool outputs, streams, and validation queues.

### Operations

- Approval decisions are bound to exact action context and expire.
- Conformance and adapter compatibility tests pass for the deployed build.
- Incident response procedures exist for policy rollback, bypass reports, classifier outages, approval outages, and data leakage.
- An incident owner and escalation path are defined for suspected guardrail bypass.

