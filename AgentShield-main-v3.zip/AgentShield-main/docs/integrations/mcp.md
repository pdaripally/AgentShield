# Model Context Protocol (MCP) integration

Agent Shield treats [MCP](https://modelcontextprotocol.io) as a
first-class tool-call channel: every `tools/call` that flows through
an MCP server is a candidate for the same `.guardrails.yaml`
contract that gates LangChain tools, OpenAI Agents SDK function
calls, Semantic Kernel filters, and HTTP endpoints. The wire shape
is language-agnostic; the only thing that differs per ecosystem is
the host wiring around `validate_tool_call` / `validate_tool_output`.

This page covers the integration at the contract level. For the
runnable code, jump to one of the per-language entries in the table
below.

## Per-language entry points

| Language | Crate / package | Pattern A wrapper | Worked example |
|---|---|---|---|
| Python | [`agent_shield.mcp`](../../sdk/python/agent_shield/mcp/) | `shield_server(server)` walks a FastMCP registry | [`examples/agents/bank-manager/`](../../examples/agents/bank-manager/) |
| Node.js / TS | [`@microsoft/agent-shield/mcp`](../../sdk/node/) | `shieldServer(server)` | [`examples/agents/bank-manager/`](../../examples/agents/bank-manager/) |
| Rust | [`agent_shield_mcp`](../../sdk/rust/agent_shield_mcp/README.md) | _not yet — see [`README.md`](../../sdk/rust/agent_shield_mcp/README.md#why-no-guardedmcpserverls-wrapper-yet)_ | [`sdk/rust/agent_shield_mcp/examples/kubectl_mcp.rs`](../../sdk/rust/agent_shield_mcp/examples/kubectl_mcp.rs) |
| .NET | — | _not yet_ | _not yet_ |

## What gets gated when traffic flows through MCP

An MCP server is a tool provider, not an agent loop. It never sees
a user-facing prompt and never emits a final assistant message, so
Stage 1 (Input) and Stage 5 (Output) are typically not attached on
the server side — they belong on the agent that's *calling* the MCP
server. The stages that an MCP integration mediates are:

| Stage | What it gates on the MCP side | Source data |
|---|---|---|
| **2 — State validation** | predicate / variable checks that must pass before any tool call on this server | session state (variables) |
| **3 — Tool execution** | the `tools/call` request itself | tool name + arguments (`@tool.name`, `@tool.params.*`) |
| **4 — Post-tool validation** | the `tools/call` response before it returns to the agent | tool result body (`@result.*`) |

Stage 3 mints an **admission handle** that Stage 4 must consume to
release the pairing. The admission handle is keyed on the
MCP JSON-RPC request id (or a synthetic id, if the host doesn't
expose JSON-RPC ids). Stage 4 called with a stale, unknown, or
already-consumed handle fails closed.

## Human approval over MCP

Agent Shield folds human-in-the-loop into the MCP tool channel: a
`kind: human` resolver suspending produces a `pending_resolution`
whose `tool` field is always `agent_shield.ask_human`. Hosts that
integrate over MCP register exactly one tool named
`agent_shield.ask_human` (the [reference
server](../../examples/tools/ask-human-mcp-server/) is the
canonical implementation) and route incoming calls to it through
their approval UI.

The four-step contract is identical across SDKs:

1. **Stage 3 deny with `pending_resolution`.** The host inspects
   `verdict.pending_resolution.{tool, variable, prompt, request_id, kind}`.
2. **Host invokes `agent_shield.ask_human`.** Either through the
   agent's LLM (assistant calls the MCP tool naturally) or through
   the host's approval UI directly. The tool returns a resolver
   envelope: `{ "decision": "allow"|"deny"|"cancelled",
   "value": <typed>, "reason": "..." }`.
3. **Host populates the variable.** When `decision == "allow"`, the
   host writes `envelope.value` into the variable named by
   `pending_resolution.variable`. In Rust:
   `session.set_variable(&pending.variable, envelope.value)`.
4. **Host retries the original tool call.** Re-issue the same
   `validate_tool_call(...)` with the same tool name and arguments.
   The gate now sees the variable as `@status: resolved` and the
   call admits.

Same wire shape on the bus: an `incident.resolution_needed` event
fires when the resolver suspends, carrying the same `request_id`
the verdict embedded.

## MCP catalog parity (host responsibility)

The host owns the MCP `tools/list` registry. The policy's
`resources.tools[]` is the gate-side catalog. **There is no
automatic reconciliation.** Two failure modes:

- A tool in the policy that the host hasn't registered — calls
  never reach the gate (host returns "unknown tool"). Detectable
  in tests; not a security risk.
- A tool the host has registered that the policy doesn't gate —
  the call lands in your MCP server and runs ungated. Potentially
  a security risk.

Mitigation: keep the two lists in lockstep with a manual diff in
CI, or add a catch-all `applies_to.tools: ["*"]` policy that
matches every tool dispatched so the default posture
is "gated" rather than "ungated".

## Portability across hosts

The same `.guardrails.yaml` enforces identically across:

- Python MCP servers (FastMCP, hand-rolled, etc.) via `agent_shield.mcp`.
- Node MCP servers via `@microsoft/agent-shield/mcp`.
- Rust MCP servers via `agent_shield_mcp` (the per-call helpers).
- Any non-MCP framework — the policy is portable; only the host
  wiring changes.

Framework-specific tweaks belong in the SDK adapter, not in the
YAML. If a behavior can't be expressed portably across MCP and
non-MCP hosts, that's a spec gap; file a spec issue rather than
adding a per-framework escape hatch.

## See also

- [`sdk/rust/agent_shield_mcp/README.md`](../../sdk/rust/agent_shield_mcp/README.md) — Rust worked example, lifecycle pitfalls, MCP catalog parity guidance.
- [`examples/tools/ask-human-mcp-server/`](../../examples/tools/ask-human-mcp-server/) — reference `agent_shield.ask_human` MCP server.
- [Spec §11 — resolvers](../../spec/SPECIFICATION.md#11-resolvers), [§12 — guard policies](../../spec/SPECIFICATION.md#12-guard-policies-shared-contract), [§13 — resources](../../spec/SPECIFICATION.md#13-resources), [§16 — admission binding](../../spec/SPECIFICATION.md#16-tool_execution_validation-stage-3).
- [Post-tool limits and dangerous patterns](../POST_TOOL_LIMITS.md) — what AgentShield does and does not guarantee on Stage 4.
