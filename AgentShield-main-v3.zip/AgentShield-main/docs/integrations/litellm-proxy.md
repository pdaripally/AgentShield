# LiteLLM Proxy integration

Agent Shield can run as a [LiteLLM Proxy](https://docs.litellm.ai/docs/simple_proxy) guardrail for OpenAI-compatible chat traffic. Use the in-process SDK for arbitrary `/tools/*` or framework-specific routes.

> [!IMPORTANT]
> With `post_call` enabled, streamed responses run in **buffer mode**: the guardrail drains the upstream stream, validates the complete response, then emits replayed or replacement chunks. Time-to-first-token equals full-response latency.

## Install

```bash
pip install -e "sdk/python[litellm-proxy]"
# When public packages ship: pip install agent-shield[litellm-proxy]
```

## Register

LiteLLM resolves guardrail dotted paths relative to its config directory. Put a shim beside `litellm_config.yaml`:

```python
# /etc/litellm/agent_shield_guardrail.py
from agent_shield.integrations.litellm_proxy import (
    AgentShieldLiteLLMGuardrail,
    agentshield_guardrail,
)
```

Recommended `guardrails:` registration:

```yaml
guardrails:
  - guardrail_name: agent_shield
    litellm_params:
      guardrail: agent_shield_guardrail.AgentShieldLiteLLMGuardrail
      mode: ["pre_call", "post_call"]
      guardrails_path: /etc/agent-shield/guardrails.yaml
      default_on: true
```

Callback registration is also supported:

```yaml
litellm_settings:
  callbacks:
    - agent_shield_guardrail.agentshield_guardrail
```

The callback singleton reads `AGENT_SHIELD_LITELLM_GUARDRAILS_PATH`.

## Stage coverage

| Stage | LiteLLM hook | Source data | Block / mutate behavior |
|---|---|---|---|
| **1 — Input** | `async_pre_call_hook` | last `role=user` message | HTTP 400 block |
| **2/3 — Tool call** | post-call / stream iterator | assistant `tool_calls[*]` | drop tool calls + replacement assistant message; or rewrite arguments |
| **4 — Tool output** | next `async_pre_call_hook` | trailing `role=tool` messages | replace tool content or raise HTTP 400 |
| **5 — Output** | post-call / stream iterator | final assistant `content` | replacement block message or mutated content |

Verdict dispatch and block-message formatting are delegated to the shared Rust core used by the in-process SDKs.

## Turn lifecycle and sessions

```text
user → Stage 1 → upstream → assistant.tool_calls → Stage 2/3
tool → Stage 4 → upstream → assistant.content → Stage 5
```

The guardrail opens a turn on a request ending in `role=user`, keeps it open across assistant tool calls and trailing `role=tool` requests, and closes it on the final assistant content response.

Session id resolution order:

1. `data["metadata"]["agent_shield_session_id"]`
2. `data["litellm_session_id"]`
3. `data["user"]`
4. fresh UUID

Sessions use a bounded LRU (`AGENT_SHIELD_LITELLM_SESSION_CACHE_SIZE`, default `512`) with idle TTL (`AGENT_SHIELD_LITELLM_SESSION_TTL_SECONDS`, default `1800`). Requests for the same session id are serialized with an `asyncio.Lock`.

## Streaming

Buffer-mode steps:

1. Drain the upstream `ModelResponseStream`.
2. Reassemble `delta.content` and chunked `tool_calls.function.arguments` by tool-call index.
3. Run Stages 2/3 and Stage 5 against complete data.
4. Allow → replay captured chunks. Block/mutate → emit replacement chunks with `finish_reason="stop"`.

If token-by-token UX matters more than Stage 5 on a route, remove `post_call` from that guardrail `mode:` or use an in-process adapter that owns the buffering boundary.

## Threat model

Mitigated: Stage 1 input blocks, Stage 2/3 assistant tool-call gating, Stage 4 tool-output gating, Stage 5 final-response redaction, and fail-closed rejection of fabricated tool history for the same session.

Not mitigated: local tools that bypass the proxy, arbitrary non-chat backend routes, and client-side replay or alteration of old assistant messages.

## Out of scope

- `n > 1` multi-choice responses.
- Requests ending in `role=assistant`, `role=system`, or other terminal roles.
- Human-approval suspend/resume flows; use in-process SDK adapters.
- Token-by-token Stage 5 enforcement.
- LiteLLM-as-a-library adapters for other frameworks.

## Configuration reference

| Var | Default | Purpose |
|---|---:|---|
| `AGENT_SHIELD_LITELLM_GUARDRAILS_PATH` | required | `.guardrails.yaml` enforced by the callback singleton |
| `AGENT_SHIELD_LITELLM_SESSION_CACHE_SIZE` | `512` | cached-session LRU cap |
| `AGENT_SHIELD_LITELLM_SESSION_TTL_SECONDS` | `1800` | idle TTL in seconds; `0` disables TTL eviction |
| `AGENT_SHIELD_LITELLM_STAGE4_ON_BLOCK` | `replace` | `replace` tool content or `raise` HTTP 400 |
| `AGENT_SHIELD_LITELLM_GUARDRAIL_NAME` | `agent_shield` | LiteLLM log / metric identifier |

When using `guardrails:`, set the same values under `litellm_params:`.

## Block envelopes

LiteLLM wraps Agent Shield error details under `error.provider_specific_fields.shield`. Extract it with:

```python
def extract_shield_envelope(body: dict) -> dict | None:
    err = body.get("error")
    if isinstance(err, dict):
        psf = err.get("provider_specific_fields")
        if isinstance(psf, dict) and isinstance(psf.get("shield"), dict):
            return psf["shield"]
    detail = body.get("detail")
    if isinstance(detail, dict) and isinstance(detail.get("shield"), dict):
        return detail["shield"]
    shield = body.get("shield")
    return shield if isinstance(shield, dict) else None
```

Branch on `shield["kind"]` (`blocked` vs. `pending_resolution`), not on message text.

## Production hardening

Do not expose uvicorn / LiteLLM Proxy directly to untrusted clients. Put nginx, Envoy, HAProxy, ALB, or equivalent in front and enforce:

| Control | Recommended value |
|---|---|
| Request body/header read timeout | `< 10s` |
| Maximum request body | `1m`–`10m` |
| Per-IP connection and request limits | route-specific |
| Keep-alive idle timeout | `< 60s` |

Minimal nginx shape:

```nginx
upstream litellm_proxy { server 127.0.0.1:4000; keepalive 32; }
server {
    listen 443 ssl http2;
    server_name llm.example.internal;
    client_body_timeout 10s;
    client_header_timeout 10s;
    send_timeout 10s;
    keepalive_timeout 30s;
    client_max_body_size 1m;
    limit_req  zone=llm burst=10 nodelay;
    limit_conn llm_conn 20;
    location / {
        proxy_pass http://litellm_proxy;
        proxy_http_version 1.1;
        proxy_set_header Connection "";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_buffering off;
        proxy_read_timeout 600s;
    }
}
```

For Kubernetes, enforce the same controls at the Ingress / Gateway, restrict pod ingress with `NetworkPolicy`, and set CPU / memory limits. See the [LiteLLM Proxy deployment guide](https://docs.litellm.ai/docs/proxy/deploy).

## Reference

- LiteLLM guardrails docs: https://docs.litellm.ai/docs/proxy/guardrails
- Source: `sdk/python/agent_shield/integrations/litellm_proxy/`
- Tests: `tests/e2e/run_litellm_proxy.py`
- Spec: [`spec/SPECIFICATION.md`](../../spec/SPECIFICATION.md)
