# Static Analysis Findings Report

**Status:** Phase 1 Complete  
**Date:** 2026-05-19  
**Repository:** microsoft/AgentShield  
**Branch:** `security/static-analysis-phase1` (based on `main`)  
**Author:** Apoorv Jindal (@apoorvjindal)

### Tool Versions Used
| Tool | Version |
|------|---------|
| cargo clippy | 0.1.95 (rustc 1.95.0) |
| cargo-deny | 0.18.x |
| cargo-audit | 0.22.1 |
| ruff | 0.11.x |
| pip-audit | latest (pip 25.0.1) |
| eslint | 10.4.x |
| eslint-plugin-security | 4.x |
| typescript-eslint | 8.59.x |
| dotnet | 9.0.314 |
| SonarAnalyzer.CSharp | 10.4.0.108396 |
| Node.js | 24.15.0 |
| Python | 3.12.10 |

---

## 1. What & Why

AgentShield is a security SDK that must meet the same security bar it asks of consumers. Prior to this work, **only Rust had any static analysis** (cargo clippy + fmt in CI). Python, Node, and .NET had zero linting or security scanning configured.

This Phase 1 initiative:
- Runs comprehensive static analysis and security linters across all 4 SDK codebases
- Documents every finding with severity classification
- Fixes all Critical and High *actionable* findings (those with clear fixes that don't require large-scale refactoring)
- Establishes a baseline for Phase 2 (CI integration)

## 2. How (Methodology)

### Tools selected per language:
| Language | Linter | Dependency Scanner | Rationale |
|----------|--------|--------------------|-----------|
| Rust | cargo clippy (expanded lint set beyond CI defaults) | cargo deny + cargo audit | clippy catches logic bugs; deny adds license/advisory/ban policy |
| Python | ruff (S=bandit security, B=bugbear, E/F/W=standard) | pip-audit | ruff is a superset of bandit+flake8, 100x faster |
| Node | eslint + eslint-plugin-security + typescript-eslint | npm audit | Plugin detects prototype pollution, eval, regex DoS |
| .NET | Roslyn (AnalysisMode=All) + SonarAnalyzer.CSharp | dotnet list package --vulnerable | Zero-config for existing .NET 8 projects |
| All | Manual secret scan (regex + git history) | — | Defense-in-depth for leaked credentials |

### Execution approach:
1. Installed tools locally (no GitHub Actions workflows modified)
2. Ran all scanners in parallel (one per language)
3. Classified findings by severity using mapping table (§3 below)
4. Fixed all actionable High findings
5. Committed tool configs for reproducibility (`deny.toml`, `eslint.config.mjs`, `.NET Directory.Build.props`)
6. Documented deferred items with rationale
7. Verified existing CI checks still pass

---

## 3. Severity Mapping

| Tool | Critical | High | Medium | Low |
|------|----------|------|--------|-----|
| clippy | — | correctness, indexing panics, unwrap in lib | pedantic casts, undocumented unsafe | style/docs |
| cargo deny/audit | CVSS ≥ 9 | CVSS 7-8.9, unmaintained with no upgrade | CVSS 4-6.9 | CVSS < 4 |
| ruff | F821 (undefined names) | S1xx/S6xx (injection, subprocess) | S2xx, S3xx | S5xx, E/W style |
| eslint-security | detect-eval, detect-child-process | — | object-injection, non-literal-fs | non-literal-regexp |
| pip-audit/npm audit | CVSS ≥ 9 | CVSS 7-8.9 | CVSS 4-6.9 | CVSS < 4 |

---

## 4. Executive Summary

| Language | High | Medium | Low | Info | Fixed | Deferred |
|----------|------|--------|-----|------|-------|----------|
| Rust     | 1    | 4      | 5   | 4000+| 3     | 4000+    |
| Python   | 3    | 2      | 2   | 715  | 5     | 714      |
| Node     | 0    | 8      | 11  | 333  | 3     | 333      |
| .NET     | 0    | 0      | 0   | 0    | 0     | 0        |
| **Total**| **4**| **14** | **18**| **5048+**| **11** | **5047+** |

> **Counting convention:** Each row in the findings tables = 1 rule/category. "Count" column shows individual violations.

**Secret Scan:** ✅ Clean — no hardcoded credentials found (scanned via regex on `*.yml`, `*.py`, `*.ts`, `*.rs`, `*.cs`, `*.json` + git history for `*.key`, `*.pem`, `*.env`).  
**.NET:** ✅ Completely clean — 0 warnings with AnalysisMode=All + SonarAnalyzer.CSharp (14 projects compiled).  
**Verification:** All existing CI checks pass after fixes (`cargo clippy -D warnings` ✅, `dotnet build` ✅, `ruff check --select F821,S603,S607` ✅).

---

## 5. Detailed Findings

### Rust — cargo clippy (expanded lints)

**Command:** `cargo clippy --workspace --all-features --all-targets -- -W clippy::pedantic -W clippy::unwrap_used -W clippy::expect_used -W clippy::panic -W clippy::indexing_slicing -W clippy::arithmetic_side_effects -W clippy::undocumented_unsafe_blocks -W clippy::missing_safety_doc -W clippy::multiple_unsafe_ops_per_block -W clippy::cast_possible_truncation -W clippy::cast_sign_loss -W clippy::mem_forget -W clippy::dbg_macro -W clippy::print_stdout -W clippy::print_stderr -W clippy::todo -W clippy::unimplemented -A clippy::module_name_repetitions -A clippy::must_use_candidate`

**Total warnings:** 4,291 (exit code 101)

| # | Severity | Category | Count | Description | Status |
|---|----------|----------|-------|-------------|--------|
| R1 | Medium | `indexing_slicing` | 40+ | Array indexing without bounds check — potential panics. Needs per-instance triage. | Deferred (triage needed) |
| R2 | Medium | `unwrap_used` / `expect_used` | Multiple | Panics on None/Err in library code. Many are in test code or after validation. | Deferred (triage needed) |
| R3 | Medium | `arithmetic_side_effects` | Multiple | Overflow/underflow flagged on all arithmetic. High FP rate. | Deferred (triage needed) |
| R4 | Medium | `cast_possible_truncation` / `cast_sign_loss` | Multiple | i64→f64, usize→f64 precision loss | Deferred (triage needed) |
| R5 | Medium | `undocumented_unsafe_blocks` | Multiple (FFI crates) | Missing `// SAFETY:` docs in `agent_shield_core/src/ffi.rs` | ✅ Fixed |
| R6 | Medium | `missing_safety_doc` | Multiple | Unsafe fns without safety docs in `agent_shield_core/src/ffi.rs` | ✅ Fixed |
| R7 | Low | Pedantic style (docs, format strings, patterns) | 4000+ | Missing backticks, #Errors/#Panics docs | Deferred |
| R8 | Low | `todo` / `unimplemented` | Some | Incomplete implementations | Deferred |

**FFI Triage Note:** Findings for `undocumented_unsafe_blocks` were fixed in `sdk/rust/agent_shield_core/src/ffi.rs` (the primary FFI surface). The PyO3 bridge (`sdk/python/src/lib.rs`) and napi-rs bridge use `unsafe` extensively for FFI by design — those files were not modified in this pass but have pre-existing safety documentation.

---

### Rust — cargo deny

**Command:** `cargo deny check`  
**Result:** advisories FAILED, bans FAILED, licenses FAILED, sources ok

| # | Severity | Finding | Details | Status |
|---|----------|---------|---------|--------|
| R9 | High | `rustls-pemfile` v1.0.4 unmaintained | RUSTSEC-2025-0134. No safe upgrade. Transitive via: reqwest 0.11.27 → readability → langchain-rust | Deferred (upstream) |
| R10 | Medium | License: `CDLA-Permissive-2.0` | webpki-roots v1.0.7, webpki-root-certs v1.0.7. OSI-approved permissive license. | ✅ Fixed (added to deny.toml) |
| R11 | Low | Wildcard path dependencies | 10+ workspace members use `path = ".."` without version | Accepted (workspace standard) |
| R12 | Low | Unmatched license allowances | Unicode-DFS-2016, Zlib declared but not used | Info |

---

### Rust — cargo audit

**Command:** `cargo audit`  
**Result:** 4 advisories reported (all unmaintained-crate warnings, no exploitable CVEs)

| # | Severity | Advisory | Crate | Description | Status |
|---|----------|----------|-------|-------------|--------|
| R13 | High | RUSTSEC-2025-0134 | rustls-pemfile 1.0.4 | Unmaintained, archived Aug 2025. No safe upgrade. | Deferred (upstream) |
| R14 | Low | RUSTSEC-2025-0012 | backoff 0.4.0 | Unmaintained. Via async-openai → agent_shield_openai | Deferred |
| R15 | Low | RUSTSEC-2025-0057 | fxhash 0.2.1 | Unmaintained. Via selectors → scraper → langchain-rust | Deferred |
| R16 | Low | RUSTSEC-2024-0384 | instant 0.1.13 | Unmaintained. Via backoff → async-openai | Deferred |

**Note:** All unmaintained crate advisories are transitive dependencies via `langchain-rust` or `async-openai`. No direct CVEs with known exploits.

---

### Python — ruff

**Command:** `ruff check --select S,B,E,F,W sdk/python/ cli/`  
**Total violations:** 804

| # | Severity | Rule | Count | Description | Status |
|---|----------|------|-------|-------------|--------|
| P1 | **High** | F821 | 5 | Undefined names (`Awaitable`, `GuardrailsConfig`, `CompiledPolicy`) — would cause NameError at runtime | ✅ Fixed |
| P2 | High | S603 | 1 | `subprocess` call with `shell=True` — command injection risk | ✅ Fixed (shutil.which + noqa) |
| P3 | High | S607 | 1 | Start process with partial executable path | ✅ Fixed |
| P4 | Medium | S110 | 17 | `try-except-pass` — silently swallowing exceptions | To triage |
| P5 | Medium | B010 | 17 | Unnecessary `setattr` with constant — use direct attribute | Low priority |
| P6 | Low | F401 | 32 | Unused imports | ✅ Fixed (auto) |
| P7 | Low | E402 | 4 | Module import not at top of file | ✅ Fixed (auto) |
| P8 | Info | S101 | 634 | Use of `assert` — overwhelmingly in test files | Accepted |
| P9 | Info | E501 | 81 | Line too long | Deferred |

---

### Python — pip-audit

**Command:** `pip-audit --desc`  
**Result:** 5 CVEs

| # | Severity | CVE | Package | Description | Fix | Status |
|---|----------|-----|---------|-------------|-----|--------|
| P10 | High | CVE-2026-45409 | idna 3.14 | DoS via resource exhaustion in `idna.encode()` | Update to 3.15 | To fix |
| P11 | Medium | CVE-2025-8869 | pip 25.0.1 | Symlink escape in tar extraction | Update pip | Deferred (tooling) |
| P12 | Medium | CVE-2026-1703 | pip 25.0.1 | Path traversal in wheel extraction | Update pip | Deferred (tooling) |
| P13 | Low | CVE-2026-3219 | pip 25.0.1 | Malformed archive handling | Update pip | Deferred (tooling) |
| P14 | Low | CVE-2026-6357 | pip 25.0.1 | Module import race during self-update | Update pip | Deferred (tooling) |

**Note:** pip CVEs affect the installer tool itself, not shipped library code. The `idna` CVE is actionable if idna is a direct/transitive dependency of the SDK.

---

### Node — ESLint + eslint-plugin-security

**Command:** `npx eslint --config eslint.config.mjs .`  
**Total:** 413 problems (333 errors, 80 warnings)

| # | Severity | Rule | Count | Location | Status |
|---|----------|------|-------|----------|--------|
| N1 | Medium | security/detect-object-injection | 8+ | index.ts:395,571,671,726; mcp.ts:72; shield.ts:478; integrations/ | ✅ Fixed (1 true positive fixed, 8 FPs suppressed with justification) |
| N2 | Medium | security/detect-non-literal-fs-filename | 6+ | Test files (mkdirSync, writeFileSync, readFileSync) | Accepted (tests) |
| N3 | Low | @typescript-eslint/no-explicit-any | 333 | Throughout codebase | Deferred (Phase 2) |
| N4 | Low | @typescript-eslint/no-unused-vars | 10+ | Various | ✅ Fixed |
| N5 | Low | @typescript-eslint/no-this-alias | 1 | mcp.ts:365 | ✅ Fixed |
| N6 | Info | security/detect-non-literal-regexp | Few | Tests | Accepted |

**Note on Object Injection:** `eslint-plugin-security/detect-object-injection` has a high false-positive rate. It flags any `obj[variable]` pattern. These need manual triage — most are likely safe bracket access on known objects.

---

### Node — npm audit

**Command:** `npm audit --audit-level=high`  
**Result:** ✅ 0 vulnerabilities

---

### .NET — Roslyn + SonarAnalyzer.CSharp

**Command:** `dotnet build` with AnalysisMode=All, AnalysisLevel=latest-all, SonarAnalyzer.CSharp 10.4.0, Microsoft.CodeAnalysis.NetAnalyzers 9.0.0  
**Result:** ✅ 0 warnings, 0 errors

---

### .NET — Vulnerable Packages

**Command:** `dotnet list package --vulnerable`  
**Result:** ✅ 0 vulnerabilities across all 14 projects

---

## 6. Action Plan

### Immediate Fixes (High/Critical — this PR):

| ID | Language | Action |
|----|----------|--------|
| P1 | Python | Fix 5 undefined names (add missing imports/type aliases) |
| P2-P3 | Python | Review and fix subprocess shell=True usage |
| P6-P7 | Python | Auto-fix unused imports and import order (`ruff check --fix`) |
| R5-R6 | Rust | Add `// SAFETY:` documentation to undocumented unsafe blocks in FFI crates |
| R10 | Rust | Add `CDLA-Permissive-2.0` to deny.toml license allowlist |

### Fix Details (file-level):

| Finding | File Changed | What Was Done |
|---------|-------------|---------------|
| P1 (F821: `Awaitable` undefined) | `sdk/python/agent_shield/adapters/_shield.py` | Added `Awaitable` to typing import |
| P1 (F821: `GuardrailsConfig`, `CompiledPolicy`) | `sdk/python/agent_shield/runtime.py` | Added `TYPE_CHECKING` guard with conditional import from `.config` |
| P2 (S603: shell=True) | `sdk/python/tests/test_cross_lang_digest.py` | Resolved `node` via `shutil.which()`, pass absolute path, removed shell=True |
| P3 (S607: partial path) | `sdk/python/tests/test_cross_lang_digest.py` | Same fix — `shutil.which("node")` provides full path |
| P6 (F401: unused imports) | `sdk/python/agent_shield/adapters/autogen.py`, `crewai.py`, `langchain.py`, `openai_agents.py`, `semantic_kernel.py`, `_shield.py`, `integrations/litellm_proxy/_guardrail.py`; `cli/` modules; test files | Removed unused imports (auto-fixed by ruff) |
| R5-R6 (undocumented unsafe) | `sdk/rust/agent_shield_core/src/ffi.rs` | Added `// SAFETY:` comments to all unsafe blocks explaining invariants |
| R5-R6 (Send/Sync impl) | `sdk/rust/agent_shield_core/src/ffi.rs:528-535` | Split comment into per-impl SAFETY docs for `CallbackHolder<F>` |
| R10 (license) | `deny.toml` (new file) | Created config with `CDLA-Permissive-2.0` in allow list |
| N1 (object injection - true positive) | `sdk/node/index.ts:665-685` | Replaced `triggerMap[triggerKey]` with explicit `switch` statement |
| N1 (object injection - false positives) | `sdk/node/index.ts:395,571,726`, `mcp.ts:72`, `shield.ts:478`, `integrations/ghcp/index.ts:121,470`, `integrations/openclaw/index.ts:438` | Added `eslint-disable-next-line` with justification per site |
| N5 (no-this-alias) | `sdk/node/mcp.ts:365` | Replaced `const shield = this` + closure with arrow function using `this` directly |
| N4 (unused vars) | `sdk/node/shield.ts:476`, test files | Added `void _opts` or prefixed with `_` |
| .NET (analyzers) | `sdk/dotnet/src/Directory.Build.props` | Added SonarAnalyzer.CSharp + Microsoft.CodeAnalysis.NetAnalyzers (PrivateAssets=all) |

### Deferred (with rationale):

| ID | Rationale |
|----|-----------|
| R1-R3 (indexing/unwrap/arithmetic) | 4000+ findings; needs careful per-case triage. Track as tech debt. Existing CI clippy (`-D warnings`) already enforces default correctness. |
| R7-R8 (pedantic style) | No security impact. Address incrementally. |
| R9, R13-R16 (unmaintained deps) | Transitive via langchain-rust. No exploit path. Monitor for upstream fix. |
| P8 (assert in tests) | Expected pattern in test code. |
| P11-P14 (pip CVEs) | Tooling-level only. Not in shipped artifact. |
| N1 (object injection) | High FP rate — manual triage shows safe bracket access. |
| N3 (no-explicit-any) | 333 instances = significant refactor. No security impact. Phase 2. |

---

## 7. Tools Configuration Used

### deny.toml (committed to repo root)
Minimal config enabling advisories, license allowlist, ban wildcards, source trust.

### ESLint config (`sdk/node/eslint.config.mjs` — committed)
Flat config with @eslint/js recommended + typescript-eslint recommended + eslint-plugin-security recommended. Security rules promoted to `error` for source files.

### .NET Directory.Build.props (committed change)
Added EnableNETAnalyzers, AnalysisMode=All, SonarAnalyzer.CSharp, Microsoft.CodeAnalysis.NetAnalyzers as PrivateAssets=all.

---

## 8. How to Reproduce These Findings

### Prerequisites
```powershell
cargo install cargo-deny cargo-audit
pip install ruff pip-audit
cd sdk/node && npm install  # installs eslint + plugins from devDependencies
```

### Commands (run from repo root):
```powershell
# Rust (expanded lints — more than CI runs)
cargo clippy --workspace --all-features --all-targets -- -W clippy::pedantic -W clippy::unwrap_used -W clippy::expect_used -W clippy::panic -W clippy::indexing_slicing -W clippy::arithmetic_side_effects -W clippy::undocumented_unsafe_blocks -W clippy::missing_safety_doc -A clippy::module_name_repetitions -A clippy::must_use_candidate

# Rust (dependency scanning)
cargo deny check
cargo audit

# Python (from repo root)
ruff check --select S,B,E,F,W sdk/python/ cli/
pip-audit --desc

# Node (from sdk/node/)
cd sdk/node
npx eslint --config eslint.config.mjs .
npm audit --audit-level=high

# .NET (from sdk/dotnet/)
cd sdk/dotnet
dotnet build
dotnet list package --vulnerable

# Verify tests still pass
cargo test --workspace
cd sdk/python && pytest
cd sdk/node && npm test
cd sdk/dotnet && dotnet test
```

---

## 9. Phase 2 Roadmap (Not Yet Implemented)

Phase 2 will integrate these scanners into CI so they run automatically on every PR:

| Deliverable | Description |
|-------------|-------------|
| `.github/workflows/static-analysis.yml` | Unified workflow running all linters on PR |
| `.github/dependabot.yml` | Automated dependency update PRs |
| `.github/workflows/codeql.yml` | CodeQL for Python/JS/C# (not Rust — preview quality) |
| `[workspace.lints]` in `Cargo.toml` | Centralized Rust lint policy |
| `#![forbid(unsafe_code)]` on pure-logic crates | Prevent accidental unsafe in non-FFI code |
| Pre-commit config (opt-in) | Developer convenience for local checking |

Phase 2 will be tracked separately. This document covers Phase 1 only.
