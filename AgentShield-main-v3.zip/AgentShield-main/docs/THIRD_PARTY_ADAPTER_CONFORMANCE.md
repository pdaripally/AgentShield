# Third-party adapter conformance

This is the minimum public evidence a third-party adapter should publish before Agent Shield links to it from the README.

## Required tests

1. **Canonical guarded path** — the documented supported path must produce Stage-3/4 verdicts with a stable `tool_call_id` / `invocation_hash` binding when tool execution is mediated.
2. **Direct-call bypass proof** — calling the raw framework/tool surface directly must be shown to bypass guardrails, or the adapter must prove it has removed the raw path entirely.
3. **Wrapped-to-raw swap regression** — replacing a wrapped tool with the raw tool mid-session must fail closed or emit an explicit incident that the host can act on.
4. **Malformed / unknown invocation shape** — unknown tool-call envelopes must fail closed. Do not coerce unknown shapes into best-effort execution.
5. **Streaming deny** (if streaming is supported) — after at least one chunk is released, a later deny must terminate the stream and emit the documented incident.
6. **Versioned capability report** — the adapter must state which Agent Shield stages are `full`, `partial`, or `unsupported` for each supported framework version.
7. **Parity fixtures** — the adapter's SDK must pass the canonical Shield API, capability, verdict-dispatch, invocation-hash, and documented error-mapping parity fixtures for its ecosystem.

## Required docs

Publish a `MEDIATION.md` with:

- mediated public APIs,
- unsupported / bypass paths,
- streaming behavior against §18.4,
- unknown invocation-shape handling,
- exact wrap sites in source (`file:line`).

## Release-claim rule

If a path is not covered by tests and docs, do not claim it as mediated.
