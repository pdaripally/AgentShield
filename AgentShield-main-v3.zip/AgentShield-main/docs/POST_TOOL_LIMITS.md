# Post-tool limits

Agent Shield's Stage 4 (`post_tool_validation`) and Stage 5 (`output_validation`) checks protect later context and later disclosure. They do **not** reverse a side effect that has already happened.

## The fundamental limit

If a tool already wired money, sent mail, deleted a row, or ran a shell command, a later Stage-4/5 deny can still:

- stop the model from seeing the raw result,
- stop the user from seeing the raw result,
- emit telemetry and incident evidence,
- terminate the rest of the turn.

It cannot make the side effect unhappen.

That is why Agent Shield is a **mediation layer**, not a compensating transaction engine. See §17 for post-tool validation semantics and §22 for the host contract.

## Compensating patterns the host must own

### Pre-action validation

Any irreversible action should have a Stage-3 policy strict enough that the call is denied **before** the backend executes it.

Examples:

- block external recipients before `sendMail` runs,
- block high-value transfers before `wire_funds` runs,
- block destructive SQL or shell tools before execution.

### Idempotency keys

Retryable side effects should carry host-owned idempotency keys. That composes with resolver `transport.retry:` behavior: a retried tool call stays safe only when the backend can collapse duplicates.

### Backend authorization

Tool backends must still authorize independently. Agent Shield is not a replacement for backend authz, tenant scoping, or business-rule enforcement.

### Out-of-band confirmation

Use `kind: human` for high-stakes actions where a person must approve or cancel before the tool executes. Cache decisions only inside the intended session boundary.

## Common insecure integration patterns

- **Using post-tool validation as the primary gate on irreversible actions.** If the action is irreversible, Stage 3 should be the hard gate.
- **Caching approval decisions across `session_id`s.** Session isolation is load-bearing; a decision for one conversation must not authorize another.
- **Logging raw tool outputs at info level for debugging.** If a post-tool policy exists, the raw output is exactly the data you should assume is sensitive. Use telemetry redaction and approved sink controls instead.
- **Custom adapters that call the underlying tool before any Shield call.** That is a bypass, not an integration.
- **Mixing shadow mode and active mode without per-request scoping.** Mode must be attached to the request/session you are actually mediating.

## Worked examples

### `examples/agents/bank-manager/`

- `wire transfer`: **irreversible**. The controlling guard must be Stage 3 plus `kind: human` for approval-worthy transfers.
- transfer memo / beneficiary details shown back to the model: Stage 4 can still redact or block disclosure, but only after the transfer tool has already acted.
- customer-visible assistant response: Stage 5 can still block or redact leaked account details.

### `examples/agents/document-dlp/`

- document retrieval: usually reversible in the backend, but the **disclosure** to the model or user is not. Stage 4 protects what enters later context; Stage 5 protects what leaves the agent.
- outbound email/send action: effectively irreversible once delivered. Stage 3 should gate it; Stage 4/5 only constrain later disclosure of the result.

## Practical guidance

1. Put hard preconditions on irreversible tools in Stage 3.
2. Treat Stage 4/5 as containment and disclosure controls.
3. Keep backend authz and audit outside Agent Shield.
4. Use `kind: human` when the business process truly needs confirmation.
