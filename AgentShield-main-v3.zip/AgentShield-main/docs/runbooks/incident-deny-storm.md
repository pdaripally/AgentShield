# Incident runbook: deny storm

## Trigger

Use this runbook when deny or block volume jumps sharply across many sessions, tenants, or routes.

## Immediate actions

1. Confirm whether the spike started with a config, model, resolver, or adapter rollout.
2. Page the service owner if customer traffic is materially degraded.
3. Freeze further policy/runtime deploys until the cause is understood.

## What to check first

- Top guard-policy names by deny count.
- Event mix: `guard_policy.*.blocked`, `incident.limit_exceeded`, `resolver_*`, `incident.stream_aborted`.
- Whether the spike is isolated to one tenant, one framework adapter, or one workload.
- Error budgets, request latency, and resolver availability in the same window.

## Common causes

- A stricter policy rollout that removed an allow path.
- Resolver timeouts or backend failures causing fail-closed outcomes.
- Adapter bypass regressions that changed the canonical invocation seen by Stage 4.
- Prompt amplification or malformed input tripping runtime limits.

## Mitigation

- If a new release caused the storm, roll back that release or drain traffic from the affected pool.
- If the issue is resolver availability, follow `incident-resolver-down.md`.
- If limit events dominate, follow `incident-limit-exceeded.md`.
- If only one tenant or route is affected, narrow traffic and preserve samples before broad rollback.

## Root-cause checklist

- Which policy names blocked most frequently?
- Did the merged YAML or adapter version change?
- Did the canonical invocation hash shape change?
- Did telemetry redaction hide a field operators now need for diagnosis?
- Did the host add a new tool, endpoint, or agent path without updating policy coverage?

## Exit criteria

- Deny rate returns to expected baseline.
- The triggering config/runtime change is identified.
- A corrective action is tracked before the incident is closed.
