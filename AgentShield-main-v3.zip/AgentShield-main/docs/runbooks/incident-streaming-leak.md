# Incident runbook: streaming leak or mid-stream abort

## Trigger

Use this runbook when streamed content appears to leak sensitive material, or when `incident.stream_aborted` / `incident.stream_limit_exceeded` events spike.

## Most-common root cause: hand-rolled streaming wrapper

Before working through the rest of this runbook, check whether the affected route uses a **custom streaming wrapper around `shield.run` / `Shield.RunAsync` / `Shield::guarded_run`**. The canonical anti-pattern looks like:

```python
async for chunk in agent.run_stream(...):
    yield chunk                              # ← raw chunk leaks here
final = await shield.run_with_session(session, consume, user_input=prompt)
# … Stage 5 redacts `final`, but the raw chunks already shipped
```

This pattern is **unsafe by construction**. Stage 5 redaction requires the *full output context* to compute redaction spans:

- **Per-chunk Stage 5 cannot work**: a substring cannot be classified as sensitive until enough surrounding text has been seen.
- **Per-stream-finalize Stage 5 emits raw chunks BEFORE redaction**: the leak has already shipped over the wire by the time the final pass returns.

If the incident matches this pattern, the fix is structural — not a YAML / policy tweak. See "Prevention" below and the per-SDK README streaming sections.

## Immediate actions

1. Stop or drain streaming traffic for the affected route.
2. Preserve request IDs, session IDs, and event samples.
3. Determine whether any partial output already reached end users.
4. Page the on-call owner for the affected adapter/framework path.

## Evidence to collect

- The exact streaming route, adapter, and framework version.
- Whether the incident emitted `incident.stream_aborted` or `incident.stream_limit_exceeded`.
- The policy name or limit name associated with the denial.
- Whether the host buffered chunks or released them directly to clients.
- **Whether the route uses a custom streaming wrapper** rather than a shipped adapter (see "Most-common root cause" above).

## Containment

- Temporarily force buffered/non-streaming responses if the product can tolerate it.
- Disable the affected streaming feature flag or endpoint until the boundary is understood.
- If only one adapter path is implicated, route traffic to a known-mediated path documented in `docs/adapter-mediated-paths.md`.

## Root-cause checklist

- Did a chunk escape before Stage 5 denied the stream?
- Did the host release chunks before the guarded boundary completed validation?
- **Did the host hand-roll a streaming wrapper instead of using a shipped streaming adapter?** See the top of this runbook.
- Did a new upstream truncation or gateway cap change the stream length behavior?
- Did the deployment move onto a runtime that lacks the expected streaming safeguards?

## Remediation

- Fix the adapter/buffering path before re-enabling streaming.
- If the route used a hand-rolled streaming wrapper, replace it with one of the three safe options under "Prevention" below.
- Add or update the relevant conformance case for the observed failure mode.
- Review whether user-visible content must be deleted or customers notified under local policy.

## Prevention

**Do not hand-roll streaming wrappers around AgentShield.** Only an adapter that owns chunk emission — so it can buffer, validate, and *then* emit the safe-to-emit slice — can stream safely.

When AgentShield does not yet ship a streaming adapter for your framework, choose one of:

1. **Disable streaming** and use the buffer-mode response. Stage 5 sees the full output and redaction is correct.
2. **Use the [LiteLLM Proxy plugin](../integrations/litellm-proxy.md)**, which enforces Stage 5 in buffer-mode at the gateway. (Latency trade-off documented in the Streaming section.)
3. **Implement a sentinel-only stream**: emit a heartbeat / progress token, run the real LLM call to completion, then reveal the validated output after Stage 5 returns.

The per-SDK streaming-adapter inventory lives in each SDK's README under the "Streaming safety" subsection; the cross-SDK matrix lives in [`docs/adapter-mediated-paths.md`](../adapter-mediated-paths.md).

## Exit criteria

- The affected streaming path is either disabled or demonstrably mediated.
- New events confirm the incident is no longer recurring.
- A follow-up item exists for any missing conformance or adapter coverage.
