# Runbook: release rollback

## Scope

Use this runbook when a new AgentShield runtime or adapter release must be rolled back without losing control of in-flight sessions.

## Important constraint

AgentShield session state is owned by the host application's session lifecycle. The runtime is in-process and does not promise transparent cross-version migration of live in-memory session objects.

## Safe rollback pattern

1. Stop sending new sessions to the bad release.
2. Keep sticky routing for existing sessions so they continue on the version that created them.
3. Drain old pods/processes only after active sessions finish or are explicitly reset.
4. Shift new traffic to the previous known-good release.

## If the host externalizes session state

- Verify that the previous release can read the persisted session format.
- If compatibility is uncertain, preserve the store and rehydrate only after validation in staging.
- Never mutate persisted session data during rollback unless a migration plan exists.

## Operational checklist

- Confirm the exact tag/commit to restore.
- Restore the previous container/app image and the matching `.guardrails.yaml` set.
- Re-run conformance and smoke checks on the rollback candidate.
- Monitor deny rate, error rate, and resolver/stream incidents during the rollback window.

## When to force session resets

Reset sessions only when:

- the bad release corrupted session state,
- the host cannot maintain sticky routing, or
- the previous release is incompatible with the current session format.

If you reset, notify the product owner because approval state and per-session variables may be lost.

## Exit criteria

- New traffic is fully on the known-good release.
- Existing sessions are drained or intentionally reset.
- A corrective action exists for the failed release before attempting redeploy.
