# Incident runbook: runtime limit exceeded

## Trigger

Use this runbook when `incident.limit_exceeded` or `incident.stream_limit_exceeded` events spike, or when callers report requests failing because of size/complexity bounds.

## Immediate actions

1. Identify the limit name carried on the event attributes.
2. Determine whether the spike is malicious traffic, unexpected workload growth, or a recent config change.
3. Compare gateway-layer request limits with runtime `limits:` settings.

## Typical causes

- Prompt amplification or tool-parameter explosion.
- Oversized YAML/config merges.
- Resolver responses exceeding expected schema size.
- New workloads that legitimately need higher caps but were deployed without tuning.

## Diagnostics

- Top offending routes, tenants, tool names, and limit names.
- Request body sizes and response sizes at the gateway.
- Whether a new policy or customer workload recently increased prompt/context size.
- Whether failures correlate with a single adapter or SDK.

## Mitigation

- Block or rate-limit abusive traffic at the edge.
- Reduce prompt/context bloat upstream.
- If the workload is legitimate, raise the affected limit through normal config change control and keep gateway caps aligned.
- If streaming-length events dominate, treat it as a potential exfiltration or amplification incident until ruled out.

## Exit criteria

- The offending limit name returns to normal volume.
- Any changed cap is reviewed and documented.
- The postmortem records whether the event was attack traffic, user error, or an undersized default.
