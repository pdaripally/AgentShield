# Incident runbook: resolver trust failure

## Trigger

Use this runbook when `resolver_response_schema_violation` or `resolver_signature_invalid` events flood the bus.

## Why this matters

These failures mean the resolver path is responding, but its output no longer satisfies the contract AgentShield was configured to trust. Treat this as a trust-boundary incident, not a routine availability issue.

## Immediate actions

1. Preserve failing samples and associated request IDs.
2. Confirm whether the resolver code, schema, or signing key changed.
3. Stop rollout of new resolver versions until the trust failure is explained.
4. Page both the application owner and the resolver owner.

## Diagnostics

- Compare live responses against the configured `response_schema`.
- Validate the expected signing algorithm and `verification_key_env` material.
- Confirm TLS and identity settings on the resolver `transport:` path.
- Check whether an upstream proxy, gateway, or serializer is rewriting the payload.

## Mitigation

- Roll back to the last known-good resolver build if this began after a deploy.
- Rotate verification keys only through normal key-management procedures; do not disable signature checks to restore traffic.
- If schema drift is intentional, deploy the schema and code change together in a reviewed rollout.

## Exit criteria

- Resolver responses validate again.
- Signature or schema drift is understood and documented.
- Any key rotation or schema migration is recorded for later audit.
