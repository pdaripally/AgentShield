# Incident runbook: resolver unavailable

## Trigger

Use this runbook when resolver-backed decisions start failing because of transport errors, timeouts, DNS failures, or backend outages.

## Expected AgentShield behavior

Per `spec/SPECIFICATION.md#117-on_error-semantics`, resolver failures fail closed unless the spec-defined path synthesizes a safe null result. There is no production "break glass" override in AgentShield itself; the host owns traffic routing and rollout decisions.

## Immediate actions

1. Confirm the resolver endpoint, DNS, TLS, and identity status.
2. Notify the resolver service owner.
3. Preserve representative deny events and transport errors.
4. Stop rollout of any new policy or runtime changes until the dependency is healthy.

## Diagnostics

- Check resolver latency, timeout rate, and 5xx rate.
- Verify outbound egress/network policy still allows the resolver destination.
- Confirm certificates, mTLS identities, and trust bundles are valid.
- Confirm the host is not silently bypassing the guarded path.

## Mitigation

- Restore the resolver service or route traffic to a healthy instance.
- If the host has an existing safer non-resolver path, move traffic there explicitly; do not bypass AgentShield in place.
- If the incident is isolated to one deployment slice, drain that slice and keep healthy slices serving.

## What not to do

- Do not add an emergency allow-all policy.
- Do not patch the runtime to ignore resolver failures.
- Do not drop TLS or signature verification to recover availability.

## Exit criteria

- Resolver availability and latency recover.
- Deny rate attributable to resolver transport failure returns to baseline.
- Any traffic routing change is documented and either reverted or made permanent through normal change control.
