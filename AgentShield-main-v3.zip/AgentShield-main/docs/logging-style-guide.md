# Agent Shield — Logging Style Guide

This guide is **normative** for any code that emits logs from the Agent Shield SDKs (Rust, Python, .NET, Node). It exists so that adopters get the same observability surface, the same log levels mean the same things, and sensitive data never leaks at `info+`.

These rules are **partially CI-gated today**:

- Rule 1 ("Sensitive data NEVER appears at `info+`") is hard-gated today by the CI lint scripts under [`.github/scripts/`](../.github/scripts/) (`lint-logging.sh`, `lint_logging.py`, `lint-logging-dotnet.sh`).
- The Rust + Python no-PII sentinel runtime tests (`sdk/rust/agent_shield_core/tests/no_pii_sentinel.rs`, `sdk/python/tests/test_no_pii_sentinel.py`) land in PR1 as scaffolded tests with `#[ignore]` / `pytest.skip(...)`; they become runtime enforcement once those markers are removed in PR2/PR3. The .NET wrapper is a passthrough over the FFI'd `ShieldLogEvent` and cannot introduce PII independently of the Rust core, so a separate .NET runtime sentinel test is unnecessary; Rule 7 on the .NET side is enforced by `lint-logging-dotnet.sh`.
- Node-side CI enforcement is deferred until the Node SDK unblock tracked in microsoft/AgentShield#82; the ESLint rule currently lands as a stub.
- Rules 2-7 remain normative for all SDKs, but today they are reviewer/audit enforced rather than CI-gated end-to-end.

If you are about to add a `log::info!` / `logger.info(...)` / `_logger.LogInformation(...)` / `console.info(...)` call, **read this guide first**. Most contributions need only Rule 1 + Rule 4.

---

## The 7 rules

### 1. Sensitive data NEVER appears at `info+`.

Sensitive data means: tool arguments, tool results, endpoint request bodies, endpoint response bodies, agent inputs, agent results, user input strings, agent output strings, variable values populated by tools, secrets (API keys, tokens), and obvious PII (emails, phone numbers, account numbers).

The exhaustive token list lives at [`.github/scripts/sensitive-names.txt`](../.github/scripts/sensitive-names.txt). Adding to that list tightens the lint; removing requires a paired update to this guide.

If you need to log a sensitive value for debugging, do **either**:

- **Demote to `debug`**: `log::debug!(target: "...", "tool args: {}", tool_args)`. Debug is operator-controlled; the operator who turns it on accepts the disclosure cost.
- **Redact to type+length**: `log::info!(target: "...", "tool args: <object len={}>", n_keys)`. Carries operational signal without the payload.

### 2. Use the canonical log target prefix.

All Rust log calls must include `target: "agent_shield::<area>"` where `<area>` is one of the established areas. This lets adopters filter our log surface from theirs:

| Area | Used by |
|---|---|
| `agent_shield::runtime` | `runtime/`, session lifecycle |
| `agent_shield::resolver_runtime` | `resolver_runtime/`, `auto_resolution` |
| `agent_shield::guard_policy_runtime` | `guard_policy_runtime/`, stage runners |
| `agent_shield::ifc` | `ifc.rs`, declassification checks |
| `agent_shield::expressions` | `expressions/`, evaluator + builtins |
| `agent_shield::lifetime_tracker` | `lifetime_tracker/` |
| `agent_shield::populator` | `populator.rs` |
| `agent_shield::shield` | The Rust SDK `Shield` orchestrator |
| `agent_shield::facade` | The Rust SDK facade |
| `agent_shield::<framework>` | Per-framework adapter (e.g. `agent_shield::openai`) |
| `agent_shield.<sink>` | Bundled observability sinks (e.g. `agent_shield.azure_monitor`) |

Python uses `logging.getLogger("agent_shield.<area>")`. .NET uses `ILogger<T>` with the type name. Node uses the structured-logger naming the consuming framework provides.

### 3. Log levels mean what they say.

| Level | When |
|---|---|
| `error` | Unrecoverable: shutdown imminent OR data corruption avoided. Rare. |
| `warn` | Recoverable but operator-actionable: fail-closed deny, retry exhausted, lifecycle method swallowed an error. |
| `info` | Steady-state operational signal: provider startup, configuration applied, capability summary at startup. **Not per-request.** |
| `debug` | Per-request / per-call detail useful when an operator turns it on. May include sensitive values (operator opts in). |
| `trace` | Hot-path internals only operators reading source code understand. |

If you find yourself wanting to emit at `info` for every tool call, you want a `ShieldLogEvent` emitted via the dispatcher, not a `log::info!`. See Rule 6.

### 4. Use structured templates, not concatenation.

Yes:
```rust
log::warn!(target: "agent_shield::runtime", "populator on `{}` raised {:?}; skipping", var.name, e);
```

No:
```rust
log::warn!(target: "agent_shield::runtime", "populator on `{}` raised {}", var.name, format!("{:?}", e));
```

Same for Python (`logger.warning("Tool '%s' raised %s", tool_name, type(exc).__name__)`, not f-strings; keep the full exception text/traceback at debug with `exc_info=True`) and .NET (`_logger.LogWarning("Tool {Name} raised", toolName)`, not `$"..."`). Structured templates let downstream pipelines extract fields without re-parsing the message.

### 5. Don't duplicate the dispatcher.

Every observability provider already receives `ShieldLogEvent`s from the central `ObservabilityDispatcher`. If your new info+ line is reporting the same fact a `ShieldLogEvent` already carries (`tool.<name>.called`, `guard_policy.<name>.evaluated`, etc.), drop the log call — the dispatcher is the canonical surface.

If you genuinely need a log line that the dispatcher doesn't carry (e.g. operational warning during a swallow path), that's fine. Rule 4 still applies.

### 6. Operational state goes through the dispatcher; logs are a fallback.

`ShieldLogEvent` is the canonical surface for runtime state changes. The `log::*` macros are for:

- Operator warnings the runtime can't recover from cleanly (`record_tool_failure failed: ...`).
- Provider-side fallbacks when a configured sink fails (e.g. CloudWatch endpoint unreachable → `log::error!` so the operator sees something even when the metric pipe is broken).
- Debug-level diagnostics the runtime emits during development.

If you find yourself wanting a *new* category of operational state visible to adopters, add a typed `ShieldLogEvent` variant (`KnownEventType` in [observability/event.rs](../sdk/rust/agent_shield_core/src/observability/event.rs)) and emit it via the dispatcher. Then nothing has to be fan-out logged.

### 7. .NET SDK is silent by design.

The .NET SDK does not call `_logger.LogInformation` / `Console.WriteLine` from production code. All operational state is emitted through `IObservabilityProvider` callbacks registered on the runtime. This is deliberate — adopters wire `Microsoft.Extensions.Logging` (or any other logger) into the provider, and the SDK doesn't second-guess that wiring.

If you find yourself wanting to add a `_logger.Log*` call in `sdk/dotnet/src/`, **stop**. Either:

- The information belongs on a `ShieldLogEvent` carried by an existing provider call → emit it through the dispatcher.
- The information is a developer-debug aid → use `Debug.WriteLine` (compiled out in release).

---

## Allowed exceptions to the lint

The CI lint exempts the following paths because the log call IS the user-facing surface, not metadata about it:

- `examples/**` — demo agents; their logs are part of the demo output.
- `tests/**` and `sdk/*/tests/**` — test scaffolding.
- `sdk/rust/agent_shield_core/src/approval/console.rs` — `eprintln!` IS the interactive console approval surface (`(a)llow / (b)lock / ...`); demoting it to debug would break the contract.
- `sdk/rust/agent_shield_core/src/classifiers/auto.rs` (debug-level only) — autoload diagnostics, gated by debug.
- `sdk/rust/agent_shield/src/observability/{azure_monitor,cloudwatch}.rs` info+ — the documented fallback emit path when no remote endpoint is configured. This IS the dispatcher's terminal sink in that mode.

Adding a new exception requires updating both the lint scripts AND this guide in the same PR.

---

## See also

- [`.github/scripts/sensitive-names.txt`](../.github/scripts/sensitive-names.txt) — the lint's denylist of sensitive identifier names.
- [`tasks/logging-audit.md`](../tasks/logging-audit.md) — current inventory of every log call site under `sdk/`, with bucket classification.
- v8 perf-logging plan §5 PR1 — the planning context for these rules.
