# Production deployment checklist

AgentShield is a mediation layer, not a complete system boundary. The host application still owns authentication, authorization, credentials, network reachability, and operations per `spec/SPECIFICATION.md#22-host-contract`.

Use this checklist before calling an AgentShield deployment production-ready.

## 1. Identity, authn, and authz

- Require strong caller authentication on every host-facing endpoint before the request reaches the agent loop.
- Enforce backend authorization in the host and downstream services; AgentShield policy is not a substitute for service-side ACLs.
- Treat resolver responses as untrusted until they satisfy the configured schema/signature contract.
- Use stable, unguessable `session_id` / request correlation identifiers so approval and state bindings cannot be replayed across tenants.

## 2. Transport security

- Terminate TLS at the edge and re-encrypt on every hop that leaves the host process.
- Prefer mTLS for service-to-service traffic, especially resolver, MCP, classifier, and sidecar paths.
- If you deploy on Kubernetes, start from `deploy/kubernetes/istio-sdk-reference/` and keep Istio peer authentication in `STRICT` mode.
- When running a runtime that includes PR2 trust-boundary features, set `transport:` explicitly for external resolvers instead of relying on defaults.

## 3. Network policy and egress control

- Default-deny egress from agent workloads.
- Allow only the exact resolver/classifier/MCP destinations the deployment needs.
- Separate internet egress for the agent host from internal-only resolver and tool networks.
- Log DNS and egress-policy denials so resolver outages can be distinguished from policy failures.

## 4. Gateway limits and amplification controls

- Enforce request-size, response-size, and rate limits at the ingress gateway before traffic reaches the SDK.
- Bound streaming response sizes and chunk cadence at the gateway as a second line of defense.
- Apply tenant-level and API-key-level rate limits to agent endpoints.
- When available in your runtime version, align gateway caps with the YAML `limits:` block so the outer gateway and inner runtime fail closed at similar thresholds.

## 5. Runtime limits

- Review default `limits:` values before rollout; lower caps are safer for hostile environments, higher caps may be necessary for large trusted workflows.
- Monitor `incident.limit_exceeded` floods by limit name; they usually indicate prompt amplification, config bloat, or a too-low cap.
- Treat repeated `incident.stream_limit_exceeded` events as a deployment problem until proven otherwise.

## 6. Secrets and key management

- Store resolver credentials, classifier API keys, and signing/verification keys in a managed secret store, never in YAML.
- Rotate secrets independently of application deploys.
- For signed resolver responses, inject public keys through environment variables such as `response_signature.verification_key_env`.
- Scope secrets to the minimum environment, namespace, and workload identity that needs them.

## 7. Container and host hardening

- Run the host process as a non-root user.
- Use read-only root filesystems where the framework permits it.
- Drop Linux capabilities you do not need.
- Pin base images and OS packages; rebuild on base-image CVEs.
- Keep the AgentShield runtime in-process; do not add an unguarded bypass path around the adapter or SDK wrapper.

## 8. Audit-log handling

- Persist AgentShield events outside the process boundary.
- Define retention, access control, and deletion rules for those logs before go-live.
- Default to redacted telemetry; only opt into raw payload capture for tightly scoped forensic workflows.
- Alert on spikes in block, deny, schema-violation, signature-invalid, and stream-aborted events.

## 9. Release and change management

- Require the conformance release-claim gate, CodeQL, SCA, secret scanning, license scanning, and the existing CI suites before promoting a release.
- Run `.github/skills/ci-verification/verify.sh` against the exact commit you plan to tag.
- Keep a rollback plan that drains or preserves in-flight session ownership; see `docs/runbooks/release-rollback.md`.

## 10. What this checklist does not replace

This checklist does not certify your system. It does not prove downstream tools are safe, that your model is robust to every jailbreak, or that your host application enforces business authorization correctly. It is the minimum operational baseline for deploying AgentShield without obvious trust-boundary gaps.
