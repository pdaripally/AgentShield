# Design Document: Cross-SDK Test Parity Framework

| Field | Value |
|-------|-------|
| **Author** | Apoorv Jindal |
| **Status** | Draft — Pending Team Review |
| **Created** | 2026-05-19 |
| **Target** | Agent Shield v0.14.0 |
| **Reviewers** | TBD |

---

## 1. Problem Statement

Agent Shield ships four SDK surfaces (Rust, Python, Node, .NET) wrapping a shared Rust core. Today, each SDK has its own test harness that independently consumes a shared pool of ~60 YAML-defined behavioral test cases. However:

1. **No enforcement mechanism** ensures all four SDKs pass the same set of cases — behavioral drift between SDKs is undetected until customers report it.
2. **No security-invariant test suite** validates the project's #1 property: fail-closed semantics (ambiguity → deny). A binding that silently fails-open would be a CVE-class bug.
3. **No FFI boundary testing** validates correctness across the PyO3 / napi-rs / P/Invoke boundaries under stress (concurrency, malformed input, panics).
4. **Test coverage for core features** (config extends, resolvers, malformed config rejection) is incomplete across the shared suite.
5. **No CI gate** blocks PRs that introduce cross-SDK divergence.

This design proposes a unified test parity framework that solves all five problems with minimal additional infrastructure.

---

## 2. Goals & Non-Goals

### Goals
- G1: All four SDKs pass the same behavioral test suite, enforced in CI
- G2: Security-critical invariants (fail-closed) are explicitly tested cross-SDK
- G3: FFI boundary correctness is validated per-binding
- G4: Test case coverage expands from ~60 to ~150+ deterministic cases
- G5: Parity failures are surfaced clearly (not hidden as silent skips)
- G6: Implementable with parallel agents in ≤2 days

### Non-Goals
- Streaming validation (requires spec clarification and Clock trait refactor)
- E2E adapter tests with real LLM providers (deferred to frozen-replay milestone)
- Performance benchmarking (deferred to nightly CI milestone)
- Telemetry/observability parity (deferred)
- Changes to `spec/SPECIFICATION.md`

---

## 3. Design Overview

### 3.1 Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│  CI: cross-sdk-parity.yml                                        │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │  tests/conformance/run_parity.py                             │ │
│  │  • Validates YAML cases against JSON Schema                  │ │
│  │  • Spawns 4 SDK harnesses in parallel                        │ │
│  │  • Collects JSON result files                                │ │
│  │  • Computes capability-aware parity matrix                   │ │
│  │  • Outputs: PR comment (Markdown), artifact (JSON)           │ │
│  │  • Exit code: 0 = parity OK, 1 = regression detected        │ │
│  └─────────────────────────────────────────────────────────────┘ │
│                              │                                    │
│         ┌────────────────────┼────────────────────┐              │
│         ▼                    ▼                    ▼              │
│  ┌────────────┐  ┌──────────────┐  ┌──────────────┐            │
│  │ Rust       │  │ Python       │  │ Node         │  + .NET     │
│  │ cargo test │  │ pytest       │  │ node --test  │             │
│  │ --emit-json│  │ --report=json│  │ --report=json│             │
│  └────────────┘  └──────────────┘  └──────────────┘            │
└─────────────────────────────────────────────────────────────────┘
```

**Key design decision**: A lightweight Python orchestrator (~250 LOC) rather than a separate Rust conformance binary. Rationale:
- Existing precedent in repo (`tests/parity/generate_drift_catalog.py`)
- No new build/release/dependency surface
- 95% of the value of a Rust driver at 5% of maintenance cost
- The Rust harness's existing YAML parser already validates semantics; the orchestrator only compares results

### 3.2 Parity Semantics

Not all SDKs support all features at all times. Raw case-count comparison is too blunt. Instead:

```yaml
# In each .cases.yaml test case:
sdk_support:
  rust: required      # Must pass — failure = CI red
  python: required
  node: required
  dotnet: optional    # May skip — tracked but not gating

xfail:
  dotnet: {issue: "https://github.com/microsoft/AgentShield/issues/123"}
```

**Status taxonomy:**

| Status | Meaning | CI effect |
|--------|---------|-----------|
| `pass` | Test passed | ✓ |
| `fail` | Test failed unexpectedly | ❌ blocks PR |
| `skip` | SDK marked `optional` for this case | ⚠️ tracked |
| `xfail` | Known failure with linked issue | ⚠️ tracked, not blocking |
| `unknown_action` | Harness doesn't recognize the YAML action verb | ❌ blocks PR |
| `error` | Harness crashed | ❌ blocks PR |

`unknown_action` is critical: it prevents an SDK harness from silently passing cases it doesn't actually implement. If the YAML uses `action: fire_event` and a harness doesn't know that verb, it must report it — not skip it.

### 3.3 Common Result Format

Each SDK harness emits a JSON file:

```json
{
  "sdk": "python",
  "sdk_version": "0.13.0",
  "core_version": "0.13.0",
  "timestamp": "2026-05-19T14:00:00Z",
  "results": [
    {
      "suite": "fail-closed",
      "case": "null_field_denies",
      "status": "pass",
      "duration_ms": 4,
      "error_detail": null
    },
    {
      "suite": "resolver-flows",
      "case": "cycle_detection",
      "status": "unknown_action",
      "duration_ms": 0,
      "error_detail": "Unrecognized action: invoke_resolver_chain"
    }
  ]
}
```

A JSON Schema (`tests/conformance/result_schema.json`) validates this format.

---

## 4. New Test Suites

### 4.1 Fail-Closed Security Invariants (`tests/cases/fail-closed.cases.yaml`)

**Priority**: P0 — This is the single highest-value deliverable.

Tests the project's core security property: when in doubt, deny.

| # | Case | Expected |
|---|------|----------|
| 1 | Null variable in boolean guard expression | `allowed: false` |
| 2 | Missing variable reference in `evaluate_when` | `allowed: false` |
| 3 | Unresolved variable in `active_if` | Policy inactive (safe default) |
| 4 | Cross-type comparison (string == number) | `false` (not error) |
| 5 | Unknown field in guardrails YAML | Load-time error |
| 6 | Invalid event namespace (e.g. `custom.foo`) | Load-time error |
| 7 | Conflicting verdicts (allow + deny from 2 guards) | `deny` wins |
| 8 | Empty `evaluate_when[]` with action: block | Block applies |
| 9 | Resolver returns invalid decision value | Treated as deny |
| 10 | Malformed expression syntax | Load-time error |
| 11 | Division by zero in expression | `null` → `false` → deny |
| 12 | Null propagation through arithmetic | `null + 5 → null → false` |
| 13 | Boolean coercion of empty array `[]` | `false` |
| 14 | Boolean coercion of empty string `""` | `false` |
| 15 | Variable with `@status: unset` in guard | `null` → deny |

### 4.2 Config Merging & Extends (`tests/cases/extends-merge.cases.yaml`)

Tests `extends:` chain resolution, the config composition model.

| # | Case | Expected |
|---|------|----------|
| 1 | Child inherits parent guard_policies | Both apply |
| 2 | Same-name guard_policy merges additively | Union of evaluate_when |
| 3 | Three-file chain (grandparent → parent → child) | All policies present |
| 4 | `active_if` is immutable across extends | Child cannot weaken parent's active_if |
| 5 | `allowed_when:` AND-composes across chain | Tighter restriction wins |
| 6 | Child adds new variable | Variable available |
| 7 | Parent + child same-name variable, compatible types | Merged |
| 8 | Parent + child same-name variable, incompatible types | Load-time error |
| 9 | Circular extends (A extends B extends A) | Load-time error |
| 10 | Child overrides parent's `default` on variable | Child wins |
| 11 | Relative path resolution in extends | Resolved relative to declaring file |
| 12 | Missing extends target | Load-time error |

### 4.3 Resolver Flows (`tests/cases/resolver-flows.cases.yaml`)

Tests resolver orchestration using **scripted mock resolvers**:

```yaml
# Mock resolver protocol in YAML:
given:
  resolver_mocks:
    - name: "approval_resolver"
      responses:
        - {decision: allow, value: "approved", set_variables: {approved: true}}
```

| # | Case | Expected |
|---|------|----------|
| 1 | Expression resolver evaluates inline | Correct verdict |
| 2 | Tool resolver returns allow | Variable set, tool proceeds |
| 3 | Tool resolver returns deny | Tool blocked |
| 4 | Human resolver allow_once | Single invocation allowed |
| 5 | Human resolver allow_always | All subsequent allowed |
| 6 | Human resolver decline | Blocked |
| 7 | Resolver retry (fail then succeed) | Succeeds on retry |
| 8 | Resolver max_retries exhausted | Deny |
| 9 | Fallback chain (primary fails, fallback allows) | Fallback verdict used |
| 10 | `on_allow` sets variables | Variables updated post-allow |
| 11 | Cycle detection (A→B→A) | Error, not infinite loop |
| 12 | Resolver `cancelled` decision | Tool blocked, reason logged |

### 4.4 Malformed Config & Robustness (`tests/cases/malformed-config.cases.yaml`)

| # | Case | Expected |
|---|------|----------|
| 1 | Invalid YAML syntax (unclosed bracket) | Parse error |
| 2 | Unknown top-level field | Load-time error |
| 3 | Unknown field inside guard_policy | Load-time error |
| 4 | Duplicate policy ID | Load-time error |
| 5 | Invalid resolver `kind` value | Load-time error |
| 6 | Type mismatch: enum variable with non-member default | Load-time error |
| 7 | Missing `name` on variable | Load-time error |
| 8 | Invalid expression syntax in `evaluate_when` | Load-time error |
| 9 | Reference to undeclared variable | Load-time error |
| 10 | Reference to undeclared predicate | Load-time error |
| 11 | Empty YAML document | Load-time error (not crash) |
| 12 | Deeply nested tool params (100 levels) | Handles without stack overflow |

### 4.5 Expanded Adapter Scenarios (`tests/cases/adapter-scenarios.yaml`)

Expand from 4 to ~15 scenarios. New additions:

| # | Scenario | Tests |
|---|----------|-------|
| 5 | Multi-turn state ratcheting | Variable goes public→internal→protected across turns |
| 6 | Human resolver approve flow | Resolver fires, user approves, tool proceeds |
| 7 | Human resolver deny flow | Resolver fires, user denies, tool blocked |
| 8 | Concurrent tool calls | Two tools same turn: one blocked, one allowed |
| 9 | Monitor mode | Block logged but execution proceeds |
| 10 | MCP tool gating | MCP-registered tool blocked by policy |
| 11 | Post-tool validation (Stage 4) | Tool output scanned, PII in result triggers redact |
| 12 | Tool output triggers variable update | `populated_by: tool` sets variable from output |
| 13 | Wildcard + specific policy interaction | Specific policy overrides wildcard for named tool |
| 14 | Multiple guard_policies on same tool | All must pass (AND semantics) |
| 15 | on_block_policy: return_verdict | Returns verdict object instead of raising |

---

## 5. FFI Boundary Tests

**Not YAML-driven** — these are per-binding programmatic tests.

### 5.1 Test Matrix (PR Gate — lightweight)

| Category | Test | Expected |
|----------|------|----------|
| UTF-8 | Embedded NUL byte in tool name | Correct handling or defined error |
| UTF-8 | 4-byte emoji in variable value | Round-trips correctly |
| UTF-8 | Empty string | Not null, handled correctly |
| UTF-8 | 1 MB string payload | Correct verdict returned |
| Panic | Core panic → binding exception | No UB, catchable exception |
| Concurrency | 4 threads × 10K validate_tool_call | All verdicts correct, no corruption |
| Payload | 1 MB JSON tool_params | Correct verdict, no OOM |

### 5.2 Nightly Stress (deferred from PR gate)

- 16 threads × 1M iterations
- 50 MB payloads
- RSS leak detection over long runs

---

## 6. Verdict Dispatch Parity Expansion

Add to `tests/parity/verdict_dispatch_canonical.json`:

| # | New case | Tests |
|---|----------|-------|
| 1 | `warn` action in enforce mode | Proceeds with warning logged |
| 2 | `append` transform | Appended text in output |
| 3 | `prepend` transform | Prepended text in output |
| 4 | Monitor mode + block verdict | Proceeds (override_to_proceed: true) |
| 5 | `pending_resolution` shape | Correct wire format emitted |
| 6 | `redact` + custom redaction text | Substitution applied |
| 7 | `declassify_to` action | Proceeds with declassification |
| 8 | Multiple transforms (prepend + append) | Both applied in order |

---

## 7. Implementation Plan

### Execution Strategy: Parallel Agents (2 days)

**Batch 1** (Day 1, first 30 min): Schema foundation
- WI-1: Update `test-cases.schema.json`, define `result_schema.json`, backfill existing cases

**Batch 2** (Day 1, remainder — 7 parallel agents):
- WI-2: `fail-closed.cases.yaml` (15 cases)
- WI-3: Extend Rust harness for JSON output
- WI-4: Python harness JSON output mode
- WI-5: Node harness JSON output mode
- WI-6: .NET harness JSON output mode
- WI-7: `malformed-config.cases.yaml` (12 cases)
- WI-8: `extends-merge.cases.yaml` (12 cases)

**Batch 3** (Day 2 — 7 parallel agents):
- WI-9: `resolver-flows.cases.yaml` (12 cases)
- WI-10: Verdict dispatch parity expansion (8 entries)
- WI-11: FFI boundary tests — Python
- WI-12: FFI boundary tests — Node
- WI-13: FFI boundary tests — .NET
- WI-14: `run_parity.py` + `.github/workflows/cross-sdk-parity.yml`
- WI-15: Expand `adapter-scenarios.yaml` (15 scenarios)

### PR Strategy

| PR | Contents | Reviewers |
|----|----------|-----------|
| PR 1 | Schema, all new test suites & fixtures, verdict dispatch cases, design doc | Core team |
| PR 2 | SDK harness JSON emission (all 4 SDKs) + FFI boundary tests (Python/Node/.NET) | Per-SDK owners |
| PR 3 | Parity orchestrator (`run_parity.py`) + CI workflow | DevOps / core team |

PR 2 can land independently of PR 1 (harness changes are self-contained). PR 3 depends on both PR 1 (cases to run) and PR 2 (JSON output to consume).

---

## 8. Risks & Mitigations

| Risk | Impact | Mitigation |
|------|--------|------------|
| Existing cases fail when backfilled as `required` | Day-1 CI red | Use `xfail` with linked issues for known gaps; fix forward |
| Harness JSON output changes break existing test runs | Developer friction | JSON output is opt-in via env var (default: off) |
| Resolver mock protocol doesn't fit all SDKs | Blocked WI-9 | Design protocol in WI-1 (schema phase); get sign-off before cases are written |
| `unknown_action` reveals many missing verbs | Noisy parity results | Start parity gate in "warn" mode; promote to "block" after 1 sprint |
| FFI boundary tests flaky on shared CI runners | False failures | PR gate uses conservative thresholds (4 threads, 10K iter); heavy tests nightly only |

---

## 9. Success Metrics

| Metric | Current | Target |
|--------|---------|--------|
| Shared behavioral test cases | ~60 | ~150 |
| SDKs consuming shared cases | 4 (but unverified parity) | 4 with enforced parity |
| Security invariant cases | 0 | 15 |
| FFI boundary test coverage | 0 bindings | 3 bindings |
| Cross-SDK parity CI gate | None | Active (capability-aware) |
| Verdict dispatch parity entries | ~8 | ~16 |
| Adapter scenarios | 4 | 15 |

---

## 10. Open Questions for Team Review

1. **Parity gate rollout**: Start in "warn" mode (report-only) or "block" mode immediately?
2. **Resolver mock protocol**: Should mock definitions live inside case YAML or in separate fixture files?
3. **xfail expiry policy**: Should xfail entries auto-expire after N days without resolution?
4. **PR granularity**: Consolidated to 3 PRs — foundation (cases/fixtures), SDK harness+FFI, and orchestrator+CI.
5. **Drift catalog policy**: Who can bless new drift? Require linked RFC/issue?

---

## Appendix A: Deferred Work (Post-MVP)

- Events & Lifetimes suite (needs `Clock` trait + `test-clock` feature in Rust core)
- Streaming validation (needs spec clarification on chunk-level vs buffer semantics)
- Node/.NET E2E adapter runners with frozen replay (`nock`/`WireMock.NET`)
- Performance benchmarks (`criterion` + per-binding micro-benchmarks)
- Telemetry parity (span names, log shapes across SDKs)
- Coverage measurement floors (`cargo-llvm-cov`, coverage.py, c8, coverlet)
- Nightly FFI stress tests (16-thread, 1M-iter, 50MB)
- Concurrency stress tests per SDK

## Appendix B: Relevant Existing Files

| File | Role |
|------|------|
| `tests/cases/test-cases.schema.json` | Schema for .cases.yaml |
| `tests/cases/*.cases.yaml` | Existing 7 test suites (~60 cases) |
| `tests/fixtures/` | Shared guardrails YAML fixtures |
| `sdk/rust/agent_shield_core/tests/integration_cases.rs` | Rust harness (already exists) |
| `sdk/python/tests/test_integration_cases.py` | Python harness |
| `sdk/node/__tests__/integration_cases.test.mjs` | Node harness |
| `sdk/dotnet/tests/AgentShield.Tests/IntegrationCaseTests.cs` | .NET harness |
| `tests/parity/verdict_dispatch_canonical.json` | Verdict dispatch parity fixture |
| `tests/parity/generate_drift_catalog.py` | Drift catalog generator (orchestrator precedent) |
| `tests/parity/drift-catalog.json` | Current drift state (11 medium, 23 low) |
