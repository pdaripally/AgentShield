# `agent-shield init` — design a `.guardrails.yaml` with an LLM

`agent-shield init` is an **agentic** CLI that authors a working
`.guardrails.yaml` for your specific agent. It primes a frontier LLM
(OpenAI or Anthropic) with the AgentShield v2 spec, the JSON schema,
two curated example configs, and your tool definitions — then runs a
conversational design loop:

- The model **asks clarifying questions** ("Is `refund_order`
  destructive?", "What sensitivity does `get_customer` return?").
- It **proposes config increments**, each validated through the same
  Rust loader that compiles your policy at runtime.
- On a validation error, it **self-corrects** (up to 3 attempts) before
  asking you for help.
- When the config is complete, it writes a schema-valid file you can
  ship — not a template stub.

This is a tool, not a runtime hot path. It runs locally (no
guardrails enforcement involved), takes ~30 seconds to a couple of
minutes depending on how much you push back on its proposals, and
costs roughly a few cents per design session at current model prices.

## Install

The CLI ships as a separate Python package, `agent-shield-cli`,
that depends on the runtime SDK for validation.

> **Source install (works today).** `pip install "agent-shield-cli[openai]"`
> 404s against PyPI — neither the runtime SDK nor the CLI are published
> on a public registry yet. Install from this repo until then. Like the
> runtime SDK, the CLI's transitive `agent-shield` dependency is a
> maturin-built native extension, so a **Rust toolchain** (`rustc` /
> `cargo` 1.78+, install via [rustup](https://rustup.rs/)) is required.

```bash
git clone https://github.com/microsoft/AgentShield.git
cd AgentShield

pip install -e "cli[openai]"      # for --provider openai or azure
pip install -e "cli[anthropic]"   # for --provider anthropic
```

The `-e cli[<extra>]` invocation also pulls `agent-shield` from
`sdk/python` transitively, so a single command gets you the
validator-gated CLI ready to run.

<details>
<summary><strong>When public packages ship</strong> (not yet runnable — these commands 404 today)</summary>

```bash
pip install "agent-shield-cli[openai]"     # for --provider openai or azure
pip install "agent-shield-cli[anthropic]"  # for --provider anthropic
```

</details>

Set your provider key:

```bash
export OPENAI_API_KEY=sk-...
# or
export ANTHROPIC_API_KEY=sk-ant-...
# or (Azure OpenAI)
export AZURE_OPENAI_API_KEY=...
export AZURE_OPENAI_ENDPOINT=https://<resource>.openai.azure.com/
export AZURE_OPENAI_API_VERSION=2024-12-01-preview   # optional, this is the default
```

## TL;DR

```bash
agent-shield init \
  --openai-tools tools.json \
  --describe "Customer support bot. Handles refunds up to \$500, account lookups, email replies." \
  --provider openai \
  --model gpt-5
```

The CLI loads your tools, builds a prompt that embeds the full
v2 spec, and runs the design loop in your terminal. Every proposal
goes through the Rust loader before it can be accepted; invalid YAML
never reaches disk.

## Flags

| Flag | Notes |
|---|---|
| `--output` / `-o` | Output path (default: `./.guardrails.yaml`). |
| `--describe` | 1-2 sentence agent role. Heavily primes the LLM. |
| `--mcp PATH` | MCP `tools/list` JSON or allowlist YAML. Repeatable. |
| `--openai-tools PATH` | OpenAI function-call JSON. |
| `--anthropic-tools PATH` | Anthropic tool JSON. |
| `--from PATH` | Extend an existing file via `extends:`. Parent is preserved byte-for-byte. |
| `--provider {openai,anthropic,azure}` | Or set `AGENT_SHIELD_PROVIDER`. |
| `--model NAME` | Or set `AGENT_SHIELD_MODEL`. Provider-specific (e.g. `gpt-5`, `claude-opus-4`, or your Azure deployment name). |
| `--api-key` | Override env keys. |
| `--env-file PATH` | Path to a `.env` file with provider credentials (`AZURE_OPENAI_*`, `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, and — for AACS Stage 1 — **both** `AZURE_CONTENT_SAFETY_ENDPOINT` and `AZURE_CONTENT_SAFETY_KEY`). Default search: `./.env`, then `<git-root>/.env`; the first that exists wins. Pre-set environment variables always win — the file never overwrites them. Missing files at the default paths are silently skipped; passing an explicit `--env-file` that does not exist is an error. |
| `--non-interactive` | One-shot mode. Requires `--describe`. The model gets no follow-up questions; it must produce a complete config from the initial prompt. |
| `--max-turns` | Hard cap on assistant turns (default 30). |
| `--force` | Overwrite output if it exists. |
| `--dry-run` | Print final YAML to stdout instead of writing. |

## What a session looks like

```text
$ agent-shield init \
    --openai-tools tools.json \
    --describe "Customer support bot. Handles refunds up to \$500, account lookups, email replies." \
    --provider openai --model gpt-5

agent-shield init — openai / gpt-5
  tools: 4 | parent: (none) | output: .guardrails.yaml

— Drafting starter metadata + objective + resources.
\`\`\`yaml
metadata:
  name: ecommerce-support-bot
  ...
\`\`\`
[a]ccept / [r]efine / [s]kip > a

? Refunds above $500 — should the agent be allowed at all, or always require a
  manager approval?
> always require approval

? Does `get_customer` return any sensitivity classifier we can pipe into a
  variable, or is the whole profile uniformly sensitive?
> uniformly customer-PII

— Adding manager_approval resolver + refund_amount variable + Stage-2 gate.
\`\`\`yaml
variables:
  - name: refund_amount
    type: number
    populated_by:
      - kind: tool
        name: refund_order
        expression: "@result.amount"
  - name: manager_approval
    type: boolean
    on_demand_by:
      kind: human
      prompt: "Approve refund over $500?"
    lifetime: per_call
predicates:
  needs_manager_review: "refund_amount > 500"
state_validation:
  guard_policies:
    - name: refund_threshold_gate
      applies_to: { tools: [refund_order] }
      evaluate_when:
        - expression: "not needs_manager_review or manager_approval == true"
          reason: "Refund > $500 requires manager approval."
\`\`\`
[a]ccept / [r]efine / [s]kip > a

... (continues for Stage-1 jailbreak, Stage-4 PII redaction, Stage-5
output redaction, with the model asking what data classes appear) ...

✔ wrote .guardrails.yaml (8 turn(s))
  Next: review the inline comments, refine objective.forbidden for your
  specific risks, and run your test suite against the new file.
```

You walk away with a config that looks like the hand-written examples
in [`examples/`](../../examples/) — variables that mean something for
your domain, gates that block real risks, an objective that names
your agent's actual scope. Not a stub.

## How the validation gate works

Every `propose` and the final `done` payload is loaded through the
exact same Rust validator that compiles your policy at runtime:

```python
GuardrailsConfig.from_dict(model_output).compile()._native_handle
```

If the loader rejects it (e.g. unknown top-level key, Stage-2 policy
missing `applies_to:`, expression references an undeclared variable),
the error is fed back to the LLM as a `validation_error` message and
it gets up to 3 self-correct retries on that proposal. If it can't
recover, you're asked whether to refine or abort. **An invalid file
never reaches disk.**

This is the same gate the runtime uses — if `init`'s output validates,
your runtime will load it.

## Layering on top of an existing config (`--from`)

```bash
agent-shield init \
  --from .guardrails.yaml \
  --output .guardrails.child.yaml \
  --mcp new-mcp-server-tools.json \
  --describe "Adding a new vendor MCP server with 6 tools." \
  --provider openai --model gpt-5
```

The output starts with `extends: [".guardrails.yaml"]`, adds only new
tools, and only emits policies that don't conflict with the parent.
The parent file is **never** modified — your hand-edits are safe.

The CLI refuses to run when `--from` and `--output` resolve to the
same path (would create an `extends:` self-cycle per
[spec §3.2](../../spec/SPECIFICATION.md#32-composability)).

## Non-interactive mode (CI-friendly)

For build pipelines:

```bash
agent-shield init \
  --non-interactive \
  --describe "Banking back-office bot — read accounts, prepare transfers up to \$10k, no autonomous send." \
  --openai-tools tools.json \
  --provider openai --model gpt-5 \
  -o .guardrails.yaml
```

In non-interactive mode the LLM is told it has one shot — no
follow-up questions allowed. The output is still validated (same
gate) and the run still aborts non-zero on failure.

## What the CLI does **not** do

- It does not enforce your guardrails — that's the runtime SDK.
- It does not edit your existing file in place (use `--from`).
- It does not autotune classifier thresholds — emits sensible
  defaults from the spec for the user to refine.
- It does not wire LLM credentials into the generated
  `configurations[]` blocks — the model emits `${env.YOUR_KEY}`
  placeholders for you to fill in.

## Troubleshooting

- **`the openai package is required`** — install the OpenAI extra: `pip install -e cli[openai]` from this repo (or `pip install agent-shield-cli[openai]` once the CLI is on PyPI — not live today).
- **`no API key found`** — set `OPENAI_API_KEY` / `ANTHROPIC_API_KEY` / `AZURE_OPENAI_API_KEY` or pass `--api-key`. A project-local `.env` is auto-discovered (`./.env` → `<git-root>/.env`); use `--env-file PATH` to point at a different file.
- **`Could not locate the AgentShield spec files`** — the installation may be corrupted; reinstall from the repo with `pip install --force-reinstall -e 'cli[openai]'` (or, once published, `pip install --force-reinstall 'agent-shield-cli[openai]'`).
- **`post-write validation failed`** — the LLM produced YAML that passed in-memory validation but failed when loaded from disk (typically an extends-chain mismatch). Re-run with `--max-turns` set higher or with a tighter `--describe`.

## Maintainer note: how the bundled spec works

`agent-shield init` needs the v2 spec, JSON schema, and
expression-language reference in its system prompt. To avoid the
CLI breaking on wheel installs (where the repo isn't on disk) AND
to avoid checking the spec into two places, the CLI uses a build
hook to materialise the spec into the package at install time.

The hook lives at `cli/_build_backend.py`. When `pip install ./cli`
runs, the hook reads `<repo>/spec/SPECIFICATION.md`, the JSON
schema, and `expressions/LANGUAGE.md` from the repo root and
copies them into `cli/agent_shield_cli/init/_data/spec/`. That
directory is git-ignored — the materialised copy never lives in
git.

At runtime `_context.py::_get_spec_root()` reads the bundle via
`importlib.resources.files('agent_shield_cli.init._data')`, with a
fallback walk-up to the canonical `<repo>/spec/` for editable /
source-tree usage.

No manual sync step is needed. Edit `<repo>/spec/` and reinstall
the CLI; the bundled copy refreshes automatically.

For release builds where pip only sees the sdist (no repo around
it), the release pipeline can stage canonical copies into
`cli/_canonical_spec/` before invoking the build; the hook checks
that location as a fallback.

House-style patterns and the minimal valid skeleton are written
inline in `cli/agent_shield_cli/init/_context.py` as a Python
string, so no example configs are bundled.
