# Information Flow Control: Design

The companion document `information-flow-control-proof.md` states
what is guaranteed. This document states how it is configured.

## 1. Overview

Agent Shield supports Information Flow Control (IFC): a runtime
mechanism that tracks how data moves between tools and refuses to
admit egress from a session whose accumulated exposure exceeds the
target sink's clearance. The mechanism complements the declarative
guard-policy system with a mathematically provable security
guarantee against the data-exfiltration attack class (§3).

When configured, the runtime maintains a single running exposure
per session as a label-typed variable, raises it on every recorded
read of a tagged source, and denies any egress to a sink whose
declared clearance is incompatible with the current exposure. The
protection is systematic: authors do not write per-pair deny
rules. It falls out of the declared variable populators and the
`allowed_when:` clauses on regulated sinks.

IFC is opt-in at the configuration level. To enable it, declare a
`type: compartment` variable with an optional `vocabulary:` field
(Specification §10.1), pair it with `populated_by:` entries on
every tagged source (§10.5), and write `allowed_when:` clauses
using the array subset operator (LANGUAGE.md §3.7) on every
regulated sink. The specification and the expression-language
reference are the normative sources for the surface syntax; this
document states how those primitives compose into a sound IFC
realisation.

## 2. Table of Contents

1. Overview
2. Table of Contents
3. Threat Model
4. The Primitive
5. Why this primitive
6. Mathematical equivalence
7. Audience and clearance: two separate variables
8. Independent compartments
9. Hierarchies as derived shapes
10. YAML conventions
11. Implementation
    - 11a. Why label-typed variables reject resolvers
12. Defaults
13. Host capabilities
14. Closed tag universe and load-time validation
15. Composability
16. Stage hooks
17. Declassification
18. Worked example
19. Out of scope
20. Honest scope
21. References

## 3. Threat Model

IFC defends against the class of attacks in which data from a
trusted, sensitive, or restricted source flows through the agent
to an unauthorized destination. Examples:

- An untrusted email contains a prompt injection that causes the
  agent to leak the user's contacts via a malicious URL in a Teams
  message.
- A coding agent reads a private GitHub repository, then is
  tricked into posting the contents as a comment on a public
  issue.
- A document agent reads a confidential customer record, then is
  asked to summarize it via an external API call that logs the
  input.
- A bank-assistant agent reads a customer's account balance and
  is induced to send it to an attacker-controlled email address.

Pattern matching, classifiers, and LLM-based validators catch
many of these heuristically. A sufficiently novel rephrasing
evades them. IFC catches them deterministically by tracking what
kinds of data have been read and refusing to write to incompatible
destinations. The protection is enforced by the runtime at every
gated boundary. The author does not need to predict every
(sensitive_source, leaky_sink) pair.

The accompanying proof states this guarantee formally as
coarse-grained noninterference (CGNI) under an explicit-flow
attacker model. See the proof's §3 for the property and §4.6 for
the ten side conditions (TC-1 through TC-10) on which the
guarantee depends.

## 4. The Primitive

A closed tag universe `T` declared once at config-load time. Three
policy functions over tag sets:

- `λ : Source → 2^T`. The tags carried by data returned from a
  source. Realised by `populated_by:` entries on a `type:
  compartment` variable (Specification §10.5).
- `μ : Sink → 2^T`. The tags a sink will accept in its arguments.
  Realised by an `allowed_when:` clause on a guard policy whose
  right-hand side is a literal tag array (LANGUAGE.md §3.7).
- `ν : Sink → 2^T`. The clearance an observer must hold to see the
  sink's effects (distinct from `μ`; see §7). Read directionally:
  `ν = ∅` means no clearance required (publicly observable).
  `ν = T` means top clearance required (fully restricted).
  External email is `ν = ∅`. An internal-only audit log is
  `ν = T`. Realised by a second `type: compartment` variable
  populated identically and gated by its own guard policy.

The runtime keeps one running exposure per scope: a tag set that
grows by union and is checked by subset. The lattice operations
are implemented by the variable runtime. The type-locked
set-union join on `populated_by:` writes (Specification §10.5.5)
IS `⊔`. The array subset operator on `allowed_when:` clauses
(LANGUAGE.md §3.7) IS `⊑`. Both operations are
O(|`vocabulary:`|) when a compartment vocabulary is declared.

```yaml
variables:
  - name: exposure
    type: compartment
    vocabulary: [pii, financial, source_code, internal]
    default: []
    lifetime: per_session
    populated_by:
      - kind: tool
        name: read_customer_balance
        phase: after
        value: [pii, financial]
      - kind: tool
        name: read_repo_source
        phase: after
        value: [source_code, internal]

tool_execution_validation:
  guard_policies:
    - name: enforce_egress_clearance
      applies_to:
        tools: [write_audit_log, send_email_external]
      evaluate_when:
        - expression: "@tool.name == 'write_audit_log' and not (exposure <= ['pii', 'financial', 'source_code', 'internal'])"
          reason: "Audit log clearance does not admit current exposure."
        - expression: "@tool.name == 'send_email_external' and not (exposure <= [])"
          reason: "External email cannot carry tagged data."

output_validation:
  guard_policies:
    - name: enforce_user_output_clearance
      evaluate_when:
        - expression: "not (exposure <= [])"
          reason: "User output channel admits only public data."
```

A companion `type: compartment` variable for audience tracking
(§7) and a chain-typed variable using `type: level` (§9) are
the two remaining shapes the surface admits. Every IFC
configuration is some combination of these three pieces:
`type: compartment` for set lattices, `type: level` for chain
quotients, and `allowed_when:` clauses for the egress gates.

The trace from the worked example reproduces directly from the
variable runtime:

```
read(read_customer_balance)
  ⇒ populated_by writes [pii, financial] to exposure via
    the type-locked set-union join (Specification §10.5.5)
  ⇒ exposure = {pii, financial}
egress(write_audit_log)
  ⇒ allowed_when: exposure <= ['pii','financial','source_code','internal']
  ⇒ {pii, financial} ⊆ {pii, financial, source_code, internal}   ✓ admitted
egress(send_email_external)
  ⇒ allowed_when: exposure <= []
  ⇒ {pii, financial} ⊆ ∅                                          ✗ denied
```

**Stage choice.** The example above places the egress gates in
`tool_execution_validation:` (Stage 3). The same deterministic
subset check is equally at home in `state_validation:` (Stage
2) — the spec's expression-only deterministic stage; both
stages are pre-call and satisfy TC-2 (complete mediation).
Choose Stage 2 when the gate is purely deterministic and you
want the cheapest path; choose Stage 3 when the same policy
block also carries LLM- or classifier-based detection that
should sit beside the subset check. Stage 5
(`output_validation`) is the user-channel egress — the gate
that blocks the agent's response when the running exposure is
non-empty — and is written directly under `output_validation:`;
the `strict_resource_coverage:` mechanism (Specification §10.1,
§12.13) does not cover Stage 5 because Stage 5 has no resource
catalog to iterate. The `strict_resource_coverage:` mechanism
requires the deployment to enumerate which **pre-call** stages
MUST carry the per-resource egress gate; there is no default.
See `information-flow-control-proof.md` TC-7 and §11b below for
the soundness rules on the stage set.

## 4a. Use-case patterns

The minimal example in §4 uses only static `value:` populators
for exposition. The variable surface is deliberately wider than
that: a single label-typed variable can declare many populator
entries with mixed value-derivation strategies, all joining
into the same running exposure under the type-locked
set-union. This subsection walks three patterns that the
static-only example does not show but are the common shape of
production IFC configurations. The formal counterpart — the
per-call witnessing function `ω_s(v)` — is in the proof's
§2.2.1.

### Use case A: Dynamic per-call labels (`@result.*`)

When a tool returns its own classification alongside the
content, populate with `expression:` against the result
envelope instead of `value:`. The runtime writes whatever
the expression evaluates to; missing fields escalate to the
lattice top (`⊤`) and out-of-vocabulary tags are dropped with
a warning, both per Specification §10.5.4 / §10.5.5.

```yaml
variables:
  - name: exposure
    type: compartment
    vocabulary: [pii, financial, source_code, internal]
    default: []
    strict_resource_coverage:
      mode: error
      stages: [tool_execution_validation]
    populated_by:
      - kind: tool
        name: read_document
        phase: after
        expression: "@result.sensitivity_tags"
```

Behaviour on different return shapes (assuming the tool's
result schema declares `sensitivity_tags: array[string]`):

| Tool returns | Joined into `exposure` | Event emitted |
|---|---|---|
| `{ content: "...", sensitivity_tags: ["pii", "internal"] }` | `{pii, internal}` | `variable.exposure.changed` |
| `{ content: "...", sensitivity_tags: [] }` | `∅` (no-op widening) | `variable.exposure.changed` |
| `{ content: "...", sensitivity_tags: ["pii", "super_secret"] }` (one tag out of vocabulary) | `{pii}` (in-vocab subset retained; `"super_secret"` dropped) | `variable.exposure.vocabulary_violation` (severity `warn`) |
| `{ content: "..." }` (field missing) | full vocabulary `{pii, financial, source_code, internal}` (lattice top) | `variable.exposure.populator_null` (severity `warn`) |
| `{ content: "...", sensitivity_tags: null }` | full vocabulary (lattice top) | `variable.exposure.populator_null` |

The fail-closed escalations defend against missing or broken
classification metadata. They do NOT defend against a tool
that returns a *valid but incorrect* tag set — the tool's
correctness in self-classifying its output is a TCB obligation
for the source. Authors who do not fully trust a tool to label
its own output correctly SHOULD combine the dynamic populator
with a conservative static populator (see Use case B).

### Use case B: Many tools, one label, mixed strategies

A single label-typed variable is expected to declare many
populator entries spanning many sources. Each entry whose
selector matches the current call fires independently; the
writes compose under set-union; the running label widens
monotonically across the session.

```yaml
variables:
  - name: exposure
    type: compartment
    vocabulary: [pii, financial, source_code, internal]
    default: []
    strict_resource_coverage:
      mode: error
      stages: [tool_execution_validation]
    populated_by:
      # Static minimum on a well-known sensitive tool.
      - kind: tool
        name: read_customer_balance
        phase: after
        value: [pii, financial]

      # Dynamic refinement on a tool that classifies its own output.
      - kind: tool
        name: read_document
        phase: after
        expression: "@result.sensitivity_tags"

      # Fan-out conservative floor across a glob of related tools.
      - kind: tool
        name:
          include: ["fetch_partner_*"]
          exclude: ["fetch_partner_public_directory"]
        phase: after
        value: [internal]

      # Belt-and-braces: a static floor on the same tool covered
      # dynamically above. Both populators fire on every successful
      # call; the join takes the worst case.
      - kind: tool
        name: read_document
        phase: after
        value: [internal]
```

Properties of this shape:

- **Multiple populators on the same source compose, not
  override.** The two `read_document` entries both fire on each
  successful call; the runtime writes the join of the dynamic
  result and the static floor. If `@result.sensitivity_tags`
  evaluates to `["pii"]`, the joined write is `{pii,
  internal}` — the static `internal` floor cannot be suppressed
  by the tool's reported tag set.
- **The glob selector is one populator entry covering many
  sources.** `fetch_partner_*` (with `fetch_partner_public_directory`
  carved out) writes `[internal]` for every matching tool. A
  later, narrower populator on a specific `fetch_partner_*`
  tool stacks additively (both fire, results join).
- **Static and dynamic forms coexist in one variable.** There
  is no separate "static-label variable" and "dynamic-label
  variable" concept; one `type: compartment` variable
  accommodates every population strategy.
- **Coverage check applies to the variable, not per
  populator.** When `strict_resource_coverage:` declares
  `mode: error` and a pre-call `stages:` set (Specification
  §12.13), the loader checks that every catalogued resource is
  covered by *some* guard policy at one of those stages
  referencing `exposure`. Which populator entries write to
  `exposure` is orthogonal to whether the egress side of the
  IFC story is complete.

### Use case C: Delegated classification (MCP1 reads, MCP2 classifies)

When the classification lives in a different tool than the
data read — for example, an MCP server `mcp1` that reads
documents and a separate MCP server `mcp2` whose job is to
classify what was read — there is no special "delegation"
mechanism. The agent's workflow calls both tools; each tool
has its own populator entry; the running label is the join of
what both calls contributed. See `docs/ifc-design-rationale.md`
§7 for the design rationale.

```yaml
variables:
  - name: exposure
    type: compartment
    vocabulary: [public, internal, confidential, restricted]
    default: []
    strict_resource_coverage:
      mode: error
      stages: [tool_execution_validation]
    populated_by:
      # MCP1 returns the document; we don't trust the source
      # to classify itself, so write a conservative pre-classification.
      - kind: tool
        name: mcp1.read_document
        phase: after
        value: [internal]

      # MCP2 reads the same document (passed by the agent) and
      # returns a precise classification. Its populator pulls
      # the classification from @result.
      - kind: tool
        name: mcp2.classify_document
        phase: after
        expression: "@result.classification_tags"
```

The agent's workflow is a free composition:

1. Call `mcp1.read_document(uri=...)`. The populator joins
   `{internal}` into `exposure`. Running exposure now
   `⊇ {internal}`.
2. Call `mcp2.classify_document(content=...)` with the
   content from step 1. The populator joins MCP2's reported
   classification (e.g., `{confidential}`) into `exposure`.
   Running exposure now `⊇ {internal, confidential}`.
3. Any subsequent egress is gated against the joined
   exposure. The classifier's verdict raises the floor; it
   cannot lower the floor MCP1 already established.

If the agent skips step 2 and goes straight to egress, the
running exposure is still `{internal}` from step 1, so the
conservative floor remains. If the agent calls MCP2 multiple
times against different documents within the same session,
each call's classification joins independently; the lattice
algebra is the contract, and the agent cannot "undo" a prior
classification by calling MCP2 again with different inputs.

## 5. Why this primitive

The project owner's algebraic argument: the map from read-sequences
to `L` is a monoid homomorphism that factors through the
commutative-idempotent quotient. The free commutative-idempotent
monoid on a generating set `T` is `(2^T, ∪, ∅)`. This is the most
expressive carrier compatible with commutative-idempotent reads.

The algebra does not force the powerset choice. Any chosen
join-semilattice is a quotient (homomorphic image) of `2^T`. The
claim is that picking anything narrower (a linear chain, a custom
poset) gives strictly less expressiveness, and is recoverable as
a quotient if needed (§9).

A linear chain like `[public, internal, secret]` with rank
arithmetic is such a quotient: it embeds tag sets as ranks but
cannot represent incomparable tag pairs. PII and source-code are
independent dimensions. Forcing them onto a total order
(`pii < source_code` or `source_code < pii`) is a fake ordering
authors will get wrong.

## 6. Mathematical equivalence

The structure `(2^T, ⊆, ∪, ∅, T)` is a complete distributive
lattice and in particular a bounded join-semilattice. The proof
obligations from the companion document are stated against an
arbitrary join-semilattice `L` and instantiated here at `L = 2^T`.
The proof is directly applicable. Nothing in it depends on `L`
being a chain.

| Operation | Lattice | Variable surface |
|-----------|---------|------------------|
| order     | `ℓ₁ ⊑ ℓ₂` | `ℓ₁ <= ℓ₂` (LANGUAGE.md §3.7 array subset operator) |
| join      | `ℓ₁ ⊔ ℓ₂` | `populated_by:` write applied via type-locked set-union (Specification §10.5.5) |
| bottom    | `⊥`     | `default: []` on the `type: compartment` variable |
| top       | `⊤`     | the literal `vocabulary:` array as the RHS of an `allowed_when:` subset check |

Every theorem in the proof transfers. The symbols `⊑`, `⊔`, `⊥`,
`⊤` are mechanical aliases for `⊆`, `∪`, `∅`, `T`.

## 7. Audience and clearance: two separate variables

A sink (or a source: every resource is potentially both) has two
orthogonal properties that authors often conflate.

- `μ(k)`: what data `k` will accept in its arguments.
- `ν(k)`: who can see `k`'s effects (and, for sources, who can see
  the return value).

External email is the canonical example. A deployment may decide
email internals are tagged-data-aware and accept `[pii, financial]`
(`μ = {pii, financial}`), but the email itself, once sent, is
visible to anyone reading it (`ν = ∅`). A sink that accepts high
data but broadcasts to a low audience is exactly the leak the
lattice prevents.

Under the variable surface both `μ` and `ν` are realised by
separate `type: compartment` variables and separate guard
policies. A common pattern is to name them `exposure_clearance`
and `exposure_audience`, populate them by the same resources, and
co-locate their populators and guard policies for review.

The two compatibility checks the proof requires (TC-8 and TC-9)
become deployment obligations under this surface:

1. `μ(k) ⊆ ν(k)`. A sink cannot accept data tagged at a level
   its audience is not cleared to see. The author must write the
   `allowed_when:` clause for the audience guard policy at least
   as strict as the clearance guard policy for the same sink.
2. `λ(s) ⊆ ν(s)`. A source cannot return data (or have observable
   side-effects) tagged at a level its audience is not cleared to
   see. The author must populate the audience variable at least
   as strictly as the exposure variable for the same source.

A load-time linter that extracts subset literals from
`allowed_when:` expressions and verifies these inequalities is
desirable future work; the present runtime relies on author
discipline. The proof transfers under TC-8 and TC-9 only when the
discipline holds.

Where no audience guard policy is declared, no audience check
fires and the runtime treats the sink as universally observable
(`ν = ∅`, the most conservative default for confidentiality).
Most regulated resources will need both an exposure populator
and an audience populator.

The user output channel is hard-coded to `ν(user_output) = ∅`:
the user is the most permissive audience for confidentiality
purposes.

The security guarantees treat the LLM and every tool as a fixed
nondeterministic transducer for the duration of the analysis (proof
TC-10). Real deployments using a remote LLM with continuous model
updates do not satisfy this strictly. The property holds at any
given moment of fixed model state. Deployments requiring the formal
guarantee against drift must pin model versions.

## 8. Independent compartments

`pii` and `source_code` are unrelated tags. Reading a `[pii]`-tagged
source raises exposure to `{pii}`, which is properly incomparable
to a `[source_code]`-cleared sink: `{pii} ⊆ {source_code}` is
false, and `{source_code} ⊆ {pii}` is also false. A linear chain
cannot express this without falsely ordering one above the other.

### Worked example A: diagonal flow

```
populated_by(read_customer_balance) writes [pii, financial]
  ⇒  exposure = {pii, financial}
allowed_when on write_audit_log:
  exposure <= [pii, financial, source_code, internal]
  ⇒  {pii, financial} ⊆ {pii, financial, source_code, internal}   ✓ admitted
allowed_when on send_email_external:
  exposure <= []
  ⇒  {pii, financial} ⊆ ∅                                          ✗ denied
```

### Worked example B: incomparable sinks

```
populated_by(read_repo_source) writes [source_code, internal]
  ⇒  exposure = {source_code, internal}
allowed_when on send_to_pii_compliant_archiver:
  exposure <= [pii, financial]
  ⇒  {source_code, internal} ⊆ {pii, financial}                    ✗ denied
```

The source-code is not PII-cleared. The lattice correctly rejects
because the tag sets are incomparable.

## 9. Hierarchies as derived shapes

A linear chain `[public, internal, secret]` is recovered by
declaring a `type: level` variable (Specification §10.1) whose
`members:` list enumerates the chain low → high. The type-locked
`max()` join applies on every `populated_by:` write, ensuring the
running level only ever rises.

```yaml
variables:
  - name: data_sensitivity
    type: level
    members: [public, internal, secret]   # low → high
    default: public
    lifetime: per_session
    populated_by:
      - kind: tool
        name: t_internal
        phase: after
        value: internal
      - kind: tool
        name: t_secret
        phase: after
        value: secret

tool_execution_validation:
  guard_policies:
    - name: external_sink_clearance
      applies_to:
        tools: [external_sink]
      evaluate_when:
        - expression: "not (data_sensitivity <= 'public')"
          reason: "External sink admits only public data."

    - name: internal_sink_clearance
      applies_to:
        tools: [internal_sink]
      evaluate_when:
        - expression: "not (data_sensitivity <= 'internal')"
          reason: "Internal sink admits at most internal data."

    - name: secret_sink_clearance
      applies_to:
        tools: [secret_sink]
      evaluate_when:
        - expression: "not (data_sensitivity <= 'secret')"
          reason: "Secret sink admits at most secret data."
```

This recovers `public ⊑ internal ⊑ secret` exactly: under the
member-index comparison (LANGUAGE.md §3.4a) `public <= internal`
and `internal <= secret` both hold. Authors who want more
structured hierarchies declare additional `type: level` variables
for each independent chain.

`type: level` and `type: compartment` are deliberately not
interchangeable. Use `type: compartment` for truly incomparable
dimensions (§8); use `type: level` only when the algebra of the
deployment genuinely is a chain.

## 10. YAML conventions

The variable surface uses general-purpose primitives, not
IFC-specific shorthands. A few conventions are recommended:

- Name the running-exposure variable identifiably (e.g.,
  `exposure`, `confidentiality_exposure`, `data_exposure`) so that
  guard-policy `allowed_when:` clauses reading it are immediately
  legible to review.
- Declare an explicit `default:` matching the lattice bottom
  (`[]` for `type: compartment`, the lowest member for `type:
  level`). Omitting `default:` leaves the variable in the `unset`
  state; an `unset` variable evaluates to `null` in expressions,
  which renders `unset_var <= [...]` as `false` (LANGUAGE.md
  §3.7). The behaviour is fail-closed either way; declaring
  `default:` explicitly makes it fail-closed by design and gives
  reset-driven declassification a well-defined target value.
- An admit-all sink is expressible as `allowed_when: "exposure <= […full vocabulary…]"`.
  The literal vocabulary array on the right-hand side admits any
  subset of `T` and is the variable-surface equivalent of an
  unrestricted internal logging sink. Use sparingly; this is the
  configuration's most conspicuous trust-base widening, and the
  runtime does not provide a single-flag escape hatch for it.
- The surface does not accept forbidden-tag lists. Specifying
  sinks by what they reject fails open when a new tag is
  introduced and old sinks aren't updated to forbid it.
  Subset-against-allowed-list fails closed under the same drift:
  a sink that declares `allowed_when: "exposure <= ['pii']"`
  will reject any future `financial` tag without the author
  touching the file.

## 11. Implementation

The implementation is the standard label-typed-variable runtime
in `agent_shield_core`. Specification §10.5.5 mandates the
type-locked set-union join for `type: compartment` variables and
the type-locked `max()` join for `type: level` variables. The
array subset operator (LANGUAGE.md §3.7) is the primitive used
by `allowed_when:` clauses to enforce `⊆`.

A conformant implementation stores the compartment variable as a
sorted, deduplicated array of tag strings; when `vocabulary:` is declared and
small enough, the runtime MAY use a fixed-width bitset indexed by
vocabulary position as an internal representation. Both
representations satisfy the §10.5.5 contract; the proof's
invariant `I` (`information-flow-control-proof.md` §4.1) holds
under either, and the choice is implementation-internal.

The variable engine emits the audit events listed in
Specification §9.3 on every state transition:

| Event                                       | When                                                              | Severity   |
|---------------------------------------------|-------------------------------------------------------------------|------------|
| `variable.<name>.changed`                   | `populated_by:` write succeeds                                    | `info`     |
| `variable.<name>.declassified`              | Host calls `reset_variable()`, lifetime expiry (runtime `reset_by:` support deferred) | `critical` |
| `variable.<name>.populator_null`            | populator returns `null` (escalates to lattice top under §10.5.4) | `warn`     |
| `variable.<name>.vocabulary_violation`      | populator value names a tag outside `vocabulary:` (when declared) | `warn`     |
| `guard_policy.<name>.redacted`              | a clearance guard policy admitted egress after redaction          | `info`     |

The declassified event is the audit anchor for every IFC
declassification (§17), regardless of whether it fires from a
host capability call,
or a lifetime boundary.

### 11a. Why label-typed variables reject resolvers

Specification §11.5 forbids `on_demand_by:` and resolver
`set_variables:` writes on `type: level` and `type: compartment`
variables. The prohibition is enforced at config-load (load-time
error for the declarative forms) and at runtime (drop with audit
for the wire-envelope form). The rationale is **not** a
proof-soundness requirement — TC-1 is preserved under either
surface — but a deliberate separation of two concerns the spec
keeps apart by construction:

- **Populators record *exposure*.** They fire deterministically
  on every named tool / endpoint / agent invocation and write
  through the type-locked join. The exposure variable accumulates
  evidence of what data has flowed through the session. The
  agent does not choose whether the populator fires; the runtime
  fires it on every matching call.
- **Resolvers collect *authorization*.** They fire on demand when
  a gating expression reads a variable in `@status == 'unset'`,
  delegate the decision to a human / classifier / peer agent /
  expression / sub-agent, and write the result through
  last-write-wins `set_variables:` semantics. The resolver answers
  the question *"is this allowed?"*, not *"what flowed?"*

Merging these on a single variable creates several footguns the
spec eliminates by construction:

1. **Author confusion: "ask the user to label the document."** A
   plausible-looking YAML —

   ```yaml
   exposure:
     type: compartment
     vocabulary: [pii, financial, confidential]
     on_demand_by:
       kind: human
       prompt: "What sensitivity does this document contain?"
   ```

   — reads as "the runtime will ask the user to classify the
   document." In practice the user's answer becomes the
   *exposure*, replacing the empirical record of what data
   actually flowed through. A user who answers `[]` ("nothing
   sensitive") tells the IFC engine no labeled source has been
   read, regardless of what populators would have recorded. The
   exposure variable is no longer a faithful reflection of the
   session's information flow — it is a faithful reflection of
   the user's *belief about* the session's information flow,
   which is a fundamentally different (and weaker) guarantee.

2. **Dead-code surprise.** A label-typed variable with
   `default: []` (the recommended default per §12) is in
   `@status == 'resolved'` from the start. Auto-resolution per
   §11.5 only fires when `@status == 'unset'`. The resolver in
   the YAML above would *never fire* — but the author wouldn't
   know unless they read §11.5 closely. Forbidding the
   declaration makes the dead code impossible.

3. **Incoherent `decision: deny`.** A resolver may return
   `decision: deny`, transitioning the target variable to
   `denied` and freezing it for the rest of the lifetime. There
   is no coherent reading of "the exposure was denied" — labels
   accumulate; they do not authorize. The `denied` status is a
   resolver-surface concept that does not map onto IFC.

4. **Two divergent lifetime semantics.** Resolvers have their
   own `lifetime.allow:` semantics for caching a decision
   (§11.8). Labels have their own `lifetime:` semantics for
   bounding exposure accumulation (§10.7, §13). Conflating them
   on a single variable forces the author to pick one — and
   whichever they pick, the other's semantics silently does not
   apply.

5. **Authorization-on-release is the actual idiom.** The case
   that *looks* like "resolve a label" is almost always
   *"approve a release of accumulated label."* The spec
   directs that to a separate resolver-typed variable
   (`declassification_approval` or similar) whose `decision:
   allow` is consumed by a `reset_by:` entry on the label
   variable. The pattern is documented in §17 and exercised in
   the worked example of §18. It expresses authorization
   explicitly, leaves the audit trail (`variable.exposure
   .declassified`, severity `critical`) visible, and keeps the
   exposure variable populator-only.

The affordance the spec provides is a **normal path** for each
intent: populators for labeling, resolvers for authorization,
`reset_by:` for declassification once §10.6 is implemented. A configuration whose author
is tempted to write `on_demand_by:` on a label-typed variable is
a configuration that has confused one of those intents for
another. The load-time error surfaces the confusion before it
ever affects a session.

#### Hypothetical: what would relaxing the rule look like

For completeness, a relaxation amendment **would** look like the
following — and is the right text to point at when explaining
why the spec does not take this path:

> §10.1 — strike `on_demand_by:` from the prohibition list on
> `type: level` and `type: compartment`. Add: *"A resolver write
> on a label-typed variable (`value:` on auto-resolution or any
> `set_variables:` entry on `on_allow:` / the wire envelope)
> MUST be applied through the type-locked join (§10.5) at the
> write site — `max(@current, @incoming)` for level,
> `union(@current, @incoming)` for compartment — and CANNOT
> lower the stored label. A resolver returning `value: null`
> MUST be treated as the lattice top per §10.5.4. A resolver
> returning `decision: deny` or `decision: cancelled` MUST be a
> load-time error when the target is label-typed (since the
> `denied` state is incoherent on an accumulation variable)."*
>
> §11.5 — replace the "Label-typed variables reject resolvers
> outright" block with the join semantics above; preserve cycle
> detection and audit emission unchanged. Add a `variable.<name>
> .resolved` event emission in parallel with the existing
> `variable.<name>.changed` event so resolver-initiated label writes
> remain distinguishable in the audit log.

The relaxation is mechanically implementable, and TC-1 of the
formal proof would still hold (`λ` remains bound at config-merge
in both surfaces). The spec rejects it because the footgun
surface it opens — author intent mis-mapped onto exposure
tracking, plus dead-code resolvers behind `default:` — costs
more than the affordance is worth. Security in this project is
defended at the level of *what configurations the loader admits*,
not just at the level of what the runtime enforces; closing off
foot-gun configurations is part of the IFC contract.

### 11b. Choosing coverage stages

`strict_resource_coverage:` (Specification §10.1, §12.13) is
declared on the variable whose value must be covered by
resource-bound guard policies. There is no default — both
`mode:` and `stages:` are author-declared. For IFC the
recommended starting point is the pre-call pair:

```yaml
variables:
  - name: exposure
    type: compartment
    strict_resource_coverage:
      mode: error
      stages: [state_validation, tool_execution_validation]
```

This admits coverage at either pre-call stage and rejects any
configuration that catalogues a resource without a pre-call
gate referencing the exposure variable. Two variations are
worth knowing about:

- **Force Stage 3 specifically.** Deployments that mandate every
  egress gate also carry an LLM-monitored or classifier-monitored
  check beside the deterministic subset clause should set
  `stages: [tool_execution_validation]`. The loader then rejects
  a Stage-2-only gate referencing the exposure variable, forcing
  the author into a Stage-3 policy block that can host the
  additional detection arms.

- **Allow Stage 4 for read-only catalogs.** A RAG-style agent
  whose entire catalog is reads (no `send_*`, no `post_*`, no
  `write_*`) MAY include `post_tool_validation` in `stages:` to
  let Stage-4 redaction policies count as coverage. This is
  sound only because the relevant flow for a read-only catalog
  is data entering the agent's context, which Stage 4 can
  redact; for any catalog containing a write resource, Stage 4
  alone is too late and the proof's TC-7 reduces to author
  discipline. The spec does not enforce read-only-ness
  structurally (`permission:` is advisory, Specification
  §13.3); the author owns this invariant.

`input_validation` (Stage 1) and `output_validation` (Stage 5)
are rejected at config-load by the spec: Stage 1 fires before
any resource is bound, and Stage 5 gates the agent's per-turn
response text (not a catalogued invocation), so neither has a
per-resource coverage notion (Specification §10.1).

The Stage-5 user-channel egress clause shown in the worked
example of §4 is still required for the IFC story to hold — it
is just not enforced by `strict_resource_coverage:`. Authors
write it directly under `output_validation:` referencing the
exposure variable; TC-7 of the proof depends on its presence as
an authoring obligation, not a load-time check.

## 12. Defaults

| Field | Default | Rationale |
|-------|---------|-----------|
| compartment variable `vocabulary:` | optional | Declare it when the compartment must stay within a closed tag universe `T`; omit it for open vocabularies (Specification §10.1). |
| compartment variable `default:` | recommended `[]` | The exposure starts at `⊥`. Omitting leaves the variable `unset`; expressions evaluate `unset <= […]` as `false`, which is still fail-closed. |
| level variable `members:` | required | The chain must be enumerated low → high (Specification §10.1). |
| level variable `default:` | recommended first `members:` entry | The level starts at the lowest declared rank. |
| label-typed variable `lifetime:` | `per_session` | Only `per_session` is safe without host capability declaration; see §13. |
| guard policy on regulated sink | none implicit | A sink with no matching `allowed_when:` clause has no IFC gate at all; authors MUST write the clause explicitly for the proof to hold. |
| variable `update:` block | forbidden on label-typed variables | Specification §10.2 — guarantees `λ`, `μ`, `ν` immutability after config-merge. |
| populator `value:` outside `vocabulary:` | load-time error when a compartment vocabulary is declared | Specification §10.5.5 — no out-of-universe writes. |
| populator returning `null` | escalates running label to `T` (lattice top) | Specification §10.5.4 — fail-closed under populator failure. |
| resolver writes on label-typed variables (`on_demand_by:`, `set_variables:`) | rejected at config-load | Specification §11.5 — labels record exposure (populator-only); resolvers collect authorization (separate variable). Conflating the two on one variable opens the footguns enumerated in §11a. |

The discipline is fail-closed throughout. Authors who want an
unrestricted internal sink must write a syntactically conspicuous
`allowed_when:` clause that admits the entire vocabulary; the
runtime does not provide a single-flag escape hatch.

## 13. Host capabilities

Some lifetime choices depend on the host's actual capabilities,
which the runtime cannot verify directly. Hosts declare
capabilities at runtime build time.

| Capability | Required for | Semantics |
|------------|--------------|-----------|
| `supports_context_reset` | `lifetime: per_turn` or `lifetime: per_request` on a label-typed variable; `reset_by:` support is deferred; future mid-session label declassification | Host genuinely tears down the LLM context at the boundary (fresh chat-completion thread, clean message history derived only from low data). Hosts that retain memory across turns (LangChain memory, AutoGen group chats, conversation IDs that persist across the SDK boundary) MUST NOT set this. |

Configurations that require an unset capability are rejected at
config-load time with a precise error.

## 14. Closed tag universe and load-time validation

The `vocabulary:` field of a `type: compartment` variable, when declared (and the `members:` field of a `type: level` variable), is exhaustively enumerated at config-load time. Every compartment tag literal that appears in a `populated_by:` `value:` field or in the right-hand side of an `allowed_when:` array-subset expression must appear in the declared `vocabulary:` (Specification §10.5.5). Unknown literals are load-time errors with precise
paths. This eliminates an entire category of typo-driven
silent-IFC-bypass bugs.

A configuration that uses tag literals on the right-hand side of
an `allowed_when:` subset expression without declaring a
corresponding label-typed variable evaluates the literal as a
plain array (LANGUAGE.md §3.7); the subset check still runs,
but without a declared exposure variable no `λ`-driven
accumulation occurs, the proof's invariant `I` does not hold,
and the configuration provides no IFC guarantee. Authors who
intend IFC must declare the exposure variable.

## 15. Composability

In an `extends:` chain, label-typed variables follow the strict
no-redefinition rule (Specification §10.9): the `members:`/`vocabulary:`, `default:`, and `lifetime:` fields are immutable once declared. A child file that redeclares an inherited label-typed variable with a different `members:` (for `type: level`) or `vocabulary:` (for `type: compartment`) is rejected
at config-load time. This guarantees the trusted base for `λ`,
`μ`, and `ν` does not silently change between the base and the
leaf config (proof TC-1).

`populated_by:` entries on label-typed variables (`reset_by:` is deferred)
are additive across the chain (Specification §10.6): a child
file may add additional source-tagging entries to an inherited
exposure variable, and may add new guard policies that consume
the variable. Existing entries are not replaced.

Same-name guard policies merge additively under the standard
extends-chain rules (Specification §13). A child file may
tighten an inherited `allowed_when:` clause by adding additional
deny conditions; the AND-composition of `allowed_when:` clauses
across the chain is a tightening operation.

## 16. Stage hooks

| Stage         | Hook                                                                          | IFC effect                                                                                                                                                                  |
|---------------|-------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1. input      | `validate_input`                                                              | `populated_by:` entries with `kind: input` write to the exposure variable on admission                                                                                       |
| 2. state      | `validate_state`                                                              | `allowed_when:` clauses on state-validation guard policies may gate state transitions                                                                                        |
| 3. tool exec  | `validate_tool_call` / `validate_endpoint_call` / `validate_agent_call`       | `allowed_when:` clauses gating the sink check `exposure <= […]`; deny on subset failure                                                                                      |
| 4. post-tool  | `record_tool_success` / `record_endpoint_success` / `record_agent_success`    | `populated_by:` entries with `phase: after` fire on success; the type-locked union join writes `λ(target)` into the exposure variable                                        |
| 5. output     | `validate_output`                                                             | `allowed_when:` clauses on output-validation guard policies check the running exposure against the user's clearance (`∅` by default); deny on subset failure                 |

Plus scope-boundary resets (proof TC-3):

| Boundary | Behaviour |
|----------|-----------|
| `turn.end` (with `lifetime: per_turn` on the exposure variable, host advertises `supports_context_reset`) | exposure resets to `default:`; `variable.<name>.declassified` event emitted |
| `request.end` (with `lifetime: per_request`, host advertises `supports_context_reset`) | exposure resets to `default:`; `variable.<name>.declassified` event emitted |
| `session.end` (with `lifetime: per_session`, the default) | exposure resets to `default:`; `variable.<name>.declassified` event emitted |

`reset_by:` (§10.6) mid-scope declassification is not yet implemented in this runtime; see §17 for the deferred design intent.

## 17. Declassification

`reset_by:` on the exposure variable (Specification §10.6) is deferred to a follow-up runtime implementation. The intended design is to lower the running exposure on a named lifecycle event and emit `variable.<name>.declassified` (Specification §9.3, severity `critical`) with the variable identity and prior label:

> **Not yet implemented in this runtime:** `reset_by[]` / §10.6 declassification is deferred to a follow-up PR. The following block is conceptual and intentionally not runnable.
```yaml-deferred
variables:
  - name: exposure
    type: compartment
    vocabulary: [pii, financial, source_code, internal]
    default: []
    populated_by:
      - kind: tool
        name: read_customer_balance
        phase: after
        value: [pii, financial]
    reset_by:
      - kind: tool
        name: pii_summarizer             # designer-registered redaction tool
        phase: after
        reason: "Operator confirmed redacted summary; clearing exposure."
```

When §10.6 is implemented, the runtime should enforce:

1. The post-reset label is the variable's `default:`, which is
   `⊥` (or whatever the author declared) and therefore
   structurally `⊆ E` at the moment of invocation; the proof's
   `ℓ′ ⊆ E` pre-condition holds by construction.
2. The reset fires only on a named lifecycle event
   (`kind: tool` / `endpoint` / `agent` plus `phase: before` or
   `phase: after`, or a closed-namespace event under
   `kind: event`). No ad-hoc reset from arbitrary expressions.
3. Every invocation emits the `variable.<name>.declassified`
   event carrying the `reason:` text. This is the audit anchor.

Even after §10.6 is implemented, the runtime will not verify the release contract `ρ_δ` of the
declassifier or the operational context-replacement discipline
(TC-5 in the proof). Both remain the designer's proof obligation
per declassifier:

1. **Release function correctness.** `ρ_δ` must depend only on
   the designer-authorised projection of its input at the target
   level. The deployment is responsible for proving this
   property of each registered declassifier (typically the tool
   named in the `reset_by:` entry).
2. **Context replacement.** Declassification would lower `E`, but the
   runtime cannot directly remove the original high values from
   the LLM's context. The registered declassifier must
   operationally replace or remove the high portion of context
   (typically by host-supplied context rewriting, e.g., the
   LLM's message history is rewritten so the secret value is
   replaced by the redacted summary). Without this, the high
   content remains in context and subsequent low-observable
   egresses may leak it even though the gate passes.

Composition of declassifiers is an auditable concern (proof
§4.5.4). Chains may compose into laundering attacks if the set
of future `reset_by:`-firing tools is not carefully reviewed. A
deployment seeking formal anti-laundering should constrain its
registered set so that no two declassifying tools can chain
without the composite being explicitly registered with its own
release contract.

The conservative return-label and internal-derivation rules
(proof §2.5) mean that once exposure rises into "high" territory,
subsequent admissibility checks become more conservative.
Authors may need to declassify earlier and more often than they
expect. This is the price of coarse current-label IFC.

## 18. Worked example

The configuration in §4 is a complete worked example. The
running trace:

1. Initial state: `exposure = []`.
2. The agent calls `read_customer_balance`. The `populated_by:`
   entry fires on `phase: after`, and the type-locked set-union
   writes `[pii, financial]` to `exposure`. New state:
   `exposure = [pii, financial]`.
3. The agent calls `write_audit_log`. The clearance guard policy
   checks `exposure <= ['pii', 'financial', 'source_code', 'internal']`,
   which evaluates to `{pii, financial} ⊆ {pii, financial, source_code, internal} = true`.
   Admitted.
4. The agent calls `send_email_external`. The clearance guard
   policy checks `exposure <= []`, which evaluates to
   `{pii, financial} ⊆ ∅ = false`. Denied with the policy's
   `reason:` text in the verdict.

A second case: a coding agent reading a private GitHub
repository and being tricked into posting the contents as a
comment on a public issue. Add `read_private_repo` as a
`populated_by:` source writing `[source_code, internal]`, and
`post_public_issue_comment` as a sink whose
`allowed_when: "not (exposure <= [])"` clause denies any tagged
egress. The flow `{source_code, internal} ⊆ ∅` denies the
comment automatically. The author did not write a specific rule
for the GitHub leak.

## 19. Out of scope

The following are deliberately not part of v1.

- **Integrity labels.** Confidentiality only.
  Prompt-injection-as-integrity-attack (the agent reads
  attacker-controlled text and is tricked into deleting records)
  is not addressed by this lattice. Use guard policies,
  classifiers, predicates. Adding integrity labels is genuine
  future work and is achievable.
- **Per-variable taint.** The proof labels sources and sinks, not
  values. Adding per-value taint reintroduces the
  bound-argument-substitution attack class the project owner
  ruled out.
- **Static analysis of guard expressions.** This is a runtime
  monitor.
- **Principal hierarchies.** The DLM-style decentralised model is
  out of scope for v1.
- **Termination-insensitive noninterference (TINI).** The proof
  states possibilistic CGNI, not TINI. Reasoning about LLM
  termination behaviour requires modelling internals that the
  opaque-LLM threat model excludes. Not achievable in this
  setting.
- **Probabilistic noninterference.** The proof uses possibilistic
  NI. Attackers with statistical models of LLM sampling
  distributions may infer more than a single-trace attacker. Not
  achievable in this setting.
- **Side channels.** Timing, retry behaviour, blocked-attempt
  observation. Not achievable in any deployment that talks to
  remote LLM or tool APIs.
- **Implicit flows through the LLM.** Training-time leakage,
  learned associations, control-flow channels through the LLM.
  Not achievable without changing the threat model.
- **Declassifier-composition safety.** Theorem 2 holds for the
  registered set as given. Composition is an audit concern.
  Achievable as future work via constrained declassifier sets.

Of these, two (integrity labels, declassifier-composition safety)
are achievable as v2 work. The remaining four (TINI, probabilistic
NI, side channels, implicit flows) are fundamental limits of
running IFC over an opaque LLM that talks to external APIs.

## 20. Honest scope

This design implements coarse dynamic no-write-down IFC for
mediated agent effects. It is provably sound for the explicit-flow,
mediated-effect, low-observer attacker model under the side
conditions enumerated in `information-flow-control-proof.md` §4.6.
It is not full TINI. It is not a substitute for the existing
guard-policy machinery for integrity concerns. It relies on the
host honouring the wrapped-surface contract (TC-2) and the host
capability declaration for sub-session scope resets (TC-3).

When configured per the production guidance — an explicitly
declared `type: compartment` exposure variable with `default: []`,
`lifetime: per_session`, `populated_by:` entries on every tagged
source, `allowed_when:` clauses on every regulated sink (no
implicit admit-all), `reset_by:` entries restricted to named
lifecycle boundaries with a registered release function, and a
paired audience variable when `μ`/`ν` differ — it gives a
defensible runtime IFC guarantee for an agent runtime with an
opaque LLM core.

## 21. References

### In this repository

- [`information-flow-control-proof.md`](./information-flow-control-proof.md):
  the formal compliance proof against coarse-grained
  noninterference, including the ten side conditions on which the
  runtime guarantee depends.
- [`../spec/SPECIFICATION.md`](../spec/SPECIFICATION.md):
  the normative source for variable syntax. Relevant sections:
  §9.3 (closed event namespace, including
  `variable.<name>.declassified` and related audit events),
  §10.1 (label-typed variables `compartment` and `level`),
  §10.2 (forbidden `update:` block on label-typed variables),
  §10.5 (populator semantics including the type-locked join,
  §10.5.4 null-escalation rule, §10.5.5 vocabulary enforcement),
  §10.6 (resetters and the `reason:` field),
  §10.9 (no redefinition across `extends:` chains),
  §11.5 (resolver-write rejection on label-typed variables),
  §12 (guard-policy default-deny semantics).
- [`../spec/expressions/LANGUAGE.md`](../spec/expressions/LANGUAGE.md):
  the normative reference for expressions used in
  `allowed_when:` and `evaluate_when[].expression`. Relevant
  sections: §3.4a (enum / level member-index comparison),
  §3.7 (array subset operator), §5.3 (`subset` / `superset`
  named built-ins).
- [`../spec/schema/guardrails.schema.json`](../spec/schema/guardrails.schema.json):
  the canonical JSON Schema for label-typed variables, populators,
  resetters, and guard policies.

### Literature

- Stefan, Russo, Mitchell, Mazières (2011). *Flexible dynamic
  information flow control in Haskell.* The closest model: a
  current label tracked dynamically against a join-semilattice.
  Agent Shield diverges by labelling sources and sinks rather
  than values.
- Myers and Liskov (2000). *Protecting privacy using the
  decentralized label model.* Confidentiality-only restriction
  with a single principal hierarchy is the special case Agent
  Shield's tag-set carrier instantiates.
- Sabelfeld and Myers (2003). *Language-based information-flow
  security.* The general framework Agent Shield's possibilistic
  noninterference and delimited-release declassification
  semantics follow.
- Sutherland (1986). The original possibilistic-noninterference
  formulation, adopted in §2.6 of the proof.
