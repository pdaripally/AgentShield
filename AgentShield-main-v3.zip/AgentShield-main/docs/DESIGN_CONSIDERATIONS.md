# Design considerations

This index groups the operational guidance that sits beside the normative spec.

## Security and mediation

- [Security model](security-model.md)
- [Adapter mediated paths](adapter-mediated-paths.md)
- [Post-tool limits](POST_TOOL_LIMITS.md)

## Portability and parity

- [SDK parity](SDK_PARITY.md)
- [Framework compatibility](FRAMEWORK_COMPAT.md)
- [Third-party adapter conformance](THIRD_PARTY_ADAPTER_CONFORMANCE.md)

## Current design rules

- Keep `.guardrails.yaml` portable across frameworks.
- Fix adapter gaps in SDK code, not in framework-specific YAML escape hatches.
- Treat post-tool checks as containment, not rollback.
- Match the ecosystem's native middleware contract rather than forcing API symmetry where none exists.
