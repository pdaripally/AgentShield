# Pluggable Moderation Providers

Agent Shield ships **bundled moderation classifier providers** — external
content-classification services exposed through the YAML configuration
contract. Build the SDK with the appropriate Cargo feature, declare the
provider in `configurations[]`, and the runtime auto-wires the
implementation. No per-user HTTP code.

## Supported providers

| Provider              | `provider:` value(s)                                   | Cargo feature        | Service                             |
| --------------------- | ------------------------------------------------------ | -------------------- | ----------------------------------- |
| OpenAI Moderation     | `openai_moderation`                                    | `openai-moderation`  | OpenAI `/v1/moderations`            |
| Azure Content Safety  | `aacs`, `azure_content_safety`, `microsoft.azure.content_safety` | `aacs`               | Azure AI Content Safety             |
| Google Perspective    | `perspective`                                          | `perspective`        | Jigsaw / Google toxicity analysis   |
| Lakera Guard          | `lakera_guard`, `lakera`                               | `lakera-guard`       | Prompt-injection & content safety   |
| Llama Guard           | `llama_guard`                                          | `llama-guard`        | Meta Llama Guard (self-hosted)      |
| Custom HTTP           | *(omit provider, supply `endpoint:`)*                  | `http`               | Any classifier-verdict HTTP endpoint |

All bundled providers live under
`sdk/rust/agent_shield_core/src/classifiers/`. They share a common
fail-closed contract: any HTTP error, malformed body, missing
decision field, or unrecognized response shape surfaces as
`Err(reason)` from the `ClassifierCaller` trait, which the
GuardPolicyEngine folds into a `BLOCK` verdict.

## Quick start (Rust)

```toml
[dependencies]
agent_shield_core = { git = "https://github.com/microsoft/AgentShield", tag = "v<version>", features = ["lakera-guard"] }
```

```yaml
# .guardrails.yaml
configurations:
  - id: "lakera"
    type: classifier
    provider: "lakera_guard"
    api_key_env: "LAKERA_GUARD_API_KEY"
    category_thresholds:
      prompt_injection: 0.8
      jailbreak: 0.7

input_validation:
  guard_policies:
    - name: "lakera_input"
      evaluate_when:
        - classifier:
            configuration: "lakera"
          reason: "Lakera Guard flagged the user input."
      action: "block"
```

```bash
export LAKERA_GUARD_API_KEY=...
# Build the runtime; the auto-wire path detects the LLM and classifier
# configurations and installs HTTP-backed providers automatically.
```

## Quick start (Python / Node / .NET)

The bundled providers live in the core. The Python wheel
(`maturin develop --features lakera-guard,openai-moderation`), the
Node native module (build the napi crate with the same feature
flags), and the .NET native lib (build `agent_shield_core` with the
features and copy the resulting `libagent_shield_core.so` /
`agent_shield_core.dll` into your runtime) all pick up the same
provider catalog. No per-language HTTP plumbing.

## Azure AI Content Safety (AACS)

AACS requires **both** of the following environment variables to be
set. The `agent-shield init` CLI fails closed if either is missing
when AACS is requested in `--describe`:

```bash
# In your .env (or pre-set in the shell):
AZURE_CONTENT_SAFETY_ENDPOINT=https://<your-resource>.cognitiveservices.azure.com
AZURE_CONTENT_SAFETY_KEY="<your key>"
```

The canonical YAML shape (also what `agent-shield init` emits when
both vars are present):

```yaml
configurations:
  - id: aacs
    type: classifier
    provider: microsoft.azure.content_safety
    endpoint: "${env.AZURE_CONTENT_SAFETY_ENDPOINT}"
    api_key_env: AZURE_CONTENT_SAFETY_KEY
    threshold: 0.5

input_validation:
  guard_policies:
    - name: block_prompt_injection_input
      action: block
      evaluate_when:
        - classifier: { configuration: aacs }
          reason: "AACS flagged a prompt-injection input."
```

`endpoint:` is read from the env at runtime via `${env.…}`;
`api_key_env:` names the env var the runtime should read for the
API key — **the key value itself is never embedded in the YAML**.
Setting only one of the two vars produces a config that fails
closed on the first call; the CLI rejects the request at
generation time so the failure surfaces immediately.

## Per-category thresholds

`category_thresholds:` maps category names to their fail thresholds
(0.0 – 1.0 for score-based providers, 0/2/4/6 normalized to 0.0/0.33/0.66/1.0
for AACS severities). When the map is non-empty:

* Only listed categories are monitored.
* Unlisted high scores cannot trigger the verdict via the global
  `threshold:` field.
* The classifier verdict surfaces the highest-scoring listed category
  as `label`.

When `category_thresholds:` is empty / unset:

* The provider's native flagging signal forces a deny independent
  of the threshold.
* The maximum category score is compared to the global `threshold:`.

## Writing your own provider

If your service isn't in the bundled list, leave `provider:` unset
and supply an explicit `endpoint:` returning a classifier-verdict envelope —
the generic HTTP path in `DefaultDelegateDispatcher::dispatch_classifier`
handles that case. For deeper control, implement
`agent_shield_core::guard_policy_runtime::ClassifierCaller` directly
and register it on `RuntimeBuilder::register_classifier_caller`. The
host-supplied implementation always takes precedence over the
auto-wired bundled providers.

## Spec references

* [§6.2 — `configurations[]` routing matrix](../spec/SPECIFICATION.md#62-schema)
* [§11.12.4 — classifier verdict envelope](../spec/SPECIFICATION.md#11124-classifier)
* [§12.5.1 — `evaluate_when[].classifier:` detection](../spec/SPECIFICATION.md#1251-detection-kinds), [§12.9 — content-guard-policy specifics](../spec/SPECIFICATION.md#129-content-guard-policy-specifics)
* [`docs/security-model.md`](security-model.md) — fail-closed guarantees
