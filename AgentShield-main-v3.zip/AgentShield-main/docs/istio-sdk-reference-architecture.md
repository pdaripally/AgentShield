# Agent Shield on Kubernetes + Istio (SDK-First Reference Architecture)

This document describes the recommended deployment model for Agent Shield on Kubernetes and Istio in the v2 direction.

## Scope

This is a deployment reference for agents that already use Agent Shield SDK adapters.

- Security enforcement stays inside the agent execution loop through SDK adapters.
- Istio provides transport and platform controls (mTLS, policy, telemetry).
- Guardrails configuration is managed as Kubernetes config.

## Non-goals

This reference does not introduce a new HTTP reverse proxy protocol integration.

- No Envoy ext_authz integration
- No network-boundary replacement for Stage 2-4 checks

Agent Shield value is highest at tool and execution boundaries (Stages 2-4), which are inside the agent or MCP server runtime.

## Architecture

```text
User/Caller
   |
   v
Istio Ingress / East-West Mesh
   |
   v
Agent Pod (sidecar injected)
  - Agent app process (uses Agent Shield SDK adapter)
  - Envoy sidecar (mTLS, mesh telemetry)
  - mounted .guardrails.yaml (ConfigMap)
   |
   +--> Optional MCP Server Pod/Container
          - wrapped with MCPShield
          - same or separate guardrails ConfigMap

Observability:
  - Agent Shield events emitted via SDK observability provider
  - App/sidecar telemetry exported to OTLP collector
```

## 1) SDK integration in the agent

Use the SDK adapter in-process. Example (LangChain shape):

```python
import agent_shield.adapters.langchain
from agent_shield import Shield

shield = (
    Shield.from_yaml("/etc/agent-shield/.guardrails.yaml")
    .with_langchain()
    .build()
)

guarded_agent = shield.guard(agent)
```

For MCP servers, use `MCPShield`:

```python
from agent_shield.mcp import MCPShield

mcp_shield = MCPShield.from_yaml("/etc/agent-shield/.guardrails.yaml").build()
mcp_shield.protect_server(server)
```

## 2) Guardrails config via ConfigMap

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: agent-shield-guardrails
  namespace: agents

data:
  .guardrails.yaml: |
    metadata:
      name: "team-baseline"
      version: "1.0.0"
      agent_shield_version: "2.0"
    objective:
      goal: ["Handle user support requests safely"]
      forbidden: ["Expose secrets", "Execute unauthorized tool actions"]
    input_validation:
      guard_policies:
        - name: "block_jailbreak_regex"
          evaluate_when:
            - pattern: "(?i)(ignore|forget|bypass).*(instruction|policy)"
              reason: "Potential jailbreak attempt detected."
          action: "block"
```

Mount into the agent container:

```yaml
volumeMounts:
  - name: guardrails
    mountPath: /etc/agent-shield
    readOnly: true
volumes:
  - name: guardrails
    configMap:
      name: agent-shield-guardrails
      items:
        - key: .guardrails.yaml
          path: .guardrails.yaml
```

## 3) Istio mTLS and mesh policy

Enable sidecar injection for the namespace:

```bash
kubectl create namespace agents
kubectl label namespace agents istio-injection=enabled --overwrite
```

Enforce strict mTLS:

```yaml
apiVersion: security.istio.io/v1
kind: PeerAuthentication
metadata:
  name: default
  namespace: agents
spec:
  mtls:
    mode: STRICT
```

Optional destination rule for explicit ISTIO_MUTUAL:

```yaml
apiVersion: networking.istio.io/v1
kind: DestinationRule
metadata:
  name: default
  namespace: agents
spec:
  host: "*.agents.svc.cluster.local"
  trafficPolicy:
    tls:
      mode: ISTIO_MUTUAL
```

## 4) OTel wiring

Agent Shield SDK emits events through registered observability providers. Wire your provider to your app telemetry pipeline and export to OTLP.

Typical deployment env:

```yaml
env:
  - name: OTEL_SERVICE_NAME
    value: agent-app
  - name: OTEL_EXPORTER_OTLP_ENDPOINT
    value: http://otel-collector.observability.svc.cluster.local:4317
```

In code, register your observability provider with the runtime builder (direct runtime) or shield builder helper (adapter path).

## 5) Minimal deployment skeleton

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: agent-app
  namespace: agents
spec:
  replicas: 2
  selector:
    matchLabels:
      app: agent-app
  template:
    metadata:
      labels:
        app: agent-app
    spec:
      containers:
        - name: app
          image: ghcr.io/your-org/agent-app:latest
          ports:
            - containerPort: 8080
          env:
            - name: GUARDRAILS_PATH
              value: /etc/agent-shield/.guardrails.yaml
            - name: OTEL_SERVICE_NAME
              value: agent-app
            - name: OTEL_EXPORTER_OTLP_ENDPOINT
              value: http://otel-collector.observability.svc.cluster.local:4317
          volumeMounts:
            - name: guardrails
              mountPath: /etc/agent-shield
              readOnly: true
      volumes:
        - name: guardrails
          configMap:
            name: agent-shield-guardrails
```

## 6) Real-stack verification checklist

Use a real Kubernetes + Istio control plane (local kind is acceptable for first pass; managed cluster preferred for final validation).

1. Deploy namespace, ConfigMap, Deployment, Service, and PeerAuthentication.
2. Confirm sidecar injection:
   - `kubectl -n agents get pod -o jsonpath='{.items[0].spec.containers[*].name}'`
   - Expect app container plus `istio-proxy`.
3. Confirm strict mTLS:
   - `istioctl authn tls-check deploy/agent-app.agents`
   - Expect `STRICT`/mTLS for in-mesh traffic.
4. Run allow/deny functional probes against the agent API.
   - Normal request should succeed.
   - Known jailbreak/forbidden payload should be blocked by guardrails.
5. Validate Stage 2-4 enforcement (tool-call boundary):
   - Trigger a guarded tool path in the app.
   - Confirm deny/redact/approval behavior in app response and logs.
6. Validate observability:
   - Agent Shield events appear in your telemetry sink.
   - Correlate request trace/span to guardrail decision event.
7. Failure mode check:
   - Roll deployment and verify policy behavior remains fail-closed per your guardrails configuration.

## 7) Acceptance criteria for this architecture

- Agent uses SDK adapter in-process (not a reverse proxy hop).
- Guardrails file is externalized through ConfigMap.
- Istio mTLS is strictly enforced in namespace.
- Stage 2-4 controls are demonstrably active on real tool calls.
- Guardrail events are exported into the platform observability pipeline.

## Notes

- This reference is intentionally small and composable.
- If you need ingress authz/rate-limit controls, keep them in Istio/Envoy where they belong.
- Keep semantic policy enforcement in Agent Shield SDK/MCP boundaries.

## 8) Repo-ready manifests and scripts

Use the runnable bundle in `deploy/kubernetes/istio-sdk-reference/`:

- `kustomization.yaml` for one-command apply
- `setup-kind-istio.sh` for local kind + Istio bootstrap
- `test.sh` for sidecar, mTLS, and allow/deny probes

Quick commands:

```bash
kubectl apply -k deploy/kubernetes/istio-sdk-reference
bash deploy/kubernetes/istio-sdk-reference/test.sh
```
