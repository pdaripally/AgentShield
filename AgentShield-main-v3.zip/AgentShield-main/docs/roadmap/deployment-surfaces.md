# Deployment surfaces — roadmap

> **Status.** This document lists deployment surfaces that are **not** shipped in the current release. If a customer use case is blocked on one of them, file an issue against [microsoft/AgentShield](https://github.com/microsoft/AgentShield/issues) with the use case and constraints.

## What ships today

1. **In-process SDK** — Python, Node, .NET, Rust. See [`deploy/README.md`](../../deploy/README.md).
2. **LiteLLM Proxy guardrail** — OpenAI-compatible `/chat/completions` traffic routed through LiteLLM Proxy. Docs: [`docs/integrations/litellm-proxy.md`](../integrations/litellm-proxy.md).
3. **Istio + SDK reference deployment** — kustomize bundle for an SDK-integrated app. It does not include an AgentShield sidecar container. See [`deploy/kubernetes/istio-sdk-reference/`](../../deploy/kubernetes/istio-sdk-reference/).

Everything below is roadmap only.

## Generic HTTP gateway / reverse proxy

**Status:** Not shipped.  
**Tracking:** [#16 — feat: Validate AIGateway (YARPy) integration](https://github.com/microsoft/AgentShield/issues/16).

A standalone process would terminate HTTP, map each route to a `.guardrails.yaml` plus request/response extraction recipe, preserve session correlation across non-OpenAI request shapes, and apply Stage 5 safely to streaming responses.

## Standalone AgentShield Kubernetes sidecar container

**Status:** Not shipped.

A pod sidecar would intercept outbound LLM/tool calls without changing the app image. The hard parts are re-deriving in-process invariants such as `tool_call` → `tool_output` binding across a network boundary and extracting tool arguments from byte-level HTTP rather than framework objects.

## Official Helm chart

**Status:** Not shipped. The Kubernetes reference uses raw kustomize manifests.

A chart can wrap the existing [`deploy/kubernetes/istio-sdk-reference/`](../../deploy/kubernetes/istio-sdk-reference/) bundle, but it would still require a customer-built app image until a gateway or sidecar image exists.

## Official Docker image for a gateway / sidecar

**Status:** Not shipped. The repository publishes no `ghcr.io/microsoft/agent-shield`-style image.

A useful image depends on a shipped gateway or sidecar binary. It should be multi-arch, non-root, distroless, health-checkable, signed, and SBOM-attached.

## How to drive these forward

1. File or comment on an issue with the blocked use case, ingress shape, image-build policy, and supported runtimes.
2. Gateway and sidecar designs need an RFC because out-of-process stage semantics affect the spec. See [`CONTRIBUTING.md`](../../CONTRIBUTING.md).
3. Demand drives prioritization.
