# Agent Shield — Architecture

This document defines the responsibility boundaries between the four
implementation layers of Agent Shield: **Rust core**, **Rust SDK facade
+ adapter crates**, **per-language SDKs (Python / Node / .NET)**, and
**FFI bindings**. Read this before adding new functionality so it lands
in the right layer.

## TL;DR

```
                      ┌─────────────────────────────────┐
                      │        spec/SPECIFICATION.md    │
                      │  (the .guardrails.yaml contract)│
                      └────────────────┬────────────────┘
                                       │
            ┌──────────────────────────┴───────────────────────────┐
            │                                                       │
            ▼                                                       ▼
┌──────────────────────────┐                        ┌──────────────────────────┐
│  agent_shield_core (Rust)│                        │   spec/schemas/wire/    │
│                          │                        │   (canonical wire JSON  │
│  - 5-stage engine        │                        │    schemas)             │
│  - session isolation     │                        └─────────┬────────────────┘
│  - resolver lifecycle    │                                  │
│  - expression language   │                                  │
│  - 126 C ABI exports     │                                  ▼
│  - shield_primitives     │                        ┌──────────────────────────┐
│  - wire-shape parsers    │                        │ tests/fixtures/wire/    │
│                          │                        │ tests/fixtures/coverage/│
└────────┬───────┬─────────┘                        │ (golden fixtures)       │
         │       │                                  └──────────────────────────┘
         │       │
    ┌────┘       └─────────────────┐
    │                              │
    ▼                              ▼
┌────────────────────┐    ┌─────────────────────────────────────────┐
│ Rust SDK facade    │    │  Bindings (PyO3 / napi-rs / P/Invoke)    │
│ agent_shield       │    │                                          │
│ + 5 adapter crates │    │  - Marshal language values ↔ wire shapes │
│                    │    │  - Wrap opaque handles                   │
│ - Shield + Builder │    │  - Bridge host callbacks                 │
│ - FrameworkBundle  │    └────────────────┬──────────────────────────┘
│ - ext-trait/adapter│                     │
└────────────────────┘                     │
                                           ▼
                              ┌────────────────────────┐
                              │  Per-language SDKs     │
                              │  (Python / Node / .NET)│
                              │                        │
                              │ - Shield orchestrator  │
                              │ - Wrapper classes over │
                              │   native handles       │
                              │ - Framework adapters   │
                              └────────────────────────┘
```

## Layer 1 — Rust core (`sdk/rust/agent_shield_core`)

### Responsibility

The **single source of truth** for everything spec-defined or
deterministically shared across languages. Approximately 42 kLOC of
Rust. Stable target for FFI consumers.

### What lives in core (and why)

| Concern | Why it's here |
|---|---|
| `.guardrails.yaml` parser, validator, merger | Spec §6 / §13 are language-agnostic. One parser ⇒ no drift. |
| 5-stage validation engine (`guard_policy_runtime/stage_*.rs`) | Spec §14 / §16-§18 are deterministic. Each stage is a pure function over (config, request, session state). |
| `LifetimeTracker`, `EventBus`, `ActivationCache` (all session-keyed) | Spec §9 / §10 — session state isolation is a security invariant. One implementation ⇒ provable cross-session isolation. |
| `ResolverInvocationManager` | Spec §11 — pending registry, cancellation, late-completion, timeout, shutdown. Concurrency-correctness lives here once. |
| Expression language (`expressions/`) | Spec §7 + `spec/expressions/LANGUAGE.md`. The grammar parser, evaluator, fail-closed null semantics, built-ins. |
| `shield_primitives` (block-message format, `OnBlockPolicy` enum) | Customer-visible block string `[GUARDRAIL <ACTION>] <reason>` is byte-equivalent across SDKs. One formatter ⇒ no drift. |
| `wire_shapes` (LlmResponse / ClassifierVerdict parsers) | Each binding used to reimplement `decision: "ALLOW"` parsing. One canonical parser ⇒ no silent fail-closed bugs. |
| Observability dispatch (`observability/`) | The wire shape of `ShieldLogEvent` and the dispatcher state-machine. SDKs only adapt to language-native logging. |
| Session lifecycle (`runtime/session.rs`) | Per-session state (variables, predicates, latches, activation cache) lives here. SDKs hold an `Arc<GuardrailsSession>` handle. |
| C ABI surface (`ffi.rs`, ~63 deliberate handoff points) | The narrow waist between Rust core and language hosts. |

### What does NOT belong in core

* **Async state machine that calls into host code** — Stage 1 → execute → Stage 5 sequencing requires re-entering a host runtime (Python asyncio / Node N-API / .NET Task). Cross-FFI re-entry across 3 host runtimes is too fragile. The state machine lives per-SDK.
* **Framework-specific reflection** — extracting text from a LangChain `AIMessage`, wrapping a `StructuredTool`, hooking `client.messages.stream` — these depend on language-native classes. Cannot move to Rust.
* **Language-idiomatic API ergonomics** — async/await semantics, decorator patterns, `using` blocks, ContextVar / AsyncLocalStorage — language-typed primitives.
* **Per-framework agent loop helpers** — `runAnthropicAgent`, `createLangchainAgent` — adapter-shape glue.

### Stability guarantee

The C ABI is the SDK contract. Adding new exports is non-breaking;
removing or changing the signature of an export is breaking. Mark old
exports `#[deprecated]` for one release, then remove.

The expression language and the .guardrails.yaml YAML grammar follow
the spec's stability rules — see `spec/SPECIFICATION.md` §1.

### Dependencies

`agent_shield_core` depends only on Rust ecosystem crates (serde,
tokio for the async runtime when needed, sha2 for digest, jsonschema
for fixture validation in dev-dep, etc.). It does NOT depend on any
SDK or facade crate. **No upward dependency** from core.

---

## Layer 2a — Rust SDK facade (`sdk/rust/agent_shield`)

### Responsibility

A thin Rust SDK over `agent_shield_core` that mirrors the
customer-facing API of Python / Node / .NET. Approximately 1.2 kLOC.

### What lives here

| Concern | Why |
|---|---|
| `Shield` orchestrator + `ShieldBuilder` | Customer-facing entry point. Owns Stage 1 → execute → Stage 5 sequencing using `agent_shield_core::shield_primitives` for verdict-handling rules. |
| `FrameworkBundle` trait | Capability surface every framework adapter implements. |
| `ToolWrapper` trait | How adapters wrap framework tools through Stage 2+3+4. |
| `CapabilityReport` (Rust-side struct) | Mirrors `spec/schemas/wire/capability_report.schema.json`. Same shape across all 4 SDKs. |
| `ShieldError` enum | Shield-level errors (Blocked / Runtime / Config / Other). |
| Re-exports of `agent_shield_core` types | Customers import `Shield`, `Session`, `Runtime`, etc. from `agent_shield` not `agent_shield_core`. |

### What does NOT belong here

* Spec primitives (variables, lifetimes, events, predicates) — those live in core
* Wire-shape parsers — those live in core
* Framework-specific tool wrapping — those live in adapter crates

### Dependencies

Depends only on `agent_shield_core`. **NEVER** depends on any adapter
crate (would create a cycle). Adapter crates depend on
`agent_shield`, not the other way around.

---

## Layer 2b — Rust adapter crates

`agent_shield_anthropic` / `agent_shield_langchain` / `agent_shield_openai` /
`agent_shield_rig` / `agent_shield_mcp`

### Responsibility

Per-framework integration. ~250-600 LOC each. Each crate exposes:

* A `Shield<Framework>Ext` extension trait that adds `with_<framework>()` to `ShieldBuilder`
* A `<Framework>ToolWrapper: ToolWrapper` impl for Pattern B (pre-wrap tools)
* (Optional) Pattern A factories — e.g. `shield.create_langchain_agent(...)`
* A `CAPABILITY_REPORT: CapabilityReport` constant declaring honest per-stage coverage

### Dependencies

Each adapter depends on `agent_shield` (the facade) and the
framework's Rust SDK crate (e.g. `langchain-rust`, `rig-core`).
**Never** depends on another adapter crate.

### Why extension traits, not feature flags

The facade crate owns no framework knowledge. Customers `use
agent_shield_<framework>::Shield<Framework>Ext` to opt into one
framework. No facade ↔ adapter dependency cycle, no compile-time
feature flags, fully a la carte.

---

## Layer 3 — FFI bindings (`sdk/python/src/lib.rs`, `sdk/node/src/lib.rs`,
`sdk/dotnet/src/AgentShield/Interop/`)

### Responsibility

Marshal between language-typed values and core's wire shapes. Wrap
opaque handles (`*mut Runtime`, `*mut Shield`, …) in language-native
classes. Bridge host callbacks (Python callable → Rust trait object).

PyO3 ~1.5 kLOC, napi-rs ~1.5 kLOC, P/Invoke ~520 LOC.

### What lives here

* C ABI struct + function signatures (P/Invoke `[DllImport]`, napi `extern "C" fn`, PyO3 `#[pyfunction]`)
* `impl Trait for Py<Type>` bridges that wrap a host callable in the appropriate Rust trait object
* Conversion helpers: language value ⇒ JSON ⇒ FFI call ⇒ JSON ⇒ language value
* Lifetime / drop bridging (Python `Drop` on `__del__`, .NET `IDisposable`, etc.)

### What does NOT belong here

* Wire-shape parsing logic — call core's `shield_parse_*` exports instead
* Block-message formatting — call `shield_format_block_message`
* Anything stateful beyond a single FFI call

### Why minimal binding logic

Every line of binding logic is a chance for silent-fail bugs (the
`PyLlmCaller` JSON-string regression of 2026-05-07 is canonical:
binding-side parsing missed JSON-encoded LLM responses, fail-closed,
12 cross-language e2e tests broke for months). **Push every parse,
every transformation, every default-fill into core**. Bindings should
be type-marshaling and handle-wrapping only.

---

## Layer 4 — Per-language SDKs (`sdk/python/agent_shield`, `sdk/node`,
`sdk/dotnet/src/AgentShield`)

### Responsibility

Customer-facing API in each language's idiom. Approximately:
* Python: 7 kLOC (ships 6 framework adapters)
* Node: 3 kLOC (ships 3 framework adapters)
* .NET: 5 kLOC (ships 5 framework adapters)

### What lives here

| Concern | Why |
|---|---|
| Wrapper classes (`Runtime`, `Session`, `RuntimeBuilder`, `Shield`, `ShieldBuilder`, `StreamingGuard`, `MCPShield`) over native handles | Customers don't see opaque handles; they see typed classes with method completion, docstrings, type stubs. |
| `Shield` orchestrator (Stage 1→5 state machine) | Orchestrating stages requires re-entering a host async runtime to call user code. Per-SDK because async semantics are language-typed. |
| Framework adapters (`langchain.py`, `openai_agents.js`, `Anthropic.SDK` wrapper, etc.) | Reflect on language-native framework objects (extract text from `AIMessage`, wrap `StructuredTool`, etc.). Inherently per-language. |
| Hooks: `LlmCaller` / `ClassifierCaller` / `HumanResolver` / `AgentResolver` / `DelegateDispatcher` / `Extractor` / `ObservabilityProvider` Protocol/Interface declarations | Language-typed contracts that customer impls satisfy. |
| Streaming integration (per-framework chunk shapes) | Framework-specific. |
| Type definitions (dataclasses / TS types / .NET records) | Language-typed dataclasses mirror core's wire shapes. |

### What does NOT belong here

* Spec semantics (variables, predicates, etc.)
* Cross-stage sequencing rules — those live in core via `shield_primitives`
* Block-message formatting
* Wire-shape JSON parsing — call into core

### Why each SDK has a Shield orchestrator instead of one in core

Re-entering 3 different host async runtimes (asyncio / N-API / Task)
through FFI for a "execute this user function and await its result"
callback is a documented hard problem. The verdict-handling rules
(deterministic, `(verdict, policy) → outcome` pure function) live in
core; the surrounding state machine that schedules the host call lives
per SDK. About 600-900 LOC each — the price of language-native async
correctness.

---

## Cross-cutting

### Wire shapes

`spec/schemas/wire/` defines the canonical JSON shape of every wire
artifact: `stage_verdict`, `variable_state`, `resolver_request`,
`resolver_response`, `delegate_request`, `llm_response`,
`classifier_verdict`, `shield_log_event`, `capability_report`.

Drift detection: `tests/fixtures/wire/` ships 31 golden fixtures.
Conformance suites in Rust + Python + Node + .NET each validate
that each fixture round-trips through the language's typed
deserializer + serializer without loss. Adding a new wire shape
requires updating all 4 conformance suites.

### Coverage matrix

`tests/fixtures/coverage/` ships the canonical stage-coverage test
matrix. Each adapter's test parameterizes over the matrix; passing
proves the adapter's `CapabilityReport` claims aren't lying.

### Cross-language parity

`tests/parity/` ships Shield API and CapabilityReport conformance
tests that fail when Python claims a method that Rust / Node / .NET
don't have, or when adapters in different languages diverge on
coverage claims for the same framework.

### Naming

* Canonical name table: `spec/schemas/wire/*.schema.json` snake_case is canonical
* Per-language idiomatic case: `snake_case` Python+Rust, `camelCase` Node, `PascalCase` .NET
* `.NET` interfaces use the `I` prefix per .NET convention (e.g. `IHumanResolver`)
* Legacy aliases live in deprecated form for one major release, then are removed

---

## Testing taxonomy

Agent Shield's test surface is organised into 7 tiers. Each tier has a
specific purpose; tests should land in the lowest applicable tier.
Duplicating the same scenario across tiers is anti-pattern unless it's
explicit cross-language drift detection (Tiers 3 and 4).

### Tier 1 — Spec engine (Rust core unit tests)

* **Where**: `sdk/rust/agent_shield_core/src/**/*.rs` (`#[cfg(test)] mod tests`)
* **Owner**: Rust core
* **Purpose**: Prove every spec primitive obeys its rule
* **Examples**: variable state transitions, predicate memoization, expression evaluation, event-bus latch semantics, lifetime-tracker boundary clears, populator path matching
* **Density**: ~1,120 test attributes; this is the security core — keep dense
* **Don't put here**: anything that requires a built `Runtime` and full integration; that's Tier 2

### Tier 2 — Cross-language spec conformance

* **Where**: `tests/cases/*.cases.yaml` (108+ shared cases) consumed by per-language harnesses
* **Harnesses**:
  * Rust: `sdk/rust/agent_shield_core/tests/integration_cases.rs`
  * Python: `sdk/python/tests/test_integration_cases.py`
  * Node: `sdk/node/__tests__/integration_cases.test.mjs`
  * .NET: `sdk/dotnet/tests/AgentShield.Tests/IntegrationCaseTests.cs`
* **Purpose**: Same case → same result in 4 languages. Prove the runtime semantics are byte-equivalent.
* **Schema**: `tests/cases/test-cases.schema.json` — declarative `given / when / then` triples
* **What belongs here**: any test that exercises spec-defined runtime behaviour through the public Session API and could plausibly run in any of the 4 languages
* **Don't put here**: language-specific concerns (asyncio, ContextVar, .NET DI integration). Those go in Tier 5.

### Tier 3 — Wire conformance (cross-language)

* **Where**: `tests/fixtures/wire/*/*.json` (31 golden fixtures) consumed by 4 SDKs
* **Suites**: 4× per-language test files (`test_wire_fixtures.py`, `wire_fixtures.test.ts`, `WireFixtureTests.cs`, `wire_fixtures.rs`)
* **Purpose**: JSON wire shapes are byte-equivalent across language deserializers + serializers. Round-trip stability.
* **The 4× redundancy is intentional drift detection.** Removing any copy weakens the net. Don't consolidate.
* **Adding a new wire shape requires updating all 4 conformance suites** plus the JSON Schema.

### Tier 4 — API parity (cross-language)

* **Where**: `tests/parity/` — `shield_canonical_api.json`, `capability_canonical.json`, `verdict_dispatch_canonical.json` consumed by 4 SDKs
* **Suites**: 4× per-language parity tests (`tests/parity/test_*.py`, `__tests__/verdict_dispatch_parity.test.ts`, `tests/AgentShield.Tests/*ParityTests.cs`, `agent_shield/tests/parity_*.rs`)
* **Purpose**: Same Shield method shape in all 4 languages, same CapabilityReport claim per adapter, same dispatch outcome per (verdict, policy, mode) input.
* **Drift catalog**: `tests/parity/drift-catalog.json` (machine-readable; CI-blocked when it changes unexpectedly).

### Tier 5 — Per-SDK typed surface

* **Where**: `sdk/<lang>/tests/test_*.py` / `__tests__/*.test.ts` / `AgentShield.Tests/*.cs` / `agent_shield/tests/*.rs`
* **Purpose**: Language-typed wrappers, idiomatic API ergonomics
* **What belongs here**: dataclass coercion, exception type mapping, asyncio / ContextVar / AsyncLocalStorage / AsyncLocal interaction, type stubs / Protocol implementations, language-specific error handling, pyo3 / napi-rs / P/Invoke bridge behaviour
* **Don't put here**: anything that's already covered by Tier 2 with a shared fixture. Use Tier 2 instead so all 4 languages run it.

### Tier 6 — Per-framework adapter

* **Where**: `tests/cases/adapter-scenarios.yaml` (cross-language shared scenarios) consumed by per-framework harnesses
* **Harnesses**:
  * Python: `tests/e2e/run_*.py` (langchain / openai_agents / anthropic_agents / autogen / crewai / semantic_kernel)
  * Node: `tests/e2e/node/run-*.test.mjs`
  * Rust: `sdk/rust/agent_shield_<framework>/tests/adapter_scenarios.rs`
  * .NET: `sdk/dotnet/tests/AgentShield.Tests/AdapterScenariosTests.cs`
* **Purpose**: Same scenario → same adapter behaviour across frameworks within a language, AND across languages for the same framework
* **Don't put here**: framework-specific edge cases that don't generalise (e.g. LangChain.js StructuredTool subtype handling); those stay in per-adapter unit tests in Tier 5

### Tier 7 — Demo end-to-end

* **Where**: `examples/*/demo/*.py`
* **Purpose**: Customer-visible smoke test of integration paths. Catches "demo broken on `pip install`" regressions.
* **CI**: syntax-only (real LLM calls require API keys). The 42 demo scripts must `python -c "import ast; ast.parse(open(f).read())"` cleanly.

### Decision tree: where does my test go?

1. Does it test a single spec primitive in isolation? → **Tier 1** (Rust core unit test)
2. Does it test runtime behaviour through the Session API and could run in any language? → **Tier 2** (shared YAML case)
3. Does it test a JSON wire shape? → **Tier 3** (golden fixture in all 4 SDKs)
4. Does it test cross-language API parity? → **Tier 4** (canonical contract + 4 parity tests)
5. Does it test language-specific async / typed-surface concerns? → **Tier 5** (per-SDK unit test)
6. Does it test a framework adapter's runtime behaviour? → **Tier 6** (adapter-scenarios.yaml)
7. Does it smoke-test a customer-visible demo? → **Tier 7** (`examples/`)

If none fit cleanly, that's a new category — discuss before adding.

---

## Adding a new feature: where does it go?

1. **Is it spec-defined?** → Goes in core. Spec author writes it, runtime author implements it.
2. **Is it deterministic logic shared by every SDK?** (block-message format, on-block dispatch, wire-shape parsing) → Goes in core, exposed via FFI.
3. **Is it a framework adapter?** → Goes in the adapter (per-language).
4. **Is it language-typed (e.g. a Python decorator, a .NET attribute, a Node middleware)?** → Goes in the per-language SDK.
5. **Does it require re-entering a host async runtime to call user code?** → Goes in the per-language SDK. Don't try to push it through FFI.

When in doubt: prefer core. Every line of duplicated logic across N
SDKs is N chances to drift.

---

## Anti-patterns

* **Hand-rolled JSON parsing in a binding** — silent fail-closed bug class. Use core's `shield_parse_*` instead.
* **Per-framework Shield subclass** — Python had this until 2026-05-07; replaced with composition. Subclass-per-framework forces customers to import differently per framework, doesn't compose, and creates 6× the surface to maintain.
* **Adapter monkey-patching the base Shield's generic methods** — the Node adapters used to override `Shield.prototype.run` and `Shield.prototype.protectTool`. Whichever adapter loaded first won. Generic methods live on the base class; adapters install only framework-specific helpers.
* **Stateful mutable Shield post-build** — `shield.reset()` that mutates in place creates aliasing footguns. Use functional `with_fresh_session()` returning a new Shield.
* **Global mutable state in Runtime** — variables, event-bus latches, activation cache leak across concurrent sessions. All session-scoped state lives in `GuardrailsSession`, keyed by `SessionId`.
* **Spec changes that go through code review without a corresponding wire-fixture update** — leads to silent shape drift across SDKs.

---

## Versioning

| Layer | Versioning |
|---|---|
| Spec | `agent_shield_version: "2.0"` in YAML; spec is in `spec/SPECIFICATION.md` |
| `agent_shield_core` C ABI | Adding exports = minor bump. Removing or changing signature = major bump. |
| `agent_shield_core` Rust API | Per Rust crate semver. |
| Per-language SDK | Per language ecosystem (PyPI / npm / NuGet). All currently 0.13.0. Customer-facing API breaks = major bump. |
| Adapter crates | Track facade version. |

---

## Open architectural items (deferred)

These are real but not regressions. Tracked in `tasks/lessons.md` if
they're carried forward.

1. **Shield orchestrator state machine duplicated ~4,000 LOC across 4 SDKs.** Verdict-handling rules already in `shield_primitives`; further consolidation requires language-async wrapping that's too fragile across 3 host runtimes.
2. **Wire-shape parsing duplication** — being addressed in Phase D.
3. **Shield API method-parity drift** — being addressed in Phase E (parity tests).
4. **CapabilityReport cross-language conformance** — being addressed in Phase G.
5. **HumanResolver as MCP tool** — pending design-confirmation. Currently `HumanResolver` is a special FFI callback; the proposed model collapses it to a regular `kind: tool` resolver where the agent's LLM calls a host-defined `ask_human` MCP tool, the tool's populator sets the variable, and the runtime retries the gate. Eliminates the special channel; one less callback bridge per SDK.
