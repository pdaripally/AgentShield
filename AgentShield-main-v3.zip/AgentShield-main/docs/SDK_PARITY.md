# SDK parity

This table mirrors `tests/parity/shield_canonical_api.json`. The supporting cross-SDK parity fixtures now also live in `tests/parity/verdict_dispatch_canonical.json`, `tests/parity/invocation_hash_canonicalization.json`, and `tests/parity/error_mapping_parity.json`. Public-surface differences are only acceptable when they reflect a genuine ecosystem-specific middleware shape.

- `kind: human` is part of the supported model in every SDK.
- Python/Node use `shield.guard(agent)` where the ecosystem has a natural agent object.
- Rust intentionally treats Pattern A as `n/a (ecosystem)` and ships Pattern B for Rig via `GuardedRigTool` / `with_rig_full_coverage()`.
- .NET uses framework-native middleware (`DelegatingChatClient`, `IAutoFunctionInvocationFilter`, `IMiddleware`) rather than a forced one-size-fits-all `Guard(...)` surface.

## Shield methods

| Method | Rust | Python | Node | .NET | Notes |
|---|---|---|---|---|---|
| `from_yaml` | ✓ `from_yaml` | ✓ `from_yaml` | ✓ `fromYaml` | ✓ `FromYaml` | Build a ShieldBuilder from a single guardrails YAML file path. |
| `from_yaml_chain` | ✓ `from_yaml_chain` | ✓ `from_yaml_chain` | ✓ `fromYamlChain` | ✓ `FromYaml` | Build a ShieldBuilder from a chain of guardrails YAML files (extends-merge). .NET dispatches via FromYaml(IReadOnlyList<string>) overload. |
| `with_fresh_session` | ✓ `with_fresh_session` | ✓ `with_fresh_session` | ✓ `withFreshSession` | ✓ `WithFreshSession` | Functional update: return a NEW Shield bound to a fresh session, sharing the runtime+bundle. |
| `mode` | ✓ `mode` | ✓ `mode` | ✓ `mode` | ✓ `Mode` | Behavioural mode (Enforce / Monitor). |
| `capabilities` | ✓ `capabilities` | ✓ `capabilities` | ✓ `capabilities` | ✓ `Capabilities` | Adapter capability profile. Canonical accessor name across all four SDKs. |
| `protect_tools` | ✓ `protect_tools` | ✓ `protect_tools` | ✓ `protectTools` | ✓ `ProtectTools` | Wrap a list of framework tools with Stage 2/3/4 enforcement. Shape of input/output differs per language. |
| `run` | ✓ `run` | ✓ `run` | ✓ `run` | ✓ `RunAsync` | Stage 1 + Stage 5 wrapper around an opaque user-supplied agent thunk across all four SDKs. |
| `protect_tool` | ✓ `protect_tool` | ✓ `protect_tool` | ✓ `protectTool` | ✓ `ProtectToolAsync` | Stage 2/3/4 wrapper around a single tool function (singular) across all four SDKs. |
| `with_session` | ✓ `with_session` | n/a (ecosystem) | n/a (ecosystem) | ✓ `WithSession` | Intentional asymmetry — Same rationale as Shield.session: Rust+.NET expose Arc<GuardrailsSession>-style accessors that customers swap functionally (with_session) for session-fork scenarios. Python+Node use the bundle-managed `with_fresh_session()` pattern which is more idiomatic for those languages. The cross-language test harness verifies both shapes deliver identical session-fork semantics. Audited 2026-05: 5 real callsites in agent_shield/tests/with_fresh_session.rs. |
| `from_runtime` | ✓ `from_runtime` | n/a (ecosystem) | n/a (ecosystem) | ✓ `FromRuntime` | Intentional asymmetry — Escape hatch from the YAML-driven build path. Used by integration tests and library-composition scenarios where the GuardrailsRuntime is constructed via RuntimeBuilder directly (e.g. with custom callers/dispatchers that don't fit the bundle pattern). Python+Node customers in the same scenario drop down to RuntimeBuilder.build() and don't need a Shield wrapper. Audited 2026-05: 6 real callsites across Rust facade tests and the bank-manager + sensitive-documents Rust examples. |
| `session` | ✓ `session` | n/a (ecosystem) | n/a (ecosystem) | ✓ `Session` | Intentional asymmetry — Rust+.NET hold a default Arc<GuardrailsSession> on the Shield itself so single-session apps don't have to thread a session handle through every call. Python+Node use `runtime.new_session()` per request (idiomatic in those languages: with-statements / async context) and don't need the accessor. Audited 2026-05: 84 real callsites in Rust facade tests and the with_fresh_session test suite. |
| `runtime` | ✓ `runtime` | ✓ `runtime` | ✓ `runtime` | ✓ `Runtime` | Underlying GuardrailsRuntime. |
| `guard` | n/a (ecosystem) | ✓ `guard` | ✓ `guard` | n/a (ecosystem) | Intentional asymmetry — Pattern A entry-point shape is genuinely ecosystem-specific, not a parity gap. Python+Node have framework-owned agent-object abstractions (LangChain Runnable, OpenAI Agents SDK Agent, Anthropic Agents) that map naturally to a single shield.guard(agent) wrapper via a bundle-dispatch pattern. Rust has no equivalent agent-object framework: rig is the only production-viable agent SDK and it owns the loop via rig::Agent + PromptHook (no external wrap point); the canonical Rust pattern is shield.run(thunk) + shield.protect_tool(...) primitives. .NET has best-in-class native middleware surfaces — Microsoft.Extensions.AI's DelegatingChatClient (UseAgentShield()), Semantic Kernel's IAutoFunctionInvocationFilter, AutoGen .NET's IMiddleware — each per-framework shape IS that framework's idiomatic integration point. Forcing Shield.Guard<T> on Rust/.NET would be less idiomatic, not more. Pattern A coverage is delivered in all four SDKs; the entry-point shape matches each ecosystem's middleware idiom. See spec/SPECIFICATION.md §2.x and .github/copilot-instructions.md "Per-ecosystem adapter shapes". |
| `before_invoke` | ✓ `before_invoke` | ✓ `before_invoke` | ✓ `beforeInvoke` | ✓ `BeforeInvokeAsync` | Stage 1 only (yes/no answer) convenience helper, available in all four SDKs. |

## ShieldBuilder methods

| Method | Rust | Python | Node | .NET | Notes |
|---|---|---|---|---|---|
| `build` | ✓ `build` | ✓ `build` | ✓ `build` | ✓ `Build` | Build the Shield. Consumes the builder. |
| `with_mode` | ✓ `with_mode` | ✓ `with_mode` | ✓ `withMode` | ✓ `WithMode` | Set the Shield's runtime mode (Enforce / Monitor). |
| `with_on_block` | ✓ `with_on_block` | ✓ `with_on_block` | ✓ `withOnBlock` | ✓ `WithOnBlock` | Set the OnBlockPolicy. |
| `with_llm` | ✓ `with_llm` | ✓ `with_client` | ✓ `withClient` | ✓ `WithLlm` | Register an LLM caller. NOTE: name drift — Python/Node expose with_client (typed as a framework client), Rust/.NET expose with_llm (typed as an LlmCaller). |
| `with_observability` | ✓ `with_observability` | ✓ `with_observability` | ✓ `withObservability` | ✓ `WithObservability` | Register an observability provider (single). Canonical cross-SDK name. Customers chain to register multiple. |
| `with_agent_resolver` | ✓ `with_agent_resolver` | ✓ `with_agent_resolver` | ✓ `withAgentResolver` | ✓ `WithAgentResolver` | Register an AgentResolver. Available in all four SDKs. |
| `with_delegate_dispatcher` | ✓ `with_delegate_dispatcher` | n/a (ecosystem) | n/a (ecosystem) | ✓ `WithDelegateDispatcher` | Intentional asymmetry — Subsumed by YAML-driven delegate auto-wiring in agent_shield_core. The bundled HTTP delegate dispatcher handles `configurations: - {type: agent, transport: http_jsonrpc}` etc. without host code. Kept on Rust+.NET as an escape hatch for custom non-HTTP delegate transports; Python+Node customers drop to RuntimeBuilder for the rare case. Audited 2026-05: only callsite is sdk/rust/agent_shield/tests/parity_api.rs (compile-time surface check). |
| `with_classifier` | ✓ `with_classifier` | n/a (ecosystem) | n/a (ecosystem) | ✓ `WithClassifier` | Intentional asymmetry — Subsumed by YAML-driven classifier auto-wiring (bundled providers: AACS / Lakera Guard / Llama Guard / OpenAI Moderation / Perspective). Kept on Rust+.NET as an escape hatch for custom classifiers; Python+Node customers use YAML or drop down to RuntimeBuilder. Audited 2026-05: only callsite is sdk/rust/agent_shield/tests/parity_api.rs (compile-time surface check) — no example in examples/ uses this method. |
| `with_extractor` | ✓ `with_extractor` | n/a (ecosystem) | n/a (ecosystem) | ✓ `WithExtractor` | Intentional asymmetry — Custom payload extractors are a rare escape hatch — the expression language's `@result.<path>` syntax covers virtually all real cases. Kept on Rust+.NET as an escape hatch; Python+Node customers drop down to RuntimeBuilder. Audited 2026-05: only callsite is sdk/rust/agent_shield/tests/parity_api.rs (compile-time surface check). |
| `with_capability` | ✓ `with_capability` | n/a (ecosystem) | n/a (ecosystem) | ✓ `WithCapability` | Intentional asymmetry — Internal/test helper for synthesising CapabilityReports without going through a framework bundle. Used by agent_shield_rig::with_rig_full_coverage to promote the hook-based capability report from Partial to Full when a customer commits to the wrap-tools-up-front Pattern B path. Not a customer-facing 'guess what to wire' API. Audited 2026-05: 6 callsites all internal — `with_rig_full_coverage` plus parity_api compile fixtures. |

## Framework-pattern notes

| Ecosystem | Pattern A | Pattern B | Pattern C |
|---|---|---|---|
| Rust | n/a (no production framework with a wrap-the-agent object) | `agent_shield_rig::GuardedRigTool` / `with_rig_full_coverage()` | `shield.run(...)`, `shield.protect_tool(...)` |
| Python | `shield.guard(agent)` | `shield.protect_tools(...)` | `shield.run(...)` / `shield.protect_tool(...)` |
| Node | `shield.guard(agent)` | `shield.protectTools(...)`, `protectOpenaiTools(...)`, `protectAnthropicTools(...)` | `shield.run(...)`, `shield.protectTool(...)` |
| .NET | framework-native middleware entry points | `ProtectTool` / framework filter registration | `RunAsync` / runtime primitives |
