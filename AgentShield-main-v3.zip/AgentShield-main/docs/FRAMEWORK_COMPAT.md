# Framework compatibility

This matrix is the release-claim view: what each shipped adapter is wired to today, which package/version range the repo claims to support, and where CI exercises it.

## Current matrix

| Adapter | Ecosystem | Framework package / surface | Supported range or CI pin | CI status | Notes |
|---|---|---|---|---|---|
| LangChain | Python | `langchain`, `langchain-openai` | `>=0.3` | existing SDK + adapter tests | Adapter lives in `sdk/python/agent_shield/adapters/langchain.py`. |
| LangChain | Node | `@langchain/core` | `^1.1.44` | existing SDK + adapter tests | Tool wrapping + guarded agent builder. |
| LangChain | Rust | `langchain-rust` | `4.6` | existing crate tests | Pattern B / explicit wrapper surface. |
| OpenAI Agents | Python | `openai-agents` | `>=0.1` | existing SDK + adapter tests | Native guardrail helper objects included. |
| OpenAI Agents | Node | `@openai/agents`, `@openai/agents-openai` | `>=0.11.0` | existing SDK + adapter tests | Pattern A/B plus streamed text surface. |
| OpenAI | Rust | `async-openai` | `0.34` | existing crate tests | Rust crate is named `agent_shield_openai`. |
| Anthropic | Python | `anthropic` | `>=0.68` | existing SDK + adapter tests | Uses Anthropic tool-runner surface. |
| Anthropic | Node | `@anthropic-ai/sdk` | `>=0.40.0` | existing SDK + adapter tests | Partial streaming over text deltas. |
| Anthropic | .NET | `Anthropic.SDK` | `5.*` | existing adapter tests | Non-streaming helper + partial streaming claim. |
| Anthropic | Rust | raw Messages/tool-use schema | no external SDK pin | existing crate tests | Crate intentionally avoids a Rust Anthropic SDK dependency. |
| Semantic Kernel | Python | `semantic-kernel` | `>=1.0` | existing SDK tests | Streaming unsupported on Python. |
| Semantic Kernel | .NET | `Microsoft.SemanticKernel` | `1.*` | existing adapter tests | Uses `IAutoFunctionInvocationFilter`. |
| AutoGen | Python | `autogen-agentchat`, `autogen-core` | `>=0.4` | existing SDK tests | Partial Stage 2/3/4 coverage. |
| AutoGen | .NET | `AutoGen.Core` | `0.*` | existing adapter tests | Uses `IMiddleware`. |
| CrewAI | Python | `crewai` | `>=0.60` | existing SDK tests | No Node/.NET/Rust surface claimed. |
| MCP | Python | in-process MCP server helpers | repo surface | existing SDK tests | No third-party package pin. |
| MCP | Node | in-process MCP server helpers | repo surface | existing SDK tests | No streaming claim. |
| MCP | .NET | in-process MCP server helpers | repo surface | existing adapter tests | `MCPShield`. |
| MCP | Rust | in-process MCP server helpers | repo surface | existing crate tests | Explicit Stage 3/4 helpers. |
| Rig | Rust | `rig-core` | `0.35` | existing crate tests | Full Stage-3 coverage requires Pattern B / `GuardedRigTool`. |
| Microsoft.Extensions.AI | .NET | `Microsoft.Extensions.AI` | `9.*` | existing adapter tests | `DelegatingChatClient` middleware. |

## Notes

- This PR documents the compatibility story and keeps CI anchored to the versions already exercised in-repo.
- Package ranges come from the SDK manifests (`pyproject.toml`, `package.json`, `*.csproj`, `Cargo.toml`).
- Rows without a third-party package pin are still compatibility rows: the adapter surface itself is the contract being tested.
