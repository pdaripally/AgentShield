# Information Flow Control: Compliance Proof

## 1. Scope

This document proves that the IFC runtime in Agent Shield satisfies
two information-flow security properties.

1. Pure CGNI (Theorem 1, §4.4). Coarse-grained, possibilistic
   noninterference for executions that contain no declassification.
2. CGNI modulo δ (Theorem 2, §4.5). The same property weakened to
   permit the released outputs of registered declassifiers, in the
   sense of Sabelfeld and Myers's delimited release (2003).

Both properties are confidentiality-only. Both assume an
explicit-flow attacker model with possibilistic semantics for LLM
nondeterminism. Ten side conditions (TC-1 through TC-10, §4.6) are
load-bearing. Some are enforced by the runtime; others are TCB
axioms about the host or about specific declassifiers.

This document does not claim termination-insensitive noninterference
(TINI), probabilistic noninterference, integrity, or soundness when
any side condition fails. §4 enumerates what is and is not in scope.

The companion document `information-flow-control.md` describes how
the runtime is configured.

## 2. Formal model

### 2.1 Carrier

Let `T` be a finite set of tags declared as the `vocabulary:`
field of a `type: compartment` variable in the YAML configuration
at config-load time (Specification §10.1). Define the label
lattice `L` as the powerset lattice over `T`:

```
carrier:    L  =  2^T
order:      ℓ₁ ⊑ ℓ₂   ⟺   ℓ₁ ⊆ ℓ₂
join:       ℓ₁ ⊔ ℓ₂   =   ℓ₁ ∪ ℓ₂
bottom:     ⊥  =  ∅
top:        ⊤  =  T
```

`(L, ⊑, ⊔, ⊥, ⊤)` is a complete distributive lattice and in
particular a bounded join-semilattice. It is the free
join-semilattice on `T`: every monoid homomorphism from `T*`
(read-sequences) to a commutative-idempotent monoid factors uniquely
through `(L, ∪)`.

The choice of `L = 2^T` is the most expressive carrier compatible
with commutative-idempotent read semantics. Other join-semilattices
over the same generators are quotients of `2^T` via `X ↦ ⊔X`. The
algebra does not force the powerset; it admits it. Narrower
lattices (a linear chain, for instance) are recoverable as
quotients, and are declared directly as `type: level` variables
(Specification §10.1) whose type-locked `max()` join factors
through `(L, ∪)` via member-rank ordering.

The lattice operations are realised by the variable runtime. The
type-locked set-union join on a `type: compartment` variable
(Specification §10.5.5) IS `⊔`. The array subset operator on
`allowed_when:` clauses (LANGUAGE.md §3.7) IS `⊑`. All subsequent
references in this proof to `L`, `⊔`, `⊑`, `⊥`, and `⊤` resolve
to those primitives.

### 2.2 Sources, sinks, policy functions, observer audiences

Let `S` be the set of source identifiers declared in `resources:`.
Let `K` be the set of sink identifiers. Every resource is
potentially both a source and a sink. The policy provides three
functions.

- `λ : S → L`. The source classification function. `λ(s)` is the
  label assigned to data returned from `s`. It is realised by
  the `populated_by:` entries of a `type: compartment` variable
  (Specification §10.5): each entry binds a source `s` to a
  label value, and the type-locked set-union join writes
  `exposure ⊔ λ(s)` on success.
- `μ : K → L`. The sink clearance function. `μ(k)` is the label
  `k` will admit in its arguments. The runtime admits an egress
  to `k` iff the running exposure is a subset of `μ(k)`. It is
  realised by a guard policy whose `applies_to.tools: [k]` (or
  the analogous endpoint/agent `applies_to`) and whose
  `allowed_when:` clause uses the array subset operator
  (LANGUAGE.md §3.7) against the running-exposure variable.
- `ν : K → L`. The observer audience function. Read
  directionally: `ν(k)` is the clearance an observer must hold
  to see `k`'s effects. `ν(k) = ∅` means no clearance is
  required (publicly observable). `ν(k) = T` means top clearance
  is required (fully restricted). External email has `ν = ∅`.
  An internal-only audit log has `ν = T`. It is realised by a
  second `type: compartment` variable, populated by the same
  resources as the running-exposure variable, and gated by its
  own subset-based guard policy on each sink.

All three functions are fixed at config-merge time and are
read-only thereafter. This is TC-1 (§4.6). The strict
no-redefinition rule for label-typed variables across `extends:`
chains (Specification §10.9), together with the load-time
prohibitions on resolver writes (§11.5), expression-driven
mutation (§10.2), and out-of-vocabulary populator values
(§10.5.5), discharges read-only-after-merge for `λ`, `μ`, and
`ν`.

User input is treated as a pseudo-source `user_input ∈ S` with
`λ(user_input)` realised by a `populated_by:` entry on the
exposure variable that fires on Stage 1 user input. The user
output channel is a pseudo-sink `user_output ∈ K` with
`μ(user_output)` realised by an `output_validation:` guard
policy whose `allowed_when:` clause matches the running
exposure against the user's clearance, and `ν(user_output) = ∅`.
The user is the most permissive audience for confidentiality
purposes: anyone reading the user-facing output sees it.

#### 2.2.1 Per-call witnessing of `λ` and `μ`

The type signatures `λ : S → L` and `μ : K → L` used above
are a shorthand. The actual realisations through
`populated_by:` and `allowed_when:` admit a per-call
dependence on the invocation's runtime values that the
signatures do not surface directly. This subsection makes the
dependence explicit and discharges the soundness obligation
it raises. The clarification is operational, not
foundational: Lemma 1 (§4.3) survives unchanged because its
proof only requires that *some* element of `L` be joined per
call, never that the joined value be a fixed function of the
source identifier alone.

**Per-call witnessing of `λ`.** A populator entry is one of
two forms (Specification §10.5.3):

- `value: <literal>` — the entry writes a fixed value
  `ℓ ∈ L` on every successful invocation of the targeted
  source.
- `expression: <expr>` — the entry evaluates an expression
  that may reference the call's return envelope (`@result.*`)
  and writes the resulting value `ℓ ∈ L`. The label written
  on a given invocation is therefore a function of `(s, v)`
  where `v` is the value returned by the call, not of `s`
  alone.

Define, for each populator entry `e` whose selector matches
source `s`, the **per-entry witnessing function**
`ω_{e,s} : V_s → L` where `V_s` is the set of possible return
values from `s`. `ω_{e,s}(v)` is normalised to lie in `L` by:

1. `ω_{e,s}(v) = ℓ` for static `value: ℓ` entries (constant
   function of `v`).
2. `ω_{e,s}(v) = ⟦expression⟧(v)` for dynamic `expression:`
   entries, with the convention that `ω_{e,s}(v) = ⊤`
   whenever the expression evaluates to `null` (Specification
   §10.5.4) or returns a value containing tags outside the
   declared `vocabulary:` (the in-vocabulary subset survives;
   if every tag is out-of-vocabulary the result is `⊥`, per
   §10.5.5).

When multiple populator entries match the same source
(Specification §10.5.1, "Evaluation rule per call site"),
every matching entry fires on each invocation and the writes
compose under the type-locked join. Define the **per-source
witnessing function** `ω_s : V_s → L` as

```
ω_s(v) = ⊔_{e : e matches s} ω_{e,s}(v)
```

The operational-semantics transition `invoke(s, a) / return(v)`
in §2.5 then realises

```
E′ = E ∪ ω_s(v)
```

The fixed-function reading `E′ = E ∪ λ(s)` in the table is
shorthand for the per-call form when no ambiguity arises; for
entirely-static configurations they coincide, and for
dynamic configurations `λ(s) := sup_v ω_s(v) ⊆ ⊤` is the
sound upper bound (it is exactly `⊤` whenever any matching
entry is dynamic, by normalisation clause 2).

**Soundness of the per-call form.** The proof of Lemma 1
(§4.3) only requires that the label written on each admitted
`invoke(s, a) / return(v)` transition be some element of `L`,
and that the post-state assignment `Γ′(v) = E′` reflect the
joined value. Substituting `ω_s(v)` for `λ(s)` in the
`invoke / return` row leaves both conditions intact:
`ω_s(v) ∈ L` by the normalisation clauses, and the
conservative derivation rule `Γ′(v) = E′` is unchanged.

**Trust placement.** The per-call form makes visible that, for
dynamic populators, the tool's return envelope is part of the
trusted base for `λ` on that source. The fail-closed
normalisation clauses defend against *missing* or
*out-of-vocabulary* tags (the runtime widens to `⊤` or drops
the offending elements with a warn event, per
Specification §10.5.4 and §10.5.5). They do not defend against
a *valid but incorrect* tag returned by a misbehaving tool;
correctness of the tool's self-classification is a tool-level
TCB obligation, the same kind of obligation TC-1 places on
the populator expression body itself. Authors who do not
trust a tool to label its own output correctly SHOULD pair a
static `value:` populator (conservative minimum) with the
dynamic one (precise refinement); both fire on each call and
the lattice join takes the maximum, which always dominates
the static floor.

**Per-call witnessing of `μ`.** The analogous structure
applies to `μ` through `allowed_when:` expressions. An
`allowed_when:` clause may reference call-bound namespaces
(`@tool.params.*`, `@endpoint.params.*`, `@agent.params.*`),
making the admit set per-call. Define
`μ_k : A_k → L ∪ {undef}` over the call's argument bundle
`a ∈ A_k` by `μ_k(a) = ⟦allowed_when⟧(a)` when the clause
evaluates to a literal tag-set RHS, and `μ_k(a) = undef`
(treated as `∅` for admission purposes) when the clause
evaluates to `null` or `false`. The expression language's
fail-closed null-as-false rule (LANGUAGE.md §3.3) is what
guarantees the undef case denies any non-empty exposure: the
admit set is empty, so `E ⊆ ∅` only when `E = ∅`. The proof's
totality argument (TC-7 + Specification §12.13) is unaffected;
every call still flows through one of the covering policies
and the policy's per-call effective admit set is what
`μ_k(a)` resolves to.

**Multiple populators per variable as the common shape.**
The per-call form makes a design point explicit that the
fixed-function shorthand can obscure: a single label-typed
variable is *expected* to declare many populator entries
spanning many sources, with mixed static and dynamic
derivation strategies. Each entry fires independently when
its selector matches; the writes compose via the type-locked
join; the running label widens monotonically over the
session. The IFC story for one source can therefore be split
across several populator entries on the same variable — a
conservative static minimum plus a precise dynamic refinement,
or a fan-out populator covering a glob of related sources
plus per-source overrides for specific cases. The proof's
operational semantics handles all of these as the same
admitted transition: one call, one `ω_s(v)`, one join into
`E`.

### 2.3 Trace events

An agent execution is a sequence of events.

- `invoke(s, a) / return(v)`. A tool, endpoint, or sub-agent call
  that has succeeded, with arguments `a` and result `v`.
- `invoke(k, a) blocked`. An attempted call whose call-site gate
  failed.
- `internal(α, V_in, V_out, Γ_α)`. An LLM-internal step or
  host-side transformation that consumes a multiset of input
  values `V_in ⊆ π`, produces a multiset of output values `V_out`,
  and assigns labels `Γ_α : V_out → L` per the closure rule of
  §2.5.
- `egress_user(a)`. The agent emits an answer `a` to the user
  (admitted iff the user-output gate holds).
- `declassify(δ, ℓ′, V_in, V_out)`. Invocation of a registered
  declassifier `δ` lowering the running exposure to `ℓ′` and
  releasing values `V_out` derived from `V_in` per `δ`'s release
  function.
- `reset`. A scope-boundary event that resets the running exposure
  to `⊥` and (only when TC-3 holds) the agent context.

### 2.4 State

State is a triple `σ = (E, π, Γ)`.

- `E ∈ L` is the running exposure (a tag set).
- `π` is an abstract over-approximation of the information that
  may influence future agent observable behaviour. `π` is not a
  literal token buffer or context window. The runtime cannot
  observe the LLM's internal state directly. `π` is a
  soundness-preserving over-approximation: any data the agent has
  read remains in `π` until removed by a registered declassifier
  or a scope reset. Token eviction, summarization, prompt
  compression, and host-side memory rewrites do not shrink `π`,
  because the runtime cannot verify what information was actually
  removed. Only `declassify(δ, ℓ′, ·, ·)` (under TC-5) and `reset`
  (under TC-3) shrink `π`.
- `Γ : V → L` is a ghost labelling that, for every value `v ∈ π`,
  records the tag set assigned to `v` at the moment it entered
  `π`. `Γ` is not materialised in the runtime. It exists only to
  state the invariant in §4.1.

Initial state: `E = ∅`, `π = ∅`, `Γ = ∅`.

### 2.5 Operational semantics

| Transition | Pre-condition | Post-condition |
|------------|---------------|----------------|
| `invoke(s, a) / return(v)` admitted | `E ⊆ μ(s)` | `E′ = E ∪ λ(s)`; `π′ = π ∪ {v}`; `Γ′ = Γ[v ↦ E′]`; observable iff `ν(s) ⊆ μ_obs` |
| `invoke(k, a) blocked` | `E ⊄ μ(k)` | `E′ = E`; `π′ = π`; no observable (TC-6) |
| `internal(α, V_in, V_out, Γ_α)` | `V_in ⊆ π` | `E′ = E`; `π′ = π ∪ V_out`; `Γ_α(v_out) = E` for every `v_out ∈ V_out`; `Γ′ = Γ ∪ Γ_α` |
| `egress_user(a)` admitted | `E ⊆ μ(user_output)` | `E′ = E`; `π′ = π`; observable (`ν(user_output) = ∅` makes it universally low-observable) |
| `egress_user(a)` blocked | `E ⊄ μ(user_output)` | `E′ = E`; `π′ = π`; no observable |
| `declassify(δ, ℓ′, V_in, V_out)` | `δ ∈ TrustedDeclassifiers` ∧ `ℓ′ ⊆ E` ∧ release contract holds (TC-5) ∧ context-replacement set `V_replaced ⊆ π` exists with `Γ(v) ⊆ ℓ′` for every `v ∈ π \ V_replaced` | `E′ = ℓ′`; `π′ = (π \ V_replaced) ∪ V_out`; `Γ′(v_out) = ℓ′` for `v_out ∈ V_out`; `Γ′ = Γ` on `π \ V_replaced` |
| `reset` | host capability `supports_context_reset` is set (TC-3) | `E′ = ∅`; `π′ = ∅`; `Γ′ = ∅` |

The bundled `invoke / return` transition encodes the duality
between reads and writes: a tool call is itself an egress (the
agent sends arguments to the tool) and a tool result is the
read that follows. The call-site gate `E ⊆ μ(s)` runs on the
agent's outbound arguments. On success, the source's label
`λ(s)` joins into the exposure and the return value enters `π`.
The conservative return-label rule `Γ′(v) = E′` reflects that
the runtime cannot verify whether the source's return value
depends only on `λ(s)` or also on the supplied arguments and
hidden state. Assigning the join is the safe over-approximation.

The `internal` transition's conservative derivation rule
(`Γ_α(v_out) = E` for every internally-derived `v_out`) is the
formal counterpart of the statement that the LLM may recombine
known values, hidden state, training data, or hallucinated
content internally, and the runtime cannot inspect which subset
of `π` an output depends on. Since `E` is by `I` an upper bound
on every label in `π`, attributing every derived value to `E`
is sound and makes `π` well-defined under agent-internal
computation.

### 2.6 Possibilistic noninterference

The LLM is a nondeterministic transducer. Given a context `π` it
may produce any of a set of outputs (sampling, temperature, hidden
state, time-of-day clocks, model version drift). A single
configuration `C` together with an input sequence `τ_in` (the
sequence of values returned at each source-read site) induces a
*set* of possible traces `Traces(C, τ_in)`, not a single
deterministic trace.

Adopt **possibilistic noninterference** (Sutherland 1986;
Sabelfeld and Myers 2003 §3.2). Define

```
LowProj(C, τ_in)  :=  { τ|_obs  :  τ ∈ Traces(C, τ_in) }
```

the set of low-observable trace-projections realisable for `C`
under input sequence `τ_in`. Two input sequences `τ_in, τ_in'`
agree on low reads iff at every source-read site `i` either
both produce the same value, or `λ(sᵢ) ⊄ μ_obs` (i.e., `i` is a
high-read site). The CGNI definitions in §3 are stated as
equality of `LowProj` sets across pairs of low-equivalent input
sequences. The relation is biconditional: if some low-observable
projection `p` is realisable in `τ_in`, the same `p` must be
realisable in `τ_in'`, and conversely.

This is not probabilistic NI. Probabilistic NI requires equal
*distributions* of low projections. The opaque-LLM threat model
prohibits modeling those distributions.

## 3. Security property

### 3.1 Observer model

Let `μ_obs ∈ L` be the observer's clearance: the maximum tag set
the low attacker is allowed to learn. An admitted event `e` is
*low-observable* iff `e ∈ {invoke/return, egress_user}` and
`ν(target(e)) ⊆ μ_obs`. For `egress_user`,
`ν(user_output) = ∅ ⊆ μ_obs` always holds. The user is
universally observable.

The low attacker's view of a trace `τ` is the projection
`τ|_obs`: the subsequence of low-observable admitted events
together with their argument bundles `a` and (for
`invoke/return`) their return values `v`. The attacker does not
see blocked events, internal transitions, declassification
events (except as their outputs flow into admitted egresses),
timing, retries, log entries, or any internal runtime state.

### 3.2 Pure CGNI

**Definition (Pure CGNI).** A configuration `C` whose runtime
traces contain no `declassify` events satisfies pure CGNI iff for
every two input sequences `τ_in, τ_in'` that agree on low reads:

```
LowProj(C, τ_in)  =  LowProj(C, τ_in')                            (1)
```

The set of possible low-observable projections is independent of
the data read at high source sites.

### 3.3 CGNI modulo δ

For configurations whose traces may contain
`declassify(δ, ℓ′, V_in, V_out)` events, pure CGNI cannot hold:
declassification is a controlled leak. Weaken (1) to permit the
leaks the registered declassifiers explicitly authorise.

For each registered declassifier `δ` the designer supplies:

- a release function `ρ_δ : (V_in, ℓ′) → V_out` that maps an
  input multiset of values and a target level to an output
  multiset;
- an explicit assertion that `ρ_δ` depends only on the
  designer-authorised projection of `V_in` at level `ℓ′`.

Define **release-equivalence** on low projections:
`τ|_obs ≈_R τ'|_obs` iff the projections are equal as
subsequences except possibly at admitted egress events whose
argument or return components are values in `Δ(σ_at_event)` for
the respective execution. At those positions the projections may
differ arbitrarily. The relation does not constrain how they
differ. The semantic content of the difference is delegated to
the registered `ρ_δ`. The provenance set `Δ` is defined formally
in §4.5.1.

**Definition (CGNI modulo δ).** A configuration `C` satisfies
CGNI modulo δ iff for every two input sequences `τ_in, τ_in'`
agreeing on low reads:

```
LowProj(C, τ_in)  ≈_R^set  LowProj(C, τ_in')                      (2)
```

where `≈_R^set` lifts `≈_R` to sets: every projection in
`LowProj(C, τ_in)` has a release-equivalent counterpart in
`LowProj(C, τ_in')`, and conversely. The set of possible
low-observable projections is identical up to the explicit,
authorised release of registered declassifiers.

## 4. Proof

### 4.1 Runtime invariant

**Invariant (I).** At every reachable state `(E, π, Γ)`:

```
∀ v ∈ π :  Γ(v) ⊆ E
```

Every value currently in the LLM context has been read or
derived from sources whose labels are included in the running
exposure.

### 4.2 Argument-dependency lemma

**Lemma (Args).** For every reachable state `(E, π, Γ)` and
every value `a` whose construction is a function of values in
`π`, define `Γ̂(a) := ⊔_{v ∈ deps(a)} Γ(v)` where
`deps(a) ⊆ π` is the multiset of values contributing to `a`.
Then `Γ̂(a) ⊆ E`.

*Proof.* By invariant `I`, every `v ∈ deps(a) ⊆ π` has
`Γ(v) ⊆ E`. The join of a finite collection of subsets of `E`
is a subset of `E` (`L = 2^T` is closed under `∪`). Hence
`Γ̂(a) = ⊔ Γ(v) ⊆ E`. ∎

The Args lemma is what justifies the call-site gate. The gate
checks `E ⊆ μ(s)`, which by Args implies `Γ̂(a) ⊆ μ(s)` for any
argument bundle `a` derived from `π`.

### 4.3 Lemma 1: invariant preservation

**Lemma 1.** Invariant `I` is preserved by every transition in
§2.5.

*Proof.* Case-split on the transition rule.

- `invoke(s, a) / return(v)` admitted. Pre-state satisfies `I`.
  The gate gives `E ⊆ μ(s)` and by Args `Γ̂(a) ⊆ E ⊆ μ(s)`.
  Post-state has `E′ = E ∪ λ(s)`, `π′ = π ∪ {v}`,
  `Γ′ = Γ[v ↦ E′]`. For `v′ ∈ π`:
  `Γ′(v′) = Γ(v′) ⊆ E ⊆ E′`. For `v` itself:
  `Γ′(v) = E′ ⊆ E′`. Both cases satisfy `I`.

- `invoke(k, a) blocked` and `egress_user(a)` admitted or
  blocked. `E′ = E`, `π′ = π`, `Γ′ = Γ`. `I` is preserved
  trivially.

- `internal(α, V_in, V_out, Γ_α)`. `E′ = E`,
  `π′ = π ∪ V_out`, `Γ′ = Γ ∪ Γ_α`. For existing `v ∈ π`:
  unchanged, satisfies `I`. For new `v_out ∈ V_out`:
  `Γ′(v_out) = Γ_α(v_out) = E = E′`. `I` is preserved trivially
  under the conservative derivation rule.

- `declassify(δ, ℓ′, V_in, V_out)`. Pre-condition gives
  `ℓ′ ⊆ E` and the TC-5 axiom: a host-supplied
  context-replacement set `V_replaced ⊆ π` exists such that every
  `v ∈ π \ V_replaced` has `Γ(v) ⊆ ℓ′`. Post-state has
  `E′ = ℓ′`, `π′ = (π \ V_replaced) ∪ V_out`, with
  `Γ′(v_out) = ℓ′` for `v_out ∈ V_out` and `Γ′(v) = Γ(v)` for
  `v ∈ π \ V_replaced`. By TC-5, every `v ∈ π \ V_replaced` has
  `Γ(v) ⊆ ℓ′ = E′`, satisfying `I` for retained values. New
  values `v_out ∈ V_out` have `Γ′(v_out) = ℓ′ = E′`, satisfying
  `I`. The replaced values `V_replaced` are no longer in `π′`,
  so the universal claim is vacuously satisfied for them.
  Invariant preserved modulo TC-5.

- `reset`. `E′ = ∅`, `π′ = ∅`, `Γ′ = ∅`. The invariant
  `∀ v ∈ ∅ : Γ′(v) ⊆ ∅` is vacuously true. Requires TC-3.

So `I` is maintained at every step modulo TC-3 and TC-5. ∎

### 4.4 Theorem 1: Pure CGNI

**Theorem 1.** Under invariant `I`, possibilistic semantics, and
side conditions (TC-1) through (TC-10), the runtime satisfies
pure CGNI for configurations whose traces contain no `declassify`
events. The guarantee holds within a single fixed-model,
fixed-tool-state window per TC-10; comparisons across model or
tool-state changes are not within scope.

*Proof.* By bisimulation. Define a low-equivalence relation on
states:

```
(E₁, π₁, Γ₁)  ~_low  (E₂, π₂, Γ₂)
   ⟺   E₁ = E₂
        ∧  for every v ∈ π₁ with Γ₁(v) ⊆ μ_obs,  v ∈ π₂ ∧ Γ₂(v) = Γ₁(v)
        ∧  for every v ∈ π₂ with Γ₂(v) ⊆ μ_obs,  v ∈ π₁ ∧ Γ₁(v) = Γ₂(v)
```

Two states are low-equivalent iff they have the same exposure
and their low projections of `π` are pointwise-identical. High
values in either `π` may differ arbitrarily.

We argue the four bisimulation properties.

(B1) **Initial states are `~_low`-related.** Both initial states
have `E = ∅`, `π = ∅`, `Γ = ∅`. Trivially related.

(B2) **`~_low` is preserved by every transition under
low-equivalent inputs.**

  *Read at low-label source `s` (`λ(s) ⊆ μ_obs`).* By TC-9,
  `λ(s) ⊆ ν(s)`, so `ν(s)` may be either `⊆ μ_obs` (the source
  is also low-observable) or `⊄ μ_obs` (the source is
  high-observable but its data is low). In both sub-cases the
  read produces the same value `v` across executions because
  the input sequences agree on low reads. Both states raise
  `E` to `E ∪ λ(s)` and label `v` as the new
  `E′ = E ∪ λ(s)`. Since `E` is identical and `λ(s)` is fixed
  by the configuration, the new label is identical in both
  executions.

  Sub-case `ν(s) ⊆ μ_obs`: the invocation event is in the low
  projection. The gate gives `E ⊆ μ(s)` and TC-8 gives
  `μ(s) ⊆ ν(s)`; combined with `ν(s) ⊆ μ_obs` we have
  `E ⊆ μ(s) ⊆ ν(s) ⊆ μ_obs`. Combined with `λ(s) ⊆ μ_obs` (this
  sub-case), `E′ = E ∪ λ(s) ⊆ μ_obs`. So `v` joins the low
  projection pointwise-identically and the projected event
  extends both projections identically. Relation preserved.

  Sub-case `ν(s) ⊄ μ_obs`: the invocation event is not in the
  low projection (high audience). The read still happens. Both
  states label `v` as `E′ = E ∪ λ(s)`, identical across
  executions. Sub-cases on prior `E`: if pre-read `E ⊆ μ_obs`,
  `v` is low (label `⊆ μ_obs`) and joins the low projection of
  `π` pointwise-identically across executions; if pre-read
  `E ⊄ μ_obs`, `v` is high and joins the high projection.
  Either way the bisimulation invariant on the low projection
  of `π` is preserved.

  *Read at high-label source `s` (`λ(s) ⊄ μ_obs`).* By TC-9,
  `λ(s) ⊆ ν(s)`, so `ν(s) ⊄ μ_obs`. This case is always
  high-observable. The invocation event is not in either
  projection. Inputs may differ. Both states raise `E` to
  `E ∪ λ(s)` (identical), label the new `v` as the new
  `E′ ⊃ λ(s) ⊄ μ_obs` (so `v` is in the high projection), and
  add `v` to `π`. Values may differ; low projection of `π` is
  unchanged. Relation preserved.

  *Internal transition.* By the conservative derivation rule
  (§2.5), every derived value `v_out` carries label `E`. Since
  `E` is identical in both bisimilar states, the partition of
  `π` into low projection (values with label `⊆ μ_obs`) and
  high projection (values with label `⊄ μ_obs`) is determined
  by `E` alone. If `E ⊆ μ_obs`, derived values join the low
  projection; the values themselves must agree pointwise across
  executions. By TC-10, the LLM's possibility set on identical
  low inputs is identical, so possibilistically the same
  derived values are realisable in both executions. If
  `E ⊄ μ_obs`, derived values join the high projection; they
  need not agree.

  *Admitted invoke/return.* The gate `E ⊆ μ(s)` is identical in
  both states (`E` identical). For low-observable invocations
  (`ν(s) ⊆ μ_obs`): by TC-8, `μ(s) ⊆ ν(s) ⊆ μ_obs`; by TC-9,
  `λ(s) ⊆ ν(s) ⊆ μ_obs`. The conservative return-label rule
  assigns `Γ′(v) = E ∪ λ(s) ⊆ μ_obs`, so `v` is in the low
  projection. By Args and the bisimulation hypothesis, `a` is
  pointwise-identical across executions. By TC-10, the
  source's nondeterminism is parameterised by `a` and the
  source's own state only, so the possibility set of `v` is
  identical in both. Possibilistically, the same admitted
  invoke/return event with identical `a` and the same
  possibility-set of `v` appears in both projections. Low
  projections are extended identically.

  For high-observable invocations (`ν(s) ⊄ μ_obs`): the event
  is not in either projection. Either `μ(s) ⊄ μ_obs` or
  `λ(s) ⊄ μ_obs`, giving `E′ = E ∪ λ(s)` possibly `⊄ μ_obs`.
  `v` may be in the high projection of `π` and need not agree.

  *Blocked invoke.* Not in either projection. `(E, π, Γ)`
  unchanged. Relation preserved.

  *Admitted egress_user.* `ν(user_output) = ∅ ⊆ μ_obs`, always
  low-observable. Gate `E ⊆ μ(user_output)` identical. By
  Args and the low-projection hypothesis, `a` is
  pointwise-identical. Same admitted event in both projections.

  *Blocked egress_user.* Not in either projection. Relation
  preserved.

  *Reset.* Both states reset identically. Trivially related.

(B3) **Bisimilar states produce identical sets of low-observable
events.** From (B2), every transition that produces a
low-observable event produces the same event in both bisimilar
states. Conversely, a transition that produces no low-observable
event produces no contribution to either projection.

(B4) **`LowProj(C, τ_in) = LowProj(C, τ_in')`.** From (B1)
through (B3) the two executions remain bisimilar throughout, so
their low projections are the same set of possibility-sequences.
∎

### 4.5 Theorem 2: CGNI modulo δ

**Theorem 2.** Under the conditions of Theorem 1 plus the
release-contract axiom (TC-5) for every registered declassifier,
the runtime satisfies CGNI modulo δ for configurations whose
traces may contain `declassify` events.

#### 4.5.1 Formal provenance

Define the declassifier-provenance state `Δ : State → 𝒫(V)` as
a state-dependent set tracked alongside the bisimulation. `Δ(σ)`
is the subset of `π` whose values are causally derivable from
registered declassifier outputs at any point in the prefix
leading to `σ`.

`Δ` is updated alongside each transition by the following rules:

| Transition | Δ update |
|------------|----------|
| `invoke(s, a) / return(v)` admitted | `Δ′ = Δ ∪ {v}` if `deps(a) ∩ Δ ≠ ∅`, otherwise `Δ′ = Δ` |
| `internal(α, V_in, V_out, ·)` | `Δ′ = Δ ∪ V_out` if `Δ ≠ ∅`, otherwise `Δ′ = Δ` |
| `declassify(δ, ℓ′, V_in, V_out)` | `Δ′ = (Δ ∩ (π \ V_replaced)) ∪ V_out` |
| `reset` | `Δ′ = ∅` |
| any other transition | `Δ′ = Δ` |

The `internal` rule is the conservative reading under
opaque-LLM semantics: once any `Δ`-value exists in `π`, every
subsequent internal output is potentially `Δ`-influenced. The
runtime cannot verify which subset of `π` an internal step
actually used. This over-approximates `Δ` and is sound.

#### 4.5.2 Release-equivalence

Two low projections `τ₁|_obs, τ₂|_obs` are release-equivalent,
written `τ₁|_obs ≈_R τ₂|_obs`, iff they are equal as subsequences
except possibly at admitted-egress positions where the differing
components (in `a` or `v`) are values in `Δ(σ_at_event)` for the
respective execution. At those positions the projections may
differ arbitrarily.

#### 4.5.3 Proof

*Proof of Theorem 2.* Extend the bisimulation `~_low` of
Theorem 1 to a relation `~_R` that tracks `Δ`-membership in
addition to label and exposure equivalence:

```
(E₁, π₁, Γ₁, Δ₁)  ~_R  (E₂, π₂, Γ₂, Δ₂)
   ⟺   E₁ = E₂
        ∧  for every v ∈ π₁ with Γ₁(v) ⊆ μ_obs and v ∉ Δ₁:
              v ∈ π₂ ∧ Γ₂(v) = Γ₁(v) ∧ v ∉ Δ₂
        ∧  symmetric for π₂
        ∧  no constraint on values in Δᵢ
```

Argue (B1') through (B4') by analogy with Theorem 1.

(B1') Initial states are `~_R`-related (`Δ` empty initially;
reduces to `~_low`).

(B2') `~_R` is preserved by every transition.

  *Read at low source (low-observable).* Two sub-cases on
  whether `deps(a) ∩ Δ ≠ ∅`. If empty: the Theorem 1 argument
  applies directly. `a` agrees pointwise across executions, the
  source's possibility set on identical inputs is identical,
  `v` agrees pointwise possibilistically, and `v ∉ Δ′`. The
  non-`Δ` portion of the low projection is extended
  pointwise-identically. If non-empty: `v ∈ Δ′` by the
  provenance rule. The bisimulation tolerates arbitrary
  differences in `v` because `v ∈ Δ′`. `Δ` is updated
  identically (both gain `v`). Relation preserved.

  *Read at high source.* Identical to Theorem 1; `v` is in the
  high projection regardless of `Δ`-membership. `Δ` updates by
  provenance rule.

  *Internal transition.* Under the conservative `Δ`
  propagation rule: if pre-state `Δ ≠ ∅`, the new `V_out` is
  added to `Δ′` in both executions; values may differ but lie
  in `Δ`. If pre-state `Δ = ∅`, the Theorem 1 argument applies:
  the LLM's possibility set on identical low inputs is
  identical (TC-10), so derived low values agree pointwise
  possibilistically. Relation preserved.

  *Admitted egress to user.* Identical to Theorem 1 if
  `deps(a) ∩ Δ = ∅`; admits release-difference if
  `deps(a) ∩ Δ ≠ ∅`, which is exactly the relaxation `≈_R`
  permits.

  *`declassify(δ, ℓ′, V_in, V_out)`.* By TC-5,
  `V_out = ρ_δ(V_in, ℓ′)`. The runtime cannot inspect `V_out`.
  The two executions may produce different `V_out` because
  their `V_in` may differ in high components. Both states
  transition to `π′ = (π \ V_replaced) ∪ V_out` (host supplies
  `V_replaced`), and
  `Δ′ = (Δ ∩ (π \ V_replaced)) ∪ V_out`. Values removed by
  context replacement leave both `π` and `Δ`; new
  declassifier outputs enter both. The bisimulation tolerates
  arbitrary differences in `V_out`. `E′ = ℓ′` identically.
  Relation preserved.

  *Reset.* Both states reset identically, including
  `Δ′ = ∅`. Trivially related.

(B3') Bisimilar states under `~_R` produce release-equivalent
low projections.

(B4') `LowProj(C, τ_in) ≈_R^set LowProj(C, τ_in')`. ∎

Theorem 2 does not establish what the registered declassifiers
actually release. The runtime admits any `ρ_δ` the deployment
registers. If the deployment registers `ρ_δ = identity` (a
"declassifier" that simply lowers exposure without transforming
the data), Theorem 2 still holds, but the deployment has chosen
to leak everything at that boundary. Theorem 2 says: the runtime
correctly enforces the designer's stated release policy. The
soundness of the release policy itself is the designer's
obligation under TC-5.

#### 4.5.4 Composition of declassifiers

If a deployment registers two declassifiers `δ₁, δ₂` whose
outputs can flow into one another (a `δ₁`-derived value reaches
`δ₂`'s `V_in`), the composed release function `ρ_{δ₂} ∘ ρ_{δ₁}`
is not automatically safe. Theorem 2 holds for the composed
pipeline as written. Values flow through `Δ` regardless of how
many declassifiers participated. The semantic content of the
release is whatever the composed function happens to compute,
which may exceed the designer's intent.

The runtime cannot detect this. Composition safety is a
property of the registered declassifier set, evaluated in audit.
Theorem 2 does not prove composition safety. A deployment
seeking formal anti-laundering should constrain its registered
set: forbid `δ₁`-outputs from reaching `δ₂`'s `V_in` unless the
composite is explicitly registered with its own release
contract; structure declassifiers as a forest with no shared
downstream joins; or allow at most one declassification per
scope.

The runtime's mitigations are operational, not formal:

- Every `declassify(δ, ℓ′, V_in, V_out)` invocation emits a
  `variable.<name>.declassified` audit event (Specification
  §9.3, severity `critical`) carrying the variable identity,
  the prior label, and the reason text declared on the
  future `reset_by:` entry (runtime support deferred).
- Declassifiers fire only from named guard-policy actions at
  fixed lifecycle boundaries. No expression or host code can
  declassify out-of-band.
- The set of registered declassifiers is the audit boundary.

### 4.6 Side conditions

The proofs above are valid iff all of the following hold. Each
is a non-trivial assumption that must be enforced operationally.
The runtime validates as many as possible at config-load time
and through complete-mediation wrapping at runtime; some are
inherently outside the runtime's reach.

**(TC-1) Trusted base for `λ`, `μ`, and `ν`.** All three policy
functions are bound at config-merge time and are read-only
thereafter. The runtime enforces this through five load-time
checks on the label-typed variables that realise `λ`, `μ`, and
`ν` (§2.2):

- The `members:` of every `type: level` variable and the
  `vocabulary:` of every `type: compartment` variable are
  declared once and are immutable across `extends:` chains
  (Specification §10.9). The set `T` cannot be enlarged or
  shrunk after config-merge.
- Specification §10.5.5 rejects any `populated_by:` `value:`
  that names a tag outside the variable's vocabulary, ensuring
  every label appearing in `λ` lies in the closed universe `T`.
- Specification §10.2 forbids `update:` blocks on label-typed
  variables, ruling out expression-driven mutation of the
  population values that realise `λ`. This is the load-time
  check that carries TC-1 \u2014 without it, an `update:` block
  could reshape `λ` at runtime.
- Specification §11.5 syntactically rejects resolver writes
  (`on_demand_by:`, resolver `set_variables:`) on label-typed
  variables. This is *defense in depth*, not a TC-1 requirement
  \u2014 resolver definitions are themselves bound at config-merge,
  and a resolver writing through the type-locked join would
  preserve `λ`-boundedness as well as a populator does. The
  prohibition exists because mixing the populator surface
  (exposure accounting, type-locked join, fires on every
  invocation) with the resolver surface (one-shot authorization,
  last-write-wins, fires on demand) on a single variable opens
  configuration-level footguns that the loader closes by
  construction. See `information-flow-control.md` §11a for the
  enumeration.
- Guard-policy `allowed_when:` clauses that realise `μ(k)` and
  `ν(k)` reference label-typed variables only on their
  right-hand side; the policy engine never writes them, so `μ`
  and `ν` are read-only.

TC-1 fixes the **function shape** — the populator entry's
expression body, the policy's `allowed_when:` body, the
variable's `members:` (for `type: level`) or `vocabulary:`
(for `type: compartment`), the `extends:`-chain identity of
the variable, and the writing surface available to those
bodies — at config-merge time. It does NOT require the *value*
produced
by evaluating those bodies to be fixed at config-merge time:
dynamic `expression:` populators legitimately read the
call's return envelope (`@result.*`), and `allowed_when:`
clauses legitimately read call-bound parameters
(`@tool.params.*`). The per-call evaluation of `λ` and `μ`
is normative behaviour and is formalised in §2.2.1; the
fail-closed escalations of Specification §10.5.4 / §10.5.5
and the null-as-false rule of LANGUAGE.md §3.3 keep those
per-call evaluations within the type-locked lattice.

**(TC-2) Complete mediation.** Every value entering `π` does so
through an `invoke / return` event whose `λ(s)` is correctly
known and joined into `E`, or through an `internal` event whose
closure rule assigns labels per §2.5. Every value leaving `π`
to the world does so through an event gated against the
appropriate `μ`. The runtime enforces this by wrapping tool
calls, endpoint calls, sub-agent calls, and the user-output
channel with check-then-call-then-raise primitives executed
atomically. Hosts must use the wrapped surface. Out-of-band
tool execution is a contract violation that voids the
guarantee.

**(TC-3) Reset implies context wipe; only available when host
advertises capability.** `reset` requires `π′ = ∅`. The runtime
cannot verify this directly. It relies on a host capability
declaration `supports_context_reset: true` set at runtime build
time. The default `lifetime:` for label-typed variables is
`per_session` (no mid-session reset). Configurations declaring
`lifetime: per_turn` or `lifetime: per_request` on a label-typed
variable are rejected at config-load time unless the host has
set `supports_context_reset`. This is an enforced check.

**(TC-4) Explicit-flow attacker only.** The proofs bound
explicit data flow through `π`. They say nothing about implicit
flows: timing channels, control-flow channels, training-time
leakage, model probing, or learned associations the LLM may
have absorbed before the configured policy took effect.

**(TC-5) Trusted declassification with release contracts and
context replacement.** The pre-condition `ℓ′ ⊆ E` ensures
declassification can only relax. Release functions (`ρ_δ`) are
designer-supplied invariants. Critically, declassification
*lowers `E`* but the runtime cannot directly remove the
original high values from `π` (the LLM's context is opaque).
For invariant `I` to hold post-declassification, the registered
declassifier must operationally replace or remove the high
portion of `π`, typically by host-supplied context replacement
(the LLM's history is rewritten so the secret is replaced by
the redacted summary). Without this discipline, declassify
lowers `E` but the high content remains in `π` and TC-5 is
vacuously violated. Subsequent low-observable egresses may then
leak the residual high data even though the gate passes. The
runtime registers each declassifier by name and treats both the
release function and the context-replacement discipline as TCB
axioms. It emits audit events per invocation. Composition of
declassifiers is not automatically safe (§4.5.4).

**(TC-6) Observer model excludes side channels.** The CGNI
definitions count only admitted events with low audience labels.
Real attackers may infer information from blocked attempts
(timing, retry behaviour, out-of-band log access). These are
out of scope. Operational deployments that care about side
channels must deploy additional measures.

**(TC-7) All sinks fail closed by default.** Totality of the
egress gate — that every sink `k` is covered by at least one
**pre-call** guard policy whose `allowed_when:` clause realises
`μ(k)` — is enforced at config-load time by the coverage check
(Specification §12.13). When a label-typed variable declares
`strict_resource_coverage:` with `mode: error` and a `stages:`
set drawn from `{ state_validation, tool_execution_validation }`,
the loader rejects any configuration whose `resources.tools[]`,
`resources.endpoints[]`, or `resources.agents[]` catalog
contains a resource not matched by a guard policy at one of
those stages that references the variable (Specification
§12.13's six checks). TC-2 (complete mediation) holds at any
pre-call stage because Stage 2 and Stage 3 are wrapped by the
same `check → call → raise` primitive; the verdict precedes the
side-effect either way.

A `stages:` set that includes `post_tool_validation` does NOT
satisfy TC-7 for any resource whose invocation produces an
external effect (an outbound message, a write to a system of
record, a sub-agent action). Stage 4 runs after the call
returns; by then the side-effect has already fired and the
gate's `block` verdict cannot prevent it. Stage 4 inclusion is
sound only for catalogs mechanically constrained to pure reads,
where the relevant flow is data entering `π` (the agent's
context) and Stage 4 redaction is the sink-side primitive. The
spec does not enforce this constraint structurally; including
`post_tool_validation` in `stages:` is an authoring obligation
that every covered resource is a pure read.

Configurations using `mode: warn` (or absent
`strict_resource_coverage:`) load with structured warnings
(`ifc_authoring` category, Specification §19) or no diagnostics,
but no enforcement; deployments that depend on the soundness
argument of this document MUST configure `mode: error` with a
pre-call `stages:` set on every label-typed variable, or the
totality argument below reduces to author discipline.

The Stage 5 (`output_validation`) user-channel egress clause —
the gate that blocks the agent's response when the running
exposure is non-empty (see `information-flow-control.md` §4) —
is **not** covered by `strict_resource_coverage:`. Stage 5 has
no resource catalog to iterate, so the omission of a Stage-5
clause cannot be detected the same way a missing per-resource
gate can. Authors MUST therefore write the Stage-5 clause
directly under `output_validation:` referencing the exposure
variable; its presence is an authoring obligation, and the
totality argument below depends on it even though no load-time
check enforces it.
Once totality is structural, a sink with no matching
`allowed_when:` clause denies egress when the running
exposure is non-empty: the covering guard policy's
`evaluate_when:` produces a failure signal and `allowed_when:`'s
subset check against an admit-set that does not include the
running exposure evaluates to `false`. Label-typed variables
compose this with the variable-engine fail-closed rules: the
`default:` field on the exposure variable is `[]` (= `⊥` = `∅`)
unless declared otherwise; populator failure on a label-typed
variable escalates the running label to the lattice top `T`
(Specification §10.5.4); and any populator `value:` outside
the declared `vocabulary:` fails config-load (Specification
§10.5.5). Authors must explicitly opt sinks into accepting
tagged data by writing an `allowed_when:` clause whose subset
check admits the relevant region of `T`. Admit-all
(`allowed_when: "true"`) is expressible but requires a
syntactically conspicuous policy entry visible to review; the
runtime does not provide a single-flag escape hatch for
default-top clearance.

**(TC-8) Audience-clearance compatibility for arguments.** For
every sink `k`, the runtime requires `μ(k) ⊆ ν(k)` at
config-load time. A sink cannot accept data tagged at a level
its audience is not cleared to learn. Where `ν(k)` is omitted,
the runtime defaults to `ν(k) = ∅` (publicly observable), which
forces `μ(k) = ∅` unless audience is declared explicitly.

**(TC-9) Audience-label compatibility for source effects.** For
every source `s`, the runtime requires `λ(s) ⊆ ν(s)` at
config-load time. A source cannot return data tagged at a level
the audience is not cleared to learn. The check covers both the
return value of the call and any side-effects of the call that
are observable at the same audience level (a tool that writes
to a public log when invoked: the tool's invocation is itself
observable to whoever sees the log, and the visible tag set is
bounded by `λ(s)`). Where a source has side-effects observable
at a lower audience than its return value (a tool whose log
entry is public but whose return value is high), authors must
split it into two resources or model it via a broader `ν(s)`.

**(TC-10) Fixed-transducer model with high-input-independent
entropy.** The proofs treat the LLM and every tool, sub-agent,
and endpoint as a fixed nondeterministic transducer for the
duration of the security analysis. Possibility sets must be
invariant under any two compared executions. All comparisons
between executions must lie within a single fixed-model,
fixed-tool-state window, with sampling entropy and any internal
nondeterminism independent of high inputs. Operationally: pin
model versions, ensure sampling entropy comes from a source
uncorrelated with high inputs, treat the LLM as a fixed
transducer for the duration of the analysis. Real deployments
using a remote LLM with continuous model updates do not
satisfy this strictly across update boundaries. The property
holds within any contiguous fixed-model window. Deployments
needing the formal guarantee against drift must pin to a
specific model snapshot.

## 5. Out of scope

The following properties are not claimed.

- **TINI.** Termination-insensitive noninterference is not
  proved. Blocked egresses are observable as "no event" only via
  timing or progress, which TC-6 excludes. Achieving TINI in
  this setting is not just future work: it requires reasoning
  about LLM termination behaviour, which the opaque-LLM
  assumption blocks.
- **Probabilistic NI.** Possibilistic NI is what is proved.
  Probabilistic NI requires modeling the LLM's output
  distribution. The opaque-LLM threat model prohibits this.
- **Integrity.** This is confidentiality-only IFC. Prompt
  injection that causes high-integrity actions is not addressed
  by this lattice. Use guard policies, classifiers, and
  predicates for integrity. Adding integrity labels (a second
  tag set per resource, dual to confidentiality) is genuine
  future work and is achievable. The model is not principally
  blocked by anything in the current design.
- **Implicit-flow soundness through the LLM.** The LLM may,
  through learned associations or training-time exposure, leak
  information that never explicitly entered `π` during this
  session. Bounded only by explicit flow and per-scope context
  retention. Tracking implicit flows through an opaque LLM is
  not achievable without changing the threat model.
- **Side-channel soundness.** Timing, retry behaviour,
  blocked-attempt observation. Out of scope. Achievable in
  closed environments with constant-time enforcement, but not
  achievable in any deployment that talks to remote LLM or tool
  APIs.
- **Declassifier-composition safety.** Theorem 2 holds for the
  registered set as given. Composition of declassifiers may
  launder secrets without the runtime detecting it. This is an
  audit concern. Composition safety is achievable as future
  work via constrained declassifier sets (see §4.5.4).
- **Soundness when (TC-1) through (TC-10) are violated.** Each
  side condition is load-bearing. A configuration that wires a
  label to a tool result, a host that bypasses the wrapped
  surface, or a per-turn scope without a host capability
  declaration all break the invariant and forfeit the
  guarantee.
- **Substitute for static analysis.** Compared to FlowCaml,
  Jif, or Paragon, this is a dynamic, coarse-grained monitor.
  It does not enforce program-counter labels or eliminate
  implicit-flow channels through host-side control flow.

Two of these properties (integrity, declassifier-composition
safety) are genuinely achievable as v2 work. The remaining four
(TINI, probabilistic NI, implicit-flow tracking, side channels)
are fundamental limits of running IFC over an opaque LLM. No
amount of host discipline or label-model enrichment recovers
them without changing the threat model.

## 6. Relation to the literature

The model is closest to LIO (Stefan, Russo, Mitchell, Mazières,
2011), specifically the "current label" component, generalised
from a Haskell process to an agent runtime. Agent Shield diverges
from LIO in that LIO labels values and propagates per-value
labels through computation; Agent Shield labels sources and sinks
and propagates a single running exposure. This is the
simplification justified by the project's algebraic premise: the
agent's context is, by construction, the join of its inputs, so
a single running label suffices when the LLM is opaque and all
reads and writes are mediated.

The choice of `2^T` as the carrier corresponds to the DLM-style
(Decentralised Label Model, Myers and Liskov, 2000) lattice when
restricted to confidentiality-only labels and a single principal
hierarchy. DLM's principal hierarchies and integrity dimension
are out of scope for v1.

The declassification model is delimited release (Sabelfeld and
Myers, 2003). Explicit release functions per declassifier,
enforced at named program points.

The honest framing (coarse dynamic no-write-down for mediated
agent effects) corresponds to what the recent agent-IFC
literature calls boundary-mediated IFC or interface-level IFC.
Weaker than program-level IFC. Stronger than no IFC at all. For
an opaque-LLM threat model with mediated side effects it is the
right cut: IFC inside the LLM is unreachable, but IFC at every
boundary the LLM crosses is enforceable.

## 7. Conclusion

Under the side conditions (TC-1) through (TC-10), the runtime
maintains invariant `I` and therefore satisfies pure CGNI
(Theorem 1) for configurations without declassification, and
CGNI modulo δ (Theorem 2) for configurations with registered
declassifiers. Theorem 2 establishes that the runtime correctly
enforces the designer's stated release policy. The soundness of
the release policy itself, including composition of
declassifiers, remains the designer's responsibility under
audit.

This is a defensible mathematical guarantee for this coarse,
explicit-flow, mediated-boundary, possibilistic-NI design. Two
of the deferred properties (integrity, declassifier-composition
safety) are achievable as v2 work and depend only on extending
the label model or constraining the declassifier registration
set. Four (TINI, probabilistic NI, implicit-flow tracking,
side-channel soundness) are not achievable in this setting:
they are fundamental limits of running IFC over an opaque LLM
that talks to external APIs.
