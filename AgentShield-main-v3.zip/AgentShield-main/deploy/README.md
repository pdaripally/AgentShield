# Deploying Agent Shield

> **Status — what ships today.** Agent Shield is an **in-process SDK** with one optional **out-of-process integration** (the LiteLLM Proxy guardrail, scoped to OpenAI-compatible chat traffic). It is **not** a generic HTTP gateway that fronts arbitrary backend routes, a standalone Kubernetes sidecar container, an official Docker image, or a Helm chart. See [Not currently shipped](#not-currently-shipped-roadmap) below for what is on the roadmap.

This directory documents the production-oriented deployment patterns that are actually runnable from this repository. Use them with the operator checklist in [`docs/PRODUCTION_DEPLOYMENT.md`](../docs/PRODUCTION_DEPLOYMENT.md).

## Deployment-surface status matrix

| Surface | Status | Coverage | Source |
|---|---|---|---|
| **In-process SDK** (Python, Node, .NET, Rust) — Patterns A / B / C | **Production-shipped** | All five stages, every framework adapter that ships in `sdk/<lang>/adapters/` | [`sdk/`](../sdk/) |
| **LiteLLM Proxy guardrail plugin** | **Production-shipped (out-of-process)** | OpenAI-compatible `/chat/completions` traffic routed through LiteLLM Proxy. Stage 5 runs in [buffer mode](../docs/integrations/litellm-proxy.md#streaming) when streaming is enabled. | [`sdk/python/agent_shield/integrations/litellm_proxy/`](../sdk/python/agent_shield/integrations/litellm_proxy/) |
| **Istio + SDK reference (kustomize)** | **Reference architecture** — not a transparent sidecar; requires an app image that **already** links the SDK in-process | Mesh-level mTLS, identity, OTel telemetry around an SDK-linked app | [`deploy/kubernetes/istio-sdk-reference/`](kubernetes/istio-sdk-reference/) |
| Standalone AgentShield Kubernetes sidecar (Envoy/iptables interception) | **Not shipped** — spec permits the shape, no binary yet | n/a | [`docs/roadmap/deployment-surfaces.md`](../docs/roadmap/deployment-surfaces.md) |
| Generic HTTP gateway / reverse-proxy fronting arbitrary `/chat` + `/tools/*` | **Not shipped** — LiteLLM Proxy plugin only mediates OpenAI-compatible chat | n/a | [`docs/roadmap/deployment-surfaces.md`](../docs/roadmap/deployment-surfaces.md) |
| Official Helm chart / Docker image (`ghcr.io/microsoft/agent-shield`) | **Not shipped** — depends on a gateway or sidecar landing first | n/a | [`docs/roadmap/deployment-surfaces.md`](../docs/roadmap/deployment-surfaces.md) |

The two "Production-shipped" rows are the *only* surfaces an operator can deploy from this repository without writing new code. The Istio reference is a kustomize bundle that pairs Istio with an application image *the customer builds and that already links the SDK in-process*; AgentShield does not ship a sidecar container, nor does it intercept traffic at the network layer.

## Current deployment surfaces (shipped today)

### 1. In-process SDK (primary surface)

The host application embeds the language binding (`agent_shield` for Python and Rust, `@microsoft/agent-shield` for Node, `Microsoft.AgentShield` for .NET) and routes every governed input, tool call, tool output, and final response through the SDK before it reaches the model, the tool, or the user. There is no separate Agent Shield process to deploy. Per-language entry-points:

- [`sdk/python/README.md`](../sdk/python/README.md)
- [`sdk/node/README.md`](../sdk/node/README.md)
- [`sdk/rust/README.md`](../sdk/rust/agent_shield/README.md)
- [`sdk/dotnet/README.md`](../sdk/dotnet/README.md)

Minimum-viable Python example (LangChain adapter):

```python
from agent_shield import Shield
import agent_shield.adapters.langchain  # side-effect import

shield  = Shield.from_yaml(".guardrails.yaml").with_langchain().with_client(my_llm).build()
guarded = shield.guard(my_agent)
result  = await guarded.ainvoke(user_input)
```

This intentional design removes a class of bypass paths (network hops, sidecar restarts, mesh misconfiguration) and keeps the `tool_call` → `tool_output` binding inside a single process boundary.

### 2. LiteLLM Proxy guardrail (out-of-process, OpenAI-compatible chat only)

If you already run [LiteLLM Proxy](https://docs.litellm.ai/docs/simple_proxy) as a centralised LLM gateway, you can enforce the same `.guardrails.yaml` at the proxy boundary for OpenAI-compatible `/chat/completions` traffic. This is the **only** out-of-process integration that ships today; it does **not** mediate arbitrary backend routes like `/tools/*` or app-specific endpoints — those still need in-process SDK integration. The integration source lives in [`sdk/python/agent_shield/integrations/litellm_proxy/`](../sdk/python/agent_shield/integrations/litellm_proxy/); the full setup guide is in [`docs/integrations/litellm-proxy.md`](../docs/integrations/litellm-proxy.md).

Minimum-viable wiring:

```bash
pip install agent-shield[litellm-proxy]
```

```python
# /etc/litellm/agent_shield_guardrail.py — shim required because LiteLLM resolves
# guardrail dotted paths against the config directory, not installed packages.
from agent_shield.integrations.litellm_proxy import (
    AgentShieldLiteLLMGuardrail,
    agentshield_guardrail,
)
```

```yaml
# /etc/litellm/litellm_config.yaml
guardrails:
  - guardrail_name: agent_shield
    litellm_params:
      guardrail: agent_shield_guardrail.AgentShieldLiteLLMGuardrail
      mode: ["pre_call", "post_call"]
      guardrails_path: /etc/agent-shield/guardrails.yaml
      default_on: true
```

### 3. Istio-on-Kubernetes reference for in-process SDK deployments

For Kubernetes deployments of agents that link the SDK **in-process**, this repository ships a kustomize-based reference that pairs the SDK with Istio for mesh-level mTLS, identity, and OTel telemetry:

- [`docs/istio-sdk-reference-architecture.md`](../docs/istio-sdk-reference-architecture.md) — narrative architecture, trust boundaries, threat model.
- [`deploy/kubernetes/istio-sdk-reference/`](kubernetes/istio-sdk-reference/) — kustomize manifests, Istio peer/destination policies, and a `setup-kind-istio.sh` smoke test that brings up a local `kind` cluster.

The bundle assumes your application image already links the Agent Shield SDK; it does **not** include an AgentShield sidecar container and does not intercept traffic. See [`deploy/kubernetes/istio-sdk-reference/README.md`](kubernetes/istio-sdk-reference/README.md) for the build-your-own-image step and test wiring.

## Not currently shipped (roadmap)

The following deployment surfaces are **not** available in this release. The full design sketch, severity, and one-paragraph spec per item live in [`docs/roadmap/deployment-surfaces.md`](../docs/roadmap/deployment-surfaces.md). To drive any of these forward, file an RFC against [microsoft/AgentShield](https://github.com/microsoft/AgentShield).

| Surface | Status | Tracking |
|---|---|---|
| Generic HTTP gateway / reverse-proxy that fronts arbitrary `/chat` + `/tools/*` backends | **Not shipped.** The LiteLLM Proxy integration only mediates OpenAI-compatible chat traffic. | [#16](https://github.com/microsoft/AgentShield/issues/16) (AIGateway/YARPy validation) and [`docs/roadmap/deployment-surfaces.md`](../docs/roadmap/deployment-surfaces.md) |
| Standalone AgentShield Kubernetes sidecar container (Envoy/iptables traffic interception) | **Not shipped.** | [`docs/roadmap/deployment-surfaces.md`](../docs/roadmap/deployment-surfaces.md) |
| Official Helm chart | **Not shipped.** Reference deployment uses raw kustomize manifests. | [`docs/roadmap/deployment-surfaces.md`](../docs/roadmap/deployment-surfaces.md) |
| Official Docker image (`ghcr.io/microsoft/agent-shield`) for a gateway/sidecar path | **Not shipped.** | [`docs/roadmap/deployment-surfaces.md`](../docs/roadmap/deployment-surfaces.md) |

If a customer use case requires one of the above today, the supported path is to embed the SDK in-process (option 1) or to route OpenAI-compatible traffic through LiteLLM Proxy with the bundled guardrail (option 2).
