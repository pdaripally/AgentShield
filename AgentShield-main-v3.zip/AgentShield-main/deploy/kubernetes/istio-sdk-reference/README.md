# Istio + SDK Reference Deployment

> [!IMPORTANT]
> **Scope.** This is an Istio-based reference deployment for applications that link the Agent Shield SDK **in-process**. It does **not** include an AgentShield sidecar container and does not intercept traffic. If you need traffic-interception sidecar deployment, an AgentShield reverse-proxy, or a Helm chart, those surfaces are **not currently shipped** — see [`docs/roadmap/deployment-surfaces.md`](../../../docs/roadmap/deployment-surfaces.md).

## What this bundle is

A kustomize bundle that deploys an agent service which already uses Agent Shield SDK adapters, fronted by Istio for mesh-level mTLS, identity, and OTel telemetry. The bundle is the production-oriented reference in this repository and is intended to be adapted, not copied blindly.

## Files

- `namespace.yaml`: namespace with Istio sidecar injection enabled.
- `guardrails-configmap.yaml`: `.guardrails.yaml` mounted into the app container.
- `deployment.yaml`: agent app deployment (build your own SDK-integrated image — see [Building an app image](#building-an-app-image)).
- `service.yaml`: ClusterIP service for the app.
- `peer-authentication.yaml`: STRICT mTLS for the namespace.
- `destination-rule.yaml`: `ISTIO_MUTUAL` service-to-service TLS policy.
- `kustomization.yaml`: apply all resources.
- `test.sh`: real-stack checks (sidecar, mTLS, allow/deny probes, Stage 2-4 checklist).

## Building an app image

This repository does **not** publish a prebuilt sample image. The `deployment.yaml` references the placeholder image `ghcr.io/your-org/agent-app:latest` — you must replace it with a container image of your own agent app that links the Agent Shield SDK in-process.

A common starting point is to containerise one of the in-tree demo agents (for example [`examples/agents/bank-manager`](../../../examples/agents/bank-manager/)) wrapped in a small HTTP server that exposes a `/health` endpoint and a `/chat` (or equivalent) endpoint. Minimal `Dockerfile` sketch:

```dockerfile
# build context = repo root
FROM python:3.12-slim
WORKDIR /app
COPY examples/agents/bank-manager/requirements.txt ./requirements.txt
RUN pip install --no-cache-dir -r requirements.txt
COPY examples/agents/bank-manager ./bank-manager
COPY tests/fixtures/smoke/minimal.guardrails.yaml /etc/agent-shield/.guardrails.yaml
# Replace this with whatever HTTP entrypoint you build around demo.py;
# the demo as shipped is a CLI script and does not expose /chat by itself.
CMD ["python", "-m", "bank-manager.server"]
```

Once built and pushed, replace the `image:` field in `deployment.yaml`:

```yaml
spec:
  template:
    spec:
      containers:
        - name: app
          image: registry.example.com/my-org/agent-app:v0.1.0
```

## Deploy

```bash
kubectl apply -k deploy/kubernetes/istio-sdk-reference
```

## Test

```bash
bash deploy/kubernetes/istio-sdk-reference/test.sh
```

Optional overrides:

```bash
NAMESPACE=agents SERVICE=agent-app PORT=8080 CHAT_PATH=/chat bash deploy/kubernetes/istio-sdk-reference/test.sh
```

The default `DENY_EXPECTED_REGEX` is `^(400|403|422)$` because the wire-level status returned for a denied request depends on how the host app surfaces the SDK verdict:

- **Hand-rolled HTTP layers** that map a guardrail deny to an authorisation failure typically return **`403`**.
- **LiteLLM Proxy** (and apps that mirror its shape) returns **`400`** when a guardrail rejects a request, because LiteLLM treats guardrail failures as malformed input.
- **Pydantic / FastAPI** validators sometimes surface a deny as **`422`**.

Tighten the regex to your app's actual contract — e.g., `DENY_EXPECTED_REGEX='^403$'` if you guarantee a 403, or `DENY_EXPECTED_REGEX='^400$'` if you front your agent with LiteLLM Proxy and rely on its native guardrail status code. The relevant overrides:

```bash
HEALTH_EXPECTED_REGEX='^2[0-9][0-9]$' \
ALLOW_EXPECTED_REGEX='^2[0-9][0-9]$' \
DENY_EXPECTED_REGEX='^(400|403|422)$' \
bash deploy/kubernetes/istio-sdk-reference/test.sh
```

If your deployment name differs from the service name:

```bash
DEPLOYMENT=agent-app-v2 \
APP_LABEL_SELECTOR='app.kubernetes.io/name=agent-app-v2' \
bash deploy/kubernetes/istio-sdk-reference/test.sh
```

`test.sh` writes the `kubectl port-forward` log to
`<script-dir>/agent_shield_pf.log` by default. Hardened workspaces that
forbid writes to `/tmp` (or CI runs that need to collect the log as an
artifact) can override the path via `AGENT_SHIELD_PF_LOG`:

```bash
AGENT_SHIELD_PF_LOG=/var/log/agent-shield/pf.log \
bash deploy/kubernetes/istio-sdk-reference/test.sh
```

## Notes

- Replace `ghcr.io/your-org/agent-app:latest` in `deployment.yaml` with your app image (see [Building an app image](#building-an-app-image)).
- Your app should expose a health route (`/health`) and a request route (`/chat` by default in `test.sh`).
- For stronger validation, include one route in your app that deterministically triggers a guarded tool call so Stage 2-4 behavior can be asserted in CI.
