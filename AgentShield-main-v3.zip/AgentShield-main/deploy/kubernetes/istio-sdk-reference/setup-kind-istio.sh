#!/usr/bin/env bash
set -euo pipefail

CLUSTER_NAME="${CLUSTER_NAME:-agentshield-istio}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

require_cmd kind
require_cmd kubectl
require_cmd curl

if ! command -v istioctl >/dev/null 2>&1; then
  echo "istioctl not found in PATH" >&2
  echo "install from https://istio.io/latest/docs/setup/getting-started/#download" >&2
  exit 1
fi

echo "Creating kind cluster: $CLUSTER_NAME"
kind create cluster --name "$CLUSTER_NAME" --image kindest/node:v1.30.0 || true

echo "Installing Istio via local istioctl"
istioctl install -y --set profile=demo

kubectl label namespace agents istio-injection=enabled --overwrite 2>/dev/null || true

echo "Applying reference manifests"
kubectl apply -k deploy/kubernetes/istio-sdk-reference

echo "Done. Run: bash deploy/kubernetes/istio-sdk-reference/test.sh"
