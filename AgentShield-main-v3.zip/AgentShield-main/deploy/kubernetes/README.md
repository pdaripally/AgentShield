# Agent Shield on Kubernetes

> **Status — what ships today.** Agent Shield is an **in-process SDK**. There is no standalone AgentShield container, sidecar, or Helm chart to deploy. The bundle in [`istio-sdk-reference/`](istio-sdk-reference/) is a reference deployment for applications that **already** link the Agent Shield SDK in-process. It does **not** ship an AgentShield sidecar container and does not intercept traffic with Envoy/iptables.

This directory documents production-oriented Kubernetes deployment patterns for SDK-integrated hosts.

To run a host agent that links the Agent Shield SDK on Kubernetes with mesh-level mTLS and identity, use the reference architecture:

- [`istio-sdk-reference/`](istio-sdk-reference/) — kustomize manifests, Istio peer/destination policies, and a `setup-kind-istio.sh` smoke test that brings up a local `kind` cluster with Istio installed and runs the reference deployment end to end.

See [`docs/istio-sdk-reference-architecture.md`](../../docs/istio-sdk-reference-architecture.md) for the narrative architecture, trust boundaries, and threat model.

A traffic-interception sidecar container, a generic HTTP gateway, and an official Helm chart are **not** shipped today — see [`docs/roadmap/deployment-surfaces.md`](../../docs/roadmap/deployment-surfaces.md).
