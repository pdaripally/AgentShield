# Changelog

All notable changes to Agent Shield are documented in this file.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/) once
the v1.0.0 spec freezes. While the spec is at `1.0.0-draft` and the SDKs
are pre-1.0, breaking changes may land in any release; each is called out
explicitly in the **Breaking changes** section below.

## [Unreleased]

### Breaking changes

- **Section 16.0 admission handles.** Stage 3 now returns a runtime-minted
  admission id and Stage 4 consumes that id exactly once. Host-provided
  `tool_call_id` values are observability-only and no longer participate in
  binding. Raw callers must migrate from `validate_tool_call(...);
  validate_tool_output(tool, result, tool_call_id)` to using the returned
  admission id. Legacy lookup helpers now raise `MissingAdmissionHandleError`
  (Python/Node) or `MissingAdmissionHandleException` (.NET) when no matching
  Stage-3 admission was observed; they never fabricate an id. `ToolAdmission`,
  `TurnRef`, `validate_tool_output_at`, and `validate_tool_output_for_turn`
  are removed. High-level `shield.guard(agent)` adapters handle the new
  lifecycle internally.

- **Python proxy surface removed.** The non-functional `agent_shield.proxy`
  package, the `[proxy]` extras, the `agent-shield-proxy` console
  script, the `deploy/docker/Dockerfile.proxy` image, and the K8s
  sidecar walkthrough in `deploy/README.md` and `docs/security-model.md`
  have been deleted. v1.0 conformance is in-process only; out-of-process
  deployment shapes (sidecars, gateways, supervising proxies) remain
  a future extension and are explicitly outside the v1.0 surface.

### Fixed

- **.NET native library now ships with bundled classifier providers.**
  The `cargo build` invocations in
  `sdk/dotnet/src/AgentShield/AgentShield.NativeLibrary.targets` and
  the `build-dotnet-native` job of `.github/workflows/publish.yml`
  previously omitted `--features`, so the shipped `agent_shield_core`
  library only enabled the `http` default feature. YAML referencing
  `provider: azure_content_safety` (or the other four bundled
  providers: `lakera_guard`, `llama_guard`, `openai_moderation`,
  `perspective`) failed at `Shield.FromYaml(...).Build()` with
  `classifier_wiring_missing — ... feature is disabled in this SDK
  build` even when the matching env var (e.g.
  `AZURE_CONTENT_SAFETY_KEY`) was set. The .NET build now enables the
  same five classifier features as the Python and Node native-library
  builds, restoring out-of-the-box parity for AACS and the other
  bundled providers.

### Notes

- This file was added so the `Changelog` URL declared in
  `sdk/python/pyproject.toml` resolves on PyPI.

