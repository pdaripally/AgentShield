# Agent Shield — Quickstart

Get running with Agent Shield from this repository. The fastest path is a framework adapter; use LiteLLM Proxy for OpenAI-compatible gateway enforcement; use the direct SDK for custom loops.

> Agent Shield ships today as an in-process SDK plus a LiteLLM Proxy guardrail. It is not a generic HTTP gateway, standalone Kubernetes sidecar, or Helm chart. See [`docs/roadmap/deployment-surfaces.md`](docs/roadmap/deployment-surfaces.md).

## 1. Prerequisites

- Python 3.11+, Node.js 20.19+, .NET 8 SDK+, or Rust 1.78+.
- A Rust toolchain for Python / Node / .NET native builds (`rustup`).
- Optional LLM key for LLM/classifier-backed policies; expression and regex policies need no key.

## 2. Install the SDK

Public registry packages are not live yet. Use a source install:

```bash
git clone https://github.com/microsoft/AgentShield.git
cd AgentShield
pip install -e sdk/python
pip install -e "sdk/python[langchain]"
pip install -e "sdk/python[autogen]"        # plus: pip install "autogen-agentchat" "autogen-ext[openai]"
pip install -e "sdk/python[crewai]"         # plus: pip install "crewai[azure-ai-inference]"
pip install -e "sdk/python[all]"
pip install -e "cli[openai]"                # optional policy designer
cd sdk/node && npm install && npm run build && npm run build:wrapper && cd ../..
```

For .NET, add `<ProjectReference>` entries under `sdk/dotnet/src/`; see [`sdk/dotnet/README.md`](sdk/dotnet/README.md). For Rust, use `git = "https://github.com/microsoft/AgentShield"` or local `path = ...`; see [`sdk/rust/agent_shield/README.md`](sdk/rust/agent_shield/README.md).

Local release artifacts also work:

```bash
pip install ./agent_shield-<version>-cp311-abi3-manylinux_2_34_x86_64.whl
npm install ./microsoft-agent-shield-<version>.tgz
dotnet nuget add source ./packages --name local
dotnet add package AgentShield --version <version> --source local
```

When public packages ship:

```bash
pip install agent-shield[langchain]
npm install @microsoft/agent-shield
dotnet add package AgentShield
```

```toml
agent_shield_core = { git = "https://github.com/microsoft/AgentShield", tag = "v<version>" }
```

## 3. Set up LLM credentials (optional)

```bash
export OPENAI_API_KEY="sk-..."
export ANTHROPIC_API_KEY="sk-ant-..."
export AZURE_OPENAI_ENDPOINT="https://<your-resource>.openai.azure.com"
export AZURE_OPENAI_API_KEY="<your-key>"
export AZURE_OPENAI_DEPLOYMENT="gpt-4o-mini"
export AZURE_OPENAI_API_VERSION="2024-12-01-preview"
```

## 4. Integrate with your framework

| Framework | Python entry point | Node / .NET / Rust entry point |
|---|---|---|
| LangChain | `shield.guard(agent)` | Node `shield.guard(agent)` |
| OpenAI Agents SDK | `shield.create_openai_agents_agent(...)` | Node `shield.runOpenaiAgent({...})` |
| Anthropic Agents SDK | `shield.create_anthropic_agents_agent(...)` | Node `shield.runAnthropicAgent({...})` |
| AutoGen | `shield.create_autogen_team(...)` | .NET `AgentShieldMiddleware` |
| CrewAI | `shield.protect_tools(...)` + `shield.guard_crew(crew)` | — |
| Semantic Kernel | `shield.create_semantic_kernel_agent(...)` | .NET `UseAgentShield(...)` |
| Rust Rig | — | `GuardedRigTool` + `run_rig` |

Python LangChain:

```python
from agent_shield import Shield
import agent_shield.adapters.langchain

shield = Shield.from_yaml(".guardrails.yaml").with_langchain().with_client(my_llm).build()
guarded = shield.guard(my_agent)
result = await guarded.ainvoke(user_input)
```

Node OpenAI Agents:

```typescript
import OpenAI from 'openai'
import { Shield } from '@microsoft/agent-shield'
import '@microsoft/agent-shield/adapters/openai_agents'

const shield = await Shield.fromYaml('.guardrails.yaml').withOpenaiAgents().build()
const text = await shield.runOpenaiAgent({
  client: new OpenAI(), model: 'gpt-4o-mini', tools, dispatchToolCall,
  messages: [{ role: 'user', content: 'user input' }],
})
```

Do not hand-roll streaming wrappers around `shield.run` / `Shield.RunAsync`; use a shipped streaming adapter, disable streaming, or buffer at LiteLLM Proxy. See [`docs/adapter-mediated-paths.md`](docs/adapter-mediated-paths.md).

## 5. Out-of-process integration (LiteLLM Proxy)

```bash
pip install -e "sdk/python[litellm-proxy]"
```

```python
# /etc/litellm/agent_shield_guardrail.py
from agent_shield.integrations.litellm_proxy import AgentShieldLiteLLMGuardrail
```

```yaml
guardrails:
  - guardrail_name: agent_shield
    litellm_params:
      guardrail: agent_shield_guardrail.AgentShieldLiteLLMGuardrail
      mode: ["pre_call", "post_call"]
      guardrails_path: /etc/agent-shield/guardrails.yaml
      default_on: true
```

With `post_call`, Stage 5 buffers streams to full-response latency. Full setup: [`docs/integrations/litellm-proxy.md`](docs/integrations/litellm-proxy.md).

## 6. Direct SDK integration

Use direct sessions for custom loops. Python smoke example:

```python
from agent_shield import RuntimeBuilder

runtime = RuntimeBuilder.from_yaml("tests/fixtures/smoke/minimal.guardrails.yaml").build()
with runtime.new_session(session_id="s-1", correlation_id="c-1") as session:
    session.begin_turn()
    assert session.validate_input("hello")
    blocked = session.validate_tool_call("echo", {"msg": "hi"})
    print(blocked.verdict.allowed, blocked.verdict.reason)
    session.set_variable("authorized", True)
    allowed = session.validate_tool_call("echo", {"msg": "hi"})
    print(allowed.verdict.allowed)
    print(session.validate_output("echoed: hi").response)
```

Direct SDK docs: [Node](sdk/node/README.md), [.NET](sdk/dotnet/README.md), [Rust](sdk/rust/agent_shield/README.md), [Rust MCP](sdk/rust/agent_shield_mcp/README.md).

## 7. Write your first `.guardrails.yaml`

Shortcut: run [`agent-shield init`](docs/getting-started/init.md).

```yaml
metadata:
  name: "document-agent"
  version: "1.0.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Help users find documents while enforcing DLP policies."]
variables:
  - name: data_sensitivity
    type: string
    update_policy: max
    ordering: ["public", "internal", "confidential", "restricted"]
    default: "public"
    populated_by:
      - kind: tool
        name: read_document
        phase: after_execute
  - name: send_email_authorized
    type: boolean
    on_demand_by:
      kind: human
      prompt: "Approve outbound email to ${@tool.params.to}?"
    lifetime: per_session
resources:
  tools:
    - { name: read_document, description: "Read a document" }
    - { name: send_email, description: "Send an email" }
state_validation:
  guard_policies:
    - name: block_outbound_when_restricted
      applies_to: { tools: [send_email] }
      active_if: "data_sensitivity == 'restricted'"
      action: block
      reason: "Restricted data may not be emailed."
    - name: send_email_requires_approval
      applies_to: { tools: [send_email] }
      evaluate_when:
        - expression: "send_email_authorized == true"
          reason: "Outbound email requires manager approval."
      action: block
output_validation:
  guard_policies:
    - name: ssn_redact
      detect:
        kind: pattern
        patterns: ['\b\d{3}-\d{2}-\d{4}\b']
      action: redact
      replacement: "[SSN REDACTED]"
```

A blocked human resolver surfaces `pending_resolution = {kind, tool, variable, prompt, request_id}`. Your host shows the prompt, then resumes with `set_variable(...)` / `setVariable(...)` / `SetVariable(...)`.

## 8. Run the demos

```bash
pip install -r examples/agents/bank-manager/requirements.txt
cp examples/agents/bank-manager/.env.example .env
python examples/agents/bank-manager/demo.py --scenarios all
python examples/agents/bank-manager/demo.py --framework anthropic --scenarios all
```

| Demo | What it shows |
|---|---|
| [Bank Manager](examples/agents/bank-manager/README.md) | VIP transfer approvals, social engineering, prompt injection in tool memos, account enumeration |
| [Document DLP](examples/agents/document-dlp/README.md) | Sensitivity ratchets, email policy, output PII redaction |

## Next steps

- [Specification](spec/SPECIFICATION.md)
- [Expression language](spec/expressions/LANGUAGE.md)
- [JSON Schema](spec/schema/guardrails.schema.json)
- [Reference policies](examples/policies/)
- [Production checklist](docs/PRODUCTION_DEPLOYMENT.md)
