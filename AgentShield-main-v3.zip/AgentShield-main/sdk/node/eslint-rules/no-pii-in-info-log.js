// Agent Shield — Node ESLint custom rule (stub).
//
// SHIP STATUS: stub. Wired into the build only when the napi-rs Node 24
// blocker is resolved (tracked at microsoft/AgentShield#82). Until
// then, the Node SDK is in deferred state per v8 plan §5.
//
// What it will do once active:
//
//   Flag `console.info` / `console.warn` / `console.error` /
//   `logger.info` / `logger.warn` / `logger.error` call sites in
//   `sdk/node/**/*.ts` whose argument list references an identifier
//   whose name appears in `.github/scripts/sensitive-names.txt`
//   (case-insensitive, separator-insensitive substring).
//
//   Allowed exceptions per docs/logging-style-guide.md:
//     - `__tests__/**`
//     - `dist/**`, `node_modules/**`
//     - `sdk/node/adapters/openai_agents.ts:405` — the documented
//       one-shot `console.warn` for the OpenAI Agents SDK adapter
//       compat warning (annotate with a `// eslint-disable-next-line`
//       comment when the rule is wired up).
//
// References:
//   - docs/logging-style-guide.md (the 7 rules this rule enforces)
//   - .github/scripts/sensitive-names.txt (the denylist)
//   - microsoft/AgentShield#82 (Node SDK unblock tracking issue)

'use strict'

const fs = require('node:fs')
const path = require('node:path')

const SENSITIVE_FILE = path.resolve(
  __dirname,
  '..',
  '..',
  '..',
  '.github',
  'scripts',
  'sensitive-names.txt'
)

function loadSensitiveTokens() {
  if (!fs.existsSync(SENSITIVE_FILE)) {
    return []
  }
  return fs
    .readFileSync(SENSITIVE_FILE, 'utf8')
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => line.length > 0 && !line.startsWith('#'))
    .map(normalizeIdentifier)
    .filter((token) => token.length > 0)
}

const INFO_PLUS_LEVELS = new Set(['info', 'warn', 'warning', 'error', 'critical'])
const LOGGER_NAMES = new Set(['logger', '_logger', 'console'])

function normalizeIdentifier(name) {
  return String(name).toLowerCase().replace(/[_-]+/g, '')
}

function collectReferencedNames(node, names = new Set(), visited) {
  if (!node || typeof node !== 'object') return names
  if (!visited) visited = new WeakSet()
  if (visited.has(node)) return names
  visited.add(node)
  if (node.type === 'Identifier' && typeof node.name === 'string') {
    names.add(normalizeIdentifier(node.name))
  }
  if (node.type === 'MemberExpression' && node.property?.name) {
    names.add(normalizeIdentifier(node.property.name))
  }
  for (const key of Object.keys(node)) {
    if (key === 'parent') continue
    const child = node[key]
    if (Array.isArray(child)) {
      for (const c of child) collectReferencedNames(c, names, visited)
    } else if (child && typeof child === 'object' && child.type) {
      collectReferencedNames(child, names, visited)
    }
  }
  return names
}

module.exports = {
  meta: {
    type: 'problem',
    docs: {
      description:
        'Disallow logging sensitive identifiers (tool args, PII, secrets) at info+ levels.',
      category: 'Possible Problems',
    },
    schema: [],
    messages: {
      sensitiveAtInfo:
        'Sensitive identifier `{{name}}` referenced in {{level}}-level log call. ' +
        'Demote to debug or redact to type+length. See docs/logging-style-guide.md Rule 1.',
    },
  },

  create(context) {
    const tokens = loadSensitiveTokens()
    if (tokens.length === 0) return {}

    return {
      CallExpression(node) {
        if (node.callee?.type !== 'MemberExpression') return
        const targetName = node.callee.object?.name?.toLowerCase()
        const methodName = node.callee.property?.name?.toLowerCase()
        if (!targetName || !methodName) return
        if (!LOGGER_NAMES.has(targetName)) return
        if (!INFO_PLUS_LEVELS.has(methodName)) return

        const names = new Set()
        const visited = new WeakSet()
        for (const arg of node.arguments) {
          collectReferencedNames(arg, names, visited)
        }

        for (const name of names) {
          for (const token of tokens) {
            if (name.includes(token)) {
              context.report({
                node,
                messageId: 'sensitiveAtInfo',
                data: { name, level: methodName },
              })
              return
            }
          }
        }
      },
    }
  },
}
