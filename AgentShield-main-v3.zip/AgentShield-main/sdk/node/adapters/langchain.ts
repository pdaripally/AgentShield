// LangChain.js adapter for Agent Shield.
//
// Registers the LangChain capability bundle and side-effect methods
// (`withLangchain`, `withLlm`, `createLangchainAgent`, and a Runnable-shaped
// `GuardedRunner.invoke`) without touching canonical base Shield methods.

import {
  Shield,
  ShieldBuilder,
  GuardedRunner,
  CapabilityReport,
  CoverageLevel,
  type CapabilityBundle,
  type LlmCallerFactory,
  type ToolWrapper,
  type ToolMeta,
  type AgentBoundary,
  type StreamingAdapter,
  type StreamingValidatorLike,
  type RunOpts,
} from '../shield.js'
import { StreamingReplaceNotSupportedError } from '../errors.js'

// ─── Module augmentation: install adapter methods on Shield/ShieldBuilder

declare module '../shield.js' {
  interface ShieldBuilder {
    /** Bind this builder to the LangChain capability bundle. */
    withLangchain(opts?: LangchainWithOpts): this
    /** Set the LangChain BaseChatModel to drive LLM-resolver gates. */
    withLlm(client: unknown): this
  }
  interface Shield {
    /** Pattern A — protect tools and build a LangChain agent. */
    createLangchainAgent(opts: CreateLangchainAgentOpts): Promise<unknown>
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars -- declaration-merging augmentation; TAgent must match the primary GuardedRunner<TAgent, TResult> in shield.ts even though this particular method only uses TResult.
  interface GuardedRunner<TAgent, TResult> {
    /**
     * LangChain `Runnable.invoke(input, config?)` alias for
     * {@link GuardedRunner.run}. Lets a guarded agent slot into
     * `RunnableSequence` and other LangChain compositions that expect
     * the `.invoke()` method name. Internally delegates to `.run(...)`
     * — no separate code path.
     *
     * Accepts either a plain `string` (forwarded as-is) or a
     * LangChain-style input dict (e.g. `{input: '...'}`,
     * `{question: '...'}`, or `{messages: [...]}`). When passed a
     * dict, the human-readable text is extracted for Stage 1 input
     * validation and the full dict is forwarded to the underlying
     * LangChain agent through `opts.inputDict`.
     */
    invoke(
      input: string | Record<string, unknown> | undefined,
      config?: unknown,
    ): Promise<TResult>
  }
}

// ─── Public opts / handle types ───────────────────────────────────

/**
 * Structural shape of a LangChain `BaseChatModel`. We avoid taking a
 * hard dep on `@langchain/core` types; the runtime treats this as an
 * opaque object with an `invoke(messages)` method.
 */
export interface LangchainBaseChatModel {
  invoke(messages: unknown[]): Promise<unknown>
}

export interface LangchainTool {
  name?: string
  description?: string
  schema?: unknown
  invoke?: (params: Record<string, unknown>) => Promise<unknown> | unknown
  func?: (params: Record<string, unknown>) => Promise<unknown> | unknown
  lc_namespace?: unknown
  returnDirect?: boolean
  [key: string]: unknown
}

export interface LangchainAgent {
  invoke?(input: LangchainInputDict, config?: unknown): Promise<unknown>
  ainvoke?(input: LangchainInputDict, config?: unknown): Promise<unknown>
  stream?(input: LangchainInputDict, config?: unknown): Promise<AsyncIterable<unknown>> | AsyncIterable<unknown>
  astream?(input: LangchainInputDict, config?: unknown): Promise<AsyncIterable<unknown>> | AsyncIterable<unknown>
}

export interface LangchainInputDict {
  input?: string
  messages?: Array<unknown>
  [key: string]: unknown
}

export interface LangchainWithOpts {
  /** Reserved for future per-bundle options. */
  [key: string]: unknown
}

export interface CreateLangchainAgentOpts {
  tools?: ReadonlyArray<LangchainTool>
  llm?: LangchainBaseChatModel
  prompt?: unknown
  systemPrompt?: unknown
  build?: (
    wrappedTools: unknown[],
    opts: CreateLangchainAgentOpts,
  ) => Promise<unknown> | unknown
  [key: string]: unknown
}

// ─── Lazy LangChain.js imports ──────────────────────────────────────
//
// Keep `@langchain/core` strictly peer-optional. We resolve it on first
// need so that customers who never call `protectTools` / streaming
// don't pay the cost (and so that loader smoke tests don't require
// LangChain installed in the runtime image).

interface LangchainCoreToolsModule {
  DynamicStructuredTool: new (init: {
    name: string
    description: string
    schema?: unknown
    func: (
      args: Record<string, unknown>,
      runManager?: unknown,
      parentConfig?: unknown,
    ) => Promise<unknown> | unknown
    returnDirect?: boolean
  }) => LangchainTool
}

interface LangchainCoreMessagesModule {
  HumanMessage: new (init: { content: string }) => unknown
  AIMessage: new (init: { content: string }) => unknown
}

let _lcTools: LangchainCoreToolsModule | null = null
let _lcMessages: LangchainCoreMessagesModule | null = null

function _loadLcTools(): LangchainCoreToolsModule {
  if (_lcTools !== null) return _lcTools
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    _lcTools = require('@langchain/core/tools') as LangchainCoreToolsModule
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err)
    throw new Error(
      'Agent Shield LangChain adapter requires `@langchain/core` to be ' +
        'installed. Add it as a dependency of your application.\n' +
        `Underlying error: ${msg}`,
    )
  }
  return _lcTools
}

function _loadLcMessages(): LangchainCoreMessagesModule {
  if (_lcMessages !== null) return _lcMessages
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    _lcMessages = require('@langchain/core/messages') as LangchainCoreMessagesModule
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err)
    throw new Error(
      'Agent Shield LangChain adapter requires `@langchain/core` to be ' +
        'installed. Add it as a dependency of your application.\n' +
        `Underlying error: ${msg}`,
    )
  }
  return _lcMessages
}

// ─── Capability 1 — LLM caller factory ──────────────────────────────
//
// LangChain audit note (parity with the OpenAI / Anthropic Node
// adapters' `node-*-remove-hardcoded-model` fixes):
//
// LangChain's `BaseChatModel` is itself the model handle — the
// customer constructs it (`new ChatOpenAI({model: 'gpt-4o'})` /
// `new ChatAnthropic({model: 'claude-3-7-sonnet'})` /...) and the
// adapter calls `llm.invoke(messages)` with no model-name kwarg.
// There is no hard-coded model in this caller closure to remove.
// That means YAML `configurations: [{id:..., type: llm, model:...}]`
// entries cannot drive LangChain's model from the adapter — to
// follow the YAML the customer must construct the right
// `BaseChatModel` and pass it to `withLlm(client)`.
//
// We still accept (and ignore) `ctx.configurationResolver` for
// protocol consistency with the other adapters: a future change
// may swap the BaseChatModel by `configurationId` (e.g. by
// memoising a map of LLMs), and external `LlmCallerFactory`
// implementations relying on `AdapterContext` continue to compile.

const _llmCallerFactory: LlmCallerFactory<
  LangchainBaseChatModel,
  (configurationId: string | null, prompt: string) => Promise<string>
> = {
  makeCaller(llm: LangchainBaseChatModel, _ctx?: import('../shield.js').AdapterContext) {
    if (!llm) {
      throw new TypeError('withLlm(): llm must be a LangChain BaseChatModel')
    }
    // `_ctx.configurationResolver` is intentionally unused — see the
    // audit note above. The argument is accepted so this factory
    // matches the `LlmCallerFactory.makeCaller(client, ctx?)`
    // signature that the OpenAI / Anthropic adapters use.
    void _ctx
    const { HumanMessage } = _loadLcMessages()
    // Returned shape matches the runtime caller contract:
    //   (configurationId: string|null, prompt: string) => Promise<string>
    return async function langchainLlmCaller(
      _configurationId: string | null,
      prompt: string,
    ): Promise<string> {
      const response: unknown = await llm.invoke([new HumanMessage({ content: prompt })])
      if (response == null) return ''
      if (typeof response === 'string') return response
      const r = response as { content?: unknown }
      if (typeof r.content === 'string') return r.content
      // AIMessage with array content (multi-modal): join text parts.
      if (Array.isArray(r.content)) {
        return (r.content as Array<unknown>)
          .map((p) =>
            typeof p === 'string'
              ? p
              : ((p as { text?: string } | null)?.text ?? ''),
          )
          .join('')
      }
      return String(response)
    }
  },
}

// ─── Capability 2 — Tool wrapper ────────────────────────────────────

interface LangchainToolMeta extends ToolMeta {
  paramsSchema: unknown
  extras: {
    schema: unknown
    lc_namespace: unknown
    returnDirect: boolean
  }
}

const _toolWrapper: ToolWrapper<LangchainTool, LangchainTool> = {
  extract(tool: LangchainTool): LangchainToolMeta {
    const name = tool?.name ? String(tool.name) : 'tool'
    return {
      name,
      description: String(tool?.description ?? tool?.name ?? 'tool'),
      paramsSchema: tool?.schema ?? null,
      extras: {
        schema: tool?.schema ?? null,
        lc_namespace: tool?.lc_namespace ?? null,
        returnDirect: !!tool?.returnDirect,
      },
    }
  },

  async invoke(original: LangchainTool, params: Record<string, unknown>): Promise<unknown> {
    // LangChain.js tools all expose.invoke(args, config?). Calling
    // through.invoke (rather than._call or.func) preserves the
    // tool's runManager/callback wiring.
    if (typeof original?.invoke === 'function') {
      return await original.invoke(params)
    }
    if (typeof original?.func === 'function') {
      return await original.func(params)
    }
    if (typeof original === 'function') {
      return await (original as unknown as (p: Record<string, unknown>) => unknown)(params)
    }
    throw new TypeError(
      `LangChain tool ${original?.name ?? '<anonymous>'} is not invokable`,
    )
  },

  wrap(
    original: LangchainTool,
    metadata: ToolMeta,
    guardedInvoke: (params: Record<string, unknown>, userInput?: string) => Promise<unknown>,
  ): LangchainTool {
    const { DynamicStructuredTool } = _loadLcTools()
    const meta = metadata as LangchainToolMeta

    // Tool body receives the args dict; orchestrator's guardedInvoke
    // expects (params, userInput). Routes Stage 2 → 3 → 4 around the
    // call.
    const guardedFunc = async (
      args: Record<string, unknown>,
      _runManager?: unknown,
      _parentConfig?: unknown,
    ): Promise<unknown> => {
      void _runManager
      void _parentConfig
      const result = await guardedInvoke(args ?? {}, '')
      // Orchestrator returns a string. LangChain tools also expect
      // strings (or a JSON-serialisable value); return as-is.
      return result
    }

    const tool = new DynamicStructuredTool({
      name: meta.name,
      description: meta.description ?? meta.name,
      schema: meta.extras?.schema ?? original?.schema ?? undefined,
      func: guardedFunc,
      returnDirect: meta.extras?.returnDirect ?? false,
    })
    return tool
  },
}

// ─── LangGraph ToolNode fail-closed rewiring ─────────────────────
//
// When a customer wraps tools with `shield.protectTools(tools)` and
// hands them to `createReactAgent({llm, tools})` themselves (i.e.
// NOT through `shield.createLangchainAgent(...)`), LangGraph builds
// its default `ToolNode` with `handleToolErrors: true`. That default
// catches any exception thrown by the wrapped tool — including the
// `AgentShieldBlockedError` raised by a denied resolver — and
// converts it into a stringified `ToolMessage` observation. The LLM
// then keeps reasoning over the "error" content and fabricates a
// final answer. Net effect: a HIGH-severity silent bypass of every
// Stage 2/3/4 deny verdict.
//
// `shield.createLangchainAgent(...)` already builds the ToolNode
// with `handleToolErrors: false`. We mirror that contract here for
// agents passed into `shield.guard(agent)`: when the agent looks
// like a compiled LangGraph state graph, walk its nodes, find any
// ToolNode-shaped runnable whose `handleToolErrors` is still the
// permissive default, and flip it to `false` in place. The mutation
// is idempotent (gated by a WeakSet) and emits a one-time
// `console.warn` so the customer can see what happened.
//
// We use structural duck-typing (look for the public
// `handleToolErrors` boolean property + `tools` array + `runTool`
// function described in `@langchain/langgraph/dist/prebuilt/tool_node.d.ts`)
// so the fix works regardless of whether the customer pinned an
// older or newer langgraph release, and without taking a hard dep
// on `@langchain/langgraph` from this adapter module.

const _toolNodeRewireSeen = new WeakSet<object>()
let _toolNodeRewireWarned = false

interface _ToolNodeLike {
  handleToolErrors?: boolean
  tools?: unknown
  runTool?: unknown
}

function _isToolNodeLike(candidate: unknown): candidate is _ToolNodeLike {
  if (candidate == null || typeof candidate !== 'object') return false
  const obj = candidate as Record<string, unknown>
  if (typeof obj['handleToolErrors'] !== 'boolean') return false
  if (!Array.isArray(obj['tools'])) return false
  // `runTool` is a protected method on the ToolNode class — it's
  // installed on the prototype, so look at the prototype chain.
  const proto = Object.getPrototypeOf(obj) as Record<string, unknown> | null
  if (proto == null) return false
  if (typeof proto['runTool'] !== 'function') return false
  return true
}

function _warnToolNodeRewired(): void {
  if (_toolNodeRewireWarned) return
  _toolNodeRewireWarned = true
  console.warn(
    '[agent-shield] LangGraph ToolNode default `handleToolErrors: true` ' +
      'would silently swallow AgentShieldBlockedError and let the model ' +
      'fabricate a bypass; rewiring to `handleToolErrors: false` so ' +
      'Stage 2/3/4 deny verdicts propagate. To suppress this ' +
      'warning, either use `shield.createLangchainAgent({tools, llm})` ' +
      'or construct your ToolNode explicitly with ' +
      '`new ToolNode(tools, { handleToolErrors: false })`.',
  )
}

// Collect ToolNode-like runnables out of any container an agent
// might use to hold them. Returns the list of distinct instances
// that ARE ToolNode-like; we then flip the flag on each. The
// traversal is shallow on purpose: we only look at the immediate
// `nodes` records of the compiled graph and its underlying
// `builder.nodes` map (the two slots langgraph uses for the
// "agent" / "tools" node table). We don't recursively descend into
// arbitrary runnables because customers can compose ToolNode into
// deeper graphs themselves — covering that case is a separate
// hardening pass.
function _collectToolNodesFromAgent(agent: unknown): _ToolNodeLike[] {
  if (agent == null || typeof agent !== 'object') return []
  const out: _ToolNodeLike[] = []
  const seen = new WeakSet<object>()

  const visitContainer = (container: unknown): void => {
    if (container == null || typeof container !== 'object') return
    const obj = container as Record<string, unknown>
    // eslint-disable-next-line security/detect-object-injection -- own-key iteration via Object.keys; no user-controlled keys
    for (const key of Object.keys(obj)) _walkNodeRecord(obj[key])
  }

  const _walkNodeRecord = (value: unknown): void => {
    if (value == null || typeof value !== 'object') return
    if (seen.has(value as object)) return
    seen.add(value as object)
    // Direct ToolNode-like
    if (_isToolNodeLike(value)) {
      out.push(value as _ToolNodeLike)
      return
    }
    const rec = value as Record<string, unknown>
    // langgraph StateGraph stores: { runnable, metadata,... } per node.
    if (rec['runnable'] !== undefined && _isToolNodeLike(rec['runnable'])) {
      out.push(rec['runnable'] as _ToolNodeLike)
    }
    // PregelNode stores the user-supplied runnable as `.bound`.
    if (rec['bound'] !== undefined && _isToolNodeLike(rec['bound'])) {
      out.push(rec['bound'] as _ToolNodeLike)
    }
  }

  const agentObj = agent as Record<string, unknown>
  // CompiledStateGraph: `nodes` is a plain record of PregelNode.
  visitContainer(agentObj['nodes'])
  // The underlying builder retains the StateGraph it was compiled
  // from. `builder.nodes` is the raw `{ runnable, metadata,... }`
  // map. Either side may hold the ToolNode reference and both are
  // the same instance, but visit both to be defensive against
  // future shape changes.
  const builder = agentObj['builder']
  if (builder !== null && typeof builder === 'object') {
    visitContainer((builder as Record<string, unknown>)['nodes'])
  }
  return out
}

/**
 * Ensure any LangGraph `ToolNode` reachable from `agent`
 * has `handleToolErrors: false`, so a tool that throws
 * `AgentShieldBlockedError` (or any other exception raised by an
 * Agent Shield-wrapped tool) propagates out of the agent run
 * instead of being silently converted into a `ToolMessage` the
 * model continues to reason over.
 *
 * Idempotent: each agent object is processed at most once, even
 * if the boundary is invoked many times against the same agent.
 *
 * Exported (under `_` prefix) for tests; treat as private API.
 */
export function _ensureToolNodeFailClosed(agent: unknown): void {
  if (agent == null || typeof agent !== 'object') return
  if (_toolNodeRewireSeen.has(agent as object)) return
  _toolNodeRewireSeen.add(agent as object)
  const nodes = _collectToolNodesFromAgent(agent)
  if (nodes.length === 0) return
  let mutated = false
  for (const node of nodes) {
    if (node.handleToolErrors === true) {
      try {
        node.handleToolErrors = false
        mutated = true
      } catch {
        // Property non-writable (frozen instance). Fall through
        // to the throw below — silent bypass is worse than a
        // loud error.
      }
    }
  }
  if (mutated) _warnToolNodeRewired()
  // Re-verify: any ToolNode still permissive after the mutation
  // pass means we cannot guarantee fail-closed semantics. Throw
  // rather than allow silent bypass.
  for (const node of nodes) {
    if (node.handleToolErrors === true) {
      throw new Error(
        'agent-shield LangChain adapter: detected a LangGraph ToolNode ' +
          'with handleToolErrors=true that could not be re-wired to ' +
          'handleToolErrors=false (frozen / non-writable property). ' +
          'AgentShieldBlockedError would be silently swallowed and the ' +
          'model would fabricate a bypass. Build your ToolNode with ' +
          '`new ToolNode(tools, { handleToolErrors: false })` ' +
          'or call `shield.createLangchainAgent({tools, llm})` instead.',
      )
    }
  }
}

// Reset hooks for tests. Not part of the public API.
export function _resetToolNodeFailClosedState(): void {
  _toolNodeRewireWarned = false
}

// ─── Capability 3 — Agent boundary (Stage 1 + Stage 5) ──────────────

function _extractMessageText(response: unknown): string | null {
  if (response == null) return null
  if (typeof response === 'string') return response
  const r = response as Record<string, unknown>
  if (typeof r['output'] === 'string') return r['output'] as string
  if (Array.isArray(r['messages']) && (r['messages'] as unknown[]).length > 0) {
    const messages = r['messages'] as unknown[]
    const last = messages[messages.length - 1]
    if (last == null) return null
    if (typeof last === 'string') return last
    const ml = last as Record<string, unknown>
    if (typeof ml['content'] === 'string') return ml['content'] as string
    if (Array.isArray(ml['content'])) {
      return (ml['content'] as unknown[])
        .map((p) =>
          typeof p === 'string'
            ? p
            : ((p as { text?: string } | null)?.text ?? ''),
        )
        .join('')
    }
    if (typeof ml['content'] !== 'undefined') return String(ml['content'])
  }
  if (typeof r['content'] === 'string') return r['content'] as string
  return null
}

function _extractChunkText(chunk: unknown): string {
  if (chunk == null) return ''
  if (typeof chunk === 'string') return chunk
  const c = chunk as Record<string, unknown>
  if (typeof c['content'] === 'string') return c['content'] as string
  if (Array.isArray(c['content'])) {
    return (c['content'] as unknown[])
      .map((p) =>
        typeof p === 'string' ? p : ((p as { text?: string } | null)?.text ?? ''),
      )
      .join('')
  }
  if (Array.isArray(c['messages']) && (c['messages'] as unknown[]).length > 0) {
    const msgs = c['messages'] as unknown[]
    return _extractChunkText(msgs[msgs.length - 1])
  }
  return ''
}

const _agentBoundary: AgentBoundary<LangchainAgent, Record<string, unknown>> = {
  async run(
    agent: LangchainAgent,
    inputText: string | undefined,
    opts: Record<string, unknown> = {},
  ): Promise<Record<string, unknown>> {
    // Before delegating to the agent, ensure any LangGraph
    // ToolNode reachable from it has `handleToolErrors: false`. This
    // is the safety net for customers who build the agent
    // themselves (Pattern A with raw `createReactAgent`) instead of
    // going through `shield.createLangchainAgent(...)`. Idempotent.
    _ensureToolNodeFailClosed(agent)
    const inputDict =
      (opts['inputDict'] as LangchainInputDict | undefined) ??
      ({ messages: [['human', inputText ?? '']] } as LangchainInputDict)
    const config = opts['config']
    if (typeof agent === 'function') {
      // Bare function (used in some tests) — forward inputText.
      return (await (agent as unknown as (s: string | undefined) => Promise<Record<string, unknown>>)(
        inputText,
      )) ?? {}
    }
    if (typeof agent.invoke === 'function') {
      return (await agent.invoke(inputDict, config)) as Record<string, unknown>
    }
    if (typeof agent.ainvoke === 'function') {
      return (await agent.ainvoke(inputDict, config)) as Record<string, unknown>
    }
    throw new TypeError('LangChain agent has no .invoke() method')
  },

  extractOutput(result: Record<string, unknown>): string | null {
    return _extractMessageText(result)
  },

  applyRedaction(
    result: Record<string, unknown>,
    redactedText: string | null | undefined,
  ): Record<string, unknown> {
    const { AIMessage } = _loadLcMessages()
    const text = redactedText ?? ''
    if (result && typeof result === 'object') {
      const out: Record<string, unknown> = { ...result, output: text }
      if (Array.isArray(result['messages']) && (result['messages'] as unknown[]).length > 0) {
        const newMessages = (result['messages'] as unknown[]).slice(0, -1)
        newMessages.push(new AIMessage({ content: text }))
        out['messages'] = newMessages
      } else {
        out['messages'] = [new AIMessage({ content: text })]
      }
      return out
    }
    return {
      output: text,
      messages: [new AIMessage({ content: text })],
    }
  },

  makeBlocked(message: string): Record<string, unknown> {
    const { AIMessage } = _loadLcMessages()
    return {
      output: message,
      messages: [new AIMessage({ content: message })],
    }
  },
}

// ─── Capability 4 — Streaming adapter ───────────────────────────────
//
// LangChain.js exposes per-token streaming via `agent.stream(input,
// config)`. We push each chunk's text content through the validator
// and yield the (possibly redacted) chunk. tool_call_chunk text is
// NOT pushed through Stage 5 — those go through Stage 2/3/4
// independently. That's the gap that makes streaming_output `partial`.

const _streamingAdapter: StreamingAdapter<LangchainAgent, unknown> = {
  async *stream(
    agent: LangchainAgent,
    inputText: string | undefined,
    validator: StreamingValidatorLike,
    opts: Record<string, unknown> = {},
  ): AsyncIterable<unknown> {
    // Mirror the non-streaming `agentBoundary.run` rewire so
    // streaming Pattern A also propagates AgentShieldBlockedError
    // instead of letting LangGraph's ToolNode swallow it into a
    // ToolMessage observation.
    _ensureToolNodeFailClosed(agent)
    const { AIMessage } = _loadLcMessages()
    const inputDict =
      (opts['inputDict'] as LangchainInputDict | undefined) ??
      ({ messages: [['human', inputText ?? '']] } as LangchainInputDict)
    const config = opts['config']

    let inner: AsyncIterable<unknown>
    if (typeof agent.stream === 'function') {
      inner = (await agent.stream(inputDict, config)) as AsyncIterable<unknown>
    } else if (typeof agent.astream === 'function') {
      inner = (await agent.astream(inputDict, config)) as AsyncIterable<unknown>
    } else {
      throw new TypeError('LangChain agent has no .stream() method')
    }

    // Validator mode drives emission scheduling:
    //   * `on_complete` — push every text-bearing chunk through the
    //     engine for accumulation but do NOT yield it to the consumer;
    //     metadata-only chunks (no text) pass through immediately so
    //     consumers still see progress events. The single terminal
    //     emission is built from `validator.finish()`.
    //   * `per_chunk` / `windowed` — the engine returns `r.payload`
    //     as the *authoritative* safe-to-emit slice (an
    //     overlap-respecting suffix of the buffer, NOT the raw
    //     upstream chunk). Yield that payload when non-empty; skip
    //     when empty (engine is still holding back overlap bytes).
    //     This mirrors the OnComplete fix that landed in
    //     `fix-streaming-mode-respect` and the Anthropic /.NET
    //     streamed paths: SDKs forward `r.payload`, not the raw
    //     chunk, so windowed validators that produce payload-altered
    //     Pass actions are honoured.
    const bufferMode = validator.mode === 'on_complete'
    let lastChunk: unknown = null

    for await (const chunk of inner) {
      const text = _extractChunkText(chunk)
      if (!text) {
        // Metadata-only chunk: not security-relevant; pass through.
        yield chunk
        continue
      }
      const r = await validator.push(text)
      if (r.stopped || r.action === 'stop') {
        yield validator.makeBlocked(
          r.reason ?? 'Stage 5 streaming guard stopped the stream.',
        )
        return
      }
      if (bufferMode) {
        // OnComplete: hold back text-bearing chunks until finish().
        // A `replace` action is safe in this mode because nothing
        // has been emitted to the consumer yet — the validated
        // payload arrives whole via the terminal apply_redaction.
        lastChunk = chunk
        continue
      }
      // per_chunk / windowed: the consumer is receiving deltas
      // immediately. A `replace` action would tell us to retract
      // everything previously emitted, which the LangChain.js
      // streaming surface cannot do (chunks already left the
      // generator). Throw the canonical error so the host switches
      // to `on_complete` cadence instead of silently rendering the
      // leaked-then-redacted concatenation.
      if (r.action === 'replace') {
        throw new StreamingReplaceNotSupportedError({
          adapter: 'LangChain.js',
          reason: r.reason,
        })
      }
      // per_chunk / windowed pass: emit r.payload (the engine's
      // safe-to-emit slice), NOT the raw chunk. Empty payload means
      // "buffered for overlap — emit nothing yet".
      if (r.payload != null && r.payload.length > 0) {
        yield validator.applyRedaction(chunk, r.payload)
      }
    }

    const tail = await validator.finish()
    if (tail.stopped || tail.action === 'stop') {
      yield validator.makeBlocked(
        tail.reason ?? 'Stage 5 streaming guard stopped the stream.',
      )
      return
    }
    if (bufferMode) {
      // OnComplete: emit the validated payload as the single terminal
      // chunk. Reuse the last upstream chunk shape so downstream
      // consumers that key on chunk structure see a familiar update.
      // A `replace` action here is safe — nothing was emitted prior,
      // so the consumer sees exactly one (redacted) emission.
      const finalText = tail.payload ?? ''
      if (finalText.length > 0) {
        if (lastChunk != null) {
          yield validator.applyRedaction(lastChunk, finalText)
        } else {
          yield { messages: [new AIMessage({ content: finalText })] }
        }
      }
      return
    }
    // per_chunk / windowed tail: a `replace` at finish means the
    // engine rewrote the buffer after we already streamed deltas to
    // the consumer. Fail loudly.
    if (tail.action === 'replace') {
      throw new StreamingReplaceNotSupportedError({
        adapter: 'LangChain.js',
        reason: tail.reason,
      })
    }
    if (tail.payload) {
      yield { messages: [new AIMessage({ content: tail.payload })] }
    }
  },
}

// ─── Capability report ──────────────────────────────────────────────

const _capabilities = new CapabilityReport({
  framework: 'langchain',
  inputValidation: CoverageLevel.FULL,
  stateValidation: CoverageLevel.FULL,
  toolAuthorization: CoverageLevel.FULL,
  toolExecutionValidation: CoverageLevel.FULL,
  toolOutputValidation: CoverageLevel.FULL,
  outputValidation: CoverageLevel.FULL,
  streamingOutput: CoverageLevel.PARTIAL,
  notes: [
    'streaming chunk-level redaction covers AIMessageChunk text, not ' +
      'tool_call deltas; full coverage post-stream',
  ],
})

// ─── Bundle ────────────────────────────────────────────────────────

export const LANGCHAIN_BUNDLE: CapabilityBundle = Object.freeze({
  name: 'langchain',
  llmCallerFactory: _llmCallerFactory as unknown as LlmCallerFactory,
  toolWrapper: _toolWrapper as unknown as ToolWrapper,
  agentBoundary: _agentBoundary as unknown as AgentBoundary,
  streamingAdapter: _streamingAdapter as unknown as StreamingAdapter,
  capabilities: _capabilities,
})

// ─── Side-effect installation ───────────────────────────────────────
//
// Idempotent — installing the adapter twice is a no-op.

interface ShieldBuilderInternal {
  _bundle: CapabilityBundle | null
  _llmCaller: ((req: unknown) => unknown) | null
  _pendingLlmClient?: unknown
  _rebindPendingLlmClient?: () => void
  withClient(client: unknown): ShieldBuilder
}

function _installSideEffects(): void {
  // 1. Builder: withLangchain() swaps in the LangChain bundle.
  if (
    !Object.prototype.hasOwnProperty.call(ShieldBuilder.prototype, 'withLangchain')
  ) {
    Object.defineProperty(ShieldBuilder.prototype, 'withLangchain', {
      value: function withLangchain(this: ShieldBuilder, _opts?: LangchainWithOpts): ShieldBuilder {
        void _opts
        const self = this as unknown as ShieldBuilderInternal
        self._bundle = LANGCHAIN_BUNDLE
        // If withClient (or withLlm) was called BEFORE withLangchain
        // the caller factory was missing; rebind now through the
        // base helper so call order is not significant.
        self._rebindPendingLlmClient?.()
        return this
      },
      writable: true,
      configurable: true,
    })
  }

  // 2. Builder: withLlm(client) is the LangChain-flavoured alias.
  //    If a bundle is already installed, route through withClient.
  //    Otherwise stash the client until withLangchain() (or any other
  //    `with<Framework>()`) is called.
  if (
    !Object.prototype.hasOwnProperty.call(ShieldBuilder.prototype, 'withLlm')
  ) {
    Object.defineProperty(ShieldBuilder.prototype, 'withLlm', {
      value: function withLlm(this: ShieldBuilder, client: unknown): ShieldBuilder {
        // Delegate to base withClient: it now uniformly handles
        // both immediate-bind (bundle installed) and pending-stash
        // (bundle not yet installed) cases.
        return (this as unknown as ShieldBuilderInternal).withClient(client)
      },
      writable: true,
      configurable: true,
    })
  }

  // 3. Shield: createLangchainAgent({tools, build}) — Pattern A.
  if (
    !Object.prototype.hasOwnProperty.call(Shield.prototype, 'createLangchainAgent')
  ) {
    Object.defineProperty(Shield.prototype, 'createLangchainAgent', {
      value: async function createLangchainAgent(
        this: Shield,
        opts: CreateLangchainAgentOpts = {},
      ): Promise<unknown> {
        const tools = (opts.tools ?? []) as LangchainTool[]
        const wrapped = await this.protectTools<LangchainTool, LangchainTool>(tools)
        if (typeof opts.build === 'function') {
          // F-probe-1.6 — customers supplying a `build` callback are
          // responsible for plumbing the wrapped tools so that a
          // thrown `AgentShieldBlockedError` propagates OUT of the
          // agent's invoke(). LangGraph's default `ToolNode` swallows
          // tool exceptions when `handleToolErrors` is left at its
          // default `true` — pass `new ToolNode(wrappedTools, {
          // handleToolErrors: false })` to preserve the fail-closed
          // contract. (See the langgraph branch below for the
          // canonical wiring.)
          return await opts.build(wrapped, opts)
        }
        // Default: try createReactAgent from @langchain/langgraph
        // if present. We require it lazily because it's a separate
        // optional package.
        let createReactAgent: (
          args: Record<string, unknown>,
        ) => unknown
        // F-probe-1.6 — `ToolNode` is also required from langgraph
        // so we can construct it with `handleToolErrors: false` and
        // override the default-swallow behavior. Without this,
        // `AgentShieldBlockedError` is caught inside the agent
        // graph and converted into a ToolMessage observation,
        // re-introducing the silent-bypass bug.
        let ToolNodeCtor:
          | (new (tools: unknown[], opts?: Record<string, unknown>) => unknown)
          | undefined
        try {
          // eslint-disable-next-line @typescript-eslint/no-require-imports
          ;({ createReactAgent } = require('@langchain/langgraph/prebuilt') as {
            createReactAgent: (args: Record<string, unknown>) => unknown
          })
          // ToolNode lives in the same prebuilt namespace in recent
          // langgraph versions. Best-effort load — if missing, fall
          // back to the raw `tools` array (older API).
          try {
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const prebuilt = require('@langchain/langgraph/prebuilt') as Record<
              string,
              unknown
            >
            const candidate = prebuilt.ToolNode
            if (typeof candidate === 'function') {
              ToolNodeCtor = candidate as new (
                tools: unknown[],
                opts?: Record<string, unknown>,
              ) => unknown
            }
          } catch {
            /* leave ToolNodeCtor undefined and pass raw tools */
          }
        } catch {
          throw new Error(
            'createLangchainAgent({tools, build}): pass a `build` ' +
              'callback that returns the agent, or install ' +
              '`@langchain/langgraph` for the default createReactAgent ' +
              'flow.',
          )
        }
        const toolsArg = ToolNodeCtor
          ? new ToolNodeCtor(wrapped, { handleToolErrors: false })
          : wrapped
        return createReactAgent({
          llm: opts.llm,
          tools: toolsArg,
          prompt: opts.prompt ?? opts.systemPrompt,
        })
      },
      writable: true,
      configurable: true,
    })
  }

  // 4. GuardedRunner: invoke(input, config?) — LangChain Runnable
  //    alias for run(inputText, opts). Lets a guarded agent slot
  //    into RunnableSequence and other LangChain compositions that
  //    expect.invoke(). Thin alias; delegates straight to.run().
  if (
    !Object.prototype.hasOwnProperty.call(GuardedRunner.prototype, 'invoke')
  ) {
    Object.defineProperty(GuardedRunner.prototype, 'invoke', {
      value: async function invoke<TAgent, TResult>(
        this: GuardedRunner<TAgent, TResult>,
        input: string | Record<string, unknown> | undefined,
        config?: unknown,
      ): Promise<TResult> {
        if (typeof input === 'string' || input === undefined) {
          const opts: RunOpts = {}
          if (config !== undefined) opts['config'] = config
          return await this.run(input, opts)
        }
        if (input !== null && typeof input === 'object') {
          const obj = input as Record<string, unknown>
          let inputText: string | undefined
          if (typeof obj['input'] === 'string') {
            inputText = obj['input'] as string
          } else if (typeof obj['question'] === 'string') {
            inputText = obj['question'] as string
          } else if (Array.isArray(obj['messages'])) {
            const msgs = obj['messages'] as unknown[]
            const last = msgs[msgs.length - 1] as Record<string, unknown> | undefined
            if (last && typeof last['content'] === 'string') {
              inputText = last['content'] as string
            }
          }
          const opts: RunOpts = { inputDict: obj }
          if (config !== undefined) opts['config'] = config
          return await this.run(inputText, opts)
        }
        return await this.run(undefined, {})
      },
      writable: true,
      configurable: true,
    })
  }

  // NOTE: This adapter intentionally does NOT touch
  // `Shield.prototype.run`, `Shield.prototype.protectTool`, or
  // `Shield.BUNDLE`. The base `Shield` class owns those — see
  // `../shield.js`. Touching them here would resurrect the
  // load-order prototype-pollution bug across adapter modules.
}

_installSideEffects()

// ─── Exports (mostly for tests / advanced users) ────────────────────

export {
  _capabilities as capabilities,
  _toolWrapper as toolWrapper,
  _agentBoundary as agentBoundary,
  _streamingAdapter as streamingAdapter,
  _llmCallerFactory as llmCallerFactory,
}
export { UnguardedToolInvocationError } from '../errors.js'
