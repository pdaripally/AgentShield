# Node OpenAI Agents adapter mediation

## Mediated paths
- `runOpenaiAgent(...)` owns the guarded agent loop at `sdk/node/adapters/openai_agents.ts:787`.
- `protectOpenaiTools(...)` wraps external tool dispatch at `sdk/node/adapters/openai_agents.ts:1173`.
- Raw chat-tool defs are re-wrapped in `_wrapChatToolDef()` at `sdk/node/adapters/openai_agents.ts:570`; prebuilt function tools are re-wrapped in `_wrapFunctionTool()` at `sdk/node/adapters/openai_agents.ts:613`.
- Streaming runs through `runOpenaiAgentStreamed(...)` at `sdk/node/adapters/openai_agents.ts:965`.

## Unsupported paths
- Running `Runner.run(...)` / `Runner.run_streamed(...)` on an unguarded agent.
- Calling the original tool dispatcher directly after wrapping.
- Direct OpenAI client / Responses API calls outside the adapter-owned loop.

## Bypass risks
- Supplying raw `agentConfig.tools` after a guarded tool set has already been built.
- Swapping the wrapped dispatcher for the raw dispatcher mid-session.
- Treating partial streamed tool-call deltas as already admitted Stage-3 invocations.

## Streaming behavior
- Rule 1 — ✓ validates complete text-delta payloads from the stream event extractor.
- Rule 2 — ✓ finite buffering/windowing is delegated to the core streaming guard.
- Rule 3 — ✓ `incident.stream_aborted` is emitted by the core dispatcher when `StreamingGuard.addChunk()` / `finish()` observe `action === 'stop'` (implemented in PR #107).
- Rule 4 — ✓ `incident.stream_limit_exceeded` is emitted by the core dispatcher when the shared `StreamingGuard` hits the core buffer bound.
- Rule 5 — ✗ streamed tool-call/result deltas are not surfaced as invocation-bound Stage-4 units; binding happens only on the assembled call.

## Unknown tool-call shapes
- Malformed JSON args are coerced to `{}` in `_wrapChatToolDef()` at `sdk/node/adapters/openai_agents.ts:597`, so the adapter preserves mediation but does not yet fail closed with `incident.unknown_invocation_shape`.

## See also

See [Post-tool limits and dangerous patterns](../../../../docs/POST_TOOL_LIMITS.md) and the [adapter-mediated path matrix](../../../../docs/adapter-mediated-paths.md).
