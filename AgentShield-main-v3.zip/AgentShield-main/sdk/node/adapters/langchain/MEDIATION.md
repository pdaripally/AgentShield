# Node LangChain adapter mediation

## Mediated paths
- `withLangchain()` installs the bundle; `shield.guard(agent)` and `createLangchainAgent(...)` route Stage 1/5 through `sdk/node/adapters/langchain.ts:607`.
- `protectTools()` / the bundle tool wrapper wrap LangChain tools at `sdk/node/adapters/langchain.ts:278`.
- Streaming goes through the adapter-owned stream bridge at `sdk/node/adapters/langchain.ts:428`.

## Unsupported paths
- Calling the original tool implementation directly.
- Running the raw LangChain agent without `shield.guard(...)` / `createLangchainAgent(...)`.
- Custom callback chains or transport hooks the adapter never sees.

## Bypass risks
- Retaining raw tool references next to the wrapped set.
- Replacing a wrapped tool after `createLangchainAgent(...)` has already assembled the guarded list.
- Assuming `tool_call_chunk` deltas are validated; the adapter only mediates documented text-stream paths.

## Streaming behavior
- Rule 1 — ✓ validates whole text payloads emitted by the adapter's extractor.
- Rule 2 — ✓ enforced by the core streaming guard's finite buffering/windowing.
- Rule 3 — ✓ `StreamingGuard.addChunk()` / `finish()` emit `incident.stream_aborted` when `action === 'stop'` (implemented in PR #107).
- Rule 4 — ✓ the shared `StreamingGuard` now emits `incident.stream_limit_exceeded` when the stream hits the core buffer bound.
- Rule 5 — ✗ tool-call deltas are not exposed as streamed invocation-bound Stage-4 units.

## Unknown tool-call shapes
- Non-invokable tools are rejected at `sdk/node/adapters/langchain.ts:260`, but unknown framework tool-call/message shapes are otherwise ignored rather than failing closed with `incident.unknown_invocation_shape`.

## See also

See [Post-tool limits and dangerous patterns](../../../../docs/POST_TOOL_LIMITS.md) and the [adapter-mediated path matrix](../../../../docs/adapter-mediated-paths.md).
