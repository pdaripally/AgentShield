# Node Anthropic adapter mediation

## Mediated paths
- `runAnthropicAgent(...)` owns the guarded Anthropic runner loop at `sdk/node/adapters/anthropic_agents.ts:695`.
- `protectAnthropicTools(...)` mediates standalone tool dispatch at `sdk/node/adapters/anthropic_agents.ts:783`.
- `_wrapAnthropicTool()` installs the guarded `run` wrapper at `sdk/node/adapters/anthropic_agents.ts:632`.
- Streaming runs through `runAnthropicAgentStreamed(...)` at `sdk/node/adapters/anthropic_agents.ts:886`.

## Unsupported paths
- Calling the original tool's `run(...)` directly.
- Running raw Anthropic SDK loops or SSE consumers outside the guarded runner.
- Tool-use / tool-result shapes the adapter does not convert into the documented wrapper path.

## Bypass risks
- Registering raw and wrapped Anthropic tools together.
- Replacing a guarded tool with the original object after setup.
- Assuming partial streamed text coverage also covers tool-use blocks before they finish.

## Streaming behavior
- Rule 1 — ✓ validates whole text-delta payloads the adapter extracts.
- Rule 2 — ✓ bounded by the core streaming guard's configured buffering/windowing.
- Rule 3 — ✓ `StreamingGuard.addChunk()` / `finish()` emit `incident.stream_aborted` when `action === 'stop'` (implemented in PR #107).
- Rule 4 — ✓ the shared `StreamingGuard` now emits `incident.stream_limit_exceeded` when the stream hits the core buffer bound.
- Rule 5 — ✗ streamed tool-use/result chunks are not exposed as invocation-bound Stage-4 units.

## Unknown tool-call shapes
- Non-object tool args are coerced to `{}` in `_wrapAnthropicTool()` at `sdk/node/adapters/anthropic_agents.ts:647`; unknown shapes therefore stay mediated but are not yet fail-closed with `incident.unknown_invocation_shape`.

## See also

See [Post-tool limits and dangerous patterns](../../../../docs/POST_TOOL_LIMITS.md) and the [adapter-mediated path matrix](../../../../docs/adapter-mediated-paths.md).
