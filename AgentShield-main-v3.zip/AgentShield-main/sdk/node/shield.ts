// Capability-based shield orchestrator (mirrors Python
// `agent_shield.adapters._shield`).
//
// What lives here (framework-agnostic):
//
//   - Stage sequencing and beginTurn / endTurn invariants
//   - Shield orchestrator class with monitor mode, on-block policy,
//     capability report, decision hooks
//   - GuardedRunner with run / runStreamed and ContextVar-equivalent
//     ambient session via AsyncLocalStorage
//   - Tool wrapping helper that routes through the orchestrator
//
// What does NOT live here:
//
//   - Framework-specific shape translation (LLM client → caller, tool
//     extraction, agent invocation, streaming chunk format) — those
//     live in framework-adapter modules and implement the capability
//     interfaces declared below.

import { AsyncLocalStorage } from 'node:async_hooks'
import { randomUUID } from 'node:crypto'
import {
  dispatchStageVerdict,
  dispatchToolVerdict,
  formatBlockMessage,
} from './native.js'
import {
  AgentShieldBlockedError,
  UnguardedToolInvocationError,
  type PendingResolutionShape,
} from './errors.js'
// Namespace import (lazy property access) breaks the shield ↔ index
// module cycle: when this module is loaded as a side-effect of
// index.ts loading, the partial `_index` object is empty, but by the
// time `ShieldBuilder.build()` is called the cycle has resolved and
// `_index.RuntimeBuilder` is fully defined.
import * as _index from './index.js'
// Type-only import — TS erases this at compile time, so it doesn't
// reintroduce the value-level cycle with `_index`.
import type { LlmConfiguration, ObservabilityProviderSchema } from './index.js'

// ─── Types from index.ts referenced here ─────────────────────────
// We avoid importing them directly to prevent the cycle. The shapes
// below are structural and match the canonical types.

/**
 * Structured suspension envelope surfaced on a Stage 2/3 block when
 * the verdict was caused by a resolver awaiting external input
 * (e.g. a `kind: human` resolver waiting on operator approval, or a
 * `kind: tool` resolver waiting on the agent to invoke a named tool).
 *
 * Mirrors the snake_case wire shape (`pending_resolution`) emitted by
 * the Rust core, camelized per Node SDK convention. The Python and
 * Node MCP adapters expose the same shape so hosts can drive the
 * human-approval / tool-resume UI without substring-matching the
 * `[GUARDRAIL...]` block message.
 */
export interface PendingResolutionLike {
  tool: string
  variable: string
  prompt?: string | null
  requestId: string
  kind: string
}

export interface StageVerdictLike {
  allowed: boolean
  action?: string | null
  reason?: string | null
  policy?: string | null
  evaluateWhenIndex?: number | null
  evaluate_when_index?: number | null
  bypassedByAllowedWhen?: boolean
  bypassed_by_allowed_when?: boolean
  redaction?: string | null
  appended?: string | null
  prepended?: string | null
  pendingResolution?: PendingResolutionLike | null
  pending_resolution?: PendingResolutionLike | null
  invocationHash?: string | null
  invocation_hash?: string | null
  postValidationInvocationHash?: string | null
  post_validation_invocation_hash?: string | null
}

export interface ToolCallOutcomeLike {
  verdict: StageVerdictLike
  params?: unknown
}

export interface ToolOutputOutcomeLike {
  verdict: StageVerdictLike
  result?: unknown
}

export interface OutputOutcomeLike {
  verdict: StageVerdictLike
  response?: string
}

export interface StreamChunkResultLike {
  action?: string | null
  payload?: string | null
  reason?: string | null
}

/**
 * Validation cadence configured on a {@link StreamingGuardLike}.
 * Mirrors `StreamingTrigger` in the Rust core.
 *
 * - `on_complete` — buffer every chunk through the engine and emit
 *   only the final validated payload at `finish()`. Streaming adapters
 *   MUST NOT yield text-bearing chunks to the consumer until
 *   `finish()` resolves.
 * - `windowed` — re-validate every `window_size` bytes (`overlap`
 *   bytes held back).
 * - `per_chunk` — validate after every chunk, in real time.
 */
export type StreamingMode = 'on_complete' | 'windowed' | 'per_chunk'

export interface SessionLike {
  beginTurn(): unknown
  endTurn(): unknown
  validateInput(input: string): Promise<StageVerdictLike>
  validateToolCall(
    tool: string,
    params: unknown,
    toolCallId: string,
  ): Promise<ToolCallOutcomeLike>
  validateToolOutput(
    tool: string,
    result: unknown,
    toolCallId: string,
  ): Promise<ToolOutputOutcomeLike>
  validateOutput(response: string): Promise<OutputOutcomeLike>
  recordToolSuccess(tool: string, result?: unknown): void
  recordToolFailure(tool: string, error: string): void
  streamingSession(stage: number | string): StreamingGuardLike
  /**
   * Write a value into a named variable on this session.
   * Used by {@link Shield.resolvePending} to translate an operator's
   * resume decision into a resolver outcome. Optional on the
   * interface so legacy mock sessions still satisfy the structural
   * type; the production {@link Session} class always implements it.
   */
  setVariable?(name: string, value: unknown): void
  emitEvent?(eventId: string, opts?: { payload?: unknown; lifetime?: unknown }): void
  completePendingResolution?(
    requestId: string,
    decision: 'allow' | 'deny' | 'cancelled',
    value?: unknown,
    setVariables?: Record<string, unknown> | null,
    reason?: string,
  ): unknown
}

export interface StreamingGuardLike {
  addChunk(chunk: string): Promise<StreamChunkResultLike>
  finish(): Promise<StreamChunkResultLike>
  readonly mode: StreamingMode
}

export interface RuntimeLike {
  newSession(): SessionLike
  /**
   * Effective runtime mode (#14): `"active"` or `"shadow"`. Optional
   * so mock runtimes still satisfy the type. Shadow forces the
   * Shield to {@link ShieldMode.MONITOR}.
   */
  mode?(): string
}

// ─── Coverage levels ─────────────────────────────────────────────

export const CoverageLevel = Object.freeze({
  FULL: 'full',
  PARTIAL: 'partial',
  UNSUPPORTED: 'unsupported',
} as const)
export type CoverageLevelValue = typeof CoverageLevel[keyof typeof CoverageLevel]

export interface CapabilityReportInit {
  framework: string
  inputValidation?: CoverageLevelValue
  stateValidation?: CoverageLevelValue
  toolAuthorization?: CoverageLevelValue
  toolExecutionValidation?: CoverageLevelValue
  toolOutputValidation?: CoverageLevelValue
  outputValidation?: CoverageLevelValue
  streamingOutput?: CoverageLevelValue
  notes?: readonly string[]
}

export class CapabilityReport {
  readonly framework: string
  readonly inputValidation: CoverageLevelValue
  readonly stateValidation: CoverageLevelValue
  readonly toolAuthorization: CoverageLevelValue
  readonly toolExecutionValidation: CoverageLevelValue
  readonly toolOutputValidation: CoverageLevelValue
  readonly outputValidation: CoverageLevelValue
  readonly streamingOutput: CoverageLevelValue
  readonly notes: readonly string[]

  constructor(opts: CapabilityReportInit) {
    this.framework = opts.framework
    this.inputValidation = opts.inputValidation ?? CoverageLevel.FULL
    this.stateValidation = opts.stateValidation ?? CoverageLevel.FULL
    this.toolAuthorization = opts.toolAuthorization ?? CoverageLevel.FULL
    this.toolExecutionValidation = opts.toolExecutionValidation ?? CoverageLevel.FULL
    this.toolOutputValidation = opts.toolOutputValidation ?? CoverageLevel.FULL
    this.outputValidation = opts.outputValidation ?? CoverageLevel.FULL
    this.streamingOutput = opts.streamingOutput ?? CoverageLevel.FULL
    this.notes = (opts.notes ?? []).slice()
  }

  isFullCoverage(): boolean {
    return [
      this.inputValidation,
      this.stateValidation,
      this.toolAuthorization,
      this.toolExecutionValidation,
      this.toolOutputValidation,
      this.outputValidation,
      this.streamingOutput,
    ].every((l) => l === CoverageLevel.FULL)
  }
}

// ─── Capability bundle interfaces ────────────────────────────────

export interface ToolMeta {
  name: string
  description?: string
}

export interface ToolWrapper<TTool = unknown, TGuarded = unknown> {
  extract(tool: TTool): ToolMeta
  invoke(tool: TTool, params: Record<string, unknown>): Promise<unknown> | unknown
  wrap(
    tool: TTool,
    meta: ToolMeta,
    guardedInvoke: (params: Record<string, unknown>, userInput?: string) => Promise<unknown>,
  ): TGuarded
}

export interface AgentBoundary<TAgent = unknown, TResult = unknown> {
  run(agent: TAgent, inputText: string | undefined, opts: Record<string, unknown>): Promise<TResult>
  extractOutput(result: TResult): string | null | undefined
  applyRedaction(result: TResult, redactedText: string | null | undefined): TResult
  makeBlocked(message: string): TResult
}

export interface StreamingPushResult {
  /**
   * Mirrors the spec's streaming verdict envelope. One of:
   *
   * - `'pass'` — append `payload` (which may be empty / buffered) to
   *   the consumer's sink. The default for backward compatibility.
   * - `'replace'` — discard every byte already emitted for this
   *   stream and emit `payload` in its place. Adapters whose sink
   *   cannot rewind (HTTP SSE, stdout, UI deltas) MUST throw
   *   {@link StreamingReplaceNotSupportedError} at the first such
   *   event so the leaked sensitive bytes are surfaced instead of
   *   silently followed by the redacted version. Adapters that
   *   accumulate `safe_parts` and emit a single final payload via
   *   {@link AgentBoundary.applyRedaction} should RESET the
   *   accumulator on `replace`.
   * - `'stop'` — equivalent to `stopped: true`; the adapter MUST
   *   stop emitting and yield {@link StreamingValidatorLike.makeBlocked}.
   *
   * The `stopped` field is preserved for backward compatibility with
   * existing adapter code paths; new code SHOULD branch on `action`
   * so the `'replace'` case is handled deliberately.
   *
   */
  action: 'pass' | 'replace' | 'stop'
  payload: string | null
  stopped: boolean
  reason: string | null
}

export interface StreamingValidatorLike {
  push(text: string): Promise<StreamingPushResult>
  finish(): Promise<StreamingPushResult>
  makeBlocked(message: string): unknown
  applyRedaction(chunk: unknown, text: string): unknown
  /**
   * The underlying guard's configured validation cadence (see
   * {@link StreamingMode}). Adapters use this to decide whether to
   * forward upstream chunks to the consumer in real time
   * (`per_chunk` / `windowed`) or to buffer every chunk and emit the
   * validated payload only at `finish()` (`on_complete`).
   */
  readonly mode: StreamingMode
}

export interface StreamingAdapter<TAgent = unknown, TEmission = unknown> {
  stream(
    agent: TAgent,
    inputText: string | undefined,
    validator: StreamingValidatorLike,
    opts: Record<string, unknown>,
  ): AsyncIterable<TEmission>
}

export interface LlmCallerFactory<TClient = unknown, TCaller = unknown> {
  makeCaller(client: TClient, ctx?: AdapterContext): TCaller
}

/**
 * Context passed to {@link LlmCallerFactory.makeCaller} so framework
 * adapters can surface their own (non-stage) errors through the same
 * observability stream as Stage 1–5 verdicts.
 *
 * Used by adapters that fail-CLOSED on a provider outage (e.g. the
 * Anthropic agent loop turns an Anthropic API 503 into a synthesized
 * block string). The fail-closed return is the right policy choice,
 * but conflating "the provider went down" with "the policy blocked" is
 * a SRE foot-gun — `recordAdapterError` routes the original error
 * through observability as a distinct signal so root-cause analysis
 * works.
 */
export interface AdapterContext {
  /** Emit a free-form `adapter.llm_caller_error` log event. */
  recordAdapterError(error: unknown): void

  /**
   * Look up a `configurations[]` entry from the merged YAML at LLM-caller
   * call time. Returns the camelCased configuration snapshot when the
   * runtime has a matching `type: llm` entry, or `null` when nothing
   * matches (unknown id, wrong `type`, or `configurationId` is empty).
   *
   * Adapter LLM-caller factories MUST use this to honour the YAML's
   * per-stage `model:` / `max_tokens:` selections; falling back to a
   * hard-coded model is a bug — the canonical adapters raise
   * {@link ConfigurationMissingModelError} when the resolved
   * configuration has neither `model:` nor `deployment:`. `null` is
   * returned (not thrown) on any lookup failure so caller closures
   * never need a try/catch around the resolver call; the underlying
   * `Runtime.llmConfiguration` errors are routed through observability
   * via {@link recordAdapterError}.
   *
   * Optional — third-party `LlmCallerFactory` implementations that
   * pre-date this field continue to work; they simply can't drive
   * per-stage model selection from YAML.
   */
  configurationResolver?: (
    configurationId: string | null | undefined,
  ) => LlmConfiguration | null
}

export interface CapabilityBundle {
  name: string
  capabilities: CapabilityReport
  toolWrapper?: ToolWrapper
  agentBoundary?: AgentBoundary
  streamingAdapter?: StreamingAdapter
  llmCallerFactory?: LlmCallerFactory
}

// ─── Shield mode + on-block policy ──────────────────────────────

export const ShieldMode = Object.freeze({
  ENFORCE: 'enforce',
  MONITOR: 'monitor',
} as const)
export type ShieldModeValue = typeof ShieldMode[keyof typeof ShieldMode]

export type OnBlockPolicy =
  | 'returnBlocked'
  | 'return_blocked'
  | 'returnVerdict'
  | 'return_verdict'
  | 'raise'
  | ((verdict: unknown) => unknown)

export class AgentShieldBlocked extends Error {
  override readonly name = 'AgentShieldBlocked'
  readonly verdict: unknown
  override readonly message: string

  constructor(verdict: unknown, message: string) {
    super(message)
    this.verdict = verdict
    this.message = message
  }
}

/**
 * Raised when `shield.run(thunk)` receives a result whose
 * runtime type is not `string`, `null`, or `undefined` and the caller
 * has not supplied an `extractText` lens.
 *
 * Previously the Pattern C surface silently coerced arbitrary objects
 * via `String(raw)` — for framework result types (Vercel AI SDK
 * `GenerateTextResult`, LangChain agent output, OpenAI Assistants
 * `Run`, etc.) that yielded `'[object Object]'`, so Stage 5 ran on a
 * literal eight-character string and the unredacted result returned
 * to the caller.
 *
 * The new fail-closed default raises this error so a forgotten
 * extractor is loud. Customers can opt in to redaction by passing
 * `extractText: (r) => r.text` (and matching
 * `setText: (r, t) => {...; return r }`, which is mandatory whenever
 * `extractText` is supplied).
 */
export class AgentShieldUnsupportedOutputTypeError extends TypeError {
  override readonly name = 'AgentShieldUnsupportedOutputTypeError'
  readonly resultType: string

  constructor(resultType: string) {
    super(
      `shield.run(thunk) received a result of type '${resultType}' but ` +
        `no 'extractText' lens was supplied. Previously the runtime ` +
        `silently coerced this via String(raw), bypassing Stage 5 ` +
        `redaction for framework result objects (e.g. Vercel AI SDK ` +
        `GenerateTextResult, LangChain output). To fix: pass ` +
        `extractText: (r) => r.text (and matching setText) so Stage 5 ` +
        `runs on the assistant-visible text field.`,
    )
    this.resultType = resultType
  }
}

/**
 * Raised when `shield.run(thunk, { extractText })` is supplied
 * without a matching `setText` writer.
 *
 * The fail-closed output lens closes the silent-bypass class where a
 * non-string framework
 * result flowed back unredacted. The opt-in `extractText` / `setText`
 * lens let customers name the assistant-visible text field. But a
 * second-order silent-bypass survived at the opt-in surface: when a
 * customer passed `extractText: (r) => r.choices[0].message.content`
 * without `setText`, the previous default mutator wrote redacted text
 * into a fresh `result.text` attribute — leaving the
 * customer-visible `r.choices[0].message.content` untouched. The
 * customer saw no exception, believed Stage 5 succeeded, and shipped
 * the unredacted text downstream, reopening the same silent-bypass
 * class at the lens opt-in surface.
 *
 * The absence of `setText` is now a configuration error.
 * Customers who *want* Stage 5 to be advisory-only (no write-back)
 * must opt in explicitly by passing `setText: null` (acknowledging
 * that Stage 5 will not mutate the result).
 */
export class AgentShieldLensIncompleteError extends TypeError {
  override readonly name = 'AgentShieldLensIncompleteError'

  constructor() {
    super(
      `shield.run: 'extractText' was supplied without 'setText'. ` +
        `Previously the runtime silently wrote redacted text into a ` +
        `fresh 'result.text' attribute via the default mutator, ` +
        `leaving the original 'extractText' source location (e.g. ` +
        `'r.choices[0].message.content') unredacted — a silent Stage 5 ` +
        `bypass at the opt-in lens surface. Pair 'extractText' with ` +
        `'setText' to ensure redacted text is written back to the ` +
        `assistant-visible location:\n\n` +
        `    await shield.run(thunk, {\n` +
        `      extractText: (r) => r.choices[0].message.content,\n` +
        `      setText: (r, t) => { r.choices[0].message.content = t; return r },\n` +
        `    })\n\n` +
        `To override fail-closed behavior, pass 'setText: null' ` +
        `explicitly (acknowledging Stage 5 will not modify the result; ` +
        `the original text remains in place).`,
    )
  }
}

/**
 * Raised when an LLM-caller adapter is asked to invoke a
 * `configurations[]` entry that does not declare `model:`.
 *
 * A security library MUST NOT pick a model on the customer's behalf.
 * When the runtime resolves the configuration referenced by a guard
 * policy's stage and finds an entry with no `model:` — or no matching
 * entry at all — the LLM caller surfaces this typed exception instead
 * of silently falling back to a hard-coded SKU (`gpt-4o-mini` /
 * `claude-sonnet-4-20250514` historically). The schema in
 * `spec/schema/guardrails.schema.json` rejects entries missing
 * `model:` at load time, so in normal operation this exception fires
 * only when an out-of-band configuration source bypasses schema
 * validation or when the runtime asks for a `configurationId` that
 * doesn't exist.
 *
 * Recovery: declare `model: <name>` on the offending
 * `configurations[]` entry in `.guardrails.yaml`. `model:` is the
 * identifier passed verbatim to the provider SDK — a model name for
 * direct OpenAI, a deployment name for Azure OpenAI, the
 * provider-native identifier for Anthropic / Amazon Bedrock /
 * Google Gemini / Vertex AI / Ollama / etc.
 */
export class ConfigurationMissingModelError extends Error {
  override readonly name = 'ConfigurationMissingModelError'
  readonly configurationId: string | null

  constructor(configurationId: string | null | undefined) {
    const idRepr =
      configurationId == null || configurationId === ''
        ? '<unset>'
        : configurationId
    super(
      `LLM configuration '${idRepr}' is missing 'model'. Add ` +
        `'model: <name>' to the configurations[] entry in your ` +
        `.guardrails.yaml. 'model:' is passed verbatim to the ` +
        `provider SDK — a model name for direct OpenAI, a deployment ` +
        `name for Azure OpenAI.`,
    )
    this.configurationId = configurationId ?? null
  }
}

// ─── Ambient session (AsyncLocalStorage equivalent of
//     Python's contextvars) ─────────────────────────────────────

interface AmbientStore {
  session: SessionLike
  userInput: string
}

const _ambient: AsyncLocalStorage<AmbientStore> = new AsyncLocalStorage()

export function currentSession(): SessionLike | null {
  return _ambient.getStore()?.session ?? null
}

export function currentUserInput(): string {
  return _ambient.getStore()?.userInput ?? ''
}

// ─── Shared orchestration helpers ───────────────────────────────

interface VerdictWire {
  allowed: boolean
  action: string | null
  reason: string | null
  policy: string | null
  evaluate_when_index: number | null
  bypassed_by_allowed_when: boolean
  redaction: string | null
  appended: string | null
  prepended: string | null
}

interface DispatchAction {
  kind: string
  message?: string
  value?: unknown
}

interface DispatchDecision {
  action: DispatchAction
  record_failure?: boolean
  record_success?: boolean
}

// Convert a JS verdict object (the camelCase shape every native
// `validate*` returns post-camelize) to the canonical wire shape
// consumed by the dispatch FFI. We defensively coerce undefined fields
// to null so the wire-shape parser accepts the payload.
function _verdictToWire(v: StageVerdictLike | null | undefined): VerdictWire {
  return {
    allowed: !!(v && v.allowed),
    action: (v && v.action) ?? null,
    reason: (v && v.reason) ?? null,
    policy: (v && v.policy) ?? null,
    evaluate_when_index:
      (v && (v.evaluateWhenIndex ?? v.evaluate_when_index)) ?? null,
    bypassed_by_allowed_when: !!(
      v && (v.bypassedByAllowedWhen ?? v.bypassed_by_allowed_when)
    ),
    redaction: (v && v.redaction) ?? null,
    appended: (v && v.appended) ?? null,
    prepended: (v && v.prepended) ?? null,
  }
}

export function _formatBlock(verdict: StageVerdictLike): string {
  // Single source of truth: route through the core formatter so the
  // canonical `[GUARDRAIL ACTION] reason` string is byte-equivalent
  // across every SDK.
  return formatBlockMessage(_verdictToWire(verdict))
}

/** Optional sink invoked with the structured `pending_resolution`
 *  envelope on a Stage 2/3 block. Mirrors the Python adapter's
 *  `pending_resolution_sink` kwarg and the Node MCP adapter's
 *  callback. */
export type PendingResolutionSink = (pr: PendingResolutionLike) => void

/** Extract the camelCase or snake_case `pending_resolution` envelope
 *  from a stage verdict. Returns `null` when the verdict carries no
 *  suspension. */
export function _extractPendingResolution(
  verdict: StageVerdictLike | null | undefined,
): PendingResolutionLike | null {
  const pr = verdict?.pendingResolution ?? verdict?.pending_resolution ?? null
  return pr ?? null
}

/** Fire a pending-resolution sink iff the verdict carries one.
 *  Sink errors are swallowed so a misbehaving host callback can
 *  never mask the guardrail block. */
export function _firePendingResolutionSink(
  sink: PendingResolutionSink | undefined,
  verdict: StageVerdictLike | null | undefined,
): void {
  if (!sink) return
  const pr = _extractPendingResolution(verdict)
  if (!pr) return
  try {
    sink(pr)
  } catch {
    /* swallow — see MCP adapter rationale */
  }
}

interface DispatchOpts {
  policy?: string
  mode?: string
}

function _dispatchStage(
  verdict: StageVerdictLike,
  opts: DispatchOpts = {},
): DispatchDecision {
  return dispatchStageVerdict(_verdictToWire(verdict), {
    policy: opts.policy ?? 'return_blocked',
    mode: opts.mode ?? 'enforce',
  }) as DispatchDecision
}

interface DispatchToolOpts extends DispatchOpts {
  stage?: string
}

function _dispatchTool(
  verdict: StageVerdictLike,
  toolName: string,
  opts: DispatchToolOpts = {},
): DispatchDecision {
  return dispatchToolVerdict(_verdictToWire(verdict), toolName, {
    stage: opts.stage ?? 'output',
    policy: opts.policy ?? 'return_blocked',
    mode: opts.mode ?? 'enforce',
  }) as DispatchDecision
}

export interface GuardedToolResult {
  blocked: boolean
  output: string
  /**
   * Which validation stage produced the block, when `blocked` is true.
   * Used by `protectToolsViaWrapper` to populate the typed
   * {@link AgentShieldBlockedError} thrown to halt the agent loop.
   * `undefined` on non-blocked outcomes.
   */
  stage?: 'tool_call' | 'tool_output' | 'tool_error'
  /**
   * Structured suspension envelope when a Stage 2/3 block
   * was caused by a resolver awaiting external input (e.g. a
   * `kind: human` resolver pending operator approval). `null` on
   * every other outcome (allowed call, plain deny without a
   * suspension, Stage 4 redaction).
   *
   * Mirrors the Python adapter's `last_pending_resolution()` shape
   * and the Node MCP adapter's `ProtectToolResult.pendingResolution`
   * field. Hosts who only need the canonical surface can ignore
   * this and read {@link Shield.lastPendingResolution} instead — both
   * paths see the same envelope.
   */
  pendingResolution?: PendingResolutionLike | null
}

async function _guardedTool(
  session: SessionLike,
  toolName: string,
  params: Record<string, unknown> | null | undefined,
  execute: (effective: Record<string, unknown>) => Promise<unknown>,
  _opts: {
    userInput?: string
    pendingResolutionSink?: PendingResolutionSink
    toolCallId?: string
  } = {},
): Promise<GuardedToolResult> {
  const pendingSink = _opts.pendingResolutionSink
  const cleaned: Record<string, unknown> = { ...(params ?? {}) }
  for (const k of Object.keys(cleaned)) {
    // eslint-disable-next-line security/detect-object-injection -- k is enumerated from the local cleaned tool params object.
    if (cleaned[k] === undefined || cleaned[k] === null) delete cleaned[k]
  }
  // binding: this is a wrapper-owned Pattern-B dispatch boundary.
  // Honor the caller-supplied tool-call id when provided so the
  // upstream framework's id (Vercel AI SDK `toolCallId`, OpenAI
  // `tool_call.id`, Anthropic `tool_use.id`, …) propagates to Stage 3,
  // Stage 4, and Stage 5 observability events for cross-system trace
  // correlation. When the caller omits it, mint a stable per-call UUID
  // so concurrent same-name dispatches don't collide on the binding key.
  const callId =
    typeof _opts.toolCallId === 'string' && _opts.toolCallId.length > 0
      ? _opts.toolCallId
      : randomUUID()
  const callOutcome = await session.validateToolCall(toolName, cleaned, callId)
  const callDecision = _dispatchTool(callOutcome.verdict, toolName, { stage: 'call' })
  if (callDecision.action.kind === 'blocked') {
    // Surface the structured pending_resolution envelope to
    // the host via the optional sink AND in the returned shape so
    // callers can recover the suspension without re-validating.
    _firePendingResolutionSink(pendingSink, callOutcome.verdict)
    return {
      blocked: true,
      stage: 'tool_call',
      output: callDecision.action.message ?? '',
      pendingResolution: _extractPendingResolution(callOutcome.verdict),
    }
  }
  const effective =
    (callOutcome.params as Record<string, unknown> | undefined) ?? cleaned

  let raw: unknown
  try {
    raw = await execute(effective)
  } catch (err) {
    try {
      session.recordToolFailure(toolName, String(err))
    } catch {
      /* swallow */
    }
    const errText = `[tool error] ${toolName}: ${err}`
    const errOutcome = await session.validateToolOutput(toolName, errText, callId)
    const errDecision = _dispatchStage(errOutcome.verdict)
    if (errDecision.action.kind === 'return_blocked') {
      _firePendingResolutionSink(pendingSink, errOutcome.verdict)
      return {
        blocked: true,
        stage: 'tool_error',
        output: errDecision.action.message ?? '',
        pendingResolution: _extractPendingResolution(errOutcome.verdict),
      }
    }
    return { blocked: false, output: String(errOutcome.result ?? errText), pendingResolution: null }
  }

  // Pass `raw` directly to Stage 4 so the
  // Rust core sees the actual structured value (object / array /
  // number / boolean) rather than `"[object Object]"` / a stringified
  // primitive. Stage-4 redaction patterns now match against the real
  // canonical JSON of the tool output, and `Session.validateToolOutput`
  // restores the container shape on the way out.
  const outOutcome = await session.validateToolOutput(toolName, raw, callId)
  const outDecision = _dispatchTool(outOutcome.verdict, toolName, { stage: 'output' })
  if (outDecision.action.kind === 'blocked') {
    if (outDecision.record_failure) {
      try {
        session.recordToolFailure(toolName, outOutcome.verdict.reason ?? 'blocked')
      } catch {
        /* swallow */
      }
    }
    _firePendingResolutionSink(pendingSink, outOutcome.verdict)
    return {
      blocked: true,
      stage: 'tool_output',
      output: outDecision.action.message ?? '',
      pendingResolution: _extractPendingResolution(outOutcome.verdict),
    }
  }

  // The customer-facing `output` is a string (framework-friendly
  // shape). When Stage 4 returned a structured value (because the
  // shape-recovery walker rebuilt the container) — or when the
  // tool itself returned a non-string — render via JSON so callers
  // see the canonical form instead of `"[object Object]"`. Strings
  // pass through unchanged; `null` / `undefined` collapse to `''`
  // for the framework contract.
  const final = outOutcome.result ?? raw
  let finalStr: string
  if (typeof final === 'string') {
    finalStr = final
  } else if (final === null || final === undefined) {
    finalStr = ''
  } else {
    try {
      finalStr = JSON.stringify(final)
    } catch {
      finalStr = String(final)
    }
  }
  if (outDecision.record_success) {
    try {
      session.recordToolSuccess(toolName, finalStr)
    } catch {
      /* swallow */
    }
  }
  return { blocked: false, output: finalStr, pendingResolution: null }
}

/**
 * Result of a Stage 1 (`input_validation`) pre-invoke check.
 *
 * Spec: a `redact` action on a content stage rewrites
 * the subject and "the rewritten subject continues through downstream
 * stages." Callers that own the agent invocation MUST forward
 * `effectiveInput` (not the original `userInput`) to the framework so
 * the redacted text flows into the agent.
 */
interface Stage1Decision {
  kind: 'proceed' | 'block'
  effectiveInput: string | null
  blockMessage: string | null
}

async function _checkStage1(
  session: SessionLike,
  userInput: string | undefined,
): Promise<Stage1Decision> {
  if (!userInput) {
    return { kind: 'proceed', effectiveInput: userInput ?? null, blockMessage: null }
  }
  const verdict = await session.validateInput(userInput)
  const decision = _dispatchStage(verdict)
  if (decision.action.kind === 'return_blocked') {
    return {
      kind: 'block',
      effectiveInput: null,
      blockMessage: decision.action.message ?? '',
    }
  }
  let effectiveInput = userInput
  if (decision.action.kind === 'proceed_with_mutation') {
    effectiveInput = String(decision.action.value ?? userInput)
  }
  return { kind: 'proceed', effectiveInput, blockMessage: null }
}

// ─── Per-session turn serialization ──────────────────────────────
//
// Sessions are serial by spec contract: per_turn variables, event
// latching, and the beginTurn/endTurn lifetime engine all assume a
// single in-flight turn at a time. When a customer accidentally
// dispatches two `shield.run(..., {session: s})` calls concurrently
// on the same session (e.g. via `Promise.all`), the SDK must not
// silently leak per-turn state into the second call.
//
// Strategy: a per-session FIFO queue (via WeakMap) chains overlapping
// turns so the second `shield.run` awaits the first's end before its
// beginTurn fires. Reentrant calls — where the current call is
// already running inside an ambient frame for the same session —
// skip the queue (avoiding self-deadlock) and skip beginTurn/endTurn
// (folding into the outer turn). Customers who want louder failures
// can opt in to `{ onConcurrent: 'reject' }`, which surfaces a
// `SessionBusyError` instead of queueing.

export type OnConcurrentPolicy = 'serialize' | 'reject'

/**
 * Thrown when {@link Shield} is configured with
 * `onConcurrent: 'reject'` and a second `shield.run` / `runStreamed`
 * call is dispatched on a session that is already in the middle of
 * an in-flight turn driven by the same Shield.
 *
 * Default behavior is `'serialize'`, which queues instead of
 * throwing. See the per-session turn serialization contract above.
 */
export class SessionBusyError extends Error {
  constructor(message?: string) {
    super(
      message ??
        'Shield session is already running a turn. Concurrent ' +
          'shield.run / runStreamed calls on the same Session are ' +
          'disallowed when `onConcurrent: "reject"` is set.',
    )
    this.name = 'SessionBusyError'
  }
}

const _sessionTurnQueue: WeakMap<SessionLike, Promise<unknown>> = new WeakMap()

function _isReentrantOnSession(session: SessionLike): boolean {
  const ambient = _ambient.getStore()
  return !!ambient && ambient.session === session
}

/**
 * Serialize `fn` against any other in-flight turn on `session`.
 *
 * Contract:
 *
 * - Reentrant calls (ambient session matches) bypass the queue and
 *   run inline; otherwise we'd self-deadlock waiting for our own
 *   outer turn to release the slot.
 * - `onConcurrent === 'reject'` throws {@link SessionBusyError}
 *   instead of waiting when the queue is non-empty.
 * - Upstream errors are swallowed via `prev.catch(() => {})` so a
 *   throwing turn 1 does not poison queued turn 2.
 * - The slot is released in `finally`, so generator close, throws,
 *   and normal completion all unblock the queue.
 */
async function _withSessionTurnSlot<T>(
  session: SessionLike,
  onConcurrent: OnConcurrentPolicy,
  fn: () => Promise<T>,
): Promise<T> {
  if (_isReentrantOnSession(session)) {
    return await fn()
  }
  const prev = _sessionTurnQueue.get(session)
  if (prev !== undefined && onConcurrent === 'reject') {
    throw new SessionBusyError()
  }
  let releaseSlot!: () => void
  const slot = new Promise<void>((resolve) => {
    releaseSlot = resolve
  })
  _sessionTurnQueue.set(session, slot)
  try {
    if (prev !== undefined) {
      await prev.catch(() => undefined)
    }
    return await fn()
  } finally {
    releaseSlot()
    if (_sessionTurnQueue.get(session) === slot) {
      _sessionTurnQueue.delete(session)
    }
  }
}

// ─── GuardedRunner ──────────────────────────────────────────────

export interface GuardedRunnerOpts {
  mode?: ShieldModeValue
  onBlock?: OnBlockPolicy
  streamingConfig?: Record<string, unknown>
  onConcurrent?: OnConcurrentPolicy
}

export interface RunOpts extends Record<string, unknown> {
  session?: SessionLike
}

export class GuardedRunner<TAgent = unknown, TResult = unknown> {
  protected readonly _runtime: RuntimeLike
  protected readonly _agent: TAgent
  protected readonly _boundary: AgentBoundary<TAgent, TResult>
  protected readonly _streaming: StreamingAdapter<TAgent, unknown> | undefined
  protected readonly _mode: ShieldModeValue
  protected readonly _onBlock: OnBlockPolicy
  protected readonly _streamingConfig: Record<string, unknown> | undefined
  protected readonly _onConcurrent: OnConcurrentPolicy
  protected readonly _session: SessionLike

  constructor(
    runtime: RuntimeLike,
    agent: TAgent,
    boundary: AgentBoundary<TAgent, TResult>,
    streaming?: StreamingAdapter<TAgent, unknown>,
    opts: GuardedRunnerOpts = {},
  ) {
    if (!boundary) {
      throw new TypeError(
        'GuardedRunner requires an AgentBoundary; framework adapter does not support agent run wrapping',
      )
    }
    this._runtime = runtime
    this._agent = agent
    this._boundary = boundary
    this._streaming = streaming
    // Shadow mode (#14) forces MONITOR.
    const runtimeMode = typeof runtime.mode === 'function'
      ? runtime.mode()
      : 'active'
    this._mode = runtimeMode === 'shadow'
      ? ShieldMode.MONITOR
      : (opts.mode ?? ShieldMode.ENFORCE)
    this._onBlock = opts.onBlock ?? 'returnBlocked'
    this._streamingConfig = opts.streamingConfig
    this._onConcurrent = opts.onConcurrent ?? 'serialize'
    this._session = runtime.newSession()
  }

  get agent(): TAgent {
    return this._agent
  }

  /**
   * Returns a NEW `GuardedRunner` bound to a fresh session spawned
   * from the same runtime. The original runner — and any in-flight
   * conversation it owns — is not mutated. This is the canonical,
   * post-build-immutable way to "start a new conversation" for an
   * agent.
   *
   * Mirrors the Rust `Shield::with_fresh_session`, the .NET
   * `Shield.WithFreshSession`, and the Python
   * `GuardedRunner.with_fresh_session` APIs.
   */
  withFreshSession(): GuardedRunner<TAgent, TResult> {
    return new GuardedRunner<TAgent, TResult>(
      this._runtime,
      this._agent,
      this._boundary,
      this._streaming,
      {
        mode: this._mode,
        onBlock: this._onBlock,
        streamingConfig: this._streamingConfig,
        onConcurrent: this._onConcurrent,
      },
    )
  }

  async run(inputText: string | undefined, opts: RunOpts = {}): Promise<TResult> {
    const session = opts.session ?? this._session
    const boundary = this._boundary
    const onBlock = this._onBlock
    const mode = this._mode
    const reentrant = _isReentrantOnSession(session)

    const drive = async (): Promise<TResult> => {
      const ambientStore = { session, userInput: inputText ?? '' }
      return await _ambient.run(
        ambientStore,
        async (): Promise<TResult> => {
          if (!reentrant) session.beginTurn()
          try {
            let effectiveInput = inputText ?? ''
            if (mode === ShieldMode.MONITOR) {
              return await this._runMonitorMode(session, inputText, opts)
            }

            // Stage 1 — canonical dispatch.
            if (inputText) {
              const verdict = await session.validateInput(inputText)
              const decision = _dispatchStage(verdict)
              if (decision.action.kind === 'return_blocked') {
                return _resolveBlock(
                  onBlock,
                  boundary,
                  verdict,
                  decision.action.message ?? '',
                ) as TResult
              }
              if (decision.action.kind === 'proceed_with_mutation') {
                effectiveInput = String(decision.action.value ?? effectiveInput)
              }
            }
            ambientStore.userInput = effectiveInput

            let result: TResult
            try {
              result = await boundary.run(this._agent, effectiveInput, opts)
            } catch (err) {
              // F-probe-1.5 / F-probe-1.6 — fail-closed.
              //
              // A guarded tool wrapped by `shield.protectTools(...)`
              // (Pattern A) throws `AgentShieldBlockedError` when a
              // Stage 2/3/4 deny fires. Convert that into the
              // canonical block envelope so the agent loop halts
              // with the same shape Stage 1/5 produces.
              if (err instanceof AgentShieldBlockedError) {
                return _resolveBlock(
                  onBlock,
                  boundary,
                  err.verdict as StageVerdictLike | null | undefined,
                  err.blockMessage,
                ) as TResult
              }
              throw err
            }

            const outputText = boundary.extractOutput(result)
            if (typeof outputText === 'string' && outputText.length > 0) {
              const outcome = await session.validateOutput(outputText)
              const stage5 = _dispatchStage(outcome.verdict)
              if (stage5.action.kind === 'return_blocked') {
                return _resolveBlock(
                  onBlock,
                  boundary,
                  outcome.verdict,
                  stage5.action.message ?? '',
                ) as TResult
              }
              if (stage5.action.kind === 'proceed_with_mutation') {
                return boundary.applyRedaction(result, outcome.response)
              }
            }
            return result
          } finally {
            if (!reentrant) {
              try {
                session.endTurn()
              } catch {
                /* swallow */
              }
            }
          }
        },
      )
    }

    return await _withSessionTurnSlot(session, this._onConcurrent, drive)
  }

  protected async _runMonitorMode(
    session: SessionLike,
    inputText: string | undefined,
    opts: RunOpts,
  ): Promise<TResult> {
    // Run validation for observability; never block. Core stamps every
    // emitted event with `mode: shadow` + `enforced: false` and routes
    // through the registered ObservabilityProvider.
    try {
      await session.validateInput(inputText ?? '')
    } catch {
      /* swallow */
    }
    const result = await this._boundary.run(this._agent, inputText, opts)
    const outputText = this._boundary.extractOutput(result)
    if (typeof outputText === 'string' && outputText.length > 0) {
      try {
        await session.validateOutput(outputText)
      } catch {
        /* swallow */
      }
    }
    return result
  }

  /**
   * Run the agent with streaming Stage 5 enforcement.
   *
   * Emission scheduling honours the streaming guard's configured mode
   * (see {@link StreamingMode}). When the mode is `on_complete` the
   * orchestrator pushes every text-bearing chunk through the engine
   * for accumulation but emits NOTHING to the consumer until
   * `validator.finish()` resolves — that final call yields a single
   * terminal chunk carrying the validated/redacted text (or a block
   * message if Stage 5 stopped the buffer). When the mode is
   * `per_chunk` or `windowed` the framework adapter forwards
   * validated chunks in real time.
   *
   * Metadata-only chunks (no text content) are always passed through
   * promptly because they are not security-relevant.
   */
  async *runStreamed(
    inputText: string | undefined,
    opts: RunOpts = {},
  ): AsyncGenerator<unknown, void, void> {
    if (!this._streaming) {
      throw new Error(
        'streaming is unsupported for this framework (no StreamingAdapter in bundle)',
      )
    }
    const session = opts.session ?? this._session
    const boundary = this._boundary
    const streaming = this._streaming
    const reentrant = _isReentrantOnSession(session)

    // Acquire the per-session slot *outside* the generator body so
    // back-pressure from the consumer doesn't keep the lock if the
    // consumer hasn't started pulling yet. Reentrant calls bypass —
    // their outer turn already owns the slot.
    if (!reentrant) {
      const prev = _sessionTurnQueue.get(session)
      if (prev !== undefined && this._onConcurrent === 'reject') {
        throw new SessionBusyError()
      }
      let releaseSlot!: () => void
      const slot = new Promise<void>((resolve) => {
        releaseSlot = resolve
      })
      _sessionTurnQueue.set(session, slot)
      try {
        if (prev !== undefined) {
          await prev.catch(() => undefined)
        }
        session.beginTurn()
        try {
          yield* this._runStreamedBody(session, boundary, streaming, inputText, opts)
        } finally {
          try {
            session.endTurn()
          } catch {
            /* swallow */
          }
        }
      } finally {
        releaseSlot()
        if (_sessionTurnQueue.get(session) === slot) {
          _sessionTurnQueue.delete(session)
        }
      }
      return
    }

    // Reentrant: fold into outer turn, no begin/end, no queue.
    yield* this._runStreamedBody(session, boundary, streaming, inputText, opts)
  }

  protected async *_runStreamedBody(
    session: SessionLike,
    boundary: AgentBoundary<TAgent, TResult>,
    streaming: StreamingAdapter<TAgent, unknown>,
    inputText: string | undefined,
    opts: RunOpts,
  ): AsyncGenerator<unknown, void, void> {
    // Shadow / Monitor (#14): run Stage 1 for observability but
    // never short-circuit; stream through a monitor validator that
    // pushes chunks to the real Stage-5 streaming guard for audit
    // events but always emits the original chunks. Core stamps
    // every emitted event with `mode: shadow` + `enforced: false`.
    if (this._mode === ShieldMode.MONITOR) {
      await session.validateInput(inputText ?? '')
      let guard: StreamingGuardLike | null = null
      try {
        guard = session.streamingSession(5)
      } catch {
        /* fall back to no-guard observability */
      }
      const passthrough = new _MonitorStreamingValidator(boundary, guard)
      const inner = streaming.stream(this._agent, inputText, passthrough, opts)
      for await (const emission of inner) {
        yield emission
      }
      // Drain the guard's finish() so any tail Stage-5 evaluation
      // fires for observability.
      if (guard) {
        try {
          await passthrough.finish()
        } catch {
          /* swallow */
        }
      }
      return
    }

    const stage1 = await _checkStage1(session, inputText)
    if (stage1.kind === 'block') {
      yield boundary.makeBlocked(stage1.blockMessage ?? '')
      return
    }
    // Spec: Stage 1 `redact` rewrites the subject and
    // "the rewritten subject continues through downstream stages."
    // Forward the post-Stage-1 effectiveInput (which equals
    // `inputText` when no redaction applied) to the streaming adapter
    // so the agent never sees the unredacted subject.
    const effectiveInput = stage1.effectiveInput ?? inputText
    const guard = session.streamingSession(5)
    const validator = new _OrchestratorStreamingValidator(guard, boundary)
    const inner = streaming.stream(this._agent, effectiveInput, validator, opts)
    for await (const emission of inner) {
      yield emission
    }
  }
}

class _OrchestratorStreamingValidator implements StreamingValidatorLike {
  private readonly _guard: StreamingGuardLike
  private readonly _boundary: AgentBoundary

  constructor(guard: StreamingGuardLike, boundary: AgentBoundary) {
    this._guard = guard
    this._boundary = boundary
  }

  get mode(): StreamingMode {
    return this._guard.mode
  }

  async push(text: string) {
    const r = await this._guard.addChunk(text)
    const action = _normalizeStreamAction(r.action)
    return {
      action,
      payload: r.payload ?? null,
      stopped: action === 'stop' || !!(r as { stopped?: boolean }).stopped,
      reason: r.reason ?? null,
    }
  }

  async finish() {
    const r = await this._guard.finish()
    const action = _normalizeStreamAction(r.action)
    return {
      action,
      payload: r.payload ?? null,
      stopped: action === 'stop' || !!(r as { stopped?: boolean }).stopped,
      reason: r.reason ?? null,
    }
  }

  makeBlocked(message: string): unknown {
    return this._boundary.makeBlocked(message)
  }

  applyRedaction(chunk: unknown, text: string): unknown {
    return this._boundary.applyRedaction(chunk, text)
  }
}

/**
 * Normalise the wire `action` string into the canonical
 * `'pass' | 'replace' | 'stop'` union. Unknown / missing values fall
 * back to `'pass'` (the safe default for legacy guards that predate
 * the action union; their behaviour is byte-equivalent to a plain
 * `pass` because the engine still drives the `payload` field).
 */
function _normalizeStreamAction(
  raw: string | null | undefined,
): 'pass' | 'replace' | 'stop' {
  if (raw === 'replace' || raw === 'stop') return raw
  return 'pass'
}

/**
 * Test hook — the orchestrator validator that bridges
 * {@link Session.streamingSession} into the {@link StreamingValidatorLike}
 * protocol. Internal: not part of the stable public API; exported so
 * cross-language test parity can drive it
 * directly with a stub guard.
 */
export const _OrchestratorStreamingValidatorForTests =
  _OrchestratorStreamingValidator

/**
 * Monitor-mode streaming validator (#14). Pushes chunks through the
 * real Stage-5 streaming guard for observability, logs a warning
 * when the guard would have blocked or redacted, but always emits
 * the ORIGINAL chunk text and never reports `stopped`. `finish()` is
 * idempotent: the adapter typically calls it at the end of `stream()`
 * and the orchestrator may call it again for tail drain; the second
 * call is a no-op so we don't emit a spurious "stream already ended"
 * warning.
 */
class _MonitorStreamingValidator implements StreamingValidatorLike {
  private readonly _guard: StreamingGuardLike | null
  private readonly _boundary: AgentBoundary
  private _finished = false

  constructor(boundary: AgentBoundary, guard: StreamingGuardLike | null) {
    this._boundary = boundary
    this._guard = guard
  }

  get mode(): StreamingMode {
    // Per-chunk so the adapter forwards chunks promptly; in shadow
    // we never want to buffer the customer's output.
    return 'per_chunk' as StreamingMode
  }

  async push(text: string) {
    if (this._guard) {
      try {
        await this._guard.addChunk(text)
      } catch {
        /* swallow — observability is best-effort */
      }
    }
    return { action: 'pass' as const, payload: text, stopped: false, reason: null }
  }

  async finish() {
    if (this._finished) {
      return { action: 'pass' as const, payload: null, stopped: false, reason: null }
    }
    this._finished = true
    if (this._guard) {
      try {
        await this._guard.finish()
      } catch {
        /* swallow */
      }
    }
    return { action: 'pass' as const, payload: null, stopped: false, reason: null }
  }

  makeBlocked(message: string): unknown {
    return this._boundary.makeBlocked(message)
  }

  applyRedaction(chunk: unknown, text: string): unknown {
    return this._boundary.applyRedaction(chunk, text)
  }
}

function _resolveBlock(
  onBlock: OnBlockPolicy,
  boundary: AgentBoundary,
  verdict: StageVerdictLike | null | undefined,
  message: string,
): unknown {
  // Function form is the host's custom callback — core never owns it.
  if (typeof onBlock === 'function') {
    return onBlock(verdict ?? message)
  }
  // For everything else, route through the canonical dispatcher so
  // the action tag is identical to what every other SDK computes.
  // We synthesise a deny verdict when the caller passed only a
  // message (the Stage-1 path); otherwise the real verdict drives.
  const v: StageVerdictLike =
    verdict ?? {
      allowed: false,
      action: 'block',
      reason: message?.replace(/^\[GUARDRAIL [A-Z]+\]\s*/, '') ?? null,
    }
  const policy =
    typeof onBlock === 'string'
      ? onBlock === 'raise'
        ? 'raise'
        : onBlock === 'returnVerdict' || onBlock === 'return_verdict'
          ? 'return_verdict'
          : 'return_blocked'
      : 'return_blocked'
  const decision = _dispatchStage(v, { policy })
  const action = decision.action
  switch (action.kind) {
    case 'raise':
      throw new AgentShieldBlocked(verdict, action.message ?? '')
    case 'return_verdict':
      return verdict
    case 'return_blocked':
    default:
      return boundary.makeBlocked(action.message ?? '')
  }
}

// ─── Tool registry: wrap a list of framework tools ──────────────

export async function protectToolsViaWrapper<TTool, TGuarded>(
  runtime: RuntimeLike,
  tools: readonly TTool[],
  wrapper: ToolWrapper<TTool, TGuarded>,
  opts: Record<string, unknown> = {},
): Promise<TGuarded[]> {
  // Shadow / Monitor (#14): when called via `Shield.protectTools` with
  // shadow runtime, the caller passes `mode: 'monitor'` here. In that
  // mode we still run Stage 3 / Stage 4 for observability but always
  // execute the underlying tool with the caller's original params.
  const monitor = opts.mode === ShieldMode.MONITOR || opts.mode === 'monitor'
  // Fail-closed by default when a wrapped tool is invoked
  // outside any ambient session. Opt back in to the legacy
  // fresh-session-per-call path via `{ allowUnguarded: true }`.
  // MONITOR mode is exempt (look-but-don't-block by design).
  const allowUnguarded = opts.allowUnguarded === true
  // Optional sink threaded down into `_guardedTool` so a
  // Stage 2/3/4 deny carrying a `pending_resolution` envelope is
  // surfaced to the host. `Shield.protectTools` wires its own
  // capture sink so `shield.lastPendingResolution()` is populated.
  const pendingResolutionSink = opts.pendingResolutionSink as
    | PendingResolutionSink
    | undefined
  const out: TGuarded[] = []
  for (const tool of tools) {
    const meta = wrapper.extract(tool)
    const guardedInvoke = async (
      params: Record<string, unknown>,
      userInput?: string,
    ): Promise<string> => {
      const ambientSession = currentSession()
      if (!ambientSession && !monitor && !allowUnguarded) {
        throw new UnguardedToolInvocationError(meta.name)
      }
      const session = ambientSession ?? runtime.newSession()
      const inp = userInput ?? currentUserInput()
      const ambient = _ambient.getStore()
      const exec = async (effective: Record<string, unknown>) =>
        wrapper.invoke(tool, effective)
      if (monitor) {
        const ambientStore = _ambient.getStore()
        const ownTurn = !ambientStore
        if (ownTurn) {
          session.beginTurn()
        }
        const runMonitor = async (): Promise<string> => {
          const effective: Record<string, unknown> = { ...(params ?? {}) }
          // mint a per-call id so concurrent same-name MONITOR
          // calls bind correctly through Stage 3 → Stage 4.
          const _monCallId = randomUUID()
          await session.validateToolCall(meta.name, effective, _monCallId)
          let raw: unknown
          try {
            raw = await exec(params ?? {})
          } catch (err) {
            const errText = `[tool error] ${meta.name}: ${String(err)}`
            await session.validateToolOutput(meta.name, errText, _monCallId)
            try {
              session.recordToolFailure(meta.name, String(err))
            } catch {
              /* swallow */
            }
            return errText
          }
          await session.validateToolOutput(meta.name, raw, _monCallId)
          try {
            session.recordToolSuccess(meta.name, raw)
          } catch {
            /* swallow */
          }
          return typeof raw === 'string' ? raw : raw == null ? '' : String(raw)
        }
        try {
          if (ambientStore) {
            return await runMonitor()
          }
          return await _ambient.run({ session, userInput: inp }, runMonitor)
        } finally {
          if (ownTurn) {
            try {
              session.endTurn()
            } catch {
              /* swallow */
            }
          }
        }
      }
      let result: GuardedToolResult
      if (ambient) {
        result = await _guardedTool(session, meta.name, params, exec, {
          userInput: inp,
          pendingResolutionSink,
        })
      } else {
        result = await _ambient.run(
          { session, userInput: inp },
          () =>
            _guardedTool(session, meta.name, params, exec, {
              userInput: inp,
              pendingResolutionSink,
            }),
        )
      }
      if (result.blocked) {
        // F-probe-1.5 / F-probe-1.6 — fail-closed.
        //
        // Returning the deny payload as a "successful" tool
        // observation lets the LLM treat the block as a recoverable
        // tool error and continue its loop, often producing
        // affirmative narrative that contradicts the block (e.g.
        // claiming a transfer succeeded after Stage 2 denied it).
        //
        // Throw a typed error instead. Adapters at the public
        // boundary (`runOpenaiAgent`, `GuardedRunner.run`, the
        // LangChain adapter's `createLangchainAgent` ToolNode
        // wiring) catch this and turn it into the canonical block
        // envelope so the agent loop halts.
        throw new AgentShieldBlockedError({
          toolName: meta.name,
          stage: result.stage ?? 'tool_call',
          message: result.output,
          pendingResolution:
            (result.pendingResolution as PendingResolutionShape | null) ?? null,
        })
      }
      return result.output
    }
    out.push(wrapper.wrap(tool, meta, guardedInvoke))
  }
  return out
}

// ─── Adapter observability emitter ──────────────────────────────
//
// Builds a `ShieldLogEvent`-shaped event (snake_case → camelCase
// already applied because we never round-trip through napi for these)
// and feeds it to every registered provider. Errors thrown by
// providers are swallowed — observability is fire-and-forget.

/**
 * Sanitize an adapter-side throwable into a safe taxonomy
 * payload suitable for `warn`+ observability emission.
 *
 * Returns only fields that are guaranteed non-sensitive:
 *   - `errorType`: the JS error class name (`TypeError`, `Error`, ...)
 *     for `instanceof Error` throwables, `"NonError"` otherwise.
 *   - `errorClass`: same as `errorType` today, reserved for future
 *     higher-level taxonomy (e.g. mapping known SDK errors to a
 *     stable namespace like `"agent_shield.adapter.network"`).
 *   - `messageHash`: a short stable hash of the raw `Error.message`
 *     for cross-event correlation without exposing the payload.
 *
 * `Error.message` itself is intentionally *not* returned by this
 * helper; callers must consult the original throwable directly if
 * they need the raw text (and emit it only at `debug`).
 *
 * See docs/logging-style-guide.md Rule 1.
 */
export function _sanitizeAdapterErrorMessage(error: unknown): {
  errorType: string
  errorClass: string
  messageHash: string
} {
  const isErr = error instanceof Error
  const errorType = isErr ? error.name || 'Error' : 'NonError'
  // FNV-1a 32-bit hash on the raw message string. Deterministic,
  // cheap, no dependency. Hex-encoded so it's grep-safe in logs.
  const raw = isErr ? error.message : String(error ?? '')
  let h = 0x811c9dc5
  for (let i = 0; i < raw.length; i++) {
    h ^= raw.charCodeAt(i)
    // Math.imul keeps the 32-bit multiply well-defined under JS
    // semantics; the `>>> 0` collapses back to unsigned.
    h = Math.imul(h, 0x01000193) >>> 0
  }
  const messageHash = ('00000000' + h.toString(16)).slice(-8)
  return { errorType, errorClass: errorType, messageHash }
}

// One-time per-process warning when a ShieldBuilder ships
// to production without explicitly picking the observability schema.
// Exported for test introspection (`_resetObservabilitySchemaWarn`
// resets the flag so each test can assert the one-shot behavior).
let _observabilitySchemaDefaultWarned = false

export function _maybeWarnObservabilitySchemaDefault(
  hasProviders: boolean,
): void {
  if (!hasProviders) return
  if (_observabilitySchemaDefaultWarned) return
  _observabilitySchemaDefaultWarned = true
  // eslint-disable-next-line no-console -- intentional one-time
  // deprecation warning for the observability schema migration.
  console.warn(
    "AgentShield: observability provider schema will switch to canonical " +
      "snake_case in next major; set `observabilityProviderSchema: 'snakeCase'` " +
      "to opt in early, or `'camelCase'` to lock in current behavior.",
  )
}

export function _resetObservabilitySchemaWarn(): void {
  _observabilitySchemaDefaultWarned = false
}

export function _emitAdapterErrorEvent(
  providers: ReadonlyArray<(event: unknown) => void>,
  adapterName: string,
  error: unknown,
  schema: ObservabilityProviderSchema = 'camelCase',
): void {
  if (!providers || providers.length === 0) return
  const sanitized = _sanitizeAdapterErrorMessage(error)
  const timestamp = new Date().toISOString()
  const baseEvent = {
    timestamp,
    eventType: 'adapter.llm_caller_error',
    category: 'adapter',
    stage: null,
    action: null,
    guardPolicy: null,
    evaluateWhenIndex: null,
    resource: null,
    variable: null,
    eventId: null,
    correlationId: '',
    sessionId: '',
    userId: null,
    tenantId: null,
  }
  // At warn+ severity we strip the raw Error.message. Only
  // the safe taxonomy (error class, hash for correlation) is emitted
  // so PII / secrets / tool args carried in an exception message
  // cannot leak to every registered observability sink. The full
  // message is still available, but only on the `debug`-level event
  // that follows (operator-controlled per the logging style guide).
  const warnEvent = {
    ...baseEvent,
    severity: 'warn',
    message:
      `${adapterName} llm caller error ` +
      `[${sanitized.errorType}#${sanitized.messageHash}]`,
    attributes: {
      'agent_shield.adapter.name': adapterName,
      'agent_shield.adapter.error_type': sanitized.errorType,
      'agent_shield.adapter.error_class': sanitized.errorClass,
      'agent_shield.adapter.message_hash': sanitized.messageHash,
    },
  }
  const rawMessage = error instanceof Error ? error.message : String(error ?? '')
  const debugEvent = {
    ...baseEvent,
    severity: 'debug',
    message: `${adapterName} llm caller error: ${rawMessage}`,
    attributes: {
      'agent_shield.adapter.name': adapterName,
      'agent_shield.adapter.error_type': sanitized.errorType,
      'agent_shield.adapter.error_class': sanitized.errorClass,
      'agent_shield.adapter.message_hash': sanitized.messageHash,
      'agent_shield.adapter.error_message': rawMessage,
    },
  }
  // Honour the customer's chosen provider schema. Events are
  // built in canonical camelCase above; if the customer opted into
  // canonical snake_case (matching Rust / Python /.NET), reshape
  // before invoking each provider. Lazy lookup avoids the
  // shield.ts ↔ index.ts initialisation cycle.
  const reshape = (ev: unknown): unknown => {
    if (schema !== 'snakeCase') return ev
    const snakeify = (_index as { _snakeifyEvent?: (v: unknown) => unknown })
      ._snakeifyEvent
    return snakeify ? snakeify(ev) : ev
  }
  for (const p of providers) {
    for (const ev of [warnEvent, debugEvent]) {
      try {
        p(reshape(ev))
      } catch {
        // Providers must never break the caller — fire and forget.
      }
    }
  }
}

// ─── Shield orchestrator ────────────────────────────────────────

export interface ShieldOpts {
  bundle?: CapabilityBundle | null
  mode?: ShieldModeValue
  onBlock?: OnBlockPolicy
  /**
   * Controls behavior when a second `shield.run` / `runStreamed` /
   * `beforeInvoke` call arrives on a {@link SessionLike} that is
   * still in the middle of an in-flight turn driven by this Shield.
   *
   * - `'serialize'` (default) — queue the new call after the
   *   in-flight turn ends. Sessions are serial by spec contract; the
   *   queue prevents `per_turn` variable leakage across overlapping
   *   `shield.run` invocations.
   * - `'reject'` — throw {@link SessionBusyError} synchronously.
   *
   * Reentrant calls — where the new `shield.run` is dispatched from
   * inside the ambient frame of an outer `shield.run` on the same
   * session — bypass the queue and fold into the outer turn under
   * both policies (otherwise the SDK would self-deadlock).
   */
  onConcurrent?: OnConcurrentPolicy
  streamingConfig?: Record<string, unknown>
  observabilityProviders?: ReadonlyArray<(event: unknown) => void>
  /**
   * Selects the wire schema events use when they reach
   * `observabilityProviders`. `'snakeCase'` matches the canonical
   * Rust core / Python /.NET shape (`event_type`, `guard_policy`,
   * `correlation_id`, `session_id`). `'camelCase'` (default for
   * now) is the historical Node shape. The default will flip to
   * `'snakeCase'` in the next major; until then, builders that
   * neither opt in nor lock in see a one-time `console.warn` at
   * {@link ShieldBuilder.build}.
   */
  observabilityProviderSchema?: ObservabilityProviderSchema
}

export interface ProtectToolsOpts {
  /**
   * Opt back into the legacy fresh-session-per-call behavior for
   * wrapped tools invoked outside any guarded session (no
   * `shield.guard(agent)` wrapper, no ambient context from
   * `shield.run(...)`).
   *
   * When `false` (the default), wrapped tools invoked outside an
   * ambient session throw {@link UnguardedToolInvocationError} so
   * a forgotten Pattern A wiring cannot silently neuter stateful
   * guardrails (per_turn / per_session variables, event latches,
   * approval state). Mirrors Python `allow_unguarded`.
   *
   * When `true`, a fresh session is minted per call and the tool
   * runs in isolation — useful for one-shot ad-hoc invocations
   * where the caller explicitly accepts that per_turn /
   * per_session gates do not carry across calls.
   *
   * MONITOR mode always silently mints a fresh session (parity
   * with Python: MONITOR is "look but don't block" by design;
   * only ENFORCE raises).
   */
  allowUnguarded?: boolean
  /**
   * Optional callback invoked with the structured
   * `pending_resolution` envelope on any Stage 2/3/4 deny on a
   * wrapped tool. Mirrors the Python adapter's
   * `pending_resolution_sink` kwarg and the OpenAI Agents adapter's
   * option. The same envelope is also latched on the shield and
   * retrievable via {@link Shield.lastPendingResolution}.
   */
  pendingResolutionSink?: PendingResolutionSink
  // Reserved for future per-call overrides.
  [key: string]: unknown
}

export class Shield {
  // Subclasses MAY override `BUNDLE` (via `static get BUNDLE() {...}`)
  // to seed a default capability bundle. The base class deliberately
  // returns `undefined` rather than throwing so:
  //   - `new Shield(runtime)` works without any adapter loaded.
  //   - Adapter `import`s do NOT race to install a default
  //     `Shield.BUNDLE`; the bundle is selected explicitly via
  //     `ShieldBuilder.with<Framework>()`.
  static get BUNDLE(): CapabilityBundle | undefined {
    return undefined
  }

  static get BUILDER_CLASS(): typeof ShieldBuilder | undefined {
    return undefined
  }

  readonly runtime: RuntimeLike
  // `_bundle` is set in the constructor but adapter `with<Framework>()`
  // patches re-bind it (non-readonly) so the late-binding flow works.
  protected _bundle: CapabilityBundle | null
  protected readonly _mode: ShieldModeValue
  protected readonly _onBlock: OnBlockPolicy
  protected readonly _onConcurrent: OnConcurrentPolicy
  protected readonly _streamingConfig: Record<string, unknown> | undefined
  protected readonly _guardedRunners: Set<GuardedRunner<unknown, unknown>>
  // Observability providers used for `recordAdapterError` and other
  // SDK-side, non-stage signals. Populated by `ShieldBuilder.build()`;
  // bare `new Shield(runtime)` constructors leave it empty.
  protected readonly _observabilityProviders: ReadonlyArray<(event: unknown) => void>
  // Wire schema used when invoking the providers above. The
  // ShieldBuilder warns once if a customer did not pick a schema
  // explicitly; the constructor here just stores whatever was chosen
  // (or the current default).
  protected readonly _observabilityProviderSchema: ObservabilityProviderSchema
  // Most recent `pending_resolution` envelope surfaced by a
  // Stage 2/3 block on any tool wrapped or run through this shield.
  // Hosts read this via {@link lastPendingResolution} to retrieve the
  // structured suspension shape (`{tool, variable, prompt, requestId,
  // kind}`) without substring-matching the `[GUARDRAIL...]` block
  // message returned to the LLM trajectory. Cross-SDK parity with the
  // Python adapter's `Shield.last_pending_resolution()` and the Node MCP
  // adapter's `MCPShield.lastPendingResolution()`.
  protected _lastPendingResolution: PendingResolutionLike | null = null
  // The {@link SessionLike} that produced the most recent
  // `pending_resolution` envelope. Captured at latch time so
  // {@link resolvePending} can write the resolver outcome back to
  // the SAME session even when called from outside the originating
  // guarded turn (the canonical Pattern A timeline: `runner.run()`
  // → blocks → operator UI → `shield.resolvePending(...)` →
  // `runner.run()` resumes). When `null`, {@link resolvePending}
  // falls back to the ambient {@link currentSession}.
  protected _lastPendingSession: SessionLike | null = null

  constructor(runtime: RuntimeLike, opts: ShieldOpts = {}) {
    this.runtime = runtime
    const ctor = this.constructor as typeof Shield
    this._bundle = opts.bundle ?? ctor.BUNDLE ?? null
    // Shadow mode (#14) forces MONITOR.
    const runtimeMode = typeof runtime.mode === 'function'
      ? runtime.mode()
      : 'active'
    this._mode = runtimeMode === 'shadow'
      ? ShieldMode.MONITOR
      : (opts.mode ?? ShieldMode.ENFORCE)
    this._onBlock = opts.onBlock ?? 'returnBlocked'
    this._onConcurrent = opts.onConcurrent ?? 'serialize'
    this._streamingConfig = opts.streamingConfig
    this._guardedRunners = new Set()
    this._observabilityProviders = opts.observabilityProviders ?? []
    this._observabilityProviderSchema = opts.observabilityProviderSchema ?? 'camelCase'
  }

  /**
   * Peek at the most recent `pending_resolution` envelope surfaced
   * by a Stage 2/3 block on a tool routed through any adapter on
   * this shield (`runOpenaiAgent`, `protectOpenaiTools`,
   * `runAnthropicAgent`, `protectAnthropicTools`, `protectTools`,
   * `guard`, `run`, `protectTool`).
   *
   * When a guarded tool call is blocked at Stage 2/3 by a resolver
   * that suspends pending external input (e.g. a `kind: human`
   * resolver awaiting operator approval, or a `kind: tool` resolver
   * awaiting a named tool call), the verdict carries a structured
   * envelope:
   *
   *     {
   *       tool: 'agent_shield.ask_human',
   *       variable: 'send_email_approved',
   *       prompt: 'Approve sending this email?',
   *       requestId: 'req-7f3c',
   *       kind: 'human',
   *     }
   *
   * The block message returned through the framework's tool-call
   * boundary is shaped for the LLM trajectory (`[GUARDRAIL...]`);
   * this method gives the host a programmatic handle on the same
   * suspension so it can drive the human-approval UI (look up the
   * named tool's resolver, prompt the operator, etc.) without
   * substring-matching the block message.
   *
   * **Non-destructive peek.** Reading the latch does NOT
   * clear it. The documented inspect-then-resolve flow
   *
   *     const pending = shield.lastPendingResolution()
   *     if (pending) {
   *       // show pending.prompt / pending.requestId in a host UI
   *       await shield.resolvePending('allow')
   *     }
   *
   * relies on this method being idempotent — multiple peeks return
   * the same envelope until {@link resolvePending} (or another
   * guarded turn) consumes it. Only {@link resolvePending} (or an
   * explicit successful turn that latches a fresh envelope) clears
   * the latch.
   *
   * Returns `null` when no recent block carried a pending
   * resolution.
   *
   * Mirrors the Python adapter's `Shield.last_pending_resolution()`
   * and the Node MCP adapter's `MCPShield.lastPendingResolution()`.
   */
  lastPendingResolution(): PendingResolutionLike | null {
    return this._lastPendingResolution
  }

  /**
   * Resolve a previously-surfaced pending resolution.
   *
   * Writes the resolver outcome back to the variable that suspended
   * a Stage 1/2/3/4 evaluation, so the next `protectTool` / `run` /
   * Pattern A entry inside the same retained session sees the
   * resolved value and proceeds without re-prompting.
   *
   * Convenience shape (single-variable case):
   *
   *     const shield = await Shield.fromYaml('guardrails.yaml')
   *         .withOpenaiAgents()
   *         .build()
   *
   *     let text = await shield.runOpenaiAgent({ client, model, tools, dispatchToolCall, userInput })
   *     const pending = shield.lastPendingResolution()
   *     if (pending) {
   *       // Operator UI uses pending.variable / pending.prompt / pending.kind.
   *       await shield.resolvePending('allow') // value defaults to true
   *       text = await shield.runOpenaiAgent({ client, model, tools, dispatchToolCall, userInput })
   *     }
   *
   * @param decision `'allow'` or `'deny'` — the operator's decision.
   *   When `value` is omitted, `'allow'` resolves the latched
   *   variable to `true` and `'deny'` to `false`.
   * @param opts Optional shape parameters:
   *   - `value` — explicit value to write (overrides the boolean
   *     default for non-boolean variables).
   *   - `setVariables` — `{name: value}` map to write multiple
   *     variables in one call. When supplied, the latched envelope
   *     is ignored.
   *   - `reason` — optional audit string (currently DEBUG-only).
   *
   * Throws when `decision` is invalid, when no session can be
   * resolved (no ambient turn AND no captured session), or when no
   * `pending_resolution` is latched and no `setVariables` map was
   * supplied.
   */
  async resolvePending(
    decision: 'allow' | 'deny',
    opts: {
      value?: unknown
      setVariables?: Record<string, unknown>
      reason?: string
    } = {},
  ): Promise<void> {
    if (decision !== 'allow' && decision !== 'deny') {
      throw new TypeError(
        `Shield.resolvePending(decision): decision must be 'allow' or ` +
          `'deny', got ${String(decision)}`,
      )
    }

    const ambient = currentSession()
    const session = ambient ?? this._lastPendingSession
    if (!session) {
      throw new Error(
        'Shield.resolvePending: no active session is available. ' +
          'Either call from inside a guarded turn (Pattern A ' +
          '`runOpenaiAgent` / `guard(...).run()`, Pattern C ' +
          '`shield.run(...)`) OR call after a Stage 1/2/3/4 block ' +
          'surfaced a `pending_resolution` envelope (the latched ' +
          'session is then used).',
      )
    }
    if (typeof session.setVariable !== 'function') {
      throw new Error(
        'Shield.resolvePending: the retained session does not expose ' +
          '`setVariable` — cannot write the resolver outcome.',
      )
    }

    const pending = this._lastPendingResolution

    if (opts.setVariables) {
      for (const [name, value] of Object.entries(opts.setVariables)) {
        session.setVariable(name, value)
      }
    } else if (!pending) {
        throw new Error(
          'Shield.resolvePending: no `pending_resolution` is latched. ' +
            'Trigger a Stage 2/3/4 block via a guarded turn first ' +
            '(the latch is populated when a block verdict carries a ' +
            '`pending_resolution` envelope), or pass ' +
            '`{ setVariables: {...} }` explicitly to write the ' +
            'resolution variables yourself.',
        )
    } else {
      if (typeof session.completePendingResolution !== 'function') {
        throw new Error(
          'Shield.resolvePending: the retained session does not expose ' +
            '`completePendingResolution` — cannot complete the pending resolution.',
        )
      }
      const requestId = pending.requestId
      if (!requestId) {
        throw new Error(
          'Shield.resolvePending: latched `pending_resolution` has no ' +
            '`request_id` field; cannot complete it.',
        )
      }
      let value = opts.value
      if (value === undefined && !opts.setVariables) value = decision === 'allow'
      session.completePendingResolution(
        String(requestId),
        decision,
        value,
        opts.setVariables ?? null,
        opts.reason,
      )
    }

    // Clear the latch so a subsequent successful turn does not look
    // like another pending block, and so the captured-session
    // reference is released for garbage collection.
    this._lastPendingResolution = null
    this._lastPendingSession = null
    // `reason` is currently DEBUG-only; observability sinks consume
    // structured guard-policy / variable events on the runtime.
    void opts.reason
  }

  /** Internal sink used by adapter methods to capture a verdict's
   *  `pending_resolution` envelope into the shield's latch. Adapter
   *  code uses {@link _composePendingResolutionSink} to fold this
   *  together with any host-supplied `pendingResolutionSink` so the
   *  latch always wins. Also captures the ambient session
   *  (when set) so {@link resolvePending} can route the resume call
   *  back to the same session even when invoked from outside the
   *  originating guarded turn. */
  protected _capturePendingResolutionSink: PendingResolutionSink = (pr) => {
    this._lastPendingResolution = pr
    const active = currentSession()
    if (active) this._lastPendingSession = active
  }

  /** Compose the shield's internal capture sink with an optional
   *  host-supplied sink. The internal latch fires first so a
   *  misbehaving host callback can never block the canonical
   *  surfacing path on {@link lastPendingResolution}. */
  protected _composePendingResolutionSink(
    extra: PendingResolutionSink | undefined,
  ): PendingResolutionSink {
    const capture = this._capturePendingResolutionSink
    if (!extra) return capture
    return (pr) => {
      capture(pr)
      try {
        extra(pr)
      } catch {
        /* swallow — see _firePendingResolutionSink rationale */
      }
    }
  }

  /**
   * Emit an `adapter.llm_caller_error` log event to every registered
   * observability provider. Used by framework adapters to surface
   * provider-side errors (e.g. an Anthropic API 503) that they choose
   * to fail-CLOSED on, so the original error is auditable as a
   * distinct signal rather than being conflated with a policy block.
   *
   * Free-form by design: the runtime's own log channel is shaped by
   * the Rust core and reserved for stage / guard-policy events. This
   * helper writes to the *same* provider callbacks but with an event
   * shape that lives entirely on the SDK side.
   */
  recordAdapterError(adapterName: string, error: unknown): void {
    _emitAdapterErrorEvent(
      this._observabilityProviders,
      adapterName,
      error,
      this._observabilityProviderSchema,
    )
  }

  static fromYaml(this: typeof Shield, path: string): ShieldBuilder {
    const BuilderCls = this.BUILDER_CLASS ?? ShieldBuilder
    return new BuilderCls(this, this.BUNDLE ?? null, path)
  }

  static fromYamlChain(this: typeof Shield, paths: readonly string[]): ShieldBuilder {
    const BuilderCls = this.BUILDER_CLASS ?? ShieldBuilder
    const b = new BuilderCls(this, this.BUNDLE ?? null, paths[0] ?? '')
    b._yamlChain = paths.slice()
    return b
  }

  get capabilities(): CapabilityReport {
    if (!this._bundle) {
      throw new Error(
        'Shield has no capability bundle: call `.with<Framework>()` on the ' +
          'builder (e.g. `.withLangchain()`, `.withOpenaiAgents()`, ' +
          '`.withAnthropic()`) before `.build()`, or supply ' +
          '`{ bundle }` to the constructor.',
      )
    }
    return this._bundle.capabilities
  }

  get mode(): ShieldModeValue {
    return this._mode
  }

  /**
   * Wrap framework tools with Stages 2 + 3 + 4 enforcement
   * (Pattern B). The wrapped tools are intended to be handed to a
   * framework agent that is itself wrapped via {@link guard}
   * (Pattern A), so every tool call runs inside the agent's
   * guarded turn and sees per_turn / per_session variables, event
   * latches, and approval state.
   *
   * When a wrapped tool is invoked **outside** any guarded session
   * (no `shield.guard(agent)` wrapper, no ambient context from
   * `shield.run(...)`) the default behavior is fail-closed: the
   * call throws {@link UnguardedToolInvocationError} so a forgotten
   * Pattern A wiring cannot silently neuter stateful guardrails.
   * Pass `{ allowUnguarded: true }` to opt back into the
   * ad-hoc-invocation path: a fresh session is minted per call.
   */
  async protectTools<TTool, TGuarded = unknown>(
    tools: readonly TTool[],
    opts: ProtectToolsOpts = {},
  ): Promise<TGuarded[]> {
    const wrapper = this._bundle?.toolWrapper as ToolWrapper<TTool, TGuarded> | undefined
    if (!wrapper) {
      const name = this._bundle ? this._bundle.name : '<no bundle>'
      throw new Error(`${name} does not support tool wrapping`)
    }
    // Compose the shield's internal pending-resolution latch
    // with any host-supplied sink so `shield.lastPendingResolution()`
    // is populated on a Stage 2/3/4 deny that carries a
    // `pending_resolution` envelope (e.g. a `kind: human` suspension).
    const pendingResolutionSink = this._composePendingResolutionSink(
      opts.pendingResolutionSink as PendingResolutionSink | undefined,
    )
    return protectToolsViaWrapper<TTool, TGuarded>(this.runtime, tools, wrapper, {
      ...opts,
      mode: this._mode,
      pendingResolutionSink,
    })
  }

  guard<TAgent = unknown, TResult = unknown>(agent: TAgent): GuardedRunner<TAgent, TResult> {
    if (!this._bundle || !this._bundle.agentBoundary) {
      const name = this._bundle ? this._bundle.name : '<no bundle>'
      throw new Error(
        `${name} does not support full agent run wrapping (no AgentBoundary). ` +
          `Use a framework-specific helper (e.g. \`runOpenaiAgent\`, ` +
          `\`runAnthropicAgent\`) or the generic \`shield.run(fn)\` Stage 1+5 wrapper instead.`,
      )
    }
    const runner = new GuardedRunner<TAgent, TResult>(
      this.runtime,
      agent,
      this._bundle.agentBoundary as AgentBoundary<TAgent, TResult>,
      this._bundle.streamingAdapter as StreamingAdapter<TAgent, unknown> | undefined,
      {
        mode: this._mode,
        onBlock: this._onBlock,
        streamingConfig: this._streamingConfig,
        onConcurrent: this._onConcurrent,
      },
    )
    this._guardedRunners.add(runner as GuardedRunner<unknown, unknown>)
    return runner
  }

  async beforeInvoke(
    userInput: string | undefined,
    opts: { session?: SessionLike } = {},
  ): Promise<string | null> {
    const ownSession = !opts.session
    const session = opts.session ?? this.runtime.newSession()
    const drive = async (): Promise<string | null> => {
      // Owned sessions are fresh-minted here so they always need a
      // turn. Customer-supplied sessions inherit any outer turn if
      // reentrancy is detected (folds into outer turn).
      const ownsTurn = ownSession || !_isReentrantOnSession(session)
      if (ownsTurn) session.beginTurn()
      try {
        // Shadow / Monitor (#14): run Stage 1 for observability but
        // never return a block message so the caller proceeds. Core
        // emits the audit event via the observability dispatcher.
        if (this._mode === ShieldMode.MONITOR) {
          await session.validateInput(userInput ?? '')
          return null
        }
        return (await _checkStage1(session, userInput)).blockMessage
      } finally {
        if (ownsTurn) {
          try {
            session.endTurn()
          } catch {
            /* swallow */
          }
        }
      }
    }
    return await _withSessionTurnSlot(session, this._onConcurrent, drive)
  }

  // ─── Canonical Pattern C: Stage 1 + Stage 5 around an opaque
  //     user-supplied agent thunk ─────────────────────────────────
  //
  // Framework-agnostic `run` on the BASE `Shield` class to avoid
  // prototype-pollution races between adapter modules. Each adapter
  // installs its own `run<Framework>Agent(...)` for full-coverage
  // Pattern A; this method covers the drop-in case where the customer
  // hands us an opaque thunk and just wants Stage 1 + Stage 5.
  //
  // Mirrors the Python `_orchestration.guarded_turn` flow:
  //   begin_turn → Stage 1 → execute → Stage 5 → end_turn
  async run<T>(
    executeFn: () => T | Promise<T>,
    opts: {
      userInput?: string
      session?: SessionLike
      // Per-call block-handling policy. When omitted, defaults
      // to `'raise'` (the new safer default — Pattern C surface change).
      // Pass `'return_blocked'` to opt back into the legacy
      // string-return shape. Mirrors the Python `Shield.run`
      // `on_block=` keyword.
      onBlock?: 'raise' | 'return_blocked'
      // Assistant-visible-text lens for framework result
      // objects. When the thunk returns something that isn't `string`,
      // `null`, or `undefined`, supply `extractText` to name the text
      // field. Stage 5 runs on the extracted string; the redacted
      // result is written back via `setText`.
      //
      // `setText` is REQUIRED whenever `extractText` is
      // supplied. Previously the runtime silently wrote redacted text
      // into a fresh `.text` attribute when `setText` was omitted —
      // leaving the original `extractText` source location (e.g.
      // `r.choices[0].message.content`) unredacted. To override the
      // fail-closed default and run Stage 5 in advisory-only mode (no
      // write-back), pass `setText: null` explicitly.
      //
      // Without `extractText`, an unsupported result type raises
      // `AgentShieldUnsupportedOutputTypeError` (fail-closed).
      // With `extractText` but no `setText` key, raises
      // `AgentShieldLensIncompleteError` (fail-closed).
      extractText?: (result: T) => string | null | undefined
      setText?: ((result: T, redacted: string) => T) | null
    } = {},
  ): Promise<T | string> {
    if (typeof executeFn !== 'function') {
      throw new TypeError('shield.run(fn): fn must be a function')
    }
    if (opts.extractText !== undefined && typeof opts.extractText !== 'function') {
      throw new TypeError('shield.run(fn, { extractText }): extractText must be a function')
    }
    // Distinguish "setText not in options" (forgot — raise)
    // from "setText explicitly null" (advisory acknowledged). The
    // `'setText' in opts` check is the reliable signal in JS; we
    // treat `setText: undefined` the same as "not in options" since
    // it would be type-equivalent to omitting it for TS callers.
    const setTextSpecified =
      'setText' in opts && opts.setText !== undefined
    if (opts.extractText !== undefined && !setTextSpecified) {
      throw new AgentShieldLensIncompleteError()
    }
    if (
      setTextSpecified &&
      opts.setText !== null &&
      typeof opts.setText !== 'function'
    ) {
      throw new TypeError(
        'shield.run(fn, { setText }): setText must be a function or null',
      )
    }
    const userInput = opts.userInput ?? ''
    const session = opts.session ?? this.runtime.newSession()
    const reentrant = _isReentrantOnSession(session)
    // Default to `'raise'` so a Stage 1 / Stage 5 block surfaces
    // as a typed `AgentShieldBlocked` exception. Customers who rely on
    // the legacy `[GUARDRAIL...]` string-return shape must explicitly
    // pass `onBlock: 'return_blocked'`. See README "Pattern C surface
    // change" for the rationale and migration guidance.
    const onBlock: 'raise' | 'return_blocked' = opts.onBlock ?? 'raise'
    const extractText = opts.extractText
    // `null` opts into advisory-only mode (Stage 5 runs but
    // does not write back to the result). A callable performs the
    // write-back. There is no implicit default — the fail-closed
    // check above ensures `setTextSpecified` implies a callable or
    // explicit `null` at this point.
    const setText: ((r: T, t: string) => T) | null =
      setTextSpecified ? (opts.setText as ((r: T, t: string) => T) | null) : null
    const advisoryOnly = setTextSpecified && opts.setText === null

    // Derive the assistant-visible-text string for Stage 5.
    // Returns `[textOrNull, applyRedaction]` where `applyRedaction(t)`
    // either writes `t` back into the framework result (via setText)
    // or, for native string returns, just returns `t`.
    type StageInput = {
      text: string | null
      apply: (redacted: string) => T | string
    }
    const _deriveStage5Input = (raw: T): StageInput => {
      if (typeof raw === 'string') {
        return { text: raw, apply: (t) => t }
      }
      if (raw === null || raw === undefined) {
        return { text: null, apply: () => raw as unknown as T }
      }
      // Primitives (`number`, `boolean`, `bigint`, `symbol`)
      // String()-coerce to a faithful representation, so Stage 5 can
      // run on them without ambiguity. The hazard is
      // specifically `typeof raw === 'object' | 'function'` whose
      // default toString() yields `'[object Object]'` (or similar)
      // and silently destroys the assistant-visible text.
      const t = typeof raw
      if (t === 'number' || t === 'boolean' || t === 'bigint' || t === 'symbol') {
        return { text: String(raw), apply: () => raw }
      }
      if (extractText !== undefined) {
        const ex = extractText(raw)
        if (ex === null || ex === undefined) {
          return { text: null, apply: () => raw }
        }
        if (typeof ex !== 'string') {
          throw new TypeError(
            `shield.run: extractText must return string | null | undefined, ` +
              `got ${typeof ex}`,
          )
        }
        return {
          text: ex,
          // `setText === null` (advisory) returns the raw
          // object unchanged. Stage 5 ran over the extracted text but
          // the result is intentionally not mutated. A non-null
          // `setText` writes back.
          apply: (redacted) =>
            advisoryOnly || setText === null ? raw : setText(raw, redacted),
        }
      }
      const resultType =
        (raw as { constructor?: { name?: string } })?.constructor?.name ??
        typeof raw
      throw new AgentShieldUnsupportedOutputTypeError(resultType)
    }

    const drive = async (): Promise<T | string> => {
      const ambientStore = { session, userInput }
      return await _ambient.run(
        ambientStore,
        async (): Promise<T | string> => {
          if (!reentrant) session.beginTurn()
          try {
            // Shadow / Monitor (#14): run stages for observability but
            // never short-circuit the caller's flow.
            if (this._mode === ShieldMode.MONITOR) {
              if (userInput) {
                await session.validateInput(userInput)
              }
              const raw = (await executeFn()) as T
              // Use the same `_deriveStage5Input` lens in
              // MONITOR so customers get the same diagnostics about
              // unsupported result types whether or not enforcement is
              // active. (The redacted text is discarded; raw is
              // returned regardless.)
              const stage5 = _deriveStage5Input(raw)
              if (stage5.text !== null && stage5.text.length > 0) {
                await session.validateOutput(stage5.text)
              }
              return raw
            }

            let effectiveInput = userInput
            if (userInput) {
              const verdict = await session.validateInput(userInput)
              const decision = _dispatchStage(verdict)
              if (decision.action.kind === 'return_blocked') {
                const message = decision.action.message ?? ''
                if (onBlock === 'raise') {
                  throw new AgentShieldBlocked(verdict, message)
                }
                return message
              }
              if (decision.action.kind === 'proceed_with_mutation') {
                effectiveInput = String(decision.action.value ?? effectiveInput)
              }
            }
            ambientStore.userInput = effectiveInput

            const raw = (await executeFn()) as T

            // Derive Stage 5 text via the `_deriveStage5Input`
            // lens. For native string returns this is just the raw
            // string; for framework result objects the customer must
            // supply `extractText` or we raise
            // `AgentShieldUnsupportedOutputTypeError`.
            const stage5Input = _deriveStage5Input(raw)
            if (stage5Input.text !== null && stage5Input.text.length > 0) {
              const outcome = await session.validateOutput(stage5Input.text)
              const stage5 = _dispatchStage(outcome.verdict)
              if (stage5.action.kind === 'return_blocked') {
                const message = stage5.action.message ?? ''
                if (onBlock === 'raise') {
                  throw new AgentShieldBlocked(outcome.verdict, message)
                }
                return message
              }
              if (stage5.action.kind === 'proceed_with_mutation') {
                const redacted = outcome.response ?? stage5Input.text
                return stage5Input.apply(redacted)
              }
            }
            return raw
          } finally {
            if (!reentrant) {
              try {
                session.endTurn()
              } catch {
                /* swallow */
              }
            }
          }
        },
      )
    }

    return await _withSessionTurnSlot(session, this._onConcurrent, drive)
  }

  // ─── Canonical Pattern B helper: Stage 2 + 3 + 4 around a single
  //     tool function ──────────────────────────────────────────────
  async protectTool(
    name: string,
    params: Record<string, unknown> | null | undefined,
    executeFn: (effective: Record<string, unknown>) => Promise<unknown> | unknown,
    opts?: { toolCallId?: string },
  ): Promise<GuardedToolResult> {
    if (typeof executeFn !== 'function') {
      throw new TypeError(
        'shield.protectTool(name, params, fn): fn must be a function',
      )
    }
    // Caller-supplied tool-call id for cross-system trace
    // correlation. Vercel AI SDK / OpenAI / Anthropic / LangChain hand
    // the host a `toolCallId` for each dispatched call; threading it
    // through to Stage 3/4/5 observability lets customers join
    // AgentShield events with framework-level events in their tracing
    // backend. Opaque string; AgentShield does not validate the format.
    const callerToolCallId = opts?.toolCallId
    if (callerToolCallId !== undefined && typeof callerToolCallId !== 'string') {
      throw new TypeError(
        'shield.protectTool(name, params, fn, opts): opts.toolCallId must be a string',
      )
    }
    const ambient = currentSession()
    let session: SessionLike
    let ownTurn = false
    if (ambient) {
      session = ambient
    } else {
      session = this.runtime.newSession()
      session.beginTurn()
      ownTurn = true
    }
    try {
      // Shadow / Monitor (#14): run Stage 3 / Stage 4 for observability
      // but never block; the tool sees the caller's original params.
      if (this._mode === ShieldMode.MONITOR) {
        const effective: Record<string, unknown> = { ...(params ?? {}) }
        // honor the caller-supplied id so the MONITOR
        // observability path records the SAME id customers see in
        // their framework-level events; mint one otherwise so
        // concurrent same-name MONITOR calls bind correctly through
        // Stage 3 → Stage 4.
        const _monCallId =
          typeof callerToolCallId === 'string' && callerToolCallId.length > 0
            ? callerToolCallId
            : randomUUID()
        await session.validateToolCall(name, effective, _monCallId)
        let raw: unknown
        try {
          raw = await executeFn(params ?? {})
        } catch (err) {
          const errText = `[tool error] ${name}: ${String(err)}`
          await session.validateToolOutput(name, errText, _monCallId)
          try {
            session.recordToolFailure(name, String(err))
          } catch {
            /* swallow */
          }
          return { blocked: false, output: errText }
        }
        await session.validateToolOutput(name, raw, _monCallId)
        try {
          session.recordToolSuccess(name, raw)
        } catch {
          /* swallow */
        }
        const out = typeof raw === 'string' ? raw : raw == null ? '' : String(raw)
        return { blocked: false, output: out }
      }
      return await _guardedTool(
        session,
        name,
        params ?? null,
        async (effective) => executeFn(effective),
        {
          // Surface the structured `pending_resolution`
          // envelope on a Stage 2/3/4 deny so the returned
          // {@link GuardedToolResult} carries it AND
          // {@link Shield.lastPendingResolution} is populated for
          // the host's canonical surface. Also pin the
          // active session reference so {@link resolvePending} can
          // route the resume call back to this same session even
          // when invoked from outside the guarded turn (the canonical
          // Pattern A timeline).
          pendingResolutionSink: (pr) => {
            this._lastPendingResolution = pr
            this._lastPendingSession = session
          },
          // Forward the caller-supplied id (or `undefined` to
          // let `_guardedTool` mint one) so Stage 3/4/5 events and
          // any pending-resolution envelope carry the upstream id.
          toolCallId: callerToolCallId,
        },
      )
    } finally {
      if (ownTurn) {
        try {
          session.endTurn()
        } catch {
          /* swallow */
        }
      }
    }
  }

  /**
   * Returns a NEW `Shield` instance backed by the same runtime,
   * bundle, mode, on-block policy, and streaming config — but with
   * an empty set of guarded runners. The original Shield (and the
   * runners spawned from it) are untouched. Mirrors the Rust
   * `Shield::with_fresh_session`, the .NET `Shield.WithFreshSession`,
   * and the Python `Shield.with_fresh_session` APIs.
   */
  withFreshSession(): this {
    const Ctor = this.constructor as new (rt: RuntimeLike, opts: ShieldOpts) => this
    return new Ctor(this.runtime, {
      bundle: this._bundle,
      mode: this._mode,
      onBlock: this._onBlock,
      onConcurrent: this._onConcurrent,
      streamingConfig: this._streamingConfig,
      observabilityProviders: this._observabilityProviders.slice(),
      observabilityProviderSchema: this._observabilityProviderSchema,
    })
  }
}

export class ShieldBuilder {
  protected readonly _shieldClass: typeof Shield
  // `_bundle` is set in the constructor but adapter `with<Framework>()`
  // patches re-bind it (non-readonly) so the late-binding flow works.
  protected _bundle: CapabilityBundle | null
  protected _path: string
  _yamlChain: readonly string[] | null = null
  protected readonly _observabilityProviders: Array<(event: unknown) => void> = []
  protected _llmCaller: ((req: unknown) => unknown) | null = null
  protected readonly _extra: Array<(builder: unknown) => void> = []
  protected _mode: ShieldModeValue = ShieldMode.ENFORCE
  protected _onBlock: OnBlockPolicy = 'returnBlocked'
  protected _onConcurrent: OnConcurrentPolicy = 'serialize'
  protected _consumed = false
  // `null` means "customer did not pick a schema". `build()`
  // logs a one-time warning in that case and defaults to camelCase
  // for backward compatibility. Explicit values from
  // {@link withObservabilityProviderSchema} suppress the warning.
  protected _observabilityProviderSchema: ObservabilityProviderSchema | null = null
  // Holds a client registered via `withClient(...)` when no bundle
  // with an `llmCallerFactory` is installed yet. Consumed by
  // `_rebindPendingLlmClient()` once an adapter installer (e.g.
  // `withLangchain()`, `withOpenaiAgents()`, `withAnthropic()`) sets
  // `_bundle`. Ensures `.withClient(c).with<Framework>()` and
  // `.with<Framework>().withClient(c)` produce equivalent Shields.
  _pendingLlmClient: unknown = null
  // Mutable indirection between an LLM-caller closure and the
  // runtime: adapter LLM-caller factories build their closure in
  // `_buildLlmCaller`, which fires the moment a client is wired —
  // typically BEFORE `build()` produces the runtime. The closure
  // therefore can't capture `Runtime.llmConfiguration` directly.
  // This holder is registered with the factory via
  // `AdapterContext.configurationResolver` at make-caller time and
  // populated in `build()` once the runtime exists, so calls to
  // `configurationResolver(configurationId)` start returning the
  // real `configurations[]` entry as soon as the first stage runs.
  // Mirrors the Python `_ConfigurationResolverHolder` in
  // `agent_shield.adapters._shield`.
  protected _configurationResolverLookup:
    | ((configurationId: string) => LlmConfiguration | null)
    | null = null

  constructor(shieldClass: typeof Shield, bundle: CapabilityBundle | null, path: string) {
    this._shieldClass = shieldClass
    this._bundle = bundle
    this._path = path
  }

  protected _checkConsumed(): void {
    if (this._consumed) {
      throw new Error(
        'ShieldBuilder.build() can only be called once. ' +
          'Call Shield.fromYaml(...) again to create a new builder.',
      )
    }
  }

  // Stable resolver closure handed to adapter `LlmCallerFactory`
  // implementations via `AdapterContext.configurationResolver`. The
  // identity is stable across the builder's lifetime — adapters
  // capture this once at `makeCaller` time and the lookup it
  // dispatches to is populated by `build()` when the runtime exists.
  // Lookup failures (unknown id, post-build runtime errors) are
  // routed through observability so SREs see them as a distinct
  // signal rather than collapsing into "the policy blocked".
  protected _resolveConfiguration(
    configurationId: string | null | undefined,
  ): LlmConfiguration | null {
    if (!configurationId) return null
    const lookup = this._configurationResolverLookup
    if (!lookup) return null
    try {
      return lookup(configurationId)
    } catch (err) {
      const bundleName = this._bundle?.name ?? 'shield_builder'
      _emitAdapterErrorEvent(
        this._observabilityProviders,
        bundleName,
        err,
        this._observabilityProviderSchema ?? 'camelCase',
      )
      return null
    }
  }

  withClient(client: unknown): this {
    this._checkConsumed()
    if (this._bundle?.llmCallerFactory && client) {
      this._llmCaller = this._buildLlmCaller(client, this._bundle)
      this._pendingLlmClient = null
    } else if (client) {
      // No bundle (or no factory) installed yet — stash the client so
      // a subsequent `.with<Framework>()` call can bind it through that
      // bundle's factory. Without this, `.withClient(c).withOpenaiAgents()`
      // and similar orderings would silently drop the client.
      this._pendingLlmClient = client
    }
    return this
  }

  // Builds an LLM caller from a client + bundle, wiring up the adapter
  // context so factory-side errors flow through observability. Shared
  // between `withClient` (immediate bind) and `_rebindPendingLlmClient`
  // (deferred bind after an adapter installer sets `_bundle`).
  protected _buildLlmCaller(
    client: unknown,
    bundle: CapabilityBundle,
  ): ((req: unknown) => unknown) | null {
    if (!bundle.llmCallerFactory) return null
    // The adapter context lets adapters fail-CLOSED on provider
    // outages without conflating the original error with a policy
    // block. Captures the providers array BY REFERENCE so callers
    // that register providers AFTER `.withClient(...)` still see
    // their handlers fire when the LLM caller errors.
    const bundleName = bundle.name
    const providersRef = this._observabilityProviders
    // Capture by reference so a schema selected AFTER `.withClient(...)`
    // still applies to errors raised from the captured caller.
    const schemaRef = (): ObservabilityProviderSchema =>
      this._observabilityProviderSchema ?? 'camelCase'
    // Bound to `this` so the resolver dispatches through the holder
    // populated by `build()`. Stable identity across the closure's
    // lifetime, so factories can safely cache it.
    const configurationResolver = (
      configurationId: string | null | undefined,
    ): LlmConfiguration | null => this._resolveConfiguration(configurationId)
    const ctx: AdapterContext = {
      recordAdapterError: (error: unknown): void => {
        _emitAdapterErrorEvent(providersRef, bundleName, error, schemaRef())
      },
      configurationResolver,
    }
    return bundle.llmCallerFactory.makeCaller(client, ctx) as (req: unknown) => unknown
  }

  // Called by adapter installers (`withLangchain`, `withOpenaiAgents`,
  // `withAnthropic`) after they set `_bundle`. If a client was stashed
  // via `.withClient(c)` BEFORE the adapter was chosen, this binds it
  // through the freshly-installed bundle's factory so call order is
  // not significant.
  _rebindPendingLlmClient(): void {
    if (!this._pendingLlmClient) return
    if (!this._bundle?.llmCallerFactory) return
    this._llmCaller = this._buildLlmCaller(this._pendingLlmClient, this._bundle)
    this._pendingLlmClient = null
  }

  withObservability(provider: (event: unknown) => void): this {
    this._checkConsumed()
    this._observabilityProviders.push(provider)
    return this
  }

  /**
   * Pick the wire schema used when this Shield delivers
   * events to {@link withObservability} providers.
   *
   * - `'snakeCase'`: matches the Rust core, Python, and .NET SDKs
   *   (`event_type`, `guard_policy`, `correlation_id`, `session_id`).
   *   This is the canonical project shape and will become the Node
   *   SDK default in the next major.
   * - `'camelCase'`: preserves the historical Node shape
   *   (`eventType`, `guardPolicy`, `correlationId`, `sessionId`).
   *
   * If neither is selected explicitly, the builder emits a one-time
   * `console.warn` at {@link build} and defaults to `'camelCase'`
   * so existing customers are not silently broken. Setting this
   * suppresses the warning.
   */
  withObservabilityProviderSchema(schema: ObservabilityProviderSchema): this {
    this._checkConsumed()
    this._observabilityProviderSchema = schema
    return this
  }

  withMode(mode: ShieldModeValue): this {
    this._checkConsumed()
    this._mode = mode
    return this
  }

  withOnBlock(policy: OnBlockPolicy): this {
    this._checkConsumed()
    this._onBlock = policy
    return this
  }

  /**
   * Configures how this Shield reacts when a second `shield.run` /
   * `runStreamed` / `beforeInvoke` arrives on a Session that is
   * already inside an in-flight turn driven by the same Shield.
   * Defaults to `'serialize'`. See {@link ShieldOpts.onConcurrent}.
   */
  withOnConcurrent(policy: OnConcurrentPolicy): this {
    this._checkConsumed()
    this._onConcurrent = policy
    return this
  }

  withExtension(hook: (builder: unknown) => void): this {
    this._checkConsumed()
    this._extra.push(hook)
    return this
  }

  /**
   * Register a host implementation for `kind: agent` resolvers
   * declared in YAML. The resolver receives a `ResolverRequest` and
   * returns a `ResolverResponse`. Mirrors `Shield::with_agent_resolver`
   * in Rust and `ShieldBuilder.WithAgentResolver` in .NET.
   */
  withAgentResolver(resolver: (req: unknown) => unknown): this {
    this._checkConsumed()
    this._extra.push((rb: unknown) => {
      const builder = rb as { registerAgentResolver(fn: (req: unknown) => unknown): unknown }
      builder.registerAgentResolver(resolver)
    })
    return this
  }

  build(): Shield {
    this._checkConsumed()
    let builder: import('./index.js').RuntimeBuilder
    if (this._yamlChain) {
      builder = _index.RuntimeBuilder.fromYamlChain(this._yamlChain.slice())
    } else {
      builder = _index.RuntimeBuilder.fromYaml(this._path)
    }
    if (this._llmCaller) builder.registerLlmCaller(this._llmCaller as never)
    // Resolve the provider schema. `null` means the customer
    // did not pick one; in that case, warn once (per process) and
    // fall back to camelCase for backward compatibility.
    let schema: ObservabilityProviderSchema
    if (this._observabilityProviderSchema !== null) {
      schema = this._observabilityProviderSchema
    } else {
      _maybeWarnObservabilitySchemaDefault(
        this._observabilityProviders.length > 0,
      )
      schema = 'camelCase'
    }
    for (const p of this._observabilityProviders) {
      builder.registerProvider(p as never, { schema })
    }
    for (const hook of this._extra) hook(builder)
    const runtime = builder.build()
    // Now that the runtime exists, fill in the LLM configuration
    // resolver so adapter caller closures can look up
    // `configurations[]` entries at call time. MUST happen BEFORE
    // any stage runs, so adapter closures captured during
    // `_buildLlmCaller` (which fires inside `withClient` /
    // `_rebindPendingLlmClient`, both before `build()`) see the live
    // runtime on their first invocation. Mirrors the Python
    // `_ConfigurationResolverHolder.bind` call.
    const runtimeWrapper = runtime as unknown as {
      llmConfiguration?: (id: string) => LlmConfiguration | null
    }
    if (typeof runtimeWrapper.llmConfiguration === 'function') {
      const bound = runtimeWrapper.llmConfiguration.bind(runtime)
      this._configurationResolverLookup = (id: string) => bound(id)
    }
    const shield = new this._shieldClass(runtime as unknown as RuntimeLike, {
      bundle: this._bundle,
      mode: this._mode,
      onBlock: this._onBlock,
      onConcurrent: this._onConcurrent,
      observabilityProviders: this._observabilityProviders.slice(),
      observabilityProviderSchema: schema,
    })
    this._consumed = true
    return shield
  }
}

// ─── Host-driven human resolution helper ────────────────────────
//
// Mirrors `sdk/python/agent_shield/_human_resolution.py`. Both
// `Shield.resolvePending` and any future `MCPShield.resolvePending`
// route their single-variable write through this helper so the Rust
// lifetime tracker stamps `@source_kind: "human"` /
// `@set_by: "human:<variable>"` rather than
// the `host_api` stamp that a direct `session.setVariable(...)`
// would produce.
//
// Mechanism: emitting `approval.<var>.<outcome>` with a payload that
// names the originating resolver kind triggers the lifetime
// tracker's auto-flip handler. `approval_attribution()` extracts the
// `kind` / `set_by` fields verbatim so the variable carries the
// human-provenance metadata exactly as if the registered
// `kind: human` resolver had returned a `allow` / `deny`
// envelope. For `decision == "allow"` the `value` is carried in the
// payload; for `decision == "deny"` the variable transitions to
// `@status: "denied"` with the default deny reason.

/**
 * Bridges a host-driven human resolution into the canonical
 * `approval.<variable>.<outcome>` event shape so the Rust lifetime
 * tracker stamps `@source_kind: "human"` (not `"host_api"`).
 *
 * Used by {@link Shield.resolvePending} (and any subclass that ships
 * an equivalent host-driven resume API). Mirrors Python's
 * `drive_human_resolution_on_session` helper byte-for-byte.
 *
 * @param session the {@link SessionLike} on which the original
 *                 block fired — the auto-flip handler runs on the
 *                 same session.
 * @param variable name of the variable named by the latched
 *                 `pending_resolution` envelope.
 * @param decision `"allow"` or `"deny"` — the operator's decision.
 * @param value for `decision === "allow"`, the value to write
 *                 onto the variable. Ignored for `"deny"`.
 */
export async function driveHumanResolutionOnSession(): Promise<void> {
  throw new Error(
    'driveHumanResolutionOnSession is deprecated; use Shield.resolvePending so core completes the pending resolution.',
  )
}
