// Stage-4 shape-preserving recovery for tool outputs.
//
// The Rust core's Stage-4 runtime (`stage_post_tool.rs`) serialises any
// non-string tool result to a JSON string via `serde_json::to_string`,
// runs detection regexes against that flat text, applies redaction
// spans, and — when at least one redaction fires — writes the whole
// result back as a single `Value::String`. The original JavaScript
// container shape (object / array) is lost, and detectors can match
// characters that are part of the JSON serialisation itself (numeric
// literals, object-key quotes, structural punctuation), which can leak
// "stringification" semantics into healthcare pipelines that expect
// structured tool results.
//
// The Rust core boundary is settled — verdict-handling decisions live
// in core; only host-runtime async glue (and now: per-language shape
// restoration) lives in the SDK. This module is the Node side of that
// restoration. The Python equivalent ships at
// `sdk/python/agent_shield/_stage4_shape.py` (commit `58b742f`); the
// two MUST produce byte-equivalent canonical JSON for the same input
// — any divergence silently mis-maps redactions across SDKs.
//
// Algorithm:
//
//  1. Walk the original JS value and emit a canonical JSON form that
//     matches `serde_json::to_string` on a `BTreeMap` (sorted object
//     keys, no whitespace, escapes only for control chars / `"` / `\`,
//     non-ASCII pass-through). Track the codepoint range of every
//     string LEAF's content (excluding the surrounding `"` quotes).
//
//  2. For each `AppliedTransform` (canonical char-span into that
//     rendered JSON), classify the span:
//      - fully inside a single leaf's content range → reapply with
//        leaf-relative offsets.
//      - on a numeric literal, structural punctuation, object key, or
//        across leaf boundaries → DROP (the audit's "redact only
//        string leaves" expectation).
//
//  3. Rebuild the structure with the surviving redactions applied to
//     their owning leaves. Object / array types preserved.
//
// Fail-closed cases (`recoverStructuredRedactions` returns `null`,
// caller falls back to the legacy stringified result — never a silent
// partial redaction):
//
//   - `NaN` / `±Infinity` (not representable in JSON)
//   - `BigInt` (no JSON representation)
//   - Symbol keys, Function values
//   - non-plain-object container with non-string keys (e.g. `Map`)
//   - circular references (cycle detected during canonicalisation)
//   - any other type the canonicaliser doesn't recognise
//
// All offsets in this module are CODEPOINT offsets, matching the Rust
// core's `Span` contract (see `RedactionSpan` JSDoc in index.ts for the
// corresponding wire-level invariant).

export interface AppliedTransformLike {
  spanStart?: number | null
  spanEnd?: number | null
  replacement?: string | null
}

interface LeafRange {
  path: ReadonlyArray<string | number>
  // Codepoint offset into the canonical JSON of the FIRST char of
  // the string leaf's escaped content (just after the opening `"`).
  contentStart: number
  // Codepoint offset just AFTER the last char of escaped content
  // (i.e. at the closing `"`). Exclusive.
  contentEnd: number
}

interface CanonicalForm {
  canonical: string
  // Codepoint length of `canonical`. Maintained alongside the string
  // because String#length counts UTF-16 code units, not codepoints,
  // and we MUST match the Rust core's codepoint-offset span contract.
  canonicalLength: number
  leafRanges: LeafRange[]
}

// Codepoint length of a string: counts user-perceived characters
// (Unicode code points), not UTF-16 code units. Necessary because
// astral-plane characters (e.g. emoji) occupy 2 UTF-16 code units in
// `String#length` but a single codepoint in the Rust core's span
// contract. Iterating with `for..of` walks the string by code point.
function _codepointLength(s: string): number {
  let n = 0
  for (const _ of s) n++
  return n
}

// ───────────────────────────────────────────────────────────────────
// Canonical JSON encoding (matches `serde_json::to_string` default)
// ───────────────────────────────────────────────────────────────────

/**
 * Escape `s` the same way `serde_json` does by default.
 *
 * `serde_json` escapes control characters (codepoint < 0x20), `"`, and
 * `\`. Non-ASCII characters pass through unmodified. Returns the inner
 * escaped form WITHOUT surrounding `"` quotes.
 *
 * Exported for the byte-parity test that pins this encoder against
 * the Python implementation and the Rust core's output.
 */
export function _escapeJsonString(s: string): string {
  let out = ''
  // Walk by codepoint — astral-plane characters must be emitted as
  // their literal UTF-16 surrogate pair (matching JSON semantics) but
  // do not need escaping themselves.
  for (const ch of s) {
    const code = ch.codePointAt(0) as number
    if (ch === '"') {
      out += '\\"'
    } else if (ch === '\\') {
      out += '\\\\'
    } else if (code === 0x0a) {
      out += '\\n'
    } else if (code === 0x0d) {
      out += '\\r'
    } else if (code === 0x09) {
      out += '\\t'
    } else if (code === 0x08) {
      out += '\\b'
    } else if (code === 0x0c) {
      out += '\\f'
    } else if (code < 0x20) {
      out += '\\u' + code.toString(16).padStart(4, '0')
    } else {
      out += ch
    }
  }
  return out
}

function _isPlainObject(v: unknown): v is Record<string, unknown> {
  if (v === null || typeof v !== 'object') return false
  const p = Object.getPrototypeOf(v)
  return p === null || p === Object.prototype
}

function _encodeNumber(n: number): string | null {
  // serde_json represents integers via Number::from_i64 / from_u64 and
  // non-integers via Number::from_f64 (ryu shortest round-trip). When
  // the napi-rs layer converts a JS number to `serde_json::Value`, an
  // integer in i64 range becomes `Number::from_i64` (no decimal point)
  // and a non-integer becomes the f64 form.
  //
  // For safe-integer values, `String(n)` matches Rust exactly.
  //
  // For non-integer values, `String(n)` matches ryu's output for the
  // vast majority of finite f64s (both use the shortest decimal that
  // round-trips). Rare divergences (e.g. `1e21` → `"1e+21"` in JS but
  // `"1e21"` in Rust) would silently mis-map redactions; we detect a
  // small set of known-divergent forms and fail-closed when we spot
  // them. NaN / Infinity are unrepresentable in JSON and always fail.
  if (!Number.isFinite(n)) return null
  if (Number.isInteger(n) && Number.isSafeInteger(n)) {
    return String(n)
  }
  const s = String(n)
  // Bail on JS's `e+` / `e-` exponent format because Rust ryu emits
  // exponents without a `+` sign for positive exponents (e.g. `1e21`
  // vs JS `1e+21`). Better to fall back to the legacy stringified
  // result than to silently apply offsets against the wrong text.
  if (s.indexOf('e+') !== -1) return null
  // `-0` round-trips to `"0"` in JS but Rust ryu may emit `"-0.0"`.
  // Conservatively fail-closed.
  if (Object.is(n, -0)) return null
  return s
}

interface CanonicaliseOk {
  ok: true
  form: CanonicalForm
}
interface CanonicaliseErr {
  ok: false
  reason: string
}

/**
 * Build a canonical JSON form of `value` matching `serde_json`'s
 * default output and collect the codepoint-ranges of every string
 * leaf's content (excluding surrounding quotes).
 *
 * Returns `{ ok: true, form }` on success, `{ ok: false, reason }`
 * when `value` contains a type that cannot be represented
 * byte-equivalent to `serde_json` (NaN / Infinity, BigInt, Symbol
 * keys, circular refs, non-plain-object container with non-string
 * keys, …).
 *
 * Exported for the byte-parity test.
 */
export function _buildCanonicalWithLeafRanges(value: unknown): CanonicaliseOk | CanonicaliseErr {
  const parts: string[] = []
  let pos = 0
  const leafRanges: LeafRange[] = []
  const seen = new WeakSet<object>()

  function emit(s: string): void {
    parts.push(s)
    pos += _codepointLength(s)
  }

  function build(v: unknown, path: ReadonlyArray<string | number>): string | null {
    if (v === null || v === undefined) {
      // serde_json renders `Value::Null` as `null`. JS `undefined` has
      // no JSON representation; the napi-rs layer normalises it to
      // `Value::Null` at the FFI boundary, so we treat them the same.
      emit('null')
      return null
    }
    if (typeof v === 'boolean') {
      emit(v ? 'true' : 'false')
      return null
    }
    if (typeof v === 'number') {
      const enc = _encodeNumber(v)
      if (enc === null) return 'unrepresentable number: ' + String(v)
      emit(enc)
      return null
    }
    if (typeof v === 'bigint') {
      return 'BigInt has no JSON representation'
    }
    if (typeof v === 'string') {
      emit('"')
      const escaped = _escapeJsonString(v)
      const start = pos
      emit(escaped)
      const end = pos
      emit('"')
      leafRanges.push({ path, contentStart: start, contentEnd: end })
      return null
    }
    if (typeof v === 'function' || typeof v === 'symbol') {
      return 'unsupported type: ' + typeof v
    }
    if (Array.isArray(v)) {
      if (seen.has(v)) return 'circular reference'
      seen.add(v)
      emit('[')
      let first = true
      for (let i = 0; i < v.length; i++) {
        if (!first) emit(',')
        first = false
        // eslint-disable-next-line security/detect-object-injection -- i is a numeric loop index over an Array, not user input.
        const err = build(v[i], path.concat(i))
        if (err) return err
      }
      emit(']')
      return null
    }
    if (_isPlainObject(v)) {
      if (seen.has(v)) return 'circular reference'
      seen.add(v)
      // Reject any Symbol-keyed properties — serde_json's `Map` only
      // accepts string keys, and silently dropping the symbol-keyed
      // entries would let Rust render a different shape than we
      // walk here.
      if (Object.getOwnPropertySymbols(v).length > 0) {
        return 'object has Symbol-keyed properties'
      }
      const keys = Object.keys(v).slice().sort()
      emit('{')
      let first = true
      for (const k of keys) {
        if (!first) emit(',')
        first = false
        emit('"')
        emit(_escapeJsonString(k))
        emit('"')
        emit(':')
        // eslint-disable-next-line security/detect-object-injection -- k comes from Object.keys(v).sort() after the plain-object guard above.
        const err = build(v[k], path.concat(k))
        if (err) return err
      }
      emit('}')
      return null
    }
    // Map / Set / Date / Buffer / TypedArray / class instance / etc.
    // The napi-rs layer's JSON conversion would render these
    // differently (or fail entirely) — bail safely.
    return 'unsupported container: ' + Object.prototype.toString.call(v)
  }

  const err = build(value, [])
  if (err) {
    return { ok: false, reason: err }
  }
  return {
    ok: true,
    form: {
      canonical: parts.join(''),
      canonicalLength: pos,
      leafRanges,
    },
  }
}

// ───────────────────────────────────────────────────────────────────
// Span-based redaction reconstruction
// ───────────────────────────────────────────────────────────────────

function _pathKey(p: ReadonlyArray<string | number>): string {
  // Stable, collision-free key — JSON-escaping the array prevents
  // confusion between numeric `2` and string `"2"`.
  return JSON.stringify(p)
}

/**
 * Slice a string by CODEPOINT range. JavaScript's `String#slice` works
 * on UTF-16 code units, which would cleave a surrogate pair in half
 * for astral-plane characters. This function walks codepoints to
 * preserve the Rust core's span contract.
 */
function _codepointSlice(s: string, start: number, end: number): string {
  let out = ''
  let i = 0
  for (const ch of s) {
    if (i >= end) break
    if (i >= start) out += ch
    i++
  }
  return out
}

interface LeafSplice {
  startCp: number
  endCp: number
  replacement: string
}

function _applyLeafTransforms(original: string, transforms: LeafSplice[]): string {
  // Apply transforms to the ESCAPED form (offsets are escape-space).
  // Sort by start descending so earlier splices don't invalidate
  // later offsets, then JSON-decode the resulting quoted form.
  const escaped = _escapeJsonString(original)
  const sorted = transforms.slice().sort((a, b) => b.startCp - a.startCp)
  let out = escaped
  const escLen = _codepointLength(escaped)
  for (const t of sorted) {
    if (t.startCp < 0 || t.endCp > escLen || t.startCp > t.endCp) {
      // Defensive: out-of-range span. Drop the splice and keep
      // whatever was already applied — failing-open would leave PHI
      // in place, so we leave the partial redaction.
      continue
    }
    const head = _codepointSlice(out, 0, t.startCp)
    const tail = _codepointSlice(out, t.endCp, _codepointLength(out))
    out = head + t.replacement + tail
  }
  try {
    return JSON.parse('"' + out + '"') as string
  } catch {
    // The redaction broke JSON escape syntax (e.g. replacement
    // injected an unescaped `"` or trailing `\`). Return the
    // redacted-escaped form raw rather than dropping the redaction.
    return out
  }
}

function _rebuild(
  value: unknown,
  perLeaf: Map<string, LeafSplice[]>,
  path: ReadonlyArray<string | number>,
): unknown {
  if (Array.isArray(value)) {
    return value.map((item, i) => _rebuild(item, perLeaf, path.concat(i)))
  }
  if (_isPlainObject(value)) {
    const out: Record<string, unknown> = {}
    for (const k of Object.keys(value)) {
      // eslint-disable-next-line security/detect-object-injection -- k comes from Object.keys(value) after the plain-object guard.
      out[k] = _rebuild(value[k], perLeaf, path.concat(k))
    }
    return out
  }
  if (typeof value === 'string') {
    const splices = perLeaf.get(_pathKey(path))
    if (!splices || splices.length === 0) return value
    return _applyLeafTransforms(value, splices)
  }
  return value
}

/**
 * Rebuild a structured value of the same shape as `original` with
 * string-leaf-only redactions applied per `appliedTransforms`.
 *
 * Each transform's `[spanStart, spanEnd)` is checked against the
 * string-leaf content ranges in the canonical JSON of `original`.
 * Transforms that fall fully inside a single leaf's content are
 * applied to that leaf (with offsets translated to leaf-relative).
 * Transforms that fall on non-string regions (numeric literals,
 * booleans, structural punctuation, object keys) — or that straddle
 * leaf boundaries — are DROPPED.
 *
 * Returns the recovered value on success, or `null` when canonical
 * reconstruction is not possible (caller should fall back to the
 * legacy stringified result — never a silent partial redaction).
 *
 * `original` MUST be a plain object or array; the function returns
 * `null` for scalars (they have no container shape to recover).
 */
export function recoverStructuredRedactions(
  original: unknown,
  appliedTransforms: ReadonlyArray<AppliedTransformLike>,
): unknown | null {
  if (!_isPlainObject(original) && !Array.isArray(original)) {
    return null
  }
  const built = _buildCanonicalWithLeafRanges(original)
  if (!built.ok) return null
  const { leafRanges } = built.form

  const perLeaf = new Map<string, LeafSplice[]>()
  const pathByKey = new Map<string, ReadonlyArray<string | number>>()
  for (const lr of leafRanges) {
    pathByKey.set(_pathKey(lr.path), lr.path)
  }
  void pathByKey // reserved for future debug, but each path is encoded inside perLeaf's key.

  for (const t of appliedTransforms) {
    const ts = t.spanStart
    const te = t.spanEnd
    if (typeof ts !== 'number' || typeof te !== 'number' || ts > te) {
      continue
    }
    const repl = typeof t.replacement === 'string' ? t.replacement : ''
    let host: LeafRange | null = null
    for (const lr of leafRanges) {
      if (lr.contentStart <= ts && te <= lr.contentEnd) {
        host = lr
        break
      }
    }
    if (host === null) {
      // Span falls outside any string leaf's content (numeric
      // literal, structural punctuation, object key, or straddles a
      // leaf boundary). Redactors only
      // apply to string leaves — drop the transform.
      continue
    }
    const key = _pathKey(host.path)
    const list = perLeaf.get(key) ?? []
    list.push({
      startCp: ts - host.contentStart,
      endCp: te - host.contentStart,
      replacement: repl,
    })
    perLeaf.set(key, list)
  }

  try {
    return _rebuild(original, perLeaf, [])
  } catch {
    return null
  }
}

// ───────────────────────────────────────────────────────────────────
// Public helper used by `Session.validateToolOutput`
// ───────────────────────────────────────────────────────────────────

/**
 * Check whether `value` is a container the Rust core would have
 * flattened to JSON in Stage 4. Strings, numbers, booleans, null,
 * and `undefined` are passed through Stage 4 as-is (or as a string
 * for the string case) — only object / array inputs need shape
 * recovery on the way out.
 */
export function _isStage4StructuredInput(value: unknown): boolean {
  return _isPlainObject(value) || Array.isArray(value)
}

// Re-exports kept stable for the byte-parity test in
// `__tests__/stage4_shape_byte_parity.test.ts`. Any rename would
// break that test, which is intentional — it pins the canonical
// encoder against the Python implementation and the Rust core.
//
// Used by the byte-parity test only:
//   - _escapeJsonString
//   - _buildCanonicalWithLeafRanges
//
// Used by `Session.validateToolOutput`:
//   - recoverStructuredRedactions
//   - _isStage4StructuredInput
//
// Internal-only:
//   - _codepointLength, _codepointSlice, _applyLeafTransforms, …
