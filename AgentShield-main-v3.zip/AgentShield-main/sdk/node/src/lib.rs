//! Node.js bindings for the unified-resolver runtime.
//!
//! Every exported class / function is a thin shim over
//! `agent_shield_core::*` — the napi layer only handles JSON
//! marshaling and TSFN bridging for host hooks (`AgentResolver`,
//! `AgentResolver`, `DelegateDispatcher`, `LlmCaller`,
//! `ClassifierCaller`, `ObservabilityProvider`, populator
//! `Extractor`).
//!
//! ## Threading model
//!
//! - The session methods on [`agent_shield_core::GuardrailsSession`]
//!   take `&self` and use interior mutability, so the napi class holds
//!   an `Arc<CoreGuardrailsSession>` with no outer lock.
//! - Async stage methods are declared `pub async fn` so napi-rs returns
//!   Promises naturally and the call runs on a tokio worker. That gives
//!   sync host hooks (which must `block_in_place(block_on(...))` on a
//!   TSFN call) a tokio runtime to land on.
//! - Pure boundary / variable / event ops are `pub fn` (sync) — they
//!   never invoke a host hook.

// agent_shield_core::RuntimeError is intentionally large; the core
// silences this lint at its own crate level, but the size propagates
// into every Result<T, RuntimeError> we surface across napi.
#![allow(clippy::result_large_err)]

use std::collections::HashMap;
use std::pin::Pin;
use std::sync::{Arc, OnceLock};

use napi::bindgen_prelude::*;
use napi::threadsafe_function::{ErrorStrategy, ThreadsafeFunction, ThreadsafeFunctionCallMode};
use napi_derive::napi;
use serde_json::{Map, Value};
use std::sync::Mutex as StdMutex;

use agent_shield_core::guard_policy_runtime::streaming::StreamingTrigger;
use agent_shield_core::resolver_runtime::{HumanResolveRequest, HumanResolver};
use agent_shield_core::{
    AgentResolveRequest, AgentResolver, ClassifierCaller, ClassifierVerdict,
    CompiledPolicy as CoreCompiledPolicy, DelegateDispatcher, DelegateRequest, Extractor,
    GuardrailsConfig as CoreGuardrailsConfig, GuardrailsRuntime as CoreGuardrailsRuntime,
    GuardrailsSession as CoreGuardrailsSession, InvalidResponseKind, Layer, LlmCaller, LlmResponse,
    ObsStage, ObservabilityProvider, RequestContext, ResolverDecision, ResolverResponse,
    ResolverRuntimeError, RuntimeBuilder, ShieldLogEvent, StageVerdict, StreamChunkAction,
    StreamChunkResult, StreamingGuard as CoreStreamingGuard, StreamingOptions,
};

/// Shared tokio runtime used to drive TSFN calls from Rust contexts that
/// are NOT already on a tokio worker (e.g. host calls into a sync session
/// method whose internals end up triggering a host hook). One worker is
/// enough — TSFN call_async only needs a runtime to await the host's
/// returned Promise.
fn sync_bridge_runtime() -> &'static tokio::runtime::Runtime {
    static RT: OnceLock<tokio::runtime::Runtime> = OnceLock::new();
    RT.get_or_init(|| {
        tokio::runtime::Builder::new_multi_thread()
            .worker_threads(1)
            .enable_all()
            .thread_name("agent-shield-sync-bridge")
            .build()
            .expect("failed to build agent-shield sync bridge runtime")
    })
}

// ─── JSON helpers ──────────────────────────────────────────────────

fn stage_verdict_to_json(v: &StageVerdict) -> Value {
    v.to_wire_value()
}

fn stage_verdict_with_params(
    verdict: &StageVerdict,
    params: &Value,
    admission: Option<agent_shield_core::AdmissionHandle>,
) -> Value {
    let mut m = Map::new();
    m.insert("verdict".into(), stage_verdict_to_json(verdict));
    m.insert("params".into(), params.clone());
    if let Some(handle) = admission {
        m.insert("admissionId".into(), Value::String(handle.id().to_string()));
    }
    Value::Object(m)
}

fn stage_verdict_with_response(verdict: &StageVerdict, response: &str) -> Value {
    let mut m = Map::new();
    m.insert("verdict".into(), stage_verdict_to_json(verdict));
    m.insert("response".into(), Value::String(response.to_string()));
    Value::Object(m)
}

fn parse_request_context(raw: Option<Value>) -> RequestContext {
    let v = match raw {
        Some(v) => v,
        None => return RequestContext::default(),
    };
    let obj = match v.as_object() {
        Some(o) => o,
        None => return RequestContext::default(),
    };
    let session_id = obj
        .get("session_id")
        .and_then(|v| v.as_str())
        .map(|s| s.to_string());
    let correlation_id = obj
        .get("correlation_id")
        .and_then(|v| v.as_str())
        .map(|s| s.to_string());
    let mut ctx = match (session_id, correlation_id) {
        (Some(s), Some(c)) => RequestContext::new(s, c),
        (Some(s), None) => {
            let default = RequestContext::default();
            RequestContext::new(s, default.correlation_id)
        }
        (None, Some(c)) => {
            let default = RequestContext::default();
            RequestContext::new(default.session_id, c)
        }
        (None, None) => RequestContext::default(),
    };
    if obj.get("correlation_id").and_then(|v| v.as_str()).is_some() {
        ctx = ctx.with_explicit_correlation_id();
    }
    if let Some(u) = obj.get("user_id").and_then(|v| v.as_str()) {
        ctx = ctx.with_user_id(u);
    }
    if let Some(t) = obj.get("tenant_id").and_then(|v| v.as_str()) {
        ctx = ctx.with_tenant_id(t);
    }
    if let Some(ext) = obj.get("extensions").cloned() {
        ctx = ctx.with_extensions(ext);
    }
    ctx
}

#[allow(dead_code)]
fn resolver_decision_str(d: &ResolverDecision) -> &'static str {
    match d {
        ResolverDecision::Allow => "allow",
        ResolverDecision::Deny => "deny",
        ResolverDecision::Cancelled => "cancelled",
    }
}

#[allow(dead_code)]
fn parse_resolver_decision(s: &str) -> Option<ResolverDecision> {
    // No case-folding, no whitespace-trim, no `canceled` alias.
    match s {
        "allow" => Some(ResolverDecision::Allow),
        "deny" => Some(ResolverDecision::Deny),
        "cancelled" => Some(ResolverDecision::Cancelled),
        _ => None,
    }
}

// ─── Wire-shape parsers ───────────────────────────────────────────
//
// Every parser below routes through the canonical
// `agent_shield_core::wire_shapes` API. The Node-side wrappers exist
// only to convert ResolverDecision / Verdict types into the
// engine-internal shapes the rest of this module expects, and to
// preserve the historical `Result<...>` signatures for inline use in
// the `LlmCaller` / `ClassifierCaller` traits below. Hosts MUST NOT
// reimplement the JSON shape grammars — see `wire_shapes.rs` for the
// single source of truth.

fn parse_resolver_response(
    json: &str,
) -> std::result::Result<ResolverResponse, agent_shield_core::ResolverInvalidResponse> {
    agent_shield_core::parse_resolver_response_json(json)
}

fn parse_llm_response(s: &str) -> std::result::Result<LlmResponse, String> {
    if s.trim().is_empty() {
        return Err("empty llm response".into());
    }
    Ok(agent_shield_core::parse_llm_response_json(s))
}

fn parse_classifier_verdict(s: &str) -> std::result::Result<ClassifierVerdict, String> {
    if s.trim().is_empty() {
        return Err("empty classifier response".into());
    }
    Ok(agent_shield_core::parse_classifier_verdict_json(s))
}

// Resource kind / envelope helpers — the canonical builders live in
// `agent_shield_core::wire_shapes`, but Node has a few internal call
// sites (e.g. observability events) that still want the bare envelope,
// so the local helpers stay as thin shims.
fn resource_kind_str(k: agent_shield_core::ResourceKind) -> &'static str {
    use agent_shield_core::ResourceKind::*;
    match k {
        Tool => "tool",
        Endpoint => "endpoint",
        Agent => "agent",
    }
}

/// Build the `resource: {kind, name, params?}` envelope.
/// Returns `Value::Null` when the resolver context has no resource
/// attached (e.g. a top-level `validate_input` resolution).
#[allow(dead_code)]
fn resource_envelope(
    kind: Option<agent_shield_core::ResourceKind>,
    name: Option<&String>,
    params: Option<&Value>,
) -> Value {
    let (kind, name) = match (kind, name) {
        (Some(k), Some(n)) => (k, n.clone()),
        _ => return Value::Null,
    };
    let mut m = Map::new();
    m.insert(
        "kind".into(),
        Value::String(resource_kind_str(kind).to_string()),
    );
    m.insert("name".into(), Value::String(name));
    if let Some(p) = params {
        m.insert("params".into(), p.clone());
    }
    Value::Object(m)
}

fn agent_request_to_json(req: &AgentResolveRequest) -> Value {
    agent_shield_core::serialize_agent_request_json(req)
}

fn delegate_request_to_json(req: &DelegateRequest) -> Value {
    agent_shield_core::serialize_delegate_request_json(req)
}

/// Build the JSON envelope delivered to a registered
/// [`HumanResolver`]. Mirrors [`agent_request_to_json`] but adds the
/// spec `approval_nonce` anti-replay token, plus the optional
/// `invocation_hash`, `session_id`, `requested_key`, and
/// `timeout_ms` fields carried by [`HumanResolveRequest`].
/// Cross-language parity: matches the dict shape produced by the
/// Python `PyHumanResolver` in `sdk/python/src/lib.rs`.
fn human_request_to_json(req: &HumanResolveRequest) -> Value {
    let mut m = Map::new();
    m.insert("request_id".into(), Value::String(req.request_id.clone()));
    m.insert(
        "variable".into(),
        req.variable
            .as_ref()
            .map(|v| Value::String(v.clone()))
            .unwrap_or(Value::Null),
    );
    m.insert(
        "resource".into(),
        resource_envelope(
            req.resource_kind,
            req.resource_name.as_ref(),
            req.resource_params.as_ref(),
        ),
    );
    m.insert(
        "prompt".into(),
        req.prompt
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    m.insert(
        "reason".into(),
        req.reason
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    m.insert(
        "approval_nonce".into(),
        Value::String(req.approval_nonce.clone()),
    );
    m.insert(
        "invocation_hash".into(),
        req.invocation_hash
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    m.insert(
        "session_id".into(),
        req.session_id
            .as_ref()
            .map(|s| Value::String(s.as_str().to_string()))
            .unwrap_or(Value::Null),
    );
    m.insert(
        "requested_key".into(),
        req.requested_key.clone().unwrap_or(Value::Null),
    );
    m.insert(
        "timeout_ms".into(),
        req.timeout_ms
            .map(|t| Value::Number(t.into()))
            .unwrap_or(Value::Null),
    );
    m.insert("context".into(), Value::Object(req.context.clone()));
    Value::Object(m)
}

fn variable_state_to_json(st: &agent_shield_core::VariableState) -> Value {
    st.to_wire_value()
}

// ─── TSFN bridge helper ─────────────────────────────────────────────

/// Call a TSFN with a String input and await a JS Promise<String> reply.
///
/// Behaves correctly whether or not the caller is already on a tokio
/// runtime worker:
///   - If a tokio runtime is current, uses `block_in_place(block_on(...))`
///     so we don't deadlock the worker.
///   - Otherwise routes the await through the dedicated
///     [`sync_bridge_runtime`].
fn call_tsfn_blocking(
    tsfn: &ThreadsafeFunction<String, ErrorStrategy::CalleeHandled>,
    arg: String,
) -> std::result::Result<String, String> {
    let fut = async {
        let promise: std::result::Result<Promise<String>, napi::Error> =
            tsfn.call_async::<Promise<String>>(Ok(arg)).await;
        match promise {
            Ok(p) => p.await.map_err(|e| format!("{e}")),
            Err(e) => Err(format!("{e}")),
        }
    };
    if let Ok(handle) = tokio::runtime::Handle::try_current() {
        tokio::task::block_in_place(|| handle.block_on(fut))
    } else {
        sync_bridge_runtime().block_on(fut)
    }
}

// ─── Host-hook trait shims ─────────────────────────────────────────

struct JsAgentResolver(ThreadsafeFunction<String, ErrorStrategy::CalleeHandled>);

impl AgentResolver for JsAgentResolver {
    fn resolve(
        &self,
        req: AgentResolveRequest,
    ) -> std::result::Result<ResolverResponse, ResolverRuntimeError> {
        let json = serde_json::to_string(&agent_request_to_json(&req)).unwrap_or_default();
        match call_tsfn_blocking(&self.0, json) {
            Ok(s) => {
                parse_resolver_response(&s).map_err(|e| ResolverRuntimeError::InvalidResponse {
                    kind: "agent",
                    invalid_kind: InvalidResponseKind::Generic,
                    message: e.reason,
                })
            }
            Err(e) => Ok(ResolverResponse {
                decision: ResolverDecision::Deny,
                value: None,
                set_variables: HashMap::new(),
                reason: Some(format!("agent resolver error: {e}")),
            }),
        }
    }
}

struct JsDelegateDispatcher(ThreadsafeFunction<String, ErrorStrategy::CalleeHandled>);

impl DelegateDispatcher for JsDelegateDispatcher {
    fn dispatch(
        &self,
        req: DelegateRequest,
    ) -> std::result::Result<ResolverResponse, ResolverRuntimeError> {
        let json = serde_json::to_string(&delegate_request_to_json(&req)).unwrap_or_default();
        match call_tsfn_blocking(&self.0, json) {
            Ok(s) => {
                parse_resolver_response(&s).map_err(|e| ResolverRuntimeError::InvalidResponse {
                    kind: "delegate",
                    invalid_kind: InvalidResponseKind::Generic,
                    message: e.reason,
                })
            }
            Err(e) => Ok(ResolverResponse {
                decision: ResolverDecision::Deny,
                value: None,
                set_variables: HashMap::new(),
                reason: Some(format!("delegate dispatcher error: {e}")),
            }),
        }
    }
}

/// Bridge an `Arc<dyn HumanResolver>` to a host-supplied Node.js
/// callback. Mirrors [`JsAgentResolver`] but dispatches through the
/// runtime's single `kind: human` resolver slot.
struct JsHumanResolver(ThreadsafeFunction<String, ErrorStrategy::CalleeHandled>);

impl HumanResolver for JsHumanResolver {
    fn resolve(
        &self,
        req: HumanResolveRequest,
    ) -> std::result::Result<ResolverResponse, ResolverRuntimeError> {
        let json = serde_json::to_string(&human_request_to_json(&req)).unwrap_or_default();
        match call_tsfn_blocking(&self.0, json) {
            Ok(s) => {
                parse_resolver_response(&s).map_err(|e| ResolverRuntimeError::InvalidResponse {
                    kind: "human",
                    invalid_kind: InvalidResponseKind::Generic,
                    message: e.reason,
                })
            }
            Err(e) => Ok(ResolverResponse {
                decision: ResolverDecision::Deny,
                value: None,
                set_variables: HashMap::new(),
                reason: Some(format!("human resolver error: {e}")),
            }),
        }
    }
}

struct JsLlmCaller(ThreadsafeFunction<String, ErrorStrategy::CalleeHandled>);

impl LlmCaller for JsLlmCaller {
    fn call(
        &self,
        configuration_id: Option<&str>,
        prompt: &str,
    ) -> std::result::Result<LlmResponse, String> {
        let payload = serde_json::json!({
            "configuration_id": configuration_id,
            "prompt": prompt,
        });
        let json = serde_json::to_string(&payload).unwrap_or_default();
        let response =
            call_tsfn_blocking(&self.0, json).map_err(|e| format!("llm caller error: {e}"))?;
        parse_llm_response(&response)
    }
}

struct JsClassifierCaller(ThreadsafeFunction<String, ErrorStrategy::CalleeHandled>);

impl ClassifierCaller for JsClassifierCaller {
    fn classify(
        &self,
        configuration_id: &str,
        subject: &str,
    ) -> std::result::Result<ClassifierVerdict, String> {
        let payload = serde_json::json!({
            "configuration_id": configuration_id,
            "subject": subject,
        });
        let json = serde_json::to_string(&payload).unwrap_or_default();
        let response =
            call_tsfn_blocking(&self.0, json).map_err(|e| format!("classifier error: {e}"))?;
        parse_classifier_verdict(&response)
    }
}

/// Bounded queue size for the observability TSFN. Observability is
/// fire-and-forget by design — when the consumer can't drain events
/// fast enough, the queue caps at this length and further events are
/// dropped (with a one-shot warning to stderr) rather than letting
/// native memory grow unbounded.
const OBSERVABILITY_QUEUE_SIZE: usize = 4096;

struct JsObservabilityProvider {
    tsfn: ThreadsafeFunction<String, ErrorStrategy::CalleeHandled>,
    /// Number of events dropped because the bounded TSFN queue was full.
    /// Incremented atomically so we can emit a single warning the first
    /// time it happens without spamming.
    dropped: std::sync::atomic::AtomicU64,
}

impl ObservabilityProvider for JsObservabilityProvider {
    fn emit(&self, event: ShieldLogEvent) {
        let json = match serde_json::to_string(&event) {
            Ok(s) => s,
            Err(_) => return,
        };
        // Fire-and-forget — observability MUST NOT block the engine.
        // With a bounded queue + NonBlocking, `call` returns
        // `Status::QueueFull` when we'd grow native memory; we drop the
        // event in that case.
        let status = self
            .tsfn
            .call(Ok(json), ThreadsafeFunctionCallMode::NonBlocking);
        if status != napi::Status::Ok {
            let prev = self
                .dropped
                .fetch_add(1, std::sync::atomic::Ordering::Relaxed);
            // Warn once when the first drop happens; subsequent drops
            // are silent so a slow consumer can't generate log spam.
            if prev == 0 {
                eprintln!(
                    "agent-shield: observability TSFN queue full ({} events queued), dropping events — slow JS consumer?",
                    OBSERVABILITY_QUEUE_SIZE
                );
            }
        }
    }
}

struct JsExtractor(ThreadsafeFunction<String, ErrorStrategy::CalleeHandled>);

impl Extractor for JsExtractor {
    fn extract(&self, raw: &Value) -> Option<Value> {
        let json = serde_json::to_string(raw).unwrap_or_else(|_| "null".into());
        match call_tsfn_blocking(&self.0, json) {
            Ok(s) => agent_shield_core::parse_extractor_output_json(&s),
            Err(_) => None,
        }
    }
}

// ─── Builder ────────────────────────────────────────────────────────

/// runtime builder. `from_yaml` / `from_yaml_chain` produce a builder
/// that is mutated through `register_*` methods and finalized via
/// [`Self::build`]. Every register method consumes the inner builder
/// (because the underlying [`agent_shield_core::RuntimeBuilder`]
/// uses move-style chaining) and stashes the new value back in the
/// `Option<...>` slot.
#[napi(js_name = "RuntimeBuilder")]
pub struct JsRuntimeBuilder {
    inner: StdMutex<Option<RuntimeBuilder>>,
}

impl JsRuntimeBuilder {
    fn take(&self) -> Result<RuntimeBuilder> {
        self.inner
            .lock()
            .unwrap()
            .take()
            .ok_or_else(|| Error::from_reason("already consumed"))
    }
    fn put(&self, b: RuntimeBuilder) {
        *self.inner.lock().unwrap() = Some(b);
    }
    fn with<F: FnOnce(RuntimeBuilder) -> RuntimeBuilder>(&self, f: F) -> Result<()> {
        let b = self.take()?;
        self.put(f(b));
        Ok(())
    }
}

fn make_string_tsfn(
    env: &Env,
    callback: JsFunction,
) -> Result<ThreadsafeFunction<String, ErrorStrategy::CalleeHandled>> {
    let mut tsfn = callback.create_threadsafe_function(0, |ctx| Ok(vec![ctx.value]))?;
    tsfn.unref(env)?;
    Ok(tsfn)
}

/// Build a TSFN with a bounded queue, used exclusively for the
/// observability provider. Other request/response hooks need
/// synchronous responses so they keep `max_queue_size = 0` (unbounded);
/// observability is fire-and-forget so it tolerates drops.
fn make_observability_tsfn(
    env: &Env,
    callback: JsFunction,
) -> Result<ThreadsafeFunction<String, ErrorStrategy::CalleeHandled>> {
    let mut tsfn =
        callback.create_threadsafe_function(OBSERVABILITY_QUEUE_SIZE, |ctx| Ok(vec![ctx.value]))?;
    tsfn.unref(env)?;
    Ok(tsfn)
}

// ─── Observability callback isolation (R76.5) ──────────────────────
//
// The TSFN trampoline for fire-and-forget `.call()` invocations
// terminates the host Node process via `napi_fatal_exception` if the
// JS callback throws synchronously (see napi 2.16 source,
// `threadsafe_function::call_js_cb` → `handle_call_js_cb_status`).
// Observability sinks are notoriously buggy (custom SIEM transports,
// log forwarders, user-supplied formatters); a single throw must
// never take down the agent. The Python and .NET bindings already
// catch + swallow at the trait shim, so this also restores
// cross-SDK parity.
//
// We isolate the user callback by replacing it with a Rust-managed
// wrapper function (`create_function_from_closure`) before handing
// it to `create_threadsafe_function`. The wrapper invokes the user
// JS function via `JsFunction::call`, which internally clears any
// pending exception and surfaces it as a `Result::Err` — so the
// throw never escapes back into the trampoline's pending-exception
// check.

/// Process-global registry of user-supplied observability callbacks,
/// each held alive by a napi `Ref<()>`. Entries are never removed —
/// the runtime that owns the wrapping TSFN typically lives for the
/// host process's lifetime, and napi's `Ref<()>::drop` impl carries a
/// `debug_assert` against dropping a non-zero refcount that would
/// otherwise panic whenever a builder is collected in tests.
static OBS_CB_REGISTRY: OnceLock<StdMutex<HashMap<u64, napi::Ref<()>>>> = OnceLock::new();
static OBS_CB_NEXT_ID: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
/// First-error gate. The very first observability-callback exception
/// emits `log::warn!`; subsequent ones go to `log::debug!` so a
/// persistently-broken sink can't generate log spam.
static OBS_CB_ERROR_COUNT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);

fn obs_cb_registry() -> &'static StdMutex<HashMap<u64, napi::Ref<()>>> {
    OBS_CB_REGISTRY.get_or_init(|| StdMutex::new(HashMap::new()))
}

/// Wrap a user-supplied JS observability callback in a Rust-managed
/// guard that catches any synchronous JavaScript exception thrown by
/// the user code and routes it through `log::warn!` / `log::debug!`
/// instead of letting it propagate up the napi TSFN trampoline
/// (which would call `napi_fatal_exception` and terminate the host
/// Node process). R76.5.
///
/// The original user `JsFunction` is held alive via a napi `Ref<()>`
/// in [`OBS_CB_REGISTRY`]; the returned wrapper function captures the
/// registry id and looks the user fn up on each invocation.
///
/// Per `docs/logging-style-guide.md` Rule 1, the event payload (which
/// may contain tool args, variable values, etc.) MUST NOT appear at
/// `info+`. Only a stable category + the napi error type are logged;
/// the raw exception message is demoted to `debug`.
fn wrap_observability_callback(env: &Env, callback: JsFunction) -> Result<JsFunction> {
    let user_ref = env.create_reference(callback)?;
    let id = OBS_CB_NEXT_ID.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
    obs_cb_registry().lock().unwrap().insert(id, user_ref);

    env.create_function_from_closure(
        "agentShieldObservabilityCallback",
        move |ctx: napi::CallContext<'_>| -> Result<napi::JsUndefined> {
            let n = ctx.length;
            let mut args: Vec<napi::JsUnknown> = Vec::with_capacity(n);
            for i in 0..n {
                args.push(ctx.get::<napi::JsUnknown>(i)?);
            }
            let user_fn: JsFunction = {
                let guard = obs_cb_registry().lock().unwrap();
                let r = match guard.get(&id) {
                    Some(r) => r,
                    None => return ctx.env.get_undefined(),
                };
                ctx.env.get_reference_value::<JsFunction>(r)?
            };

            if let Err(e) = user_fn.call(None, &args) {
                let prev = OBS_CB_ERROR_COUNT
                    .fetch_add(1, std::sync::atomic::Ordering::Relaxed);
                if prev == 0 {
                    log::warn!(
                        target: "agent_shield_observability_callback_error",
                        "observability callback threw; isolating failure (R76.5). Subsequent exceptions logged at DEBUG."
                    );
                }
                log::debug!(
                    target: "agent_shield_observability_callback_error",
                    "observability callback exception: {}",
                    e
                );
            }
            ctx.env.get_undefined()
        },
    )
}

/// Map a `RuntimeError` from a loader path (`from_yaml*`, `build`) to a
/// napi `Error`. For `RuntimeError::Config(_)` we prepend a sentinel JSON
/// envelope on the *reason* string so the TypeScript wrapper can lift the
/// structured fields (`path`, `line`, `column`, `field`, `code`,
/// `remediation`) into an `AgentShieldConfigError` instance while still
/// preserving the canonical Display message as a substring (existing tests
/// grep on substrings like `"already in extends chain"`).
fn map_loader_err(e: agent_shield_core::RuntimeError) -> Error {
    if let Some(wire) = e.loader_wire() {
        let json = wire.to_json();
        Error::from_reason(format!("AGENT_SHIELD_LOADER_ERROR_JSON:{json}\n{e}"))
    } else {
        Error::from_reason(format!("{e}"))
    }
}

#[napi]
impl JsRuntimeBuilder {
    /// Load a single guardrails YAML file and resolve any `extends:` chain.
    #[napi(factory)]
    pub fn from_yaml(path: String) -> Result<Self> {
        let inner =
            RuntimeBuilder::from_yaml(std::path::Path::new(&path)).map_err(map_loader_err)?;
        Ok(Self {
            inner: StdMutex::new(Some(inner)),
        })
    }

    /// Load a prepared chain of YAML files (leaf-wins).
    #[napi(factory)]
    pub fn from_yaml_chain(paths: Vec<String>) -> Result<Self> {
        let path_refs: Vec<&std::path::Path> = paths
            .iter()
            .map(|p| std::path::Path::new(p.as_str()))
            .collect();
        let inner = RuntimeBuilder::from_yaml_chain(&path_refs).map_err(map_loader_err)?;
        Ok(Self {
            inner: StdMutex::new(Some(inner)),
        })
    }

    /// Load a prepared chain of YAML strings (leaf-wins).
    #[napi(factory)]
    pub fn from_yaml_strings(yamls: Vec<String>) -> Result<Self> {
        let refs: Vec<&str> = yamls.iter().map(String::as_str).collect();
        let inner = RuntimeBuilder::from_yaml_strings(&refs).map_err(map_loader_err)?;
        Ok(Self {
            inner: StdMutex::new(Some(inner)),
        })
    }

    /// Build from a [`CompiledPolicy`] produced by
    /// `GuardrailsConfig.compile()`. Lets the host cache compiled
    /// runtimes by content digest in multi-tenant SaaS deployments.
    #[napi(factory)]
    pub fn from_compiled_policy(compiled: &CompiledPolicy) -> Result<Self> {
        let inner = RuntimeBuilder::from_compiled_policy(compiled.inner.as_ref());
        Ok(Self {
            inner: StdMutex::new(Some(inner)),
        })
    }

    /// Register a `kind: agent` resolver.
    #[napi(ts_args_type = "callback: (err: Error | null, requestJson: string) => Promise<string>")]
    pub fn register_agent_resolver(&self, env: Env, callback: JsFunction) -> Result<()> {
        let tsfn = make_string_tsfn(&env, callback)?;
        let resolver: Arc<dyn AgentResolver> = Arc::new(JsAgentResolver(tsfn));
        self.with(|b| b.register_agent_resolver(resolver))
    }

    /// Register the delegate dispatcher used by `kind: delegate` resolvers.
    #[napi(ts_args_type = "callback: (err: Error | null, requestJson: string) => Promise<string>")]
    pub fn register_delegate_dispatcher(&self, env: Env, callback: JsFunction) -> Result<()> {
        let tsfn = make_string_tsfn(&env, callback)?;
        let dispatcher: Arc<dyn DelegateDispatcher> = Arc::new(JsDelegateDispatcher(tsfn));
        self.with(|b| b.register_delegate_dispatcher(dispatcher))
    }

    /// Register the runtime's active `kind: human` resolver callback
    /// Last call wins.
    #[napi(ts_args_type = "callback: (err: Error | null, requestJson: string) => Promise<string>")]
    pub fn register_human_resolver(&self, env: Env, callback: JsFunction) -> Result<()> {
        let tsfn = make_string_tsfn(&env, callback)?;
        let handler: Arc<dyn HumanResolver> = Arc::new(JsHumanResolver(tsfn));
        self.with(|b| b.register_human_resolver(handler))
    }

    /// Register the LLM caller used by `evaluate_when[].llm` detection.
    #[napi(ts_args_type = "callback: (err: Error | null, requestJson: string) => Promise<string>")]
    pub fn register_llm_caller(&self, env: Env, callback: JsFunction) -> Result<()> {
        let tsfn = make_string_tsfn(&env, callback)?;
        let caller: Arc<dyn LlmCaller> = Arc::new(JsLlmCaller(tsfn));
        self.with(|b| b.register_llm_caller(caller))
    }

    /// Register the classifier caller used by `evaluate_when[].classifier`.
    #[napi(ts_args_type = "callback: (err: Error | null, requestJson: string) => Promise<string>")]
    pub fn register_classifier_caller(&self, env: Env, callback: JsFunction) -> Result<()> {
        let tsfn = make_string_tsfn(&env, callback)?;
        let caller: Arc<dyn ClassifierCaller> = Arc::new(JsClassifierCaller(tsfn));
        self.with(|b| b.register_classifier_caller(caller))
    }

    /// Register an observability provider. Multiple providers fan-out;
    /// each call adds another. The callback is fire-and-forget — it
    /// receives a JSON-encoded `ShieldLogEvent` and any return value
    /// is ignored.
    ///
    /// R76.5 — the user callback is wrapped in a Rust-managed isolation
    /// shim ([`wrap_observability_callback`]) before being handed to
    /// the threadsafe-function trampoline, so a synchronous throw in
    /// the user's sink can never propagate up the napi boundary and
    /// crash the host Node process.
    #[napi(ts_args_type = "callback: (err: Error | null, eventJson: string) => void")]
    pub fn register_provider(&self, env: Env, callback: JsFunction) -> Result<()> {
        let guarded = wrap_observability_callback(&env, callback)?;
        let tsfn = make_observability_tsfn(&env, guarded)?;
        let provider: Arc<dyn ObservabilityProvider> = Arc::new(JsObservabilityProvider {
            tsfn,
            dropped: std::sync::atomic::AtomicU64::new(0),
        });
        self.with(|b| b.register_provider(provider))
    }

    /// Register a populator extractor (matched by reverse-domain name).
    #[napi(
        ts_args_type = "name: string, callback: (err: Error | null, rawJson: string) => Promise<string>"
    )]
    pub fn register_extractor(&self, env: Env, name: String, callback: JsFunction) -> Result<()> {
        let tsfn = make_string_tsfn(&env, callback)?;
        let extractor: Box<dyn Extractor> = Box::new(JsExtractor(tsfn));
        self.with(|b| b.register_extractor(&name, extractor))
    }

    /// Override the per-(turn, variable, tool) retry limit.
    #[napi]
    pub fn tool_retry_limit(&self, n: u32) -> Result<()> {
        self.with(|b| b.tool_retry_limit(n as usize))
    }

    /// Set the runtime's effective enforcement mode (#14). Accepts
    /// `"active"` or `"shadow"`. The `AGENT_SHIELD_MODE` env var,
    /// when set, takes precedence over this call.
    #[napi]
    pub fn with_mode(&self, mode: String) -> Result<()> {
        let m = agent_shield_core::shield_primitives::RuntimeMode::from_wire_str(&mode)
            .ok_or_else(|| {
                Error::from_reason(format!(
                    "withMode: unknown mode {mode:?} (expected `active` or `shadow`)"
                ))
            })?;
        self.with(|b| b.with_mode(m))
    }

    /// Declare host capability for sub-session IFC scope reset
    /// (proof TC-3 in `docs/information-flow-control-proof.md`).
    /// Required when the merged config declares `ifc.scope:
    /// per_turn` or `per_request`. Hosts that retain LLM context
    /// across these boundaries MUST NOT call this with `true`.
    #[napi]
    pub fn supports_context_reset(&self, supports: bool) -> Result<()> {
        self.with(|b| b.supports_context_reset(supports))
    }

    /// Pin streaming defaults. `trigger`: `0=on_complete`, `1=windowed`,
    /// `2=per_chunk`.
    #[napi]
    pub fn streaming_window(&self, trigger: u8, window_size: u32, overlap: u32) -> Result<()> {
        let trig = match trigger {
            1 => StreamingTrigger::Windowed,
            2 => StreamingTrigger::PerChunk,
            _ => StreamingTrigger::OnComplete,
        };
        let opts = StreamingOptions {
            trigger: trig,
            window_size: window_size as usize,
            overlap: overlap as usize,
        };
        self.with(|b| b.streaming_window(opts))
    }

    /// Consume the builder and produce a runtime.
    #[napi]
    pub fn build(&self) -> Result<GuardrailsRuntime> {
        let inner = self.take()?;
        let runtime = inner.build().map_err(map_loader_err)?;
        Ok(GuardrailsRuntime { inner: runtime })
    }

    /// Non-consuming snapshot of every `configurations[]` entry as an
    /// array of plain objects (full field set, identical shape to
    /// [`GuardrailsRuntime::configuration`]). Safe to call between
    /// other builder mutations; does NOT consume the builder.
    ///
    /// Mirrors `PyRuntimeBuilder.configurations` (Python). Used by
    /// adapter / framework integrations to wire host-side
    /// configuration resolvers at register time (e.g. classifier
    /// callers that need to know the resolved endpoint / headers /
    /// threshold before the runtime is built and `Runtime.configuration`
    /// becomes reachable).
    #[napi]
    pub fn configurations(&self) -> Result<Vec<Value>> {
        let guard = self.inner.lock().unwrap();
        let inner = guard
            .as_ref()
            .ok_or_else(|| Error::from_reason("already consumed"))?;
        Ok(inner
            .config()
            .configurations
            .iter()
            .map(|c| c.to_full_json_value())
            .collect())
    }
}

// ─── Runtime ────────────────────────────────────────────────────────

#[napi]
pub struct GuardrailsRuntime {
    inner: Arc<CoreGuardrailsRuntime>,
}

#[napi]
impl GuardrailsRuntime {
    /// Spawn a new per-conversation session bound to the given request
    /// context. `requestContext` may be omitted / null — the
    /// runtime auto-generates session/correlation ids.
    #[napi]
    pub fn new_session(&self, request_context: Option<Value>) -> Result<GuardrailsSession> {
        let ctx = parse_request_context(request_context);
        let session = self.inner.new_session(ctx);
        Ok(GuardrailsSession {
            inner: Arc::new(session),
        })
    }

    /// Borrow the merged config metadata name. Full config introspection
    /// is not exposed through napi yet — hosts that need it should use
    /// the YAML they loaded.
    #[napi]
    pub fn metadata_name(&self) -> String {
        self.inner.config().metadata.name.clone()
    }

    /// Look up a `configurations[]` entry by id.
    ///
    /// Returns an object mirroring the `ShieldConfiguration` fields
    /// for the resolved entry (snake_case keys — the JS facade
    /// camelCases them at the `Runtime.llmConfiguration` boundary),
    /// or `null` when no entry matches. Used by adapter LLM-caller
    /// closures to honour the YAML's per-stage `model:` / `provider:`
    /// `max_tokens:` selection rather than hard-coding a model name.
    /// Mirrors `PyGuardrailsRuntime.llm_configuration` in the Python
    /// SDK so the two surfaces stay byte-equivalent.
    #[napi]
    pub fn llm_configuration(&self, configuration_id: String) -> Value {
        for c in &self.inner.config().configurations {
            if c.id == configuration_id {
                let mut map = Map::new();
                map.insert("id".into(), Value::String(c.id.clone()));
                map.insert(
                    "type".into(),
                    Value::String(c.config_type.as_str().to_string()),
                );
                if let Some(ref m) = c.model {
                    map.insert("model".into(), Value::String(m.clone()));
                }
                if let Some(ref p) = c.provider {
                    map.insert("provider".into(), Value::String(p.clone()));
                }
                if let Some(ref pc) = c.provider_config {
                    map.insert("provider_config".into(), pc.clone());
                }
                if let Some(ref e) = c.endpoint {
                    map.insert("endpoint".into(), Value::String(e.clone()));
                }
                if let Some(t) = c.timeout {
                    map.insert("timeout".into(), Value::Number(t.into()));
                }
                if let Some(mt) = c.max_tokens {
                    map.insert("max_tokens".into(), Value::Number(mt.into()));
                }
                if let Some(ref env) = c.api_key_env {
                    map.insert("api_key_env".into(), Value::String(env.clone()));
                }
                if let Some(ref meta) = c.metadata {
                    map.insert("metadata".into(), meta.clone());
                }
                if let Some(def) = c.default {
                    map.insert("default".into(), Value::Bool(def));
                }
                return Value::Object(map);
            }
        }
        Value::Null
    }

    /// Look up ANY `configurations[]` entry by id, regardless of
    /// `type:`. Returns every populated field — including classifier-
    /// specific (`headers`, `threshold`, `category_thresholds`,
    /// `method`) and HTTP-endpoint / MCP / A2A fields that
    /// [`Self::llm_configuration`] omits.
    ///
    /// Mirrors `PyGuardrailsRuntime.configuration` in the Python SDK
    /// and `Runtime.Configuration` in the .NET SDK; routes through the
    /// language-agnostic
    /// `agent_shield_core::ShieldConfiguration::to_full_json_value`
    /// helper so the returned JSON is byte-equivalent across all
    /// three bindings — the cross-SDK regression contract for F97.6.
    ///
    /// Returns `null` when no entry matches.
    ///
    /// Classifier callbacks (notably the Azure AI Content Safety
    /// adapter and any custom-model classifier) invoke this from
    /// inside their `register_classifier_caller` closure with
    /// `request.configurationId` so they can read endpoint /
    /// headers / threshold / category_thresholds / provider_config
    /// directly from YAML rather than maintaining a parallel
    /// YAML→config map in code.
    #[napi]
    pub fn configuration(&self, configuration_id: String) -> Value {
        for c in &self.inner.config().configurations {
            if c.id == configuration_id {
                return c.to_full_json_value();
            }
        }
        Value::Null
    }

    /// Flush all pending observability events through the per-provider
    /// async dispatcher worker. Hosts that synchronously inspect captured
    /// events after a `validate*` call MUST flush first; with the
    /// per-provider async worker model events are otherwise not visible
    /// until the worker thread picks them up.
    #[napi]
    pub fn flush_observability(&self) {
        self.inner.observability().flush();
    }
}

// ─── Session ────────────────────────────────────────────────────────

#[napi]
pub struct GuardrailsSession {
    inner: Arc<CoreGuardrailsSession>,
}

#[napi]
impl GuardrailsSession {
    #[napi]
    pub fn set_correlation_id(&self, value: Option<String>) {
        self.inner.set_correlation_id(value);
    }

    // ── Variable ops ────────────────────────────────────────────────

    /// Set a declared variable. `value` is any JSON value.
    #[napi]
    pub fn set_variable(&self, name: String, value: Value) -> Result<()> {
        self.inner
            .set_variable(&name, value)
            .map_err(|e| Error::from_reason(format!("set_variable: {e}")))
    }

    /// Reset a declared variable to `unset`.
    #[napi]
    pub fn reset_variable(&self, name: String) -> Result<()> {
        self.inner
            .reset_variable(&name)
            .map_err(|e| Error::from_reason(format!("reset_variable: {e}")))
    }

    /// Synchronously invoke the variable's `on_demand_by:` resolver.
    /// Returns the resolved value, or `null` for `Deny` / `Cancelled`
    /// no resolver. Async because resolver hooks may dispatch
    /// through TSFN.
    #[napi]
    pub async fn resolve_variable(&self, name: String) -> Result<Value> {
        let inner = self.inner.clone();
        let result = tokio::task::spawn_blocking(move || inner.resolve_variable(&name))
            .await
            .map_err(|e| Error::from_reason(format!("resolve_variable: join: {e}")))?
            .map_err(|e| Error::from_reason(format!("resolve_variable: {e}")))?;
        Ok(result.unwrap_or(Value::Null))
    }

    /// Read the cached state envelope for a variable.
    /// Returns `null` if the variable is not declared.
    #[napi]
    pub fn read_variable(&self, name: String) -> Result<Value> {
        match self.inner.read_variable(&name) {
            Some(state) => Ok(variable_state_to_json(&state)),
            None => Ok(Value::Null),
        }
    }

    // ── Event ops ───────────────────────────────────────────────────

    /// Emit a closed-namespace event. `lifetime` is an optional YAML
    /// scalar/map already parsed into JSON shape; `payload` is any JSON.
    #[napi]
    pub fn emit_event(
        &self,
        event_id: String,
        lifetime: Option<Value>,
        payload: Option<Value>,
    ) -> Result<()> {
        let lt = match lifetime {
            None | Some(Value::Null) => None,
            Some(v) => {
                let lt: agent_shield_core::Lifetime = serde_json::from_value(v)
                    .map_err(|e| Error::from_reason(format!("invalid lifetime: {e}")))?;
                Some(lt)
            }
        };
        self.inner
            .emit_event(&event_id, lt, payload)
            .map_err(|e| Error::from_reason(format!("emit_event: {e}")))
    }

    #[napi]
    pub fn clear_event(&self, event_id: String) -> Result<()> {
        self.inner
            .clear_event(&event_id)
            .map_err(|e| Error::from_reason(format!("clear_event: {e}")))
    }

    #[napi]
    pub fn emit_incident(&self, name: String, payload: Option<Value>) -> Result<()> {
        self.inner
            .emit_incident(&name, payload)
            .map_err(|e| Error::from_reason(format!("emit_incident: {e}")))
    }

    #[napi]
    pub fn complete_pending_resolution(
        &self,
        request_id: String,
        decision: String,
        value: Option<Value>,
        set_variables: Option<Value>,
        reason: Option<String>,
    ) -> Result<Value> {
        let decision = match decision.as_str() {
            "allow" => ResolverDecision::Allow,
            "deny" => ResolverDecision::Deny,
            "cancelled" => ResolverDecision::Cancelled,
            other => {
                return Err(Error::from_reason(format!(
                    "invalid decision {other:?}; expected 'allow', 'deny', or 'cancelled'"
                )))
            }
        };
        let set_variables = match set_variables {
            None | Some(Value::Null) => HashMap::new(),
            Some(Value::Object(m)) => m.into_iter().collect(),
            Some(_) => return Err(Error::from_reason("setVariables must be an object")),
        };
        let resp = ResolverResponse {
            decision,
            value,
            set_variables,
            reason,
        };
        let out = self
            .inner
            .complete_pending_resolution(&request_id, resp)
            .map_err(|e| Error::from_reason(format!("complete_pending_resolution: {e}")))?;
        Ok(serde_json::json!({
            "decision": match out.decision {
                ResolverDecision::Allow => "allow",
                ResolverDecision::Deny => "deny",
                ResolverDecision::Cancelled => "cancelled",
            },
            "value": out.value.unwrap_or(Value::Null),
            "set_variables": out.set_variables,
            "reason": out.reason,
        }))
    }

    // ── Boundary ops ────────────────────────────────────────────────

    #[napi]
    pub fn begin_turn(&self) -> Result<u32> {
        self.inner
            .begin_turn()
            .map(|n| n as u32)
            .map_err(|e| Error::from_reason(format!("begin_turn: {e}")))
    }

    #[napi]
    pub fn end_turn(&self) -> Result<()> {
        self.inner
            .end_turn()
            .map_err(|e| Error::from_reason(format!("end_turn: {e}")))
    }

    #[napi]
    pub fn begin_request(&self) -> Result<u32> {
        self.inner
            .begin_request()
            .map(|n| n as u32)
            .map_err(|e| Error::from_reason(format!("begin_request: {e}")))
    }

    #[napi]
    pub fn end_request(&self) -> Result<()> {
        self.inner
            .end_request()
            .map_err(|e| Error::from_reason(format!("end_request: {e}")))
    }

    #[napi]
    pub fn close(&self) {
        self.inner.close();
    }

    /// Latest turn id (or 0 before the first `begin_turn`).
    #[napi(getter)]
    pub fn current_turn_id(&self) -> u32 {
        self.inner.current_turn_id() as u32
    }

    /// Latest request id (or 0 before the first `begin_request`).
    #[napi(getter)]
    pub fn current_request_id(&self) -> u32 {
        self.inner.current_request_id() as u32
    }

    // ── Stage validation ────────────────────────────────────────────

    /// Stage 1 — input validation. Returns the StageVerdict.
    #[napi]
    pub async fn validate_input(&self, input: String) -> Result<Value> {
        let inner = self.inner.clone();
        let verdict = tokio::task::spawn_blocking(move || inner.validate_input(&input))
            .await
            .map_err(|e| Error::from_reason(format!("validate_input: join: {e}")))?;
        Ok(stage_verdict_to_json(&verdict))
    }

    /// Stage 3 — tool execution validation. `toolCallId` is
    /// required and MUST be paired with the same id
    /// passed to the matching Stage 4 `validateToolOutput`. Hosts with
    /// parallel/repeated same-name tool calls MUST pass a distinct id
    /// per call. Returns `{ verdict, params }` where `params` is the
    /// (possibly mutated) parameter shape after Stage 3 transforms.
    #[napi]
    pub async fn validate_tool_call(
        &self,
        tool: String,
        params: Value,
        tool_call_id: Option<String>,
    ) -> Result<Value> {
        let inner = self.inner.clone();
        let (verdict, admission, params): (
            agent_shield_core::StageVerdict,
            Option<agent_shield_core::AdmissionHandle>,
            Value,
        ) = tokio::task::spawn_blocking(move || {
            let mut p = params;
            let (v, h) = inner.validate_tool_call(&tool, &mut p, tool_call_id.as_deref());
            (v, h, p)
        })
        .await
        .map_err(|e| Error::from_reason(format!("validate_tool_call: join: {e}")))?;
        Ok(stage_verdict_with_params(&verdict, &params, admission))
    }

    /// Stage 3 — endpoint variant. `toolCallId` is REQUIRED for API
    /// symmetry but currently unused (no Stage 4 for endpoint).
    /// Returns `{ verdict, body }`.
    #[napi]
    pub async fn validate_endpoint_call(
        &self,
        method: String,
        uri: String,
        body: Value,
        tool_call_id: String,
    ) -> Result<Value> {
        let inner = self.inner.clone();
        let (verdict, body): (agent_shield_core::StageVerdict, Value) =
            tokio::task::spawn_blocking(move || {
                let mut b = body;
                let v = inner.validate_endpoint_call(
                    &method,
                    &uri,
                    &mut b,
                    Some(tool_call_id.as_str()),
                );
                (v, b)
            })
            .await
            .map_err(|e| Error::from_reason(format!("validate_endpoint_call: join: {e}")))?;
        let mut m = Map::new();
        m.insert("verdict".into(), stage_verdict_to_json(&verdict));
        m.insert("body".into(), body);
        Ok(Value::Object(m))
    }

    /// Stage 3 — agent variant. `toolCallId` is REQUIRED for API
    /// symmetry but currently unused (no Stage 4 for agent). Returns
    /// `{ verdict, params }`.
    #[napi]
    pub async fn validate_agent_call(
        &self,
        agent: String,
        params: Value,
        tool_call_id: String,
    ) -> Result<Value> {
        let inner = self.inner.clone();
        let (verdict, params): (agent_shield_core::StageVerdict, Value) =
            tokio::task::spawn_blocking(move || {
                let mut p = params;
                let v = inner.validate_agent_call(&agent, &mut p, Some(tool_call_id.as_str()));
                (v, p)
            })
            .await
            .map_err(|e| Error::from_reason(format!("validate_agent_call: join: {e}")))?;
        Ok(stage_verdict_with_params(&verdict, &params, None))
    }

    /// Stage 4 — post-tool validation. `toolCallId` MUST match
    /// the id passed to the paired Stage 3 `validateToolCall`. A
    /// non-matching or missing entry fails closed with a `<binding>`
    /// policy verdict. Returns `{ verdict, result }`.
    #[napi]
    pub async fn validate_tool_output(&self, admission_id: String, result: Value) -> Result<Value> {
        let inner = self.inner.clone();
        let (verdict, result): (agent_shield_core::StageVerdict, Value) =
            tokio::task::spawn_blocking(
                move || -> Result<(agent_shield_core::StageVerdict, Value)> {
                    let mut r = result;
                    let id = admission_id
                        .parse::<u64>()
                        .map_err(|_| Error::from_reason("admissionId must be a non-zero u64"))?;
                    let handle = agent_shield_core::AdmissionHandle::from_ffi_u64(id)
                        .ok_or_else(|| Error::from_reason("admissionId must be non-zero"))?;
                    let v = inner.validate_tool_output(handle, &mut r);
                    Ok((v, r))
                },
            )
            .await
            .map_err(|e| Error::from_reason(format!("validate_tool_output: join: {e}")))??;
        let mut m = Map::new();
        m.insert("verdict".into(), stage_verdict_to_json(&verdict));
        m.insert("result".into(), result);
        Ok(Value::Object(m))
    }

    #[napi]
    pub fn evict_admission(&self, admission_id: String) -> Result<()> {
        let id = admission_id
            .parse::<u64>()
            .map_err(|_| Error::from_reason("admissionId must be a non-zero u64"))?;
        let handle = agent_shield_core::AdmissionHandle::from_ffi_u64(id)
            .ok_or_else(|| Error::from_reason("admissionId must be non-zero"))?;
        self.inner.evict_admission(handle);
        Ok(())
    }

    /// Stage 5 — output validation. Returns `{ verdict, response }`.
    #[napi]
    pub async fn validate_output(&self, response: String) -> Result<Value> {
        let inner = self.inner.clone();
        let (verdict, response) = tokio::task::spawn_blocking(move || {
            let mut r = response;
            let v = inner.validate_output(&mut r);
            (v, r)
        })
        .await
        .map_err(|e| Error::from_reason(format!("validate_output: join: {e}")))?;
        Ok(stage_verdict_with_response(&verdict, &response))
    }

    // ── Resource cycle helpers ──────────────────────────────────────

    #[napi]
    pub fn record_tool_success(&self, tool: String, result: Value) -> Result<()> {
        self.inner
            .record_tool_success(&tool, &result)
            .map_err(|e| Error::from_reason(format!("record_tool_success: {e}")))
    }

    #[napi]
    pub fn record_tool_failure(&self, tool: String, error: String) -> Result<()> {
        self.inner
            .record_tool_failure(&tool, &error)
            .map_err(|e| Error::from_reason(format!("record_tool_failure: {e}")))
    }

    #[napi]
    pub fn record_endpoint_success(
        &self,
        method: String,
        pattern: String,
        result: Value,
    ) -> Result<()> {
        self.inner
            .record_endpoint_success(&method, &pattern, &result)
            .map_err(|e| Error::from_reason(format!("record_endpoint_success: {e}")))
    }

    #[napi]
    pub fn record_endpoint_failure(
        &self,
        method: String,
        pattern: String,
        error: String,
    ) -> Result<()> {
        self.inner
            .record_endpoint_failure(&method, &pattern, &error)
            .map_err(|e| Error::from_reason(format!("record_endpoint_failure: {e}")))
    }

    #[napi]
    pub fn record_agent_success(&self, agent: String, result: Value) -> Result<()> {
        self.inner
            .record_agent_success(&agent, &result)
            .map_err(|e| Error::from_reason(format!("record_agent_success: {e}")))
    }

    #[napi]
    pub fn record_agent_failure(&self, agent: String, error: String) -> Result<()> {
        self.inner
            .record_agent_failure(&agent, &error)
            .map_err(|e| Error::from_reason(format!("record_agent_failure: {e}")))
    }

    // ── Streaming ───────────────────────────────────────────────────

    /// Construct a streaming guard for Stage 4 (`stage == 4`) or Stage 5
    /// (`stage == 5`).
    #[napi]
    pub fn streaming_session(&self, stage: u8) -> Result<StreamingGuard> {
        let stage = match stage {
            4 => ObsStage::PostTool,
            5 => ObsStage::Output,
            other => {
                return Err(Error::from_reason(format!(
                    "streaming_session: stage must be 4 or 5, got {other}"
                )))
            }
        };
        let guard = self.inner.streaming_session(stage);
        Ok(StreamingGuard {
            inner: Arc::new(StdMutex::new(Some(guard))),
        })
    }
}

// ─── Streaming guard ────────────────────────────────────────────────
//
// The Rust struct name matches the desired JavaScript class name on
// purpose: napi-rs registers wrapper classes under their Rust name
// (the `js_name` attribute is honoured by the codegen for `native.js`
// /`native.d.ts` but the compiled binding registers the Rust ident).
// Keeping the names in sync avoids the `Js*` artefacts leaking into
// the public JS surface.

#[napi]
pub struct StreamingGuard {
    inner: Arc<StdMutex<Option<CoreStreamingGuard>>>,
}

fn stream_chunk_to_json(r: &StreamChunkResult) -> Value {
    let action = match r.action {
        StreamChunkAction::Pass => "pass",
        StreamChunkAction::Replace => "replace",
        StreamChunkAction::Stop => "stop",
    };
    let mut m = Map::new();
    m.insert("action".into(), Value::String(action.to_string()));
    m.insert("payload".into(), Value::String(r.payload.clone()));
    m.insert(
        "reason".into(),
        r.reason
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    Value::Object(m)
}

#[napi]
impl StreamingGuard {
    /// Submit a chunk. Returns `{ action, payload, reason }`.
    #[napi]
    pub async fn add_chunk(&self, chunk: String) -> Result<Value> {
        let guard = self.inner.clone();
        let result = tokio::task::spawn_blocking(move || {
            let mut g = guard.lock().unwrap();
            let inner = g
                .as_mut()
                .ok_or_else(|| "stream already finished".to_string())?;
            Ok::<StreamChunkResult, String>(inner.add_chunk(&chunk))
        })
        .await
        .map_err(|e| Error::from_reason(format!("add_chunk: join: {e}")))?
        .map_err(|e| Error::from_reason(format!("add_chunk: {e}")))?;
        Ok(stream_chunk_to_json(&result))
    }

    /// End the stream. Returns the final `StreamChunkResult`.
    ///
    /// Atomicity: the guard slot is cleared inside the same critical
    /// section as `end_stream()` so concurrent `add_chunk`/`finish`
    /// calls observe an "already finished" error instead of racing
    /// against a half-ended stream.
    #[napi]
    pub async fn finish(&self) -> Result<Value> {
        let guard = self.inner.clone();
        let result = tokio::task::spawn_blocking(move || {
            let mut g = guard.lock().unwrap();
            let inner = g
                .as_mut()
                .ok_or_else(|| "stream already finished".to_string())?;
            let res = inner.end_stream();
            *g = None;
            Ok::<StreamChunkResult, String>(res)
        })
        .await
        .map_err(|e| Error::from_reason(format!("finish: join: {e}")))?
        .map_err(|e| Error::from_reason(format!("finish: {e}")))?;
        Ok(stream_chunk_to_json(&result))
    }

    /// The streaming guard's configured validation cadence:
    /// `'on_complete'` / `'windowed'` / `'per_chunk'`.
    ///
    /// SDK adapters use this to decide whether to forward upstream
    /// chunks to the customer in real time (`per_chunk` / `windowed`)
    /// or to buffer every chunk and emit only the final validated
    /// payload at `finish()` (`on_complete`). Pure read accessor; safe
    /// to call after `finish()` (returns the trigger at construction
    /// time).
    #[napi(getter)]
    pub fn mode(&self) -> String {
        let g = self.inner.lock().unwrap();
        let trig = g
            .as_ref()
            .map(|g| g.mode())
            .unwrap_or(StreamingTrigger::OnComplete);
        match trig {
            StreamingTrigger::OnComplete => "on_complete".into(),
            StreamingTrigger::Windowed => "windowed".into(),
            StreamingTrigger::PerChunk => "per_chunk".into(),
        }
    }
}

// ─── GuardrailsConfig / CompiledPolicy ──────────────────────────────
//
// Thin napi-rs wrappers around `GuardrailsConfig` and `CompiledPolicy`
// from `agent_shield_core::config`. The Node facade in
// `sdk/node/config.js` collapses to a thin handle wrapper around
// these. `GuardrailsConfig` is immutable-by-convention: every fluent
// method clones the inner builder and returns a new instance, so
// napi-rs `&self` callers compose without aliasing or surprise
// mutation.
//
// The Rust struct names match the desired JavaScript class names on
// purpose (`StreamingGuard` / `CompiledPolicy` / `GuardrailsConfig`)
// so napi-rs registers them under the right ident even when other
// `#[napi]` factories reference them via `&Type` parameters.

#[napi]
pub struct GuardrailsConfig {
    inner: CoreGuardrailsConfig,
}

#[napi]
impl GuardrailsConfig {
    /// Start a chain from a single YAML file on disk.
    #[napi(factory)]
    pub fn load(path: String) -> Result<Self> {
        Ok(Self {
            inner: CoreGuardrailsConfig::load(path),
        })
    }

    /// Start a chain from a raw YAML string.
    #[napi(factory, js_name = "fromString")]
    pub fn from_string(yaml: String) -> Result<Self> {
        Ok(Self {
            inner: CoreGuardrailsConfig::from_string(yaml),
        })
    }

    /// Start a chain from a typed value (serialised to YAML at compile
    /// time).
    #[napi(factory, js_name = "fromValue")]
    pub fn from_value(value: Value) -> Result<Self> {
        Ok(Self {
            inner: CoreGuardrailsConfig::from_value(value),
        })
    }

    /// Append another configuration's layers to this chain. Leaf-wins.
    #[napi]
    pub fn extend(&self, other: &GuardrailsConfig) -> Result<GuardrailsConfig> {
        Ok(GuardrailsConfig {
            inner: self.inner.clone().extend(other.inner.clone()),
        })
    }

    /// Append a single path layer.
    #[napi(js_name = "extendPath")]
    pub fn extend_path(&self, path: String) -> Result<GuardrailsConfig> {
        Ok(GuardrailsConfig {
            inner: self.inner.clone().extend_path(path),
        })
    }

    /// Append a single YAML-string layer.
    #[napi(js_name = "extendString")]
    pub fn extend_string(&self, yaml: String) -> Result<GuardrailsConfig> {
        Ok(GuardrailsConfig {
            inner: self.inner.clone().extend_string(yaml),
        })
    }

    /// Append a final value-shaped layer that overrides earlier values.
    #[napi(js_name = "withOverrides")]
    pub fn with_overrides(&self, overrides: Value) -> Result<GuardrailsConfig> {
        Ok(GuardrailsConfig {
            inner: self.inner.clone().with_overrides(overrides),
        })
    }

    /// Append a "policy pack" layer. `pack` may be a string (path to a
    /// YAML file) or an object (typed value layer).
    #[napi(js_name = "withPolicyPack")]
    pub fn with_policy_pack(&self, pack: Value) -> Result<GuardrailsConfig> {
        let layer = match pack {
            Value::String(s) => Layer::Path(std::path::PathBuf::from(s)),
            other => Layer::Object(other),
        };
        Ok(GuardrailsConfig {
            inner: self.inner.clone().with_policy_pack(layer),
        })
    }

    /// Materialise the chain into a [`CompiledPolicy`].
    #[napi]
    pub fn compile(&self) -> Result<CompiledPolicy> {
        let compiled = self
            .inner
            .compile()
            .map_err(|e| Error::from_reason(format!("{e}")))?;
        Ok(CompiledPolicy {
            inner: Arc::new(compiled),
        })
    }

    /// Compute the canonical SHA-256 digest of the chain *without*
    /// validating it. This is the introspection-only twin of
    /// [`compile`](Self::compile): callers can fingerprint a chain
    /// (cache key, log line) without paying the full validation cost
    /// or rejecting partial overlays. The digest is byte-stable with
    /// the digest produced by [`compile`](Self::compile) for the same
    /// content.
    #[napi(getter)]
    pub fn digest(&self) -> Result<String> {
        self.inner
            .digest()
            .map_err(|e| Error::from_reason(format!("{e}")))
    }

    /// Number of layers in the chain.
    #[napi]
    pub fn len(&self) -> u32 {
        self.inner.len() as u32
    }

    /// Whether the chain has no layers.
    #[napi(js_name = "isEmpty")]
    pub fn is_empty(&self) -> bool {
        self.inner.is_empty()
    }
}

#[napi]
pub struct CompiledPolicy {
    inner: Arc<CoreCompiledPolicy>,
}

#[napi]
impl CompiledPolicy {
    /// SHA-256 (lowercase hex) of the canonical JSON encoding of the
    /// merged configuration. Byte-stable across SDKs for the same
    /// content.
    #[napi(getter)]
    pub fn digest(&self) -> String {
        self.inner.digest().to_string()
    }
}

// ─── Module-level helpers (versioning) ──────────────────────────────

#[napi(js_name = "version")]
pub fn version() -> String {
    agent_shield_core::RUNTIME_SPEC_VERSION.to_string()
}

/// Effective runtime mode (#14) as a wire string.
///
/// Exposed as a module-level function so the JS `Runtime.mode()`
/// wrapper can read the underlying core's effective mode without
/// expanding the napi class surface.
#[napi(js_name = "runtimeMode")]
pub fn runtime_mode(runtime: &GuardrailsRuntime) -> String {
    runtime.inner.mode().as_wire_str().to_string()
}

/// Parse a lifetime value (string for the bare keyword form, object
/// for the map / `for:` / `until_event:` forms) and return the
/// canonical representation as a JS value (string or object).
///
/// Routes through `agent_shield_core::lifetime::parse_lifetime`, the
/// single canonical lifetime parser shared by every language SDK.
#[napi(js_name = "parseLifetime")]
pub fn parse_lifetime(value: Value) -> napi::Result<Value> {
    let lt = agent_shield_core::lifetime::parse_lifetime(value)
        .map_err(|e| napi::Error::from_reason(format!("invalid lifetime: {e}")))?;
    serde_json::to_value(&lt)
        .map_err(|e| napi::Error::from_reason(format!("serialize lifetime: {e}")))
}

// ─── Canonical verdict-handling decision (Stage 1/5 + tools) ────────

fn parse_policy_str(s: &str) -> napi::Result<agent_shield_core::OnBlockPolicy> {
    agent_shield_core::OnBlockPolicy::from_wire_str(s)
        .ok_or_else(|| napi::Error::from_reason(format!("unknown on_block policy: {s:?}")))
}

fn parse_mode_str(s: &str) -> napi::Result<agent_shield_core::ShieldMode> {
    agent_shield_core::ShieldMode::from_wire_str(s)
        .ok_or_else(|| napi::Error::from_reason(format!("unknown shield mode: {s:?}")))
}

fn verdict_value_to_core(value: &Value) -> napi::Result<agent_shield_core::StageVerdict> {
    agent_shield_core::stage_verdict_from_wire(value)
        .ok_or_else(|| napi::Error::from_reason("malformed StageVerdict wire shape"))
}

/// Canonical Stage 1 / Stage 5 verdict-handling decision.
///
/// Returns an object: `{action: {kind, value?, message?}, recordBlock,
/// overrideToProceed}`. Note the camelCased keys at the JS boundary —
/// the underlying core uses snake_case but napi auto-camelCases for
/// the JS surface.
///
/// `opts` is `{policy?, mode?}` — both strings, both optional.
#[napi(js_name = "dispatchStageVerdict")]
pub fn napi_dispatch_stage_verdict(verdict: Value, opts: Option<Value>) -> napi::Result<Value> {
    let opts_map = opts
        .as_ref()
        .and_then(|v| v.as_object())
        .cloned()
        .unwrap_or_default();
    let policy = opts_map
        .get("policy")
        .and_then(|v| v.as_str())
        .unwrap_or("return_blocked");
    let mode = opts_map
        .get("mode")
        .and_then(|v| v.as_str())
        .unwrap_or("enforce");
    let v = verdict_value_to_core(&verdict)?;
    let p = parse_policy_str(policy)?;
    let m = parse_mode_str(mode)?;
    let outcome = agent_shield_core::dispatch_stage_verdict(&v, p, m);
    Ok(agent_shield_core::dispatch_outcome_to_wire(&outcome))
}

/// Canonical Stage 2/3/4 (tool-call) verdict-handling decision.
///
/// `stage` is `'call'` (Stage 2/3, pre-execute) or `'output'` (Stage 4,
/// post-execute). Returns `{action, recordFailure, recordSuccess,
/// overrideToProceed}`.
///
/// `opts` is an options object: `{stage?, policy?, mode?}` — all
/// strings, all optional.
#[napi(js_name = "dispatchToolVerdict")]
pub fn napi_dispatch_tool_verdict(
    verdict: Value,
    tool_name: String,
    opts: Option<Value>,
) -> napi::Result<Value> {
    let opts_map = opts
        .as_ref()
        .and_then(|v| v.as_object())
        .cloned()
        .unwrap_or_default();
    let stage = opts_map
        .get("stage")
        .and_then(|v| v.as_str())
        .unwrap_or("output");
    let policy = opts_map
        .get("policy")
        .and_then(|v| v.as_str())
        .unwrap_or("return_blocked");
    let mode = opts_map
        .get("mode")
        .and_then(|v| v.as_str())
        .unwrap_or("enforce");
    let v = verdict_value_to_core(&verdict)?;
    let p = parse_policy_str(policy)?;
    let m = parse_mode_str(mode)?;
    let s = match stage {
        "call" | "Call" | "stage23" | "stage_23" => agent_shield_core::ToolStage::Call,
        "output" | "Output" | "stage4" | "stage_4" => agent_shield_core::ToolStage::Output,
        other => {
            return Err(napi::Error::from_reason(format!(
                "unknown tool stage: {other:?}; expected 'call' or 'output'"
            )))
        }
    };
    let outcome = agent_shield_core::dispatch_tool_verdict(&v, &tool_name, s, p, m);
    Ok(agent_shield_core::tool_dispatch_outcome_to_wire(&outcome))
}

/// Format a verdict as the canonical `[GUARDRAIL ACTION] reason`
/// string. Hands off to `agent_shield_core::format_block_message` so
/// every SDK produces byte-equivalent strings.
#[napi(js_name = "formatBlockMessage")]
pub fn napi_format_block_message(verdict: Value) -> napi::Result<String> {
    let v = verdict_value_to_core(&verdict)?;
    Ok(agent_shield_core::format_block_message(&v))
}

/// Apply the telemetry-redaction pass.
///
/// `event` is a `ShieldLogEvent` JSON object. `policy` is an optional
/// `TelemetryPolicy` JSON object; when omitted, the fail-closed default
/// applies. Returns the redacted event JSON. Hands off to
/// `agent_shield_core::observability::redact_event` so every SDK
/// produces byte-equivalent output.
#[napi(js_name = "redactLogEvent")]
pub fn napi_redact_log_event(event: Value, policy: Option<Value>) -> napi::Result<Value> {
    use agent_shield_core::observability::{redact_event, ShieldLogEvent, TelemetryPolicy};
    let mut ev: ShieldLogEvent = serde_json::from_value(event)
        .map_err(|e| napi::Error::from_reason(format!("invalid ShieldLogEvent: {e}")))?;
    let pol = match policy {
        Some(p) => TelemetryPolicy::from_json_value(&p)
            .map_err(|e| napi::Error::from_reason(format!("invalid TelemetryPolicy: {e}")))?,
        None => TelemetryPolicy::fail_closed(),
    };
    redact_event(&mut ev, &pol);
    serde_json::to_value(&ev)
        .map_err(|e| napi::Error::from_reason(format!("serialize redacted event: {e}")))
}

// ─── Hook integration runtime ──────────────────────────────────────
//
// napi-rs surface over `agent_shield_core::integrations::hooks`:
// `HookSessionRegistry`, `HookSession`, `StageDispatcher`. Async
// serialisation of concurrent callbacks for the same session id is
// the integration's responsibility; Node's single-threaded event
// loop is sufficient for most hosts. Wire shapes match the pyo3
// surface so cross-language consumers see identical JSON.

use agent_shield_core::integrations::hooks::{
    ConcurrencyError as CoreConcurrencyError, RegistryOptions as CoreRegistryOptions,
    RequestStateError as CoreRequestStateError, RequestToken as CoreRequestToken,
    SessionLease as CoreSessionLease, SessionRegistry as CoreSessionRegistry,
    StageDispatcher as CoreStageDispatcher,
};
use agent_shield_core::shield_primitives::{
    dispatch_outcome_to_wire as core_dispatch_outcome_to_wire, tool_dispatch_outcome_to_wire,
    OnBlockPolicy as CoreOnBlockPolicy, ShieldMode as CoreShieldMode,
};

fn parse_mode(s: &str) -> napi::Result<CoreShieldMode> {
    CoreShieldMode::from_wire_str(s).ok_or_else(|| {
        napi::Error::from_reason(format!(
            "unknown ShieldMode: {s:?} (expected \"enforce\" or \"monitor\")"
        ))
    })
}

fn parse_policy(s: &str) -> napi::Result<CoreOnBlockPolicy> {
    CoreOnBlockPolicy::from_wire_str(s).ok_or_else(|| {
        napi::Error::from_reason(format!(
            "unknown OnBlockPolicy: {s:?} (expected \"return_blocked\", \"return_verdict\", \"raise\", or \"custom\")"
        ))
    })
}

#[napi(js_name = "HookSessionRegistry")]
pub struct HookSessionRegistry {
    inner: CoreSessionRegistry,
    in_flight_timeout: std::time::Duration,
}

#[napi]
impl HookSessionRegistry {
    /// Construct a registry around an existing `GuardrailsRuntime`.
    /// Options are object-shaped: `{ maxSize?, ttlSeconds?,
    /// inFlightTimeoutSeconds? }`. All optional with the same
    /// defaults as the pyo3 surface (512, 1800, 300).
    #[napi(constructor)]
    pub fn new(runtime: &GuardrailsRuntime, options: Option<Value>) -> napi::Result<Self> {
        let mut max_size = 512usize;
        let mut ttl_seconds = 1800u64;
        let mut in_flight_seconds = 300u64;
        if let Some(Value::Object(obj)) = options {
            if let Some(v) = obj.get("maxSize").and_then(|v| v.as_u64()) {
                max_size = v as usize;
            }
            if let Some(v) = obj.get("ttlSeconds").and_then(|v| v.as_u64()) {
                ttl_seconds = v;
            }
            if let Some(v) = obj.get("inFlightTimeoutSeconds").and_then(|v| v.as_u64()) {
                in_flight_seconds = v;
            }
        }
        let in_flight_timeout = std::time::Duration::from_secs(in_flight_seconds);
        let opts = CoreRegistryOptions {
            max_size,
            ttl: std::time::Duration::from_secs(ttl_seconds),
            in_flight_timeout,
        };
        Ok(Self {
            inner: CoreSessionRegistry::new(runtime.inner.clone(), opts),
            in_flight_timeout,
        })
    }

    /// Acquire a lease on the session keyed by `sessionId`. Returns a
    /// `HookSession` instance that decrements the lease counter on
    /// `release()`. Integrations MUST call `release()` (typically in
    /// a `try / finally`) so eviction can reclaim the entry.
    #[napi]
    pub fn acquire(
        &self,
        session_id: String,
        request_context: Option<Value>,
    ) -> napi::Result<HookSession> {
        let ctx = parse_request_context(request_context);
        let lease = self
            .inner
            .acquire(&session_id, ctx)
            .map_err(|e| napi::Error::from_reason(e.to_string()))?;
        Ok(HookSession {
            inner: StdMutex::new(Some(lease)),
            in_flight_timeout: self.in_flight_timeout,
        })
    }

    #[napi(js_name = "len")]
    pub fn js_len(&self) -> u32 {
        self.inner.len() as u32
    }
}

#[napi(js_name = "HookSession")]
pub struct HookSession {
    inner: StdMutex<Option<CoreSessionLease>>,
    in_flight_timeout: std::time::Duration,
}

impl HookSession {
    fn with_lease<F, R>(&self, f: F) -> napi::Result<R>
    where
        F: FnOnce(&CoreSessionLease) -> napi::Result<R>,
    {
        let guard = self
            .inner
            .lock()
            .map_err(|_| napi::Error::from_reason("HookSession mutex poisoned".to_string()))?;
        match guard.as_ref() {
            Some(lease) => f(lease),
            None => Err(napi::Error::from_reason(
                "HookSession has been released; acquire a fresh lease".to_string(),
            )),
        }
    }
}

#[napi]
impl HookSession {
    #[napi]
    pub fn begin_turn(&self) -> napi::Result<()> {
        self.with_lease(|l| {
            l.begin_turn()
                .map_err(|e| napi::Error::from_reason(e.to_string()))
        })
    }

    #[napi]
    pub fn restart_turn(&self) -> napi::Result<()> {
        self.with_lease(|l| {
            l.restart_turn()
                .map_err(|e| napi::Error::from_reason(e.to_string()))
        })
    }

    #[napi]
    pub fn end_turn(&self) -> napi::Result<()> {
        self.with_lease(|l| {
            l.end_turn()
                .map_err(|e| napi::Error::from_reason(e.to_string()))
        })
    }

    #[napi]
    pub fn turn_is_open(&self) -> napi::Result<bool> {
        self.with_lease(|l| Ok(l.turn_is_open()))
    }

    /// Begin a request scope. Returns a numeric token the caller
    /// MUST present to `endRequest` when the logical request
    /// completes. JS `number` is precise up to 2^53; the underlying
    /// counter is u64 but per-session lifetime makes overflow
    /// practically unreachable.
    #[napi]
    pub fn begin_request(&self) -> napi::Result<f64> {
        self.with_lease(|l| {
            l.begin_request(Some(self.in_flight_timeout))
                .map(|t| t.0 as f64)
                .map_err(|e| match e {
                    CoreConcurrencyError::AlreadyInFlight { age } => {
                        napi::Error::from_reason(format!(
                            "another request is in flight for this session (age={:?})",
                            age
                        ))
                    }
                    CoreConcurrencyError::SessionError(msg) => napi::Error::from_reason(msg),
                })
        })
    }

    /// Retire a request token. Returns "ok" | "mismatch" |
    /// "no_request_open" rather than throwing — the failure-hook
    /// double-call path relies on no_request_open being safe.
    #[napi]
    pub fn end_request(&self, token: f64) -> napi::Result<String> {
        let tok = CoreRequestToken(token as u64);
        self.with_lease(|l| {
            Ok(match l.end_request(tok) {
                Ok(()) => "ok".to_string(),
                Err(CoreRequestStateError::Mismatch) => "mismatch".to_string(),
                Err(CoreRequestStateError::NoRequestOpen) => "no_request_open".to_string(),
            })
        })
    }

    /// Retire whatever request is currently open without needing the
    /// token. Convenience for hosts that don't want to plumb the
    /// token across hook callbacks.
    #[napi]
    pub fn end_current_request(&self) -> napi::Result<String> {
        self.with_lease(|l| {
            Ok(match l.end_current_request() {
                Ok(()) => "ok".to_string(),
                Err(CoreRequestStateError::NoRequestOpen) => "no_request_open".to_string(),
                Err(CoreRequestStateError::Mismatch) => "mismatch".to_string(),
            })
        })
    }

    #[napi]
    pub fn request_is_open(&self) -> napi::Result<bool> {
        self.with_lease(|l| Ok(l.request_is_open()))
    }

    #[napi]
    pub fn turn_kv_set(&self, key: String, value: Value) -> napi::Result<Value> {
        self.with_lease(|l| Ok(l.turn_kv_set(&key, value).unwrap_or(Value::Null)))
    }

    #[napi]
    pub fn turn_kv_get(&self, key: String) -> napi::Result<Value> {
        self.with_lease(|l| Ok(l.turn_kv_get(&key).unwrap_or(Value::Null)))
    }

    #[napi]
    pub fn turn_kv_remove(&self, key: String) -> napi::Result<Value> {
        self.with_lease(|l| Ok(l.turn_kv_remove(&key).unwrap_or(Value::Null)))
    }

    #[napi]
    pub fn turn_kv_keys(&self) -> napi::Result<Vec<String>> {
        self.with_lease(|l| Ok(l.turn_kv_keys()))
    }

    #[napi]
    pub fn record_tool_success(&self, tool_name: String, result: Value) -> napi::Result<()> {
        self.with_lease(|l| {
            l.record_tool_success(&tool_name, &result)
                .map_err(|e| napi::Error::from_reason(e.to_string()))
        })
    }

    #[napi]
    pub fn record_tool_failure(&self, tool_name: String, error: String) -> napi::Result<()> {
        self.with_lease(|l| {
            l.record_tool_failure(&tool_name, &error)
                .map_err(|e| napi::Error::from_reason(e.to_string()))
        })
    }

    /// Drop the lease. Idempotent — safe to call multiple times.
    #[napi]
    pub fn release(&self) {
        if let Ok(mut g) = self.inner.lock() {
            let _ = g.take();
        }
    }
}

#[napi(js_name = "StageDispatcher")]
pub struct StageDispatcher {
    inner: CoreStageDispatcher,
}

#[napi]
impl StageDispatcher {
    #[napi(constructor)]
    #[allow(clippy::new_without_default)]
    pub fn new() -> Self {
        Self {
            inner: CoreStageDispatcher,
        }
    }

    /// Stage 1.
    #[napi]
    pub fn validate_input(
        &self,
        session: &HookSession,
        user_input: String,
        mode: Option<String>,
        policy: Option<String>,
    ) -> napi::Result<Value> {
        let m = parse_mode(mode.as_deref().unwrap_or("enforce"))?;
        let p = parse_policy(policy.as_deref().unwrap_or("return_blocked"))?;
        let result = session.with_lease(|lease| {
            Ok(self
                .inner
                .validate_input(lease.session(), &user_input, m, p))
        })?;
        let mut out = Map::new();
        out.insert(
            "dispatch".into(),
            core_dispatch_outcome_to_wire(&result.dispatch),
        );
        Ok(Value::Object(out))
    }

    /// Stages 2 + 3.
    #[napi]
    pub fn validate_tool_call(
        &self,
        session: &HookSession,
        tool_name: String,
        params: Value,
        tool_call_id: String,
        mode: Option<String>,
        policy: Option<String>,
    ) -> napi::Result<Value> {
        let m = parse_mode(mode.as_deref().unwrap_or("enforce"))?;
        let p = parse_policy(policy.as_deref().unwrap_or("return_blocked"))?;
        let result = session.with_lease(|lease| {
            Ok(self.inner.validate_tool_call(
                lease.session(),
                &tool_name,
                params,
                &tool_call_id,
                m,
                p,
            ))
        })?;
        let mut out = Map::new();
        out.insert(
            "dispatch".into(),
            tool_dispatch_outcome_to_wire(&result.dispatch),
        );
        if let Some(handle) = result.admission {
            out.insert("admissionId".into(), Value::String(handle.id().to_string()));
        }
        out.insert("effective_params".into(), result.effective_params);
        Ok(Value::Object(out))
    }

    /// Stage 4.
    #[napi]
    pub fn validate_tool_output(
        &self,
        session: &HookSession,
        tool_name: String,
        output: Value,
        admission_id: String,
        mode: Option<String>,
        policy: Option<String>,
    ) -> napi::Result<Value> {
        let m = parse_mode(mode.as_deref().unwrap_or("enforce"))?;
        let p = parse_policy(policy.as_deref().unwrap_or("return_blocked"))?;
        let result = session.with_lease(|lease| {
            Ok(self.inner.validate_tool_output(
                lease.session(),
                &tool_name,
                output,
                agent_shield_core::AdmissionHandle::from_ffi_u64(
                    admission_id
                        .parse::<u64>()
                        .map_err(|_| Error::from_reason("admissionId must be a non-zero u64"))?,
                )
                .ok_or_else(|| Error::from_reason("admissionId must be non-zero"))?,
                m,
                p,
            ))
        })?;
        let mut out = Map::new();
        out.insert(
            "dispatch".into(),
            tool_dispatch_outcome_to_wire(&result.dispatch),
        );
        out.insert("effective_output".into(), result.effective_output);
        Ok(Value::Object(out))
    }

    /// Stage 5.
    #[napi]
    pub fn validate_output(
        &self,
        session: &HookSession,
        content: String,
        mode: Option<String>,
        policy: Option<String>,
    ) -> napi::Result<Value> {
        let m = parse_mode(mode.as_deref().unwrap_or("enforce"))?;
        let p = parse_policy(policy.as_deref().unwrap_or("return_blocked"))?;
        let mut buf = content;
        let result = session
            .with_lease(|lease| Ok(self.inner.validate_output(lease.session(), &mut buf, m, p)))?;
        let mut out = Map::new();
        out.insert(
            "dispatch".into(),
            core_dispatch_outcome_to_wire(&result.dispatch),
        );
        Ok(Value::Object(out))
    }
}

// Mark types we import-but-don't-use-publicly so dead-code lints stay clean.
#[allow(dead_code, clippy::let_underscore_future)]
fn _silence_unused() -> impl Sized {
    let _: Pin<Box<dyn std::future::Future<Output = ()> + Send>> = Box::pin(async {});
}
