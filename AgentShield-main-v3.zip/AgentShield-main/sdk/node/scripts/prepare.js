// `npm install` runs `prepare` automatically (unless `--ignore-scripts`).
// For `file:` installs of the source tree this is what produces a usable
// `dist/` — without it, `main:./dist/index.js` resolves to nothing and
// `require('@microsoft/agent-shield')` fails with "Cannot find module".
//
// What this script does:
//   1. If `dist/index.js` is already present (someone has run
//      `npm run build:wrapper` in this checkout), skip — no need to
//      rebuild on every dependent's install.
//   2. Otherwise, attempt `npm run build:wrapper` (tsc-only; no Rust).
//      This requires the TS dev dependencies, which `npm install` will
//      have already provided.
//   3. If TS compilation fails for any reason, exit 0 with a warning.
//      `prepare` is best-effort: failing it would block the dependent's
//      install, and a stale or absent `dist/` will produce a clearer
//      error at `require` time anyway.
//
// What this script does NOT do:
//   * Run `npm run build` (the napi-rs Rust build). That requires the
//     Rust toolchain, which most installing environments will not have.
//     Contributors must run `npm run build` themselves; published-package
//     consumers get per-triple prebuilt `.node` artifacts via the
//     `@microsoft/agent-shield-<triple>` packages set up by
//     `napi prepublish`.

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const distEntry = path.join(__dirname, '..', 'dist', 'index.js');
if (fs.existsSync(distEntry)) {
  process.exit(0);
}

const result = spawnSync('npm', ['run', 'build:wrapper'], {
  stdio: 'inherit',
  cwd: path.join(__dirname, '..'),
});

if (result.status !== 0) {
  console.warn(
    '[agent-shield] prepare: `npm run build:wrapper` failed; `dist/` ' +
      'may be missing. Run `npm run build && npm run build:wrapper` in ' +
      'the package directory to produce a usable build.',
  );
}

process.exit(0);
