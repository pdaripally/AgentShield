# Node MCP integration mediation

## Mediated paths
- `protectTool(...)` / `protectToolOutput(...)` mediate Stage 2/3/4 on the MCP helper surface at `sdk/node/mcp.ts:152` and `sdk/node/mcp.ts:205`.
- `MCPShield.protectTools(...)` wraps `(name, fn)` pairs at `sdk/node/mcp.ts:352`.
- `_wrapCallable()` applies the in-process server wrapper at `sdk/node/mcp.ts:360`.

## Unsupported paths
- Inputs before the MCP server boundary and final assistant outputs after the server returns.
- Remote MCP servers or raw callables not wrapped in-process.
- Any raw registry path left alongside the wrapped callable.

## Bypass risks
- Leaving the original function reachable after `protectTools()`.
- Replacing the wrapped callable mid-connection.
- Using connection-scoped state when call-scoped isolation is required.

## Streaming behavior
- The Node MCP helper does not expose streaming on this surface. Rules 1-5 are not applicable.

## Unknown tool-call shapes
- `_cleanArgs()` normalizes host-provided args and `toolCallId` is mandatory, but unexpected call shapes are not yet reported via `incident.unknown_invocation_shape`.

## See also

See [Post-tool limits and dangerous patterns](../../../docs/POST_TOOL_LIMITS.md) and the [adapter-mediated path matrix](../../../docs/adapter-mediated-paths.md).
