// Composable configuration object model for Agent Shield.
//
// Thin TS shell over the napi-rs `GuardrailsConfig` / `CompiledPolicy`
// handles. Composition, YAML materialisation and SHA-256 digest live
// in Rust; this file only preserves the public JS surface — `.layers`
// descriptors, `yamlStrings`, dispatch-by-type on extend / compose.

import * as fs from 'node:fs'
import * as native from './native.js'

export const NATIVE: unique symbol = Symbol('native')
export const LAYERS: unique symbol = Symbol('layers')

export type LayerKind = 'path' | 'string' | 'object'

export interface LayerDescriptor {
  kind: LayerKind
  source: unknown
  description?: string
}

export type ConfigSource =
  | string
  | Record<string, unknown>
  | GuardrailsConfig

const _render = (l: LayerDescriptor): string => {
  if (l.kind === 'path') return fs.readFileSync(l.source as string, 'utf8')
  if (l.kind === 'string') return l.source as string
  if (l.kind === 'object') return JSON.stringify(l.source)
  throw new Error(`unknown layer kind: ${(l as { kind: string }).kind}`)
}

function _make(
  handle: native.GuardrailsConfig,
  layers: readonly LayerDescriptor[],
): GuardrailsConfig {
  const cfg = Object.create(GuardrailsConfig.prototype) as GuardrailsConfig
  Object.defineProperty(cfg, NATIVE, { value: handle })
  Object.defineProperty(cfg, LAYERS, { value: Object.freeze(layers.slice()) })
  return cfg
}

export class CompiledPolicy {
  public readonly yamlStrings: readonly string[]
  // Internal native handle. Public-readonly so external code can't reach in
  // and mutate it; the symbol property keeps it out of normal property
  // enumeration. Definite-assignment-asserted because it's set via
  // Object.defineProperty in the constructor (TS doesn't track that).
  private declare readonly [NATIVE]: native.GuardrailsConfig

  constructor(nativeCfg: native.GuardrailsConfig, yamlStrings: readonly string[]) {
    Object.defineProperty(this, NATIVE, { value: nativeCfg })
    this.yamlStrings = Object.freeze(yamlStrings.slice())
    Object.freeze(this)
  }

  get digest(): string {
    return this[NATIVE].digest
  }

  /** Alias for {@link digest}. */
  get hash(): string {
    return this[NATIVE].digest
  }

  equals(other: unknown): boolean {
    return other instanceof CompiledPolicy && other.digest === this.digest
  }

  toString(): string {
    return `CompiledPolicy(layers=${this.yamlStrings.length}, digest=${this.digest.slice(0, 16)}…)`
  }
}

export class GuardrailsConfig {
  // Symbol-keyed slots are populated via `Object.defineProperty` in the
  // factories so they remain non-enumerable. Declared via `declare` so
  // TS knows the shape but doesn't insist on initialiser tracking; the
  // value is set in the constructor (or via `_make`).
  private declare readonly [NATIVE]: native.GuardrailsConfig | null
  private declare readonly [LAYERS]: readonly LayerDescriptor[]

  // Public form is `new GuardrailsConfig([])` (empty chain that throws on compile).
  // Non-empty chains must use the static factories.
  constructor(layers: readonly LayerDescriptor[] = []) {
    if (!Array.isArray(layers) || layers.length !== 0) {
      throw new TypeError(
        'GuardrailsConfig: use the static factories (load/fromString/fromObject)',
      )
    }
    Object.defineProperty(this, NATIVE, { value: null })
    Object.defineProperty(this, LAYERS, { value: Object.freeze([]) })
  }

  static load(path: string): GuardrailsConfig {
    const p = String(path)
    return _make(native.GuardrailsConfig.load(p), [{ kind: 'path', source: p }])
  }

  static fromString(
    yamlText: string,
    { description = '' }: { description?: string } = {},
  ): GuardrailsConfig {
    const t = String(yamlText)
    return _make(native.GuardrailsConfig.fromString(t), [
      { kind: 'string', source: t, description },
    ])
  }

  static fromObject(
    data: Record<string, unknown>,
    { description = '' }: { description?: string } = {},
  ): GuardrailsConfig {
    return _make(native.GuardrailsConfig.fromValue(data), [
      { kind: 'object', source: data, description },
    ])
  }

  static compose(...sources: ConfigSource[]): GuardrailsConfig {
    if (sources.length === 0) {
      throw new Error('GuardrailsConfig.compose requires at least one source')
    }
    return sources
      .slice(1)
      .reduce<GuardrailsConfig>((c, s) => c.extend(s), GuardrailsConfig._fromSource(sources[0]!))
  }

  extend(source: ConfigSource): GuardrailsConfig {
    if (!(source instanceof GuardrailsConfig)) {
      return this.extend(GuardrailsConfig._fromSource(source))
    }
    if (this[NATIVE] === null) return _make(source[NATIVE]!, source[LAYERS])
    if (source[NATIVE] === null) return _make(this[NATIVE], this[LAYERS])
    return _make(
      this[NATIVE].extend(source[NATIVE]),
      this[LAYERS].concat(source[LAYERS]),
    )
  }

  withOverrides(
    overrides: Record<string, unknown>,
    { description = 'overrides' }: { description?: string } = {},
  ): GuardrailsConfig {
    return this.extend(GuardrailsConfig.fromObject(overrides, { description }))
  }

  withPolicyPack(
    pack: ConfigSource,
    { description = 'policy_pack' }: { description?: string } = {},
  ): GuardrailsConfig {
    if (typeof pack === 'string') return this.extend(pack)
    if (pack && typeof pack === 'object' && !(pack instanceof GuardrailsConfig)) {
      return this.extend(GuardrailsConfig.fromObject(pack, { description }))
    }
    return this.extend(pack)
  }

  get layers(): readonly LayerDescriptor[] {
    return this[LAYERS]
  }

  get length(): number {
    return this[LAYERS].length
  }

  compile(): CompiledPolicy {
    const handle = this[NATIVE]
    if (handle === null || this[LAYERS].length === 0) {
      throw new Error('GuardrailsConfig.compile: no layers to compile')
    }
    // Wrap the native chain handle (not a native CompiledPolicy) so `digest` is
    // the non-validating canonical digest. The runtime build path re-enters
    // native to validate and produce the merged config.
    return new CompiledPolicy(handle, this[LAYERS].map(_render))
  }

  static _fromSource(source: ConfigSource): GuardrailsConfig {
    if (source instanceof GuardrailsConfig) return source
    if (typeof source === 'string') {
      return /[\r\n]/.test(source)
        ? GuardrailsConfig.fromString(source)
        : GuardrailsConfig.load(source)
    }
    if (source && typeof source === 'object') return GuardrailsConfig.fromObject(source)
    throw new TypeError(`Cannot construct GuardrailsConfig from ${typeof source}`)
  }
}
