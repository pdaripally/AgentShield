// Agent Shield for MCP (Model Context Protocol) servers — Node SDK.
//
// MCP servers are tool providers, not agent loops, so this module is
// a sibling integration rather than a framework adapter. Mirrors the
// Python `agent_shield.mcp` and the .NET `AgentShield.MCP` modules.
//
// Session scope
// -------------
// By default an MCPShield instance holds a single long-lived session
// for the lifetime of the connection so state predicates span tool
// calls. Pass `{ sessionScope: 'call' }` to opt out (per-call sessions,
// stateless).

import {
  CoverageLevel,
  CapabilityReport,
  Shield,
  ShieldBuilder,
  currentSession,
  currentUserInput,
  type CapabilityBundle,
  type GuardedToolResult,
  type PendingResolutionLike,
  type SessionLike,
  type RuntimeLike,
  type StageVerdictLike,
} from './shield.js'
// Namespace import (lazy property access) breaks the mcp ↔ index
// AND the mcp ↔ shield module cycles. `_index.RuntimeBuilder` and
// `_shield.ShieldBuilder` are referenced only inside method bodies
// (or deferred via queueMicrotask), so the cycle resolves before
// any access.
import * as _index from './index.js'
import * as _shield from './shield.js'
import { randomUUID } from 'node:crypto'

// ─── Module augmentation: install MCP entry points on the base
//     Shield / ShieldBuilder so the documented 3-line drop-in works
//     (`Shield.fromYaml(...).withMcp().build()` + `shieldServer(server, shield)`).
declare module './shield.js' {
  interface ShieldBuilder {
    /**
     * Tag this builder for the MCP integration. The Shield it produces
     * reports the MCP capability bundle from `.capabilities` and is
     * the recommended argument for {@link shieldServer}. Idempotent.
     *
     * The base Shield's `protectTool(name, params, fn)` already covers
     * Stage 2/3/4 wrapping of MCP tools, so no separate Shield class
     * is needed for the drop-in case — `MCPShield` remains for
     * customers who want connection-scoped session semantics or the
     * structured `pending_resolution` accessor.
     */
    withMcp(): this
  }
  interface Shield {
    /**
     * Walk an MCP server's tool registry and replace every handler
     * with a Stage-2/3/4-guarded version. Returns the same `server`
     * for fluent chaining.
     *
     * Supports the common MCP server shapes: FastMCP-style
     * `_tool_manager._tools`, the official TypeScript SDK's
     * `_registeredTools`, and top-level `tools` / `_tools` registries.
     * Hosts with a custom registry can drop down to
     * `shield.protectTool(name, params, fn)` inside their own
     * dispatcher.
     */
    protectServer<TServer>(server: TServer, opts?: ProtectServerOpts): TServer
  }
}

let _MCP_CAPABILITIES_CACHE: CapabilityReport | null = null
function _mcpCapabilities(): CapabilityReport {
  if (_MCP_CAPABILITIES_CACHE === null) {
    _MCP_CAPABILITIES_CACHE = new CapabilityReport({
      framework: 'mcp',
      inputValidation: CoverageLevel.UNSUPPORTED,
      stateValidation: CoverageLevel.FULL,
      toolAuthorization: CoverageLevel.FULL,
      toolExecutionValidation: CoverageLevel.FULL,
      toolOutputValidation: CoverageLevel.FULL,
      outputValidation: CoverageLevel.UNSUPPORTED,
      streamingOutput: CoverageLevel.UNSUPPORTED,
      notes: [
        'MCP is a tool-provider integration; no user-facing input or assistant-output boundary exists for Stage 1 / Stage 5 / streaming',
      ],
    })
  }
  return _MCP_CAPABILITIES_CACHE
}

/**
 * MCP capability bundle, installed on a `ShieldBuilder` by
 * {@link ShieldBuilder.withMcp}. Exposes the MCP capability report
 * but no `toolWrapper` / `agentBoundary` — Stage 2/3/4 wrapping
 * routes through the base `Shield.protectTool(name, params, fn)`,
 * and there is no agent-loop boundary on the MCP side (MCP is a
 * tool provider, not an agent loop).
 *
 * Lazy: the underlying `CapabilityReport` is constructed on first
 * access via `.capabilities` so the bundle does not force the
 * shield-module imports to resolve at `./mcp.js` load time (the
 * `mcp.ts ↔ shield.ts` cycle leaves `CoverageLevel` undefined at
 * top-level evaluation order).
 */
export const MCP_BUNDLE: CapabilityBundle = Object.freeze({
  name: 'mcp',
  get capabilities(): CapabilityReport {
    return _mcpCapabilities()
  },
}) as CapabilityBundle

export class MCPGuardrailBlocked extends Error {
  override readonly name = 'MCPGuardrailBlocked'
  readonly toolName: string
  override readonly message: string

  constructor(toolName: string, message: string) {
    super(message)
    this.toolName = toolName
    this.message = message
  }
}

function _formatBlock(verdict: StageVerdictLike | null | undefined): string {
  const action = (verdict?.action ?? 'block').toUpperCase()
  const reason = verdict?.reason ?? 'blocked by policy'
  return `[GUARDRAIL ${action}] ${reason}`
}

function _cleanArgs(
  args: Record<string, unknown> | null | undefined,
): Record<string, unknown> {
  const cleaned: Record<string, unknown> = { ...(args ?? {}) }
  for (const k of Object.keys(cleaned)) {
    // eslint-disable-next-line security/detect-object-injection -- k is enumerated from the local cleaned-args object.
    if (cleaned[k] === undefined || cleaned[k] === null) delete cleaned[k]
  }
  return cleaned
}

/** Optional sink invoked with the structured `pending_resolution`
 *  envelope on a Stage 2/3 block. See {@link PendingResolutionLike}. */
export type PendingResolutionSink = (pr: PendingResolutionLike) => void

function _extractPending(
  verdict: StageVerdictLike | null | undefined,
): PendingResolutionLike | null {
  // Accept either the camelCase (`pendingResolution`, the canonical
  // Node SDK shape) or the snake_case raw wire key (defensive — some
  // adapters or future runtimes may forward verdicts without
  // re-camelizing).
  const pr = verdict?.pendingResolution ?? verdict?.pending_resolution ?? null
  return pr ?? null
}

function _firePendingSink(
  sink: PendingResolutionSink | undefined,
  verdict: StageVerdictLike | null | undefined,
): void {
  if (!sink) return
  const pr = _extractPending(verdict)
  if (!pr) return
  try {
    sink(pr)
  } catch {
    // Sink errors must NOT mask the guardrail block — debug-only
    // (mirrors the Python adapter).
  }
}

// ──── Stage 4 result shape preservation ─────────────────────────
//
// MCP servers return `CallToolResult` objects shaped like
// `{ content: [{ type,...}], isError? }` where `type: "text"` items
// carry the textual payload and `image` / `resource` items carry
// binary or URI references. The Stage 4 redaction pipeline operates
// on text; previously the wrapper coerced the entire result via
// `String(result)` which produced `"[object Object]"` and lost the
// shape. The contract is now: shape in → shape out, with redactions
// applied to `text` fields in-place. Image / resource content is
// passed through unmodified.

interface CallToolContentItem {
  type: string
  text?: string
  [k: string]: unknown
}

interface CallToolResultLike {
  content: CallToolContentItem[]
  [k: string]: unknown
}

function _isCallToolResult(x: unknown): x is CallToolResultLike {
  return (
    typeof x === 'object' &&
    x !== null &&
    Array.isArray((x as { content?: unknown }).content)
  )
}

/**
 * Stage-4 payload adapter. Extracts a `text` string the runtime can
 * scan / redact, and a `restore(validatedText)` closure that puts the
 * (possibly mutated) text back into the original shape. Three shapes
 * are recognised:
 *
 *  1. `string` — pass through.
 *  2. MCP `CallToolResult` (`{content: [{type, text}],...}`) — join
 *     `text` fields from text-typed items; on restore, write the
 *     validated string back into the first text item and drop any
 *     additional text items (image / resource items are preserved
 *     in their original positions).
 *  3. Other objects — `JSON.stringify` for Stage 4 input so the
 *     runtime sees a readable representation rather than
 *     `"[object Object]"`. The restored result is the validated
 *     string (we do not attempt to JSON-parse a redacted string
 *     back into the original object; that round-trip is unsafe
 *     after pattern-based mutation).
 */
interface Stage4Payload {
  text: string
  restore(validated: string): unknown
}

function _stage4Payload(result: unknown): Stage4Payload {
  if (typeof result === 'string') {
    return { text: result, restore: (t) => t }
  }
  if (_isCallToolResult(result)) {
    const content = result.content
    const textIndices: number[] = []
    const parts: string[] = []
    for (let i = 0; i < content.length; i++) {
      // eslint-disable-next-line security/detect-object-injection -- i is a numeric loop index over the local content array.
      const item = content[i]
      if (item && item.type === 'text' && typeof item.text === 'string') {
        textIndices.push(i)
        parts.push(item.text)
      }
    }
    // Join with a newline boundary so adjacent text items remain
    // visually separated for pattern matchers; identical to how
    // most MCP clients render multi-text content.
    const text = parts.join('\n')
    return {
      text,
      restore: (validated) => {
        // Shape-preserve: keep image/resource items in place. Write
        // the validated string into the first text item and remove
        // any subsequent text items so a redact verdict
        // ("[PII REDACTED]") doesn't get duplicated across N items.
        if (textIndices.length === 0) {
          // No text items existed — append a single text item with
          // the validated payload so the redacted string is not
          // silently dropped on the return.
          const merged: CallToolContentItem[] = [
            ...content,
            { type: 'text', text: validated },
          ]
          return { ...result, content: merged }
        }
        const merged: CallToolContentItem[] = []
        let wroteText = false
        for (let i = 0; i < content.length; i++) {
          // eslint-disable-next-line security/detect-object-injection -- i is a numeric loop index over the local content array.
          const item = content[i]
          if (item && item.type === 'text' && typeof item.text === 'string') {
            if (!wroteText) {
              merged.push({ ...item, text: validated })
              wroteText = true
            }
            // Subsequent text items are absorbed into the first one.
          } else {
            merged.push(item)
          }
        }
        return { ...result, content: merged }
      },
    }
  }
  if (result == null) {
    return { text: '', restore: (t) => t }
  }
  // Fallback: structured non-MCP object. JSON-stringify so the Stage
  // 4 runtime sees a readable representation instead of
  // `"[object Object]"`. The restored payload is the validated
  // string — we do not attempt to round-trip JSON.parse(validated)
  // back into the original object because redaction-mutated JSON
  // may not be syntactically valid.
  try {
    return { text: JSON.stringify(result), restore: (t) => t }
  } catch {
    return { text: String(result), restore: (t) => t }
  }
}

export interface ProtectToolResult {
  allowed: boolean
  effectiveArgs: Record<string, unknown>
  blockMessage: string | null
  /**
   * Structured suspension envelope when a Stage 2/3 block was caused
   * by a resolver awaiting external input (e.g. `kind: human`
   * pending operator approval). `null` on every other outcome.
   * Mirrors the Python adapter's `last_pending_resolution()`.
   */
  pendingResolution: PendingResolutionLike | null
}

export interface ProtectToolOutputResult {
  allowed: boolean
  /**
   * Stage-4-effective tool result. Shape preservation: a
   * `string` input returns a `string`; an MCP `CallToolResult`
   * (`{content: [{type, text}],...}`) returns the same shape with
   * text content redacted in-place. Other object shapes round-trip
   * as a JSON-stringified payload (best-effort).
   */
  effectiveOutput: unknown
  blockMessage: string | null
  pendingResolution: PendingResolutionLike | null
}

async function _doProtectTool(
  session: SessionLike,
  toolName: string,
  args: Record<string, unknown> | null | undefined,
  toolCallId: string,
  pendingResolutionSink?: PendingResolutionSink,
): Promise<ProtectToolResult> {
  if (!toolCallId) {
    throw new TypeError('toolCallId is required and must be non-empty')
  }
  const cleaned = _cleanArgs(args)
  const outcome = await session.validateToolCall(toolName, cleaned, toolCallId)
  if (!outcome.verdict.allowed) {
    _firePendingSink(pendingResolutionSink, outcome.verdict)
    return {
      allowed: false,
      effectiveArgs: cleaned,
      blockMessage: _formatBlock(outcome.verdict),
      pendingResolution: _extractPending(outcome.verdict),
    }
  }
  return {
    allowed: true,
    effectiveArgs: (outcome.params as Record<string, unknown> | undefined) ?? cleaned,
    blockMessage: null,
    pendingResolution: null,
  }
}

async function _doProtectToolOutput(
  session: SessionLike,
  toolName: string,
  output: unknown,
  toolCallId: string,
  record: boolean,
  pendingResolutionSink?: PendingResolutionSink,
): Promise<ProtectToolOutputResult> {
  if (!toolCallId) {
    throw new TypeError('toolCallId is required and must be non-empty')
  }
  // Preserve the result shape (string / CallToolResult /
  // other) across Stage 4 instead of coercing to `"[object Object]"`.
  const payload = _stage4Payload(output)
  const outcome = await session.validateToolOutput(toolName, payload.text, toolCallId)
  if (!outcome.verdict.allowed) {
    _firePendingSink(pendingResolutionSink, outcome.verdict)
    if (record) {
      try {
        session.recordToolFailure(toolName, outcome.verdict.reason ?? 'blocked')
      } catch {
        /* swallow */
      }
    }
    return {
      allowed: false,
      effectiveOutput: payload.restore(payload.text),
      blockMessage: _formatBlock(outcome.verdict),
      pendingResolution: _extractPending(outcome.verdict),
    }
  }
  // Stage 4 may have produced a redacted / appended / prepended
  // string; `outcome.result` is the canonical effective payload.
  const validated = outcome.result ?? payload.text
  const validatedStr = typeof validated === 'string' ? validated : String(validated)
  const restored = payload.restore(validatedStr)
  if (record) {
    try {
      // Resource cycle records the canonical text representation
      // (what the runtime saw), not the wrapper-shape object —
      // matches the Python adapter's recording behaviour.
      session.recordToolSuccess(toolName, validatedStr)
    } catch {
      /* swallow */
    }
  }
  return {
    allowed: true,
    effectiveOutput: restored,
    blockMessage: null,
    pendingResolution: null,
  }
}

/**
 * Stage 2 + 3 — guard an inbound MCP tool call.
 *
 * `toolCallId` is REQUIRED (Section 16.0 mandatory binding). Reuse
 * the same id on the paired {@link protectToolOutput} call so Stage 4
 * binds against the canonical invocation Stage 3 admitted. When the
 * host framework does not surface a native id (e.g. raw MCP without
 * a request id), mint one with `randomUUID()` per call.
 *
 * `pendingResolutionSink` — optional callback invoked with the
 * structured suspension envelope on a Stage 2/3 block caused by a
 * resolver awaiting external input (e.g. `kind: human` waiting on
 * operator approval). See {@link PendingResolutionLike}. The same
 * envelope is also returned via the {@link ProtectToolResult.pendingResolution}
 * field so the sink is optional — pick whichever fits the host loop.
 */
export async function protectTool(
  runtime: RuntimeLike,
  toolName: string,
  args: Record<string, unknown> | null | undefined,
  toolCallId: string,
  opts: {
    session?: SessionLike
    pendingResolutionSink?: PendingResolutionSink
  } = {},
): Promise<ProtectToolResult> {
  const session = opts.session ?? runtime.newSession()
  return _doProtectTool(
    session,
    toolName,
    args,
    toolCallId,
    opts.pendingResolutionSink,
  )
}

/**
 * Stage 4 — guard an outbound MCP tool result.
 *
 * `toolCallId` is REQUIRED and MUST match the id passed to the
 * paired {@link protectTool} call (Section 16.0).
 *
 * Shape preservation: a `string` input returns a `string`;
 * an MCP `CallToolResult` (`{content: [{type, text}],...}`) returns
 * the same object shape with text content redacted in-place. Image
 * (`type: "image"`) and resource (`type: "resource"`) content items
 * pass through unmodified — they carry base64 / URI payloads that
 * the text-redaction pipeline does not interpret.
 *
 * `pendingResolutionSink` — see {@link protectTool}. The same
 * envelope is also exposed via {@link ProtectToolOutputResult.pendingResolution}.
 */
export async function protectToolOutput(
  runtime: RuntimeLike,
  toolName: string,
  output: unknown,
  toolCallId: string,
  opts: {
    session?: SessionLike
    record?: boolean
    pendingResolutionSink?: PendingResolutionSink
  } = {},
): Promise<ProtectToolOutputResult> {
  const session = opts.session ?? runtime.newSession()
  const record = opts.record ?? true
  return _doProtectToolOutput(
    session,
    toolName,
    output,
    toolCallId,
    record,
    opts.pendingResolutionSink,
  )
}

export type SessionScope = 'connection' | 'call'

export interface MCPShieldOpts {
  capabilities?: CapabilityReport
  sessionScope?: SessionScope
}

export type MCPOnBlock = 'raise' | 'returnMessage'

export interface ProtectToolsOpts {
  onBlock?: MCPOnBlock
  /** Optional sink called on every Stage 2/3 block with a structured
   *  pending_resolution. Most hosts will prefer the latched
   *  {@link MCPShield.lastPendingResolution} accessor instead. */
  pendingResolutionSink?: PendingResolutionSink
}

export type MCPToolFn = (params?: Record<string, unknown>) => Promise<unknown> | unknown

export class MCPShieldBuilder {
  protected _path: string
  _yamlChain: readonly string[] | null = null
  protected readonly _observabilityProviders: Array<(event: unknown) => void> = []
  protected _llmCaller: ((req: unknown) => unknown) | null = null
  protected readonly _extra: Array<(builder: unknown) => void> = []
  protected _sessionScope: SessionScope = 'connection'

  constructor(path: string) {
    this._path = path
  }

  withObservability(provider: (event: unknown) => void): this {
    this._observabilityProviders.push(provider)
    return this
  }

  withLlmCaller(caller: (req: unknown) => unknown): this {
    this._llmCaller = caller
    return this
  }

  /**
   * Register a host implementation for `kind: agent` resolvers
   * declared in YAML. The resolver receives a `ResolverRequest` and
   * returns a `ResolverResponse` envelope (`{decision, value,...}`).
   * Mirrors {@link ShieldBuilder.withAgentResolver} and replaces the
   * earlier `.withExtension((b) => b.registerAgentResolver(fn))`
   * escape hatch.
   */
  withAgentResolver(resolver: (req: unknown) => unknown): this {
    this._extra.push((rb: unknown) => {
      const builder = rb as { registerAgentResolver(fn: (req: unknown) => unknown): unknown }
      builder.registerAgentResolver(resolver)
    })
    return this
  }

  /**
   * Register a host implementation for `classifier:` references in
   * `evaluate_when[]`. The caller receives a `ClassifierRequest`
   * (`{configurationId, subject}`) and returns a `ClassifierVerdict`
   * (or a JSON-string with the same shape). Replaces the earlier
   * `.withExtension((b) => b.registerClassifierCaller(fn))` escape
   * hatch — the loader's `classifier_wiring_missing` remediation
   * hint points at this method directly.
   */
  withClassifierCaller(caller: (req: unknown) => unknown): this {
    this._extra.push((rb: unknown) => {
      const builder = rb as { registerClassifierCaller(fn: (req: unknown) => unknown): unknown }
      builder.registerClassifierCaller(caller)
    })
    return this
  }

  withExtension(hook: (builder: unknown) => void): this {
    this._extra.push(hook)
    return this
  }

  withSessionScope(scope: SessionScope): this {
    this._sessionScope = scope
    return this
  }

  build(): MCPShield {
    let builder: import('./index.js').RuntimeBuilder
    if (this._yamlChain) {
      builder = _index.RuntimeBuilder.fromYamlChain(this._yamlChain.slice())
    } else {
      builder = _index.RuntimeBuilder.fromYaml(this._path)
    }
    if (this._llmCaller) builder.registerLlmCaller(this._llmCaller as never)
    for (const p of this._observabilityProviders) builder.registerProvider(p as never)
    for (const hook of this._extra) hook(builder)
    return new MCPShield(builder.build() as unknown as RuntimeLike, {
      sessionScope: this._sessionScope,
    })
  }
}

export class MCPShield {
  readonly runtime: RuntimeLike
  protected readonly _capabilities: CapabilityReport
  protected readonly _sessionScope: SessionScope
  protected _session: SessionLike | null = null
  // Most recent `pending_resolution` envelope surfaced by a
  // Stage 2/3 block on a tool wrapped via this shield. Hosts call
  // {@link lastPendingResolution} to read and clear; the latch is
  // shared across both {@link protectTool} and {@link protectTools}
  // so the surfacing pattern is the same regardless of API surface.
  protected _lastPendingResolution: PendingResolutionLike | null = null

  constructor(runtime: RuntimeLike, opts: MCPShieldOpts = {}) {
    this.runtime = runtime
    this._capabilities = opts.capabilities ?? _mcpCapabilities()
    const scope = opts.sessionScope ?? 'connection'
    if (scope !== 'connection' && scope !== 'call') {
      throw new Error(
        `sessionScope must be 'connection' or 'call', got ${JSON.stringify(scope)}`,
      )
    }
    this._sessionScope = scope
  }

  /** Start a builder from a single YAML file or a chain of YAML files. */
  static fromYaml(pathOrPaths: string | readonly string[]): MCPShieldBuilder {
    if (Array.isArray(pathOrPaths)) {
      const b = new MCPShieldBuilder('')
      b._yamlChain = pathOrPaths.slice()
      return b
    }
    return new MCPShieldBuilder(pathOrPaths as string)
  }

  get capabilities(): CapabilityReport {
    return this._capabilities
  }

  get sessionScope(): SessionScope {
    return this._sessionScope
  }

  /**
   * The held connection session, or `null` when scope is `'call'`.
   * Lazily created on first access in connection mode.
   */
  get session(): SessionLike | null {
    if (this._sessionScope !== 'connection') return null
    if (this._session === null) this._session = this.runtime.newSession()
    return this._session
  }

  /**
   * Drop the held connection session. The next call lazily creates a
   * fresh one. No-op when scope is `'call'`.
   */
  resetSession(): void {
    this._session = null
  }

  protected _resolveSession(explicit: SessionLike | null | undefined): SessionLike {
    if (explicit) return explicit
    if (this._sessionScope === 'connection') {
      const sess = this.session
      if (sess) return sess
    }
    return this.runtime.newSession()
  }

  /**
   * Read AND clear the most recent `pending_resolution` envelope
   * surfaced by a Stage 2/3 block on a tool routed through
   * {@link protectTool} or {@link protectTools} on this shield.
   *
   * When a wrapped tool is blocked at Stage 2/3 by a resolver that
   * suspends pending external input (e.g. a `kind: human` resolver
   * awaiting operator approval, or a `kind: tool` resolver awaiting
   * a named tool call), the verdict carries a structured envelope:
   *
   *     {
   *       tool: 'agent_shield.ask_human',
   *       variable: 'trade_authorized',
   *       prompt: 'Authorize this trade?',
   *       requestId: 'req-7f3c',
   *       kind: 'human',
   *     }
   *
   * The block message surfaced through the MCP wrapper is shaped
   * for the upstream LLM trajectory (`[GUARDRAIL...]`); this method
   * gives the host a programmatic handle on the same suspension so
   * it can drive the human-approval UI (look up the named tool's
   * resolver, prompt the operator, etc.) without substring-matching
   * the block message.
   *
   * **Non-destructive peek.** Reading the latch does NOT
   * clear it. Multiple peeks return the same envelope until a fresh
   * block re-latches a new one. Use the per-call result's
   * `pendingResolution` field to disambiguate "did THIS call block?"
   * vs "is there a residual latch from a prior block?".
   *
   * Returns `null` when no block has ever carried a pending
   * resolution.
   *
   * Mirrors the Python adapter's `Shield.last_pending_resolution()`.
   */
  lastPendingResolution(): PendingResolutionLike | null {
    return this._lastPendingResolution
  }

  protected _captureSink: PendingResolutionSink = (pr) => {
    this._lastPendingResolution = pr
  }

  protected _composeSink(
    extra: PendingResolutionSink | undefined,
  ): PendingResolutionSink {
    if (!extra) return this._captureSink
    return (pr) => {
      // Internal latch always wins; the host-supplied sink is
      // called after so a misbehaving sink can never block the
      // canonical surfacing path.
      this._captureSink(pr)
      try {
        extra(pr)
      } catch {
        /* swallow — see _firePendingSink rationale */
      }
    }
  }

  async protectTool(
    toolName: string,
    args: Record<string, unknown> | null | undefined,
    toolCallId: string,
    opts: {
      session?: SessionLike
      pendingResolutionSink?: PendingResolutionSink
    } = {},
  ): Promise<ProtectToolResult> {
    return _doProtectTool(
      this._resolveSession(opts.session),
      toolName,
      args,
      toolCallId,
      this._composeSink(opts.pendingResolutionSink),
    )
  }

  async protectToolOutput(
    toolName: string,
    output: unknown,
    toolCallId: string,
    opts: {
      session?: SessionLike
      record?: boolean
      pendingResolutionSink?: PendingResolutionSink
    } = {},
  ): Promise<ProtectToolOutputResult> {
    const record = opts.record ?? true
    return _doProtectToolOutput(
      this._resolveSession(opts.session),
      toolName,
      output,
      toolCallId,
      record,
      this._composeSink(opts.pendingResolutionSink),
    )
  }

  /**
   * Wrap a list of `(name, fn)` tool pairs with Stage 2/3/4 enforcement.
   * Returns a list of `(name, wrappedFn)` pairs the MCP server can
   * register. `onBlock` is `"raise"` (throws MCPGuardrailBlocked) or
   * `"returnMessage"` (returns the formatted block string).
   *
   * Shape preservation: wrapped tools that return MCP
   * `CallToolResult` objects (`{content: [{type, text}],...}`)
   * round-trip the shape — Stage 4 redaction is applied to text
   * content in-place; image / resource items pass through.
   *
   * Pending-resolution surfacing: a Stage 2/3 block caused
   * by a resolver awaiting external input (e.g. `kind: human`
   * approval) latches the structured envelope on the shield. Hosts
   * read it via {@link lastPendingResolution} after observing the
   * `[GUARDRAIL...]` block string. Pass
   * `opts.pendingResolutionSink` for a push-style callback.
   */
  protectTools(
    tools: ReadonlyArray<[string, MCPToolFn]>,
    opts: ProtectToolsOpts = {},
  ): Array<[string, MCPToolFn]> {
    const onBlock = opts.onBlock ?? 'raise'
    const sink = this._composeSink(opts.pendingResolutionSink)
    return tools.map(([name, fn]) => [name, this._wrapCallable(name, fn, onBlock, sink)])
  }

  protected _wrapCallable(
    toolName: string,
    fn: MCPToolFn,
    onBlock: MCPOnBlock,
    pendingResolutionSink?: PendingResolutionSink,
  ): MCPToolFn {
    return async (params: Record<string, unknown> = {}): Promise<unknown> => {
      const session = currentSession() ?? this._resolveSession(null)
      // Pre-fetch the ambient user input so a custom resolver context can
      // optionally include it in its prompts. Currently unused at this
      // call site but kept symmetric with the Python adapter.
      void currentUserInput()
      // binding: MCP servers do not surface the upstream client's
      // request id at the tool boundary, so we mint a stable per-call
      // id here. Stage 3 + Stage 4 share one id even when the server
      // sees concurrent same-name calls on the held connection session.
      const callId = randomUUID()
      const sink = pendingResolutionSink ?? this._captureSink
      const inboundCheck = await _doProtectTool(
        session,
        toolName,
        params,
        callId,
        sink,
      )
      if (!inboundCheck.allowed) {
        if (onBlock === 'raise') {
          throw new MCPGuardrailBlocked(toolName, inboundCheck.blockMessage ?? '')
        }
        return inboundCheck.blockMessage
      }
      const result = await fn(inboundCheck.effectiveArgs)
      const out = await _doProtectToolOutput(
        session,
        toolName,
        result,
        callId,
        true,
        sink,
      )
      if (!out.allowed) {
        if (onBlock === 'raise') {
          throw new MCPGuardrailBlocked(toolName, out.blockMessage ?? '')
        }
        return out.blockMessage
      }
      // Preserve the CallToolResult / string / other shape
      // the underlying tool returned. `effectiveOutput` is the
      // restored, shape-preserved payload (e.g. `{content: [{type:
      // 'text', text: '[PII REDACTED]'}]}` for an MCP result, or a
      // plain string for a string-returning tool).
      return out.effectiveOutput
    }
  }

  /**
   * Wrap every tool registered on an MCP `server` with Stage 2/3/4
   * enforcement. Mirrors `MCPShield.protect_server` in the Python
   * SDK and parses the same registry shapes — FastMCP-style
   * `_tool_manager._tools`, the official TypeScript SDK's
   * `_registeredTools`, and top-level `tools` / `_tools` registries.
   *
   * Hosts with a custom registry can wrap tools individually via
   * {@link protectTool} or {@link protectTools} instead.
   */
  protectServer<TServer>(server: TServer, opts: ProtectServerOpts = {}): TServer {
    const sink = this._composeSink(opts.pendingResolutionSink)
    const onBlock = opts.onBlock ?? 'raise'
    _walkServerTools(server, (name, fn) => {
      return this._wrapCallable(name, fn, onBlock, sink)
    })
    return server
  }
}

/**
 * Options for {@link shieldServer} and {@link MCPShield.protectServer}.
 *
 * `onBlock` controls how a Stage 2/3/4 block surfaces inside the
 * tool handler: `'raise'` throws {@link MCPGuardrailBlocked} (the
 * default — matches the Python SDK), `'returnMessage'` returns the
 * formatted `[GUARDRAIL...]` string in place of the tool's
 * normal output.
 */
export interface ProtectServerOpts {
  onBlock?: MCPOnBlock
  pendingResolutionSink?: PendingResolutionSink
}

// ─── MCP server tool-registry walker ────────────────────────────────
//
// `_walkServerTools(server, replace)` enumerates the registered tools
// on an MCP server instance and calls `replace(name, originalFn)` for
// each one; the return value is wired back into the registry in place
// of the original handler. Three duck-typed registry shapes are
// recognised in priority order:
//
//   1. FastMCP-style: `server._tool_manager._tools` (dict)
//   2. TS MCP SDK: `server._registeredTools` (Map | dict)
//   3. Generic dict: `server._tools` or `server.tools` (dict)
//   4. Generic array: `server.tools` ([{name, handler},...])
//
// For each registered tool the handler is sniffed on `.handler`,
// `.callback`, `.fn`, `.func`, `.invoke`, or — if the entry IS
// callable — the entry itself. Hosts with a custom registry should
// call {@link MCPShield.protectTools} (or
// {@link Shield.protectTool}) directly instead of relying on the
// walker.

type _WrapperFn = (name: string, fn: MCPToolFn) => MCPToolFn

function _walkServerTools(server: unknown, replace: _WrapperFn): void {
  if (server == null || (typeof server !== 'object' && typeof server !== 'function')) {
    throw new TypeError(
      'protectServer / shieldServer require an MCP server instance; ' +
        `got ${server === null ? 'null' : typeof server}`,
    )
  }
  const s = server as Record<string, unknown>
  const candidates: unknown[] = []
  const tm = s['_tool_manager']
  if (tm && typeof tm === 'object' && (tm as Record<string, unknown>)['_tools'] !== undefined) {
    candidates.push((tm as Record<string, unknown>)['_tools'])
  }
  if (s['_registeredTools'] !== undefined) candidates.push(s['_registeredTools'])
  if (s['_tools'] !== undefined) candidates.push(s['_tools'])
  if (s['tools'] !== undefined) candidates.push(s['tools'])
  for (const reg of candidates) {
    if (_wrapRegistry(reg, replace)) return
  }
  throw new TypeError(
    'Cannot locate the MCP tool registry on this server. Supported ' +
      'shapes: `_tool_manager._tools`, `_registeredTools`, ' +
      '`_tools`, `tools`. Custom registries should call ' +
      '`shield.protectTool(name, params, fn)` directly per tool.',
  )
}

function _wrapRegistry(registry: unknown, replace: _WrapperFn): boolean {
  if (registry instanceof Map) {
    for (const [name, entry] of registry.entries()) {
      const key = typeof name === 'string' ? name : String(name)
      _wrapEntry(entry, key, (wrapped) => registry.set(key, wrapped), replace)
    }
    return true
  }
  if (Array.isArray(registry)) {
    for (const entry of registry) {
      const name = _extractName(entry)
      if (!name) continue
      _wrapEntry(entry, name, () => undefined, replace)
    }
    return true
  }
  if (registry !== null && typeof registry === 'object') {
    const reg = registry as Record<string, unknown>
    for (const name of Object.keys(reg)) {
      // eslint-disable-next-line security/detect-object-injection -- name is enumerated from the registry's own keys.
      const entry = reg[name]
      _wrapEntry(
        entry,
        name,
        (wrapped) => {
          // eslint-disable-next-line security/detect-object-injection -- name is enumerated from the registry's own keys.
          reg[name] = wrapped
        },
        replace,
      )
    }
    return true
  }
  return false
}

function _extractName(entry: unknown): string | null {
  if (entry == null || (typeof entry !== 'object' && typeof entry !== 'function')) {
    return null
  }
  const e = entry as { name?: unknown }
  return typeof e.name === 'string' && e.name.length > 0 ? e.name : null
}

const _HANDLER_KEYS = ['handler', 'callback', 'fn', 'func', 'invoke'] as const

function _wrapEntry(
  entry: unknown,
  name: string,
  rebind: (wrapped: MCPToolFn) => void,
  replace: _WrapperFn,
): void {
  if (entry == null) return
  if (typeof entry === 'function') {
    const wrapped = replace(name, entry as MCPToolFn)
    rebind(wrapped)
    return
  }
  if (typeof entry !== 'object') return
  const e = entry as Record<string, unknown>
  for (const key of _HANDLER_KEYS) {
    // eslint-disable-next-line security/detect-object-injection -- key is iterated from the literal _HANDLER_KEYS allow-list.
    const handler = e[key]
    if (typeof handler === 'function') {
      const wrapped = replace(name, handler as MCPToolFn)
      // eslint-disable-next-line security/detect-object-injection -- key is iterated from the literal _HANDLER_KEYS allow-list.
      e[key] = wrapped
      return
    }
  }
}

/**
 * Convenience drop-in: wrap every tool registered on an MCP
 * `server` with Stage 2/3/4 enforcement, in one call.
 *
 * Accepts either a base {@link Shield} (recommended — produced by
 * `Shield.fromYaml(...).withMcp().build()`) or an {@link MCPShield}
 * (for hosts that opted into connection-scoped session semantics).
 * Returns the same `server` for fluent chaining.
 *
 *     import { Shield } from '@microsoft/agent-shield'
 *     import { shieldServer } from '@microsoft/agent-shield/mcp'
 *
 *     const shield = Shield.fromYaml('.guardrails.yaml').withMcp().build()
 *     shieldServer(server, shield)
 *
 * Mirrors `agent_shield.mcp.shield_server` in Python.
 */
export function shieldServer<TServer>(
  server: TServer,
  shield: Shield | MCPShield,
  opts: ProtectServerOpts = {},
): TServer {
  if (shield instanceof MCPShield) {
    return shield.protectServer(server, opts)
  }
  if (shield instanceof Shield) {
    return shield.protectServer(server, opts)
  }
  throw new TypeError(
    'shieldServer(server, shield): `shield` must be a Shield or MCPShield instance. ' +
      'Construct one via `Shield.fromYaml(...).withMcp().build()` or ' +
      '`MCPShield.fromYaml(...).build()`.',
  )
}

// ─── Side-effect installation ───────────────────────────────────────
//
// Idempotent. Importing this module installs `ShieldBuilder.withMcp`
// and `Shield.protectServer` on the prototypes. The check guards
// against double-install when multiple paths pull `./mcp.js` in.

interface ShieldBuilderInternal {
  _bundle: CapabilityBundle | null
}

function _wrapWithShield(
  shield: Shield,
  toolName: string,
  fn: MCPToolFn,
  onBlock: MCPOnBlock,
): MCPToolFn {
  return async (params: Record<string, unknown> = {}): Promise<unknown> => {
    const result: GuardedToolResult = await shield.protectTool(
      toolName,
      params,
      async (effective) => fn(effective),
    )
    if (result.blocked) {
      if (onBlock === 'raise') {
        throw new MCPGuardrailBlocked(toolName, result.output ?? '')
      }
      return result.output
    }
    return result.output
  }
}

let _mcpSideEffectsInstalled = false

function _patchPrototypes(
  SB: typeof ShieldBuilder,
  S: typeof Shield,
): void {
  if (_mcpSideEffectsInstalled) return
  _mcpSideEffectsInstalled = true
  if (!Object.prototype.hasOwnProperty.call(SB.prototype, 'withMcp')) {
    Object.defineProperty(SB.prototype, 'withMcp', {
      value: function withMcp(this: ShieldBuilder): ShieldBuilder {
        const self = this as unknown as ShieldBuilderInternal
        // Install only when no other adapter bundle is in place; an
        // already-installed framework bundle (LangChain, OpenAI
        // Agents, Anthropic) covers MCP-style tool wrapping through
        // its own toolWrapper, so overwriting would silently drop
        // the adapter's framework-specific surface. Re-installing
        // over an existing MCP bundle is a no-op so
        // `.withMcp().withMcp()` works.
        if (!self._bundle || self._bundle.name === 'mcp') {
          self._bundle = MCP_BUNDLE
        }
        return this
      },
      writable: true,
      configurable: true,
    })
  }
  if (!Object.prototype.hasOwnProperty.call(S.prototype, 'protectServer')) {
    Object.defineProperty(S.prototype, 'protectServer', {
      value: function protectServer<TServer>(
        this: Shield,
        server: TServer,
        opts: ProtectServerOpts = {},
      ): TServer {
        const onBlock = opts.onBlock ?? 'raise'
        // The base Shield's `protectTool(name, params, fn)` consumes
        // the verdict internally so the pendingResolutionSink option
        // is ignored on this path; use `MCPShield.protectServer` (or
        // wire `shield.protectTool` calls directly) when a structured
        // pending_resolution surface is required.
        void opts.pendingResolutionSink
        _walkServerTools(server, (name, fn) => {
          return _wrapWithShield(this, name, fn, onBlock)
        })
        return server
      },
      writable: true,
      configurable: true,
    })
  }
}

function _installMcpSideEffects(): void {
  if (_mcpSideEffectsInstalled) return
  // Fast path: shield.js has already finished evaluating (the common
  // case for `require('@microsoft/agent-shield')`, where index.ts
  // re-exports from shield.js BEFORE pulling in mcp.js). Install
  // immediately so customers see the augmented prototypes synchronously.
  const SB = _shield.ShieldBuilder
  const S = _shield.Shield
  if (SB && S) {
    _patchPrototypes(SB, S)
    return
  }
  // Cycle path: an adapter-side import (e.g.
  // `require('@microsoft/agent-shield/adapters/langchain')`) triggered
  // the module-graph cycle `langchain → shield → index → mcp → shield`.
  // shield.js is still mid-evaluation up the stack, so its `exports`
  // object exists but `ShieldBuilder` / `Shield` are placeholder
  // `void 0` slots. Deferring via `queueMicrotask` is not enough in
  // pure CJS — microtasks do not drain in between synchronous customer
  // statements, so code like
  //   require('.../adapters/langchain'); Shield.fromYaml(p).withMcp()
  // would see `withMcp` as undefined on the prototype.
  //
  // Strategy: hook the shield module's `exports` directly with
  // accessor descriptors that fire the install the moment shield.ts
  // assigns `exports.Shield = Shield` and
  // `exports.ShieldBuilder = ShieldBuilder` at the end of its own
  // top-level evaluation, *before* control unwinds back to the
  // customer's `require()` call.
  //
  // This is only safe in environments where:
  //   (1) the imported namespace IS the underlying CJS exports object
  //       (true under tsc + Node thanks to `__importStar`'s
  //       `__esModule` short-circuit), AND
  //   (2) the current `Shield` / `ShieldBuilder` slots are plain data
  //       descriptors (placeholder `void 0`s from tsc's CJS preamble).
  //
  // Under vitest / Vite the test transformer hands us an ESM-style
  // namespace where each named export is already an accessor reading
  // live bindings off the underlying module record. Replacing those
  // accessors would sever the live-binding link and pin the value to
  // whatever stale snapshot we captured — which is exactly the
  // regression that surfaced for plain `import { Shield } from
  // '../shield.js'` consumers under vitest. Detect that shape and
  // fall back to the (microtask) deferral path, which is sufficient
  // there because ESM cycle resolution finishes before any test body
  // runs and the microtask drains in between modules.

  const shieldExports = _shield as unknown as Record<string, unknown>
  const sbDesc = Object.getOwnPropertyDescriptor(shieldExports, 'ShieldBuilder')
  const sDesc = Object.getOwnPropertyDescriptor(shieldExports, 'Shield')
  const canHookExports =
    !!sbDesc &&
    !!sDesc &&
    sbDesc.configurable === true &&
    sDesc.configurable === true &&
    // Plain data descriptors (`exports.X = void 0`) have `writable`
    // defined; ESM-style live-binding accessor descriptors have
    // `get`/`set` instead.
    typeof sbDesc.get !== 'function' &&
    typeof sDesc.get !== 'function'

  if (canHookExports) {
    let _sb: unknown = shieldExports.ShieldBuilder
    let _s: unknown = shieldExports.Shield
    const _trigger = (): void => {
      if (_mcpSideEffectsInstalled) return
      if (_sb && _s) {
        _patchPrototypes(_sb as typeof ShieldBuilder, _s as typeof Shield)
      }
    }
    Object.defineProperty(shieldExports, 'ShieldBuilder', {
      configurable: true,
      enumerable: true,
      get: () => _sb,
      set: (v: unknown) => {
        _sb = v
        _trigger()
      },
    })
    Object.defineProperty(shieldExports, 'Shield', {
      configurable: true,
      enumerable: true,
      get: () => _s,
      set: (v: unknown) => {
        _s = v
        _trigger()
      },
    })
  }

  // Belt-and-braces: defer one microtask in case
  //   (a) the exports object is an ESM namespace (live bindings) where
  //       we deliberately skipped the setter hook above, or
  //   (b) a future shield.ts refactor switches to a publication shape
  //       (e.g. `Object.defineProperty(exports, 'Shield', { get })`)
  //       that bypasses the assignment-trigger setter.
  // Customer Pattern A always has at least one `await` (e.g.
  // `await Shield.fromYaml(p).withMcp().build()`) which drains the
  // microtask queue before any `withMcp`-typed call site.
  queueMicrotask(() => {
    if (_mcpSideEffectsInstalled) return
    const SB2 = _shield.ShieldBuilder
    const S2 = _shield.Shield
    if (SB2 && S2) _patchPrototypes(SB2, S2)
  })
}

_installMcpSideEffects()
