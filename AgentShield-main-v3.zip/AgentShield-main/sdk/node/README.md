# Agent Shield — Node.js SDK

Node.js bindings for [Agent Shield](https://github.com/microsoft/AgentShield), an open specification and reference implementation for runtime security controls on AI agents. Loads a [`.guardrails.yaml`](../../spec/SPECIFICATION.md) contract and enforces it across **5 validation stages** (Input → State → Tool execution → Post-tool → Output).

The Node SDK is a thin [`napi-rs`](https://napi.rs) layer over the Rust `agent_shield_core` plus a small camelCase TypeScript facade. All validation logic lives in Rust; the Node side translates shapes and exposes idiomatic JS / TS APIs.

## Install

> **Install today (none of the public-registry commands are live yet).** `npm install @microsoft/agent-shield` 404s — releases are currently private GitHub Actions artifacts. Use the **source install** until the project publishes externally:

```bash
git clone https://github.com/microsoft/AgentShield.git
cd AgentShield/sdk/node
npm install
npm run build           # napi-rs build (requires Rust toolchain)
npm run build:wrapper   # TypeScript compile + copy native artifacts

# Then in your project, install against the repo path:
npm install /absolute/path/to/AgentShield/sdk/node
```

Requires **Node.js >= 20.19** and a working **Rust toolchain** (`rustup`) for the native build. The same source-install pattern is documented for every SDK in [QUICKSTART §2 — Install the SDK](../../QUICKSTART.md#2-install-the-sdk).

If you're integrating with LangChain.js, the following peer-dependency set is tested and resolves cleanly today:

```bash
npm install langchain@^1 @langchain/core@^1.1 @langchain/openai@^1 @langchain/community@^1
```

(Mixing `@langchain/core@^0.3` with `@langchain/community@^1` will hit an `ERESOLVE` because `@langchain/community@1.x` requires `@langchain/core@^1.1`.)

<details>
<summary><b>When public packages ship</b> — not yet runnable</summary>

```bash
npm install @microsoft/agent-shield
```

The package is currently `"private": true` in `package.json` and is **not on npm**. See [QUICKSTART — When public packages ship](../../QUICKSTART.md#when-public-packages-ship) for the consumer-facing shape of the future published command.

</details>

## Quick start

```typescript
import { Shield, currentUserInput } from '@microsoft/agent-shield'
import '@microsoft/agent-shield/adapters/langchain'  // side-effect import: registers bundle

const shield = await Shield.fromYaml('.guardrails.yaml')
  .withLangchain()
  .withClient(myLangChainModel)
  .build()

const guarded = shield.guard(myAgent)
const result  = await guarded.invoke('user input')
```

> **Using OpenAI Agents (`@openai/agents`) or Anthropic Agents (`@anthropic-ai/sdk`) instead of LangChain?** Those SDKs own the agent loop themselves and do not expose an agent-object boundary, so the entry-point is `shield.runOpenaiAgent({...})` / `shield.runAnthropicAgent({...})` rather than `shield.guard()`. See [Pattern A](#pattern-a--guard-the-agent-loop-full-coverage) below.

**Before shipping:** read [Post-tool limits and dangerous patterns](../../docs/POST_TOOL_LIMITS.md) — it covers what AgentShield does and does not guarantee.

## Three integration patterns

The same conceptual model — **Patterns A / B / C** — applies across all four AgentShield SDKs (Python, Node, Rust, .NET); the *implementation shape* matches each ecosystem's idiomatic middleware surface. In Node, that means agent-object wrapping for frameworks that have one, and `shield.run(thunk)` boundaries for opaque loops.

### Pattern A — Guard the agent loop (full coverage)

AgentShield runs all 5 validation stages around the agent loop. The integration shape matches each framework's native middleware surface, so the entry-point differs by adapter — see the table below.

| Framework | Pattern A entry-point | Side-effect import |
|---|---|---|
| **LangChain.js** | `shield.guard(agent)` | `@microsoft/agent-shield/adapters/langchain` |
| **OpenAI Agents SDK** (`@openai/agents`) | `shield.runOpenaiAgent({...})` | `@microsoft/agent-shield/adapters/openai_agents` |
| **Anthropic Agents SDK** (`@anthropic-ai/sdk`) | `shield.runAnthropicAgent({...})` | `@microsoft/agent-shield/adapters/anthropic_agents` |

**LangChain.js** — wrap the agent object you already have:

```typescript
import { Shield } from '@microsoft/agent-shield'
import '@microsoft/agent-shield/adapters/langchain'

const shield = await Shield.fromYaml('.guardrails.yaml')
  .withLangchain()
  .withClient(model)
  .build()

const guarded = shield.guard(agent)
const result  = await guarded.invoke('user input')   // Stages 1 + 5; wrapped tools run Stages 2/3/4
```

**OpenAI Agents SDK** — the adapter drives `@openai/agents`'s `Runner.run` loop for you:

```typescript
import OpenAI from 'openai'
import { Shield } from '@microsoft/agent-shield'
import '@microsoft/agent-shield/adapters/openai_agents'

const shield = await Shield.fromYaml('.guardrails.yaml').withOpenaiAgents().build()
const text   = await shield.runOpenaiAgent({
  client: new OpenAI(),
  model: 'gpt-4o-mini',
  tools,                            // raw OpenAI chat-tool defs or pre-built FunctionTool[]
  dispatchToolCall,                 // (name, args) => Promise<unknown> — required for raw chat-tool defs
  messages: [{ role: 'user', content: 'user input' }],
})
```

**Anthropic Agents SDK** — same shape, mirroring `client.beta.messages.toolRunner(...)`:

```typescript
import Anthropic from '@anthropic-ai/sdk'
import { Shield } from '@microsoft/agent-shield'
import '@microsoft/agent-shield/adapters/anthropic_agents'

const shield = await Shield.fromYaml('.guardrails.yaml').withAnthropic().build()
const text   = await shield.runAnthropicAgent({
  client: new Anthropic(), model: 'claude-3-5-sonnet-latest', tools, dispatchTool,
  messages: [{ role: 'user', content: 'user input' }],
})
```

#### Why two different APIs?

LangChain.js exposes a uniform agent object (`Runnable`) the adapter can wrap end-to-end, so the bundle ships an `AgentBoundary` and `shield.guard(agent)` works. The OpenAI Agents and Anthropic Agents SDKs own the model → tool-call → model loop themselves (via `Runner.run` and `BetaToolRunner`) and do not expose an equivalent agent-object boundary — so the adapters expose `runOpenaiAgent({...})` / `runAnthropicAgent({...})` helpers that mirror each SDK's runner shape directly. Calling `shield.guard(agent)` on a non-LangChain bundle throws a clear error pointing at the right helper. This asymmetry is intentional: per-ecosystem adapter shapes match each SDK's idiomatic middleware surface rather than forcing a uniform API.

#### Pending-resolution envelope (cross-SDK casing)

When a Stage 2/3/4 verdict is blocked because a resolver is awaiting external input (e.g. a `kind: human` resolver waiting on operator approval, or a `kind: tool` resolver waiting on the agent to invoke a named tool), the verdict carries a structured **pending-resolution envelope** that the host UI reads via `shield.lastPendingResolution()` (Node) / `shield.last_pending_resolution()` (Python). The host writes the manager decision back through `session.setVariable(...)` (Node) / `session.set_variable(...)` (Python) — or wires a custom resolver-response envelope when implementing a `HumanResolver` directly.

**Field names are stable across SDKs; casing follows each ecosystem's idiom.** Node / TypeScript uses `camelCase`, Python uses `snake_case`, .NET uses `PascalCase`. A polyglot UI tier that consumes envelopes from multiple SDK runtimes must translate at the SDK boundary, not assume one casing wins.

| Canonical field | Node / TypeScript (`camelCase`) | Python (`snake_case`) | Direction |
|---|---|---|---|
| `kind` | `kind` | `kind` | Pending → host (resolver kind: `"human"`, `"tool"`, `"delegate"`, `"agent"`, `"expression"`) |
| `requestId` / `request_id` | `requestId` | `request_id` | Pending → host (correlation id for the suspended resolution) |
| `tool` | `tool` | `tool` | Pending → host (e.g. `"agent_shield.ask_human"`) |
| `variable` | `variable` | `variable` | Pending → host (target variable the resolver writes on resume) |
| `prompt` | `prompt` | `prompt` | Pending → host (human-readable prompt; may be `null`) |
| `setVariables` / `set_variables` | `setVariables` | `set_variables` | Host → resolver-response envelope (additional variable mutations on `allow`; see `ResolverResponseEnvelope`) |

Node reads the envelope idiomatically:

```typescript
const pending = shield.lastPendingResolution()
if (pending) {
  // pending = { kind: 'human', requestId: '...', tool: '...', variable: '...', prompt: '...' }
  const decision = await promptManagerUi(pending.prompt, { requestId: pending.requestId })
  session.setVariable(pending.variable, decision)   // resume
}
```

Python:

```python
pending = shield.last_pending_resolution()
if pending is not None:
    # pending = {"kind": "human", "request_id": "...", "tool": "...",
    #            "variable": "...", "prompt": "..."}
    decision = await prompt_manager_ui(pending["prompt"], request_id=pending["request_id"])
    session.set_variable(pending["variable"], decision)   # resume
```

This casing asymmetry is intentional per the SDK-shape doctrine — each ecosystem uses its own idiomatic casing (see the project's `.github/copilot-instructions.md` "Per-ecosystem adapter shapes" section). The wire-level `.guardrails.yaml` contract is byte-identical across SDKs; only the host-facing envelope shape follows ecosystem idiom. A polyglot UI tier translates at the SDK boundary:

```typescript
type PendingResolutionAny = {
  kind: string
  tool: string
  variable: string
  prompt?: string | null
  requestId?: string   // Node
  request_id?: string  // Python (when forwarded as JSON from a Python service)
}

function normalizePending(p: PendingResolutionAny) {
  return {
    kind: p.kind,
    tool: p.tool,
    variable: p.variable,
    prompt: p.prompt ?? null,
    requestId: p.requestId ?? p.request_id!,
  }
}
```

### Pattern B — Protect individual tools

When the framework owns the loop tightly and only the tool boundary is wrappable. As with Pattern A, the entry-point matches each ecosystem's native shape:

| Framework | Pattern B entry-point |
|---|---|
| **LangChain.js** | `await shield.protectTools(myTools)` |
| **OpenAI Agents SDK** | `shield.protectOpenaiTools({ dispatchToolCall })` |
| **Anthropic Agents SDK** | `shield.protectAnthropicTools({ dispatchTool })` |

```typescript
// LangChain.js — wraps tool objects in place
import { Shield } from '@microsoft/agent-shield'
import '@microsoft/agent-shield/adapters/langchain'

const shield = await Shield.fromYaml('.guardrails.yaml').withLangchain().build()
const protectedTools = await shield.protectTools(myTools)  // async — returns Promise<TGuarded[]>
// ... pass protectedTools to your agent constructor
```

```typescript
// OpenAI Agents — returns a guarded (name, args) => result dispatcher
import { Shield } from '@microsoft/agent-shield'
import '@microsoft/agent-shield/adapters/openai_agents'

const shield = await Shield.fromYaml('.guardrails.yaml').withOpenaiAgents().build()
const guardedDispatch = shield.protectOpenaiTools({ dispatchToolCall })
// ... call guardedDispatch(name, args) from inside your customer-owned Runner loop
```

### Pattern C — Stage 1 + 5 boundary (opaque loops)

For black-box agent loops you don't control. AgentShield runs Stage 1 (input) and Stage 5 (output) around the call, plus Stage 2/3/4 around individual tool calls if you wrap them with `shield.protectTool`:

```typescript
const shield = await Shield.fromYaml('.guardrails.yaml').withClient(model).build()

try {
  const result = await shield.run(async () => {
    // `currentUserInput()` is the effective value after Stage 1 mutations.
    return await runMyOpaqueAgent(currentUserInput())
  }, { userInput: 'user input' })
} catch (err) {
  if (err instanceof AgentShieldBlocked) {
    // Stage 1 or Stage 5 denied the turn. `err.message` is the
    // canonical `[GUARDRAIL ...]` block string; `err.verdict` is the
    // raw StageVerdict for richer host UX.
    return renderBlockedTurn(err)
  }
  throw err
}

// And for individual tool calls inside the loop:
const safe = await shield.protectTool('send_email', params, async (effective) => {
  return await actuallySend(effective)
})
```

> **Default block handling.** `shield.run` raises `AgentShieldBlocked` when Stage 1 or Stage 5 denies a turn. To opt into string-return behavior, pass `{ onBlock: 'return_blocked' }`.

#### Streaming safety

> **⚠️ DANGER — hand-rolled streaming wrappers around `shield.run` / `shield.runStreamed` are unsafe by construction.**
>
> Stage 5 redaction requires the *full output context* to compute redaction spans. **Per-chunk Stage 5 cannot work** — you cannot know whether a substring is sensitive until you have seen enough surrounding text. **Per-stream-finalize Stage 5 emits raw chunks to the client *before* redaction runs** — the leak has already shipped over the wire by the time the final pass returns.
>
> Only an adapter that owns chunk emission (so it can buffer, validate, and *then* emit the safe-to-emit slice) can stream safely.
>
> **Safe options when a streaming adapter does not exist for your framework:**
>
> 1. Disable streaming and use the buffer-mode response.
> 2. Use the [LiteLLM Proxy plugin](../../docs/integrations/litellm-proxy.md), which enforces Stage 5 in buffer-mode at the gateway.
> 3. Implement a sentinel-only stream and reveal the validated output after Stage 5 returns.
>
> **Streaming-adapter inventory (Node):**
>
> | Framework | Streaming adapter | Status |
> |---|---|---|
> | OpenAI Agents SDK | `runOpenaiAgentStreamed` | ✅ Partial — text deltas only |
> | Anthropic Agents SDK | `runAnthropicAgentStreamed` | ✅ Partial — text-delta streaming |
> | LangChain.js | adapter streaming via `shield.guard(agent).stream(...)` | ✅ Partial — text chunks only |
> | Custom / opaque loops | none | ❌ Not safe — pick one of the 3 safe options above |
>
> See [`docs/adapter-mediated-paths.md`](../../docs/adapter-mediated-paths.md) for the cross-SDK matrix and [`docs/runbooks/incident-streaming-leak.md`](../../docs/runbooks/incident-streaming-leak.md) for incident response.

#### Pattern C block handling

`shield.run` accepts an `onBlock` option:

```typescript
// Default (recommended): a Stage 1/5 block raises AgentShieldBlocked.
await shield.run(thunk, { userInput })

// Opt into string-return form.
const result = await shield.run(thunk, { userInput, onBlock: 'return_blocked' })
if (typeof result === 'string' && result.startsWith('[GUARDRAIL')) {
  return renderBlockedTurn(result)
}
```

The default raises so host code cannot mistake a block for a valid agent result; string-return mode is explicit.

## YAML auto-wiring

YAML configurations drive everything; no host code needed for the common case:

- **Runtime-bound `kind: human` handlers** — register the active handler in host code (for example `registerHumanResolver(...)`); YAML no longer names providers.
- **LLM clients** — `configurations: - {id, type: llm, provider, model, api_key_env}` auto-wire HTTP-based callers.
- **Classifiers** — `configurations: - {id, type: classifier, provider: ...}` auto-wire HTTP-based callers (the supported set lives in the Rust core under `agent_shield_core::classifiers`).

## Observability

```typescript
import { Shield, ConsoleObservabilityProvider } from '@microsoft/agent-shield'

const shield = await Shield.fromYaml('.guardrails.yaml')
  .withClient(model)
  .withObservability(new ConsoleObservabilityProvider())
  .build()
```

Every emitted event carries [OpenTelemetry GenAI semantic-convention](https://opentelemetry.io/docs/specs/semconv/gen-ai/) attributes (`gen_ai.system="agent_shield"`, `gen_ai.operation.name="guard.<stage>"`, `gen_ai.response.finish_reason="content_filter"` on blocks), so any OTel exporter (LangSmith, Phoenix, Honeycomb) sees AgentShield events with the same shape it sees other GenAI telemetry.

For a custom provider, register any object with an `emit(event)` method.

## Lower-level API

For framework-agnostic code, drop down to `RuntimeBuilder` directly:

```typescript
import { RuntimeBuilder } from '@microsoft/agent-shield'

const runtime = RuntimeBuilder.fromYaml('.guardrails.yaml').build()
const session = runtime.newSession({ userId: 'u1', correlationId: 'c1' })

const v1 = await session.validateInput('user prompt')
if (!v1.allowed) throw new Error(v1.reason)

const { verdict: v2, params } = await session.validateToolCall('send_email', toolParams)
if (!v2.allowed) throw new Error(v2.reason)
```

## Building from source

```bash
cd sdk/node
npm install
npm run build           # napi-rs build (requires Rust toolchain)
npm run build:wrapper   # TypeScript compile + copy native artifacts into dist/
npx vitest run          # tests
```

### Local / `file:` installs

If you point at a local checkout from another project:

```json
{ "dependencies": { "agent-shield": "file:/path/to/AgentShield/sdk/node" } }
```

`npm install` runs the package's `prepare` script automatically, which calls
`build:wrapper` (TypeScript compile) on your behalf. You do **not** need to
pre-build `dist/` in the source tree.

The native (`napi-rs`) binary is **not** rebuilt automatically — that
requires a Rust toolchain and is treated as a contributor-owned step.
For a `file:` install to work end-to-end, the source tree must already
contain a built `agent-shield.<triple>.node` (run `npm run build` once
in `sdk/node/`). If it does not, `require('@microsoft/agent-shield')`
will succeed for the JS surface but fail at native load with
`Cannot find module '@microsoft/agent-shield-<triple>'` — clear hint
that you need either the per-triple npm package or a local `npm run build`.

If you pass `--ignore-scripts` to `npm install` (some lockfile/security
workflows do), the `prepare` step is skipped and `dist/` will be missing.
Either drop `--ignore-scripts`, or run `npm run build && npm run build:wrapper`
manually inside `node_modules/agent-shield/` afterward.

## More

- [Specification](../../spec/SPECIFICATION.md) — the source of truth for `.guardrails.yaml` semantics.
- [Expression-language reference](../../spec/expressions/LANGUAGE.md).
- [Examples](../../examples/) — bank-manager, sensitive-documents, IFC, ask-human MCP server.
