import '../_support/cases/e2e/mcp/mcpPendingResolution.js'
import '../_support/cases/e2e/mcp/mcpServer.js'
