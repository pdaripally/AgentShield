
import { describe, expect, it } from 'vitest'
import { RuntimeBuilder, Shield, AgentShieldBlocked } from '../../index.js'

const STAGE1_BLOCK_YAML = `
metadata:
  name: stage1-block
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
input_validation:
  guard_policies:
    - name: block_ssn
      evaluate_when:
        - patterns:
            - "SSN \\\\d{3}-\\\\d{2}-\\\\d{4}"
          reason: "SSNs are blocked at Stage 1 for this test"
      action: "block"
`

const STAGE5_BLOCK_YAML = `
metadata:
  name: stage5-block
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
output_validation:
  guard_policies:
    - name: block_topsecret
      evaluate_when:
        - patterns:
            - "TOPSECRET-[A-Z0-9]+"
          reason: "TOPSECRET tokens must not appear in output"
      action: "block"
`

function buildShield(yaml: string): Shield {
  const runtime = RuntimeBuilder.fromYamlStrings([yaml]).build()
  return new Shield(runtime)
}

describe('Shield.run default-raise', () => {
  describe('default behaviour (no onBlock supplied)', () => {
    it('Stage 1 block raises AgentShieldBlocked', async () => {
      const shield = buildShield(STAGE1_BLOCK_YAML)
      let thunkRan = false
      await expect(
        shield.run(
          async () => {
            thunkRan = true
            return 'should not see this'
          },
          { userInput: 'SSN 123-45-6789 hi' },
        ),
      ).rejects.toBeInstanceOf(AgentShieldBlocked)
      expect(thunkRan).toBe(false)
    })

    it('Stage 1 block exception carries the canonical block message', async () => {
      const shield = buildShield(STAGE1_BLOCK_YAML)
      try {
        await shield.run(async () => 'unreachable', {
          userInput: 'SSN 999-88-7777 oops',
        })
        throw new Error('expected AgentShieldBlocked to be thrown')
      } catch (err) {
        expect(err).toBeInstanceOf(AgentShieldBlocked)
        const msg = (err as AgentShieldBlocked).message
        expect(msg).toContain('[GUARDRAIL')
      }
    })

    it('Stage 5 block raises AgentShieldBlocked', async () => {
      const shield = buildShield(STAGE5_BLOCK_YAML)
      await expect(
        shield.run(async () => 'here is the TOPSECRET-ABCD token'),
      ).rejects.toBeInstanceOf(AgentShieldBlocked)
    })
  })

  describe('legacy opt-in (onBlock: "return_blocked")', () => {
    it('Stage 1 block returns the canonical string', async () => {
      const shield = buildShield(STAGE1_BLOCK_YAML)
      const result = await shield.run(async () => 'unreachable', {
        userInput: 'SSN 555-44-3333 please',
        onBlock: 'return_blocked',
      })
      expect(typeof result).toBe('string')
      expect(result as string).toMatch(/^\[GUARDRAIL/)
    })

    it('Stage 5 block returns the canonical string', async () => {
      const shield = buildShield(STAGE5_BLOCK_YAML)
      const result = await shield.run(
        async () => 'here is TOPSECRET-XYZ token',
        { onBlock: 'return_blocked' },
      )
      expect(typeof result).toBe('string')
      expect(result as string).toMatch(/^\[GUARDRAIL/)
    })
  })

  describe('allow path is unchanged', () => {
    it('non-blocking output returns the thunk result (default)', async () => {
      const shield = buildShield(STAGE5_BLOCK_YAML)
      const result = await shield.run(async () => 'totally benign output')
      expect(result).toBe('totally benign output')
    })

    it('non-blocking output returns the thunk result (legacy)', async () => {
      const shield = buildShield(STAGE5_BLOCK_YAML)
      const result = await shield.run(async () => 'totally benign output', {
        onBlock: 'return_blocked',
      })
      expect(result).toBe('totally benign output')
    })
  })
})
