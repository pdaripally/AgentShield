
import { describe, expect, it } from 'vitest'
import {
  RuntimeBuilder,
  Shield,
  AgentShieldBlocked,
  AgentShieldLensIncompleteError,
  AgentShieldUnsupportedOutputTypeError,
} from '../../index.js'

const STAGE5_REDACT_YAML = `
metadata:
  name: stage5-redact-emails
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
output_validation:
  guard_policies:
    - name: redact_emails
      evaluate_when:
        - patterns:
            - "[a-z0-9._-]+@[a-z0-9-]+\\\\.[a-z.]+"
          reason: "redact emails at Stage 5"
      action: redact
      replacement: "[REDACTED]"
`

const STAGE5_BLOCK_YAML = `
metadata:
  name: stage5-block-topsecret
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
output_validation:
  guard_policies:
    - name: block_topsecret
      evaluate_when:
        - patterns:
            - "TOPSECRET-[A-Z0-9]+"
          reason: "TOPSECRET tokens must not appear in output"
      action: "block"
`

function buildShield(yaml: string): Shield {
  const runtime = RuntimeBuilder.fromYamlStrings([yaml]).build()
  return new Shield(runtime)
}

class FrameworkResult {
  text: string
  toolResults: unknown[]
  constructor(text: string, toolResults: unknown[] = []) {
    this.text = text
    this.toolResults = toolResults
  }
}

describe('Shield.run default rejects non-string outputs', () => {
  it('arbitrary class result raises AgentShieldUnsupportedOutputTypeError', async () => {
    const shield = buildShield(STAGE5_REDACT_YAML)

    await expect(
      shield.run(async () => new FrameworkResult('email: alice@example.com')),
    ).rejects.toThrowError(AgentShieldUnsupportedOutputTypeError)
  })

  it('error carries resultType and migration-hint message', async () => {
    const shield = buildShield(STAGE5_REDACT_YAML)

    let caught: unknown
    try {
      await shield.run(async () => new FrameworkResult('hi'))
    } catch (err) {
      caught = err
    }
    expect(caught).toBeInstanceOf(AgentShieldUnsupportedOutputTypeError)
    const e = caught as AgentShieldUnsupportedOutputTypeError
    expect(e.resultType).toBe('FrameworkResult')
    expect(e.message).toMatch(/extractText/)
    expect(e.message).toMatch(/Stage 5/)
  })

  it('plain object literal also raises (no .text auto-extract)', async () => {
    const shield = buildShield(STAGE5_REDACT_YAML)

    await expect(
      shield.run(async () => ({ text: 'alice@example.com' })),
    ).rejects.toThrowError(AgentShieldUnsupportedOutputTypeError)
  })
})

describe('Shield.run extractText opt-in with paired setText', () => {
  it('redacts via extractText and writes back into .text', async () => {
    const shield = buildShield(STAGE5_REDACT_YAML)

    const result = await shield.run(
      async () => new FrameworkResult('email: alice@example.com'),
      {
        extractText: (r) => r.text,
        setText: (r, t) => {
          r.text = t
          return r
        },
      },
    )
    expect(result).toBeInstanceOf(FrameworkResult)
    const fw = result as FrameworkResult
    expect(fw.text).not.toContain('alice@example.com')
    expect(fw.text).toContain('[REDACTED]')
    expect(fw.toolResults).toEqual([])
  })

  it('extractText returning null|undefined skips Stage 5 cleanly', async () => {
    const shield = buildShield(STAGE5_REDACT_YAML)

    const result = await shield.run(
      async () => ({ text: null } as { text: string | null }),
      {
        extractText: (r) => r.text,
        setText: (r, t) => {
          r.text = t
          return r
        },
      },
    )
    expect(result).toEqual({ text: null })
  })

  it('extractText with empty string passes through', async () => {
    const shield = buildShield(STAGE5_REDACT_YAML)

    const result = await shield.run(
      async () => new FrameworkResult(''),
      {
        extractText: (r) => r.text,
        setText: (r, t) => {
          r.text = t
          return r
        },
      },
    )
    const fw = result as FrameworkResult
    expect(fw.text).toBe('')
  })
})

describe('Shield.run extractText with custom setText', () => {
  it('custom setText returns a new object for immutable results', async () => {
    const shield = buildShield(STAGE5_REDACT_YAML)

    type Frozen = { readonly text: string; readonly id: number }
    const result = await shield.run(
      async (): Promise<Frozen> => ({ text: 'email: alice@example.com', id: 7 }),
      {
        extractText: (r) => r.text,
        setText: (r, t) => ({ ...r, text: t }),
      },
    )
    expect(result).toMatchObject({ id: 7 })
    expect((result as Frozen).text).toContain('[REDACTED]')
    expect((result as Frozen).text).not.toContain('alice@example.com')
  })
})

describe('Shield.run extractText routes block through onBlock', () => {
  it('Stage 5 block on extracted text raises AgentShieldBlocked by default', async () => {
    const shield = buildShield(STAGE5_BLOCK_YAML)

    await expect(
      shield.run(
        async () => new FrameworkResult('TOPSECRET-ABCD leaked'),
        {
          extractText: (r) => r.text,
          setText: (r, t) => {
            r.text = t
            return r
          },
        },
      ),
    ).rejects.toThrowError(AgentShieldBlocked)
  })

  it('Stage 5 block returns string under onBlock:return_blocked', async () => {
    const shield = buildShield(STAGE5_BLOCK_YAML)

    const result = await shield.run(
      async () => new FrameworkResult('TOPSECRET-XYZ found'),
      {
        extractText: (r) => r.text,
        setText: (r, t) => {
          r.text = t
          return r
        },
        onBlock: 'return_blocked',
      },
    )
    expect(typeof result).toBe('string')
    expect(result as string).toMatch(/^\[GUARDRAIL/)
  })
})

describe('native shapes unchanged (regression)', () => {
  it('string return continues to redact at Stage 5', async () => {
    const shield = buildShield(STAGE5_REDACT_YAML)

    const result = await shield.run(async () => 'alice@example.com here')
    expect(typeof result).toBe('string')
    expect(result as string).toContain('[REDACTED]')
  })

  it('null return passes through', async () => {
    const shield = buildShield(STAGE5_REDACT_YAML)

    const result = await shield.run(async () => null)
    expect(result).toBeNull()
  })

  it('undefined return passes through', async () => {
    const shield = buildShield(STAGE5_REDACT_YAML)

    const result = await shield.run(async () => undefined)
    expect(result).toBeUndefined()
  })
})

describe('extractText / setText input validation', () => {
  it('non-function extractText raises TypeError', async () => {
    const shield = buildShield(STAGE5_REDACT_YAML)

    await expect(
      shield.run(async () => new FrameworkResult('hi'), {
 // @ts-expect-error — runtime guard test
        extractText: 'not a function',
      }),
    ).rejects.toThrowError(TypeError)
  })

  it('non-function setText raises TypeError', async () => {
    const shield = buildShield(STAGE5_REDACT_YAML)

    await expect(
      shield.run(async () => new FrameworkResult('hi'), {
        extractText: (r) => r.text,
 // @ts-expect-error — runtime guard test
        setText: 'not a function',
      }),
    ).rejects.toThrowError(TypeError)
  })

  it('extractText returning non-string raises TypeError post-execute', async () => {
    const shield = buildShield(STAGE5_REDACT_YAML)

    await expect(
      shield.run(async () => new FrameworkResult('hi'), {
 // @ts-expect-error — deliberately wrong return type
        extractText: () => 12345,
        setText: (r, t) => {
          r.text = t
          return r
        },
      }),
    ).rejects.toThrowError(TypeError)
  })
})


type FakeLitellmResponse = {
  choices: Array<{ message: { content: string } }>
}

function fakeLitellmResponse(content: string): FakeLitellmResponse {
  return { choices: [{ message: { content } }] }
}

describe('extractText without setText fail-closed', () => {
  it('extractText alone raises AgentShieldLensIncompleteError', async () => {
    const shield = buildShield(STAGE5_REDACT_YAML)

    await expect(
      shield.run(
        async () => fakeLitellmResponse('email: alice@example.com'),
        {
          extractText: (r) => r.choices[0].message.content,
        },
      ),
    ).rejects.toThrowError(AgentShieldLensIncompleteError)
  })

  it('error message points at both setText and setText:null paths', async () => {
    const shield = buildShield(STAGE5_REDACT_YAML)

    let caught: unknown
    try {
      await shield.run(async () => fakeLitellmResponse('hi'), {
        extractText: (r) => r.choices[0].message.content,
      })
    } catch (err) {
      caught = err
    }
    expect(caught).toBeInstanceOf(AgentShieldLensIncompleteError)
    const msg = (caught as Error).message
    expect(msg).toMatch(/setText/)
    expect(msg).toMatch(/setText: null/)
    expect(msg).toMatch(/extractText/)
  })

  it('raise is eager — fires before the thunk executes', async () => {
    const shield = buildShield(STAGE5_REDACT_YAML)
    let thunkCalled = false

    await expect(
      shield.run(
        async () => {
          thunkCalled = true
          return new FrameworkResult('hi')
        },
        { extractText: (r) => r.text },
      ),
    ).rejects.toThrowError(AgentShieldLensIncompleteError)

    expect(thunkCalled).toBe(false)
  })
})

describe('setText:null is the acknowledge-and-override path', () => {
  it('advisory mode runs Stage 5 but does not mutate the result', async () => {
    const shield = buildShield(STAGE5_REDACT_YAML)

    const original = fakeLitellmResponse('email: alice@example.com')
    const result = await shield.run(async () => original, {
      extractText: (r) => r.choices[0].message.content,
      setText: null,
    })

    expect(result).toBe(original)
    expect((result as FakeLitellmResponse).choices[0].message.content).toBe(
      'email: alice@example.com',
    )
    expect((result as Record<string, unknown>).text).toBeUndefined()
  })

  it('advisory mode still routes Stage 5 block through onBlock', async () => {
    const shield = buildShield(STAGE5_BLOCK_YAML)

    await expect(
      shield.run(async () => fakeLitellmResponse('TOPSECRET-ABCD leaked'), {
        extractText: (r) => r.choices[0].message.content,
        setText: null,
      }),
    ).rejects.toThrowError(AgentShieldBlocked)
  })
})

describe('symmetric lens (extractText + setText) still works', () => {
  it('redacts and writes back at the customer-named location', async () => {
    const shield = buildShield(STAGE5_REDACT_YAML)

    const original = fakeLitellmResponse('email: alice@example.com')
    const result = await shield.run(async () => original, {
      extractText: (r) => r.choices[0].message.content,
      setText: (r, t) => {
        r.choices[0].message.content = t
        return r
      },
    })

    expect(result).toBe(original)
    const content = (result as FakeLitellmResponse).choices[0].message.content
    expect(content).not.toContain('alice@example.com')
    expect(content).toContain('[REDACTED]')
    expect((result as Record<string, unknown>).text).toBeUndefined()
  })
})

describe('regression: paths unaffected by lens plumbing', () => {
  it('string return path still redacts (no lens required)', async () => {
    const shield = buildShield(STAGE5_REDACT_YAML)
    const result = await shield.run(async () => 'alice@example.com here')
    expect(typeof result).toBe('string')
    expect(result as string).toContain('[REDACTED]')
  })

  it('non-string result without extractText still raises default', async () => {
    const shield = buildShield(STAGE5_REDACT_YAML)
    await expect(
      shield.run(async () => fakeLitellmResponse('email: alice@example.com')),
    ).rejects.toThrowError(AgentShieldUnsupportedOutputTypeError)
  })
})
