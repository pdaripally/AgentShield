import '../_support/cases/behavior/runtimeSafety/prototypeIsolation.js'
import '../_support/cases/behavior/runtimeSafety/ffiBoundary.js'
import '../_support/cases/behavior/runtimeSafety/sideEffectImports.js'
