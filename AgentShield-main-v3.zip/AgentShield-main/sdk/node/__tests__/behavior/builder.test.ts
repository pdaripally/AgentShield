import '../_support/cases/behavior/builder/builderLifecycle.js'
import '../_support/cases/behavior/builder/builderClientBinding.js'
