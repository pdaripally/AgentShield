import { describe, expect, it } from 'vitest'
import { RuntimeBuilder } from '../../index.js'
import type { ShieldLogEvent } from '../../index.js'
import { waitForIncident } from '../_support/observability.js'

const blockOutputYaml = (name: string) => `
metadata:
  name: "${name}-block-output"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Block confidential output."]
  forbidden: ["Leak secrets."]
output_validation:
  guard_policies:
    - name: "block-confidential"
      evaluate_when:
        - pattern: "CONFIDENTIAL"
          reason: "Output contains confidential marker."
      action: block
`

const toolYaml = (name: string, toolName: string, description: string) => `
metadata:
  name: "${name}-bypass-paths"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Guard ${name} tool calls."]
  forbidden: ["Leak secrets."]
resources:
  tools:
    - name: "${toolName}"
      description: "${description}"
      permission: "read_only"
`

async function makeSession(yaml: string) {
  const captured: ShieldLogEvent[] = []
  const runtime = RuntimeBuilder.fromYamlStrings([yaml])
    .registerProvider((event) => captured.push(event as ShieldLogEvent))
    .build()
  const session = runtime.newSession()
  await session.beginTurn()
  return { runtime, session, captured }
}

const adapterCases = [
  {
    adapter: 'OpenAI Agents',
    yaml: toolYaml('OpenAI Agents', 'web_search', 'Search the web.'),
    toolName: 'web_search',
    callParams: { query: 'test' },
    output: { results: ['r1'] },
    callId: 'oai_call_001',
    malformedId: 'oai_malformed_001',
    invalidToolCallId: undefined,
    streamingYaml: blockOutputYaml('openai-agents'),
  },
  {
    adapter: 'Anthropic Agents',
    yaml: toolYaml('Anthropic Agents SDK', 'calculator', 'Performs arithmetic.'),
    toolName: 'calculator',
    callParams: { op: 'add', a: 1, b: 2 },
    output: { result: 3 },
    callId: 'ant_call_001',
    malformedId: 'ant_malformed_001',
    invalidToolCallId: undefined,
    streamingYaml: undefined,
  },
  {
    adapter: 'LangChain',
    yaml: toolYaml('LangChain', 'search', 'Web search.'),
    toolName: 'search',
    callParams: { query: 'hello' },
    output: { results: ['r1'] },
    callId: 'lc_call_001',
    malformedId: 'lc_malformed_001',
    invalidToolCallId: 42,
    streamingYaml: blockOutputYaml('langchain'),
  },
  {
    adapter: 'MCP',
    yaml: toolYaml('MCP', 'mcp_lookup', 'Lookup data.'),
    toolName: 'mcp_lookup',
    callParams: { query: 'hello' },
    output: { result: 'ok' },
    callId: 'mcp_call_001',
    malformedId: 'mcp_malformed_001',
    invalidToolCallId: null,
    streamingYaml: undefined,
  },
]

describe.each(adapterCases)('$adapter adapter bypass paths', (adapterCase) => {
  it('guarded tool call produces an invocation hash through Stage 3 and Stage 4', async () => {
    const { session } = await makeSession(adapterCase.yaml)

    const call = await session.validateToolCall(
      adapterCase.toolName,
      adapterCase.callParams,
      adapterCase.callId,
    )
    expect(call.verdict.allowed).toBe(true)
    expect(call.verdict.invocationHash).toBeTruthy()

    const out = await session.validateToolOutput(
      adapterCase.toolName,
      adapterCase.output,
      adapterCase.callId,
    )
    expect(out.verdict.allowed).toBe(true)
    expect(out.verdict.invocationHash).toBeTruthy()
  })

  it('direct Stage 4 without Stage 3 fails closed with no invocation hash', async () => {
    const { session } = await makeSession(adapterCase.yaml)
    const out = await session.validateToolOutput(adapterCase.toolName, adapterCase.output, 'missing')
    expect(out.verdict.allowed).toBe(false)
    expect(out.verdict.policy).toBe('<binding>')
    expect(out.verdict.invocationHash).toBeNull()
  })

  it('raw dispatch without Stage 3 emits the unguarded-dispatch incident', async () => {
    const { runtime, session, captured } = await makeSession(adapterCase.yaml)
    const out = await session.validateToolOutput(adapterCase.toolName, adapterCase.output, 'missing')
    expect(out.verdict.allowed).toBe(false)
    const incident = await waitForIncident(runtime, captured, 'incident.unguarded_tool_dispatch')
    expect(incident).toBeTruthy()
  })

  it('null params normalize to an empty object and still produce an invocation hash', async () => {
    const { session } = await makeSession(adapterCase.yaml)
    const outcome = await session.validateToolCall(
      adapterCase.toolName,
      null as any,
      adapterCase.malformedId,
    )
    expect(outcome.verdict.allowed).toBe(true)
    expect(outcome.verdict.invocationHash).toBeTruthy()
  })

  if (adapterCase.invalidToolCallId !== undefined) {
    it('non-string toolCallId is rejected at the API boundary', async () => {
      const { session } = await makeSession(adapterCase.yaml)
      await expect(
        session.validateToolCall(adapterCase.toolName, {}, adapterCase.invalidToolCallId as any),
      ).rejects.toThrow()
    })
  }

  if (adapterCase.streamingYaml) {
    it('streaming Stage 5 deny emits the stream-aborted incident', async () => {
      const { runtime, session, captured } = await makeSession(adapterCase.streamingYaml)
      const guard = session.streamingSession('output')
      await guard.push('Partial text then CONFIDENTIAL marker.')
      const result = await guard.finish()
      expect(result.action).toBe('stop')
      const incident = await waitForIncident(runtime, captured, 'incident.stream_aborted')
      expect(incident).toBeTruthy()
    })
  }
})
