import type { ShieldLogEvent } from '../../index.js'

export async function waitForIncident(
  runtime: { flushObservability: () => void },
  captured: ShieldLogEvent[],
  eventId: string,
  timeoutMs = 2000,
  pollMs = 5,
): Promise<ShieldLogEvent> {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    runtime.flushObservability()
    const incident = captured.find(
      (event) => event.eventType === 'incident_emitted' && event.eventId === eventId,
    )
    if (incident) return incident
    await new Promise((resolve) => setTimeout(resolve, pollMs))
  }
  throw new Error(`timed out after ${timeoutMs}ms waiting for ${eventId}`)
}
