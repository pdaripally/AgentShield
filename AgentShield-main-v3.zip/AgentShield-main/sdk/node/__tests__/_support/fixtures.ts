import * as fs from 'node:fs'
import * as path from 'node:path'

const FIXTURE_ROOT = path.resolve(__dirname, '..', '.tmp-fixtures')

export function writeYamlFixture(slug: string, fileName: string, yaml: string): string {
  const dir = path.join(FIXTURE_ROOT, slug)
  fs.mkdirSync(dir, { recursive: true })
  const filePath = path.join(dir, fileName)
  fs.writeFileSync(filePath, yaml, 'utf8')
  return filePath
}

export function removeFixtureDir(slug: string): void {
  fs.rmSync(path.join(FIXTURE_ROOT, slug), { recursive: true, force: true })
}
