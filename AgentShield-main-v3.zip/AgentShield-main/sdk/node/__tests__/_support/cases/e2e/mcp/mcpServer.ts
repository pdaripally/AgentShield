
import { describe, expect, it } from 'vitest'
import * as fs from 'node:fs'
import * as os from 'node:os'
import * as path from 'node:path'
import { randomUUID } from 'node:crypto'
import {
  MCPGuardrailBlocked,
  MCPShield,
  MCP_BUNDLE,
  Shield,
  shieldServer,
} from '../../../../../index.js'

function writeYaml(yaml: string, name: string): string {
  const file = path.join(
    os.tmpdir(),
    `agent-shield-test-${name}-${randomUUID()}.guardrails.yaml`,
  )
  fs.writeFileSync(file, yaml, 'utf8')
  return file
}

const MINIMAL_YAML = path.resolve(
  __dirname,
  '..',
  '..',
  '..',
  '..',
  '..',
  '..',
  '..',
  'tests',
  'fixtures',
  'smoke',
  'minimal.guardrails.yaml',
)


describe('Shield.fromYaml(...).withMcp.build', () => {
  it('the documented 3-line drop-in compiles and produces an MCP-capable Shield', () => {
    const shield = Shield.fromYaml(MINIMAL_YAML).withMcp().build()
    expect(shield).toBeInstanceOf(Shield)
    expect(shield.capabilities.framework).toBe('mcp')
    expect(typeof (shield as unknown as { protectServer: unknown }).protectServer).toBe(
      'function',
    )
  })

  it('withMcp is idempotent — chaining twice still produces a working shield', () => {
    const shield = Shield.fromYaml(MINIMAL_YAML).withMcp().withMcp().build()
    expect(shield.capabilities.framework).toBe('mcp')
  })

  it('MCP_BUNDLE exposes the MCP capability report lazily', () => {
    expect(MCP_BUNDLE.name).toBe('mcp')
    expect(MCP_BUNDLE.capabilities.framework).toBe('mcp')
    expect(MCP_BUNDLE.toolWrapper).toBeUndefined()
    expect(MCP_BUNDLE.agentBoundary).toBeUndefined()
  })
})

describe('shieldServer(server, shield) wires request handlers', () => {
  interface MockServer {
    _registeredTools: Record<
      string,
      { callback: (params: Record<string, unknown>) => Promise<unknown> | unknown }
    >
  }

  function mockMcpServer(
    handlers: Record<
      string,
      (params: Record<string, unknown>) => Promise<unknown> | unknown
    >,
  ): MockServer {
    const reg: MockServer['_registeredTools'] = {}
    for (const [name, fn] of Object.entries(handlers)) {
      reg[name] = { callback: fn }
    }
    return { _registeredTools: reg }
  }

  it('replaces every registered tool handler with a Stage 2/3/4-guarded wrapper', async () => {
    let underlyingCalls = 0
    const server = mockMcpServer({
      echo: async (params) => {
        underlyingCalls++
        return `echo: ${String(params.msg ?? '')}`
      },
    })
    const originalRef = server._registeredTools.echo.callback

    const shield = Shield.fromYaml(MINIMAL_YAML).withMcp().build()
    const returned = shieldServer(server, shield, { onBlock: 'returnMessage' })

    expect(returned).toBe(server)
    expect(server._registeredTools.echo.callback).not.toBe(originalRef)

    const blocked = await server._registeredTools.echo.callback({ msg: 'hi' })
    expect(String(blocked)).toContain('GUARDRAIL')
    expect(underlyingCalls).toBe(0)
  })

  it('accepts an MCPShield directly', async () => {
    let underlyingCalls = 0
    const server = mockMcpServer({
      echo: async () => {
        underlyingCalls++
        return 'ok'
      },
    })

    const mcpShield = MCPShield.fromYaml(MINIMAL_YAML).build()
    const returned = shieldServer(server, mcpShield, { onBlock: 'returnMessage' })

    expect(returned).toBe(server)
    const out = await server._registeredTools.echo.callback({})
    expect(String(out)).toContain('GUARDRAIL')
    expect(underlyingCalls).toBe(0)
  })

  it('admits the tool when the gate is satisfied (Pattern A end-to-end)', async () => {
    let underlyingCalls = 0
    const server = mockMcpServer({
      echo: async (params) => {
        underlyingCalls++
        return { content: [{ type: 'text', text: `you said: ${String(params.msg)}` }] }
      },
    })

    const mcpShield = MCPShield.fromYaml(MINIMAL_YAML).build()
    shieldServer(server, mcpShield, { onBlock: 'returnMessage' })

    const session = mcpShield.session
    expect(session).not.toBeNull()
    session!.beginTurn()
    session!.setVariable('authorized', true)

    const out = (await server._registeredTools.echo.callback({ msg: 'hello' })) as {
      content: Array<{ type: string; text: string }>
    }
    expect(underlyingCalls).toBe(1)
    expect(out.content[0].text).toContain('you said: hello')
  })

  it('onBlock: "raise" throws MCPGuardrailBlocked through the wrapped handler', async () => {
    const server = mockMcpServer({
      echo: async () => 'never runs',
    })

    const shield = Shield.fromYaml(MINIMAL_YAML).withMcp().build()
    shieldServer(server, shield, { onBlock: 'raise' })

    await expect(
      server._registeredTools.echo.callback({ msg: 'hi' }),
    ).rejects.toBeInstanceOf(MCPGuardrailBlocked)
  })

  it('rejects bogus shield arguments', () => {
    const server = mockMcpServer({ echo: async () => 'ok' })
    expect(() =>
      shieldServer(server, { not: 'a shield' } as unknown as Shield),
    ).toThrow(/Shield or MCPShield/)
  })

  it('rejects servers with no recognised tool registry', () => {
    const shield = Shield.fromYaml(MINIMAL_YAML).withMcp().build()
    expect(() => shieldServer({ unrelated: 'shape' }, shield)).toThrow(
      /tool registry/,
    )
  })

  it('also walks the FastMCP-style `_tool_manager._tools` registry', async () => {
    let underlyingCalls = 0
    const server = {
      _tool_manager: {
        _tools: {
          echo: {
            fn: async () => {
              underlyingCalls++
              return 'fastmcp ok'
            },
          },
        },
      },
    }

    const shield = Shield.fromYaml(MINIMAL_YAML).withMcp().build()
    shieldServer(server, shield, { onBlock: 'returnMessage' })

    const out = await server._tool_manager._tools.echo.fn({})
    expect(String(out)).toContain('GUARDRAIL')
    expect(underlyingCalls).toBe(0)
  })
})


const AGENT_RESOLVER_YAML = `
metadata:
  name: mcp-agent-resolver-fixture
  version: 0.1.0
  agent_shield_version: "2.0"
objective:
  goal: ["delegate authorization to a host agent"]
  forbidden: ["execute without delegating"]
resources:
  tools:
    - name: "execute_trade"
      description: "Execute a trade."
      permission: "execute"
variables:
  - name: "trade_authorized"
    type: "boolean"
    on_demand_by:
      kind: "agent"
      prompt: "Authorize this trade via host agent?"
    lifetime: "per_session"
state_validation:
  guard_policies:
    - name: "trade_requires_agent_authorization"
      applies_to:
        tools: ["execute_trade"]
      evaluate_when:
        - expression: "trade_authorized == true"
          reason: "Trade was not authorized by host agent."
      action: "block"
`

describe('MCPShieldBuilder.withAgentResolver', () => {
  it('registers the agent resolver and invokes it on a kind: agent gate', async () => {
    const yamlPath = writeYaml(AGENT_RESOLVER_YAML, 'agent-resolver')
    try {
      let invocations = 0
      const shield = MCPShield.fromYaml(yamlPath)
        .withAgentResolver((req) => {
          invocations++
          void req
          return {
            decision: 'allow',
            value: true,
            set_variables: {},
            reason: 'authorized by test resolver',
          }
        })
        .build()

      const session = shield.runtime.newSession()
      session.beginTurn()

      const result = await shield.protectTool(
        'execute_trade',
        { account_id: 'A-1', qty: 1 },
        'tc_f31_6_agent',
        { session },
      )

      expect(result.allowed).toBe(true)
      expect(invocations).toBeGreaterThanOrEqual(1)
    } finally {
      fs.unlinkSync(yamlPath)
    }
  })
})

const CLASSIFIER_YAML = `
metadata:
  name: mcp-classifier-fixture
  version: 0.1.0
  agent_shield_version: "2.0"
objective:
  goal: ["classify the user input"]
  forbidden: ["let unclassified input through"]
resources:
  tools:
    - name: "respond"
      description: "Echo a response."
      permission: "read_only"
configurations:
  - id: "safety-classifier"
    type: "classifier"
    endpoint: "https://classifier.invalid/score"
    threshold: 0.5
    on_error: "block"
input_validation:
  guard_policies:
    - name: "block_unsafe_input"
      evaluate_when:
        - classifier:
            configuration: "safety-classifier"
          reason: "Input was classified as unsafe."
      action: "block"
`

describe('MCPShieldBuilder.withClassifierCaller', () => {
  it('registers the classifier caller and invokes it on an input gate', async () => {
    const yamlPath = writeYaml(CLASSIFIER_YAML, 'classifier-caller')
    try {
      let invocations = 0
      const shield = MCPShield.fromYaml(yamlPath)
        .withClassifierCaller((req) => {
          invocations++
          void req
          return { score: 0.1, threshold: 0.5 }
        })
        .build()

      const session = shield.runtime.newSession()
      session.beginTurn()

      const verdict = await session.validateInput('hello world')
      expect(verdict.allowed).toBe(true)
      expect(invocations).toBeGreaterThanOrEqual(1)
    } finally {
      fs.unlinkSync(yamlPath)
    }
  })
})
