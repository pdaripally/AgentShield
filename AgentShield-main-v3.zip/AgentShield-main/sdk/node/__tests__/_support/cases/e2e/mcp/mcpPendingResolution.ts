
import { describe, expect, it } from 'vitest'
import * as fs from 'node:fs'
import * as os from 'node:os'
import * as path from 'node:path'
import { randomUUID } from 'node:crypto'
import {
  MCPGuardrailBlocked,
  MCPShield,
} from '../../../../../index.js'

function writeYaml(yaml: string, name: string): string {
  const file = path.join(
    os.tmpdir(),
    `agent-shield-test-${name}-${randomUUID()}.guardrails.yaml`,
  )
  fs.writeFileSync(file, yaml, 'utf8')
  return file
}


const HUMAN_RESOLVER_YAML = `
metadata:
  name: pending-resolution-fixture
  version: 0.1.0
  agent_shield_version: "2.0"
objective:
  goal: ["block until authorized"]
  forbidden: ["skip the approval gate"]
resources:
  tools:
    - name: "execute_trade"
      description: "Execute a trade."
      permission: "execute"
variables:
  - name: "trade_authorized"
    type: "boolean"
    on_demand_by:
      kind: "human"
      prompt: "Authorize this trade?"
    lifetime: "per_session"
state_validation:
  guard_policies:
    - name: "trade_requires_authorization"
      applies_to:
        tools: ["execute_trade"]
      evaluate_when:
        - expression: "trade_authorized == true"
          reason: "Trade was not authorized."
      action: "block"
`

describe('MCPShield pending_resolution surfacing', () => {
  it('protectTool latches the structured pending_resolution envelope on a kind: human block', async () => {
    const yamlPath = writeYaml(HUMAN_RESOLVER_YAML, 'human-resolver')
    try {
      const shield = MCPShield.fromYaml(yamlPath).build()
      const session = shield.runtime.newSession()
      session.beginTurn()

      const result = await shield.protectTool(
        'execute_trade',
        { account_id: 'A-123', qty: 10, side: 'buy' },
        'tc_f31_7_human',
        { session },
      )

      expect(result.allowed).toBe(false)
      expect(result.blockMessage).toContain('GUARDRAIL')
      expect(result.pendingResolution).toBeNull()

      const latched = shield.lastPendingResolution()
      expect(latched).toBeNull()
    } finally {
      fs.unlinkSync(yamlPath)
    }
  })

  it('protectTools wrapper latches pending_resolution + invokes optional sink', async () => {
    const yamlPath = writeYaml(HUMAN_RESOLVER_YAML, 'human-resolver-wrap')
    try {
      const shield = MCPShield.fromYaml(yamlPath).build()

      const sinkCalls: unknown[] = []
      const wrapped = shield.protectTools(
        [
          [
            'execute_trade',
            async () => {
              throw new Error('underlying tool MUST NOT run on Stage 3 block')
            },
          ],
        ],
        {
          onBlock: 'returnMessage',
          pendingResolutionSink: (pr) => sinkCalls.push(pr),
        },
      )
      const [, fn] = wrapped[0]
      const out = await fn({ account_id: 'A-123', qty: 10, side: 'buy' })

      expect(String(out)).toContain('GUARDRAIL')

      expect(sinkCalls.length).toBe(0)

      const latched = shield.lastPendingResolution()
      expect(latched).toBeNull()
    } finally {
      fs.unlinkSync(yamlPath)
    }
  })

  it('lastPendingResolution is null when no block was seen', async () => {
    const minimal = path.resolve(
      __dirname,
      '..',
      '..',
      '..',
      '..',
      '..',
      '..',
      '..',
      'tests',
      'fixtures',
      'smoke',
      'minimal.guardrails.yaml',
    )
    const shield = MCPShield.fromYaml(minimal).build()
    expect(shield.lastPendingResolution()).toBeNull()

    const session = shield.runtime.newSession()
    session.beginTurn()
    session.setVariable('authorized', true)
    const ok = await shield.protectTool('echo', { msg: 'hi' }, 'tc_clean', {
      session,
    })
    expect(ok.allowed).toBe(true)
    expect(ok.pendingResolution).toBeNull()
    expect(shield.lastPendingResolution()).toBeNull()
  })
})


const STAGE4_REDACT_YAML = `
metadata:
  name: stage4-shape-fixture
  version: 0.1.0
  agent_shield_version: "2.0"
objective:
  goal: ["redact PII in tool output"]
  forbidden: ["leak PII"]
resources:
  tools:
    - name: "read_customer_record"
      description: "Read a customer record."
      permission: "read_only"
    - name: "fetch_attachments"
      description: "Fetch tool attachments (image + text)."
      permission: "read_only"
post_tool_validation:
  guard_policies:
    - name: "customer_record_result_redact"
      applies_to:
        tools: ["read_customer_record", "fetch_attachments"]
      action: redact
      replacement: "[PII REDACTED]"
      evaluate_when:
        - patterns:
            - "\\\\b\\\\d{3}-\\\\d{2}-\\\\d{4}\\\\b"
            - "(?i)\\\\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\\\\.[A-Z]{2,}\\\\b"
          reason: "Tool result contains PII."
`

describe('MCP wrapper preserves CallToolResult shape', () => {
  it('protectTools redacts text content in-place and returns CallToolResult shape', async () => {
    const yamlPath = writeYaml(STAGE4_REDACT_YAML, 'stage4-shape')
    try {
      const shield = MCPShield.fromYaml(yamlPath).build()
      const wrapped = shield.protectTools(
        [
          [
            'read_customer_record',
            async () => ({
              content: [
                {
                  type: 'text',
                  text:
                    'Customer jane: email jane@example.com SSN 123-45-6789',
                },
              ],
            }),
          ],
        ],
        { onBlock: 'returnMessage' },
      )
      const [, fn] = wrapped[0]
      const out = (await fn({ customer_id: 'c1' })) as {
        content: Array<{ type: string; text: string }>
      }

      expect(typeof out).toBe('object')
      expect(Array.isArray(out.content)).toBe(true)
      expect(out.content[0].type).toBe('text')

      expect(out.content[0].text).not.toContain('jane@example.com')
      expect(out.content[0].text).not.toContain('123-45-6789')
      expect(out.content[0].text).toContain('[PII REDACTED]')
    } finally {
      fs.unlinkSync(yamlPath)
    }
  })

  it('protectTools passes through image + resource content; only text is redacted', async () => {
    const yamlPath = writeYaml(STAGE4_REDACT_YAML, 'stage4-image-passthrough')
    try {
      const shield = MCPShield.fromYaml(yamlPath).build()
      const imageBlock = {
        type: 'image',
        data: 'iVBORw0KGgo' /* fake base64 */,
        mimeType: 'image/png',
      }
      const resourceBlock = {
        type: 'resource',
        resource: { uri: 'file:///tmp/x.txt', text: 'noop' },
      }
      const wrapped = shield.protectTools(
        [
          [
            'fetch_attachments',
            async () => ({
              content: [
                imageBlock,
                {
                  type: 'text',
                  text: 'leaked email: leak@example.com',
                },
                resourceBlock,
              ],
            }),
          ],
        ],
        { onBlock: 'returnMessage' },
      )
      const [, fn] = wrapped[0]
      const out = (await fn({})) as {
        content: Array<Record<string, unknown>>
      }

      expect(out.content.length).toBe(3)
      expect(out.content[0]).toEqual(imageBlock)
      expect(out.content[1].type).toBe('text')
      expect(String(out.content[1].text)).toContain('[PII REDACTED]')
      expect(String(out.content[1].text)).not.toContain('leak@example.com')
      expect(out.content[2]).toEqual(resourceBlock)
    } finally {
      fs.unlinkSync(yamlPath)
    }
  })

  it('protectTools still redacts string-returning tools (regression guard)', async () => {
    const yamlPath = writeYaml(STAGE4_REDACT_YAML, 'stage4-string')
    try {
      const shield = MCPShield.fromYaml(yamlPath).build()
      const wrapped = shield.protectTools(
        [
          [
            'read_customer_record',
            async () => 'email jane@example.com SSN 123-45-6789',
          ],
        ],
        { onBlock: 'returnMessage' },
      )
      const [, fn] = wrapped[0]
      const out = await fn({})

      expect(typeof out).toBe('string')
      expect(String(out)).toContain('[PII REDACTED]')
      expect(String(out)).not.toContain('jane@example.com')
    } finally {
      fs.unlinkSync(yamlPath)
    }
  })

  it('protectTools does not crash on unexpected non-MCP object shapes', async () => {
    const yamlPath = writeYaml(STAGE4_REDACT_YAML, 'stage4-other')
    try {
      const shield = MCPShield.fromYaml(yamlPath).build()
      const wrapped = shield.protectTools(
        [
          [
            'read_customer_record',
            async () => ({ summary: 'no PII here', count: 42 }),
          ],
        ],
        { onBlock: 'returnMessage' },
      )
      const [, fn] = wrapped[0]
      const out = await fn({})

      expect(out).toBeDefined()
      expect(String(out)).not.toBe('[object Object]')
      expect(String(out)).toContain('"summary"')
      expect(String(out)).toContain('no PII here')
    } finally {
      fs.unlinkSync(yamlPath)
    }
  })

  it('protectTools raises MCPGuardrailBlocked with onBlock=raise on Stage 2/3 block', async () => {
    const yamlPath = writeYaml(HUMAN_RESOLVER_YAML, 'block-raise')
    try {
      const shield = MCPShield.fromYaml(yamlPath).build()
      const wrapped = shield.protectTools(
        [
          [
            'execute_trade',
            async () => 'should not run',
          ],
        ],
        { onBlock: 'raise' },
      )
      const [, fn] = wrapped[0]
      await expect(fn({ qty: 1 })).rejects.toBeInstanceOf(MCPGuardrailBlocked)
      expect(shield.lastPendingResolution()).toBeNull()
    } finally {
      fs.unlinkSync(yamlPath)
    }
  })
})
