
import { describe, it, expect, vi } from 'vitest'
import * as path from 'node:path'

import { DynamicStructuredTool } from '@langchain/core/tools'

import {
  RuntimeBuilder,
  Shield,
  ShieldBuilder,
  CapabilityReport,
  CoverageLevel,
  AgentShieldBlockedError,
} from '../../../../../index.js'

import * as langchainAdapter from '../../../../../adapters/langchain.js'
const LANGCHAIN_BUNDLE = (langchainAdapter as any).LANGCHAIN_BUNDLE


const FIXTURES_NODE = path.resolve(
  __dirname,
  '..',
  '..',
  '..',
  '..',
  '..',
  '..',
  '..',
  'tests',
  'fixtures',
  'smoke',
)
const FIXTURES_PY = path.resolve(
  __dirname,
  '..',
  '..',
  '..',
  '..',
  '..',
  '..',
  'python',
  'tests',
  'fixtures_smoke',
)
const MINIMAL = path.join(FIXTURES_NODE, 'minimal.guardrails.yaml')
const INPUT_BLOCK = path.join(FIXTURES_NODE, 'input-block.guardrails.yaml')
const TOOL_ARGS_REDACT = path.join(FIXTURES_PY, 'tool_args_redact.guardrails.yaml')


const STAGE2_YAML = `
metadata:
  name: "stage2-block"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["block tool"]
  forbidden: ["allow tool"]
resources:
  tools:
    - name: "echo"
      description: "Echo helper."
      permission: "read_only"
state_validation:
  guard_policies:
    - name: "deny_echo"
      applies_to:
        tools: ["echo"]
      allowed_when: "false"
`

const STAGE4_YAML = `
metadata:
  name: "stage4-redact"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["scrub ssn from tool output"]
  forbidden: ["leak ssn"]
resources:
  tools:
    - name: "echo"
      description: "Echo helper."
      permission: "read_only"
post_tool_validation:
  guard_policies:
    - name: "redact_ssn_output"
      action: redact
      replacement: "[REDACTED]"
      evaluate_when:
        - pattern: "\\\\d{3}-\\\\d{2}-\\\\d{4}"
          reason: "SSN in tool output."
`

const STAGE5_YAML = `
metadata:
  name: "stage5-block"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["block forbidden output"]
  forbidden: ["leak FORBIDDEN"]
resources:
  tools:
    - name: "echo"
      description: "Echo helper."
      permission: "read_only"
output_validation:
  guard_policies:
    - name: "block_forbidden"
      action: block
      evaluate_when:
        - pattern: "FORBIDDEN"
          reason: "Output contained forbidden token."
`

const PASSTHROUGH_YAML = `
metadata:
  name: "passthrough"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["pass through every call"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "echo"
      description: "Echo helper."
      permission: "read_only"
`

const TOOL_EXC_YAML = `
metadata:
  name: "tool-exception"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test exception"]
  forbidden: ["x"]
resources:
  tools:
    - name: "boom"
      description: "always throws"
      permission: "read_only"
`


function shieldFromYamlString(text: string): Shield {
  const runtime = RuntimeBuilder.fromYamlStrings([text]).build()
  return new Shield(runtime as any, { bundle: LANGCHAIN_BUNDLE } as any)
}

function shieldFromPath(p: string): Shield {
  const runtime = RuntimeBuilder.fromYaml(p).build()
  return new Shield(runtime as any, { bundle: LANGCHAIN_BUNDLE } as any)
}


describe('LangChain adapter — capability report', () => {
  it('declares the documented per-stage coverage', () => {
    const rep = (langchainAdapter as any).capabilities as CapabilityReport
    expect(rep).toBeInstanceOf(CapabilityReport)
    expect(rep.framework).toBe('langchain')
    expect(rep.inputValidation).toBe(CoverageLevel.FULL)
    expect(rep.stateValidation).toBe(CoverageLevel.FULL)
    expect(rep.toolAuthorization).toBe(CoverageLevel.FULL)
    expect(rep.toolExecutionValidation).toBe(CoverageLevel.FULL)
    expect(rep.toolOutputValidation).toBe(CoverageLevel.FULL)
    expect(rep.outputValidation).toBe(CoverageLevel.FULL)
    expect(rep.streamingOutput).toBe(CoverageLevel.PARTIAL)
    expect(rep.notes.length).toBeGreaterThan(0)
    expect(rep.notes[0]).toMatch(/streaming/i)
    expect(rep.isFullCoverage()).toBe(false)
  })

  it('LANGCHAIN_BUNDLE wires all four capabilities', () => {
    expect(LANGCHAIN_BUNDLE.name).toBe('langchain')
    expect(typeof LANGCHAIN_BUNDLE.toolWrapper.extract).toBe('function')
    expect(typeof LANGCHAIN_BUNDLE.toolWrapper.invoke).toBe('function')
    expect(typeof LANGCHAIN_BUNDLE.toolWrapper.wrap).toBe('function')
    expect(typeof LANGCHAIN_BUNDLE.agentBoundary.run).toBe('function')
    expect(typeof LANGCHAIN_BUNDLE.agentBoundary.makeBlocked).toBe('function')
    expect(typeof LANGCHAIN_BUNDLE.streamingAdapter.stream).toBe('function')
    expect(typeof LANGCHAIN_BUNDLE.llmCallerFactory.makeCaller).toBe('function')
  })
})

describe('LangChain adapter — builder side effects', () => {
  it('installs withLangchain on ShieldBuilder.prototype', () => {
    expect(typeof (ShieldBuilder.prototype as any).withLangchain).toBe(
      'function',
    )
  })

  it('installs withLlm on ShieldBuilder.prototype', () => {
    expect(typeof (ShieldBuilder.prototype as any).withLlm).toBe('function')
  })

  it('Shield.fromYaml(...).withLangchain.build returns a wired Shield', () => {
    const shield = (Shield as any)
      .fromYaml(MINIMAL)
      .withLangchain()
      .build() as Shield
    expect(shield).toBeInstanceOf(Shield)
    expect(shield.capabilities.framework).toBe('langchain')
  })

  it('withLlm before withLangchain defers the LLM until the bundle is bound', () => {
    const calls: string[] = []
    const fakeLlm = {
      invoke: async (msgs: any[]) => {
        calls.push(msgs[0].content)
        return { content: 'ok' }
      },
    }
    const shield = (Shield as any)
      .fromYaml(MINIMAL)
      .withLlm(fakeLlm)
      .withLangchain()
      .build()
    expect(shield).toBeInstanceOf(Shield)
    expect((shield as any).runtime).toBeDefined()
  })
})

describe('LangChain adapter — Stage 1 block', () => {
  it('blocks the input and never invokes the agent', async () => {
    const shield = shieldFromPath(INPUT_BLOCK)
    let agentCalled = false
    const fakeAgent = {
      invoke: async (_input: any) => {
        void _input
        agentCalled = true
        return { output: 'should not happen', messages: [] }
      },
    }
    const guarded = shield.guard(fakeAgent)
    const result: any = await guarded.run('DENY_ME this request')
    expect(agentCalled).toBe(false)
    expect(result.output).toMatch(/\[GUARDRAIL BLOCK\]/)
    expect(result.messages).toBeDefined()
    expect(result.messages.length).toBe(1)
    expect(typeof result.messages[0].content).toBe('string')
    expect(result.messages[0].content).toMatch(/\[GUARDRAIL BLOCK\]/)
  })
})

describe('LangChain adapter — Stage 2 block (tool authorization)', () => {
  it('blocks the tool call by throwing AgentShieldBlockedError and never calls the original func', async () => {
    const shield = shieldFromYamlString(STAGE2_YAML)
    let originalCalled = false
    const tool = new DynamicStructuredTool({
      name: 'echo',
      description: 'echo helper',
      schema: {
        type: 'object',
        properties: { msg: { type: 'string' } },
      } as any,
      func: async (args: any) => {
        originalCalled = true
        return `direct: ${args.msg}`
      },
    })
    const wrapped = (await shield.protectTools([tool], { allowUnguarded: true }))[0] as any
    let caught: unknown = null
    try {
      await wrapped.invoke({ msg: 'hello' })
    } catch (err) {
      caught = err
    }
    expect(originalCalled).toBe(false)
    expect(caught).toBeInstanceOf(AgentShieldBlockedError)
    const blocked = caught as AgentShieldBlockedError
    expect(blocked.toolName).toBe('echo')
    expect(blocked.stage).toBe('tool_call')
    expect(blocked.blockMessage).toMatch(/\[GUARDRAIL BLOCK\]/)
  })
})

describe('LangChain adapter — Stage 3 mutation (params redaction)', () => {
  it('forwards the redacted params, not the originals, to the inner tool', async () => {
    const shield = shieldFromPath(TOOL_ARGS_REDACT)
    let receivedArgs: Record<string, unknown> | null = null
    const tool = new DynamicStructuredTool({
      name: 'echo',
      description: 'echo helper',
      schema: {
        type: 'object',
        properties: { msg: { type: 'string' } },
      } as any,
      func: async (args: any) => {
        receivedArgs = args
        return `echo: ${args.msg}`
      },
    })
    const wrapped = (await shield.protectTools([tool], { allowUnguarded: true }))[0] as any
    const result = await wrapped.invoke({ msg: 'My SSN is 123-45-6789, please' })
    expect(receivedArgs).not.toBeNull()
    expect((receivedArgs as any).msg).not.toContain('123-45-6789')
    expect((receivedArgs as any).msg).toContain('[REDACTED]')
    expect(result).toContain('[REDACTED]')
    expect(result).not.toContain('123-45-6789')
  })
})

describe('LangChain adapter — Stage 4 redaction (tool output)', () => {
  it('redacts the tool output before the agent sees it', async () => {
    const shield = shieldFromYamlString(STAGE4_YAML)
    const tool = new DynamicStructuredTool({
      name: 'echo',
      description: 'echo helper',
      schema: {
        type: 'object',
        properties: { msg: { type: 'string' } },
      } as any,
      func: async () => 'Result: SSN 999-88-7777 found',
    })
    const wrapped = (await shield.protectTools([tool], { allowUnguarded: true }))[0] as any
    const result = await wrapped.invoke({ msg: 'find' })
    expect(result).toContain('[REDACTED]')
    expect(result).not.toContain('999-88-7777')
  })
})

describe('LangChain adapter — Stage 5 block (output validation)', () => {
  it('blocks a forbidden agent output', async () => {
    const shield = shieldFromYamlString(STAGE5_YAML)
    const fakeAgent = {
      invoke: async (_input: any) => {
        void _input
        return {
          output: 'this contains FORBIDDEN content',
          messages: [{ content: 'this contains FORBIDDEN content' }],
        }
      },
    }
    const guarded = shield.guard(fakeAgent)
    const result: any = await guarded.run('hello')
    expect(result.output).toMatch(/\[GUARDRAIL BLOCK\]/)
    expect(result.output).toMatch(/FORBIDDEN|forbidden/i)
    expect(result.messages?.[0]?.content).toMatch(/\[GUARDRAIL BLOCK\]/)
  })
})

describe('LangChain adapter — tool exception path', () => {
  it('calls recordToolFailure when the underlying tool throws', async () => {
    const runtime = RuntimeBuilder.fromYamlStrings([TOOL_EXC_YAML]).build()
    const failures: Array<[string, string]> = []
    const realNewSession = runtime.newSession.bind(runtime)
    ;(runtime as any).newSession = (opts?: any) => {
      const sess = realNewSession(opts)
      const orig = sess.recordToolFailure.bind(sess)
      sess.recordToolFailure = ((name: string, err: string) => {
        failures.push([name, err])
        return orig(name, err)
      }) as any
      return sess
    }
    const shield = new Shield(runtime as any, {
      bundle: LANGCHAIN_BUNDLE,
    } as any)

    const boom = new DynamicStructuredTool({
      name: 'boom',
      description: 'always throws',
      schema: { type: 'object', properties: {} } as any,
      func: async () => {
        throw new Error('boom-error')
      },
    })
    const wrapped = (await shield.protectTools([boom], { allowUnguarded: true }))[0] as any
    const result = await wrapped.invoke({})
    expect(failures.length).toBeGreaterThanOrEqual(1)
    expect(failures[0][0]).toBe('boom')
    expect(failures[0][1]).toMatch(/boom-error/)
    expect(typeof result).toBe('string')
    expect(result).toMatch(/boom/)
  })
})

describe('LangChain adapter — Pattern B (protectTools)', () => {
  it('preserves the LangChain tool shape (name/description/schema/lc_namespace)', async () => {
    const shield = shieldFromYamlString(PASSTHROUGH_YAML)
    const schema = {
      type: 'object',
      properties: { msg: { type: 'string' } },
      required: ['msg'],
    }
    const tool = new DynamicStructuredTool({
      name: 'echo',
      description: 'A helpful echo tool.',
      schema: schema as any,
      func: async ({ msg }: any) => `echo: ${msg}`,
    })
    const wrapped = (await shield.protectTools([tool], { allowUnguarded: true }))[0] as any
    expect(wrapped.name).toBe('echo')
    expect(wrapped.description).toBe('A helpful echo tool.')
    expect(wrapped.schema).toBe(schema)
    expect(Array.isArray(wrapped.lc_namespace)).toBe(true)
    expect(typeof wrapped.invoke).toBe('function')
    expect(typeof wrapped.call).toBe('function')
    const r = await wrapped.invoke({ msg: 'hi' })
    expect(r).toBe('echo: hi')
  })
})

describe('LangChain adapter — Pattern A (createLangchainAgent)', () => {
  it('wraps tools and invokes the build callback with the wrapped list', async () => {
    const shield = shieldFromYamlString(PASSTHROUGH_YAML)
    const tool = new DynamicStructuredTool({
      name: 'echo',
      description: 'echo',
      schema: {
        type: 'object',
        properties: { msg: { type: 'string' } },
      } as any,
      func: async ({ msg }: any) => `direct: ${msg}`,
    })

    const buildSpy = vi.fn(async (wrappedTools: any[]) => {
      return { tools: wrappedTools, invoke: async () => ({ output: 'ok' }) }
    })

    const agent = (await (shield as any).createLangchainAgent({
      tools: [tool],
      build: buildSpy,
    })) as any

    expect(buildSpy).toHaveBeenCalledOnce()
    const wrappedTools = buildSpy.mock.calls[0][0]
    expect(Array.isArray(wrappedTools)).toBe(true)
    expect(wrappedTools.length).toBe(1)
    expect(wrappedTools[0].name).toBe('echo')
    expect(wrappedTools[0]).not.toBe(tool) // separate wrapper
    expect(typeof wrappedTools[0].invoke).toBe('function')
    expect(Array.isArray(wrappedTools[0].lc_namespace)).toBe(true)
    expect(agent.tools.length).toBe(1)
  })

  it('shield.run(fn) is a callable convenience for Pattern B', async () => {
    const shield = shieldFromPath(MINIMAL)
    const r = await (shield as any).run(async () => 42)
    expect(r).toBe(42)
  })
})


describe('LangChain adapter — GuardedRunner.invoke alias', () => {
  it('exposes .invoke as a function on the guarded runner', () => {
    const shield = shieldFromPath(MINIMAL)
    const fakeAgent = {
      invoke: async (_input: any) => {
        void _input
        return { output: 'ok', messages: [{ content: 'ok' }] }
      },
    }
    const guarded = shield.guard(fakeAgent)
    expect(typeof (guarded as any).invoke).toBe('function')
    expect(typeof (guarded as any).run).toBe('function')
  })

  it('with a string input matches .run(input) result shape', async () => {
    const shield = shieldFromPath(MINIMAL)
    const calls: any[] = []
    const fakeAgent = {
      invoke: async (input: any) => {
        calls.push(input)
        return { output: 'echoed', messages: [{ content: 'echoed' }] }
      },
    }

    const g1 = shield.guard(fakeAgent)
    const viaRun: any = await g1.run('hello')

    const g2 = shield.guard(fakeAgent)
    const viaInvoke: any = await (g2 as any).invoke('hello')

    expect(viaInvoke.output).toBe(viaRun.output)
    expect(calls.length).toBe(2)
    expect(calls[0]).toEqual(calls[1])
  })

  it('with a LangChain-style {input: "..."} dict forwards to the boundary', async () => {
    const shield = shieldFromPath(MINIMAL)
    let received: any = null
    const fakeAgent = {
      invoke: async (input: any) => {
        received = input
        return { output: 'pong', messages: [{ content: 'pong' }] }
      },
    }
    const guarded = shield.guard(fakeAgent)
    const result: any = await (guarded as any).invoke({ input: 'ping' })
    expect(result.output).toBe('pong')
    expect(received).toBeDefined()
    expect(received.input).toBe('ping')
  })

  it('extracts human-readable text from a dict for Stage 1 validation', async () => {
    const shield = shieldFromPath(INPUT_BLOCK)
    let agentCalled = false
    const fakeAgent = {
      invoke: async (_input: any) => {
        void _input
        agentCalled = true
        return { output: 'should not happen', messages: [] }
      },
    }
    const guarded = shield.guard(fakeAgent)
    const result: any = await (guarded as any).invoke({ input: 'DENY_ME this request' })
    expect(agentCalled).toBe(false)
    expect(result.output).toMatch(/\[GUARDRAIL BLOCK\]/)
  })
})


describe('LangChain streaming adapter — respects validator mode', () => {
  function makeFakeAgent(chunks: ReadonlyArray<unknown>) {
    return {
      async stream() {
        async function* gen() {
          for (const c of chunks) yield c
        }
        return gen()
      },
    }
  }

  function makeStubValidator(opts: {
    mode: 'on_complete' | 'per_chunk' | 'windowed'
    pushHandler?: (text: string) => {
      payload: string | null
      stopped: boolean
      reason: string | null
    }
    finishHandler?: () => {
      payload: string | null
      stopped: boolean
      reason: string | null
    }
  }) {
    const calls: { push: string[]; finish: number } = { push: [], finish: 0 }
    const validator = {
      get mode() {
        return opts.mode
      },
      async push(text: string) {
        calls.push.push(text)
        return (
          opts.pushHandler?.(text) ?? {
            payload: '',
            stopped: false,
            reason: null,
          }
        )
      },
      async finish() {
        calls.finish += 1
        return (
          opts.finishHandler?.() ?? {
            payload: '',
            stopped: false,
            reason: null,
          }
        )
      },
      makeBlocked: (msg: string) => ({ blocked: msg }),
      applyRedaction: (chunk: unknown, text: string) => ({ chunk, text }),
    }
    return { validator, calls }
  }

  it('OnComplete: buffers every text chunk and emits ONE final chunk at finish', async () => {
    const adapter = LANGCHAIN_BUNDLE.streamingAdapter
    const upstream = [
      { messages: [{ content: 'Hello ' }] },
      { messages: [{ content: 'world' }] },
      { messages: [{ content: '!' }] },
    ]
    const agent = makeFakeAgent(upstream)
    const { validator, calls } = makeStubValidator({
      mode: 'on_complete',
      finishHandler: () => ({ payload: 'Hello world!', stopped: false, reason: null }),
    })

    const emissions: unknown[] = []
    for await (const e of adapter.stream(agent, '', validator, {})) {
      emissions.push(e)
    }

    expect(calls.push).toEqual(['Hello ', 'world', '!'])
    expect(calls.finish).toBe(1)
    expect(emissions.length).toBe(1)
    expect((emissions[0] as { text: string }).text).toBe('Hello world!')
  })

  it('OnComplete: holds back text chunks, passes metadata-only chunks promptly', async () => {
    const adapter = LANGCHAIN_BUNDLE.streamingAdapter
    const meta1 = { messages: [{ content: '' }] }
    const meta2 = { messages: [{ content: '' }] }
    const upstream = [
      meta1,
      { messages: [{ content: 'Hello' }] },
      meta2,
      { messages: [{ content: ' world' }] },
    ]
    const agent = makeFakeAgent(upstream)
    const { validator, calls } = makeStubValidator({
      mode: 'on_complete',
      finishHandler: () => ({ payload: 'Hello world', stopped: false, reason: null }),
    })

    const emissions: unknown[] = []
    for await (const e of adapter.stream(agent, '', validator, {})) {
      emissions.push(e)
    }

    expect(calls.push).toEqual(['Hello', ' world'])
    expect(emissions.length).toBe(3)
    expect(emissions[0]).toBe(meta1)
    expect(emissions[1]).toBe(meta2)
    expect((emissions[2] as { text: string }).text).toBe('Hello world')
  })

  it('OnComplete: Stop verdict emits a single blocked message and aborts', async () => {
    const adapter = LANGCHAIN_BUNDLE.streamingAdapter
    const upstream = [
      { messages: [{ content: 'safe ' }] },
      { messages: [{ content: 'BAD content' }] },
      { messages: [{ content: 'never seen' }] },
    ]
    const agent = makeFakeAgent(upstream)
    let pushIdx = 0
    const { validator } = makeStubValidator({
      mode: 'on_complete',
      pushHandler: (_text) => {
        void _text
        pushIdx += 1
        if (pushIdx === 2) {
          return { payload: null, stopped: true, reason: 'policy violation' }
        }
        return { payload: '', stopped: false, reason: null }
      },
    })

    const emissions: unknown[] = []
    for await (const e of adapter.stream(agent, '', validator, {})) {
      emissions.push(e)
    }

    expect(emissions.length).toBe(1)
    expect((emissions[0] as { blocked: string }).blocked).toMatch(
      /policy violation/,
    )
  })

  it('PerChunk: emits engine payload (NOT raw chunk) mid-stream', async () => {
    const adapter = LANGCHAIN_BUNDLE.streamingAdapter
    const upstream = [
      { messages: [{ content: 'Hello' }] },
      { messages: [{ content: ' world' }] },
    ]
    const agent = makeFakeAgent(upstream)
    const { validator, calls } = makeStubValidator({
      mode: 'per_chunk',
      pushHandler: (text) => ({ payload: text, stopped: false, reason: null }),
      finishHandler: () => ({ payload: '', stopped: false, reason: null }),
    })

    const emissions: unknown[] = []
    for await (const e of adapter.stream(agent, '', validator, {})) {
      emissions.push(e)
    }

    expect(calls.push.length).toBe(2)
    expect(emissions.length).toBe(2)
    expect(emissions[0]).toEqual({ chunk: upstream[0], text: 'Hello' })
    expect(emissions[1]).toEqual({ chunk: upstream[1], text: ' world' })
  })

  it('Windowed: buffered pushes (empty payload) emit nothing; non-empty payload reaches consumer verbatim', async () => {
    const adapter = LANGCHAIN_BUNDLE.streamingAdapter
    const upstream = [
      { messages: [{ content: 'first ' }] },
      { messages: [{ content: 'second ' }] },
      { messages: [{ content: 'third' }] },
    ]
    const agent = makeFakeAgent(upstream)
    let pushIdx = 0
    const { validator, calls } = makeStubValidator({
      mode: 'windowed',
      pushHandler: () => {
        pushIdx += 1
        if (pushIdx === 1) {
          return { payload: '', stopped: false, reason: null }
        }
        if (pushIdx === 2) {
          return { payload: 'first second ', stopped: false, reason: null }
        }
        return { payload: 'third [REDACTED]', stopped: false, reason: null }
      },
      finishHandler: () => ({ payload: '', stopped: false, reason: null }),
    })

    const emissions: unknown[] = []
    for await (const e of adapter.stream(agent, '', validator, {})) {
      emissions.push(e)
    }

    expect(calls.push.length).toBe(3)
    expect(emissions.length).toBe(2)
    expect(emissions[0]).toEqual({ chunk: upstream[1], text: 'first second ' })
    expect(emissions[1]).toEqual({ chunk: upstream[2], text: 'third [REDACTED]' })
  })
})
