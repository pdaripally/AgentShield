
import { afterAll, beforeAll, describe, it, expect, vi } from 'vitest'
import * as fs from 'node:fs'
import * as path from 'node:path'
import { CapabilityReport, CoverageLevel, RuntimeBuilder, Shield, ShieldBuilder } from '../../../../../index.js'

import {
  ANTHROPIC_AGENTS_BUNDLE,
  ANTHROPIC_AGENTS_CAPABILITIES,
  _setAnthropicModuleForTesting,
  install,
  type AnthropicSdkLikeModule,
} from '../../../../../adapters/anthropic_agents.js'

install()

const REPO_ROOT = path.resolve(__dirname, '..', '..', '..', '..', '..', '..', '..')
const MINIMAL = path.join(
  REPO_ROOT,
  'tests',
  'fixtures',
  'smoke',
  'minimal.guardrails.yaml',
)
const INPUT_BLOCK = path.join(
  REPO_ROOT,
  'tests',
  'fixtures',
  'smoke',
  'input-block.guardrails.yaml',
)

const STAGES_YAML = `
metadata:
  name: "anthropic-adapter-test"
  version: "0.1.0"
  agent_shield_version: "2.0"

objective:
  goal:
    - "Adapter test fixture."
  forbidden:
    - "DENY_ME inputs."

resources:
  tools:
    - name: "weather"
      description: "Returns a weather report."
      permission: "read_only"
    - name: "secret_tool"
      description: "Forbidden tool."
      permission: "execute"

input_validation:
  guard_policies:
    - name: "deny_input"
      evaluate_when:
        - patterns:
            - "DENY_ME_INPUT"
          reason: "Input matched DENY_ME_INPUT."
      action: "block"

state_validation:
  guard_policies:
    - name: "block_secret_tool"
      applies_to:
        tools:
          - "secret_tool"
      evaluate_when:
        - expression: "false"
          reason: "secret_tool is forbidden."
      action: "block"

tool_execution_validation:
  guard_policies:
    - name: "redact_tool_args"
      applies_to:
        tools:
          - "weather"
      evaluate_when:
        - patterns:
            - "REDACT_ME_ARG"
          reason: "Sensitive value in tool args."
      action: "redact"
      replacement: "[ARG_REDACTED]"

post_tool_validation:
  guard_policies:
    - name: "redact_tool_output"
      applies_to:
        tools:
          - "weather"
      evaluate_when:
        - patterns:
            - "REDACT_ME_OUTPUT"
          reason: "Sensitive value in tool output."
      action: "redact"
      replacement: "[OUTPUT_REDACTED]"

output_validation:
  guard_policies:
    - name: "deny_output"
      evaluate_when:
        - patterns:
            - "DENY_ME_OUTPUT"
          reason: "Output matched DENY_ME_OUTPUT."
      action: "block"
`

function buildShield(yamlPath: string = MINIMAL): Shield {
  return (Shield as any).fromYaml(yamlPath).withAnthropic().build()
}

function buildShieldFromYaml(yaml: string): Shield {
  const runtime = RuntimeBuilder.fromYamlStrings([yaml]).build()
  return new (Shield as any)(runtime, { bundle: ANTHROPIC_AGENTS_BUNDLE })
}


class FakeToolError extends Error {
  readonly content: string | unknown[]
  constructor(content: string | unknown[]) {
    super(typeof content === 'string' ? content : 'tool_error')
    this.content = content
    this.name = 'ToolError'
  }
}

const FAKE_SDK_MODULE: AnthropicSdkLikeModule = {
  ToolError: FakeToolError as unknown as new (
    content: string | unknown[],
  ) => Error,
}

_setAnthropicModuleForTesting(FAKE_SDK_MODULE)


interface ScriptToolUse {
  id: string
  name: string
  input: Record<string, unknown>
}

interface ScriptResponse {
  text?: string
  toolUses?: ScriptToolUse[]
  stop_reason: 'tool_use' | 'end_turn'
}

interface FakeRunnerToolResult {
  type: 'tool_result'
  tool_use_id: string
  content: string | unknown[]
  is_error?: boolean
}

interface FakeRunner {
  runUntilDone: () => Promise<{
    content: Array<{ type: string; text?: string }>
    stop_reason: string
  }>
  [Symbol.asyncIterator]?: () => AsyncIterator<unknown>
  toolResults: FakeRunnerToolResult[]
  callBody: Record<string, unknown>
}

interface FakeClient {
  messages: {
    create: ReturnType<typeof vi.fn>
  }
  beta: {
    messages: {
      toolRunner: ReturnType<typeof vi.fn>
    }
  }
  _lastRunner?: FakeRunner
}

function makeFakeAnthropicClient(script: ScriptResponse[]): FakeClient {
  const create = vi.fn(async () => {
    throw new Error(
      'unexpected: runner-based runAnthropicAgent must not call messages.create directly',
    )
  })

  const client: FakeClient = {
    messages: { create },
    beta: {
      messages: {
        toolRunner: vi.fn(),
      },
    },
  }

  client.beta.messages.toolRunner.mockImplementation(
    (body: Record<string, unknown>) => {
      const tools = Array.isArray(body.tools) ? (body.tools as any[]) : []
      const maxIters = (body.max_iterations as number | undefined) ?? 10
      const toolResults: FakeRunnerToolResult[] = []

      const runUntilDone = async () => {
        let iter = 0
        let lastTextSnapshot = ''
        let lastStopReason = ''
        for (const resp of script) {
          if (iter >= maxIters) break
          iter++
          lastStopReason = resp.stop_reason
          if (resp.stop_reason === 'end_turn') {
            lastTextSnapshot = resp.text ?? ''
            break
          }
          for (const tu of resp.toolUses ?? []) {
            const tool = tools.find((t) => t && t.name === tu.name)
            if (!tool || typeof tool.run !== 'function') {
              toolResults.push({
                type: 'tool_result',
                tool_use_id: tu.id,
                content: `Error: Tool '${tu.name}' not found`,
                is_error: true,
              })
              continue
            }
            try {
              const out = await tool.run(tu.input, {
                toolUseBlock: tu,
                signal: undefined,
              })
              toolResults.push({
                type: 'tool_result',
                tool_use_id: tu.id,
                content: out,
              })
            } catch (err) {
              const content =
                err instanceof FakeToolError
                  ? err.content
                  : `Error: ${err instanceof Error ? err.message : String(err)}`
              toolResults.push({
                type: 'tool_result',
                tool_use_id: tu.id,
                content,
                is_error: true,
              })
            }
          }
        }
        return {
          content: lastTextSnapshot
            ? [{ type: 'text', text: lastTextSnapshot }]
            : [],
          stop_reason: lastStopReason || 'end_turn',
        }
      }

      const runner: FakeRunner = {
        runUntilDone,
        toolResults,
        callBody: body,
      }
      client._lastRunner = runner
      return runner
    },
  )

  return client
}


describe('Anthropic adapter — installation', () => {
  it('installs withAnthropic on ShieldBuilder.prototype', () => {
    expect(typeof (ShieldBuilder.prototype as any).withAnthropic).toBe('function')
  })

  it('installs runAnthropicAgent / protectAnthropicTools / runAnthropicAgentStreamed on Shield.prototype', () => {
    expect(typeof (Shield.prototype as any).runAnthropicAgent).toBe('function')
    expect(typeof (Shield.prototype as any).protectAnthropicTools).toBe('function')
    expect(typeof (Shield.prototype as any).runAnthropicAgentStreamed).toBe(
      'function',
    )
  })

  it('Shield.fromYaml works without subclassing once the adapter is loaded', () => {
    const shield = buildShield()
    expect(shield).toBeInstanceOf(Shield)
  })
})

describe('Anthropic adapter — CapabilityReport', () => {
  it('declares the documented coverage profile', () => {
    const rep = ANTHROPIC_AGENTS_CAPABILITIES
    expect(rep).toBeInstanceOf(CapabilityReport)
    expect(rep.framework).toBe('anthropic_agents')
    expect(rep.inputValidation).toBe(CoverageLevel.FULL)
    expect(rep.stateValidation).toBe(CoverageLevel.FULL)
    expect(rep.toolAuthorization).toBe(CoverageLevel.FULL)
    expect(rep.toolExecutionValidation).toBe(CoverageLevel.FULL)
    expect(rep.toolOutputValidation).toBe(CoverageLevel.FULL)
    expect(rep.outputValidation).toBe(CoverageLevel.FULL)
    expect(rep.streamingOutput).toBe(CoverageLevel.PARTIAL)
    expect(rep.notes.length).toBeGreaterThan(0)
    expect(rep.notes[0]).toMatch(/streaming chunk-level Stage-5/)
  })

  it('shield.capabilities surfaces the bundle report', () => {
    const shield = buildShield()
    expect(shield.capabilities).toBe(ANTHROPIC_AGENTS_CAPABILITIES)
  })
})

describe('Anthropic adapter — Pattern A (runAnthropicAgent)', () => {
  it('Stage 1 block: client.beta.messages.toolRunner is never called', async () => {
    const shield = (Shield as any)
      .fromYaml(INPUT_BLOCK)
      .withAnthropic()
      .build()
    const client = makeFakeAnthropicClient([])
    const dispatchTool = vi.fn()
    const result = await shield.runAnthropicAgent({
      client,
      model: 'claude-sonnet-4-20250514',
      tools: [],
      messages: [{ role: 'user', content: 'please DENY_ME run' }],
      dispatchTool,
    })
    expect(result).toContain('GUARDRAIL')
    expect(client.beta.messages.toolRunner).not.toHaveBeenCalled()
    expect(client.messages.create).not.toHaveBeenCalled()
    expect(dispatchTool).not.toHaveBeenCalled()
  })

  it('drives a tool_use → end_turn loop and returns final text', async () => {
    const stagesShield = buildShieldFromYaml(STAGES_YAML)
    const client = makeFakeAnthropicClient([
      {
        stop_reason: 'tool_use',
        toolUses: [{ id: 'toolu_1', name: 'weather', input: { city: 'Seattle' } }],
      },
      { stop_reason: 'end_turn', text: 'the weather is sunny' },
    ])
    const dispatch = vi.fn(async (_name: string, args: any) => `weather:${args.city}`)
    const result = await stagesShield.runAnthropicAgent({
      client,
      model: 'claude-sonnet-4-20250514',
      tools: [{ name: 'weather', description: 'w', input_schema: {} }],
      messages: [{ role: 'user', content: 'how is the weather?' }],
      dispatchTool: dispatch,
    })

    expect(result).toBe('the weather is sunny')
    expect(client.beta.messages.toolRunner).toHaveBeenCalledTimes(1)
    expect(dispatch).toHaveBeenCalledTimes(1)
    expect(dispatch).toHaveBeenCalledWith('weather', { city: 'Seattle' })

    const tr = client._lastRunner?.toolResults
    expect(tr).toHaveLength(1)
    expect(tr![0].tool_use_id).toBe('toolu_1')
    expect(tr![0].content).toBe('weather:Seattle')
    expect(tr![0].is_error).toBeUndefined()
  })

  it('forwards model + max_tokens + system + max_iterations to the runner body', async () => {
    const stagesShield = buildShieldFromYaml(STAGES_YAML)
    const client = makeFakeAnthropicClient([
      { stop_reason: 'end_turn', text: 'done' },
    ])
    const dispatch = vi.fn()
    await stagesShield.runAnthropicAgent({
      client,
      model: 'claude-haiku-test',
      tools: [],
      messages: [{ role: 'user', content: 'hi' }],
      dispatchTool: dispatch,
      system: 'be terse',
      maxTokens: 256,
      maxIters: 3,
    })
    const body = client.beta.messages.toolRunner.mock.calls[0][0]
    expect(body.model).toBe('claude-haiku-test')
    expect(body.max_tokens).toBe(256)
    expect(body.system).toBe('be terse')
    expect(body.max_iterations).toBe(3)
    expect(body.messages).toEqual([{ role: 'user', content: 'hi' }])
  })

  it('Stage 2 block: dispatchTool never called for forbidden tool, tool_result carries is_error', async () => {
    const shield = buildShieldFromYaml(STAGES_YAML)
    const client = makeFakeAnthropicClient([
      {
        stop_reason: 'tool_use',
        toolUses: [{ id: 'toolu_x', name: 'secret_tool', input: { x: 1 } }],
      },
      { stop_reason: 'end_turn', text: 'all done' },
    ])
    const dispatchTool = vi.fn(async () => 'should not run')
    const result = await shield.runAnthropicAgent({
      client,
      model: 'claude-sonnet-4-20250514',
      tools: [{ name: 'secret_tool', description: 's', input_schema: {} }],
      messages: [{ role: 'user', content: 'please use secret_tool' }],
      dispatchTool,
    })

    expect(dispatchTool).not.toHaveBeenCalled()
    expect(result).toBe('all done')
    const tr = client._lastRunner?.toolResults
    expect(tr).toHaveLength(1)
    expect(tr![0].is_error).toBe(true)
    expect(String(tr![0].content)).toContain('GUARDRAIL')
    expect(String(tr![0].content)).toContain('secret_tool')
  })

  it('Stage 3 mutation: redacted args reach dispatchTool', async () => {
    const shield = buildShieldFromYaml(STAGES_YAML)
    const client = makeFakeAnthropicClient([
      {
        stop_reason: 'tool_use',
        toolUses: [
          {
            id: 'toolu_a',
            name: 'weather',
            input: { city: 'REDACT_ME_ARG-Seattle' },
          },
        ],
      },
      { stop_reason: 'end_turn', text: 'done' },
    ])
    const dispatchTool = vi.fn(async (_n: string, args: any) => `ok:${args.city}`)
    const result = await shield.runAnthropicAgent({
      client,
      model: 'claude-sonnet-4-20250514',
      tools: [{ name: 'weather', description: 'w', input_schema: {} }],
      messages: [{ role: 'user', content: 'check' }],
      dispatchTool,
    })
    expect(result).toBe('done')
    expect(dispatchTool).toHaveBeenCalledTimes(1)
    const passedArgs = dispatchTool.mock.calls[0][1] as any
    expect(JSON.stringify(passedArgs)).not.toContain('REDACT_ME_ARG')
    expect(JSON.stringify(passedArgs)).toContain('[ARG_REDACTED]')
  })

  it('Stage 4 redaction: tool result is redacted before the runner sees it', async () => {
    const shield = buildShieldFromYaml(STAGES_YAML)
    const client = makeFakeAnthropicClient([
      {
        stop_reason: 'tool_use',
        toolUses: [{ id: 'toolu_b', name: 'weather', input: { city: 'Seattle' } }],
      },
      { stop_reason: 'end_turn', text: 'done' },
    ])
    const dispatchTool = vi.fn(async () => 'temperature: REDACT_ME_OUTPUT degrees')
    const result = await shield.runAnthropicAgent({
      client,
      model: 'claude-sonnet-4-20250514',
      tools: [{ name: 'weather', description: 'w', input_schema: {} }],
      messages: [{ role: 'user', content: 'check' }],
      dispatchTool,
    })
    expect(result).toBe('done')
    const tr = client._lastRunner?.toolResults
    expect(tr).toHaveLength(1)
    expect(String(tr![0].content)).not.toContain('REDACT_ME_OUTPUT')
    expect(String(tr![0].content)).toContain('[OUTPUT_REDACTED]')
  })

  it('Stage 5 block: final assistant text is gated by output_validation', async () => {
    const shield = buildShieldFromYaml(STAGES_YAML)
    const client = makeFakeAnthropicClient([
      {
        stop_reason: 'end_turn',
        text: 'the answer is DENY_ME_OUTPUT confidential',
      },
    ])
    const dispatchTool = vi.fn()
    const result = await shield.runAnthropicAgent({
      client,
      model: 'claude-sonnet-4-20250514',
      tools: [],
      messages: [{ role: 'user', content: 'tell me' }],
      dispatchTool,
    })
    expect(result).toContain('GUARDRAIL')
    expect(dispatchTool).not.toHaveBeenCalled()
  })

  it('tool exception path records failure and produces an error tool_result', async () => {
    const shield = buildShieldFromYaml(STAGES_YAML)
    const client = makeFakeAnthropicClient([
      {
        stop_reason: 'tool_use',
        toolUses: [{ id: 'toolu_c', name: 'weather', input: { city: 'X' } }],
      },
      { stop_reason: 'end_turn', text: 'handled' },
    ])
    const dispatchTool = vi.fn(async () => {
      throw new Error('boom')
    })
    const result = await shield.runAnthropicAgent({
      client,
      model: 'claude-sonnet-4-20250514',
      tools: [{ name: 'weather', description: 'w', input_schema: {} }],
      messages: [{ role: 'user', content: 'check' }],
      dispatchTool,
    })
    expect(result).toBe('handled')
    expect(dispatchTool).toHaveBeenCalledTimes(1)
    const tr = client._lastRunner?.toolResults
    expect(tr).toHaveLength(1)
    expect(tr![0].is_error).toBe(true)
    expect(String(tr![0].content)).toContain('boom')
  })

  it('multi-iter loop: drives multiple tool_use rounds', async () => {
    const shield = buildShieldFromYaml(STAGES_YAML)
    const client = makeFakeAnthropicClient([
      {
        stop_reason: 'tool_use',
        toolUses: [{ id: 'toolu_1', name: 'weather', input: { city: 'A' } }],
      },
      {
        stop_reason: 'tool_use',
        toolUses: [{ id: 'toolu_2', name: 'weather', input: { city: 'B' } }],
      },
      { stop_reason: 'end_turn', text: 'A and B both checked' },
    ])
    let count = 0
    const dispatchTool = vi.fn(async (_n: string, args: any) => {
      count++
      return `r${count}:${args.city}`
    })
    const result = await shield.runAnthropicAgent({
      client,
      model: 'claude-sonnet-4-20250514',
      tools: [{ name: 'weather', description: 'w', input_schema: {} }],
      messages: [{ role: 'user', content: 'check both' }],
      dispatchTool,
    })
    expect(result).toBe('A and B both checked')
    expect(dispatchTool).toHaveBeenCalledTimes(2)
    expect(client._lastRunner?.toolResults).toHaveLength(2)
  })

  it('respects maxIters when the model never returns end_turn', async () => {
    const shield = buildShieldFromYaml(STAGES_YAML)
    const client = makeFakeAnthropicClient([
      {
        stop_reason: 'tool_use',
        toolUses: [{ id: 'toolu_1', name: 'weather', input: { city: 'A' } }],
      },
      {
        stop_reason: 'tool_use',
        toolUses: [{ id: 'toolu_2', name: 'weather', input: { city: 'B' } }],
      },
      {
        stop_reason: 'tool_use',
        toolUses: [{ id: 'toolu_3', name: 'weather', input: { city: 'C' } }],
      },
    ])
    const dispatchTool = vi.fn(async () => 'ok')
    await shield.runAnthropicAgent({
      client,
      model: 'claude-sonnet-4-20250514',
      tools: [{ name: 'weather', description: 'w', input_schema: {} }],
      messages: [{ role: 'user', content: 'go' }],
      dispatchTool,
      maxIters: 2,
    })
    expect(dispatchTool).toHaveBeenCalledTimes(2)
    const body = client.beta.messages.toolRunner.mock.calls[0][0]
    expect(body.max_iterations).toBe(2)
  })

  it('does not fail-OPEN on malformed (non-object) tool args from the model', async () => {
    const shield = buildShieldFromYaml(STAGES_YAML)
    const client = makeFakeAnthropicClient([
      {
        stop_reason: 'tool_use',
        toolUses: [
          {
            id: 'toolu_x',
            name: 'weather',
            input: 'not-an-object' as unknown as Record<string, unknown>,
          },
        ],
      },
      { stop_reason: 'end_turn', text: 'recovered' },
    ])
    const dispatchTool = vi.fn(async () => 'ok')
    const result = await shield.runAnthropicAgent({
      client,
      model: 'claude-sonnet-4-20250514',
      tools: [{ name: 'weather', description: 'w', input_schema: {} }],
      messages: [{ role: 'user', content: 'check' }],
      dispatchTool,
    })
    expect(result).toBe('recovered')
    expect(dispatchTool).toHaveBeenCalledTimes(1)
    const passedArgs = dispatchTool.mock.calls[0][1]
    expect(typeof passedArgs).toBe('object')
    expect(passedArgs).not.toBe('not-an-object')
  })

  it('throws a clear error when the client lacks beta.messages.toolRunner', async () => {
    const shield = buildShieldFromYaml(STAGES_YAML)
    const brokenClient = {
      messages: { create: vi.fn() },
    }
    await expect(
      shield.runAnthropicAgent({
        client: brokenClient as any,
        model: 'claude-sonnet-4-20250514',
        tools: [],
        messages: [{ role: 'user', content: 'hi' }],
        dispatchTool: vi.fn(),
      }),
    ).rejects.toThrow(/beta\.messages\.toolRunner/)
  })
})

describe('Anthropic adapter — Pattern B (protectAnthropicTools)', () => {
  it('returns a wrapped dispatcher and an unchanged tools list', () => {
    const shield = buildShieldFromYaml(STAGES_YAML)
    const tools = [{ name: 'weather', description: 'w', input_schema: {} }]
    const dispatchTool = vi.fn()
    const wrapped = shield.protectAnthropicTools({ tools, dispatchTool })
    expect(wrapped.tools).toBe(tools)
    expect(typeof wrapped.dispatchTool).toBe('function')
  })

  it('blocks unauthorized tools with a {blocked, blockMessage} shape', async () => {
    const shield = buildShieldFromYaml(STAGES_YAML)
    const dispatchTool = vi.fn(async () => 'ran')
    const wrapped = shield.protectAnthropicTools({ tools: [], dispatchTool, allowUnguarded: true })
    const r = (await wrapped.dispatchTool('secret_tool', {})) as any
    expect(r.blocked).toBe(true)
    expect(r.blockMessage).toContain('GUARDRAIL')
    expect(dispatchTool).not.toHaveBeenCalled()
  })

  it('passes Stage-3-mutated args to dispatchTool and returns the (possibly redacted) string', async () => {
    const shield = buildShieldFromYaml(STAGES_YAML)
    const dispatchTool = vi.fn(async (_n: string, args: any) => `ok:${args.city}`)
    const wrapped = shield.protectAnthropicTools({ tools: [], dispatchTool, allowUnguarded: true })
    const out = (await wrapped.dispatchTool('weather', {
      city: 'REDACT_ME_ARG-Seattle',
    })) as string
    expect(typeof out).toBe('string')
    expect(out).toContain('[ARG_REDACTED]')
    expect(dispatchTool).toHaveBeenCalledTimes(1)
    const passedArgs = dispatchTool.mock.calls[0][1] as any
    expect(JSON.stringify(passedArgs)).toContain('[ARG_REDACTED]')
  })

  it('redacts tool output via Stage 4', async () => {
    const shield = buildShieldFromYaml(STAGES_YAML)
    const dispatchTool = vi.fn(async () => 'value=REDACT_ME_OUTPUT-x')
    const wrapped = shield.protectAnthropicTools({ tools: [], dispatchTool, allowUnguarded: true })
    const out = (await wrapped.dispatchTool('weather', { city: 'A' })) as string
    expect(out).not.toContain('REDACT_ME_OUTPUT')
    expect(out).toContain('[OUTPUT_REDACTED]')
  })

  it('records tool failure when dispatchTool throws', async () => {
    const shield = buildShieldFromYaml(STAGES_YAML)
    const dispatchTool = vi.fn(async () => {
      throw new Error('kaboom')
    })
    const wrapped = shield.protectAnthropicTools({ tools: [], dispatchTool, allowUnguarded: true })
    const out = await wrapped.dispatchTool('weather', { city: 'A' })
    expect(typeof out).toBe('string')
    expect(out as string).toContain('kaboom')
  })
})


describe('Anthropic adapter — LLM caller observability', () => {
  const LLM_CONFIG_YAML = `metadata:
  name: anthropic-llm-error-fixture
  version: 0.1.0
  agent_shield_version: "2.0"
objective:
  goal: ["exercise LLM caller error observability"]
  forbidden: ["bypass"]
configurations:
  - id: stage1-judge
    type: llm
    provider: anthropic
    model: claude-3-5-haiku-latest
    max_tokens: 256
input_validation:
  guard_policies:
    - name: trivial
      evaluate_when:
        - patterns: ["x"]
          reason: "x"
      action: "block"
`

  const LLM_FIXTURE_DIR = path.resolve(__dirname, '.tmp-fixtures', 'anthropic-llm-error')
  const LLM_FIXTURE_PATH = path.join(LLM_FIXTURE_DIR, 'fixture.guardrails.yaml')
  beforeAll(() => {
    fs.mkdirSync(LLM_FIXTURE_DIR, { recursive: true })
    fs.writeFileSync(LLM_FIXTURE_PATH, LLM_CONFIG_YAML, 'utf8')
  })
  afterAll(() => {
    try {
      fs.rmSync(LLM_FIXTURE_DIR, { recursive: true, force: true })
    } catch {
    }
  })

  it('emits adapter.llm_caller_error AND returns a fail-closed block string', async () => {
    const captured: any[] = []
    const provider = (event: any): void => {
      captured.push(event)
    }
    const failingClient = {
      messages: {
        create: vi.fn(async () => {
          throw new Error('anthropic API 503: service unavailable')
        }),
      },
    }
    const builder = (Shield as any)
      .fromYaml(LLM_FIXTURE_PATH)
      .withAnthropic()
      .withObservability(provider)
      .withClient(failingClient)

    const boundCaller = (builder as any)._llmCaller as (req: unknown) => Promise<string>
    expect(typeof boundCaller).toBe('function')

    const shield = builder.build() as Shield
    expect(shield).toBeInstanceOf(Shield)

    const out = await boundCaller({ configurationId: 'stage1-judge', prompt: 'hi' })

    expect(typeof out).toBe('string')
    const decoded = JSON.parse(out)
    expect(decoded.decision).toBe('block')
    expect(decoded.reason).toContain('anthropic llm caller error')
    expect(decoded.reason).toContain('503')

    const errorEvents = captured.filter(
      (e) => e.eventType === 'adapter.llm_caller_error' && e.severity === 'warn',
    )
    expect(errorEvents).toHaveLength(1)
    const ev = errorEvents[0]
    expect(ev.category).toBe('adapter')
    expect(ev.severity).toBe('warn')
    expect(ev.message).toContain('anthropic_agents')
    expect(ev.message).not.toContain('503')
    expect(ev.attributes['agent_shield.adapter.name']).toBe('anthropic_agents')
    expect(ev.attributes['agent_shield.adapter.error_type']).toBeDefined()
    expect(ev.attributes['agent_shield.adapter.error_message']).toBeUndefined()
    const debugEvent = captured.find(
      (e) => e.eventType === 'adapter.llm_caller_error' && e.severity === 'debug',
    )
    expect(debugEvent).toBeDefined()
    expect(debugEvent!.attributes['agent_shield.adapter.error_message']).toContain('503')
  })

  it('AdapterContext captures providers BY REFERENCE so late registration still routes errors', async () => {
    const captured: any[] = []
    const provider = (event: any): void => {
      captured.push(event)
    }
    const failingClient = {
      messages: {
        create: vi.fn(async () => {
          throw new Error('upstream timeout')
        }),
      },
    }
    const builder = (Shield as any)
      .fromYaml(LLM_FIXTURE_PATH)
      .withAnthropic()
      .withClient(failingClient)
      .withObservability(provider)

    const boundCaller = (builder as any)._llmCaller as (req: unknown) => Promise<string>
    const shield = builder.build() as Shield
    expect(shield).toBeInstanceOf(Shield)

    const out = await boundCaller({ configurationId: 'stage1-judge', prompt: 'hi' })
    const decoded = JSON.parse(out)
    expect(decoded.decision).toBe('block')

    const errorEvents = captured.filter(
      (e) => e.eventType === 'adapter.llm_caller_error' && e.severity === 'warn',
    )
    expect(errorEvents).toHaveLength(1)
    expect(
      errorEvents[0].attributes['agent_shield.adapter.error_message'],
    ).toBeUndefined()
    const debugEvent = captured.find(
      (e) => e.eventType === 'adapter.llm_caller_error' && e.severity === 'debug',
    )
    expect(debugEvent).toBeDefined()
    expect(
      debugEvent!.attributes['agent_shield.adapter.error_message'],
    ).toContain('upstream timeout')
  })

  it('shield.recordAdapterError emits to providers even outside the LLM-caller path', () => {
    const captured: any[] = []
    const provider = (event: any): void => {
      captured.push(event)
    }
    const shield = (Shield as any)
      .fromYaml(MINIMAL)
      .withAnthropic()
      .withObservability(provider)
      .build() as Shield

    shield.recordAdapterError('custom_adapter', new TypeError('bad arg'))

    expect(captured).toHaveLength(2)
    const warn = captured.find((e) => e.severity === 'warn')!
    expect(warn.eventType).toBe('adapter.llm_caller_error')
    expect(warn.attributes['agent_shield.adapter.name']).toBe('custom_adapter')
    expect(warn.attributes['agent_shield.adapter.error_type']).toBe('TypeError')
    expect(warn.attributes['agent_shield.adapter.error_class']).toBe('TypeError')
    expect(warn.attributes['agent_shield.adapter.error_message']).toBeUndefined()
    const dbg = captured.find((e) => e.severity === 'debug')!
    expect(dbg.attributes['agent_shield.adapter.error_message']).toBe('bad arg')
  })
})
