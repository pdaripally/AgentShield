
import { describe, it, expect, vi } from 'vitest'
import * as path from 'node:path'
import {
  RuntimeBuilder,
  Shield,
  ShieldBuilder,
  CoverageLevel,
  AgentShieldBlockedError,
} from '../../../../../index.js'
import {
  OPENAI_CAPABILITIES,
  OPENAI_BUNDLE,
  install,
  _setAgentsModuleForTesting,
  _setAgentsOpenaiModuleForTesting,
  type AgentsLikeModule,
  type AgentsOpenaiLikeModule,
} from '../../../../../adapters/openai_agents.js'

install()

const FIXTURES = path.resolve(__dirname, '../../../../../../../tests/fixtures/smoke')
const MINIMAL = path.join(FIXTURES, 'minimal.guardrails.yaml')
const INPUT_BLOCK = path.join(FIXTURES, 'input-block.guardrails.yaml')

const COMMON_HEADER = `metadata:
  name: "openai-adapter-test"
  version: "0.1.0"
  agent_shield_version: "2.0"

objective:
  goal: ["Test OpenAI adapter."]
  forbidden: ["Mishandle the test fixture."]

resources:
  tools:
    - name: "echo"
      description: "Echoes a message back."
      permission: "read_only"
`

function buildShieldFromYaml(yaml: string): Shield {
  const rt = RuntimeBuilder.fromYamlStrings([yaml]).build()
  return new (Shield as any)(rt, { bundle: OPENAI_BUNDLE })
}

function buildShieldFromPath(p: string): Shield {
  const rt = RuntimeBuilder.fromYaml(p).build()
  return new (Shield as any)(rt, { bundle: OPENAI_BUNDLE })
}


interface FakeAgent {
  name: string
  instructions: string
  model: string
  tools: any[]
  [k: string]: unknown
}

interface FakeWrappedTool {
  type: 'function'
  name: string
  description: string
  parameters: any
  strict: boolean
  execute: (input: any) => Promise<unknown>
}

interface ScenarioToolCall {
  name: string
  args: Record<string, unknown> | string
  asString?: boolean
}

interface Scenario {
  toolCalls?: ScenarioToolCall[]
  finalOutput: string
}

function makeFakeAgentsModule(scenario: Scenario): {
  agentsMod: AgentsLikeModule
  runSpy: ReturnType<typeof vi.fn>
  toolResults: string[]
} {
  const toolResults: string[] = []

  const runSpy = vi.fn(
    async (agent: FakeAgent, _input: string, _opts?: Record<string, unknown>) => {
      void _input
      void _opts
      for (const tc of scenario.toolCalls ?? []) {
        const tool = agent.tools.find((t: any) => t.name === tc.name) as
          | FakeWrappedTool
          | undefined
        if (!tool) {
          throw new Error(
            `fake Runner: agent has no tool named ${tc.name}; tools=` +
              JSON.stringify(agent.tools.map((t: any) => t.name)),
          )
        }
        let payload: unknown
        if (tc.asString === true) {
          payload =
            typeof tc.args === 'string' ? tc.args : JSON.stringify(tc.args)
        } else {
          payload = tc.args
        }
        const callable = (tool as any).invoke ?? (tool as any).execute
        let out: unknown
        if ((tool as any).invoke && !(tool as any).execute) {
          out = await (tool as any).invoke(
            null,
            typeof payload === 'string' ? payload : JSON.stringify(payload),
            undefined,
          )
        } else {
          out = await (callable as (i: unknown) => Promise<unknown>)(payload)
        }
        toolResults.push(typeof out === 'string' ? out : JSON.stringify(out))
      }
      return { finalOutput: scenario.finalOutput }
    },
  )

  const agentsMod: AgentsLikeModule = {
    Agent: function (this: FakeAgent, opts: any) {
      Object.assign(this, opts)
    } as any,
    tool: (opts: any): FakeWrappedTool => ({
      type: 'function',
      name: opts.name,
      description: opts.description,
      parameters: opts.parameters,
      strict: !!opts.strict,
      execute: opts.execute,
    }),
    run: runSpy,
  }

  return { agentsMod, runSpy, toolResults }
}

function makeFakeAgentsOpenaiModule(): {
  agentsOpenaiMod: AgentsOpenaiLikeModule
  setClient: ReturnType<typeof vi.fn>
  setApi: ReturnType<typeof vi.fn>
} {
  const setClient = vi.fn()
  const setApi = vi.fn()
  return {
    agentsOpenaiMod: {
      setDefaultOpenAIClient: setClient,
      setOpenAIAPI: setApi,
    },
    setClient,
    setApi,
  }
}

function makeStubClient(): any {
  return {
    chat: {
      completions: {
        create: vi.fn(async () => {
          throw new Error(
            'unexpected: Runner-based runOpenaiAgent must not call chat.completions.create directly',
          )
        }),
      },
    },
    _isStubClient: true,
  }
}


describe('OpenAI adapter — capability report', () => {
  it('exposes the documented coverage matrix', () => {
    expect(OPENAI_CAPABILITIES.framework).toBe('openai_agents')
    expect(OPENAI_CAPABILITIES.inputValidation).toBe(CoverageLevel.FULL)
    expect(OPENAI_CAPABILITIES.stateValidation).toBe(CoverageLevel.FULL)
    expect(OPENAI_CAPABILITIES.toolAuthorization).toBe(CoverageLevel.FULL)
    expect(OPENAI_CAPABILITIES.toolExecutionValidation).toBe(CoverageLevel.FULL)
    expect(OPENAI_CAPABILITIES.toolOutputValidation).toBe(CoverageLevel.FULL)
    expect(OPENAI_CAPABILITIES.outputValidation).toBe(CoverageLevel.FULL)
    expect(OPENAI_CAPABILITIES.streamingOutput).toBe(CoverageLevel.PARTIAL)
    expect(OPENAI_CAPABILITIES.notes.length).toBeGreaterThan(0)
    expect(OPENAI_CAPABILITIES.notes[0]).toContain('Pattern')
  })

  it('shield.capabilities reports the OpenAI profile', () => {
    const shield = buildShieldFromPath(MINIMAL)
    expect(shield.capabilities.framework).toBe('openai_agents')
    expect(shield.capabilities.streamingOutput).toBe(CoverageLevel.PARTIAL)
  })
})

describe('OpenAI adapter — builder install', () => {
  it('installs withOpenaiAgents on ShieldBuilder.prototype', () => {
    expect(typeof (ShieldBuilder.prototype as any).withOpenaiAgents).toBe(
      'function',
    )
  })

  it('withOpenaiAgents returns the builder and sets the bundle', () => {
    const builder = new (ShieldBuilder as any)(Shield, null, MINIMAL)
    const ret = builder.withOpenaiAgents()
    expect(ret).toBe(builder)
    expect(builder._bundle).toBe(OPENAI_BUNDLE)
  })

  it('Shield.fromYaml(...).withOpenaiAgents.build works without subclassing', () => {
    const shield = (Shield as any).fromYaml(MINIMAL).withOpenaiAgents().build()
    expect(shield.capabilities.framework).toBe('openai_agents')
  })

  it('installs runOpenaiAgent, protectOpenaiTools on Shield.prototype; protectTool and run remain on the base class', () => {
    expect(typeof (Shield.prototype as any).runOpenaiAgent).toBe('function')
    expect(typeof (Shield.prototype as any).protectOpenaiTools).toBe('function')
    expect(typeof (Shield.prototype as any).protectTool).toBe('function')
    expect(typeof (Shield.prototype as any).run).toBe('function')
  })
})


describe('runOpenaiAgent — Pattern A (Runner-driven)', () => {
  it('runs the loop: Runner.run drives tool call → tool result → final output', async () => {
    const yaml =
      COMMON_HEADER +
      `variables:
  - name: "authorized"
    type: "boolean"
    default: true
`
    const shield = buildShieldFromYaml(yaml)
    const dispatch = vi.fn(async (_name: string, args: any) => `pong:${args.msg}`)
    const fake = makeFakeAgentsModule({
      toolCalls: [{ name: 'echo', args: { msg: 'hi' }, asString: true }],
      finalOutput: 'final answer',
    })
    const fakeOai = makeFakeAgentsOpenaiModule()
    const client = makeStubClient()

    const result = await (shield as any).runOpenaiAgent({
      client,
      model: 'gpt-4o-mini',
      tools: [{ type: 'function', function: { name: 'echo' } }],
      messages: [{ role: 'user', content: 'hello' }],
      dispatchToolCall: dispatch,
      _agentsModule: fake.agentsMod,
      _agentsOpenaiModule: fakeOai.agentsOpenaiMod,
    })

    expect(result).toBe('final answer')
    expect(dispatch).toHaveBeenCalledTimes(1)
    expect(dispatch).toHaveBeenCalledWith('echo', { msg: 'hi' })
    expect(fake.runSpy).toHaveBeenCalledTimes(1)
    expect(fake.runSpy.mock.calls[0][1]).toBe('hello')
    expect(fake.runSpy.mock.calls[0][2]).toEqual({ maxTurns: 10 })
    expect(fake.toolResults[0]).toBe('pong:hi')
    expect(fakeOai.setClient).toHaveBeenCalledTimes(1)
    expect(fakeOai.setClient).toHaveBeenCalledWith(client)
    expect(fakeOai.setApi).toHaveBeenCalledWith('chat_completions')
  })

  it('forwards maxIters to Runner.run as maxTurns', async () => {
    const yaml =
      COMMON_HEADER +
      `variables:
  - name: "authorized"
    type: "boolean"
    default: true
`
    const shield = buildShieldFromYaml(yaml)
    const fake = makeFakeAgentsModule({ finalOutput: 'done' })
    const fakeOai = makeFakeAgentsOpenaiModule()

    await (shield as any).runOpenaiAgent({
      model: 'gpt-4o-mini',
      client: makeStubClient(),
      messages: [{ role: 'user', content: 'hi' }],
      maxIters: 3,
      _agentsModule: fake.agentsMod,
      _agentsOpenaiModule: fakeOai.agentsOpenaiMod,
    })

    expect(fake.runSpy.mock.calls[0][2]).toEqual({ maxTurns: 3 })
  })

  it('Stage 1 block: blocked input short-circuits before Runner.run', async () => {
    const shield = buildShieldFromPath(INPUT_BLOCK)
    const dispatch = vi.fn()
    const fake = makeFakeAgentsModule({ finalOutput: 'should not reach here' })
    const fakeOai = makeFakeAgentsOpenaiModule()

    const result = await (shield as any).runOpenaiAgent({
      model: 'gpt-4o-mini',
      client: makeStubClient(),
      messages: [{ role: 'user', content: 'please trigger DENY_ME' }],
      dispatchToolCall: dispatch,
      _agentsModule: fake.agentsMod,
      _agentsOpenaiModule: fakeOai.agentsOpenaiMod,
    })

    expect(result).toContain('GUARDRAIL')
    expect(fake.runSpy).not.toHaveBeenCalled()
    expect(dispatch).not.toHaveBeenCalled()
  })

  it('Stage 2 block: disallowed tool halts the Runner; runOpenaiAgent returns the canonical [GUARDRAIL] block message ', async () => {
    const shield = buildShieldFromPath(MINIMAL)
    const dispatch = vi.fn(async () => 'should never run')
    const fake = makeFakeAgentsModule({
      toolCalls: [{ name: 'echo', args: { msg: 'hi' }, asString: true }],
      finalOutput: 'fallback',
    })
    const fakeOai = makeFakeAgentsOpenaiModule()

    const result = await (shield as any).runOpenaiAgent({
      model: 'gpt-4o-mini',
      client: makeStubClient(),
      tools: [{ type: 'function', function: { name: 'echo' } }],
      messages: [{ role: 'user', content: 'please echo' }],
      dispatchToolCall: dispatch,
      _agentsModule: fake.agentsMod,
      _agentsOpenaiModule: fakeOai.agentsOpenaiMod,
    })

    expect(dispatch).not.toHaveBeenCalled()
    expect(result).toMatch(/\[GUARDRAIL\b/)
    expect(result).not.toBe('fallback')
  })

  it('Stage 3 redact: mutated args reach the dispatcher under the wrapped execute', async () => {
    const yaml =
      COMMON_HEADER +
      `variables:
  - name: "authorized"
    type: "boolean"
    default: true

tool_execution_validation:
  guard_policies:
    - name: "redact_secret"
      evaluate_when:
        - patterns: ["TOPSECRET"]
          reason: "Secret in tool args."
      action: "redact"
      replacement: "[REDACTED]"
`
    const shield = buildShieldFromYaml(yaml)
    const seen: any[] = []
    const dispatch = vi.fn(async (_name: string, args: any) => {
      seen.push(args)
      return 'ok'
    })
    const fake = makeFakeAgentsModule({
      toolCalls: [
        { name: 'echo', args: { msg: 'TOPSECRET payload' }, asString: true },
      ],
      finalOutput: 'done',
    })
    const fakeOai = makeFakeAgentsOpenaiModule()

    const result = await (shield as any).runOpenaiAgent({
      model: 'gpt-4o-mini',
      client: makeStubClient(),
      tools: [{ type: 'function', function: { name: 'echo' } }],
      messages: [{ role: 'user', content: 'echo a secret' }],
      dispatchToolCall: dispatch,
      _agentsModule: fake.agentsMod,
      _agentsOpenaiModule: fakeOai.agentsOpenaiMod,
    })

    expect(result).toBe('done')
    expect(dispatch).toHaveBeenCalledTimes(1)
    expect(seen[0].msg).toContain('[REDACTED]')
    expect(seen[0].msg).not.toContain('TOPSECRET')
  })

  it('Stage 4 redact: tool result is redacted before being returned to the Runner', async () => {
    const yaml =
      COMMON_HEADER +
      `variables:
  - name: "authorized"
    type: "boolean"
    default: true

post_tool_validation:
  guard_policies:
    - name: "ssn_redact"
      evaluate_when:
        - patterns: ["\\\\b\\\\d{3}-\\\\d{2}-\\\\d{4}\\\\b"]
          reason: "SSN in tool output."
      action: "redact"
      replacement: "[SSN]"
`
    const shield = buildShieldFromYaml(yaml)
    const dispatch = vi.fn(async () => 'My SSN is 123-45-6789, carry on.')
    const fake = makeFakeAgentsModule({
      toolCalls: [{ name: 'echo', args: {}, asString: true }],
      finalOutput: 'all clear',
    })
    const fakeOai = makeFakeAgentsOpenaiModule()

    await (shield as any).runOpenaiAgent({
      model: 'gpt-4o-mini',
      client: makeStubClient(),
      tools: [{ type: 'function', function: { name: 'echo' } }],
      messages: [{ role: 'user', content: 'fetch' }],
      dispatchToolCall: dispatch,
      _agentsModule: fake.agentsMod,
      _agentsOpenaiModule: fakeOai.agentsOpenaiMod,
    })

    expect(fake.toolResults[0]).toContain('[SSN]')
    expect(fake.toolResults[0]).not.toContain('123-45-6789')
  })

  it('Stage 5 block: Runner.finalOutput blocked', async () => {
    const yaml =
      COMMON_HEADER +
      `output_validation:
  guard_policies:
    - name: "no_leak"
      evaluate_when:
        - patterns: ["LEAK"]
          reason: "Forbidden token in output."
      action: "block"
`
    const shield = buildShieldFromYaml(yaml)
    const fake = makeFakeAgentsModule({ finalOutput: 'here is the LEAK token' })
    const fakeOai = makeFakeAgentsOpenaiModule()

    const result = await (shield as any).runOpenaiAgent({
      model: 'gpt-4o-mini',
      client: makeStubClient(),
      messages: [{ role: 'user', content: 'tell me' }],
      _agentsModule: fake.agentsMod,
      _agentsOpenaiModule: fakeOai.agentsOpenaiMod,
    })

    expect(result).toContain('GUARDRAIL')
  })

  it('tool exception → record_tool_failure + error fed back to Runner', async () => {
    const yaml =
      COMMON_HEADER +
      `variables:
  - name: "authorized"
    type: "boolean"
    default: true
`
    const shield = buildShieldFromYaml(yaml)
    const { runtime } = shield as any
    const origNewSession = runtime.newSession.bind(runtime)
    const failures: any[] = []
    runtime.newSession = (ctx?: any) => {
      const s = origNewSession(ctx)
      const orig = s.recordToolFailure.bind(s)
      s.recordToolFailure = (name: string, err: string) => {
        failures.push({ name, err })
        return orig(name, err)
      }
      return s
    }

    const dispatch = vi.fn(async () => {
      throw new Error('boom')
    })
    const fake = makeFakeAgentsModule({
      toolCalls: [{ name: 'echo', args: {}, asString: true }],
      finalOutput: 'recovered',
    })
    const fakeOai = makeFakeAgentsOpenaiModule()

    await (shield as any).runOpenaiAgent({
      model: 'gpt-4o-mini',
      client: makeStubClient(),
      tools: [{ type: 'function', function: { name: 'echo' } }],
      messages: [{ role: 'user', content: 'go' }],
      dispatchToolCall: dispatch,
      _agentsModule: fake.agentsMod,
      _agentsOpenaiModule: fakeOai.agentsOpenaiMod,
    })

    expect(failures.length).toBeGreaterThan(0)
    expect(failures[0].name).toBe('echo')
    expect(failures[0].err).toContain('boom')
    expect(fake.toolResults[0]).toContain('boom')
  })

  it('handles tools where Runner hands us a pre-parsed object (no JSON parse)', async () => {
    const yaml =
      COMMON_HEADER +
      `variables:
  - name: "authorized"
    type: "boolean"
    default: true
`
    const shield = buildShieldFromYaml(yaml)
    const seen: any[] = []
    const dispatch = vi.fn(async (_name: string, args: any) => {
      seen.push(args)
      return 'ok'
    })
    const fake = makeFakeAgentsModule({
      toolCalls: [{ name: 'echo', args: { msg: 'parsed-obj' }, asString: false }],
      finalOutput: 'done',
    })
    const fakeOai = makeFakeAgentsOpenaiModule()

    await (shield as any).runOpenaiAgent({
      model: 'gpt-4o-mini',
      client: makeStubClient(),
      tools: [{ type: 'function', function: { name: 'echo' } }],
      messages: [{ role: 'user', content: 'go' }],
      dispatchToolCall: dispatch,
      _agentsModule: fake.agentsMod,
      _agentsOpenaiModule: fakeOai.agentsOpenaiMod,
    })

    expect(seen[0]).toEqual({ msg: 'parsed-obj' })
  })

  it('unparseable JSON string args fail closed: dispatcher sees {} instead of crashing', async () => {
    const yaml =
      COMMON_HEADER +
      `variables:
  - name: "authorized"
    type: "boolean"
    default: true
`
    const shield = buildShieldFromYaml(yaml)
    const seen: any[] = []
    const dispatch = vi.fn(async (_name: string, args: any) => {
      seen.push(args)
      return 'ok'
    })
    const fake = makeFakeAgentsModule({
      toolCalls: [{ name: 'echo', args: '{not valid json', asString: true }],
      finalOutput: 'done',
    })
    const fakeOai = makeFakeAgentsOpenaiModule()

    const result = await (shield as any).runOpenaiAgent({
      model: 'gpt-4o-mini',
      client: makeStubClient(),
      tools: [{ type: 'function', function: { name: 'echo' } }],
      messages: [{ role: 'user', content: 'go' }],
      dispatchToolCall: dispatch,
      _agentsModule: fake.agentsMod,
      _agentsOpenaiModule: fakeOai.agentsOpenaiMod,
    })

    expect(result).toBe('done')
    expect(dispatch).toHaveBeenCalledTimes(1)
    expect(seen[0]).toEqual({})
  })

  it('emits an install hint when @openai/agents is not available', async () => {
    const shield = buildShieldFromPath(MINIMAL)
    _setAgentsModuleForTesting(null)
    await expect(
      (shield as any).runOpenaiAgent({
        model: 'gpt-4o-mini',
        client: makeStubClient(),
        messages: [{ role: 'user', content: 'hi' }],
      }),
    ).rejects.toThrow(/@openai\/agents.*is not installed/i)
  })

  it('honours the global test seam when no per-call override is supplied', async () => {
    const shield = buildShieldFromPath(MINIMAL)
    const fake = makeFakeAgentsModule({ finalOutput: 'global-seam' })
    _setAgentsModuleForTesting(fake.agentsMod)
    _setAgentsOpenaiModuleForTesting({
      setDefaultOpenAIClient: vi.fn(),
      setOpenAIAPI: vi.fn(),
    })
    try {
      const result = await (shield as any).runOpenaiAgent({
        model: 'gpt-4o-mini',
        client: makeStubClient(),
        messages: [{ role: 'user', content: 'hi' }],
      })
      expect(result).toBe('global-seam')
    } finally {
      _setAgentsModuleForTesting(null)
      _setAgentsOpenaiModuleForTesting(null)
    }
  })

  it('accepts pre-built FunctionTool objects: re-wraps `.invoke` for Stage 2/3/4', async () => {
    const yaml =
      COMMON_HEADER +
      `variables:
  - name: "authorized"
    type: "boolean"
    default: true
`
    const shield = buildShieldFromYaml(yaml)
    const innerInvoke = vi.fn(async (_ctx: any, inputJson: string) => {
      const parsed = JSON.parse(inputJson)
      return `pre-built:${parsed.msg}`
    })
    const preBuiltTool = {
      type: 'function' as const,
      name: 'echo',
      description: 'pre-built echo',
      parameters: { type: 'object', properties: {} },
      strict: false,
      invoke: innerInvoke,
    }
    const fake = makeFakeAgentsModule({
      toolCalls: [{ name: 'echo', args: { msg: 'hello' }, asString: true }],
      finalOutput: 'done',
    })
    const fakeOai = makeFakeAgentsOpenaiModule()

    const result = await (shield as any).runOpenaiAgent({
      model: 'gpt-4o-mini',
      client: makeStubClient(),
      tools: [preBuiltTool],
      messages: [{ role: 'user', content: 'invoke' }],
      _agentsModule: fake.agentsMod,
      _agentsOpenaiModule: fakeOai.agentsOpenaiMod,
    })

    expect(result).toBe('done')
    expect(innerInvoke).toHaveBeenCalledTimes(1)
    expect(fake.toolResults[0]).toBe('pre-built:hello')
  })
})


describe('runOpenaiAgent — agentConfig passthrough', () => {
  it('forwards arbitrary AgentOpts fields (tool_choice, outputType, handoffs) to the Agent constructor', async () => {
    const shield = buildShieldFromPath(MINIMAL)
    const fake = makeFakeAgentsModule({ finalOutput: 'ok' })
    const fakeOai = makeFakeAgentsOpenaiModule()
    const agentCtorCalls: any[] = []

    const agentsModWithSpy: typeof fake.agentsMod = {
      ...fake.agentsMod,
      Agent: function (this: any, opts: any) {
        agentCtorCalls.push(opts)
        Object.assign(this, opts)
      } as any,
    }

    const structuredOutputSchema = { type: 'object', properties: { ans: { type: 'string' } } }
    await (shield as any).runOpenaiAgent({
      model: 'gpt-4o-mini',
      client: makeStubClient(),
      messages: [{ role: 'user', content: 'hi' }],
      agentConfig: {
        tool_choice: 'auto',
        outputType: structuredOutputSchema,
        handoffs: ['triage-agent'],
        model_settings: { temperature: 0.1 },
      },
      _agentsModule: agentsModWithSpy,
      _agentsOpenaiModule: fakeOai.agentsOpenaiMod,
    })

    expect(agentCtorCalls).toHaveLength(1)
    const ctorOpts = agentCtorCalls[0]
    expect(ctorOpts.name).toBe('agent-shield-managed')
    expect(ctorOpts.model).toBe('gpt-4o-mini')
    expect(ctorOpts.tool_choice).toBe('auto')
    expect(ctorOpts.outputType).toBe(structuredOutputSchema)
    expect(ctorOpts.handoffs).toEqual(['triage-agent'])
    expect(ctorOpts.model_settings).toEqual({ temperature: 0.1 })
  })

  it('agentConfig.model overrides the adapter default (spread order: agentConfig wins)', async () => {
    const shield = buildShieldFromPath(MINIMAL)
    const fake = makeFakeAgentsModule({ finalOutput: 'ok' })
    const fakeOai = makeFakeAgentsOpenaiModule()
    const agentCtorCalls: any[] = []

    const agentsModWithSpy: typeof fake.agentsMod = {
      ...fake.agentsMod,
      Agent: function (this: any, opts: any) {
        agentCtorCalls.push(opts)
        Object.assign(this, opts)
      } as any,
    }

    await (shield as any).runOpenaiAgent({
      client: makeStubClient(),
      messages: [{ role: 'user', content: 'hi' }],
      model: 'gpt-3.5-turbo',
      agentConfig: { model: 'gpt-4o' },
      _agentsModule: agentsModWithSpy,
      _agentsOpenaiModule: fakeOai.agentsOpenaiMod,
    })

    expect(agentCtorCalls[0].model).toBe('gpt-4o')
  })

  it('agentConfig.tools is ignored (with a one-shot warn) — shield-wrapped tools survive', async () => {
    const yaml =
      COMMON_HEADER +
      `variables:
  - name: "authorized"
    type: "boolean"
    default: true
`
    const shield = buildShieldFromYaml(yaml)
    const dispatch = vi.fn(async (_n: string, args: any) => `out:${args.msg}`)
    const fake = makeFakeAgentsModule({
      toolCalls: [{ name: 'echo', args: { msg: 'hi' }, asString: true }],
      finalOutput: 'done',
    })
    const fakeOai = makeFakeAgentsOpenaiModule()
    const agentCtorCalls: any[] = []
    const agentsModWithSpy: typeof fake.agentsMod = {
      ...fake.agentsMod,
      Agent: function (this: any, opts: any) {
        agentCtorCalls.push(opts)
        Object.assign(this, opts)
      } as any,
    }

    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {})
    try {
      const result = await (shield as any).runOpenaiAgent({
        model: 'gpt-4o-mini',
        client: makeStubClient(),
        tools: [{ type: 'function', function: { name: 'echo' } }],
        dispatchToolCall: dispatch,
        messages: [{ role: 'user', content: 'hi' }],
        agentConfig: {
          tools: [
            {
              type: 'function',
              name: 'evil-unguarded',
              parameters: {},
              execute: vi.fn(),
            },
          ],
          tool_choice: 'auto',
        },
        _agentsModule: agentsModWithSpy,
        _agentsOpenaiModule: fakeOai.agentsOpenaiMod,
      })

      expect(result).toBe('done')
      expect(agentCtorCalls).toHaveLength(1)
      const ctorOpts = agentCtorCalls[0]

      expect(Array.isArray(ctorOpts.tools)).toBe(true)
      expect(ctorOpts.tools).toHaveLength(1)
      expect(ctorOpts.tools[0].name).toBe('echo')
      expect(ctorOpts.tool_choice).toBe('auto')

      expect(dispatch).toHaveBeenCalledTimes(1)

      const warnedAboutTools = warnSpy.mock.calls.some((args) =>
        String(args[0] ?? '').includes('agentConfig.tools'),
      )
      expect(warnedAboutTools).toBe(true)
    } finally {
      warnSpy.mockRestore()
    }
  })

  it('runs without agentConfig (backwards-compatible default)', async () => {
    const shield = buildShieldFromPath(MINIMAL)
    const fake = makeFakeAgentsModule({ finalOutput: 'ok' })
    const fakeOai = makeFakeAgentsOpenaiModule()
    const agentCtorCalls: any[] = []
    const agentsModWithSpy: typeof fake.agentsMod = {
      ...fake.agentsMod,
      Agent: function (this: any, opts: any) {
        agentCtorCalls.push(opts)
        Object.assign(this, opts)
      } as any,
    }

    await (shield as any).runOpenaiAgent({
      model: 'gpt-4o-mini',
      client: makeStubClient(),
      messages: [{ role: 'user', content: 'hi' }],
      _agentsModule: agentsModWithSpy,
      _agentsOpenaiModule: fakeOai.agentsOpenaiMod,
    })

    const keys = Object.keys(agentCtorCalls[0]).sort()
    expect(keys).toEqual(['instructions', 'model', 'name', 'tools'])
  })
})


describe('protectOpenaiTools — Pattern B', () => {
  it('returns a single (name, args) => Promise<string> dispatcher', async () => {
    const yaml =
      COMMON_HEADER +
      `variables:
  - name: "authorized"
    type: "boolean"
    default: true
`
    const shield = buildShieldFromYaml(yaml)
    const dispatch = vi.fn(async (_name: string, args: any) => `ok:${args.msg}`)
    const guarded = (shield as any).protectOpenaiTools({
      tools: [{ type: 'function', function: { name: 'echo' } }],
      dispatchToolCall: dispatch,
      allowUnguarded: true,
    })
    expect(typeof guarded).toBe('function')
    const out = await guarded('echo', { msg: 'hi' })
    expect(out).toBe('ok:hi')
    expect(dispatch).toHaveBeenCalledTimes(1)
  })

  it('blocks unauthorized tool by throwing AgentShieldBlockedError without firing dispatcher ', async () => {
    const shield = buildShieldFromPath(MINIMAL)
    const dispatch = vi.fn(async () => 'should not run')
    const guarded = (shield as any).protectOpenaiTools({
      dispatchToolCall: dispatch,
      allowUnguarded: true,
    })
    let caught: unknown = null
    try {
      await guarded('echo', { msg: 'hi' })
    } catch (err) {
      caught = err
    }
    expect(dispatch).not.toHaveBeenCalled()
    expect(caught).toBeInstanceOf(AgentShieldBlockedError)
    const blocked = caught as AgentShieldBlockedError
    expect(blocked.toolName).toBe('echo')
    expect(blocked.stage).toBe('tool_call')
    expect(blocked.blockMessage).toMatch(/GUARDRAIL/)
  })

  it('throws without dispatchToolCall', () => {
    const shield = buildShieldFromPath(MINIMAL)
    expect(() => (shield as any).protectOpenaiTools({})).toThrow(/dispatchToolCall/)
  })
})


describe('Shield.run — Pattern C', () => {
  it('runs Stage 1 + Stage 5 around an opaque thunk', async () => {
    const shield = buildShieldFromPath(MINIMAL)
    const result = await (shield as any).run(async () => 'final answer', {
      userInput: 'hello there',
    })
    expect(result).toBe('final answer')
  })

  it('blocks at Stage 1 before invoking the thunk', async () => {
    const shield = buildShieldFromPath(INPUT_BLOCK)
    const thunk = vi.fn(async () => 'never')
    const result = await (shield as any).run(thunk, {
      userInput: 'go DENY_ME now',
      onBlock: 'return_blocked',
    })
    expect(result).toContain('GUARDRAIL')
    expect(thunk).not.toHaveBeenCalled()
  })
})


function makeFakeStreamingAgentsModule(opts: {
  deltas: string[]
  toolCalls?: ScenarioToolCall[]
  finalOutput?: string
  raiseOnIter?: boolean
}): {
  agentsMod: AgentsLikeModule
  runSpy: ReturnType<typeof vi.fn>
  toolResults: string[]
} {
  const toolResults: string[] = []

  const runSpy = vi.fn(
    async (agent: FakeAgent, _input: string, runOpts?: Record<string, unknown>) => {
      for (const tc of opts.toolCalls ?? []) {
        const tool = agent.tools.find((t: any) => t.name === tc.name) as
          | FakeWrappedTool
          | undefined
        if (!tool) {
          throw new Error(`fake streamed Runner: agent has no tool ${tc.name}`)
        }
        const payload =
          tc.asString === true
            ? typeof tc.args === 'string'
              ? tc.args
              : JSON.stringify(tc.args)
            : tc.args
        let out: unknown
        if ((tool as any).invoke && !(tool as any).execute) {
          out = await (tool as any).invoke(
            null,
            typeof payload === 'string' ? payload : JSON.stringify(payload),
            undefined,
          )
        } else {
          out = await (tool as any).execute(payload)
        }
        toolResults.push(typeof out === 'string' ? out : JSON.stringify(out))
      }

      if (runOpts?.stream !== true) {
        return { finalOutput: opts.finalOutput ?? '' }
      }

      const deltas = opts.deltas
      const streamed = {
        async *[Symbol.asyncIterator]() {
          for (const d of deltas) {
            yield {
              type: 'raw_model_stream_event',
              data: { type: 'output_text_delta', delta: d },
            }
          }
          yield {
            type: 'run_item_stream_event',
            data: { type: 'message_output_created' },
          }
          if (opts.raiseOnIter) {
            throw new Error('upstream stream failure')
          }
        },
        completed: Promise.resolve(),
        finalOutput: opts.finalOutput ?? '',
      }
      return streamed as any
    },
  )

  const agentsMod: AgentsLikeModule = {
    Agent: function (this: FakeAgent, agentOpts: any) {
      Object.assign(this, agentOpts)
    } as any,
    tool: (toolOpts: any): FakeWrappedTool => ({
      type: 'function',
      name: toolOpts.name,
      description: toolOpts.description,
      parameters: toolOpts.parameters,
      strict: !!toolOpts.strict,
      execute: toolOpts.execute,
    }),
    run: runSpy,
  }
  return { agentsMod, runSpy, toolResults }
}

async function collect<T>(iter: AsyncIterable<T>): Promise<T[]> {
  const out: T[] = []
  for await (const x of iter) out.push(x)
  return out
}

describe('runOpenaiAgentStreamed — Pattern A (streamed Runner-driven)', () => {
  it('installs runOpenaiAgentStreamed on Shield.prototype', () => {
    expect(typeof (Shield.prototype as any).runOpenaiAgentStreamed).toBe(
      'function',
    )
  })

  it('PerChunk: streams text deltas in real time (engine payload, not raw chunk)', async () => {
    const yaml = COMMON_HEADER
    const rt = RuntimeBuilder.fromYamlStrings([yaml])
      .streamingWindow({ trigger: 'per_chunk', windowSize: 1, overlap: 0 })
      .build()
    const shield = new (Shield as any)(rt, { bundle: OPENAI_BUNDLE })

    const fake = makeFakeStreamingAgentsModule({
      deltas: ['Hello ', 'world', '!'],
    })

    const events = await collect(
      (shield as any).runOpenaiAgentStreamed({
        model: 'gpt-4o-mini',
        client: makeStubClient(),
        messages: [{ role: 'user', content: 'say hi' }],
        _agentsModule: fake.agentsMod,
        _agentsOpenaiModule: makeFakeAgentsOpenaiModule().agentsOpenaiMod,
      }),
    )

    const deltas = events.filter((e: any) => e.type === 'text_delta')
    expect(deltas.length).toBeGreaterThanOrEqual(1)
    const final = events.find((e: any) => e.type === 'final') as any
    expect(final).toBeDefined()
    expect(final.text).toBe('Hello world!')
    expect(deltas.map((d: any) => d.text).join('')).toBe('Hello world!')

    expect(fake.runSpy.mock.calls[0][2]).toMatchObject({ stream: true })
  })

  it('OnComplete: buffers all chunks, emits a single validated terminal text_delta', async () => {
    const yaml = COMMON_HEADER
    const shield = buildShieldFromYaml(yaml)

    const fake = makeFakeStreamingAgentsModule({
      deltas: ['Hello ', 'world', '!'],
    })

    const events = await collect(
      (shield as any).runOpenaiAgentStreamed({
        model: 'gpt-4o-mini',
        client: makeStubClient(),
        messages: [{ role: 'user', content: 'say hi' }],
        _agentsModule: fake.agentsMod,
        _agentsOpenaiModule: makeFakeAgentsOpenaiModule().agentsOpenaiMod,
      }),
    )

    const deltas = events.filter((e: any) => e.type === 'text_delta')
    expect(deltas).toHaveLength(1)
    expect(deltas[0]).toEqual({ type: 'text_delta', text: 'Hello world!' })
    const final = events.find((e: any) => e.type === 'final') as any
    expect(final.text).toBe('Hello world!')
  })

  it('Stage 1 block: caller never invoked; single `blocked` emission', async () => {
    const shield = buildShieldFromPath(INPUT_BLOCK)
    const fake = makeFakeStreamingAgentsModule({
      deltas: ['should', ' never', ' reach the consumer'],
    })

    const events = await collect(
      (shield as any).runOpenaiAgentStreamed({
        model: 'gpt-4o-mini',
        client: makeStubClient(),
        messages: [{ role: 'user', content: 'please DENY_ME now' }],
        _agentsModule: fake.agentsMod,
        _agentsOpenaiModule: makeFakeAgentsOpenaiModule().agentsOpenaiMod,
      }),
    )

    expect(events).toHaveLength(1)
    expect((events[0] as any).type).toBe('blocked')
    expect((events[0] as any).message).toContain('GUARDRAIL')
    expect(fake.runSpy).not.toHaveBeenCalled()
  })

  it('Stage 5 OnComplete redact: emits the redacted text once at the end', async () => {
    const yaml =
      COMMON_HEADER +
      `output_validation:
  guard_policies:
    - name: "ssn_redact"
      action: "redact"
      replacement: "[SSN]"
      evaluate_when:
        - patterns: ["\\\\b\\\\d{3}-\\\\d{2}-\\\\d{4}\\\\b"]
          reason: "SSN in output"
`
    const shield = buildShieldFromYaml(yaml)
    const fake = makeFakeStreamingAgentsModule({
      deltas: ['SSN is ', '123-45-6789', ' done.'],
    })

    const events = await collect(
      (shield as any).runOpenaiAgentStreamed({
        model: 'gpt-4o-mini',
        client: makeStubClient(),
        messages: [{ role: 'user', content: 'tell me' }],
        _agentsModule: fake.agentsMod,
        _agentsOpenaiModule: makeFakeAgentsOpenaiModule().agentsOpenaiMod,
      }),
    )

    const deltas = events.filter((e: any) => e.type === 'text_delta')
    expect(deltas).toHaveLength(1)
    expect((deltas[0] as any).text).toContain('[SSN]')
    expect((deltas[0] as any).text).not.toContain('123-45-6789')
  })

  it('PerChunk replace throws StreamingReplaceNotSupportedError (no SSN leak)', async () => {
    const { StreamingReplaceNotSupportedError } = await import('../../../../../index.js')
    const yaml =
      COMMON_HEADER +
      `output_validation:
  guard_policies:
    - name: "ssn_redact"
      action: "redact"
      replacement: "[SSN]"
      evaluate_when:
        - patterns: ["\\\\b\\\\d{3}-\\\\d{2}-\\\\d{4}\\\\b"]
          reason: "SSN in output"
`
    const rt = RuntimeBuilder.fromYamlStrings([yaml])
      .streamingWindow({ trigger: 'per_chunk', windowSize: 1, overlap: 0 })
      .build()
    const shield = new (Shield as any)(rt, { bundle: OPENAI_BUNDLE })

    const fake = makeFakeStreamingAgentsModule({
      deltas: Array.from('SSN is 123-45-6789 done.'),
    })

    const emissions: unknown[] = []
    let caught: unknown = null
    try {
      for await (const e of (shield as any).runOpenaiAgentStreamed({
        model: 'gpt-4o-mini',
        client: makeStubClient(),
        messages: [{ role: 'user', content: 'tell me' }],
        _agentsModule: fake.agentsMod,
        _agentsOpenaiModule: makeFakeAgentsOpenaiModule().agentsOpenaiMod,
      }) as AsyncIterable<unknown>) {
        emissions.push(e)
      }
    } catch (err) {
      caught = err
    }
    expect(caught).toBeInstanceOf(StreamingReplaceNotSupportedError)
    expect((caught as { adapter: string }).adapter).toBe('OpenAI Agents')
    for (const em of emissions) {
      const text = (em as { text?: unknown }).text
      const s = typeof text === 'string' ? text : ''
      expect(s.includes('[SSN]') && /\d{3}-\d{2}-\d{4}/.test(s)).toBe(false)
    }
  })

  it('tool calls inside the streamed loop fire Stage 2/3/4 (wrapped execute)', async () => {
    const yaml =
      COMMON_HEADER +
      `variables:
  - name: "authorized"
    type: "boolean"
    default: true
`
    const shield = buildShieldFromYaml(yaml)
    const dispatch = vi.fn(async (_name: string, args: any) => `pong:${args.msg}`)
    const fake = makeFakeStreamingAgentsModule({
      deltas: ['done'],
      toolCalls: [{ name: 'echo', args: { msg: 'hi' }, asString: true }],
    })

    const events = await collect(
      (shield as any).runOpenaiAgentStreamed({
        model: 'gpt-4o-mini',
        client: makeStubClient(),
        tools: [{ type: 'function', function: { name: 'echo' } }],
        messages: [{ role: 'user', content: 'go' }],
        dispatchToolCall: dispatch,
        _agentsModule: fake.agentsMod,
        _agentsOpenaiModule: makeFakeAgentsOpenaiModule().agentsOpenaiMod,
      }),
    )

    expect(dispatch).toHaveBeenCalledTimes(1)
    expect(dispatch).toHaveBeenCalledWith('echo', { msg: 'hi' })
    expect(fake.toolResults[0]).toBe('pong:hi')
    const final = events.find((e: any) => e.type === 'final') as any
    expect(final.text).toBe('done')
  })

  it('throws clear error when stream:true return is not async-iterable', async () => {
    const shield = buildShieldFromYaml(COMMON_HEADER)
    const brokenAgentsMod: AgentsLikeModule = {
      Agent: function (this: any, agentOpts: any) {
        Object.assign(this, agentOpts)
      } as any,
      tool: (o: any) => o,
      run: vi.fn(async () => ({ finalOutput: 'no stream' })) as any,
    }
    await expect(
      collect(
        (shield as any).runOpenaiAgentStreamed({
          model: 'gpt-4o-mini',
          client: makeStubClient(),
          messages: [{ role: 'user', content: 'hi' }],
          _agentsModule: brokenAgentsMod,
          _agentsOpenaiModule: makeFakeAgentsOpenaiModule().agentsOpenaiMod,
        }),
      ),
    ).rejects.toThrow(/async-iterable/)
  })
})
