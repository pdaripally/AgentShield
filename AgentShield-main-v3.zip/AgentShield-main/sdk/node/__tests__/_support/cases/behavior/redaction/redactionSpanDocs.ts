
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'

import { describe, expect, test } from 'vitest'

const INDEX_TS = resolve(__dirname, '..', '..', '..', '..', '..', 'index.ts')

function extractSection(source: string, anchor: string, lines: number): string {
  const idx = source.indexOf(anchor)
  expect(idx, `anchor "${anchor}" missing from index.ts`).toBeGreaterThan(-1)
  return source
    .slice(0, idx + anchor.length)
    .split('\n')
    .slice(-lines)
    .concat(source.slice(idx + anchor.length).split('\n').slice(0, lines))
    .join('\n')
}

describe('RedactionSpan JSDoc — codepoint-offset contract', () => {
  const source = readFileSync(INDEX_TS, 'utf8')

  test('RedactionSpanInit JSDoc specifies codepoint offsets', () => {
    const section = extractSection(source, 'export interface RedactionSpanInit', 40)
    expect(section.toLowerCase()).toContain('codepoint')
  })

  test('RedactionSpan class JSDoc references the codepoint contract', () => {
    const section = extractSection(source, 'export class RedactionSpan', 25)
    expect(section.toLowerCase()).toContain('codepoint')
  })

  test('RedactionSpan JSDoc opening positively asserts codepoint as the canonical contract', () => {
    const openingOf = (anchor: string) => {
      const block = extractSection(source, anchor, 40)
      const fence = block.indexOf('```')
      return (fence === -1 ? block : block.slice(0, fence)).toLowerCase()
    }
    const initOpening = openingOf('export interface RedactionSpanInit')
    const classOpening = openingOf('export class RedactionSpan')

    expect(initOpening).toContain('codepoint')
    expect(classOpening).toContain('codepoint')

    const forbidden = ['byte range', 'byte offset', 'byte-range', 'byte-offset']
    const check = (block: string, label: string) => {
      for (const phrase of forbidden) {
        let idx = block.indexOf(phrase)
        while (idx !== -1) {
          const preamble = block.slice(Math.max(0, idx - 8), idx)
          expect(
            preamble.includes('not '),
            `${label} opening uses "${phrase}" as canonical contract — must say codepoint instead`,
          ).toBe(true)
          idx = block.indexOf(phrase, idx + phrase.length)
        }
      }
    }
    check(initOpening, 'RedactionSpanInit JSDoc')
    check(classOpening, 'RedactionSpan class JSDoc')
  })

  test('JSDoc warns about JavaScript UTF-16 length pitfall', () => {
    const section = extractSection(source, 'export interface RedactionSpanInit', 60)
    expect(section.toLowerCase()).toContain('utf-16')
  })
})
