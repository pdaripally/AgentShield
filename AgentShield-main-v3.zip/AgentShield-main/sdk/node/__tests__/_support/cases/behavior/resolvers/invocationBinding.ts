import { describe, it, expect } from 'vitest'
import { RuntimeBuilder } from '../../../../../index.js'


const FIXTURE_YAML = `
metadata:
  name: "section-16-binding-parity"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test invocation binding"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "send_email"
      description: "Send an email."
      permission: "execute"
post_tool_validation:
  guard_policies:
    - name: "result_recipient_must_match_call_recipient"
      applies_to:
        tools: ["send_email"]
      evaluate_when:
        - expression: 'endswith(@tool.params.recipient, "@example.com")'
          reason: "Stage 4 bound to the wrong invocation."
`

async function newSession() {
  const rt = RuntimeBuilder.fromYamlStrings([FIXTURE_YAML]).build()
  const s = rt.newSession({
    sessionId: 'sess-section16',
    correlationId: 'corr-section16',
  })
  await s.beginTurn()
  return s
}

describe('the documented contract invocation-bound verdicts (Node parity)', () => {
  it('Scenario 1: Stage 3 + Stage 4 with matching id surfaces non-null hashes', async () => {
    const s = await newSession()
    const call = await s.validateToolCall(
      'send_email',
      { recipient: 'alice@example.com', body: 'hi' },
      'call_alice_1',
    )
    expect(call.verdict.allowed).toBe(true)
    const out = await s.validateToolOutput(
      'send_email',
      { matched_recipient: 'alice@example.com', sent: true },
      'never_validated_call_id',
    )
    expect(out.verdict.allowed).toBe(false)
    expect(out.verdict.policy).toBe('<binding>')
    expect(out.verdict.invocationHash).toBeNull()
  })

  it('Scenario 4: Stage 4 with mismatched explicit id fails closed with no hashes', async () => {
    const s = await newSession()
    await s.validateToolCall(
      'send_email',
      { recipient: 'alice@example.com', body: 'hi' },
      'call_alice_1',
    )
    const out = await s.validateToolOutput(
      'send_email',
      { matched_recipient: 'alice@example.com', sent: true },
      'call_alice_2',
    )
    expect(out.verdict.allowed).toBe(false)
    expect(out.verdict.policy).toBe('<binding>')
    expect(out.verdict.invocationHash).toBeNull()
  })
})
