
import { describe, it, expect, vi, beforeEach } from 'vitest'
import { z } from 'zod'
import { tool } from '@langchain/core/tools'
import { AIMessage, HumanMessage } from '@langchain/core/messages'

import { RuntimeBuilder, Shield, AgentShieldBlockedError } from '../../../../../index.js'
import * as langchainAdapter from '../../../../../adapters/langchain.js'

const HAS_LANGGRAPH = await (async () => {
  try {
    await import('@langchain/langgraph/prebuilt')
    return true
  } catch {
    return false
  }
})()
const describeIfLanggraph = HAS_LANGGRAPH ? describe : describe.skip

const LANGCHAIN_BUNDLE = (langchainAdapter as any).LANGCHAIN_BUNDLE
const _ensureToolNodeFailClosed = (langchainAdapter as any)
  ._ensureToolNodeFailClosed as (agent: unknown) => void
const _resetToolNodeFailClosedState = (langchainAdapter as any)
  ._resetToolNodeFailClosedState as () => void

const DENY_PII_YAML = `
metadata:
  name: "deny-pii"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["block PII submission"]
  forbidden: ["allow PII submission"]
resources:
  tools:
    - name: "submit_pii"
      description: "Submit a PII record."
      permission: "read_only"
state_validation:
  guard_policies:
    - name: "deny_submit_pii"
      applies_to:
        tools: ["submit_pii"]
      allowed_when: "false"
`

function makeShield(yaml = DENY_PII_YAML, opts: { onBlock?: any } = {}): Shield {
  const runtime = RuntimeBuilder.fromYamlStrings([yaml]).build()
  return new Shield(runtime as any, {
    bundle: LANGCHAIN_BUNDLE,
    ...opts,
  } as any)
}

beforeEach(() => {
  _resetToolNodeFailClosedState()
})


describeIfLanggraph('createReactAgent ToolNode rewiring', () => {
  it('flips handleToolErrors:false on a langgraph ToolNode reachable via the compiled graph', async () => {
    const { ToolNode } = await import('@langchain/langgraph/prebuilt')

    const t = tool(async () => 'ok', {
      name: 'echo',
      description: 'echo helper',
      schema: z.object({ msg: z.string() }),
    })

    const node = new ToolNode([t])
    expect(node.handleToolErrors).toBe(true)

    const fakeCompiledGraph = {
      nodes: { tools: { bound: node, triggers: [], channels: [] } },
      builder: { nodes: { tools: { runnable: node, metadata: undefined } } },
    }

    _ensureToolNodeFailClosed(fakeCompiledGraph)
    expect(node.handleToolErrors).toBe(false)
  })

  it('rewires a real createReactAgent compiled graph in place', async () => {
    const { createReactAgent, ToolNode } = await import(
      '@langchain/langgraph/prebuilt'
    )

    const t = tool(async () => 'ok', {
      name: 'echo',
      description: 'echo helper',
      schema: z.object({ msg: z.string() }),
    })

    const fakeLlm: any = {
      _modelType: () => 'fake',
      invoke: async () => new AIMessage({ content: 'noop' }),
      bindTools: () => fakeLlm,
      lc_namespace: ['fake'],
    }

    const agent = createReactAgent({ llm: fakeLlm, tools: [t] }) as any

    const builderNodes = agent?.builder?.nodes as Record<string, any>
    const toolsNode = builderNodes?.tools?.runnable as InstanceType<typeof ToolNode>
    expect(toolsNode).toBeInstanceOf(ToolNode)
    expect(toolsNode.handleToolErrors).toBe(true)

    _ensureToolNodeFailClosed(agent)
    expect(toolsNode.handleToolErrors).toBe(false)
  })
})


describeIfLanggraph('end-to-end propagation through shield.guard.invoke', () => {
  it('AgentShieldBlockedError thrown by a wrapped tool propagates out of guarded.invoke with onBlock=raise', async () => {
    const { ToolNode } = await import('@langchain/langgraph/prebuilt')

    let innerCalled = false
    const submitPii = tool(
      async () => {
        innerCalled = true
        return 'should-never-fire'
      },
      {
        name: 'submit_pii',
        description: 'submit PII',
        schema: z.object({ ssn: z.string() }),
      },
    )

    const shield = makeShield(DENY_PII_YAML, { onBlock: 'raise' })
    const wrapped = await shield.protectTools([submitPii])

    const toolNode = new ToolNode(wrapped as any[])
    expect(toolNode.handleToolErrors).toBe(true)

    const fakeAgent = {
      builder: { nodes: { tools: { runnable: toolNode } } },
      nodes: { tools: { bound: toolNode } },
      async invoke(input: any) {
        const aiMessageWithToolCall = new AIMessage({
          content: '',
          tool_calls: [
            {
              name: 'submit_pii',
              args: { ssn: '123-45-6789' },
              id: 'call_1',
              type: 'tool_call',
            },
          ],
        })
        const priorMessages = (input?.messages ?? []).map((m: any) => {
          if (m == null) return new HumanMessage({ content: '' })
          if (typeof m === 'string') return new HumanMessage({ content: m })
          if (typeof m.getType === 'function') return m
          return new HumanMessage({ content: String(m?.content ?? '') })
        })
        const messages = [...priorMessages, aiMessageWithToolCall]
        return await toolNode.invoke({ messages } as any)
      },
    }

    const guarded = shield.guard(fakeAgent as any)

    let caught: unknown = null
    try {
      await (guarded as any).invoke({
        messages: [{ role: 'user', content: 'use submit_pii' }],
      })
    } catch (e) {
      caught = e
    }
    expect(caught).not.toBeNull()
    const err = caught as Error
    const errInfo = `${err.name}: ${err.message}`
    const isShieldBlock =
      err instanceof AgentShieldBlockedError ||
      err.name === 'AgentShieldBlocked' ||
      err.name === 'AgentShieldBlockedError' ||
      /agent.?shield|guardrail|blocked|denies|deny|policy/i.test(errInfo)
    expect(isShieldBlock, errInfo).toBe(true)

    expect(toolNode.handleToolErrors).toBe(false)
    expect(innerCalled).toBe(false)
  })

  it('with default onBlock=returnBlocked, the buggy "fake tool answer" path is replaced by a guardrail block envelope', async () => {
    const { ToolNode } = await import('@langchain/langgraph/prebuilt')

    let innerCalled = false
    const submitPii = tool(
      async () => {
        innerCalled = true
        return 'should-never-fire'
      },
      {
        name: 'submit_pii',
        description: 'submit PII',
        schema: z.object({ ssn: z.string() }),
      },
    )
    const shield = makeShield()
    const wrapped = await shield.protectTools([submitPii])
    const toolNode = new ToolNode(wrapped as any[])

    const fakeAgent = {
      builder: { nodes: { tools: { runnable: toolNode } } },
      async invoke(_input: any) {
        const aiMessageWithToolCall = new AIMessage({
          content: '',
          tool_calls: [
            {
              name: 'submit_pii',
              args: { ssn: '123-45-6789' },
              id: 'call_2',
              type: 'tool_call',
            },
          ],
        })
        return await toolNode.invoke({
          messages: [aiMessageWithToolCall],
        } as any)
      },
    }

    const guarded = shield.guard(fakeAgent as any)
    const result: any = await (guarded as any).invoke({
      messages: [{ role: 'user', content: 'use submit_pii' }],
    })

    expect(innerCalled).toBe(false)
    expect(toolNode.handleToolErrors).toBe(false)
    expect(result).toBeDefined()
    const messages = result?.messages
    expect(Array.isArray(messages)).toBe(true)
    expect(messages.length).toBeGreaterThan(0)
    const last = messages[messages.length - 1]
    expect(typeof last?.getType === 'function' ? last.getType() : null).toBe('ai')
    const blob = JSON.stringify(result)
    expect(blob).toMatch(/GUARDRAIL|policy|deny|guard/i)
  })

  it('without the fix, a permissive ToolNode swallows the deny into a tool message (regression sentinel)', async () => {
    const { ToolNode } = await import('@langchain/langgraph/prebuilt')

    const submitPii = tool(async () => 'should-never-fire', {
      name: 'submit_pii',
      description: 'submit PII',
      schema: z.object({ ssn: z.string() }),
    })

    const shield = makeShield()
    const wrapped = await shield.protectTools([submitPii])
    const toolNode = new ToolNode(wrapped as any[])
    expect(toolNode.handleToolErrors).toBe(true) // still permissive

    const aiMessageWithToolCall = new AIMessage({
      content: '',
      tool_calls: [
        {
          name: 'submit_pii',
          args: { ssn: '123-45-6789' },
          id: 'call_1',
          type: 'tool_call',
        },
      ],
    })

    const result = (await toolNode.invoke({
      messages: [aiMessageWithToolCall],
    } as any)) as any
    const out = result?.messages?.[0]
    expect(out).toBeDefined()
    expect(out.status).toBe('error')
    expect(String(out.content)).toMatch(/Error/i)
  })
})


describeIfLanggraph('idempotent rewiring and one-time warning', () => {
  it('only flips the flag on the first call for a given agent', async () => {
    const { ToolNode } = await import('@langchain/langgraph/prebuilt')
    const t = tool(async () => 'ok', {
      name: 'echo',
      description: 'echo',
      schema: z.object({}),
    })
    const node = new ToolNode([t])
    const agent = { builder: { nodes: { tools: { runnable: node } } } }

    _ensureToolNodeFailClosed(agent)
    expect(node.handleToolErrors).toBe(false)

    node.handleToolErrors = true
    _ensureToolNodeFailClosed(agent)
    expect(node.handleToolErrors).toBe(true)
  })

  it('emits exactly one console.warn across many distinct rewires', async () => {
    const { ToolNode } = await import('@langchain/langgraph/prebuilt')
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {})
    try {
      _resetToolNodeFailClosedState()
      for (let i = 0; i < 3; i++) {
        const t = tool(async () => 'ok', {
          name: `echo${i}`,
          description: 'echo',
          schema: z.object({}),
        })
        const node = new ToolNode([t])
        _ensureToolNodeFailClosed({ builder: { nodes: { tools: { runnable: node } } } })
      }
      const adapterWarns = warn.mock.calls.filter((c) =>
        String(c[0] ?? '').includes('[agent-shield] LangGraph ToolNode'),
      )
      expect(adapterWarns.length).toBe(1)
    } finally {
      warn.mockRestore()
    }
  })
})


describe('non-langgraph agents are untouched', () => {
  it('a plain agent with no nodes is a no-op', () => {
    const agent = { invoke: async () => ({ output: 'ok' }) }
    expect(() => _ensureToolNodeFailClosed(agent)).not.toThrow()
  })

  it('a graph whose nodes hold non-ToolNode runnables is not mutated', () => {
    const decoyRunnable = { invoke: async () => 'ok' }
    const agent = { builder: { nodes: { tools: { runnable: decoyRunnable } } } }
    expect(() => _ensureToolNodeFailClosed(agent)).not.toThrow()
  })
})


describeIfLanggraph('frozen ToolNode raises a clear error rather than bypassing', () => {
  it('throws a fail-closed error when handleToolErrors cannot be flipped', async () => {
    const { ToolNode } = await import('@langchain/langgraph/prebuilt')
    const t = tool(async () => 'ok', {
      name: 'echo',
      description: 'echo',
      schema: z.object({}),
    })
    const node = new ToolNode([t])
    Object.defineProperty(node, 'handleToolErrors', {
      value: true,
      writable: false,
      configurable: false,
    })
    const agent = { builder: { nodes: { tools: { runnable: node } } } }

    let caught: unknown = null
    try {
      _ensureToolNodeFailClosed(agent)
    } catch (e) {
      caught = e
    }
    expect(caught).not.toBeNull()
    expect(String((caught as Error).message)).toMatch(/handleToolErrors/)
      })
})
