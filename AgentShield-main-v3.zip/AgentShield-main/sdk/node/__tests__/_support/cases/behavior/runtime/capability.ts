
import { describe, expect, it } from 'vitest'
import * as path from 'node:path'
import * as fs from 'node:fs'
import {
  AgentShieldBlocked,
  CapabilityReport,
  CompiledPolicy,
  CoverageLevel,
  GuardrailsConfig,
  MCPGuardrailBlocked,
  MCPShield,
  RuntimeBuilder,
  Shield,
  ShieldBuilder,
  ShieldMode,
  protectTool,
  protectToolOutput,
} from '../../../../../index.js'

const REPO_ROOT = path.resolve(__dirname, '..', '..', '..', '..', '..', '..', '..')
const MINIMAL = path.join(
  REPO_ROOT,
  'tests',
  'fixtures',
  'smoke',
  'minimal.guardrails.yaml',
)

describe('GuardrailsConfig', () => {
  it('constructs from a single path', () => {
    const cfg = GuardrailsConfig.load(MINIMAL)
    expect(cfg.length).toBe(1)
    expect(cfg.layers[0].kind).toBe('path')
  })

  it('constructs from a YAML string', () => {
    const text = fs.readFileSync(MINIMAL, 'utf8')
    const cfg = GuardrailsConfig.fromString(text)
    expect(cfg.length).toBe(1)
    expect(cfg.layers[0].kind).toBe('string')
  })

  it('constructs from a JS object', () => {
    const cfg = GuardrailsConfig.fromObject({
      metadata: { name: 'x', version: '0.1.0' },
    })
    expect(cfg.length).toBe(1)
    expect(cfg.layers[0].kind).toBe('object')
  })

  it('extend returns a new instance and grows the chain', () => {
    const cfg1 = GuardrailsConfig.load(MINIMAL)
    const cfg2 = cfg1.extend({ metadata: { description: 'overlay' } })
    expect(cfg1.length).toBe(1)
    expect(cfg2.length).toBe(2)
    expect(cfg2.layers[1].kind).toBe('object')
  })

  it('compose chains multiple sources in one call', () => {
    const cfg = GuardrailsConfig.compose(MINIMAL, {
      metadata: { description: 'overlay' },
    })
    expect(cfg.length).toBe(2)
  })

  it('compile yields YAML strings + sha256 digest', () => {
    const compiled = GuardrailsConfig.load(MINIMAL).compile()
    expect(compiled).toBeInstanceOf(CompiledPolicy)
    expect(compiled.yamlStrings.length).toBe(1)
    expect(compiled.digest).toMatch(/^[0-9a-f]{64}$/)
    expect(compiled.hash).toBe(compiled.digest)
  })

  it('compile is deterministic for identical content', () => {
    const a = GuardrailsConfig.load(MINIMAL).compile()
    const b = GuardrailsConfig.load(MINIMAL).compile()
    expect(a.digest).toBe(b.digest)
    expect(a.equals(b)).toBe(true)
  })

  it('compile changes when an overlay differs', () => {
    const a = GuardrailsConfig.load(MINIMAL).compile()
    const b = GuardrailsConfig.load(MINIMAL)
      .withOverrides({ metadata: { description: 'different' } })
      .compile()
    expect(a.equals(b)).toBe(false)
    expect(a.digest).not.toBe(b.digest)
  })

  it('empty chain compile throws', () => {
    expect(() => new GuardrailsConfig([]).compile()).toThrow(/no layers/)
  })
})

describe('RuntimeBuilder.fromConfig', () => {
  it('accepts a path', () => {
    const rt = RuntimeBuilder.fromConfig(MINIMAL).build()
    expect(rt.metadataName).toBe('smoke-minimal')
  })

  it('accepts a list of paths', () => {
    const rt = RuntimeBuilder.fromConfig([MINIMAL]).build()
    expect(rt.metadataName).toBe('smoke-minimal')
  })

  it('accepts a GuardrailsConfig', () => {
    const cfg = GuardrailsConfig.load(MINIMAL)
    const rt = RuntimeBuilder.fromConfig(cfg).build()
    expect(rt.metadataName).toBe('smoke-minimal')
  })

  it('accepts a CompiledPolicy', () => {
    const compiled = GuardrailsConfig.load(MINIMAL).compile()
    const rt = RuntimeBuilder.fromConfig(compiled).build()
    expect(rt.metadataName).toBe('smoke-minimal')
  })

  it('fromYamlStrings accepts in-memory chains', () => {
    const text = fs.readFileSync(MINIMAL, 'utf8')
    const rt = RuntimeBuilder.fromYamlStrings([text]).build()
    expect(rt.metadataName).toBe('smoke-minimal')
  })
})

describe('CapabilityReport', () => {
  it('defaults every stage to FULL', () => {
    const rep = new CapabilityReport({ framework: 'test' })
    expect(rep.isFullCoverage()).toBe(true)
  })

  it('honours per-stage overrides', () => {
    const rep = new CapabilityReport({
      framework: 'test',
      streamingOutput: CoverageLevel.UNSUPPORTED,
    })
    expect(rep.isFullCoverage()).toBe(false)
    expect(rep.streamingOutput).toBe(CoverageLevel.UNSUPPORTED)
  })

  it('CoverageLevel enum has the three documented values', () => {
    expect(CoverageLevel.FULL).toBe('full')
    expect(CoverageLevel.PARTIAL).toBe('partial')
    expect(CoverageLevel.UNSUPPORTED).toBe('unsupported')
  })
})

describe('Shield orchestrator', () => {
  const _fakeBundle = {
    name: '_fake',
    llmCallerFactory: { makeCaller: () => () => '' },
    toolWrapper: {
      extract: (tool) => ({
        name: tool.name,
        description: tool.description ?? tool.name,
      }),
      invoke: async (tool, params) => tool(...Object.values(params)),
      wrap: (tool, meta, guardedInvoke) => async (params) =>
        guardedInvoke(params, ''),
    },
    agentBoundary: {
      run: async (agent, input) => ({ text: await agent(input) }),
      extractOutput: (r) => r?.text ?? null,
      applyRedaction: (r, t) => ({ ...r, text: t }),
      makeBlocked: (msg) => ({ text: msg, blocked: true }),
    },
    streamingAdapter: null,
    capabilities: new CapabilityReport({ framework: '_fake' }),
  }

  class _LocalShield extends Shield {
    static get BUNDLE() {
      return _fakeBundle
    }
    static get BUILDER_CLASS() {
      return ShieldBuilder
    }
  }

  it('exposes capability report', () => {
    const shield = _LocalShield.fromYaml(MINIMAL).build()
    expect(shield.capabilities).toBe(_fakeBundle.capabilities)
  })

  it('runs an agent with stage 1 + stage 5 enforcement', async () => {
    const shield = _LocalShield.fromYaml(MINIMAL).build()
    const fakeAgent = async (input) => `processed: ${input}`
    const guarded = shield.guard(fakeAgent)
    const result = await guarded.run('hello')
    expect(result.text).toBe('processed: hello')
  })

  it('honours monitor mode (never blocks)', async () => {
    const shield = _LocalShield.fromYaml(MINIMAL)
      .withMode(ShieldMode.MONITOR)
      .build()
    expect(shield.mode).toBe(ShieldMode.MONITOR)
    const fakeAgent = async (input) => `processed: ${input}`
    const guarded = shield.guard(fakeAgent)
    const result = await guarded.run('hello')
    expect(result.text).toBe('processed: hello')
  })

  it('on_block="raise" wires AgentShieldBlocked', async () => {
    const shield = _LocalShield.fromYaml(MINIMAL).withOnBlock('raise').build()
    expect(shield._onBlock).toBe('raise')
    expect(AgentShieldBlocked).toBeDefined()
  })
})

describe('MCPShield', () => {
  it('exposes the MCP capability profile', () => {
    const shield = MCPShield.fromYaml(MINIMAL).build()
    const rep = shield.capabilities
    expect(rep.framework).toBe('mcp')
    expect(rep.inputValidation).toBe(CoverageLevel.UNSUPPORTED)
    expect(rep.outputValidation).toBe(CoverageLevel.UNSUPPORTED)
    expect(rep.streamingOutput).toBe(CoverageLevel.UNSUPPORTED)
    expect(rep.toolAuthorization).toBe(CoverageLevel.FULL)
  })

  it('protectTool blocks unauthorized tool', async () => {
    const shield = MCPShield.fromYaml(MINIMAL).build()
    const session = shield.runtime.newSession()
    session.beginTurn()
    const r = await protectTool(shield.runtime, 'echo', { msg: 'hi' }, 'tc_block', {
      session,
    })
    expect(r.allowed).toBe(false)
    expect(r.blockMessage).toContain('GUARDRAIL')
  })

  it('protectTool allows authorized tool', async () => {
    const shield = MCPShield.fromYaml(MINIMAL).build()
    const session = shield.runtime.newSession()
    session.beginTurn()
    session.setVariable('authorized', true)
    const r = await protectTool(shield.runtime, 'echo', { msg: 'hi' }, 'tc_allow', {
      session,
    })
    expect(r.allowed).toBe(true)
    expect(r.effectiveArgs).toEqual({ msg: 'hi' })
  })

  it('protectToolOutput allows + records on success', async () => {
    const shield = MCPShield.fromYaml(MINIMAL).build()
    const session = shield.runtime.newSession()
    session.beginTurn()
    session.setVariable('authorized', true)
    const toolCallId = 'tc_minimal'
    await protectTool(shield.runtime, 'echo', { msg: 'hi' }, toolCallId, {
      session,
    })
    const r = await protectToolOutput(
      shield.runtime,
      'echo',
      'result',
      toolCallId,
      { session },
    )
    expect(r.allowed).toBe(true)
    expect(r.effectiveOutput).toBe('result')
  })

  it('protectTool requires non-empty toolCallId (the documented contract)', async () => {
    const shield = MCPShield.fromYaml(MINIMAL).build()
    await expect(
      protectTool(shield.runtime, 'echo', { msg: 'hi' }, ''),
    ).rejects.toThrow(/toolCallId/)
    await expect(
      protectToolOutput(shield.runtime, 'echo', 'result', ''),
    ).rejects.toThrow(/toolCallId/)
  })

  it('protectTools wraps a list of (name, fn) pairs', async () => {
    const shield = MCPShield.fromYaml(MINIMAL).build()
    const wrapped = shield.protectTools(
      [['echo', async (params) => `echo: ${params.msg}`]],
      { onBlock: 'returnMessage' },
    )
    expect(wrapped.length).toBe(1)
    const [name, fn] = wrapped[0]
    expect(name).toBe('echo')
    expect(typeof fn).toBe('function')
  })

  it('MCPGuardrailBlocked is exposed', () => {
    const exc = new MCPGuardrailBlocked('echo', 'msg')
    expect(exc).toBeInstanceOf(Error)
    expect(exc.toolName).toBe('echo')
    expect(exc.message).toBe('msg')
  })

  it('defaults to per-connection session; state spans tool calls', async () => {
    const shield = MCPShield.fromYaml(MINIMAL).build()
    expect(shield.sessionScope).toBe('connection')

    const sess = shield.session
    expect(sess).not.toBeNull()
    sess.beginTurn()
    sess.setVariable('authorized', true)

    const r1 = await shield.protectTool('echo', { msg: 'first' }, 'tc_first')
    const r2 = await shield.protectTool('echo', { msg: 'second' }, 'tc_second')
    expect(r1.allowed).toBe(true)
    expect(r2.allowed).toBe(true)
  })

  it('per-call scope does not share state across calls', async () => {
    const shield = MCPShield.fromYaml(MINIMAL)
      .withSessionScope('call')
      .build()
    expect(shield.sessionScope).toBe('call')
    expect(shield.session).toBeNull()
    const r = await shield.protectTool('echo', { msg: 'hi' }, 'tc_per_call')
    expect(r.allowed).toBe(false)
    expect(r.blockMessage).toContain('GUARDRAIL')
  })

  it('resetSession drops the held session', () => {
    const shield = MCPShield.fromYaml(MINIMAL).build()
    const s1 = shield.session
    expect(s1).not.toBeNull()
    shield.resetSession()
    const s2 = shield.session
    expect(s2).not.toBe(s1)
  })
})

describe('Wire-shape JSON Schema conformance', () => {

  const SCHEMA_DIR = path.join(REPO_ROOT, 'spec', 'schemas', 'wire')

  function loadSchema(name) {
    return JSON.parse(
      fs.readFileSync(path.join(SCHEMA_DIR, `${name}.schema.json`), 'utf8'),
    )
  }

  it('every wire schema is loadable + names a v2.0.0-prototype $id', () => {
    for (const name of [
      'stage_verdict',
      'variable_state',
      'resolver_request',
      'resolver_response',
      'delegate_request',
      'llm_response',
      'classifier_verdict',
      'shield_log_event',
      'capability_report',
    ]) {
      const schema = loadSchema(name)
      expect(schema.$id).toMatch(/v2\.0\.0-prototype$/)
      expect(schema.$schema).toBe(
        'http://json-schema.org/draft-07/schema#',
      )
    }
  })

  it('real validateInput output has the expected wire shape', async () => {
    const rt = RuntimeBuilder.fromYaml(MINIMAL).build()
    const session = rt.newSession()
    session.beginTurn()
    const verdict = await session.validateInput('hello')

    expect(typeof verdict.allowed).toBe('boolean')
    for (const key of [
      'action',
      'reason',
      'policy',
      'evaluateWhenIndex',
      'bypassedByAllowedWhen',
      'redaction',
      'appended',
      'prepended',
    ]) {
      expect(key in verdict).toBe(true)
    }
  })

  it('real capability report serialises to the wire schema shape', () => {
    const shield = MCPShield.fromYaml(MINIMAL).build()
    const rep = shield.capabilities
    const wire = {
      framework: rep.framework,
      input_validation: rep.inputValidation,
      state_validation: rep.stateValidation,
      tool_authorization: rep.toolAuthorization,
      tool_execution_validation: rep.toolExecutionValidation,
      tool_output_validation: rep.toolOutputValidation,
      output_validation: rep.outputValidation,
      streaming_output: rep.streamingOutput,
      notes: [...rep.notes],
    }
    expect(['full', 'partial', 'unsupported']).toContain(
      wire.streaming_output,
    )
    expect(wire.framework).toBe('mcp')
  })
})
