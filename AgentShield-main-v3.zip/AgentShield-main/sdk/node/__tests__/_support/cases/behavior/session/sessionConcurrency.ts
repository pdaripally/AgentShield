
import { describe, it, expect } from 'vitest'
import * as path from 'path'

import { Shield, SessionBusyError } from '../../../../../index.js'

const FIXTURE = path.resolve(
  __dirname,
  '../../../fixtures/concurrentSession.guardrails.yaml',
)

function readVar(session: { readVariable(n: string): unknown }, name: string) {
  const v = session.readVariable(name) as { value?: unknown } | null
  return v?.value ?? null
}

describe('shield.run — per-session serialization ', () => {
  it('serializes overlapping turns on the same Session by default', async () => {
    const shield = Shield.fromYaml(FIXTURE).build()
    const session = shield.runtime.newSession({ sessionId: 'session-serialization-serial' })

    const observed: Array<string | null> = []
    const p1 = shield.run(
      async () => {
        ;(session as unknown as { setVariable(n: string, v: unknown): void }).setVariable(
          'turn_token',
          'p1-secret',
        )
        await new Promise((r) => setTimeout(r, 40))
        observed.push(readVar(session, 'turn_token') as string | null) // 'p1-secret'
        return 'p1'
      },
      { userInput: '', session },
    )
    const p2 = shield.run(
      async () => {
        observed.push(readVar(session, 'turn_token') as string | null) // null
        return 'p2'
      },
      { userInput: '', session },
    )

    const [r1, r2] = await Promise.all([p1, p2])
    expect(r1).toBe('p1')
    expect(r2).toBe('p2')
    expect(observed).toEqual(['p1-secret', null])
  })

  it('reproduces the audit round-10 D.1 case and produces correct ordering', async () => {
    const shield = Shield.fromYaml(FIXTURE).build()
    const shared = shield.runtime.newSession({ sessionId: 'session-serialization-overlap' })

    let p2Read: unknown = 'NOT_READ'
    const p1 = shield.run(
      async () => {
        ;(shared as unknown as { setVariable(n: string, v: unknown): void }).setVariable(
          'turn_token',
          'p1-secret',
        )
        await new Promise((r) => setTimeout(r, 80))
        return 'p1'
      },
      { userInput: 'p1', session: shared },
    )
    const p2 = shield.run(
      async () => {
        p2Read = readVar(shared, 'turn_token')
        return 'p2'
      },
      { userInput: 'p2', session: shared },
    )

    const settled = await Promise.allSettled([p1, p2])
    expect(settled[0].status).toBe('fulfilled')
    expect(settled[1].status).toBe('fulfilled')
    expect(p2Read).toBeNull()
  })

  it('allows reentrant shield.run on the same ambient session without deadlock', async () => {
    const shield = Shield.fromYaml(FIXTURE).build()
    const session = shield.runtime.newSession({ sessionId: 'session-serialization-reentrant' })

    const reads: Array<string | null> = []
    const result = await shield.run(
      async () => {
        ;(session as unknown as { setVariable(n: string, v: unknown): void }).setVariable(
          'turn_token',
          'outer-token',
        )
        const inner = await shield.run(
          async () => {
            reads.push(readVar(session, 'turn_token') as string | null)
            return 'inner'
          },
          { userInput: '', session },
        )
        return `outer:${inner as string}`
      },
      { userInput: '', session },
    )

    expect(result).toBe('outer:inner')
    expect(reads).toEqual(['outer-token'])
  })

  it('does not poison the queue when an earlier turn throws', async () => {
    const shield = Shield.fromYaml(FIXTURE).build()
    const session = shield.runtime.newSession({ sessionId: 'session-serialization-throws' })

    const p1 = shield.run(
      async () => {
        await new Promise((r) => setTimeout(r, 20))
        throw new Error('turn 1 blew up')
      },
      { userInput: '', session },
    )
    const p2 = shield.run(
      async () => {
        return 'p2-ok'
      },
      { userInput: '', session },
    )

    await expect(p1).rejects.toThrow('turn 1 blew up')
    await expect(p2).resolves.toBe('p2-ok')
  })

  it('throws SessionBusyError when configured with onConcurrent: "reject"', async () => {
    const shield = Shield.fromYaml(FIXTURE)
      .withOnConcurrent('reject')
      .build()
    const session = shield.runtime.newSession({ sessionId: 'session-serialization-reject' })

    const slowGate = new Promise<void>((resolve) => {
      setTimeout(resolve, 30)
    })
    const p1 = shield.run(
      async () => {
        await slowGate
        return 'p1'
      },
      { userInput: '', session },
    )

    await expect(
      shield.run(async () => 'p2', { userInput: '', session }),
    ).rejects.toBeInstanceOf(SessionBusyError)

    await expect(p1).resolves.toBe('p1')
  })
})
