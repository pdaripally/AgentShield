import { describe, it, expectTypeOf } from 'vitest'
import type { ShieldLogEvent } from '../../../../../index'


describe('ShieldLogEvent interface covers all Rust-core fields', () => {
  it('typed providers can read agentId, mode, enforced, tool, messageContainsRawContent', () => {
    const ev: ShieldLogEvent = {
      timestamp: '2025-01-01T00:00:00Z',
      severity: 'info',
      eventType: 'tool.invoked',
      category: 'tool',
      stage: 'tool_call',
      action: null,
      guardPolicy: null,
      evaluateWhenIndex: null,
      resource: { kind: 'tool', name: 'echo' },
      tool: 'echo',
      variable: null,
      eventId: null,
      correlationId: 'corr-1',
      sessionId: 'sess-1',
      agentId: 'agent-x',
      userId: null,
      tenantId: null,
      mode: 'active',
      enforced: true,
      message: 'tool invoked',
      messageContainsRawContent: false,
      attributes: {},
    }
    const _agentId: string | null | undefined = ev.agentId
    const _mode: string | null | undefined = ev.mode
    const _enforced: boolean | null | undefined = ev.enforced
    const _tool: string | null | undefined = ev.tool
    const _raw: boolean | undefined = ev.messageContainsRawContent
    void _agentId
    void _mode
    void _enforced
    void _tool
    void _raw
    expectTypeOf(ev).toMatchObjectType<{
      agentId?: string | null
      mode?: string | null
      enforced?: boolean | null
      tool?: string | null
      messageContainsRawContent?: boolean
    }>()
  })

  it('all newly-added fields are optional (omitting them is valid)', () => {
    const ev: ShieldLogEvent = {
      timestamp: '2025-01-01T00:00:00Z',
      severity: 'info',
      eventType: 'session.begin',
      category: 'session',
      correlationId: '',
      sessionId: '',
      message: '',
      attributes: {},
    }
    void ev
  })
})
