
import { describe, expect, it } from 'vitest'
import * as path from 'node:path'
import {
  CapabilityReport,
  Shield,
  ShieldBuilder,
  UnguardedToolInvocationError,
} from '../../../../../index.js'
import { UnguardedToolInvocationError as UTI_FromErrors } from '../../../../../errors.js'

const REPO_ROOT = path.resolve(__dirname, '..', '..', '..', '..', '..', '..', '..')
const MINIMAL = path.join(
  REPO_ROOT,
  'tests',
  'fixtures',
  'smoke',
  'minimal.guardrails.yaml',
)


interface FakeTool {
  (params: Record<string, unknown>): Promise<string>
  name: string
  description: string
}

function _makeTool(name: string, returnValue = 'ok'): {
  tool: FakeTool
  calls: Record<string, unknown>[]
} {
  const calls: Record<string, unknown>[] = []
  const callable = async (params: Record<string, unknown>) => {
    calls.push({ ...params })
    return returnValue
  }
  Object.defineProperty(callable, 'name', {
    value: name,
    writable: false,
    configurable: true,
  })
  Object.defineProperty(callable, 'description', {
    value: `fake tool ${name}`,
    writable: false,
    configurable: true,
    enumerable: true,
  })
  return { tool: callable as unknown as FakeTool, calls }
}

const _fakeBundle = {
  name: '_fake',
  llmCallerFactory: { makeCaller: () => () => '' },
  toolWrapper: {
    extract: (tool: FakeTool) => ({
      name: tool.name,
      description: tool.description,
    }),
    invoke: async (tool: FakeTool, params: Record<string, unknown>) =>
      tool(params),
    wrap:
      (tool: FakeTool, meta: { name: string }, guardedInvoke: any) =>
      async (params: Record<string, unknown>) =>
        guardedInvoke(params, ''),
  },
  agentBoundary: {
    run: async (agent: any, input: string) => ({ text: await agent(input) }),
    extractOutput: (r: any) => r?.text ?? null,
    applyRedaction: (r: any, t: string) => ({ ...r, text: t }),
    makeBlocked: (msg: string) => ({ text: msg, blocked: true }),
  },
  streamingAdapter: null,
  capabilities: new CapabilityReport({ framework: '_fake' }),
}

class _LocalShield extends Shield {
  static get BUNDLE() {
    return _fakeBundle as any
  }
  static get BUILDER_CLASS() {
    return ShieldBuilder
  }
}

function _buildShield(): Shield {
  return (_LocalShield as any).fromYaml(MINIMAL).build()
}


describe('protectTools default — fail-closed ', () => {
  it('throws UnguardedToolInvocationError with an actionable message', async () => {
    const shield = _buildShield()
    const { tool, calls } = _makeTool('issue_refund', 'refunded')
    const [wrapped] = await shield.protectTools<FakeTool, any>([tool])

    let caught: unknown = null
    try {
      await wrapped({ order_id: '1234', amount: 50.0 })
    } catch (err) {
      caught = err
    }

    expect(caught).toBeInstanceOf(UnguardedToolInvocationError)
    const e = caught as UnguardedToolInvocationError
    expect(e.message).toContain('issue_refund')
    expect(e.message).toContain('shield.guard(agent)')
    expect(e.message).toContain('allowUnguarded: true')
    expect(e.toolName).toBe('issue_refund')
    expect(calls).toEqual([])
  })
})


describe('UnguardedToolInvocationError surface', () => {
  it('is exported from the main package and the errors module (same class)', () => {
    expect(UnguardedToolInvocationError).toBe(UTI_FromErrors)
  })

  it('is a subclass of Error with the expected name', () => {
    const err = new UnguardedToolInvocationError('my_tool')
    expect(err).toBeInstanceOf(Error)
    expect(err).toBeInstanceOf(UnguardedToolInvocationError)
    expect(err.name).toBe('UnguardedToolInvocationError')
    expect(err.toolName).toBe('my_tool')
  })

  it('is exported from per-adapter entry points', async () => {
    const openai = await import('../../../../../adapters/openai_agents.js')
    const anthropic = await import('../../../../../adapters/anthropic_agents.js')
    const langchain = await import('../../../../../adapters/langchain.js')
    expect((openai as any).UnguardedToolInvocationError).toBe(
      UnguardedToolInvocationError,
    )
    expect((anthropic as any).UnguardedToolInvocationError).toBe(
      UnguardedToolInvocationError,
    )
    expect((langchain as any).UnguardedToolInvocationError).toBe(
      UnguardedToolInvocationError,
    )
  })
})


describe('protectTools allowUnguarded:true opt-in', () => {
  it('mints a fresh session per call and runs the tool', async () => {
    const shield = _buildShield()
    const { tool, calls } = _makeTool('lookup_order', 'order#1234')
    const [wrapped] = await shield.protectTools<FakeTool, any>([tool], {
      allowUnguarded: true,
    })

    const out = await wrapped({ order_id: '1234' })

    expect(calls).toEqual([{ order_id: '1234' }])
    expect(String(out)).toContain('order#1234')
  })
})


describe('protectTools inside shield.run — succeeds via ambient session', () => {
  it('uses the ambient session set by shield.run with no opt-in needed', async () => {
    const shield = _buildShield()
    const { tool, calls } = _makeTool('lookup_order', 'order#1234')
    const [wrapped] = await shield.protectTools<FakeTool, any>([tool])

    const out = await (shield as any).run(
      async () => {
        return String(await wrapped({ order_id: '1234' }))
      },
      { userInput: 'hello' },
    )

    expect(calls).toEqual([{ order_id: '1234' }])
    expect(String(out)).toContain('order#1234')
  })
})


describe('protectOpenaiTools — fail-closed ', () => {
  it('throws UnguardedToolInvocationError when invoked outside runOpenaiAgent', async () => {
    await import('../../../../../adapters/openai_agents.js')

    const shield = _buildShield()
    const dispatch = async (_name: string, _args: Record<string, unknown>) =>
      'should-never-run'
    const guarded = (shield as any).protectOpenaiTools({
      dispatchToolCall: dispatch,
    })

    let caught: unknown = null
    try {
      await guarded('searchKnowledgeBase', {
        query: 'direct call outside guard(agent)',
      })
    } catch (err) {
      caught = err
    }

    expect(caught).toBeInstanceOf(UnguardedToolInvocationError)
    const e = caught as UnguardedToolInvocationError
    expect(e.toolName).toBe('searchKnowledgeBase')
    expect(e.message).toContain('searchKnowledgeBase')
    expect(e.message).toContain('shield.guard(agent)')
    expect(e.message).toContain('allowUnguarded: true')
  })

  it('runs when allowUnguarded:true is passed (opt-in legacy path)', async () => {
    await import('../../../../../adapters/openai_agents.js')

    const shield = _buildShield()
    const calls: Array<{ name: string; args: Record<string, unknown> }> = []
    const dispatch = async (name: string, args: Record<string, unknown>) => {
      calls.push({ name, args })
      return `ok:${args.msg}`
    }
    const guarded = (shield as any).protectOpenaiTools({
      dispatchToolCall: dispatch,
      allowUnguarded: true,
    })

    const out = await guarded('lookup_order', { msg: 'hi' })

    expect(out).toBe('ok:hi')
    expect(calls).toEqual([{ name: 'lookup_order', args: { msg: 'hi' } }])
  })
})


describe('protectAnthropicTools — fail-closed (cross-SDK parity)', () => {
  it('throws UnguardedToolInvocationError when invoked outside ambient session', async () => {
    await import('../../../../../adapters/anthropic_agents.js')

    const shield = _buildShield()
    const dispatch = async (_n: string, _a: Record<string, unknown>) =>
      'should-never-run'
    const wrapped = (shield as any).protectAnthropicTools({
      tools: [],
      dispatchTool: dispatch,
    })

    let caught: unknown = null
    try {
      await wrapped.dispatchTool('weather', { city: 'Seattle' })
    } catch (err) {
      caught = err
    }

    expect(caught).toBeInstanceOf(UnguardedToolInvocationError)
    const e = caught as UnguardedToolInvocationError
    expect(e.toolName).toBe('weather')
    expect(e.message).toContain('weather')
  })

  it('accepts an explicit session: opt — that is itself an opt-out from fail-closed', async () => {
    await import('../../../../../adapters/anthropic_agents.js')

    const shield = _buildShield()
    const sess = shield.runtime.newSession()
    sess.beginTurn()
    try {
      const calls: Array<{ name: string; args: Record<string, unknown> }> = []
      const dispatch = async (name: string, args: Record<string, unknown>) => {
        calls.push({ name, args })
        return 'sunny'
      }
      const wrapped = (shield as any).protectAnthropicTools({
        tools: [],
        dispatchTool: dispatch,
        session: sess,
      })
      const out = await wrapped.dispatchTool('weather', { city: 'Seattle' })
      expect(typeof out).toBe('string')
      expect(calls.length).toBe(1)
    } finally {
      try {
        sess.endTurn()
      } catch {
      }
    }
  })
})
