import { describe, expect, it } from 'vitest'
import * as path from 'node:path'
import { RuntimeBuilder, Shield } from '../../../../../index.js'
import { OPENAI_BUNDLE } from '../../../../../adapters/openai_agents.js'

const FIXTURE = path.resolve(
  __dirname,
  '..',
  '..',
  '..',
  '..',
  '..',
  '..',
  '..',
  'tests',
  'fixtures',
  'contract',
  'pending_resolution.guardrails.yaml',
)

function _newShield(): Shield {
  const rt = RuntimeBuilder.fromYaml(FIXTURE).build()
  return new Shield(rt, { bundle: OPENAI_BUNDLE })
}

async function _triggerHumanBlock(shield: Shield): Promise<void> {
  let dispatched = false
  const result = await shield.protectTool(
    'send_email',
    { to: 'alice@example.com', subject: 'Hi' },
    async () => {
      dispatched = true
      return 'should-not-run'
    },
  )
  expect(result.blocked).toBe(true)
  expect(result.pendingResolution).toBeNull()
  expect(dispatched).toBe(false)
}

describe('Shield.lastPendingResolution — runtime-bound human resolver', () => {
  it('remains null for a fail-closed kind: human block without handler', async () => {
    const shield = _newShield()
    await _triggerHumanBlock(shield)
    expect(shield.lastPendingResolution()).toBeNull()
    expect(shield.lastPendingResolution()).toBeNull()
  })

  it('explicit setVariables still lets resolvePending unblock the next call', async () => {
    const shield = _newShield()
    const session = shield.runtime.newSession()
    await shield.run(
      async () => {
        await _triggerHumanBlock(shield)
        await shield.resolvePending('allow', {
          setVariables: { send_email_approved: true },
        })
        const ok = await shield.protectTool(
          'send_email',
          { to: 'alice@example.com', subject: 'Hi' },
          async () => 'sent',
        )
        expect(ok.blocked).toBe(false)
      },
      { session, userInput: 'send the email' },
    )
    expect(shield.lastPendingResolution()).toBeNull()
  })
})
