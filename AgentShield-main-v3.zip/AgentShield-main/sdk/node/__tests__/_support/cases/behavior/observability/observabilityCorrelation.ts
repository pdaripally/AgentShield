import { describe, it, expect } from 'vitest'
import * as path from 'path'
import { Shield } from '../../../../../shield'


const MINIMAL = path.resolve(
  __dirname,
  '../../../../../../../tests/fixtures/smoke/minimal.guardrails.yaml',
)

const KNOWN = 'corr-audit'

describe('Node correlation_id round-trip', () => {
  it('camelCase schema: captured event preserves correlationId verbatim', async () => {
    const captured: any[] = []
    const shield = Shield.fromYaml(MINIMAL)
      .withObservability((ev: any) => captured.push(ev))
      .withObservabilityProviderSchema('camelCase')
      .build()
    const session = shield.runtime.newSession({
      sessionId: 'sess-observability-correlation',
      correlationId: KNOWN,
    })
    session.beginTurn()
    await session.validateInput('hi')
    session.endTurn()
    await new Promise((r) => setTimeout(r, 80))
    expect(captured.length).toBeGreaterThan(0)
    const tagged = captured.filter((e) => e.correlationId === KNOWN)
    expect(tagged.length).toBe(captured.length)
    for (const ev of captured) {
      expect(ev.correlationId).toBe(KNOWN)
      expect(ev.correlationId).not.toBe('')
    }
  })

  it('snakeCase schema: captured event preserves correlation_id verbatim', async () => {
    const captured: any[] = []
    const shield = Shield.fromYaml(MINIMAL)
      .withObservability((ev: any) => captured.push(ev))
      .withObservabilityProviderSchema('snakeCase')
      .build()
    const session = shield.runtime.newSession({
      sessionId: 'sess-observability-correlation-snake',
      correlationId: KNOWN,
    })
    session.beginTurn()
    await session.validateInput('hi')
    session.endTurn()
    await new Promise((r) => setTimeout(r, 80))
    expect(captured.length).toBeGreaterThan(0)
    for (const ev of captured) {
      expect(ev.correlation_id).toBe(KNOWN)
      expect(ev.correlation_id).not.toBe('')
      expect(ev.correlationId).toBeUndefined()
    }
  })
})
