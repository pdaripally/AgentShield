import { describe, expect, it } from 'vitest'
import { RuntimeBuilder, Shield } from '../../../../../index.js'

const YAML = `
metadata:
  name: turn-lease-stress
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["stress per-turn lease isolation"]
variables:
  - name: turn_token
    type: string
    lifetime: per_turn
`

function readVar(session: { readVariable(n: string): unknown }, name: string) {
  const v = session.readVariable(name) as { value?: unknown } | null
  return v?.value ?? null
}

describe('turn lease stress (Node structurally safe via queue)', () => {
  it('20 concurrent shield.run calls on one Session isolate per_turn state', async () => {
    const shield = new Shield(RuntimeBuilder.fromYamlStrings([YAML]).build())
    const session = shield.runtime.newSession({ sessionId: 'node-turn-lease-stress' })
    const results = await Promise.all(
      Array.from({ length: 20 }, (_, i) => {
        const token = `token-${i}`
        return shield.run(
          async () => {
            ;(session as unknown as { setVariable(n: string, v: unknown): void }).setVariable(
              'turn_token',
              token,
            )
            await Promise.resolve()
            return readVar(session, 'turn_token')
          },
          { userInput: token, session },
        )
      }),
    )
    expect(results).toEqual(Array.from({ length: 20 }, (_, i) => `token-${i}`))
  })
})
