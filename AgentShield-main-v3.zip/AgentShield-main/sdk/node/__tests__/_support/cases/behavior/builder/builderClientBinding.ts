
import { describe, it, expect } from 'vitest'
import * as path from 'node:path'

import { Shield } from '../../../../../index.js'

import '../../../../../adapters/langchain.js'
import '../../../../../adapters/openai_agents.js'
import '../../../../../adapters/anthropic_agents.js'

const REPO_ROOT = path.resolve(__dirname, '..', '..', '..', '..', '..', '..', '..')
const MINIMAL = path.join(
  REPO_ROOT,
  'tests',
  'fixtures',
  'smoke',
  'minimal.guardrails.yaml',
)

const mockLangchainClient = {
  invoke: async (_input: unknown): Promise<unknown> => {
    void _input
    return { content: 'ok' }
  },
  bindTools: (_tools: unknown[]): unknown => {
    void _tools
    return mockLangchainClient
  },
}

const mockOpenaiClient = {
  responses: {
    create: async (_args: unknown): Promise<unknown> => {
      void _args
      return { output: [] }
    },
  },
}

const mockAnthropicClient = {
  messages: {
    create: async (_args: unknown): Promise<unknown> => {
      void _args
      return {
        content: [{ type: 'text', text: 'ok' }],
      }
    },
  },
}

describe('builder client/adapter ordering parity', () => {
  describe('LangChain adapter', () => {
    it('withClient(c).withLangchain produces a bound LLM caller', () => {
      const builder = (Shield as unknown as typeof Shield)
        .fromYaml(MINIMAL)
        .withClient(mockLangchainClient)
        .withLangchain() as unknown as {
          _llmCaller: ((req: unknown) => unknown) | null
          _pendingLlmClient: unknown
          build: () => Shield
        }
      expect(typeof builder._llmCaller).toBe('function')
      expect(builder._pendingLlmClient).toBeNull()
      expect(builder.build()).toBeInstanceOf(Shield)
    }, 15_000)

    it('withLangchain.withClient(c) produces a bound LLM caller', () => {
      const builder = (Shield as unknown as typeof Shield)
        .fromYaml(MINIMAL)
        .withLangchain()
        .withClient(mockLangchainClient) as unknown as {
          _llmCaller: ((req: unknown) => unknown) | null
          _pendingLlmClient: unknown
          build: () => Shield
        }
      expect(typeof builder._llmCaller).toBe('function')
      expect(builder._pendingLlmClient).toBeNull()
      expect(builder.build()).toBeInstanceOf(Shield)
    })

    it('withLlm(c).withLangchain (LangChain-flavoured alias) still works', () => {
      const builder = (Shield as unknown as typeof Shield)
        .fromYaml(MINIMAL)
        .withLlm(mockLangchainClient)
        .withLangchain() as unknown as {
          _llmCaller: ((req: unknown) => unknown) | null
          _pendingLlmClient: unknown
        }
      expect(typeof builder._llmCaller).toBe('function')
      expect(builder._pendingLlmClient).toBeNull()
    })
  })

  describe('OpenAI Agents adapter', () => {
    it('withClient(c).withOpenaiAgents produces a bound LLM caller', () => {
      const builder = (Shield as unknown as typeof Shield)
        .fromYaml(MINIMAL)
        .withClient(mockOpenaiClient)
        .withOpenaiAgents() as unknown as {
          _llmCaller: ((req: unknown) => unknown) | null
          _pendingLlmClient: unknown
          build: () => Shield
        }
      expect(typeof builder._llmCaller).toBe('function')
      expect(builder._pendingLlmClient).toBeNull()
      expect(builder.build()).toBeInstanceOf(Shield)
    })

    it('withOpenaiAgents.withClient(c) produces a bound LLM caller', () => {
      const builder = (Shield as unknown as typeof Shield)
        .fromYaml(MINIMAL)
        .withOpenaiAgents()
        .withClient(mockOpenaiClient) as unknown as {
          _llmCaller: ((req: unknown) => unknown) | null
          _pendingLlmClient: unknown
          build: () => Shield
        }
      expect(typeof builder._llmCaller).toBe('function')
      expect(builder._pendingLlmClient).toBeNull()
      expect(builder.build()).toBeInstanceOf(Shield)
    })
  })

  describe('Anthropic adapter', () => {
    it('withClient(c).withAnthropic produces a bound LLM caller', () => {
      const builder = (Shield as unknown as typeof Shield)
        .fromYaml(MINIMAL)
        .withClient(mockAnthropicClient)
        .withAnthropic() as unknown as {
          _llmCaller: ((req: unknown) => unknown) | null
          _pendingLlmClient: unknown
          build: () => Shield
        }
      expect(typeof builder._llmCaller).toBe('function')
      expect(builder._pendingLlmClient).toBeNull()
      expect(builder.build()).toBeInstanceOf(Shield)
    })

    it('withAnthropic.withClient(c) produces a bound LLM caller', () => {
      const builder = (Shield as unknown as typeof Shield)
        .fromYaml(MINIMAL)
        .withAnthropic()
        .withClient(mockAnthropicClient) as unknown as {
          _llmCaller: ((req: unknown) => unknown) | null
          _pendingLlmClient: unknown
          build: () => Shield
        }
      expect(typeof builder._llmCaller).toBe('function')
      expect(builder._pendingLlmClient).toBeNull()
      expect(builder.build()).toBeInstanceOf(Shield)
    })
  })

  describe('edge cases', () => {
    it('withClient(c) without any adapter stashes the client', () => {
      const builder = (Shield as unknown as typeof Shield)
        .fromYaml(MINIMAL)
        .withClient(mockOpenaiClient) as unknown as {
          _llmCaller: ((req: unknown) => unknown) | null
          _pendingLlmClient: unknown
        }
      expect(builder._llmCaller).toBeNull()
      expect(builder._pendingLlmClient).toBe(mockOpenaiClient)
    })

    it('switching adapters after withClient rebinds against the latest bundle', () => {
      const b1 = (Shield as unknown as typeof Shield)
        .fromYaml(MINIMAL)
        .withClient(mockAnthropicClient)
        .withAnthropic() as unknown as {
          _llmCaller: ((req: unknown) => unknown) | null
        }
      const c1 = b1._llmCaller
      expect(typeof c1).toBe('function')

      const rebound = (b1 as unknown as { withClient(c: unknown): unknown })
        .withClient(mockAnthropicClient) as unknown as {
          _llmCaller: ((req: unknown) => unknown) | null
        }
      expect(typeof rebound._llmCaller).toBe('function')
    })
  })
})
