
import { describe, expect, it } from 'vitest'
import * as path from 'node:path'
import * as fs from 'node:fs'
import * as os from 'node:os'
import {
  RuntimeBuilder,
  AgentShieldResolverEnvelopeError,
  type ResolverResponseEnvelope,
} from '../../../../../index.js'

const _AGENT_GATE_YAML = `
metadata:
  name: "agent-resolver-envelope"
  version: "0.1.0"
  agent_shield_version: "2.0"

objective:
  goal: ["gate a tool on an agent-resolved variable"]
  forbidden: ["execute without resolver approval"]

resources:
  tools:
    - name: "do_thing"
      description: "Do a thing."
      permission: "execute"

variables:
  - name: "agent_authorized"
    type: "boolean"
    on_demand_by:
      kind: "agent"
      prompt: "Approve this?"
    lifetime: "per_session"

state_validation:
  guard_policies:
    - name: "thing_requires_approval"
      applies_to:
        tools: ["do_thing"]
      evaluate_when:
        - expression: "agent_authorized == true"
          reason: "Approval required."
      action: "block"
`

function _writeYaml(body: string, slug: string): string {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), `as-node-${slug}-`))
  const p = path.join(dir, 'guardrails.yaml')
  fs.writeFileSync(p, body, 'utf8')
  return p
}

describe('AgentShieldResolverEnvelopeError — typed surface', () => {
  it('exports an Error subclass with the decision field populated', () => {
    const err = new AgentShieldResolverEnvelopeError({ decision: 'allow' })
    expect(err).toBeInstanceOf(Error)
    expect(err).toBeInstanceOf(AgentShieldResolverEnvelopeError)
    expect(err.name).toBe('AgentShieldResolverEnvelopeError')
    expect(err.decision).toBe('allow')
    expect(err.message).toContain('value')
    expect(err.message).toContain('allow')
  })
})

describe('registerAgentResolver — envelope validation', () => {
  it("'allow' with explicit value resolves the variable", async () => {
    const yamlPath = _writeYaml(_AGENT_GATE_YAML, 'allow-ok')
    try {
      const rt = RuntimeBuilder.fromYaml(yamlPath)
        .registerAgentResolver((): ResolverResponseEnvelope => ({
          decision: 'allow',
          value: true,
        }))
        .build()
      const s = rt.newSession()
      s.beginTurn()
      try {
        const v = await s.validateToolCall('do_thing', { x: 1 }, 'tc-allow')
        expect(v.verdict.allowed).toBe(true)
      } finally {
        s.endTurn()
      }
    } finally {
      fs.rmSync(path.dirname(yamlPath), { recursive: true, force: true })
    }
  })

  it("'allow' with explicit null value is accepted", async () => {
    const yamlPath = _writeYaml(_AGENT_GATE_YAML, 'allow-null')
    try {
      const rt = RuntimeBuilder.fromYaml(yamlPath)
        .registerAgentResolver((): ResolverResponseEnvelope => ({
          decision: 'allow',
          value: null,
        }))
        .build()
      const s = rt.newSession()
      s.beginTurn()
      try {
        await s.resolveVariable('agent_authorized')
        const state = s.readVariable('agent_authorized')
        expect(state?.status).toBe('resolved')
        expect(state?.value).toBeNull()
      } finally {
        s.endTurn()
      }
    } finally {
      fs.rmSync(path.dirname(yamlPath), { recursive: true, force: true })
    }
  })

  it("'allow' WITHOUT value field fails closed ", async () => {
    const yamlPath = _writeYaml(_AGENT_GATE_YAML, 'allow-missing')
    try {
      const rt = RuntimeBuilder.fromYaml(yamlPath)
        .registerAgentResolver((): ResolverResponseEnvelope =>
          ({ decision: 'allow' } as unknown as ResolverResponseEnvelope),
        )
        .build()
      const s = rt.newSession()
      s.beginTurn()
      try {
        await s.resolveVariable('agent_authorized')
        const state = s.readVariable('agent_authorized')
        expect(state).not.toBeNull()
        expect(state?.status).toBe('denied')
        expect(String(state?.denyReason ?? '').toLowerCase()).toContain('value')
      } finally {
        s.endTurn()
      }
    } finally {
      fs.rmSync(path.dirname(yamlPath), { recursive: true, force: true })
    }
  })

  it("'deny' WITHOUT value field is accepted (value not required on deny)", async () => {
    const yamlPath = _writeYaml(_AGENT_GATE_YAML, 'deny-novalue')
    try {
      const rt = RuntimeBuilder.fromYaml(yamlPath)
        .registerAgentResolver((): ResolverResponseEnvelope => ({
          decision: 'deny',
          reason: 'never',
        }))
        .build()
      const s = rt.newSession()
      s.beginTurn()
      try {
        await s.resolveVariable('agent_authorized')
        const state = s.readVariable('agent_authorized')
        expect(state?.status).toBe('denied')
        expect(state?.denyReason).toContain('never')
      } finally {
        s.endTurn()
      }
    } finally {
      fs.rmSync(path.dirname(yamlPath), { recursive: true, force: true })
    }
  })

  it("'cancelled' WITHOUT value field is accepted (value not required on cancelled)", async () => {
    const yamlPath = _writeYaml(_AGENT_GATE_YAML, 'cancelled-novalue')
    try {
      const rt = RuntimeBuilder.fromYaml(yamlPath)
        .registerAgentResolver((): ResolverResponseEnvelope => ({
          decision: 'cancelled',
          reason: 'user backed out',
        }))
        .build()
      const s = rt.newSession()
      s.beginTurn()
      try {
        await s.resolveVariable('agent_authorized')
        const state = s.readVariable('agent_authorized')
        expect(state?.status).not.toBe('resolved')
        const reason = String(state?.denyReason ?? '').toLowerCase()
        expect(reason).not.toContain('value is required')
        expect(reason).not.toContain('host error')
      } finally {
        s.endTurn()
      }
    } finally {
      fs.rmSync(path.dirname(yamlPath), { recursive: true, force: true })
    }
  })

  it('unknown decision word is rejected at the wire boundary', async () => {
    const yamlPath = _writeYaml(_AGENT_GATE_YAML, 'bad-decision')
    try {
      const rt = RuntimeBuilder.fromYaml(yamlPath)
        .registerAgentResolver((): ResolverResponseEnvelope =>
          ({ decision: 'maybe' } as unknown as ResolverResponseEnvelope),
        )
        .build()
      const s = rt.newSession()
      s.beginTurn()
      try {
        await s.resolveVariable('agent_authorized')
        const state = s.readVariable('agent_authorized')
        expect(state?.status).toBe('denied')
        const reason = String(state?.denyReason ?? '').toLowerCase()
        expect(reason).toMatch(/decision|maybe/)
      } finally {
        s.endTurn()
      }
    } finally {
      fs.rmSync(path.dirname(yamlPath), { recursive: true, force: true })
    }
  })

  it('additional top-level properties on the response are rejected', async () => {
    const yamlPath = _writeYaml(_AGENT_GATE_YAML, 'extra-props')
    try {
      const rt = RuntimeBuilder.fromYaml(yamlPath)
        .registerAgentResolver((): ResolverResponseEnvelope =>
          ({
            decision: 'allow',
            value: true,
            meta: { hostInternal: 'should-not-pass' },
          } as unknown as ResolverResponseEnvelope),
        )
        .build()
      const s = rt.newSession()
      s.beginTurn()
      try {
        await s.resolveVariable('agent_authorized')
        const state = s.readVariable('agent_authorized')
        expect(state?.status).toBe('denied')
        const reason = String(state?.denyReason ?? '').toLowerCase()
        expect(reason).toMatch(/unknown field|meta/)
      } finally {
        s.endTurn()
      }
    } finally {
      fs.rmSync(path.dirname(yamlPath), { recursive: true, force: true })
    }
  })
})
