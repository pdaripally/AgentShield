import { describe, it, expect } from 'vitest'
import * as path from 'path'
import { RuntimeBuilder } from '../../../../../native.js'


const MINIMAL = path.resolve(
  __dirname,
  '../../../../../../../tests/fixtures/smoke/minimal.guardrails.yaml',
)

async function flushEvents(): Promise<void> {
  await new Promise((r) => setTimeout(r, 80))
}

describe('observability callback isolation', () => {
  it('throw in first invocation does not crash the process and second event is delivered', async () => {
    const events: unknown[] = []
    let calls = 0

    let uncaught: unknown = null
    const onUncaught = (err: unknown) => {
      uncaught = err
    }
    process.on('uncaughtException', onUncaught)

    try {
      const builder = RuntimeBuilder.fromYaml(MINIMAL)
      builder.registerProvider((_err: unknown, eventJson: unknown) => {
        calls++
        if (calls === 1) {
          throw new Error('synthetic observability sink failure')
        }
        if (typeof eventJson === 'string') {
          events.push(JSON.parse(eventJson))
        }
      })
      const rt = builder.build()
      const s = rt.newSession({
        session_id: 'sess-observability-callback',
        correlation_id: 'corr-observability-callback',
      })
      s.beginTurn()
      await s.validateInput('hello world')
      await s.validateOutput('ok')
      s.endTurn()
      rt.flushObservability()
      s.close()

      await flushEvents()
    } finally {
      process.off('uncaughtException', onUncaught)
    }

    expect(uncaught).toBeNull()

    expect(calls).toBeGreaterThanOrEqual(2)
    expect(events.length).toBeGreaterThanOrEqual(1)
  })

  it('callback that throws on every invocation does not crash the process', async () => {
    let calls = 0
    let uncaught: unknown = null
    const onUncaught = (err: unknown) => {
      uncaught = err
    }
    process.on('uncaughtException', onUncaught)

    try {
      const builder = RuntimeBuilder.fromYaml(MINIMAL)
      builder.registerProvider(() => {
        calls++
        throw new Error('persistent observability sink failure')
      })
      const rt = builder.build()
      const s = rt.newSession({
        session_id: 'sess-observability-callback-b',
        correlation_id: 'corr-observability-callback-b',
      })
      s.beginTurn()
      await s.validateInput('hello world')
      await s.validateOutput('ok')
      s.endTurn()
      rt.flushObservability()
      s.close()

      await flushEvents()
    } finally {
      process.off('uncaughtException', onUncaught)
    }

    expect(uncaught).toBeNull()
    expect(calls).toBeGreaterThanOrEqual(2)
  })
})
