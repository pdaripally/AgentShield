
import { describe, it, expect } from 'vitest'
import {
  RuntimeBuilder,
  Shield,
  type ShieldLogEvent,
} from '../../../../../index.js'

const FIXTURE_YAML = `
metadata:
  name: "caller-tool-call-id"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test caller-supplied tool_call_id propagation"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "echo"
      description: "Echo the supplied message."
      permission: "execute"
`

function _newShield(captured: ShieldLogEvent[]): Shield {
  const rt = RuntimeBuilder.fromYamlStrings([FIXTURE_YAML])
    .registerProvider((event) => {
      captured.push(event as ShieldLogEvent)
    })
    .build()
  return new Shield(rt, {})
}

async function _flush(): Promise<void> {
  await new Promise((r) => setTimeout(r, 50))
}

describe('Shield.protectTool caller-supplied toolCallId', () => {
  it('default 3-arg call mints a per-call UUID (backward compatible)', async () => {
    const captured: ShieldLogEvent[] = []
    const shield = _newShield(captured)

    const result = await shield.protectTool('echo', { msg: 'hi' }, async () => 'ok')
    expect(result.blocked).toBe(false)
    expect(result.output).toBe('ok')

    await _flush()
    const called = captured.find(
      (ev) =>
        ((ev.attributes ?? {}) as Record<string, unknown>)['agent_shield.event.id'] ===
        'tool.echo.called',
    )
    expect(called).toBeDefined()
    const attrs = (called as ShieldLogEvent).attributes as Record<string, unknown>
    const id = attrs['agent_shield.invocation.tool_call_id']
    expect(typeof id).toBe('string')
    expect((id as string).length).toBeGreaterThan(0)
  })

  it('4-arg call with {toolCallId} propagates the customer-supplied id to observability', async () => {
    const captured: ShieldLogEvent[] = []
    const shield = _newShield(captured)
    const supplied = 'vercel-call-abc123'

    const result = await shield.protectTool(
      'echo',
      { msg: 'hi' },
      async () => 'ok',
      { toolCallId: supplied },
    )
    expect(result.blocked).toBe(false)
    expect(result.output).toBe('ok')

    await _flush()
    const called = captured.find(
      (ev) =>
        ((ev.attributes ?? {}) as Record<string, unknown>)['agent_shield.event.id'] ===
        'tool.echo.called',
    )
    expect(called).toBeDefined()
    const attrs = (called as ShieldLogEvent).attributes as Record<string, unknown>
    expect(attrs['agent_shield.invocation.tool_call_id']).toBe(supplied)
  })

  it('rejects a non-string toolCallId at the SDK boundary', async () => {
    const captured: ShieldLogEvent[] = []
    const shield = _newShield(captured)
    await expect(
      shield.protectTool(
        'echo',
        { msg: 'hi' },
        async () => 'ok',
 // eslint-disable-next-line @typescript-eslint/no-explicit-any -- deliberate negative test.
        { toolCallId: 42 as any },
      ),
    ).rejects.toThrow(TypeError)
  })

  it('empty-string toolCallId falls back to a minted id (treated as absent)', async () => {
    const captured: ShieldLogEvent[] = []
    const shield = _newShield(captured)

    const result = await shield.protectTool(
      'echo',
      { msg: 'hi' },
      async () => 'ok',
      { toolCallId: '' },
    )
    expect(result.blocked).toBe(false)

    await _flush()
    const called = captured.find(
      (ev) =>
        ((ev.attributes ?? {}) as Record<string, unknown>)['agent_shield.event.id'] ===
        'tool.echo.called',
    )
    expect(called).toBeDefined()
    const attrs = (called as ShieldLogEvent).attributes as Record<string, unknown>
    const id = attrs['agent_shield.invocation.tool_call_id']
    expect(typeof id).toBe('string')
    expect((id as string).length).toBeGreaterThan(0)
  })
})
