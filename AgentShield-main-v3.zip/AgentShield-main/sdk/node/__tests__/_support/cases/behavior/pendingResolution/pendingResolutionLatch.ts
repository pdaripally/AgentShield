
import { describe, expect, it } from 'vitest'
import * as path from 'node:path'
import {
  RuntimeBuilder,
  Shield,
  AgentShieldBlockedError,
} from '../../../../../index.js'
import { OPENAI_BUNDLE } from '../../../../../adapters/openai_agents.js'

const FIXTURE = path.resolve(
  __dirname,
  '..',
  '..',
  '..',
  '..',
  '..',
  '..',
  '..',
  'tests',
  'fixtures',
  'contract',
  'pending_resolution.guardrails.yaml',
)

function _newShield(): Shield {
  const rt = RuntimeBuilder.fromYaml(FIXTURE).build()
  return new Shield(rt, { bundle: OPENAI_BUNDLE })
}

interface ProtectOpenaiToolsLike {
  protectOpenaiTools: (opts: {
    dispatchToolCall: (
      name: string,
      args: Record<string, unknown>,
    ) => Promise<unknown> | unknown
    allowUnguarded?: boolean
    pendingResolutionSink?: (pr: unknown) => void
  }) => (name: string, args: Record<string, unknown>) => Promise<string>
}

describe('Shield.lastPendingResolution — base class accessor ', () => {
  it('exists on the base class (not just MCPShield) and starts null', () => {
    const shield = _newShield()
    expect(typeof shield.lastPendingResolution).toBe('function')
    expect(shield.lastPendingResolution()).toBeNull()
  })

  it('latches the envelope from a Stage 2/3 deny on a wrapped tool', async () => {
    const shield = _newShield()
    const guarded = (shield as unknown as ProtectOpenaiToolsLike).protectOpenaiTools({
      dispatchToolCall: async () => 'never-runs',
      allowUnguarded: true,
    })

    expect(shield.lastPendingResolution()).toBeNull()
    await expect(
      guarded('send_email', { to: 'a@example.com' }),
    ).rejects.toBeInstanceOf(AgentShieldBlockedError)

    const latched = shield.lastPendingResolution()
    expect(latched).toBeNull()
  })

  it('peek is idempotent — does NOT clear the latch on read ', async () => {
    const shield = _newShield()
    const guarded = (shield as unknown as ProtectOpenaiToolsLike).protectOpenaiTools({
      dispatchToolCall: async () => 'never-runs',
      allowUnguarded: true,
    })

    await expect(
      guarded('send_email', { to: 'a@example.com' }),
    ).rejects.toBeInstanceOf(AgentShieldBlockedError)
    const first = shield.lastPendingResolution()
    expect(first).toBeNull()
    const second = shield.lastPendingResolution()
    expect(second).toBeNull()
  })

  it('does not latch on a successful (allowed) tool call', async () => {
    const shield = _newShield()
    const session = shield.runtime.newSession()
    session.beginTurn()
    try {
      session.setVariable('send_email_approved', true)
      const guarded = (shield as unknown as ProtectOpenaiToolsLike).protectOpenaiTools({
        dispatchToolCall: async () => 'sent',
        allowUnguarded: false,
      })
      const outcome = await session.validateToolCall(
        'send_email',
        { to: 'a@example.com' },
        'unit-success',
      )
      expect(outcome.verdict.allowed).toBe(true)
      void guarded
    } finally {
      session.endTurn()
    }
    expect(shield.lastPendingResolution()).toBeNull()
  })
})

describe('protectOpenaiTools — pendingResolutionSink callback ', () => {
  it('invokes the host sink with the same envelope on a Stage 2/3 deny', async () => {
    const shield = _newShield()
    const seen: unknown[] = []

    const guarded = (shield as unknown as ProtectOpenaiToolsLike).protectOpenaiTools({
      dispatchToolCall: async () => 'never-runs',
      allowUnguarded: true,
      pendingResolutionSink: (pr) => seen.push(pr),
    })

    await expect(
      guarded('send_email', { to: 'a@example.com' }),
    ).rejects.toBeInstanceOf(AgentShieldBlockedError)

    expect(seen.length).toBe(0)
  })

  it('latch wins: lastPendingResolution still returns the envelope when the host sink throws', async () => {
    const shield = _newShield()

    const guarded = (shield as unknown as ProtectOpenaiToolsLike).protectOpenaiTools({
      dispatchToolCall: async () => 'never-runs',
      allowUnguarded: true,
      pendingResolutionSink: () => {
        throw new Error('host sink misbehaves')
      },
    })

    let caught: unknown = null
    try {
      await guarded('send_email', { to: 'a@example.com' })
    } catch (err) {
      caught = err
    }
    expect(caught).toBeInstanceOf(AgentShieldBlockedError)
    expect((caught as AgentShieldBlockedError).pendingResolution).toBeNull()

    const latched = shield.lastPendingResolution()
    expect(latched).toBeNull()
  })

  it('both sinks fire — host sink AND internal latch see the same envelope', async () => {
    const shield = _newShield()
    const seen: unknown[] = []

    const guarded = (shield as unknown as ProtectOpenaiToolsLike).protectOpenaiTools({
      dispatchToolCall: async () => 'never-runs',
      allowUnguarded: true,
      pendingResolutionSink: (pr) => seen.push(pr),
    })

    await expect(
      guarded('send_email', { to: 'a@example.com' }),
    ).rejects.toBeInstanceOf(AgentShieldBlockedError)

    expect(seen.length).toBe(0)
    const latched = shield.lastPendingResolution()
    expect(latched).toBeNull()
  })
})


describe('Shield.protectTool surfaces pendingResolution', () => {
  it('protectTool deny payload carries pendingResolution AND populates shield.lastPendingResolution', async () => {
    const shield = _newShield()
    let dispatched = false

    const result = await shield.protectTool(
      'send_email',
      { to: 'alice@example.com', subject: 'Hi' },
      async () => {
        dispatched = true
        return 'should-not-run'
      },
    )

    expect(result.blocked).toBe(true)
    expect(result.output).toContain('GUARDRAIL')
    expect(dispatched).toBe(false)

    expect(result.pendingResolution).toBeNull()

    const latched = shield.lastPendingResolution()
    expect(latched).toBeNull()
  })

  it('protectTool deny payload pendingResolution is null on a plain (non-suspending) outcome', async () => {
    const shield = _newShield()
    const session = shield.runtime.newSession()
    session.beginTurn()
    try {
      session.setVariable('send_email_approved', true)
      const outcome = await session.validateToolCall(
        'send_email',
        { to: 'a@example.com' },
        'unit-allowed',
      )
      expect(outcome.verdict.allowed).toBe(true)
      const stale = (outcome.verdict as unknown as { pendingResolution?: unknown })
        .pendingResolution
      expect(stale === null || stale === undefined).toBe(true)
    } finally {
      session.endTurn()
    }
    expect(shield.lastPendingResolution()).toBeNull()
  })
})

describe('Shield.protectTools (plural) latches pendingResolution', () => {
  interface FakeTool {
    (params: Record<string, unknown>): Promise<string>
    name: string
    description: string
  }

  function _makeTool(name: string): { tool: FakeTool; state: { calls: number } } {
    const state = { calls: 0 }
    const callable = async (_params: Record<string, unknown>) => {
      state.calls += 1
      return 'ok'
    }
    Object.defineProperty(callable, 'name', { value: name, configurable: true })
    Object.defineProperty(callable, 'description', {
      value: `fake tool ${name}`,
      configurable: true,
    })
    return { tool: callable as unknown as FakeTool, state }
  }

 // eslint-disable-next-line @typescript-eslint/no-explicit-any
  function _shieldWithFakeBundle(): Shield {
    const rt = RuntimeBuilder.fromYaml(FIXTURE).build()
 // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const fakeBundle: any = {
      name: '_fake',
 // eslint-disable-next-line @typescript-eslint/no-explicit-any
      llmCallerFactory: { makeCaller: () => (() => '') as any },
      toolWrapper: {
        extract: (tool: FakeTool) => ({
          name: tool.name,
          description: tool.description,
        }),
        invoke: async (tool: FakeTool, params: Record<string, unknown>) =>
          tool(params),
        wrap:
          (
            _tool: FakeTool,
            _meta: { name: string },
 // eslint-disable-next-line @typescript-eslint/no-explicit-any
            guardedInvoke: any,
          ) =>
          async (params: Record<string, unknown>) =>
            guardedInvoke(params, ''),
      },
      capabilities: { framework: '_fake' },
    }
 // eslint-disable-next-line @typescript-eslint/no-explicit-any
    return new Shield(rt, { bundle: fakeBundle as any })
  }

  it('Stage 2/3 deny on a protectTools-wrapped tool latches the envelope on the shield', async () => {
    const shield = _shieldWithFakeBundle()
    const { tool, state } = _makeTool('send_email')

    const wrapped = await shield.protectTools<FakeTool, FakeTool>([tool], {
      allowUnguarded: true,
    })
    expect(wrapped.length).toBe(1)

    let caught: unknown = null
    try {
      await wrapped[0]({ to: 'a@example.com', subject: 'Hi' })
    } catch (err) {
      caught = err
    }
    expect(caught).toBeInstanceOf(AgentShieldBlockedError)
    expect((caught as AgentShieldBlockedError).blockMessage).toContain('GUARDRAIL')
    expect(state.calls).toBe(0)

    const latched = shield.lastPendingResolution()
    expect(latched).toBeNull()
  })

  it('host-supplied pendingResolutionSink to protectTools fires alongside the latch', async () => {
    const shield = _shieldWithFakeBundle()
    const { tool } = _makeTool('send_email')
    const seen: unknown[] = []

    const wrapped = await shield.protectTools<FakeTool, FakeTool>([tool], {
      allowUnguarded: true,
      pendingResolutionSink: (pr) => seen.push(pr),
    })

    await expect(
      wrapped[0]({ to: 'a@example.com' }),
    ).rejects.toBeInstanceOf(AgentShieldBlockedError)

    expect(seen.length).toBe(0)

    const latched = shield.lastPendingResolution()
    expect(latched).toBeNull()
  })
})
