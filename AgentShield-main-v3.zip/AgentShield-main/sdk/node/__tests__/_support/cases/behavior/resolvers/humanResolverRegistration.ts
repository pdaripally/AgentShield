
import { describe, expect, it } from 'vitest'
import * as path from 'node:path'
import * as fs from 'node:fs'
import * as os from 'node:os'
import {
  RuntimeBuilder,
  Runtime,
  type HumanResolveRequest,
  type ResolverResponseEnvelope,
} from '../../../../../index.js'

const _HUMAN_NAMED_YAML = `
metadata:
  name: "named-human-resolver"
  version: "0.1.0"
  agent_shield_version: "2.0"

objective:
  goal: ["send email only after explicit approval"]
  forbidden: ["send without approval"]

resources:
  tools:
    - name: "send_email"
      description: "Send email."
      permission: "execute"

variables:
  - name: "send_email_authorized"
    type: "boolean"
    on_demand_by:
      kind: "human"
      prompt: "Approve sending email to \${@tool.params.to}?"
      timeout_ms: 60000
    lifetime: "per_session"

state_validation:
  guard_policies:
    - name: "send_email_requires_approval"
      applies_to:
        tools: ["send_email"]
      evaluate_when:
        - expression: "send_email_authorized == true"
          reason: "Sending email requires explicit user confirmation"
      action: "block"
`

function _writeYaml(body: string, slug: string): string {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), `as-node-${slug}-`))
  const p = path.join(dir, 'guardrails.yaml')
  fs.writeFileSync(p, body, 'utf8')
  return p
}

describe('RuntimeBuilder.registerHumanResolver — ', () => {
  it('is chainable and returns RuntimeBuilder', () => {
    const yamlPath = _writeYaml(_HUMAN_NAMED_YAML, 'chain')
    try {
      const builder = RuntimeBuilder.fromYaml(yamlPath).registerHumanResolver(
        () => ({ decision: 'deny', reason: 'test' }),
      )
      expect(builder).toBeInstanceOf(RuntimeBuilder)
      const rt = builder.build()
      expect(rt).toBeInstanceOf(Runtime)
    } finally {
      fs.rmSync(path.dirname(yamlPath), { recursive: true, force: true })
    }
  })

  it('rejects non-callable fn with TypeError', () => {
    const yamlPath = _writeYaml(_HUMAN_NAMED_YAML, 'badfn')
    try {
      const builder = RuntimeBuilder.fromYaml(yamlPath)
      expect(() =>
 // @ts-expect-error - intentionally bad type
        builder.registerHumanResolver(null),
      ).toThrow(TypeError)
      expect(() =>
 // @ts-expect-error - intentionally bad type
        builder.registerHumanResolver('not-a-function'),
      ).toThrow(TypeError)
    } finally {
      fs.rmSync(path.dirname(yamlPath), { recursive: true, force: true })
    }
  })

  it('fails closed when no human resolver is registered', async () => {
    const yamlPath = _writeYaml(_HUMAN_NAMED_YAML, 'missing')
    try {
      const rt = RuntimeBuilder.fromYaml(yamlPath).build()
      const session = rt.newSession()
      session.beginTurn()
      try {
        const outcome = await session.validateToolCall(
          'send_email',
          { to: 'missing@example.com' },
          'tc-missing',
        )
        expect(outcome.verdict.allowed).toBe(false)
        expect(outcome.verdict.pendingResolution).toBeNull()
      } finally {
        session.endTurn()
      }
    } finally {
      fs.rmSync(path.dirname(yamlPath), { recursive: true, force: true })
    }
  })

  it('rejects provider/name fields in human resolver YAML', () => {
    for (const [field, line] of [
      ['provider', '      provider: auto_reject\n'],
      ['name', '      name: cli_prompt\n'],
    ] as const) {
      const yamlPath = _writeYaml(
        _HUMAN_NAMED_YAML.replace('      prompt:', `${line}      prompt:`),
        `bad-${field}`,
      )
      try {
        expect(() => RuntimeBuilder.fromYaml(yamlPath)).toThrow(new RegExp(field))
      } finally {
        fs.rmSync(path.dirname(yamlPath), { recursive: true, force: true })
      }
    }
  })

  it("'allow' with explicit value clears the gate and the tool admits", async () => {
    const yamlPath = _writeYaml(_HUMAN_NAMED_YAML, 'allow')
    try {
      const seen: HumanResolveRequest[] = []
      const rt = RuntimeBuilder.fromYaml(yamlPath)
        .registerHumanResolver((req): ResolverResponseEnvelope => {
          seen.push(req)
          return { decision: 'allow', value: true }
        })
        .build()

      const session = rt.newSession()
      session.beginTurn()
      try {
        const outcome = await session.validateToolCall(
          'send_email',
          { to: 'alice@example.com', subject: 'Hi' },
          'tc-allow',
        )
        expect(outcome.verdict.allowed).toBe(true)
      } finally {
        session.endTurn()
      }

      expect(seen.length).toBe(1)
      const req = seen[0]
      expect(req.requestId).toBeTruthy()
      expect(req.prompt).toContain('Approve sending email to alice@example.com')
      expect(typeof req.approvalNonce).toBe('string')
      expect(req.approvalNonce.length).toBeGreaterThan(0)
    } finally {
      fs.rmSync(path.dirname(yamlPath), { recursive: true, force: true })
    }
  })

  it("'deny' keeps the gate blocked", async () => {
    const yamlPath = _writeYaml(_HUMAN_NAMED_YAML, 'deny')
    try {
      const rt = RuntimeBuilder.fromYaml(yamlPath)
        .registerHumanResolver((): ResolverResponseEnvelope => ({
          decision: 'deny',
          reason: 'user said no',
        }))
        .build()

      const session = rt.newSession()
      session.beginTurn()
      try {
        const outcome = await session.validateToolCall(
          'send_email',
          { to: 'bob@example.com' },
          'tc-deny',
        )
        expect(outcome.verdict.allowed).toBe(false)
      } finally {
        session.endTurn()
      }
    } finally {
      fs.rmSync(path.dirname(yamlPath), { recursive: true, force: true })
    }
  })

  it('async callback is awaited before the verdict resolves', async () => {
    const yamlPath = _writeYaml(_HUMAN_NAMED_YAML, 'async')
    try {
      const rt = RuntimeBuilder.fromYaml(yamlPath)
        .registerHumanResolver(async (): Promise<ResolverResponseEnvelope> => {
          await new Promise((r) => setTimeout(r, 5))
          return { decision: 'allow', value: true }
        })
        .build()

      const session = rt.newSession()
      session.beginTurn()
      try {
        const outcome = await session.validateToolCall(
          'send_email',
          { to: 'carol@example.com' },
          'tc-async',
        )
        expect(outcome.verdict.allowed).toBe(true)
      } finally {
        session.endTurn()
      }
    } finally {
      fs.rmSync(path.dirname(yamlPath), { recursive: true, force: true })
    }
  })

  it("envelope validation: 'allow' without explicit value fails closed", async () => {
    const yamlPath = _writeYaml(_HUMAN_NAMED_YAML, 'envelope')
    try {
      const rt = RuntimeBuilder.fromYaml(yamlPath)
        .registerHumanResolver((): ResolverResponseEnvelope =>
          ({ decision: 'allow' } as unknown as ResolverResponseEnvelope),
        )
        .build()

      const session = rt.newSession()
      session.beginTurn()
      try {
        const outcome = await session.validateToolCall(
          'send_email',
          { to: 'dave@example.com' },
          'tc-envelope-bad',
        )
        expect(outcome.verdict.allowed).toBe(false)
        const state = session.readVariable('send_email_authorized')
        expect(state?.status).toBe('denied')
        expect(String(state?.denyReason ?? '').toLowerCase()).toContain('value')
      } finally {
        session.endTurn()
      }
    } finally {
      fs.rmSync(path.dirname(yamlPath), { recursive: true, force: true })
    }
  })
})
