import { describe, expect, it } from 'vitest'
import * as fs from 'node:fs'
import * as path from 'node:path'


type NodeSdk = typeof import('../../../../../index.js')

const FIXTURES = path.resolve(__dirname, '../../../../../../../tests/fixtures/smoke')
const MINIMAL = path.join(FIXTURES, 'minimal.guardrails.yaml')
const MINIMAL_YAML = fs.readFileSync(MINIMAL, 'utf8')
const ONE_MIB = 1024 * 1024

let sdk: NodeSdk | null = null
let nativeLoadError: unknown = null

try {
  sdk = await import('../../../../../index.js')
} catch (error) {
  nativeLoadError = error
}

const describeIfNative = nativeLoadError ? describe.skip : describe

function buildRuntime() {
  return sdk!.RuntimeBuilder.fromYaml(MINIMAL).build()
}

function newSession(
  runtime = buildRuntime(),
  suffix = 'default',
) {
  return runtime.newSession({
    sessionId: `sess-ffi-${suffix}`,
    correlationId: `corr-ffi-${suffix}`,
  })
}

function makeDeepObject(depth: number): Record<string, unknown> {
  let current: Record<string, unknown> = { leaf: 'done' }
  for (let i = 0; i < depth; i += 1) {
    current = {
      depth: i,
      child: current,
    }
  }
  return current
}

function countDepth(node: unknown): number {
  let depth = 0
  let current = node as { child?: unknown } | undefined
  while (current && typeof current === 'object' && 'child' in current) {
    depth += 1
    current = current.child as { child?: unknown } | undefined
  }
  return depth
}

describeIfNative('Node napi-rs FFI boundary', () => {
  it('handles an embedded NUL byte in the tool name without truncating to echo', async () => {
    const session = newSession()
    const result = await session.validateToolCall(
      'echo\x00suffix',
      { msg: 'hi' },
      'call-nul-byte',
    )

    expect(result.verdict.allowed).toBe(true)
    expect(result.verdict.policy).toBeNull()
  })

  it('round-trips a 4-byte emoji in tool params', async () => {
    const session = newSession()
    session.setVariable('authorized', true)

    const emoji = '🛡️'
    const result = await session.validateToolCall(
      'echo',
      { value: emoji },
      'call-emoji',
    )

    expect(result.verdict.allowed).toBe(true)
    expect((result.params as { value: string }).value).toBe(emoji)
  })

  it('treats empty-string input as a real string, not null', async () => {
    const session = newSession()
    const verdict = await session.validateInput('')

    expect(verdict).toBeTruthy()
    expect(verdict.allowed).toBe(true)
  })

  it('accepts a deeply nested JSON payload without crashing the FFI boundary', async () => {
    const session = newSession()
    session.setVariable('authorized', true)

    const depth = 24
    const nested = makeDeepObject(depth)
    const result = await session.validateToolCall('echo', nested, 'call-deep-json')

    expect(result.verdict.allowed).toBe(true)
    expect(countDepth(result.params)).toBe(depth)
  })

  it('surfaces malformed long-expression configs as JavaScript errors', () => {
    const longBrokenExpression = '('.repeat(4096)
    const yaml = `${MINIMAL_YAML}
output_validation:
  guard_policies:
    - name: "ffi-long-invalid-expression"
      evaluate_when:
        - expression: "${longBrokenExpression}
          reason: "FFI should surface parser errors as JS exceptions."
      action: "block"
`

    expect(() => sdk!.RuntimeBuilder.fromYamlStrings([yaml]).build()).toThrowError(Error)
  })

  it('handles a 1 MiB string tool parameter value without OOM', async () => {
    const session = newSession()
    session.setVariable('authorized', true)

    const payload = 'x'.repeat(ONE_MIB)
    const result = await session.validateToolCall(
      'echo',
      { payload },
      'call-large-string',
    )

    expect(result.verdict.allowed).toBe(true)
    expect((result.params as { payload: string }).payload.length).toBe(ONE_MIB)
  })

  it('handles 4 concurrent batches of 10K validateToolCall calls with consistent verdicts', async () => {
    const runtime = buildRuntime()
    const batches = Array.from({ length: 4 }, (_, batchIndex) =>
      (async () => {
        const session = newSession(runtime, `batch-${batchIndex}`)
        let validated = 0

        for (let i = 0; i < 10_000; i += 1) {
          const result = await session.validateToolCall(
            'echo',
            { msg: `batch-${batchIndex}-call-${i}` },
            `call-${batchIndex}-${i}`,
          )

          expect(result.verdict.allowed).toBe(false)
          expect(result.verdict.policy).toBe('echo_only_when_authorized')
          validated += 1
        }

        return validated
      })(),
    )

    await expect(Promise.all(batches)).resolves.toEqual([10_000, 10_000, 10_000, 10_000])
  }, 30_000)

  it('handles a ~1 MiB JSON object in toolParams without OOM', async () => {
    const session = newSession()
    session.setVariable('authorized', true)

    const chunk = 'y'.repeat(1024)
    const toolParams = {
      entries: Array.from({ length: 1024 }, (_, index) => ({
        index,
        value: chunk,
      })),
    }

    expect(Buffer.byteLength(JSON.stringify(toolParams), 'utf8')).toBeGreaterThanOrEqual(ONE_MIB)

    const result = await session.validateToolCall('echo', toolParams, 'call-large-object')

    expect(result.verdict.allowed).toBe(true)
    expect((result.params as { entries: Array<{ index: number; value: string }> }).entries).toHaveLength(1024)
    expect((result.params as { entries: Array<{ index: number; value: string }> }).entries[0]).toEqual({
      index: 0,
      value: chunk,
    })
  })
})
