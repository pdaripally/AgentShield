
import { afterAll, beforeAll, describe, it, expect } from 'vitest'
import * as fs from 'node:fs'
import * as path from 'node:path'
import { ConfigurationMissingModelError, RuntimeBuilder, Shield } from '../../../../../index.js'
import {
  OPENAI_BUNDLE,
  install,
  makeLlmCaller,
} from '../../../../../adapters/openai_agents.js'

install()

const MULTI_CONFIG_YAML = `metadata:
  name: oai-llm-caller-model-fixture
  version: 0.1.0
  agent_shield_version: "2.0"
objective:
  goal: ["exercise configurations[] routing"]
  forbidden: ["bypass"]
configurations:
  - id: stage1-judge
    type: llm
    provider: openai.chat
    model: gpt-4o
    max_tokens: 256
  - id: stage3-judge
    type: llm
    provider: openai.chat
    model: gpt-4o-mini-with-context
input_validation:
  guard_policies:
    - name: trivial_input_guard
      evaluate_when:
        - patterns: ["jailbreak"]
          reason: "jailbreak attempt"
      action: "block"
`

const FIXTURE_DIR = path.resolve(__dirname, '.tmp-fixtures', 'openai')
const FIXTURE_PATH = path.join(FIXTURE_DIR, 'oai_llm_caller_model.guardrails.yaml')

beforeAll(() => {
  fs.mkdirSync(FIXTURE_DIR, { recursive: true })
  fs.writeFileSync(FIXTURE_PATH, MULTI_CONFIG_YAML, 'utf8')
})

afterAll(() => {
  try {
    fs.rmSync(FIXTURE_DIR, { recursive: true, force: true })
  } catch {
  }
})

interface RecordedCall {
  model: string
  messages: unknown
  max_tokens?: number
  [key: string]: unknown
}

function makeFakeClient(): {
  client: { chat: { completions: { create: (args: any) => Promise<any> } } }
  calls: RecordedCall[]
} {
  const calls: RecordedCall[] = []
  const client = {
    chat: {
      completions: {
        create: async (args: RecordedCall) => {
          calls.push(args)
          return {
            choices: [{ message: { content: 'ok' } }],
          }
        },
      },
    },
  }
  return { client, calls }
}

function buildRuntime(yaml: string) {
  return RuntimeBuilder.fromYamlStrings([yaml]).build()
}


describe('Runtime.llmConfiguration', () => {
  it('returns the camelCased YAML configuration for a known id', () => {
    const rt = buildRuntime(MULTI_CONFIG_YAML)
    const cfg = rt.llmConfiguration('stage1-judge')
    expect(cfg).not.toBeNull()
    expect(cfg!.id).toBe('stage1-judge')
    expect(cfg!.type).toBe('llm')
    expect(cfg!.model).toBe('gpt-4o')
    expect(cfg!.maxTokens).toBe(256)
  })

  it('returns null for an unknown id', () => {
    const rt = buildRuntime(MULTI_CONFIG_YAML)
    expect(rt.llmConfiguration('does-not-exist')).toBeNull()
  })
})


describe('makeLlmCaller — configurationResolver wiring', () => {
  it('uses the YAML-declared model for each configurationId', async () => {
    const rt = buildRuntime(MULTI_CONFIG_YAML)
    const { client, calls } = makeFakeClient()

    const caller = makeLlmCaller(client, {
      configurationResolver: (id) => rt.llmConfiguration(id ?? ''),
    })

    await caller({ configurationId: 'stage1-judge', prompt: 'is the input safe?' })
    await caller({ configurationId: 'stage3-judge', prompt: 'is the tool call safe?' })

    expect(calls).toHaveLength(2)
    expect(calls[0].model).toBe('gpt-4o')
    expect(calls[0].max_tokens).toBe(256)
    expect(calls[1].model).toBe('gpt-4o-mini-with-context')
    expect(calls[1].max_tokens).toBeUndefined()
  })

  it('raises ConfigurationMissingModelError when no matching configuration', async () => {
    const rt = buildRuntime(MULTI_CONFIG_YAML)
    const { client, calls } = makeFakeClient()
    const adapterErrors: unknown[] = []

    const caller = makeLlmCaller(client, {
      configurationResolver: (id) => rt.llmConfiguration(id ?? ''),
      recordAdapterError: (err) => adapterErrors.push(err),
    })

    await expect(
      caller({ configurationId: 'not-in-yaml', prompt: 'judge me' }),
    ).rejects.toThrow(ConfigurationMissingModelError)

    expect(calls).toHaveLength(0)
  })

  it('raises when no resolver is wired', async () => {
    const { client, calls } = makeFakeClient()
    const caller = makeLlmCaller(client)
    await expect(
      caller({ configurationId: 'stage1-judge', prompt: 'prompt' }),
    ).rejects.toThrow(ConfigurationMissingModelError)
    expect(calls).toHaveLength(0)
  })

  it('raises when configurationId is null', async () => {
    const { client, calls } = makeFakeClient()

    const caller = makeLlmCaller(client, {
      configurationResolver: () => null,
    })

    await expect(
      caller({ configurationId: null, prompt: 'prompt' }),
    ).rejects.toThrow(ConfigurationMissingModelError)
    await expect(
      caller({ configurationId: '' as unknown as null, prompt: 'prompt' }),
    ).rejects.toThrow(ConfigurationMissingModelError)

    expect(calls).toHaveLength(0)
  })

  it('raises when resolver returns null for a non-empty configurationId', async () => {
    const { client } = makeFakeClient()

    const caller = makeLlmCaller(client, {
      configurationResolver: () => null,
    })

    await expect(
      caller({ configurationId: 'unknown', prompt: 'prompt' }),
    ).rejects.toThrow(ConfigurationMissingModelError)
  })

  it('raises (and records the resolver error) when the resolver throws', async () => {
    const { client, calls } = makeFakeClient()
    const adapterErrors: unknown[] = []

    const caller = makeLlmCaller(client, {
      configurationResolver: () => {
        throw new Error('boom')
      },
      recordAdapterError: (err) => adapterErrors.push(err),
    })

    await expect(
      caller({ configurationId: 'stage1-judge', prompt: 'prompt' }),
    ).rejects.toThrow(ConfigurationMissingModelError)

    expect(calls).toHaveLength(0)

    const messages = adapterErrors.map((e) =>
      e instanceof Error ? e.message : String(e),
    )
    expect(messages.some((m) => m.includes('configurationResolver raised'))).toBe(true)
    expect(messages.some((m) => m.includes('boom'))).toBe(true)
  })
})


describe('ShieldBuilder wires the resolver through build', () => {
  it('caller honours YAML configurations after build', async () => {
    const { client, calls } = makeFakeClient()

    const builder = Shield.fromYaml(FIXTURE_PATH)
      .withOpenaiAgents()
      .withClient(client)

    const boundCaller = (builder as unknown as {
      _llmCaller: ((req: unknown) => unknown) | null
    })._llmCaller
    expect(boundCaller).not.toBeNull()

    builder.build()
    const fn = boundCaller as (req: unknown) => Promise<string>
    await fn({ configurationId: 'stage1-judge', prompt: 'prompt' })
    await fn({ configurationId: 'stage3-judge', prompt: 'prompt' })

    expect(calls.at(-2)?.model).toBe('gpt-4o')
    expect(calls.at(-2)?.max_tokens).toBe(256)
    expect(calls.at(-1)?.model).toBe('gpt-4o-mini-with-context')
  })

  it('builder bound BEFORE build raises; AFTER build honours YAML', async () => {
    const { client, calls } = makeFakeClient()

    const builder = Shield.fromYaml(FIXTURE_PATH)
      .withOpenaiAgents()
      .withClient(client)

    const fn = (
      builder as unknown as {
        _llmCaller: (req: unknown) => Promise<string>
      }
    )._llmCaller

    await expect(
      fn({ configurationId: 'stage1-judge', prompt: 'prompt' }),
    ).rejects.toThrow(ConfigurationMissingModelError)

    builder.build()

    await fn({ configurationId: 'stage1-judge', prompt: 'prompt' })
    expect(calls[0].model).toBe('gpt-4o')
  })

  it('client wired BEFORE withOpenaiAgents (pending-rebind path) also gets the resolver', async () => {
    const { client, calls } = makeFakeClient()

    const builder = Shield.fromYaml(FIXTURE_PATH)
      .withClient(client)
      .withOpenaiAgents()

    builder.build()

    const fn = (
      builder as unknown as {
        _llmCaller: (req: unknown) => Promise<string>
      }
    )._llmCaller

    await fn({ configurationId: 'stage1-judge', prompt: 'prompt' })
    expect(calls[0].model).toBe('gpt-4o')
    expect(calls[0].max_tokens).toBe(256)
  })

  it('surfaces resolver lookup errors through observability providers', async () => {
    const { client, calls } = makeFakeClient()

    const events: Array<Record<string, unknown>> = []
    const provider = (e: unknown): void => {
      events.push(e as Record<string, unknown>)
    }

    const builder = Shield.fromYaml(FIXTURE_PATH)
      .withOpenaiAgents()
      .withClient(client)
      .withObservability(provider)

    builder.build()

    ;(
      builder as unknown as {
        _configurationResolverLookup:
          | ((id: string) => unknown)
          | null
      }
    )._configurationResolverLookup = () => {
      throw new Error('synthetic resolver failure')
    }

    const fn = (
      builder as unknown as {
        _llmCaller: (req: unknown) => Promise<string>
      }
    )._llmCaller

    await expect(
      fn({ configurationId: 'stage1-judge', prompt: 'prompt' }),
    ).rejects.toThrow(ConfigurationMissingModelError)

    expect(calls).toHaveLength(0)

    expect(events.length).toBeGreaterThan(0)
    const debugEvent = events.find(
      (e) =>
        e.eventType === 'adapter.llm_caller_error' && e.severity === 'debug',
    )
    expect(debugEvent).toBeDefined()
    const attrs = debugEvent!['attributes'] as Record<string, unknown>
    const message = String(attrs['agent_shield.adapter.error_message'] ?? '')
    expect(message).toContain('synthetic resolver failure')
    const warnEvent = events.find(
      (e) =>
        e.eventType === 'adapter.llm_caller_error' && e.severity === 'warn',
    )
    expect(warnEvent).toBeDefined()
    const warnMsg = String(warnEvent?.message ?? '')
    expect(warnMsg).not.toContain('synthetic resolver failure')
  })
})

describe('OPENAI_BUNDLE.llmCallerFactory', () => {
  it('forwards ctx.configurationResolver to the caller closure', async () => {
    const { client, calls } = makeFakeClient()
    const calledIds: string[] = []
    const caller = OPENAI_BUNDLE.llmCallerFactory!.makeCaller(client, {
      recordAdapterError: () => {},
      configurationResolver: (id) => {
        calledIds.push(String(id))
        if (id === 'stage1-judge') {
          return { id: 'stage1-judge', type: 'llm', model: 'gpt-from-resolver' }
        }
        return null
      },
    }) as (req: unknown) => Promise<string>

    await caller({ configurationId: 'stage1-judge', prompt: 'prompt' })
    expect(calledIds).toContain('stage1-judge')
    expect(calls[0].model).toBe('gpt-from-resolver')
  })
})


const AZURE_YAML = `metadata:
  name: oai-azure-fixture
  version: 0.1.0
  agent_shield_version: "2.0"
objective:
  goal: ["exercise Azure routing"]
  forbidden: ["bypass"]
configurations:
  - id: azure-judge
    type: llm
    provider: azure_openai
    model: my-gpt4o-deployment
  - id: openai-judge
    type: llm
    provider: openai.chat
    model: gpt-4o
input_validation:
  guard_policies:
    - name: trivial_input_guard
      evaluate_when:
        - patterns: ["jailbreak"]
          reason: "jailbreak attempt"
      action: "block"
`

describe('Azure-OpenAI routing', () => {

  it('Runtime.llmConfiguration surfaces model for Azure entry', () => {
    const rt = buildRuntime(AZURE_YAML)
    const cfg = rt.llmConfiguration('azure-judge')
    expect(cfg).not.toBeNull()
    expect(cfg!.model).toBe('my-gpt4o-deployment')
    expect(cfg!.provider).toBe('azure_openai')
  })

  it('caller sends YAML model verbatim on Azure providers', async () => {
    const rt = buildRuntime(AZURE_YAML)
    const { client, calls } = makeFakeClient()
    const caller = makeLlmCaller(client, {
      configurationResolver: (id) => rt.llmConfiguration(id ?? ''),
    })

    await caller({ configurationId: 'azure-judge', prompt: 'p' })

    expect(calls).toHaveLength(1)
    expect(calls[0].model).toBe('my-gpt4o-deployment')
  })

  it('caller sends YAML model verbatim on non-Azure provider entries', async () => {
    const rt = buildRuntime(AZURE_YAML)
    const { client, calls } = makeFakeClient()
    const caller = makeLlmCaller(client, {
      configurationResolver: (id) => rt.llmConfiguration(id ?? ''),
    })

    await caller({ configurationId: 'openai-judge', prompt: 'p' })
    expect(calls[0].model).toBe('gpt-4o')
  })

  it('caller accepts microsoft.azure.openai reverse-domain provider alias', async () => {
    const yaml = `metadata:
  name: rd
  version: 0.1.0
  agent_shield_version: "2.0"
objective:
  goal: ["x"]
  forbidden: ["bypass"]
configurations:
  - id: judge
    type: llm
    provider: microsoft.azure.openai
    model: my-deploy
input_validation:
  guard_policies:
    - name: trivial
      evaluate_when:
        - patterns: ["x"]
          reason: "x"
      action: "block"
`
    const rt = buildRuntime(yaml)
    const { client, calls } = makeFakeClient()
    const caller = makeLlmCaller(client, {
      configurationResolver: (id) => rt.llmConfiguration(id ?? ''),
    })
    await caller({ configurationId: 'judge', prompt: 'p' })
    expect(calls[0].model).toBe('my-deploy')
  })
})
