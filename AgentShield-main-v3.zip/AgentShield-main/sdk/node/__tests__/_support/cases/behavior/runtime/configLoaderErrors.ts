
import { describe, it, expect, beforeAll, afterAll } from 'vitest'
import * as fs from 'node:fs'
import * as os from 'node:os'
import * as path from 'node:path'

import { Shield } from '../../../../../shield.js'
import { RuntimeBuilder } from '../../../../../index.js'
import { AgentShieldConfigError } from '../../../../../errors.js'

const TMP_ROOT = fs.mkdtempSync(path.join(os.tmpdir(), 'agent-shield-loader-typed-'))

const MINIMAL_VALID = `metadata:
  name: "test-valid"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["pass"]
  forbidden: ["fail"]
resources:
  tools:
    - name: "echo"
      description: "echo"
      permission: "read_only"
`

function writeFixture(name: string, content: string): string {
  const p = path.join(TMP_ROOT, name)
  fs.writeFileSync(p, content)
  return p
}

afterAll(() => {
  try {
    fs.rmSync(TMP_ROOT, { recursive: true, force: true })
  } catch {
  }
})

describe('AgentShieldConfigError — class identity & export surface', () => {
  it('is exported from both the package root and ./errors.js', async () => {
    const pkgRoot = await import('../../../../../index.js')
    expect(pkgRoot.AgentShieldConfigError).toBe(AgentShieldConfigError)
  })

  it('is a subclass of Error so existing catch handlers keep working', () => {
    const err = new AgentShieldConfigError('test', {})
    expect(err).toBeInstanceOf(Error)
    expect(err).toBeInstanceOf(AgentShieldConfigError)
    expect(err.name).toBe('AgentShieldConfigError')
  })

  it('toJSON emits the canonical 5+2 wire shape', () => {
    const err = new AgentShieldConfigError('boom', {
      path: '/x.yaml',
      line: 3,
      column: 5,
      field: 'resources.tools[0].name',
      code: 'schema_violation',
      remediation: 'Add a name',
    })
    expect(err.toJSON()).toEqual({
      name: 'AgentShieldConfigError',
      message: 'boom',
      path: '/x.yaml',
      line: 3,
      column: 5,
      field: 'resources.tools[0].name',
      code: 'schema_violation',
      remediation: 'Add a name',
    })
  })
})

describe('Shield.fromYaml → typed loader errors', () => {
  it('unparseable YAML raises AgentShieldConfigError with code + line', () => {
    const p = writeFixture('unparseable.guardrails.yaml', '{this is: not yaml\n  - and: [broken')
    let caught: unknown = null
    try {
      Shield.fromYaml(p).build()
    } catch (err) {
      caught = err
    }
    expect(caught).toBeInstanceOf(AgentShieldConfigError)
    const e = caught as AgentShieldConfigError
    expect(e.code).toBe('unparseable_yaml')
    expect(e.line ?? e.column).not.toBeNull()
  })

  it('schema violation carries path and a structured code', () => {
    const p = writeFixture(
      'bad-schema.guardrails.yaml',
      `metadata:
  name: "x"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: "this should be a list"
  forbidden: ["fail"]
`,
    )
    let caught: unknown = null
    try {
      Shield.fromYaml(p).build()
    } catch (err) {
      caught = err
    }
    expect(caught).toBeInstanceOf(AgentShieldConfigError)
    const e = caught as AgentShieldConfigError
    expect(e.path).toContain('bad-schema.guardrails.yaml')
    expect(typeof e.code).toBe('string')
    expect(e.code!.length).toBeGreaterThan(0)
  })

  it('unknown resolver kind raises typed exception', () => {
    const p = writeFixture(
      'bad-resolver.guardrails.yaml',
      `metadata:
  name: "x"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["pass"]
  forbidden: ["fail"]
resources:
  tools:
    - name: "echo"
      description: "echo"
      permission: "read_only"
resolvers:
  - id: "bad"
    kind: "telepathy"
`,
    )
    let caught: unknown = null
    try {
      Shield.fromYaml(p).build()
    } catch (err) {
      caught = err
    }
    expect(caught).toBeInstanceOf(AgentShieldConfigError)
    const e = caught as AgentShieldConfigError
    expect(typeof e.code).toBe('string')
  })

  it('extends-chain cycle raises typed exception with cycle_detected code', () => {
    const a = writeFixture('cycle-a.guardrails.yaml', `extends: ["./cycle-b.guardrails.yaml"]\n` + MINIMAL_VALID)
    writeFixture('cycle-b.guardrails.yaml', `extends: ["./cycle-a.guardrails.yaml"]\n` + MINIMAL_VALID)
    let caught: unknown = null
    try {
      Shield.fromYaml(a).build()
    } catch (err) {
      caught = err
    }
    expect(caught).toBeInstanceOf(AgentShieldConfigError)
    const e = caught as AgentShieldConfigError
    expect(e.message).toMatch(/extends|cycle/i)
    expect(['cycle_detected', 'extends_cycle']).toContain(e.code)
  })
})

describe('Shield.fromYamlChain → typed loader errors', () => {
  it('chain with a malformed leaf raises AgentShieldConfigError', () => {
    const valid = writeFixture('chain-base.guardrails.yaml', MINIMAL_VALID)
    const bad = writeFixture('chain-bad.guardrails.yaml', '{nope: [')
    let caught: unknown = null
    try {
      Shield.fromYamlChain([valid, bad]).build()
    } catch (err) {
      caught = err
    }
    expect(caught).toBeInstanceOf(AgentShieldConfigError)
  })
})

describe('RuntimeBuilder.fromYaml* — typed loader errors', () => {
  it('fromYaml directly on RuntimeBuilder raises typed exception', () => {
    const p = writeFixture('rb-bad.guardrails.yaml', '{this is: not yaml')
    let caught: unknown = null
    try {
      RuntimeBuilder.fromYaml(p).build()
    } catch (err) {
      caught = err
    }
    expect(caught).toBeInstanceOf(AgentShieldConfigError)
  })

  it('fromYamlStrings raises typed exception on malformed YAML', () => {
    let caught: unknown = null
    try {
      RuntimeBuilder.fromYamlStrings(['{nope']).build()
    } catch (err) {
      caught = err
    }
    expect(caught).toBeInstanceOf(AgentShieldConfigError)
  })
})

describe('AgentShieldConfigError — non-loader errors unaffected', () => {
  it('passing a non-existent path yields AgentShieldConfigError (io_error code)', () => {
    let caught: unknown = null
    try {
      Shield.fromYaml('/definitely/does/not/exist/anywhere.yaml').build()
    } catch (err) {
      caught = err
    }
    expect(caught).toBeInstanceOf(AgentShieldConfigError)
    const e = caught as AgentShieldConfigError
    expect(e.code).toBe('io_error')
  })
})

beforeAll(() => {
  expect(fs.existsSync(TMP_ROOT)).toBe(true)
})
