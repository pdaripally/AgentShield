
import { describe, it, expect } from 'vitest'
import { execFileSync } from 'node:child_process'
import * as path from 'node:path'

const SDK_ROOT = path.resolve(__dirname, '..', '..', '..', '..', '..')

function runNode(script: string): string {
  const out = execFileSync(process.execPath, ['-e', script], {
    cwd: SDK_ROOT,
    encoding: 'utf8',
    env: {
      ...process.env,
      NODE_PATH: path.join(SDK_ROOT, 'node_modules'),
    },
  })
  return out.toString().trim()
}

describe('adapter-subpath side-effect imports do not crash', () => {
  it('require @microsoft/agent-shield/adapters/langchain in isolation', () => {
    expect(
      runNode(
        `require('@microsoft/agent-shield/adapters/langchain'); console.log('ok');`,
      ),
    ).toBe('ok')
  })

  it('require @microsoft/agent-shield/adapters/openai_agents in isolation', () => {
    expect(
      runNode(
        `require('@microsoft/agent-shield/adapters/openai_agents'); console.log('ok');`,
      ),
    ).toBe('ok')
  })

  it('require @microsoft/agent-shield/adapters/anthropic_agents in isolation', () => {
    expect(
      runNode(
        `require('@microsoft/agent-shield/adapters/anthropic_agents'); console.log('ok');`,
      ),
    ).toBe('ok')
  })

  it('adapter-then-root order still works', () => {
    expect(
      runNode(
        `require('@microsoft/agent-shield/adapters/langchain'); require('@microsoft/agent-shield'); console.log('ok');`,
      ),
    ).toBe('ok')
  })

  it('root-then-adapter order still works', () => {
    expect(
      runNode(
        `require('@microsoft/agent-shield'); require('@microsoft/agent-shield/adapters/langchain'); console.log('ok');`,
      ),
    ).toBe('ok')
  })
})

describe('MCP prototype augmentations are present synchronously', () => {

  it('ShieldBuilder.prototype.withMcp is callable after adapter-only require', () => {
    const out = runNode(`
      require('@microsoft/agent-shield/adapters/langchain');
      const { ShieldBuilder } = require('@microsoft/agent-shield');
      console.log(typeof ShieldBuilder.prototype.withMcp);
    `)
    expect(out).toBe('function')
  })

  it('Shield.prototype.protectServer is callable after adapter-only require', () => {
    const out = runNode(`
      require('@microsoft/agent-shield/adapters/langchain');
      const { Shield } = require('@microsoft/agent-shield');
      console.log(typeof Shield.prototype.protectServer);
    `)
    expect(out).toBe('function')
  })

  it('Shield.fromYaml(...).withMcp works synchronously after adapter-only require', () => {
    const yamlPath = path
      .resolve(SDK_ROOT, '../../tests/fixtures/smoke/minimal.guardrails.yaml')
      .replace(/\\/g, '\\\\')
    const out = runNode(`
      require('@microsoft/agent-shield/adapters/langchain');
      const { Shield } = require('@microsoft/agent-shield');
      const builder = Shield.fromYaml('${yamlPath}').withMcp();
      console.log(typeof builder.build === 'function' ? 'ok' : 'no-build');
    `)
    expect(out).toBe('ok')
  })
})
