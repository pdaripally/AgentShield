import { afterEach, beforeEach, describe, expect, it } from 'vitest'

import { RuntimeBuilder } from '../../../../../index.js'

const UNSET = 'AGENT_SHIELD_F16_NODE_TEST_UNSET_VAR_XYZ123'
const SET = 'AGENT_SHIELD_F16_NODE_TEST_AACS_KEY_OK'

function yamlWithAacs(apiKeyEnv: string | null): string {
  const apiKeyLine = apiKeyEnv ? `    api_key_env: "${apiKeyEnv}"\n` : ''
  return `metadata:
  name: "test"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["pass"]
  forbidden: ["fail"]
configurations:
  - id: "aacs_default"
    type: classifier
    provider: "azure_content_safety"
    endpoint: "https://example.cognitiveservices.azure.com"
    threshold: 0.5
${apiKeyLine}post_tool_validation:
  guard_policies:
    - name: "aacs_check"
      evaluate_when:
        - classifier:
            configuration: "aacs_default"
          reason: "classifier flagged"
`
}

describe('classifier wiring validated at load time', () => {
  beforeEach(() => {
    delete process.env[UNSET]
    delete process.env[SET]
  })
  afterEach(() => {
    delete process.env[UNSET]
    delete process.env[SET]
  })

  it('build throws with actionable text when the api_key_env is unset', () => {
    delete process.env[UNSET]
    const yaml = yamlWithAacs(UNSET)
    let err: Error | null = null
    try {
      RuntimeBuilder.fromYamlStrings([yaml]).build()
    } catch (e) {
      err = e as Error
    }
    expect(err).not.toBeNull()
    const msg = String(err!.message ?? err)
    expect(msg).toContain('aacs_default')
    expect(msg).toContain(UNSET)
    expect(msg).toContain('aacs_check')
    expect(msg).toContain('classifier_wiring_missing')
  })

  it('build succeeds when the api_key_env is set', () => {
    process.env[SET] = 'sk-test-credential-not-real'
    const yaml = yamlWithAacs(SET)
    const builder = RuntimeBuilder.fromYamlStrings([yaml])
    const runtime = builder.build()
    expect(runtime).toBeDefined()
  })

  it('build throws when the YAML references a configurations entry that does not exist', () => {
    const yaml = `metadata:
  name: "test"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["pass"]
  forbidden: ["fail"]
post_tool_validation:
  guard_policies:
    - name: "ghost_check"
      evaluate_when:
        - classifier:
            configuration: "not_defined_anywhere"
          reason: "classifier flagged"
`
    let err: Error | null = null
    try {
      RuntimeBuilder.fromYamlStrings([yaml]).build()
    } catch (e) {
      err = e as Error
    }
    expect(err).not.toBeNull()
    const msg = String(err!.message ?? err)
    expect(msg).toContain('not_defined_anywhere')
    expect(msg).toContain('ghost_check')
    expect(msg).toContain('classifier_wiring_missing')
  })
})
