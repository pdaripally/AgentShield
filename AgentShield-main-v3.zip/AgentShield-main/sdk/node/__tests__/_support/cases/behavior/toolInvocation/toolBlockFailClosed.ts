
import { describe, expect, it, vi } from 'vitest'
import * as path from 'node:path'

import { DynamicStructuredTool } from '@langchain/core/tools'

import {
  RuntimeBuilder,
  Shield,
  AgentShieldBlockedError,
} from '../../../../../index.js'
import '../../../../../adapters/langchain.js'
import {
  OPENAI_BUNDLE,
  _setAgentsModuleForTesting,
  _setAgentsOpenaiModuleForTesting,
  type AgentsLikeModule,
  type AgentsOpenaiLikeModule,
} from '../../../../../adapters/openai_agents.js'
import { LANGCHAIN_BUNDLE } from '../../../../../adapters/langchain.js'

const FIXTURE = path.resolve(
  __dirname,
  '..',
  '..',
  '..',
  '..',
  '..',
  '..',
  '..',
  'tests',
  'fixtures',
  'contract',
  'pending_resolution.guardrails.yaml',
)

function _newShield(bundle: unknown): Shield {
  const rt = RuntimeBuilder.fromYaml(FIXTURE).build()
 // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return new Shield(rt, { bundle: bundle as any })
}

function _makeStubClient(): unknown {
  return { _stub: true }
}

function _makeFakeAgentsOpenai(): AgentsOpenaiLikeModule {
  return {
    OpenAIChatCompletionsModel: function (this: unknown, _opts: unknown) {
      void _opts
    } as unknown as new (opts: unknown) => unknown,
    setDefaultOpenAIClient: vi.fn(),
  } as unknown as AgentsOpenaiLikeModule
}

interface FakeAgent {
  name: string
  tools: Array<{ name: string; execute?: (i: unknown) => Promise<unknown> }>
}

function _makeFakeAgents(toolName: string, finalIfReached: string): {
  agentsMod: AgentsLikeModule
  toolObservations: string[]
} {
  const toolObservations: string[] = []
  const agentsMod: AgentsLikeModule = {
    Agent: function (this: FakeAgent, opts: unknown) {
      Object.assign(this, opts as object)
    } as unknown as new (opts: Record<string, unknown>) => unknown,
    tool: (opts: Record<string, unknown>) => ({
      type: 'function',
      name: opts.name as string,
      description: opts.description as string,
      parameters: opts.parameters,
      strict: !!opts.strict,
      execute: opts.execute as (i: unknown) => Promise<unknown>,
    }),
    run: vi.fn(
      async (agent: FakeAgent, _input: string, _opts?: Record<string, unknown>) => {
        void _input
        void _opts
        const t = agent.tools.find((x) => x.name === toolName)
        if (!t || typeof t.execute !== 'function') {
          return { finalOutput: finalIfReached }
        }
        const out = await t.execute({ to: 'alice@example.com', subject: 'Hi' })
        toolObservations.push(typeof out === 'string' ? out : JSON.stringify(out))
        return { finalOutput: finalIfReached }
      },
    ),
  }
  return { agentsMod, toolObservations }
}

describe('OpenAI Agents adapter halts on tool block', () => {
  it('runOpenaiAgent returns the canonical block message and discards LLM fallback narrative', async () => {
    const shield = _newShield(OPENAI_BUNDLE)
    const { agentsMod, toolObservations } = _makeFakeAgents(
      'send_email',
      'Email sent successfully ✅',
    )
    _setAgentsModuleForTesting(agentsMod)
    _setAgentsOpenaiModuleForTesting(_makeFakeAgentsOpenai())
    try {
      const result = await (shield as unknown as {
        runOpenaiAgent: (opts: Record<string, unknown>) => Promise<string>
      }).runOpenaiAgent({
        model: 'gpt-4o-mini',
        client: _makeStubClient(),
        tools: [{ type: 'function', function: { name: 'send_email' } }],
        messages: [{ role: 'user', content: 'send email' }],
        dispatchToolCall: async () => 'should-never-run',
      })

      expect(result).toMatch(/\[GUARDRAIL/)
      expect(result).not.toContain('Email sent successfully')
      expect(toolObservations).toEqual([])
    } finally {
      _setAgentsModuleForTesting(null)
      _setAgentsOpenaiModuleForTesting(null)
    }
  })

  it('runOpenaiAgentStreamed yields a single { type: blocked } emission on tool block', async () => {
    const shield = _newShield(OPENAI_BUNDLE)
    const agentsMod: AgentsLikeModule = {
      Agent: function (this: FakeAgent, opts: unknown) {
        Object.assign(this, opts as object)
      } as unknown as new (opts: Record<string, unknown>) => unknown,
      tool: (opts: Record<string, unknown>) => ({
        type: 'function',
        name: opts.name as string,
        description: opts.description as string,
        parameters: opts.parameters,
        strict: !!opts.strict,
        execute: opts.execute as (i: unknown) => Promise<unknown>,
      }),
      run: vi.fn(
        async (
          agent: FakeAgent,
          _input: string,
          opts?: Record<string, unknown>,
        ): Promise<unknown> => {
          void _input
          if (!opts?.stream) {
            return { finalOutput: 'irrelevant' }
          }
          const t = agent.tools.find((x) => x.name === 'send_email')
          async function* iter(): AsyncGenerator<unknown, void, void> {
            await (t!.execute as (i: unknown) => Promise<unknown>)({
              to: 'a@example.com',
            })
            yield {} as unknown
          }
          return Object.assign(iter(), { completed: Promise.resolve() })
        },
      ),
    }
    _setAgentsModuleForTesting(agentsMod)
    _setAgentsOpenaiModuleForTesting(_makeFakeAgentsOpenai())
    try {
      const emissions: Array<{ type: string; message?: string; text?: string }> = []
      const gen = (shield as unknown as {
        runOpenaiAgentStreamed: (
          opts: Record<string, unknown>,
        ) => AsyncGenerator<
          { type: string; message?: string; text?: string },
          void,
          void
        >
      }).runOpenaiAgentStreamed({
        model: 'gpt-4o-mini',
        client: _makeStubClient(),
        tools: [{ type: 'function', function: { name: 'send_email' } }],
        messages: [{ role: 'user', content: 'send email' }],
        dispatchToolCall: async () => 'should-never-run',
      })
      for await (const e of gen) emissions.push(e)
      expect(emissions.length).toBe(1)
      expect(emissions[0].type).toBe('blocked')
      expect(emissions[0].message).toMatch(/GUARDRAIL/)
    } finally {
      _setAgentsModuleForTesting(null)
      _setAgentsOpenaiModuleForTesting(null)
    }
  })

  it('protectOpenaiTools (Pattern B) throws AgentShieldBlockedError so customer loops fail-closed', async () => {
    const shield = _newShield(OPENAI_BUNDLE)
    const guarded = (shield as unknown as {
      protectOpenaiTools: (opts: {
        dispatchToolCall: (
          name: string,
          args: Record<string, unknown>,
        ) => Promise<string>
        allowUnguarded?: boolean
      }) => (name: string, args: Record<string, unknown>) => Promise<string>
    }).protectOpenaiTools({
      dispatchToolCall: async () => 'should-never-run',
      allowUnguarded: true,
    })
    let caught: unknown = null
    try {
      await guarded('send_email', { to: 'a@example.com' })
    } catch (err) {
      caught = err
    }
    expect(caught).toBeInstanceOf(AgentShieldBlockedError)
    const blocked = caught as AgentShieldBlockedError
    expect(blocked.toolName).toBe('send_email')
    expect(blocked.stage).toBe('tool_call')
    expect(blocked.blockMessage).toMatch(/GUARDRAIL/)
    expect(blocked.pendingResolution).toBeNull()
  })
})

describe('LangChain adapter halts on tool block', () => {
  it('protectTools-wrapped DynamicStructuredTool throws AgentShieldBlockedError out of .invoke', async () => {
    const shield = _newShield(LANGCHAIN_BUNDLE)

    let toolCalled = false
    const tool = new DynamicStructuredTool({
      name: 'send_email',
      description: 'sends an email',
      schema: {
        type: 'object',
        properties: {
          to: { type: 'string' },
          subject: { type: 'string' },
        },
      } as unknown as object,
      func: async () => {
        toolCalled = true
        return 'sent ✅ (the bypass — should NEVER appear)'
      },
    })

    const wrapped = (
      await shield.protectTools<DynamicStructuredTool, DynamicStructuredTool>(
        [tool],
        { allowUnguarded: true },
      )
    )[0] as DynamicStructuredTool

    let caught: unknown = null
    try {
      await wrapped.invoke({ to: 'a@example.com', subject: 'Hi' })
    } catch (err) {
      caught = err
    }
    expect(toolCalled).toBe(false)
    expect(caught).toBeInstanceOf(AgentShieldBlockedError)
    const blocked = caught as AgentShieldBlockedError
    expect(blocked.toolName).toBe('send_email')
    expect(blocked.stage).toBe('tool_call')
    expect(blocked.blockMessage).toMatch(/GUARDRAIL/)
    expect(blocked.blockMessage).not.toContain('sent ✅')
  })
})

describe('Pattern A — Shield.guard(agent).invoke returns canonical block on tool throw', () => {
  it('GuardedRunner converts AgentShieldBlockedError from inside the boundary into a canonical block string', async () => {
    const shield = _newShield({
      name: '_canonical',
      llmCallerFactory: {
 // eslint-disable-next-line @typescript-eslint/no-explicit-any
        makeCaller: () => (() => '') as any,
      },
      agentBoundary: {
        run: async (_agent: unknown, _input: string | undefined) => {
          void _agent
          void _input
          throw new AgentShieldBlockedError({
            toolName: 'send_email',
            stage: 'tool_call',
            message: '[GUARDRAIL BLOCK] denied for test',
          })
        },
        extractOutput: (r: unknown) => (typeof r === 'string' ? r : ''),
        applyRedaction: (_r: unknown, redacted: string) => redacted,
        makeBlocked: (message: string) => message,
      },
      capabilities: { framework: '_canonical' },
    })

    const guarded = (
      shield as unknown as {
        guard: <T>(agent: T) => { run: (input?: string) => Promise<unknown> }
      }
    ).guard({ _fake: true })

    const result = await guarded.run('please send the email')
    expect(typeof result).toBe('string')
    expect(String(result)).toMatch(/GUARDRAIL/)
  })
})
