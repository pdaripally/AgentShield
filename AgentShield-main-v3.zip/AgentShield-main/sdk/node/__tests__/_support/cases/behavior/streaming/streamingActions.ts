
import { describe, it, expect } from 'vitest'

import {
  StreamingReplaceNotSupportedError,
  _OrchestratorStreamingValidatorForTests,
  type StreamingPushResult,
  type StreamingGuardLike,
  type StreamingMode,
  type AgentBoundary,
  type StreamChunkResult,
} from '../../../../../index.js'

import * as langchainAdapter from '../../../../../adapters/langchain.js'
const LANGCHAIN_BUNDLE = (langchainAdapter as { LANGCHAIN_BUNDLE: { streamingAdapter: any } })
  .LANGCHAIN_BUNDLE


class FakeNativeGuard implements StreamingGuardLike {
  private readonly _pushResults: StreamChunkResult[]
  private readonly _finishResult: StreamChunkResult
  private readonly _mode: StreamingMode
  private _idx = 0
  readonly chunksReceived: string[] = []
  ended = false

  constructor(opts: {
    pushResults: StreamChunkResult[]
    finishResult?: StreamChunkResult
    mode?: StreamingMode
  }) {
    this._pushResults = opts.pushResults
    this._finishResult =
      opts.finishResult ?? { action: 'pass', payload: '', reason: null }
    this._mode = opts.mode ?? 'per_chunk'
  }

  get mode(): StreamingMode {
    return this._mode
  }

  async addChunk(chunk: string): Promise<StreamChunkResult> {
    this.chunksReceived.push(chunk)
    if (this._idx < this._pushResults.length) {
      const r = this._pushResults[this._idx]
      this._idx += 1
      return r
    }
    return { action: 'pass', payload: '', reason: null }
  }

  async finish(): Promise<StreamChunkResult> {
    this.ended = true
    return this._finishResult
  }
}

const FAKE_BOUNDARY: AgentBoundary = {
  run: async () => undefined as unknown,
  extractOutput: () => null,
  applyRedaction: (chunk: unknown, text: string | null | undefined) =>
    ({ chunk, text }) as unknown,
  makeBlocked: (message: string) => ({ blocked: message }) as unknown,
}


describe('StreamingPushResult action field ', () => {
  it('surfaces action: pass on the public type', () => {
    const r: StreamingPushResult = {
      action: 'pass',
      payload: 'hello',
      stopped: false,
      reason: null,
    }
    expect(r.action).toBe('pass')
    expect(r.payload).toBe('hello')
  })

  it('surfaces action: replace on the public type', () => {
    const r: StreamingPushResult = {
      action: 'replace',
      payload: 'SSN [SSN]',
      stopped: false,
      reason: 'ssn redaction',
    }
    expect(r.action).toBe('replace')
    expect(r.stopped).toBe(false)
  })

  it('surfaces action: stop with stopped flag for backward-compat', () => {
    const r: StreamingPushResult = {
      action: 'stop',
      payload: '',
      stopped: true,
      reason: 'policy',
    }
    expect(r.action).toBe('stop')
    expect(r.stopped).toBe(true)
  })
})


describe('_OrchestratorStreamingValidator propagates action ', () => {
  it('push pass propagates action: pass', async () => {
    const guard = new FakeNativeGuard({
      pushResults: [{ action: 'pass', payload: 'hi', reason: null }],
    })
    const v = new _OrchestratorStreamingValidatorForTests(guard, FAKE_BOUNDARY)
    const r = await v.push('hi')
    expect(r.action).toBe('pass')
    expect(r.payload).toBe('hi')
    expect(r.stopped).toBe(false)
    expect(r.reason).toBeNull()
  })

  it('push replace propagates action: replace (canonical reproducer)', async () => {
    const guard = new FakeNativeGuard({
      pushResults: [
        { action: 'replace', payload: 'SSN [SSN]', reason: 'ssn' },
      ],
    })
    const v = new _OrchestratorStreamingValidatorForTests(guard, FAKE_BOUNDARY)
    const r = await v.push('9')
    expect(r.action).toBe('replace')
    expect(r.payload).toBe('SSN [SSN]')
    expect(r.stopped).toBe(false)
    expect(r.reason).toBe('ssn')
  })

  it('push stop propagates action: stop and sets stopped=true', async () => {
    const guard = new FakeNativeGuard({
      pushResults: [{ action: 'stop', payload: '', reason: 'blocked' }],
    })
    const v = new _OrchestratorStreamingValidatorForTests(guard, FAKE_BOUNDARY)
    const r = await v.push('x')
    expect(r.action).toBe('stop')
    expect(r.stopped).toBe(true)
    expect(r.reason).toBe('blocked')
  })

  it('finish propagates action: replace', async () => {
    const guard = new FakeNativeGuard({
      pushResults: [],
      finishResult: {
        action: 'replace',
        payload: '[REDACTED]',
        reason: 'tail rewrite',
      },
    })
    const v = new _OrchestratorStreamingValidatorForTests(guard, FAKE_BOUNDARY)
    const r = await v.finish()
    expect(r.action).toBe('replace')
    expect(r.payload).toBe('[REDACTED]')
    expect(r.reason).toBe('tail rewrite')
  })

  it('finish propagates action: pass with empty payload', async () => {
    const guard = new FakeNativeGuard({
      pushResults: [],
      finishResult: { action: 'pass', payload: '', reason: null },
    })
    const v = new _OrchestratorStreamingValidatorForTests(guard, FAKE_BOUNDARY)
    const r = await v.finish()
    expect(r.action).toBe('pass')
    expect(r.stopped).toBe(false)
  })

  it('normalises unknown / missing action to pass (defensive)', async () => {
    const guard = new FakeNativeGuard({
      pushResults: [
        { action: undefined as unknown as 'pass', payload: 'ok', reason: null },
      ],
    })
    const v = new _OrchestratorStreamingValidatorForTests(guard, FAKE_BOUNDARY)
    const r = await v.push('x')
    expect(r.action).toBe('pass')
    expect(r.payload).toBe('ok')
  })
})


describe('StreamingReplaceNotSupportedError exception surface', () => {
  it('is importable from the package root', () => {
    expect(typeof StreamingReplaceNotSupportedError).toBe('function')
  })

  it('extends Error so existing catch (err) handlers keep working', () => {
    const err = new StreamingReplaceNotSupportedError({ adapter: 'X', reason: 'y' })
    expect(err).toBeInstanceOf(Error)
    expect(err.name).toBe('StreamingReplaceNotSupportedError')
    expect(err.adapter).toBe('X')
    expect(err.reason).toBe('y')
    expect(err.message).toMatch(/on_complete/)
    expect(err.message).toMatch(/replace/)
  })

  it('survives instanceof across an explicit super-call chain', () => {
    try {
      throw new StreamingReplaceNotSupportedError({ adapter: 'A' })
    } catch (e) {
      expect(e instanceof StreamingReplaceNotSupportedError).toBe(true)
    }
  })
})


describe('LangChain.js streaming adapter ', () => {

  function makeFakeAgent(chunks: unknown[]) {
    return {
      async stream(_input: unknown, _config: unknown) {
        async function* iter() {
          for (const c of chunks) yield c
        }
        return iter()
      },
    }
  }

  function makeStubValidator(opts: {
    mode: 'on_complete' | 'per_chunk' | 'windowed'
    pushResults: StreamingPushResult[]
    finishResult?: StreamingPushResult
  }) {
    let idx = 0
    return {
      get mode() {
        return opts.mode
      },
      async push(_text: string): Promise<StreamingPushResult> {
        if (idx < opts.pushResults.length) {
          const r = opts.pushResults[idx]
          idx += 1
          return r
        }
        return { action: 'pass', payload: '', stopped: false, reason: null }
      },
      async finish(): Promise<StreamingPushResult> {
        return (
          opts.finishResult ?? {
            action: 'pass',
            payload: '',
            stopped: false,
            reason: null,
          }
        )
      },
      makeBlocked: (msg: string) => ({ blocked: msg }),
      applyRedaction: (chunk: unknown, text: string) => ({ chunk, text }),
    }
  }

  it('per_chunk + replace: throws StreamingReplaceNotSupportedError (canonical SSN repro)', async () => {
    const adapter = LANGCHAIN_BUNDLE.streamingAdapter
    const chunks = Array.from('SSN 123-45-6789').map((ch) => ({
      messages: [{ content: ch }],
    }))
    const pushResults: StreamingPushResult[] = chunks.slice(0, -1).map(() => ({
      action: 'pass',
      payload: '',
      stopped: false,
      reason: null,
    }))
    pushResults.push({
      action: 'replace',
      payload: 'SSN [SSN]',
      stopped: false,
      reason: 'Output contained an SSN.',
    })

    const agent = makeFakeAgent(chunks)
    const validator = makeStubValidator({ mode: 'per_chunk', pushResults })

    const emissions: unknown[] = []
    let caught: unknown = null
    try {
      for await (const e of adapter.stream(agent, '', validator, {})) {
        emissions.push(e)
      }
    } catch (err) {
      caught = err
    }
    expect(caught).toBeInstanceOf(StreamingReplaceNotSupportedError)
    const exc = caught as StreamingReplaceNotSupportedError
    expect(exc.adapter).toBe('LangChain.js')
    for (const em of emissions) {
      const text =
        (em as { text?: unknown }).text ??
        (em as { messages?: Array<{ content?: unknown }> }).messages?.[0]?.content
      const s = typeof text === 'string' ? text : ''
      expect(s.includes('SSN [SSN]') && /\d{3}-\d{2}-\d{4}/.test(s)).toBe(false)
    }
    expect(exc.reason).toBe('Output contained an SSN.')
    expect(exc.message).toContain('SSN')
  })

  it('per_chunk + replace at finish: throws', async () => {
    const adapter = LANGCHAIN_BUNDLE.streamingAdapter
    const chunks = [{ messages: [{ content: 'hello' }] }]
    const agent = makeFakeAgent(chunks)
    const validator = makeStubValidator({
      mode: 'per_chunk',
      pushResults: [{ action: 'pass', payload: 'hello', stopped: false, reason: null }],
      finishResult: {
        action: 'replace',
        payload: '[REDACTED]',
        stopped: false,
        reason: 'tail rewrite',
      },
    })
    await expect(async () => {
      for await (const _ of adapter.stream(agent, '', validator, {})) {
      }
    }).rejects.toBeInstanceOf(StreamingReplaceNotSupportedError)
  })

  it('on_complete + replace at finish: safe — emits ONE redacted chunk only', async () => {
    const adapter = LANGCHAIN_BUNDLE.streamingAdapter
    const chunks = Array.from('SSN 123-45-6789').map((ch) => ({
      messages: [{ content: ch }],
    }))
    const validator = makeStubValidator({
      mode: 'on_complete',
      pushResults: chunks.map(() => ({
        action: 'pass',
        payload: '',
        stopped: false,
        reason: null,
      })),
      finishResult: {
        action: 'replace',
        payload: 'SSN [SSN]',
        stopped: false,
        reason: 'ssn',
      },
    })
    const emissions: unknown[] = []
    for await (const e of adapter.stream(makeFakeAgent(chunks), '', validator, {})) {
      emissions.push(e)
    }
    expect(emissions.length).toBe(1)
    expect((emissions[0] as { text: string }).text).toBe('SSN [SSN]')
  })

  it('per_chunk + stop: still terminates with makeBlocked (backward-compat preserved)', async () => {
    const adapter = LANGCHAIN_BUNDLE.streamingAdapter
    const chunks = [{ messages: [{ content: 'bad' }] }]
    const validator = makeStubValidator({
      mode: 'per_chunk',
      pushResults: [
        { action: 'stop', payload: '', stopped: true, reason: 'policy' },
      ],
    })
    const emissions: unknown[] = []
    for await (const e of adapter.stream(makeFakeAgent(chunks), '', validator, {})) {
      emissions.push(e)
    }
    expect(emissions.length).toBe(1)
    expect((emissions[0] as { blocked: string }).blocked).toBe('policy')
  })

  it('per_chunk + pass-only: no error, emits validated payloads (no regression)', async () => {
    const adapter = LANGCHAIN_BUNDLE.streamingAdapter
    const chunks = [
      { messages: [{ content: 'alpha ' }] },
      { messages: [{ content: 'beta' }] },
    ]
    const validator = makeStubValidator({
      mode: 'per_chunk',
      pushResults: [
        { action: 'pass', payload: 'alpha ', stopped: false, reason: null },
        { action: 'pass', payload: 'beta', stopped: false, reason: null },
      ],
    })
    const emissions: unknown[] = []
    for await (const e of adapter.stream(makeFakeAgent(chunks), '', validator, {})) {
      emissions.push(e)
    }
    expect(emissions.length).toBe(2)
    expect((emissions[0] as { text: string }).text).toBe('alpha ')
    expect((emissions[1] as { text: string }).text).toBe('beta')
  })
})
