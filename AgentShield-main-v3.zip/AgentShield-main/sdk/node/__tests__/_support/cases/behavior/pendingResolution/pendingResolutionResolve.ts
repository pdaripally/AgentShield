
import { describe, expect, it } from 'vitest'
import * as path from 'node:path'
import {
  RuntimeBuilder,
  Shield,
  AgentShieldBlockedError,
  type PendingResolutionLike,
} from '../../../../../index.js'
import { OPENAI_BUNDLE } from '../../../../../adapters/openai_agents.js'

const FIXTURE = path.resolve(
  __dirname,
  '..',
  '..',
  '..',
  '..',
  '..',
  '..',
  '..',
  'tests',
  'fixtures',
  'contract',
  'pending_resolution.guardrails.yaml',
)

function _newShield(): Shield {
  const rt = RuntimeBuilder.fromYaml(FIXTURE).build()
  return new Shield(rt, { bundle: OPENAI_BUNDLE })
}

describe('Shield.resolvePending — Pattern A resume API', () => {
  it('exists on the base class and is async', () => {
    const shield = _newShield()
    expect(typeof shield.resolvePending).toBe('function')
    const ret = shield.resolvePending('allow', {
      setVariables: { send_email_approved: true },
    })
    expect(ret).toBeInstanceOf(Promise)
    ret.catch(() => {})
  })

  it("decision='allow' resumes a kind:human block on the SAME session", async () => {
    const shield = _newShield()
    let dispatched = false
    let firstBlocked = false
    let secondOk = false

    const session = shield.runtime.newSession()
    await shield.run(
      async () => {
        const blocked = await shield.protectTool(
          'send_email',
          { to: 'alice@example.com', subject: 'Hi' },
          async () => {
            dispatched = true
            return 'should-not-run'
          },
        )
        firstBlocked = blocked.blocked
        expect(dispatched).toBe(false)

        expect(shield.lastPendingResolution()).toBeNull()

        await shield.resolvePending('allow', {
          setVariables: { send_email_approved: true },
        })

        const ok = await shield.protectTool(
          'send_email',
          { to: 'alice@example.com', subject: 'Hi' },
          async () => {
            dispatched = true
            return 'sent'
          },
        )
        secondOk = !ok.blocked
      },
      { session, userInput: 'send the email' },
    )
    expect(firstBlocked).toBe(true)
    expect(secondOk).toBe(true)
    expect(dispatched).toBe(true)
  })

  it("decision='deny' keeps the gate blocked with the policy reason", async () => {
    const shield = _newShield()
    let firstBlocked = false
    let secondBlocked = false
    let secondOutput = ''

    const session = shield.runtime.newSession()
    await shield.run(
      async () => {
        const first = await shield.protectTool(
          'send_email',
          { to: 'alice@example.com', subject: 'Hi' },
          async () => 'should-not-run',
        )
        firstBlocked = first.blocked

        expect(shield.lastPendingResolution()).toBeNull()

        await shield.resolvePending('deny', { setVariables: {} })

        const second = await shield.protectTool(
          'send_email',
          { to: 'alice@example.com', subject: 'Hi' },
          async () => 'should-not-run',
        )
        secondBlocked = second.blocked
        secondOutput = String(second.output)
      },
      { session, userInput: 'send the email' },
    )
    expect(firstBlocked).toBe(true)
    expect(secondBlocked).toBe(true)
    expect(secondOutput).toContain('GUARDRAIL')
  })

  it('explicit value= overrides the boolean default', async () => {
    const shield = _newShield()
    let ok = false
    const session = shield.runtime.newSession()
    await shield.run(
      async () => {
        const first = await shield.protectTool(
          'send_email',
          { to: 'alice@example.com', subject: 'Hi' },
          async () => 'should-not-run',
        )
        expect(first.blocked).toBe(true)

        expect(shield.lastPendingResolution()).toBeNull()

        await shield.resolvePending('allow', {
          value: true,
          setVariables: { send_email_approved: true },
        })

        const second = await shield.protectTool(
          'send_email',
          { to: 'alice@example.com', subject: 'Hi' },
          async () => 'sent',
        )
        ok = !second.blocked
      },
      { session, userInput: 'send the email' },
    )
    expect(ok).toBe(true)
  })

  it('setVariables={} writes the explicit map (bypasses latched envelope)', async () => {
    const shield = _newShield()
    let ok = false
    const session = shield.runtime.newSession()
    await shield.run(
      async () => {
        const first = await shield.protectTool(
          'send_email',
          { to: 'alice@example.com', subject: 'Hi' },
          async () => 'should-not-run',
        )
        expect(first.blocked).toBe(true)
        shield.lastPendingResolution()

        await shield.resolvePending('allow', {
          setVariables: { send_email_approved: true },
        })

        const second = await shield.protectTool(
          'send_email',
          { to: 'alice@example.com', subject: 'Hi' },
          async () => 'sent',
        )
        ok = !second.blocked
      },
      { session, userInput: 'send the email' },
    )
    expect(ok).toBe(true)
  })

  it('uses the captured session when called from outside a guarded turn (Pattern A timeline)', async () => {
    const shield = _newShield()
    const session = shield.runtime.newSession()

    let firstBlocked = false
    await shield.run(
      async () => {
        const first = await shield.protectTool(
          'send_email',
          { to: 'alice@example.com', subject: 'Hi' },
          async () => 'should-not-run',
        )
        firstBlocked = first.blocked
      },
      { session, userInput: 'send the email' },
    )
    expect(firstBlocked).toBe(true)

    const { currentSession } = await import('../../../../../shield.js')
    expect(currentSession()).toBeNull()

    ;(shield as unknown as { _lastPendingSession: unknown })._lastPendingSession =
      session

    expect(shield.lastPendingResolution()).toBeNull()
    await shield.resolvePending('allow', {
      setVariables: { send_email_approved: true },
    })

    let secondOk = false
    await shield.run(
      async () => {
        const second = await shield.protectTool(
          'send_email',
          { to: 'alice@example.com', subject: 'Hi' },
          async () => 'sent',
        )
        secondOk = !second.blocked
      },
      { session, userInput: 'send the email again' },
    )
    expect(secondOk).toBe(true)
  })

  it("rejects unknown decision strings with TypeError", async () => {
    const shield = _newShield()
    ;(shield as unknown as { _lastPendingSession: unknown })._lastPendingSession =
      shield.runtime.newSession()
    ;(shield as unknown as {
      _lastPendingResolution: PendingResolutionLike | null
    })._lastPendingResolution = {
      tool: 'agent_shield.ask_human',
      variable: 'send_email_approved',
      prompt: '?',
      requestId: 'req-x',
      kind: 'human',
    }
    await expect(
      shield.resolvePending('maybe' as unknown as 'allow'),
    ).rejects.toBeInstanceOf(TypeError)
  })

  it('throws when no session is available', async () => {
    const shield = _newShield()
    ;(shield as unknown as { _lastPendingSession: unknown })._lastPendingSession =
      null
    ;(shield as unknown as {
      _lastPendingResolution: PendingResolutionLike | null
    })._lastPendingResolution = null
    await expect(shield.resolvePending('allow')).rejects.toThrow(
      /no active session/i,
    )
  })

  it('throws when no latch and no setVariables provided', async () => {
    const shield = _newShield()
    const session = shield.runtime.newSession()
    ;(shield as unknown as { _lastPendingSession: unknown })._lastPendingSession =
      session
    ;(shield as unknown as {
      _lastPendingResolution: PendingResolutionLike | null
    })._lastPendingResolution = null
    await expect(shield.resolvePending('allow')).rejects.toThrow(
      /no .*pending_resolution/i,
    )
  })

  it('end-to-end: protectTool block → resolvePending → guarded returns AgentShieldBlockedError disappears', async () => {
    const shield = _newShield()

    const session = shield.runtime.newSession()

    let firstBlocked = false
    let secondOk = false

    await shield.run(
      async () => {
        const r1 = await shield.protectTool(
          'send_email',
          { to: 'alice@example.com', subject: 'Hi' },
          async () => 'should-not-run',
        )
        firstBlocked = r1.blocked
        expect(shield.lastPendingResolution()).toBeNull()

        await shield.resolvePending('allow', {
          setVariables: { send_email_approved: true },
        })

        const r2 = await shield.protectTool(
          'send_email',
          { to: 'alice@example.com', subject: 'Hi' },
          async () => 'sent',
        )
        secondOk = !r2.blocked
      },
      { session, userInput: 'send the email' },
    )

    expect(firstBlocked).toBe(true)
    expect(secondOk).toBe(true)
  })
})
