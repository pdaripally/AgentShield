import { describe, expect, it } from 'vitest'
import * as path from 'node:path'
import { RuntimeBuilder, Shield } from '../../../../../index.js'
import { OPENAI_BUNDLE } from '../../../../../adapters/openai_agents.js'

const FIXTURE = path.resolve(
  __dirname,
  '..',
  '..',
  '..',
  '..',
  '..',
  '..',
  '..',
  'tests',
  'fixtures',
  'contract',
  'pending_resolution.guardrails.yaml',
)

function _newShieldWithHuman(
  decision: 'allow' | 'deny',
  value: boolean | undefined = true,
): Shield {
  const rt = RuntimeBuilder.fromYaml(FIXTURE)
    .registerHumanResolver(() =>
      decision === 'allow'
        ? { decision: 'allow', value }
        : { decision: 'deny', reason: 'user denied' },
    )
    .build()
  return new Shield(rt, { bundle: OPENAI_BUNDLE })
}

describe('runtime-bound human resolver provenance', () => {
  it("'allow' stamps @sourceKind == 'human'", async () => {
    const shield = _newShieldWithHuman('allow', true)
    const session = shield.runtime.newSession()

    await shield.run(
      async () => {
        const r1 = await shield.protectTool(
          'send_email',
          { to: 'alice@example.com', subject: 'Hi' },
          async () => 'sent',
        )
        expect(r1.blocked).toBe(false)
      },
      { session, userInput: 'send the email' },
    )

    const state = session.readVariable('send_email_approved')
    expect(state).not.toBeNull()
    expect(state!.status).toBe('resolved')
    expect(state!.value).toBe(true)
    expect(state!.sourceKind).toBe('human')
    expect(state!.setBy).toBe('human:send_email_approved')
    expect(shield.lastPendingResolution()).toBeNull()
  })

  it("'deny' marks the variable denied AND stamps @sourceKind == 'human'", async () => {
    const shield = _newShieldWithHuman('deny')
    const session = shield.runtime.newSession()

    await shield.run(
      async () => {
        const r1 = await shield.protectTool(
          'send_email',
          { to: 'alice@example.com', subject: 'Hi' },
          async () => 'should-not-run',
        )
        expect(r1.blocked).toBe(true)
      },
      { session, userInput: 'send the email' },
    )

    const state = session.readVariable('send_email_approved')
    expect(state).not.toBeNull()
    expect(state!.status).toBe('denied')
    expect(state!.sourceKind).toBe('human')
    expect(shield.lastPendingResolution()).toBeNull()
  })

  it('resolvePending still requires explicit setVariables when no pending_resolution is latched', async () => {
    const rt = RuntimeBuilder.fromYaml(FIXTURE).build()
    const shield = new Shield(rt, { bundle: OPENAI_BUNDLE })
    const session = shield.runtime.newSession()
    ;(shield as unknown as { _lastPendingSession: unknown })._lastPendingSession =
      session
    await expect(shield.resolvePending('allow')).rejects.toThrow(
      /pending_resolution/i,
    )

    await shield.resolvePending('allow', {
      setVariables: { send_email_approved: true },
    })
    expect(session.readVariable('send_email_approved')?.value).toBe(true)
  })
})
