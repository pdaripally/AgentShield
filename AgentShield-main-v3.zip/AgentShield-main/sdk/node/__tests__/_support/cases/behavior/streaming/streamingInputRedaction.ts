
import { describe, it, expect } from 'vitest'
import * as path from 'path'

import { GuardedRunner, RuntimeBuilder } from '../../../../../index.js'

const FIXTURES = path.resolve(__dirname, '../../../../../../../tests/fixtures/smoke')
const INPUT_REDACT = path.join(FIXTURES, 'input-redact.guardrails.yaml')

function makeStreamingAdapter() {
  const seenInputs: Array<string | undefined> = []
  return {
    seenInputs,
    stream: async function* (_agent: unknown, input: string | undefined, validator: any) {
      seenInputs.push(input)
      const text = `stream saw: ${input ?? ''}`
      const r = await validator.push(text)
      if (r.stopped) {
        yield validator.makeBlocked(r.reason ?? 'blocked')
        return
      }
      const tail = await validator.finish()
      if (tail.stopped) {
        yield validator.makeBlocked(tail.reason ?? 'blocked')
        return
      }
      yield { output: r.payload ?? text }
    },
  }
}

function makeBoundary() {
  return {
    run: async (_agent: unknown, _input: string | undefined) => ({}),
    extractOutput: () => '',
    applyRedaction: (r: unknown) => r,
    makeBlocked: (m: string) => ({ blocked: m }),
  }
}

describe('Stage 1 input redaction propagates to runStreamed', () => {
  it('streaming + redact: agent sees the redacted subject', async () => {
    const runtime = RuntimeBuilder.fromYaml(INPUT_REDACT).build()
    const streaming = makeStreamingAdapter()
    const runner = new GuardedRunner(runtime, {}, makeBoundary(), streaming as any)

    const emissions: any[] = []
    for await (const emission of runner.runStreamed('please process SECRET-ABCD1234 now')) {
      emissions.push(emission)
    }

    expect(streaming.seenInputs.length).toBeGreaterThan(0)
    const forwarded = String(streaming.seenInputs[streaming.seenInputs.length - 1] ?? '')
    expect(forwarded).not.toContain('SECRET-ABCD1234')
    expect(forwarded).toContain('[INPUT REDACTED]')
    for (const e of emissions) {
      expect(JSON.stringify(e)).not.toContain('SECRET-ABCD1234')
    }
  })

  it('streaming + no Stage 1 mutation: agent sees the original input', async () => {
    const minimal = path.join(FIXTURES, 'minimal.guardrails.yaml')
    const runtime = RuntimeBuilder.fromYaml(minimal).build()
    const streaming = makeStreamingAdapter()
    const runner = new GuardedRunner(runtime, {}, makeBoundary(), streaming as any)

    const userText = 'just a normal message'
    const emissions: any[] = []
    for await (const emission of runner.runStreamed(userText)) {
      emissions.push(emission)
    }

    expect(streaming.seenInputs).toEqual([userText])
    expect(emissions.length).toBeGreaterThan(0)
  })

  it('non-streaming + redact still works (regression guard)', async () => {
    const runtime = RuntimeBuilder.fromYaml(INPUT_REDACT).build()
    let seenInput = ''
    const stubBoundary = {
      run: async (_agent: unknown, input: string | undefined) => {
        seenInput = input ?? ''
        return {}
      },
      extractOutput: () => '',
      applyRedaction: (r: unknown) => r,
      makeBlocked: (m: string) => m,
    }
    const runner = new GuardedRunner(runtime, {}, stubBoundary, null)

    await runner.run('hello SECRET-ABCD')

    expect(seenInput).not.toContain('SECRET-ABCD')
    expect(seenInput).toContain('[INPUT REDACTED]')
  })
})
