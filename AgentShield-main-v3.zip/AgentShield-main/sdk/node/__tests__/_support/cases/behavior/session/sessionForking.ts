
import { describe, it, expect, beforeEach } from 'vitest'
import * as path from 'path'

import { Shield, GuardedRunner, ShieldMode, RuntimeBuilder } from '../../../../../index.js'

const FIXTURES = path.resolve(__dirname, '../../../../../../../tests/fixtures/smoke')
const MINIMAL = path.join(FIXTURES, 'minimal.guardrails.yaml')
const INPUT_REDACT = path.join(FIXTURES, 'input-redact.guardrails.yaml')

describe('Shield.withFreshSession', () => {
  beforeEach(() => {
  })

  it('returns a NEW Shield instance', () => {
    const runtime = RuntimeBuilder.fromYaml(MINIMAL).build()
    const original = new Shield(runtime)

    const forked = original.withFreshSession()

    expect(forked).not.toBe(original) // (1)
    expect(forked.runtime).toBe(original.runtime) // (4)
  })

  it('preserves config (mode, on-block, bundle) on the fork', () => {
    const runtime = RuntimeBuilder.fromYaml(MINIMAL).build()
    const original = new Shield(runtime, {
      mode: ShieldMode.MONITOR,
      onBlock: 'raise',
    })

    const forked = original.withFreshSession()

    expect(forked.mode).toBe(ShieldMode.MONITOR)
    expect(forked._onBlock).toBe('raise')
    expect(forked._bundle).toBe(original._bundle)
  })

  it('does NOT mutate the original Shield', () => {
    const runtime = RuntimeBuilder.fromYaml(MINIMAL).build()
    const original = new Shield(runtime)
    const originalRunners = original._guardedRunners
    const originalRuntimeRef = original.runtime

    original.withFreshSession()

    expect(original._guardedRunners).toBe(originalRunners) // (2)
    expect(original.runtime).toBe(originalRuntimeRef)
  })

  it('starts the fork with an EMPTY runner set', () => {
    const runtime = RuntimeBuilder.fromYaml(MINIMAL).build()
    const original = new Shield(runtime)
    original._guardedRunners.add({ fake: 'runner' })

    const forked = original.withFreshSession()

    expect(forked._guardedRunners.size).toBe(0) // (3)
    expect(original._guardedRunners.size).toBe(1) // original untouched
  })

  it('GuardedRunner.withFreshSession returns a NEW runner with a fresh session', () => {
    const runtime = RuntimeBuilder.fromYaml(MINIMAL).build()
    const stubBoundary = {
      run: async () => ({}),
      extractOutput: () => '',
      applyRedaction: (r: unknown) => r,
      makeBlocked: (m: string) => m,
    }
    const original = new GuardedRunner(runtime, {}, stubBoundary, null)
    const originalSession = original._session

    const forked = original.withFreshSession()

    expect(forked).not.toBe(original) // (1)
    expect(forked._session).not.toBe(original._session) // (3)
    expect(forked._runtime).toBe(original._runtime) // (4)
    expect(original._session).toBe(originalSession)
  })

  it('GuardedRunner.run passes Stage 1 mutated input to the boundary', async () => {
    const runtime = RuntimeBuilder.fromYaml(INPUT_REDACT).build()
    let seenInput = ''
    const stubBoundary = {
      run: async (_agent: unknown, input: string | undefined) => {
        seenInput = input ?? ''
        return {}
      },
      extractOutput: () => '',
      applyRedaction: (r: unknown) => r,
      makeBlocked: (m: string) => m,
    }
    const runner = new GuardedRunner(runtime, {}, stubBoundary, null)

    await runner.run('hello SECRET-ABCD')

    expect(seenInput).toBe('hello [INPUT REDACTED]')
  })
})
