
import { describe, expect, it } from 'vitest'
import { RuntimeBuilder } from '../../../../../index.js'

const REDACT_DIGIT_RUN = `
metadata:
  name: "structured-redaction-digit-run"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
  forbidden: []
resources:
  tools:
    - name: "lookup"
      description: "Lookup helper."
      permission: "read_only"
post_tool_validation:
  guard_policies:
    - name: "redact_digits"
      applies_to:
        tools: ["lookup"]
      evaluate_when:
        - pattern: "\\\\d+"
          reason: "Digit run."
      action: "redact"
      replacement: "[D]"
`

const REDACT_SSN = `
metadata:
  name: "structured-redaction-ssn"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
  forbidden: []
resources:
  tools:
    - name: "lookup"
      description: "Lookup helper."
      permission: "read_only"
post_tool_validation:
  guard_policies:
    - name: "redact_ssn"
      applies_to:
        tools: ["lookup"]
      evaluate_when:
        - pattern: "\\\\d{3}-\\\\d{2}-\\\\d{4}"
          reason: "SSN detected."
      action: "redact"
      replacement: "[SSN]"
`

const BLOCK_SSN = `
metadata:
  name: "structured-redaction-block"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
  forbidden: []
resources:
  tools:
    - name: "lookup"
      description: "Lookup helper."
      permission: "read_only"
post_tool_validation:
  guard_policies:
    - name: "block_ssn_unless_approved"
      applies_to:
        tools: ["lookup"]
      evaluate_when:
        - pattern: "\\\\d{3}-\\\\d{2}-\\\\d{4}"
          reason: "SSN detected."
      action: "block"
`

async function runStage4(yaml: string, params: unknown, result: unknown) {
  const rt = RuntimeBuilder.fromYamlStrings([yaml]).build()
  const session = rt.newSession()
  session.beginTurn()
  try {
    const callOutcome = await session.validateToolCall(
      'lookup',
      params,
      'tc-1',
    )
    expect(callOutcome.verdict.allowed).toBe(true)
    expect(callOutcome.admissionId).toBeDefined()
    const out = await session.validateToolOutput(callOutcome.admissionId!, result)
    return out
  } finally {
    session.endTurn()
  }
}

describe('dict tool result round-trips as a dict', () => {
  it('dict with mixed string + number leaves: only strings redacted', async () => {
    const out = await runStage4(
      REDACT_DIGIT_RUN,
      {},
      { ssn: '123-45-6789', n: 42 },
    )
    expect(out.verdict.allowed).toBe(true)
    const recovered = out.result as Record<string, unknown>
    expect(typeof recovered).toBe('object')
    expect(Array.isArray(recovered)).toBe(false)
    expect(recovered.n).toBe(42)
    expect(typeof recovered.n).toBe('number')
    expect(String(recovered.ssn).indexOf('123-45-6789')).toBe(-1)
    expect(String(recovered.ssn).indexOf('[D]')).toBeGreaterThanOrEqual(0)
  })

  it('nested dict redacts only string leaves', async () => {
    const out = await runStage4(
      REDACT_SSN,
      {},
      {
        patient: {
          name: 'Alice',
          ssn: '123-45-6789',
          age: 42,
          active: true,
        },
        trace_id: 'abc-no-ssn',
      },
    )
    const recovered = out.result as Record<string, unknown>
    expect(typeof recovered).toBe('object')
    const patient = recovered.patient as Record<string, unknown>
    expect(typeof patient).toBe('object')
    expect(patient.name).toBe('Alice')
    expect(patient.ssn).toBe('[SSN]')
    expect(patient.age).toBe(42)
    expect(patient.active).toBe(true)
    expect(recovered.trace_id).toBe('abc-no-ssn')
  })
})

describe('list tool result round-trips as an array', () => {
  it('list with string + number elements: only strings redacted', async () => {
    const out = await runStage4(REDACT_DIGIT_RUN, {}, ['abc123', 456])
    const recovered = out.result as unknown[]
    expect(Array.isArray(recovered)).toBe(true)
    expect(recovered.length).toBe(2)
    expect(String(recovered[0]).indexOf('123')).toBe(-1)
    expect(String(recovered[0]).startsWith('abc')).toBe(true)
    expect(recovered[1]).toBe(456)
    expect(typeof recovered[1]).toBe('number')
  })

  it('list of dicts: per-element shape preserved', async () => {
    const out = await runStage4(REDACT_SSN, {}, [
      { name: 'Alice', ssn: '123-45-6789', age: 30 },
      { name: 'Bob', ssn: '987-65-4321', age: 45 },
    ])
    const recovered = out.result as Array<Record<string, unknown>>
    expect(Array.isArray(recovered)).toBe(true)
    expect(recovered.length).toBe(2)
    for (const entry of recovered) {
      expect(typeof entry).toBe('object')
      expect(entry.ssn).toBe('[SSN]')
      expect(typeof entry.age).toBe('number')
    }
  })
})

describe('plain-string Stage-4 path unchanged', () => {
  it('string input returns a redacted string', async () => {
    const out = await runStage4(REDACT_SSN, {}, 'SSN 123-45-6789 here')
    expect(out.verdict.allowed).toBe(true)
    expect(typeof out.result).toBe('string')
    expect(String(out.result).indexOf('123-45-6789')).toBe(-1)
    expect(String(out.result).indexOf('[SSN]')).toBeGreaterThanOrEqual(0)
  })
})

describe('no redaction fired preserves shape', () => {
  it('dict with no PII round-trips byte-equal', async () => {
    const out = await runStage4(REDACT_SSN, {}, {
      name: 'Alice',
      age: 30,
      active: true,
    })
    expect(out.result).toEqual({ name: 'Alice', age: 30, active: true })
  })

  it('list with no PII round-trips byte-equal', async () => {
    const out = await runStage4(REDACT_SSN, {}, ['abc', 123, true])
    expect(out.result).toEqual(['abc', 123, true])
  })
})

describe('keys that contain digits are NOT redacted', () => {
  it('object keys are preserved verbatim even when they match the digit redactor', async () => {
    const out = await runStage4(REDACT_DIGIT_RUN, {}, {
      key_42: 'no digits here',
    })
    const recovered = out.result as Record<string, unknown>
    expect(typeof recovered).toBe('object')
    expect('key_42' in recovered).toBe(true)
    expect(recovered.key_42).toBe('no digits here')
  })
})

describe('structured input that hits a block still blocks', () => {
  it('Stage-4 block fires on structured input', async () => {
    const out = await runStage4(BLOCK_SSN, {}, {
      ssn: '123-45-6789',
      ok: true,
    })
    expect(out.verdict.allowed).toBe(false)
  })
})

describe('empty-string leaf is harmless', () => {
  it('dict with an empty-string field round-trips unchanged', async () => {
    const out = await runStage4(REDACT_SSN, {}, {
      ssn: '',
      label: 'no ssn here',
    })
    const recovered = out.result as Record<string, unknown>
    expect(typeof recovered).toBe('object')
    expect(recovered.ssn).toBe('')
    expect(recovered.label).toBe('no ssn here')
  })
})

describe('non-ASCII strings pass through', () => {
  it('Unicode leaves keep their codepoints (no escaping)', async () => {
    const out = await runStage4(REDACT_SSN, {}, {
      name: 'Café — résumé 漢字 ✓',
      ssn: 'no ssn here',
    })
    const recovered = out.result as Record<string, unknown>
    expect(recovered.name).toBe('Café — résumé 漢字 ✓')
    expect(recovered.ssn).toBe('no ssn here')
  })

  it('Unicode characters surrounding a redacted SSN survive verbatim', async () => {
    const out = await runStage4(REDACT_SSN, {}, {
      note: 'résumé 123-45-6789 漢字',
    })
    const recovered = out.result as Record<string, unknown>
    expect(typeof recovered.note).toBe('string')
    expect(String(recovered.note).indexOf('123-45-6789')).toBe(-1)
    expect(String(recovered.note).indexOf('résumé')).toBeGreaterThanOrEqual(0)
    expect(String(recovered.note).indexOf('漢字')).toBeGreaterThanOrEqual(0)
  })
})

describe('fail-closed on unrepresentable inputs', () => {
  it('NaN in a numeric leaf surfaces as an FFI error (not a silent mis-redaction)', async () => {
    await expect(
      runStage4(REDACT_SSN, {}, { ssn: '123-45-6789', bad: Number.NaN }),
    ).rejects.toThrow(/serde_json::Number|Failed to convert/i)
  })

  it('Infinity surfaces as an FFI error', async () => {
    await expect(
      runStage4(REDACT_SSN, {}, { ssn: '123-45-6789', bad: Number.POSITIVE_INFINITY }),
    ).rejects.toThrow(/serde_json::Number|Failed to convert/i)
  })
})
