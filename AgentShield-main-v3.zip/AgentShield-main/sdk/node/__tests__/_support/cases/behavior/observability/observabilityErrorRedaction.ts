import { describe, it, expect } from 'vitest'
import {
  _emitAdapterErrorEvent,
  _sanitizeAdapterErrorMessage,
} from '../../../../../shield'


const PII_SECRET = 'SECRET alice@example.com 4242-4242-4242-4242'

function makePiiError(): Error {
  return new Error(PII_SECRET)
}

function payloadString(event: unknown): string {
  return JSON.stringify(event)
}

describe('_emitAdapterErrorEvent never leaks raw error.message at warn+', () => {
  it('warn-level event does not contain verbatim error.message', () => {
    const captured: unknown[] = []
    _emitAdapterErrorEvent([(ev) => captured.push(ev)], 'test-adapter', makePiiError())
    const warnPlus = captured.filter(
      (e) => (e as { severity?: string }).severity === 'warn'
        || (e as { severity?: string }).severity === 'error',
    )
    expect(warnPlus.length).toBeGreaterThan(0)
    for (const ev of warnPlus) {
      const s = payloadString(ev)
      expect(s).not.toContain('SECRET')
      expect(s).not.toContain('alice@example.com')
      expect(s).not.toContain('4242-4242-4242-4242')
    }
  })

  it('warn-level event keeps safe taxonomy fields', () => {
    const captured: unknown[] = []
    _emitAdapterErrorEvent([(ev) => captured.push(ev)], 'test-adapter', new TypeError(PII_SECRET))
    const warn = captured.find(
      (e) => (e as { severity?: string }).severity === 'warn',
    ) as Record<string, unknown> | undefined
    expect(warn).toBeDefined()
    const attrs = warn!['attributes'] as Record<string, unknown>
    expect(attrs['agent_shield.adapter.name']).toBe('test-adapter')
    expect(attrs['agent_shield.adapter.error_type']).toBe('TypeError')
    expect(attrs['agent_shield.adapter.error_class']).toBe('TypeError')
    expect(typeof attrs['agent_shield.adapter.message_hash']).toBe('string')
    expect(attrs['agent_shield.adapter.error_message']).toBeUndefined()
    const msg = warn!['message'] as string
    expect(msg).not.toContain('SECRET')
    expect(msg).not.toContain('alice@example.com')
  })

  it('debug-level event preserves the full error.message (operator opt-in)', () => {
    const captured: unknown[] = []
    _emitAdapterErrorEvent([(ev) => captured.push(ev)], 'test-adapter', makePiiError())
    const debug = captured.find(
      (e) => (e as { severity?: string }).severity === 'debug',
    ) as Record<string, unknown> | undefined
    expect(debug).toBeDefined()
    const attrs = debug!['attributes'] as Record<string, unknown>
    expect(attrs['agent_shield.adapter.error_message']).toBe(PII_SECRET)
  })

  it('handles non-Error throwables without leaking', () => {
    const captured: unknown[] = []
    _emitAdapterErrorEvent([(ev) => captured.push(ev)], 'test-adapter', PII_SECRET)
    const warnPlus = captured.filter(
      (e) => (e as { severity?: string }).severity === 'warn',
    )
    for (const ev of warnPlus) {
      const s = payloadString(ev)
      expect(s).not.toContain('SECRET')
      expect(s).not.toContain('alice@example.com')
    }
  })
})

describe('_sanitizeAdapterErrorMessage helper shape', () => {
  it('returns errorType, errorClass, messageHash for Error', () => {
    const out = _sanitizeAdapterErrorMessage(new TypeError(PII_SECRET))
    expect(out.errorType).toBe('TypeError')
    expect(out.errorClass).toBe('TypeError')
    expect(typeof out.messageHash).toBe('string')
    expect(out.messageHash.length).toBeGreaterThan(0)
    expect(out.messageHash).not.toContain('SECRET')
    expect(out.messageHash).not.toContain('alice@')
  })

  it('hash is deterministic for the same message', () => {
    const a = _sanitizeAdapterErrorMessage(new Error('foo'))
    const b = _sanitizeAdapterErrorMessage(new Error('foo'))
    expect(a.messageHash).toBe(b.messageHash)
  })

  it('hash differs for distinct messages', () => {
    const a = _sanitizeAdapterErrorMessage(new Error('foo'))
    const b = _sanitizeAdapterErrorMessage(new Error('bar'))
    expect(a.messageHash).not.toBe(b.messageHash)
  })

  it('handles non-Error throwables', () => {
    const out = _sanitizeAdapterErrorMessage('whoops')
    expect(out.errorType).toBe('NonError')
    expect(out.errorClass).toBe('NonError')
    expect(typeof out.messageHash).toBe('string')
  })

  it('handles null/undefined', () => {
    const a = _sanitizeAdapterErrorMessage(null)
    expect(a.errorType).toBe('NonError')
    const b = _sanitizeAdapterErrorMessage(undefined)
    expect(b.errorType).toBe('NonError')
  })
})
