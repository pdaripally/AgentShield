
import { describe, it, expect } from 'vitest'

import { RuntimeBuilder } from '../../../../../index.js'

const CLASSIFIER_YAML = `metadata:
  name: "classifier-config-test"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test classifier callback"]
  forbidden: []
configurations:
  - id: "aacs_main"
    type: classifier
    endpoint: "https://example.cognitiveservices.azure.com/contentsafety/text:analyze"
    threshold: 0.6
    headers:
      Ocp-Apim-Subscription-Key: "test-key-not-real"
      X-Test-Header: "marker-classifier-config"
    category_thresholds:
      Hate: 0.5
      Violence: 0.7
    provider_config:
      categories: ["Hate", "Violence"]
      output_type: "FourSeverityLevels"
output_validation:
  guard_policies:
    - name: "aacs_output_check"
      evaluate_when:
        - classifier:
            configuration: "aacs_main"
          reason: "classifier flagged output"
`

describe('Runtime.configuration / RuntimeBuilder.configurations ', () => {
  it('returns null for an unknown configuration id', () => {
    const rt = RuntimeBuilder.fromYamlStrings([CLASSIFIER_YAML])
      .registerClassifierCaller(() => ({ classification: 'allow' }))
      .build()
    expect(rt.configuration('does-not-exist')).toBeNull()
  })

  it('returns the full untyped classifier config for a known id', () => {
    const rt = RuntimeBuilder.fromYamlStrings([CLASSIFIER_YAML])
      .registerClassifierCaller(() => ({ classification: 'allow' }))
      .build()
    const cfg = rt.configuration('aacs_main')
    expect(cfg).not.toBeNull()
    expect(cfg!.id).toBe('aacs_main')
    expect(cfg!.type).toBe('classifier')
    expect(cfg!.endpoint).toBe(
      'https://example.cognitiveservices.azure.com/contentsafety/text:analyze',
    )
    expect(cfg!.threshold).toBeCloseTo(0.6)
    const headers = cfg!.headers as Record<string, string>
    expect(headers['Ocp-Apim-Subscription-Key']).toBe('test-key-not-real')
    expect(headers['X-Test-Header']).toBe('marker-classifier-config')
    const cats = cfg!.categoryThresholds as Record<string, number>
    expect(cats['Hate']).toBeCloseTo(0.5)
    expect(cats['Violence']).toBeCloseTo(0.7)
    const pc = cfg!.providerConfig as Record<string, unknown>
    expect(pc['output_type']).toBe('FourSeverityLevels')
    expect(pc['categories']).toEqual(['Hate', 'Violence'])
  })

  it('exposes the YAML configuration to a classifier callback via runtime closure', async () => {
    interface Captured {
      configurationId: string
      cfg: Record<string, unknown> | null
    }
    const captured: Captured[] = []
    const holder: { rt: ReturnType<typeof rb.build> | null } = { rt: null }
    const rb = RuntimeBuilder.fromYamlStrings([CLASSIFIER_YAML]).registerClassifierCaller(
      (req) => {
        const cfg = holder.rt ? holder.rt.configuration(req.configurationId) : null
        captured.push({ configurationId: req.configurationId, cfg })
        return { classification: 'allow' }
      },
    )
    const runtime = rb.build()
    holder.rt = runtime
    const session = runtime.newSession({
      sessionId: 'sess-classifier-config',
      correlationId: 'corr-classifier-config',
    })
    try {
      session.beginTurn()
      await session.validateOutput('hello world')
    } finally {
      session.close()
    }
    expect(captured).toHaveLength(1)
    expect(captured[0].configurationId).toBe('aacs_main')
    const cfg = captured[0].cfg
    expect(cfg).not.toBeNull()
    expect(cfg!.type).toBe('classifier')
    expect(cfg!.endpoint).toContain('cognitiveservices.azure.com')
    expect(cfg!.threshold).toBeCloseTo(0.6)
    const headers = cfg!.headers as Record<string, string>
    expect(headers['Ocp-Apim-Subscription-Key']).toBe('test-key-not-real')
    const pc = cfg!.providerConfig as Record<string, unknown>
    expect(pc['output_type']).toBe('FourSeverityLevels')
  })

  it('RuntimeBuilder.configurations snapshots the YAML before build', () => {
    const rb = RuntimeBuilder.fromYamlStrings([CLASSIFIER_YAML]).registerClassifierCaller(
      () => ({ classification: 'allow' }),
    )
    const snapshot = rb.configurations()
    expect(snapshot).toHaveLength(1)
    const cfg = snapshot[0]
    expect(cfg.id).toBe('aacs_main')
    expect(cfg.type).toBe('classifier')
    expect(cfg.threshold).toBeCloseTo(0.6)
    const headers = cfg.headers as Record<string, string>
    expect(headers['X-Test-Header']).toBe('marker-classifier-config')
    const runtime = rb.build()
    expect(runtime.configuration('aacs_main')).not.toBeNull()
  })

  it('Runtime.configuration emits classifier-specific fields that llmConfiguration filters out', () => {
    const rt = RuntimeBuilder.fromYamlStrings([CLASSIFIER_YAML])
      .registerClassifierCaller(() => ({ classification: 'allow' }))
      .build()
    expect(rt.llmConfiguration('aacs_main')).toBeNull()
    const cfg = rt.configuration('aacs_main')
    expect(cfg).not.toBeNull()
    expect(cfg!.type).toBe('classifier')
    expect(cfg).toHaveProperty('headers')
    expect(cfg).toHaveProperty('threshold')
    expect(cfg).toHaveProperty('categoryThresholds')
    expect(cfg).toHaveProperty('providerConfig')
  })
})
