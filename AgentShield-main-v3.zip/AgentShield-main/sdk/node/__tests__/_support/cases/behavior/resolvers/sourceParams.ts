
import { describe, expect, it } from 'vitest'
import { RuntimeBuilder } from '../../../../../index.js'

const YAML = `
metadata:
  name: "source-params-fixture"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["read account"]
  forbidden: ["none"]
resources:
  tools:
    - name: "read_account"
      description: "returns the customer record for a given account id"
      permission: "read_only"
variables:
  - name: "customer"
    type: "object"
    populated_by:
      - kind: "tool"
        name: "read_account"
        phase: "after"
        expression: "@result"
`

describe('Session.readVariable surfaces sourceParams', () => {
  it('populator writes @source_params; readVariable returns them', async () => {
    const rt = RuntimeBuilder.fromYamlStrings([YAML]).build()
    const session = rt.newSession({
      sessionId: 'sess-source-params',
      correlationId: 'corr-source-params',
    })
    session.beginTurn()
    try {
      const params = { account_id: 'ACC-1001', authenticated: true }
      const call = await session.validateToolCall('read_account', params, 'call-1')
      expect(call.verdict.allowed).toBe(true)
      expect(call.admissionId).toBeDefined()

      const out = await session.validateToolOutput(
        call.admissionId!,
        { customer_id: 'ACC-1001' },
      )
      expect(out.verdict.allowed).toBe(true)

      const state = session.readVariable('customer')
      expect(state).not.toBeNull()
      const s = state!
      expect(s.status).toBe('resolved')
      expect(s.sourceKind).toBe('populator')

      expect(s.sourceParams).not.toBeNull()
      expect(s.sourceParams).toEqual({
        accountId: 'ACC-1001',
        authenticated: true,
      })
    } finally {
      session.endTurn()
    }
  })
})
