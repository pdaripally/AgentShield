
import { describe, expect, it } from 'vitest'
import * as path from 'node:path'
import {
  RuntimeBuilder,
  Shield,
  AgentShieldBlockedError,
} from '../../../../../index.js'
import {
  MCPShield,
} from '../../../../../mcp.js'

const FIXTURE = path.resolve(
  __dirname,
  '..',
  '..',
  '..',
  '..',
  '..',
  '..',
  '..',
  'tests',
  'fixtures',
  'contract',
  'pending_resolution.guardrails.yaml',
)

function assertNoPending(pending: unknown): void {
  expect(pending === null || pending === undefined).toBe(true)
}


describe('contract — direct Session.validateToolCall surfaces pendingResolution', () => {
  it('validateToolCall verdict carries pendingResolution on kind: human block', async () => {
    const rt = RuntimeBuilder.fromYaml(FIXTURE).build()
    const session = rt.newSession()
    session.beginTurn()
    try {
      const outcome = await session.validateToolCall(
        'send_email',
        { to: 'alice@example.com', subject: 'Hi' },
        'contract-1',
      )
      expect(outcome.verdict.allowed).toBe(false)
      const pending = (outcome.verdict as unknown as { pendingResolution?: unknown })
        .pendingResolution
      assertNoPending(pending)
    } finally {
      session.endTurn()
    }
  })

  it('after setVariable, verdict.pendingResolution is null and call is allowed', async () => {
    const rt = RuntimeBuilder.fromYaml(FIXTURE).build()
    const session = rt.newSession()
    session.beginTurn()
    try {
      const blocked = await session.validateToolCall(
        'send_email',
        { to: 'alice@example.com' },
        'contract-2a',
      )
      expect(blocked.verdict.allowed).toBe(false)

      session.setVariable('send_email_approved', true)

      const allowed = await session.validateToolCall(
        'send_email',
        { to: 'alice@example.com' },
        'contract-2b',
      )
      expect(allowed.verdict.allowed).toBe(true)
      const stale = (allowed.verdict as unknown as { pendingResolution?: unknown })
        .pendingResolution
      expect(stale === null || stale === undefined).toBe(true)
    } finally {
      session.endTurn()
    }
  })
})


describe('contract — MCPShield.protectTool & lastPendingResolution', () => {
  it('protectTool returns pendingResolution + MCPShield.lastPendingResolution latches the same envelope', async () => {
    const shield = MCPShield.fromYaml(FIXTURE).build()
    const session = shield.runtime.newSession()
    session.beginTurn()

    const result = await shield.protectTool(
      'send_email',
      { to: 'alice@example.com', subject: 'Hi' },
      'contract-mcp-1',
      { session },
    )

    expect(result.allowed).toBe(false)
    expect(result.blockMessage).toContain('GUARDRAIL')
    assertNoPending(result.pendingResolution)

    const latched = shield.lastPendingResolution()
    assertNoPending(latched)

    expect(shield.lastPendingResolution()).toEqual(latched)
  })
})


import { OPENAI_BUNDLE } from '../../../../../adapters/openai_agents.js'

describe('contract — Node OpenAI Agents protectOpenaiTools / runOpenaiAgent', () => {
  it('Shield.lastPendingResolution latches pendingResolution from a kind: human block in protectOpenaiTools', async () => {
    const rt = RuntimeBuilder.fromYaml(FIXTURE).build()
    const shield = new Shield(rt, { bundle: OPENAI_BUNDLE })

    expect(shield.lastPendingResolution()).toBeNull()

    const dispatchCalls: Array<{ name: string; args: Record<string, unknown> }> = []
    const dispatch = async (name: string, args: Record<string, unknown>) => {
      dispatchCalls.push({ name, args })
      return 'ok'
    }

    const guarded = (shield as unknown as {
      protectOpenaiTools: (opts: {
        dispatchToolCall: typeof dispatch
        allowUnguarded?: boolean
      }) => (name: string, args: Record<string, unknown>) => Promise<string>
    }).protectOpenaiTools({
      dispatchToolCall: dispatch,
      allowUnguarded: true,
    })

    const payload = guarded('send_email', {
      to: 'alice@example.com',
      subject: 'Hi',
    })

    let caught: unknown = null
    try {
      await payload
    } catch (err) {
      caught = err
    }
    expect(caught).toBeInstanceOf(AgentShieldBlockedError)
    const blocked = caught as AgentShieldBlockedError
    expect(blocked.toolName).toBe('send_email')
    expect(blocked.stage).toBe('tool_call')
    expect(blocked.blockMessage).toContain('GUARDRAIL')
    assertNoPending(blocked.pendingResolution)

    const latched = shield.lastPendingResolution()
    assertNoPending(latched)

    expect(shield.lastPendingResolution()).toEqual(latched)

    expect(dispatchCalls).toEqual([])
  })
})
