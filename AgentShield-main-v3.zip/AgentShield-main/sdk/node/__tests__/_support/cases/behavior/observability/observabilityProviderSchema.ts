import { describe, it, expect, beforeEach, vi } from 'vitest'
import * as path from 'path'
import { Shield, _resetObservabilitySchemaWarn } from '../../../../../shield'


const MINIMAL = path.resolve(
  __dirname,
  '../../../../../../../tests/fixtures/smoke/minimal.guardrails.yaml',
)

async function captureFirstEvent(shield: Shield, captured: unknown[]): Promise<void> {
  const session = shield.runtime.newSession({
    sessionId: 'sess-observability-provider',
    correlationId: 'corr-observability-provider',
  })
  session.beginTurn()
  await session.validateInput('hello')
  session.endTurn()
  await new Promise((r) => setTimeout(r, 80))
}

describe('observability provider schema (snake_case vs camelCase)', () => {
  beforeEach(() => {
    _resetObservabilitySchemaWarn()
  })

  it('snakeCase mode: providers receive canonical snake_case keys', async () => {
    const captured: any[] = []
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => undefined)
    const shield = Shield.fromYaml(MINIMAL)
      .withObservability((ev: any) => captured.push(ev))
      .withObservabilityProviderSchema('snakeCase')
      .build()
    await captureFirstEvent(shield, captured)
    expect(captured.length).toBeGreaterThan(0)
    const ev = captured[0]
    expect(ev).toHaveProperty('event_type')
    expect(ev).toHaveProperty('correlation_id')
    expect(ev).toHaveProperty('session_id')
    expect(ev).not.toHaveProperty('eventType')
    expect(ev).not.toHaveProperty('correlationId')
    expect(ev).not.toHaveProperty('sessionId')
    const matched = warnSpy.mock.calls.find((args) =>
      String(args[0] ?? '').includes('observability provider schema'),
    )
    expect(matched).toBeUndefined()
    warnSpy.mockRestore()
  })

  it('camelCase mode (explicit): providers receive historical camelCase keys without warn', async () => {
    const captured: any[] = []
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => undefined)
    const shield = Shield.fromYaml(MINIMAL)
      .withObservability((ev: any) => captured.push(ev))
      .withObservabilityProviderSchema('camelCase')
      .build()
    await captureFirstEvent(shield, captured)
    expect(captured.length).toBeGreaterThan(0)
    const ev = captured[0]
    expect(ev).toHaveProperty('eventType')
    expect(ev).toHaveProperty('correlationId')
    expect(ev).not.toHaveProperty('event_type')
    expect(ev).not.toHaveProperty('correlation_id')
    const matched = warnSpy.mock.calls.find((args) =>
      String(args[0] ?? '').includes('observability provider schema'),
    )
    expect(matched).toBeUndefined()
    warnSpy.mockRestore()
  })

  it('no schema set: defaults to camelCase AND emits a one-time deprecation warn', async () => {
    const captured: any[] = []
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => undefined)
    const shield = Shield.fromYaml(MINIMAL)
      .withObservability((ev: any) => captured.push(ev))
      .build()
    await captureFirstEvent(shield, captured)
    expect(captured.length).toBeGreaterThan(0)
    const ev = captured[0]
    expect(ev).toHaveProperty('eventType')
    expect(ev).not.toHaveProperty('event_type')
    const matched = warnSpy.mock.calls.find((args) =>
      String(args[0] ?? '').includes('observability provider schema'),
    )
    expect(matched).toBeDefined()
    warnSpy.mockRestore()
  })

  it('default warn fires at most once per process', () => {
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => undefined)
    Shield.fromYaml(MINIMAL)
      .withObservability(() => undefined)
      .build()
    Shield.fromYaml(MINIMAL)
      .withObservability(() => undefined)
      .build()
    Shield.fromYaml(MINIMAL)
      .withObservability(() => undefined)
      .build()
    const matched = warnSpy.mock.calls.filter((args) =>
      String(args[0] ?? '').includes('observability provider schema'),
    )
    expect(matched.length).toBe(1)
    warnSpy.mockRestore()
  })

  it('no providers registered: no schema warn even at default', () => {
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => undefined)
    Shield.fromYaml(MINIMAL).build()
    const matched = warnSpy.mock.calls.find((args) =>
      String(args[0] ?? '').includes('observability provider schema'),
    )
    expect(matched).toBeUndefined()
    warnSpy.mockRestore()
  })
})
