
import { describe, expect, it } from 'vitest'
import * as path from 'node:path'
import * as fs from 'node:fs'
import * as os from 'node:os'
import {
  RuntimeBuilder,
  type DelegateDispatcher,
  type DelegateRequest,
  type ResolverRequest,
  type ResolverResponseEnvelope,
} from '../../../../../index.js'

function _writeYaml(body: string, slug: string): string {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), `as-node-${slug}-`))
  const p = path.join(dir, 'guardrails.yaml')
  fs.writeFileSync(p, body, 'utf8')
  return p
}

function _yamlWithResolver(resolverBlock: string, configurationsBlock = ''): string {
  return `
metadata:
  name: "resolver-request-envelope"
  version: "0.1.0"
  agent_shield_version: "2.0"

objective:
  goal: ["gate a tool on a keyed per-id authorization"]
  forbidden: []
${configurationsBlock}
resources:
  tools:
    - name: "do_thing"
      description: "tool gated on per-id authorization"
      permission: "execute"

variables:
  - name: "authorized"
    type: "boolean"
    key: "@tool.params.id"
${resolverBlock}

state_validation:
  guard_policies:
    - name: "needs_authz"
      applies_to:
        tools: ["do_thing"]
      evaluate_when:
        - expression: "authorized == true"
          reason: "must be authorized"
      action: "block"
`
}

const _AGENT_RESOLVER_BLOCK = `    on_demand_by:
      kind: "agent"
      prompt: "Authorize id=\${@tool.params.id}?"
    lifetime: "per_call"
`

const _DELEGATE_RESOLVER_BLOCK = `    on_demand_by:
      kind: "delegate"
      configuration: "approval-service"
      prompt: "Authorize id=\${@tool.params.id}?"
      lifetime: "per_turn"
    lifetime: "per_call"
`

const _DELEGATE_CONFIGURATIONS = `
configurations:
  - id: "approval-service"
    type: "http_endpoint"
    endpoint: "https://example.com/approval"
    timeout: 5000
`

describe('resolver request envelopes carry requestedKey', () => {
  it("kind: agent — JS callback receives `requestedKey` for keyed variable", async () => {
    const yamlPath = _writeYaml(
      _yamlWithResolver(_AGENT_RESOLVER_BLOCK),
      'agent-keyed',
    )
    const captured: ResolverRequest[] = []
    try {
      const rt = RuntimeBuilder.fromYaml(yamlPath)
        .registerAgentResolver((req: ResolverRequest): ResolverResponseEnvelope => {
          captured.push(req)
          return { decision: 'allow', value: true }
        })
        .build()
      const s = rt.newSession()
      s.beginTurn()
      try {
        const v = await s.validateToolCall('do_thing', { id: 'K42' }, 'tc-1')
        expect(v.verdict.allowed).toBe(true)
      } finally {
        s.endTurn()
      }
    } finally {
      fs.rmSync(path.dirname(yamlPath), { recursive: true, force: true })
    }

    expect(captured).toHaveLength(1)
    const req = captured[0]
    expect(req.variable).toBe('authorized')
    expect(req.requestedKey).toBe('K42')
    expect(req.resource).not.toBeNull()
    expect(req.resource?.kind).toBe('tool')
    expect(req.resource?.name).toBe('do_thing')
  })

  it("kind: delegate — JS callback receives `requestedKey` for keyed variable", async () => {
    const yamlPath = _writeYaml(
      _yamlWithResolver(_DELEGATE_RESOLVER_BLOCK, _DELEGATE_CONFIGURATIONS),
      'delegate-keyed',
    )
    const captured: DelegateRequest[] = []
    try {
      const dispatcher: DelegateDispatcher = (
        req: DelegateRequest,
      ): ResolverResponseEnvelope => {
        captured.push(req)
        return { decision: 'allow', value: true }
      }
      const rt = RuntimeBuilder.fromYaml(yamlPath)
        .registerDelegateDispatcher(dispatcher)
        .build()
      const s = rt.newSession()
      s.beginTurn()
      try {
        const v = await s.validateToolCall('do_thing', { id: 'K42' }, 'tc-1')
        expect(v.verdict.allowed).toBe(true)
      } finally {
        s.endTurn()
      }
    } finally {
      fs.rmSync(path.dirname(yamlPath), { recursive: true, force: true })
    }

    expect(captured).toHaveLength(1)
    const req = captured[0]
    expect(req.variable).toBe('authorized')
    expect(req.requestedKey).toBe('K42')
    expect(req.resource).not.toBeNull()
    expect(req.resource?.kind).toBe('tool')
    expect(req.resource?.name).toBe('do_thing')
    expect(req.configurationId).toBe('approval-service')
  })

  it('non-keyed variable still surfaces `requestedKey: null`', async () => {
    const yaml = `
metadata:
  name: "resolver-request-unkeyed"
  version: "0.1.0"
  agent_shield_version: "2.0"

objective:
  goal: ["non-keyed variable resolver envelope shape"]
  forbidden: []

resources:
  tools:
    - name: "do_thing"
      description: "tool gated on a non-keyed flag"
      permission: "execute"

variables:
  - name: "authorized"
    type: "boolean"
    on_demand_by:
      kind: "agent"
      prompt: "Authorize?"
    lifetime: "per_call"

state_validation:
  guard_policies:
    - name: "needs_authz"
      applies_to:
        tools: ["do_thing"]
      evaluate_when:
        - expression: "authorized == true"
          reason: "must be authorized"
      action: "block"
`
    const yamlPath = _writeYaml(yaml, 'agent-unkeyed')
    const captured: ResolverRequest[] = []
    try {
      const rt = RuntimeBuilder.fromYaml(yamlPath)
        .registerAgentResolver((req: ResolverRequest): ResolverResponseEnvelope => {
          captured.push(req)
          return { decision: 'allow', value: true }
        })
        .build()
      const s = rt.newSession()
      s.beginTurn()
      try {
        await s.validateToolCall('do_thing', {}, 'tc-1')
      } finally {
        s.endTurn()
      }
    } finally {
      fs.rmSync(path.dirname(yamlPath), { recursive: true, force: true })
    }

    expect(captured).toHaveLength(1)
    const req = captured[0]
    expect('requestedKey' in req).toBe(true)
    expect(req.requestedKey).toBeNull()
  })
})
