import { describe, expect, it } from 'vitest'
import * as fs from 'node:fs'
import * as path from 'node:path'
import { AgentShieldBlocked, MCPGuardrailBlocked, MCPShield } from '../../../../../index.js'

const REPO_ROOT = path.resolve(__dirname, '..', '..', '..', '..', '..', '..', '..')
const fixturePath = path.join(REPO_ROOT, 'tests', 'parity', 'error_mapping_parity.json')
const canonical = fs.existsSync(fixturePath)
  ? JSON.parse(fs.readFileSync(fixturePath, 'utf8'))
  : { cases: [] }

function getCase(name: string) {
  const c = canonical.cases.find((x) => x.name === name)
  if (!c) throw new Error(`parity fixture missing case "${name}"`)
  return c
}

describe('error mapping parity', () => {
  it('shield_blocked_raise', async () => {
    const c = getCase('shield_blocked_raise')
    const err = new AgentShieldBlocked(null, 'blocked')
    expect(err).toBeInstanceOf(AgentShieldBlocked)
    expect(AgentShieldBlocked.name).toBe(c.expected.node)
  })

  it('mcp_blocked_raise', async () => {
    const c = getCase('mcp_blocked_raise')
    const shield = MCPShield.fromYaml(path.join(REPO_ROOT, c.fixture)).build()
    const wrapped = shield.protectTools(
      [['echo', async ({ msg }) => `echo: ${msg}`]],
      { onBlock: 'raise' },
    )
    await expect(wrapped[0][1]({ msg: 'hi' })).rejects.toBeInstanceOf(MCPGuardrailBlocked)
    expect(MCPGuardrailBlocked.name).toBe(c.expected.node)
  })
})
