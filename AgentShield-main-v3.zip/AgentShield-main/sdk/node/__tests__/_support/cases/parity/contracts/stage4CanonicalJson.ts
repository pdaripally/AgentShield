
import { describe, expect, test } from 'vitest'
import {
  _buildCanonicalWithLeafRanges,
  _escapeJsonString,
} from '../../../../../_stage4_shape.js'

const FIXTURES: ReadonlyArray<{
  name: string
  input: unknown
  expectedBytes: string
  expectedLeafRanges: Array<{ path: ReadonlyArray<string | number>; contentStart: number; contentEnd: number }>
}> = [
  {
    name: 'dict redaction reproducer — ssn + numeric leaf',
    input: { ssn: '123-45-6789', n: 42 },
    expectedBytes: '{"n":42,"ssn":"123-45-6789"}',
    expectedLeafRanges: [{ path: ['ssn'], contentStart: 15, contentEnd: 26 }],
  },
  {
    name: 'list redaction reproducer — abc123 + numeric',
    input: ['abc123', 456],
    expectedBytes: '["abc123",456]',
    expectedLeafRanges: [{ path: [0], contentStart: 2, contentEnd: 8 }],
  },
  {
    name: 'nested dict with mixed types',
    input: {
      patient: { name: 'Alice', ssn: '123-45-6789', age: 42, active: true },
      trace_id: 'abc-no-ssn',
    },
    expectedBytes:
      '{"patient":{"active":true,"age":42,"name":"Alice","ssn":"123-45-6789"},"trace_id":"abc-no-ssn"}',
    expectedLeafRanges: [
      { path: ['patient', 'name'], contentStart: 43, contentEnd: 48 },
      { path: ['patient', 'ssn'], contentStart: 57, contentEnd: 68 },
      { path: ['trace_id'], contentStart: 83, contentEnd: 93 },
    ],
  },
]

describe('canonical JSON byte parity with Python & Rust', () => {
  for (const fix of FIXTURES) {
    test(`encoder produces canonical bytes: ${fix.name}`, () => {
      const built = _buildCanonicalWithLeafRanges(fix.input)
      expect(built.ok, `canonicaliser bailed on fixture "${fix.name}"`).toBe(true)
      if (!built.ok) return // type-narrow
      expect(built.form.canonical).toBe(fix.expectedBytes)
      const got = built.form.leafRanges.map((lr) => ({
        path: lr.path,
        contentStart: lr.contentStart,
        contentEnd: lr.contentEnd,
      }))
      expect(got).toEqual(fix.expectedLeafRanges)
    })
  }

  test('escapeJsonString matches serde_json default (control chars + quote + backslash only)', () => {
    expect(_escapeJsonString('hello')).toBe('hello')
    expect(_escapeJsonString('he"llo')).toBe('he\\"llo')
    expect(_escapeJsonString('he\\llo')).toBe('he\\\\llo')
    expect(_escapeJsonString('a\nb')).toBe('a\\nb')
    expect(_escapeJsonString('a\rb')).toBe('a\\rb')
    expect(_escapeJsonString('a\tb')).toBe('a\\tb')
    expect(_escapeJsonString('a\bb')).toBe('a\\bb')
    expect(_escapeJsonString('a\fb')).toBe('a\\fb')
    expect(_escapeJsonString('a\x01b')).toBe('a\\u0001b')
    expect(_escapeJsonString('Café 漢字')).toBe('Café 漢字')
  })
})

describe('canonicaliser fail-closed sentinels', () => {
  test('NaN bails', () => {
    const r = _buildCanonicalWithLeafRanges({ x: Number.NaN })
    expect(r.ok).toBe(false)
  })

  test('Infinity bails', () => {
    const r = _buildCanonicalWithLeafRanges({ x: Number.POSITIVE_INFINITY })
    expect(r.ok).toBe(false)
  })

  test('-Infinity bails', () => {
    const r = _buildCanonicalWithLeafRanges({ x: Number.NEGATIVE_INFINITY })
    expect(r.ok).toBe(false)
  })

  test('BigInt bails', () => {
    const r = _buildCanonicalWithLeafRanges({ x: 1n })
    expect(r.ok).toBe(false)
  })

  test('function value bails', () => {
    const r = _buildCanonicalWithLeafRanges({ x: () => 1 })
    expect(r.ok).toBe(false)
  })

  test('Symbol-keyed property bails', () => {
    const sym = Symbol('s')
    const obj: Record<string | symbol, unknown> = { a: 1 }
    obj[sym] = 'leak'
    const r = _buildCanonicalWithLeafRanges(obj)
    expect(r.ok).toBe(false)
  })

  test('circular reference bails', () => {
    const a: Record<string, unknown> = {}
    a.self = a
    const r = _buildCanonicalWithLeafRanges(a)
    expect(r.ok).toBe(false)
  })

  test('Map (non-plain container) bails', () => {
    const m = new Map<unknown, unknown>([[1, 'one']])
    const r = _buildCanonicalWithLeafRanges({ m })
    expect(r.ok).toBe(false)
  })
})
