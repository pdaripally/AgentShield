import { describe, expect, it } from 'vitest'
import * as fs from 'node:fs'
import * as path from 'node:path'
import { RuntimeBuilder } from '../../../../../index.js'

const REPO_ROOT = path.resolve(__dirname, '..', '..', '..', '..', '..', '..', '..')
const fixturePath = path.join(
  REPO_ROOT,
  'tests',
  'parity',
  'invocation_hash_canonicalization.json',
)
if (!fs.existsSync(fixturePath)) {
  throw new Error(`Missing parity fixture: ${fixturePath}`)
}
const canonical = JSON.parse(fs.readFileSync(fixturePath, 'utf8'))
if (!Array.isArray(canonical.cases) || canonical.cases.length === 0) {
  throw new Error(`No cases found in parity fixture: ${fixturePath}`)
}

describe('invocation hash canonicalization parity', () => {
  for (const c of canonical.cases) {
    it(c.name, async () => {
      const runtime = RuntimeBuilder.fromYaml(path.join(REPO_ROOT, c.fixture)).build()
      const session = runtime.newSession({
        sessionId: `sess-${c.name}`,
        correlationId: `corr-${c.name}`,
      })
      await session.beginTurn()
      const out = await session.validateToolCall(c.tool_name, { ...c.params }, c.tool_call_id)
      expect(out.verdict.allowed).toBe(true)
      expect(out.verdict.invocationHash).toBe(c.expected.invocation_hash)
      expect(out.verdict.postValidationInvocationHash).toBe(
        c.expected.post_validation_invocation_hash,
      )
      if (c.expected.effective_params) {
        expect(out.params).toEqual(c.expected.effective_params)
      }
    })
  }
})
