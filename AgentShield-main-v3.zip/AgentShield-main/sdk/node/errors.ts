/**
 * SDK-level error types used by the Pattern A / B helpers.
 *
 * Kept in a dedicated file so test fixtures, framework adapters, and
 * the main `index.ts` re-export surface can all reference these
 * without import cycles through `shield.ts`.
 */

/**
 * Structured shape of the pending-resolution envelope surfaced by
 * Agent Shield core when a guarded tool call is blocked. Mirrors the
 * canonical shape stored in `Shield.lastPendingResolution()` and the
 * Python SDK's `pending_resolution` dict.
 */
export interface PendingResolutionShape {
  resolver?: string | null
  decision?: string | null
  reason?: string | null
  setVariables?: Record<string, unknown> | null
  blockedTool?: string | null
  stage?: string | null
  raw?: Record<string, unknown> | null
  [key: string]: unknown
}

/**
 * Thrown by guarded tool wrappers (Pattern A) when validation Stage 2,
 * Stage 3, or Stage 4 denies a tool invocation. Adapters at the public
 * boundary (`runOpenaiAgent`, `createLangchainAgent`, `GuardedRunner.run`)
 * catch this typed error and turn it into the canonical block envelope
 * so the LLM loop halts instead of treating the deny payload as a
 * successful observation (F-probe-1.5, F-probe-1.6).
 *
 * This is intentionally a SEPARATE class from the existing
 * `AgentShieldBlocked` (which models the on_block="raise" Stage 1/5
 * policy) so existing customer catch-handlers are unaffected.
 *
 * Per AGENTS.md "Sensible defaults > flags. The default behavior
 * must match the spec's security posture (fail-closed)." A tool block
 * MUST halt the agent loop; the LLM must not see the deny message as
 * an observation it can argue with.
 */
export class AgentShieldBlockedError extends Error {
  readonly toolName: string
  readonly stage: 'tool_call' | 'tool_output' | 'tool_error'
  readonly pendingResolution: PendingResolutionShape | null
  readonly blockMessage: string
  readonly verdict: unknown

  constructor(init: {
    toolName: string
    stage: 'tool_call' | 'tool_output' | 'tool_error'
    message: string
    pendingResolution?: PendingResolutionShape | null
    verdict?: unknown
  }) {
    super(init.message)
    this.name = 'AgentShieldBlockedError'
    this.toolName = init.toolName
    this.stage = init.stage
    this.pendingResolution = init.pendingResolution ?? null
    this.blockMessage = init.message
    this.verdict = init.verdict ?? null
    Object.setPrototypeOf(this, AgentShieldBlockedError.prototype)
  }
}

/**
 * Raised when a tool wrapped by `shield.protectTools(...)` (or one of
 * the per-framework variants — `shield.protectOpenaiTools(...)`,
 * `shield.protectAnthropicTools(...)`) is invoked **outside** any
 * guarded session.
 *
 * Mirrors Python's
 * `agent_shield.UnguardedToolInvocation`. The Node SDK previously
 * silently minted a fresh session per call when no ambient
 * `AsyncLocalStorage` context was present, which dropped every
 * per_turn / per_session / multi-call gate (rate limits, approval
 * state, conversation-scoped variables) whenever the customer forgot
 * the agent-side wiring.
 *
 * Per AGENTS.md "Sensible defaults > flags. The default behavior
 * must match the spec's security posture (fail-closed). Don't ship
 * safety as opt-in." The fresh-session path is now opt-in via
 * `{ allowUnguarded: true }`; the default throws this error.
 *
 * Customers who legitimately want one-shot ad-hoc invocations can
 * opt in via `shield.protectTools(tools, { allowUnguarded: true })`.
 */
export class UnguardedToolInvocationError extends Error {
  readonly toolName: string

  constructor(toolName: string, message?: string) {
    super(message ?? UnguardedToolInvocationError.formatMessage(toolName))
    this.name = 'UnguardedToolInvocationError'
    this.toolName = toolName
    // Restore prototype chain for cross-realm `instanceof` checks
    // (compiled-to-ES5 target also needs this).
    Object.setPrototypeOf(this, UnguardedToolInvocationError.prototype)
  }

  /**
   * Build the canonical actionable message. Kept as a static so
   * tests can assert against the exact wording without
   * instantiating the error.
   */
  static formatMessage(toolName: string): string {
    return (
      `Tool '${toolName}' was invoked outside a guarded session. ` +
      "Wrap your agent with `shield.guard(agent)` so the wrapped tool " +
      "runs inside the agent's guarded turn, or pass " +
      '`{ allowUnguarded: true }` to `shield.protectTools(...)` to opt ' +
      'into ad-hoc invocation (fresh session per call; per_turn / ' +
      'per_session state will NOT carry across calls).'
    )
  }
}

/**
 * Raised when an append-only streaming sink receives a ``replace`` action
 * from the Stage-5 streaming guard.
 *
 * Stage-5 streaming guards may emit a {@link StreamChunkResult} with
 * `action === 'replace'` when the validator rewrites the buffered
 * output (for example, redacting a sensitive span that only became
 * visible after a later chunk closed the match window). The semantics
 * of `replace` are: *discard every byte already emitted for this
 * stream and substitute `payload` in its place.*
 *
 * Sinks that cannot retract bytes already delivered to the consumer —
 * HTTP SSE without rewind support, stdout, terminal renderers, any UI
 * that immediately paints each delta — would otherwise leave the
 * leaked PHI/secret on screen with the redacted version appended
 * after it. The SDK throws this error at the FIRST such event so the
 * consumer fails loudly instead of silently rendering stale sensitive
 * text.
 *
 * Mitigation:
 *
 * - Switch the streaming cadence to `on_complete` (the default) so no
 *   text-bearing chunks ever leave the guard until `finish()` returns
 *   the fully validated payload — that is the spec's safe default and
 *   the only mode whose output is byte-equivalent to the non-streaming
 *   path.
 * - Or wrap the sink in an in-memory buffer that the SDK can rewrite
 *   cleanly on `replace` before flushing to the customer.
 *
 * Mirrors Python's
 * {@link https://github.com/microsoft/AgentShield/blob/main/sdk/python/agent_shield/errors.py | StreamingReplaceNotSupportedError}.
 */
export class StreamingReplaceNotSupportedError extends Error {
  readonly reason: string | null
  readonly adapter: string | null

  constructor(opts: { adapter?: string; reason?: string | null; message?: string } = {}) {
    const adapter = opts.adapter ?? null
    const reason = opts.reason ?? null
    const message =
      opts.message ??
      `${adapter ? `${adapter} ` : ''}streaming adapter received a ` +
        '`replace` action from the Stage-5 guard, but deltas are ' +
        'yielded directly to the consumer (append-only sink) and ' +
        'cannot be retracted. Switch the streaming cadence to ' +
        '`on_complete` (the default, safest) or disable streaming. ' +
        `Reason: ${reason ?? '<no reason supplied>'}`
    super(message)
    this.name = 'StreamingReplaceNotSupportedError'
    this.reason = reason
    this.adapter = adapter
    Object.setPrototypeOf(this, StreamingReplaceNotSupportedError.prototype)
  }
}

/**
 * Raised when a resolver callback returns a malformed envelope.
 *
 * the resolver wire envelope as:
 *
 *   { decision: "allow" | "deny" | "cancelled",
 *     value: <typed value matching the variable, or null>,
 *     setVariables: {... },
 *     reason: "<human-readable explanation>" }
 *
 * On `decision: "allow"` the `value` field is REQUIRED — the spec
 * permits `value: null` only as an explicit, deliberately-supplied
 * sentinel for boolean-resolved variables. An envelope that omits the
 * `value` key altogether on `allow` is silently fail-open. This error
 * closes that gap: an `allow` envelope without a `value` key raises
 * this error at the SDK surface, before the response reaches the Rust core.
 *
 * Resolvers that legitimately resolve to `null` must state the intent
 * explicitly:
 *
 *   return { decision: 'allow', value: null, setVariables: {...} }
 *
 * `deny` / `cancelled` envelopes are unaffected — neither sets a
 * variable value, so `value` is optional.
 *
 * Mirrors Python's `AgentShieldResolverEnvelopeError`.
 */
export class AgentShieldResolverEnvelopeError extends Error {
  readonly decision: string

  constructor(opts: { decision?: string; hint?: string } = {}) {
    const decision = opts.decision ?? 'allow'
    const base =
      `resolver callback returned \`decision: '${decision}'\` without a ` +
      '`value` field; the value field on `allow`.'
    const migration =
      opts.hint ??
      'If your resolver is a side-effect-only gate (the variable\'s ' +
        "type is boolean and the policy intent is `value: null` means " +
        '`allow`), state that explicitly:\n\n' +
        '    return {\n' +
        "        decision: 'allow',\n" +
        '        value: null,\n' +
        '        setVariables: {...},\n' +
        '    }\n\n' +
        'If the resolver was meant to deny, return\n' +
        "    { decision: 'deny', reason: '...' }\n" +
        'instead — `deny` does not require `value`.'
    super(`${base}\n\n${migration}`)
    this.name = 'AgentShieldResolverEnvelopeError'
    this.decision = decision
    Object.setPrototypeOf(this, AgentShieldResolverEnvelopeError.prototype)
  }
}

/**
 * Structured loader-error envelope thrown by `Shield.fromYaml`,
 * `Shield.fromYamlChain`, `RuntimeBuilder.fromYaml*`, and `.build()`
 * when guardrails YAML cannot be loaded or compiled.
 *
 * Inherits from `Error` so existing `catch (err)` handlers keep
 * working; cluster-aware callers use:
 *
 *   try { Shield.fromYaml('...').build() }
 *   catch (err) {
 *     if (err instanceof AgentShieldConfigError) {
 *       console.error(err.code, err.field, err.remediation)
 *     }
 *   }
 *
 * Fields mirror the cross-language wire shape produced by
 * `agent_shield_core::LoaderErrorWire::to_json()`:
 *
 *   { path?, line?, column?, field?, code?, message, remediation? }
 */
export interface LoaderErrorWire {
  path?: string | null
  line?: number | null
  column?: number | null
  field?: string | null
  code?: string | null
  remediation?: string | null
}

export class AgentShieldConfigError extends Error {
  readonly path: string | null
  readonly line: number | null
  readonly column: number | null
  readonly field: string | null
  readonly code: string | null
  readonly remediation: string | null

  constructor(message: string, wire: LoaderErrorWire = {}) {
    super(message)
    this.name = 'AgentShieldConfigError'
    this.path = wire.path ?? null
    this.line = typeof wire.line === 'number' ? wire.line : null
    this.column = typeof wire.column === 'number' ? wire.column : null
    this.field = wire.field ?? null
    this.code = wire.code ?? null
    this.remediation = wire.remediation ?? null
    Object.setPrototypeOf(this, AgentShieldConfigError.prototype)
  }

  toJSON(): {
    name: string
    message: string
    path: string | null
    line: number | null
    column: number | null
    field: string | null
    code: string | null
    remediation: string | null
  } {
    return {
      name: this.name,
      message: this.message,
      path: this.path,
      line: this.line,
      column: this.column,
      field: this.field,
      code: this.code,
      remediation: this.remediation,
    }
  }
}

/**
 * FFI sentinel prepended by `sdk/node/src/lib.rs::map_loader_err`
 * (and the matching helpers in the Python /.NET SDKs and the core
 * `agent_shield_ffi::write_runtime_err`). Format:
 *
 *   AGENT_SHIELD_LOADER_ERROR_JSON:{json}\n{displayMessage}
 */
const LOADER_SENTINEL = 'AGENT_SHIELD_LOADER_ERROR_JSON:'

/**
 * Detect the sentinel envelope on a thrown native `Error.message`
 * and lift it into a typed `AgentShieldConfigError`. Non-loader
 * errors (any error whose message does not start with the sentinel)
 * are returned as-is so the throw site can re-raise them unchanged.
 */
export function mapNativeLoaderError(err: unknown): unknown {
  if (!(err instanceof Error) || typeof err.message !== 'string') return err
  const msg = err.message
  if (!msg.startsWith(LOADER_SENTINEL)) return err
  const newlineIdx = msg.indexOf('\n')
  const jsonPart =
    newlineIdx === -1
      ? msg.slice(LOADER_SENTINEL.length)
      : msg.slice(LOADER_SENTINEL.length, newlineIdx)
  const displayMsg = newlineIdx === -1 ? '' : msg.slice(newlineIdx + 1)
  let wire: LoaderErrorWire = {}
  try {
    const parsed = JSON.parse(jsonPart) as Record<string, unknown>
    wire = {
      path: typeof parsed.path === 'string' ? parsed.path : null,
      line: typeof parsed.line === 'number' ? parsed.line : null,
      column: typeof parsed.column === 'number' ? parsed.column : null,
      field: typeof parsed.field === 'string' ? parsed.field : null,
      code: typeof parsed.code === 'string' ? parsed.code : null,
      remediation: typeof parsed.remediation === 'string' ? parsed.remediation : null,
    }
  } catch {
    // Malformed sentinel JSON — degrade gracefully and surface the
    // display message with empty structured fields rather than
    // discarding the original error context.
  }
  return new AgentShieldConfigError(displayMsg || msg, wire)
}

/**
 * Helper used by the three native loader entry points (`fromYaml`,
 * `fromYamlChain`, `.build()`). Invokes the thunk and rethrows
 * loader errors as `AgentShieldConfigError`; all other errors pass
 * through unchanged.
 */
export function withTypedLoaderErrors<T>(thunk: () => T): T {
  try {
    return thunk()
  } catch (err) {
    const mapped = mapNativeLoaderError(err)
    if (mapped !== err) throw mapped
    throw err
  }
}
