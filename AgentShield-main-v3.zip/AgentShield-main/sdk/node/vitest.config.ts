import { defineConfig } from 'vitest/config'

// Vitest config.
//
// `integrationCases.test.mjs` uses Node's built-in `node:test` runner
// (`import { describe, it } from 'node:test'`) rather than vitest's
// suite syntax, because the cross-language test harness emits TAP that
// node:test understands natively. Vitest cannot interpret a node:test
// describe block as one of its own suites and reports
// "No test suite found in file …" if it tries to load it. Exclude that
// file here; CI runs it separately via
// `node --test sdk/node/__tests__/e2e/integrationCases.test.mjs`.
export default defineConfig({
  test: {
    exclude: ['**/node_modules/**', '**/dist/**', '__tests__/e2e/integrationCases.test.mjs'],
  },
})
