using System;

using AgentShield;

namespace AgentShield.OpenAI;

/// <summary>
/// OpenAI .NET SDK <see cref="ShieldBuilder"/> extension. The OpenAI
/// SDK does not expose construction-time tool wrapping, so Stage 2/3/4
/// must be applied explicitly via <see cref="OpenAIAdapter.GuardToolCall"/>
/// or <see cref="Shield.ProtectToolAsync"/>. Stage 1 + Stage 5 are
/// fully covered through <see cref="Shield.RunAsync{TResult}"/>.
///
/// <example>
/// Drop-in usage:
/// <code>
/// using var shield = Shield.FromYaml("guardrails.yaml").WithOpenAI().Build();
/// var reply = await shield.RunAsync(userInput, () =&gt; client.CompleteChatAsync(messages));
/// </code>
/// </example>
/// </summary>
public static class ShieldExtensions
{
    /// <summary>Honest capability profile for the OpenAI .NET SDK.</summary>
    public static readonly CapabilityReport CapabilityReport = new(
        framework: "openai",
        inputValidation: CoverageLevel.Full,
        stateValidation: CoverageLevel.Partial,
        toolAuthorization: CoverageLevel.Partial,
        toolExecutionValidation: CoverageLevel.Partial,
        toolOutputValidation: CoverageLevel.Partial,
        outputValidation: CoverageLevel.Full,
        streamingOutput: CoverageLevel.Unsupported,
        notes: new[]
        {
            "OpenAI .NET SDK does not expose construction-time tool wrapping; use ProtectToolAsync inside your tool dispatcher.",
            "Streaming Stage 5 is not currently driven through Shield.RunStreamedAsync for OpenAI responses; use the existing OpenAIAdapter helpers.",
        });

    /// <summary>Attach the OpenAI capability profile to this builder.</summary>
    public static ShieldBuilder WithOpenAI(this ShieldBuilder builder)
    {
        if (builder == null) throw new ArgumentNullException(nameof(builder));
        return builder.WithCapability(CapabilityReport);
    }
}
