# AgentShield.OpenAI mediation

## Mediated paths
- `WithOpenAI()` installs the capability profile at `sdk/dotnet/src/AgentShield.OpenAI/ShieldExtensions.cs:41`.
- `OpenAIAdapter.GuardConversation(...)` mediates Stage 1 over the last user message at `sdk/dotnet/src/AgentShield.OpenAI/OpenAIAdapter.cs:23`.
- `OpenAIAdapter.GuardToolCall(...)` mediates Stage 2/3 for `ChatToolCall.Id`-bound tool invocations at `sdk/dotnet/src/AgentShield.OpenAI/OpenAIAdapter.cs:49`.
- `Shield.ProtectToolAsync(...)` is the full Stage-2/3/4 path the OpenAI adapter relies on when the host owns tool dispatch at `sdk/dotnet/src/AgentShield/Shield.cs:320`.
- `OpenAIAdapter.GuardResponse(...)` and `Shield.RunAsync(...)` mediate Stage 5 final-text output at `sdk/dotnet/src/AgentShield.OpenAI/OpenAIAdapter.cs:68` and `sdk/dotnet/src/AgentShield/Shield.cs:249`.

## Unsupported paths
- Direct `ChatClient` / Responses API calls that never route through `Shield.RunAsync(...)` or the `OpenAIAdapter` helpers.
- Raw tool dispatch that skips `GuardToolCall(...)` / `ProtectToolAsync(...)` and calls the underlying callback directly.
- Streaming OpenAI response surfaces; this DLL currently declares streaming output unsupported.

## Bypass risks
- Parsing OpenAI tool arguments through `GuardToolCall(...)` but then executing the original tool with different/raw arguments.
- Keeping both guarded and raw tool dispatchers reachable and swapping back to the raw path mid-run.
- Assuming Stage 2/3/4 coverage exists automatically just because `WithOpenAI()` is enabled; the SDK requires explicit tool-dispatch integration.

## Streaming behavior
- Streaming is unsupported on this adapter today. Rules 1-5 are not claimed on the shipped OpenAI .NET surface.

## Unknown tool-call shapes
- `GuardToolCall(...)` assumes JSON-string tool arguments and fails at `JsonDocument.Parse(...)` for malformed JSON, but unknown host-side tool-call envelopes are not yet surfaced as `incident.unknown_invocation_shape`.

## See also

See [Post-tool limits and dangerous patterns](../../../../docs/POST_TOOL_LIMITS.md) and the [adapter-mediated path matrix](../../../../docs/adapter-mediated-paths.md).
