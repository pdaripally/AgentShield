using System;
using System.Collections.Generic;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;

using AgentShield;
using AgentShield.AI;

namespace AgentShield.SemanticKernel;

/// <summary>
/// DI registration helpers for Semantic Kernel: register the Shield, install
/// the Stage 2/3/4 auto-function filter, and decorate already-registered chat
/// services for Stage 1/5. Add chat connectors before these overloads.
/// </summary>
public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Register a <see cref="Shield"/> loaded from
    /// <paramref name="yamlPath"/>, an
    /// <see cref="IAutoFunctionInvocationFilter"/> backed by
    /// <see cref="AgentShieldFilter"/>, and decorate every
    /// already-registered chat service (see
    /// <see cref="KernelBuilderExtensions"/> for the canonical
    /// ordering note).
    ///
    /// <para>
    /// The Shield is constructed lazily on first resolution (Shield's
    /// Build() touches the native runtime, so this avoids native
    /// loader work at <c>Services.Add*</c> time).
    /// </para>
    /// </summary>
    public static IServiceCollection AddAgentShieldFilter(this IServiceCollection services, string yamlPath)
    {
        if (services == null) throw new ArgumentNullException(nameof(services));
        if (yamlPath == null) throw new ArgumentNullException(nameof(yamlPath));

        services.TryAddSingleton<Shield>(_ => Shield.FromYaml(yamlPath).Build());
        services.AddSingleton<IAutoFunctionInvocationFilter>(sp =>
            new AgentShieldFilter(sp.GetRequiredService<Shield>()));
        DecorateChatServices(services);
        return services;
    }

    /// <summary>
    /// Register a pre-built <paramref name="shield"/>, an
    /// <see cref="IAutoFunctionInvocationFilter"/> bound to it, and
    /// decorate every already-registered chat service for Stage 1/5
    /// coverage.
    /// </summary>
    public static IServiceCollection AddAgentShieldFilter(this IServiceCollection services, Shield shield)
    {
        if (services == null) throw new ArgumentNullException(nameof(services));
        if (shield == null) throw new ArgumentNullException(nameof(shield));

        services.TryAddSingleton<Shield>(shield);
        services.AddSingleton<IAutoFunctionInvocationFilter>(sp =>
            new AgentShieldFilter(sp.GetRequiredService<Shield>()));
        DecorateChatServices(services);
        return services;
    }

    /// <summary>
    /// Register a Shield built from a chain of <c>.guardrails.yaml</c>
    /// files (merged left → right with leaf-wins semantics), an
    /// <see cref="IAutoFunctionInvocationFilter"/> bound to it, and
    /// decorate every already-registered chat service for Stage 1/5
    /// coverage.
    /// </summary>
    public static IServiceCollection AddAgentShieldFilter(this IServiceCollection services, IReadOnlyList<string> yamlPaths)
    {
        if (services == null) throw new ArgumentNullException(nameof(services));
        if (yamlPaths == null) throw new ArgumentNullException(nameof(yamlPaths));

        services.TryAddSingleton<Shield>(_ => Shield.FromYaml(yamlPaths).Build());
        services.AddSingleton<IAutoFunctionInvocationFilter>(sp =>
            new AgentShieldFilter(sp.GetRequiredService<Shield>()));
        DecorateChatServices(services);
        return services;
    }

    /// <summary>
    /// Walk the service-collection snapshot and decorate
    /// every <see cref="IChatClient"/> / <see cref="IChatCompletionService"/>
    /// descriptor with the canonical Stage 1/5 wrapper. Shares the
    /// decorator builder with <see cref="KernelBuilderExtensions"/>
    /// so the two entry points produce byte-equivalent wrapping.
    /// </summary>
    private static void DecorateChatServices(IServiceCollection services)
    {
        for (int i = 0; i < services.Count; i++)
        {
            var d = services[i];
            if (d.ServiceType == typeof(IChatClient))
            {
                services[i] = ChatServiceDecorator.WrapDescriptor<IChatClient>(d,
                    (inner, shield) => new GuardedChatClient(inner, shield));
            }
            else if (d.ServiceType == typeof(IChatCompletionService))
            {
                services[i] = ChatServiceDecorator.WrapDescriptor<IChatCompletionService>(d,
                    (inner, shield) => new GuardedChatCompletionService(inner, shield));
            }
        }
    }
}

