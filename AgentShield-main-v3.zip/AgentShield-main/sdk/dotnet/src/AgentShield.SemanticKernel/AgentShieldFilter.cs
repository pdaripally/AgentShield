using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.SemanticKernel;

using AgentShield;

namespace AgentShield.SemanticKernel;

/// <summary>
/// Semantic Kernel auto-function-invocation filter that enforces
/// Agent Shield guardrails on every kernel function call.
/// Stage 2 + 3 are run before invocation (with the parameter map);
/// Stage 4 is run on the result.
///
/// <para>
/// The filter expects a <see cref="GuardrailsSession"/> per turn —
/// callers should pass one in via the constructor or assign it via
/// <see cref="CurrentSession"/>. When no session is set the filter is
/// a no-op.
/// </para>
/// </summary>
public sealed class AgentShieldFilter : IAutoFunctionInvocationFilter
{
    private readonly GuardrailsRuntime _runtime;
    private readonly Shield? _shield;
    private readonly Action<PendingResolution>? _pendingResolutionSink;
    private readonly System.Threading.AsyncLocal<GuardrailsSession?> _current = new();

    public AgentShieldFilter(GuardrailsRuntime runtime)
        : this(runtime, pendingResolutionSink: null)
    {
    }

    /// <summary>
    /// Construct over a raw <see cref="GuardrailsRuntime"/>
    /// with an optional <paramref name="pendingResolutionSink"/> that
    /// receives the structured suspension envelope on every Stage 2/3
    /// block whose verdict carries one. Sessions are minted per call
    /// from the runtime; without a bound <see cref="Shield"/> there
    /// is no canonical latch to push into, so the sink is the
    /// primary push-side surface for this constructor shape.
    /// </summary>
    public AgentShieldFilter(GuardrailsRuntime runtime, Action<PendingResolution>? pendingResolutionSink)
    {
        _runtime = runtime ?? throw new ArgumentNullException(nameof(runtime));
        _shield = null;
        _pendingResolutionSink = pendingResolutionSink;
    }

    /// <summary>
    /// Construct the filter bound to a <see cref="Shield"/> so the
    /// filter shares the Shield's <see cref="GuardrailsSession"/>
    /// state. This is the natural DI shape — register
    /// <see cref="Shield"/> as a singleton and the container injects
    /// it here automatically. State set on <c>shield.Session</c> by
    /// upstream code (e.g.
    /// <c>shield.Session.SetVariable("authorized", true)</c>) is
    /// visible to Stage 2/3/4 evaluations.
    ///
    /// <para>
    /// Per-call session resolution falls back through:
    /// </para>
    /// <list type="number">
    ///   <item><description>explicit <see cref="CurrentSession"/></description></item>
    ///   <item><description><see cref="Shield.CurrentSession"/> ambient (set by <c>shield.RunAsync</c> turn brackets)</description></item>
    ///   <item><description><c>shield.Session</c> (the bound Shield's per-instance session)</description></item>
    /// </list>
    /// </summary>
    public AgentShieldFilter(Shield shield)
        : this(shield, pendingResolutionSink: null)
    {
    }

    /// <summary>
    /// Construct bound to a <see cref="Shield"/> with
    /// an optional <paramref name="pendingResolutionSink"/> that
    /// receives the structured <see cref="PendingResolution"/>
    /// envelope on every Stage 2/3 block whose verdict carries one.
    /// The same envelope is always latched on
    /// <see cref="Shield.LastPendingResolution"/> regardless of
    /// whether a sink is supplied; the sink is an additional callback
    /// channel for push-style consumers (UI renderers, approval
    /// queues, etc.).
    ///
    /// <para>
    /// Cross-SDK parity with the Python adapter's
    /// <c>pending_resolution_sink</c> kwarg and the Node
    /// adapter's <c>pendingResolutionSink</c> option.
    /// </para>
    /// </summary>
    public AgentShieldFilter(Shield shield, Action<PendingResolution>? pendingResolutionSink)
    {
        _shield = shield ?? throw new ArgumentNullException(nameof(shield));
        _runtime = shield.Runtime;
        _pendingResolutionSink = pendingResolutionSink;
    }

    /// <summary>
    /// The <see cref="GuardrailsRuntime"/> this filter enforces against.
    /// Exposed so callers (e.g. <c>ShieldExtensions.AttachFilter</c>)
    /// can detect when a filter for the same runtime is already
    /// registered on a kernel and avoid double-registration.
    /// </summary>
    public GuardrailsRuntime Runtime => _runtime;

    /// <summary>Per-async-flow session. Assign before invoking the kernel.</summary>
    public GuardrailsSession? CurrentSession
    {
        get => _current.Value;
        set => _current.Value = value;
    }

    public async Task OnAutoFunctionInvocationAsync(
        AutoFunctionInvocationContext context,
        Func<AutoFunctionInvocationContext, Task> next)
    {
        // Resolution priority (highest first):
        //   1. Explicit per-async-flow CurrentSession (host set it).
        //   2. Shield.CurrentSession ambient — set by shield.RunAsync
        //      so a guarded turn's Stage 2/3/4 share state with
        //      Stage 1/5 in the same flow.
        //   3. The bound Shield's session (DI shape: filter was
        //      constructed via AgentShieldFilter(Shield)).
        //   4. Mint a per-call session from the runtime (legacy
        //      AgentShieldFilter(GuardrailsRuntime) shape).
        var session = _current.Value
            ?? Shield.CurrentSession
            ?? _shield?.Session;
        var ownsSession = session is null;
        session ??= _runtime.NewSession();
        await using var lease = Shield.CurrentSession == session
            ? default
            : await session.AcquireTurnLeaseAsync().ConfigureAwait(false);

        try
        {
            // Use the bare function name as the canonical policy
            // identifier. Semantic Kernel exposes a plugin prefix
            // (e.g. "SupportPlugin.OpenJiraTicket") on tools imported
            // via Plugins.AddFromObject(...), but `applies_to.tools`
            // in `.guardrails.yaml` matches exact string names. The
            // CLI-generated YAML and every other AgentShield SDK
            // (Python SK adapter, Rust core, Node) keys policies on
            // the bare function name, so honour that convention here
            // — otherwise a customer-authored policy like
            // `applies_to.tools: ["OpenJiraTicket"]` would silently
            // miss tools registered with a plugin name, and a
            // critical guard policy would be bypassed without any
            // error or warning.
            //
            // The plugin name remains available to host code via
            // `context.Function.PluginName`; we intentionally do not
            // attempt fancier matching (e.g. accepting either form)
            // because that would create two equally-valid spellings
            // of the same policy target and make YAML provenance
            // ambiguous across SDKs.
            var toolName = context.Function.Name;

            // Build a JSON object of the arguments.
            var argsObj = new System.Collections.Generic.Dictionary<string, object?>();
            if (context.Arguments is not null)
            {
                foreach (var arg in context.Arguments)
                    argsObj[arg.Key] = arg.Value;
            }
            var argsJson = JsonSerializer.Serialize(argsObj);
            using var argsDoc = JsonDocument.Parse(argsJson);

            // binding — SK's AutoFunctionInvocationContext does
            // not surface a per-invocation handle; mint a stable
            // per-call id so Stage 3 → Stage 4 bind to the same
            // canonical invocation under concurrent same-name calls.
            var boundId = Guid.NewGuid().ToString("N");

            var (verdict, mutated, admissionId) = session!.ValidateToolCall(toolName, argsDoc.RootElement.Clone(), boundId);
            if (!verdict.Allowed)
            {
                SurfacePendingResolution(verdict.PendingResolution);
                context.Result = new FunctionResult(
                    context.Function,
                    $"[Blocked by Agent Shield] {verdict.Reason ?? "policy violation"}",
                    metadata: BuildFunctionResultMetadata(verdict.PendingResolution));
                context.Terminate = true;
                return;
            }

            // Project Stage-3 mutated arguments back into context.Arguments
            // so the underlying SK function receives the redacted values.
            // Fail closed: if we can't reconcile, skip the call with a
            // synthetic block verdict rather than passing raw arguments.
            if (context.Arguments is not null
                && mutated.ValueKind == JsonValueKind.Object
                && !ArgumentsRoundtripEqual(argsDoc.RootElement, mutated))
            {
                try
                {
                    foreach (var prop in mutated.EnumerateObject())
                    {
                        context.Arguments[prop.Name] = JsonElementToObject(prop.Value);
                    }
                }
                catch (Exception ex)
                {
                    context.Result = new FunctionResult(
                        context.Function,
                        $"[Blocked by Agent Shield] failed to apply redaction: {ex.Message}");
                    context.Terminate = true;
                    return;
                }
            }

            await next(context).ConfigureAwait(false);

            var resultObj = context.Result?.GetValue<object?>();
            var resultJson = JsonSerializer.Serialize(resultObj);
            using var resultDoc = JsonDocument.Parse(resultJson);
            if (!admissionId.HasValue) return;
            var (outVerdict, outMutated) = session!.ValidateToolOutput(admissionId.Value, resultDoc.RootElement.Clone());
            if (!outVerdict.Allowed)
            {
                SurfacePendingResolution(outVerdict.PendingResolution);
                context.Result = new FunctionResult(
                    context.Function,
                    $"[Blocked by Agent Shield] {outVerdict.Reason ?? "policy violation"}",
                    metadata: BuildFunctionResultMetadata(outVerdict.PendingResolution));
                // Stage 4 MUST terminate the auto-invocation loop the
                // same way Stage 2/3 does.
                // Without this the SK loop continues iterating with
                // the block string as the observed tool result and
                // gives the model a chance to narrate around the gate.
                context.Terminate = true;
                return;
            }
            if (outMutated.GetRawText() != resultJson)
            {
                context.Result = new FunctionResult(context.Function, outMutated.GetRawText());
            }
        }
        finally
        {
            if (ownsSession) session?.Dispose();
        }
    }

    /// <summary>
    /// Compare a freshly-serialized arguments JsonElement to the
    /// runtime's mutated copy. Equal raw text means no Stage-3 transform
    /// fired, so we can skip the projection back into KernelArguments.
    /// </summary>
    private static bool ArgumentsRoundtripEqual(JsonElement original, JsonElement mutated)
    {
        return original.GetRawText() == mutated.GetRawText();
    }

    /// <summary>
    /// Push the structured suspension envelope to the
    /// bound <see cref="Shield"/>'s latch (when present) and fire the
    /// optional host-supplied sink. Called on every Stage 2/3 / Stage 4
    /// deny whose verdict carries one. Sink exceptions are swallowed —
    /// the canonical surfacing path is the Shield latch, and a
    /// misbehaving host callback must never break the guardrail
    /// pipeline.
    /// </summary>
    private void SurfacePendingResolution(PendingResolution? pending)
    {
        if (pending is null) return;
        _shield?.CapturePendingResolution(pending);
        if (_pendingResolutionSink is null) return;
        try { _pendingResolutionSink(pending); }
        catch { /* swallow — see method-level docs */ }
    }

    /// <summary>
    /// Build the SK <see cref="FunctionResult.Metadata"/> bag for a
    /// denied invocation. When the verdict carries a
    /// <see cref="PendingResolution"/> envelope, surface it under the
    /// canonical <c>agent_shield.pending_resolution</c> key so SK
    /// hosts can recover the structured shape without
    /// substring-matching the <c>[Blocked by Agent Shield]...</c>
    /// reason string. Returns <c>null</c> for non-suspension denies
    /// so those results keep their unadorned shape.
    /// </summary>
    private static IReadOnlyDictionary<string, object?>? BuildFunctionResultMetadata(PendingResolution? pending)
    {
        if (pending is null) return null;
        return new Dictionary<string, object?>(System.StringComparer.Ordinal)
        {
            ["agent_shield.pending_resolution"] = pending,
        };
    }

    /// <summary>
    /// Convert a JsonElement to a CLR object suitable for storing into a
    /// <see cref="KernelArguments"/> value slot. Mirrors SK's parameter
    /// conventions: scalars unboxed, objects/arrays kept as JsonElement.
    /// </summary>
    private static object? JsonElementToObject(JsonElement el)
    {
        return el.ValueKind switch
        {
            JsonValueKind.Null => null,
            JsonValueKind.True => true,
            JsonValueKind.False => false,
            JsonValueKind.String => el.GetString(),
            JsonValueKind.Number when el.TryGetInt64(out var i) => i,
            JsonValueKind.Number => el.GetDouble(),
            _ => el.Clone(),
        };
    }
}
