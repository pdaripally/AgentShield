using System;
using System.Collections.Generic;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;

using AgentShield;
using AgentShield.AI;

namespace AgentShield.SemanticKernel;

/// <summary>
/// Builder-time Semantic Kernel wire-up. <c>UseAgentShield(...)</c>
/// decorates already-registered chat services for Stage 1/5 and registers
/// <see cref="AgentShieldFilter"/> for Stage 2/3/4 auto-function calls; add
/// chat connectors before this call so the snapshot walk can wrap them.
/// </summary>
public static class KernelBuilderExtensions
{
    /// <summary>
    /// Wire Agent Shield into the kernel pipeline at builder time:
    /// registers a <see cref="Shield"/> singleton constructed from
    /// <paramref name="yamlPath"/>, an
    /// <see cref="IAutoFunctionInvocationFilter"/> for Stage 2/3/4,
    /// and decorates every already-registered
    /// <see cref="IChatClient"/> and
    /// <see cref="IChatCompletionService"/> with the canonical
    /// Stage 1/5 wrapper.
    ///
    /// <para>
    /// Idempotent across multiple calls on the same builder: extra
    /// invocations are no-ops because (a) the Shield singleton uses
    /// <c>TryAddSingleton</c> and (b) chat-service decoration skips
    /// descriptors that are already a Guarded* wrapper for the same
    /// runtime.
    /// </para>
    /// </summary>
    /// <param name="builder">The kernel builder.</param>
    /// <param name="yamlPath">Path to a <c>.guardrails.yaml</c> file.</param>
    public static IKernelBuilder UseAgentShield(this IKernelBuilder builder, string yamlPath)
    {
        if (builder == null) throw new ArgumentNullException(nameof(builder));
        if (yamlPath == null) throw new ArgumentNullException(nameof(yamlPath));

        builder.Services.TryAddSingleton<Shield>(_ => Shield.FromYaml(yamlPath).Build());
        RegisterFilter(builder.Services);
        DecorateChatServices(builder.Services);
        return builder;
    }

    /// <summary>
    /// Wire Agent Shield into the kernel pipeline at builder time,
    /// bound to a pre-built <paramref name="shield"/>. The caller
    /// retains ownership of the Shield (DI does not dispose it).
    /// Also decorates every already-registered
    /// <see cref="IChatClient"/> / <see cref="IChatCompletionService"/>
    /// for Stage 1/5 coverage.
    /// </summary>
    /// <param name="builder">The kernel builder.</param>
    /// <param name="shield">A pre-built Shield instance.</param>
    public static IKernelBuilder UseAgentShield(this IKernelBuilder builder, Shield shield)
    {
        if (builder == null) throw new ArgumentNullException(nameof(builder));
        if (shield == null) throw new ArgumentNullException(nameof(shield));

        builder.Services.TryAddSingleton<Shield>(shield);
        RegisterFilter(builder.Services);
        DecorateChatServices(builder.Services);
        return builder;
    }

    /// <summary>
    /// Build a chain of <c>.guardrails.yaml</c> files and wire the
    /// resulting Shield into the kernel pipeline. See
    /// <see cref="UseAgentShield(IKernelBuilder, string)"/> for the
    /// single-file form.
    /// </summary>
    public static IKernelBuilder UseAgentShield(this IKernelBuilder builder, IReadOnlyList<string> yamlPaths)
    {
        if (builder == null) throw new ArgumentNullException(nameof(builder));
        if (yamlPaths == null) throw new ArgumentNullException(nameof(yamlPaths));

        builder.Services.TryAddSingleton<Shield>(_ => Shield.FromYaml(yamlPaths).Build());
        RegisterFilter(builder.Services);
        DecorateChatServices(builder.Services);
        return builder;
    }

    private static void RegisterFilter(IServiceCollection services)
    {
        services.AddSingleton<IAutoFunctionInvocationFilter>(sp =>
            new AgentShieldFilter(sp.GetRequiredService<Shield>()));
    }

    /// <summary>
    /// Walk the service-collection snapshot and decorate
    /// every registered <see cref="IChatClient"/> and
    /// <see cref="IChatCompletionService"/> descriptor with the
    /// canonical Stage 1/5 wrapper. Handles both non-keyed and
    /// keyed (<c>AddOpenAIChatCompletion("svc1", ...)</c>)
    /// registrations.
    ///
    /// <para>
    /// Iterates by index rather than enumerator so the in-place
    /// replacement is well-defined; the descriptor list is mutated
    /// only at positions whose service type matches.
    /// </para>
    /// </summary>
    private static void DecorateChatServices(IServiceCollection services)
    {
        for (int i = 0; i < services.Count; i++)
        {
            var d = services[i];
            if (d.ServiceType == typeof(IChatClient))
            {
                services[i] = ChatServiceDecorator.WrapDescriptor<IChatClient>(d,
                    (inner, shield) => new GuardedChatClient(inner, shield));
            }
            else if (d.ServiceType == typeof(IChatCompletionService))
            {
                services[i] = ChatServiceDecorator.WrapDescriptor<IChatCompletionService>(d,
                    (inner, shield) => new GuardedChatCompletionService(inner, shield));
            }
        }
    }
}
