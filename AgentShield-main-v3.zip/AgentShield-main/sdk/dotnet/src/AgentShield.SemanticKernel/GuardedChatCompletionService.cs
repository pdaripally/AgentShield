using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;

using AgentShield;

namespace AgentShield.SemanticKernel;

/// <summary>
/// Semantic Kernel <see cref="IChatCompletionService"/> decorator for Stage
/// 1/5 coverage on hosts that do not route through MEAI's
/// <see cref="Microsoft.Extensions.AI.IChatClient"/>. Session resolution
/// matches <see cref="AgentShield.AI.GuardedChatClient"/>; SK tool stages
/// remain handled by <see cref="AgentShieldFilter"/>.
/// </summary>
public sealed class GuardedChatCompletionService : IChatCompletionService
{
    private readonly IChatCompletionService _inner;
    private readonly Shield? _shield;
    private readonly GuardrailsRuntime _runtime;
    private GuardrailsSession? _lazySession;
    private readonly object _lazyLock = new();

    /// <summary>
    /// Construct bound to a <see cref="Shield"/> so the underlying
    /// chat service sees the same <see cref="GuardrailsSession"/> the
    /// host configured via <c>shield.Session.SetVariable(...)</c>.
    /// This is the correct shape for stateful Stage 5 policies that
    /// depend on session variables set upstream of the chat call.
    /// </summary>
    public GuardedChatCompletionService(IChatCompletionService inner, Shield shield)
    {
        _inner = inner ?? throw new ArgumentNullException(nameof(inner));
        _shield = shield ?? throw new ArgumentNullException(nameof(shield));
        _runtime = shield.Runtime;
    }

    /// <summary>
    /// Construct over a raw <see cref="GuardrailsRuntime"/>. A single
    /// lazy session is minted from the runtime on first use and
    /// reused for the lifetime of this client.
    /// </summary>
    public GuardedChatCompletionService(IChatCompletionService inner, GuardrailsRuntime runtime)
    {
        _inner = inner ?? throw new ArgumentNullException(nameof(inner));
        _runtime = runtime ?? throw new ArgumentNullException(nameof(runtime));
        _shield = null;
    }

    /// <summary>The wrapped inner chat service. Exposed so callers can detect double-wrapping.</summary>
    public IChatCompletionService Inner => _inner;

    /// <summary>The runtime this decorator enforces against.</summary>
    public GuardrailsRuntime Runtime => _runtime;

    /// <inheritdoc/>
    public IReadOnlyDictionary<string, object?> Attributes => _inner.Attributes;

    /// <inheritdoc/>
    public async Task<IReadOnlyList<ChatMessageContent>> GetChatMessageContentsAsync(
        ChatHistory chatHistory,
        PromptExecutionSettings? executionSettings = null,
        Kernel? kernel = null,
        CancellationToken cancellationToken = default)
    {
        if (chatHistory == null) throw new ArgumentNullException(nameof(chatHistory));

        var (session, ownsSession) = ResolveSession();
        session.BeginRequest();
        try
        {
            var (blockedReason, userText, effectiveText) = ValidateInput(session, chatHistory);
            if (blockedReason != null)
            {
                return new[]
                {
                    new ChatMessageContent(AuthorRole.Assistant, blockedReason),
                };
            }

            // Spec — forward post-Stage-1 redacted text
            // to the inner chat service. Without this projection the
            // LLM sees the raw user input even when Stage 1 redacted
            // it. Mirrors GuardedChatClient.ApplyStage1Redaction.
            var effectiveHistory = ApplyStage1Redaction(chatHistory, userText, effectiveText);

            var inner = await _inner.GetChatMessageContentsAsync(
                effectiveHistory, executionSettings, kernel, cancellationToken)
                .ConfigureAwait(false);

            // Stage 5: concatenate the assistant text across returned
            // ChatMessageContent items (most providers return one;
            // multi-message returns are concatenated so the verdict
            // observes the full response).
            var assistantText = string.Concat(
                inner.Where(c => c.Role == AuthorRole.Assistant)
                     .Select(c => c.Content ?? string.Empty));
            if (string.IsNullOrEmpty(assistantText)) return inner;

            var (verdict, redacted) = session.ValidateOutput(assistantText);
            if (!verdict.Allowed)
            {
                return new[]
                {
                    new ChatMessageContent(AuthorRole.Assistant,
                        $"[Blocked by Agent Shield] {verdict.Reason ?? "policy violation"}"),
                };
            }
            if (!string.Equals(redacted, assistantText, StringComparison.Ordinal))
            {
                return new[]
                {
                    new ChatMessageContent(AuthorRole.Assistant, redacted),
                };
            }
            return inner;
        }
        finally
        {
            session.EndRequest();
            if (ownsSession) session.Dispose();
        }
    }

    /// <inheritdoc/>
    public async IAsyncEnumerable<StreamingChatMessageContent> GetStreamingChatMessageContentsAsync(
        ChatHistory chatHistory,
        PromptExecutionSettings? executionSettings = null,
        Kernel? kernel = null,
        [EnumeratorCancellation] CancellationToken cancellationToken = default)
    {
        if (chatHistory == null) throw new ArgumentNullException(nameof(chatHistory));

        var (session, ownsSession) = ResolveSession();
        session.BeginRequest();
        try
        {
            var (blockedReason, userText, effectiveText) = ValidateInput(session, chatHistory);
            if (blockedReason != null)
            {
                yield return new StreamingChatMessageContent(AuthorRole.Assistant, blockedReason);
                yield break;
            }

            var effectiveHistory = ApplyStage1Redaction(chatHistory, userText, effectiveText);

            // OnComplete-style buffering: text-bearing chunks are held
            // back from the consumer until the upstream stream
            // completes; the validated/redacted payload is emitted as
            // a single terminal chunk. Mirrors the same cadence used
            // by GuardedChatClient.GetStreamingResponseAsync default
            // (StreamingMode.OnComplete). Non-text-bearing chunks
            // (tool calls, metadata-only) flow through unchanged.
            using var guard = session.StreamingSession(StreamingStage.Output);
            StreamingChatMessageContent? lastBufferedChunk = null;
            var stopped = false;

            await foreach (var chunk in _inner.GetStreamingChatMessageContentsAsync(
                effectiveHistory, executionSettings, kernel, cancellationToken)
                .ConfigureAwait(false))
            {
                var text = chunk.Content ?? string.Empty;
                if (string.IsNullOrEmpty(text))
                {
                    yield return chunk;
                    continue;
                }

                var pushed = guard.Push(text);
                if (pushed.Action == StreamAction.Stop)
                {
                    yield return new StreamingChatMessageContent(AuthorRole.Assistant,
                        $"[GUARDRAIL BLOCK] {pushed.Reason ?? "blocked by policy"}");
                    stopped = true;
                    yield break;
                }
                lastBufferedChunk = chunk;
            }

            if (!stopped)
            {
                var tail = guard.Finish();
                if (tail.Action == StreamAction.Stop)
                {
                    yield return new StreamingChatMessageContent(AuthorRole.Assistant,
                        $"[GUARDRAIL BLOCK] {tail.Reason ?? "blocked by policy"}");
                    yield break;
                }
                var finalText = tail.Payload;
                if (!string.IsNullOrEmpty(finalText))
                {
                    yield return new StreamingChatMessageContent(AuthorRole.Assistant, finalText)
                    {
                        ModelId = lastBufferedChunk?.ModelId,
                    };
                }
            }
        }
        finally
        {
            session.EndRequest();
            if (ownsSession) session.Dispose();
        }
    }

    private (GuardrailsSession Session, bool Owned) ResolveSession()
    {
        if (_shield != null) return (_shield.Session, false);
        var ambient = Shield.CurrentSession;
        if (ambient != null) return (ambient, false);
        if (_lazySession == null)
        {
            lock (_lazyLock)
            {
                _lazySession ??= _runtime.NewSession();
            }
        }
        return (_lazySession, false);
    }

    private static (string? Blocked, string UserText, string EffectiveText) ValidateInput(
        GuardrailsSession session, ChatHistory history)
    {
        ChatMessageContent? lastUser = null;
        for (int i = history.Count - 1; i >= 0; i--)
        {
            if (history[i].Role == AuthorRole.User)
            {
                lastUser = history[i];
                break;
            }
        }
        var text = lastUser?.Content ?? string.Empty;
        if (string.IsNullOrEmpty(text)) return (null, string.Empty, string.Empty);

        var verdict = session.ValidateInput(text);
        if (!verdict.Allowed)
        {
            return (
                $"[Blocked by Agent Shield] {verdict.Reason ?? "policy violation"}",
                text,
                text);
        }
        // Spec — surface the post-Stage-1 effective
        // text so callers forward it to the inner service instead of
        // the raw user input.
        var decision = VerdictDispatcher.DispatchStage(
            verdict, OnBlockPolicy.ReturnBlocked, ShieldMode.Enforce);
        var effective = decision.Action.Kind == "proceed_with_mutation"
            ? decision.Action.Value ?? text
            : text;
        return (null, text, effective);
    }

    private static ChatHistory ApplyStage1Redaction(
        ChatHistory original, string userText, string effectiveText)
    {
        if (string.Equals(userText, effectiveText, StringComparison.Ordinal))
            return original;

        int lastUserIdx = -1;
        for (int i = original.Count - 1; i >= 0; i--)
        {
            if (original[i].Role == AuthorRole.User)
            {
                lastUserIdx = i;
                break;
            }
        }
        if (lastUserIdx < 0) return original;

        var cloned = new ChatHistory();
        for (int i = 0; i < original.Count; i++)
        {
            if (i == lastUserIdx)
            {
                cloned.AddUserMessage(effectiveText);
            }
            else
            {
                cloned.Add(original[i]);
            }
        }
        return cloned;
    }
}
