using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;

using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;

using AgentShield;

namespace AgentShield.SemanticKernel;

/// <summary>
/// Semantic Kernel <see cref="ILlmCaller"/> adapter for guard-policy LLM
/// judges. It resolves the YAML <c>configurations[]</c> entry, maps supported
/// cfg fields into <see cref="PromptExecutionSettings"/> / ExtensionData,
/// calls the configured <see cref="IChatCompletionService"/>, and parses the
/// reply as the <see cref="LlmResponse"/> JSON wire shape.
/// </summary>
public sealed class SKLlmCaller : ILlmCaller
{
    private readonly IChatCompletionService _chatService;
    private readonly Kernel? _kernel;
    private GuardrailsRuntime? _runtime;

    public SKLlmCaller(IChatCompletionService chatService, Kernel? kernel = null)
    {
        _chatService = chatService ?? throw new ArgumentNullException(nameof(chatService));
        _kernel = kernel;
    }

    /// <summary>
    /// Bind the caller to a <see cref="GuardrailsRuntime"/> so it can
    /// look up <c>configurations[]</c> entries by id at call time.
    /// Invoked by the <see cref="ShieldExtensions.WithSKLlmJudge"/>
    /// post-build hook. Mirrors the Python
    /// <c>_ConfigurationResolverHolder.bind</c> pattern and the
    /// <see cref="AgentShield.AI.MEAILlmCaller.Bind"/> shape on the
    /// Microsoft.Extensions.AI adapter.
    /// </summary>
    public void Bind(GuardrailsRuntime runtime)
    {
        _runtime = runtime ?? throw new ArgumentNullException(nameof(runtime));
    }

    public LlmResponse Call(LlmRequest request)
    {
        LlmConfiguration? cfg = null;
        if (_runtime != null && !string.IsNullOrEmpty(request.ConfigurationId))
        {
            try
            {
                cfg = _runtime.LlmConfiguration(request.ConfigurationId);
            }
            catch
            {
                // Resolver lookup must never break the LLM caller with an
                // internal error — surface the missing-model condition
                // directly so SREs see a load-time-shaped message rather
                // than a transport failure.
                cfg = null;
            }
        }

        var settings = BuildPromptExecutionSettings(cfg, request.ConfigurationId);

        var history = new ChatHistory();
        history.AddUserMessage(request.Prompt);

        // The Rust core invokes ILlmCaller.Call synchronously — bridge
        // through to the async chat completion service with
        // GetAwaiter().GetResult(). Matches the
        // sync_client.chat.completions.create(...) pattern in the
        // Python adapter and the synchronous bridge in
        // MEAILlmCaller.Call.
        var response = _chatService.GetChatMessageContentsAsync(
                history, settings, _kernel)
            .ConfigureAwait(false)
            .GetAwaiter()
            .GetResult();

        var text = response.Count > 0 ? (response[0].Content ?? string.Empty) : string.Empty;
        return ParseResponse(text);
    }

    /// <summary>
    /// Build a <see cref="PromptExecutionSettings"/> instance that
    /// carries the resolved cfg. Sets
    /// <see cref="PromptExecutionSettings.ModelId"/> directly (the
    /// canonical routing field) and stashes provider-tunable kwargs
    /// in <see cref="PromptExecutionSettings.ExtensionData"/> — every
    /// shipped SK connector parses ExtensionData when constructing
    /// its provider-specific settings.
    ///
    /// <para>
    /// Throws <see cref="ConfigurationMissingModelException"/> when
    /// the resolved cfg has no <c>Model</c> — a security library MUST
    /// NOT silently rely on the kernel-bound default. The schema
    /// enforces this at load time. — <c>Model</c> is the
    /// identifier passed verbatim to the provider SDK (a model name
    /// for direct OpenAI, a deployment name for Azure OpenAI).
    /// </para>
    /// </summary>
    private PromptExecutionSettings BuildPromptExecutionSettings(LlmConfiguration? cfg, string? configurationId)
    {
        if (cfg == null || string.IsNullOrEmpty(cfg.Model))
        {
            throw new ConfigurationMissingModelException(configurationId);
        }

        var settings = new PromptExecutionSettings();
        settings.ModelId = cfg.Model!;

        if (cfg.MaxTokens.HasValue)
        {
            // `max_tokens` is the canonical provider-tunable
            // kwarg. Every SK chat connector parses ExtensionData for
            // this key when materialising its concrete settings type.
            settings.ExtensionData ??= new Dictionary<string, object>();
            settings.ExtensionData["max_tokens"] = (int)cfg.MaxTokens.Value;
        }

        return settings;
    }

    private static LlmResponse ParseResponse(string text)
    {
        if (string.IsNullOrWhiteSpace(text))
        {
            return LlmResponse.Allow(reason: "");
        }

        // The judge LLM is expected to return a JSON verdict matching
        // the LlmResponse wire shape. If parsing fails, treat the
        // text as a free-form rationale and default to allow — the
        // guard-policy engine still gets the reason via the envelope.
        try
        {
            using var doc = JsonDocument.Parse(text);
            if (doc.RootElement.ValueKind != JsonValueKind.Object)
            {
                return LlmResponse.Allow(reason: text);
            }

            var root = doc.RootElement;
            string decision = "allow";
            if (root.TryGetProperty("decision", out var decisionEl) && decisionEl.ValueKind == JsonValueKind.String)
            {
                decision = decisionEl.GetString() ?? "allow";
            }

            double confidence = 1.0;
            if (root.TryGetProperty("confidence", out var confidenceEl) && confidenceEl.ValueKind == JsonValueKind.Number)
            {
                confidence = confidenceEl.GetDouble();
            }

            string? reason = null;
            if (root.TryGetProperty("reason", out var reasonEl) && reasonEl.ValueKind == JsonValueKind.String)
            {
                reason = reasonEl.GetString();
            }

            List<string>? categories = null;
            if (root.TryGetProperty("categories", out var catsEl) && catsEl.ValueKind == JsonValueKind.Array)
            {
                categories = new List<string>();
                foreach (var c in catsEl.EnumerateArray())
                {
                    if (c.ValueKind == JsonValueKind.String)
                        categories.Add(c.GetString() ?? "");
                }
            }

            Dictionary<string, bool>? boolFlags = null;
            if (root.TryGetProperty("bool_flags", out var flagsEl) && flagsEl.ValueKind == JsonValueKind.Object)
            {
                boolFlags = new Dictionary<string, bool>();
                foreach (var kv in flagsEl.EnumerateObject())
                {
                    if (kv.Value.ValueKind == JsonValueKind.True || kv.Value.ValueKind == JsonValueKind.False)
                        boolFlags[kv.Name] = kv.Value.GetBoolean();
                }
            }

            return new LlmResponse(decision, confidence, reason, categories, boolFlags);
        }
        catch (JsonException)
        {
            return LlmResponse.Allow(reason: text);
        }
    }
}
