# AgentShield.SemanticKernel mediation

## Mediated paths
- `WithSemanticKernel(kernel)` installs the SK integration at `sdk/dotnet/src/AgentShield.SemanticKernel/ShieldExtensions.cs:48`.
- `AttachFilter(kernel)` registers `AgentShieldFilter` at `sdk/dotnet/src/AgentShield.SemanticKernel/ShieldExtensions.cs:72`.
- `AgentShieldFilter` mediates function invocation around `IAutoFunctionInvocationFilter` at `sdk/dotnet/src/AgentShield.SemanticKernel/AgentShieldFilter.cs:23`.

## Unsupported paths
- Direct kernel function invocation without the filter attached.
- Any plugin/function path that bypasses `IAutoFunctionInvocationFilter`.
- Non-SK tool/agent loops; this DLL only owns the Semantic Kernel middleware contract.

## Bypass risks
- Building a kernel without registering the filter on every execution path.
- Holding raw `KernelFunction` references and invoking them outside the filtered kernel.
- Assuming adapter-owned mediation on framework surfaces that never pass through the SK filter.

## Streaming behavior
- Rule 1 — ✓ the capability report claims SK streaming output coverage on the filtered path.
- Rule 2 — ✓ bounded buffering/windowing is delegated to the core streaming guard when the filtered path streams text.
- Rule 3 — ✓ shared `StreamingGuard.Push()` / `Finish()` now emit `incident.stream_aborted` on policy stop verdicts.
- Rule 4 — ✓ the shared `StreamingGuard` now emits `incident.stream_limit_exceeded` when the stream hits the core buffer bound.
- Rule 5 — ✓ not applicable on this surface; Stage-4 tool/result binding still uses the normal function-invocation path rather than streamed tool chunks.

## Unknown tool-call shapes
- `AgentShieldFilter` works on SK's typed invocation/result objects; unknown invocation shapes outside that contract are not yet surfaced as `incident.unknown_invocation_shape`.

## See also

See [Post-tool limits and dangerous patterns](../../../../docs/POST_TOOL_LIMITS.md) and the [adapter-mediated path matrix](../../../../docs/adapter-mediated-paths.md).
