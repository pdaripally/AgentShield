using System;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.SemanticKernel.ChatCompletion;

using AgentShield;
using AgentShield.AI;

namespace AgentShield.SemanticKernel;

/// <summary>
/// Shared descriptor-rewriting helpers that wrap any
/// already-registered <see cref="IChatClient"/> /
/// <see cref="IChatCompletionService"/> with the canonical Stage 1/5
/// guard. Used by both <see cref="KernelBuilderExtensions"/>
/// (<c>builder.UseAgentShield(...)</c>) and
/// <see cref="ServiceCollectionExtensions"/>
/// (<c>services.AddAgentShieldFilter(...)</c>) so the two entry
/// points produce byte-equivalent wrapping.
///
/// <para>
/// Decoration walks the snapshot at the call site; chat services
/// registered AFTER the AgentShield call will not be decorated.
/// This matches the contract of every other SK middleware
/// (logging, telemetry).
/// </para>
/// </summary>
internal static class ChatServiceDecorator
{
    /// <summary>
    /// Build a replacement <see cref="ServiceDescriptor"/> that
    /// resolves the original instance via the same factory /
    /// implementation-type / instance shape the customer registered,
    /// then wraps it with <paramref name="wrap"/> bound to the
    /// container's <see cref="Shield"/>. Preserves the original
    /// service lifetime and keyed-service key (if any).
    /// </summary>
    public static ServiceDescriptor WrapDescriptor<T>(
        ServiceDescriptor original,
        Func<T, Shield, T> wrap) where T : class
    {
        if (original.IsKeyedService)
        {
            return new ServiceDescriptor(
                typeof(T),
                original.ServiceKey,
                (sp, key) =>
                {
                    var inner = (T)ResolveKeyedOriginal(sp, key, original);
                    if (IsAlreadyGuarded(inner)) return inner;
                    var shield = sp.GetRequiredService<Shield>();
                    return wrap(inner, shield);
                },
                original.Lifetime);
        }
        return new ServiceDescriptor(
            typeof(T),
            sp =>
            {
                var inner = (T)ResolveOriginal(sp, original);
                if (IsAlreadyGuarded(inner)) return inner;
                var shield = sp.GetRequiredService<Shield>();
                return wrap(inner, shield);
            },
            original.Lifetime);
    }

    /// <summary>
    /// Idempotency guard so a second AgentShield wire-up call (or
    /// a customer that pre-wrapped the chat service manually) does
    /// not double-wrap. Double-wrapping would re-validate the same
    /// text against Stage 1/5 twice per call, doubling latency and
    /// potentially emitting duplicate incidents.
    /// </summary>
    public static bool IsAlreadyGuarded(object instance) =>
        instance is GuardedChatClient || instance is GuardedChatCompletionService;

    private static object ResolveOriginal(IServiceProvider sp, ServiceDescriptor original)
    {
        if (original.ImplementationInstance is { } inst) return inst;
        if (original.ImplementationFactory is { } factory) return factory(sp);
        if (original.ImplementationType is { } implType)
            return ActivatorUtilities.CreateInstance(sp, implType);
        throw new InvalidOperationException(
            $"AgentShield: cannot resolve original {original.ServiceType.Name} " +
            "registration (no instance, factory, or implementation type).");
    }

    private static object ResolveKeyedOriginal(
        IServiceProvider sp, object? key, ServiceDescriptor original)
    {
        if (original.KeyedImplementationInstance is { } inst) return inst;
        if (original.KeyedImplementationFactory is { } factory) return factory(sp, key);
        if (original.KeyedImplementationType is { } implType)
            return ActivatorUtilities.CreateInstance(sp, implType);
        throw new InvalidOperationException(
            $"AgentShield: cannot resolve original keyed {original.ServiceType.Name} " +
            $"registration (key={key}; no instance, factory, or implementation type).");
    }
}
