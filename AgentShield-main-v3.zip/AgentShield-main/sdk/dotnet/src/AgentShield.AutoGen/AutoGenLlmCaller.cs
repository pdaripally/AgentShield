using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

using AutoGen.Core;

using AgentShield;

namespace AgentShield.AutoGen;

/// <summary>
/// AutoGen .NET <see cref="ILlmCaller"/> adapter for guard-policy LLM judges.
/// It resolves YAML cfg, forwards AutoGen-supported options, calls the bound
/// <see cref="IAgent"/>, and parses <see cref="LlmResponse"/> JSON. AutoGen
/// binds models at agent construction time, so per-call <c>model:</c> routing
/// is intentionally left to the pre-bound agent.
/// </summary>
public sealed class AutoGenLlmCaller : ILlmCaller
{
    private readonly IAgent _agent;
    private GuardrailsRuntime? _runtime;

    public AutoGenLlmCaller(IAgent agent)
    {
        _agent = agent ?? throw new ArgumentNullException(nameof(agent));
    }

    /// <summary>
    /// Bind the caller to a <see cref="GuardrailsRuntime"/> so it can
    /// look up <c>configurations[]</c> entries by id at call time.
    /// Invoked by the
    /// <see cref="ShieldExtensions.WithAutoGenLlmJudge"/> post-build
    /// hook. Mirrors the Python
    /// <c>_ConfigurationResolverHolder.bind</c> pattern.
    /// </summary>
    public void Bind(GuardrailsRuntime runtime)
    {
        _runtime = runtime ?? throw new ArgumentNullException(nameof(runtime));
    }

    public LlmResponse Call(LlmRequest request)
    {
        LlmConfiguration? cfg = null;
        if (_runtime != null && !string.IsNullOrEmpty(request.ConfigurationId))
        {
            try
            {
                cfg = _runtime.LlmConfiguration(request.ConfigurationId);
            }
            catch
            {
                // Resolver lookup must never break the LLM caller —
                // fall through to the documented fallback path.
                cfg = null;
            }
        }

        var options = BuildOptions(cfg);
        var messages = new IMessage[] { new TextMessage(Role.User, request.Prompt, "agent_shield") };

        // The Rust core invokes ILlmCaller.Call synchronously — bridge
        // through to the async agent reply with
        // GetAwaiter().GetResult(). Matches the
        // sync_client.chat.completions.create(...) pattern in the
        // Python adapter and the synchronous bridge in
        // MEAILlmCaller / SKLlmCaller.
        var reply = _agent.GenerateReplyAsync(messages, options, CancellationToken.None)
            .ConfigureAwait(false)
            .GetAwaiter()
            .GetResult();

        var text = reply?.GetContent() ?? string.Empty;
        return ParseResponse(text);
    }

    /// <summary>
    /// Build a <see cref="GenerateReplyOptions"/> envelope from the
    /// resolved cfg. Returns <c>null</c> when no cfg matched and no
    /// options need to be sent — AutoGen then uses the agent's
    /// construction-time defaults.
    ///
    /// <para>
    /// <see cref="LlmConfiguration.Model"/> is intentionally NOT
    /// applied — see class docstring. <c>temperature</c> is applied
    /// opportunistically (today only via the
    /// <see cref="LlmConfiguration.Metadata"/> / <c>provider_config</c>
    /// envelope since the FFI doesn't surface a typed
    /// <c>temperature</c> field yet; we read it best-effort from
    /// those JSON blobs to forward when the customer declares it).
    /// </para>
    /// </summary>
    private static GenerateReplyOptions? BuildOptions(LlmConfiguration? cfg)
    {
        if (cfg == null) return null;

        var options = new GenerateReplyOptions();
        var any = false;

        if (cfg.MaxTokens.HasValue)
        {
            options.MaxToken = (int)cfg.MaxTokens.Value;
            any = true;
        }

        // temperature / top_p / presence_penalty / etc. are
        // "applied opportunistically". The current FFI surface only
        // exposes typed `max_tokens`; provider-tunable kwargs live
        // under `metadata` or `provider_config` as free-form JSON.
        // Best-effort read of `temperature` from those envelopes so
        // customers who declare it get it forwarded.
        var temperature = ReadFloatProperty(cfg.Metadata, "temperature")
            ?? ReadFloatProperty(cfg.ProviderConfig, "temperature");
        if (temperature.HasValue)
        {
            options.Temperature = temperature.Value;
            any = true;
        }

        return any ? options : null;
    }

    private static float? ReadFloatProperty(JsonElement? element, string propertyName)
    {
        if (element == null) return null;
        var el = element.Value;
        if (el.ValueKind != JsonValueKind.Object) return null;
        if (!el.TryGetProperty(propertyName, out var prop)) return null;
        if (prop.ValueKind != JsonValueKind.Number) return null;
        try
        {
            return (float)prop.GetDouble();
        }
        catch
        {
            return null;
        }
    }

    private static LlmResponse ParseResponse(string text)
    {
        if (string.IsNullOrWhiteSpace(text))
        {
            return LlmResponse.Allow(reason: "");
        }

        // The judge LLM is expected to return a JSON verdict matching
        // the LlmResponse wire shape. If parsing fails, treat the
        // text as a free-form rationale and default to allow — the
        // guard-policy engine still gets the reason via the envelope.
        try
        {
            using var doc = JsonDocument.Parse(text);
            if (doc.RootElement.ValueKind != JsonValueKind.Object)
            {
                return LlmResponse.Allow(reason: text);
            }

            var root = doc.RootElement;
            string decision = "allow";
            if (root.TryGetProperty("decision", out var decisionEl) && decisionEl.ValueKind == JsonValueKind.String)
            {
                decision = decisionEl.GetString() ?? "allow";
            }

            double confidence = 1.0;
            if (root.TryGetProperty("confidence", out var confidenceEl) && confidenceEl.ValueKind == JsonValueKind.Number)
            {
                confidence = confidenceEl.GetDouble();
            }

            string? reason = null;
            if (root.TryGetProperty("reason", out var reasonEl) && reasonEl.ValueKind == JsonValueKind.String)
            {
                reason = reasonEl.GetString();
            }

            List<string>? categories = null;
            if (root.TryGetProperty("categories", out var catsEl) && catsEl.ValueKind == JsonValueKind.Array)
            {
                categories = new List<string>();
                foreach (var c in catsEl.EnumerateArray())
                {
                    if (c.ValueKind == JsonValueKind.String)
                        categories.Add(c.GetString() ?? "");
                }
            }

            Dictionary<string, bool>? boolFlags = null;
            if (root.TryGetProperty("bool_flags", out var flagsEl) && flagsEl.ValueKind == JsonValueKind.Object)
            {
                boolFlags = new Dictionary<string, bool>();
                foreach (var kv in flagsEl.EnumerateObject())
                {
                    if (kv.Value.ValueKind == JsonValueKind.True || kv.Value.ValueKind == JsonValueKind.False)
                        boolFlags[kv.Name] = kv.Value.GetBoolean();
                }
            }

            return new LlmResponse(decision, confidence, reason, categories, boolFlags);
        }
        catch (JsonException)
        {
            return LlmResponse.Allow(reason: text);
        }
    }
}
