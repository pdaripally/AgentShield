using System;
using System.Collections.Generic;
using System.Linq;

using AutoGen.Core;

using AgentShield;

namespace AgentShield.AutoGen;

/// <summary>
/// AutoGen <see cref="ShieldBuilder"/> extension that attaches the
/// AutoGen capability profile to the Shield. AutoGen exposes only a
/// turn-level <c>IMiddleware</c> hook, so the unified
/// <see cref="Shield"/> orchestrator drives Stage 1 + Stage 5 via
/// <c>RunAsync</c> and tools must be guarded explicitly with
/// <c>ProtectToolAsync</c> (or the existing <see cref="ToolProtection"/>
/// helpers).
///
/// <example>
/// Drop-in usage:
/// <code>
/// using var shield = Shield.FromYaml("guardrails.yaml")
///     .WithAutoGen()
///     .Build();
/// var reply = await shield.RunAsync(userInput, () =&gt; agent.GenerateReplyAsync(messages));
/// </code>
/// </example>
/// </summary>
public static class ShieldExtensions
{
    /// <summary>
    /// Honest capability profile for AutoGen — Stage 1 + Stage 5 are
    /// fully covered through <c>RunAsync</c>; Stage 2/3/4 require
    /// explicit per-tool wrapping (no per-tool middleware hook in
    /// AutoGen) so we report Partial there.
    /// </summary>
    public static readonly CapabilityReport CapabilityReport = new(
        framework: "autogen",
        inputValidation: CoverageLevel.Full,
        stateValidation: CoverageLevel.Partial,
        toolAuthorization: CoverageLevel.Partial,
        toolExecutionValidation: CoverageLevel.Partial,
        toolOutputValidation: CoverageLevel.Partial,
        outputValidation: CoverageLevel.Full,
        streamingOutput: CoverageLevel.Unsupported,
        notes: new[]
        {
            "AutoGen does not surface a per-tool middleware hook — Stage 2/3/4 require explicit ProtectToolAsync calls in the tool body.",
            "Streaming output is not currently driven through this Shield surface; use the existing AgentShieldMiddleware path if needed.",
        });

    /// <summary>
    /// Attach the AutoGen capability profile to this builder. The
    /// resulting Shield exposes <see cref="Shield.RunAsync{TResult}"/>
    /// for Stage 1 + Stage 5 enforcement around an AutoGen agent's
    /// generate-reply call.
    /// </summary>
    public static ShieldBuilder WithAutoGen(this ShieldBuilder builder)
    {
        if (builder == null) throw new ArgumentNullException(nameof(builder));
        return builder.WithCapability(CapabilityReport);
    }

    /// <summary>
    /// Register an AutoGen <see cref="IAgent"/> as the guard-policy LLM judge.
    /// YAML cfg options that AutoGen exposes are applied per call; <c>model:</c>
    /// routing remains bound to the supplied agent instance.
    /// </summary>
    public static ShieldBuilder WithAutoGenLlmJudge(
        this ShieldBuilder builder,
        IAgent judgeAgent)
    {
        if (builder == null) throw new ArgumentNullException(nameof(builder));
        if (judgeAgent == null) throw new ArgumentNullException(nameof(judgeAgent));
        var caller = new AutoGenLlmCaller(judgeAgent);
        return builder
            .WithLlm(caller)
            .WithPostBuildHook(rt => caller.Bind(rt));
    }

    /// <summary>
    /// Wrap an AutoGen <see cref="IAgent"/> with <see cref="AgentShieldMiddleware"/>
    /// so every reply flows through all five stages. In group chats, Stage 5
    /// redaction/blocking happens before the team manager forwards the message
    /// to downstream participants.
    /// </summary>
    public static IAgent WrapAgent(this Shield shield, IAgent agent)
    {
        if (shield == null) throw new ArgumentNullException(nameof(shield));
        if (agent == null) throw new ArgumentNullException(nameof(agent));
        return agent.RegisterMiddleware(new AgentShieldMiddleware(shield));
    }

    /// <summary>
    /// Wrap every agent in <paramref name="agents"/> with
    /// <see cref="AgentShieldMiddleware"/>. Each returned
    /// <see cref="IAgent"/> applies Stage 1–5 around its
    /// <c>GenerateReplyAsync</c> call.
    ///
    /// <para>
    /// The canonical "wrap every participant in a team" helper.
    /// Hand the result to a
    /// <c>RoundRobinGroupChat</c> / <c>SequentialGroupChat</c> /
    /// custom <c>IGroupChat</c> instead of the raw participants list
    /// to guarantee that intermediate inter-agent text replies are
    /// Stage 5-redacted (and the other four stages enforced) BEFORE
    /// the team manager publishes them to the next participant.
    /// </para>
    /// </summary>
    public static IEnumerable<IAgent> WrapAgents(
        this Shield shield, IEnumerable<IAgent> agents)
    {
        if (shield == null) throw new ArgumentNullException(nameof(shield));
        if (agents == null) throw new ArgumentNullException(nameof(agents));
        return agents.Select(a =>
            a == null
                ? throw new ArgumentException(
                    "Participant list contains a null IAgent.", nameof(agents))
                : shield.WrapAgent(a));
    }
}
