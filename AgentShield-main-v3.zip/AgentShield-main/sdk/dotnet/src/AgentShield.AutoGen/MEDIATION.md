# AgentShield.AutoGen mediation

## Mediated paths
- `WithAutoGen()` installs middleware wiring at `sdk/dotnet/src/AgentShield.AutoGen/ShieldExtensions.cs:57`.
- `AgentShieldMiddleware` mediates AutoGen messages and tool dispatch at `sdk/dotnet/src/AgentShield.AutoGen/AgentShieldMiddleware.cs:55`.

## Unsupported paths
- Direct invocation of the underlying AutoGen tool or middleware chain without `AgentShieldMiddleware`.
- Streaming output; this adapter declares streaming unsupported.
- Tool/message shapes outside the handled `ToolCallMessage`, `ToolCallResultMessage`, and `ToolCallAggregateMessage` cases.

## Bypass risks
- Registering the middleware on some agents but not all.
- Replacing guarded tool handlers with raw handlers after middleware installation.
- Treating unsupported streaming or side-channel messages as mediated.

## Streaming behavior
- Streaming is unsupported on this adapter. Rules 1-5 are not claimed on the shipped surface.

## Unknown tool-call shapes
- Unrecognised AutoGen message kinds fall through to the default text path in `AgentShieldMiddleware`; they do not yet emit `incident.unknown_invocation_shape`.

## See also

See [Post-tool limits and dangerous patterns](../../../../docs/POST_TOOL_LIMITS.md) and the [adapter-mediated path matrix](../../../../docs/adapter-mediated-paths.md).
