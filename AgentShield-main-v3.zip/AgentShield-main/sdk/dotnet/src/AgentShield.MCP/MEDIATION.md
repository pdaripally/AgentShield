# AgentShield.MCP mediation

## Mediated paths
- `ProtectTool(...)` and `ProtectToolOutput(...)` mediate Stage 2/3/4 at `sdk/dotnet/src/AgentShield.MCP/MCPShield.cs:150` and `sdk/dotnet/src/AgentShield.MCP/MCPShield.cs:188`.
- Session-scoped wrapping and server/tool helper surfaces all live in `sdk/dotnet/src/AgentShield.MCP/MCPShield.cs`.

## Unsupported paths
- Inputs before the MCP server boundary and final assistant outputs after the server returns.
- Remote MCP servers or raw server callables not wrapped by `MCPShield`.
- Any direct use of the raw callable after the wrapper is installed.

## Bypass risks
- Leaving raw callables reachable beside wrapped ones.
- Replacing wrapped callables in the registry after setup.
- Reusing connection-scoped state where call-scoped isolation is required.

## Streaming behavior
- The .NET MCP integration does not expose streamed Stage-4/5 surfaces. Rules 1-5 are not applicable.

## Unknown tool-call shapes
- `toolCallId` is mandatory and malformed JSON fails at the helper boundary, but unexpected host-side call shapes are not yet surfaced as `incident.unknown_invocation_shape`.

## See also

See [Post-tool limits and dangerous patterns](../../../../docs/POST_TOOL_LIMITS.md) and the [adapter-mediated path matrix](../../../../docs/adapter-mediated-paths.md).
