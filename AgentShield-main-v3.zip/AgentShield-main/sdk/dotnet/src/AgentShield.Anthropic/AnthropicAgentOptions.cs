using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

using Anthropic.SDK;
using Anthropic.SDK.Messaging;

using AnthropicTool = Anthropic.SDK.Common.Tool;

namespace AgentShield.Anthropic;

/// <summary>
/// Tool dispatcher signature used by
/// <see cref="ShieldAnthropicHelpers.RunAnthropicAgentAsync"/>. Receives the
/// tool name (as referenced by guardrails policy) and the
/// (post-Stage-3) JSON arguments the model produced for this
/// <c>tool_use</c> block; returns the raw tool output as a string.
/// </summary>
public delegate Task<string> AnthropicDispatchTool(
    string toolName,
    JsonElement arguments,
    CancellationToken cancellationToken);

/// <summary>
/// Options for <see cref="ShieldAnthropicHelpers.RunAnthropicAgentAsync"/>.
/// Mirrors the shape of the Node <c>runAnthropicAgent</c> options
/// object so the surface is stable across SDKs.
/// </summary>
public sealed class AnthropicAgentOptions
{
    /// <summary>
    /// The Anthropic Messages client. Either an
    /// <see cref="IAnthropicMessagesClient"/> (for testability) or
    /// supply <see cref="AnthropicClient"/> via the
    /// <c>ClientNative</c> property — the helper auto-wraps it.
    /// At least one of <see cref="Client"/> / <see cref="ClientNative"/>
    /// must be set.
    /// </summary>
    public IAnthropicMessagesClient? Client { get; set; }

    /// <summary>
    /// Convenience pass-through: a real Anthropic.SDK
    /// <see cref="AnthropicClient"/>. Wrapped automatically via
    /// <see cref="AnthropicMessagesClientAdapter"/> if
    /// <see cref="Client"/> is not set.
    /// </summary>
    public AnthropicClient? ClientNative { get; set; }

    /// <summary>Claude model id (e.g. <c>claude-sonnet-4-20250514</c>).</summary>
    public string Model { get; set; } = "claude-sonnet-4-20250514";

    /// <summary>Conversation messages — same list shape as
    /// <see cref="MessageParameters.Messages"/>. Stage 1 validates the
    /// last user-role message in this list.</summary>
    public IList<Message> Messages { get; set; } = new List<Message>();

    /// <summary>Tools advertised to Claude. Optional. Pass-through to
    /// <see cref="MessageParameters.Tools"/>.</summary>
    public IList<AnthropicTool>? Tools { get; set; }

    /// <summary>Optional system prompt. When set, becomes a single
    /// <see cref="SystemMessage"/> on <see cref="MessageParameters.System"/>.</summary>
    public string? System { get; set; }

    /// <summary>Customer-owned tool dispatcher. Required when
    /// <see cref="Tools"/> is non-empty.</summary>
    public AnthropicDispatchTool? DispatchTool { get; set; }

    /// <summary>Maximum number of model→tool→model iterations before
    /// the loop is cut. Defaults to 10.</summary>
    public int MaxIters { get; set; } = 10;

    /// <summary>
    /// Maximum tokens per model call (hard requirement of the
    /// Anthropic Messages API). Defaults to 4096.
    /// </summary>
    public int MaxTokens { get; set; } = 4096;

    /// <summary>Optional hook to mutate the per-iteration
    /// <see cref="MessageParameters"/> just before it's sent (e.g. set
    /// <c>Temperature</c>, <c>StopSequences</c>, etc.).</summary>
    public Action<MessageParameters>? ConfigureRequest { get; set; }

    internal IAnthropicMessagesClient ResolveClient()
    {
        if (Client != null) return Client;
        if (ClientNative != null) return AnthropicMessagesClientAdapter.From(ClientNative);
        throw new ArgumentException(
            "AnthropicAgentOptions requires Client or ClientNative to be set.");
    }
}
