using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

using Anthropic.SDK.Messaging;

using AgentShield;

using AnthropicTool = Anthropic.SDK.Common.Tool;

namespace AgentShield.Anthropic;

/// <summary>
/// Pattern A helper for the Anthropic Messages API. The helper owns
/// the full agent loop — Stage 1 (input) → for each iteration: model
/// call → Stage 2/3 (tool authorization + arg mutation) → tool
/// dispatch → Stage 4 (post-tool validation) → next iteration → final
/// Stage 5 (output) — and returns the final assistant text (or the
/// canonical <c>[GUARDRAIL ACTION] reason</c> block message).
///
/// <para>
/// Mirrors the Node <c>shield.runAnthropicAgent(opts)</c> entry point
/// and the Python <c>AgentShield(...).create_runner(...).run(...)</c>
/// entry point. The customer's <c>DispatchTool</c> callback handles
/// the actual tool execution — this helper only owns
/// validation, redaction, and the Anthropic message-building shape.
/// </para>
/// </summary>
public static class ShieldAnthropicHelpers
{
    /// <summary>
    /// Run a full Pattern A guarded agent turn against the Anthropic
    /// Messages API.
    ///
    /// <example>
    /// <code>
    /// using var shield = Shield.FromYaml("guardrails.yaml").WithAnthropic().Build();
    /// var reply = await shield.RunAnthropicAgentAsync(new() {
    ///     ClientNative = client, Model = "claude-sonnet-4-20250514",
    ///     Tools = tools, Messages = messages, DispatchTool = dispatch });
    /// </code>
    /// </example>
    /// </summary>
    public static async Task<string> RunAnthropicAgentAsync(
        this Shield shield,
        AnthropicAgentOptions options,
        CancellationToken cancellationToken = default)
    {
        if (shield == null) throw new ArgumentNullException(nameof(shield));
        if (options == null) throw new ArgumentNullException(nameof(options));
        if (options.Messages == null) throw new ArgumentException("Messages is required", nameof(options));
        var hasTools = options.Tools != null && options.Tools.Count > 0;
        if (hasTools && options.DispatchTool == null)
            throw new ArgumentException(
                "DispatchTool is required when Tools is non-empty", nameof(options));

        var client = options.ResolveClient();
        var session = shield.Session;

        // Stage 1 — validate the most recent user message.
        var userInput = ExtractUserInput(options.Messages);
        if (!string.IsNullOrEmpty(userInput))
        {
            var inputVerdict = session.ValidateInput(userInput);
            if (!inputVerdict.Allowed)
            {
                return BlockMessageFormatter.Format(inputVerdict);
            }
        }

        // Working copy of the message history that the loop appends to.
        var working = new List<Message>(options.Messages);
        MessageResponse? lastResponse = null;

        for (int iter = 0; iter < options.MaxIters; iter++)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var parameters = new MessageParameters
            {
                Model = options.Model,
                Messages = working,
                MaxTokens = options.MaxTokens,
            };
            if (hasTools)
            {
                parameters.Tools = new List<AnthropicTool>(options.Tools!);
            }
            if (!string.IsNullOrEmpty(options.System))
            {
                parameters.System = new List<SystemMessage>
                {
                    new SystemMessage(options.System!, cacheControl: null!),
                };
            }
            options.ConfigureRequest?.Invoke(parameters);

            var response = await client
                .GetClaudeMessageAsync(parameters, cancellationToken)
                .ConfigureAwait(false);
            lastResponse = response;

            var blocks = response.Content ?? new List<ContentBase>();
            var toolUses = blocks.OfType<ToolUseContent>().ToList();

            if (toolUses.Count == 0)
            {
                // No tool_use → final assistant turn.
                var finalText = ExtractAssistantText(response);
                return await ApplyStage5Async(session, finalText).ConfigureAwait(false);
            }

            // Append the assistant message verbatim — Anthropic
            // requires the original tool_use blocks in history.
            working.Add(new Message
            {
                Role = RoleType.Assistant,
                Content = new List<ContentBase>(blocks),
            });

            // Dispatch each tool_use block under Stage 2/3/4.
            var resultBlocks = new List<ContentBase>(toolUses.Count);
            foreach (var toolUse in toolUses)
            {
                var resultBlock = await GuardedDispatchAsync(
                    shield, toolUse, options.DispatchTool!, cancellationToken)
                    .ConfigureAwait(false);
                resultBlocks.Add(resultBlock);
            }
            working.Add(new Message
            {
                Role = RoleType.User,
                Content = resultBlocks,
            });

            if (string.Equals(response.StopReason, "end_turn", StringComparison.OrdinalIgnoreCase))
            {
                break;
            }
        }

        // Loop exhausted (or end_turn after a tool_use) — fall back to
        // whatever text the last response carried.
        var tail = ExtractAssistantText(lastResponse);
        return await ApplyStage5Async(session, tail).ConfigureAwait(false);
    }

    // ── Stage 1: extract the most recent user-role text ───────────

    private static string ExtractUserInput(IList<Message> messages)
    {
        if (messages == null || messages.Count == 0) return string.Empty;
        for (int i = messages.Count - 1; i >= 0; i--)
        {
            var m = messages[i];
            if (m == null || m.Role != RoleType.User) continue;
            if (m.Content == null || m.Content.Count == 0) continue;

            // Skip turns whose content is purely tool_result blocks —
            // those are framework-internal, not new user input.
            var hasNonToolResult = m.Content.Any(b => b is not ToolResultContent);
            if (!hasNonToolResult) continue;

            var parts = new List<string>();
            foreach (var block in m.Content)
            {
                if (block is TextContent tc && !string.IsNullOrEmpty(tc.Text))
                {
                    parts.Add(tc.Text);
                }
            }
            if (parts.Count > 0) return string.Join("\n", parts);
        }
        return string.Empty;
    }

    // ── Stage 5: validate / redact final assistant text ───────────

    private static string ExtractAssistantText(MessageResponse? response)
    {
        if (response?.Content == null) return string.Empty;
        var parts = new List<string>();
        foreach (var block in response.Content)
        {
            if (block is TextContent tc && !string.IsNullOrEmpty(tc.Text))
            {
                parts.Add(tc.Text);
            }
        }
        return string.Join("", parts);
    }

    private static async Task<string> ApplyStage5Async(
        GuardrailsSession session,
        string text)
    {
        if (string.IsNullOrEmpty(text))
        {
            return text;
        }
        var (verdict, redacted) = session.ValidateOutput(text);
        if (!verdict.Allowed)
        {
            return BlockMessageFormatter.Format(verdict);
        }
        return await Task.FromResult(redacted ?? text).ConfigureAwait(false);
    }

    // ── Stage 2/3/4: guarded dispatch of a single tool_use block ──

    private static async Task<ContentBase> GuardedDispatchAsync(
        Shield shield,
        ToolUseContent toolUse,
        AnthropicDispatchTool dispatch,
        CancellationToken cancellationToken)
    {
        var name = toolUse.Name ?? string.Empty;
        var id = toolUse.Id ?? string.Empty;
        var inputJson = toolUse.Input?.ToJsonString() ?? "{}";
        JsonElement args;
        try
        {
            args = JsonDocument.Parse(inputJson).RootElement.Clone();
        }
        catch
        {
            args = JsonDocument.Parse("{}").RootElement.Clone();
        }

        var (blocked, output) = await shield.ProtectToolAsync(
            name,
            args,
            mutated => dispatch(name, mutated, cancellationToken),
            cancellationToken).ConfigureAwait(false);

        return ToolResultBlock(id, output, isError: blocked);
    }

    private static ContentBase ToolResultBlock(string toolUseId, string content, bool isError)
    {
        return new ToolResultContent
        {
            ToolUseId = toolUseId,
            Content = new List<ContentBase>
            {
                new TextContent { Text = content ?? string.Empty },
            },
            IsError = isError ? true : (bool?)null,
        };
    }
}
