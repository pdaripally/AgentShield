using System;

using AgentShield;

namespace AgentShield.Anthropic;

/// <summary>
/// Anthropic <see cref="ShieldBuilder"/> extension. Mirrors the Node
/// <c>withAnthropic()</c> capability bundle. Pattern A — i.e. the
/// adapter owns the Messages-API agent loop via
/// <see cref="ShieldAnthropicHelpers.RunAnthropicAgentAsync"/> — gives
/// full Stage 1 → 5 coverage; the generic
/// <see cref="Shield.RunAsync{TResult}"/> drop-in covers Stage 1 +
/// Stage 5 only.
///
/// <example>
/// Pattern A drop-in (≤ 5 lines, full coverage):
/// <code>
/// using var shield = Shield.FromYaml("guardrails.yaml").WithAnthropic().Build();
/// var reply = await shield.RunAnthropicAgentAsync(new() {
///     ClientNative = client, Model = "claude-sonnet-4-20250514",
///     Tools = tools, Messages = messages, DispatchTool = dispatch });
/// </code>
/// </example>
/// </summary>
public static class ShieldExtensions
{
    /// <summary>Honest capability profile for Anthropic.SDK Pattern A.</summary>
    public static readonly CapabilityReport CapabilityReport = new(
        framework: "anthropic_agents",
        inputValidation: CoverageLevel.Full,
        stateValidation: CoverageLevel.Full,
        toolAuthorization: CoverageLevel.Full,
        toolExecutionValidation: CoverageLevel.Full,
        toolOutputValidation: CoverageLevel.Full,
        outputValidation: CoverageLevel.Full,
        // Streaming partial: Anthropic streams text_delta chunks for
        // Stage 5 chunk-level validation, but tool_use blocks are
        // gated by Stage 2/3/4 only once each block completes — we do
        // not emit a streaming variant in this SDK yet.
        streamingOutput: CoverageLevel.Partial,
        notes: new[]
        {
            "Pattern A = full coverage; Pattern C drop-in covers Stage 1+5 only via Shield.RunAsync.",
            "streaming chunk-level Stage-5 covers content_block_delta text only; tool_use blocks gated by Stage 2/3/4 once each block completes",
        });

    /// <summary>Attach the Anthropic capability profile to this builder.</summary>
    public static ShieldBuilder WithAnthropic(this ShieldBuilder builder)
    {
        if (builder == null) throw new ArgumentNullException(nameof(builder));
        return builder.WithCapability(CapabilityReport);
    }
}
