using System.Threading;
using System.Threading.Tasks;

using Anthropic.SDK;
using Anthropic.SDK.Messaging;

namespace AgentShield.Anthropic;

/// <summary>
/// Minimal abstraction over the Anthropic.SDK
/// <see cref="MessagesEndpoint.GetClaudeMessageAsync(MessageParameters, CancellationToken)"/>
/// call. The adapter takes an <see cref="IAnthropicMessagesClient"/>
/// rather than a concrete <see cref="AnthropicClient"/> so the agent
/// loop is unit-testable with a simple mock — the concrete
/// <see cref="MessagesEndpoint"/> is sealed by the upstream SDK and
/// would otherwise force network-level mocking.
///
/// <para>
/// In real-world code, customers call
/// <see cref="AnthropicMessagesClientAdapter"/>.<c>From</c> to wrap an
/// <see cref="AnthropicClient"/> they already created — the
/// <c>RunAnthropicAgentAsync</c> overloads also accept an
/// <see cref="AnthropicClient"/> directly and wrap it implicitly.
/// </para>
/// </summary>
public interface IAnthropicMessagesClient
{
    /// <summary>
    /// Send a non-streaming Messages request to Claude. Mirrors
    /// <see cref="MessagesEndpoint.GetClaudeMessageAsync(MessageParameters, CancellationToken)"/>.
    /// </summary>
    Task<MessageResponse> GetClaudeMessageAsync(
        MessageParameters parameters,
        CancellationToken cancellationToken = default);
}

/// <summary>
/// Default <see cref="IAnthropicMessagesClient"/> implementation that
/// delegates straight to <c>AnthropicClient.Messages.GetClaudeMessageAsync</c>.
/// </summary>
public sealed class AnthropicMessagesClientAdapter : IAnthropicMessagesClient
{
    private readonly AnthropicClient _client;

    /// <summary>Wrap an existing <see cref="AnthropicClient"/>.</summary>
    public AnthropicMessagesClientAdapter(AnthropicClient client)
    {
        _client = client ?? throw new System.ArgumentNullException(nameof(client));
    }

    /// <summary>Convenience factory — equivalent to <c>new AnthropicMessagesClientAdapter(client)</c>.</summary>
    public static IAnthropicMessagesClient From(AnthropicClient client) =>
        new AnthropicMessagesClientAdapter(client);

    /// <inheritdoc />
    public Task<MessageResponse> GetClaudeMessageAsync(
        MessageParameters parameters,
        CancellationToken cancellationToken = default) =>
        _client.Messages.GetClaudeMessageAsync(parameters, cancellationToken);
}
