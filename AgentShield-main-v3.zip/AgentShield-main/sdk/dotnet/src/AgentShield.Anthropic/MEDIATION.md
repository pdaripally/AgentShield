# AgentShield.Anthropic mediation

## Mediated paths
- `WithAnthropic()` installs the capability bundle at `sdk/dotnet/src/AgentShield.Anthropic/ShieldExtensions.cs:49`.
- `RunAnthropicAgentAsync(...)` owns the Anthropic tool loop at `sdk/dotnet/src/AgentShield.Anthropic/AnthropicShieldHelpers.cs:47`.
- Tool-use blocks are mediated where the helper enumerates `ToolUseContent` blocks before dispatch and validates outputs after execution in `sdk/dotnet/src/AgentShield.Anthropic/AnthropicShieldHelpers.cs:106` and `sdk/dotnet/src/AgentShield.Anthropic/AnthropicShieldHelpers.cs:182`.

## Unsupported paths
- Direct use of the underlying Anthropic SDK client.
- Any streaming surface beyond the documented partial text-delta support note in the capability report.
- Tool-call/message block shapes the helper never converts into `ToolUseContent`.

## Bypass risks
- Mixing guarded helper dispatch with raw SDK tool execution.
- Replacing the wrapped tool catalog with raw callbacks mid-run.
- Assuming every content block type is mediated just because `RunAnthropicAgentAsync(...)` is in use.

## Streaming behavior
- Rule 1 — ✓ the documented streaming claim is limited to text-delta/content-block text.
- Rule 2 — ✓ the partial streaming note assumes finite buffering/windowing in the core guard.
- Rule 3 — ✓ shared `StreamingGuard.Push()` / `Finish()` now emit `incident.stream_aborted` on policy stop verdicts.
- Rule 4 — ✓ the shared `StreamingGuard` now emits `incident.stream_limit_exceeded` when the stream hits the core buffer bound.
- Rule 5 — ✗ tool-use / tool-result streaming is not surfaced as invocation-bound Stage-4 chunks on this DLL today.

## Unknown tool-call shapes
- The helper only handles `ToolUseContent` blocks. Other block shapes fall through to the final-text path, so unknown invocation shapes are not yet fail-closed with `incident.unknown_invocation_shape`.

## See also

See [Post-tool limits and dangerous patterns](../../../../docs/POST_TOOL_LIMITS.md) and the [adapter-mediated path matrix](../../../../docs/adapter-mediated-paths.md).
