using System;
using Microsoft.Extensions.AI;

using AgentShield;

namespace AgentShield.AI;

/// <summary>
/// Microsoft.Extensions.AI <see cref="ShieldBuilder"/> extension.
/// Wraps any <see cref="IChatClient"/> implementation with Stage 1 +
/// Stage 5 enforcement (and streaming Stage 5 via the streaming guard).
///
/// <example>
/// Drop-in usage:
/// <code>
/// using var shield = Shield.FromYaml("guardrails.yaml").WithChatClient(client).Build();
/// var guarded = shield.GuardChatClient(client);
/// var response = await guarded.GetResponseAsync(messages);
/// </code>
/// </example>
/// </summary>
public static class ShieldExtensions
{
    /// <summary>Honest capability profile for Microsoft.Extensions.AI.</summary>
    public static readonly CapabilityReport CapabilityReport = new(
        framework: "microsoft.extensions.ai",
        inputValidation: CoverageLevel.Full,
        stateValidation: CoverageLevel.Partial,
        toolAuthorization: CoverageLevel.Partial,
        toolExecutionValidation: CoverageLevel.Partial,
        toolOutputValidation: CoverageLevel.Partial,
        outputValidation: CoverageLevel.Full,
        streamingOutput: CoverageLevel.Full,
        notes: new[]
        {
            "Stage 1 + Stage 5 are driven through GuardedChatClient (or Shield.RunAsync). Tool stages require explicit per-tool wrapping when the host invokes tools manually.",
        });

    /// <summary>
    /// Attach the Microsoft.Extensions.AI capability profile and
    /// stash the inner <see cref="IChatClient"/> so the resulting
    /// Shield can produce a guarded chat client on demand.
    /// </summary>
    public static ShieldBuilder WithChatClient(this ShieldBuilder builder, IChatClient client)
    {
        if (builder == null) throw new ArgumentNullException(nameof(builder));
        if (client == null) throw new ArgumentNullException(nameof(client));
        var bundle = new FrameworkBundle(CapabilityReport, agentBoundary: client);
        return builder.WithBundle(bundle);
    }

    /// <summary>
    /// Produce a <see cref="GuardedChatClient"/> wrapping
    /// <paramref name="client"/> bound to this Shield. The wrapped
    /// client uses <c>shield.Session</c> as its session so state
    /// upstream code sets via <c>shield.Session.SetVariable(...)</c>
    /// is visible to Stage 5 <c>active_if</c> predicates. (Without
    /// this binding the wrapped client would mint a fresh session
    /// per call and stateful policies would silently never activate.)
    /// </summary>
    public static GuardedChatClient GuardChatClient(this Shield shield, IChatClient client)
    {
        if (shield == null) throw new ArgumentNullException(nameof(shield));
        if (client == null) throw new ArgumentNullException(nameof(client));
        return new GuardedChatClient(client, shield);
    }

    /// <summary>
    /// Register an MEAI <see cref="IChatClient"/> as the guard-policy LLM
    /// judge. The adapter binds to runtime <c>configurations[]</c> lookup so
    /// per-stage model/options selection stays YAML-driven.
    /// </summary>
    public static ShieldBuilder WithLlmJudge(
        this ShieldBuilder builder,
        IChatClient judgeClient)
    {
        if (builder == null) throw new ArgumentNullException(nameof(builder));
        if (judgeClient == null) throw new ArgumentNullException(nameof(judgeClient));
        var caller = new MEAILlmCaller(judgeClient);
        return builder
            .WithLlm(caller)
            .WithPostBuildHook(rt => caller.Bind(rt));
    }
}
