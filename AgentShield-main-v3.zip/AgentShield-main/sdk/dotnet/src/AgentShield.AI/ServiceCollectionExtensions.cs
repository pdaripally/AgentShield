using System;
using System.Collections.Generic;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.DependencyInjection;

namespace AgentShield.AI;

/// <summary>
/// DI helpers that register an <see cref="IChatClient"/> through the safe
/// MEAI order: Agent Shield is added before the customer's optional builder
/// configuration, so <c>UseFunctionInvocation()</c> lands inside the guard.
/// The loaded <see cref="Shield"/> is also registered as a singleton.
/// </summary>
public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Registers an <see cref="IChatClient"/> guarded by AgentShield
    /// using a pre-built <see cref="Shield"/>.
    /// </summary>
    /// <param name="services">The DI service collection.</param>
    /// <param name="innerFactory">
    /// Factory producing the un-guarded inner <see cref="IChatClient"/>
    /// (the model gateway — typically Azure OpenAI / OpenAI / Ollama
    /// resolved from configuration).
    /// </param>
    /// <param name="shield">The loaded AgentShield instance.</param>
    /// <param name="configure">
    /// Optional callback for additional middleware (e.g. logging,
    /// caching, <see cref="ChatClientBuilder"/>'s built-in
    /// <c>UseFunctionInvocation()</c>). Invoked AFTER AgentShield is
    /// registered, so any middleware added here lands inside the
    /// AgentShield wrapper — the safety-correct ordering for tool
    /// guarding.
    /// </param>
    /// <param name="lifetime">The lifetime for the chat client itself.</param>
    /// <returns>The <see cref="IServiceCollection"/> for chaining.</returns>
    public static IServiceCollection AddAgentShieldChatClient(
        this IServiceCollection services,
        Func<IServiceProvider, IChatClient> innerFactory,
        Shield shield,
        Action<ChatClientBuilder>? configure = null,
        ServiceLifetime lifetime = ServiceLifetime.Singleton)
        => AddAgentShieldChatClient(services, innerFactory, shield, pendingResolutionSink: null, configure, lifetime);

    /// <summary>
    /// DI overload that additionally threads an optional
    /// <paramref name="pendingResolutionSink"/> through into the
    /// <see cref="GuardedChatClient"/>. The sink receives the
    /// structured <see cref="PendingResolution"/> envelope on every
    /// Stage 2/3 block whose verdict carries one; the same envelope
    /// is always latched on <see cref="Shield.LastPendingResolution"/>
    /// regardless of whether a sink is supplied.
    ///
    /// <para>
    /// Cross-SDK parity with the Python adapter's
    /// <c>pending_resolution_sink</c> kwarg and the Node
    /// adapter's <c>pendingResolutionSink</c> option.
    /// </para>
    /// </summary>
    public static IServiceCollection AddAgentShieldChatClient(
        this IServiceCollection services,
        Func<IServiceProvider, IChatClient> innerFactory,
        Shield shield,
        Action<PendingResolution>? pendingResolutionSink,
        Action<ChatClientBuilder>? configure = null,
        ServiceLifetime lifetime = ServiceLifetime.Singleton)
    {
        if (services is null) throw new ArgumentNullException(nameof(services));
        if (innerFactory is null) throw new ArgumentNullException(nameof(innerFactory));
        if (shield is null) throw new ArgumentNullException(nameof(shield));

        services.AddSingleton(shield);

        var builder = services.AddChatClient(innerFactory, lifetime);
        builder.UseAgentShield(shield, pendingResolutionSink);
        configure?.Invoke(builder);
        return services;
    }

    /// <summary>
    /// Registers an <see cref="IChatClient"/> guarded by AgentShield,
    /// loading the contract from a single <c>.guardrails.yaml</c>
    /// path. The <see cref="Shield"/> is built once at registration
    /// time and registered as a singleton.
    /// </summary>
    public static IServiceCollection AddAgentShieldChatClient(
        this IServiceCollection services,
        Func<IServiceProvider, IChatClient> innerFactory,
        string yamlPath,
        Action<ChatClientBuilder>? configure = null,
        ServiceLifetime lifetime = ServiceLifetime.Singleton)
    {
        if (services is null) throw new ArgumentNullException(nameof(services));
        if (innerFactory is null) throw new ArgumentNullException(nameof(innerFactory));
        if (yamlPath is null) throw new ArgumentNullException(nameof(yamlPath));

        var shield = Shield.FromYaml(yamlPath).Build();
        return services.AddAgentShieldChatClient(innerFactory, shield, configure, lifetime);
    }

    /// <summary>
    /// Registers an <see cref="IChatClient"/> guarded by AgentShield,
    /// loading the contract from an ordered chain of
    /// <c>.guardrails.yaml</c> paths (extends-chain composition).
    /// The first entry is the base; subsequent entries layer on top in
    /// the order given.
    /// </summary>
    public static IServiceCollection AddAgentShieldChatClient(
        this IServiceCollection services,
        Func<IServiceProvider, IChatClient> innerFactory,
        IReadOnlyList<string> yamlPaths,
        Action<ChatClientBuilder>? configure = null,
        ServiceLifetime lifetime = ServiceLifetime.Singleton)
    {
        if (services is null) throw new ArgumentNullException(nameof(services));
        if (innerFactory is null) throw new ArgumentNullException(nameof(innerFactory));
        if (yamlPaths is null) throw new ArgumentNullException(nameof(yamlPaths));
        if (yamlPaths.Count == 0)
            throw new ArgumentException("At least one YAML path is required.", nameof(yamlPaths));

        var shield = Shield.FromYaml(yamlPaths).Build();

        return services.AddAgentShieldChatClient(innerFactory, shield, configure, lifetime);
    }
}
