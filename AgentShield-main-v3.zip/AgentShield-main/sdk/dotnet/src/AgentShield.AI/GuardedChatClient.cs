using System;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.AI;

using AgentShield;

namespace AgentShield.AI;

/// <summary>
/// Microsoft.Extensions.AI chat-client decorator: Stage 1/5 wrap chat calls,
/// and <see cref="ChatOptions.Tools"/> become <see cref="GuardedAIFunction"/>
/// shims for Stage 3/4 coverage. Session resolution is bound Shield session,
/// ambient session, then a lazy client-owned session; borrowed sessions are not
/// disposed here. Register <c>UseAgentShield(...)</c> before
/// <c>UseFunctionInvocation()</c> so the guard is outermost and the invoker sees
/// wrapped tools. Provider-side server tools are outside MEAI's local
/// <see cref="AIFunction"/> dispatch surface.
/// </summary>
public sealed class GuardedChatClient : DelegatingChatClient
{
    private readonly GuardrailsRuntime _runtime;
    private readonly Shield? _shield;
    private readonly Action<PendingResolution>? _pendingResolutionSink;
    private GuardrailsSession? _lazySession;
    private readonly object _lazyLock = new();
    private bool _disposed;

    /// <summary>
    /// Construct over a raw <see cref="GuardrailsRuntime"/>. When no
    /// ambient <see cref="Shield.CurrentSession"/> is active for the
    /// calling flow, a single lazy session is minted from the runtime
    /// and reused for the lifetime of this client.
    /// </summary>
    public GuardedChatClient(IChatClient innerClient, GuardrailsRuntime runtime)
        : base(innerClient)
    {
        _runtime = runtime ?? throw new ArgumentNullException(nameof(runtime));
        _shield = null;
        _pendingResolutionSink = null;
    }

    /// <summary>
    /// Construct bound to a <see cref="Shield"/> so the underlying
    /// chat client sees the same <see cref="GuardrailsSession"/> the
    /// host configured via <c>shield.Session.SetVariable(...)</c> and
    /// related state-mutating calls. This is the correct shape for
    /// stateful Stage 5 (<c>active_if</c>) policies that depend on
    /// session variables set upstream of the chat call.
    /// </summary>
    public GuardedChatClient(IChatClient innerClient, Shield shield)
        : this(innerClient, shield, pendingResolutionSink: null)
    {
    }

    /// <summary>
    /// Construct bound to a <see cref="Shield"/> with an
    /// optional <paramref name="pendingResolutionSink"/> that receives
    /// the structured suspension envelope on every Stage 2/3 block
    /// whose verdict carries one. The same envelope is always
    /// latched on <see cref="Shield.LastPendingResolution"/>
    /// regardless of whether a sink is supplied; the sink is an
    /// additional callback channel for push-style consumers (UI
    /// renderers, approval queues, etc.).
    ///
    /// <para>
    /// Cross-SDK parity with the Python adapter's
    /// <c>pending_resolution_sink</c> kwarg and the Node
    /// adapter's <c>pendingResolutionSink</c> option.
    /// </para>
    /// </summary>
    public GuardedChatClient(IChatClient innerClient, Shield shield, Action<PendingResolution>? pendingResolutionSink)
        : base(innerClient)
    {
        _shield = shield ?? throw new ArgumentNullException(nameof(shield));
        _runtime = shield.Runtime;
        _pendingResolutionSink = pendingResolutionSink;
    }

    public override async Task<ChatResponse> GetResponseAsync(
        IEnumerable<ChatMessage> messages,
        ChatOptions? options = null,
        CancellationToken cancellationToken = default)
    {
        var messageList = messages as System.Collections.Generic.IReadOnlyList<ChatMessage>
            ?? messages.ToList();

        var (session, ownsSession) = ResolveSession();
        await using var lease = Shield.CurrentSession == session
            ? default
            : await session.AcquireTurnLeaseAsync(cancellationToken).ConfigureAwait(false);
        session.BeginTurn();
        session.BeginRequest();
        // Per-turn block latch — written by GuardedAIFunction on a
        // Stage 3 / Stage 4 deny, read here after the inner client
        // returns. Closes the affirmative-narrative bypass even when
        // MEAI's FunctionInvokingChatClient swallows the
        // typed exception internally.
        using var blockScope = TurnBlockChannel.BeginTurn();
        try
        {
            var (blocked, userText, effectiveText) = ValidateInput(session, messageList);
            if (blocked != null)
                return new ChatResponse(new ChatMessage(ChatRole.Assistant, blocked));

            // Spec — forward post-Stage-1 redacted text
            // to the inner ChatClient. Previously the inner client saw
            // the raw user input even when Stage 1 had redacted it.
            var effectiveMessages = ApplyStage1Redaction(messageList, userText, effectiveText);

            // Stage 3 + 4 — substitute guarded shims for every
            // AIFunction in options.Tools so the downstream invoker
            // (typically UseFunctionInvocation()) dispatches through
            // the gate. Fast-path tool-free calls without allocating a
            // clone.
            var effectiveOptions = WrapTools(options, session);

            ChatResponse response;
            try
            {
                response = await base.GetResponseAsync(effectiveMessages, effectiveOptions, cancellationToken)
                    .ConfigureAwait(false);
            }
            catch (AgentShieldBlockedException ex)
            {
                // Test fakes (and some MEAI configurations) let the
                // typed exception propagate out of the inner client
                // unchanged — same fail-closed handling as the latch
                // path below.
                return BuildBlockedChatResponse(ex);
            }

            if (blockScope.State.FirstBlock is { } latched)
            {
                // MEAI's FunctionInvokingChatClient caught the throw
                // and synthesised a tool-result string. Discard that
                // synthesised response and surface the canonical
                // block message so the LLM cannot narrate around the
                // gate.
                return BuildBlockedChatResponse(latched);
            }

            var responseText = response.Text ?? "";
            if (string.IsNullOrEmpty(responseText)) return response;

            var (verdict, redacted) = session.ValidateOutput(responseText);
            if (!verdict.Allowed)
            {
                return new ChatResponse(new ChatMessage(ChatRole.Assistant,
                    $"[Blocked by Agent Shield] {verdict.Reason ?? "policy violation"}"))
                {
                    ResponseId = response.ResponseId,
                    ModelId = response.ModelId,
                    Usage = response.Usage,
                };
            }
            if (redacted != responseText)
            {
                var redactedMessages = response.Messages.ToList();
                var lastIdx = redactedMessages.FindLastIndex(m => m.Role == ChatRole.Assistant);
                if (lastIdx >= 0)
                    redactedMessages[lastIdx] = new ChatMessage(ChatRole.Assistant, redacted);
                else
                    redactedMessages.Add(new ChatMessage(ChatRole.Assistant, redacted));
                return new ChatResponse(redactedMessages)
                {
                    ResponseId = response.ResponseId,
                    ModelId = response.ModelId,
                    Usage = response.Usage,
                };
            }
            return response;
        }
        finally
        {
            session.EndRequest();
            try { session.EndTurn(); } catch { /* best-effort */ }
            // Only dispose if we own this session for the call scope.
            // Borrowed sessions (explicit Shield or ambient) outlive
            // this call. The single lazy session lives until Dispose().
            if (ownsSession) session.Dispose();
        }
    }

    /// <summary>
    /// Streaming Stage 1 + Stage 5 enforcement. <see cref="StreamingMode.OnComplete"/>
    /// holds text until <c>Finish()</c>; per-chunk/windowed modes emit only the
    /// guard-returned payload suffix and stop with a terminal block chunk.
    /// </summary>
    public override async IAsyncEnumerable<ChatResponseUpdate> GetStreamingResponseAsync(
        IEnumerable<ChatMessage> messages,
        ChatOptions? options = null,
        [EnumeratorCancellation] CancellationToken cancellationToken = default)
    {
        var messageList = messages as System.Collections.Generic.IReadOnlyList<ChatMessage>
            ?? messages.ToList();

        var (session, ownsSession) = ResolveSession();
        await using var lease = Shield.CurrentSession == session
            ? default
            : await session.AcquireTurnLeaseAsync(cancellationToken).ConfigureAwait(false);
        session.BeginTurn();
        session.BeginRequest();
        // Per-turn block latch — see GetResponseAsync for the rationale.
        // GuardedAIFunction may write to this from inside the inner
        // stream when MEAI's function-invocation loop dispatches a
        // tool mid-stream.
        using var blockScope = TurnBlockChannel.BeginTurn();
        try
        {
            var (blocked, userText, effectiveText) = ValidateInput(session, messageList);
            if (blocked != null)
            {
                yield return new ChatResponseUpdate
                {
                    Role = ChatRole.Assistant,
                    Contents = new[] { (AIContent)new TextContent(blocked) },
                };
                yield break;
            }

            // Spec — forward post-Stage-1 redacted text
            // to the inner ChatClient. Previously the streaming path
            // sent the raw user input to the inner client even when
            // Stage 1 had redacted it.
            var effectiveMessages = ApplyStage1Redaction(messageList, userText, effectiveText);

            // Stage 3 + 4 — same wrap-tools-up-front contract as
            // GetResponseAsync. Streaming does not change the
            // shim semantics: AIFunction.InvokeAsync is called by the
            // invoker only after the FunctionCallContent arguments
            // have been reassembled from the upstream chunks.
            var effectiveOptions = WrapTools(options, session);

            using var guard = session.StreamingSession(StreamingStage.Output);
            var bufferMode = guard.Mode == StreamingMode.OnComplete;
            var stopped = false;
            // Held back in OnComplete so we can attach the final
            // validated text to the last upstream chunk's metadata.
            ChatResponseUpdate? lastBufferedChunk = null;
            // Last upstream chunk seen with text content — used to
            // carry response/model id onto payload-bearing emissions
            // in per_chunk / windowed modes.
            ChatResponseUpdate? lastTextChunk = null;

            // Manual enumeration so we can catch
            // AgentShieldBlockedException raised by the inner stream
            // (Stage 3/4 deny from a tool dispatched inside the
            // function-invocation loop) and convert it into a
            // canonical terminal block emission. `yield return`
            // inside a `try {... } catch {... }` is illegal in C#,
            // so the catch sets a flag we observe after the chunk is
            // safely yielded outside the try.
            var innerEnumerator = base.GetStreamingResponseAsync(
                    effectiveMessages, effectiveOptions, cancellationToken)
                .GetAsyncEnumerator(cancellationToken);
            AgentShieldBlockedException? streamCaughtBlock = null;
            try
            {
                while (true)
                {
                    ChatResponseUpdate? chunk;
                    bool hasNext;
                    try
                    {
                        hasNext = await innerEnumerator.MoveNextAsync().ConfigureAwait(false);
                        chunk = hasNext ? innerEnumerator.Current : null;
                    }
                    catch (AgentShieldBlockedException ex)
                    {
                        streamCaughtBlock = ex;
                        break;
                    }
                    if (!hasNext) break;
                    if (chunk is null) continue;

                    var chunkText = chunk.Text ?? string.Empty;

                    // Metadata-only chunks (no text) are not security-relevant
                    // — pass them through in real time even in OnComplete so
                    // consumers see token usage, finish reason, role, etc.
                    // promptly.
                    if (chunkText.Length == 0)
                    {
                        yield return chunk;
                        // After surfacing the chunk, check the per-turn
                        // block latch — a tool dispatched between the
                        // previous chunk and this one may have denied.
                        if (blockScope.State.FirstBlock is { } latchedMeta)
                        {
                            streamCaughtBlock = latchedMeta;
                            break;
                        }
                        continue;
                    }

                    var pushed = guard.Push(chunkText);

                    if (pushed.Action == StreamAction.Stop)
                    {
                        yield return new ChatResponseUpdate
                        {
                            Role = ChatRole.Assistant,
                            Contents = new[]
                            {
                                (AIContent)new TextContent(
                                    $"[GUARDRAIL BLOCK] {pushed.Reason ?? "blocked by policy"}"),
                            },
                        };
                        stopped = true;
                        break;
                    }

                    if (pushed.Action == StreamAction.Replace && !bufferMode)
                    {
                        // per_chunk / windowed yields each
                        // ChatResponseUpdate to the consumer in real time
                        // (append-only sink — IAsyncEnumerable<ChatResponseUpdate>
                        // and downstream Microsoft.Extensions.AI consumers
                        // concatenate deltas). The Rust core returns
                        // Replace with the ENTIRE validated buffer (spec
                        // "discard prior emission and substitute
                        // payload"), expecting the host to retract the
                        // bytes it already yielded. Append-only sinks
                        // can't retract — silently emitting the Replace
                        // payload would leave the leaked PHI on screen
                        // followed by the redacted version (canonical
                        // reproducer: "SSN 123-45-6789SSN [SSN]").
                        // Fail loudly so the customer's YAML gets
                        // switched to `trigger: on_complete` (safe
                        // buffered default).
                        throw new StreamingReplaceNotSupportedException(
                            adapter: "GuardedChatClient",
                            reason: pushed.Reason);
                    }

                    if (bufferMode)
                    {
                        // OnComplete: do NOT yield text-bearing chunks; the
                        // engine returns Pass(empty) for every push and the
                        // final validated payload arrives at Finish() below.
                        // Remember the last upstream chunk so we can carry
                        // its metadata onto the terminal emission.
                        lastBufferedChunk = chunk;
                    }
                    else
                    {
                        // per_chunk / windowed: emit pushed.Payload (the engine's
                        // safe-to-emit slice) on Pass when non-empty. Empty
                        // payload means "buffered for overlap — emit nothing
                        // yet". Replace is handled above (throws) — only
                        // Pass reaches this branch in non-buffer mode.
                        lastTextChunk = chunk;
                        if (!string.IsNullOrEmpty(pushed.Payload))
                        {
                            yield return new ChatResponseUpdate
                            {
                                Role = chunk.Role ?? ChatRole.Assistant,
                                Contents = new[] { (AIContent)new TextContent(pushed.Payload) },
                                ResponseId = chunk.ResponseId,
                                ModelId = chunk.ModelId,
                            };
                        }
                    }

                    // Check the per-turn block latch after every
                    // upstream chunk so a tool deny dispatched mid-
                    // stream produces a canonical terminal block on
                    // the next iteration boundary.
                    if (blockScope.State.FirstBlock is { } latched)
                    {
                        streamCaughtBlock = latched;
                        break;
                    }
                }
            }
            finally
            {
                await innerEnumerator.DisposeAsync().ConfigureAwait(false);
            }

            // Tool-deny short-circuit: replace whatever the upstream
            // stream was producing with a canonical block message and
            // bail out of Stage-5 finishing. The Shield.LastPendingResolution
            // latch already carries the structured envelope.
            if (streamCaughtBlock is not null)
            {
                yield return BuildBlockedStreamUpdate(streamCaughtBlock);
                yield break;
            }

            if (!stopped)
            {
                var tail = guard.Finish();
                if (tail.Action == StreamAction.Stop)
                {
                    yield return new ChatResponseUpdate
                    {
                        Role = ChatRole.Assistant,
                        Contents = new[]
                        {
                            (AIContent)new TextContent(
                                $"[GUARDRAIL BLOCK] {tail.Reason ?? "blocked by policy"}"),
                        },
                    };
                }
                else if (bufferMode)
                {
                    // OnComplete: emit ONE final chunk carrying the
                    // validated text. The engine returns Pass(full_text)
                    // if no redaction fired, or Replace(redacted_text)
                    // if it did — either way the payload is the safe
                    // textual content to surface. Replace is byte-
                    // equivalent to Pass here: the engine has only
                    // ever emitted Pass(empty) for earlier pushes, so
                    // the replacement payload is the FIRST and ONLY
                    // consumer-visible text chunk.
                    var finalText = tail.Payload;
                    if (finalText.Length > 0)
                    {
                        var role = lastBufferedChunk?.Role ?? ChatRole.Assistant;
                        yield return new ChatResponseUpdate
                        {
                            Role = role,
                            Contents = new[] { (AIContent)new TextContent(finalText) },
                            ResponseId = lastBufferedChunk?.ResponseId,
                            ModelId = lastBufferedChunk?.ModelId,
                        };
                    }
                }
                else if (tail.Action == StreamAction.Replace)
                {
                    // same append-only sink contract as the mid-
                    // stream branch — Replace at Finish() in per_chunk /
                    // windowed cadence rewrites prior emissions and is
                    // unsafe. Fail loudly.
                    throw new StreamingReplaceNotSupportedException(
                        adapter: "GuardedChatClient",
                        reason: tail.Reason);
                }
                else if (!string.IsNullOrEmpty(tail.Payload))
                {
                    // per_chunk / windowed tail: the engine flushes the
                    // held-back overlap (Pass) here — must reach the
                    // consumer.
                    var role = lastTextChunk?.Role ?? ChatRole.Assistant;
                    yield return new ChatResponseUpdate
                    {
                        Role = role,
                        Contents = new[] { (AIContent)new TextContent(tail.Payload) },
                        ResponseId = lastTextChunk?.ResponseId,
                        ModelId = lastTextChunk?.ModelId,
                    };
                }
            }
        }
        finally
        {
            session.EndRequest();
            try { session.EndTurn(); } catch { /* best-effort */ }
            if (ownsSession) session.Dispose();
        }
    }

    /// <summary>
    /// Build the canonical Stage 3 / Stage 4 block <see cref="ChatResponse"/>:
    /// a single assistant message containing
    /// <c>[Blocked by Agent Shield] &lt;reason&gt;</c>. The structured
    /// suspension envelope (when present) is already latched on
    /// <see cref="Shield.LastPendingResolution"/> by
    /// <c>GuardedAIFunction</c>; the host pulls it from there to
    /// avoid the LLM trajectory leaking JSON shapes.
    /// </summary>
    private static ChatResponse BuildBlockedChatResponse(AgentShieldBlockedException ex)
    {
        var text = $"[Blocked by Agent Shield] {ex.Message}";
        return new ChatResponse(new ChatMessage(ChatRole.Assistant, text));
    }

    /// <summary>
    /// Streaming counterpart to <see cref="BuildBlockedChatResponse"/>:
    /// produce the canonical terminal <see cref="ChatResponseUpdate"/>
    /// for a Stage 3 / Stage 4 tool deny dispatched mid-stream.
    /// </summary>
    private static ChatResponseUpdate BuildBlockedStreamUpdate(AgentShieldBlockedException ex)
    {
        return new ChatResponseUpdate
        {
            Role = ChatRole.Assistant,
            Contents = new[]
            {
                (AIContent)new TextContent($"[Blocked by Agent Shield] {ex.Message}"),
            },
        };
    }

    /// <summary>
    /// Clone <paramref name="options"/> and replace every
    /// <see cref="AIFunction"/> in <see cref="ChatOptions.Tools"/> with
    /// a <see cref="GuardedAIFunction"/> bound to
    /// <paramref name="session"/>. Returns <paramref name="options"/>
    /// unchanged when there is nothing to wrap (null options, null /
    /// empty tools, or every tool is a non-invocable
    /// <see cref="AIFunctionDeclaration"/>); never mutates the caller's
    /// options or tools collection.
    /// </summary>
    private ChatOptions? WrapTools(ChatOptions? options, GuardrailsSession session)
    {
        if (options?.Tools is not { Count: > 0 } tools) return options;

        var hasInvocable = false;
        foreach (var t in tools)
        {
            if (t is AIFunction) { hasInvocable = true; break; }
        }
        if (!hasInvocable) return options;

        var cloned = options.Clone();
        var wrapped = new List<AITool>(tools.Count);
        foreach (var t in tools)
        {
            wrapped.Add(t is AIFunction fn
                ? new GuardedAIFunction(fn, session, _shield, _pendingResolutionSink)
                : t);
        }
        cloned.Tools = wrapped;
        return cloned;
    }

    private static (string? Blocked, string UserText, string EffectiveText) ValidateInput(
        GuardrailsSession session,
        System.Collections.Generic.IReadOnlyList<ChatMessage> messages)
    {
        var lastUser = messages.LastOrDefault(m => m.Role == ChatRole.User);
        var text = lastUser?.Text ?? "";
        if (string.IsNullOrEmpty(text)) return (null, "", "");
        var verdict = session.ValidateInput(text);
        if (!verdict.Allowed)
            return ($"[Blocked by Agent Shield] {verdict.Reason ?? "policy violation"}", text, text);
        // Spec: a `redact` action on a content stage
        // rewrites the subject and "the rewritten subject continues
        // through downstream stages." Surface the post-Stage-1
        // effective text so callers can forward it to the inner
        // ChatClient instead of the raw user input.
        var decision = VerdictDispatcher.DispatchStage(verdict, OnBlockPolicy.ReturnBlocked, ShieldMode.Enforce);
        var effective = decision.Action.Kind == "proceed_with_mutation"
            ? decision.Action.Value ?? text
            : text;
        return (null, text, effective);
    }

    /// <summary>
    /// Clone <paramref name="messages"/> replacing the last user
    /// message's text with <paramref name="effectiveText"/>. Returns
    /// the original list unchanged when no rewrite is needed (no
    /// Stage 1 redaction was applied or no user message exists).
    /// </summary>
    private static System.Collections.Generic.IReadOnlyList<ChatMessage> ApplyStage1Redaction(
        System.Collections.Generic.IReadOnlyList<ChatMessage> messages,
        string userText,
        string effectiveText)
    {
        if (string.Equals(userText, effectiveText, StringComparison.Ordinal))
            return messages;
        var lastUserIdx = -1;
        for (int i = messages.Count - 1; i >= 0; i--)
        {
            if (messages[i].Role == ChatRole.User) { lastUserIdx = i; break; }
        }
        if (lastUserIdx < 0) return messages;
        var cloned = messages.ToList();
        cloned[lastUserIdx] = new ChatMessage(ChatRole.User, effectiveText);
        return cloned;
    }

    /// <summary>
    /// Resolve the session for this call. Returns the session and a
    /// flag indicating whether the caller owns it (and must dispose
    /// it at end of call). See class-level docs for precedence.
    /// </summary>
    private (GuardrailsSession Session, bool Owned) ResolveSession()
    {
        // 1. Explicit Shield supplied at construction wins — its
        //    session is the canonical state surface upstream code
        //    mutates via shield.Session.SetVariable(...).
        if (_shield != null)
            return (_shield.Session, Owned: false);

        // 2. Ambient session from the calling async flow (set by
        //    Shield.RunAsync / RunStreamedAsync).
        var ambient = Shield.CurrentSession;
        if (ambient != null)
            return (ambient, Owned: false);

        // 3. Lazy per-instance session — minted once from the runtime
        //    and reused for the lifetime of this client. Disposed on
        //    Dispose(). This preserves backward compatibility for
        //    GuardedChatClient(IChatClient, GuardrailsRuntime) callers
        //    while ensuring state set across calls on the same client
        //    instance remains visible to later calls.
        if (_lazySession == null)
        {
            lock (_lazyLock)
            {
                if (_lazySession == null)
                {
                    if (_disposed) throw new ObjectDisposedException(nameof(GuardedChatClient));
                    _lazySession = _runtime.NewSession();
                }
            }
        }
        return (_lazySession, Owned: false);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing && !_disposed)
        {
            _disposed = true;
            try { _lazySession?.Dispose(); } catch { /* best effort */ }
            _lazySession = null;
        }
        base.Dispose(disposing);
    }
}
