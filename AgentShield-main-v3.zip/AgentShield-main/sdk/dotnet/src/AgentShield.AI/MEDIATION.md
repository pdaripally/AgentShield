# AgentShield.AI mediation

## Mediated paths
- `WithChatClient(...)` and `GuardChatClient(...)` install the wrapper at `sdk/dotnet/src/AgentShield.AI/ShieldExtensions.cs:44` and `sdk/dotnet/src/AgentShield.AI/ShieldExtensions.cs:56`.
- `GuardedChatClient.GetResponseAsync(...)` mediates Stage 1 and Stage 5 at `sdk/dotnet/src/AgentShield.AI/GuardedChatClient.cs:39`.
- `GuardedChatClient.GetStreamingResponseAsync(...)` owns streamed Stage-5 output mediation at `sdk/dotnet/src/AgentShield.AI/GuardedChatClient.cs:129`.

## Unsupported paths
- Direct calls on the underlying `IChatClient`.
- Tool dispatch before/after the chat client boundary; this DLL is Stage-1/5 middleware, not a tool wrapper.
- Any custom streaming surface not routed through `DelegatingChatClient`.

## Bypass risks
- Holding both the guarded chat client and the raw inner client.
- Assuming tool approvals or tool-result checks happen here; they belong to framework-specific tool middleware, not `DelegatingChatClient`.
- Replacing the guarded client in DI with the raw client for some requests.

## Streaming behavior
- Rule 1 — ✓ `StreamingSession` validates whole text slices from `ChatResponseUpdate` objects.
- Rule 2 — ✓ bounded by the core streaming guard's finite buffering/windowing.
- Rule 3 — ✓ shared `StreamingGuard.Push()` / `Finish()` now emit `incident.stream_aborted` on policy stop verdicts.
- Rule 4 — ✓ the shared `StreamingGuard` now emits `incident.stream_limit_exceeded` when the stream hits the core buffer bound.
- Rule 5 — ✓ not applicable on this surface; `AgentShield.AI` streams only Stage-5 assistant output, not Stage-4 tool-result chunks.

## Unknown tool-call shapes
- Not applicable on the primary surface: `AgentShield.AI` wraps chat messages, not framework tool-call envelopes.

## See also

See [Post-tool limits and dangerous patterns](../../../../docs/POST_TOOL_LIMITS.md) and the [adapter-mediated path matrix](../../../../docs/adapter-mediated-paths.md).
