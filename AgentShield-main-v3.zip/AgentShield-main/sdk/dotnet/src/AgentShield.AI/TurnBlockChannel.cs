using System.Threading;

namespace AgentShield.AI;

/// <summary>
/// Per-async-flow side-channel that <see cref="GuardedAIFunction"/>
/// uses to signal a Stage 3 / Stage 4 deny back to the enclosing
/// <see cref="GuardedChatClient"/>. Necessary because
/// Microsoft.Extensions.AI's <c>FunctionInvokingChatClient</c>
/// internally catches exceptions thrown from an
/// <see cref="Microsoft.Extensions.AI.AIFunction"/> body and converts
/// them into a function-result string — without a side-channel the
/// surrounding chat-client wrapper has no way to learn that a block
/// fired and would let the LLM continue narrating.
/// </summary>
internal static class TurnBlockChannel
{
    private static readonly AsyncLocal<TurnBlockState?> _state = new();

    public static TurnBlockState? Current => _state.Value;

    public static TurnBlockScope BeginTurn()
    {
        var fresh = new TurnBlockState();
        var previous = _state.Value;
        _state.Value = fresh;
        return new TurnBlockScope(fresh, previous);
    }

    internal readonly struct TurnBlockScope : System.IDisposable
    {
        public TurnBlockState State { get; }
        private readonly TurnBlockState? _previous;
        public TurnBlockScope(TurnBlockState state, TurnBlockState? previous)
        { State = state; _previous = previous; }
        public void Dispose() => _state.Value = _previous;
    }
}

/// <summary>
/// Latch shared between <see cref="GuardedAIFunction"/> (writer) and
/// <see cref="GuardedChatClient"/> (reader). Holds the FIRST block of
/// a turn — subsequent blocks are ignored so observable behaviour is
/// deterministic when one turn triggers multiple tool calls.
/// </summary>
internal sealed class TurnBlockState
{
    private readonly object _lock = new();
    private AgentShieldBlockedException? _firstBlock;

    public AgentShieldBlockedException? FirstBlock
    {
        get
        {
            lock (_lock)
            {
                return _firstBlock;
            }
        }
    }

    public bool IsBlocked
    {
        get
        {
            lock (_lock)
            {
                return _firstBlock != null;
            }
        }
    }

    public void Record(AgentShieldBlockedException ex)
    {
        lock (_lock)
        {
            _firstBlock ??= ex;
        }
    }
}
