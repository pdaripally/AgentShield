using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.AI;

using AgentShield;

namespace AgentShield.AI;

/// <summary>
/// <see cref="AIFunction"/> shim for MEAI Stage 3/4 coverage: wrap tools
/// before the invoker sees them, latch guarded blocks so MEAI cannot fold
/// them into model-visible tool-error text, and mint one binding GUID
/// per invocation because MEAI does not expose the upstream call id here.
/// </summary>
internal sealed class GuardedAIFunction : AIFunction
{
    private const string DefaultBlockReason = "blocked by policy";
    private const string Stage3 = "stage_3";
    private const string Stage4 = "stage_4";

    private readonly AIFunction _inner;
    private readonly GuardrailsSession _session;
    private readonly Shield? _shield;
    private readonly Action<PendingResolution>? _pendingResolutionSink;

    internal GuardedAIFunction(AIFunction inner, GuardrailsSession session)
        : this(inner, session, null, null)
    {
    }

    internal GuardedAIFunction(
        AIFunction inner,
        GuardrailsSession session,
        Shield? shield,
        Action<PendingResolution>? pendingResolutionSink)
    {
        _inner = inner ?? throw new ArgumentNullException(nameof(inner));
        _session = session ?? throw new ArgumentNullException(nameof(session));
        _shield = shield;
        _pendingResolutionSink = pendingResolutionSink;
    }

    public override string Name => _inner.Name;
    public override string Description => _inner.Description;
    public override IReadOnlyDictionary<string, object?> AdditionalProperties => _inner.AdditionalProperties;
    public override JsonElement JsonSchema => _inner.JsonSchema;
    public override JsonElement? ReturnJsonSchema => _inner.ReturnJsonSchema;
    public override JsonSerializerOptions JsonSerializerOptions => _inner.JsonSerializerOptions;
    public override MethodInfo? UnderlyingMethod => _inner.UnderlyingMethod;

    protected override async ValueTask<object?> InvokeCoreAsync(
        AIFunctionArguments arguments,
        CancellationToken cancellationToken)
    {
        // Per-invocation binding id. Each shim call mints its
        // own so concurrent same-name calls cannot collide in the
        // binding cache (the upstream FunctionCallContent.CallId is
        // not surfaced into AIFunctionArguments by M.E.AI 9.x).
        var boundId = Guid.NewGuid().ToString("N");

        // ── Stage 3 — admit the call ──────────────────────────────
        JsonElement paramsJson = SerializeArguments(arguments);
        ToolCallValidationResult admission;
        try
        {
            admission = _session.ValidateToolCall(_inner.Name, paramsJson, boundId);
        }
        catch (Exception ex)
        {
            try { _session.RecordToolFailure(_inner.Name, ex.Message); }
            catch { /* best-effort observability */ }
            throw;
        }

        if (!admission.Verdict.Allowed)
        {
            try { _session.RecordToolFailure(_inner.Name, admission.Verdict.Reason ?? DefaultBlockReason); }
            catch { /* best-effort observability */ }
            SurfacePendingResolution(admission.Verdict.PendingResolution);
            throw BuildAndLatchBlock(
                _inner.Name,
                Stage3,
                admission.Verdict.Reason,
                admission.Verdict.PendingResolution);
        }

        // Stage 3 may have mutated the arguments — rebind them into a
        // fresh AIFunctionArguments instance so the inner function
        // receives the rewritten params. Services / Context flow
        // through unchanged so request-scoped DI keeps working.
        AIFunctionArguments effectiveArgs = ApplyMutatedArgs(arguments, admission.Params);

        // ── Execute inner ─────────────────────────────────────────
        object? result;
        try
        {
            result = await _inner.InvokeAsync(effectiveArgs, cancellationToken).ConfigureAwait(false);
        }
        catch (Exception ex)
        {
            try { _session.RecordToolFailure(_inner.Name, ex.Message); }
            catch { /* best-effort observability */ }
            throw;
        }

        // ── Stage 4 — validate / redact the result ────────────────
        JsonElement resultJson = SerializeResult(result);
        var (outVerdict, outRedacted) =
            _session.ValidateToolOutput(_inner.Name, resultJson, boundId);

        if (!outVerdict.Allowed)
        {
            try { _session.RecordToolFailure(_inner.Name, outVerdict.Reason ?? DefaultBlockReason); }
            catch { /* best-effort observability */ }
            SurfacePendingResolution(outVerdict.PendingResolution);
            throw BuildAndLatchBlock(
                _inner.Name,
                Stage4,
                outVerdict.Reason,
                outVerdict.PendingResolution);
        }

        try { _session.RecordToolSuccess(_inner.Name, outRedacted); }
        catch { /* best-effort observability */ }

        // Type-fidelity fast path: on an allow with no mutation,
        // return the original object reference so the M.E.AI
        // invocation pipeline can format it exactly as the bare
        // inner function would have. Only on actual redaction do we
        // hand back the JsonElement.
        if (string.Equals(resultJson.GetRawText(), outRedacted.GetRawText(), StringComparison.Ordinal))
            return result;
        return outRedacted;
    }

    private JsonElement SerializeArguments(AIFunctionArguments? args)
    {
        if (args is null || args.Count == 0)
            return EmptyObject;
        try
        {
            var dict = new Dictionary<string, object?>(args.Count);
            foreach (var kv in args) dict[kv.Key] = kv.Value;
            return JsonSerializer.SerializeToElement(dict, _inner.JsonSerializerOptions);
        }
        catch
        {
            return EmptyObject;
        }
    }

    private static AIFunctionArguments ApplyMutatedArgs(
        AIFunctionArguments? original, JsonElement mutated)
    {
        if (mutated.ValueKind != JsonValueKind.Object)
            return original ?? new AIFunctionArguments();

        var rebuilt = new AIFunctionArguments();
        foreach (var prop in mutated.EnumerateObject())
        {
            // Keep the rebuilt args weakly typed (object?) — the inner
            // function's parameter binding is responsible for marshaling
            // back into typed parameters via its JsonSerializerOptions.
            rebuilt[prop.Name] = JsonElementToObject(prop.Value);
        }
        if (original is not null)
        {
            if (original.Services is not null) rebuilt.Services = original.Services;
            if (original.Context is not null)
            {
                foreach (var kv in original.Context) rebuilt.Context[kv.Key] = kv.Value;
            }
        }
        return rebuilt;
    }

    private static object? JsonElementToObject(JsonElement el) => el.ValueKind switch
    {
        JsonValueKind.String => el.GetString(),
        JsonValueKind.Number => el.TryGetInt64(out var l) ? l : el.GetDouble(),
        JsonValueKind.True => true,
        JsonValueKind.False => false,
        JsonValueKind.Null => null,
        JsonValueKind.Undefined => null,
        // For arrays / objects we hand back a JsonNode so the inner
        // function's binder can re-serialize without losing structure.
        _ => JsonNode.Parse(el.GetRawText()),
    };

    private JsonElement SerializeResult(object? result)
    {
        if (result is JsonElement je) return je;
        try
        {
            return JsonSerializer.SerializeToElement(result, _inner.JsonSerializerOptions);
        }
        catch
        {
            // Non-serializable result — fall back to its string form so
            // Stage 4 regex / span machinery still has something to
            // inspect rather than silently skipping validation.
            return JsonSerializer.SerializeToElement(result?.ToString() ?? string.Empty);
        }
    }

    private void SurfacePendingResolution(PendingResolution? pending)
    {
        if (pending is null) return;
        // Latch on the bound Shield (canonical pull-side surface) and
        // fire the optional sink (push-side surface). Sink exceptions
        // are swallowed so a misbehaving host callback can never break
        // the guardrail pipeline — cross-SDK parity with Python /
        // Node's `pending_resolution_sink` behaviour.
        _shield?.CapturePendingResolution(pending);
        if (_pendingResolutionSink is { } sink)
        {
            try { sink(pending); }
            catch { /* host callback must not break the gate */ }
        }
    }

    /// <summary>
    /// Build the <see cref="AgentShieldBlockedException"/> for a
    /// Stage 3 / Stage 4 deny AND latch it on the per-turn
    /// <see cref="TurnBlockChannel"/> so the enclosing
    /// <see cref="GuardedChatClient"/> can surface the canonical
    /// block envelope even if Microsoft.Extensions.AI's
    /// <c>FunctionInvokingChatClient</c> catches the throw internally
    /// and continues its tool-call loop.
    /// </summary>
    private static AgentShieldBlockedException BuildAndLatchBlock(
        string tool, string stage, string? reason, PendingResolution? pending)
    {
        var ex = new AgentShieldBlockedException(
            reason ?? DefaultBlockReason,
            tool,
            stage,
            pending);
        TurnBlockChannel.Current?.Record(ex);
        return ex;
    }

    private static readonly JsonElement EmptyObject =
        JsonDocument.Parse("{}").RootElement.Clone();
}
