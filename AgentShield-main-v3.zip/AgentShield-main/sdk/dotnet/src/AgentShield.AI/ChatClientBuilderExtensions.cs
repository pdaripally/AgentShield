using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using Microsoft.Extensions.AI;

using AgentShield;

namespace AgentShield.AI;

/// <summary>
/// Microsoft.Extensions.AI <see cref="ChatClientBuilder"/> middleware for
/// Agent Shield. Register <c>UseAgentShield(...)</c> before
/// <c>UseFunctionInvocation()</c>: MEAI builds in reverse, so this makes the
/// guard the outer client and lets its <see cref="GuardedAIFunction"/> shims
/// reach the invoker. Reversed ordering throws at registration time.
/// </summary>
public static class ChatClientBuilderExtensions
{
    /// <summary>
    /// Wrap the chain with a <see cref="GuardedChatClient"/> bound to
    /// <paramref name="shield"/>. State mutated upstream via
    /// <c>shield.Session.SetVariable(...)</c> is visible to Stage 5
    /// <c>active_if</c> predicates.
    ///
    /// <para>
    /// The same Shield instance can be threaded into multiple
    /// <c>ChatClientBuilder</c> chains — the underlying runtime and
    /// session are reused.
    /// </para>
    /// <para>
    /// Throws <see cref="InvalidOperationException"/> at registration
    /// time when <c>UseFunctionInvocation()</c> has already been
    /// registered on the same builder, because that ordering puts the
    /// function-invoker outside <see cref="GuardedChatClient"/> and
    /// silently bypasses tool-stage gating. See class-level docs.
    /// </para>
    /// </summary>
    public static ChatClientBuilder UseAgentShield(this ChatClientBuilder builder, Shield shield)
        => UseAgentShield(builder, shield, pendingResolutionSink: null);

    /// <summary>
    /// Wrap the chain with a <see cref="GuardedChatClient"/>
    /// bound to <paramref name="shield"/>, with an optional
    /// <paramref name="pendingResolutionSink"/> that receives the
    /// structured suspension envelope on every Stage 2/3 block whose
    /// verdict carries one. The same envelope is always latched on
    /// <see cref="Shield.LastPendingResolution"/> regardless of
    /// whether a sink is supplied.
    ///
    /// <para>
    /// Cross-SDK parity with the Python adapter's
    /// <c>pending_resolution_sink</c> kwarg and the Node
    /// adapter's <c>pendingResolutionSink</c> option.
    /// </para>
    /// </summary>
    public static ChatClientBuilder UseAgentShield(
        this ChatClientBuilder builder,
        Shield shield,
        Action<PendingResolution>? pendingResolutionSink)
    {
        if (builder == null) throw new ArgumentNullException(nameof(builder));
        if (shield == null) throw new ArgumentNullException(nameof(shield));
        ThrowIfFunctionInvocationAlreadyRegistered(builder);
        return builder.Use(inner => new GuardedChatClient(inner, shield, pendingResolutionSink));
    }

    /// <summary>
    /// Load a guardrails contract from <paramref name="yamlPath"/>,
    /// build a Shield, and wrap the chain with a
    /// <see cref="GuardedChatClient"/>. Convenience overload for the
    /// common case where the Shield does not need to be shared with
    /// other components.
    ///
    /// <para>
    /// The Shield owns the loaded native runtime; it lives for the
    /// lifetime of the resulting <see cref="IChatClient"/> and is
    /// disposed when the wrapper is disposed.
    /// </para>
    /// <para>
    /// Throws <see cref="InvalidOperationException"/> at registration
    /// time when <c>UseFunctionInvocation()</c> has already been
    /// registered on the same builder. See class-level docs.
    /// </para>
    /// </summary>
    public static ChatClientBuilder UseAgentShield(this ChatClientBuilder builder, string yamlPath)
    {
        if (builder == null) throw new ArgumentNullException(nameof(builder));
        if (yamlPath == null) throw new ArgumentNullException(nameof(yamlPath));
        ThrowIfFunctionInvocationAlreadyRegistered(builder);
        var shield = Shield.FromYaml(yamlPath).Build();
        return builder.Use(inner => new GuardedChatClient(inner, shield));
    }

    /// <summary>
    /// Load a chain of guardrails YAML files (merged left → right
    /// with leaf-wins semantics), build a Shield, and wrap the
    /// chain. See <see cref="UseAgentShield(ChatClientBuilder, string)"/>
    /// for the single-file form.
    /// <para>
    /// Throws <see cref="InvalidOperationException"/> at registration
    /// time when <c>UseFunctionInvocation()</c> has already been
    /// registered on the same builder. See class-level docs.
    /// </para>
    /// </summary>
    public static ChatClientBuilder UseAgentShield(this ChatClientBuilder builder, IReadOnlyList<string> yamlPaths)
    {
        if (builder == null) throw new ArgumentNullException(nameof(builder));
        if (yamlPaths == null) throw new ArgumentNullException(nameof(yamlPaths));
        ThrowIfFunctionInvocationAlreadyRegistered(builder);
        var shield = Shield.FromYaml(yamlPaths).Build();
        return builder.Use(inner => new GuardedChatClient(inner, shield));
    }

    /// <summary>
    /// SAFETY-CRITICAL builder-time check. Reflectively peeks at the
    /// builder's registered factory list and dry-runs each factory
    /// against a sentinel inner. If any factory produces (or yields a
    /// chain containing) a <c>FunctionInvokingChatClient</c>, then
    /// <c>UseFunctionInvocation()</c> was registered BEFORE
    /// <c>UseAgentShield()</c> on this builder — at
    /// <see cref="ChatClientBuilder.Build(IServiceProvider)"/> time
    /// that ordering puts the function-invoker on the OUTSIDE of the
    /// <see cref="GuardedChatClient"/> wrapper, and tool dispatch
    /// happens against the caller's unwrapped <see cref="AIFunction"/>s.
    /// Stage 3 (tool admission) and Stage 4 (post-tool) are then
    /// silently bypassed.
    /// <para>
    /// We refuse to register in that ordering: throw
    /// <see cref="InvalidOperationException"/> with a clear diagnostic
    /// pointing the customer at the canonical builder order documented
    /// on the class.
    /// </para>
    /// <para>
    /// Reflection is best-effort: if the MEAI internal layout has
    /// shifted (e.g. a future version renames <c>_clientFactories</c>),
    /// the probe falls through silently rather than crashing the host.
    /// The XML-doc + README rewrite remain the primary lines of
    /// defence; this probe is the eager belt-and-braces detection.
    /// </para>
    /// </summary>
    private static void ThrowIfFunctionInvocationAlreadyRegistered(ChatClientBuilder builder)
    {
        IList? factories;
        try
        {
            var field = typeof(ChatClientBuilder).GetField(
                "_clientFactories",
                BindingFlags.Instance | BindingFlags.NonPublic);
            factories = field?.GetValue(builder) as IList;
        }
#pragma warning disable CA1031 // generic-catch acceptable: reflection probe is best-effort
        catch
#pragma warning restore CA1031
        {
            return;
        }
        if (factories is null || factories.Count == 0) return;

        var fnInvokerType = typeof(FunctionInvokingChatClient);

        using var sentinel = new NullChatClient();
        var emptyServices = EmptyServiceProvider.Instance;

        foreach (var f in factories)
        {
            if (f is not Delegate del) continue;
            object? produced;
            try
            {
                var ps = del.Method.GetParameters();
                produced = ps.Length switch
                {
                    1 => del.DynamicInvoke(sentinel),
                    2 => del.DynamicInvoke(sentinel, emptyServices),
                    _ => null,
                };
            }
#pragma warning disable CA1031 // generic-catch acceptable: factory dry-run is best-effort
            catch
#pragma warning restore CA1031
            {
                continue;
            }
            if (produced is null) continue;

            bool isFnInvoker = fnInvokerType.IsInstanceOfType(produced);
            if (!isFnInvoker && produced is IChatClient producedClient)
            {
                try { isFnInvoker = producedClient.GetService(fnInvokerType) is not null; }
#pragma warning disable CA1031
                catch { isFnInvoker = false; }
#pragma warning restore CA1031
            }

            if (isFnInvoker)
            {
                if (produced is IDisposable disp)
                {
                    try { disp.Dispose(); }
#pragma warning disable CA1031
                    catch { /* best effort */ }
#pragma warning restore CA1031
                }
                throw new InvalidOperationException(
                    "AgentShield is being registered INSIDE Microsoft.Extensions.AI's " +
                    "UseFunctionInvocation() (.UseFunctionInvocation() was called on " +
                    "this ChatClientBuilder before .UseAgentShield()). At Build() time " +
                    "the function-invoker becomes the OUTER delegating client and " +
                    "GuardedChatClient ends up inside it — every AIFunction in " +
                    "ChatOptions.Tools is dispatched by the outer invoker against the " +
                    "caller's UNWRAPPED tools, silently bypassing Stage 3 (tool " +
                    "admission) and Stage 4 (post-tool) gating. " +
                    "Fix: place .UseAgentShield(shield) BEFORE .UseFunctionInvocation() " +
                    "in the builder chain so the GuardedChatClient wraps the " +
                    "function-invoking middleware. See sdk/dotnet/README.md " +
                    "(\"Microsoft.Extensions.AI — DelegatingChatClient decorator chain\") " +
                    "for the canonical order.");
            }

            if (produced is IDisposable producedDisposable)
            {
                try { producedDisposable.Dispose(); }
#pragma warning disable CA1031
                catch { /* best effort */ }
#pragma warning restore CA1031
            }
        }
    }

    private sealed class NullChatClient : IChatClient
    {
        public Task<ChatResponse> GetResponseAsync(
            IEnumerable<ChatMessage> messages,
            ChatOptions? options = null,
            CancellationToken cancellationToken = default) =>
            Task.FromResult(new ChatResponse());

        public async IAsyncEnumerable<ChatResponseUpdate> GetStreamingResponseAsync(
            IEnumerable<ChatMessage> messages,
            ChatOptions? options = null,
            [System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            await Task.CompletedTask.ConfigureAwait(false);
            yield break;
        }

        public object? GetService(Type serviceType, object? serviceKey = null) => null;
        public void Dispose() { }
    }

    private sealed class EmptyServiceProvider : IServiceProvider
    {
        public static readonly EmptyServiceProvider Instance = new();
        public object? GetService(Type serviceType) => null;
    }
}
