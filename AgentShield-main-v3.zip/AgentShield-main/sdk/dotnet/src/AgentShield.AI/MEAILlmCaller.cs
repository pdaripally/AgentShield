using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.AI;

using AgentShield;

namespace AgentShield.AI;

/// <summary>
/// Microsoft.Extensions.AI <see cref="ILlmCaller"/> adapter for guard-policy
/// LLM judges. It resolves the YAML <c>configurations[]</c> entry, requires
/// an explicit model, forwards supported options through <see cref="ChatOptions"/>,
/// and parses the response as the <see cref="LlmResponse"/> JSON wire shape.
/// </summary>
public sealed class MEAILlmCaller : ILlmCaller
{
    private readonly IChatClient _chatClient;
    private GuardrailsRuntime? _runtime;

    public MEAILlmCaller(IChatClient chatClient)
    {
        _chatClient = chatClient ?? throw new ArgumentNullException(nameof(chatClient));
    }

    /// <summary>
    /// Bind the caller to a <see cref="GuardrailsRuntime"/> so it can
    /// look up <c>configurations[]</c> entries by id at call time.
    /// Invoked by the <see cref="ShieldExtensions.WithLlmJudge"/>
    /// post-build hook. Mirrors the Python
    /// <c>_ConfigurationResolverHolder.bind</c> pattern.
    /// </summary>
    public void Bind(GuardrailsRuntime runtime)
    {
        _runtime = runtime ?? throw new ArgumentNullException(nameof(runtime));
    }

    public LlmResponse Call(LlmRequest request)
    {
        LlmConfiguration? cfg = null;
        if (_runtime != null && !string.IsNullOrEmpty(request.ConfigurationId))
        {
            try
            {
                cfg = _runtime.LlmConfiguration(request.ConfigurationId);
            }
            catch
            {
                // Resolver lookup must never break the LLM caller with an
                // internal error — surface the missing-model condition
                // directly so SREs see a load-time-shaped message rather
                // than a transport failure.
                cfg = null;
            }
        }

        if (cfg == null || string.IsNullOrEmpty(cfg.Model))
        {
            // A security library MUST NOT pick a model on the
            // customer's behalf. The schema rejects entries missing
            // `model:` at load time; this throw fires only when an
            // out-of-band configuration source bypasses validation.
            //
            // `cfg.Model` is the identifier passed verbatim to
            // the provider SDK (a model name for direct OpenAI, a
            // deployment name for Azure OpenAI). The adapter does not
            // synthesize or translate it.
            throw new ConfigurationMissingModelException(request.ConfigurationId);
        }

        var options = new ChatOptions
        {
            ModelId = cfg.Model!,
        };
        if (cfg.MaxTokens.HasValue) options.MaxOutputTokens = (int)cfg.MaxTokens.Value;

        var messages = new[] { new ChatMessage(ChatRole.User, request.Prompt) };

        // The Rust core invokes ILlmCaller.Call synchronously — bridge
        // through to the async chat client with GetAwaiter().GetResult().
        // Matches the sync_client.chat.completions.create(...) pattern
        // in the Python adapter and the napi-rs sync-blocking call in
        // the Node adapter.
        var response = _chatClient.GetResponseAsync(messages, options)
            .ConfigureAwait(false)
            .GetAwaiter()
            .GetResult();

        var text = response?.Text ?? string.Empty;
        return ParseResponse(text);
    }

    private static LlmResponse ParseResponse(string text)
    {
        if (string.IsNullOrWhiteSpace(text))
        {
            return LlmResponse.Allow(reason: "");
        }

        // The judge LLM is expected to return a JSON verdict matching
        // the LlmResponse wire shape. If parsing fails, treat the
        // text as a free-form rationale and default to allow — the
        // guard-policy engine still gets the reason via the envelope.
        try
        {
            using var doc = JsonDocument.Parse(text);
            if (doc.RootElement.ValueKind != JsonValueKind.Object)
            {
                return LlmResponse.Allow(reason: text);
            }

            var root = doc.RootElement;
            string decision = "allow";
            if (root.TryGetProperty("decision", out var decisionEl) && decisionEl.ValueKind == JsonValueKind.String)
            {
                decision = decisionEl.GetString() ?? "allow";
            }

            double confidence = 1.0;
            if (root.TryGetProperty("confidence", out var confidenceEl) && confidenceEl.ValueKind == JsonValueKind.Number)
            {
                confidence = confidenceEl.GetDouble();
            }

            string? reason = null;
            if (root.TryGetProperty("reason", out var reasonEl) && reasonEl.ValueKind == JsonValueKind.String)
            {
                reason = reasonEl.GetString();
            }

            List<string>? categories = null;
            if (root.TryGetProperty("categories", out var catsEl) && catsEl.ValueKind == JsonValueKind.Array)
            {
                categories = new List<string>();
                foreach (var c in catsEl.EnumerateArray())
                {
                    if (c.ValueKind == JsonValueKind.String)
                        categories.Add(c.GetString() ?? "");
                }
            }

            Dictionary<string, bool>? boolFlags = null;
            if (root.TryGetProperty("bool_flags", out var flagsEl) && flagsEl.ValueKind == JsonValueKind.Object)
            {
                boolFlags = new Dictionary<string, bool>();
                foreach (var kv in flagsEl.EnumerateObject())
                {
                    if (kv.Value.ValueKind == JsonValueKind.True || kv.Value.ValueKind == JsonValueKind.False)
                        boolFlags[kv.Name] = kv.Value.GetBoolean();
                }
            }

            return new LlmResponse(decision, confidence, reason, categories, boolFlags);
        }
        catch (JsonException)
        {
            return LlmResponse.Allow(reason: text);
        }
    }
}
