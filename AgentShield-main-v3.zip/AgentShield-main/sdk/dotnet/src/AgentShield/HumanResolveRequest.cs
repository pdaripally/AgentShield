using System.Text.Json;

namespace AgentShield;

/// <summary>
/// Envelope delivered to an <see cref="IHumanResolver"/>
/// callback registered via
/// <see cref="ShieldBuilder.WithHumanResolver(IHumanResolver)"/>.
/// Mirrors the Rust
/// <c>agent_shield_core::resolver_runtime::HumanResolveRequest</c>
/// shape (and the Python <c>HumanResolveRequest</c> dataclass) so a
/// guardrails file authored against any SDK lands identical host-side
/// data in every other binding.
///
/// <para>
/// All fields except <see cref="RequestId"/> and <see cref="Context"/>
/// are nullable: the runtime emits <c>null</c> for any field that
/// was not bound at the gating site. The flat
/// <see cref="ResourceKind"/> / <see cref="ResourceName"/> /
/// <see cref="ResourceParams"/> mirror what
/// <see cref="ResolverRequest"/> exposes for the agent / delegate
/// kinds; the nested <see cref="Resource"/> envelope is also
/// populated when both kind and name are bound.
/// </para>
///
/// <para>
/// <see cref="ApprovalNonce"/> carries the spec /// cryptographically-unpredictable anti-replay token. Hosts that
/// queue approval requests out-of-band MUST echo back the same
/// nonce on the response so the runtime's binding-check site can
/// fail closed on a stale or substituted approval.
/// </para>
///
/// <para>
/// <see cref="TimeoutMs"/> reflects the resolver's
/// <c>timeout_ms:</c> declaration in YAML or the runtime's
/// host-defined default when omitted.
/// </para>
/// </summary>
public sealed record HumanResolveRequest(
    string RequestId,
    string? Variable,
    string? ResourceKind,
    string? ResourceName,
    string? Prompt,
    string? Reason,
    JsonElement Context,
    string ApprovalNonce,
    string? InvocationHash = null,
    string? SessionId = null,
    int? TimeoutMs = null,
    JsonElement? ResourceParams = null,
    JsonElement? RequestedKey = null,
    ResolverResource? Resource = null);
