using System.Text.Json;
using System.Text.Json.Serialization;

namespace AgentShield;

/// <summary>
/// Centralised <see cref="JsonSerializerOptions"/> used by every
/// canonical Agent Shield wire envelope. The Rust core emits
/// snake_case JSON; the .NET surface uses PascalCase records. This
/// single configured options instance handles every conversion so we
/// never need per-property <c>[JsonPropertyName]</c> attributes.
/// </summary>
internal static class AgentShieldJsonOptions
{
    /// <summary>
    /// Default options:
    ///   - <c>SnakeCaseLower</c> property naming (matches the Rust core wire shape).
    ///   - Case-insensitive matching on read so spec drift doesn't cause silent loss.
    ///   - Snake-case-named string converters for every wire enum.
    ///   - Skip <c>null</c> properties on write so optional fields stay omitted.
    /// </summary>
    public static readonly JsonSerializerOptions Default = Build();

    private static JsonSerializerOptions Build()
    {
        var opts = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower,
            DictionaryKeyPolicy = JsonNamingPolicy.SnakeCaseLower,
            PropertyNameCaseInsensitive = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
        };
        opts.Converters.Add(new JsonStringEnumConverter(JsonNamingPolicy.SnakeCaseLower));
        return opts;
    }
}
