using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace AgentShield;

/// <summary>
/// Outcome of a stage validation. Wire format mirrors StageVerdict:
/// <code>
/// {"allowed": bool, "action": "block"|"warn"|"redact"|"append"|"prepend"|null,
///  "reason": string|null, "policy": string|null,
///  "evaluate_when_index": int|null,
///  "bypassed_by_allowed_when": bool,
///  "redaction": string|null, "appended": string|null, "prepended": string|null,
///  "pending_resolution": object|null,
///  "invocation_hash": string|null,
///  "post_validation_invocation_hash": string|null,
///  "applied_transforms": object[]}
/// </code>
/// </summary>
/// <remarks>
/// <para>
/// <c>InvocationHash</c> and <c>PostValidationInvocationHash</c> carry the
/// SHA-256 canonical invocation hash for invocation-bound stages.
/// The host MUST execute the post-validation
/// invocation and MUST NOT execute a later-mutated invocation under
/// the prior verdict. Both fields are <c>null</c> on input / output
/// stages and on verdicts emitted before this branch.
/// </para>
/// <para>
/// <c>AppliedTransforms</c> is the ordered manifest of every
/// redaction / append / prepend that fired during the stage. Spec
/// documents this as a structured provenance log so hosts can
/// audit / replay transforms, achieve cross-process telemetry parity
/// with the Python / Node SDKs, and (for Stage 4 specifically) map
/// canonical char-spans back to their owning string leaves of a
/// structured tool-call result. The Rust core's FFI always emits the
/// field (possibly as an empty array); deserialising into a list
/// preserves that provenance to .NET hosts. Optional / nullable for
/// backward compatibility with customer-constructed
/// <see cref="StageVerdict"/> literals from before this field
/// existed.
/// </para>
/// </remarks>
public sealed record StageVerdict(
    bool Allowed,
    string? Action,
    string? Reason,
    string? Policy,
    int? EvaluateWhenIndex,
    bool BypassedByAllowedWhen,
    string? Redaction,
    string? Appended,
    string? Prepended,
    PendingResolution? PendingResolution = null,
    string? InvocationHash = null,
    string? PostValidationInvocationHash = null,
    IReadOnlyList<AppliedTransform>? AppliedTransforms = null)
{
    /// <summary>Convenience constant for an unconditional allow.</summary>
    public static StageVerdict Allow { get; } =
        new(true, null, null, null, null, false, null, null, null, null, null, null, null);

    internal static StageVerdict FromJson(string json)
    {
        if (string.IsNullOrEmpty(json))
            throw new InvalidOperationException("Empty StageVerdict JSON");

        return JsonSerializer.Deserialize<StageVerdict>(json, AgentShieldJsonOptions.Default)
            ?? throw new InvalidOperationException($"Invalid StageVerdict JSON: {json}");
    }
}

/// <summary>
/// Side-channel description of a deny that was caused by a
/// <c>kind: tool</c> (or synthesised <c>kind: human</c>) resolver
/// suspending while waiting for the agent to call its tool.
/// </summary>
/// <remarks>
/// The host is expected to surface this to the agent's framework so
/// the agent's LLM calls the named tool with the rendered prompt; the
/// tool's <c>populated_by:</c> writes the response back into the
/// variable, which unblocks the next gate evaluation.
/// </remarks>
public sealed record PendingResolution(
    [property: JsonPropertyName("tool")] string Tool,
    [property: JsonPropertyName("variable")] string Variable,
    [property: JsonPropertyName("prompt")] string? Prompt,
    [property: JsonPropertyName("request_id")] string RequestId,
    [property: JsonPropertyName("kind")] string Kind);

