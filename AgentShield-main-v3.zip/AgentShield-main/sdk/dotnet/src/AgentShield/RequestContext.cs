using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace AgentShield;

/// <summary>
/// Per-session request envelope passed to <see cref="GuardrailsRuntime.NewSession"/>.
/// Mirrors the Rust <c>RequestContext</c> struct (spec §3.4).
/// All fields are optional; the runtime auto-generates session/correlation ids
/// when they are not provided.
/// </summary>
public sealed record RequestContext(
    string? UserId = null,
    string? TenantId = null,
    string? SessionId = null,
    string? CorrelationId = null,
    IReadOnlyDictionary<string, JsonElement>? Extensions = null)
{
    /// <summary>Empty default context — runtime fills in session/correlation ids.</summary>
    public static RequestContext Default => new();

    internal string? ToJson()
    {
        if (UserId is null && TenantId is null && SessionId is null
            && CorrelationId is null && (Extensions is null || Extensions.Count == 0))
        {
            return null;
        }

        var dict = new Dictionary<string, object?>();
        if (UserId is not null) dict["user_id"] = UserId;
        if (TenantId is not null) dict["tenant_id"] = TenantId;
        if (SessionId is not null) dict["session_id"] = SessionId;
        if (CorrelationId is not null) dict["correlation_id"] = CorrelationId;
        if (Extensions is { Count: > 0 })
        {
            var exts = new Dictionary<string, JsonElement>();
            foreach (var kv in Extensions) exts[kv.Key] = kv.Value;
            dict["extensions"] = exts;
        }
        return JsonSerializer.Serialize(dict);
    }
}
