using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text.Json.Nodes;

using AgentShield.Interop;

namespace AgentShield;

/// <summary>
/// Immutable guardrails runtime. Construct via
/// <see cref="RuntimeBuilder"/> then create per-request sessions with
/// <see cref="NewSession"/>. A runtime is safe to share across threads;
/// each thread should obtain its own session.
/// </summary>
public sealed class GuardrailsRuntime : IDisposable
{
    private IntPtr _handle;
    private bool _disposed;
    private readonly List<GCHandle> _pinnedDelegates;

    internal GuardrailsRuntime(IntPtr handle, List<GCHandle> pinnedDelegates)
    {
        _handle = handle;
        _pinnedDelegates = pinnedDelegates;
    }

    ~GuardrailsRuntime()
    {
        DisposeCore();
    }

    /// <summary>Convenience: build a runtime directly from a YAML path.</summary>
    public static GuardrailsRuntime FromYaml(string path)
    {
        using var b = RuntimeBuilder.FromYaml(path);
        return b.Build();
    }

    /// <summary>Convenience: build a runtime from a chain of YAML paths.</summary>
    public static GuardrailsRuntime FromYamlChain(IEnumerable<string> paths)
    {
        using var b = RuntimeBuilder.FromYamlChain(paths);
        return b.Build();
    }

    /// <summary>Open a per-request session. Default <see cref="RequestContext"/> is used when omitted.</summary>
    public GuardrailsSession NewSession(RequestContext? context = null)
    {
        ThrowIfDisposed();
        var ctxJson = (context ?? RequestContext.Default).ToJson();
        var sessHandle = NativeMethods.shield_runtime_new_session(_handle, ctxJson, out var err);
        NativeMethods.ThrowIfErr(err);
        if (sessHandle == IntPtr.Zero)
            throw new GuardrailsException("shield_runtime_new_session returned null");
        var session = new GuardrailsSession(sessHandle);
        if (context?.CorrelationId is not null)
            session.SetCorrelationId(context.CorrelationId);
        return session;
    }

    /// <summary>
    /// Effective runtime mode (#14): <c>"active"</c> or
    /// <c>"shadow"</c>. YAML <c>mode:</c> with
    /// <c>AGENT_SHIELD_MODE</c> env override. Shadow forces the
    /// <see cref="Shield"/> to <see cref="ShieldMode.Monitor"/>.
    /// </summary>
    public string Mode
    {
        get
        {
            ThrowIfDisposed();
            var ptr = NativeMethods.shield_runtime_mode(_handle);
            if (ptr == IntPtr.Zero) return "active";
            return Marshal.PtrToStringUTF8(ptr) ?? "active";
        }
    }

    /// <summary>
    /// Look up a <c>configurations[]</c> entry by id.
    /// Returns a typed <see cref="AgentShield.LlmConfiguration"/> for
    /// the resolved entry, or <c>null</c> when no entry matches.
    ///
    /// <para>
    /// Mirrors <c>Runtime.llm_configuration(id)</c> (Python) and
    /// <c>Runtime.llmConfiguration(id)</c> (Node). Adapter LLM-callers
    /// invoke this from inside their <see cref="ILlmCaller.Call"/>
    /// implementation, passing
    /// <c>request.ConfigurationId</c>, to drive per-stage
    /// model / max_tokens choices from YAML rather than hard-coding a
    /// fallback (see <see cref="AgentShield.AI.MEAILlmCaller"/> in the
    /// Microsoft.Extensions.AI adapter).
    /// </para>
    /// </summary>
    public LlmConfiguration? LlmConfiguration(string configurationId)
    {
        ThrowIfDisposed();
        if (configurationId == null) throw new ArgumentNullException(nameof(configurationId));
        var ptr = NativeMethods.shield_runtime_llm_configuration(_handle, configurationId, out var err);
        NativeMethods.ThrowIfErr(err);
        var json = NativeMethods.ReadAndFreeString(ptr);
        if (json == null) return null;
        return System.Text.Json.JsonSerializer.Deserialize<LlmConfiguration>(json);
    }

    /// <summary>
    /// Look up ANY <c>configurations[]</c> entry by id, regardless of
    /// <c>type:</c>. Returns every populated field as a
    /// <see cref="JsonNode"/> — including classifier-specific
    /// (<c>headers</c>, <c>threshold</c>, <c>category_thresholds</c>,
    /// <c>method</c>) and HTTP-endpoint / MCP / A2A fields that
    /// <see cref="LlmConfiguration(string)"/> omits — or
    /// <c>null</c> when no entry matches.
    ///
    /// <para>
    /// Mirrors <c>Runtime.configuration(id)</c> in Python and
    /// Node. The JSON payload is
    /// byte-equivalent across all three SDKs for the same merged
    /// YAML — that byte equivalence is the cross-SDK regression
    /// contract. Keys remain in YAML snake_case so the
    /// host can forward the blob to provider SDKs (e.g. Azure AI
    /// Content Safety) without back-converting from .NET
    /// PascalCase.
    /// </para>
    ///
    /// <para>
    /// Classifier callers (<see cref="IClassifierCaller"/>
    /// implementations) invoke this from inside their
    /// <c>Call</c> implementation, passing
    /// <c>request.ConfigurationId</c>, so they can read endpoint /
    /// headers / threshold / category_thresholds / provider_config
    /// directly from YAML — no parallel YAML→config map in host
    /// code, no second YAML parse. This is the parity fix for the
    /// Azure AI Content Safety dispatcher and any custom-model
    /// classifier the host wires up.
    /// </para>
    /// </summary>
    public JsonNode? Configuration(string configurationId)
    {
        ThrowIfDisposed();
        if (configurationId == null) throw new ArgumentNullException(nameof(configurationId));
        var ptr = NativeMethods.shield_runtime_configuration(_handle, configurationId, out var err);
        NativeMethods.ThrowIfErr(err);
        var json = NativeMethods.ReadAndFreeString(ptr);
        if (json == null) return null;
        return JsonNode.Parse(json);
    }

    /// <summary>Get the native ABI version string.</summary>
    public static string Version
    {
        get
        {
            var ptr = NativeMethods.shield_version();
            return Marshal.PtrToStringUTF8(ptr) ?? "unknown";
        }
    }

    public void Dispose()
    {
        DisposeCore();
        GC.SuppressFinalize(this);
    }

    /// <summary>
    /// Block until every registered observability provider has
    /// drained the events emitted so far. Hosts that synchronously
    /// inspect captured events after a <c>Validate*</c> call MUST
    /// flush first; the per-provider worker model otherwise leaves
    /// events buffered for an indeterminate window.
    /// </summary>
    public void FlushObservability()
    {
        if (_handle == IntPtr.Zero) return;
        NativeMethods.shield_runtime_flush_observability(_handle);
    }

    private void DisposeCore()
    {
        if (_disposed) return;
        _disposed = true;

        if (_handle != IntPtr.Zero)
        {
            NativeMethods.shield_runtime_free(_handle);
            _handle = IntPtr.Zero;
        }

        // Free pinned delegates after the runtime — the runtime may
        // still be invoking them up until shield_runtime_free returns.
        foreach (var h in _pinnedDelegates)
            if (h.IsAllocated) h.Free();
        _pinnedDelegates.Clear();
    }

    private void ThrowIfDisposed()
    {
        if (_disposed) throw new GuardrailsDisposedException(nameof(GuardrailsRuntime));
    }
}
