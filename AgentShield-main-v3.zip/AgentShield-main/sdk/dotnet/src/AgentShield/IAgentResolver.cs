namespace AgentShield;

/// <summary>
/// Host-side resolver for variables flagged with
/// <c>on_demand_by: { kind: "agent" }</c>. The resolver is logically
/// backed by another autonomous agent and returns a wire-shaped
/// <see cref="ResolverResponse"/> for the runtime to write into the
/// target variable.
/// </summary>
public interface IAgentResolver
{
    ResolverResponse Resolve(ResolverRequest request);
}
