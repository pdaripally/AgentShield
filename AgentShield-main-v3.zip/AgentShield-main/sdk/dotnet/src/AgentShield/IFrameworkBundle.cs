using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;

namespace AgentShield;

/// <summary>
/// Wraps a framework's tool object so the <see cref="Shield"/> can
/// install Stage 2/3/4 enforcement around its native call shape.
///
/// <para>
/// The orchestrator drives a guarded turn through three operations:
/// </para>
/// <list type="bullet">
///   <item><see cref="GetName"/> — the tool name as the policy refers to it.</item>
///   <item><see cref="InvokeAsync"/> — call the underlying tool body with
///   (post-Stage-3) mutated args. The orchestrator owns Stage 2/3/4 and
///   <c>record_tool_*</c>; this method is the one bridge to the original
///   framework tool.</item>
///   <item><see cref="Wrap"/> — produce a framework-shaped TOut whose
///   body delegates to <paramref name="guarded"/> at call time. <paramref name="guarded"/>
///   receives the JSON args extracted from the framework's call convention
///   and returns the post-validation output text.</item>
/// </list>
/// </summary>
public interface IToolWrapper<TIn, TOut>
{
    /// <summary>Tool name as the policy YAML refers to it.</summary>
    string GetName(TIn tool);

    /// <summary>JSON-Schema description of the tool's args. Optional —
    /// implementations that have no schema may return an empty object.</summary>
    JsonElement ExtractArgsSchema(TIn tool);

    /// <summary>Invoke the underlying tool body with (post-Stage-3)
    /// mutated args. The orchestrator calls this between Stage 3 and
    /// Stage 4.</summary>
    Task<string> InvokeAsync(TIn tool, JsonElement args);

    /// <summary>
    /// Produce a framework-shaped tool whose body delegates to
    /// <paramref name="guarded"/>. The guarded callback receives the
    /// caller-provided JSON args and returns the validated output text.
    /// </summary>
    TOut Wrap(TIn tool, Func<JsonElement, Task<string>> guarded);
}

/// <summary>
/// Optional capability for adapters that know how to drive an agent's
/// run loop themselves. When present, callers can use
/// <see cref="Shield.RunAsync{TResult}"/> with a typed agent and a
/// boundary instead of writing the <c>execute</c> closure by hand.
/// </summary>
public interface IAgentBoundary<TAgent>
{
    /// <summary>Run the agent. Returns whatever the framework returns.</summary>
    Task<object?> RunAsync(TAgent agent, string input);

    /// <summary>Pull the final assistant text out of the framework result.</summary>
    string? ExtractOutput(object? result);

    /// <summary>Apply a Stage 5 redaction to the framework result.</summary>
    object? ApplyRedaction(object? result, string redacted);

    /// <summary>Build the framework's idiomatic blocked result.</summary>
    object? MakeBlocked(string message);
}

/// <summary>
/// Optional capability for adapters that drive token-by-token streaming.
/// </summary>
public interface IStreamingAdapter<TAgent>
{
    /// <summary>Yield validated chunks for an agent run.</summary>
    IAsyncEnumerable<string> StreamAsync(TAgent agent, string input);
}

/// <summary>
/// Container for the optional capabilities a framework adapter may
/// register through <see cref="ShieldBuilder.WithCapability"/>.
/// </summary>
public sealed class FrameworkBundle
{
    public CapabilityReport Capabilities { get; }
    public object? ToolWrapper { get; }
    public object? AgentBoundary { get; }
    public object? StreamingAdapter { get; }

    public FrameworkBundle(
        CapabilityReport capabilities,
        object? toolWrapper = null,
        object? agentBoundary = null,
        object? streamingAdapter = null)
    {
        Capabilities = capabilities ?? throw new ArgumentNullException(nameof(capabilities));
        ToolWrapper = toolWrapper;
        AgentBoundary = agentBoundary;
        StreamingAdapter = streamingAdapter;
    }
}
