// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

namespace AgentShield;

/// <summary>
/// Gating level for the v8 perf-logging instrumentation (PR5 / PR6).
/// Mirrors the Rust <c>agent_shield_core::PerfTelemetry</c> enum and
/// the Python <c>agent_shield.PerfTelemetry</c> enum. Wire shape: a
/// single byte at the FFI boundary (<c>0 = Off</c>, <c>1 = External</c>,
/// <c>2 = Full</c>).
/// </summary>
/// <remarks>
/// <para>Set on the runtime via
/// <see cref="RuntimeBuilder.WithPerfTelemetry(PerfTelemetry)"/> or
/// <see cref="ShieldBuilder.WithPerfTelemetry(PerfTelemetry)"/>. Default
/// — when neither method is called — is <see cref="Off"/>, which emits
/// zero perf events and keeps the event stream byte-identical to the
/// pre-v8 baseline.</para>
///
/// <para>See <c>spec/SPECIFICATION.md</c> §19 for the per-event
/// gating contract.</para>
/// </remarks>
public enum PerfTelemetry : byte
{
    /// <summary>
    /// No perf events emit. The legacy event stream
    /// (gating verdicts, resolver invocations, load errors, warnings,
    /// closed-namespace bus events) is byte-identical to the pre-v8
    /// baseline. This is the default.
    /// </summary>
    Off = 0,

    /// <summary>
    /// Only <c>llm_called</c> and <c>classifier_called</c> events
    /// emit. Predicted common-case ask for adopters who want
    /// external-service cost signals without being drowned by stage /
    /// policy / detection events. Each emitted event carries the
    /// AC10-Corr correlation attributes (<c>agent_shield.guard_policy</c>,
    /// <c>agent_shield.stage</c>,
    /// <c>agent_shield.evaluate_when_index</c>) so adopters can
    /// attribute LLM/classifier cost back to the triggering policy.
    /// </summary>
    External = 1,

    /// <summary>
    /// Every perf event emits: <c>stage_evaluated</c>,
    /// <c>policy_evaluated</c>, plus <c>llm_called</c> and
    /// <c>classifier_called</c>. Diagnostic mode — verbose; pick this
    /// for performance triage runs, not steady-state production.
    /// </summary>
    Full = 2,
}
