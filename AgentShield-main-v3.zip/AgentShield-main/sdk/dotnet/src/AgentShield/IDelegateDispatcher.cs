using System.Text.Json;

namespace AgentShield;

/// <summary>
/// Envelope passed to the delegate dispatcher for configuration-backed
/// resources (HTTP endpoints, classifiers, MCP servers, A2A agents, LLMs).
///
/// <para>
/// <see cref="Lifetime"/> is the resolver's <c>lifetime:</c> declaration
/// per spec §11.12.1. When non-<c>null</c>, the dispatcher SHOULD
/// forward it verbatim onto the protocol-specific request body so the
/// remote endpoint can mint a per-call lifetime envelope. <c>null</c>
/// when the resolver did not declare a lifetime.
/// </para>
/// </summary>
public sealed record DelegateRequest(
    string ConfigurationId,
    string ConfigurationType,
    JsonElement Configuration,
    ResolverRequest Base,
    JsonElement? Lifetime = null);

/// <summary>
/// Host-side dispatcher that wires a resource invocation to the
/// configured backend (HTTP, classifier, MCP server, A2A agent, etc.).
/// A single pluggable hook covering all configuration-backed resources
/// (spec §11.6).
/// </summary>
public interface IDelegateDispatcher
{
    ResolverResponse Dispatch(DelegateRequest request);
}
