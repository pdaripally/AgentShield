using System;
using System.Collections.Generic;
using System.Text.Json;

namespace AgentShield;

/// <summary>
/// Fluent builder for <see cref="Shield"/>. Mirrors the Python
/// <c>ShieldBuilder</c> surface and the Node <c>ShieldBuilder</c> chain
/// so the customer-facing ergonomics stay identical across SDKs.
///
/// <para>
/// Construct via <see cref="Shield.FromYaml(string)"/>,
/// <see cref="Shield.FromYaml(IReadOnlyList{string})"/>, or
/// <see cref="Shield.FromRuntime"/>; chain <c>WithLlm</c>,
/// <c>WithAgentResolver</c>, <c>WithExtractor</c>, etc.; finish with
/// <see cref="Build"/>.
/// </para>
/// </summary>
public sealed class ShieldBuilder
{
    private const string ConsumedMessage =
        "ShieldBuilder.Build() can only be called once. " +
        "Call Shield.FromYaml(...) again to create a new builder.";

    private readonly RuntimeBuilder? _runtimeBuilder;
    private readonly GuardrailsRuntime? _runtime;
    private readonly bool _ownsRuntime;
    private bool _consumed;

    private ILlmCaller? _llmCaller;
    private IClassifierCaller? _classifierCaller;
    private readonly Dictionary<string, IExtractor> _extractors = new();
    private IAgentResolver? _agentResolver;
    private IHumanResolver? _humanResolver;
    private IDelegateDispatcher? _delegateDispatcher;
    private readonly List<IObservabilityProvider> _observabilityProviders = new();
    private ShieldMode _mode = ShieldMode.Enforce;
    private OnBlockPolicy _onBlock = OnBlockPolicy.ReturnBlocked;
    // track whether `WithOnBlock(policy|callback)` was called
    // explicitly. When false, the Pattern C `Shield.RunAsync` surface
    // defaults to `Raise` (the new safer default); when true, the
    // shield-level policy / callback continues to govern `RunAsync`
    // for backward compatibility with existing customer setups.
    private bool _onBlockExplicitlySet;
    private Func<StageVerdict?, string, object?>? _onBlockCallback;
    private CapabilityReport _capabilities = new("custom");
    private FrameworkBundle? _bundle;
    private readonly List<Action<GuardrailsRuntime>> _postBuildHooks = new();
    private readonly List<Action<Shield>> _postBuildShieldHooks = new();
    private PerfTelemetry? _perfTelemetry;

    internal ShieldBuilder(RuntimeBuilder runtimeBuilder)
    {
        _runtimeBuilder = runtimeBuilder ?? throw new ArgumentNullException(nameof(runtimeBuilder));
        _ownsRuntime = true;
    }

    internal ShieldBuilder(GuardrailsRuntime runtime, bool ownsRuntime = false)
    {
        _runtime = runtime ?? throw new ArgumentNullException(nameof(runtime));
        _ownsRuntime = ownsRuntime;
    }

    private void ThrowIfConsumed()
    {
        if (_consumed) throw new InvalidOperationException(ConsumedMessage);
    }

    /// <summary>Register the LLM caller used by guard policies.</summary>
    public ShieldBuilder WithLlm(ILlmCaller caller)
    {
        ThrowIfConsumed();
        _llmCaller = caller ?? throw new ArgumentNullException(nameof(caller));
        return this;
    }

    /// <summary>Register a classifier caller (returns score + threshold).</summary>
    public ShieldBuilder WithClassifier(IClassifierCaller caller)
    {
        ThrowIfConsumed();
        _classifierCaller = caller ?? throw new ArgumentNullException(nameof(caller));
        return this;
    }

    /// <summary>Register a value extractor by name.</summary>
    public ShieldBuilder WithExtractor(string name, IExtractor extractor)
    {
        ThrowIfConsumed();
        if (string.IsNullOrEmpty(name)) throw new ArgumentException("name is required", nameof(name));
        if (extractor == null) throw new ArgumentNullException(nameof(extractor));
        _extractors[name] = extractor;
        return this;
    }

    /// <summary>Register the agent-resolver callback.</summary>
    public ShieldBuilder WithAgentResolver(IAgentResolver resolver)
    {
        ThrowIfConsumed();
        _agentResolver = resolver ?? throw new ArgumentNullException(nameof(resolver));
        return this;
    }

    /// <summary>
    /// Register the active <c>kind: human</c> resolver for this runtime.
    /// YAML does not name the handler; if none is registered,
    /// <c>kind: human</c> denies fail-closed. Last call wins.
    /// </summary>
    public ShieldBuilder WithHumanResolver(IHumanResolver resolver)
    {
        ThrowIfConsumed();
        _humanResolver = resolver ?? throw new ArgumentNullException(nameof(resolver));
        return this;
    }

    /// <summary>Register the delegate dispatcher.</summary>
    public ShieldBuilder WithDelegateDispatcher(IDelegateDispatcher dispatcher)
    {
        ThrowIfConsumed();
        _delegateDispatcher = dispatcher ?? throw new ArgumentNullException(nameof(dispatcher));
        return this;
    }

    /// <summary>Register an observability provider.</summary>
    public ShieldBuilder WithObservability(IObservabilityProvider provider)
    {
        ThrowIfConsumed();
        if (provider == null) throw new ArgumentNullException(nameof(provider));
        _observabilityProviders.Add(provider);
        return this;
    }

    /// <summary>Set <see cref="ShieldMode.Enforce"/> or <see cref="ShieldMode.Monitor"/>.</summary>
    public ShieldBuilder WithMode(ShieldMode mode)
    {
        ThrowIfConsumed();
        _mode = mode;
        return this;
    }

    /// <summary>Set the on-block policy.</summary>
    public ShieldBuilder WithOnBlock(OnBlockPolicy policy)
    {
        ThrowIfConsumed();
        _onBlock = policy;
        _onBlockCallback = null;
        _onBlockExplicitlySet = true;
        return this;
    }

    /// <summary>Set a custom on-block callback. Receives the verdict (may be null
    /// for non-verdict block paths) and the formatted block message; whatever
    /// the callback returns is forwarded back to the caller, attempting to
    /// coerce to the target <c>TResult</c>.</summary>
    public ShieldBuilder WithOnBlock(Func<StageVerdict?, string, object?> custom)
    {
        ThrowIfConsumed();
        _onBlockCallback = custom ?? throw new ArgumentNullException(nameof(custom));
        _onBlockExplicitlySet = true;
        return this;
    }

    /// <summary>
    /// Set the capability report this Shield exposes. Per-adapter
    /// extension methods (e.g. <c>WithAutoGen</c>, <c>WithSemanticKernel</c>)
    /// call this with their honest profile.
    /// </summary>
    public ShieldBuilder WithCapability(CapabilityReport report)
    {
        ThrowIfConsumed();
        _capabilities = report ?? throw new ArgumentNullException(nameof(report));
        return this;
    }

    /// <summary>
    /// Attach an optional <see cref="FrameworkBundle"/>. Per-adapter
    /// extension methods supply this so <see cref="Shield.ProtectTools"/>
    /// can reach the framework's tool wrapper, etc.
    /// </summary>
    public ShieldBuilder WithBundle(FrameworkBundle bundle)
    {
        ThrowIfConsumed();
        _bundle = bundle ?? throw new ArgumentNullException(nameof(bundle));
        // CapabilityReport tracks whichever the adapter actually
        // declared — bundles always overwrite.
        _capabilities = bundle.Capabilities;
        return this;
    }

    /// <summary>
    /// Register a hook that runs once the <see cref="GuardrailsRuntime"/>
    /// has been built but before the <see cref="Shield"/> is returned
    /// from <see cref="Build"/>. Used by adapter extensions (e.g.
    /// Microsoft.Extensions.AI's <c>WithLlmJudge</c>) that register an
    /// <see cref="ILlmCaller"/> *before* the runtime exists and need
    /// to bind the caller to the runtime's
    /// <see cref="GuardrailsRuntime.LlmConfiguration"/> accessor after
    /// build. Mirrors Python's <c>_ConfigurationResolverHolder.bind</c>
    /// pattern.
    /// </summary>
    public ShieldBuilder WithPostBuildHook(Action<GuardrailsRuntime> hook)
    {
        ThrowIfConsumed();
        if (hook == null) throw new ArgumentNullException(nameof(hook));
        _postBuildHooks.Add(hook);
        return this;
    }

    /// <summary>
    /// Register a hook that runs once the <see cref="Shield"/> itself
    /// has been constructed (after <see cref="WithPostBuildHook"/>
    /// hooks run and the per-shield <see cref="GuardrailsSession"/>
    /// exists) but before <see cref="Build"/> returns. Used by adapter
    /// extensions that need both the runtime and the live session —
    /// e.g. Semantic Kernel's <c>WithSemanticKernel(kernel)</c> uses
    /// it to auto-register the <c>AgentShieldFilter</c> on the kernel
    /// using the Shield's session, so customers don't have to make a
    /// separate <c>AttachFilter</c> call.
    /// </summary>
    public ShieldBuilder WithPostBuildShieldHook(Action<Shield> hook)
    {
        ThrowIfConsumed();
        if (hook == null) throw new ArgumentNullException(nameof(hook));
        _postBuildShieldHooks.Add(hook);
        return this;
    }

    /// <summary>
    /// Opt into the v8 perf-logging instrumentation (PR5 / PR6).
    /// Delegates to <see cref="RuntimeBuilder.WithPerfTelemetry"/> at
    /// <see cref="Build"/> time. Default — when this method is never
    /// called — is <see cref="PerfTelemetry.Off"/>, which emits zero
    /// perf events.
    /// </summary>
    /// <remarks>
    /// Throws <see cref="InvalidOperationException"/> if the builder
    /// was constructed from a pre-built <see cref="GuardrailsRuntime"/>
    /// — perf telemetry MUST be set on the underlying RuntimeBuilder
    /// before <c>Build()</c>; setting it on a wrapping
    /// <see cref="Shield"/> over an already-built runtime would
    /// silently no-op.
    /// </remarks>
    public ShieldBuilder WithPerfTelemetry(PerfTelemetry mode)
    {
        ThrowIfConsumed();
        if (_runtime != null)
        {
            throw new InvalidOperationException(
                "WithPerfTelemetry requires a RuntimeBuilder-backed ShieldBuilder. " +
                "Set the perf-telemetry mode on the RuntimeBuilder before calling " +
                "Shield.FromRuntime, or use Shield.FromYaml(...) instead.");
        }
        _perfTelemetry = mode;
        return this;
    }

    /// <summary>Consume the builder and produce a <see cref="Shield"/>.
    /// May only be called once; subsequent calls (and any further
    /// <c>With*</c> registration) throw <see cref="InvalidOperationException"/>.</summary>
    public Shield Build()
    {
        ThrowIfConsumed();

        GuardrailsRuntime runtime;
        bool ownsRuntime;
        if (_runtime != null)
        {
            runtime = _runtime;
            ownsRuntime = _ownsRuntime;
        }
        else
        {
            var rb = _runtimeBuilder!;
            if (_llmCaller != null) rb.RegisterLlmCaller(_llmCaller);
            if (_classifierCaller != null) rb.RegisterClassifierCaller(_classifierCaller);
            foreach (var (name, ext) in _extractors)
                rb.RegisterExtractor(name, ext);
            if (_agentResolver != null) rb.RegisterAgentResolver(_agentResolver);
            if (_humanResolver != null) rb.RegisterHumanResolver(_humanResolver);
            if (_delegateDispatcher != null) rb.RegisterDelegateDispatcher(_delegateDispatcher);
            foreach (var op in _observabilityProviders)
                rb.RegisterObservabilityProvider(op);
            if (_perfTelemetry.HasValue)
                rb.WithPerfTelemetry(_perfTelemetry.Value);
            runtime = rb.Build();
            ownsRuntime = true;
        }

        foreach (var hook in _postBuildHooks)
            hook(runtime);

        var session = runtime.NewSession();
        var shield = new Shield(
            runtime,
            ownsRuntime,
            session,
            ownsSession: true,
            _capabilities,
            _mode,
            _onBlock,
            _onBlockCallback,
            _bundle,
            _onBlockExplicitlySet);
        foreach (var hook in _postBuildShieldHooks)
            hook(shield);
        _consumed = true;
        return shield;
    }
}
