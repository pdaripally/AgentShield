using System.Text.Json.Nodes;

using AgentShield.Interop;

namespace AgentShield;

/// <summary>
/// Lifetime declaration that pins how long an emitted event remains
/// "fired" (spec §10.1). Every factory canonicalizes its input through
/// the shared native parser
/// (<c>agent_shield_core::lifetime::parse_lifetime</c>) so the .NET
/// surface enforces the same grammar as every other SDK.
/// </summary>
public record Lifetime
{
    internal string Wire { get; init; } = "";

    /// <summary>"per_session" lifetime — fires once and stays set for the session.</summary>
    public static Lifetime Session() => Build("\"per_session\"");

    /// <summary>"per_request" lifetime — cleared on the next request boundary.</summary>
    public static Lifetime PerRequest() => Build("\"per_request\"");

    /// <summary>"per_turn" lifetime — cleared on the next turn boundary.</summary>
    public static Lifetime PerTurn() => Build("\"per_turn\"");

    /// <summary>"per_call" lifetime — cleared after the next stage decision.</summary>
    public static Lifetime PerCall() => Build("\"per_call\"");

    /// <summary>Fire until any of the named events fire.</summary>
    public static Lifetime UntilEvents(params string[] eventIds)
    {
        var arr = new JsonArray();
        foreach (var e in eventIds) arr.Add(e);
        return Build(new JsonObject { ["until_event"] = arr }.ToJsonString());
    }

    /// <summary>Build from raw JSON (for advanced lifetime shapes such as
    /// the variable-only allow/deny/cancelled map form).</summary>
    public static Lifetime FromJson(string json) => Build(json);

    private static Lifetime Build(string json) =>
        new() { Wire = ParseWire(json) };

    /// <summary>Canonicalise the raw JSON via the shared native parser.</summary>
    private protected static string ParseWire(string json)
    {
        var ptr = NativeMethods.shield_parse_lifetime(json, out var err);
        NativeMethods.ThrowIfErr(err);
        return NativeMethods.ReadAndFreeString(ptr)
            ?? throw new ShieldNativeException("shield_parse_lifetime returned null");
    }

    internal string? ToWireJson() => string.IsNullOrEmpty(Wire) ? null : Wire;
}
