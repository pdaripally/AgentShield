using System;

namespace AgentShield;

/// <summary>
/// Canonical block-message formatting. Produces the same
/// <c>[GUARDRAIL &lt;ACTION&gt;] &lt;reason&gt;</c> string the Rust core
/// (<c>agent_shield_core::shield_primitives::format_block_message</c>),
/// the Python orchestrator (<c>format_block_message</c>) and the Node
/// SDK emit. Cross-language byte equivalence is a customer-visible
/// invariant — every SDK speaks the same blocked-message dialect.
///
/// <para>
/// All of the formatting work happens inside the Rust core via
/// <see cref="VerdictDispatcher.FormatBlockMessage(StageVerdict)"/>;
/// this class is a thin façade kept for back-compat with the original
/// <c>BlockMessageFormatter.Format</c> entry point.
/// </para>
/// </summary>
public static class BlockMessageFormatter
{
    private const string DefaultReason = "blocked by policy";

    /// <summary>
    /// Format a verdict as <c>[GUARDRAIL ACTION] reason</c>. Routes
    /// through the canonical core formatter so the byte equivalence
    /// across SDKs is enforced by a single implementation.
    /// </summary>
    public static string Format(StageVerdict? verdict)
    {
        if (verdict is null)
            return $"[GUARDRAIL BLOCK] {DefaultReason}";
        return VerdictDispatcher.FormatBlockMessage(verdict);
    }

    /// <summary>
    /// Format a verdict for a tool call as
    /// <c>[GUARDRAIL ACTION] reason (tool: name)</c>. Matches the Rust
    /// <c>format_tool_block_message</c>.
    /// </summary>
    public static string FormatTool(StageVerdict? verdict, string toolName)
    {
        var baseMsg = Format(verdict);
        return $"{baseMsg} (tool: {toolName})";
    }
}

