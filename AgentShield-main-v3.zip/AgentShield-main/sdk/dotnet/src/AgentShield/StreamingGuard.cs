using System;
using System.Runtime.InteropServices;
using System.Text.Json;

using AgentShield.Interop;

namespace AgentShield;

/// <summary>
/// Streaming stage selector for <see cref="GuardrailsSession.StreamingSession"/>.
/// </summary>
public enum StreamingStage
{
    /// <summary>Stage 4 — post-tool streaming validation.</summary>
    PostTool = 4,
    /// <summary>Stage 5 — output streaming validation.</summary>
    Output = 5,
}

/// <summary>
/// Action returned by a streaming chunk push / finish call. Mirrors
/// <c>StreamChunkAction</c> in the Rust core.
/// </summary>
public enum StreamAction
{
    /// <summary>Forward the chunk unchanged.</summary>
    Pass,
    /// <summary>Emit <see cref="StreamChunkResult.Payload"/> instead of the chunk.</summary>
    Replace,
    /// <summary>Halt streaming — caller must abort the underlying response.</summary>
    Stop,
}

/// <summary>
/// Validation cadence configured on a <see cref="StreamingGuard"/>.
/// Mirrors <c>StreamingTrigger</c> in the Rust core. Drives how the
/// host SDK schedules emissions to the consumer (real-time pass-through
/// vs. buffer-until-finish).
/// </summary>
public enum StreamingMode
{
    /// <summary>
    /// Buffer every chunk and validate once at <see cref="StreamingGuard.Finish"/>.
    /// The host SDK MUST NOT yield text-bearing chunks to the consumer
    /// until <see cref="StreamingGuard.Finish"/> returns; the final
    /// validated payload is emitted as a single chunk.
    /// </summary>
    OnComplete = 0,
    /// <summary>Re-validate every <c>window_size</c> bytes.</summary>
    Windowed = 1,
    /// <summary>Validate after every chunk.</summary>
    PerChunk = 2,
}

/// <summary>
/// Result of a single push / finish on a streaming guard. Wire shape:
/// <code>{"action": "pass"|"replace"|"stop", "payload": string, "reason": string|null}</code>
/// </summary>
public sealed record StreamChunkResult(StreamAction Action, string Payload, string? Reason)
{
    internal static StreamChunkResult FromJson(string json)
    {
        return JsonSerializer.Deserialize<StreamChunkResult>(json, AgentShieldJsonOptions.Default)
            ?? throw new InvalidOperationException($"Invalid streaming JSON: {json}");
    }
}

/// <summary>
/// Streaming guard handle for Stage 4 / Stage 5 chunk-by-chunk
/// validation. Push individual chunks via <see cref="Push"/>; flush at
/// end via <see cref="Finish"/>; always dispose to free the native
/// handle.
/// </summary>
public sealed class StreamingGuard : IDisposable
{
    private IntPtr _handle;
    private bool _disposed;

    internal StreamingGuard(IntPtr handle)
    {
        _handle = handle;
    }

    ~StreamingGuard()
    {
        DisposeCore();
    }

    /// <summary>Push a chunk through the guard.</summary>
    public StreamChunkResult Push(string chunk)
    {
        ThrowIfDisposed();
        var ptr = NativeMethods.shield_stream_push(_handle, chunk, out var err);
        NativeMethods.ThrowIfErr(err);
        var json = NativeMethods.ReadAndFreeString(ptr)
            ?? throw new InvalidOperationException("shield_stream_push returned null");
        return StreamChunkResult.FromJson(json);
    }

    /// <summary>Flush the guard. After this call the guard is finalized.</summary>
    public StreamChunkResult Finish()
    {
        ThrowIfDisposed();
        var ptr = NativeMethods.shield_stream_finish(_handle, out var err);
        NativeMethods.ThrowIfErr(err);
        var json = NativeMethods.ReadAndFreeString(ptr)
            ?? throw new InvalidOperationException("shield_stream_finish returned null");
        return StreamChunkResult.FromJson(json);
    }

    /// <summary>
    /// The validation cadence configured on this guard. Host SDKs use
    /// this to decide whether to forward upstream chunks to the
    /// consumer in real time (<see cref="StreamingMode.PerChunk"/> /
    /// <see cref="StreamingMode.Windowed"/>) or buffer every chunk and
    /// emit only the final validated payload at
    /// <see cref="Finish"/> (<see cref="StreamingMode.OnComplete"/>).
    /// Pure read accessor — never allocates.
    /// </summary>
    public StreamingMode Mode
    {
        get
        {
            ThrowIfDisposed();
            var raw = NativeMethods.shield_stream_mode(_handle);
            return raw switch
            {
                0 => StreamingMode.OnComplete,
                1 => StreamingMode.Windowed,
                2 => StreamingMode.PerChunk,
                _ => StreamingMode.OnComplete,
            };
        }
    }

    private void ThrowIfDisposed()
    {
        if (_disposed) throw new GuardrailsDisposedException(nameof(StreamingGuard));
    }

    public void Dispose()
    {
        DisposeCore();
        GC.SuppressFinalize(this);
    }

    private void DisposeCore()
    {
        if (_disposed) return;
        _disposed = true;
        if (_handle != IntPtr.Zero)
        {
            NativeMethods.shield_stream_free(_handle);
            _handle = IntPtr.Zero;
        }
    }
}
