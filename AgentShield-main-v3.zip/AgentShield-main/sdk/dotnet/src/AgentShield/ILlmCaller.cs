using System.Collections.Generic;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace AgentShield;

/// <summary>
/// Envelope passed to LLM / classifier callers.
/// </summary>
public sealed record LlmRequest(
    string? ConfigurationId,
    string Prompt,
    string Input,
    JsonElement Context);

/// <summary>
/// A single redaction span returned by an LLM or classifier caller.
/// Half-open <c>[start, end)</c> <b>codepoint (character) range</b> over
/// the input string — NOT a byte or UTF-16 code-unit range. The Rust
/// core (see <c>sdk/rust/agent_shield_core/src/guard_policy_runtime/action.rs</c>)
/// computes spans against <c>str::chars()</c>, so non-ASCII subjects
/// redact predictably. Spans whose <c>End</c> exceeds the subject's
/// character count — or whose <c>End &lt;= Start</c> — are silently
/// dropped rather than clamped (the dropped span emits a <c>debug</c>
/// log entry from the core to aid diagnosis).
/// </summary>
/// <remarks>
/// Replacement is the (possibly empty) text that substitutes the original
/// slice. Wire shape: <c>{"start": int, "end": int, "replacement": string|null}</c>.
/// See spec / Stage 3 redact policies.
///
/// <para>Pitfall: <c>string.IndexOf</c> returns a UTF-16 code-unit
/// index. For secrets composed entirely of BMP characters (e.g. ASCII
/// PII patterns) this coincides with the codepoint index. If your
/// secret contains surrogate pairs (emoji, some CJK extensions),
/// convert via <c>System.Globalization.StringInfo</c> first.</para>
///
/// <para>Worked example (Unicode-prefixed secret):</para>
/// <code>
/// var text = "name: 田中 太郎 SSN: 123-45-6789";
/// // RIGHT — codepoint offsets for a BMP-only secret:
/// var start = text.IndexOf("123-45-6789", StringComparison.Ordinal);
/// var end = start + "123-45-6789".Length;
/// var span = new RedactionSpan(start, end, "[SSN]");
/// </code>
/// </remarks>
public sealed record RedactionSpan(int Start, int End, string? Replacement = null);

/// <summary>
/// Response an LLM caller returns. Wire format follows the C ABI:
/// <code>
/// {"decision": "allow"|"block",
///  "confidence": number, "reason": string|null,
///  "categories": [string,...],
///  "&lt;bool_flag&gt;": true, // any truthy bool field at root
///  "bool_flags": {...} }
/// </code>
/// Truthy bool flags fold into BLOCK.
/// </summary>
public sealed record LlmResponse(
    string Decision,
    double Confidence = 1.0,
    string? Reason = null,
    IReadOnlyList<string>? Categories = null,
    IReadOnlyDictionary<string, bool>? BoolFlags = null,
    IReadOnlyList<RedactionSpan>? Spans = null)
{
    public static LlmResponse Allow(double confidence = 1.0, string? reason = null) =>
        new("allow", confidence, reason);

    public static LlmResponse Block(string? reason = null, double confidence = 1.0) =>
        new("block", confidence, reason);

    internal string ToWireJson()
    {
        var obj = new JsonObject
        {
            ["decision"] = Decision,
            ["confidence"] = Confidence,
            ["reason"] = Reason,
        };
        if (Categories is { Count: > 0 })
        {
            var arr = new JsonArray();
            foreach (var c in Categories) arr.Add(c);
            obj["categories"] = arr;
        }
        if (BoolFlags is { Count: > 0 })
        {
            var flags = new JsonObject();
            foreach (var kv in BoolFlags) flags[kv.Key] = kv.Value;
            obj["bool_flags"] = flags;
        }
        if (Spans is { Count: > 0 })
        {
            var spansArr = new JsonArray();
            foreach (var sp in Spans)
            {
                spansArr.Add(new JsonObject
                {
                    ["start"] = sp.Start,
                    ["end"] = sp.End,
                    ["replacement"] = sp.Replacement,
                });
            }
            obj["spans"] = spansArr;
        }
        return obj.ToJsonString();
    }
}

/// <summary>
/// Verdict returned by a classifier caller. Wire shape of the
/// specification; the canonical ABI surface is
/// <c>sdk/rust/agent_shield_core/src/ffi.rs</c>.
/// </summary>
public sealed record ClassifierVerdict(
    double Score,
    double Threshold,
    bool Flagged,
    string? Label = null,
    string? Reason = null,
    IReadOnlyList<RedactionSpan>? Spans = null)
{
    internal string ToWireJson()
    {
        var obj = new JsonObject
        {
            ["score"] = Score,
            ["threshold"] = Threshold,
            ["flagged"] = Flagged,
            ["label"] = Label,
            ["reason"] = Reason,
        };
        if (Spans is { Count: > 0 })
        {
            var spansArr = new JsonArray();
            foreach (var sp in Spans)
            {
                spansArr.Add(new JsonObject
                {
                    ["start"] = sp.Start,
                    ["end"] = sp.End,
                    ["replacement"] = sp.Replacement,
                });
            }
            obj["spans"] = spansArr;
        }
        return obj.ToJsonString();
    }
}

/// <summary>
/// Pluggable LLM caller. Invoked whenever a guard policy, state
/// validator, or extractor declares an LLM-backed expression.
/// </summary>
public interface ILlmCaller
{
    LlmResponse Call(LlmRequest request);
}

/// <summary>
/// Pluggable classifier caller. Distinct from <see cref="ILlmCaller"/>
/// because classifiers return a (score, threshold, flagged) tuple rather
/// than a free-form decision.
/// </summary>
public interface IClassifierCaller
{
    ClassifierVerdict Call(LlmRequest request);
}
