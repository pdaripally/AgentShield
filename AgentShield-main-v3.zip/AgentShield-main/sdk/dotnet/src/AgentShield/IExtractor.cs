using System.Text.Json;

namespace AgentShield;

/// <summary>
/// Custom value extractor for variables populated by tool / endpoint /
/// agent results. The runtime invokes the extractor with the raw result
/// JSON and expects either:
/// <list type="bullet">
/// <item><description>A <see cref="JsonElement"/> — used as the variable value.</description></item>
/// <item><description><c>null</c> — signals "skip" (no update).</description></item>
/// </list>
/// Spec reference: §10.3 (extractors).
/// </summary>
public interface IExtractor
{
    JsonElement? Extract(JsonElement result);
}
