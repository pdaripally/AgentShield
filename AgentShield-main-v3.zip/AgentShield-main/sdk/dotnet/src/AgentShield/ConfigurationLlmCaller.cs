using System;
using System.Collections.Generic;
using System.Linq;

namespace AgentShield;

/// <summary>
/// Build an <see cref="ILlmCaller"/> that dispatches by EXACT
/// <c>configuration_id</c> match. Cross-SDK parity helper; mirrors
/// Python's <c>make_configuration_caller</c>, Node's
/// <c>makeConfigurationCaller</c>, and Rust's
/// <c>make_configuration_caller</c>.
/// </summary>
/// <remarks>
/// <para>
/// When a host wants distinct underlying callers per YAML
/// <c>configurations[]</c> entry (different model, mocked response,
/// separate provider), this helper composes them into a single
/// <see cref="ILlmCaller"/> that routes by exact match.
/// </para>
/// <para>
/// On unknown <c>configuration_id</c>, the dispatcher falls back to
/// <c>default</c> if provided; otherwise it throws
/// <see cref="InvalidOperationException"/> listing the registered ids
/// (which folds into a BLOCK per §12.9.3).
/// </para>
/// </remarks>
public static class ConfigurationLlmCaller
{
    /// <summary>
    /// Build a dispatching <see cref="ILlmCaller"/> from a map of
    /// <c>configuration_id → ILlmCaller</c> and an optional default.
    /// </summary>
    public static ILlmCaller Create(
        IReadOnlyDictionary<string, ILlmCaller> callers,
        ILlmCaller? defaultCaller = null)
    {
        if (callers == null) throw new ArgumentNullException(nameof(callers));
        // Defensive copy so callers can mutate the source map without
        // affecting an already-built dispatcher.
        var routes = new Dictionary<string, ILlmCaller>(callers.Count);
        foreach (var kv in callers)
        {
            if (kv.Key == null) throw new ArgumentException("configuration_id key must not be null", nameof(callers));
            if (kv.Value == null) throw new ArgumentException($"caller for '{kv.Key}' must not be null", nameof(callers));
            routes[kv.Key] = kv.Value;
        }
        return new DispatchingCaller(routes, defaultCaller);
    }

    private sealed class DispatchingCaller : ILlmCaller
    {
        private readonly IReadOnlyDictionary<string, ILlmCaller> _routes;
        private readonly ILlmCaller? _default;

        internal DispatchingCaller(
            IReadOnlyDictionary<string, ILlmCaller> routes,
            ILlmCaller? defaultCaller)
        {
            _routes = routes;
            _default = defaultCaller;
        }

        public LlmResponse Call(LlmRequest request)
        {
            if (request == null) throw new ArgumentNullException(nameof(request));
            if (request.ConfigurationId != null
                && _routes.TryGetValue(request.ConfigurationId, out var caller))
            {
                return caller.Call(request);
            }
            if (_default != null)
            {
                return _default.Call(request);
            }
            var known = string.Join(", ", _routes.Keys.OrderBy(k => k).Select(k => $"'{k}'"));
            var idRepr = request.ConfigurationId != null
                ? $"'{request.ConfigurationId}'"
                : "null";
            throw new InvalidOperationException(
                $"no LLM caller registered for configurationId={idRepr}; " +
                $"known ids: [{known}]; no default provided");
        }
    }
}
