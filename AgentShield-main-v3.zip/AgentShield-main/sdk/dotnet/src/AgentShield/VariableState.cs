using System;
using System.Text.Json;

namespace AgentShield;

/// <summary>
/// Read-only snapshot of a variable's state as cached by the runtime.
/// Maps to <c>VariableState</c> in the Rust core.
///
/// <para>
/// <see cref="SetAt"/> and <see cref="ExpiresAt"/> are nullable because
/// the canonical wire envelope emitted by
/// <c>agent_shield_core::ffi::variable_state_to_json</c> nulls
/// <c>set_at</c> whenever <c>@status!= "resolved"</c> (spec —
/// "When the variable last transitioned to <c>resolved</c>;
/// <c>null</c> while <c>unset</c> or <c>denied</c>"). <c>expires_at</c>
/// is null whenever the variable has no expiry. Callers that need a
/// concrete timestamp should guard on
/// <c>state.Status == VariableStatus.Resolved</c> before reading
/// <see cref="SetAt"/>.
/// </para>
///
/// <para>
/// <see cref="SourceParams"/> mirrors <c>@source_params</c>:
/// the snapshot of the writer's resource-bound parameter namespace
/// (<c>@tool.params</c>, <c>@endpoint.{path_params, query_params,
/// params}</c>, or <c>@agent.params</c>) captured at the moment this
/// entry last transitioned to <c>resolved</c> via a populator or
/// resolver. <c>null</c> for host-API writes and while
/// <c>@status!= "resolved"</c>. Read-only; never triggers
/// auto-resolution.
/// </para>
/// </summary>
public sealed record VariableState(
    JsonElement Value,
    VariableStatus Status,
    DateTimeOffset? SetAt,
    DateTimeOffset? ExpiresAt,
    string? DenyReason,
    string? SourceKind,
    string? SetBy,
    JsonElement? SourceParams)
{
    internal static VariableState? FromJson(string? json)
    {
        if (string.IsNullOrEmpty(json)) return null;
        return JsonSerializer.Deserialize<VariableState>(json, AgentShieldJsonOptions.Default);
    }
}

