using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Text.Json;
using AgentShield.Interop;
using YamlDotNet.Serialization;

namespace AgentShield;

/// <summary>
/// Composable, immutable-by-convention guardrails configuration. Thin
/// .NET wrapper over a Rust-owned <c>ShieldGuardrailsConfig*</c> handle:
/// composition, validation and SHA-256 digest all happen in the native
/// core. Multi-tenant SaaS callers compile the chain once via
/// <see cref="Compile"/> and feed the resulting <see cref="CompiledPolicy"/>
/// to <see cref="RuntimeBuilder.FromConfig(CompiledPolicy)"/>.
/// </summary>
public sealed class GuardrailsConfig
{
    private readonly NativeGuardrailsConfigHandle _handle;
    private readonly List<string> _yamls;

    private GuardrailsConfig(NativeGuardrailsConfigHandle handle, List<string> yamls)
    {
        _handle = handle;
        _yamls = yamls;
    }

    /// <summary>Number of layers in the composition chain.</summary>
    public int Count => _yamls.Count;

    internal IntPtr DangerousGetHandle() => _handle.DangerousGetPointer();

    // ── Constructors ─────────────────────────────────────────────

    /// <summary>Start a chain from a single YAML file.</summary>
    public static GuardrailsConfig Load(string path)
    {
        if (string.IsNullOrEmpty(path)) throw new ArgumentException(null, nameof(path));
        var ptr = NativeMethods.shield_config_load(path, out var err);
        NativeMethods.ThrowIfErr(err);
        return new GuardrailsConfig(
            NativeGuardrailsConfigHandle.FromExisting(ptr),
            new List<string> { File.ReadAllText(path) });
    }

    /// <summary>Start a chain from a raw YAML string.</summary>
    public static GuardrailsConfig FromString(string yamlText, string description = "")
    {
        if (yamlText is null) throw new ArgumentNullException(nameof(yamlText));
        var ptr = NativeMethods.shield_config_from_string(yamlText, out var err);
        NativeMethods.ThrowIfErr(err);
        return new GuardrailsConfig(
            NativeGuardrailsConfigHandle.FromExisting(ptr),
            new List<string> { yamlText });
    }

    /// <summary>Start a chain from a dictionary serialised to JSON for the FFI hop.</summary>
    public static GuardrailsConfig FromObject(IDictionary<string, object?> data, string description = "")
    {
        if (data is null) throw new ArgumentNullException(nameof(data));
        var ptr = NativeMethods.shield_config_from_json(JsonSerializer.Serialize(data), out var err);
        NativeMethods.ThrowIfErr(err);
        return new GuardrailsConfig(
            NativeGuardrailsConfigHandle.FromExisting(ptr),
            new List<string> { new SerializerBuilder().Build().Serialize(data) });
    }

    /// <summary>Convenience: chain multiple sources in one call.</summary>
    public static GuardrailsConfig Compose(params object[] sources)
    {
        if (sources is null || sources.Length == 0)
            throw new ArgumentException("Compose requires at least one source", nameof(sources));
        var cfg = FromSource(sources[0]);
        for (int i = 1; i < sources.Length; i++)
            cfg = cfg.Extend(sources[i]);
        return cfg;
    }

    // ── Fluent extension ─────────────────────────────────────────

    /// <summary>Append another layer (leaf-wins). Returns a new instance.</summary>
    public GuardrailsConfig Extend(object source)
    {
        var selfPtr = _handle.DangerousGetPointer();
        IntPtr newPtr;
        IntPtr err;
        List<string> nextYamls;

        switch (source)
        {
            case GuardrailsConfig other:
                newPtr = NativeMethods.shield_config_extend(selfPtr, other._handle.DangerousGetPointer(), out err);
                NativeMethods.ThrowIfErr(err);
                nextYamls = new List<string>(_yamls);
                nextYamls.AddRange(other._yamls);
                break;
            case string s when s.IndexOfAny(new[] { '\n', '\r' }) >= 0:
                newPtr = NativeMethods.shield_config_extend_string(selfPtr, s, out err);
                NativeMethods.ThrowIfErr(err);
                nextYamls = new List<string>(_yamls) { s };
                break;
            case string s:
                newPtr = NativeMethods.shield_config_extend_path(selfPtr, s, out err);
                NativeMethods.ThrowIfErr(err);
                nextYamls = new List<string>(_yamls) { File.ReadAllText(s) };
                break;
            case IDictionary<string, object?> dict:
                newPtr = NativeMethods.shield_config_with_overrides_json(selfPtr, JsonSerializer.Serialize(dict), out err);
                NativeMethods.ThrowIfErr(err);
                nextYamls = new List<string>(_yamls) { new SerializerBuilder().Build().Serialize(dict) };
                break;
            default:
                throw new ArgumentException(
                    $"Cannot extend GuardrailsConfig with {source?.GetType().Name ?? "null"}",
                    nameof(source));
        }

        return new GuardrailsConfig(NativeGuardrailsConfigHandle.FromExisting(newPtr), nextYamls);
    }

    /// <summary>Append a final dictionary-shaped layer that overrides earlier values.</summary>
    public GuardrailsConfig WithOverrides(IDictionary<string, object?> overrides, string description = "overrides")
        => Extend(overrides);

    /// <summary>
    /// Append a "policy pack" layer. Semantically identical to
    /// <see cref="Extend"/> — the separate name documents intent for
    /// callers that distinguish baseline policy from per-tenant or
    /// per-environment packs.
    /// </summary>
    public GuardrailsConfig WithPolicyPack(object pack, string description = "policy_pack")
        => pack is IDictionary<string, object?> dict ? Extend(dict) : Extend(pack);

    // ── Compilation ──────────────────────────────────────────────

    /// <summary>Materialise the chain into a hashable <see cref="CompiledPolicy"/>.</summary>
    public CompiledPolicy Compile()
    {
        // Digest path: non-validating — partial overlays should still
        // produce a stable content identity (matches Python / Node /
        // Rust behaviour). Validation happens later when the runtime
        // builds.
        var digestPtr = NativeMethods.shield_config_digest(_handle.DangerousGetPointer(), out var derr);
        NativeMethods.ThrowIfErr(derr);
        var digest = NativeMethods.ReadAndFreeString(digestPtr)
            ?? throw new InvalidOperationException("shield_config_digest returned null");

        // CompiledPolicy holds the GuardrailsConfig handle (not a
        // native CompiledPolicy) so the caller can lazily compile
        // when actually building a runtime. Same shape as the Python
        // and Node SDKs after the Phase 1 refactor.
        return new CompiledPolicy(_yamls, digest, _handle);
    }

    // ── Internal: source dispatch ────────────────────────────────

    private static GuardrailsConfig FromSource(object source) => source switch
    {
        GuardrailsConfig cfg => cfg,
        string s when s.IndexOfAny(new[] { '\n', '\r' }) >= 0 => FromString(s),
        string s => Load(s),
        IDictionary<string, object?> dict => FromObject(dict),
        _ => throw new ArgumentException(
            $"Cannot construct GuardrailsConfig from {source?.GetType().Name ?? "null"}",
            nameof(source)),
    };
}

/// <summary>
/// The materialised, hashable result of <see cref="GuardrailsConfig.Compile"/>.
/// Carries the ordered chain of YAML strings (preserved C#-side for the
/// existing <see cref="RuntimeBuilder.FromYamlStrings"/> path) plus a
/// SHA-256 digest computed by the native core. Used by SaaS / multi-tenant
/// callers to cache compiled runtimes by configuration content.
///
/// <para>
/// The digest is computed via the non-validating native
/// <c>shield_config_digest</c> path, so partial overlays produce a
/// stable identity even when full validation would fail. Validation
/// runs lazily when the compiled policy is built into a runtime via
/// <see cref="RuntimeBuilder.FromConfig(CompiledPolicy)"/>.
/// </para>
/// </summary>
public sealed class CompiledPolicy : IEquatable<CompiledPolicy>
{
    public IReadOnlyList<string> YamlStrings { get; }
    public string Digest { get; }

    /// <summary>Convenience alias for <see cref="Digest"/>.</summary>
    public string Hash => Digest;

    /// <summary>
    /// The originating <see cref="NativeGuardrailsConfigHandle"/>.
    /// Held so the runtime build path (Phase 1 dispatch in
    /// <see cref="RuntimeBuilder.FromConfig(CompiledPolicy)"/>) can
    /// call <c>shield_config_compile</c> once and reuse the resulting
    /// runtime for the lifetime of the policy.
    /// </summary>
    internal NativeGuardrailsConfigHandle ConfigHandle { get; }

    internal CompiledPolicy(IEnumerable<string> yamlStrings, string digest, NativeGuardrailsConfigHandle configHandle)
    {
        YamlStrings = new ReadOnlyCollection<string>(new List<string>(yamlStrings));
        Digest = digest;
        ConfigHandle = configHandle;
    }

    public bool Equals(CompiledPolicy? other) => other is not null && Digest == other.Digest;
    public override bool Equals(object? obj) => obj is CompiledPolicy o && Equals(o);
    public override int GetHashCode() => Digest.GetHashCode();
    public override string ToString()
        => $"CompiledPolicy(layers={YamlStrings.Count}, digest={Digest[..16]}…)";
}
