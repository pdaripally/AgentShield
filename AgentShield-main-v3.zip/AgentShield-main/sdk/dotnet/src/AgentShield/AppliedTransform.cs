namespace AgentShield;

/// <summary>
/// Single redaction / append / prepend transform that fired during a
/// stage validation. Mirrors <c>AppliedTransform</c> from the Rust
/// core (<c>sdk/rust/agent_shield_core/src/guard_policy_runtime/mod.rs</c>)
/// and the matching Python / Node SDK projections.
/// </summary>
/// <remarks>
/// <para>
/// A <see cref="StageVerdict"/> carries an ordered manifest of every
/// transform that contributed to the verdict in
/// <see cref="StageVerdict.AppliedTransforms"/>. Hosts use the manifest
/// for spec / audit + replay, cross-process telemetry
/// parity, and Stage-4 structured-result recovery (mapping canonical
/// char-spans back to their owning string leaves of a tool-call
/// result object).
/// </para>
/// <para>
/// For <c>redact</c> transforms, <see cref="SpanStart"/> /
/// <see cref="SpanEnd"/> are inclusive-start / exclusive-end
/// <em>codepoint</em> offsets against the canonical pre-transform
/// subject (the raw string for content stages; <c>serde_json::to_string</c>
/// on non-string Stage-4 tool results). They are <c>null</c> for
/// <c>append</c> / <c>prepend</c> transforms, where
/// <see cref="Replacement"/> instead carries the appended / prepended
/// text..NET strings are UTF-16; codepoints coincide with code units
/// only for BMP characters, so callers should walk
/// <see cref="System.Globalization.StringInfo"/> when reconstructing
/// pre-transform substrings.
/// </para>
/// <para>
/// Cross-SDK parity reference shapes:
/// <list type="bullet">
///   <item>Rust core: <c>guard_policy_runtime::AppliedTransform</c></item>
///   <item>Rust FFI: <c>ffi.rs::applied_transform_to_json</c></item>
///   <item>Python: <c>sdk/python/src/lib.rs</c> (PyDict projection)</item>
///   <item>Node: <c>sdk/node/index.ts::AppliedTransform</c></item>
/// </list>
/// </para>
/// </remarks>
public sealed record AppliedTransform(
    string Policy,
    int EvaluateWhenIndex,
    string Action,
    int? SpanStart,
    int? SpanEnd,
    string? Replacement);
