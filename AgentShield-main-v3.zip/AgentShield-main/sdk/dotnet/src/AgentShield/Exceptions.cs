using System;

namespace AgentShield;

/// <summary>
/// Base class for all Agent Shield SDK exceptions.
/// </summary>
public class GuardrailsException : Exception
{
    public GuardrailsException(string message) : base(message) { }
    public GuardrailsException(string message, Exception inner) : base(message, inner) { }
}

/// <summary>
/// Thrown when an operation is performed on a runtime / session that has
/// already been disposed.
/// </summary>
public sealed class GuardrailsDisposedException : GuardrailsException
{
    public GuardrailsDisposedException(string what)
        : base($"{what} is disposed") { }
}

/// <summary>
/// Thrown when a guardrails YAML config fails to load or build.
///
/// <para>
/// Carries the structured loader-error envelope produced by
/// <c>agent_shield_core::LoaderErrorWire</c>: when the failure
/// originates from <see cref="RuntimeBuilder.FromYaml"/>,
/// <see cref="RuntimeBuilder.FromYamlChain"/>,
/// <see cref="RuntimeBuilder.FromConfigText"/>, or
/// <see cref="RuntimeBuilder.Build"/>, the following properties are
/// populated by parsing the
/// <c>AGENT_SHIELD_LOADER_ERROR_JSON:</c> sentinel emitted by
/// <c>agent_shield_core::ffi::write_runtime_err</c>.
/// </para>
///
/// <para>
/// The cross-SDK alias <see cref="AgentShieldConfigException"/>
/// derives from this type; catch either to handle loader failures.
/// </para>
/// </summary>
public class GuardrailsConfigException : GuardrailsException
{
    /// <summary>Source-file path (or YAML-string identifier) where the error originated.</summary>
    public string? Path { get; init; }

    /// <summary>1-based line number when available (e.g. for YAML parse errors).</summary>
    public int? Line { get; init; }

    /// <summary>1-based column number when available.</summary>
    public int? Column { get; init; }

    /// <summary>Dotted path of the failing field within the document, e.g. <c>guard_policies[0].evaluate_when[0].expression</c>.</summary>
    public string? Field { get; init; }

    /// <summary>
    /// Stable snake_case code identifying the failure category:
    /// <c>unparseable_yaml</c>, <c>schema_violation</c>,
    /// <c>cycle_detected</c>, <c>io_error</c>, <c>unknown_event</c>,
    /// <c>invalid_expression</c>, <c>unresolved_reference</c>,
    /// <c>classifier_wiring_missing</c>, etc.
    /// </summary>
    public string? Code { get; init; }

    /// <summary>Human-readable remediation hint, when the variant supplies one.</summary>
    public string? Remediation { get; init; }

    public GuardrailsConfigException(string message) : base(message) { }

    public GuardrailsConfigException(string message, Exception inner) : base(message, inner) { }
}

/// <summary>
/// Cross-SDK alias for <see cref="GuardrailsConfigException"/>, matching
/// the Python <c>AgentShieldConfigError</c> and Node
/// <c>AgentShieldConfigError</c> names. Customers writing portable
/// .NET code that mirrors examples from other SDKs can catch this
/// class; existing .NET catch handlers using
/// <see cref="GuardrailsConfigException"/> keep working unchanged
/// because this type inherits from it.
/// </summary>
public sealed class AgentShieldConfigException : GuardrailsConfigException
{
    public AgentShieldConfigException(string message) : base(message) { }
    public AgentShieldConfigException(string message, Exception inner) : base(message, inner) { }
}

/// <summary>
/// Thrown when a fallible runtime call (registration, validation,
/// session op) returns a non-zero status from the native ABI.
/// </summary>
public sealed class GuardrailsRuntimeException : GuardrailsException
{
    public GuardrailsRuntimeException(string message) : base(message) { }
}

/// <summary>
/// Variable status mirrors <c>VariableState.status</c> from the Rust
/// runtime.
/// </summary>
public enum VariableStatus
{
    Unset,
    Resolved,
    Denied,
}

/// <summary>
/// Thrown when an LLM-caller adapter is asked to invoke a
/// <c>configurations[]</c> entry that does not declare <c>model:</c>.
///
/// <para>
/// A security library MUST NOT pick a model on the customer's behalf.
/// When the runtime resolves the configuration referenced by a guard
/// policy's stage and finds an entry with no <c>model:</c> — or no
/// matching entry at all — the LLM caller surfaces this typed
/// exception instead of silently falling back to a hard-coded SKU.
/// The schema in <c>spec/schema/guardrails.schema.json</c> rejects
/// entries missing <c>model:</c> at load time, so in normal operation
/// this exception fires only when an out-of-band configuration source
/// bypasses schema validation or when the runtime asks for a
/// <see cref="ConfigurationId"/> that doesn't exist.
/// </para>
///
/// <para>
/// Recovery: declare <c>model: &lt;name&gt;</c> on the offending
/// <c>configurations[]</c> entry in <c>.guardrails.yaml</c>.
/// <c>model:</c> is the identifier passed verbatim to the provider
/// SDK — a model name for direct OpenAI, a deployment name for Azure
/// OpenAI, the provider-native identifier for Anthropic / Bedrock /
/// Vertex / etc.
/// </para>
/// </summary>
public sealed class ConfigurationMissingModelException : GuardrailsException
{
    /// <summary>
    /// The <c>configurations[].id</c> the runtime asked for, or
    /// <c>null</c> when no id was supplied.
    /// </summary>
    public string? ConfigurationId { get; }

    public ConfigurationMissingModelException(string? configurationId)
        : base(BuildMessage(configurationId))
    {
        ConfigurationId = configurationId;
    }

    private static string BuildMessage(string? configurationId)
    {
        var idRepr = string.IsNullOrEmpty(configurationId) ? "<unset>" : configurationId;
        return $"LLM configuration '{idRepr}' is missing 'model'. Add " +
               "'model: <name>' to the configurations[] entry in your " +
               ".guardrails.yaml. 'model:' is passed verbatim to the " +
               "provider SDK — a model name for direct OpenAI, a " +
               "deployment name for Azure OpenAI.";
    }
}

/// <summary>
/// Thrown when a streaming Stage-5 adapter that yields chunks
/// directly to an append-only sink (HTTP SSE, stdout, terminal renderer,
/// any UI that paints each delta on arrival) receives a
/// <see cref="StreamAction.Replace"/> verdict from the Rust core's
/// streaming guard.
///
/// <para>
/// Background: Stage-5 streaming guards may emit a
/// <see cref="StreamChunkResult"/> with
/// <see cref="StreamChunkResult.Action"/> equal to
/// <see cref="StreamAction.Replace"/> when the validator rewrites the
/// buffered output (for example, redacting a sensitive span that only
/// became visible after a later chunk closed the match window). The
/// canonical semantics of <c>Replace</c> are: <em>discard
/// every byte already emitted for this stream and substitute
/// <see cref="StreamChunkResult.Payload"/> in its place.</em> The
/// payload is the ENTIRE validated buffer, not an incremental slice.
/// </para>
///
/// <para>
/// Sinks that cannot retract bytes already delivered to the consumer
/// would otherwise leave the leaked PHI/secret on screen with the
/// redacted version concatenated after it — the canonical
/// reproducer is "SSN 123-45-6789SSN [SSN]". The SDK raises this
/// exception at the FIRST such event so the consumer fails loudly
/// instead of silently rendering stale sensitive text.
/// </para>
///
/// <para>Mitigation:</para>
/// <list type="bullet">
///   <item><description>
///     Switch the streaming cadence to <see cref="StreamingMode.OnComplete"/>
///     (the default) so no text-bearing chunks ever leave the guard
///     until <c>Finish()</c> returns the fully validated payload —
///     that is the spec's safe default and the only mode whose output
///     is byte-equivalent to the non-streaming path.
///   </description></item>
///   <item><description>
///     Or wrap the sink in an in-memory buffer that the SDK can rewrite
///     cleanly on <c>Replace</c> before flushing to the customer.
///   </description></item>
/// </list>
///
/// <para>
/// Cross-SDK parity:
/// mirrors Python's <c>StreamingReplaceNotSupportedError</c> and
/// Node's <c>StreamingReplaceNotSupportedError</c>.
/// </para>
/// </summary>
public sealed class StreamingReplaceNotSupportedException : GuardrailsException
{
    /// <summary>
    /// The reason supplied by the Stage-5 guard verdict, if any.
    /// </summary>
    public string? Reason { get; }

    /// <summary>
    /// The adapter surface that detected the unsupported
    /// <c>Replace</c> verdict (e.g. <c>"RunStreamedAsync"</c>,
    /// <c>"GuardedChatClient"</c>). Useful for filtering in
    /// observability dashboards.
    /// </summary>
    public string? Adapter { get; }

    public StreamingReplaceNotSupportedException(string? adapter, string? reason)
        : base(BuildMessage(adapter, reason))
    {
        Adapter = adapter;
        Reason = reason;
    }

    public StreamingReplaceNotSupportedException()
        : this(adapter: null, reason: null) { }

    public StreamingReplaceNotSupportedException(string message)
        : base(message)
    {
    }

    private static string BuildMessage(string? adapter, string? reason)
    {
        var adapterPart = string.IsNullOrEmpty(adapter) ? "" : $"{adapter} ";
        var reasonPart = string.IsNullOrEmpty(reason) ? "<no reason supplied>" : reason;
        return $"{adapterPart}streaming adapter received a `Replace` action " +
               "from the Stage-5 guard, but deltas are yielded directly to " +
               "the consumer (append-only sink) and cannot be retracted. " +
               "Switch the streaming cadence to `on_complete` (the default, " +
               "safest) or disable streaming. " +
               $"Reason: {reasonPart}";
    }
}

/// <summary>
/// Thrown when a host-supplied resolver callback returns a
/// <see cref="ResolverResponse"/> envelope that violates spec.
///
/// <para>
/// the resolver wire envelope as
/// <c>{decision, value, set_variables, reason}</c> and REQUIRES the
/// <c>value</c> field on <c>decision: "allow"</c>. The spec permits
/// <c>value: null</c> only as an explicit, deliberately-supplied
/// sentinel (e.g. for boolean-resolved variables whose policy intent
/// is "value: null means allow"). A response that omits
/// <see cref="ResolverResponse.Value"/> on
/// <see cref="ResolverDecision.Allow"/> is silently fail-open
/// (previously the SDK would forward <c>value: null</c> to the Rust
/// core regardless of whether the resolver author intended to
/// publish <c>null</c>).
/// </para>
///
/// <para>
/// This closes that gap by failing closed at the
/// .NET resolver boundary: an <c>allow</c> response with
/// <see cref="ResolverResponse.Value"/> set to <c>null</c> (i.e. the
/// caller did not pass a value at all — the
/// <see cref="System.Text.Json.JsonElement"/>? is null, NOT a
/// <c>JsonElement</c> with <c>ValueKind == Null</c>) is rejected. The
/// surrounding <see cref="RuntimeBuilder"/> resolver invocation
/// catches the exception and synthesises a deny envelope, so the
/// guard policy fails closed instead of latching a phantom
/// <c>resolved/null</c> variable.
/// </para>
///
/// <para>
/// Resolvers that legitimately resolve to JSON null must state that
/// intent explicitly by passing
/// <c>JsonDocument.Parse("null").RootElement</c> as the
/// <see cref="ResolverResponse.Value"/>. Resolvers that meant to
/// deny should call
/// <see cref="ResolverResponse.DenyWith(string?)"/> — <c>deny</c>
/// and <c>cancelled</c> envelopes do not require <c>value</c>.
/// </para>
/// </summary>
public sealed class AgentShieldResolverEnvelopeException : GuardrailsException
{
    /// <summary>
    /// The decision that was returned (e.g. <c>"allow"</c>). Useful
    /// for matching error-handling on the violated envelope shape.
    /// </summary>
    public string Decision { get; }

    public AgentShieldResolverEnvelopeException(string decision)
        : base(BuildMessage(decision))
    {
        Decision = decision;
    }

    private static string BuildMessage(string decision)
    {
        return $"resolver callback returned `decision: \"{decision}\"` " +
               "without a `value` field; the value " +
               "field on `allow`. If your resolver legitimately resolves " +
               "to JSON null, state the intent explicitly: pass " +
               "`Value: JsonDocument.Parse(\"null\").RootElement` on the " +
               "ResolverResponse. If the resolver was meant to deny, use " +
               "`ResolverResponse.DenyWith(\"reason\")` instead — `deny` " +
               "and `cancelled` envelopes do not require `value`.";
    }
}
/// (or its overloads) receives a result of a type that is not
/// <see cref="string"/>, <c>null</c>, or a recognised primitive,
/// and the caller has not supplied an <c>extractText</c> lens.
///
/// <para>
/// Previously the Pattern C surface silently skipped Stage 5 when
/// <c>TResult</c> was not a string — every Vercel-AI-SDK-shaped
/// <c>GenerateTextResult</c>, LangChain agent output,
/// Microsoft.Extensions.AI <c>ChatCompletion</c>, etc. flowed back
/// to the caller without Stage 5 redaction. This was a CRITICAL
/// silent-bypass at the Pattern C surface.
/// </para>
///
/// <para>
/// The new fail-closed default throws this exception so a forgotten
/// extractor is loud. Customers can opt in to redaction by passing
/// <c>extractText: r =&gt; r.Text</c> (and optionally
/// <c>setText: (r, t) =&gt; r with { Text = t }</c> for record /
/// immutable types) to one of the <c>RunAsync</c> overloads.
/// </para>
/// </summary>
public sealed class AgentShieldUnsupportedOutputTypeException : GuardrailsException
{
    /// <summary>
    /// The runtime <see cref="Type.FullName"/> of the result that
    /// triggered the failure, or the simple type name if
    /// <see cref="Type.FullName"/> is unavailable.
    /// </summary>
    public string ResultType { get; }

    public AgentShieldUnsupportedOutputTypeException(string resultType)
        : base(BuildMessage(resultType))
    {
        ResultType = resultType;
    }

    private static string BuildMessage(string resultType)
    {
        return $"Shield.RunAsync received a result of type '{resultType}' " +
               "but no 'extractText' lens was supplied. Previously the " +
               "runtime silently skipped Stage 5 for non-string TResult, " +
               "bypassing output redaction for framework result objects " +
               "(e.g. Microsoft.Extensions.AI ChatCompletion, LangChain " +
               "output). To fix: pass extractText: r => r.Text (and " +
               "optionally setText) so Stage 5 runs on the " +
               "assistant-visible text field.";
    }
}

/// <summary>
/// Thrown when <c>Shield.RunAsync</c> is called with an
/// <c>extractText</c> lens but no companion <c>setText</c> writer.
/// <para>
/// Previously this combination silently fell back to a reflection-based
/// mutator that wrote the redacted text to a freshly-discovered
/// <c>Text</c> property on the result, leaving the customer's actual
/// extractor source location (e.g. <c>result.Choices[0].Message.Content</c>)
/// unredacted — the same silent-bypass class
/// <see cref="AgentShieldUnsupportedOutputTypeException"/> closed at the
/// non-lens surface, re-opened at the lens opt-in surface.
/// </para>
/// <para>
/// This forces the caller to make an explicit choice:
/// </para>
/// <list type="bullet">
///   <item>Supply <c>setText: (r, t) =&gt; r with {... = t }</c> so
///         the redacted text is written back to the same location it
///         was extracted from.</item>
///   <item>Supply <c>setText: LensWriter&lt;TResult&gt;.Advisory</c>
///         to opt into advisory-only mode — Stage 5 still runs (and a
///         block-verdict still routes through <c>OnBlockPolicy</c>),
///         but the returned result is not mutated.</item>
/// </list>
/// </summary>
public sealed class AgentShieldLensIncompleteException : GuardrailsException
{
    public AgentShieldLensIncompleteException()
        : base(BuildMessage()) { }

    public AgentShieldLensIncompleteException(string message)
        : base(message) { }

    private static string BuildMessage()
    {
        return "Shield.RunAsync was called with an 'extractText' lens " +
               "but no companion 'setText' writer. Previously " +
               "this combination silently wrote the redacted text to a " +
               "fresh '.Text' property on the result object, leaving " +
               "the caller's actual extractor source location " +
               "unredacted (re-opening the same silent-bypass class " +
               "at the lens opt-in surface). To fix, choose one: " +
               "(a) supply setText: (r, t) => r with { ... = t } so " +
               "redacted text is written back to the same location " +
               "extractText reads from, OR " +
               "(b) supply setText: LensWriter<TResult>.Advisory to " +
               "opt into advisory-only mode (Stage 5 still runs and " +
               "block-verdicts still surface, but the result is not " +
               "mutated).";
    }
}

/// <summary>
/// Sentinel struct paired with <c>Shield.RunAsync</c>'s
/// <c>setText</c> parameter. Distinguishes three cases the previous
/// <c>Func&lt;TResult, string, TResult&gt;?</c> shape could not:
/// <list type="bullet">
///   <item><c>default(LensWriter&lt;TResult&gt;)</c> — caller did NOT
///         supply a writer. <see cref="IsSpecified"/> is <c>false</c>.
///         When <c>extractText</c> is also supplied, this raises
///         <see cref="AgentShieldLensIncompleteException"/> at run()
///         entry (fail-closed).</item>
///   <item><see cref="Advisory"/> — caller explicitly opted into
///         advisory-only Stage 5 (no write-back).
///         <see cref="IsSpecified"/> is <c>true</c>,
///         <see cref="Writer"/> is <c>null</c>.</item>
///   <item>A <c>Func&lt;TResult, string, TResult&gt;</c> implicitly
///         converted via the operator below — normal write-back path.
///         <see cref="IsSpecified"/> is <c>true</c>,
///         <see cref="Writer"/> is non-<c>null</c>.</item>
/// </list>
/// </summary>
public readonly struct LensWriter<TResult>
{
    /// <summary><c>true</c> when the caller passed any non-default value (including <see cref="Advisory"/>).</summary>
    public bool IsSpecified { get; }

    /// <summary>The write-back delegate, or <c>null</c> for advisory-only mode.</summary>
    public Func<TResult, string, TResult>? Writer { get; }

    private LensWriter(bool isSpecified, Func<TResult, string, TResult>? writer)
    {
        IsSpecified = isSpecified;
        Writer = writer;
    }

    /// <summary>
    /// Advisory-only opt-in. Pass as
    /// <c>setText: LensWriter&lt;TResult&gt;.Advisory</c> to run
    /// Stage 5 on the extracted text without mutating the result.
    /// Block verdicts still surface via <c>OnBlockPolicy</c>.
    /// </summary>
    public static LensWriter<TResult> Advisory => new(isSpecified: true, writer: null);

    /// <summary>
    /// Implicit conversion from a plain
    /// <c>Func&lt;TResult, string, TResult&gt;</c> so existing
    /// call-sites (and the natural <c>setText: (r, t) =&gt;...</c>
    /// shape) keep compiling without explicit struct construction.
    /// </summary>
    public static implicit operator LensWriter<TResult>(Func<TResult, string, TResult> writer)
        => new(isSpecified: true, writer: writer ?? throw new ArgumentNullException(nameof(writer)));
}
