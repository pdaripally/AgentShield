using System;

namespace AgentShield;

/// <summary>
/// Typed deny envelope raised by Agent Shield when a stage verdict
/// denies an action. Two production callers throw this type:
/// <list type="bullet">
///   <item><description>
///     The <see cref="Shield"/> orchestrator's <c>RunAsync</c> /
///     <c>RunStreamedAsync</c> path raises it when
///     <see cref="OnBlockPolicy.Raise"/> is configured and any stage
///     denies (legacy <c>(StageVerdict?, string)</c> constructor —
///     per-tool fields are <c>null</c>).
///   </description></item>
///   <item><description>
///     The Microsoft.Extensions.AI adapter's
///     <c>GuardedAIFunction</c> shim raises it on a Stage 3 / Stage 4
///     deny — the fail-closed tool-block surface.
///   </description></item>
/// </list>
/// Inherits from <see cref="GuardrailsException"/> so the entire
/// AgentShield exception family can be filtered with a single
/// <c>catch (GuardrailsException)</c>.
/// </summary>
public sealed class AgentShieldBlockedException : GuardrailsException
{
    public StageVerdict? Verdict { get; }
    public string? ToolName { get; }
    public string? Stage { get; }
    public PendingResolution? PendingResolution { get; }

    /// <summary>
    /// Legacy constructor used by <see cref="Shield"/>'s
    /// <see cref="OnBlockPolicy.Raise"/> path.
    /// </summary>
    public AgentShieldBlockedException(StageVerdict? verdict, string message)
        : base(message)
    {
        Verdict = verdict;
        PendingResolution = verdict?.PendingResolution;
    }

    /// <summary>
    /// Per-tool stage-gate constructor used by adapter code on a
    /// Stage 3 / Stage 4 deny.
    /// </summary>
    public AgentShieldBlockedException(
        string message,
        string toolName,
        string stage,
        PendingResolution? pendingResolution = null)
        : base(message)
    {
        ToolName = toolName ?? throw new ArgumentNullException(nameof(toolName));
        Stage = stage ?? throw new ArgumentNullException(nameof(stage));
        PendingResolution = pendingResolution;
    }
}
