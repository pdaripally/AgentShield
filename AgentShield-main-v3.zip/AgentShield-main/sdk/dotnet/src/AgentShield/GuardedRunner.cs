using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace AgentShield;

/// <summary>
/// Internal helpers that drive the stage-validation pipelines used by
/// <see cref="Shield"/>. These are deliberately split from the
/// <c>Shield</c> class so they can be unit-tested independently and so
/// per-framework extension methods can compose them differently.
///
/// <para>
/// Three pipelines live here:
/// </para>
/// <list type="bullet">
///   <item>
///     <c>RunGuardedTurnAsync</c> — Stage 1 → execute → Stage 5,
///     bracketed by <see cref="GuardrailsSession.BeginTurn"/> /
///     <see cref="GuardrailsSession.EndTurn"/>.
///   </item>
///   <item>
///     <c>RunStreamedAsync</c> — Stage 1, ambient session push, then a
///     per-chunk Stage 5 streaming guard.
///   </item>
///   <item>
///     <c>RunGuardedToolAsync</c> — Stage 2 + 3, execute, Stage 4,
///     plus <c>record_tool_success</c> / <c>record_tool_failure</c>
///     bookkeeping.
///   </item>
/// </list>
/// </summary>
internal static class GuardedRunner
{
    // ── Stage 1 + 5 (full agent turn) ───────────────────────────────

    internal static async Task<TResult> RunGuardedTurnAsync<TResult>(
        GuardrailsSession session,
        string userInput,
        Func<Task<TResult>> execute,
        ShieldMode mode,
        Func<StageVerdict, string, TResult> dispatchBlocked,
        AsyncLocal<GuardrailsSession?> ambient,
        AsyncLocal<string?> ambientInput,
        Func<TResult, string?>? extractText = null,
        Func<TResult, string, TResult>? setText = null,
        CancellationToken ct = default,
        Action<PendingResolution>? pendingSink = null,
        bool advisoryOnly = false)
    {
        ct.ThrowIfCancellationRequested();
        await using var lease = ambient.Value == session
            ? default
            : await session.AcquireTurnLeaseAsync(ct).ConfigureAwait(false);
        session.BeginTurn();
        try
        {
            // Shadow / Monitor (#14): observability-only branch. Run
            // every stage validator for audit events (core stamps them
            // with `mode: shadow` + `enforced: false` and routes them
            // through the registered ObservabilityProvider), never
            // block, never apply redactions / appends / prepends.
            // Mirrors Python `_execute_with_monitor` and Node
            // `_runMonitorMode`.
            if (mode == ShieldMode.Monitor)
            {
                _ = session.ValidateInput(userInput ?? string.Empty);

                ct.ThrowIfCancellationRequested();

                var prevSessionMon = ambient.Value;
                var prevInputMon = ambientInput.Value;
                ambient.Value = session;
                ambientInput.Value = userInput ?? string.Empty;
                TResult monResult;
                try
                {
                    monResult = await execute().ConfigureAwait(false);
                }
                finally
                {
                    ambient.Value = prevSessionMon;
                    ambientInput.Value = prevInputMon;
                }

                // use the same Stage-5 text-derivation lens in
                // MONITOR as in enforcement so customers get the same
                // diagnostics about unsupported result types whether or
                // not enforcement is active. The redacted text is
                // discarded; raw is returned regardless.
                var (monText, _) = DeriveStage5Input(monResult, extractText);
                if (!string.IsNullOrEmpty(monText))
                {
                    _ = session.ValidateOutput(monText);
                }

                return monResult;
            }

            // Stage 1 — canonical dispatch.
            var inputVerdict = session.ValidateInput(userInput ?? string.Empty);
            var inputDecision = VerdictDispatcher.DispatchStage(
                inputVerdict, OnBlockPolicy.ReturnBlocked, mode);
            if (inputDecision.Action.Kind == "return_blocked"
                && !inputDecision.OverrideToProceed)
            {
                if (pendingSink is not null && inputVerdict.PendingResolution is not null)
                {
                    pendingSink(inputVerdict.PendingResolution);
                }
                return dispatchBlocked(
                    inputVerdict, inputDecision.Action.Message ?? string.Empty);
            }
            // override_to_proceed only fires when `mode == Monitor`, but
            // the dedicated Monitor branch above already handles that
            // case; in any other mode this is unreachable.
            var effectiveInput = inputDecision.Action.Kind == "proceed_with_mutation"
                ? inputDecision.Action.Value ?? userInput ?? string.Empty
                : userInput ?? string.Empty;

            ct.ThrowIfCancellationRequested();

            var prevSession = ambient.Value;
            var prevInput = ambientInput.Value;
            ambient.Value = session;
            ambientInput.Value = effectiveInput;
            TResult result;
            try
            {
                result = await execute().ConfigureAwait(false);
            }
            finally
            {
                ambient.Value = prevSession;
                ambientInput.Value = prevInput;
            }

            // Stage 5 derivation via DeriveStage5Input. For
            // native string TResult, the lens returns the raw string
            // unchanged. For framework result types the customer must
            // supply `extractText` (and optionally `setText`); without
            // it, an `AgentShieldUnsupportedOutputTypeException` is
            // raised here.
            var (text, isFromExtractor) = DeriveStage5Input(result, extractText);
            if (!string.IsNullOrEmpty(text))
            {
                var (verdict, redacted) = session.ValidateOutput(text);
                var stage5 = VerdictDispatcher.DispatchStage(
                    verdict, OnBlockPolicy.ReturnBlocked, mode);
                switch (stage5.Action.Kind)
                {
                    case "return_blocked" when !stage5.OverrideToProceed:
                        if (pendingSink is not null && verdict.PendingResolution is not null)
                        {
                            pendingSink(verdict.PendingResolution);
                        }
                        return dispatchBlocked(
                            verdict, stage5.Action.Message ?? string.Empty);
                    case "proceed_with_mutation":
                        if (isFromExtractor)
                        {
                            // advisory-only opt-in
                            // (LensWriter<TResult>.Advisory): Stage 5
                            // still ran (and a block verdict above
                            // still surfaces through dispatchBlocked),
                            // but on proceed_with_mutation we
                            // deliberately do NOT write the redacted
                            // text back. The customer asked for
                            // monitoring, not mutation.
                            if (advisoryOnly)
                            {
                                return result;
                            }
                            // write the redacted text back via
                            // the required setText
                            // delegate and return the original
                            // framework result object.
                            return ApplyRedactedText(result, redacted ?? text, setText);
                        }
                        if (redacted is TResult casted) return casted;
                        break;
                }
            }

            return result;
        }
        finally
        {
            try { session.EndTurn(); }
            catch { /* best-effort */ }
        }
    }

    /// <summary>
    /// Derive the assistant-visible text for Stage 5.
    /// <para>
    /// Returns <c>(text, isFromExtractor)</c>:
    /// </para>
    /// <list type="bullet">
    ///   <item>For native string <typeparamref name="TResult"/>, returns the raw
    ///     string and <c>isFromExtractor=false</c>.</item>
    ///   <item>For <c>null</c> or primitive types (numeric, bool, enum, char),
    ///     returns <c>null</c>/the <c>ToString()</c> coercion (faithful by
    ///     definition) and <c>isFromExtractor=false</c>.</item>
    ///   <item>When <paramref name="extractText"/> is supplied, calls it and returns
    ///     <c>(returnedText, isFromExtractor=true)</c>.</item>
    ///   <item>Otherwise throws
    ///     <see cref="AgentShieldUnsupportedOutputTypeException"/>.</item>
    /// </list>
    /// </summary>
    private static (string? Text, bool IsFromExtractor) DeriveStage5Input<TResult>(
        TResult raw,
        Func<TResult, string?>? extractText)
    {
        if (raw is string s)
        {
            return (s, false);
        }
        if (raw is null)
        {
            return (null, false);
        }
        // Primitive types: their default ToString() is a faithful
        // representation, so Stage 5 sees the true value. Only complex
        // reference types lose information through ToString().
        var t = raw.GetType();
        if (t.IsPrimitive || t.IsEnum || raw is decimal)
        {
            return (raw.ToString(), false);
        }
        if (extractText is not null)
        {
            return (extractText(raw), true);
        }
        var resultType = t.FullName ?? t.Name;
        throw new AgentShieldUnsupportedOutputTypeException(resultType);
    }

    /// <summary>
    /// Write redacted text back into a framework
    /// result.
    /// <para>
    /// At this point, <paramref name="setText"/> is guaranteed
    /// non-null when this method is reached (the lens-incomplete
    /// pairing check in <c>Shield.RunAsync</c> raises eagerly when
    /// the caller supplied <c>extractText</c> without a companion
    /// writer, and the advisory branch in the Stage 5 mutation
    /// switch above returns before calling this method when
    /// <c>advisoryOnly=true</c>).
    /// </para>
    /// </summary>
    private static TResult ApplyRedactedText<TResult>(
        TResult result,
        string redacted,
        Func<TResult, string, TResult>? setText)
    {
        if (setText is null)
        {
            // defensive only. The pairing check at the
            // Shield.RunAsync entry-point makes this unreachable.
            throw new AgentShieldLensIncompleteException();
        }
        return setText(result, redacted);
    }

    // ── Streaming Stage 1 + Stage 5 chunk-validated ────────────────
    //
    // Emission scheduling respects the guard's configured mode:
    //
    // * OnComplete — buffer every text-bearing chunk through the engine
    //   but emit nothing to the consumer until Finish() returns. The
    //   final validated text is yielded as a single chunk, or a single
    //   `[GUARDRAIL BLOCK]` chunk if the engine blocked the buffer.
    //   Replace at Finish() is byte-equivalent to Pass — the engine
    //   has only ever emitted Pass(empty) for earlier pushes, so the
    //   replacement payload is the first consumer-visible chunk.
    // * PerChunk / Windowed — emit the engine's `pushed.Payload` (the
    //   authoritative, overlap-respecting safe-to-emit slice) on Pass
    //   verdicts when non-empty; skip when empty (engine is still
    //   holding back overlap bytes). Stop verdicts emit a
    //   `[GUARDRAIL BLOCK]` chunk and abort. Replace verdicts raise
    //   `StreamingReplaceNotSupportedException` because the
    //   replacement payload is the ENTIRE validated buffer expecting
    //   the host to retract prior bytes — append-only consumers can't.
    //   SDKs forwarding the raw chunk on Pass verdicts would silently
    //   bypass windowed validators that produce payload-altered Pass
    //   actions — see `streaming-windowed-payload-respect` for context.

    internal static async IAsyncEnumerable<string> RunStreamedAsync(
        GuardrailsSession session,
        string userInput,
        Func<IAsyncEnumerable<string>> execute,
        ShieldMode mode,
        AsyncLocal<GuardrailsSession?> ambient,
        AsyncLocal<string?> ambientInput,
        [EnumeratorCancellation] CancellationToken ct = default)
    {
        ct.ThrowIfCancellationRequested();
        await using var lease = ambient.Value == session
            ? default
            : await session.AcquireTurnLeaseAsync(ct).ConfigureAwait(false);
        session.BeginTurn();
        try
        {
            // Shadow / Monitor (#14): run Stage 1 for observability,
            // push every chunk through the Stage-5 guard for audit
            // events, but always emit the ORIGINAL chunk and never
            // honour the guard's buffer / stop / replace decisions.
            // Core stamps every emitted event with `mode: shadow` +
            // `enforced: false` and routes them through the registered
            // ObservabilityProvider. Mirrors the Python / Node
            // `_MonitorStreamingValidator` contract.
            if (mode == ShieldMode.Monitor)
            {
                _ = session.ValidateInput(userInput ?? string.Empty);

                var prevSessionMon = ambient.Value;
                var prevInputMon = ambientInput.Value;
                ambient.Value = session;
                ambientInput.Value = userInput ?? string.Empty;
                try
                {
                    StreamingGuard? auditGuard = null;
                    try { auditGuard = session.StreamingSession(StreamingStage.Output); }
                    catch { /* fall back to no-guard observability */ }
                    try
                    {
                        await foreach (var chunk in execute().WithCancellation(ct).ConfigureAwait(false))
                        {
                            if (chunk is null) continue;
                            if (chunk.Length == 0)
                            {
                                yield return chunk;
                                continue;
                            }
                            if (auditGuard != null)
                            {
                                try { _ = auditGuard.Push(chunk); }
                                catch { /* observability best-effort */ }
                            }
                            // Always emit the original chunk in shadow.
                            yield return chunk;
                        }
                        if (auditGuard != null)
                        {
                            try { _ = auditGuard.Finish(); }
                            catch { /* observability best-effort */ }
                        }
                    }
                    finally
                    {
                        auditGuard?.Dispose();
                    }
                }
                finally
                {
                    ambient.Value = prevSessionMon;
                    ambientInput.Value = prevInputMon;
                }
                yield break;
            }

            var inputVerdict = session.ValidateInput(userInput ?? string.Empty);
            if (!inputVerdict.Allowed)
            {
                yield return BlockMessageFormatter.Format(inputVerdict);
                yield break;
            }
            var inputDecision = VerdictDispatcher.DispatchStage(
                inputVerdict, OnBlockPolicy.ReturnBlocked, mode);
            var effectiveInput = inputDecision.Action.Kind == "proceed_with_mutation"
                ? inputDecision.Action.Value ?? userInput ?? string.Empty
                : userInput ?? string.Empty;

            var prevSession = ambient.Value;
            var prevInput = ambientInput.Value;
            ambient.Value = session;
            ambientInput.Value = effectiveInput;
            try
            {
                using var guard = session.StreamingSession(StreamingStage.Output);
                var bufferMode = guard.Mode == StreamingMode.OnComplete;
                var stopped = false;
                await foreach (var chunk in execute().WithCancellation(ct).ConfigureAwait(false))
                {
                    if (chunk is null) continue;
                    if (chunk.Length == 0)
                    {
                        // Empty string is the framework-agnostic
                        // analogue of a metadata-only chunk — surface
                        // it so consumers that key on chunk arrival
                        // still see progress, but skip the validator.
                        yield return chunk;
                        continue;
                    }

                    var pushed = guard.Push(chunk);
                    if (pushed.Action == StreamAction.Stop)
                    {
                        yield return string.IsNullOrEmpty(pushed.Payload)
                            ? $"[GUARDRAIL BLOCK] {pushed.Reason ?? "blocked by policy"}"
                            : pushed.Payload;
                        stopped = true;
                        break;
                    }
                    else if (pushed.Action == StreamAction.Replace && !bufferMode)
                    {
                        // per_chunk / windowed yields incremental
                        // chunks to an append-only consumer in real time.
                        // The Rust core returns Replace with the ENTIRE
                        // validated buffer (per the streaming spec:
                        // "discard prior emission and substitute payload"),
                        // expecting the host to retract the bytes it
                        // already yielded. IAsyncEnumerable<string> has
                        // no retraction primitive — silently emitting
                        // the Replace payload as if it were an additive
                        // chunk would leave the leaked PHI on screen
                        // followed by the redacted version concatenated
                        // after it (canonical SSN reproducer:
                        // "SSN 123-45-6789SSN [SSN]"). Fail loudly so
                        // the configuration gets corrected.
                        throw new StreamingReplaceNotSupportedException(
                            adapter: "Shield.RunStreamedAsync",
                            reason: pushed.Reason);
                    }
                    else if (bufferMode)
                    {
                        // OnComplete: hold back text-bearing chunks until
                        // Finish() emits the validated payload.
                        continue;
                    }
                    else if (!string.IsNullOrEmpty(pushed.Payload))
                    {
                        // per_chunk / windowed: emit pushed.Payload (the
                        // engine's safe-to-emit slice) on Pass when non-
                        // empty. Empty payload means "buffered for
                        // overlap — emit nothing yet". Replace is
                        // handled above (throws) — only Pass reaches
                        // this branch in non-buffer mode.
                        yield return pushed.Payload;
                    }
                }
                if (!stopped)
                {
                    var tail = guard.Finish();
                    if (tail.Action == StreamAction.Stop)
                    {
                        yield return string.IsNullOrEmpty(tail.Payload)
                            ? $"[GUARDRAIL BLOCK] {tail.Reason ?? "blocked by policy"}"
                            : tail.Payload;
                    }
                    else if (bufferMode)
                    {
                        // OnComplete: emit the validated payload as the
                        // single terminal chunk. Empty payload (no
                        // text-bearing chunks received) yields nothing.
                        // Replace is byte-equivalent to Pass here — the
                        // engine has only ever emitted Pass(empty) for
                        // earlier pushes, so the terminal payload (full
                        // validated text on either Pass or Replace) is
                        // the FIRST and ONLY consumer-visible chunk.
                        if (!string.IsNullOrEmpty(tail.Payload))
                        {
                            yield return tail.Payload;
                        }
                    }
                    else if (tail.Action == StreamAction.Replace)
                    {
                        // same append-only sink contract as the
                        // mid-stream branch — Replace at Finish() in
                        // per_chunk / windowed cadence rewrites prior
                        // emissions and is unsafe. Fail loudly.
                        throw new StreamingReplaceNotSupportedException(
                            adapter: "Shield.RunStreamedAsync",
                            reason: tail.Reason);
                    }
                    else if (!string.IsNullOrEmpty(tail.Payload))
                    {
                        // per_chunk / windowed tail: the engine flushes
                        // the held-back overlap (Pass) here — must
                        // reach the consumer.
                        yield return tail.Payload;
                    }
                }
            }
            finally
            {
                ambient.Value = prevSession;
                ambientInput.Value = prevInput;
            }
        }
        finally
        {
            try { session.EndTurn(); }
            catch { /* best-effort */ }
        }
    }

    // ── Stage 2 + 3 + execute + Stage 4 + record ───────────────────

    internal static async Task<(bool Blocked, string Output)> RunGuardedToolAsync(
        GuardrailsSession session,
        string toolName,
        JsonElement parameters,
        Func<JsonElement, Task<string>> execute,
        ShieldMode mode,
        CancellationToken ct = default,
        string? toolCallId = null,
        Action<PendingResolution>? pendingSink = null)
    {
        ct.ThrowIfCancellationRequested();

        // binding — if the caller didn't supply an upstream
        // id, mint a per-call id so concurrent same-name calls bind
        // correctly through Stage 3 → Stage 4 instead of colliding
        // with another same-name call.
        var boundId = toolCallId ?? Guid.NewGuid().ToString("N");

        // Shadow / Monitor (#14): observability-only branch. Run Stage
        // 3 and Stage 4 validators for audit events (core stamps them
        // with `mode: shadow` + `enforced: false`), never block, never
        // apply mutated params or redacted output. Mirrors Python
        // `Shield.protect_tool` MONITOR branch and Node equivalent.
        if (mode == ShieldMode.Monitor)
        {
            var (_, _, monAdmission) = session.ValidateToolCall(toolName, parameters, boundId);

            string monOutput;
            try
            {
                ct.ThrowIfCancellationRequested();
                monOutput = await execute(parameters).ConfigureAwait(false) ?? string.Empty;
            }
            catch (Exception ex)
            {
                var monErrorText = $"[tool error] {toolName}: {ex.Message}";
                try
                {
                    JsonElement monErrEl = JsonDocument.Parse(JsonSerializer.Serialize(monErrorText)).RootElement.Clone();
                    if (monAdmission.HasValue) _ = session.ValidateToolOutput(monAdmission.Value, monErrEl);
                }
                catch { /* best-effort observability */ }
                try { session.RecordToolFailure(toolName, ex.Message); } catch { }
                return (false, monErrorText);
            }

            try
            {
                JsonElement monOutEl;
                try
                {
                    monOutEl = JsonDocument.Parse(JsonSerializer.Serialize(monOutput)).RootElement.Clone();
                }
                catch
                {
                    monOutEl = JsonDocument.Parse("\"\"").RootElement.Clone();
                }
                if (monAdmission.HasValue) _ = session.ValidateToolOutput(monAdmission.Value, monOutEl);
                try { session.RecordToolSuccess(toolName, JsonDocument.Parse(JsonSerializer.Serialize(monOutput)).RootElement); } catch { }
            }
            catch { /* best-effort observability */ }

            return (false, monOutput);
        }

        // Stage 2 + 3 — canonical tool dispatch.
        var (callVerdict, mutatedParams, admissionId) = session.ValidateToolCall(toolName, parameters, boundId);
        var callDispatch = VerdictDispatcher.DispatchTool(
            callVerdict, toolName, ToolStage.Call,
            OnBlockPolicy.ReturnBlocked, mode);
        if (callDispatch.Action.Kind == "blocked")
        {
            if (callDispatch.OverrideToProceed)
            {
                mutatedParams = parameters;
            }
            else
            {
                if (pendingSink is not null && callVerdict.PendingResolution is not null)
                {
                    pendingSink(callVerdict.PendingResolution);
                }
                return (true, callDispatch.Action.Message ?? string.Empty);
            }
        }

        // Execute the underlying tool, passing Stage-3 mutated params.
        string rawOutput;
        try
        {
            ct.ThrowIfCancellationRequested();
            rawOutput = await execute(mutatedParams).ConfigureAwait(false) ?? string.Empty;
        }
        catch (Exception ex)
        {
            try { session.RecordToolFailure(toolName, ex.Message); } catch { }
            var errorText = $"[tool error] {toolName}: {ex.Message}";
            // Run Stage 4 over the error text so policies can still
            // flag it; if Stage 4 blocks we surface the block, else
            // return the error text untouched.
            JsonElement errEl = JsonDocument.Parse(JsonSerializer.Serialize(errorText)).RootElement.Clone();
            if (!admissionId.HasValue) return (false, errorText);
            var (errVerdict, errRedacted) = session.ValidateToolOutput(admissionId.Value, errEl);
            // Use the bare-stage dispatcher (no tool-name suffix) here
            // because the error text already names the tool inline.
            var errDispatch = VerdictDispatcher.DispatchStage(
                errVerdict, OnBlockPolicy.ReturnBlocked, mode);
            if (errDispatch.Action.Kind == "return_blocked"
                && !errDispatch.OverrideToProceed)
            {
                if (pendingSink is not null && errVerdict.PendingResolution is not null)
                {
                    pendingSink(errVerdict.PendingResolution);
                }
                return (true, errDispatch.Action.Message ?? string.Empty);
            }
            return (false, JsonElementToText(errRedacted) ?? errorText);
        }

        // Stage 4
        JsonElement outEl;
        try
        {
            outEl = JsonDocument.Parse(JsonSerializer.Serialize(rawOutput)).RootElement.Clone();
        }
        catch
        {
            outEl = JsonDocument.Parse("\"\"").RootElement.Clone();
        }
        if (!admissionId.HasValue) return (false, rawOutput);
        var (outVerdict, outRedacted) = session.ValidateToolOutput(admissionId.Value, outEl);
        var outDispatch = VerdictDispatcher.DispatchTool(
            outVerdict, toolName, ToolStage.Output,
            OnBlockPolicy.ReturnBlocked, mode);
        if (outDispatch.Action.Kind == "blocked")
        {
            if (!outDispatch.OverrideToProceed)
            {
                if (outDispatch.RecordFailure)
                {
                    try { session.RecordToolFailure(toolName, outVerdict.Reason ?? "blocked"); } catch { }
                }
                if (pendingSink is not null && outVerdict.PendingResolution is not null)
                {
                    pendingSink(outVerdict.PendingResolution);
                }
                return (true, outDispatch.Action.Message ?? string.Empty);
            }
        }

        var finalText = JsonElementToText(outRedacted) ?? rawOutput;
        if (outDispatch.RecordSuccess && outDispatch.Action.Kind != "blocked")
        {
            try { session.RecordToolSuccess(toolName, JsonDocument.Parse(JsonSerializer.Serialize(finalText)).RootElement); }
            catch { /* best-effort */ }
        }
        return (false, finalText);
    }

    private static string? JsonElementToText(JsonElement el)
    {
        return el.ValueKind switch
        {
            JsonValueKind.String => el.GetString(),
            JsonValueKind.Null => null,
            JsonValueKind.Undefined => null,
            _ => el.GetRawText(),
        };
    }
}
