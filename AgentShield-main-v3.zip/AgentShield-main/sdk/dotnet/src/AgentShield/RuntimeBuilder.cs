using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;

using AgentShield.Interop;

namespace AgentShield;

/// <summary>
/// Mutable builder for <see cref="GuardrailsRuntime"/>. All resolver,
/// dispatcher, LLM caller, classifier, observability, and extractor
/// registration happens here; <see cref="Build"/> consumes the builder
/// and returns an immutable runtime.
///
/// <para>
/// Thread-safety: the builder is not thread-safe. Construct it on one
/// thread, register callbacks, then call <see cref="Build"/>.
/// </para>
/// </summary>
public sealed class RuntimeBuilder : IDisposable
{
    private IntPtr _handle;
    private bool _disposed;

    // GC-pin every delegate we hand to native code — Rust holds a raw
    // function pointer for the lifetime of the runtime, so we MUST
    // prevent the managed delegate (and the closure it captures) from
    // being collected.
    private readonly List<GCHandle> _pinnedDelegates = new();

    private RuntimeBuilder(IntPtr handle)
    {
        _handle = handle;
    }

    /// <summary>Create a builder from a single YAML config file.</summary>
    public static RuntimeBuilder FromYaml(string path)
    {
        var handle = NativeMethods.shield_builder_from_yaml(path, out var err);
        if (handle == IntPtr.Zero)
        {
            throw ReadLoaderException(err, $"Failed to load guardrails config: {path}");
        }
        return new RuntimeBuilder(handle);
    }

    /// <summary>Create a builder from a chain of YAML config files (merged in order).</summary>
    public static RuntimeBuilder FromYamlChain(IEnumerable<string> paths)
    {
        var list = new List<string>(paths);
        var pinnedStrings = new List<IntPtr>(list.Count);
        try
        {
            foreach (var p in list)
                pinnedStrings.Add(Marshal.StringToCoTaskMemUTF8(p));

            var arr = pinnedStrings.ToArray();
            var handle = NativeMethods.shield_builder_from_yaml_chain(
                arr, (UIntPtr)arr.Length, out var err);
            if (handle == IntPtr.Zero)
            {
                throw ReadLoaderException(err, "Failed to load guardrails config chain");
            }
            return new RuntimeBuilder(handle);
        }
        finally
        {
            foreach (var p in pinnedStrings)
                if (p != IntPtr.Zero) Marshal.FreeCoTaskMem(p);
        }
    }

    /// <summary>Create a builder from raw config YAML / JSON text.</summary>
    public static RuntimeBuilder FromConfigText(string configYaml)
    {
        var handle = NativeMethods.shield_builder_from_config_json(configYaml, out var err);
        if (handle == IntPtr.Zero)
        {
            throw ReadLoaderException(err, "Failed to load guardrails config from text");
        }
        return new RuntimeBuilder(handle);
    }

    /// <summary>
    /// Create a builder from a chain of YAML *strings* (no filesystem
    /// access). The rightmost string is the leaf; earlier strings are
    /// merged as ancestors with leaf-wins semantics by the Rust core
    /// string-input loader. Used by
    /// <see cref="GuardrailsConfig.Compile"/> and by callers that
    /// assemble configuration in memory (multi-tenant overlays, runtime
    /// overrides, policy packs).
    ///
    /// </summary>
    public static RuntimeBuilder FromYamlStrings(IEnumerable<string> yamls)
    {
        var list = new List<string>(yamls);
        if (list.Count == 0)
            throw new ArgumentException("FromYamlStrings requires a non-empty list of YAML strings", nameof(yamls));

        var pinnedStrings = new List<IntPtr>(list.Count);
        try
        {
            foreach (var yaml in list)
                pinnedStrings.Add(Marshal.StringToCoTaskMemUTF8(yaml));

            var arr = pinnedStrings.ToArray();
            var handle = NativeMethods.shield_builder_from_yaml_strings(
                arr, (UIntPtr)arr.Length, out var err);
            if (handle == IntPtr.Zero)
            {
                throw ReadLoaderException(err, "Failed to load guardrails config from YAML strings");
            }
            return new RuntimeBuilder(handle);
        }
        finally
        {
            foreach (var p in pinnedStrings)
                if (p != IntPtr.Zero) Marshal.FreeCoTaskMem(p);
        }
    }

    /// <summary>
    /// Construct a builder from any supported configuration shape:
    /// path, list of paths, <see cref="GuardrailsConfig"/>, or
    /// <see cref="CompiledPolicy"/>.
    /// </summary>
    public static RuntimeBuilder FromConfig(GuardrailsConfig config)
    {
        if (config is null) throw new ArgumentNullException(nameof(config));
        return FromConfig(config.Compile());
    }

    /// <summary>
    /// Construct a builder from a precompiled policy. Multi-tenant
    /// SaaS callers should cache <see cref="CompiledPolicy"/> by digest
    /// and reuse the resulting runtime to avoid repeated parsing.
    /// </summary>
    public static RuntimeBuilder FromConfig(CompiledPolicy compiled)
    {
        if (compiled is null) throw new ArgumentNullException(nameof(compiled));

        // Lazily run shield_config_compile against the held config
        // handle. This is where validation actually happens for a
        // CompiledPolicy: digest was computed via the non-validating
        // path so a partial overlay still gets a stable identity, but
        // the moment it's built into a runtime we want full schema
        // checks. Mirrors the Python / Node behaviour.
        var compiledPtr = NativeMethods.shield_config_compile(
            compiled.ConfigHandle.DangerousGetPointer(), out var err);
        NativeMethods.ThrowIfErr(err);
        try
        {
            return FromCompiledPolicy(compiledPtr);
        }
        finally
        {
            NativeMethods.shield_compiled_free(compiledPtr);
        }
    }

    /// <summary>
    /// Construct a builder directly from a native
    /// <c>ShieldCompiledPolicy*</c> handle. The handle is borrowed —
    /// the caller still owns it and is responsible for releasing it
    /// via <c>shield_compiled_free</c>.
    ///
    /// <para>
    /// This is the foundation for routing <see cref="GuardrailsConfig"/>
    /// through the native composable-config pipeline (no temporary
    /// files, no in-process YAML re-rendering).
    /// </para>
    /// </summary>
    public static RuntimeBuilder FromCompiledPolicy(IntPtr compiledHandle)
    {
        if (compiledHandle == IntPtr.Zero)
            throw new ArgumentException(
                "FromCompiledPolicy requires a non-null compiled-policy handle.",
                nameof(compiledHandle));
        var handle = NativeMethods.shield_builder_from_compiled_policy(compiledHandle, out var err);
        if (handle == IntPtr.Zero)
        {
            throw ReadLoaderException(err, "shield_builder_from_compiled_policy returned null");
        }
        return new RuntimeBuilder(handle);
    }

    // ── Resolver / dispatcher registration ────────────────────────

    /// <summary>Register the agent-resolver callback.</summary>
    public RuntimeBuilder RegisterAgentResolver(IAgentResolver resolver)
    {
        ThrowIfDisposed();
        NativeMethods.ShieldAgentResolverCallback cb = (ref NativeMethods.ShieldResolverRequest req, IntPtr _) =>
            InvokeResolver(req, resolver.Resolve);
        var freeCb = (NativeMethods.ShieldFreeResultCallback)FreeCoTaskMemCallback;
        Pin(cb);
        Pin(freeCb);
        ThrowIfErr(NativeMethods.shield_builder_register_agent_resolver(_handle, cb, freeCb, IntPtr.Zero, out var aErr), aErr);
        return this;
    }

    /// <summary>
    /// Register the runtime's active <c>kind: human</c> resolver
    /// callback. YAML does not name the handler; if none is
    /// registered, <c>kind: human</c> denies fail-closed. Last call wins.
    /// </summary>
    public RuntimeBuilder RegisterHumanResolver(IHumanResolver resolver)
    {
        ThrowIfDisposed();
        if (resolver is null) throw new ArgumentNullException(nameof(resolver));
        NativeMethods.ShieldHumanResolverCallback cb = (ref NativeMethods.ShieldHumanResolveRequest req, IntPtr _) =>
            InvokeHumanResolver(req, resolver.Resolve);
        var freeCb = (NativeMethods.ShieldFreeResultCallback)FreeCoTaskMemCallback;
        Pin(cb);
        Pin(freeCb);
        ThrowIfErr(
            NativeMethods.shield_builder_register_human_resolver(_handle, cb, freeCb, IntPtr.Zero, out var hErr),
            hErr);
        return this;
    }

    /// <summary>Register the delegate dispatcher.</summary>
    public RuntimeBuilder RegisterDelegateDispatcher(IDelegateDispatcher dispatcher)
    {
        ThrowIfDisposed();
        NativeMethods.ShieldDelegateDispatcherCallback cb = (ref NativeMethods.ShieldDelegateRequest req, IntPtr _) =>
        {
            try
            {
                var configId = ReadCStr(req.configuration_id) ?? "";
                var configType = ReadCStr(req.configuration_type) ?? "";
                var configJson = ReadCStr(req.configuration_json) ?? "{}";
                var config = JsonDocument.Parse(configJson).RootElement.Clone();
                JsonElement? lifetime = null;
                var lifetimeJson = ReadCStr(req.lifetime_json);
                if (!string.IsNullOrEmpty(lifetimeJson))
                {
                    try
                    {
                        lifetime = JsonDocument.Parse(lifetimeJson).RootElement.Clone();
                    }
                    catch
                    {
                        lifetime = null;
                    }
                }
                var baseReq = ToResolverRequest(req.base_);
                var resp = dispatcher.Dispatch(new DelegateRequest(configId, configType, config, baseReq, lifetime));
                ValidateResolverEnvelope(resp);
                return AllocResultUtf8(resp.ToWireJson());
            }
            catch (AgentShieldResolverEnvelopeException envEx)
            {
                // fail closed at the
                // delegate-dispatcher boundary when the host returned
                // a envelope missing `value` on `decision:
                // allow`. Synthesise a deny envelope so the guard
                // policy fails closed rather than latching a phantom
                // resolved/null variable.
                return AllocResultUtf8(
                    ResolverResponse.DenyWith(envEx.Message).ToWireJson());
            }
            catch (Exception ex)
            {
                return AllocResultUtf8(
                    ResolverResponse.DenyWith($"dispatcher exception: {ex.Message}").ToWireJson());
            }
        };
        var freeCb = (NativeMethods.ShieldFreeResultCallback)FreeCoTaskMemCallback;
        Pin(cb);
        Pin(freeCb);
        ThrowIfErr(NativeMethods.shield_builder_register_delegate_dispatcher(_handle, cb, freeCb, IntPtr.Zero, out var dErr), dErr);
        return this;
    }

    /// <summary>Register an LLM caller for guard policies / extractors.</summary>
    public RuntimeBuilder RegisterLlmCaller(ILlmCaller caller)
    {
        ThrowIfDisposed();
        NativeMethods.ShieldLlmCallback cb = (ref NativeMethods.ShieldLlmRequest req, IntPtr _) =>
        {
            try
            {
                var llmReq = ToLlmRequest(req);
                var resp = caller.Call(llmReq);
                return AllocResultUtf8(resp.ToWireJson());
            }
            catch (Exception ex)
            {
                return AllocResultUtf8(
                    LlmResponse.Block($"llm exception: {ex.Message}").ToWireJson());
            }
        };
        var freeCb = (NativeMethods.ShieldFreeResultCallback)FreeCoTaskMemCallback;
        Pin(cb);
        Pin(freeCb);
        ThrowIfErr(NativeMethods.shield_builder_register_llm_caller(_handle, cb, freeCb, IntPtr.Zero, out var lErr), lErr);
        return this;
    }

    /// <summary>Register a classifier caller (returns score + threshold).</summary>
    public RuntimeBuilder RegisterClassifierCaller(IClassifierCaller caller)
    {
        ThrowIfDisposed();
        NativeMethods.ShieldClassifierCallback cb = (ref NativeMethods.ShieldLlmRequest req, IntPtr _) =>
        {
            try
            {
                var llmReq = ToLlmRequest(req);
                var verdict = caller.Call(llmReq);
                return AllocResultUtf8(verdict.ToWireJson());
            }
            catch (Exception ex)
            {
                // Fail-closed: flag with a synthetic high score.
                var fallback = new ClassifierVerdict(1.0, 0.0, true,
                    Reason: $"classifier exception: {ex.Message}");
                return AllocResultUtf8(fallback.ToWireJson());
            }
        };
        var freeCb = (NativeMethods.ShieldFreeResultCallback)FreeCoTaskMemCallback;
        Pin(cb);
        Pin(freeCb);
        ThrowIfErr(NativeMethods.shield_builder_register_classifier_caller(_handle, cb, freeCb, IntPtr.Zero, out var cErr), cErr);
        return this;
    }

    /// <summary>Register an observability provider (receives JSON log events).</summary>
    public RuntimeBuilder RegisterObservabilityProvider(IObservabilityProvider provider)
    {
        ThrowIfDisposed();
        NativeMethods.ShieldLogCallback cb = (eventJsonPtr, _) =>
        {
            // Do NOT throw across the FFI boundary — a managed exception
            // here would unwind into Rust and abort the process.
            try
            {
                var json = Marshal.PtrToStringUTF8(eventJsonPtr);
                if (string.IsNullOrEmpty(json)) return;
                using var doc = JsonDocument.Parse(json);
                provider.OnLogEvent(doc.RootElement.Clone());
            }
            catch
            {
                // Swallow — observability errors must not break validation.
            }
        };
        Pin(cb);
        ThrowIfErr(NativeMethods.shield_builder_register_observability_provider(_handle, cb, IntPtr.Zero, out var oErr), oErr);
        return this;
    }

    /// <summary>Register a custom value extractor by name.</summary>
    public RuntimeBuilder RegisterExtractor(string name, IExtractor extractor)
    {
        ThrowIfDisposed();
        NativeMethods.ShieldExtractorCallback cb = (resultJsonPtr, _) =>
        {
            try
            {
                var json = Marshal.PtrToStringUTF8(resultJsonPtr) ?? "null";
                using var doc = JsonDocument.Parse(json);
                var extracted = extractor.Extract(doc.RootElement.Clone());
                if (extracted is null) return IntPtr.Zero;
                return AllocResultUtf8(extracted.Value.GetRawText());
            }
            catch
            {
                // Returning null signals "skip" to the runtime.
                return IntPtr.Zero;
            }
        };
        var freeCb = (NativeMethods.ShieldFreeResultCallback)FreeCoTaskMemCallback;
        Pin(cb);
        Pin(freeCb);
        ThrowIfErr(NativeMethods.shield_builder_register_extractor(_handle, name, cb, freeCb, IntPtr.Zero, out var xErr), xErr);
        return this;
    }

    /// <summary>
    /// Override the per-(turn, variable, tool) retry limit for
    /// <c>kind: tool</c> resolvers. Default is 3.
    /// This is a resolver-retry budget, NOT a per-tool call quota — it
    /// does NOT bound how many times the host's tool implementation can
    /// be invoked, nor is it a declarative resource control.
    /// </summary>
    public RuntimeBuilder ToolRetryLimit(int n)
    {
        ThrowIfDisposed();
        if (n < 0) throw new ArgumentOutOfRangeException(nameof(n));
        NativeMethods.shield_builder_tool_retry_limit(_handle, (UIntPtr)n);
        return this;
    }

    /// <summary>
    /// Set the runtime's effective enforcement mode (#14). Accepts
    /// <c>"active"</c> (default) or <c>"shadow"</c>. The
    /// <c>AGENT_SHIELD_MODE</c> env var, when set, takes precedence
    /// over this call.
    /// </summary>
    public RuntimeBuilder WithMode(string mode)
    {
        ThrowIfDisposed();
        if (string.IsNullOrEmpty(mode)) throw new ArgumentNullException(nameof(mode));
        var rc = NativeMethods.shield_builder_with_mode(_handle, mode);
        if (rc != 0)
        {
            throw new ArgumentException(
                $"WithMode: unknown mode '{mode}' (expected 'active' or 'shadow')",
                nameof(mode));
        }
        return this;
    }

    /// <summary>
    /// Declare host capability for sub-session IFC scope reset
    /// (proof TC-3 in <c>docs/information-flow-control-proof.md</c>).
    /// Required when the merged config declares <c>ifc.scope:
    /// per_turn</c> or <c>per_request</c>. Hosts that retain LLM
    /// context across these boundaries (LangChain memory, AutoGen
    /// group chats, persistent conversation IDs) MUST NOT call this
    /// with <c>true</c>.
    /// </summary>
    public RuntimeBuilder SupportsContextReset(bool supports = true)
    {
        ThrowIfDisposed();
        NativeMethods.shield_builder_supports_context_reset(_handle, supports ? 1 : 0);
        return this;
    }

    /// <summary>
    /// Opt into the v8 perf-logging instrumentation (PR5 / PR6). The
    /// default — when this method is never called — is
    /// <see cref="PerfTelemetry.Off"/>, which emits zero perf events
    /// and keeps the event stream byte-identical to the pre-v8
    /// baseline.
    /// </summary>
    /// <remarks>
    /// Pick <see cref="PerfTelemetry.External"/> for the
    /// predicted common-case (LLM + classifier cost signals only)
    /// or <see cref="PerfTelemetry.Full"/> for the complete
    /// stage / policy / detection / LLM / classifier event stream.
    /// See <c>spec/SPECIFICATION.md</c> for the per-event gating
    /// table.
    /// </remarks>
    public RuntimeBuilder WithPerfTelemetry(PerfTelemetry mode)
    {
        ThrowIfDisposed();
        var rc = NativeMethods.shield_builder_set_perf_telemetry(_handle, (byte)mode);
        if (rc != 0)
        {
            throw new ArgumentException(
                $"WithPerfTelemetry: native call rejected mode={mode} (rc={rc})",
                nameof(mode));
        }
        return this;
    }

    /// <summary>Configure streaming window options (trigger / size / overlap).</summary>
    public RuntimeBuilder StreamingWindow(int trigger, int windowSize, int overlap)
    {
        ThrowIfDisposed();
        if (windowSize < 0) throw new ArgumentOutOfRangeException(nameof(windowSize));
        if (overlap < 0) throw new ArgumentOutOfRangeException(nameof(overlap));
        NativeMethods.shield_builder_streaming_window(
            _handle, trigger, (UIntPtr)windowSize, (UIntPtr)overlap);
        return this;
    }

    /// <summary>Consume the builder and produce an immutable runtime.</summary>
    public GuardrailsRuntime Build()
    {
        ThrowIfDisposed();
        var rt = NativeMethods.shield_builder_build(_handle, out var err);
        if (rt == IntPtr.Zero)
        {
            throw ReadLoaderException(err, "Failed to build runtime");
        }
        // Builder handle is consumed by the build call.
        _handle = IntPtr.Zero;

        // Transfer the pinned-delegate ownership to the runtime.
        var transferred = new List<GCHandle>(_pinnedDelegates);
        _pinnedDelegates.Clear();
        return new GuardrailsRuntime(rt, transferred);
    }

    /// <summary>
    /// Finalizer — releases the native builder handle and pinned
    /// delegates if the host abandons the builder without calling
    /// <see cref="Dispose"/> or <see cref="Build"/>.
    /// </summary>
    ~RuntimeBuilder()
    {
        Dispose(disposing: false);
    }

    public void Dispose()
    {
        Dispose(disposing: true);
        GC.SuppressFinalize(this);
    }

    private void Dispose(bool disposing)
    {
        if (_disposed) return;
        _disposed = true;

        if (_handle != IntPtr.Zero)
        {
            NativeMethods.shield_builder_free(_handle);
            _handle = IntPtr.Zero;
        }

        // If Build() was never called, free the pinned delegates.
        foreach (var h in _pinnedDelegates)
            if (h.IsAllocated) h.Free();
        _pinnedDelegates.Clear();
    }

    // ── Helpers ───────────────────────────────────────────────────

    private void ThrowIfDisposed()
    {
        if (_disposed) throw new GuardrailsDisposedException(nameof(RuntimeBuilder));
    }

    private void Pin(Delegate del) => _pinnedDelegates.Add(GCHandle.Alloc(del));

    /// <summary>Allocate a UTF-8 buffer suitable for return through the FFI.</summary>
    internal static IntPtr AllocResultUtf8(string value)
    {
        var bytes = Encoding.UTF8.GetBytes(value);
        var ptr = Marshal.AllocCoTaskMem(bytes.Length + 1);
        Marshal.Copy(bytes, 0, ptr, bytes.Length);
        Marshal.WriteByte(ptr, bytes.Length, 0);
        return ptr;
    }

    private static void FreeCoTaskMemCallback(IntPtr ptr, IntPtr _)
    {
        if (ptr != IntPtr.Zero) Marshal.FreeCoTaskMem(ptr);
    }

    private static string? ReadCStr(IntPtr p) =>
        p == IntPtr.Zero ? null : Marshal.PtrToStringUTF8(p);

    private static string? ReadErr(IntPtr err)
    {
        if (err == IntPtr.Zero) return null;
        var msg = Marshal.PtrToStringUTF8(err);
        NativeMethods.shield_free_string(err);
        return msg;
    }

    private const string LoaderSentinel = "AGENT_SHIELD_LOADER_ERROR_JSON:";

    /// <summary>
    /// Build an <see cref="AgentShieldConfigException"/> from the FFI
    /// error string emitted by <c>agent_shield_core::ffi::write_runtime_err</c>.
    /// Loader-error variants prepend an
    /// <c>AGENT_SHIELD_LOADER_ERROR_JSON:{json}\n{display}</c> sentinel
    /// envelope; this helper lifts the JSON envelope into typed
    /// properties (<see cref="GuardrailsConfigException.Path"/>,
    /// <see cref="GuardrailsConfigException.Line"/>,
    /// <see cref="GuardrailsConfigException.Column"/>,
    /// <see cref="GuardrailsConfigException.Field"/>,
    /// <see cref="GuardrailsConfigException.Code"/>,
    /// <see cref="GuardrailsConfigException.Remediation"/>) while
    /// preserving the canonical display message (existing tests grep
    /// on substrings like <c>"already in extends chain"</c>). When no
    /// sentinel is present (legacy callsite or non-loader error), the
    /// helper falls back to a plain <see cref="AgentShieldConfigException"/>
    /// carrying the raw <paramref name="rawMessage"/>.
    /// </summary>
    private static AgentShieldConfigException MakeLoaderException(
        string rawMessage, string? fallbackMessage)
    {
        string display = rawMessage;
        string? path = null;
        int? line = null;
        int? column = null;
        string? field = null;
        string? code = null;
        string? remediation = null;

        if (rawMessage.StartsWith(LoaderSentinel, StringComparison.Ordinal))
        {
            var newlineIdx = rawMessage.IndexOf('\n');
            string jsonPart = newlineIdx < 0
                ? rawMessage.Substring(LoaderSentinel.Length)
                : rawMessage.Substring(
                    LoaderSentinel.Length,
                    newlineIdx - LoaderSentinel.Length);
            display = newlineIdx < 0 ? string.Empty : rawMessage.Substring(newlineIdx + 1);
            try
            {
                using var doc = JsonDocument.Parse(jsonPart);
                var root = doc.RootElement;
                if (root.TryGetProperty("path", out var pV) && pV.ValueKind == JsonValueKind.String)
                    path = pV.GetString();
                if (root.TryGetProperty("line", out var lV) && lV.ValueKind == JsonValueKind.Number
                    && lV.TryGetInt32(out var lInt)) line = lInt;
                if (root.TryGetProperty("column", out var cV) && cV.ValueKind == JsonValueKind.Number
                    && cV.TryGetInt32(out var cInt)) column = cInt;
                if (root.TryGetProperty("field", out var fV) && fV.ValueKind == JsonValueKind.String)
                    field = fV.GetString();
                if (root.TryGetProperty("code", out var codeV) && codeV.ValueKind == JsonValueKind.String)
                    code = codeV.GetString();
                if (root.TryGetProperty("remediation", out var rV) && rV.ValueKind == JsonValueKind.String)
                    remediation = rV.GetString();
            }
            catch (JsonException)
            {
                // Malformed sentinel — preserve the original error rather
                // than masking it; structured fields stay null.
                display = rawMessage;
            }
        }

        if (string.IsNullOrEmpty(display))
            display = fallbackMessage ?? rawMessage;

        return new AgentShieldConfigException(display)
        {
            Path = path,
            Line = line,
            Column = column,
            Field = field,
            Code = code,
            Remediation = remediation,
        };
    }

    /// <summary>
    /// Convenience for the four loader callsites
    /// (<see cref="FromYaml"/>, <see cref="FromYamlChain"/>,
    /// <see cref="FromConfigText"/>, <see cref="Build"/>): read the
    /// FFI error pointer (freeing it), then throw a typed
    /// <see cref="AgentShieldConfigException"/>.
    /// </summary>
    private static AgentShieldConfigException ReadLoaderException(IntPtr err, string fallbackMessage)
    {
        var raw = ReadErr(err) ?? fallbackMessage;
        return MakeLoaderException(raw, fallbackMessage);
    }

    /// <summary>
    /// Inspect the int return code of a fallible native call and throw
    /// <see cref="GuardrailsRuntimeException"/> when it indicates
    /// failure. The native side allocates an error string into
    /// <paramref name="err"/>; this helper consumes it via
    /// <see cref="ReadErr"/> (which frees the buffer).
    /// </summary>
    private static void ThrowIfErr(int rc, IntPtr err)
    {
        if (rc == 0)
        {
            // Defensive: native may set err to non-null on success in
            // future revisions; free it to avoid a leak.
            if (err != IntPtr.Zero) NativeMethods.shield_free_string(err);
            return;
        }
        var msg = ReadErr(err) ?? $"native registration failed (rc={rc})";
        throw new GuardrailsRuntimeException(msg);
    }

    internal static ResolverRequest ToResolverRequest(NativeMethods.ShieldResolverRequest req)
    {
        var contextJson = ReadCStr(req.context_json) ?? "{}";
        JsonElement context;
        try
        {
            context = JsonDocument.Parse(contextJson).RootElement.Clone();
        }
        catch
        {
            context = JsonDocument.Parse("{}").RootElement.Clone();
        }
        JsonElement? resourceParams = null;
        var paramsJson = ReadCStr(req.resource_params_json);
        if (!string.IsNullOrEmpty(paramsJson))
        {
            try
            {
                resourceParams = JsonDocument.Parse(paramsJson).RootElement.Clone();
            }
            catch
            {
                resourceParams = null;
            }
        }
        // The resolved key. The
        // canonical envelope encodes `null` for non-keyed variables
        // by setting the C string to NULL; only parse when a
        // string is actually present.
        JsonElement? requestedKey = null;
        var requestedKeyJson = ReadCStr(req.requested_key_json);
        if (!string.IsNullOrEmpty(requestedKeyJson))
        {
            try
            {
                requestedKey = JsonDocument.Parse(requestedKeyJson).RootElement.Clone();
            }
            catch
            {
                requestedKey = null;
            }
        }
        var resourceKindStr = ReadCStr(req.resource_kind);
        var resourceNameStr = ReadCStr(req.resource_name);
        // Spec — `resource: { kind, name, params }` is the
        // canonical nested shape. It exists only when both kind and
        // name are bound (i.e. the resolver fired inside an
        // invocation context).
        ResolverResource? resource = null;
        if (!string.IsNullOrEmpty(resourceKindStr) && !string.IsNullOrEmpty(resourceNameStr))
        {
            resource = new ResolverResource(resourceKindStr, resourceNameStr, resourceParams);
        }
        return new ResolverRequest(
            ReadCStr(req.request_id) ?? "",
            ReadCStr(req.variable),
            resourceKindStr,
            resourceNameStr,
            ReadCStr(req.prompt),
            ReadCStr(req.reason),
            context,
            resourceParams,
            requestedKey,
            resource);
    }

    private static LlmRequest ToLlmRequest(NativeMethods.ShieldLlmRequest req)
    {
        var contextJson = ReadCStr(req.context_json) ?? "{}";
        JsonElement context;
        try
        {
            context = JsonDocument.Parse(contextJson).RootElement.Clone();
        }
        catch
        {
            context = JsonDocument.Parse("{}").RootElement.Clone();
        }
        return new LlmRequest(
            ReadCStr(req.configuration_id),
            ReadCStr(req.prompt) ?? "",
            ReadCStr(req.input) ?? "",
            context);
    }

    private static IntPtr InvokeResolver(
        NativeMethods.ShieldResolverRequest req,
        Func<ResolverRequest, ResolverResponse> resolve)
    {
        try
        {
            var resp = resolve(ToResolverRequest(req));
            ValidateResolverEnvelope(resp);
            return AllocResultUtf8(resp.ToWireJson());
        }
        catch (AgentShieldResolverEnvelopeException envEx)
        {
            // fail closed at the resolver
            // boundary when the host returned a envelope
            // missing `value` on `decision: allow`. Synthesise a
            // deny envelope so the guard policy fails closed rather
            // than latching a phantom resolved/null variable on a
            // silent fallback.
            return AllocResultUtf8(
                ResolverResponse.DenyWith(envEx.Message).ToWireJson());
        }
        catch (Exception ex)
        {
            return AllocResultUtf8(
                ResolverResponse.DenyWith($"resolver exception: {ex.Message}").ToWireJson());
        }
    }

    /// <summary>
    /// Translate a native <see cref="NativeMethods.ShieldHumanResolveRequest"/>
    /// into the public <see cref="HumanResolveRequest"/> record, applying the same
    /// envelope validation / fail-closed marshaling as
    /// <see cref="InvokeResolver(NativeMethods.ShieldResolverRequest, Func{ResolverRequest, ResolverResponse})"/>.
    /// </summary>
    private static IntPtr InvokeHumanResolver(
        NativeMethods.ShieldHumanResolveRequest req,
        Func<HumanResolveRequest, ResolverResponse> resolve)
    {
        try
        {
            var resp = resolve(ToHumanResolveRequest(req));
            ValidateResolverEnvelope(resp);
            return AllocResultUtf8(resp.ToWireJson());
        }
        catch (AgentShieldResolverEnvelopeException envEx)
        {
            return AllocResultUtf8(
                ResolverResponse.DenyWith(envEx.Message).ToWireJson());
        }
        catch (Exception ex)
        {
            return AllocResultUtf8(
                ResolverResponse.DenyWith($"human resolver exception: {ex.Message}").ToWireJson());
        }
    }

    internal static HumanResolveRequest ToHumanResolveRequest(NativeMethods.ShieldHumanResolveRequest req)
    {
        var contextJson = ReadCStr(req.context_json) ?? "{}";
        JsonElement context;
        try
        {
            context = JsonDocument.Parse(contextJson).RootElement.Clone();
        }
        catch
        {
            context = JsonDocument.Parse("{}").RootElement.Clone();
        }
        JsonElement? resourceParams = null;
        var paramsJson = ReadCStr(req.resource_params_json);
        if (!string.IsNullOrEmpty(paramsJson))
        {
            try
            {
                resourceParams = JsonDocument.Parse(paramsJson).RootElement.Clone();
            }
            catch
            {
                resourceParams = null;
            }
        }
        JsonElement? requestedKey = null;
        var requestedKeyJson = ReadCStr(req.requested_key_json);
        if (!string.IsNullOrEmpty(requestedKeyJson))
        {
            try
            {
                requestedKey = JsonDocument.Parse(requestedKeyJson).RootElement.Clone();
            }
            catch
            {
                requestedKey = null;
            }
        }
        var resourceKindStr = ReadCStr(req.resource_kind);
        var resourceNameStr = ReadCStr(req.resource_name);
        ResolverResource? resource = null;
        if (!string.IsNullOrEmpty(resourceKindStr) && !string.IsNullOrEmpty(resourceNameStr))
        {
            resource = new ResolverResource(resourceKindStr, resourceNameStr, resourceParams);
        }
        return new HumanResolveRequest(
            RequestId: ReadCStr(req.request_id) ?? "",
            Variable: ReadCStr(req.variable),
            ResourceKind: resourceKindStr,
            ResourceName: resourceNameStr,
            Prompt: ReadCStr(req.prompt),
            Reason: ReadCStr(req.reason),
            Context: context,
            ApprovalNonce: ReadCStr(req.approval_nonce) ?? "",
            InvocationHash: ReadCStr(req.invocation_hash),
            SessionId: ReadCStr(req.session_id),
            TimeoutMs: req.timeout_ms == 0 ? (int?)null : checked((int)req.timeout_ms),
            ResourceParams: resourceParams,
            RequestedKey: requestedKey,
            Resource: resource);
    }

    /// <summary>
    /// Validate a host-returned
    /// <see cref="ResolverResponse"/> against the envelope
    /// contract. On <see cref="ResolverDecision.Allow"/> the
    /// <see cref="ResolverResponse.Value"/> field MUST be present
    /// (a non-null <c>JsonElement?</c>). It MAY carry
    /// <c>JsonValueKind.Null</c> when the resolver author
    /// deliberately publishes JSON null, but the field itself cannot
    /// be unset. <c>deny</c> / <c>cancelled</c> envelopes do not
    /// write a variable value and are unaffected.
    /// </summary>
    private static void ValidateResolverEnvelope(ResolverResponse resp)
    {
        if (resp is null)
            throw new AgentShieldResolverEnvelopeException("allow");
        if (resp.Decision == ResolverDecision.Allow && !resp.Value.HasValue)
            throw new AgentShieldResolverEnvelopeException("allow");
    }
}
