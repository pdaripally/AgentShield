using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace AgentShield;

/// <summary>
/// Framework-agnostic orchestrator for guarded agent runs. Bridges
/// the <see cref="GuardrailsRuntime"/> / <see cref="GuardrailsSession"/>
/// API to ergonomic <c>RunAsync</c> / <c>RunStreamedAsync</c> /
/// <c>ProtectToolAsync</c> entry points. Mirrors the Python
/// <c>Shield</c> orchestrator and the Node <c>Shield</c> class so the
/// customer-visible drop-in story is identical across all SDKs.
///
/// <example>
/// <code>
/// using var shield = Shield.FromYaml("guardrails.yaml")
///     .WithLlm(myLlm)
///     .Build();
/// var answer = await shield.RunAsync(async () =&gt; await agent.AskAsync(input));
/// </code>
/// </example>
///
/// <para>
/// This class is intentionally additive — it does not replace any of
/// the existing per-framework integrations
/// (<c>AgentShieldMiddleware</c>, <c>AgentShieldFilter</c>,
/// <c>GuardedChatClient</c>); customers can opt in to whichever
/// integration shape suits their codebase.
/// </para>
/// </summary>
public sealed class Shield : IDisposable
{
    private readonly GuardrailsRuntime _runtime;
    private readonly bool _ownsRuntime;
    private GuardrailsSession _session;
    private bool _ownsSession;
    private readonly CapabilityReport _capabilities;
    private readonly ShieldMode _mode;
    private readonly OnBlockPolicy _onBlock;
    private readonly Func<StageVerdict?, string, object?>? _onBlockCallback;
    // `true` when the customer explicitly called
    // `ShieldBuilder.WithOnBlock(...)`. The Pattern C `RunAsync` surface
    // defers to the shield-level policy / callback when this is set
    // (backward compatibility); otherwise it defaults to
    // `OnBlockPolicy.Raise` so Stage 1 / Stage 5 blocks surface as
    // typed `AgentShieldBlockedException` rather than silently
    // returning the `[GUARDRAIL...]` string.
    private readonly bool _onBlockExplicitlySet;
    private readonly FrameworkBundle? _bundle;
    private bool _disposed;

    // most recent `pending_resolution` envelope
    // surfaced by a Stage 2/3 block on a tool routed through any
    // adapter on this shield (`GuardedAIFunction` via MEAI's
    // `IChatClient` path; `AgentShieldFilter` via Semantic Kernel's
    // `IAutoFunctionInvocationFilter`; future adapters).
    //
    // Hosts read this via `LastPendingResolution()` to retrieve the
    // structured suspension shape (`Kind`, `Tool`, `Variable`,
    // `Prompt`, `RequestId`) without parsing the
    // `[Blocked by Agent Shield] {reason}` block message returned to
    // the LLM trajectory. Cross-SDK parity with the Python adapter's
    // `Shield.last_pending_resolution()` and the Node
    // `shield.lastPendingResolution()`.
    //
    // The latch is reset on read so a stale envelope never leaks
    // across turns.
    private PendingResolution? _lastPendingResolution;
    // session captured at the time the latch fires. Lets
    // `ResolvePendingAsync` route the resume `set_variable` call back
    // to the originating session even when invoked OUTSIDE the
    // guarded turn that produced the block (canonical Pattern A
    // timeline: tool blocks → host UI prompts the operator → host
    // calls `ResolvePendingAsync` → next agent invocation resumes
    // on the same `per_session`-scoped variable). Cross-SDK parity
    // with Python `Shield._last_pending_session` and the Node
    // `Shield._lastPendingSession`.
    private GuardrailsSession? _lastPendingSession;
    private readonly object _lastPendingResolutionLock = new();

    private static readonly AsyncLocal<GuardrailsSession?> _ambientSession = new();
    private static readonly AsyncLocal<string?> _ambientInput = new();

    /// <summary>
    /// Ambient session for the current async flow, or <c>null</c> if
    /// no <c>RunAsync</c> / <c>RunStreamedAsync</c> / <c>UseSessionAsync</c>
    /// turn is active in this flow. Mirrors <c>Activity.Current</c> /
    /// <c>HttpContext.Current</c>.
    /// </summary>
    public static GuardrailsSession? CurrentSession => _ambientSession.Value;

    /// <summary>
    /// Ambient user input for the current guarded turn after Stage 1
    /// mutations have been applied. Empty when no guarded turn is
    /// active in this async flow.
    /// </summary>
    public static string CurrentUserInput => _ambientInput.Value ?? string.Empty;

    internal Shield(
        GuardrailsRuntime runtime,
        bool ownsRuntime,
        GuardrailsSession session,
        bool ownsSession,
        CapabilityReport capabilities,
        ShieldMode mode,
        OnBlockPolicy onBlock,
        Func<StageVerdict?, string, object?>? onBlockCallback,
        FrameworkBundle? bundle,
        bool onBlockExplicitlySet = false)
    {
        _runtime = runtime ?? throw new ArgumentNullException(nameof(runtime));
        _ownsRuntime = ownsRuntime;
        _session = session ?? throw new ArgumentNullException(nameof(session));
        _ownsSession = ownsSession;
        _capabilities = capabilities ?? throw new ArgumentNullException(nameof(capabilities));
        // Shadow mode (#14) forces Monitor.
        _mode = runtime.Mode == "shadow" ? ShieldMode.Monitor : mode;
        _onBlock = onBlock;
        _onBlockCallback = onBlockCallback;
        _onBlockExplicitlySet = onBlockExplicitlySet;
        _bundle = bundle;
    }

    // ── Construction ──────────────────────────────────────────────

    /// <summary>Build a Shield from a single guardrails YAML file.</summary>
    public static ShieldBuilder FromYaml(string path) =>
        new(RuntimeBuilder.FromYaml(path));

    /// <summary>Build a Shield from a chain of guardrails YAML files
    /// (merged left → right with leaf-wins semantics).</summary>
    public static ShieldBuilder FromYaml(IReadOnlyList<string> paths) =>
        new(RuntimeBuilder.FromYamlChain(paths));

    /// <summary>Build a Shield from an existing <see cref="GuardrailsRuntime"/>.
    /// The Shield does not take ownership; the caller is still responsible
    /// for disposing the runtime.</summary>
    public static ShieldBuilder FromRuntime(GuardrailsRuntime runtime) =>
        new(runtime, ownsRuntime: false);

    // ── Surface ───────────────────────────────────────────────────

    /// <summary>The active per-shield session.</summary>
    public GuardrailsSession Session => _session;

    /// <summary>The underlying guardrails runtime.</summary>
    public GuardrailsRuntime Runtime => _runtime;

    /// <summary>The capability profile of this Shield (set by the
    /// adapter extension method).</summary>
    public CapabilityReport Capabilities => _capabilities;

    /// <summary>Behavioural mode (Enforce / Monitor).</summary>
    public ShieldMode Mode => _mode;

    /// <summary>The optional framework bundle attached at build time.</summary>
    public FrameworkBundle? Bundle => _bundle;

    /// <summary>
    /// Replace the active session. Disposes the previous session iff
    /// this Shield owned it. Returns <c>this</c> for fluent chaining.
    /// </summary>
    public Shield WithSession(GuardrailsSession session)
    {
        if (session == null) throw new ArgumentNullException(nameof(session));
        if (_ownsSession) _session.Dispose();
        _session = session;
        _ownsSession = false;
        return this;
    }

    /// <summary>
    /// Functional sibling of <see cref="WithSession"/>: returns a NEW
    /// <see cref="Shield"/> bound to a brand-new <see cref="GuardrailsSession"/>
    /// spawned from the same runtime. The original Shield (and its
    /// session) is not mutated, satisfying the post-build immutability
    /// contract documented in <c>spec/SPECIFICATION.md</c>.
    /// </summary>
    /// <remarks>
    /// The returned Shield does not own the underlying runtime — only
    /// the original Shield (or whichever instance was created via
    /// <see cref="ShieldBuilder.Build"/>) owns the runtime and is
    /// responsible for disposing it. The returned Shield does own its
    /// fresh session and will dispose it when the Shield is disposed.
    /// Mirrors the Rust <c>Shield::with_fresh_session</c>, the Node
    /// <c>shield.withFreshSession()</c>, and the Python
    /// <c>shield.with_fresh_session()</c> APIs.
    /// </remarks>
    public Shield WithFreshSession()
    {
        ThrowIfDisposed();
        var fresh = _runtime.NewSession();
        return new Shield(
            _runtime,
            ownsRuntime: false,
            fresh,
            ownsSession: true,
            _capabilities,
            _mode,
            _onBlock,
            _onBlockCallback,
            _bundle);
    }

    // ── PendingResolution latch ────────────

    /// <summary>
    /// Peek at the most recent <see cref="PendingResolution"/>
    /// envelope surfaced by a Stage 2/3 block on a tool routed
    /// through any adapter on this Shield (the
    /// <c>AgentShield.AI.GuardedChatClient</c> MEAI path and the
    /// <c>AgentShield.SemanticKernel.AgentShieldFilter</c> Semantic
    /// Kernel path both push here on every block whose verdict
    /// carries one).
    ///
    /// <para>
    /// When a guarded tool call is blocked at Stage 2/3 by a
    /// resolver that suspends pending external input (e.g. a
    /// <c>kind: human</c> resolver awaiting operator approval, or a
    /// <c>kind: tool</c> resolver awaiting a named tool call), the
    /// verdict carries a structured envelope:
    /// </para>
    /// <code>
    /// {
    ///   Kind: "human",
    ///   Tool: "agent_shield.ask_human",
    ///   Variable: "send_email_approved",
    ///   Prompt: "Approve sending this email?",
    ///   RequestId: "req-7f3c"
    /// }
    /// </code>
    /// <para>
    /// The block message routed back through the framework's
    /// tool-call boundary is shaped for the LLM trajectory
    /// (<c>[Blocked by Agent Shield]...</c>); this method gives
    /// the host a programmatic handle on the same suspension so it
    /// can drive the human-approval UI (look up the named tool's
    /// resolver, prompt the operator, etc.) without
    /// substring-matching the block message.
    /// </para>
    /// <para>
    /// <b>Non-destructive peek.</b> Reading the latch does
    /// NOT clear it. The documented inspect-then-resolve flow
    /// </para>
    /// <code>
    /// var pending = shield.LastPendingResolution();
    /// if (pending is not null)
    /// {
    ///     // Show pending.Prompt / pending.RequestId in a host UI.
    ///     await shield.ResolvePendingAsync("allow", value: true);
    /// }
    /// </code>
    /// <para>
    /// relies on this method being idempotent — multiple peeks
    /// return the same envelope until
    /// <see cref="ResolvePendingAsync"/> (or another guarded turn
    /// that latches a fresh envelope) consumes it. Only
    /// <see cref="ResolvePendingAsync"/> clears the latch.
    /// </para>
    /// <para>
    /// Returns <c>null</c> when no recent block carried a pending
    /// resolution.
    /// </para>
    /// <para>
    /// Cross-SDK parity with Python <c>Shield.last_pending_resolution()</c>
    /// and Node <c>shield.lastPendingResolution()</c>.
    /// </para>
    /// </summary>
    public PendingResolution? LastPendingResolution()
    {
        lock (_lastPendingResolutionLock)
        {
            return _lastPendingResolution;
        }
    }

    /// <summary>
    /// Internal sink used by adapter code to capture a verdict's
    /// <see cref="PendingResolution"/> envelope into the Shield's
    /// latch. Called on every Stage 2/3 block whose verdict carries
    /// one; <c>null</c> arguments are ignored. Thread-safe.
    ///
    /// <para>
    /// Adapter code uses <see cref="ComposePendingResolutionSink"/>
    /// to fold this together with any host-supplied
    /// <c>pendingResolutionSink</c> so the canonical latch always
    /// wins regardless of host-side sink behaviour.
    /// </para>
    /// </summary>
    internal void CapturePendingResolution(PendingResolution? pending)
    {
        if (pending is null) return;
        lock (_lastPendingResolutionLock)
        {
            _lastPendingResolution = pending;
            // capture the active session so a later
            // `ResolvePendingAsync` call made OUTSIDE the guarded
            // turn can still route the variable write back to the
            // originating session.
            _lastPendingSession = _ambientSession.Value ?? _session;
        }
    }

    /// <summary>
    /// Compose the Shield's internal capture sink with an optional
    /// host-supplied sink. The internal latch fires first so a
    /// misbehaving host callback can never block the canonical
    /// surfacing path on <see cref="LastPendingResolution"/>.
    /// Exceptions raised by <paramref name="extra"/> are swallowed
    /// (logged at debug by the runtime when an observability
    /// provider is wired up) so a host sink can never break the
    /// guardrail pipeline.
    /// </summary>
    internal Action<PendingResolution> ComposePendingResolutionSink(
        Action<PendingResolution>? extra)
    {
        if (extra is null)
        {
            return pr => CapturePendingResolution(pr);
        }
        return pr =>
        {
            CapturePendingResolution(pr);
            try { extra(pr); }
            catch { /* swallow — see method-level docs */ }
        };
    }

    // ── ResolvePending ────────────────────────────────────

    /// <summary>
    /// Resolve a previously-surfaced pending resolution. Writes the
    /// resolver outcome back to the variable that suspended a
    /// Stage 1/2/3/4/5 evaluation, so the next <c>ProtectToolAsync</c>
    /// <c>RunAsync</c> / adapter-middleware entry inside the same
    /// session sees the resolved value and proceeds without
    /// re-prompting.
    ///
    /// <para>
    /// Cross-SDK parity with the Python
    /// <c>Shield.resolve_pending</c> and the Node
    /// <c>shield.resolvePending</c> surfaces.
    /// </para>
    ///
    /// <example>
    /// <code>
    /// using var shield = Shield.FromYaml("guardrails.yaml").Build();
    /// var (blocked, output) = await shield.ProtectToolAsync(
    ///     "send_email", parameters, executeTool);
    /// // Operator UI: pending.Variable, pending.Prompt, pending.Kind
    /// await shield.ResolvePendingAsync("allow"); // value defaults to true
    /// // Replay — gate now sees the resolved value, tool runs.
    /// (blocked, output) = await shield.ProtectToolAsync(
    ///     "send_email", parameters, executeTool);
    /// </code>
    /// </example>
    /// </summary>
    /// <param name="decision">
    /// <c>"allow"</c> or <c>"deny"</c> — the operator's decision.
    /// When <paramref name="value"/> is omitted, <c>"allow"</c>
    /// resolves the variable to <c>true</c> and <c>"deny"</c> to
    /// <c>false</c> (the canonical boolean-approval shape).
    /// </param>
    /// <param name="value">
    /// Optional explicit value to write to the variable named by the
    /// latched <see cref="PendingResolution"/> envelope. Use this for
    /// non-boolean variables.
    /// </param>
    /// <param name="setVariables">
    /// Optional <c>{variable: value}</c> map to write multiple
    /// variables in one call. When supplied the latched envelope is
    /// ignored — use this when an <c>on_demand_by</c> resolver was
    /// configured with <c>set_variables</c> and the operator resolves
    /// several variables at once.
    /// </param>
    /// <param name="reason">
    /// Optional free-form audit string. Reserved for future
    /// observability — currently DEBUG-only.
    /// </param>
    /// <exception cref="ArgumentException">
    /// <paramref name="decision"/> is neither <c>"allow"</c> nor
    /// <c>"deny"</c>.
    /// </exception>
    /// <exception cref="InvalidOperationException">
    /// No active session is available (no ambient guarded turn AND
    /// no prior pending resolution to anchor a captured-session
    /// reference), or no <see cref="PendingResolution"/> is latched
    /// and no explicit <paramref name="setVariables"/> mapping was
    /// supplied.
    /// </exception>
    public async Task ResolvePendingAsync(
        string decision,
        object? value = null,
        IReadOnlyDictionary<string, object?>? setVariables = null,
        string? reason = null,
        CancellationToken ct = default)
    {
        ThrowIfDisposed();
        if (decision != "allow" && decision != "deny")
        {
            throw new ArgumentException(
                $"Shield.ResolvePendingAsync(decision): decision must be " +
                $"'allow' or 'deny', got '{decision}'.",
                nameof(decision));
        }
        ct.ThrowIfCancellationRequested();

        GuardrailsSession? targetSession = _ambientSession.Value;
        PendingResolution? pending;
        lock (_lastPendingResolutionLock)
        {
            if (targetSession is null) targetSession = _lastPendingSession;
            pending = _lastPendingResolution;
        }

        if (targetSession is null)
        {
            throw new InvalidOperationException(
                "Shield.ResolvePendingAsync: no active session is " +
                "available. Either call from inside a guarded turn " +
                "(`Shield.RunAsync` / Pattern A adapter middleware), " +
                "or call after a Stage 1/2/3/4 block surfaced a " +
                "`pending_resolution` envelope (the latched session " +
                "is then used).");
        }

        if (setVariables is { Count: > 0 })
        {
            foreach (var kv in setVariables)
            {
                targetSession.SetVariable(kv.Key, ToJsonElement(kv.Value));
            }
        }
        else if (pending is null)
        {
            throw new InvalidOperationException(
                "Shield.ResolvePendingAsync: no `pending_resolution` " +
                "is latched. Trigger a Stage 1/2/3/4 block via a " +
                "guarded turn first (the latch is populated when a " +
                "block verdict carries a `pending_resolution` " +
                "envelope), or pass `setVariables: ...` explicitly " +
                "to write the resolution variables yourself.");
        }
        else
        {
            if (string.IsNullOrEmpty(pending.RequestId))
            {
                throw new InvalidOperationException(
                    "Shield.ResolvePendingAsync: latched " +
                    "`pending_resolution` has no `request_id` field; " +
                    "cannot complete it.");
            }
            var resolved = value ?? (decision == "allow");
            JsonElement? valueJson = resolved is null ? null : ToJsonElement(resolved);
            targetSession.CompletePendingResolution(
                pending.RequestId,
                decision,
                valueJson,
                null,
                reason);
        }

        // Clear the latch so a subsequent successful turn does not
        // look like another pending block, and so the
        // captured-session reference is released for GC.
        lock (_lastPendingResolutionLock)
        {
            _lastPendingResolution = null;
            _lastPendingSession = null;
        }
        await Task.CompletedTask.ConfigureAwait(false);
    }

    private static JsonElement ToJsonElement(object? value)
    {
        if (value is JsonElement je) return je;
        return JsonSerializer.SerializeToElement(value, AgentShieldJsonOptions.Default);
    }

    // ── BeforeInvokeAsync ─────────────────────────────────────────

    /// <summary>
    /// Pre-flight Stage 1 check. Returns <c>null</c> when the input
    /// is allowed, or the canonical block message when Stage 1
    /// denies. Useful for "is this user input safe to even start
    /// processing?" guards at API entry points before any expensive
    /// agent work.
    ///
    /// Mirrors the Python / Node <c>before_invoke()</c> ergonomic
    /// helper. The block / proceed decision is delegated to
    /// <see cref="VerdictDispatcher.DispatchStage"/> so the message
    /// format is byte-equivalent across SDKs.
    /// </summary>
    public Task<string?> BeforeInvokeAsync(string input, CancellationToken ct = default)
    {
        ThrowIfDisposed();
        if (input == null) throw new ArgumentNullException(nameof(input));
        ct.ThrowIfCancellationRequested();
        return Task.FromResult(BeforeInvoke(input));
    }

    private string? BeforeInvoke(string input)
    {
        try
        {
            _session.BeginTurn();
        }
        catch
        {
            if (_mode == ShieldMode.Enforce) throw;
        }

        var verdict = _session.ValidateInput(input);
        var dispatch = VerdictDispatcher.DispatchStage(
            verdict,
            OnBlockPolicy.ReturnBlocked,
            _mode);

        try
        {
            _session.EndTurn();
        }
        catch
        {
            // Logged but not surfaced; turn-end errors mustn't mask
            // the block decision.
        }

        if (dispatch.OverrideToProceed)
        {
            return null;
        }

        return dispatch.Action.Kind switch
        {
            "return_blocked" => dispatch.Action.Message,
            "raise" => throw new AgentShieldBlockedException(
                verdict,
                dispatch.Action.Message ?? VerdictDispatcher.FormatBlockMessage(verdict)),
            "return_verdict" or "invoke_custom" => VerdictDispatcher.FormatBlockMessage(verdict),
            _ => null,
        };
    }

    // ── RunAsync ──────────────────────────────────────────────────

    /// <summary>
    /// Bind this Shield's session as the ambient session for
    /// the duration of <paramref name="body"/>, opening a single
    /// guarded turn around the body so per-turn variables and event
    /// latches persist across <em>all</em> agent / tool calls made
    /// inside it.
    /// <para>
    /// This is the canonical multi-agent shape: customers wrap a
    /// multi-step orchestration (e.g. a hand-off between two
    /// <c>AutoGen</c> agents) so the inner adapters
    /// (<see cref="AgentShield.AutoGen.AgentShieldMiddleware"/>, etc.)
    /// join the outer session/turn instead of allocating a fresh
    /// per-call session — which would lose <c>per_session</c> state
    /// across the handoff and break <see cref="LastPendingResolution"/>
    /// <see cref="ResolvePendingAsync"/>.
    /// </para>
    /// <para>
    /// Cross-SDK parity with the Python <c>current_session</c>
    /// <c>ContextVar</c> pattern (<c>autogen.py:796</c>) and the Node
    /// <c>AsyncLocalStorage</c> session propagation in
    /// <c>shield.ts</c>.
    /// </para>
    /// </summary>
    public async Task UseSessionAsync(Func<Task> body, CancellationToken ct = default)
    {
        ThrowIfDisposed();
        if (body == null) throw new ArgumentNullException(nameof(body));
        ct.ThrowIfCancellationRequested();

        var prevSession = _ambientSession.Value;
        var openedTurn = false;
        if (!ReferenceEquals(prevSession, _session))
        {
            _session.BeginTurn();
            openedTurn = true;
        }
        _ambientSession.Value = _session;
        try
        {
            await body().ConfigureAwait(false);
        }
        finally
        {
            _ambientSession.Value = prevSession;
            if (openedTurn)
            {
                try { _session.EndTurn(); }
                catch { /* best-effort: turn-end errors mustn't mask body exception */ }
            }
        }
    }

    /// <summary>
    /// Generic overload of <see cref="UseSessionAsync(Func{Task}, CancellationToken)"/>
    /// that returns the body's result.
    /// </summary>
    public async Task<TResult> UseSessionAsync<TResult>(
        Func<Task<TResult>> body,
        CancellationToken ct = default)
    {
        ThrowIfDisposed();
        if (body == null) throw new ArgumentNullException(nameof(body));
        ct.ThrowIfCancellationRequested();

        var prevSession = _ambientSession.Value;
        var openedTurn = false;
        if (!ReferenceEquals(prevSession, _session))
        {
            _session.BeginTurn();
            openedTurn = true;
        }
        _ambientSession.Value = _session;
        try
        {
            return await body().ConfigureAwait(false);
        }
        finally
        {
            _ambientSession.Value = prevSession;
            if (openedTurn)
            {
                try { _session.EndTurn(); }
                catch { /* best-effort: turn-end errors mustn't mask body exception */ }
            }
        }
    }

    /// <summary>
    /// Run an arbitrary async callback under Stage 1 + Stage 5
    /// enforcement. The callback's first user message should be
    /// supplied via <c>userInput</c>; if the callback's input is
    /// implicit (e.g. the underlying agent reads its own state) an
    /// empty string is acceptable and Stage 1 will validate "".
    /// </summary>
    /// <param name="onBlock">
    /// per-call block-handling policy. When <c>null</c> (the
    /// default), <c>RunAsync</c> resolves to <see cref="OnBlockPolicy.Raise"/>
    /// — a Stage 1 / Stage 5 block surfaces as a typed
    /// <see cref="AgentShieldBlockedException"/>. Pass
    /// <see cref="OnBlockPolicy.ReturnBlocked"/> to opt back into the
    /// legacy <c>[GUARDRAIL...]</c> string-return shape. Mirrors the
    /// Python <c>Shield.run</c> <c>on_block=</c> keyword and the Node
    /// <c>shield.run</c> <c>onBlock</c> option.
    /// <para>
    /// The shield-level <see cref="ShieldBuilder.WithOnBlock"/> setting
    /// continues to govern Pattern A adapters (<c>GuardedChatClient</c>,
    /// <c>AgentShieldFilter</c>, <c>AgentShieldMiddleware</c>); this
    /// per-call override applies <strong>only</strong> to the Pattern C
    /// <c>RunAsync</c> surface.
    /// </para>
    /// </param>
    public Task<TResult> RunAsync<TResult>(
        Func<Task<TResult>> execute,
        CancellationToken ct = default,
        OnBlockPolicy? onBlock = null,
        Func<TResult, string?>? extractText = null,
        LensWriter<TResult> setText = default) =>
        RunAsync(string.Empty, execute, ct, onBlock, extractText, setText);

    /// <summary>
    /// Run an arbitrary async callback under Stage 1 + Stage 5
    /// enforcement, validating <paramref name="userInput"/> at Stage 1.
    /// </summary>
    /// <param name="onBlock">
    /// per-call block-handling policy. See the <c>RunAsync</c>
    /// overload that takes only <paramref name="execute"/> for the full
    /// rationale; the short version is: <c>null</c> ⇒ <c>Raise</c> (the
    /// new safer default), pass <see cref="OnBlockPolicy.ReturnBlocked"/>
    /// for the legacy string-return shape.
    /// </param>
    /// <param name="extractText">
    /// assistant-visible-text lens. When the thunk returns
    /// something that isn't <see cref="string"/>, <c>null</c>, or a
    /// primitive type, supply <paramref name="extractText"/> to name
    /// the text field. Stage 5 runs on the extracted string; the
    /// redacted text is written back via <paramref name="setText"/>
    /// (default: reflection-write to <c>result.Text</c>).
    /// <para>
    /// Without <paramref name="extractText"/>, an unsupported result
    /// type raises
    /// <see cref="AgentShieldUnsupportedOutputTypeException"/>
    /// </para>
    /// </param>
    /// <param name="setText">
    /// companion to <paramref name="extractText"/>. Receives
    /// the original result and the redacted text; returns the result
    /// to hand back to the caller. Use this for <c>record</c> /
    /// immutable types (<c>(r, t) =&gt; r with { Text = t }</c>).
    /// </param>
    public Task<TResult> RunAsync<TResult>(
        string userInput,
        Func<Task<TResult>> execute,
        CancellationToken ct = default,
        OnBlockPolicy? onBlock = null,
        Func<TResult, string?>? extractText = null,
        LensWriter<TResult> setText = default)
    {
        ThrowIfDisposed();
        if (execute == null) throw new ArgumentNullException(nameof(execute));

        // fail-closed pairing check at entry, *before* the
        // thunk runs. Previously a missing `setText` silently invoked
        // the default reflection-mutator on `.Text`, leaving the
        // customer's `extractText` source location unredacted — the
        // same silent-bypass class that was closed at the non-lens
        // surface, re-opened at the lens opt-in surface. Eager
        // failure here also avoids burning a token-spend on a config
        // bug, since the thunk typically calls the LLM.
        if (extractText is not null && !setText.IsSpecified)
        {
            throw new AgentShieldLensIncompleteException();
        }

        // block-dispatch resolution for Pattern C `RunAsync`:
        //   1. Per-call `onBlock` parameter, when supplied, always wins
        //      (routed through `DispatchBlockedWithPolicy`, ignoring any
        //      shield-level callback / policy).
        //   2. Otherwise, when the customer explicitly called
        //      `ShieldBuilder.WithOnBlock(...)` (either the policy
        //      overload or the callback overload), the shield-level
        //      decision tree applies (via `DispatchBlocked<TResult>` —
        //      same path Pattern A adapters use).
        //   3. Otherwise (no per-call override, no shield-level
        //      opt-in), Pattern C defaults to
        //      `OnBlockPolicy.Raise` so a Stage 1 / Stage 5 block
        //      surfaces as a typed `AgentShieldBlockedException`
        //      rather than silently returning the canonical
        //      `[GUARDRAIL...]` string. See README "Pattern C surface change"
        //      for the rationale.
        Func<StageVerdict, string, TResult> dispatcher;
        if (onBlock.HasValue)
        {
            var policy = onBlock.Value;
            dispatcher = (v, m) => DispatchBlockedWithPolicy<TResult>(v, m, policy);
        }
        else if (_onBlockExplicitlySet)
        {
            dispatcher = DispatchBlocked<TResult>;
        }
        else
        {
            dispatcher = (v, m) => DispatchBlockedWithPolicy<TResult>(v, m, OnBlockPolicy.Raise);
        }

        return GuardedRunner.RunGuardedTurnAsync(
            _session,
            userInput,
            execute,
            _mode,
            dispatcher,
            _ambientSession,
            _ambientInput,
            extractText,
            // unpack the LensWriter: if `IsSpecified` but
            // `Writer` is null, the customer opted into advisory mode
            // (LensWriter<TResult>.Advisory). Pass `null` here and
            // signal advisory mode via the new `advisoryOnly` flag so
            // GuardedRunner skips the Stage 5 write-back step.
            setText.Writer,
            ct,
            CapturePendingResolution,
            // only `true` when the customer explicitly passed
            // `LensWriter<TResult>.Advisory`. `IsSpecified=false`
            // cannot reach here: the fail-closed pairing check at
            // run() entry rejects it when `extractText` is non-null.
            advisoryOnly: setText.IsSpecified && setText.Writer is null);
    }

    /// <summary>
    /// Run an arbitrary async callback under Stage 1 + Stage 5
    /// enforcement, passing the post-Stage-1 input value into the
    /// callback. This overload is the preferred shape when Stage 1
    /// policies may redact or otherwise transform input.
    /// </summary>
    /// <param name="onBlock">
    /// per-call block-handling policy. See the <c>RunAsync</c>
    /// overload that takes only <paramref name="execute"/> for the full
    /// rationale; the short version is: <c>null</c> ⇒ <c>Raise</c> (the
    /// new safer default), pass <see cref="OnBlockPolicy.ReturnBlocked"/>
    /// for the legacy string-return shape.
    /// </param>
    /// <param name="extractText">See overload docs.</param>
    /// <param name="setText">See overload docs.</param>
    public Task<TResult> RunAsync<TResult>(
        string userInput,
        Func<string, Task<TResult>> execute,
        CancellationToken ct = default,
        OnBlockPolicy? onBlock = null,
        Func<TResult, string?>? extractText = null,
        LensWriter<TResult> setText = default)
    {
        ThrowIfDisposed();
        if (execute == null) throw new ArgumentNullException(nameof(execute));
        return RunAsync(userInput, () => execute(CurrentUserInput), ct, onBlock, extractText, setText);
    }

    // ── Natural-lambda overloads for `setText` ────────────
    //
    // The `LensWriter<TResult>` shape above (a struct with an implicit
    // conversion from `Func<TResult, string, TResult>`) preserves the
    // `Advisory` sentinel but C# lambdas cannot directly target
    // a user-defined struct, even when an implicit conversion from a
    // delegate type exists — target-typing for anonymous functions only
    // considers true delegate types, not user-defined conversions.
    // Result: `setText: (r, t) => r with { Text = t }` failed to bind
    // the LensWriter overload and the compiler silently picked a
    // different overload, inferring `r` as `string` (CS1061 on r.Text).
    //
    // These Func-shaped overloads accept lambdas natively. They are
    // disambiguated from the LensWriter overloads above by making both
    // `extractText` AND `setText` *required* (no defaults), so:
    //
    //   * `RunAsync(() =>...)` → LensWriter overload (lens-less)
    //   * `RunAsync(..., setText: LensWriter<T>.Advisory)` → LensWriter overload (Advisory sentinel preserved)
    //   * `RunAsync(..., extractText: r => r.X,
    //                    setText: (r, t) => r with { X = t })` → Func overload (natural lambda)
    //
    // Internally these wrap `setText` into a `LensWriter<TResult>` via
    // the implicit conversion and delegate to the canonical overload,
    // so the dispatch path (fail-closed pairing check, advisory
    // unpacking, GuardedRunner wiring) is the single source of truth.

    /// <summary>
    /// Func-shaped overload of <see cref="RunAsync{TResult}(Func{Task{TResult}}, CancellationToken, OnBlockPolicy?, Func{TResult, string?}?, LensWriter{TResult})"/>
    /// that accepts a natural <c>(r, t) =&gt;...</c> lambda for
    /// <paramref name="setText"/>. See the LensWriter overload for full
    /// parameter docs.
    /// </summary>
    public Task<TResult> RunAsync<TResult>(
        Func<Task<TResult>> execute,
        Func<TResult, string?> extractText,
        Func<TResult, string, TResult> setText,
        CancellationToken ct = default,
        OnBlockPolicy? onBlock = null)
    {
        if (extractText == null) throw new ArgumentNullException(nameof(extractText));
        if (setText == null) throw new ArgumentNullException(nameof(setText));
        return RunAsync(string.Empty, execute, ct, onBlock, extractText, (LensWriter<TResult>)setText);
    }

    /// <summary>
    /// Func-shaped overload of <see cref="RunAsync{TResult}(string, Func{Task{TResult}}, CancellationToken, OnBlockPolicy?, Func{TResult, string?}?, LensWriter{TResult})"/>
    /// that accepts a natural <c>(r, t) =&gt;...</c> lambda for
    /// <paramref name="setText"/>. See the LensWriter overload for full
    /// parameter docs.
    /// </summary>
    public Task<TResult> RunAsync<TResult>(
        string userInput,
        Func<Task<TResult>> execute,
        Func<TResult, string?> extractText,
        Func<TResult, string, TResult> setText,
        CancellationToken ct = default,
        OnBlockPolicy? onBlock = null)
    {
        if (extractText == null) throw new ArgumentNullException(nameof(extractText));
        if (setText == null) throw new ArgumentNullException(nameof(setText));
        return RunAsync(userInput, execute, ct, onBlock, extractText, (LensWriter<TResult>)setText);
    }

    /// <summary>
    /// Func-shaped overload of <see cref="RunAsync{TResult}(string, Func{string, Task{TResult}}, CancellationToken, OnBlockPolicy?, Func{TResult, string?}?, LensWriter{TResult})"/>
    /// that accepts a natural <c>(r, t) =&gt;...</c> lambda for
    /// <paramref name="setText"/>. See the LensWriter overload for full
    /// parameter docs.
    /// </summary>
    public Task<TResult> RunAsync<TResult>(
        string userInput,
        Func<string, Task<TResult>> execute,
        Func<TResult, string?> extractText,
        Func<TResult, string, TResult> setText,
        CancellationToken ct = default,
        OnBlockPolicy? onBlock = null)
    {
        if (extractText == null) throw new ArgumentNullException(nameof(extractText));
        if (setText == null) throw new ArgumentNullException(nameof(setText));
        return RunAsync(userInput, execute, ct, onBlock, extractText, (LensWriter<TResult>)setText);
    }

    // ── RunStreamedAsync ──────────────────────────────────────────

    /// <summary>
    /// Stream a sequence of output text chunks under Stage 1 + Stage 5
    /// enforcement (per-chunk Stage 5 validation via the streaming guard).
    /// </summary>
    public IAsyncEnumerable<string> RunStreamedAsync(Func<IAsyncEnumerable<string>> execute, CancellationToken ct = default) =>
        RunStreamedAsync(string.Empty, execute, ct);

    /// <summary>
    /// Stream a sequence of output text chunks under Stage 1 + Stage 5
    /// enforcement, validating <paramref name="userInput"/> at Stage 1.
    /// </summary>
    public IAsyncEnumerable<string> RunStreamedAsync(string userInput, Func<IAsyncEnumerable<string>> execute, CancellationToken ct = default)
    {
        ThrowIfDisposed();
        if (execute == null) throw new ArgumentNullException(nameof(execute));
        return GuardedRunner.RunStreamedAsync(
            _session,
            userInput,
            execute,
            _mode,
            _ambientSession,
            _ambientInput,
            ct);
    }

    // ── ProtectToolAsync ──────────────────────────────────────────

    /// <summary>
    /// Run a tool invocation under Stage 2 + Stage 3 + Stage 4
    /// enforcement (with <c>record_tool_*</c> bookkeeping). Returns
    /// <c>(Blocked, Output)</c>; when <c>Blocked</c> is true the
    /// <c>Output</c> is the canonical <c>[GUARDRAIL ACTION] reason</c>
    /// message and the underlying tool was either short-circuited or
    /// its result was rejected by Stage 4.
    ///
    /// Pass <paramref name="toolCallId"/> (the upstream model's
    /// tool-call handle, e.g. OpenAI <c>tool_call.id</c> or Anthropic
    /// <c>tool_use.id</c>) so binding can match Stage 4 back to
    /// the canonical Stage 3 invocation under concurrent same-name
    /// calls. When omitted, a stable per-call id is minted internally.
    /// </summary>
    public Task<(bool Blocked, string Output)> ProtectToolAsync(
        string toolName,
        JsonElement parameters,
        Func<JsonElement, Task<string>> execute,
        CancellationToken ct = default,
        string? toolCallId = null)
    {
        ThrowIfDisposed();
        if (string.IsNullOrEmpty(toolName)) throw new ArgumentException("toolName is required", nameof(toolName));
        if (execute == null) throw new ArgumentNullException(nameof(execute));
        return GuardedRunner.RunGuardedToolAsync(_session, toolName, parameters, execute, _mode, ct, toolCallId, CapturePendingResolution);
    }

    // ── ProtectTools<TIn, TOut> ───────────────────────────────────

    /// <summary>
    /// Wrap a list of framework tools with Stage 2 + 3 + 4 enforcement
    /// using the supplied <see cref="IToolWrapper{TIn,TOut}"/>. The
    /// returned list contains framework-shaped tools whose body
    /// delegates to <see cref="ProtectToolAsync"/>.
    /// </summary>
    public IReadOnlyList<TOut> ProtectTools<TIn, TOut>(
        IReadOnlyList<TIn> tools,
        IToolWrapper<TIn, TOut> wrapper)
    {
        ThrowIfDisposed();
        if (tools == null) throw new ArgumentNullException(nameof(tools));
        if (wrapper == null) throw new ArgumentNullException(nameof(wrapper));

        var results = new List<TOut>(tools.Count);
        foreach (var tool in tools)
        {
            var capturedTool = tool;
            var capturedName = wrapper.GetName(tool);
            Func<JsonElement, Task<string>> guarded = async args =>
            {
                var (_, output) = await ProtectToolAsync(
                    capturedName, args,
                    mutatedArgs => wrapper.InvokeAsync(capturedTool, mutatedArgs),
                    default).ConfigureAwait(false);
                return output;
            };
            results.Add(wrapper.Wrap(capturedTool, guarded));
        }
        return results;
    }

    // ── Block dispatch ────────────────────────────────────────────

    private TResult DispatchBlocked<TResult>(StageVerdict verdict, string message)
    {
        // Custom callback short-circuits the canonical dispatcher: the
        // host owns the decision tree once they've registered one.
        if (_onBlockCallback != null)
        {
            var result = _onBlockCallback(verdict, message);
            return CoerceToResult<TResult>(result, verdict, message);
        }

        // Otherwise route through the canonical core dispatcher so the
        // .NET decision tree is byte-equivalent to the Python / Node /
        // Rust SDKs. We re-derive `message` from the dispatcher's
        // action payload to guarantee the canonical string surfaces
        // verbatim.
        var dispatch = VerdictDispatcher.DispatchStage(verdict, _onBlock, _mode);
        var action = dispatch.Action;
        switch (action.Kind)
        {
            case "raise":
                throw new AgentShieldBlockedException(verdict, action.Message ?? message);

            case "return_verdict":
                if (verdict is TResult v) return v;
                throw new AgentShieldBlockedException(verdict,
                    $"OnBlockPolicy.ReturnVerdict requires TResult assignable from StageVerdict; got {typeof(TResult).Name}.");

            case "return_blocked":
            default:
                var msg = action.Message ?? message;
                if (typeof(TResult) == typeof(string))
                    return (TResult)(object)msg;
                if (typeof(TResult) == typeof(object))
                    return (TResult)(object)msg;
                // Default for non-string TResult: throw so the caller
                // knows to either supply a callback or use string.
                throw new AgentShieldBlockedException(verdict, msg);
        }
    }

    // per-call block dispatcher used by `RunAsync`. The
    // shield-level `_onBlock` / `_onBlockCallback` settings continue to
    // govern Pattern A adapters (`GuardedChatClient`,
    // `AgentShieldFilter`, `AgentShieldMiddleware`) via
    // `DispatchBlocked<TResult>`; this dispatcher is intentionally
    // independent so the Pattern C surface (`RunAsync`) can flip its
    // default to `Raise` without changing adapter semantics.
    private TResult DispatchBlockedWithPolicy<TResult>(
        StageVerdict verdict,
        string message,
        OnBlockPolicy policy)
    {
        var dispatch = VerdictDispatcher.DispatchStage(verdict, policy, _mode);
        var action = dispatch.Action;
        switch (action.Kind)
        {
            case "raise":
                throw new AgentShieldBlockedException(verdict, action.Message ?? message);

            case "return_verdict":
                if (verdict is TResult v) return v;
                throw new AgentShieldBlockedException(verdict,
                    $"OnBlockPolicy.ReturnVerdict requires TResult assignable from StageVerdict; got {typeof(TResult).Name}.");

            case "return_blocked":
            default:
                var msg = action.Message ?? message;
                if (typeof(TResult) == typeof(string))
                    return (TResult)(object)msg;
                if (typeof(TResult) == typeof(object))
                    return (TResult)(object)msg;
                throw new AgentShieldBlockedException(verdict, msg);
        }
    }

    private static TResult CoerceToResult<TResult>(object? value, StageVerdict verdict, string message)
    {
        if (value is null)
        {
            if (default(TResult) is null) return default!;
            throw new AgentShieldBlockedException(verdict,
                $"on-block callback returned null but {typeof(TResult).Name} is non-nullable.");
        }
        if (value is TResult cast) return cast;
        if (typeof(TResult) == typeof(string))
            return (TResult)(object)(value.ToString() ?? message);
        throw new AgentShieldBlockedException(verdict,
            $"on-block callback returned {value.GetType().Name}, cannot coerce to {typeof(TResult).Name}.");
    }

    // ── IDisposable ───────────────────────────────────────────────

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        if (_ownsSession)
        {
            try { _session.Dispose(); } catch { }
        }
        if (_ownsRuntime)
        {
            try { _runtime.Dispose(); } catch { }
        }
        GC.SuppressFinalize(this);
    }

    private void ThrowIfDisposed()
    {
        if (_disposed) throw new GuardrailsDisposedException(nameof(Shield));
    }
}
