namespace AgentShield;

/// <summary>
/// Host-side resolver for variables flagged with
/// <c>on_demand_by: { kind: "human" }</c>. The registered
/// callback is invoked synchronously when the runtime needs the value
/// of a human-gated variable; it returns a envelope
/// (<c>{decision, value, set_variables, reason}</c>) shaped as a
/// <see cref="ResolverResponse"/>. YAML does not name the handler; if
/// none is registered, the resolver denies fail-closed.
///
/// <para>
/// The same fail-closed envelope validation that protects
/// <see cref="IAgentResolver"/> applies here: returning
/// <see cref="ResolverDecision.Allow"/> without an explicit
/// <see cref="ResolverResponse.Value"/> triggers the
/// fail-closed contract and the gate blocks rather than silently
/// resolving the variable to <c>null</c>.
/// </para>
/// </summary>
public interface IHumanResolver
{
    /// <summary>
    /// Resolve the supplied request synchronously. Implementations
    /// MUST NOT throw on a host-side denial — return
    /// <see cref="ResolverResponse.DenyWith(string?)"/> instead so
    /// the resolver chain observes a clean envelope. Native
    /// exceptions are caught at the FFI boundary and reified as a
    /// deny envelope.
    /// </summary>
    ResolverResponse Resolve(HumanResolveRequest request);
}
