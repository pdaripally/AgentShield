using System.Text.Json;
using System.Text.Json.Serialization;

namespace AgentShield;

/// <summary>
/// A resolved <c>configurations[]</c> entry from a <c>.guardrails.yaml</c>
/// (spec §6). Returned by
/// <see cref="GuardrailsRuntime.LlmConfiguration(string)"/>; mirrors
/// the Python <c>Runtime.llm_configuration(id)</c> dict and the Node
/// <c>Runtime.llmConfiguration(id)</c> object so adapter LLM-callers
/// can drive per-stage model / max_tokens choices from YAML rather
/// than hard-coding a fallback.
///
/// <para>
/// All fields except <see cref="Id"/> and <see cref="Type"/> are
/// optional — the routing matrix (§6.2) determines which combinations
/// are valid at load time. <see cref="Model"/> is the identifier
/// passed to the provider SDK's model parameter — a model name on
/// direct OpenAI, a deployment name on Azure OpenAI, and the
/// provider-native identifier on Anthropic / Amazon Bedrock /
/// Google Gemini / Vertex AI / Ollama / etc.
/// </para>
/// </summary>
public sealed record LlmConfiguration
{
    [JsonPropertyName("id")]
    public string Id { get; init; } = "";

    [JsonPropertyName("type")]
    public string Type { get; init; } = "";

    /// <summary>
    /// The identifier passed to the provider SDK's model parameter.
    /// For direct OpenAI this is a model name (e.g. <c>gpt-4o</c>);
    /// for Azure OpenAI this is a deployment name; for Anthropic /
    /// Amazon Bedrock / Google Gemini / Vertex AI / Ollama and other
    /// providers it is the provider-native model identifier (e.g.
    /// <c>anthropic.claude-3-5-sonnet-20241022-v2:0</c>,
    /// <c>gemini-1.5-pro</c>, <c>llama3.1</c>). The runtime treats it
    /// as an opaque string.
    /// </summary>
    [JsonPropertyName("model")]
    public string? Model { get; init; }

    [JsonPropertyName("provider")]
    public string? Provider { get; init; }

    [JsonPropertyName("provider_config")]
    public JsonElement? ProviderConfig { get; init; }

    [JsonPropertyName("endpoint")]
    public string? Endpoint { get; init; }

    [JsonPropertyName("timeout")]
    public uint? Timeout { get; init; }

    [JsonPropertyName("max_tokens")]
    public uint? MaxTokens { get; init; }

    [JsonPropertyName("api_key_env")]
    public string? ApiKeyEnv { get; init; }

    [JsonPropertyName("metadata")]
    public JsonElement? Metadata { get; init; }

    [JsonPropertyName("default")]
    public bool? Default { get; init; }
}
