using System;
using System.Runtime.InteropServices;

namespace AgentShield.Interop;

/// <summary>
/// <see cref="SafeHandle"/> wrapper around a Rust-owned
/// <c>ShieldGuardrailsConfig*</c> opaque pointer. Releases the handle
/// via <c>shield_config_free</c>.
///
/// <para>
/// Used by the .NET SDK to ferry a composable
/// <see cref="AgentShield.GuardrailsConfig"/> chain across the C ABI
/// without leaking the underlying allocation if a fluent operation
/// throws.
/// </para>
/// </summary>
internal sealed class NativeGuardrailsConfigHandle : SafeHandle
{
    /// <summary>
    /// Construct an invalid handle. The runtime fills the inner pointer
    /// when a <c>shield_config_*</c> factory returns a non-null result.
    /// </summary>
    public NativeGuardrailsConfigHandle() : base(IntPtr.Zero, ownsHandle: true) { }

    /// <summary>
    /// Wrap an already-allocated native handle. Used by the static
    /// factory helpers below after they validate the FFI return value.
    /// </summary>
    private NativeGuardrailsConfigHandle(IntPtr existing) : base(IntPtr.Zero, ownsHandle: true)
    {
        SetHandle(existing);
    }

    public override bool IsInvalid => handle == IntPtr.Zero;

    /// <summary>The raw <c>ShieldGuardrailsConfig*</c> pointer.</summary>
    public IntPtr DangerousGetPointer() => handle;

    /// <summary>
    /// Wrap a native handle returned by <c>shield_config_*</c>. The
    /// handle must already be non-null — callers MUST check the FFI
    /// out-error before calling this helper.
    /// </summary>
    public static NativeGuardrailsConfigHandle FromExisting(IntPtr existing)
    {
        if (existing == IntPtr.Zero)
            throw new ArgumentException(
                "Cannot wrap a null ShieldGuardrailsConfig handle.",
                nameof(existing));
        return new NativeGuardrailsConfigHandle(existing);
    }

    protected override bool ReleaseHandle()
    {
        if (handle != IntPtr.Zero)
        {
            NativeMethods.shield_config_free(handle);
            SetHandle(IntPtr.Zero);
        }
        return true;
    }
}

/// <summary>
/// <see cref="SafeHandle"/> wrapper around a Rust-owned
/// <c>ShieldCompiledPolicy*</c> opaque pointer. Releases the handle
/// via <c>shield_compiled_free</c>.
///
/// <para>
/// A compiled policy is the hashable, byte-stable result of
/// <c>GuardrailsConfig.compile()</c>. Multi-tenant SaaS callers cache
/// these by digest and reuse the resulting runtime to avoid repeated
/// parsing.
/// </para>
/// </summary>
internal sealed class NativeCompiledPolicyHandle : SafeHandle
{
    /// <summary>Construct an invalid handle.</summary>
    public NativeCompiledPolicyHandle() : base(IntPtr.Zero, ownsHandle: true) { }

    private NativeCompiledPolicyHandle(IntPtr existing) : base(IntPtr.Zero, ownsHandle: true)
    {
        SetHandle(existing);
    }

    public override bool IsInvalid => handle == IntPtr.Zero;

    /// <summary>The raw <c>ShieldCompiledPolicy*</c> pointer.</summary>
    public IntPtr DangerousGetPointer() => handle;

    /// <summary>
    /// Wrap a native handle returned by <c>shield_config_compile</c>.
    /// </summary>
    public static NativeCompiledPolicyHandle FromExisting(IntPtr existing)
    {
        if (existing == IntPtr.Zero)
            throw new ArgumentException(
                "Cannot wrap a null ShieldCompiledPolicy handle.",
                nameof(existing));
        return new NativeCompiledPolicyHandle(existing);
    }

    protected override bool ReleaseHandle()
    {
        if (handle != IntPtr.Zero)
        {
            NativeMethods.shield_compiled_free(handle);
            SetHandle(IntPtr.Zero);
        }
        return true;
    }
}
