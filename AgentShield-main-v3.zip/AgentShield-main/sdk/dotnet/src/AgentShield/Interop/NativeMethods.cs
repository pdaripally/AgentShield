using System;
using System.Runtime.InteropServices;

namespace AgentShield.Interop;

/// <summary>
/// P/Invoke declarations for the `shield_*` C ABI exposed by the
/// agent_shield_core native library.
///
/// <para>
/// <b>This file IS the canonical ABI surface for the .NET binding.</b>
/// No hand-maintained C header is shipped with agent_shield_core; the
/// Rust source-of-truth lives at
/// <c>sdk/rust/agent_shield_core/src/ffi.rs</c>. When extending or
/// auditing this file, cross-check signatures against <c>ffi.rs</c>
/// directly. If a generated C header is ever required, run cbindgen
/// against the <c>agent_shield_core</c> crate locally — do not
/// reintroduce a hand-maintained header in-tree.
/// </para>
///
/// Conventions:
///   * Strings out of Rust are owned by Rust and must be freed via
///     <see cref="shield_free_string"/> after copying.
///   * Fallible functions take an <c>out IntPtr err</c>; on failure
///     <paramref name="err"/> is set to a freshly allocated UTF-8 string
///     the caller MUST free with <see cref="shield_free_string"/>.
///   * Callback shapes: host allocates the returned UTF-8 buffer with
///     <see cref="Marshal.AllocCoTaskMem(int)"/> and the paired free
///     callback runs <see cref="Marshal.FreeCoTaskMem(IntPtr)"/>.
/// </summary>
internal static class NativeMethods
{
    private const string LibName = "agent_shield_core";

    // ── Callback delegate types ────────────────────────────────────

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    internal delegate void ShieldFreeResultCallback(IntPtr ptr, IntPtr userData);

    /// <summary>
    /// Mirror of <c>ShieldResolverRequest</c> from
    /// <c>sdk/rust/agent_shield_core/src/ffi.rs</c> (the canonical ABI
    /// surface). All fields are NUL-terminated UTF-8 strings owned by
    /// Rust for the lifetime of the callback invocation.
    ///
    /// <para>
    /// <c>resource_params_json</c> carries the <c>resource.params</c>
    /// map as JSON; <c>null</c> when the resolver fires outside an
    /// invocation context.
    /// </para>
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    internal struct ShieldResolverRequest
    {
        public IntPtr request_id;
        public IntPtr variable;
        public IntPtr resource_kind;
        public IntPtr resource_name;
        public IntPtr resource_params_json;
        public IntPtr prompt;
        public IntPtr reason;
        public IntPtr context_json;
        // The resolved key. JSON-
        // encoded value (`null` when the target variable is
        // non-keyed; otherwise a JSON-encoded scalar / object
        // — most commonly a string). Owned by Rust for the
        // duration of the callback. Field order matches
        // `ShieldResolverRequest` in `sdk/rust/agent_shield_core/src/ffi.rs`.
        public IntPtr requested_key_json;
    }

    /// <summary>
    /// Mirror of <c>ShieldDelegateRequest</c>. Carries the resolver's
    /// <c>lifetime:</c> declaration as JSON so the dispatcher can mint
    /// per-call envelopes verbatim.
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    internal struct ShieldDelegateRequest
    {
        public IntPtr configuration_id;
        public IntPtr configuration_type;
        public IntPtr configuration_json;
        public IntPtr lifetime_json;
        public ShieldResolverRequest base_;
    }

    [StructLayout(LayoutKind.Sequential)]
    internal struct ShieldLlmRequest
    {
        public IntPtr configuration_id;
        public IntPtr prompt;
        public IntPtr input;
        public IntPtr context_json;
    }

    /// <summary>
    /// Mirror of <c>ShieldHumanResolveRequest</c> from
    /// <c>sdk/rust/agent_shield_core/src/ffi.rs</c>. Carries the
    /// canonical resolver fields plus the human-specific
    /// <c>approval_nonce</c> (spec anti-replay token),
    /// <c>invocation_hash</c>, <c>session_id</c>, and
    /// <c>timeout_ms</c>. Field order must stay in sync with the
    /// Rust struct — this binding is positional.
    ///
    /// <para>
    /// All <c>IntPtr</c> fields are NUL-terminated UTF-8 strings
    /// owned by Rust for the duration of the callback (<c>null</c>
    /// ⇒ field absent). <c>timeout_ms</c> carries either the YAML value
    /// or the runtime's host-defined default.
    /// </para>
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    internal struct ShieldHumanResolveRequest
    {
        public IntPtr request_id;
        public IntPtr variable;
        public IntPtr resource_kind;
        public IntPtr resource_name;
        public IntPtr resource_params_json;
        public IntPtr prompt;
        public IntPtr reason;
        public IntPtr context_json;
        public IntPtr requested_key_json;
        public IntPtr approval_nonce;
        public IntPtr invocation_hash;
        public IntPtr session_id;
        public uint timeout_ms;
    }

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    internal delegate IntPtr ShieldAgentResolverCallback(
        ref ShieldResolverRequest req, IntPtr userData);

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    internal delegate IntPtr ShieldDelegateDispatcherCallback(
        ref ShieldDelegateRequest req, IntPtr userData);

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    internal delegate IntPtr ShieldHumanResolverCallback(
        ref ShieldHumanResolveRequest req, IntPtr userData);

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    internal delegate IntPtr ShieldLlmCallback(
        ref ShieldLlmRequest req, IntPtr userData);

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    internal delegate IntPtr ShieldClassifierCallback(
        ref ShieldLlmRequest req, IntPtr userData);

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    internal delegate void ShieldLogCallback(IntPtr eventJson, IntPtr userData);

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    internal delegate IntPtr ShieldExtractorCallback(IntPtr resultJson, IntPtr userData);

    // ── Builder lifecycle ─────────────────────────────────────────

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_builder_from_yaml(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string path,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_builder_from_yaml_chain(
        [In] IntPtr[] paths,
        UIntPtr n,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_builder_from_yaml_strings(
        [In] IntPtr[] yamls,
        UIntPtr n,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_builder_from_config_json(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string configYaml,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void shield_builder_free(IntPtr builder);

    // ── Builder registration ──────────────────────────────────────

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int shield_builder_register_agent_resolver(
        IntPtr builder,
        ShieldAgentResolverCallback cb,
        ShieldFreeResultCallback freeResult,
        IntPtr userData,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int shield_builder_register_delegate_dispatcher(
        IntPtr builder,
        ShieldDelegateDispatcherCallback cb,
        ShieldFreeResultCallback freeResult,
        IntPtr userData,
        out IntPtr err);

    /// <summary>
    /// Register the runtime's active <c>kind: human</c> resolver
    /// callback. Mirrors <c>shield_builder_register_human_resolver</c>
    /// in the Rust core. Last registration wins.
    /// </summary>
    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int shield_builder_register_human_resolver(
        IntPtr builder,
        ShieldHumanResolverCallback cb,
        ShieldFreeResultCallback freeResult,
        IntPtr userData,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int shield_builder_register_llm_caller(
        IntPtr builder,
        ShieldLlmCallback cb,
        ShieldFreeResultCallback freeResult,
        IntPtr userData,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int shield_builder_register_classifier_caller(
        IntPtr builder,
        ShieldClassifierCallback cb,
        ShieldFreeResultCallback freeResult,
        IntPtr userData,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int shield_builder_register_observability_provider(
        IntPtr builder,
        ShieldLogCallback cb,
        IntPtr userData,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int shield_builder_register_extractor(
        IntPtr builder,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string name,
        ShieldExtractorCallback cb,
        ShieldFreeResultCallback freeResult,
        IntPtr userData,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void shield_builder_tool_retry_limit(
        IntPtr builder,
        UIntPtr n);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    internal static extern int shield_builder_with_mode(
        IntPtr builder,
        [MarshalAs(UnmanagedType.LPStr)] string mode);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void shield_builder_supports_context_reset(
        IntPtr builder,
        int supports);

    /// <summary>
    /// PR6 (v8 perf-logging) — set the perf-telemetry gating mode.
    /// <paramref name="mode"/> is a one-byte enum encoding:
    /// <c>0 = Off</c>, <c>1 = External</c>, <c>2 = Full</c>.
    /// Returns 0 on success, -1 on null builder or out-of-range byte.
    /// </summary>
    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int shield_builder_set_perf_telemetry(
        IntPtr builder,
        byte mode);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void shield_builder_streaming_window(
        IntPtr builder,
        int trigger,
        UIntPtr windowSize,
        UIntPtr overlap);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_builder_build(IntPtr builder, out IntPtr err);

    // ── Runtime ────────────────────────────────────────────────────

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void shield_runtime_free(IntPtr runtime);

    /// <summary>
    /// Block until every registered observability provider's worker
    /// queue has drained the events emitted so far. Hosts that
    /// synchronously inspect captured events after a <c>Validate*</c>
    /// call MUST flush first.
    /// </summary>
    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void shield_runtime_flush_observability(IntPtr runtime);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_runtime_new_session(
        IntPtr runtime,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string? requestContextJson,
        out IntPtr err);

    /// <summary>
    /// Effective <c>RuntimeMode</c> (#14) as a borrowed UTF-8 static
    /// string. Pointer is owned by core; do NOT free.
    /// </summary>
    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_runtime_mode(IntPtr runtime);

    /// <summary>
    /// Look up a <c>configurations[]</c> entry by id.
    /// Mirrors the pyo3 / napi-rs accessors on the Python and Node
    /// SDKs so the .NET adapters can drive per-stage LLM-judge
    /// model / max_tokens choices from YAML.
    ///
    /// Returns a heap-allocated UTF-8 JSON object pointer (callers
    /// MUST free with <see cref="shield_free_string"/>) on match,
    /// <c>IntPtr.Zero</c> with <paramref name="err"/> populated on
    /// hard errors (null runtime / non-UTF-8 id), or
    /// <c>IntPtr.Zero</c> with <paramref name="err"/> left null when
    /// no configuration matches.
    /// </summary>
    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_runtime_llm_configuration(
        IntPtr runtime,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string configurationId,
        out IntPtr err);

    /// <summary>
    /// Look up ANY <c>configurations[]</c> entry by id, regardless of
    /// <c>type:</c>. Surfaces every populated field — including
    /// classifier-specific (<c>headers</c>, <c>threshold</c>,
    /// <c>category_thresholds</c>, <c>method</c>) and HTTP-endpoint
    /// MCP / A2A fields that
    /// <see cref="shield_runtime_llm_configuration"/> omits.
    ///
    /// <para>
    /// Mirrors <c>PyGuardrailsRuntime.configuration</c> (Python) and
    /// <c>Runtime.configuration</c> (Node); routes through the
    /// language-agnostic
    /// <c>agent_shield_core::ShieldConfiguration::to_full_json_value</c>
    /// helper so the returned JSON is byte-equivalent across all
    /// three bindings — the cross-SDK regression contract.
    /// </para>
    ///
    /// <para>
    /// Classifier callers (<see cref="AgentShield.IClassifierCaller"/>
    /// implementations) invoke this from inside their
    /// <c>Call</c> implementation, passing the request's
    /// <c>configuration_id</c>, so they can read endpoint /
    /// headers / threshold / category_thresholds / provider_config
    /// directly from YAML — no parallel YAML→config map in host
    /// code, no second YAML parse.
    /// </para>
    ///
    /// Returns a heap-allocated UTF-8 JSON object pointer (callers
    /// MUST free with <see cref="shield_free_string"/>) on match,
    /// <c>IntPtr.Zero</c> with <paramref name="err"/> populated on
    /// hard errors (null runtime / non-UTF-8 id), or
    /// <c>IntPtr.Zero</c> with <paramref name="err"/> left null when
    /// no configuration matches.
    /// </summary>
    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_runtime_configuration(
        IntPtr runtime,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string configurationId,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void shield_session_free(IntPtr session);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void shield_set_correlation_id(
        IntPtr session,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string? value);

    // ── Variable ops ───────────────────────────────────────────────

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int shield_session_set_variable(
        IntPtr session,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string name,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string valueJson,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int shield_session_reset_variable(
        IntPtr session,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string name,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_session_resolve_variable(
        IntPtr session,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string name,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_session_read_variable(
        IntPtr session,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string name,
        out IntPtr err);

    // ── Event ops ──────────────────────────────────────────────────

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int shield_session_emit_event(
        IntPtr session,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string eventId,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string? lifetimeJson,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string? payloadJson,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int shield_session_clear_event(
        IntPtr session,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string eventId,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int shield_session_emit_incident(
        IntPtr session,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string name,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string? payloadJson,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_complete_pending_resolution(
        IntPtr session,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string requestId,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string decision,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string? valueJson,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string? setVariablesJson,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string? reason);

    // ── Boundary ops ───────────────────────────────────────────────

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern ulong shield_session_begin_turn(IntPtr session, out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int shield_session_end_turn(IntPtr session, out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern ulong shield_try_acquire_turn_lease(IntPtr session);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    [return: MarshalAs(UnmanagedType.I1)]
    internal static extern bool shield_release_turn_lease(IntPtr session, ulong token);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern ulong shield_session_begin_request(IntPtr session, out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int shield_session_end_request(IntPtr session, out IntPtr err);

    // ── Stage validation ───────────────────────────────────────────

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_session_validate_input(
        IntPtr session,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string input,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_session_validate_state(
        IntPtr session,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string invocationJson,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_session_validate_tool_call(
        IntPtr session,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string tool,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string paramsJson,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string? toolCallId,
        out IntPtr mutatedParamsJson,
        out ulong admissionId,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_session_validate_tool_output(
        IntPtr session,
        ulong admissionId,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string resultJson,
        out IntPtr mutatedResultJson,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void shield_session_evict_admission(
        IntPtr session,
        ulong admissionId);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_session_validate_endpoint_call(
        IntPtr session,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string method,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string uri,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string bodyJson,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string? toolCallId,
        out IntPtr mutatedBodyJson,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_session_validate_agent_call(
        IntPtr session,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string agent,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string paramsJson,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string? toolCallId,
        out IntPtr mutatedParamsJson,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_session_validate_output(
        IntPtr session,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string response,
        out IntPtr mutatedResponse,
        out IntPtr err);

    // ── Resource cycle helpers ─────────────────────────────────────

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int shield_session_record_tool_success(
        IntPtr session,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string tool,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string resultJson,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int shield_session_record_tool_failure(
        IntPtr session,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string tool,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string errorMessage,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int shield_session_record_endpoint_success(
        IntPtr session,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string method,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string uri,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string resultJson,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int shield_session_record_endpoint_failure(
        IntPtr session,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string method,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string uri,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string errorMessage,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int shield_session_record_agent_success(
        IntPtr session,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string agent,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string resultJson,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int shield_session_record_agent_failure(
        IntPtr session,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string agent,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string errorMessage,
        out IntPtr err);

    // ── Streaming ──────────────────────────────────────────────────

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_session_streaming_session(
        IntPtr session,
        int stage,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_stream_push(
        IntPtr stream,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string chunk,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_stream_finish(IntPtr stream, out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void shield_stream_free(IntPtr stream);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int shield_stream_mode(IntPtr stream);

    // ── GuardrailsConfig / CompiledPolicy ──────────────────────────
    //
    // Composable configuration surface. Hosts assemble a chain of
    // YAML / string / value layers, compile it once into a
    // CompiledPolicy handle, and feed that into a runtime via
    // shield_builder_from_compiled_policy. Every fluent extension
    // function returns a NEW handle — neither input is consumed,
    // both must be freed by the caller.

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_config_load(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string path,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_config_from_string(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string yaml,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_config_from_json(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string json,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_config_extend(
        IntPtr handle,
        IntPtr other,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_config_extend_path(
        IntPtr handle,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string path,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_config_extend_string(
        IntPtr handle,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string yaml,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_config_with_overrides_json(
        IntPtr handle,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string json,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern UIntPtr shield_config_len(IntPtr handle);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    [return: MarshalAs(UnmanagedType.I1)]
    internal static extern bool shield_config_is_empty(IntPtr handle);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_config_compile(IntPtr handle, out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_config_digest(IntPtr handle, out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void shield_config_free(IntPtr handle);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_compiled_digest(IntPtr handle);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void shield_compiled_free(IntPtr handle);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_builder_from_compiled_policy(
        IntPtr compiled,
        out IntPtr err);

    // ── Misc ───────────────────────────────────────────────────────

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_parse_lifetime(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string jsonIn,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void shield_free_string(IntPtr s);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_version();

    // ── Canonical verdict-handling decision (Stage 1/5 + tools) ───────

    /// <summary>
    /// Return JSON-encoded VerdictDispatch for a Stage 1 / Stage 5
    /// verdict. <paramref name="policy"/> is OnBlockPolicy as int
    /// (0=ReturnBlocked, 1=ReturnVerdict, 2=Raise, 3=Custom).
    /// <paramref name="mode"/> is ShieldMode as int (0=Enforce,
    /// 1=Monitor). Caller MUST free the returned string with
    /// <see cref="shield_free_string"/>.
    /// </summary>
    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_dispatch_stage_verdict(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string verdictJson,
        uint policy,
        uint mode,
        out IntPtr err);

    /// <summary>
    /// Return JSON-encoded ToolVerdictDispatch for a Stage 2/3/4
    /// verdict on a tool call. <paramref name="stage"/> is 0=Call
    /// (Stage 2/3) or 1=Output (Stage 4).
    /// </summary>
    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_dispatch_tool_verdict(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string verdictJson,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string toolName,
        uint stage,
        uint policy,
        uint mode,
        out IntPtr err);

    /// <summary>
    /// Return the canonical <c>[GUARDRAIL ACTION] reason</c> string for
    /// a verdict. Caller MUST free the returned string.
    /// </summary>
    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_format_block_message(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string verdictJson,
        out IntPtr err);

    [DllImport(LibName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern IntPtr shield_format_stream_block_message(
        [MarshalAs(UnmanagedType.LPUTF8Str)] string verdictJson,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string streamKind,
        out IntPtr err);

    // ── Helpers ────────────────────────────────────────────────────

    /// <summary>Read a UTF-8 string returned by Rust and free it.</summary>
    internal static string? ReadAndFreeString(IntPtr ptr)
    {
        if (ptr == IntPtr.Zero) return null;
        try
        {
            return Marshal.PtrToStringUTF8(ptr);
        }
        finally
        {
            shield_free_string(ptr);
        }
    }

    /// <summary>
    /// If <paramref name="err"/> is non-null, free it after reading the
    /// message and throw a <see cref="ShieldNativeException"/>.
    /// </summary>
    internal static void ThrowIfErr(IntPtr err)
    {
        if (err == IntPtr.Zero) return;
        var msg = Marshal.PtrToStringUTF8(err) ?? "<unknown native error>";
        shield_free_string(err);
        throw new ShieldNativeException(msg);
    }
}

/// <summary>
/// Thrown when the native ABI populates an `err` out-parameter.
/// </summary>
public sealed class ShieldNativeException : Exception
{
    public ShieldNativeException(string message) : base(message) { }
}
