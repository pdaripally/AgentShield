using System.Text.Json;

namespace AgentShield;

/// <summary>
/// Pluggable observability provider that receives every log event the
/// runtime emits (one event per stage decision, variable change,
/// boundary, etc.). Events are JSON-serialized per spec §5.3 and exposed
/// to callers as <see cref="JsonElement"/> for forwarding to OTel /
/// CloudWatch / Azure Monitor / etc.
/// </summary>
public interface IObservabilityProvider
{
    void OnLogEvent(JsonElement eventJson);
}
