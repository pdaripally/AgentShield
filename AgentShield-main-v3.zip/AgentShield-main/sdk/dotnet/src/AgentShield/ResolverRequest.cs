using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace AgentShield;

/// <summary>
/// Envelope passed to a host-implemented resolver / dispatcher. The
/// fields are NUL-checked then UTF-8 decoded from the native struct.
///
/// <para>
/// <see cref="ResourceParams"/> carries the <c>resource.params</c>
/// map (the same JSON object the agent passed to the gated tool /
/// agent / endpoint). Hosts use it to make parameter-sensitive
/// approval decisions. <c>null</c> when the resolver fires outside an
/// invocation context (e.g. a top-level variable resolution).
/// </para>
///
/// <para>
/// <see cref="Resource"/> is the spec-canonical nested envelope
/// (<c>{ kind, name, params }</c>) introduced for cross-SDK
/// parity with the Node and Python bindings. <see cref="ResourceKind"/>
/// <see cref="ResourceName"/> / <see cref="ResourceParams"/> are
/// retained verbatim as flat back-compat fields — the two
/// representations describe the same resource and hosts MAY consume
/// either.
/// </para>
///
/// <para>
/// <see cref="RequestedKey"/> is the / / /// resolved key forwarded by the runtime when the target variable
/// declares <c>key:</c>. <c>null</c> when the variable is non-keyed;
/// otherwise a JSON-encoded value (most commonly a string, but any
/// JSON shape is permitted — hosts that gate per-key SHOULD treat it
/// as opaque). Previously the canonical core serializers dropped this
/// field, so the .NET binding never saw it.
/// </para>
/// </summary>
public sealed record ResolverRequest(
    string RequestId,
    string? Variable,
    string? ResourceKind,
    string? ResourceName,
    string? Prompt,
    string? Reason,
    JsonElement Context,
    JsonElement? ResourceParams = null,
    JsonElement? RequestedKey = null,
    ResolverResource? Resource = null);

/// <summary>
/// Spec <c>resource: {kind, name, params}</c> envelope.
/// Mirrors the nested shape exposed by the Python (<c>resource</c>
/// dict) and Node (<see cref="ResolverRequest.Resource"/>) bindings
/// so a guardrail file authored against any SDK lands identical
/// host-side data in every other binding.
/// </summary>
/// <param name="Kind">
/// Lowercase canonical resource kind: <c>"tool"</c>, <c>"agent"</c>,
/// or <c>"endpoint"</c>.
/// </param>
/// <param name="Name">Resource name from the guardrails YAML.</param>
/// <param name="Params">
/// Invocation parameters (<c>resource.params</c>). <c>null</c> when
/// the resolver fires outside any invocation context.
/// </param>
public sealed record ResolverResource(
    string Kind,
    string Name,
    JsonElement? Params);

/// <summary>
/// Decisions a resolver can return. Maps to spec resolver semantics
/// (allow / deny / cancelled).
/// </summary>
public enum ResolverDecision
{
    Allow,
    Deny,
    Cancelled,
}

/// <summary>
/// Response a resolver returns to the runtime.
///
/// <para>
/// <see cref="Value"/> populates the variable when <see cref="Decision"/>
/// is <see cref="ResolverDecision.Allow"/>. <see cref="SetVariables"/>
/// optionally lets the resolver set additional variables atomically.
/// </para>
/// </summary>
public sealed record ResolverResponse(
    ResolverDecision Decision,
    JsonElement? Value = null,
    IReadOnlyDictionary<string, JsonElement>? SetVariables = null,
    string? Reason = null)
{
    /// <summary>Build a basic allow response with a value.</summary>
    public static ResolverResponse AllowWith(JsonElement value) =>
        new(ResolverDecision.Allow, value);

    /// <summary>Build a deny response with an optional reason.</summary>
    public static ResolverResponse DenyWith(string? reason = null) =>
        new(ResolverDecision.Deny, null, null, reason);

    /// <summary>Build a cancellation response with an optional reason.</summary>
    public static ResolverResponse CancelledWith(string? reason = null) =>
        new(ResolverDecision.Cancelled, null, null, reason);

    internal string ToWireJson()
    {
        var obj = new JsonObject
        {
            ["decision"] = Decision switch
            {
                ResolverDecision.Allow => "allow",
                ResolverDecision.Deny => "deny",
                ResolverDecision.Cancelled => "cancelled",
                _ => "deny",
            },
        };
        obj["value"] = Value.HasValue
            ? JsonNode.Parse(Value.Value.GetRawText())
            : null;
        if (SetVariables is { Count: > 0 })
        {
            var sv = new JsonObject();
            foreach (var kv in SetVariables)
                sv[kv.Key] = JsonNode.Parse(kv.Value.GetRawText());
            obj["set_variables"] = sv;
        }
        if (Reason is not null)
            obj["reason"] = Reason;
        return obj.ToJsonString();
    }
}
