# Agent Shield — .NET SDK

.NET SDK for [Agent Shield](https://github.com/microsoft/AgentShield), an open specification and reference implementation for runtime security controls on AI agents. Loads a [`.guardrails.yaml`](https://github.com/microsoft/AgentShield/blob/main/spec/SPECIFICATION.md) contract and enforces it across **5 validation stages** (Input → State → Tool execution → Post-tool → Output).

The .NET SDK is a P/Invoke layer over the Rust `agent_shield_core` plus an idiomatic C# facade. All validation logic lives in Rust; the .NET side translates shapes and exposes per-framework integrations through each ecosystem's native middleware contract.

## Packages

| Package | Description |
|---------|-------------|
| `AgentShield` | Core runtime + P/Invoke bindings + `Shield` builder |
| `AgentShield.AI` | [Microsoft.Extensions.AI](https://learn.microsoft.com/en-us/dotnet/ai/microsoft-extensions-ai) integration via `DelegatingChatClient` (`UseAgentShield()`) |
| `AgentShield.SemanticKernel` | [Semantic Kernel](https://learn.microsoft.com/en-us/semantic-kernel/) integration via `IAutoFunctionInvocationFilter` |
| `AgentShield.AutoGen` | [AutoGen .NET](https://microsoft.github.io/autogen-for-net/) integration via `IMiddleware` |
| `AgentShield.OpenAI` | [OpenAI .NET SDK](https://github.com/openai/openai-dotnet) integration |
| `AgentShield.Anthropic` | [Anthropic.SDK](https://github.com/tghamm/Anthropic.SDK) integration |

All packages target .NET 8.0+ and require the native `agent_shield_core` library at runtime (shipped in the package's `runtimes/<RID>/native/` folder).

**.NET runtime requirement: .NET 8 SDK or newer** (`<TargetFramework>net8.0</TargetFramework>` in every shipping csproj; see [`sdk/dotnet/src/Directory.Build.props`](src/Directory.Build.props)).

## Install

### Local development install (no NuGet feed yet)

> **The `dotnet add package AgentShield` snippet below 404s today** —
> AgentShield packages are not published to NuGet.org yet
> (`AgentShield`, `AgentShield.AI`, `AgentShield.SemanticKernel`,
> `AgentShield.AutoGen`, `AgentShield.OpenAI`, `AgentShield.Anthropic`,
> `AgentShield.MCP` all return BlobNotFound from
> `api.nuget.org`). Until releases ship publicly, consume the
> projects via `<ProjectReference>` from your own csproj. This also
> works against a `git clone`d copy of this repo.

```xml
<!-- YourApp.csproj -->
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
  </PropertyGroup>

  <ItemGroup>
    <!-- Adjust the relative path to wherever you cloned AgentShield. -->
    <ProjectReference Include="../AgentShield/sdk/dotnet/src/AgentShield/AgentShield.csproj" />
    <ProjectReference Include="../AgentShield/sdk/dotnet/src/AgentShield.AI/AgentShield.AI.csproj" />
    <ProjectReference Include="../AgentShield/sdk/dotnet/src/AgentShield.SemanticKernel/AgentShield.SemanticKernel.csproj" />
    <!-- Additional adapters available under sdk/dotnet/src/, all the same shape:
         AgentShield.AutoGen / AgentShield.OpenAI / AgentShield.Anthropic / AgentShield.MCP -->
  </ItemGroup>
</Project>
```

Then build as usual:

```bash
dotnet build YourApp.csproj
```

At runtime your process still needs the native `agent_shield_core`
library on its loader path — build it via
`cargo build --release --manifest-path sdk/rust/agent_shield_core/Cargo.toml`
(see [Building from source](#building-from-source) below) and either
set `LD_LIBRARY_PATH=<repo>/sdk/rust/agent_shield_core/target/release`
(Linux) / `DYLD_LIBRARY_PATH` (macOS) / put the `.dll` next to your
app (Windows), or copy the artifact into your runtime image.

<details>
<summary><strong>When public packages ship</strong> (these commands 404 on NuGet.org today)</summary>

```bash
dotnet add package AgentShield
dotnet add package AgentShield.AI               # Microsoft.Extensions.AI
dotnet add package AgentShield.SemanticKernel   # Semantic Kernel
# … etc.
```

</details>

## Quick start

```csharp
using AgentShield;

using var shield = Shield.FromYaml(".guardrails.yaml").Build();

// Pattern C — Stage 1 + Stage 5 around an opaque agent thunk:
var answer = await shield.RunAsync("user input", async effectiveInput =>
{
    // effectiveInput is the value after Stage 1 mutations.
    return await callMyOpaqueAgentAsync(effectiveInput);
});
```

**Before shipping:** read [Post-tool limits and dangerous patterns](../../docs/POST_TOOL_LIMITS.md) — it covers what AgentShield does and does not guarantee.

## Three integration patterns

The same conceptual model — **Patterns A / B / C** — applies across all four AgentShield SDKs (Python, Node, Rust, .NET); the *implementation shape* matches each ecosystem's idiomatic middleware surface. .NET has the most sophisticated middleware story of any ecosystem, so each framework adapter uses that framework's *native* contract:

### Pattern A — Guard the agent loop (full coverage)

The integration shape depends on which .NET framework you're using:

#### Microsoft.Extensions.AI — `DelegatingChatClient` decorator chain

> ⚠️ **Builder order is SAFETY-CRITICAL.** Place `.UseAgentShield(shield)` **BEFORE** `.UseFunctionInvocation()` in the builder chain. Microsoft.Extensions.AI applies builder factories in reverse at `Build()` time, so the **first-registered** middleware becomes the **outermost** delegating client at runtime. Registering AgentShield first puts `GuardedChatClient` on the outside of `FunctionInvokingChatClient` — the only ordering where the guard sees every `AIFunction` and can install its Stage 3/Stage 4 shims before the function invoker dispatches. The reverse order is rejected at registration time with an `InvalidOperationException` (a regression-test guards the silent-bypass path the wrong order used to enable).

```csharp
using AgentShield;
using AgentShield.AI;
using Azure.AI.OpenAI;
using Microsoft.Extensions.AI;

using var shield = Shield.FromYaml(".guardrails.yaml").Build();

// Current MEAI API: GetChatClient(...).AsIChatClient() returns an
// IChatClient adapter — that's what AsBuilder() expects.
var rawClient = new AzureOpenAIClient(endpoint, credential)
    .GetChatClient(deployment)
    .AsIChatClient();

IChatClient chatClient = rawClient
    .AsBuilder()
    .UseLogging()
    .UseOpenTelemetry()
    .UseAgentShield(shield)         // ← registered FIRST → outermost at runtime
    .UseFunctionInvocation()        // ← registered AFTER → wrapped by AgentShield
    .Build();

// Current MEAI API: IChatClient.GetResponseAsync (not the deprecated
// CompleteAsync). Streaming uses GetStreamingResponseAsync.
var response = await chatClient.GetResponseAsync("user input");
```

##### DI registration (ASP .NET Core, generic hosts)

The natural-looking shape `services.AddChatClient(builder => builder.UseAgentShield(...))` **does not compile** — MEAI's `AddChatClient` lambda receives an `IServiceProvider`, not a `ChatClientBuilder`. Two working patterns:

```csharp
// Pattern 1 — fluent helper (recommended). Registers Shield as a
// singleton, applies UseAgentShield first, then runs the configure
// action so customer middleware (UseFunctionInvocation etc.) wraps
// AROUND AgentShield in registration order.
services.AddAgentShieldChatClient(
    innerFactory: sp => new AzureOpenAIClient(endpoint, credential)
        .GetChatClient(deployment)
        .AsIChatClient(),
    yamlPath: ".guardrails.yaml",
    configure: b => b.UseLogging()
                     .UseOpenTelemetry()
                     .UseFunctionInvocation());
```

```csharp
// Pattern 2 — explicit chain over the ChatClientBuilder returned by
// AddChatClient. Same outcome as Pattern 1, useful when the Shield is
// already constructed in host start-up. Note the safety-critical
// ordering: UseAgentShield is registered BEFORE UseFunctionInvocation.
var shield = Shield.FromYaml(".guardrails.yaml").Build();
services.AddSingleton<Shield>(shield);
services
    .AddChatClient(sp => rawClient)
    .UseAgentShield(shield)
    .UseFunctionInvocation();
```

> The DI helper `AddAgentShieldChatClient` lives in `AgentShield.AI.ServiceCollectionExtensions`. It resolves the Shield from DI on each chat-client construction, so the same Shield (and therefore the same `GuardrailsSession`) is shared across the host's lifetime — matching the inline `Shield.FromYaml(...)` shape.

#### Semantic Kernel — `IAutoFunctionInvocationFilter`

The builder-time shape mirrors the rest of SK's middleware (`AddOpenAIChatCompletion`,
`Plugins.AddFromObject`, …) — chain `.UseAgentShield(...)` onto the
kernel builder before `Build()` and the auto-function-invocation
filter is wired automatically:

```csharp
using AgentShield;
using AgentShield.SemanticKernel;
using Microsoft.SemanticKernel;

var kernel = Kernel.CreateBuilder()
    .AddOpenAIChatCompletion(...)
    .UseAgentShield(".guardrails.yaml")   // ← Stage 2/3/4 on every tool call
    .Build();

// Stage 1 + Stage 5 still come from the orchestrator. Resolve the
// Shield from the kernel's services and bracket the call with RunAsync:
var shield = kernel.Services.GetRequiredService<Shield>();
var result = await shield.RunAsync(
    "user input",
    async _ => (await kernel.InvokePromptAsync("user input")).ToString());
```

DI-first hosts (ASP.NET Core, generic hosts) can register the filter
straight into the service collection — SK picks it up when the kernel
is resolved:

```csharp
services.AddAgentShieldFilter(".guardrails.yaml");
services.AddKernel().AddOpenAIChatCompletion(...);
```

If you've already built the Shield elsewhere, pass it through:

```csharp
using var shield = Shield.FromYaml(".guardrails.yaml").Build();

var kernel = Kernel.CreateBuilder()
    .AddOpenAIChatCompletion(...)
    .UseAgentShield(shield)
    .Build();
```

The post-build helper — useful when the kernel is constructed by a
later phase of host start-up — is still available and idempotent:

```csharp
using var shield = Shield.FromYaml(".guardrails.yaml")
    .WithSemanticKernel(kernel)
    .Build();
// or, when the kernel comes later:
shield.AttachFilter(kernel);
```

> **Coverage asymmetry.** The kernel filter sees Stage 2/3/4 only.
> Stage 1 + Stage 5 live around the LLM boundary which the filter does
> not observe — wrap the call in `shield.RunAsync(...)` to close that
> gap. (Hosts that also configure the chat client via
> `Microsoft.Extensions.AI` can additionally chain the
> `ChatClientBuilder.UseAgentShield(shield)` middleware for Stage 1/5
> at the chat-client boundary.)

> **Tool name matching.** The filter matches policies on the **bare
> function name** (e.g. `OpenJiraTicket`), even when the function is
> imported as part of a plugin (e.g.
> `builder.Plugins.AddFromObject(new SupportPlugin(), "SupportPlugin")`).
> This matches the convention used by `agent-shield init`-generated
> YAML and by every other AgentShield SDK; the plugin prefix is
> stripped before the policy lookup.

#### AutoGen .NET — `IMiddleware`

```csharp
using AgentShield;
using AgentShield.AutoGen;
using AutoGen.Core;

using var shield = Shield.FromYaml(".guardrails.yaml").Build();

var agent = new MyAgent(...)
    .RegisterMiddleware(new AgentShieldMiddleware(shield));   // ← guards every reply

var reply = await agent.GenerateReplyAsync(messages);
```

### Pattern B — Protect individual tools

For frameworks where you want only the tool boundary guarded:

```csharp
using var shield = Shield.FromYaml(".guardrails.yaml").Build();

var protectedTools = await shield.ProtectAnthropicToolsAsync(myTools);
// ... pass protectedTools to your Anthropic client
```

### Pattern C — Stage 1 + 5 boundary (opaque loops)

For black-box agent loops you don't control:

```csharp
using var shield = Shield.FromYaml(".guardrails.yaml").Build();

try
{
    var result = await shield.RunAsync("user input", async effectiveInput =>
    {
        // your model call + custom loop here
        return await runMyOpaqueAgentAsync(effectiveInput);
    });
}
catch (AgentShieldBlockedException ex)
{
    // Stage 1 or Stage 5 denied the turn. ex.Message is the canonical
    // [GUARDRAIL ...] block string; ex.Verdict is the raw StageVerdict.
    return RenderBlockedTurn(ex);
}
```

> **`Shield.RunAsync` throws `AgentShieldBlockedException` by default.** Previously a Stage 1/5 block silently returned the block-message string for `RunAsync<string>` (and threw for non-`string` `TResult`), which is too easy for host code to mishandle (a silent-bypass class already closed for tool wrappers). The default flipped to `OnBlockPolicy.Raise`. To opt back into the legacy string-return form, pass `onBlock: OnBlockPolicy.ReturnBlocked` to the overload that accepts it (see [Pattern C surface change](#pattern-c-surface-change) below).

#### Streaming safety

> **⚠️ DANGER — hand-rolled streaming wrappers around `Shield.RunAsync` / `Shield.RunStreamedAsync` are unsafe by construction.**
>
> Stage 5 redaction requires the *full output context* to compute redaction spans. **Per-chunk Stage 5 cannot work** — you cannot know whether a substring is sensitive until you have seen enough surrounding text. **Per-stream-finalize Stage 5 emits raw chunks to the client *before* redaction runs** — the leak has already shipped over the wire by the time the final pass returns.
>
> Only an adapter that owns chunk emission (so it can buffer, validate, and *then* emit the safe-to-emit slice) can stream safely.
>
> **Safe options when a streaming adapter does not exist for your framework:**
>
> 1. Disable streaming and use the buffer-mode response.
> 2. Use the [LiteLLM Proxy plugin](../../docs/integrations/litellm-proxy.md), which enforces Stage 5 in buffer-mode at the gateway.
> 3. Implement a sentinel-only stream and reveal the validated output after Stage 5 returns.
>
> **Streaming-adapter inventory (.NET):**
>
> | Framework | Streaming surface | Status |
> |---|---|---|
> | Microsoft.Extensions.AI | `GuardedChatClient.GetStreamingResponseAsync` | ✅ Partial — Stage-5 chat streaming only |
> | Semantic Kernel | shared `StreamingGuard` (emits on policy stop) | ✅ Partial — auto-function streaming |
> | Anthropic (`AgentShield.Anthropic`) | helper-owned Anthropic loop | ✅ Partial — text blocks only |
> | AutoGen | not supported | ❌ Disable streaming |
> | Custom / opaque loops | none | ❌ Not safe — pick one of the 3 safe options above |
>
> See [`docs/adapter-mediated-paths.md`](../../docs/adapter-mediated-paths.md) for the cross-SDK matrix and [`docs/runbooks/incident-streaming-leak.md`](../../docs/runbooks/incident-streaming-leak.md) for incident response.

#### Pattern C surface change

`Shield.RunAsync` accepts an `onBlock` override:

```csharp
// Default (recommended): a Stage 1/5 block throws AgentShieldBlockedException.
var answer = await shield.RunAsync("user input", async _ => await callOpaqueAgentAsync());

// Opt back into the legacy string-return form.
var result = await shield.RunAsync<string>(
    "user input",
    async _ => await callOpaqueAgentAsync(),
    onBlock: OnBlockPolicy.ReturnBlocked);
if (result.StartsWith("[GUARDRAIL")) RenderBlockedTurn(result);
```

Per the project doctrine ("Don't ship safety as opt-in"), the default is the fail-closed-raise form; the legacy form is available only when explicitly requested. This mirrors the same flip applied at the tool-wrapper layer for Pattern A/B.

## Pinning Microsoft.Extensions.AI versions

`AgentShield.AI` declares a **floor** of `Microsoft.Extensions.AI` (and
`Microsoft.Extensions.AI.Abstractions`) at **9.10.2** with no upper
bound. The painful failure mode is cross-major *mixing* inside a single
app — e.g. AgentShield.AI built against 9.10.x while a sibling library
(`Microsoft.SemanticKernel`, `Microsoft.Extensions.AI.OpenAI`, …)
transitively requires 10.x. The canonical symptom is
`System.MissingMethodException: get_ContinuationToken` thrown when the
runtime resolves to 9.10.x but the IL was compiled against the 10.x
`ChatOptions` surface (or vice versa).

The floor-only constraint lets NuGet **unify the whole graph upward**:
if anything in your app requires 10.x, the whole solution lands on
10.x and AgentShield.AI runs against that single, consistent version.
The 9.10.2 surface AgentShield.AI compiles against is forward-
compatible with the 10.x runtime, so upward unification is safe.

If you want a stricter, reproducible pin (locked runtime version),
drop the canonical version into a `Directory.Packages.props` (Central
Package Management) entry so every project in the solution agrees:

```xml
<!-- Directory.Packages.props -->
<Project>
  <PropertyGroup>
    <ManagePackageVersionsCentrally>true</ManagePackageVersionsCentrally>
  </PropertyGroup>

  <ItemGroup>
    <PackageVersion Include="Microsoft.Extensions.AI"               Version="10.3.0" />
    <PackageVersion Include="Microsoft.Extensions.AI.Abstractions"  Version="10.3.0" />
    <PackageVersion Include="Microsoft.Extensions.AI.OpenAI"        Version="10.3.0" />
  </ItemGroup>
</Project>
```

If you instead want to *force* the 9.10.x line (no transitive bump
into 10.x), pin the version with a range constraint in
`Directory.Packages.props`:

```xml
<PackageVersion Include="Microsoft.Extensions.AI"
                Version="[9.10.2,10.0.0)" />
```

…but be aware this can fail to restore (`NU1107`) if another package
in your solution requires MEAI 10.x — you'll have to choose one major.

## YAML auto-wiring

YAML configurations drive everything; no host code needed for the common case:

- **Runtime-bound `kind: human` handlers** — register the active handler in host code (for example `RegisterHumanResolver(...)` / `WithHumanResolver(...)`); YAML no longer names providers.
- **LLM clients** — `configurations: - {id, type: llm, provider, model, api_key_env}` auto-wire HTTP-based callers.
- **Classifiers** — `configurations: - {id, type: classifier, provider: ...}` auto-wire HTTP-based callers.

```yaml
# .guardrails.yaml
configurations:
  - id: "gpt4o"
    type: llm
    provider: openai
    model: gpt-4o
    api_key_env: OPENAI_API_KEY

tool_execution_validation:
  configuration: "gpt4o"
  prompts:
    task_adherence: "Is this tool call consistent with the user's request?"
```

`Shield.FromYaml` reads `configurations` and auto-resolves `OPENAI_API_KEY` from the environment — no manual wiring required.

## Observability

`AgentShield` ships the `IObservabilityProvider` interface (single
method, `void OnLogEvent(JsonElement eventJson)`) and otherwise stays
out of your way — it does not ship pre-baked OTel / CloudWatch / Azure
Monitor providers. Forward events to your telemetry pipeline with a
short adapter:

```csharp
using System.Text.Json;
using AgentShield;

public sealed class ConsoleObservability : IObservabilityProvider
{
    public void OnLogEvent(JsonElement eventJson) =>
        Console.WriteLine(eventJson.GetRawText());
}

using var shield = Shield.FromYaml(".guardrails.yaml")
    .WithObservability(new ConsoleObservability())
    .Build();
```

Every emitted event carries [OpenTelemetry GenAI semantic-convention](https://opentelemetry.io/docs/specs/semconv/gen-ai/) attributes (`gen_ai.system="agent_shield"`, `gen_ai.operation.name="guard.<stage>"`, `gen_ai.response.finish_reason="content_filter"` on blocks), so an `IObservabilityProvider` that forwards the JSON straight to an OTel exporter sees AgentShield events with the same shape as other GenAI telemetry.

## Lower-level API

For framework-agnostic code, drop down to `GuardrailsRuntime` directly:

```csharp
using AgentShield;

using var runtime = GuardrailsRuntime.FromYaml(".guardrails.yaml");

var input = runtime.NewSession().ValidateInput("user prompt");
if (!input.Allowed) throw new InvalidOperationException(input.Reason);
```

## Building from source

```bash
# Build the native engine
cargo build --release --manifest-path sdk/rust/agent_shield_core/Cargo.toml

# Build + test the .NET projects
dotnet build sdk/dotnet/tests/AgentShield.Tests/AgentShield.Tests.csproj
LD_LIBRARY_PATH=sdk/rust/agent_shield_core/target/release \
  dotnet test sdk/dotnet/tests/AgentShield.Tests/AgentShield.Tests.csproj
```

## More

- [Specification](https://github.com/microsoft/AgentShield/blob/main/spec/SPECIFICATION.md) — the source of truth for `.guardrails.yaml` semantics.
- [Expression-language reference](https://github.com/microsoft/AgentShield/blob/main/spec/expressions/LANGUAGE.md).
- [Examples](https://github.com/microsoft/AgentShield/tree/main/examples) — bank-manager, sensitive-documents, IFC, ask-human MCP server.
