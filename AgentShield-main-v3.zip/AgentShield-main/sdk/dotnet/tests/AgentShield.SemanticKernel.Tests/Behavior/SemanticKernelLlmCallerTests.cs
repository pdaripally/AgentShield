using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Threading.Tasks;
using System.Threading;
using System;
using AgentShield;
using Microsoft.SemanticKernel.ChatCompletion;
using Microsoft.SemanticKernel;
using Xunit;

namespace AgentShield.SemanticKernel.Tests;

public class SKLlmCallerTests
{

    [Fact]
    public void Caller_UsesYamlModel_ForEachConfigurationId()
    {
        using var rt = GuardrailsRuntime.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"));

        var recorder = new RecordingChatCompletionService(JsonAllow());
        var caller = new SKLlmCaller(recorder);
        caller.Bind(rt);

        var ctx = JsonDocument.Parse("{}").RootElement;
        caller.Call(new LlmRequest("stage1-judge", "is the input safe?", "", ctx));
        caller.Call(new LlmRequest("stage3-judge", "is the tool call safe?", "", ctx));

        Assert.Equal(2, recorder.Calls.Count);
        Assert.Equal("gpt-4o", recorder.Calls[0].ModelId);
        Assert.True(recorder.Calls[0].ExtensionData != null &&
            recorder.Calls[0].ExtensionData!.ContainsKey("max_tokens"));
        Assert.Equal(256, Convert.ToInt32(recorder.Calls[0].ExtensionData!["max_tokens"]));
        Assert.Equal("gpt-4o-mini-with-context", recorder.Calls[1].ModelId);
        Assert.True(recorder.Calls[1].ExtensionData == null ||
            !recorder.Calls[1].ExtensionData!.ContainsKey("max_tokens"));
    }

    [Fact]
    public void Caller_UsesYamlModel_ForAzureProvider()
    {
        using var rt = GuardrailsRuntime.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"));

        var recorder = new RecordingChatCompletionService(JsonAllow());
        var caller = new SKLlmCaller(recorder);
        caller.Bind(rt);

        caller.Call(new LlmRequest("azure-judge", "judge", "", JsonDocument.Parse("{}").RootElement));

        Assert.Single(recorder.Calls);
        Assert.Equal("my-azure-deployment", recorder.Calls[0].ModelId);
    }

    [Fact]
    public void Caller_RaisesConfigurationMissingModelError_WhenNoMatchingConfiguration()
    {
        using var rt = GuardrailsRuntime.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"));

        var recorder = new RecordingChatCompletionService(JsonAllow());
        var caller = new SKLlmCaller(recorder);
        caller.Bind(rt);

        var ctx = JsonDocument.Parse("{}").RootElement;
        var ex1 = Assert.Throws<ConfigurationMissingModelException>(() =>
            caller.Call(new LlmRequest(null, "judge", "", ctx)));
        Assert.Null(ex1.ConfigurationId);

        var ex2 = Assert.Throws<ConfigurationMissingModelException>(() =>
            caller.Call(new LlmRequest("not-in-yaml", "judge", "", ctx)));
        Assert.Equal("not-in-yaml", ex2.ConfigurationId);

        Assert.Empty(recorder.Calls);
    }

    [Fact]
    public void Caller_ParsesJsonBlockVerdict()
    {
        using var rt = GuardrailsRuntime.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"));

        var recorder = new RecordingChatCompletionService(JsonBlock("policy violation"));
        var caller = new SKLlmCaller(recorder);
        caller.Bind(rt);

        var resp = caller.Call(new LlmRequest("stage1-judge", "input?", "",
            JsonDocument.Parse("{}").RootElement));

        Assert.Equal("block", resp.Decision);
        Assert.Equal("policy violation", resp.Reason);
    }

    [Fact]
    public void Stage1_RoutesThroughConfiguredJudgeModel()
    {
        var recorder = new RecordingChatCompletionService(JsonAllow());
        using var shield = Shield.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"))
            .WithSKLlmJudge(recorder)
            .Build();

        var verdict = shield.Session.ValidateInput("hello");

        Assert.True(verdict.Allowed);
        Assert.Single(recorder.Calls);
        Assert.Equal("gpt-4o", recorder.Calls[0].ModelId);
        Assert.NotNull(recorder.Calls[0].ExtensionData);
        Assert.Equal(256, Convert.ToInt32(recorder.Calls[0].ExtensionData!["max_tokens"]));
    }

    [Fact]
    public void Stage3_RoutesThroughConfiguredJudgeModel()
    {
        var recorder = new RecordingChatCompletionService(JsonAllow());
        using var shield = Shield.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"))
            .WithSKLlmJudge(recorder)
            .Build();

        var args = JsonDocument.Parse("{\"x\":1}").RootElement;
        var (verdict, _) = shield.Session.ValidateToolCall("safe_tool", args, "call_1");

        Assert.True(verdict.Allowed);
        Assert.Contains(recorder.Calls, c => c.ModelId == "gpt-4o-mini-with-context");
    }

    [Fact]
    public void WithSKLlmJudge_NullArgs_Throws()
    {
        using var rt = GuardrailsRuntime.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"));
        var builder = Shield.FromRuntime(rt);
        Assert.Throws<ArgumentNullException>(() => ((ShieldBuilder?)null)!.WithSKLlmJudge(
            new RecordingChatCompletionService(JsonAllow())));
        Assert.Throws<ArgumentNullException>(() => builder.WithSKLlmJudge(null!));
    }

    private static string JsonAllow() => "{\"decision\":\"allow\",\"confidence\":1.0}";

    private static string JsonBlock(string reason)
        => $"{{\"decision\":\"block\",\"confidence\":1.0,\"reason\":\"{reason}\"}}";

    private static string FindFixture(string name)
    {
        var dir = AppContext.BaseDirectory;
        while (dir != null)
        {
            var candidate = Path.Combine(dir, "tests", "fixtures", name);
            if (File.Exists(candidate)) return candidate;
            if (File.Exists(Path.Combine(dir, "AgentShield.sln")))
            {
                var path = Path.Combine(dir, "tests", "fixtures", name);
                if (File.Exists(path)) return path;
            }
            dir = Directory.GetParent(dir)?.FullName;
        }
        throw new FileNotFoundException($"Test fixture not found: {name}");
    }

    private sealed class RecordingChatCompletionService : IChatCompletionService
    {
        private readonly string _response;
        public List<RecordedCall> Calls { get; } = new();

        public RecordingChatCompletionService(string response)
        {
            _response = response;
        }

        public IReadOnlyDictionary<string, object?> Attributes { get; } =
            new Dictionary<string, object?>();

        public Task<IReadOnlyList<ChatMessageContent>> GetChatMessageContentsAsync(
            ChatHistory chatHistory,
            PromptExecutionSettings? executionSettings = null,
            Kernel? kernel = null,
            CancellationToken cancellationToken = default)
        {
            Calls.Add(new RecordedCall(
                Settings: executionSettings,
                ModelId: executionSettings?.ModelId,
                ExtensionData: executionSettings?.ExtensionData));
            IReadOnlyList<ChatMessageContent> result = new[]
            {
                new ChatMessageContent(AuthorRole.Assistant, _response),
            };
            return Task.FromResult(result);
        }

        public async IAsyncEnumerable<StreamingChatMessageContent> GetStreamingChatMessageContentsAsync(
            ChatHistory chatHistory,
            PromptExecutionSettings? executionSettings = null,
            Kernel? kernel = null,
            [EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            Calls.Add(new RecordedCall(
                Settings: executionSettings,
                ModelId: executionSettings?.ModelId,
                ExtensionData: executionSettings?.ExtensionData));
            yield return new StreamingChatMessageContent(AuthorRole.Assistant, _response);
            await Task.CompletedTask;
        }
    }

    private sealed record RecordedCall(
        PromptExecutionSettings? Settings,
        string? ModelId,
        IDictionary<string, object>? ExtensionData);
}
