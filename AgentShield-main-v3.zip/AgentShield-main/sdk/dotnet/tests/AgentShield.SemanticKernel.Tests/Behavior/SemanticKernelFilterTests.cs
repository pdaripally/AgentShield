using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Threading.Tasks;
using System.Threading;
using System;
using AgentShield.AI;
using AgentShield;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.SemanticKernel.ChatCompletion;
using Microsoft.SemanticKernel;
using Xunit;
using static AgentShield.Tests.Support.JsonTest;

namespace AgentShield.SemanticKernel.Tests;

public class AgentShieldFilterTests : IDisposable
{
    private readonly GuardrailsRuntime _runtime;

    public AgentShieldFilterTests()
    {
        _runtime = GuardrailsRuntime.FromYaml(MinimalFixture);
    }

    public void Dispose() => _runtime.Dispose();

    private static string SmokeFixturesDir
    {
        get
        {
            var dir = AppContext.BaseDirectory;
            while (dir != null && !Directory.Exists(Path.Combine(dir, "tests", "fixtures", "smoke")))
            {
                dir = Directory.GetParent(dir)?.FullName;
            }
            if (dir == null)
                throw new DirectoryNotFoundException("Could not locate tests/fixtures/smoke");
            return Path.Combine(dir, "tests", "fixtures", "smoke");
        }
    }

    private static string MinimalFixture =>
        Path.Combine(SmokeFixturesDir, "minimal.guardrails.yaml");

    private static AutoFunctionInvocationContext CreateContext(
        KernelFunction function,
        KernelArguments? arguments = null)
    {
        var kernel = Kernel.CreateBuilder().Build();
        var result = new FunctionResult(function, "initial");
        var chatHistory = new ChatHistory();
        var msg = new ChatMessageContent(AuthorRole.Assistant, "test");
        return new AutoFunctionInvocationContext(kernel, function, result, chatHistory, msg)
        {
            Arguments = arguments ?? new KernelArguments(),
        };
    }

    [Fact]
    public void Filter_NullRuntime_Throws()
    {
        Assert.Throws<ArgumentNullException>(() => new AgentShieldFilter((GuardrailsRuntime)null!));
    }

    [Fact]
    public void Filter_NullShield_Throws()
    {
        Assert.Throws<ArgumentNullException>(() => new AgentShieldFilter((Shield)null!));
    }

    [Fact]
    public void Filter_Constructs_AndImplementsInterface()
    {
        var filter = new AgentShieldFilter(_runtime);
        Assert.IsAssignableFrom<IAutoFunctionInvocationFilter>(filter);
    }

    [Fact]
    public void Filter_CurrentSession_RoundTrips()
    {
        var filter = new AgentShieldFilter(_runtime);
        Assert.Null(filter.CurrentSession);

        using var session = _runtime.NewSession();
        filter.CurrentSession = session;
        Assert.Same(session, filter.CurrentSession);

        filter.CurrentSession = null;
        Assert.Null(filter.CurrentSession);
    }

    [Fact]
    public async Task BlockedToolCall_SetsResultAndTerminates()
    {
        var filter = new AgentShieldFilter(_runtime);
        var function = KernelFunctionFactory.CreateFromMethod(() => "result", "echo");
        var context = CreateContext(function);

        var nextCalled = false;
        await filter.OnAutoFunctionInvocationAsync(context, _ =>
        {
            nextCalled = true;
            return Task.CompletedTask;
        });

        Assert.False(nextCalled, "next() must not be called when the tool is blocked");
        Assert.True(context.Terminate, "filter must terminate the invocation chain on block");
        Assert.Contains("[Blocked by Agent Shield]", context.Result?.ToString());
    }

    [Fact]
    public async Task Stage4_PostToolBlock_TerminatesInvocationChain()
    {
        var stage4Fixture = FindFixture("sk-stage4-block.guardrails.yaml");
        using var stage4Runtime = GuardrailsRuntime.FromYaml(stage4Fixture);
        var filter = new AgentShieldFilter(stage4Runtime);

        var function = KernelFunctionFactory.CreateFromMethod(
            () => "result-with-deny-me-marker",
            "lookup");
        var context = CreateContext(function);

        var nextCalled = false;
        await filter.OnAutoFunctionInvocationAsync(context, ctx =>
        {
            nextCalled = true;
            ctx.Result = new FunctionResult(ctx.Function, "result-with-deny-me-marker");
            return Task.CompletedTask;
        });

        Assert.True(nextCalled, "Stage 4 runs only after the tool has executed");
        Assert.True(
            context.Terminate,
            "Stage 4 deny MUST set context.Terminate=true to halt the SK auto-invocation loop");
        var rendered = context.Result?.ToString() ?? "";
        Assert.StartsWith("[Blocked by Agent Shield]", rendered);
        Assert.Contains("Stage 4 deny marker", rendered);
        Assert.DoesNotContain("result-with-deny-me-marker", rendered);
    }

    private static string FindFixture(string name)
    {
        var dir = AppContext.BaseDirectory;
        while (dir != null && !File.Exists(Path.Combine(dir, "tests", "fixtures", name)))
            dir = Directory.GetParent(dir)?.FullName;
        if (dir == null)
            throw new FileNotFoundException($"Fixture not found: {name}");
        return Path.Combine(dir, "tests", "fixtures", name);
    }

    [Fact]
    public async Task AllowedToolCall_PassesThroughToNext()
    {
        var filter = new AgentShieldFilter(_runtime);
        using var session = _runtime.NewSession();
        session.SetVariable("authorized", Parse("true"));
        filter.CurrentSession = session;

        var function = KernelFunctionFactory.CreateFromMethod(() => "result", "echo");
        var context = CreateContext(function);

        var nextCalled = false;
        await filter.OnAutoFunctionInvocationAsync(context, ctx =>
        {
            nextCalled = true;
            ctx.Result = new FunctionResult(ctx.Function, "echoed-payload");
            return Task.CompletedTask;
        });

        Assert.True(nextCalled, "next() must run for allowed tools");
        Assert.False(context.Terminate, "context.Terminate stays false on the happy path");
        var rendered = context.Result?.ToString() ?? "";
        Assert.Contains("echoed-payload", rendered);
    }

    [Fact]
    public async Task ToolCallWithArguments_PassesParametersThrough()
    {
        var filter = new AgentShieldFilter(_runtime);
        using var session = _runtime.NewSession();
        session.SetVariable("authorized", Parse("true"));
        filter.CurrentSession = session;

        var function = KernelFunctionFactory.CreateFromMethod(() => "ok", "echo");
        var args = new KernelArguments { { "msg", "hi" }, { "n", 7 } };
        var context = CreateContext(function, args);

        var nextCalled = false;
        await filter.OnAutoFunctionInvocationAsync(context, ctx =>
        {
            nextCalled = true;
            ctx.Result = new FunctionResult(ctx.Function, "ok");
            return Task.CompletedTask;
        });

        Assert.True(nextCalled, "echo is allowed once `authorized == true`");
    }

    [Fact]
    public async Task UnknownTool_AllowedByCatchAllAbsence()
    {
        var filter = new AgentShieldFilter(_runtime);

        var function = KernelFunctionFactory.CreateFromMethod(() => "x", "unlisted_tool");
        var context = CreateContext(function);

        var nextCalled = false;
        await filter.OnAutoFunctionInvocationAsync(context, ctx =>
        {
            nextCalled = true;
            ctx.Result = new FunctionResult(ctx.Function, "x");
            return Task.CompletedTask;
        });

        Assert.True(nextCalled);
        Assert.False(context.Terminate);
    }

    [Fact]
    public async Task BlockedMessage_UsesCanonicalPrefix()
    {
        var filter = new AgentShieldFilter(_runtime);
        var function = KernelFunctionFactory.CreateFromMethod(() => "x", "echo");
        var context = CreateContext(function);

        await filter.OnAutoFunctionInvocationAsync(context, _ => Task.CompletedTask);

        var rendered = context.Result?.ToString() ?? "";
        Assert.StartsWith("[Blocked by Agent Shield]", rendered);
    }

    [Fact]
    public async Task FilterDisposesOwnedSession_DoesNotDisposeBorrowed()
    {
        var filter = new AgentShieldFilter(_runtime);
        using var session = _runtime.NewSession();
        session.SetVariable("authorized", Parse("true"));
        filter.CurrentSession = session;

        var function = KernelFunctionFactory.CreateFromMethod(() => "ok", "echo");
        var context = CreateContext(function);

        await filter.OnAutoFunctionInvocationAsync(context, ctx =>
        {
            ctx.Result = new FunctionResult(ctx.Function, "ok");
            return Task.CompletedTask;
        });

        var status = session.ReadVariable("authorized");
        Assert.NotNull(status);
        Assert.Equal(VariableStatus.Resolved, status!.Status);
    }

    [Fact]
    public async Task PluginQualifiedTool_BlockedByBareNamePolicy()
    {
        var filter = new AgentShieldFilter(_runtime);
        var bareFunction = KernelFunctionFactory.CreateFromMethod(() => "result", "echo");
        var plugin = KernelPluginFactory.CreateFromFunctions("SupportPlugin", new[] { bareFunction });
        var qualifiedFunction = plugin["echo"];
        Assert.Equal("SupportPlugin", qualifiedFunction.PluginName);
        Assert.Equal("echo", qualifiedFunction.Name);

        var context = CreateContext(qualifiedFunction);

        var nextCalled = false;
        await filter.OnAutoFunctionInvocationAsync(context, _ =>
        {
            nextCalled = true;
            return Task.CompletedTask;
        });

        Assert.False(nextCalled,
            "BARE-NAME policy MUST block plugin-qualified tool calls. " +
            "Without this guard, customers who import functions via " +
            "Plugins.AddFromObject silently bypass every policy in " +
            "their .guardrails.yaml (audit behavior).");
        Assert.True(context.Terminate);
        Assert.Contains("[Blocked by Agent Shield]", context.Result?.ToString());
    }

    [Fact]
    public async Task BareNameTool_StillBlockedByBareNamePolicy()
    {
        var filter = new AgentShieldFilter(_runtime);
        var function = KernelFunctionFactory.CreateFromMethod(() => "result", "echo");
        Assert.True(string.IsNullOrEmpty(function.PluginName),
            "Sanity: CreateFromMethod without a plugin leaves PluginName empty.");
        var context = CreateContext(function);

        var nextCalled = false;
        await filter.OnAutoFunctionInvocationAsync(context, _ =>
        {
            nextCalled = true;
            return Task.CompletedTask;
        });

        Assert.False(nextCalled);
        Assert.True(context.Terminate);
    }

    [Fact]
    public async Task TwoPluginsSameFunctionName_BothBlockedByBareNamePolicy()
    {
        var filter = new AgentShieldFilter(_runtime);
        var aBare = KernelFunctionFactory.CreateFromMethod(() => "from-a", "echo");
        var bBare = KernelFunctionFactory.CreateFromMethod(() => "from-b", "echo");
        var pluginA = KernelPluginFactory.CreateFromFunctions("PluginA", new[] { aBare });
        var pluginB = KernelPluginFactory.CreateFromFunctions("PluginB", new[] { bBare });

        foreach (var qualified in new[] { pluginA["echo"], pluginB["echo"] })
        {
            var context = CreateContext(qualified);
            var nextCalled = false;
            await filter.OnAutoFunctionInvocationAsync(context, _ =>
            {
                nextCalled = true;
                return Task.CompletedTask;
            });

            Assert.False(nextCalled,
                $"plugin '{qualified.PluginName}'.echo must be blocked by the bare-name 'echo' policy");
            Assert.True(context.Terminate);
        }
    }
}

public class UseAgentShieldChatDecorationTests
{

    private static string SmokeFixturesDir
    {
        get
        {
            var dir = AppContext.BaseDirectory;
            while (dir != null && !Directory.Exists(Path.Combine(dir, "tests", "fixtures", "smoke")))
            {
                dir = Directory.GetParent(dir)?.FullName;
            }
            if (dir == null)
                throw new DirectoryNotFoundException("Could not locate tests/fixtures/smoke");
            return Path.Combine(dir, "tests", "fixtures", "smoke");
        }
    }

    private static string InputBlockFixture =>
        Path.Combine(SmokeFixturesDir, "input-block.guardrails.yaml");

    private static string RedactFixture =>
        Path.Combine(SmokeFixturesDir, "redact.guardrails.yaml");

    private static string MinimalFixture =>
        Path.Combine(SmokeFixturesDir, "minimal.guardrails.yaml");

    private sealed class RecordingChatClient : IChatClient
    {
        public List<List<ChatMessage>> Calls { get; } = new();
        private readonly string _responseText;

        public RecordingChatClient(string responseText)
        {
            _responseText = responseText;
        }

        public Task<ChatResponse> GetResponseAsync(
            IEnumerable<ChatMessage> messages,
            ChatOptions? options = null,
            CancellationToken cancellationToken = default)
        {
            Calls.Add(messages.ToList());
            return Task.FromResult(new ChatResponse(
                new ChatMessage(ChatRole.Assistant, _responseText)));
        }

        public async IAsyncEnumerable<ChatResponseUpdate> GetStreamingResponseAsync(
            IEnumerable<ChatMessage> messages,
            ChatOptions? options = null,
            [EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            Calls.Add(messages.ToList());
            await Task.CompletedTask.ConfigureAwait(false);
            yield return new ChatResponseUpdate
            {
                Role = ChatRole.Assistant,
                Contents = new[] { (AIContent)new Microsoft.Extensions.AI.TextContent(_responseText) },
            };
        }

        public object? GetService(Type serviceType, object? serviceKey = null) => null;
        public void Dispose() { }
    }

    private sealed class RecordingChatCompletionService : IChatCompletionService
    {
        public List<ChatHistory> Calls { get; } = new();
        private readonly string _responseText;

        public RecordingChatCompletionService(string responseText)
        {
            _responseText = responseText;
        }

        public IReadOnlyDictionary<string, object?> Attributes { get; } =
            new Dictionary<string, object?>();

        public Task<IReadOnlyList<ChatMessageContent>> GetChatMessageContentsAsync(
            ChatHistory chatHistory,
            PromptExecutionSettings? executionSettings = null,
            Kernel? kernel = null,
            CancellationToken cancellationToken = default)
        {
            Calls.Add(chatHistory);
            IReadOnlyList<ChatMessageContent> result = new[]
            {
                new ChatMessageContent(AuthorRole.Assistant, _responseText),
            };
            return Task.FromResult(result);
        }

        public async IAsyncEnumerable<StreamingChatMessageContent> GetStreamingChatMessageContentsAsync(
            ChatHistory chatHistory,
            PromptExecutionSettings? executionSettings = null,
            Kernel? kernel = null,
            [EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            Calls.Add(chatHistory);
            await Task.CompletedTask.ConfigureAwait(false);
            yield return new StreamingChatMessageContent(AuthorRole.Assistant, _responseText);
        }
    }

    [Fact]
    public void UseAgentShield_DecoratesIChatClient_WithGuardedChatClient()
    {
        var builder = Kernel.CreateBuilder();
        var inner = new RecordingChatClient("hi");
        builder.Services.AddSingleton<IChatClient>(inner);
        builder.UseAgentShield(MinimalFixture);

        var kernel = builder.Build();
        var resolved = kernel.Services.GetRequiredService<IChatClient>();

        Assert.IsType<GuardedChatClient>(resolved);
        Assert.NotSame(inner, resolved);
    }

    [Fact]
    public async Task UseAgentShield_ChatClient_Stage1BlocksMaliciousInput()
    {
        var builder = Kernel.CreateBuilder();
        var inner = new RecordingChatClient("OK");
        builder.Services.AddSingleton<IChatClient>(inner);
        builder.UseAgentShield(InputBlockFixture);

        var kernel = builder.Build();
        var guarded = kernel.Services.GetRequiredService<IChatClient>();

        var response = await guarded.GetResponseAsync(new[]
        {
            new ChatMessage(ChatRole.User, "please DENY_ME now"),
        });

        Assert.Empty(inner.Calls);
        Assert.Contains("[Blocked by Agent Shield]", response.Text);
    }

    [Fact]
    public async Task UseAgentShield_ChatClient_Stage5RedactsResponse()
    {
        var builder = Kernel.CreateBuilder();
        var inner = new RecordingChatClient("the token is SECRET-ABC1234");
        builder.Services.AddSingleton<IChatClient>(inner);
        builder.UseAgentShield(RedactFixture);

        var kernel = builder.Build();
        var guarded = kernel.Services.GetRequiredService<IChatClient>();

        var response = await guarded.GetResponseAsync(new[]
        {
            new ChatMessage(ChatRole.User, "what is the token?"),
        });

        Assert.Single(inner.Calls);
        Assert.DoesNotContain("SECRET-ABC1234", response.Text);
    }

    [Fact]
    public async Task UseAgentShield_ChatClient_CleanInputAndOutput_PassesThrough()
    {
        var builder = Kernel.CreateBuilder();
        var inner = new RecordingChatClient("hello back");
        builder.Services.AddSingleton<IChatClient>(inner);
        builder.UseAgentShield(MinimalFixture);

        var kernel = builder.Build();
        var guarded = kernel.Services.GetRequiredService<IChatClient>();

        var response = await guarded.GetResponseAsync(new[]
        {
            new ChatMessage(ChatRole.User, "hi"),
        });

        Assert.Single(inner.Calls);
        Assert.Equal("hello back", response.Text);
    }

    [Fact]
    public void UseAgentShield_DecoratesIChatCompletionService_WithGuardedWrapper()
    {
        var builder = Kernel.CreateBuilder();
        var inner = new RecordingChatCompletionService("hi");
        builder.Services.AddSingleton<IChatCompletionService>(inner);
        builder.UseAgentShield(MinimalFixture);

        var kernel = builder.Build();
        var resolved = kernel.Services.GetRequiredService<IChatCompletionService>();

        Assert.IsType<GuardedChatCompletionService>(resolved);
        Assert.NotSame(inner, resolved);
    }

    [Fact]
    public async Task UseAgentShield_ChatCompletion_Stage1BlocksMaliciousInput()
    {
        var builder = Kernel.CreateBuilder();
        var inner = new RecordingChatCompletionService("OK");
        builder.Services.AddSingleton<IChatCompletionService>(inner);
        builder.UseAgentShield(InputBlockFixture);

        var kernel = builder.Build();
        var guarded = kernel.Services.GetRequiredService<IChatCompletionService>();

        var history = new ChatHistory();
        history.AddUserMessage("please DENY_ME now");
        var contents = await guarded.GetChatMessageContentsAsync(history);

        Assert.Empty(inner.Calls);
        Assert.Single(contents);
        Assert.Contains("[Blocked by Agent Shield]", contents[0].Content);
    }

    [Fact]
    public async Task UseAgentShield_ChatCompletion_Stage5RedactsResponse()
    {
        var builder = Kernel.CreateBuilder();
        var inner = new RecordingChatCompletionService("the token is SECRET-ABC1234");
        builder.Services.AddSingleton<IChatCompletionService>(inner);
        builder.UseAgentShield(RedactFixture);

        var kernel = builder.Build();
        var guarded = kernel.Services.GetRequiredService<IChatCompletionService>();

        var history = new ChatHistory();
        history.AddUserMessage("what is the token?");
        var contents = await guarded.GetChatMessageContentsAsync(history);

        Assert.Single(inner.Calls);
        Assert.Single(contents);
        Assert.DoesNotContain("SECRET-ABC1234", contents[0].Content);
    }

    [Fact]
    public async Task UseAgentShield_ChatCompletion_StreamingStage5BlocksRunaway()
    {
        var builder = Kernel.CreateBuilder();
        var inner = new RecordingChatCompletionService("the token is SECRET-ABCD1234");
        builder.Services.AddSingleton<IChatCompletionService>(inner);
        builder.UseAgentShield(RedactFixture);

        var kernel = builder.Build();
        var guarded = kernel.Services.GetRequiredService<IChatCompletionService>();

        var history = new ChatHistory();
        history.AddUserMessage("what is the token?");
        var collected = new List<StreamingChatMessageContent>();
        await foreach (var chunk in guarded.GetStreamingChatMessageContentsAsync(history))
        {
            collected.Add(chunk);
        }

        var joined = string.Concat(collected.Select(c => c.Content ?? string.Empty));
        Assert.DoesNotContain("SECRET-ABCD1234", joined);
    }

    [Fact]
    public void UseAgentShield_DecoratesKeyedIChatClient()
    {
        var builder = Kernel.CreateBuilder();
        var inner = new RecordingChatClient("hi");
        builder.Services.AddKeyedSingleton<IChatClient>("svc1", inner);
        builder.UseAgentShield(MinimalFixture);

        var kernel = builder.Build();
        var resolved = kernel.Services.GetRequiredKeyedService<IChatClient>("svc1");

        Assert.IsType<GuardedChatClient>(resolved);
    }

    [Fact]
    public void UseAgentShield_DecoratesKeyedIChatCompletionService()
    {
        var builder = Kernel.CreateBuilder();
        var inner = new RecordingChatCompletionService("hi");
        builder.Services.AddKeyedSingleton<IChatCompletionService>("svc1", inner);
        builder.UseAgentShield(MinimalFixture);

        var kernel = builder.Build();
        var resolved = kernel.Services.GetRequiredKeyedService<IChatCompletionService>("svc1");

        Assert.IsType<GuardedChatCompletionService>(resolved);
    }

    [Fact]
    public void UseAgentShield_DecoratesChatServices_AndAlsoRegistersFunctionInvocationFilter()
    {
        var builder = Kernel.CreateBuilder();
        var inner = new RecordingChatClient("hi");
        builder.Services.AddSingleton<IChatClient>(inner);
        builder.UseAgentShield(MinimalFixture);

        var kernel = builder.Build();

        Assert.Contains(kernel.AutoFunctionInvocationFilters,
            f => f is AgentShieldFilter);

        var chat = kernel.Services.GetRequiredService<IChatClient>();
        Assert.IsType<GuardedChatClient>(chat);
    }

    [Fact]
    public void UseAgentShield_CalledTwice_DoesNotDoubleWrapChatClient()
    {
        var builder = Kernel.CreateBuilder();
        var inner = new RecordingChatClient("hi");
        builder.Services.AddSingleton<IChatClient>(inner);
        builder.UseAgentShield(MinimalFixture).UseAgentShield(MinimalFixture);

        var kernel = builder.Build();
        var resolved = kernel.Services.GetRequiredService<IChatClient>();

        var guarded = Assert.IsType<GuardedChatClient>(resolved);
        Assert.NotNull(guarded);
    }

    [Fact]
    public void UseAgentShield_ShieldOverload_AlsoDecoratesChatClient()
    {
        using var shield = Shield.FromYaml(MinimalFixture).Build();
        var builder = Kernel.CreateBuilder();
        var inner = new RecordingChatClient("hi");
        builder.Services.AddSingleton<IChatClient>(inner);
        builder.UseAgentShield(shield);

        var kernel = builder.Build();
        Assert.IsType<GuardedChatClient>(kernel.Services.GetRequiredService<IChatClient>());
    }

    [Fact]
    public void UseAgentShield_YamlChainOverload_AlsoDecoratesChatClient()
    {
        var builder = Kernel.CreateBuilder();
        var inner = new RecordingChatClient("hi");
        builder.Services.AddSingleton<IChatClient>(inner);
        builder.UseAgentShield(new[] { MinimalFixture });

        var kernel = builder.Build();
        Assert.IsType<GuardedChatClient>(kernel.Services.GetRequiredService<IChatClient>());
    }

    [Fact]
    public void AddAgentShieldFilter_AlsoDecoratesChatClient()
    {
        var services = new ServiceCollection();
        var inner = new RecordingChatClient("hi");
        services.AddSingleton<IChatClient>(inner);
        services.AddAgentShieldFilter(MinimalFixture);

        using var sp = services.BuildServiceProvider();
        var resolved = sp.GetRequiredService<IChatClient>();
        Assert.IsType<GuardedChatClient>(resolved);
    }

    [Fact]
    public void AddAgentShieldFilter_AlsoDecoratesChatCompletionService()
    {
        var services = new ServiceCollection();
        var inner = new RecordingChatCompletionService("hi");
        services.AddSingleton<IChatCompletionService>(inner);
        services.AddAgentShieldFilter(MinimalFixture);

        using var sp = services.BuildServiceProvider();
        var resolved = sp.GetRequiredService<IChatCompletionService>();
        Assert.IsType<GuardedChatCompletionService>(resolved);
    }
}
