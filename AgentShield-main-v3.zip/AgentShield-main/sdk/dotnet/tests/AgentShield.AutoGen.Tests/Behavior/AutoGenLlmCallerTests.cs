using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.Threading;
using System;
using AgentShield;
using AutoGen.Core;
using Xunit;

namespace AgentShield.AutoGen.Tests;

public class AutoGenLlmCallerTests
{

    [Fact]
    public void Caller_ForwardsMaxTokens_FromYamlConfiguration()
    {
        using var rt = GuardrailsRuntime.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"));

        var recorder = new RecordingAgent(JsonAllow());
        var caller = new AutoGenLlmCaller(recorder);
        caller.Bind(rt);

        var ctx = JsonDocument.Parse("{}").RootElement;
        caller.Call(new LlmRequest("stage1-judge", "is the input safe?", "", ctx));
        caller.Call(new LlmRequest("stage3-judge", "is the tool call safe?", "", ctx));

        Assert.Equal(2, recorder.Calls.Count);
        Assert.Equal(256, recorder.Calls[0].Options?.MaxToken);
        Assert.Null(recorder.Calls[1].Options);
    }

    [Fact]
    public void Caller_ForwardsTemperature_FromCfgMetadata()
    {
        using var rt = GuardrailsRuntime.FromYaml(FindFixture("autogen-llm-caller-test.guardrails.yaml"));

        var recorder = new RecordingAgent(JsonAllow());
        var caller = new AutoGenLlmCaller(recorder);
        caller.Bind(rt);

        var ctx = JsonDocument.Parse("{}").RootElement;
        caller.Call(new LlmRequest("temperature-judge", "judge", "", ctx));

        Assert.Single(recorder.Calls);
        Assert.NotNull(recorder.Calls[0].Options);
        Assert.Equal(0.3f, recorder.Calls[0].Options!.Temperature);
    }

    [Fact]
    public void Caller_FallsBackToAgentDefaults_WhenNoMatchingConfiguration()
    {
        using var rt = GuardrailsRuntime.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"));

        var recorder = new RecordingAgent(JsonAllow());
        var caller = new AutoGenLlmCaller(recorder);
        caller.Bind(rt);

        var ctx = JsonDocument.Parse("{}").RootElement;
        caller.Call(new LlmRequest(null, "judge", "", ctx));
        caller.Call(new LlmRequest("not-in-yaml", "judge", "", ctx));

        Assert.Equal(2, recorder.Calls.Count);
        Assert.Null(recorder.Calls[0].Options);
        Assert.Null(recorder.Calls[1].Options);
    }

    [Fact]
    public void Caller_ParsesJsonBlockVerdict()
    {
        using var rt = GuardrailsRuntime.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"));

        var recorder = new RecordingAgent(JsonBlock("policy violation"));
        var caller = new AutoGenLlmCaller(recorder);
        caller.Bind(rt);

        var resp = caller.Call(new LlmRequest("stage1-judge", "input?", "",
            JsonDocument.Parse("{}").RootElement));

        Assert.Equal("block", resp.Decision);
        Assert.Equal("policy violation", resp.Reason);
    }

    [Fact]
    public void Stage1_RoutesThroughAutoGenJudgeAgent()
    {
        var recorder = new RecordingAgent(JsonAllow());
        using var shield = Shield.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"))
            .WithAutoGenLlmJudge(recorder)
            .Build();

        var verdict = shield.Session.ValidateInput("hello");

        Assert.True(verdict.Allowed);
        Assert.Single(recorder.Calls);
        Assert.Equal(256, recorder.Calls[0].Options?.MaxToken);
    }

    [Fact]
    public void Stage3_RoutesThroughAutoGenJudgeAgent()
    {
        var recorder = new RecordingAgent(JsonAllow());
        using var shield = Shield.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"))
            .WithAutoGenLlmJudge(recorder)
            .Build();

        var args = JsonDocument.Parse("{\"x\":1}").RootElement;
        var (verdict, _) = shield.Session.ValidateToolCall("safe_tool", args, "call_1");

        Assert.True(verdict.Allowed);
        Assert.NotEmpty(recorder.Calls);
    }

    [Fact]
    public void WithAutoGenLlmJudge_NullArgs_Throws()
    {
        using var rt = GuardrailsRuntime.FromYaml(FindFixture("llm-caller-test.guardrails.yaml"));
        var builder = Shield.FromRuntime(rt);
        Assert.Throws<ArgumentNullException>(() => ((ShieldBuilder?)null)!.WithAutoGenLlmJudge(
            new RecordingAgent(JsonAllow())));
        Assert.Throws<ArgumentNullException>(() => builder.WithAutoGenLlmJudge(null!));
    }

    private static string JsonAllow() => "{\"decision\":\"allow\",\"confidence\":1.0}";

    private static string JsonBlock(string reason)
        => $"{{\"decision\":\"block\",\"confidence\":1.0,\"reason\":\"{reason}\"}}";

    private static string FindFixture(string name)
    {
        var dir = AppContext.BaseDirectory;
        while (dir != null)
        {
            var candidate = Path.Combine(dir, "tests", "fixtures", name);
            if (File.Exists(candidate)) return candidate;
            if (File.Exists(Path.Combine(dir, "AgentShield.sln")))
            {
                var path = Path.Combine(dir, "tests", "fixtures", name);
                if (File.Exists(path)) return path;
            }
            dir = Directory.GetParent(dir)?.FullName;
        }
        throw new FileNotFoundException($"Test fixture not found: {name}");
    }

    private sealed class RecordingAgent : IAgent
    {
        private readonly string _response;
        public List<RecordedCall> Calls { get; } = new();

        public RecordingAgent(string response)
        {
            _response = response;
        }

        public string Name => "recording-judge";

        public Task<IMessage> GenerateReplyAsync(
            IEnumerable<IMessage> messages,
            GenerateReplyOptions? options = null,
            CancellationToken cancellationToken = default)
        {
            Calls.Add(new RecordedCall(options));
            IMessage reply = new TextMessage(Role.Assistant, _response, Name);
            return Task.FromResult(reply);
        }
    }

    private sealed record RecordedCall(GenerateReplyOptions? Options);
}
