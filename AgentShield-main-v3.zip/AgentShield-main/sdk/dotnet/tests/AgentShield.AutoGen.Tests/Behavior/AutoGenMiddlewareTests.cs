using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.Threading;
using System;
using AgentShield;
using AutoGen.Core;
using Moq;
using Xunit;
using static AgentShield.Tests.Support.JsonTest;

namespace AgentShield.AutoGen.Tests;

public class AgentShieldMiddlewareTests : IDisposable
{
    private readonly GuardrailsRuntime _runtime;

    public AgentShieldMiddlewareTests()
    {
        _runtime = GuardrailsRuntime.FromYaml(MinimalFixture);
    }

    public void Dispose() => _runtime.Dispose();

    private static string SmokeFixturesDir
    {
        get
        {
            var dir = AppContext.BaseDirectory;
            while (dir != null && !Directory.Exists(Path.Combine(dir, "tests", "fixtures", "smoke")))
            {
                dir = Directory.GetParent(dir)?.FullName;
            }
            if (dir == null)
                throw new DirectoryNotFoundException("Could not locate tests/fixtures/smoke");
            return Path.Combine(dir, "tests", "fixtures", "smoke");
        }
    }

    private static string MinimalFixture =>
        Path.Combine(SmokeFixturesDir, "minimal.guardrails.yaml");

    [Fact]
    public void Middleware_NullRuntime_Throws()
    {
        Assert.Throws<ArgumentNullException>(() => new AgentShieldMiddleware((GuardrailsRuntime)null!));
    }

    [Fact]
    public void Middleware_NullShield_Throws()
    {
        Assert.Throws<ArgumentNullException>(() => new AgentShieldMiddleware((Shield)null!));
    }

    [Fact]
    public void Middleware_Constructs_AndExposesName()
    {
        var middleware = new AgentShieldMiddleware(_runtime);
        Assert.Equal("AgentShield", middleware.Name);
    }

    [Fact]
    public async Task Middleware_BothCtorOverloads_ProduceFunctionallyEquivalentBehaviour()
    {
        using var shield = Shield.FromRuntime(_runtime).Build();
        var runtimeMiddleware = new AgentShieldMiddleware(_runtime);
        var shieldMiddleware = new AgentShieldMiddleware(shield);

        Assert.Equal(runtimeMiddleware.Name, shieldMiddleware.Name);

        async Task<string?> Drive(AgentShieldMiddleware mw)
        {
            var reply = new TextMessage(Role.Assistant, "Hello!", "TestAgent");
            var mockAgent = new Mock<IAgent>();
            mockAgent.Setup(a => a.Name).Returns("TestAgent");
            mockAgent
                .Setup(a => a.GenerateReplyAsync(
                    It.IsAny<IEnumerable<IMessage>>(),
                    It.IsAny<GenerateReplyOptions?>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(reply);

            var ctx = new MiddlewareContext(
                new IMessage[] { new TextMessage(Role.User, "hi", "User") }, null);
            var got = await mw.InvokeAsync(ctx, mockAgent.Object);
            return got.GetContent();
        }

        Assert.Equal(await Drive(runtimeMiddleware), await Drive(shieldMiddleware));
    }

    [Fact]
    public async Task InvokeAsync_BenignInput_PassesThroughToAgent()
    {
        var middleware = new AgentShieldMiddleware(_runtime);
        var agentResponse = new TextMessage(Role.Assistant, "Hello!", "TestAgent");

        var mockAgent = new Mock<IAgent>();
        mockAgent.Setup(a => a.Name).Returns("TestAgent");
        mockAgent
            .Setup(a => a.GenerateReplyAsync(
                It.IsAny<IEnumerable<IMessage>>(),
                It.IsAny<GenerateReplyOptions?>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(agentResponse);

        var messages = new IMessage[]
        {
            new TextMessage(Role.User, "Hello, how are you?", "User"),
        };
        var context = new MiddlewareContext(messages, null);

        var result = await middleware.InvokeAsync(context, mockAgent.Object);

        Assert.Equal("Hello!", result.GetContent());
        mockAgent.Verify(a => a.GenerateReplyAsync(
            It.IsAny<IEnumerable<IMessage>>(),
            It.IsAny<GenerateReplyOptions?>(),
            It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task InvokeAsync_NoUserMessage_StillInvokesAgent()
    {
        var middleware = new AgentShieldMiddleware(_runtime);
        var agentResponse = new TextMessage(Role.Assistant, "ok", "TestAgent");

        var mockAgent = new Mock<IAgent>();
        mockAgent.Setup(a => a.Name).Returns("TestAgent");
        mockAgent
            .Setup(a => a.GenerateReplyAsync(
                It.IsAny<IEnumerable<IMessage>>(),
                It.IsAny<GenerateReplyOptions?>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(agentResponse);

        var messages = new IMessage[]
        {
            new TextMessage(Role.System, "system prompt", "system"),
        };
        var context = new MiddlewareContext(messages, null);

        var result = await middleware.InvokeAsync(context, mockAgent.Object);

        Assert.Equal("ok", result.GetContent());
    }

    [Fact]
    public async Task InvokeAsync_EmptyAssistantOutput_PassesThrough()
    {
        var middleware = new AgentShieldMiddleware(_runtime);
        var agentResponse = new TextMessage(Role.Assistant, "", "TestAgent");

        var mockAgent = new Mock<IAgent>();
        mockAgent.Setup(a => a.Name).Returns("TestAgent");
        mockAgent
            .Setup(a => a.GenerateReplyAsync(
                It.IsAny<IEnumerable<IMessage>>(),
                It.IsAny<GenerateReplyOptions?>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(agentResponse);

        var messages = new IMessage[]
        {
            new TextMessage(Role.User, "ping", "User"),
        };
        var context = new MiddlewareContext(messages, null);

        var result = await middleware.InvokeAsync(context, mockAgent.Object);

        Assert.Equal("", result.GetContent());
    }

    private static GuardrailsRuntime BuildToolBlockRuntime() =>
        RuntimeBuilder.FromYamlStrings(new[] { """
            metadata:
              name: "autogen-stage23-block"
              version: "0.1.0"
              agent_shield_version: "2.0"
            objective:
              goal:
                - "Block a specific tool name."
            resources:
              tools:
                - name: "safe_tool"
                  description: "An allowed tool."
                  permission: "read_only"
                - name: "blocked_tool"
                  description: "A forbidden tool."
                  permission: "read_only"
            tool_execution_validation:
              guard_policies:
                - name: "block_blocked_tool"
                  applies_to:
                    tools: ["blocked_tool"]
                  action: "block"
                  evaluate_when:
                    - expression: "false"
                      reason: "Tool is blocked by policy"
            """ }).Build();

    [Fact]
    public async Task InvokeAsync_ToolCall_Stage2Or3Block_ShortCircuitsToResult()
    {
        using var runtime = BuildToolBlockRuntime();
        var middleware = new AgentShieldMiddleware(runtime);

        var toolCall = new ToolCallMessage(
            new[] { new ToolCall("blocked_tool", "{\"x\":1}") { ToolCallId = "tc_1" } },
            "TestAgent");

        var mockAgent = new Mock<IAgent>();
        mockAgent.Setup(a => a.Name).Returns("TestAgent");
        mockAgent
            .Setup(a => a.GenerateReplyAsync(
                It.IsAny<IEnumerable<IMessage>>(),
                It.IsAny<GenerateReplyOptions?>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(toolCall);

        var context = new MiddlewareContext(
            new IMessage[] { new TextMessage(Role.User, "go", "User") }, null);

        var result = await middleware.InvokeAsync(context, mockAgent.Object);

        var resultMsg = Assert.IsType<ToolCallResultMessage>(result);
        Assert.Single(resultMsg.ToolCalls);
        Assert.Equal("blocked_tool", resultMsg.ToolCalls[0].FunctionName);
        Assert.Equal("tc_1", resultMsg.ToolCalls[0].ToolCallId);
        Assert.NotNull(resultMsg.ToolCalls[0].Result);
        Assert.Contains("[Blocked by Agent Shield]", resultMsg.ToolCalls[0].Result!);
        Assert.Contains("blocked_tool", resultMsg.ToolCalls[0].Result!);
    }

    private static GuardrailsRuntime BuildToolRedactRuntime() =>
        RuntimeBuilder.FromYamlStrings(new[] { """
            metadata:
              name: "autogen-stage3-redact"
              version: "0.1.0"
              agent_shield_version: "2.0"
            objective:
              goal:
                - "Strip SSNs from tool params."
            resources:
              tools:
                - name: "safe_tool"
                  description: "Tool whose args may contain SSN."
                  permission: "read_only"
            tool_execution_validation:
              guard_policies:
                - name: "redact_args_ssn"
                  applies_to:
                    tools: ["safe_tool"]
                  action: "redact"
                  replacement: "[REDACTED]"
                  evaluate_when:
                    - patterns:
                        - "\\b\\d{3}-\\d{2}-\\d{4}\\b"
                      reason: "SSN in tool arg"
            """ }).Build();

    [Fact]
    public async Task InvokeAsync_ToolCall_Stage3Mutation_PropagatesMutatedArgs()
    {
        using var runtime = BuildToolRedactRuntime();
        var middleware = new AgentShieldMiddleware(runtime);

        var rawArgs = "{\"note\":\"SSN is 123-45-6789\"}";
        var toolCall = new ToolCallMessage(
            new[] { new ToolCall("safe_tool", rawArgs) { ToolCallId = "tc_99" } },
            "TestAgent");

        var mockAgent = new Mock<IAgent>();
        mockAgent.Setup(a => a.Name).Returns("TestAgent");
        mockAgent
            .Setup(a => a.GenerateReplyAsync(
                It.IsAny<IEnumerable<IMessage>>(),
                It.IsAny<GenerateReplyOptions?>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(toolCall);

        var context = new MiddlewareContext(
            new IMessage[] { new TextMessage(Role.User, "call safe_tool", "User") }, null);

        var result = await middleware.InvokeAsync(context, mockAgent.Object);

        var passed = Assert.IsType<ToolCallMessage>(result);
        Assert.Single(passed.ToolCalls);
        Assert.Equal("tc_99", passed.ToolCalls[0].ToolCallId);
        Assert.DoesNotContain("123-45-6789", passed.ToolCalls[0].FunctionArguments);
        Assert.Contains("[REDACTED]", passed.ToolCalls[0].FunctionArguments);
    }

    private static GuardrailsRuntime BuildPostToolRedactRuntime() =>
        RuntimeBuilder.FromYamlStrings(new[] { """
            metadata:
              name: "autogen-stage4-redact"
              version: "0.1.0"
              agent_shield_version: "2.0"
            objective:
              goal:
                - "Strip SSNs from tool results."
            resources:
              tools:
                - name: "safe_tool"
                  description: "Tool whose result may contain SSN."
                  permission: "read_only"
            post_tool_validation:
              guard_policies:
                - name: "redact_output_ssn"
                  action: "redact"
                  replacement: "[REDACTED]"
                  evaluate_when:
                    - patterns:
                        - "\\b\\d{3}-\\d{2}-\\d{4}\\b"
                      reason: "SSN in tool result"
            """ }).Build();

    [Fact]
    public async Task InvokeAsync_ToolResult_Stage4Redact_RedactsResultText()
    {
        using var runtime = BuildPostToolRedactRuntime();
        var middleware = new AgentShieldMiddleware(runtime);

        var callMsg = new ToolCallMessage(
            new[]
            {
                new ToolCall("safe_tool", "{}") { ToolCallId = "tc_42" },
            },
            "TestAgent");
        var resultMsg = new ToolCallResultMessage(
            new[]
            {
                new ToolCall("safe_tool", "{}", "the SSN is 123-45-6789, take note")
                { ToolCallId = "tc_42" },
            },
            "TestAgent");
        var aggregate = new ToolCallAggregateMessage(callMsg, resultMsg, "TestAgent");

        var mockAgent = new Mock<IAgent>();
        mockAgent.Setup(a => a.Name).Returns("TestAgent");
        mockAgent
            .Setup(a => a.GenerateReplyAsync(
                It.IsAny<IEnumerable<IMessage>>(),
                It.IsAny<GenerateReplyOptions?>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(aggregate);

        var context = new MiddlewareContext(
            new IMessage[] { new TextMessage(Role.User, "show data", "User") }, null);

        var guarded = await middleware.InvokeAsync(context, mockAgent.Object);

        var guardedAgg = Assert.IsType<ToolCallAggregateMessage>(guarded);
        var redacted = Assert.IsType<ToolCallResultMessage>(guardedAgg.Message2);
        Assert.Single(redacted.ToolCalls);
        Assert.Equal("tc_42", redacted.ToolCalls[0].ToolCallId);
        Assert.NotNull(redacted.ToolCalls[0].Result);
        Assert.DoesNotContain("123-45-6789", redacted.ToolCalls[0].Result!);
        Assert.Contains("[REDACTED]", redacted.ToolCalls[0].Result!);
    }

    [Fact]
    public async Task InvokeAsync_ToolExecutionThrows_RecordsFailureAndRethrows()
    {
        using var runtime = BuildToolRedactRuntime();
        var middleware = new AgentShieldMiddleware(runtime);

        var inboundCall = new ToolCallMessage(
            new[] { new ToolCall("safe_tool", "{\"x\":1}") { ToolCallId = "tc_err" } },
            "User");

        var mockAgent = new Mock<IAgent>();
        mockAgent.Setup(a => a.Name).Returns("TestAgent");
        mockAgent
            .Setup(a => a.GenerateReplyAsync(
                It.IsAny<IEnumerable<IMessage>>(),
                It.IsAny<GenerateReplyOptions?>(),
                It.IsAny<CancellationToken>()))
            .ThrowsAsync(new InvalidOperationException("boom in safe_tool"));

        var context = new MiddlewareContext(new IMessage[] { inboundCall }, null);

        var ex = await Assert.ThrowsAsync<InvalidOperationException>(
            () => middleware.InvokeAsync(context, mockAgent.Object));
        Assert.Equal("boom in safe_tool", ex.Message);
    }
}

public class ToolProtectionTests : IDisposable
{
    private readonly GuardrailsRuntime _runtime;

    public ToolProtectionTests()
    {
        _runtime = GuardrailsRuntime.FromYaml(MinimalFixture);
    }

    public void Dispose() => _runtime.Dispose();

    private static string SmokeFixturesDir
    {
        get
        {
            var dir = AppContext.BaseDirectory;
            while (dir != null && !Directory.Exists(Path.Combine(dir, "tests", "fixtures", "smoke")))
            {
                dir = Directory.GetParent(dir)?.FullName;
            }
            if (dir == null)
                throw new DirectoryNotFoundException("Could not locate tests/fixtures/smoke");
            return Path.Combine(dir, "tests", "fixtures", "smoke");
        }
    }

    private static string MinimalFixture =>
        Path.Combine(SmokeFixturesDir, "minimal.guardrails.yaml");

    [Fact]
    public void GuardToolCall_Authorized_AllowsAndReturnsParameters()
    {
        using var session = _runtime.NewSession();
        session.SetVariable("authorized", Parse("true"));

        var mutated = ToolProtection.GuardToolCall(session, "echo", Parse("{\"msg\":\"hi\"}"));

        Assert.Equal("hi", mutated.GetProperty("msg").GetString());
    }

    [Fact]
    public void GuardToolCall_Unauthorized_ThrowsBlocked()
    {
        using var session = _runtime.NewSession();

        var ex = Assert.Throws<GuardrailsException>(
            () => ToolProtection.GuardToolCall(session, "echo", Parse("{\"msg\":\"hi\"}")));

        Assert.Contains("echo", ex.Message);
        Assert.Contains("blocked", ex.Message, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void GuardToolCall_PreservesScalarTypes()
    {
        using var session = _runtime.NewSession();
        session.SetVariable("authorized", Parse("true"));

        var mutated = ToolProtection.GuardToolCall(
            session, "echo", Parse("{\"msg\":\"x\",\"n\":7,\"flag\":true}"));

        Assert.Equal("x", mutated.GetProperty("msg").GetString());
        Assert.Equal(7, mutated.GetProperty("n").GetInt32());
        Assert.True(mutated.GetProperty("flag").GetBoolean());
    }

    [Fact]
    public void GuardToolOutput_BenignResult_PassesThrough()
    {
        using var session = _runtime.NewSession();
        session.SetVariable("authorized", Parse("true"));

        var id = Guid.NewGuid().ToString("N");
        ToolProtection.GuardToolCall(session, "echo", Parse("{\"msg\":\"hi\"}"), id);

        var result = Parse("{\"echoed\":\"hi\"}");
        var mutated = ToolProtection.GuardToolOutput(session, "echo", result, id);

        Assert.Equal("hi", mutated.GetProperty("echoed").GetString());
    }

    [Fact]
    public void GuardToolOutput_NullSession_Throws()
    {
        Assert.ThrowsAny<Exception>(() =>
            ToolProtection.GuardToolOutput(null!, "echo", Parse("{}")));
    }

    private static string ContractFixturesDir
    {
        get
        {
            var dir = AppContext.BaseDirectory;
            while (dir != null && !Directory.Exists(Path.Combine(dir, "tests", "fixtures", "contract")))
            {
                dir = Directory.GetParent(dir)?.FullName;
            }
            if (dir == null)
                throw new DirectoryNotFoundException("Could not locate tests/fixtures/contract");
            return Path.Combine(dir, "tests", "fixtures", "contract");
        }
    }

    private static string PendingResolutionFixture =>
        Path.Combine(ContractFixturesDir, "pending_resolution.guardrails.yaml");

    [Fact]
    public async Task InvokeAsync_ToolCallBlockedByHumanResolver_LatchesPendingResolution()
    {
        using var shield = Shield.FromYaml(PendingResolutionFixture).Build();
        var middleware = new AgentShieldMiddleware(shield);

        var toolCall = new ToolCallMessage(
            new[] { new ToolCall("send_email", "{\"to\":\"alice@example.com\"}") { ToolCallId = "tc_42" } },
            "TestAgent");

        var mockAgent = new Mock<IAgent>();
        mockAgent.Setup(a => a.Name).Returns("TestAgent");
        mockAgent
            .Setup(a => a.GenerateReplyAsync(
                It.IsAny<IEnumerable<IMessage>>(),
                It.IsAny<GenerateReplyOptions?>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(toolCall);

        var ctx = new MiddlewareContext(
            new IMessage[] { new TextMessage(Role.User, "send the email", "User") }, null);
        var got = await middleware.InvokeAsync(ctx, mockAgent.Object);

        var resultMsg = Assert.IsType<ToolCallResultMessage>(got);
        Assert.Contains("[Blocked by Agent Shield]", resultMsg.ToolCalls[0].Result!);

        Assert.Null(shield.LastPendingResolution());
    }

    [Fact]
    public async Task InvokeAsync_RuntimeCtor_DoesNotLatchPendingResolution()
    {
        using var runtime = GuardrailsRuntime.FromYaml(PendingResolutionFixture);
        var middleware = new AgentShieldMiddleware(runtime);

        var toolCall = new ToolCallMessage(
            new[] { new ToolCall("send_email", "{}") { ToolCallId = "tc_99" } },
            "TestAgent");

        var mockAgent = new Mock<IAgent>();
        mockAgent.Setup(a => a.Name).Returns("TestAgent");
        mockAgent
            .Setup(a => a.GenerateReplyAsync(
                It.IsAny<IEnumerable<IMessage>>(),
                It.IsAny<GenerateReplyOptions?>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(toolCall);

        var ctx = new MiddlewareContext(
            new IMessage[] { new TextMessage(Role.User, "go", "User") }, null);
        var got = await middleware.InvokeAsync(ctx, mockAgent.Object);

        var resultMsg = Assert.IsType<ToolCallResultMessage>(got);
        Assert.Contains("[Blocked by Agent Shield]", resultMsg.ToolCalls[0].Result!);
    }

    [Fact]
    public async Task ProtectToolAsync_HumanResolverBlock_LatchesPendingResolution()
    {
        using var shield = Shield.FromYaml(PendingResolutionFixture).Build();

        var (blocked, output) = await shield.ProtectToolAsync(
            "send_email",
            Parse("{\"to\":\"alice@example.com\"}"),
            _ => Task.FromResult("sent"));

        Assert.True(blocked);
        Assert.Contains("[GUARDRAIL", output);

        Assert.Null(shield.LastPendingResolution());
    }

    [Fact]
    public async Task ResolvePendingAsync_AfterProtectToolBlock_UnblocksNextCall()
    {
        using var shield = Shield.FromYaml(PendingResolutionFixture).Build();

        var (blocked1, _) = await shield.ProtectToolAsync(
            "send_email", Parse("{}"), _ => Task.FromResult("sent"));
        Assert.True(blocked1);

        await shield.UseSessionAsync(() => shield.ResolvePendingAsync("allow", setVariables: new Dictionary<string, object?> { ["send_email_approved"] = true }));

        Assert.Null(shield.LastPendingResolution());

        var (blocked2, output) = await shield.ProtectToolAsync(
            "send_email", Parse("{}"), _ => Task.FromResult("sent"));
        Assert.False(blocked2);
        Assert.Equal("sent", output);
    }

    [Fact]
    public async Task ResolvePendingAsync_Deny_WritesFalseToLatchedVariable()
    {
        using var shield = Shield.FromYaml(PendingResolutionFixture).Build();

        var (blocked, _) = await shield.ProtectToolAsync(
            "send_email", Parse("{}"), _ => Task.FromResult("sent"));
        Assert.True(blocked);

        await shield.UseSessionAsync(() => shield.ResolvePendingAsync(
            "deny",
            setVariables: new Dictionary<string, object?> { ["send_email_approved"] = false }));

        var (blocked2, _) = await shield.ProtectToolAsync(
            "send_email", Parse("{}"), _ => Task.FromResult("sent"));
        Assert.True(blocked2);
        Assert.Null(shield.LastPendingResolution());
    }

    [Fact]
    public async Task ResolvePendingAsync_InvalidDecision_Throws()
    {
        using var shield = Shield.FromYaml(PendingResolutionFixture).Build();

        await Assert.ThrowsAsync<ArgumentException>(
            () => shield.ResolvePendingAsync("maybe"));
    }

    [Fact]
    public async Task ResolvePendingAsync_NoSessionNoLatch_Throws()
    {
        using var shield = Shield.FromYaml(PendingResolutionFixture).Build();

        await Assert.ThrowsAsync<InvalidOperationException>(
            () => shield.ResolvePendingAsync("allow"));
    }

    [Fact]
    public async Task ResolvePendingAsync_ExplicitSetVariables_WritesMappedValues()
    {
        using var shield = Shield.FromYaml(PendingResolutionFixture).Build();

        var (blocked, _) = await shield.ProtectToolAsync(
            "send_email", Parse("{}"), _ => Task.FromResult("sent"));
        Assert.True(blocked);

        var map = new Dictionary<string, object?>
        {
            ["send_email_approved"] = true,
        };
        await shield.UseSessionAsync(() => shield.ResolvePendingAsync("allow", setVariables: map));

        var (blocked2, output) = await shield.ProtectToolAsync(
            "send_email", Parse("{}"), _ => Task.FromResult("sent"));
        Assert.False(blocked2);
        Assert.Equal("sent", output);
    }

    [Fact]
    public async Task UseSessionAsync_PublishesShieldSessionAsAmbient()
    {
        using var shield = Shield.FromYaml(MinimalFixture).Build();
        Assert.Null(Shield.CurrentSession);

        GuardrailsSession? seen = null;
        await shield.UseSessionAsync(() =>
        {
            seen = Shield.CurrentSession;
            return Task.CompletedTask;
        });

        Assert.NotNull(seen);
        Assert.Same(shield.Session, seen);
        Assert.Null(Shield.CurrentSession);
    }

    [Fact]
    public async Task UseSessionAsync_AutoGenMiddleware_JoinsAmbientSession()
    {
        using var shield = Shield.FromYaml(MinimalFixture).Build();
        var middleware = new AgentShieldMiddleware(shield);

        var sessions = new List<GuardrailsSession?>();
        var mockAgent = new Mock<IAgent>();
        mockAgent.Setup(a => a.Name).Returns("Worker");
        mockAgent
            .Setup(a => a.GenerateReplyAsync(
                It.IsAny<IEnumerable<IMessage>>(),
                It.IsAny<GenerateReplyOptions?>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(() =>
            {
                sessions.Add(Shield.CurrentSession);
                return new TextMessage(Role.Assistant, "ok", "Worker");
            });

        await shield.UseSessionAsync(async () =>
        {
            var ctx1 = new MiddlewareContext(
                new IMessage[] { new TextMessage(Role.User, "step one", "User") }, null);
            await middleware.InvokeAsync(ctx1, mockAgent.Object);

            var ctx2 = new MiddlewareContext(
                new IMessage[] { new TextMessage(Role.User, "step two", "User") }, null);
            await middleware.InvokeAsync(ctx2, mockAgent.Object);
        });

        Assert.Equal(2, sessions.Count);
        Assert.NotNull(sessions[0]);
        Assert.Same(shield.Session, sessions[0]);
        Assert.Same(sessions[0], sessions[1]);
    }

    [Fact]
    public async Task UseSessionAsync_MultiAgentHandoff_PreservesPendingResolution()
    {
        using var shield = Shield.FromYaml(PendingResolutionFixture).Build();
        var middleware = new AgentShieldMiddleware(shield);

        var agentA = new Mock<IAgent>();
        agentA.Setup(a => a.Name).Returns("AgentA");
        agentA
            .Setup(a => a.GenerateReplyAsync(
                It.IsAny<IEnumerable<IMessage>>(),
                It.IsAny<GenerateReplyOptions?>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new ToolCallMessage(
                new[] { new ToolCall("send_email", "{}") { ToolCallId = "tc_a" } },
                "AgentA"));

        var agentB = new Mock<IAgent>();
        agentB.Setup(a => a.Name).Returns("AgentB");
        agentB
            .Setup(a => a.GenerateReplyAsync(
                It.IsAny<IEnumerable<IMessage>>(),
                It.IsAny<GenerateReplyOptions?>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new TextMessage(Role.Assistant, "agent B output", "AgentB"));

        PendingResolution? pendingFromInsideHandoff = null;
        await shield.UseSessionAsync(async () =>
        {
            var ctxA = new MiddlewareContext(
                new IMessage[] { new TextMessage(Role.User, "send the email", "User") }, null);
            var replyA = await middleware.InvokeAsync(ctxA, agentA.Object);
            Assert.IsType<ToolCallResultMessage>(replyA);

            pendingFromInsideHandoff = shield.LastPendingResolution();
            Assert.Null(pendingFromInsideHandoff);

            var ctxB = new MiddlewareContext(
                new IMessage[] { new TextMessage(Role.User, "continue", "User") }, null);
            var replyB = await middleware.InvokeAsync(ctxB, agentB.Object);
            var textB = Assert.IsType<TextMessage>(replyB);
            Assert.Equal("agent B output", textB.Content);
        });

        Assert.Null(pendingFromInsideHandoff);
    }

    [Fact]
    public async Task UseSessionAsync_AfterScope_RestoresAmbientSession()
    {
        using var shieldOuter = Shield.FromYaml(MinimalFixture).Build();
        using var shieldInner = Shield.FromYaml(MinimalFixture).Build();

        await shieldOuter.UseSessionAsync(async () =>
        {
            Assert.Same(shieldOuter.Session, Shield.CurrentSession);
            await shieldInner.UseSessionAsync(() =>
            {
                Assert.Same(shieldInner.Session, Shield.CurrentSession);
                return Task.CompletedTask;
            });
            Assert.Same(shieldOuter.Session, Shield.CurrentSession);
        });

        Assert.Null(Shield.CurrentSession);
    }

    [Fact]
    public async Task InvokeAsync_WithoutAmbientSession_StillUsesFreshSession()
    {
        using var runtime = GuardrailsRuntime.FromYaml(MinimalFixture);
        var middleware = new AgentShieldMiddleware(runtime);

        GuardrailsSession? observed = null;
        var mockAgent = new Mock<IAgent>();
        mockAgent.Setup(a => a.Name).Returns("Solo");
        mockAgent
            .Setup(a => a.GenerateReplyAsync(
                It.IsAny<IEnumerable<IMessage>>(),
                It.IsAny<GenerateReplyOptions?>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(() =>
            {
                observed = Shield.CurrentSession;
                return new TextMessage(Role.Assistant, "ok", "Solo");
            });

        var ctx = new MiddlewareContext(
            new IMessage[] { new TextMessage(Role.User, "hi", "User") }, null);
        await middleware.InvokeAsync(ctx, mockAgent.Object);

        Assert.Null(observed);
    }

    [Fact]
    public async Task UseSessionAsync_Generic_ReturnsBodyResult()
    {
        using var shield = Shield.FromYaml(MinimalFixture).Build();

        var got = await shield.UseSessionAsync(async () =>
        {
            await Task.Yield();
            return 42;
        });

        Assert.Equal(42, got);
    }

    [Fact]
    public async Task UseSessionAsync_NullBody_Throws()
    {
        using var shield = Shield.FromYaml(MinimalFixture).Build();
        await Assert.ThrowsAsync<ArgumentNullException>(
            async () => await shield.UseSessionAsync((Func<Task>)null!));
        await Assert.ThrowsAsync<ArgumentNullException>(
            async () => await shield.UseSessionAsync((Func<Task<int>>)null!));
    }
}

public class IntermediateRedactionTests
{
    private static string SmokeFixturesDir
    {
        get
        {
            var dir = AppContext.BaseDirectory;
            while (dir != null && !Directory.Exists(Path.Combine(dir, "tests", "fixtures", "smoke")))
            {
                dir = Directory.GetParent(dir)?.FullName;
            }
            if (dir == null)
                throw new DirectoryNotFoundException("Could not locate tests/fixtures/smoke");
            return Path.Combine(dir, "tests", "fixtures", "smoke");
        }
    }

    private static string RedactFixture =>
        Path.Combine(SmokeFixturesDir, "redact.guardrails.yaml");

    [Fact]
    public void WrapAgent_NullShield_Throws()
    {
        Shield? shield = null;
        var agent = new Mock<IAgent>().Object;
        Assert.Throws<ArgumentNullException>(() => shield!.WrapAgent(agent));
    }

    [Fact]
    public void WrapAgent_NullAgent_Throws()
    {
        using var shield = Shield.FromYaml(RedactFixture).Build();
        Assert.Throws<ArgumentNullException>(() => shield.WrapAgent(null!));
    }

    [Fact]
    public void WrapAgents_NullShield_Throws()
    {
        Shield? shield = null;
        Assert.Throws<ArgumentNullException>(() =>
            shield!.WrapAgents(Array.Empty<IAgent>()).ToList());
    }

    [Fact]
    public void WrapAgents_NullAgents_Throws()
    {
        using var shield = Shield.FromYaml(RedactFixture).Build();
        Assert.Throws<ArgumentNullException>(() =>
            shield.WrapAgents(null!).ToList());
    }

    [Fact]
    public void WrapAgents_NullElement_Throws()
    {
        using var shield = Shield.FromYaml(RedactFixture).Build();
        var ex = Assert.Throws<ArgumentException>(() =>
            shield.WrapAgents(new IAgent[] { null! }).ToList());
        Assert.Equal("agents", ex.ParamName);
    }

    [Fact]
    public async Task WrapAgent_ReturnsAgentThatInvokesUnderlyingAgent()
    {
        using var shield = Shield.FromYaml(RedactFixture).Build();
        var inner = new Mock<IAgent>();
        inner.Setup(a => a.Name).Returns("Inner");
        inner.Setup(a => a.GenerateReplyAsync(
                It.IsAny<IEnumerable<IMessage>>(),
                It.IsAny<GenerateReplyOptions?>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new TextMessage(Role.Assistant, "clean reply", "Inner"));

        var wrapped = shield.WrapAgent(inner.Object);
        Assert.NotSame(inner.Object, wrapped);

        var reply = await wrapped.GenerateReplyAsync(
            new IMessage[] { new TextMessage(Role.User, "hi", "User") });
        Assert.Equal("clean reply", reply.GetContent());
        inner.Verify(a => a.GenerateReplyAsync(
            It.IsAny<IEnumerable<IMessage>>(),
            It.IsAny<GenerateReplyOptions?>(),
            It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task WrapAgent_IntermediateReply_IsRedactedBeforeReachingNextParticipant()
    {
        using var shield = Shield.FromYaml(RedactFixture).Build();

        var emitter = new Mock<IAgent>();
        emitter.Setup(a => a.Name).Returns("Emitter");
        emitter.Setup(a => a.GenerateReplyAsync(
                It.IsAny<IEnumerable<IMessage>>(),
                It.IsAny<GenerateReplyOptions?>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new TextMessage(
                Role.Assistant,
                "the launch token is SECRET-ABC123, do not share",
                "Emitter"));

        List<IMessage>? listenerObserved = null;
        var listener = new Mock<IAgent>();
        listener.Setup(a => a.Name).Returns("Listener");
        listener.Setup(a => a.GenerateReplyAsync(
                It.IsAny<IEnumerable<IMessage>>(),
                It.IsAny<GenerateReplyOptions?>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync((IEnumerable<IMessage> msgs, GenerateReplyOptions? _, CancellationToken __) =>
            {
                listenerObserved = msgs.ToList();
                return new TextMessage(Role.Assistant, "noted", "Listener");
            });

        var wrappedEmitter = shield.WrapAgent(emitter.Object);
        var wrappedListener = shield.WrapAgent(listener.Object);

        var seed = new IMessage[] { new TextMessage(Role.User, "share the token", "User") };

        var emitterReply = await wrappedEmitter.GenerateReplyAsync(seed);

        Assert.NotNull(emitterReply.GetContent());
        Assert.DoesNotContain("SECRET-ABC123", emitterReply.GetContent());

        var listenerContext = seed.Concat(new[] { emitterReply }).ToArray();
        await wrappedListener.GenerateReplyAsync(listenerContext);

        Assert.NotNull(listenerObserved);
        var concatenated = string.Join(
            "\n",
            listenerObserved!.Select(m => m.GetContent() ?? string.Empty));
        Assert.DoesNotContain("SECRET-ABC123", concatenated);
    }

    [Fact]
    public async Task WrapAgents_BulkHelper_AppliesMiddlewareToEveryAgent()
    {
        using var shield = Shield.FromYaml(RedactFixture).Build();

        IAgent BuildMock(string name, string reply)
        {
            var m = new Mock<IAgent>();
            m.Setup(a => a.Name).Returns(name);
            m.Setup(a => a.GenerateReplyAsync(
                    It.IsAny<IEnumerable<IMessage>>(),
                    It.IsAny<GenerateReplyOptions?>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new TextMessage(Role.Assistant, reply, name));
            return m.Object;
        }

        var participants = new[]
        {
            BuildMock("A", "raw SECRET-AAA111 leaks here"),
            BuildMock("B", "and B also says SECRET-BBB222"),
            BuildMock("C", "all clear"),
        };

        var wrapped = shield.WrapAgents(participants).ToList();
        Assert.Equal(3, wrapped.Count);
        for (var i = 0; i < participants.Length; i++)
        {
            Assert.NotSame(participants[i], wrapped[i]);
        }

        var ctx = new IMessage[] { new TextMessage(Role.User, "speak", "User") };
        var replyA = await wrapped[0].GenerateReplyAsync(ctx);
        var replyB = await wrapped[1].GenerateReplyAsync(ctx);
        var replyC = await wrapped[2].GenerateReplyAsync(ctx);

        Assert.DoesNotContain("SECRET-AAA111", replyA.GetContent());
        Assert.DoesNotContain("SECRET-BBB222", replyB.GetContent());
        Assert.Equal("all clear", replyC.GetContent());
    }

    [Fact]
    public async Task WrapAgent_ChainOfRedactedReplies_NeverLeaksAcrossMultipleRounds()
    {
        using var shield = Shield.FromYaml(RedactFixture).Build();

        var emitter = new Mock<IAgent>();
        emitter.Setup(a => a.Name).Returns("Emitter");
        emitter.Setup(a => a.GenerateReplyAsync(
                It.IsAny<IEnumerable<IMessage>>(),
                It.IsAny<GenerateReplyOptions?>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new TextMessage(
                Role.Assistant, "rotate SECRET-DEADBEEF immediately", "Emitter"));

        var observedHistories = new List<List<IMessage>>();
        var listener = new Mock<IAgent>();
        listener.Setup(a => a.Name).Returns("Listener");
        listener.Setup(a => a.GenerateReplyAsync(
                It.IsAny<IEnumerable<IMessage>>(),
                It.IsAny<GenerateReplyOptions?>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync((IEnumerable<IMessage> msgs, GenerateReplyOptions? _, CancellationToken __) =>
            {
                observedHistories.Add(msgs.ToList());
                return new TextMessage(Role.Assistant, "ack", "Listener");
            });

        var wrappedEmitter = shield.WrapAgent(emitter.Object);
        var wrappedListener = shield.WrapAgent(listener.Object);

        var history = new List<IMessage> { new TextMessage(Role.User, "start", "User") };

        for (var round = 0; round < 3; round++)
        {
            var emitted = await wrappedEmitter.GenerateReplyAsync(history.ToArray());
            history.Add(emitted);
            await wrappedListener.GenerateReplyAsync(history.ToArray());
            history.Add(new TextMessage(Role.Assistant, "ack", "Listener"));
        }

        Assert.Equal(3, observedHistories.Count);
        foreach (var seen in observedHistories)
        {
            var joined = string.Join("\n", seen.Select(m => m.GetContent() ?? string.Empty));
            Assert.DoesNotContain("SECRET-DEADBEEF", joined);
        }
    }
}
