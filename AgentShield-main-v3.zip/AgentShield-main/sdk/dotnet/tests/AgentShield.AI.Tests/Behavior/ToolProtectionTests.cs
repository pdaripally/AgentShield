using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Threading.Tasks;
using System.Threading;
using System;
using AgentShield;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.DependencyInjection;
using Xunit;
using static AgentShield.Tests.Support.JsonTest;

namespace AgentShield.AI.Tests;

public class GuardedChatClientToolBlockTests
{
    private static string FindFixture(string name)
    {
        var dir = AppContext.BaseDirectory;
        while (dir != null && !File.Exists(Path.Combine(dir, "tests", "fixtures", name)))
            dir = Directory.GetParent(dir)?.FullName;
        if (dir == null)
            throw new FileNotFoundException($"Fixture not found: {name}");
        return Path.Combine(dir, "tests", "fixtures", name);
    }

    [Fact]
    public async Task Stage3DenyDuringTurn_HostSeesOnlyCanonicalBlock_NoAffirmativeNarrative()
    {
        var fixturePath = FindFixture("guarded-chat-client-tools.guardrails.yaml");
        using var shield = Shield.FromYaml(fixturePath).Build();
        shield.Session.SetVariable(
            "user_role",
            JsonDocument.Parse("\"analyst\"").RootElement.Clone());

        var adminInvocations = new List<string>();
        var helperInvocations = new List<string>();

        var adminTool = AIFunctionFactory.Create(
            (string action) => { adminInvocations.Add(action); return "OK"; },
            name: "admin_tool",
            description: "Run privileged action.");
        var helperTool = AIFunctionFactory.Create(
            (string note) => { helperInvocations.Add(note); return "helper-result"; },
            name: "helper_tool",
            description: "Auxiliary helper that would run after the admin call.");

        using var inner = new MultiToolChatClient();
        using var guarded = new GuardedChatClient(inner, shield);

        var resp = await guarded.GetResponseAsync(
            new[] { new ChatMessage(ChatRole.User, "do the admin action then summarize") },
            new ChatOptions { Tools = new List<AITool> { adminTool, helperTool } });

        Assert.Empty(adminInvocations);

        var text = resp.Text ?? "";
        Assert.Contains("[Blocked by Agent Shield]", text);
        Assert.Contains("admin_tool is reserved", text);
        Assert.DoesNotContain("I have completed", text, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("here's what I did", text, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("helper-result", text);
        Assert.DoesNotContain("\"shield\":true", text);
        Assert.DoesNotContain("\"error\":\"blocked\"", text);
    }

    [Fact]
    public async Task Streaming_Stage3DenyDuringTurn_HostSeesOnlyCanonicalBlock_NoAffirmativeNarrative()
    {
        var fixturePath = FindFixture("guarded-chat-client-tools.guardrails.yaml");
        using var shield = Shield.FromYaml(fixturePath).Build();
        shield.Session.SetVariable(
            "user_role",
            JsonDocument.Parse("\"analyst\"").RootElement.Clone());

        var adminInvocations = new List<string>();
        var helperInvocations = new List<string>();

        var adminTool = AIFunctionFactory.Create(
            (string action) => { adminInvocations.Add(action); return "OK"; },
            name: "admin_tool",
            description: "Run privileged action.");
        var helperTool = AIFunctionFactory.Create(
            (string note) => { helperInvocations.Add(note); return "helper-result"; },
            name: "helper_tool",
            description: "Auxiliary helper.");

        using var inner = new MultiToolChatClient();
        using var guarded = new GuardedChatClient(inner, shield);

        var collected = new System.Text.StringBuilder();
        await foreach (var update in guarded.GetStreamingResponseAsync(
            new[] { new ChatMessage(ChatRole.User, "do it") },
            new ChatOptions { Tools = new List<AITool> { adminTool, helperTool } }))
        {
            collected.Append(update.Text);
        }

        Assert.Empty(adminInvocations);
        var text = collected.ToString();
        Assert.Contains("[Blocked by Agent Shield]", text);
        Assert.Contains("admin_tool is reserved", text);
        Assert.DoesNotContain("I have completed", text, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("here's what I did", text, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("helper-result", text);
    }

    private sealed class MultiToolChatClient : IChatClient
    {
        public async Task<ChatResponse> GetResponseAsync(
            IEnumerable<ChatMessage> messages, ChatOptions? options = null,
            CancellationToken cancellationToken = default)
        {
            var admin = options?.Tools?.OfType<AIFunction>().FirstOrDefault(f => f.Name == "admin_tool");
            var helper = options?.Tools?.OfType<AIFunction>().FirstOrDefault(f => f.Name == "helper_tool");

            string firstResult;
            try
            {
                var args = new AIFunctionArguments { ["action"] = "rotate-keys" };
                var r = await admin!.InvokeAsync(args, cancellationToken).ConfigureAwait(false);
                firstResult = r?.ToString() ?? "";
            }
            catch
            {
                firstResult = "(internal exception caught — continuing)";
            }

            if (helper is not null)
            {
                var args2 = new AIFunctionArguments { ["note"] = "follow-up" };
                try
                {
                    await helper.InvokeAsync(args2, cancellationToken).ConfigureAwait(false);
                }
                catch
                {
                }
            }

            return new ChatResponse(new ChatMessage(
                ChatRole.Assistant,
                $"I have completed the action. {firstResult} Here's what I did next..."));
        }

        public async IAsyncEnumerable<ChatResponseUpdate> GetStreamingResponseAsync(
            IEnumerable<ChatMessage> messages, ChatOptions? options = null,
            [EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            var resp = await GetResponseAsync(messages, options, cancellationToken).ConfigureAwait(false);
            yield return new ChatResponseUpdate
            {
                Role = ChatRole.Assistant,
                Contents = new[] { (AIContent)new TextContent(resp.Text ?? string.Empty) },
            };
        }

        public object? GetService(Type serviceType, object? serviceKey = null) => null;
        public void Dispose() { }
    }
}

public class GuardedChatClientToolTests : IDisposable
{
    private readonly string _fixturePath;

    public GuardedChatClientToolTests()
    {
        _fixturePath = FindFixture("guarded-chat-client-tools.guardrails.yaml");
    }

    public void Dispose() { }

    private static string FindFixture(string name)
    {
        var dir = AppContext.BaseDirectory;
        while (dir != null && !File.Exists(Path.Combine(dir, "tests", "fixtures", name)))
            dir = Directory.GetParent(dir)?.FullName;
        if (dir == null)
            throw new FileNotFoundException($"Fixture not found: {name}");
        return Path.Combine(dir, "tests", "fixtures", name);
    }

    private static JsonElement Json(string raw) => JsonDocument.Parse(raw).RootElement.Clone();

    [Fact]
    public async Task Stage3_AdminToolBlockedForNonAdminRole_InnerNotInvoked()
    {
        using var shield = Shield.FromYaml(_fixturePath).Build();
        shield.Session.SetVariable("user_role", Json("\"analyst\""));

        var invocations = new List<string>();
        var adminTool = AIFunctionFactory.Create(
            (string action) =>
            {
                invocations.Add(action);
                return "OK";
            },
            name: "admin_tool",
            description: "Run privileged action.");

        var inner = new SelfInvokingChatClient();
        using var guarded = new GuardedChatClient(inner, shield);

        var resp = await guarded.GetResponseAsync(
            new[] { new ChatMessage(ChatRole.User, "do it") },
            new ChatOptions { Tools = new List<AITool> { adminTool } });

        Assert.Empty(invocations); // inner function never ran
        Assert.Contains("[Blocked by Agent Shield]", resp.Text);
        Assert.Contains("admin_tool is reserved", resp.Text);
        Assert.DoesNotContain("\"error\":\"blocked\"", resp.Text);
        Assert.DoesNotContain("\"shield\":true", resp.Text);
    }

    [Fact]
    public async Task Stage3_AdminToolAllowedForAdminRole_InnerInvoked()
    {
        using var shield = Shield.FromYaml(_fixturePath).Build();
        shield.Session.SetVariable("user_role", Json("\"admin\""));

        var invocations = new List<string>();
        var adminTool = AIFunctionFactory.Create(
            (string action) =>
            {
                invocations.Add(action);
                return "executed: " + action;
            },
            name: "admin_tool",
            description: "Run privileged action.");

        var inner = new SelfInvokingChatClient(toolArgs: new() { ["action"] = "rotate-keys" });
        using var guarded = new GuardedChatClient(inner, shield);

        var resp = await guarded.GetResponseAsync(
            new[] { new ChatMessage(ChatRole.User, "rotate keys") },
            new ChatOptions { Tools = new List<AITool> { adminTool } });

        Assert.Single(invocations);
        Assert.Equal("rotate-keys", invocations[0]);
        Assert.Contains("executed: rotate-keys", resp.Text);
        Assert.DoesNotContain("[Blocked by Agent Shield]", resp.Text);
    }

    [Fact]
    public async Task Stage4_LookupUserSsnRedacted_BeforeReturningToModel()
    {
        using var shield = Shield.FromYaml(_fixturePath).Build();

        var lookupTool = AIFunctionFactory.Create(
            (string userId) => $"user={userId} SSN-123-45-6789 active",
            name: "lookup_user",
            description: "Lookup a user record.");

        var inner = new SelfInvokingChatClient(toolArgs: new() { ["userId"] = "u-42" });
        using var guarded = new GuardedChatClient(inner, shield);

        var resp = await guarded.GetResponseAsync(
            new[] { new ChatMessage(ChatRole.User, "who is u-42") },
            new ChatOptions { Tools = new List<AITool> { lookupTool } });

        Assert.DoesNotContain("123-45-6789", resp.Text);
        Assert.Contains("[SSN-REDACTED]", resp.Text);
    }

    [Fact]
    public async Task Streaming_Stage3_AdminToolBlockedForNonAdminRole_InnerNotInvoked()
    {
        using var shield = Shield.FromYaml(_fixturePath).Build();
        shield.Session.SetVariable("user_role", Json("\"analyst\""));

        var invocations = new List<string>();
        var adminTool = AIFunctionFactory.Create(
            (string action) =>
            {
                invocations.Add(action);
                return "OK";
            },
            name: "admin_tool",
            description: "Run privileged action.");

        var inner = new SelfInvokingChatClient();
        using var guarded = new GuardedChatClient(inner, shield);

        var collected = new System.Text.StringBuilder();
        await foreach (var update in guarded.GetStreamingResponseAsync(
            new[] { new ChatMessage(ChatRole.User, "do it") },
            new ChatOptions { Tools = new List<AITool> { adminTool } }))
        {
            collected.Append(update.Text);
        }

        Assert.Empty(invocations);
        var text = collected.ToString();
        Assert.Contains("[Blocked by Agent Shield]", text);
        Assert.Contains("admin_tool is reserved", text);
        Assert.DoesNotContain("\"error\":\"blocked\"", text);
    }

    [Fact]
    public async Task NoTools_OptionsPassThroughUnchanged()
    {
        using var shield = Shield.FromYaml(_fixturePath).Build();
        var inner = new EchoChatClient();
        using var guarded = new GuardedChatClient(inner, shield);

        var opts = new ChatOptions { ModelId = "test-model" };
        var resp = await guarded.GetResponseAsync(
            new[] { new ChatMessage(ChatRole.User, "ping") }, opts);

        Assert.Same(opts, inner.LastOptions);
        Assert.Equal("echo: ping", resp.Text);
    }

    [Fact]
    public async Task CallerToolsList_NotMutated_AfterWrapping()
    {
        using var shield = Shield.FromYaml(_fixturePath).Build();
        var fn = AIFunctionFactory.Create(
            () => "hi",
            name: "lookup_user",
            description: "noop.");
        var originalTools = new List<AITool> { fn };
        var opts = new ChatOptions { Tools = originalTools };

        var inner = new SelfInvokingChatClient(toolArgs: new());
        using var guarded = new GuardedChatClient(inner, shield);

        _ = await guarded.GetResponseAsync(
            new[] { new ChatMessage(ChatRole.User, "lookup") }, opts);

        Assert.Single(originalTools);
        Assert.Same(fn, originalTools[0]);
        Assert.NotSame(originalTools, inner.LastOptions?.Tools);
    }

    private sealed class SelfInvokingChatClient : IChatClient
    {
        private readonly Dictionary<string, object?> _toolArgs;
        public ChatOptions? LastOptions { get; private set; }

        public SelfInvokingChatClient(Dictionary<string, object?>? toolArgs = null)
        {
            _toolArgs = toolArgs ?? new Dictionary<string, object?>();
        }

        public async Task<ChatResponse> GetResponseAsync(
            IEnumerable<ChatMessage> messages, ChatOptions? options = null,
            CancellationToken cancellationToken = default)
        {
            LastOptions = options;
            var fn = options?.Tools?.OfType<AIFunction>().FirstOrDefault();
            if (fn is null)
                return new ChatResponse(new ChatMessage(ChatRole.Assistant, "(no tool)"));

            var args = new AIFunctionArguments();
            foreach (var kv in _toolArgs) args[kv.Key] = kv.Value;
            var result = await fn.InvokeAsync(args, cancellationToken).ConfigureAwait(false);
            var text = result switch
            {
                null => string.Empty,
                string s => s,
                JsonElement je => je.GetRawText(),
                _ => JsonSerializer.Serialize(result),
            };
            return new ChatResponse(new ChatMessage(ChatRole.Assistant, text));
        }

        public async IAsyncEnumerable<ChatResponseUpdate> GetStreamingResponseAsync(
            IEnumerable<ChatMessage> messages, ChatOptions? options = null,
            [EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            var resp = await GetResponseAsync(messages, options, cancellationToken).ConfigureAwait(false);
            yield return new ChatResponseUpdate
            {
                Role = ChatRole.Assistant,
                Contents = new[] { (AIContent)new TextContent(resp.Text ?? string.Empty) },
            };
        }

        public object? GetService(Type serviceType, object? serviceKey = null) => null;
        public void Dispose() { }
    }

    private sealed class EchoChatClient : IChatClient
    {
        public ChatOptions? LastOptions { get; private set; }

        public Task<ChatResponse> GetResponseAsync(
            IEnumerable<ChatMessage> messages, ChatOptions? options = null,
            CancellationToken cancellationToken = default)
        {
            LastOptions = options;
            var last = messages.LastOrDefault(m => m.Role == ChatRole.User);
            return Task.FromResult(new ChatResponse(
                new ChatMessage(ChatRole.Assistant, "echo: " + (last?.Text ?? ""))));
        }

        public async IAsyncEnumerable<ChatResponseUpdate> GetStreamingResponseAsync(
            IEnumerable<ChatMessage> messages, ChatOptions? options = null,
            [EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            var r = await GetResponseAsync(messages, options, cancellationToken).ConfigureAwait(false);
            yield return new ChatResponseUpdate
            {
                Role = ChatRole.Assistant,
                Contents = new[] { (AIContent)new TextContent(r.Text ?? string.Empty) },
            };
        }

        public object? GetService(Type serviceType, object? serviceKey = null) => null;
        public void Dispose() { }
    }
}

public class MeaiPendingResolutionTests
{
    private static string FixturePath
    {
        get
        {
            var dir = AppContext.BaseDirectory;
            while (dir != null && !Directory.Exists(Path.Combine(dir, "tests", "fixtures", "contract")))
                dir = Directory.GetParent(dir)?.FullName;
            if (dir == null)
                throw new DirectoryNotFoundException("contract fixtures dir not found");
            return Path.Combine(dir, "tests", "fixtures", "contract", "pending_resolution.guardrails.yaml");
        }
    }

    private static void AssertNoPending(PendingResolution? pending)
    {
        Assert.Null(pending);
    }


    [Fact]
    public async Task MeaiDenyPayload_IncludesPendingResolution()
    {
        using var shield = Shield.FromYaml(FixturePath).Build();

        var bodyRan = false;
        var sendEmail = AIFunctionFactory.Create(
            (string to) => { bodyRan = true; return "sent"; },
            name: "send_email",
            description: "Send an email.");

        var inner = new SelfInvokingChatClient(toolArgs: new() { ["to"] = "alice@example.com" });
        using var guarded = new GuardedChatClient(inner, shield);

        var resp = await guarded.GetResponseAsync(
            new[] { new ChatMessage(ChatRole.User, "send the email") },
            new ChatOptions { Tools = new List<AITool> { sendEmail } });

        Assert.False(bodyRan, "inner tool body must not run when Stage 3 denies");

        var text = resp.Text ?? "";
        Assert.Contains("[Blocked by Agent Shield]", text);
        Assert.DoesNotContain("\"error\":\"blocked\"", text);
        Assert.DoesNotContain("\"shield\":true", text);
        Assert.DoesNotContain("pendingResolution", text);

        AssertNoPending(shield.LastPendingResolution());
    }

    [Fact]
    public async Task ShieldLastPendingResolution_NonDestructivePeek()
    {

        using var shield = Shield.FromYaml(FixturePath).Build();
        var sendEmail = AIFunctionFactory.Create(
            (string to) => "sent",
            name: "send_email",
            description: "Send an email.");

        var inner = new SelfInvokingChatClient(toolArgs: new() { ["to"] = "alice@example.com" });
        using var guarded = new GuardedChatClient(inner, shield);

        _ = await guarded.GetResponseAsync(
            new[] { new ChatMessage(ChatRole.User, "send it") },
            new ChatOptions { Tools = new List<AITool> { sendEmail } });

        var first = shield.LastPendingResolution();
        var second = shield.LastPendingResolution();
        AssertNoPending(first);
        AssertNoPending(second);
        Assert.Same(first, second);
    }

    [Fact]
    public async Task PendingResolutionSink_FiresWithCanonicalEnvelope()
    {
        using var shield = Shield.FromYaml(FixturePath).Build();
        PendingResolution? sinkCapture = null;

        var sendEmail = AIFunctionFactory.Create(
            (string to) => "sent",
            name: "send_email",
            description: "Send an email.");

        var inner = new SelfInvokingChatClient(toolArgs: new() { ["to"] = "alice@example.com" });
        using var guarded = new GuardedChatClient(
            inner, shield, pendingResolutionSink: pr => sinkCapture = pr);

        _ = await guarded.GetResponseAsync(
            new[] { new ChatMessage(ChatRole.User, "send it") },
            new ChatOptions { Tools = new List<AITool> { sendEmail } });

        AssertNoPending(sinkCapture);
        AssertNoPending(shield.LastPendingResolution());
    }

    [Fact]
    public async Task NonSuspensionDeny_DoesNotIncludePendingResolutionField()
    {

        var adminFixture = FindFixture("guarded-chat-client-tools.guardrails.yaml");
        using var shield = Shield.FromYaml(adminFixture).Build();
        shield.Session.SetVariable("user_role",
            JsonDocument.Parse("\"analyst\"").RootElement.Clone());

        var adminTool = AIFunctionFactory.Create(
            (string action) => "OK",
            name: "admin_tool",
            description: "Run privileged action.");

        var inner = new SelfInvokingChatClient(toolArgs: new() { ["action"] = "rotate" });
        using var guarded = new GuardedChatClient(inner, shield);

        var resp = await guarded.GetResponseAsync(
            new[] { new ChatMessage(ChatRole.User, "rotate") },
            new ChatOptions { Tools = new List<AITool> { adminTool } });

        var text = resp.Text ?? "";
        Assert.Contains("[Blocked by Agent Shield]", text);
        Assert.DoesNotContain("\"error\":\"blocked\"", text);
        Assert.DoesNotContain("pendingResolution", text);

        Assert.Null(shield.LastPendingResolution());
    }

    private static string FindFixture(string name)
    {
        var dir = AppContext.BaseDirectory;
        while (dir != null && !File.Exists(Path.Combine(dir, "tests", "fixtures", name)))
            dir = Directory.GetParent(dir)?.FullName;
        if (dir == null)
            throw new FileNotFoundException($"Fixture not found: {name}");
        return Path.Combine(dir, "tests", "fixtures", name);
    }

    private sealed class SelfInvokingChatClient : IChatClient
    {
        private readonly Dictionary<string, object?> _toolArgs;

        public SelfInvokingChatClient(Dictionary<string, object?>? toolArgs = null)
        {
            _toolArgs = toolArgs ?? new Dictionary<string, object?>();
        }

        public async Task<ChatResponse> GetResponseAsync(
            IEnumerable<ChatMessage> messages, ChatOptions? options = null,
            CancellationToken cancellationToken = default)
        {
            var fn = options?.Tools?.OfType<AIFunction>().FirstOrDefault();
            if (fn is null)
                return new ChatResponse(new ChatMessage(ChatRole.Assistant, "(no tool)"));

            var args = new AIFunctionArguments();
            foreach (var kv in _toolArgs) args[kv.Key] = kv.Value;
            var result = await fn.InvokeAsync(args, cancellationToken).ConfigureAwait(false);
            var text = result switch
            {
                null => string.Empty,
                string s => s,
                JsonElement je => je.GetRawText(),
                _ => JsonSerializer.Serialize(result),
            };
            return new ChatResponse(new ChatMessage(ChatRole.Assistant, text));
        }

        public async IAsyncEnumerable<ChatResponseUpdate> GetStreamingResponseAsync(
            IEnumerable<ChatMessage> messages, ChatOptions? options = null,
            [EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            var resp = await GetResponseAsync(messages, options, cancellationToken).ConfigureAwait(false);
            yield return new ChatResponseUpdate
            {
                Role = ChatRole.Assistant,
                Contents = new[] { (AIContent)new TextContent(resp.Text ?? string.Empty) },
            };
        }

        public object? GetService(Type serviceType, object? serviceKey = null) => null;
        public void Dispose() { }
    }
}

public class InputRedactionPropagationTests
{
    private const string RedactYaml = """
        metadata:
          name: "input-redact-propagation"
          version: "0.1.0"
          agent_shield_version: "2.0"
        objective:
          goal:
            - "Demonstrate Stage 1 redaction."
          forbidden:
            - "Pass raw secret tokens into the agent."
        resources:
          tools:
            - name: "echo"
              description: "Echo helper."
              permission: "read_only"
        input_validation:
          guard_policies:
            - name: "redact_secret_input"
              evaluate_when:
                - patterns:
                    - "SECRET-[A-Z0-9]{4,}"
                  reason: "Input contained a secret token."
              action: "redact"
              replacement: "[INPUT REDACTED]"
        """;

    [Fact]
    public async Task Streaming_InputRedact_ForwardsRedactedTextToInnerClient()
    {
        using var runtime = RuntimeBuilder.FromYamlStrings(new[] { RedactYaml }).Build();
        using var inner = new RecordingMockChatClient("ok");
        using var guarded = new GuardedChatClient(inner, runtime);

        var messages = new[] { new ChatMessage(ChatRole.User, "process SECRET-ABCD1234 now") };
        var collected = new List<ChatResponseUpdate>();
        await foreach (var chunk in guarded.GetStreamingResponseAsync(messages))
        {
            collected.Add(chunk);
        }

        Assert.NotNull(inner.LastStreamingMessages);
        var lastUser = inner.LastStreamingMessages!.LastOrDefault(m => m.Role == ChatRole.User);
        Assert.NotNull(lastUser);
        Assert.DoesNotContain("SECRET-ABCD1234", lastUser!.Text ?? string.Empty);
        Assert.Contains("[INPUT REDACTED]", lastUser.Text ?? string.Empty);
    }

    [Fact]
    public async Task NonStreaming_InputRedact_ForwardsRedactedTextToInnerClient()
    {
        using var runtime = RuntimeBuilder.FromYamlStrings(new[] { RedactYaml }).Build();
        using var inner = new RecordingMockChatClient("ok");
        using var guarded = new GuardedChatClient(inner, runtime);

        var messages = new[] { new ChatMessage(ChatRole.User, "process SECRET-ABCD1234 now") };
        _ = await guarded.GetResponseAsync(messages);

        Assert.NotNull(inner.LastNonStreamingMessages);
        var lastUser = inner.LastNonStreamingMessages!.LastOrDefault(m => m.Role == ChatRole.User);
        Assert.NotNull(lastUser);
        Assert.DoesNotContain("SECRET-ABCD1234", lastUser!.Text ?? string.Empty);
        Assert.Contains("[INPUT REDACTED]", lastUser.Text ?? string.Empty);
    }

    [Fact]
    public async Task Streaming_NoStage1Policy_PassesOriginalInputThrough()
    {
        const string minimal = """
            metadata:
              name: "input-redact-minimal"
              version: "0.1.0"
              agent_shield_version: "2.0"
            objective:
              goal: ["pass through"]
              forbidden: ["n/a"]
            resources:
              tools:
                - name: "echo"
                  description: "Echo helper."
                  permission: "read_only"
            """;
        using var runtime = RuntimeBuilder.FromYamlStrings(new[] { minimal }).Build();
        using var inner = new RecordingMockChatClient("ok");
        using var guarded = new GuardedChatClient(inner, runtime);

        const string userText = "hello world";
        var messages = new[] { new ChatMessage(ChatRole.User, userText) };
        var collected = new List<ChatResponseUpdate>();
        await foreach (var chunk in guarded.GetStreamingResponseAsync(messages))
        {
            collected.Add(chunk);
        }

        Assert.NotNull(inner.LastStreamingMessages);
        var lastUser = inner.LastStreamingMessages!.LastOrDefault(m => m.Role == ChatRole.User);
        Assert.Equal(userText, lastUser?.Text);
    }

    private sealed class RecordingMockChatClient : IChatClient
    {
        private readonly string _streamText;

        public RecordingMockChatClient(string streamText)
        {
            _streamText = streamText;
        }

        public IList<ChatMessage>? LastStreamingMessages { get; private set; }
        public IList<ChatMessage>? LastNonStreamingMessages { get; private set; }

        public Task<ChatResponse> GetResponseAsync(
            IEnumerable<ChatMessage> messages,
            ChatOptions? options = null,
            CancellationToken cancellationToken = default)
        {
            LastNonStreamingMessages = messages.ToList();
            return Task.FromResult(new ChatResponse(new ChatMessage(ChatRole.Assistant, _streamText)));
        }

        public async IAsyncEnumerable<ChatResponseUpdate> GetStreamingResponseAsync(
            IEnumerable<ChatMessage> messages,
            ChatOptions? options = null,
            [EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            LastStreamingMessages = messages.ToList();
            yield return new ChatResponseUpdate
            {
                Role = ChatRole.Assistant,
                Contents = new[] { (AIContent)new TextContent(_streamText) },
            };
            await Task.Yield();
        }

        public void Dispose() { }

        public object? GetService(Type serviceType, object? key = null) => null;
    }
}

public class ResolverEnvelopeValidationTests
{
    private static readonly string AgentResolverFixture = string.Join(
        "\n",
        new[]
        {
            "metadata:",
            "  name: \"agent-resolver-envelope\"",
            "  version: \"0.1.0\"",
            "  agent_shield_version: \"2.0\"",
            "",
            "objective:",
            "  goal:",
            "    - \"Drive an agent-kind resolver via Stage 2 auto-resolution.\"",
            "",
            "resources:",
            "  tools:",
            "    - name: \"ping\"",
            "      description: \"No-op tool.\"",
            "      permission: \"execute\"",
            "",
            "variables:",
            "  - name: \"approved\"",
            "    type: \"boolean\"",
            "    description: \"Auto-resolved via agent kind at gating.\"",
            "    on_demand_by:",
            "      kind: \"agent\"",
            "      prompt: \"Approve ping?\"",
            "",
            "state_validation:",
            "  guard_policies:",
            "    - name: \"ping_requires_approval\"",
            "      applies_to:",
            "        tools:",
            "          - \"ping\"",
            "      evaluate_when:",
            "        - expression: \"approved == true\"",
            "          reason: \"ping requires approved == true.\"",
            "      action: \"block\"",
            "",
        });

    private sealed class CallbackResolver : IAgentResolver
    {
        private readonly Func<ResolverRequest, ResolverResponse> _impl;
        public int Calls;

        public CallbackResolver(Func<ResolverRequest, ResolverResponse> impl)
        {
            _impl = impl;
        }

        public ResolverResponse Resolve(ResolverRequest request)
        {
            Calls++;
            return _impl(request);
        }
    }

    private sealed class RecordingObservability : IObservabilityProvider
    {
        private readonly object _lock = new();
        private readonly List<JsonElement> _events = new();

        public IReadOnlyList<JsonElement> Events
        {
            get
            {
                lock (_lock)
                {
                    return _events.ToArray();
                }
            }
        }

        public void OnLogEvent(JsonElement eventJson)
        {
            var cloned = eventJson.Clone();
            lock (_lock)
            {
                _events.Add(cloned);
            }
        }

        public List<string> ResolverDecisions()
        {
            var decisions = new List<string>();
            JsonElement[] snapshot;
            lock (_lock)
            {
                snapshot = _events.ToArray();
            }
            foreach (var e in snapshot)
            {
                if (!e.TryGetProperty("event_type", out var t)
                    || t.ValueKind != JsonValueKind.String
                    || t.GetString() != "resolution_invoked")
                {
                    continue;
                }
                if (!e.TryGetProperty("attributes", out var attrs)
                    || attrs.ValueKind != JsonValueKind.Object)
                {
                    continue;
                }
                if (attrs.TryGetProperty("agent_shield.resolver.decision", out var d)
                    && d.ValueKind == JsonValueKind.String)
                {
                    decisions.Add(d.GetString()!);
                }
            }
            return decisions;
        }
    }

    [Fact]
    public void Exception_CarriesDecisionAndCanonicalMessage()
    {
        var ex = new AgentShieldResolverEnvelopeException("allow");
        Assert.Equal("allow", ex.Decision);
        Assert.Contains("`decision: \"allow\"`", ex.Message, StringComparison.Ordinal);
        Assert.Contains("resolver callback returned", ex.Message, StringComparison.Ordinal);
        Assert.Contains("value", ex.Message, StringComparison.Ordinal);
    }

    [Fact]
    public void Exception_Is_GuardrailsException_Subclass()
    {
        var ex = new AgentShieldResolverEnvelopeException("allow");
        Assert.IsAssignableFrom<GuardrailsException>(ex);
    }

    [Fact]
    public void AgentResolver_AllowWithoutValue_FailsClosed()
    {
        var resolver = new CallbackResolver(_ =>
            new ResolverResponse(ResolverDecision.Allow));
        var obs = new RecordingObservability();

        using var rt = RuntimeBuilder
            .FromYamlStrings(new[] { AgentResolverFixture })
            .RegisterAgentResolver(resolver)
            .RegisterObservabilityProvider(obs)
            .Build();
        using var s = rt.NewSession();

        var v = s.ValidateToolCall("ping", Parse("{}"));
        Assert.Equal(1, resolver.Calls);
        Assert.False(v.Verdict.Allowed);
        rt.FlushObservability();

        Assert.Contains("deny", obs.ResolverDecisions());
        Assert.DoesNotContain("allow", obs.ResolverDecisions());
    }

    [Fact]
    public void AgentResolver_AllowWithExplicitJsonNull_IsAccepted()
    {
        var resolver = new CallbackResolver(_ =>
            new ResolverResponse(
                ResolverDecision.Allow,
                Value: Parse("null")));
        var obs = new RecordingObservability();

        using var rt = RuntimeBuilder
            .FromYamlStrings(new[] { AgentResolverFixture })
            .RegisterAgentResolver(resolver)
            .RegisterObservabilityProvider(obs)
            .Build();
        using var s = rt.NewSession();

        var v = s.ValidateToolCall("ping", Parse("{}"));
        Assert.Equal(1, resolver.Calls);
        Assert.False(v.Verdict.Allowed);
        rt.FlushObservability();

        Assert.Contains("allow", obs.ResolverDecisions());
        Assert.DoesNotContain("deny", obs.ResolverDecisions());
    }

    [Fact]
    public void AgentResolver_AllowWithValue_True_PassesGate()
    {
        var resolver = new CallbackResolver(_ =>
            ResolverResponse.AllowWith(Parse("true")));
        var obs = new RecordingObservability();

        using var rt = RuntimeBuilder
            .FromYamlStrings(new[] { AgentResolverFixture })
            .RegisterAgentResolver(resolver)
            .RegisterObservabilityProvider(obs)
            .Build();
        using var s = rt.NewSession();

        var v = s.ValidateToolCall("ping", Parse("{}"));
        Assert.Equal(1, resolver.Calls);
        Assert.True(v.Verdict.Allowed);
        rt.FlushObservability();
        Assert.Contains("allow", obs.ResolverDecisions());
    }

    [Fact]
    public void AgentResolver_DenyWithoutValue_IsAccepted_AndGateBlocks()
    {
        var resolver = new CallbackResolver(_ =>
            ResolverResponse.DenyWith("explicit deny from resolver"));
        var obs = new RecordingObservability();

        using var rt = RuntimeBuilder
            .FromYamlStrings(new[] { AgentResolverFixture })
            .RegisterAgentResolver(resolver)
            .RegisterObservabilityProvider(obs)
            .Build();
        using var s = rt.NewSession();

        var v = s.ValidateToolCall("ping", Parse("{}"));
        Assert.Equal(1, resolver.Calls);
        Assert.False(v.Verdict.Allowed);
        rt.FlushObservability();

        Assert.Contains("deny", obs.ResolverDecisions());
    }

    [Fact]
    public void AgentResolver_CancelledWithoutValue_IsAccepted()
    {
        var resolver = new CallbackResolver(_ =>
            ResolverResponse.CancelledWith("user cancelled"));
        var obs = new RecordingObservability();

        using var rt = RuntimeBuilder
            .FromYamlStrings(new[] { AgentResolverFixture })
            .RegisterAgentResolver(resolver)
            .RegisterObservabilityProvider(obs)
            .Build();
        using var s = rt.NewSession();

        var v = s.ValidateToolCall("ping", Parse("{}"));
        Assert.Equal(1, resolver.Calls);
        Assert.False(v.Verdict.Allowed);
        rt.FlushObservability();

        Assert.Contains("cancelled", obs.ResolverDecisions());
        Assert.DoesNotContain("deny", obs.ResolverDecisions());
    }

    [Fact]
    public void AgentResolver_BareConstructor_DefaultsToAllow_AndFailsClosed()
    {
        var resolver = new CallbackResolver(_ =>
            new ResolverResponse(ResolverDecision.Allow, null, null, null));
        var obs = new RecordingObservability();

        using var rt = RuntimeBuilder
            .FromYamlStrings(new[] { AgentResolverFixture })
            .RegisterAgentResolver(resolver)
            .RegisterObservabilityProvider(obs)
            .Build();
        using var s = rt.NewSession();

        var v = s.ValidateToolCall("ping", Parse("{}"));
        Assert.False(v.Verdict.Allowed);
        rt.FlushObservability();
        Assert.Contains("deny", obs.ResolverDecisions());
        Assert.DoesNotContain("allow", obs.ResolverDecisions());
    }

    [Fact]
    public void AgentResolver_AllowWithSetVariables_StillRequiresValue()
    {
        var resolver = new CallbackResolver(_ =>
            new ResolverResponse(
                ResolverDecision.Allow,
                Value: null,
                SetVariables: new Dictionary<string, JsonElement>
                {
                    ["other"] = Parse("\"sidechannel\""),
                }));
        var obs = new RecordingObservability();

        using var rt = RuntimeBuilder
            .FromYamlStrings(new[] { AgentResolverFixture })
            .RegisterAgentResolver(resolver)
            .RegisterObservabilityProvider(obs)
            .Build();
        using var s = rt.NewSession();

        var v = s.ValidateToolCall("ping", Parse("{}"));
        Assert.False(v.Verdict.Allowed);
        rt.FlushObservability();
        Assert.Contains("deny", obs.ResolverDecisions());
        Assert.DoesNotContain("allow", obs.ResolverDecisions());
    }
}

public class BypassEnforcementTests
{
    private static string FindFixture(string name)
    {
        var dir = AppContext.BaseDirectory;
        while (dir != null && !File.Exists(Path.Combine(dir, "tests", "fixtures", name)))
            dir = Directory.GetParent(dir)?.FullName;
        if (dir == null)
            throw new FileNotFoundException($"Fixture not found: {name}");
        return Path.Combine(dir, "tests", "fixtures", name);
    }

    private static string Fixture => FindFixture("transfer-funds-silent-bypass.guardrails.yaml");

    [Fact]
    public void RegistrationOrder_WrongOrder_ThrowsAtBuilderTime()
    {

        using var shield = Shield.FromYaml(Fixture).Build();
        using var inner = new RecordingChatClient();

        var ex = Assert.Throws<InvalidOperationException>(() =>
            inner.AsBuilder()
                .UseFunctionInvocation()
                .UseAgentShield(shield));

        Assert.Contains("UseFunctionInvocation", ex.Message, StringComparison.Ordinal);
        Assert.Contains("BEFORE", ex.Message, StringComparison.Ordinal);
        Assert.Contains("bypass", ex.Message, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void RegistrationOrder_WrongOrder_PathOverload_AlsoThrows()
    {
        using var inner = new RecordingChatClient();

        var ex = Assert.Throws<InvalidOperationException>(() =>
            inner.AsBuilder()
                .UseFunctionInvocation()
                .UseAgentShield(Fixture));

        Assert.Contains("UseFunctionInvocation", ex.Message, StringComparison.Ordinal);
    }

    [Fact]
    public async Task RegistrationOrder_CorrectOrder_BlocksTransferFunds_AndReturnsDenyPayload()
    {
        using var shield = Shield.FromYaml(Fixture).Build();

        var executions = new List<long>();
        var transferFunds = AIFunctionFactory.Create(
            (long amount, string account) =>
            {
                executions.Add(amount);
                return $"EXECUTED {amount} to {account}";
            },
            name: "transfer_funds",
            description: "Transfer funds between accounts.");

        using var inner = new SelfInvokingChatClient(toolArgs: new()
        {
            ["amount"] = 5000L,
            ["account"] = "offshore-12345",
        });

        using var client = inner.AsBuilder()
            .UseAgentShield(shield)
            .Build();

        var resp = await client.GetResponseAsync(
            new[] { new ChatMessage(ChatRole.User, "Please transfer $5000 to offshore-12345") },
            new ChatOptions { Tools = new List<AITool> { transferFunds } });

        Assert.Empty(executions);

        var text = resp.Text ?? string.Empty;
        Assert.Contains("[Blocked by Agent Shield]", text, StringComparison.Ordinal);
        Assert.Contains("transfer_funds", text, StringComparison.Ordinal);
        Assert.DoesNotContain("\"error\":\"blocked\"", text, StringComparison.Ordinal);
        Assert.DoesNotContain("\"shield\":true", text, StringComparison.Ordinal);
        Assert.DoesNotContain("EXECUTED", text, StringComparison.Ordinal);
    }

    [Fact]
    public async Task AddAgentShieldChatClient_DI_BlocksTransferFunds()
    {
        var executions = new List<long>();
        var transferFunds = AIFunctionFactory.Create(
            (long amount, string account) =>
            {
                executions.Add(amount);
                return $"EXECUTED {amount} to {account}";
            },
            name: "transfer_funds",
            description: "Transfer funds between accounts.");

        var services = new ServiceCollection();
        services.AddAgentShieldChatClient(
            innerFactory: _ => new SelfInvokingChatClient(toolArgs: new()
            {
                ["amount"] = 5000L,
                ["account"] = "offshore-12345",
            }),
            yamlPath: Fixture);

        await using var provider = services.BuildServiceProvider();
        var client = provider.GetRequiredService<IChatClient>();

        var resp = await client.GetResponseAsync(
            new[] { new ChatMessage(ChatRole.User, "Please transfer $5000 to offshore-12345") },
            new ChatOptions { Tools = new List<AITool> { transferFunds } });

        Assert.Empty(executions);
        Assert.Contains("[Blocked by Agent Shield]", resp.Text, StringComparison.Ordinal);
        Assert.Contains("transfer_funds", resp.Text, StringComparison.Ordinal);
        Assert.DoesNotContain("\"shield\":true", resp.Text, StringComparison.Ordinal);
    }

    [Fact]
    public void AddAgentShieldChatClient_DI_RegistersShieldSingleton()
    {
        var services = new ServiceCollection();
        services.AddAgentShieldChatClient(
            innerFactory: _ => new RecordingChatClient(),
            yamlPath: Fixture);

        using var provider = services.BuildServiceProvider();
        var shield1 = provider.GetRequiredService<Shield>();
        var shield2 = provider.GetRequiredService<Shield>();
        Assert.Same(shield1, shield2);
    }

    [Fact]
    public async Task UseAgentShield_Shield_BuildsGuardedDelegatingChain_DenyPayloadShape()
    {
        using var shield = Shield.FromYaml(Fixture).Build();

        var executions = new List<long>();
        var transferFunds = AIFunctionFactory.Create(
            (long amount, string account) =>
            {
                executions.Add(amount);
                return $"EXECUTED {amount} to {account}";
            },
            name: "transfer_funds",
            description: "Transfer funds.");

        using var inner = new SelfInvokingChatClient(toolArgs: new()
        {
            ["amount"] = 5000L,
            ["account"] = "offshore-12345",
        });

        using var client = inner.AsBuilder()
            .UseAgentShield(shield)
            .Build();

        var resp = await client.GetResponseAsync(
            new[] { new ChatMessage(ChatRole.User, "transfer $5000") },
            new ChatOptions { Tools = new List<AITool> { transferFunds } });

        Assert.Empty(executions);
        Assert.Contains("[Blocked by Agent Shield]", resp.Text, StringComparison.Ordinal);
        Assert.DoesNotContain("\"shield\":true", resp.Text, StringComparison.Ordinal);
    }

    private sealed class SelfInvokingChatClient : IChatClient
    {
        private readonly Dictionary<string, object?> _toolArgs;
        public ChatOptions? LastOptions { get; private set; }

        public SelfInvokingChatClient(Dictionary<string, object?>? toolArgs = null)
        {
            _toolArgs = toolArgs ?? new Dictionary<string, object?>();
        }

        public async Task<ChatResponse> GetResponseAsync(
            IEnumerable<ChatMessage> messages, ChatOptions? options = null,
            CancellationToken cancellationToken = default)
        {
            LastOptions = options;
            var fn = options?.Tools?.OfType<AIFunction>().FirstOrDefault();
            if (fn is null)
                return new ChatResponse(new ChatMessage(ChatRole.Assistant, "(no tool)"));

            var args = new AIFunctionArguments();
            foreach (var kv in _toolArgs) args[kv.Key] = kv.Value;
            var result = await fn.InvokeAsync(args, cancellationToken).ConfigureAwait(false);
            var text = result switch
            {
                null => string.Empty,
                string s => s,
                JsonElement je => je.GetRawText(),
                _ => JsonSerializer.Serialize(result),
            };
            return new ChatResponse(new ChatMessage(ChatRole.Assistant, text));
        }

        public async IAsyncEnumerable<ChatResponseUpdate> GetStreamingResponseAsync(
            IEnumerable<ChatMessage> messages, ChatOptions? options = null,
            [EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            var resp = await GetResponseAsync(messages, options, cancellationToken).ConfigureAwait(false);
            yield return new ChatResponseUpdate
            {
                Role = ChatRole.Assistant,
                Contents = new[] { (AIContent)new TextContent(resp.Text ?? string.Empty) },
            };
        }

        public object? GetService(Type serviceType, object? serviceKey = null) => null;
        public void Dispose() { }
    }

    private sealed class RecordingChatClient : IChatClient
    {
        public Task<ChatResponse> GetResponseAsync(
            IEnumerable<ChatMessage> messages, ChatOptions? options = null,
            CancellationToken cancellationToken = default) =>
            Task.FromResult(new ChatResponse(new ChatMessage(ChatRole.Assistant, "unreachable")));

        public async IAsyncEnumerable<ChatResponseUpdate> GetStreamingResponseAsync(
            IEnumerable<ChatMessage> messages, ChatOptions? options = null,
            [EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            await Task.CompletedTask.ConfigureAwait(false);
            yield break;
        }

        public object? GetService(Type serviceType, object? serviceKey = null) => null;
        public void Dispose() { }
    }
}
