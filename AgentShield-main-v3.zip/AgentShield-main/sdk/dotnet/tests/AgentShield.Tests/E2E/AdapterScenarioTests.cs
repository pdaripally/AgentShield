using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json.Nodes;
using System.Text.Json;
using System.Threading.Tasks;
using System;
using AgentShield.AI;
using AgentShield.Anthropic;
using AgentShield.AutoGen;
using AgentShield.MCP;
using AgentShield.OpenAI;
using AgentShield.SemanticKernel;
using AgentShield;
using Microsoft.Extensions.AI;
using Microsoft.SemanticKernel;
using Xunit.Abstractions;
using Xunit;
using YamlDotNet.RepresentationModel;

namespace AgentShield.Tests;

public class AdapterScenariosTests
{
    private const string PiiResponse =
        "{\"customer_name\":\"Jane Doe\",\"ssn\":\"123-45-6789\",\"balance\":50000}";

    private readonly ITestOutputHelper _output;

    public AdapterScenariosTests(ITestOutputHelper output)
    {
        _output = output;
    }

    private static string RepoRoot
    {
        get
        {
            var dir = AppContext.BaseDirectory;
            while (dir != null && !File.Exists(Path.Combine(
                dir, "tests", "e2e", "adapter-scenarios.yaml")))
                dir = Directory.GetParent(dir)?.FullName;
            return dir ?? throw new DirectoryNotFoundException(
                "could not locate tests/e2e/adapter-scenarios.yaml");
        }
    }

    private static string ScenariosPath =>
        Path.Combine(RepoRoot, "tests", "e2e", "adapter-scenarios.yaml");

    private static string FixturePath(string rel) =>
        Path.Combine(RepoRoot, "tests", "fixtures", rel);

    private sealed class AllowLlm : ILlmCaller
    {
        public LlmResponse Call(LlmRequest req) => LlmResponse.Allow();
    }

    private sealed record AdapterSpec(
        string Name,
        Func<ShieldBuilder, ShieldBuilder> Bind,
        CapabilityReport Capability);

    private static IReadOnlyList<AdapterSpec> ShieldAdapters()
    {
        return new AdapterSpec[]
        {
            new("autogen", b => b.WithAutoGen(), AgentShield.AutoGen.ShieldExtensions.CapabilityReport),
            new("openai", b => b.WithOpenAI(), AgentShield.OpenAI.ShieldExtensions.CapabilityReport),
            new("anthropic", b => b.WithAnthropic(), AgentShield.Anthropic.ShieldExtensions.CapabilityReport),
            new("microsoft.extensions.ai", b => b.WithChatClient(NoopChatClient.Instance), AgentShield.AI.ShieldExtensions.CapabilityReport),
            new("semantic_kernel", b => b.WithSemanticKernel(Kernel.CreateBuilder().Build()), AgentShield.SemanticKernel.ShieldExtensions.CapabilityReport),
        };
    }

    private sealed class NoopChatClient : IChatClient
    {
        public static readonly NoopChatClient Instance = new();
        public Task<ChatResponse> GetResponseAsync(
            IEnumerable<ChatMessage> messages,
            ChatOptions? options = null,
            System.Threading.CancellationToken cancellationToken = default) =>
            Task.FromResult(new ChatResponse(new ChatMessage(ChatRole.Assistant, "")));
        public async System.Collections.Generic.IAsyncEnumerable<ChatResponseUpdate> GetStreamingResponseAsync(
            IEnumerable<ChatMessage> messages,
            ChatOptions? options = null,
            [System.Runtime.CompilerServices.EnumeratorCancellation]
            System.Threading.CancellationToken cancellationToken = default)
        {
            await Task.CompletedTask;
            yield break;
        }
        public object? GetService(Type serviceType, object? serviceKey = null) => null;
        public void Dispose() { }
    }

    private static readonly HashSet<string> NetCapabilities = new();

    private static string? SkipForUnsupported(AdapterSpec adapter, YamlMappingNode scenario)
    {
        if (scenario.Children.ContainsKey("validate_input"))
        {
            if (adapter.Capability.InputValidation == CoverageLevel.Unsupported)
                return "input_validation Unsupported on this adapter";
        }
        var hasTool = scenario.Children.ContainsKey("tool")
            || scenario.Children.ContainsKey("steps");
        if (hasTool && (
            adapter.Capability.ToolExecutionValidation == CoverageLevel.Unsupported
            || adapter.Capability.ToolOutputValidation == CoverageLevel.Unsupported))
        {
            return "tool_execution_validation or tool_output_validation Unsupported on this adapter";
        }
        return null;
    }

    private static string? KnownXfail(string adapter, string scenarioName)
    {
        if (scenarioName is "variable change blocks subsequent tool"
            or "state accumulates across tool calls")
        {
            return "populator cannot extract `@result.<field>` from a JSON-string tool body "
                + "(cross-SDK; same failure in Python's run_langchain.py)";
        }
        return null;
    }

    public static IEnumerable<object[]> AdapterScenarioPairs()
    {
        if (!File.Exists(ScenariosPath))
            yield break;

        using var reader = new StreamReader(ScenariosPath);
        var stream = new YamlStream();
        stream.Load(reader);
        var root = (YamlMappingNode)stream.Documents[0].RootNode;
        var scenarios = (YamlSequenceNode)root["scenarios"];

        foreach (var spec in ShieldAdapters())
        {
            foreach (YamlMappingNode scenario in scenarios)
            {
                var name = ((YamlScalarNode)scenario["name"]).Value!;
                yield return new object[] { spec.Name, name };
            }
        }
    }

    [Theory]
    [MemberData(nameof(AdapterScenarioPairs))]
    public async Task AdapterScenario(string adapterName, string scenarioName)
    {
        var adapter = ShieldAdapters().Single(a => a.Name == adapterName);
        var scenario = LoadScenario(scenarioName);

        if (scenario.Children.ContainsKey("capabilities"))
        {
            var required = ((YamlSequenceNode)scenario["capabilities"])
                .Children.Cast<YamlScalarNode>().Select(n => n.Value!).ToHashSet();
            if (!required.IsSubsetOf(NetCapabilities))
            {
                _output.WriteLine($"[{adapterName}] SKIP {scenarioName}: requires {string.Join(',', required)}");
                return;
            }
        }

        var coverageSkip = SkipForUnsupported(adapter, scenario);
        if (coverageSkip != null)
        {
            _output.WriteLine($"[{adapterName}] SKIP {scenarioName}: {coverageSkip}");
            return;
        }

        var xfail = KnownXfail(adapterName, scenarioName);
        if (xfail != null)
        {
            _output.WriteLine($"[{adapterName}] XFAIL {scenarioName}: {xfail}");
            return;
        }

        using var tmp = new TempDir();
        var fixturePath = ResolveFixture(scenario, tmp.Path);
        var builder = Shield.FromYaml(fixturePath);
        builder = adapter.Bind(builder);
        builder = builder.WithLlm(new AllowLlm());
        using var shield = builder.Build();

        ApplySetup(shield, scenario);

        if (scenario.Children.ContainsKey("tool"))
            await RunSimpleTool(adapterName, scenarioName, scenario, shield);
        else if (scenario.Children.ContainsKey("validate_input"))
            RunValidateInput(adapterName, scenarioName, scenario, shield);
        else if (scenario.Children.ContainsKey("steps"))
            await RunSteps(adapterName, scenarioName, scenario, shield);
        else
        {
            _output.WriteLine($"[{adapterName}] SKIP {scenarioName}: unsupported scenario shape");
            return;
        }
        _output.WriteLine($"[{adapterName}] PASS {scenarioName}");
    }

    public static IEnumerable<object[]> McpScenarios()
    {
        if (!File.Exists(ScenariosPath))
            yield break;

        using var reader = new StreamReader(ScenariosPath);
        var stream = new YamlStream();
        stream.Load(reader);
        var root = (YamlMappingNode)stream.Documents[0].RootNode;
        var scenarios = (YamlSequenceNode)root["scenarios"];
        foreach (YamlMappingNode scenario in scenarios)
        {
            var name = ((YamlScalarNode)scenario["name"]).Value!;
            if (!scenario.Children.ContainsKey("tool")
                && !scenario.Children.ContainsKey("steps"))
                continue;
            if (scenario.Children.ContainsKey("capabilities"))
                continue;
            yield return new object[] { name };
        }
    }

    [Theory]
    [MemberData(nameof(McpScenarios))]
    public void McpAdapterScenario(string scenarioName)
    {
        var scenario = LoadScenario(scenarioName);

        var xfail = KnownXfail("mcp", scenarioName);
        if (xfail != null)
        {
            _output.WriteLine($"[mcp] XFAIL {scenarioName}: {xfail}");
            return;
        }

        using var tmp = new TempDir();
        var fixturePath = ResolveFixture(scenario, tmp.Path);
        using var mcp = MCPShield.FromYaml(fixturePath)
            .WithLlmCaller(new AllowLlm())
            .Build();
        var session = mcp.Session!;
        try { session.BeginTurn(); } catch { }

        ApplySetupOn(session, scenario);

        if (scenario.Children.ContainsKey("tool"))
            RunMcpSimpleTool(scenarioName, scenario, mcp);
        else if (scenario.Children.ContainsKey("steps"))
            RunMcpSteps(scenarioName, scenario, mcp);
        _output.WriteLine($"[mcp] PASS {scenarioName}");
    }

    private static async Task RunSimpleTool(
        string adapter, string name, YamlMappingNode scenario, Shield shield)
    {
        var toolSpec = (YamlMappingNode)scenario["tool"];
        var toolName = ScalarOrEmpty(toolSpec, "name");
        var response = ToolResponse(toolSpec);
        var invoked = false;

        var (blocked, output) = await shield.ProtectToolAsync(
            toolName,
            JsonDocument.Parse("{}").RootElement.Clone(),
            _ =>
            {
                invoked = true;
                return Task.FromResult(response);
            });

        AssertExpected(name, (YamlMappingNode)scenario["expected"], invoked, output);
    }

    private static void RunValidateInput(
        string adapter, string name, YamlMappingNode scenario, Shield shield)
    {
        var input = ScalarOrEmpty(scenario, "validate_input");
        var verdict = shield.Session.ValidateInput(input);
        var expected = (YamlMappingNode)scenario["expected"];
        if (expected.Children.ContainsKey("allowed"))
        {
            var want = bool.Parse(ScalarOrEmpty(expected, "allowed"));
            Assert.True(verdict.Allowed == want,
                $"[{adapter}] [{name}] allowed mismatch: reason={verdict.Reason}");
        }
        if (expected.Children.ContainsKey("action"))
        {
            var want = ScalarOrEmpty(expected, "action");
            Assert.True(string.Equals(verdict.Action, want, StringComparison.OrdinalIgnoreCase),
                $"[{adapter}] [{name}] action mismatch: got {verdict.Action}, want {want}");
        }
    }

    private static async Task RunSteps(
        string adapter, string name, YamlMappingNode scenario, Shield shield)
    {
        var steps = (YamlSequenceNode)scenario["steps"];
        for (var i = 0; i < steps.Children.Count; i++)
        {
            var step = (YamlMappingNode)steps[i];
            var action = ScalarOrEmpty(step, "action");
            var label = $"{name}[step {i} {action}]";
            switch (action)
            {
                case "invoke_tool":
                {
                    var toolSpec = (YamlMappingNode)step["tool"];
                    var toolName = ScalarOrEmpty(toolSpec, "name");
                    var response = ToolResponse(toolSpec);
                    var invoked = false;
                    var (_, output) = await shield.ProtectToolAsync(
                        toolName,
                        JsonDocument.Parse("{}").RootElement.Clone(),
                        _ =>
                        {
                            invoked = true;
                            return Task.FromResult(response);
                        });
                    if (step.Children.ContainsKey("expected"))
                        AssertExpected(label, (YamlMappingNode)step["expected"], invoked, output);
                    break;
                }
                case "check_variable":
                {
                    var varName = ScalarOrEmpty(step, "variable");
                    var wantNode = step["expected_value"];
                    var got = shield.Session.ResolveVariable(varName);
                    var gotJson = got.HasValue ? got.Value.GetRawText() : "null";
                    var wantJson = YamlToJson(wantNode);
                    Assert.True(JsonNormalize(gotJson) == JsonNormalize(wantJson),
                        $"[{adapter}] [{label}] variable {varName}: expected {wantJson}, got {gotJson}");
                    break;
                }
                case "set_variable":
                {
                    var varName = ScalarOrEmpty(step, "variable");
                    var value = JsonDocument.Parse(YamlToJson(step["value"])).RootElement.Clone();
                    shield.Session.SetVariable(varName, value);
                    break;
                }
                case "reset_variable":
                {
                    var varName = ScalarOrEmpty(step, "variable");
                    shield.Session.ResetVariable(varName);
                    break;
                }
                case "validate_tool_call":
                {
                    var toolName = ScalarOrEmpty(step, "tool_name");
                    var (verdict, _) = shield.Session.ValidateToolCall(
                        toolName, JsonDocument.Parse("{}").RootElement.Clone(), "case_invocation");
                    if (step.Children.ContainsKey("expected"))
                    {
                        var exp = (YamlMappingNode)step["expected"];
                        if (exp.Children.ContainsKey("allowed"))
                        {
                            var want = bool.Parse(ScalarOrEmpty(exp, "allowed"));
                            Assert.True(verdict.Allowed == want,
                                $"[{adapter}] [{label}] allowed mismatch: reason={verdict.Reason}");
                        }
                    }
                    break;
                }
                default:
                    throw new InvalidOperationException($"[{adapter}] unknown step action: {action}");
            }
        }
    }

    private static void RunMcpSimpleTool(
        string name, YamlMappingNode scenario, MCPShield mcp)
    {
        var toolSpec = (YamlMappingNode)scenario["tool"];
        var toolName = ScalarOrEmpty(toolSpec, "name");
        var response = ToolResponse(toolSpec);
        var invoked = false;
        string output;

        var toolCallId = Guid.NewGuid().ToString("N");
        var (allowed, _, blockMsg) = mcp.ProtectTool(toolName, "{}", toolCallId);
        if (!allowed)
        {
            output = blockMsg ?? "[GUARDRAIL BLOCK] blocked";
        }
        else
        {
            invoked = true;
            var (postAllowed, postOutput, postBlock) = mcp.ProtectToolOutput(toolName, response, toolCallId);
            output = postAllowed ? postOutput : (postBlock ?? "[GUARDRAIL BLOCK] blocked");
        }

        AssertExpected(name, (YamlMappingNode)scenario["expected"], invoked, output);
    }

    private static void RunMcpSteps(
        string name, YamlMappingNode scenario, MCPShield mcp)
    {
        var steps = (YamlSequenceNode)scenario["steps"];
        var session = mcp.Session!;
        for (var i = 0; i < steps.Children.Count; i++)
        {
            var step = (YamlMappingNode)steps[i];
            var action = ScalarOrEmpty(step, "action");
            var label = $"{name}[step {i} {action}]";
            switch (action)
            {
                case "invoke_tool":
                {
                    var toolSpec = (YamlMappingNode)step["tool"];
                    var toolName = ScalarOrEmpty(toolSpec, "name");
                    var response = ToolResponse(toolSpec);
                    var invoked = false;
                    string output;
                    var toolCallId = Guid.NewGuid().ToString("N");
                    var (allowed, _, blockMsg) = mcp.ProtectTool(toolName, "{}", toolCallId);
                    if (!allowed)
                    {
                        output = blockMsg ?? "[GUARDRAIL BLOCK] blocked";
                    }
                    else
                    {
                        invoked = true;
                        var (postAllowed, postOutput, postBlock) = mcp.ProtectToolOutput(toolName, response, toolCallId);
                        output = postAllowed ? postOutput : (postBlock ?? "[GUARDRAIL BLOCK] blocked");
                    }
                    if (step.Children.ContainsKey("expected"))
                        AssertExpected(label, (YamlMappingNode)step["expected"], invoked, output);
                    break;
                }
                case "set_variable":
                {
                    var varName = ScalarOrEmpty(step, "variable");
                    var value = JsonDocument.Parse(YamlToJson(step["value"])).RootElement.Clone();
                    session.SetVariable(varName, value);
                    break;
                }
                case "reset_variable":
                {
                    var varName = ScalarOrEmpty(step, "variable");
                    session.ResetVariable(varName);
                    break;
                }
                case "validate_tool_call":
                {
                    var toolName = ScalarOrEmpty(step, "tool_name");
                    var (verdict, _) = session.ValidateToolCall(
                        toolName, JsonDocument.Parse("{}").RootElement.Clone(), "case_invocation");
                    if (step.Children.ContainsKey("expected"))
                    {
                        var exp = (YamlMappingNode)step["expected"];
                        if (exp.Children.ContainsKey("allowed"))
                        {
                            var want = bool.Parse(ScalarOrEmpty(exp, "allowed"));
                            Assert.True(verdict.Allowed == want,
                                $"[mcp] [{label}] allowed mismatch: reason={verdict.Reason}");
                        }
                    }
                    break;
                }
                case "check_variable":
                    break;
                default:
                    throw new InvalidOperationException($"[mcp] unknown step action: {action}");
            }
        }
    }

    private static YamlMappingNode LoadScenario(string scenarioName)
    {
        using var reader = new StreamReader(ScenariosPath);
        var stream = new YamlStream();
        stream.Load(reader);
        var root = (YamlMappingNode)stream.Documents[0].RootNode;
        var scenarios = (YamlSequenceNode)root["scenarios"];
        foreach (YamlMappingNode s in scenarios)
            if (((YamlScalarNode)s["name"]).Value == scenarioName)
                return s;
        throw new KeyNotFoundException($"scenario {scenarioName} not in {ScenariosPath}");
    }

    private static string ScalarOrEmpty(YamlMappingNode node, string key) =>
        node.Children.ContainsKey(key)
            ? ((YamlScalarNode)node[key]).Value ?? ""
            : "";

    private static string ToolResponse(YamlMappingNode toolSpec)
    {
        if (toolSpec.Children.ContainsKey("response_pii")
            && bool.TryParse(((YamlScalarNode)toolSpec["response_pii"]).Value, out var pii)
            && pii)
            return PiiResponse;
        if (toolSpec.Children.ContainsKey("response_sensitivity"))
        {
            var sensitivity = ((YamlScalarNode)toolSpec["response_sensitivity"]).Value;
            return $"{{\"sensitivity\":\"{sensitivity}\"}}";
        }
        return ScalarOrEmpty(toolSpec, "response") is var r && r.Length > 0 ? r : "ok";
    }

    private static void ApplySetup(Shield shield, YamlMappingNode scenario)
    {
        try { shield.Session.BeginTurn(); } catch { }
        ApplySetupOn(shield.Session, scenario);
    }

    private static void ApplySetupOn(GuardrailsSession session, YamlMappingNode scenario)
    {
        if (!scenario.Children.ContainsKey("setup")) return;
        var setup = (YamlMappingNode)scenario["setup"];
        if (!setup.Children.ContainsKey("variables")) return;
        var vars = (YamlMappingNode)setup["variables"];
        foreach (var kv in vars.Children)
        {
            var name = ((YamlScalarNode)kv.Key).Value!;
            var value = JsonDocument.Parse(YamlToJson(kv.Value)).RootElement.Clone();
            session.SetVariable(name, value);
        }
    }

    private static void AssertExpected(
        string name, YamlMappingNode expected, bool invoked, string result)
    {
        if (expected.Children.ContainsKey("tool_invoked"))
        {
            var want = bool.Parse(ScalarOrEmpty(expected, "tool_invoked"));
            Assert.True(invoked == want,
                $"[{name}] tool_invoked mismatch — got {invoked}, want {want}; result={result}");
        }
        if (expected.Children.ContainsKey("result"))
        {
            var want = ScalarOrEmpty(expected, "result");
            Assert.True(result == want,
                $"[{name}] result mismatch — got {result}, want {want}");
        }
        if (expected.Children.ContainsKey("result_contains"))
        {
            var needle = ScalarOrEmpty(expected, "result_contains");
            Assert.True(result.Contains(needle, StringComparison.Ordinal),
                $"[{name}] expected result to contain {needle}, got {result}");
        }
        if (expected.Children.ContainsKey("result_contains_lower"))
        {
            var needle = ScalarOrEmpty(expected, "result_contains_lower");
            Assert.True(result.ToLowerInvariant().Contains(needle, StringComparison.Ordinal),
                $"[{name}] expected lowercased result to contain {needle}, got {result}");
        }
        if (expected.Children.ContainsKey("result_not_contains"))
        {
            var needle = ScalarOrEmpty(expected, "result_not_contains");
            Assert.False(result.Contains(needle, StringComparison.Ordinal),
                $"[{name}] expected result NOT to contain {needle}, got {result}");
        }
    }

    private static string YamlToJson(YamlNode node)
    {
        return node switch
        {
            YamlScalarNode s => ScalarToJson(s),
            YamlSequenceNode seq =>
                "[" + string.Join(",", seq.Children.Select(YamlToJson)) + "]",
            YamlMappingNode map =>
                "{" + string.Join(",", map.Children.Select(kv =>
                    JsonString(((YamlScalarNode)kv.Key).Value!) + ":" + YamlToJson(kv.Value))) + "}",
            _ => "null",
        };
    }

    private static string ScalarToJson(YamlScalarNode s)
    {
        var v = s.Value ?? "";
        if (s.Style is YamlDotNet.Core.ScalarStyle.SingleQuoted
            or YamlDotNet.Core.ScalarStyle.DoubleQuoted)
            return JsonString(v);
        if (bool.TryParse(v, out var b)) return b ? "true" : "false";
        if (v == "null" || v == "~" || v == "") return "null";
        if (long.TryParse(v, out var i)) return i.ToString();
        if (double.TryParse(v, System.Globalization.NumberStyles.Float,
            System.Globalization.CultureInfo.InvariantCulture, out var d))
            return d.ToString(System.Globalization.CultureInfo.InvariantCulture);
        return JsonString(v);
    }

    private static string JsonString(string s)
    {
        return JsonSerializer.Serialize(s);
    }

    private static string JsonNormalize(string json)
    {
        if (string.IsNullOrEmpty(json) || json == "null") return "null";
        try
        {
            using var doc = JsonDocument.Parse(json);
            return doc.RootElement.GetRawText();
        }
        catch { return json; }
    }

    private static string ResolveFixture(YamlMappingNode scenario, string tmpDir)
    {
        if (scenario.Children.ContainsKey("fixture"))
            return FixturePath(((YamlScalarNode)scenario["fixture"]).Value!);
        if (scenario.Children.ContainsKey("fixture_inline"))
            return WriteInlineFixture((YamlMappingNode)scenario["fixture_inline"], tmpDir);
        throw new InvalidOperationException("scenario has neither fixture nor fixture_inline");
    }

    private static string WriteInlineFixture(YamlMappingNode spec, string tmpDir)
    {
        var name = spec.Children.ContainsKey("name")
            ? ((YamlScalarNode)spec["name"]).Value!
            : "inline-scenario";
        var json = new JsonObject();
        json["metadata"] = new JsonObject
        {
            ["name"] = name,
            ["version"] = "2.0.0",
            ["agent_shield_version"] = "2.0",
        };
        json["objective"] = new JsonObject
        {
            ["goal"] = new JsonArray("E2E test"),
            ["forbidden"] = new JsonArray(),
        };
        if (spec.Children.ContainsKey("resources"))
        {
            json["resources"] = new JsonObject
            {
                ["tools"] = JsonNode.Parse(YamlToJson(spec["resources"])),
            };
        }
        foreach (var key in new[]
        {
            "configurations", "variables", "state_validation",
            "input_validation", "tool_execution_validation",
            "post_tool_validation", "output_validation",
        })
        {
            if (spec.Children.ContainsKey(key))
                json[key] = JsonNode.Parse(YamlToJson(spec[key]));
        }
        var path = Path.Combine(tmpDir, $"{name}.guardrails.yaml");
        File.WriteAllText(path, json.ToJsonString());
        return path;
    }

    private sealed class TempDir : IDisposable
    {
        public string Path { get; }
        public TempDir()
        {
            Path = System.IO.Path.Combine(
                AppContext.BaseDirectory,
                "scratch",
                "adapter-scenarios-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(Path);
        }
        public void Dispose()
        {
            try { Directory.Delete(Path, recursive: true); } catch { }
        }
    }
}
