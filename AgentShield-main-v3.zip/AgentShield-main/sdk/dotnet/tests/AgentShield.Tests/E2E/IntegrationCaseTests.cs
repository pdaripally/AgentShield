using System.Collections.Concurrent;
using System.Diagnostics;
using System.Linq;
using System.Text.Json.Serialization;
using System.Text.Json;
using AgentShield;
using Xunit.Abstractions;
using Xunit.Sdk;
using Xunit;
using YamlDotNet.RepresentationModel;

namespace AgentShield.Tests;

public class IntegrationCaseTests : IClassFixture<IntegrationCaseReportFixture>
{
    private readonly ITestOutputHelper _output;

    public IntegrationCaseTests(ITestOutputHelper output, IntegrationCaseReportFixture _)
    {
        _output = output;
    }

    private static string RepoRoot
    {
        get
        {
            var dir = AppContext.BaseDirectory;
            while (dir != null && !Directory.Exists(Path.Combine(dir, "tests", "cases")))
                dir = Directory.GetParent(dir)?.FullName;
            return dir ?? throw new DirectoryNotFoundException(
                "Could not find repo root (expected tests/cases/ directory)");
        }
    }

    private static string CasesDir => Path.Combine(RepoRoot, "tests", "cases");
    private static string FixturesDir => Path.Combine(RepoRoot, "tests", "fixtures");

    private static string? FindFixture(string name)
    {
        var direct = Path.Combine(FixturesDir, name);
        if (File.Exists(direct)) return direct;

        var leaf = Path.GetFileName(name);
        if (Directory.Exists(FixturesDir))
        {
            foreach (var subdir in Directory.GetDirectories(FixturesDir))
            {
                var candidate = Path.Combine(subdir, leaf);
                if (File.Exists(candidate)) return candidate;
            }
        }

        return null;
    }

    public static IEnumerable<object[]> LoadAllCases()
    {
        foreach (var yamlFile in Directory.GetFiles(CasesDir, "*.cases.yaml", SearchOption.AllDirectories).OrderBy(f => f))
        {
            using var reader = new StreamReader(yamlFile);
            var yaml = new YamlStream();
            yaml.Load(reader);

            var root = (YamlMappingNode)yaml.Documents[0].RootNode;
            var suiteName = GetScalar(root, "suite") ?? Path.GetFileNameWithoutExtension(yamlFile);

            var casesNode = root.Children.ContainsKey("cases")
                ? (YamlSequenceNode)root["cases"]
                : null;
            if (casesNode == null) continue;

            var suiteFixture = GetScalar(root, "fixture");
            var suiteFixtures = GetStringList(root, "fixtures");

            foreach (YamlMappingNode caseNode in casesNode)
            {
                var caseName = GetScalar(caseNode, "name") ?? "unnamed";
                var caseId = $"{suiteName}::{caseName}";
                yield return new object[] { suiteName, caseName, caseId, caseNode, suiteFixture!, suiteFixtures! };
            }
        }
    }

    [Theory]
    [MemberData(nameof(LoadAllCases))]
    public void SharedCase(string suiteName, string caseName, string caseId, YamlMappingNode caseNode,
        string? suiteFixture, List<string>? suiteFixtures)
    {
        _output.WriteLine($"Running: {caseId}");

        var stopwatch = Stopwatch.StartNew();
        var status = "pass";
        string? errorDetail = null;
        var isXfail = TryGetDotnetXfail(caseNode, out var xfailDetail);

        try
        {
            if (IsOptionalForDotnet(caseNode))
            {
                status = "skip";
                errorDetail = "sdk_support.dotnet is optional";
                _output.WriteLine($"SKIP: Optional for dotnet: {caseId}");
                return;
            }

            var fixtures = ResolveFixtures(caseNode, suiteFixture, suiteFixtures);
            if (fixtures.Count == 0)
            {
                status = "skip";
                errorDetail = $"No fixtures for {caseId}";
                _output.WriteLine($"SKIP: No fixtures for {caseId}");
                return;
            }

            var expectedLoadErrorNode = GetExpectedLoadErrorNode(caseNode);
            var expectsAnyLoadError = string.Equals((expectedLoadErrorNode as YamlScalarNode)?.Value, "true", StringComparison.OrdinalIgnoreCase);
            var expectedLoadError = expectsAnyLoadError ? null : (expectedLoadErrorNode as YamlScalarNode)?.Value;
            var loadOnly = string.Equals(GetScalar(GetMapping(caseNode, "when") ?? new YamlMappingNode(), "action"), "load_config", StringComparison.Ordinal);

            var captured = new List<JsonElement>();
            var cannedGiven = GetMapping(caseNode, "given");
            var cannedResolvers = cannedGiven != null ? GetMapping(cannedGiven, "resolvers") : null;
            GuardrailsRuntime? rt = null;
            try
            {
                rt = CreateRuntime(fixtures, captured, cannedResolvers);
            }
            catch (Exception ex)
            {
                if (expectsAnyLoadError)
                    return;
                if (!string.IsNullOrEmpty(expectedLoadError))
                {
                    Assert.Contains(expectedLoadError, ex.ToString(), StringComparison.OrdinalIgnoreCase);
                    return;
                }

                throw;
            }

            if (expectsAnyLoadError)
            {
                if (!isXfail)
                    throw new XunitException($"[{caseId}] expected load error, but runtime loaded successfully");
                status = "xfail";
                return;
            }
            if (!string.IsNullOrEmpty(expectedLoadError))
            {
                if (!isXfail)
                    throw new XunitException($"[{caseId}] expected load error containing '{expectedLoadError}', but runtime loaded successfully");
                status = "xfail";
                return;
            }

            using var runtime = rt!;
            if (loadOnly)
                return;
            using var session = runtime.NewSession();

            try { session.BeginRequest(); } catch { }
            try { session.BeginTurn(); } catch { }

            var given = GetMapping(caseNode, "given");
            if (given != null)
            {
                var vars = GetMapping(given, "variables") ?? GetMapping(given, "attributes");
                if (vars != null)
                {
                    foreach (var kv in vars.Children)
                    {
                        var name = ((YamlScalarNode)kv.Key).Value!;
                        var value = YamlToObject(kv.Value);
                        session.SetVariable(name, ToJsonElement(value));
                    }
                }
            }

            if (caseNode.Children.ContainsKey("when") && caseNode.Children.ContainsKey("then"))
            {
                var when = (YamlMappingNode)caseNode["when"];
                var singleThen = (YamlMappingNode)caseNode["then"];
                var result = ExecuteAction(session, when);
                rt.FlushObservability();
                CheckAssertions(result, singleThen, caseId, session, captured);
                return;
            }

            if (caseNode.Children.ContainsKey("steps"))
            {
                var steps = (YamlSequenceNode)caseNode["steps"];
                for (var i = 0; i < steps.Children.Count; i++)
                {
                    var step = (YamlMappingNode)steps[i];
                    var stepName = $"{caseId}[step {i}]";
                    var when = (YamlMappingNode)step["when"];
                    var result = ExecuteAction(session, when);
                    rt.FlushObservability();

                    var expected = GetMapping(step, "then") ?? GetMapping(step, "expected");
                    if (expected != null)
                    {
                        CheckAssertions(result, expected, stepName, session, captured);
                    }
                }
            }
        }
        catch (UnknownActionException ex)
        {
            status = "unknown_action";
            errorDetail = ex.Message;
            _output.WriteLine($"UNKNOWN_ACTION: {ex.Message}");
        }
        catch (XunitException ex)
        {
            status = isXfail ? "xfail" : "fail";
            errorDetail = isXfail && !string.IsNullOrWhiteSpace(xfailDetail)
                ? $"{xfailDetail}{Environment.NewLine}{ex}"
                : ex.ToString();
            if (!isXfail) throw;
        }
        catch (Exception ex)
        {
            status = isXfail ? "xfail" : "error";
            errorDetail = isXfail && !string.IsNullOrWhiteSpace(xfailDetail)
                ? $"{xfailDetail}{Environment.NewLine}{ex}"
                : ex.ToString();
            if (!isXfail) throw;
        }
        finally
        {
            stopwatch.Stop();
            IntegrationCaseJsonReporter.Record(new IntegrationCaseResult(
                suiteName,
                caseName,
                status,
                stopwatch.Elapsed.TotalMilliseconds,
                errorDetail));
        }
    }

    private static List<string> ResolveFixtures(YamlMappingNode caseNode,
        string? suiteFixture, List<string>? suiteFixtures)
    {
        var given = GetMapping(caseNode, "given");

        var fixtureNames = given != null ? GetStringList(given, "fixtures") : null;

        if (fixtureNames == null || fixtureNames.Count == 0)
        {
            if (suiteFixtures != null && suiteFixtures.Count > 0)
            {
                fixtureNames = suiteFixtures;
            }
            else if (suiteFixture != null)
            {
                var scenarioDir = Path.Combine(FixturesDir, suiteFixture);
                if (Directory.Exists(scenarioDir))
                {
                    fixtureNames = Directory.GetFiles(scenarioDir, "*.guardrails.yaml")
                        .OrderBy(f => f)
                        .Select(Path.GetFileName)
                        .ToList()!;
                }
            }
        }

        if (fixtureNames == null) return new List<string>();
        var resolved = new List<string>();
        foreach (var name in fixtureNames)
        {
            var path = FindFixture(name);
            if (path == null) return new List<string>(); // any missing fixture → skip whole case
            resolved.Add(path);
        }
        return resolved;
    }

    private static YamlNode? GetExpectedLoadErrorNode(YamlMappingNode caseNode)
    {
        var then = GetMapping(caseNode, "then");
        if (then != null && then.Children.ContainsKey("expect_load_error"))
            return then["expect_load_error"];

        if (!caseNode.Children.ContainsKey("steps") || caseNode["steps"] is not YamlSequenceNode steps)
            return null;

        foreach (var child in steps.Children.OfType<YamlMappingNode>())
        {
            var expected = GetMapping(child, "then") ?? GetMapping(child, "expected");
            if (expected != null && expected.Children.ContainsKey("expect_load_error"))
                return expected["expect_load_error"];
        }

        return null;
    }

    private static bool IsOptionalForDotnet(YamlMappingNode caseNode)
    {
        var support = GetMapping(caseNode, "sdk_support");
        var dotnetSupport = support != null ? GetScalar(support, "dotnet") : null;
        return string.Equals(dotnetSupport, "optional", StringComparison.OrdinalIgnoreCase);
    }

    private static bool TryGetDotnetXfail(YamlMappingNode caseNode, out string? detail)
    {
        detail = null;
        var xfail = GetMapping(caseNode, "xfail");
        var dotnet = xfail != null ? GetMapping(xfail, "dotnet") : null;
        if (dotnet == null)
            return false;

        var issue = GetScalar(dotnet, "issue");
        var reason = GetScalar(dotnet, "reason");
        detail = string.Join("; ", new[]
        {
            !string.IsNullOrWhiteSpace(issue) ? $"issue={issue}" : null,
            !string.IsNullOrWhiteSpace(reason) ? $"reason={reason}" : null,
        }.Where(value => value != null)!);
        return true;
    }

    private static GuardrailsRuntime CreateRuntime(List<string> paths, List<JsonElement> captured, YamlMappingNode? cannedResolvers)
    {
        var builder = paths.Count == 1
            ? RuntimeBuilder.FromYaml(paths[0])
            : RuntimeBuilder.FromYamlChain(paths);
        try
        {
            builder.RegisterObservabilityProvider(new CaptureObservabilityProvider(captured));
            builder.RegisterLlmCaller(new AllowLlmCaller());
            builder.RegisterClassifierCaller(new AllowClassifierCaller());
            var canned = CannedResolverMap.FromYaml(cannedResolvers);
            builder.RegisterAgentResolver(new CannedAgentResolver(canned));
            builder.RegisterDelegateDispatcher(new CannedDelegateDispatcher(canned));
            return builder.Build();
        }
        catch
        {
            builder.Dispose();
            throw;
        }
    }

    private sealed class AllowLlmCaller : ILlmCaller
    {
        public LlmResponse Call(LlmRequest request) => LlmResponse.Allow();
    }

    private sealed class AllowClassifierCaller : IClassifierCaller
    {
        public ClassifierVerdict Call(LlmRequest request) =>
            new(Score: 0.0, Threshold: 0.5, Flagged: false);
    }

    private sealed class CannedResolverMap
    {
        private readonly Dictionary<string, YamlMappingNode> _entries;

        private CannedResolverMap(Dictionary<string, YamlMappingNode> entries)
        {
            _entries = entries;
        }

        public static CannedResolverMap FromYaml(YamlMappingNode? resolvers)
        {
            var dict = new Dictionary<string, YamlMappingNode>(StringComparer.Ordinal);
            if (resolvers != null)
            {
                foreach (var child in resolvers.Children)
                {
                    if (child.Key is YamlScalarNode key && child.Value is YamlMappingNode value && key.Value != null)
                    {
                        dict[key.Value] = value;
                    }
                }
            }
            return new CannedResolverMap(dict);
        }

        public ResolverResponse Lookup(string kind, string? variable, string? prompt)
        {
            YamlMappingNode? entry = null;
            if (variable != null && _entries.TryGetValue(variable, out var byVar))
            {
                entry = byVar;
            }
            if (entry == null && prompt != null)
            {
                foreach (var kv in _entries)
                {
                    if (string.Equals(GetScalar(kv.Value, "prompt"), prompt, StringComparison.Ordinal))
                    {
                        entry = kv.Value;
                        break;
                    }
                }
            }
            if (entry == null && _entries.Count == 1)
            {
                entry = _entries.Values.First();
            }
            if (entry == null)
            {
                return ResolverResponse.DenyWith($"{kind} resolver: no canned response (variable={variable})");
            }

            var decisionStr = GetScalar(entry, "decision") ?? "deny";
            ResolverDecision decision = decisionStr switch
            {
                "allow" => ResolverDecision.Allow,
                "cancelled" or "cancel" => ResolverDecision.Cancelled,
                _ => ResolverDecision.Deny,
            };
            JsonElement? value = null;
            if (entry.Children.ContainsKey(new YamlScalarNode("value")))
            {
                value = YamlToJsonElement(entry["value"]);
            }
            IReadOnlyDictionary<string, JsonElement>? setVars = null;
            var setVarsNode = GetMapping(entry, "set_variables");
            if (setVarsNode != null)
            {
                var sv = new Dictionary<string, JsonElement>(StringComparer.Ordinal);
                foreach (var kv in setVarsNode.Children)
                {
                    if (kv.Key is YamlScalarNode k && k.Value != null)
                    {
                        sv[k.Value] = YamlToJsonElement(kv.Value);
                    }
                }
                setVars = sv;
            }
            var reason = GetScalar(entry, "reason");
            return new ResolverResponse(decision, value, setVars, reason);
        }

        private static JsonElement YamlToJsonElement(YamlNode node)
        {
            return JsonDocument.Parse(JsonSerializer.Serialize(YamlToObject(node))).RootElement.Clone();
        }
    }

    private sealed class CannedAgentResolver : IAgentResolver
    {
        private readonly CannedResolverMap _canned;
        public CannedAgentResolver(CannedResolverMap canned) { _canned = canned; }
        public ResolverResponse Resolve(ResolverRequest request) =>
            _canned.Lookup("agent", request.Variable, request.Prompt);
    }

    private sealed class CannedDelegateDispatcher : IDelegateDispatcher
    {
        private readonly CannedResolverMap _canned;
        public CannedDelegateDispatcher(CannedResolverMap canned) { _canned = canned; }
        public ResolverResponse Dispatch(DelegateRequest request) =>
            _canned.Lookup("delegate", request.Base.Variable, request.Base.Prompt);
    }

    private sealed class CaptureObservabilityProvider : IObservabilityProvider
    {
        private readonly List<JsonElement> _captured;

        public CaptureObservabilityProvider(List<JsonElement> captured)
        {
            _captured = captured;
        }

        public void OnLogEvent(JsonElement eventJson)
        {
            lock (_captured)
            {
                _captured.Add(eventJson);
            }
        }
    }

    private static JsonElement[] SnapshotCaptured(List<JsonElement> captured)
    {
        lock (captured)
        {
            return captured.ToArray();
        }
    }

    private object? ExecuteAction(GuardrailsSession session, YamlMappingNode when)
    {
        var actionType = GetScalar(when, "action") ?? GetScalar(when, "type")
            ?? throw new InvalidOperationException("No action type in 'when' block");
        var paramsNode = GetMapping(when, "params");

        switch (actionType)
        {
            case "validate_input":
            {
                var text = GetScalar(when, "input") ?? GetScalarFromParams(paramsNode, "input") ?? "";
                return session.ValidateInput(text);
            }
            case "validate_tool_call":
            {
                var toolName = GetScalar(when, "tool_name") ?? GetScalarFromParams(paramsNode, "tool_name") ?? "";
                var toolParams = GetDictFromParams(paramsNode, "tool_params")
                    ?? YamlToDict(GetMapping(when, "tool_params"));
                var toolCallId = GetScalar(when, "tool_call_id")
                    ?? GetScalarFromParams(paramsNode, "tool_call_id")
                    ?? "case_invocation";
                var (verdict, _) = session.ValidateToolCall(toolName, ToJsonElement(toolParams), toolCallId);
                return verdict;
            }
            case "validate_endpoint_call":
            {
                var url = GetScalar(when, "url") ?? GetScalar(when, "path")
                    ?? GetScalarFromParams(paramsNode, "path")
                    ?? GetScalarFromParams(paramsNode, "url") ?? "";
                var method = GetScalar(when, "method") ?? GetScalarFromParams(paramsNode, "method") ?? "GET";
                var queryParams = GetDictFromParams(paramsNode, "query_params");
                var toolCallId = GetScalar(when, "tool_call_id")
                    ?? GetScalarFromParams(paramsNode, "tool_call_id")
                    ?? "case_invocation";
                var (verdict, _) = session.ValidateEndpointCall(method, url, ToJsonElement(queryParams), toolCallId);
                return verdict;
            }
            case "validate_output":
            {
                var text = GetScalar(when, "output") ?? GetScalarFromParams(paramsNode, "output") ?? "";
                var (verdict, response) = session.ValidateOutput(text);
                return new OutputCarrier(verdict, response);
            }
            case "validate_tool_output":
            {
                var toolName = GetScalar(when, "tool_name") ?? GetScalarFromParams(paramsNode, "tool_name") ?? "unknown_tool";
                var text = GetScalar(when, "output") ?? GetScalarFromParams(paramsNode, "output") ?? "";
                var toolCallId = GetScalar(when, "tool_call_id")
                    ?? GetScalarFromParams(paramsNode, "tool_call_id")
                    ?? "case_invocation";
                var prebindParams = GetDictFromParams(paramsNode, "tool_params")
                    ?? YamlToDict(GetMapping(when, "tool_params"))
                    ?? new Dictionary<string, object?>();
                var (_, _, admissionId) = session.ValidateToolCall(toolName, ToJsonElement(prebindParams), toolCallId);
                var (verdict, mutated) = session.ValidateToolOutput(admissionId!.Value, ToJsonElement(text));
                var textOut = mutated.ValueKind == JsonValueKind.String
                    ? mutated.GetString() ?? ""
                    : mutated.GetRawText();
                return new OutputCarrier(verdict, textOut);
            }
            case "set_attribute":
            case "set_variable":
            {
                var name = GetScalar(when, "name") ?? GetScalarFromParams(paramsNode, "name") ?? "";
                var value = GetValueFromParams(paramsNode, "value") ?? YamlToObject(when.Children.ContainsKey("value") ? when["value"] : new YamlScalarNode(""));
                session.SetVariable(name, ToJsonElement(value));
                return null;
            }
            case "reset_variable":
            {
                var name = GetScalar(when, "name") ?? GetScalarFromParams(paramsNode, "name") ?? "";
                session.ResetVariable(name);
                return null;
            }
            case "emit_event":
            {
                var eventId = GetScalar(when, "event") ?? GetScalar(when, "event_id") ?? GetScalar(when, "id")
                    ?? GetScalarFromParams(paramsNode, "event")
                    ?? GetScalarFromParams(paramsNode, "event_id")
                    ?? GetScalarFromParams(paramsNode, "id") ?? "";
                Lifetime? lifetime = null;
                if (paramsNode != null && paramsNode.Children.ContainsKey("lifetime"))
                {
                    var ltObj = YamlToObject(paramsNode["lifetime"]);
                    if (ltObj is string ltStr)
                    {
                        lifetime = Lifetime.FromJson(JsonSerializer.Serialize(ltStr));
                    }
                    else if (ltObj != null)
                    {
                        lifetime = Lifetime.FromJson(JsonSerializer.Serialize(ltObj));
                    }
                }
                session.EmitEvent(eventId, lifetime);
                return null;
            }
            case "clear_event":
            {
                var eventId = GetScalar(when, "event") ?? GetScalar(when, "event_id") ?? GetScalar(when, "id")
                    ?? GetScalarFromParams(paramsNode, "event")
                    ?? GetScalarFromParams(paramsNode, "event_id")
                    ?? GetScalarFromParams(paramsNode, "id") ?? "";
                session.ClearEvent(eventId);
                return null;
            }
            case "emit_incident":
            {
                var name = GetScalar(when, "name") ?? GetScalarFromParams(paramsNode, "name") ?? "";
                session.EmitIncident(name);
                return null;
            }
            case "begin_turn":
            {
                session.BeginTurn();
                return null;
            }
            case "end_turn":
            {
                session.EndTurn();
                return null;
            }
            case "begin_request":
            {
                session.BeginRequest();
                return null;
            }
            case "end_request":
            {
                session.EndRequest();
                return null;
            }
            case "close_session":
            {
                session.Dispose();
                return null;
            }
            case "get_active_states":
            {
                _output.WriteLine($"SKIP: get_active_states (not on .NET surface)");
                return null;
            }
            case "load_config":
                return null;
            case "resolve_variable":
            {
                var name = GetScalar(when, "name") ?? GetScalarFromParams(paramsNode, "name") ?? "";
                var result = session.ResolveVariable(name);
                return result;
            }
            case "record_tool_success":
            {
                var toolName = GetScalar(when, "tool_name") ?? GetScalarFromParams(paramsNode, "tool_name") ?? "";
                var resultVal = GetValueFromParams(paramsNode, "result") ?? YamlToObject(
                    when.Children.ContainsKey("result") ? when["result"] : new YamlScalarNode(""));
                session.RecordToolSuccess(toolName, ToJsonElement(resultVal));
                return null;
            }
            case "record_tool_failure":
            {
                var toolName = GetScalar(when, "tool_name") ?? GetScalarFromParams(paramsNode, "tool_name") ?? "";
                var error = GetScalar(when, "error") ?? GetScalarFromParams(paramsNode, "error") ?? "";
                session.RecordToolFailure(toolName, error);
                return null;
            }
            case "validate_agent_call":
            {
                var agentName = GetScalar(when, "agent_name") ?? GetScalarFromParams(paramsNode, "agent_name") ?? "";
                var agentParams = GetDictFromParams(paramsNode, "agent_params")
                    ?? YamlToDict(GetMapping(when, "agent_params"));
                var toolCallId = GetScalar(when, "tool_call_id")
                    ?? GetScalarFromParams(paramsNode, "tool_call_id")
                    ?? "case_invocation";
                var (verdict, _) = session.ValidateAgentCall(agentName, ToJsonElement(agentParams), toolCallId);
                return verdict;
            }
            default:
                throw new UnknownActionException(actionType);
        }
    }

    private sealed record OutputCarrier(StageVerdict Verdict, string Text);

    private void CheckAssertions(object? result, YamlMappingNode expected, string caseId,
        GuardrailsSession session, List<JsonElement> captured)
    {
        string? outputText = null;
        if (result is OutputCarrier carrier)
        {
            outputText = carrier.Text;
            if (expected.Children.ContainsKey("passed"))
            {
                var expectedPassed = bool.Parse(GetScalar(expected, "passed")!);
                Assert.True(carrier.Verdict.Allowed == expectedPassed,
                    $"[{caseId}] expected passed={expectedPassed}, got {carrier.Verdict.Allowed}");
            }
            result = carrier.Verdict;
        }

        if (result is StageVerdict vr)
        {
            if (expected.Children.ContainsKey("allowed"))
            {
                var expectedAllowed = bool.Parse(GetScalar(expected, "allowed")!);
                Assert.True(vr.Allowed == expectedAllowed,
                    $"[{caseId}] expected allowed={expectedAllowed}, got {vr.Allowed}");
            }

            if (expected.Children.ContainsKey("expect_verdict_action"))
            {
                var expAction = GetScalar(expected, "expect_verdict_action")!;
                Assert.True(vr.Action == expAction,
                    $"[{caseId}] expected action={expAction}, got {vr.Action}");
            }

            if (expected.Children.ContainsKey("action"))
            {
                var expAction = GetScalar(expected, "action")!;
                var matches = vr.Action == expAction ||
                    ((vr.Action == "block" || vr.Action == "block_once") && (expAction == "require_approval" || expAction == "require_approval_always"));
                Assert.True(matches,
                    $"[{caseId}] expected action={expAction}, got {vr.Action}");
            }

            if (expected.Children.ContainsKey("expect_verdict_reason"))
            {
                var expectedReason = GetScalar(expected, "expect_verdict_reason")!;
                Assert.Contains(expectedReason, vr.Reason ?? "",
                    StringComparison.OrdinalIgnoreCase);
            }

            if (expected.Children.ContainsKey("reason_contains"))
            {
                var expectedReason = GetScalar(expected, "reason_contains")!;
                Assert.Contains(expectedReason, vr.Reason ?? "",
                    StringComparison.OrdinalIgnoreCase);
            }

            if (expected.Children.ContainsKey("expect_verdict_policy"))
            {
                var expectedPolicy = GetScalar(expected, "expect_verdict_policy")!;
                Assert.True(vr.Policy == expectedPolicy,
                    $"[{caseId}] expected policy={expectedPolicy}, got {vr.Policy}");
            }

            if (expected.Children.ContainsKey("text_contains"))
            {
                var text = outputText ?? vr.Redaction ?? vr.Reason ?? "";
                var expectedContains = GetScalar(expected, "text_contains")!;
                Assert.Contains(expectedContains, text);
            }

            if (expected.Children.ContainsKey("text_not_contains"))
            {
                var text = outputText ?? vr.Redaction ?? vr.Reason ?? "";
                var items = GetStringListOrScalar(expected, "text_not_contains");
                foreach (var item in items)
                {
                    Assert.DoesNotContain(item, text);
                }
            }
        }

        if (expected.Children.ContainsKey("expect_variable_status"))
        {
            var cfg = (YamlMappingNode)expected["expect_variable_status"];
            var name = GetScalar(cfg, "name")!;
            var wantStatus = GetScalar(cfg, "status")!;
            var state = session.ReadVariable(name);
            var actualStatus = state?.Status.ToString().ToLowerInvariant() ?? "unset";
            Assert.True(actualStatus == wantStatus,
                $"[{caseId}] expected variable {name} status={wantStatus}, got {actualStatus}");
        }

        if (expected.Children.ContainsKey("expect_variable_value"))
        {
            var cfg = (YamlMappingNode)expected["expect_variable_value"];
            var name = GetScalar(cfg, "name")!;
            var expectedValue = ToJsonElement(YamlToObject(cfg["value"]));
            var state = session.ReadVariable(name);
            var actualValue = state?.Value ?? ToJsonElement(null);
            Assert.True(JsonElement.DeepEquals(actualValue, expectedValue),
                $"[{caseId}] expected variable {name} value={expectedValue.GetRawText()}, got {actualValue.GetRawText()}");
        }

        if (expected.Children.ContainsKey("expect_event_fired"))
        {
            var eventId = GetScalar(expected, "expect_event_fired")!;
            var events = SnapshotCaptured(captured);
            Assert.True(events.Any(ev => EventIdMatches(ev, eventId)),
                $"[{caseId}] expected event '{eventId}' to be fired");
        }

        if (expected.Children.ContainsKey("expect_event_not_fired"))
        {
            var eventId = GetScalar(expected, "expect_event_not_fired")!;
            var events = SnapshotCaptured(captured);
            Assert.False(events.Any(ev => EventIdMatches(ev, eventId)),
                $"[{caseId}] expected event '{eventId}' NOT to be fired");
        }

        if (result is IReadOnlyList<string> states)
        {
            var statesCfg = GetMapping(expected, "active_states");
            if (statesCfg != null)
            {
                foreach (var s in GetStringList(statesCfg, "includes") ?? new List<string>())
                    Assert.Contains(s, states);
                foreach (var s in GetStringList(statesCfg, "excludes") ?? new List<string>())
                    Assert.DoesNotContain(s, states);
            }

            foreach (var s in GetStringListOrScalar(expected, "active_states_includes"))
                Assert.Contains(s, states);
            foreach (var s in GetStringListOrScalar(expected, "active_states_excludes"))
                Assert.DoesNotContain(s, states);
        }
    }

    private static bool EventIdMatches(JsonElement eventJson, string expectedId)
    {
        if (eventJson.ValueKind != JsonValueKind.Object) return false;
        if (eventJson.TryGetProperty("event_id", out var eventIdProp) &&
            eventIdProp.ValueKind == JsonValueKind.String &&
            eventIdProp.GetString() == expectedId)
            return true;

        if (eventJson.TryGetProperty("attributes", out var attrs) &&
            attrs.ValueKind == JsonValueKind.Object &&
            attrs.TryGetProperty("agent_shield.event.id", out var attrId) &&
            attrId.ValueKind == JsonValueKind.String)
            return attrId.GetString() == expectedId;

        return false;
    }

    private static string? GetScalar(YamlMappingNode node, string key)
    {
        if (node.Children.ContainsKey(key) && node[key] is YamlScalarNode scalar)
            return scalar.Value;
        return null;
    }

    private static string? GetScalarFromParams(YamlMappingNode? paramsNode, string key)
    {
        if (paramsNode == null) return null;
        return GetScalar(paramsNode, key);
    }

    private static object? GetValueFromParams(YamlMappingNode? paramsNode, string key)
    {
        if (paramsNode == null || !paramsNode.Children.ContainsKey(key)) return null;
        return YamlToObject(paramsNode[key]);
    }

    private static YamlMappingNode? GetMapping(YamlMappingNode node, string key)
    {
        if (node.Children.ContainsKey(key) && node[key] is YamlMappingNode mapping)
            return mapping;
        return null;
    }

    private static List<string>? GetStringList(YamlMappingNode node, string key)
    {
        if (!node.Children.ContainsKey(key)) return null;
        if (node[key] is YamlSequenceNode seq)
            return seq.Children.Select(c => ((YamlScalarNode)c).Value!).ToList();
        return null;
    }

    private static List<string> GetStringListOrScalar(YamlMappingNode node, string key)
    {
        if (!node.Children.ContainsKey(key)) return new List<string>();
        if (node[key] is YamlSequenceNode seq)
            return seq.Children.Select(c => ((YamlScalarNode)c).Value!).ToList();
        if (node[key] is YamlScalarNode scalar && scalar.Value != null)
            return new List<string> { scalar.Value };
        return new List<string>();
    }

    private static Dictionary<string, object?>? GetDictFromParams(YamlMappingNode? paramsNode, string key)
    {
        if (paramsNode == null || !paramsNode.Children.ContainsKey(key)) return null;
        if (paramsNode[key] is YamlMappingNode map)
            return YamlToDict(map);
        return null;
    }

    private static Dictionary<string, object?>? YamlToDict(YamlMappingNode? node)
    {
        if (node == null) return null;
        var dict = new Dictionary<string, object?>();
        foreach (var kv in node.Children)
        {
            var k = ((YamlScalarNode)kv.Key).Value!;
            dict[k] = YamlToObject(kv.Value);
        }
        return dict;
    }

    private static object? YamlToObject(YamlNode node)
    {
        switch (node)
        {
            case YamlScalarNode scalar:
                if (scalar.Value == null || scalar.Value == "null" || scalar.Value == "~")
                    return null;
                if (bool.TryParse(scalar.Value, out var b)) return b;
                if (long.TryParse(scalar.Value, out var l)) return l;
                if (double.TryParse(scalar.Value, out var d) && scalar.Value.Contains('.'))
                    return d;
                return scalar.Value;

            case YamlSequenceNode seq:
                return seq.Children.Select(YamlToObject).ToList();

            case YamlMappingNode map:
                return YamlToDict(map);

            default:
                return node.ToString();
        }
    }

    private static JsonElement ToJsonElement(object? value)
    {
        var json = value == null
            ? "null"
            : JsonSerializer.Serialize(value);
        return JsonDocument.Parse(json).RootElement.Clone();
    }
}

public sealed class IntegrationCaseReportFixture : IDisposable
{
    public void Dispose()
    {
        IntegrationCaseJsonReporter.WriteIfConfigured();
    }
}

internal static class IntegrationCaseJsonReporter
{
    private static readonly string DotnetSdkVersion = typeof(IntegrationCaseJsonReporter).Assembly.GetName().Version?.ToString(3) ?? "0.0.0";
    private static readonly string CoreVersion = Environment.GetEnvironmentVariable("AGENT_SHIELD_CORE_VERSION") ?? DotnetSdkVersion;
    private static readonly ConcurrentBag<IntegrationCaseResult> Results = new();
    private static int _written;

    public static void Record(IntegrationCaseResult result)
    {
        Results.Add(result);
    }

    public static void WriteIfConfigured()
    {
        if (Interlocked.Exchange(ref _written, 1) != 0)
            return;

        var reportPath = Environment.GetEnvironmentVariable("AGENT_SHIELD_REPORT_JSON");
        if (string.IsNullOrWhiteSpace(reportPath))
            return;

        var directory = Path.GetDirectoryName(reportPath);
        if (!string.IsNullOrWhiteSpace(directory))
            Directory.CreateDirectory(directory);

        var payload = new IntegrationCaseReport(
            "dotnet",
            DotnetSdkVersion,
            CoreVersion,
            DateTime.UtcNow,
            Results.OrderBy(result => result.Suite, StringComparer.Ordinal)
                .ThenBy(result => result.Case, StringComparer.Ordinal)
                .ToArray());

        var json = JsonSerializer.Serialize(payload, new JsonSerializerOptions
        {
            WriteIndented = true,
        });

        File.WriteAllText(reportPath, json);
    }
}

internal sealed class UnknownActionException : Exception
{
    public UnknownActionException(string actionType)
        : base($"Unrecognized action: {actionType}")
    {
    }
}

internal sealed record IntegrationCaseReport(
    [property: JsonPropertyName("sdk")] string Sdk,
    [property: JsonPropertyName("sdk_version")] string SdkVersion,
    [property: JsonPropertyName("core_version")] string CoreVersion,
    [property: JsonPropertyName("timestamp")] DateTime Timestamp,
    [property: JsonPropertyName("results")] IReadOnlyList<IntegrationCaseResult> Results);

internal sealed record IntegrationCaseResult(
    [property: JsonPropertyName("suite")] string Suite,
    [property: JsonPropertyName("case")] string Case,
    [property: JsonPropertyName("status")] string Status,
    [property: JsonPropertyName("duration_ms")] double DurationMs,
    [property: JsonPropertyName("error_detail")] string? ErrorDetail);
