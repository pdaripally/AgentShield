using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using System;
using AgentShield;
using Microsoft.SemanticKernel;
using Xunit;
using static AgentShield.Tests.Support.JsonTest;

namespace AgentShield.Tests;

public class ContractPendingResolutionTests
{
    private static string ContractFixturesDir
    {
        get
        {
            var dir = AppContext.BaseDirectory;
            while (dir != null && !Directory.Exists(Path.Combine(dir, "tests", "fixtures", "contract")))
            {
                dir = Directory.GetParent(dir)?.FullName;
            }
            if (dir == null)
                throw new DirectoryNotFoundException(
                    "Could not locate tests/fixtures/contract — has the canonical " +
                    "pending_resolution fixture moved?");
            return Path.Combine(dir, "tests", "fixtures", "contract");
        }
    }

    private static string PendingResolutionFixture =>
        Path.Combine(ContractFixturesDir, "pending_resolution.guardrails.yaml");

    private static void AssertNoPending(PendingResolution? pending)
    {
        Assert.Null(pending);
    }


    [Fact]
    public void DotnetDirect_ValidateToolCall_CarriesPendingResolution()
    {
        using var rt = GuardrailsRuntime.FromYaml(PendingResolutionFixture);
        using var session = rt.NewSession();

        var (verdict, _, _) = session.ValidateToolCall(
            "send_email",
            Parse("{\"to\":\"alice@example.com\",\"subject\":\"Hi\"}"),
            "contract-1");

        Assert.False(verdict.Allowed,
            "kind: human gate must block until the human's answer is written back");
        AssertNoPending(verdict.PendingResolution);
    }

    [Fact]
    public void DotnetDirect_SetVariable_ClearsPendingResolution()
    {
        using var rt = GuardrailsRuntime.FromYaml(PendingResolutionFixture);
        using var session = rt.NewSession();

        var (blocked, _, _) = session.ValidateToolCall(
            "send_email",
            Parse("{\"to\":\"alice@example.com\"}"),
            "contract-2a");
        Assert.False(blocked.Allowed);
        AssertNoPending(blocked.PendingResolution);

        session.SetVariable("send_email_approved", Parse("true"));

        var (allowed, _, _) = session.ValidateToolCall(
            "send_email",
            Parse("{\"to\":\"alice@example.com\"}"),
            "contract-2b");
        Assert.True(allowed.Allowed,
            "after set_variable writes the human's answer, the gate must pass");
        Assert.Null(allowed.PendingResolution);
    }

    [Fact]
    public async Task DotnetSemanticKernel_Filter_SurfacesPendingResolution()
    {

        using var shield = Shield.FromYaml(PendingResolutionFixture).Build();
        PendingResolution? sinkCapture = null;
        var filter = new global::AgentShield.SemanticKernel.AgentShieldFilter(
            shield,
            pendingResolutionSink: pr => sinkCapture = pr);

        var kernel = global::Microsoft.SemanticKernel.Kernel.CreateBuilder().Build();
        var function = global::Microsoft.SemanticKernel.KernelFunctionFactory.CreateFromMethod(
            (string to) => $"sent to {to}",
            functionName: "send_email");
        var args = new global::Microsoft.SemanticKernel.KernelArguments
        {
            ["to"] = "alice@example.com",
        };

        var initialResult = new global::Microsoft.SemanticKernel.FunctionResult(function, "initial");
        var chatHistory = new global::Microsoft.SemanticKernel.ChatCompletion.ChatHistory();
        var assistantMsg = new global::Microsoft.SemanticKernel.ChatMessageContent(
            global::Microsoft.SemanticKernel.ChatCompletion.AuthorRole.Assistant, "test");
        var ctx = new global::Microsoft.SemanticKernel.AutoFunctionInvocationContext(
            kernel, function, initialResult, chatHistory, assistantMsg)
        {
            Arguments = args,
        };

        var nextCalled = false;
        await filter.OnAutoFunctionInvocationAsync(
            ctx, _ => { nextCalled = true; return Task.CompletedTask; });

        Assert.False(nextCalled,
            "filter must short-circuit the tool invocation when the verdict denies");
        Assert.True(ctx.Terminate,
            "filter must set context.Terminate=true on a Stage 2/3 deny");

        AssertNoPending(shield.LastPendingResolution());

        AssertNoPending(sinkCapture);

        if (ctx.Result.Metadata != null)
            Assert.False(ctx.Result.Metadata.ContainsKey("agent_shield.pending_resolution"));
    }

    [Fact]
    public async Task DotnetSemanticKernel_Filter_LastPendingResolutionIsNonDestructive()
    {

        using var shield = Shield.FromYaml(PendingResolutionFixture).Build();
        var filter = new global::AgentShield.SemanticKernel.AgentShieldFilter(shield);

        var kernel = global::Microsoft.SemanticKernel.Kernel.CreateBuilder().Build();
        var function = global::Microsoft.SemanticKernel.KernelFunctionFactory.CreateFromMethod(
            (string to) => $"sent to {to}",
            functionName: "send_email");
        var args = new global::Microsoft.SemanticKernel.KernelArguments
        {
            ["to"] = "alice@example.com",
        };

        var ctx1 = new global::Microsoft.SemanticKernel.AutoFunctionInvocationContext(
            kernel, function,
            new global::Microsoft.SemanticKernel.FunctionResult(function, "initial"),
            new global::Microsoft.SemanticKernel.ChatCompletion.ChatHistory(),
            new global::Microsoft.SemanticKernel.ChatMessageContent(
                global::Microsoft.SemanticKernel.ChatCompletion.AuthorRole.Assistant, "test"))
        {
            Arguments = args,
        };
        await filter.OnAutoFunctionInvocationAsync(ctx1, _ => Task.CompletedTask);

        var first = shield.LastPendingResolution();
        var second = shield.LastPendingResolution();
        var third = shield.LastPendingResolution();
        AssertNoPending(first);
        AssertNoPending(second);
        AssertNoPending(third);
    }
}

public class HumanResolverParityTests
{
    private static readonly JsonElement TrueValue =
        JsonDocument.Parse("true").RootElement.Clone();

    private static string TempYaml(string body, string slug)
    {
        var dir = Path.Combine(Path.GetTempPath(), $"as-dotnet-{slug}-{Guid.NewGuid():N}");
        Directory.CreateDirectory(dir);
        var p = Path.Combine(dir, "guardrails.yaml");
        File.WriteAllText(p, body);
        return p;
    }

    private static void Cleanup(string yamlPath)
    {
        try { Directory.Delete(Path.GetDirectoryName(yamlPath)!, recursive: true); }
        catch { /* best-effort */ }
    }

    private const string ApprovalYaml = @"
metadata:
  name: ""human-resolver-parity""
  version: ""0.1.0""
  agent_shield_version: ""2.0""

objective:
  goal: [""gate send_email behind a host-supplied human approver""]
  forbidden: []

resources:
  tools:
    - name: ""send_email""
      description: ""send email""
      permission: ""execute""

variables:
  - name: ""send_email_authorized""
    type: ""boolean""
    on_demand_by:
      kind: ""human""
      prompt: ""Approve sending email to ${@tool.params.to}?""
      timeout_ms: 60000
    lifetime: ""per_session""

state_validation:
  guard_policies:
    - name: ""send_email_requires_approval""
      applies_to:
        tools: [""send_email""]
      evaluate_when:
        - expression: ""send_email_authorized == true""
          reason: ""Sending email requires explicit user confirmation""
      action: ""block""
";

    [Fact]
    public void Approver_AllowsSynchronously_GatePassesAndCallbackFires()
    {
        var yamlPath = TempYaml(ApprovalYaml, "approve");
        var observed = new List<HumanResolveRequest>();
        try
        {
            using var shield = Shield.FromYaml(yamlPath)
                .WithHumanResolver(new CapturingApprover(observed))
                .Build();

            var session = shield.Session;
            session.BeginTurn();
            try
            {
                var paramsDoc = JsonDocument.Parse("{\"to\":\"alice@example.com\"}");
                var outcome = session.ValidateToolCall(
                    "send_email", paramsDoc.RootElement, "tc-1");
                Assert.True(outcome.Verdict.Allowed,
                    $"synchronous approver returning allow should let the gate pass; reason={outcome.Verdict.Reason}");
                Assert.Null(outcome.Verdict.PendingResolution);
            }
            finally
            {
                session.EndTurn();
            }
        }
        finally { Cleanup(yamlPath); }

        Assert.Single(observed);
        var req = observed[0];
        Assert.Equal("send_email_authorized", req.Variable);
        Assert.NotNull(req.Prompt);
        Assert.Contains("alice@example.com", req.Prompt!, StringComparison.Ordinal);
        Assert.False(string.IsNullOrEmpty(req.ApprovalNonce));
        Assert.True(req.ApprovalNonce.Length >= 8);
        Assert.Equal(60000, req.TimeoutMs);
    }

    [Fact]
    public void Denier_BlocksGate_ReasonSurfaces()
    {
        var yamlPath = TempYaml(ApprovalYaml, "deny");
        try
        {
            using var shield = Shield.FromYaml(yamlPath)
                .WithHumanResolver(new FixedDecisionResolver(ResolverResponse.DenyWith("user clicked Reject")))
                .Build();

            var session = shield.Session;
            session.BeginTurn();
            try
            {
                var paramsDoc = JsonDocument.Parse("{\"to\":\"alice@example.com\"}");
                var outcome = session.ValidateToolCall(
                    "send_email", paramsDoc.RootElement, "tc-1");
                Assert.False(outcome.Verdict.Allowed,
                    "deny envelope must block the gate");
            }
            finally
            {
                session.EndTurn();
            }
        }
        finally { Cleanup(yamlPath); }
    }

    [Fact]
    public void CancelledResponse_BlocksGate()
    {
        var yamlPath = TempYaml(ApprovalYaml, "cancel");
        try
        {
            using var shield = Shield.FromYaml(yamlPath)
                .WithHumanResolver(new FixedDecisionResolver(ResolverResponse.CancelledWith("user closed dialog")))
                .Build();

            var session = shield.Session;
            session.BeginTurn();
            try
            {
                var paramsDoc = JsonDocument.Parse("{\"to\":\"alice@example.com\"}");
                var outcome = session.ValidateToolCall(
                    "send_email", paramsDoc.RootElement, "tc-1");
                Assert.False(outcome.Verdict.Allowed,
                    "cancelled envelope must block the gate");
            }
            finally
            {
                session.EndTurn();
            }
        }
        finally { Cleanup(yamlPath); }
    }

    [Fact]
    public void CallbackThatThrows_GateBlocks_DoesNotCrashFFI()
    {
        var yamlPath = TempYaml(ApprovalYaml, "throw");
        try
        {
            using var shield = Shield.FromYaml(yamlPath)
                .WithHumanResolver(new ThrowingResolver("simulated host failure"))
                .Build();

            var session = shield.Session;
            session.BeginTurn();
            try
            {
                var paramsDoc = JsonDocument.Parse("{\"to\":\"alice@example.com\"}");
                var outcome = session.ValidateToolCall(
                    "send_email", paramsDoc.RootElement, "tc-1");
                Assert.False(outcome.Verdict.Allowed,
                    "exception in host callback must fail closed via the FFI deny path");
            }
            finally
            {
                session.EndTurn();
            }
        }
        finally { Cleanup(yamlPath); }
    }

    [Fact]
    public void RuntimeBuilder_RegisterHumanResolver_DirectSurface_Works()
    {
        var yamlPath = TempYaml(ApprovalYaml, "runtime");
        var observed = new List<HumanResolveRequest>();
        try
        {
            using var rt = RuntimeBuilder.FromYaml(yamlPath)
                .RegisterHumanResolver(new CapturingApprover(observed))
                .Build();
            using var session = rt.NewSession();
            session.BeginTurn();
            try
            {
                var paramsDoc = JsonDocument.Parse("{\"to\":\"bob@example.com\"}");
                var outcome = session.ValidateToolCall(
                    "send_email", paramsDoc.RootElement, "tc-1");
                Assert.True(outcome.Verdict.Allowed,
                    $"approver should let the gate pass; reason={outcome.Verdict.Reason}");
            }
            finally
            {
                session.EndTurn();
            }
        }
        finally { Cleanup(yamlPath); }

        Assert.Single(observed);
        Assert.Equal("send_email_authorized", observed[0].Variable);
        Assert.Contains("bob@example.com", observed[0].Prompt!, StringComparison.Ordinal);
    }

    [Fact]
    public void RegisterHumanResolver_NullArgument_Throws()
    {
        var yamlPath = TempYaml(ApprovalYaml, "argcheck");
        try
        {
            using var rt = RuntimeBuilder.FromYaml(yamlPath);
            Assert.Throws<ArgumentNullException>(() =>
                rt.RegisterHumanResolver(null!));
        }
        finally { Cleanup(yamlPath); }
    }

    [Fact]
    public void MissingHumanResolver_FailsClosed()
    {
        var yamlPath = TempYaml(ApprovalYaml, "missing");
        try
        {
            using var shield = Shield.FromYaml(yamlPath).Build();
            var session = shield.Session;
            session.BeginTurn();
            try
            {
                var outcome = session.ValidateToolCall(
                    "send_email", JsonDocument.Parse("{\"to\":\"alice@example.com\"}").RootElement, "tc-1");
                Assert.False(outcome.Verdict.Allowed);
                Assert.Null(outcome.Verdict.PendingResolution);
            }
            finally { session.EndTurn(); }
        }
        finally { Cleanup(yamlPath); }
    }

    [Fact]
    public void HumanProviderField_IsRejectedAtLoadTime()
    {
        var yamlPath = TempYaml(ApprovalYaml.Replace("      prompt:", "      provider: auto_reject\n      prompt:"), "provider-rejected");
        try
        {
            var ex = Assert.Throws<AgentShieldConfigException>(() => RuntimeBuilder.FromYaml(yamlPath));
            Assert.Contains("provider", ex.Message, StringComparison.OrdinalIgnoreCase);
            Assert.Contains("not allowed", ex.Message, StringComparison.OrdinalIgnoreCase);
        }
        finally { Cleanup(yamlPath); }
    }

    [Fact]
    public void HumanNameField_IsRejectedAtLoadTime()
    {
        var yamlPath = TempYaml(ApprovalYaml.Replace("      prompt:", "      name: approval_cb\n      prompt:"), "name-rejected");
        try
        {
            var ex = Assert.Throws<AgentShieldConfigException>(() => RuntimeBuilder.FromYaml(yamlPath));
            Assert.Contains("name", ex.Message, StringComparison.OrdinalIgnoreCase);
            Assert.Contains("not allowed", ex.Message, StringComparison.OrdinalIgnoreCase);
        }
        finally { Cleanup(yamlPath); }
    }

    private sealed class CapturingApprover : IHumanResolver
    {
        private readonly List<HumanResolveRequest> _sink;
        public CapturingApprover(List<HumanResolveRequest> sink) { _sink = sink; }
        public ResolverResponse Resolve(HumanResolveRequest request)
        {
            lock (_sink) { _sink.Add(request); }
            return ResolverResponse.AllowWith(TrueValue);
        }
    }

    private sealed class FixedDecisionResolver : IHumanResolver
    {
        private readonly ResolverResponse _response;
        public FixedDecisionResolver(ResolverResponse response) { _response = response; }
        public ResolverResponse Resolve(HumanResolveRequest request) => _response;
    }

    private sealed class ThrowingResolver : IHumanResolver
    {
        private readonly string _message;
        public ThrowingResolver(string message) { _message = message; }
        public ResolverResponse Resolve(HumanResolveRequest request) =>
            throw new InvalidOperationException(_message);
    }
}


public class LastPendingResolutionPeekTests
{
    private static string PendingResolutionFixture
    {
        get
        {
            var dir = AppContext.BaseDirectory;
            while (dir != null && !Directory.Exists(Path.Combine(dir, "tests", "fixtures", "contract")))
                dir = Directory.GetParent(dir)?.FullName;
            if (dir == null)
                throw new DirectoryNotFoundException(
                    "Could not locate tests/fixtures/contract — has the canonical " +
                    "pending_resolution fixture moved?");
            return Path.Combine(dir, "tests", "fixtures", "contract", "pending_resolution.guardrails.yaml");
        }
    }

    private static async Task<Shield> BuildShieldAfterHumanBlockAsync()
    {
        var shield = Shield.FromYaml(PendingResolutionFixture).Build();
        var (blocked, _) = await shield.ProtectToolAsync(
            "send_email",
            Parse("{\"to\":\"alice@example.com\"}"),
            _ => Task.FromResult("sent"));
        Assert.True(blocked, "Stage 2/3 must block when no human resolver is registered");
        Assert.Null(shield.LastPendingResolution());
        return shield;
    }

    [Fact]
    public async Task LastPendingResolution_RemainsNullForMissingHumanResolver()
    {
        using var shield = await BuildShieldAfterHumanBlockAsync();

        Assert.Null(shield.LastPendingResolution());
        Assert.Null(shield.LastPendingResolution());
        Assert.Null(shield.LastPendingResolution());
    }

    [Fact]
    public async Task ResolvePendingWithExplicitSetVariables_AllowsFollowUpCall()
    {
        using var shield = await BuildShieldAfterHumanBlockAsync();

        await shield.UseSessionAsync(() => shield.ResolvePendingAsync(
            "allow",
            setVariables: new Dictionary<string, object?> { ["send_email_approved"] = true }));

        var (blocked2, output) = await shield.ProtectToolAsync(
            "send_email",
            Parse("{\"to\":\"alice@example.com\"}"),
            _ => Task.FromResult("sent"));
        Assert.False(blocked2);
        Assert.Equal("sent", output);
        Assert.Null(shield.LastPendingResolution());
    }

    [Fact]
    public async Task ResolvePendingWithoutPendingOrSetVariables_Raises()
    {
        using var shield = await BuildShieldAfterHumanBlockAsync();

        var ex = await Assert.ThrowsAsync<InvalidOperationException>(
            () => shield.UseSessionAsync(() => shield.ResolvePendingAsync("allow")));
        Assert.Contains("pending_resolution", ex.Message, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void EmptyShield_LastPendingResolutionReturnsNull()
    {
        using var shield = Shield.FromYaml(PendingResolutionFixture).Build();
        Assert.Null(shield.LastPendingResolution());
        Assert.Null(shield.LastPendingResolution());
        Assert.Null(shield.LastPendingResolution());
    }
}
