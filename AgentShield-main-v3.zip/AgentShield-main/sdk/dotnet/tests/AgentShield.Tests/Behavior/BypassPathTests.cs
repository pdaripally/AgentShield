using System.Collections.Generic;
using System.Text.Json;
using System;
using AgentShield;
using Xunit;

namespace AgentShield.Tests;

public class BypassPathTests
{
    private const string FixtureYaml = """
metadata:
  name: "dotnet-bypass-paths"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Guard .NET adapter tool calls."]
  forbidden: ["Leak secrets."]
resources:
  tools:
    - name: "search"
      description: "Web search."
      permission: "read_only"
""";

    private const string BlockOutputYaml = """
metadata:
  name: "dotnet-block-output"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Block confidential output."]
  forbidden: ["Leak secrets."]
output_validation:
  guard_policies:
    - name: "block-confidential"
      evaluate_when:
        - pattern: "CONFIDENTIAL"
          reason: "Output contains confidential marker."
      action: block
""";

    private sealed class CapturingProvider : IObservabilityProvider
    {
        public List<JsonElement> Events { get; } = new();
        public void OnLogEvent(JsonElement e) => Events.Add(e.Clone());
    }

    private static JsonElement Json(string raw) =>
        JsonDocument.Parse(raw).RootElement.Clone();

    private static GuardrailsRuntime BuildRuntime(
        out CapturingProvider provider,
        string yaml = FixtureYaml)
    {
        provider = new CapturingProvider();
        using var b = RuntimeBuilder.FromYamlStrings(new[] { yaml });
        b.RegisterObservabilityProvider(provider);
        return b.Build();
    }

    private static GuardrailsSession NewSession(GuardrailsRuntime rt)
    {
        var s = rt.NewSession();
        s.BeginTurn();
        return s;
    }

    [Fact]
    public void GuardedToolCallProducesInvocationHash()
    {
        using var rt = BuildRuntime(out _);
        using var s = NewSession(rt);

        var (callVerdict, _, h) = s.ValidateToolCall(
            "search",
            Json("""{"query":"hello"}"""),
            "dn_call_001");
        Assert.True(callVerdict.Allowed, "Stage 3 MUST allow the call");
        Assert.False(
            string.IsNullOrEmpty(callVerdict.InvocationHash),
            "Guarded Stage 3 MUST produce InvocationHash");

        var (outVerdict, _) = s.ValidateToolOutput(h!.Value,
            Json("""{"results":["r1"]}"""));
        Assert.True(outVerdict.Allowed, "Stage 4 MUST allow the output");
        Assert.False(
            string.IsNullOrEmpty(outVerdict.InvocationHash),
            "Guarded Stage 4 MUST preserve InvocationHash from Stage 3");
    }

    [Fact]
    public void RawCallWithoutStage3FailsClosedWithNoInvocationHash()
    {
        using var rt = BuildRuntime(out _);
        using var s = NewSession(rt);
        var (verdict, _) = s.ValidateToolOutput("search", Json("""{"results":[]}"""), "never_validated_id");
        Assert.False(verdict.Allowed);
        Assert.Equal("<binding>", verdict.Policy);
        Assert.Null(verdict.InvocationHash);
    }

    [Fact]
    public void RawDispatchWithoutStage3EmitsUnguardedToolDispatchIncident()
    {
        using var rt = BuildRuntime(out var p);
        using var s = NewSession(rt);
        var (verdict, _) = s.ValidateToolOutput("search", Json("""{"results":[]}"""), "bypass_dn_001");
        Assert.False(verdict.Allowed);
        rt.FlushObservability();
        bool found = p.Events.Exists(e =>
            e.TryGetProperty("event_type", out var et) &&
            et.GetString() == "incident_emitted" &&
            e.TryGetProperty("event_id", out var ei) &&
            ei.GetString() == "incident.unguarded_tool_dispatch");
        Assert.True(found, "Expected incident.unguarded_tool_dispatch");
    }

    [Fact]
    public void NullParamsNormalizeToEmptyParamsAndReturnHash()
    {
        using var rt = BuildRuntime(out _);
        using var s = NewSession(rt);

        var (callVerdict, _) = s.ValidateToolCall(
            "search",
            Json("null"),
            "dn_malformed_001");

        Assert.True(callVerdict.Allowed, "null params MUST still allow the call");
        Assert.False(
            string.IsNullOrEmpty(callVerdict.InvocationHash),
            "null params MUST still produce InvocationHash");
    }

    [Fact]
    public void StreamingStage5BlockEmitsStreamAbortedIncident()
    {
        using var rt = BuildRuntime(out var provider, BlockOutputYaml);
        using var s = NewSession(rt);
        using var guard = s.StreamingSession(StreamingStage.Output);

        guard.Push("This output is ");
        guard.Push("marked CONFIDENTIAL and should be blocked.");
        var result = guard.Finish();

        Assert.Equal(StreamAction.Stop, result.Action);

        rt.FlushObservability();

        bool found = provider.Events.Exists(e =>
            e.TryGetProperty("event_type", out var et) &&
            et.GetString() == "incident_emitted" &&
            e.TryGetProperty("event_id", out var ei) &&
            ei.GetString() == "incident.stream_aborted");

        Assert.True(
            found,
            "Streaming Stage-5 deny MUST emit 'incident.stream_aborted'");
    }
}
