using System.Text.Json;
using System;
using AgentShield;
using Xunit;

namespace AgentShield.Tests;

public class VariableStateDeserializationTests
{

    private const string DeniedJson = """
        {
          "value": null,
          "status": "denied",
          "set_at": null,
          "expires_at": null,
          "deny_reason": "policy: insufficient_funds",
          "source_kind": "tool",
          "set_by": "approve_transfer"
        }
        """;

    private const string UnsetJson = """
        {
          "value": null,
          "status": "unset",
          "set_at": null,
          "expires_at": null,
          "deny_reason": null,
          "source_kind": null,
          "set_by": null
        }
        """;

    private const string ResolvedJson = """
        {
          "value": true,
          "status": "resolved",
          "set_at": "2025-01-15T12:34:56+00:00",
          "expires_at": "2025-01-15T13:34:56+00:00",
          "deny_reason": null,
          "source_kind": "human",
          "set_by": "approval_dialog"
        }
        """;

    [Fact]
    public void FromJson_DeniedVariable_NullSetAt_DoesNotThrow()
    {
        var state = VariableState.FromJson(DeniedJson);

        Assert.NotNull(state);
        Assert.Equal(VariableStatus.Denied, state!.Status);
        Assert.Null(state.SetAt);
    }

    [Fact]
    public void FromJson_DeniedVariable_RoundTrip_Preserves_Status()
    {
        var state = VariableState.FromJson(DeniedJson);
        Assert.NotNull(state);
        Assert.Equal(VariableStatus.Denied, state!.Status);
        Assert.Equal("policy: insufficient_funds", state.DenyReason);
        Assert.Equal("tool", state.SourceKind);
        Assert.Equal("approve_transfer", state.SetBy);

        var roundTripped = JsonSerializer.Serialize(
            state, AgentShieldJsonOptions.Default);
        var second = VariableState.FromJson(roundTripped);
        Assert.NotNull(second);
        Assert.Equal(state.Status, second!.Status);
        Assert.Equal(state.SetAt, second.SetAt);
        Assert.Equal(state.ExpiresAt, second.ExpiresAt);
        Assert.Equal(state.DenyReason, second.DenyReason);
        Assert.Equal(state.SourceKind, second.SourceKind);
        Assert.Equal(state.SetBy, second.SetBy);
    }

    [Fact]
    public void FromJson_DeniedVariable_NullSetAt_NullExpiresAt()
    {
        var state = VariableState.FromJson(DeniedJson);
        Assert.NotNull(state);
        Assert.Null(state!.SetAt);
        Assert.Null(state.ExpiresAt);
    }

    [Fact]
    public void ToJson_DeniedVariable_EmitsNullSetAt()
    {
        var state = new VariableState(
            Value: JsonDocument.Parse("null").RootElement,
            Status: VariableStatus.Denied,
            SetAt: null,
            ExpiresAt: null,
            DenyReason: "policy: blocked",
            SourceKind: "tool",
            SetBy: "policy_check",
            SourceParams: null);

        var json = JsonSerializer.Serialize(
            state, AgentShieldJsonOptions.Default);

        using var doc = JsonDocument.Parse(json);
        var root = doc.RootElement;

        var setAtOk = !root.TryGetProperty("set_at", out var setAt)
            || setAt.ValueKind == JsonValueKind.Null;
        Assert.True(setAtOk, $"set_at should be absent or JSON null, got: {json}");

        var expiresAtOk = !root.TryGetProperty("expires_at", out var expiresAt)
            || expiresAt.ValueKind == JsonValueKind.Null;
        Assert.True(expiresAtOk, $"expires_at should be absent or JSON null, got: {json}");

        var reread = VariableState.FromJson(json);
        Assert.NotNull(reread);
        Assert.Equal(VariableStatus.Denied, reread!.Status);
        Assert.Null(reread.SetAt);
        Assert.Null(reread.ExpiresAt);
    }

    [Fact]
    public void FromJson_UnsetVariable_NullSetAt_DoesNotThrow()
    {
        var state = VariableState.FromJson(UnsetJson);
        Assert.NotNull(state);
        Assert.Equal(VariableStatus.Unset, state!.Status);
        Assert.Null(state.SetAt);
    }

    [Fact]
    public void FromJson_UnsetVariable_RoundTrip_Preserves_Status()
    {
        var state = VariableState.FromJson(UnsetJson);
        Assert.NotNull(state);
        Assert.Equal(VariableStatus.Unset, state!.Status);
        Assert.Null(state.SetAt);
        Assert.Null(state.ExpiresAt);
        Assert.Null(state.DenyReason);
        Assert.Null(state.SourceKind);
        Assert.Null(state.SetBy);

        var roundTripped = JsonSerializer.Serialize(
            state, AgentShieldJsonOptions.Default);
        var second = VariableState.FromJson(roundTripped);
        Assert.NotNull(second);
        Assert.Equal(VariableStatus.Unset, second!.Status);
        Assert.Null(second.SetAt);
    }

    [Fact]
    public void ToJson_UnsetVariable_EmitsNullSetAt()
    {
        var state = new VariableState(
            Value: JsonDocument.Parse("null").RootElement,
            Status: VariableStatus.Unset,
            SetAt: null,
            ExpiresAt: null,
            DenyReason: null,
            SourceKind: null,
            SetBy: null,
            SourceParams: null);

        var json = JsonSerializer.Serialize(
            state, AgentShieldJsonOptions.Default);

        var reread = VariableState.FromJson(json);
        Assert.NotNull(reread);
        Assert.Equal(VariableStatus.Unset, reread!.Status);
        Assert.Null(reread.SetAt);
        Assert.Null(reread.ExpiresAt);
    }

    [Fact]
    public void FromJson_ResolvedVariable_StillHasNonNullSetAt()
    {
        var state = VariableState.FromJson(ResolvedJson);

        Assert.NotNull(state);
        Assert.Equal(VariableStatus.Resolved, state!.Status);
        Assert.NotNull(state.SetAt);
        Assert.Equal(
            new DateTimeOffset(2025, 1, 15, 12, 34, 56, TimeSpan.Zero),
            state.SetAt!.Value);
        Assert.NotNull(state.ExpiresAt);
        Assert.Equal(
            new DateTimeOffset(2025, 1, 15, 13, 34, 56, TimeSpan.Zero),
            state.ExpiresAt!.Value);
        Assert.Equal("human", state.SourceKind);
        Assert.Equal("approval_dialog", state.SetBy);
    }

    [Fact]
    public void FromJson_ResolvedVariable_RoundTrip_Preserves_Timestamps()
    {
        var state = VariableState.FromJson(ResolvedJson);
        Assert.NotNull(state);

        var roundTripped = JsonSerializer.Serialize(
            state, AgentShieldJsonOptions.Default);
        var second = VariableState.FromJson(roundTripped);

        Assert.NotNull(second);
        Assert.Equal(state!.Status, second!.Status);
        Assert.Equal(state.SetAt, second.SetAt);
        Assert.Equal(state.ExpiresAt, second.ExpiresAt);
        Assert.Equal(state.SourceKind, second.SourceKind);
        Assert.Equal(state.SetBy, second.SetBy);
    }

    [Fact]
    public void FromJson_ResolvedVariable_NullExpiresAt_DoesNotThrow()
    {
        const string json = """
            {
              "value": true,
              "status": "resolved",
              "set_at": "2025-01-15T12:34:56+00:00",
              "expires_at": null,
              "deny_reason": null,
              "source_kind": "expression",
              "set_by": "is_business_hours"
            }
            """;

        var state = VariableState.FromJson(json);
        Assert.NotNull(state);
        Assert.Equal(VariableStatus.Resolved, state!.Status);
        Assert.NotNull(state.SetAt);
        Assert.Null(state.ExpiresAt);
    }
}
