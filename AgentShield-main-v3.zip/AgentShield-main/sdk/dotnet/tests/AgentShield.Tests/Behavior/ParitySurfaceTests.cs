using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using System.Text;
using System.Threading.Tasks;
using System;
using AgentShield.Interop;
using AgentShield.MCP;
using AgentShield;
using NJsonSchema;
using Xunit;

namespace AgentShield.Tests;

public class CapabilityParityTests
{
    private const string Lang = "dotnet";
    private static readonly string RepoRoot = FindRepoRoot();
    private static readonly string CanonicalPath =
        Path.Combine(RepoRoot, "tests", "parity", "capability_canonical.json");

    private static readonly string[] StageFields =
    {
        "input_validation",
        "state_validation",
        "tool_authorization",
        "tool_execution_validation",
        "tool_output_validation",
        "output_validation",
        "streaming_output",
    };

    private static string FindRepoRoot()
    {
        var dir = AppContext.BaseDirectory;
        while (dir is not null
               && !Directory.Exists(Path.Combine(dir, ".git"))
               && !File.Exists(Path.Combine(dir, ".git")))
            dir = Path.GetDirectoryName(dir);
        return dir ?? throw new InvalidOperationException("repo root not found");
    }

    private static JsonDocument LoadCanonical()
    {
        var raw = File.ReadAllText(CanonicalPath);
        return JsonDocument.Parse(raw);
    }

    private static string LevelToString(CoverageLevel level) => level switch
    {
        CoverageLevel.Full => "full",
        CoverageLevel.Partial => "partial",
        CoverageLevel.Unsupported => "unsupported",
        _ => throw new InvalidOperationException($"unknown CoverageLevel {level}"),
    };

    private static IDictionary<string, string> ReportToDict(CapabilityReport report)
    {
        return new Dictionary<string, string>
        {
            ["framework"] = report.Framework,
            ["input_validation"] = LevelToString(report.InputValidation),
            ["state_validation"] = LevelToString(report.StateValidation),
            ["tool_authorization"] = LevelToString(report.ToolAuthorization),
            ["tool_execution_validation"] = LevelToString(report.ToolExecutionValidation),
            ["tool_output_validation"] = LevelToString(report.ToolOutputValidation),
            ["output_validation"] = LevelToString(report.OutputValidation),
            ["streaming_output"] = LevelToString(report.StreamingOutput),
        };
    }

    private static IDictionary<string, string> ExpectedFor(JsonDocument canonical, string fw)
    {
        var entry = canonical.RootElement.GetProperty("frameworks").GetProperty(fw);
        var canonicalClaim = entry.GetProperty("canonical");
        var dict = new Dictionary<string, string>
        {
            ["framework"] = canonicalClaim.GetProperty("framework").GetString()!,
        };
        foreach (var stage in StageFields)
        {
            if (canonicalClaim.TryGetProperty(stage, out var v))
                dict[stage] = v.GetString()!;
        }
        if (entry.TryGetProperty("language_overrides", out var overrides) &&
            overrides.TryGetProperty(Lang, out var langOverrides))
        {
            foreach (var prop in langOverrides.EnumerateObject())
            {
                if (prop.Name.StartsWith("$")) continue;
                if (prop.Value.ValueKind == JsonValueKind.String)
                    dict[prop.Name] = prop.Value.GetString()!;
            }
        }
        return dict;
    }

    private static void AssertMatches(
        string framework,
        IDictionary<string, string> expected,
        CapabilityReport actual)
    {
        var actualDict = ReportToDict(actual);
        Assert.True(
            expected["framework"] == actualDict["framework"],
            $"[{framework}] framework name drift: actual={actualDict["framework"]} " +
            $"expected={expected["framework"]}. Either update the .NET adapter or move " +
            $"this divergence into language_overrides.{Lang} in tests/parity/capability_canonical.json.");

        var diffs = new List<string>();
        foreach (var stage in StageFields)
        {
            var exp = expected.TryGetValue(stage, out var e) ? e : null;
            var act = actualDict.TryGetValue(stage, out var a) ? a : null;
            if (exp != act)
                diffs.Add($"  {stage}: actual={act} expected={exp}");
        }
        Assert.True(
            diffs.Count == 0,
            $"[{framework}] capability drift between .NET and the canonical matrix:\n" +
            string.Join("\n", diffs) +
            $"\nTo accept this divergence, add the field to " +
            $"`frameworks.{framework}.language_overrides.{Lang}` in " +
            "tests/parity/capability_canonical.json.");
    }

    [Fact]
    public void OpenAIAgents_Capability_MatchesCanonical()
    {
        using var canonical = LoadCanonical();
        AssertMatches(
            "openai_agents",
            ExpectedFor(canonical, "openai_agents"),
            global::AgentShield.OpenAI.ShieldExtensions.CapabilityReport);
    }

    [Fact]
    public void Anthropic_Capability_MatchesCanonical()
    {
        using var canonical = LoadCanonical();
        AssertMatches(
            "anthropic_agents",
            ExpectedFor(canonical, "anthropic_agents"),
            global::AgentShield.Anthropic.ShieldExtensions.CapabilityReport);
    }

    [Fact]
    public void SemanticKernel_Capability_MatchesCanonical()
    {
        using var canonical = LoadCanonical();
        AssertMatches(
            "semantic_kernel",
            ExpectedFor(canonical, "semantic_kernel"),
            global::AgentShield.SemanticKernel.ShieldExtensions.CapabilityReport);
    }

    [Fact]
    public void AutoGen_Capability_MatchesCanonical()
    {
        using var canonical = LoadCanonical();
        AssertMatches(
            "autogen",
            ExpectedFor(canonical, "autogen"),
            global::AgentShield.AutoGen.ShieldExtensions.CapabilityReport);
    }

    [Fact]
    public void MicrosoftExtensionsAi_Capability_MatchesCanonical()
    {
        using var canonical = LoadCanonical();
        AssertMatches(
            "microsoft.extensions.ai",
            ExpectedFor(canonical, "microsoft.extensions.ai"),
            global::AgentShield.AI.ShieldExtensions.CapabilityReport);
    }

    [Fact]
    public void Mcp_Capability_MatchesCanonical()
    {
        using var canonical = LoadCanonical();
        var mcpShield = global::AgentShield.MCP.MCPShield
            .FromYaml(Path.Combine(RepoRoot, "tests", "fixtures", "smoke", "minimal.guardrails.yaml"))
            .Build();
        AssertMatches("mcp", ExpectedFor(canonical, "mcp"), mcpShield.Capabilities);
    }

    [Fact]
    public void EveryDotnetFrameworkInCanonical_HasATest()
    {
        using var canonical = LoadCanonical();
        var declared = new List<string>();
        foreach (var prop in canonical.RootElement.GetProperty("frameworks").EnumerateObject())
        {
            var implementedIn = prop.Value.GetProperty("implemented_in");
            if (implementedIn.EnumerateArray().Any(v => v.GetString() == Lang))
                declared.Add(prop.Name);
        }
        declared.Sort(StringComparer.Ordinal);

        var expectedTests = new[]
        {
            "anthropic_agents",
            "autogen",
            "mcp",
            "microsoft.extensions.ai",
            "openai_agents",
            "semantic_kernel",
        };
        Assert.Equal(expectedTests.OrderBy(s => s, StringComparer.Ordinal),
                     declared);
    }
}

public class ErrorMappingParityTests
{
    private static readonly string RepoRoot = FindRepoRoot();
    private static readonly string FixturePath =
        Path.Combine(RepoRoot, "tests", "parity", "error_mapping_parity.json");

    private static string FindRepoRoot()
    {
        var dir = AppContext.BaseDirectory;
        while (dir is not null
               && !Directory.Exists(Path.Combine(dir, ".git"))
               && !File.Exists(Path.Combine(dir, ".git")))
            dir = Path.GetDirectoryName(dir);
        return dir ?? throw new InvalidOperationException("repo root not found");
    }

    private static JsonElement Case(string name)
    {
        using var doc = JsonDocument.Parse(File.ReadAllText(FixturePath));
        return doc.RootElement
            .GetProperty("cases")
            .EnumerateArray()
            .First(c => c.GetProperty("name").GetString() == name)
            .Clone();
    }

    [Fact]
    public async Task ShieldBlockedRaise_MapsToExpectedException()
    {
        var c = Case("shield_blocked_raise");
        using var shield = Shield.FromYaml(Path.Combine(RepoRoot, c.GetProperty("fixture").GetString()!))
            .WithOnBlock(OnBlockPolicy.Raise)
            .Build();

        var ex = await Assert.ThrowsAsync<AgentShieldBlockedException>(async () =>
            await shield.RunAsync<string>(
                userInput: "DENY_ME please",
                execute: () => Task.FromResult("never runs")));
        Assert.Equal(c.GetProperty("expected").GetProperty("dotnet").GetString(), ex.GetType().Name);
    }

    [Fact]
    public void McpBlockedRaise_MapsToExpectedExceptionType()
    {
        var c = Case("mcp_blocked_raise");
        var ex = new MCPGuardrailBlockedException("echo", "blocked");
        Assert.Equal(c.GetProperty("expected").GetProperty("dotnet").GetString(), ex.GetType().Name);
    }
}

[Trait("Category", "FFI")]
public class FfiBoundaryTests
{
    private const int OneMegabyte = 1024 * 1024;

    private const string FixtureYaml = """
metadata:
  name: "ffi-boundary"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["exercise ffi boundary"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "ffi_echo"
      description: "ffi boundary echo tool"
      permission: "read_only"
variables:
  - name: "ffi_value"
    type: "string"
    default: ""
""";

    private static readonly bool NativeAvailable = CheckNativeAvailable();
    private static readonly string? NativeSkipReason = NativeAvailable ? null : "Native library not available";

    private static bool CheckNativeAvailable()
    {
        try
        {
            using var builder = RuntimeBuilder.FromConfigText(FixtureYaml);
            using var runtime = builder.Build();
            return true;
        }
        catch (DllNotFoundException) { return false; }
        catch (TypeInitializationException) { return false; }
    }

    private static GuardrailsRuntime BuildRuntime()
    {
        Assert.True(NativeAvailable, NativeSkipReason ?? "Native library check failed");
        using var builder = RuntimeBuilder.FromConfigText(FixtureYaml);
        return builder.Build();
    }

    private static JsonElement Json(string json) =>
        JsonDocument.Parse(json).RootElement.Clone();

    private static JsonElement JsonValue<T>(T value) =>
        JsonSerializer.SerializeToElement(value);

    private static string BuildDeeplyNestedInvalidInvocationJson()
    {
        var sb = new StringBuilder(300_000);
        sb.Append("{\"kind\":\"tool\",\"name\":\"ffi_echo\",\"params\":");
        for (var i = 0; i < 512; i++)
            sb.Append("{\"nested\":");

        sb.Append('"');
        sb.Append(new string('x', 256 * 1024));
        return sb.ToString();
    }

    private static string BuildVeryLongInvalidInvocationJson() =>
        "{\"kind\":\"tool\",\"name\":\"ffi_echo\",\"params\":{\"payload\":\"" +
        new string('y', OneMegabyte) +
        "\"";

    public static IEnumerable<object[]> PathologicalInvocationPayloads()
    {
        yield return new object[] { "deep-nesting", BuildDeeplyNestedInvalidInvocationJson() };
        yield return new object[] { "very-long-string", BuildVeryLongInvalidInvocationJson() };
    }

    private static JsonElement BuildLargeJsonObject()
    {
        var payload = Enumerable.Range(0, 2048)
            .ToDictionary(i => $"key_{i:D4}", _ => new string('x', 512));

        var bytes = JsonSerializer.SerializeToUtf8Bytes(payload);
        Assert.True(bytes.Length >= OneMegabyte, $"expected at least 1 MiB, got {bytes.Length} bytes");
        using var doc = JsonDocument.Parse(bytes);
        return doc.RootElement.Clone();
    }

    [Fact]
    public void ValidateToolCall_EmbeddedNulInToolName_HandlesGracefully()
    {
        using var runtime = BuildRuntime();
        using var session = runtime.NewSession();

        var (verdict, mutated) = session.ValidateToolCall(
            "ffi_echo\0suffix",
            JsonValue(new Dictionary<string, string> { ["payload"] = "ok" }),
            "ffi-nul-tool");

        Assert.True(verdict.Allowed);
        Assert.Equal("ok", mutated.GetProperty("payload").GetString());
    }

    [Fact]
    public void SetVariable_FourByteEmoji_RoundTripsCorrectly()
    {
        using var runtime = BuildRuntime();
        using var session = runtime.NewSession();

        const string emoji = "🛡️";
        session.SetVariable("ffi_value", JsonValue(emoji));

        var state = session.ReadVariable("ffi_value");
        Assert.NotNull(state);
        Assert.Equal(emoji, state!.Value.GetString());
    }

    [Fact]
    public void ValidateInput_EmptyString_IsHandledWithoutNull()
    {
        using var runtime = BuildRuntime();
        using var session = runtime.NewSession();

        var verdict = session.ValidateInput(string.Empty);

        Assert.NotNull(verdict);
        Assert.True(verdict.Allowed);
    }

    [Fact]
    public void ValidateToolCall_OneMegabyteStringValue_ReturnsCorrectVerdict()
    {
        using var runtime = BuildRuntime();
        using var session = runtime.NewSession();

        var payload = new string('a', OneMegabyte);
        var (verdict, mutated) = session.ValidateToolCall(
            "ffi_echo",
            JsonValue(new Dictionary<string, string> { ["payload"] = payload }),
            "ffi-1mb-string");

        Assert.True(verdict.Allowed);
        Assert.Equal(payload.Length, mutated.GetProperty("payload").GetString()!.Length);
    }

    [Theory]
    [MemberData(nameof(PathologicalInvocationPayloads))]
    public void PathologicalNativeInput_ThrowsManagedException_InsteadOfCrashing(string scenario, string payload)
    {
        using var runtime = BuildRuntime();
        using var session = runtime.NewSession();

        var ex = Assert.Throws<ShieldNativeException>(() =>
            session.ValidateState(payload));

        Assert.False(string.IsNullOrWhiteSpace(ex.Message));

        var (verdict, _) = session.ValidateToolCall(
            "ffi_echo",
            Json("{\"payload\":\"still-alive\"}"),
            $"ffi-after-native-error-{scenario}");

        Assert.True(verdict.Allowed);
    }

    [Fact]
    public async Task ValidateToolCall_TaskWhenAllAcrossSessions_RemainsConsistent()
    {
        using var runtime = BuildRuntime();

        var tasks = Enumerable.Range(0, 4).Select(taskIndex => Task.Run(() =>
        {
            using var session = runtime.NewSession();
            var expected = $"task-{taskIndex}";
            var parameters = JsonValue(new Dictionary<string, string> { ["payload"] = expected });

            for (var iteration = 0; iteration < 10_000; iteration++)
            {
                var (verdict, mutated) = session.ValidateToolCall(
                    "ffi_echo",
                    parameters,
                    $"ffi-concurrency-{taskIndex}-{iteration}");

                Assert.True(verdict.Allowed);
                Assert.Equal(expected, mutated.GetProperty("payload").GetString());
            }
        }));

        await Task.WhenAll(tasks);
    }

    [Fact]
    public void ValidateToolCall_OneMegabyteJsonObject_ReturnsCorrectVerdict()
    {
        using var runtime = BuildRuntime();
        using var session = runtime.NewSession();

        var parameters = BuildLargeJsonObject();
        var (verdict, mutated) = session.ValidateToolCall("ffi_echo", parameters, "ffi-1mb-object");

        Assert.True(verdict.Allowed);
        Assert.Equal(new string('x', 512), mutated.GetProperty("key_0000").GetString());
        Assert.True(Encoding.UTF8.GetByteCount(mutated.GetRawText()) >= OneMegabyte);
    }
}

public class InvocationHashCanonicalizationParityTests
{
    private static readonly string RepoRoot = FindRepoRoot();
    private static readonly string FixturePath =
        Path.Combine(RepoRoot, "tests", "parity", "invocation_hash_canonicalization.json");

    private static string FindRepoRoot()
    {
        var dir = AppContext.BaseDirectory;
        while (dir is not null
               && !Directory.Exists(Path.Combine(dir, ".git"))
               && !File.Exists(Path.Combine(dir, ".git")))
            dir = Path.GetDirectoryName(dir);
        return dir ?? throw new InvalidOperationException("repo root not found");
    }

    public static IEnumerable<object[]> Cases()
    {
        if (!File.Exists(FixturePath))
            throw new FileNotFoundException($"Missing parity fixture: {FixturePath}");

        var fixtureJson = File.ReadAllText(FixturePath);
        if (string.IsNullOrWhiteSpace(fixtureJson))
            throw new InvalidOperationException($"Parity fixture is empty: {FixturePath}");

        using var doc = JsonDocument.Parse(fixtureJson);
        var cases = new List<object[]>();
        foreach (var c in doc.RootElement.GetProperty("cases").EnumerateArray())
            cases.Add(new object[] { c.GetRawText() });

        if (cases.Count == 0)
            throw new InvalidOperationException($"No cases found in parity fixture: {FixturePath}");

        return cases;
    }

    private static JsonElement Json(string raw) => JsonDocument.Parse(raw).RootElement.Clone();

    [Theory]
    [MemberData(nameof(Cases))]
    public void ValidateToolCall_MatchesCanonicalHashes(string caseJson)
    {
        using var doc = JsonDocument.Parse(caseJson);
        var c = doc.RootElement;
        var path = Path.Combine(RepoRoot, c.GetProperty("fixture").GetString()!);
        using var runtime = GuardrailsRuntime.FromYaml(path);
        using var session = runtime.NewSession();
        session.BeginTurn();

        var (verdict, mutated) = session.ValidateToolCall(
            c.GetProperty("tool_name").GetString()!,
            Json(c.GetProperty("params").GetRawText()),
            c.GetProperty("tool_call_id").GetString()!);
        var expected = c.GetProperty("expected");

        Assert.True(verdict.Allowed);
        Assert.Equal(expected.GetProperty("invocation_hash").GetString(), verdict.InvocationHash);
        Assert.Equal(
            expected.GetProperty("post_validation_invocation_hash").GetString(),
            verdict.PostValidationInvocationHash);
        if (expected.TryGetProperty("effective_params", out var effective))
            Assert.Equal(
                JsonSerializer.Serialize(effective),
                JsonSerializer.Serialize(mutated));
    }
}

public class ShieldApiParityTests
{
    private const string Lang = "dotnet";
    private static readonly string RepoRoot = FindRepoRoot();
    private static readonly string CanonicalPath =
        Path.Combine(RepoRoot, "tests", "parity", "shield_canonical_api.json");

    private static string FindRepoRoot()
    {
        var dir = AppContext.BaseDirectory;
        while (dir is not null
               && !Directory.Exists(Path.Combine(dir, ".git"))
               && !File.Exists(Path.Combine(dir, ".git")))
            dir = Path.GetDirectoryName(dir);
        return dir ?? throw new InvalidOperationException("repo root not found");
    }

    private static JsonDocument LoadCanonical()
    {
        var raw = File.ReadAllText(CanonicalPath);
        return JsonDocument.Parse(raw);
    }

    private static HashSet<string> PublicMembers(Type cls, IEnumerable<Assembly> extensionAssemblies)
    {
        var members = new HashSet<string>(StringComparer.Ordinal);

        const BindingFlags flags =
            BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.DeclaredOnly;
        foreach (var m in cls.GetMethods(flags))
        {
            if (m.IsSpecialName) continue;
            members.Add(m.Name);
        }
        foreach (var p in cls.GetProperties(flags))
        {
            members.Add(p.Name);
        }
        foreach (var p in cls.GetProperties(BindingFlags.Instance | BindingFlags.Public))
        {
            if (p.DeclaringType == typeof(object)) continue;
            members.Add(p.Name);
        }

        foreach (var asm in extensionAssemblies)
        {
            Type[] types;
            try { types = asm.GetTypes(); }
            catch (ReflectionTypeLoadException ex) { types = ex.Types.Where(t => t != null).Cast<Type>().ToArray(); }
            foreach (var t in types)
            {
                if (!t.IsSealed || !t.IsAbstract) continue; // static class
                foreach (var m in t.GetMethods(BindingFlags.Public | BindingFlags.Static))
                {
                    if (!m.IsDefined(typeof(System.Runtime.CompilerServices.ExtensionAttribute), false))
                        continue;
                    var ps = m.GetParameters();
                    if (ps.Length == 0) continue;
                    if (ps[0].ParameterType.IsAssignableFrom(cls))
                    {
                        members.Add(m.Name);
                    }
                }
            }
        }

        return members;
    }

    private static IEnumerable<Assembly> AdapterAssemblies()
    {
        yield return typeof(Shield).Assembly; // self
        yield return typeof(global::AgentShield.OpenAI.ShieldExtensions).Assembly;
        yield return typeof(global::AgentShield.Anthropic.ShieldExtensions).Assembly;
        yield return typeof(global::AgentShield.SemanticKernel.ShieldExtensions).Assembly;
        yield return typeof(global::AgentShield.AutoGen.ShieldExtensions).Assembly;
        yield return typeof(global::AgentShield.AI.ShieldExtensions).Assembly;
        yield return typeof(global::AgentShield.MCP.MCPShield).Assembly;
    }

    [Fact]
    public void Shield_HasEveryCanonicalMethodUnderItsDotnetAlias()
    {
        using var canonical = LoadCanonical();
        var members = PublicMembers(typeof(Shield), AdapterAssemblies());
        var missing = new List<(string canonical, string alias)>();
        foreach (var entry in canonical.RootElement.GetProperty("shield_methods").EnumerateArray())
        {
            if (!Includes(entry.GetProperty("must_exist_in"), Lang)) continue;
            var alias = entry.GetProperty("aliases").GetProperty(Lang).GetString()!;
            if (!members.Contains(alias))
            {
                missing.Add((entry.GetProperty("name").GetString()!, alias));
            }
        }
        Assert.True(
            missing.Count == 0,
            $"Shield is missing {missing.Count} canonical method(s) under their .NET aliases: " +
            string.Join(", ", missing.Select(m => $"{m.canonical}->{m.alias}")) +
            ". Either add the method to sdk/dotnet/src/AgentShield/Shield.cs (or expose it via " +
            "an extension method on AgentShield.*) or remove 'dotnet' from `must_exist_in` in " +
            "tests/parity/shield_canonical_api.json (and document the drift in `drift_catalog`).");
    }

    [Fact]
    public void ShieldBuilder_HasEveryCanonicalMethodUnderItsDotnetAlias()
    {
        using var canonical = LoadCanonical();
        var members = PublicMembers(typeof(ShieldBuilder), AdapterAssemblies());
        var missing = new List<(string canonical, string alias)>();
        foreach (var entry in canonical.RootElement.GetProperty("shield_builder_methods").EnumerateArray())
        {
            if (!Includes(entry.GetProperty("must_exist_in"), Lang)) continue;
            var alias = entry.GetProperty("aliases").GetProperty(Lang).GetString()!;
            if (!members.Contains(alias))
            {
                missing.Add((entry.GetProperty("name").GetString()!, alias));
            }
        }
        Assert.True(
            missing.Count == 0,
            $"ShieldBuilder is missing {missing.Count} canonical method(s) under their .NET aliases: " +
            string.Join(", ", missing.Select(m => $"{m.canonical}->{m.alias}")) +
            ". Either add the method to sdk/dotnet/src/AgentShield/ShieldBuilder.cs (or expose " +
            "it via an extension method) or remove 'dotnet' from `must_exist_in` in " +
            "tests/parity/shield_canonical_api.json.");
    }

    [Fact]
    public void NoUndeclaredDotnetExtensionsOnShieldOrBuilder()
    {
        using var canonical = LoadCanonical();
        var canonicalShield = new HashSet<string>(StringComparer.Ordinal);
        foreach (var entry in canonical.RootElement.GetProperty("shield_methods").EnumerateArray())
        {
            if (entry.GetProperty("aliases").TryGetProperty(Lang, out var alias))
                canonicalShield.Add(alias.GetString()!);
        }
        var canonicalBuilder = new HashSet<string>(StringComparer.Ordinal);
        foreach (var entry in canonical.RootElement.GetProperty("shield_builder_methods").EnumerateArray())
        {
            if (entry.GetProperty("aliases").TryGetProperty(Lang, out var alias))
                canonicalBuilder.Add(alias.GetString()!);
        }
        var declaredExtensions = canonical.RootElement
            .GetProperty("language_specific_extensions")
            .GetProperty(Lang);
        var extShield = declaredExtensions.GetProperty("shield")
            .EnumerateArray().Select(v => v.GetString()!).ToHashSet();
        var extBuilder = declaredExtensions.GetProperty("shield_builder")
            .EnumerateArray().Select(v => v.GetString()!).ToHashSet();

        var asms = AdapterAssemblies().ToList();
        var shieldActual = PublicMembers(typeof(Shield), asms);
        var builderActual = PublicMembers(typeof(ShieldBuilder), asms);

        var undeclaredShield = shieldActual
            .Where(n => !canonicalShield.Contains(n) && !extShield.Contains(n))
            .OrderBy(s => s).ToList();
        var undeclaredBuilder = builderActual
            .Where(n => !canonicalBuilder.Contains(n) && !extBuilder.Contains(n))
            .OrderBy(s => s).ToList();

        var msgParts = new List<string>();
        if (undeclaredShield.Count > 0)
            msgParts.Add($"Shield has {undeclaredShield.Count} undeclared public method(s): [{string.Join(", ", undeclaredShield)}]");
        if (undeclaredBuilder.Count > 0)
            msgParts.Add($"ShieldBuilder has {undeclaredBuilder.Count} undeclared public method(s): [{string.Join(", ", undeclaredBuilder)}]");

        Assert.True(
            msgParts.Count == 0,
            "Undeclared public surface in .NET — every public method must be either in " +
            "`shield_methods`/`shield_builder_methods` (cross-language canonical) or in " +
            "`language_specific_extensions.dotnet` (.NET-only) in " +
            "tests/parity/shield_canonical_api.json. Found:\n  - " + string.Join("\n  - ", msgParts));
    }

    private static bool Includes(JsonElement arr, string value)
    {
        foreach (var v in arr.EnumerateArray())
            if (v.GetString() == value) return true;
        return false;
    }
}

public class VerdictDispatchParityTests
{
    private static readonly string RepoRoot = FindRepoRoot();
    private static readonly string CanonicalPath =
        Path.Combine(RepoRoot, "tests", "parity", "verdict_dispatch_canonical.json");

    private static string FindRepoRoot()
    {
        var dir = AppContext.BaseDirectory;
        while (dir is not null
               && !Directory.Exists(Path.Combine(dir, ".git"))
               && !File.Exists(Path.Combine(dir, ".git")))
            dir = Path.GetDirectoryName(dir);
        return dir ?? throw new InvalidOperationException("repo root not found");
    }

    public static IEnumerable<object[]> StageCases()
    {
        if (!File.Exists(CanonicalPath)) yield break;
        using var doc = JsonDocument.Parse(File.ReadAllText(CanonicalPath));
        foreach (var c in doc.RootElement.GetProperty("stage_cases").EnumerateArray())
        {
            yield return new object[] { c.GetRawText() };
        }
    }

    public static IEnumerable<object[]> ToolCases()
    {
        if (!File.Exists(CanonicalPath)) yield break;
        using var doc = JsonDocument.Parse(File.ReadAllText(CanonicalPath));
        foreach (var c in doc.RootElement.GetProperty("tool_cases").EnumerateArray())
        {
            yield return new object[] { c.GetRawText() };
        }
    }

    private static StageVerdict ParseVerdict(JsonElement v)
    {
        return StageVerdict.FromJson(v.GetRawText());
    }

    private static OnBlockPolicy ParsePolicy(string s) => s switch
    {
        "return_blocked" => OnBlockPolicy.ReturnBlocked,
        "return_verdict" => OnBlockPolicy.ReturnVerdict,
        "raise" => OnBlockPolicy.Raise,
        "custom" => (OnBlockPolicy)3,
        _ => throw new ArgumentException($"unknown policy: {s}"),
    };

    private static ShieldMode ParseMode(string s) => s switch
    {
        "enforce" => ShieldMode.Enforce,
        "monitor" => ShieldMode.Monitor,
        _ => throw new ArgumentException($"unknown mode: {s}"),
    };

    private static ToolStage ParseStage(string s) => s switch
    {
        "call" => ToolStage.Call,
        "output" => ToolStage.Output,
        _ => throw new ArgumentException($"unknown stage: {s}"),
    };

    [Theory]
    [MemberData(nameof(StageCases))]
    public void Stage_Dispatch_Matches_Canonical(string caseJson)
    {
        using var doc = JsonDocument.Parse(caseJson);
        var c = doc.RootElement;
        var verdict = ParseVerdict(c.GetProperty("verdict"));
        var policy = ParsePolicy(c.GetProperty("policy").GetString()!);
        var mode = ParseMode(c.GetProperty("mode").GetString()!);
        var name = c.GetProperty("name").GetString();

        var actual = VerdictDispatcher.DispatchStage(verdict, policy, mode);
        var expected = c.GetProperty("expected");

        var expectedAction = expected.GetProperty("action");
        Assert.Equal(expectedAction.GetProperty("kind").GetString(), actual.Action.Kind);
        if (expectedAction.TryGetProperty("message", out var msg))
        {
            Assert.Equal(msg.GetString(), actual.Action.Message);
        }
        if (expectedAction.TryGetProperty("value", out var val))
        {
            Assert.Equal(val.GetString(), actual.Action.Value);
        }
        Assert.Equal(expected.GetProperty("record_block").GetBoolean(), actual.RecordBlock);
        Assert.Equal(
            expected.GetProperty("override_to_proceed").GetBoolean(),
            actual.OverrideToProceed);
    }

    [Theory]
    [MemberData(nameof(ToolCases))]
    public void Tool_Dispatch_Matches_Canonical(string caseJson)
    {
        using var doc = JsonDocument.Parse(caseJson);
        var c = doc.RootElement;
        var verdict = ParseVerdict(c.GetProperty("verdict"));
        var toolName = c.GetProperty("tool_name").GetString()!;
        var stage = ParseStage(c.GetProperty("stage").GetString()!);
        var policy = ParsePolicy(c.GetProperty("policy").GetString()!);
        var mode = ParseMode(c.GetProperty("mode").GetString()!);

        var actual = VerdictDispatcher.DispatchTool(verdict, toolName, stage, policy, mode);
        var expected = c.GetProperty("expected");

        var expectedAction = expected.GetProperty("action");
        Assert.Equal(expectedAction.GetProperty("kind").GetString(), actual.Action.Kind);
        if (expectedAction.TryGetProperty("message", out var msg))
        {
            Assert.Equal(msg.GetString(), actual.Action.Message);
        }
        if (expectedAction.TryGetProperty("value", out var val))
        {
            Assert.Equal(val.GetString(), actual.Action.Value);
        }
        Assert.Equal(expected.GetProperty("record_failure").GetBoolean(), actual.RecordFailure);
        Assert.Equal(expected.GetProperty("record_success").GetBoolean(), actual.RecordSuccess);
        Assert.Equal(
            expected.GetProperty("override_to_proceed").GetBoolean(),
            actual.OverrideToProceed);
    }
}

public class WireFixtureTests
{
    private static readonly string RepoRoot = FindRepoRoot();
    private static readonly string SchemasDir =
        Path.Combine(RepoRoot, "spec", "schemas", "wire");
    private static readonly string FixturesDir =
        Path.Combine(RepoRoot, "tests", "fixtures", "wire");

    private static string FindRepoRoot()
    {
        var dir = AppContext.BaseDirectory;
        while (dir is not null
               && !Directory.Exists(Path.Combine(dir, ".git"))
               && !File.Exists(Path.Combine(dir, ".git")))
            dir = Path.GetDirectoryName(dir);
        return dir ?? throw new InvalidOperationException("repo root not found");
    }

    public static IEnumerable<object[]> AllFixtures()
    {
        foreach (var shapeDir in Directory.EnumerateDirectories(FixturesDir).OrderBy(d => d))
        {
            var shape = Path.GetFileName(shapeDir);
            var schemaPath = Path.Combine(SchemasDir, $"{shape}.schema.json");
            if (!File.Exists(schemaPath))
            {
                throw new FileNotFoundException(
                    $"No schema for fixture shape {shape}: {schemaPath}");
            }
            foreach (var fixture in Directory.EnumerateFiles(shapeDir, "*.json").OrderBy(f => f))
            {
                yield return new object[] { shape, fixture, schemaPath };
            }
        }
    }

    [Theory]
    [MemberData(nameof(AllFixtures))]
    public void Fixture_IsJsonObject(string shape, string fixturePath, string schemaPath)
    {
        var json = File.ReadAllText(fixturePath);
        using var doc = JsonDocument.Parse(json);
        Assert.Equal(JsonValueKind.Object, doc.RootElement.ValueKind);
    }

    [Theory]
    [MemberData(nameof(AllFixtures))]
    public void Fixture_ValidatesAgainstSchema(string shape, string fixturePath, string schemaPath)
    {
        var schema = JsonSchema.FromFileAsync(schemaPath).GetAwaiter().GetResult();
        var fixture = File.ReadAllText(fixturePath);
        var errors = schema.Validate(fixture);
        Assert.True(
            errors.Count == 0,
            $"{shape}/{Path.GetFileName(fixturePath)}: " +
            string.Join("; ", errors.Select(e => $"{e.Path}: {e.Kind}")));
    }

    [Theory]
    [MemberData(nameof(AllFixtures))]
    public void Fixture_RoundTripsThroughJson(string shape, string fixturePath, string schemaPath)
    {
        var schema = JsonSchema.FromFileAsync(schemaPath).GetAwaiter().GetResult();
        using var doc = JsonDocument.Parse(File.ReadAllText(fixturePath));

        var reserialised = JsonSerializer.Serialize(
            doc.RootElement,
            new JsonSerializerOptions { WriteIndented = false });

        var errors = schema.Validate(reserialised);
        Assert.True(
            errors.Count == 0,
            $"Round-trip {shape}/{Path.GetFileName(fixturePath)}: " +
            string.Join("; ", errors.Select(e => $"{e.Path}: {e.Kind}")));
    }

    [Theory]
    [MemberData(nameof(AllFixtures))]
    public void Fixture_UsesSnakeCase(string shape, string fixturePath, string schemaPath)
    {
        using var doc = JsonDocument.Parse(File.ReadAllText(fixturePath));
        foreach (var key in AllKeys(doc.RootElement))
        {
            Assert.False(
                key.Any(char.IsUpper),
                $"Key '{key}' in {fixturePath} has uppercase characters " +
                "(canonical wire format is snake_case)");
        }
    }

    private static IEnumerable<string> AllKeys(JsonElement element)
    {
        if (element.ValueKind == JsonValueKind.Object)
        {
            foreach (var prop in element.EnumerateObject())
            {
                yield return prop.Name;
                foreach (var child in AllKeys(prop.Value))
                    yield return child;
            }
        }
        else if (element.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in element.EnumerateArray())
                foreach (var child in AllKeys(item))
                    yield return child;
        }
    }

    [Fact]
    public void EverySchemaHasAtLeastOneFixture()
    {
        foreach (var schema in Directory.EnumerateFiles(SchemasDir, "*.schema.json"))
        {
            var shape = Path.GetFileNameWithoutExtension(schema)
                .Replace(".schema", "");
            var dir = Path.Combine(FixturesDir, shape);
            Assert.True(Directory.Exists(dir),
                $"Schema {Path.GetFileName(schema)} has no fixtures dir");
            var files = Directory.GetFiles(dir, "*.json");
            Assert.True(files.Length > 0,
                $"Schema {Path.GetFileName(schema)} has no fixtures in {dir}");
        }
    }

    [Fact]
    public void NoOrphanFixtureDirectories()
    {
        foreach (var dir in Directory.EnumerateDirectories(FixturesDir))
        {
            var shape = Path.GetFileName(dir);
            var schemaPath = Path.Combine(SchemasDir, $"{shape}.schema.json");
            Assert.True(File.Exists(schemaPath),
                $"Fixture directory {shape} has no matching schema");
        }
    }
}
