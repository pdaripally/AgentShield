using System.IO;
using System;
using Xunit;

namespace AgentShield.Tests;

public class RedactionSpanDocContractTests
{
    private static string LocateIlmCallerSource()
    {
        var dir = AppContext.BaseDirectory;
        for (var i = 0; i < 10; i++)
        {
            var candidate = Path.Combine(dir, "src", "AgentShield", "ILlmCaller.cs");
            if (File.Exists(candidate)) return candidate;
            var parent = Directory.GetParent(dir);
            if (parent is null) break;
            dir = parent.FullName;
        }

        throw new FileNotFoundException(
            "Could not locate sdk/dotnet/src/AgentShield/ILlmCaller.cs walking up from "
            + AppContext.BaseDirectory);
    }

    private static string ExtractRedactionSpanDocBlock()
    {
        var path = LocateIlmCallerSource();
        var source = File.ReadAllText(path);
        var anchor = "public sealed record RedactionSpan(";
        var idx = source.IndexOf(anchor, StringComparison.Ordinal);
        Assert.True(idx > 0, $"anchor '{anchor}' missing from {path}");
        var start = Math.Max(0, idx - 2000);
        return source.Substring(start, idx - start);
    }

    [Fact]
    public void RedactionSpan_XmlDoc_Specifies_Codepoint_Offsets()
    {
        var block = ExtractRedactionSpanDocBlock();
        Assert.Contains("codepoint", block, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void RedactionSpan_XmlDoc_Does_Not_Claim_Byte_Range()
    {
        var block = ExtractRedactionSpanDocBlock();
        string[] forbidden = { "byte range", "byte offset", "byte-range", "byte-offset" };
        foreach (var phrase in forbidden)
        {
            Assert.False(
                block.Contains(phrase, StringComparison.OrdinalIgnoreCase),
                $"RedactionSpan XML doc must not call offsets a '{phrase}' (behavior).");
        }
    }

    [Fact]
    public void RedactionSpan_XmlDoc_Warns_About_Utf16_CodeUnit_Pitfall()
    {
        var block = ExtractRedactionSpanDocBlock();
        Assert.Contains("UTF-16", block, StringComparison.OrdinalIgnoreCase);
    }
}
