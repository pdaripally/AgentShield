using System.IO;
using System.Threading.Tasks;
using System;
using AgentShield;
using Xunit;
using static AgentShield.Tests.Support.JsonTest;

namespace AgentShield.Tests;

public class PendingResolutionProvenanceTests
{
    private const string SendEmailYaml = @"
metadata:
  name: ""shield-human-resolver-provenance""
  version: ""0.1.0""
  agent_shield_version: ""2.0""

objective:
  goal: [""send email only after explicit approval""]
  forbidden: [""send without approval""]

resources:
  tools:
    - name: ""send_email""
      description: ""Send email.""
      permission: ""execute""

variables:
  - name: ""send_email_authorized""
    type: ""boolean""
    on_demand_by:
      kind: ""human""
      prompt: ""Approve sending email?""
    lifetime: ""per_session""

state_validation:
  guard_policies:
    - name: ""send_email_requires_approval""
      applies_to:
        tools: [""send_email""]
      evaluate_when:
        - expression: ""send_email_authorized == true""
          reason: ""Sending email requires explicit user confirmation""
      action: ""block""
";

    private static Shield BuildShield(ResolverResponse? response = null)
    {
        var rb = RuntimeBuilder.FromYamlStrings(new[] { SendEmailYaml });
        if (response != null) rb.RegisterHumanResolver(new FixedHumanResolver(response));
        return Shield.FromRuntime(rb.Build()).Build();
    }

    [Fact]
    public async Task RegisteredHumanResolver_AllowStampsHumanProvenance()
    {
        using var shield = BuildShield(ResolverResponse.AllowWith(Parse("true")));
        var (blocked, output) = await shield.ProtectToolAsync(
            "send_email",
            Parse("{\"to\":\"alice@example.com\"}"),
            _ => Task.FromResult("sent"));
        Assert.False(blocked);
        Assert.Equal("sent", output);
        Assert.Null(shield.LastPendingResolution());

        var state = ReadAuthorizedState(shield);
        Assert.NotNull(state);
        Assert.Equal("resolved", state!.Status);
        Assert.True(state.Value);
        Assert.Equal("human", state.SourceKind);
        Assert.Equal("human:send_email_authorized", state.SetBy);
    }

    [Fact]
    public async Task RegisteredHumanResolver_DenyStampsHumanProvenanceAndDenied()
    {
        using var shield = BuildShield(ResolverResponse.DenyWith("user denied"));
        var (blocked, _) = await shield.ProtectToolAsync(
            "send_email",
            Parse("{\"to\":\"alice@example.com\"}"),
            _ => Task.FromResult("sent"));
        Assert.True(blocked);
        Assert.Null(shield.LastPendingResolution());

        var state = ReadAuthorizedState(shield);
        Assert.NotNull(state);
        Assert.Equal("denied", state!.Status);
        Assert.Equal("human", state.SourceKind);
    }

    [Fact]
    public async Task MissingHumanResolver_DoesNotLatchPendingResolution()
    {
        using var shield = BuildShield();
        var (blocked, _) = await shield.ProtectToolAsync(
            "send_email",
            Parse("{\"to\":\"alice@example.com\"}"),
            _ => Task.FromResult("sent"));
        Assert.True(blocked);
        Assert.Null(shield.LastPendingResolution());
    }

    [Fact]
    public async Task ResolvePending_NoPendingThrows()
    {
        using var shield = BuildShield();
        await shield.UseSessionAsync(async () =>
        {
            var ex = await Assert.ThrowsAsync<InvalidOperationException>(
                () => shield.ResolvePendingAsync("allow"));
            Assert.Contains("pending_resolution", ex.Message, StringComparison.Ordinal);
        });
    }

    private sealed class FixedHumanResolver : IHumanResolver
    {
        private readonly ResolverResponse _response;
        public FixedHumanResolver(ResolverResponse response) { _response = response; }
        public ResolverResponse Resolve(HumanResolveRequest request) => _response;
    }

    private sealed record AuthorizedSnapshot(
        string Status,
        bool? Value,
        string? SourceKind,
        string? SetBy);

    private static AuthorizedSnapshot? ReadAuthorizedState(Shield shield)
    {
        var sessionField = typeof(Shield).GetField(
            "_session",
            System.Reflection.BindingFlags.Instance |
            System.Reflection.BindingFlags.NonPublic);
        Assert.NotNull(sessionField);
        var session = (GuardrailsSession?)sessionField!.GetValue(shield);
        Assert.NotNull(session);

        var handleField = typeof(GuardrailsSession).GetField(
            "_handle",
            System.Reflection.BindingFlags.Instance |
            System.Reflection.BindingFlags.NonPublic);
        Assert.NotNull(handleField);
        var handle = (IntPtr)handleField!.GetValue(session)!;

        var ptr = Interop.NativeMethods.shield_session_read_variable(
            handle, "send_email_authorized", out var err);
        Interop.NativeMethods.ThrowIfErr(err);
        var json = Interop.NativeMethods.ReadAndFreeString(ptr);
        if (string.IsNullOrEmpty(json)) return null;

        using var doc = System.Text.Json.JsonDocument.Parse(json);
        var root = doc.RootElement;

        string status = root.GetProperty("status").GetString() ?? "";
        bool? boolValue = null;
        if (root.TryGetProperty("value", out var v) &&
            v.ValueKind == System.Text.Json.JsonValueKind.True)
        {
            boolValue = true;
        }
        else if (root.TryGetProperty("value", out var v2) &&
                 v2.ValueKind == System.Text.Json.JsonValueKind.False)
        {
            boolValue = false;
        }
        string? sourceKind = null;
        if (root.TryGetProperty("source_kind", out var sk) &&
            sk.ValueKind == System.Text.Json.JsonValueKind.String)
        {
            sourceKind = sk.GetString();
        }
        string? setBy = null;
        if (root.TryGetProperty("set_by", out var sb) &&
            sb.ValueKind == System.Text.Json.JsonValueKind.String)
        {
            setBy = sb.GetString();
        }

        return new AuthorizedSnapshot(status, boolValue, sourceKind, setBy);
    }
}
