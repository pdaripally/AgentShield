using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.Json;
using System;
using Xunit;

namespace AgentShield.Tests;

public class AacsClassifierWiringTests
{
    private const string UnsetEnvVar = "AGENT_SHIELD_DOTNET_TEST_UNSET_VAR_XYZ123";
    private const string SetEnvVar = "AGENT_SHIELD_DOTNET_TEST_AACS_KEY_OK";

    private static string YamlWithAacs(string? apiKeyEnv)
    {
        var apiKeyLine = apiKeyEnv is null
            ? string.Empty
            : $"    api_key_env: \"{apiKeyEnv}\"\n";

        return $@"metadata:
  name: ""test""
  version: ""0.1.0""
  agent_shield_version: ""2.0""
objective:
  goal: [""pass""]
  forbidden: [""fail""]
configurations:
  - id: ""aacs_default""
    type: classifier
    provider: ""azure_content_safety""
    endpoint: ""https://example.cognitiveservices.azure.com""
    threshold: 0.5
{apiKeyLine}post_tool_validation:
  guard_policies:
    - name: ""aacs_check""
      evaluate_when:
        - classifier:
            configuration: ""aacs_default""
          reason: ""classifier flagged""
";
    }

    private static void ClearEnv()
    {
        SetEnv(UnsetEnvVar, null);
        SetEnv(SetEnvVar, null);
    }

    private static void SetEnv(string name, string? value)
    {
        if (value is null)
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                Environment.SetEnvironmentVariable(name, null);
            }
            else
            {
                _ = unsetenv(name);
            }
        }
        else
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                Environment.SetEnvironmentVariable(name, value);
            }
            else
            {
                _ = setenv(name, value, overwrite: 1);
            }
        }
        Environment.SetEnvironmentVariable(name, value);
    }

    [DllImport("libc", SetLastError = true)]
    private static extern int setenv(string name, string value, int overwrite);

    [DllImport("libc", SetLastError = true)]
    private static extern int unsetenv(string name);

    [Fact]
    public void ShieldFromYamlWithAacsConfigurationBuildsWhenEnvVarSet()
    {
        ClearEnv();
        try
        {
            SetEnv(SetEnvVar, "sk-test-credential-not-real");
            var yaml = YamlWithAacs(SetEnvVar);

            try
            {
                using var shield = Shield.FromYaml(new[] { WriteTempYaml(yaml) }).Build();
                Assert.NotNull(shield);
            }
            catch (AgentShieldConfigException ex) when (
                ex.Message.Contains("azure_content_safety", StringComparison.Ordinal) &&
                ex.Message.Contains("Cargo feature is disabled", StringComparison.Ordinal))
            {
                // Local native builds may omit the bundled AACS feature; the
                // env-var path is still valid when the error is feature-gating,
                // not missing configuration.
                Assert.Contains("aacs_default", ex.Message, StringComparison.Ordinal);
            }
        }
        finally
        {
            ClearEnv();
        }
    }

    [Fact]
    public void ShieldFromYamlWithUnsetEnvVarRaisesActionableError()
    {
        ClearEnv();
        try
        {
            var yaml = YamlWithAacs(UnsetEnvVar);
            var path = WriteTempYaml(yaml);

            var ex = Assert.ThrowsAny<Exception>(() =>
            {
                using var _ = Shield.FromYaml(new[] { path }).Build();
            });

            var msg = ex.Message;
            Assert.Contains("aacs_default", msg);
            Assert.Contains(UnsetEnvVar, msg);
            Assert.Contains("aacs_check", msg);
            Assert.Contains("classifier_wiring_missing", msg);
        }
        finally
        {
            ClearEnv();
        }
    }

    [Fact]
    public void ShieldFromYamlWithMissingConfigurationEntryRaisesActionableError()
    {
        const string yaml = @"metadata:
  name: ""test""
  version: ""0.1.0""
  agent_shield_version: ""2.0""
objective:
  goal: [""pass""]
  forbidden: [""fail""]
post_tool_validation:
  guard_policies:
    - name: ""ghost_check""
      evaluate_when:
        - classifier:
            configuration: ""not_defined_anywhere""
          reason: ""classifier flagged""
";
        var path = WriteTempYaml(yaml);

        var ex = Assert.ThrowsAny<Exception>(() =>
        {
            using var _ = Shield.FromYaml(new[] { path }).Build();
        });

        var msg = ex.Message;
        Assert.Contains("not_defined_anywhere", msg);
        Assert.Contains("ghost_check", msg);
        Assert.Contains("classifier_wiring_missing", msg);
    }

    [Fact]
    public void HostRegisteredClassifierCallerBypassesWiringCheck()
    {
        ClearEnv();
        try
        {
            var yaml = YamlWithAacs(UnsetEnvVar);
            var path = WriteTempYaml(yaml);

            using var shield = Shield.FromYaml(new[] { path })
                .WithClassifier(new MockClassifierCaller())
                .Build();

            Assert.NotNull(shield);
        }
        finally
        {
            ClearEnv();
        }
    }

    private static string WriteTempYaml(string yaml)
    {
        var dir = Path.Combine(AppContext.BaseDirectory, "_aacs_wiring_tests");
        Directory.CreateDirectory(dir);
        var path = Path.Combine(dir, $"guardrails_{Guid.NewGuid():N}.yaml");
        File.WriteAllText(path, yaml);
        return path;
    }

    private sealed class MockClassifierCaller : IClassifierCaller
    {
        public ClassifierVerdict Call(LlmRequest request) =>
            new ClassifierVerdict(Score: 0.0, Threshold: 0.5, Flagged: false);
    }
}

public class ConfigurationLlmCallerTests
{
    private sealed class RecordingCaller : ILlmCaller
    {
        private readonly string _label;
        public List<string> Prompts { get; } = new();

        public RecordingCaller(string label) { _label = label; }

        public LlmResponse Call(LlmRequest request)
        {
            Prompts.Add(request.Prompt);
            return new LlmResponse("allow", Reason: $"{_label}:{request.Prompt}");
        }
    }

    private static LlmRequest Req(string? configurationId, string prompt)
        => new(configurationId, prompt, prompt, default(JsonElement));

    [Fact]
    public void ExactMatch_RoutesToRegisteredCaller()
    {
        var input = new RecordingCaller("input");
        var tool = new RecordingCaller("tool");

        var dispatcher = ConfigurationLlmCaller.Create(new Dictionary<string, ILlmCaller>
        {
            ["input_llm"] = input,
            ["tool_execution_llm"] = tool,
        });

        Assert.Equal("input:hello", dispatcher.Call(Req("input_llm", "hello")).Reason);
        Assert.Equal("tool:calc", dispatcher.Call(Req("tool_execution_llm", "calc")).Reason);
        Assert.Equal(new[] { "hello" }, input.Prompts);
        Assert.Equal(new[] { "calc" }, tool.Prompts);
    }

    [Fact]
    public void SubstringMatch_DoesNotRoute()
    {
        var input = new RecordingCaller("input");
        var fallback = new RecordingCaller("default");

        var dispatcher = ConfigurationLlmCaller.Create(
            new Dictionary<string, ILlmCaller> { ["input_llm"] = input },
            fallback);

        Assert.Equal("default:hello", dispatcher.Call(Req("my_input_check", "hello")).Reason);
        Assert.Empty(input.Prompts);
        Assert.Equal(new[] { "hello" }, fallback.Prompts);
    }

    [Fact]
    public void Default_UsedForUnknownId()
    {
        var fallback = new RecordingCaller("default");
        var dispatcher = ConfigurationLlmCaller.Create(
            new Dictionary<string, ILlmCaller>(), fallback);

        Assert.Equal("default:x", dispatcher.Call(Req("never_registered", "x")).Reason);
    }

    [Fact]
    public void Default_UsedWhenConfigurationIdIsNull()
    {
        var fallback = new RecordingCaller("default");
        var dispatcher = ConfigurationLlmCaller.Create(
            new Dictionary<string, ILlmCaller> { ["input_llm"] = new RecordingCaller("input") },
            fallback);

        Assert.Equal("default:x", dispatcher.Call(Req(null, "x")).Reason);
    }

    [Fact]
    public void NoDefault_UnknownId_Throws()
    {
        var dispatcher = ConfigurationLlmCaller.Create(new Dictionary<string, ILlmCaller>
        {
            ["input_llm"] = new RecordingCaller("input"),
        });

        var ex = Assert.Throws<InvalidOperationException>(
            () => dispatcher.Call(Req("unknown_id", "x")));
        Assert.Contains("no LLM caller registered", ex.Message);
        Assert.Contains("'input_llm'", ex.Message);
        Assert.Contains("'unknown_id'", ex.Message);
        Assert.Contains("no default provided", ex.Message);
    }

    [Fact]
    public void NoDefault_NullId_ErrorRepresentsAsLiteralNull()
    {
        var dispatcher = ConfigurationLlmCaller.Create(
            new Dictionary<string, ILlmCaller>());
        var ex = Assert.Throws<InvalidOperationException>(
            () => dispatcher.Call(Req(null, "x")));
        Assert.Contains("configurationId=null", ex.Message);
    }

    [Fact]
    public void Dispatcher_TakesDefensiveCopy()
    {
        var caller = new RecordingCaller("a");
        var callers = new Dictionary<string, ILlmCaller> { ["a"] = caller };
        var dispatcher = ConfigurationLlmCaller.Create(callers);
        callers.Clear();
        Assert.Equal("a:x", dispatcher.Call(Req("a", "x")).Reason);
    }

    [Fact]
    public void Create_NullCallers_Throws()
    {
        Assert.Throws<ArgumentNullException>(
            () => ConfigurationLlmCaller.Create(null!));
    }
}
