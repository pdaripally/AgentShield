using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System;
using AgentShield;
using Xunit;

namespace AgentShield.Tests;

public class AppliedTransformsSurfaceTests
{
    [Fact]
    public void Stage1Redact_SurfacesAppliedTransformsManifest()
    {
        const string yaml = """
metadata:
  name: "stage1-redact-manifest"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test applied_transforms wire shape"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "echo"
      description: "echo"
      permission: "read_only"
input_validation:
  guard_policies:
    - name: "redact_secret_token"
      action: "redact"
      replacement: "[REDACTED]"
      evaluate_when:
        - patterns:
            - "SECRET-[A-Z0-9]{4,}"
          reason: "secret token in input"
""";
        using var rt = RuntimeBuilder.FromYamlStrings(new[] { yaml }).Build();
        using var session = rt.NewSession();
        session.BeginTurn();

        var verdict = session.ValidateInput("hello SECRET-ABCD world");

        Assert.True(verdict.Allowed, $"Stage 1 redact must allow; reason={verdict.Reason}");
        Assert.Equal("redact", verdict.Action);
        Assert.Equal("hello [REDACTED] world", verdict.Redaction);

        Assert.NotNull(verdict.AppliedTransforms);
        Assert.NotEmpty(verdict.AppliedTransforms!);

        var t = verdict.AppliedTransforms!.Single();
        Assert.Equal("redact_secret_token", t.Policy);
        Assert.Equal(0, t.EvaluateWhenIndex);
        Assert.Equal("redact", t.Action);
        Assert.Equal("[REDACTED]", t.Replacement);

        Assert.NotNull(t.SpanStart);
        Assert.NotNull(t.SpanEnd);
        Assert.Equal(6, t.SpanStart!.Value);
        Assert.Equal(17, t.SpanEnd!.Value);
    }

    [Fact]
    public void Stage1CleanAllow_AppliedTransformsIsEmpty()
    {
        const string yaml = """
metadata:
  name: "stage1-clean-allow"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test applied_transforms is empty on clean allow"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "echo"
      description: "echo"
      permission: "read_only"
input_validation:
  guard_policies:
    - name: "redact_secret_token"
      action: "redact"
      replacement: "[REDACTED]"
      evaluate_when:
        - patterns:
            - "SECRET-[A-Z0-9]{4,}"
          reason: "secret token in input"
""";
        using var rt = RuntimeBuilder.FromYamlStrings(new[] { yaml }).Build();
        using var session = rt.NewSession();
        session.BeginTurn();

        var verdict = session.ValidateInput("nothing sensitive here");

        Assert.True(verdict.Allowed);
        Assert.NotNull(verdict.AppliedTransforms);
        Assert.Empty(verdict.AppliedTransforms!);
    }

    [Fact]
    public void AppliedTransform_JsonShape_MatchesCanonicalWireKeys()
    {
        var transform = new AppliedTransform(
            Policy: "redact_secret_token",
            EvaluateWhenIndex: 0,
            Action: "redact",
            SpanStart: 6,
            SpanEnd: 17,
            Replacement: "[REDACTED]");

        var json = System.Text.Json.JsonSerializer.Serialize(
            transform,
            typeof(AppliedTransform),
            GetJsonOptions());

        Assert.Contains("\"policy\":\"redact_secret_token\"", json, StringComparison.Ordinal);
        Assert.Contains("\"evaluate_when_index\":0", json, StringComparison.Ordinal);
        Assert.Contains("\"action\":\"redact\"", json, StringComparison.Ordinal);
        Assert.Contains("\"span_start\":6", json, StringComparison.Ordinal);
        Assert.Contains("\"span_end\":17", json, StringComparison.Ordinal);
        Assert.Contains("\"replacement\":\"[REDACTED]\"", json, StringComparison.Ordinal);

        var roundTripped = System.Text.Json.JsonSerializer.Deserialize<AppliedTransform>(
            json, GetJsonOptions());
        Assert.Equal(transform, roundTripped);
    }

    private static System.Text.Json.JsonSerializerOptions GetJsonOptions()
    {
        var opts = new System.Text.Json.JsonSerializerOptions
        {
            PropertyNamingPolicy = System.Text.Json.JsonNamingPolicy.SnakeCaseLower,
            DictionaryKeyPolicy = System.Text.Json.JsonNamingPolicy.SnakeCaseLower,
            PropertyNameCaseInsensitive = true,
            DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull,
        };
        return opts;
    }
}

public class ProtectToolCallerToolCallIdTests
{
    private const string FixtureYaml = """
metadata:
  name: "caller-tool-call-id"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test caller-supplied tool_call_id propagation"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "echo"
      description: "Echo the supplied message."
      permission: "execute"
""";

    private sealed class CapturingProvider : IObservabilityProvider
    {
        public List<JsonElement> Events { get; } = new();
        public void OnLogEvent(JsonElement e) => Events.Add(e.Clone());
    }

    private static Shield BuildShield(out CapturingProvider provider)
    {
        provider = new CapturingProvider();
        var capturedProvider = provider;
        return Shield
            .FromYaml(new[] { FixtureYamlAsFile() })
            .WithObservability(capturedProvider)
            .Build();
    }

    private static string FixtureYamlAsFile()
    {
        var path = System.IO.Path.Combine(
            System.IO.Path.GetTempPath(),
            $"agentshield-caller-tool-id-{Guid.NewGuid():N}.guardrails.yaml");
        System.IO.File.WriteAllText(path, FixtureYaml);
        return path;
    }

    private static JsonElement? FindToolCalledEvent(
        CapturingProvider provider,
        string toolName)
    {
        var target = $"tool.{toolName}.called";
        foreach (var ev in provider.Events)
        {
            if (!ev.TryGetProperty("attributes", out var attrs)) continue;
            if (!attrs.TryGetProperty("agent_shield.event.id", out var evId)) continue;
            if (evId.ValueKind == JsonValueKind.String &&
                evId.GetString() == target)
            {
                return ev;
            }
        }
        return null;
    }

    private static string? ReadToolCallId(JsonElement ev)
    {
        if (!ev.TryGetProperty("attributes", out var attrs)) return null;
        if (!attrs.TryGetProperty("agent_shield.invocation.tool_call_id", out var idEl))
            return null;
        return idEl.ValueKind == JsonValueKind.String ? idEl.GetString() : null;
    }

    [Fact]
    public async Task ProtectToolAsync_CallerSuppliedToolCallId_PropagatesToObservability()
    {
        using var shield = BuildShield(out var provider);
        const string supplied = "vercel-call-abc123";

        var (blocked, output) = await shield.ProtectToolAsync(
            "echo",
            JsonDocument.Parse("""{"msg":"hi"}""").RootElement,
            _ => Task.FromResult("ok"),
            toolCallId: supplied);

        Assert.False(blocked);
        Assert.Equal("ok", output);

        shield.Runtime.FlushObservability();
        var ev = FindToolCalledEvent(provider, "echo");
        Assert.NotNull(ev);
        var observed = ReadToolCallId(ev!.Value);
        Assert.Equal(supplied, observed);
    }

    [Fact]
    public async Task ProtectToolAsync_DefaultPath_MintsToolCallId()
    {
        using var shield = BuildShield(out var provider);

        var (blocked, _) = await shield.ProtectToolAsync(
            "echo",
            JsonDocument.Parse("""{"msg":"hi"}""").RootElement,
            _ => Task.FromResult("ok"));

        Assert.False(blocked);

        shield.Runtime.FlushObservability();
        var ev = FindToolCalledEvent(provider, "echo");
        Assert.NotNull(ev);
        var minted = ReadToolCallId(ev!.Value);
        Assert.False(string.IsNullOrEmpty(minted), "expected a minted toolCallId");
    }
}

public class ResolverRequestShapeTests
{
    private static string TempYaml(string body, string slug)
    {
        var dir = Path.Combine(Path.GetTempPath(), $"as-dotnet-{slug}-{Guid.NewGuid():N}");
        Directory.CreateDirectory(dir);
        var p = Path.Combine(dir, "guardrails.yaml");
        File.WriteAllText(p, body);
        return p;
    }

    private static string YamlWithResolver(string resolverBlock, string configurationsBlock = "")
    {
        return $@"
metadata:
  name: ""resolver-request-shape""
  version: ""0.1.0""
  agent_shield_version: ""2.0""

objective:
  goal: [""gate a tool on a keyed per-id authorization""]
  forbidden: []
{configurationsBlock}
resources:
  tools:
    - name: ""do_thing""
      description: ""tool gated on per-id authorization""
      permission: ""execute""

variables:
  - name: ""authorized""
    type: ""boolean""
    key: ""@tool.params.id""
{resolverBlock}

state_validation:
  guard_policies:
    - name: ""needs_authz""
      applies_to:
        tools: [""do_thing""]
      evaluate_when:
        - expression: ""authorized == true""
          reason: ""must be authorized""
      action: ""block""
";
    }

    private const string AgentResolverBlock = @"    on_demand_by:
      kind: ""agent""
      prompt: ""Authorize id=${@tool.params.id}?""
    lifetime: ""per_call""
";

    private const string DelegateResolverBlock = @"    on_demand_by:
      kind: ""delegate""
      configuration: ""approval-service""
      prompt: ""Authorize id=${@tool.params.id}?""
      lifetime: ""per_turn""
    lifetime: ""per_call""
";

    private const string DelegateConfigurations = @"
configurations:
  - id: ""approval-service""
    type: ""http_endpoint""
    endpoint: ""https://example.com/approval""
    timeout: 5000
";

    [Fact]
    public void AgentResolver_KeyedVariable_DeliversRequestedKeyAndResource()
    {
        var yamlPath = TempYaml(YamlWithResolver(AgentResolverBlock), "agent-keyed");
        var captured = new List<ResolverRequest>();
        try
        {
            var resolver = new CapturingAgentResolver(captured);
            using var rt = RuntimeBuilder.FromYaml(yamlPath)
                .RegisterAgentResolver(resolver)
                .Build();
            using var session = rt.NewSession();
            session.BeginTurn();
            try
            {
                var paramsDoc = JsonDocument.Parse("{\"id\":\"K42\"}");
                var outcome = session.ValidateToolCall(
                    "do_thing", paramsDoc.RootElement, "tc-1");
                Assert.True(outcome.Verdict.Allowed,
                    $"approver returned allow — gate should pass; reason={outcome.Verdict.Reason}");
            }
            finally
            {
                session.EndTurn();
            }
        }
        finally
        {
            try { Directory.Delete(Path.GetDirectoryName(yamlPath)!, recursive: true); }
            catch { /* best-effort cleanup */ }
        }

        Assert.Single(captured);
        var req = captured[0];
        Assert.Equal("authorized", req.Variable);

        Assert.NotNull(req.RequestedKey);
        Assert.Equal("K42", req.RequestedKey!.Value.GetString());

        Assert.NotNull(req.Resource);
        Assert.Equal("tool", req.Resource!.Kind);
        Assert.Equal("do_thing", req.Resource!.Name);
        Assert.NotNull(req.Resource!.Params);
        Assert.Equal("K42", req.Resource!.Params!.Value.GetProperty("id").GetString());

        Assert.Equal("tool", req.ResourceKind);
        Assert.Equal("do_thing", req.ResourceName);
    }

    [Fact]
    public void DelegateDispatcher_KeyedVariable_DeliversRequestedKeyAndResource()
    {
        var yamlPath = TempYaml(
            YamlWithResolver(DelegateResolverBlock, DelegateConfigurations),
            "delegate-keyed");
        var captured = new List<DelegateRequest>();
        try
        {
            var dispatcher = new CapturingDispatcher(captured);
            using var rt = RuntimeBuilder.FromYaml(yamlPath)
                .RegisterDelegateDispatcher(dispatcher)
                .Build();
            using var session = rt.NewSession();
            session.BeginTurn();
            try
            {
                var paramsDoc = JsonDocument.Parse("{\"id\":\"K42\"}");
                var outcome = session.ValidateToolCall(
                    "do_thing", paramsDoc.RootElement, "tc-1");
                Assert.True(outcome.Verdict.Allowed,
                    $"dispatcher returned allow — gate should pass; reason={outcome.Verdict.Reason}");
            }
            finally
            {
                session.EndTurn();
            }
        }
        finally
        {
            try { Directory.Delete(Path.GetDirectoryName(yamlPath)!, recursive: true); }
            catch { /* best-effort cleanup */ }
        }

        Assert.Single(captured);
        var req = captured[0];
        Assert.Equal("authorized", req.Base.Variable);

        Assert.NotNull(req.Base.RequestedKey);
        Assert.Equal("K42", req.Base.RequestedKey!.Value.GetString());

        Assert.NotNull(req.Base.Resource);
        Assert.Equal("tool", req.Base.Resource!.Kind);
        Assert.Equal("do_thing", req.Base.Resource!.Name);
        Assert.NotNull(req.Base.Resource!.Params);
        Assert.Equal("K42",
            req.Base.Resource!.Params!.Value.GetProperty("id").GetString());

        Assert.Equal("approval-service", req.ConfigurationId);
        Assert.Equal("http_endpoint", req.ConfigurationType);
    }

    private sealed class CapturingAgentResolver : IAgentResolver
    {
        private readonly List<ResolverRequest> _sink;
        public CapturingAgentResolver(List<ResolverRequest> sink) { _sink = sink; }
        public ResolverResponse Resolve(ResolverRequest request)
        {
            lock (_sink) { _sink.Add(request); }
            return ResolverResponse.AllowWith(JsonDocument.Parse("true").RootElement);
        }
    }

    private sealed class CapturingDispatcher : IDelegateDispatcher
    {
        private readonly List<DelegateRequest> _sink;
        public CapturingDispatcher(List<DelegateRequest> sink) { _sink = sink; }
        public ResolverResponse Dispatch(DelegateRequest request)
        {
            lock (_sink) { _sink.Add(request); }
            return ResolverResponse.AllowWith(JsonDocument.Parse("true").RootElement);
        }
    }
}

public class ResolverSourceParameterTests
{
    private const string Yaml = """
metadata:
  name: "resolver-source-params"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["read account"]
  forbidden: ["none"]
resources:
  tools:
    - name: "read_account"
      description: "returns the customer record for a given account id"
      permission: "read_only"
variables:
  - name: "customer"
    type: "object"
    populated_by:
      - kind: "tool"
        name: "read_account"
        phase: "after"
        expression: "@result"
""";

    [Fact]
    public void ReadVariable_SurfacesSourceParams_FromPopulatorWrite()
    {
        using var b = RuntimeBuilder.FromYamlStrings(new[] { Yaml });
        using var rt = b.Build();
        using var session = rt.NewSession();
        session.BeginTurn();

        var (callVerdict, _, admissionId) = session.ValidateToolCall(
            "read_account",
            JsonDocument.Parse("""{"account_id":"ACC-1001","authenticated":true}""")
                .RootElement.Clone(),
            "call-1");
        Assert.True(callVerdict.Allowed,
            $"Stage 3 must admit read_account; got {callVerdict}");
        Assert.NotNull(admissionId);

        var (outVerdict, _) = session.ValidateToolOutput(
            admissionId!.Value,
            JsonDocument.Parse("""{"customer_id":"ACC-1001"}""").RootElement.Clone());
        Assert.True(outVerdict.Allowed,
            $"Stage 4 must allow the benign tool result; got {outVerdict}");

        var state = session.ReadVariable("customer");
        Assert.NotNull(state);
        Assert.Equal(VariableStatus.Resolved, state!.Status);
        Assert.Equal("populator", state.SourceKind);

        Assert.True(state.SourceParams.HasValue,
            "behavior regression: ReadVariable dropped @source_params. " +
            "Spec the binding contract requires the resource-bound parameter snapshot " +
            "to be surfaced alongside SourceKind / SetBy so hosts can " +
            "audit / replay which invocation produced the variable value.");

        var sp = state.SourceParams!.Value;
        Assert.Equal(JsonValueKind.Object, sp.ValueKind);
        Assert.Equal("ACC-1001", sp.GetProperty("account_id").GetString());
        Assert.True(sp.GetProperty("authenticated").GetBoolean());
    }

    [Fact]
    public void VariableState_RoundTrips_SourceParams_Through_Json()
    {
        const string json = """
            {
              "value": {"customer_id":"ACC-1001"},
              "status": "resolved",
              "set_at": "2026-05-06T14:25:30Z",
              "expires_at": null,
              "deny_reason": null,
              "source_kind": "tool",
              "set_by": "read_account",
              "source_params": {"account_id":"ACC-1001","authenticated":true}
            }
            """;

        var state = VariableState.FromJson(json);
        Assert.NotNull(state);
        Assert.True(state!.SourceParams.HasValue,
            "FromJson must hydrate source_params into the record");

        var sp = state.SourceParams!.Value;
        Assert.Equal("ACC-1001", sp.GetProperty("account_id").GetString());
        Assert.True(sp.GetProperty("authenticated").GetBoolean());
    }
}

public class LensWriterTests
{
    private const string Stage5RedactYaml = @"
metadata:
  name: stage5-redact-emails
  version: ""0.1.0""
  agent_shield_version: ""2.0""
objective:
  goal: [""test""]
output_validation:
  guard_policies:
    - name: redact_emails
      evaluate_when:
        - patterns:
            - ""[a-z0-9._-]+@[a-z0-9-]+\\.[a-z.]+""
          reason: ""redact emails at Stage 5""
      action: redact
      replacement: ""[REDACTED]""
";

    private static Shield BuildShield(string yaml)
    {
        var rb = RuntimeBuilder.FromYamlStrings(new[] { yaml });
        return Shield.FromRuntime(rb.Build()).Build();
    }

    private sealed record FrameworkResult(string Text, int Tokens);

    [Fact]
    public async Task NaturalLambda_RecordWith_CompilesAndWritesRedaction()
    {
        using var shield = BuildShield(Stage5RedactYaml);
        var original = new FrameworkResult("email: alice@example.com", 42);

        var result = await shield.RunAsync<FrameworkResult>(
            () => Task.FromResult(original),
            extractText: r => r.Text,
            setText: (r, t) => r with { Text = t });

        Assert.DoesNotContain("alice@example.com", result.Text);
        Assert.Contains("[REDACTED]", result.Text);
        Assert.Equal(42, result.Tokens);
        Assert.Equal("email: alice@example.com", original.Text);
    }

    [Fact]
    public async Task FuncVariable_StillBinds_AndWritesRedaction()
    {
        using var shield = BuildShield(Stage5RedactYaml);
        var original = new FrameworkResult("email: bob@example.com", 7);

        Func<FrameworkResult, string?> extractor = r => r.Text;
        Func<FrameworkResult, string, FrameworkResult> writer = (r, t) => r with { Text = t };

        var result = await shield.RunAsync<FrameworkResult>(
            () => Task.FromResult(original),
            extractText: extractor,
            setText: writer);

        Assert.DoesNotContain("bob@example.com", result.Text);
        Assert.Contains("[REDACTED]", result.Text);
        Assert.Equal(7, result.Tokens);
    }

    private static FrameworkResult ApplyText(FrameworkResult r, string t) => r with { Text = t };
    private static string? ExtractText(FrameworkResult r) => r.Text;

    [Fact]
    public async Task MethodGroup_StillBinds_AndWritesRedaction()
    {
        using var shield = BuildShield(Stage5RedactYaml);
        var original = new FrameworkResult("email: carol@example.com", 13);

        var result = await shield.RunAsync<FrameworkResult>(
            () => Task.FromResult(original),
            extractText: ExtractText,
            setText: ApplyText);

        Assert.DoesNotContain("carol@example.com", result.Text);
        Assert.Contains("[REDACTED]", result.Text);
        Assert.Equal(13, result.Tokens);
    }

    [Fact]
    public async Task Advisory_Sentinel_StillBinds_LensWriterOverload()
    {
        using var shield = BuildShield(Stage5RedactYaml);
        var original = new FrameworkResult("email: dave@example.com", 99);

        var result = await shield.RunAsync<FrameworkResult>(
            () => Task.FromResult(original),
            extractText: r => r.Text,
            setText: LensWriter<FrameworkResult>.Advisory);

        Assert.Same(original, result);
        Assert.Equal("email: dave@example.com", result.Text);
        Assert.Equal(99, result.Tokens);
    }

    [Fact]
    public async Task ExtractText_Without_SetText_StillThrows_LensIncomplete()
    {
        using var shield = BuildShield(Stage5RedactYaml);
        await Assert.ThrowsAsync<AgentShieldLensIncompleteException>(async () =>
            await shield.RunAsync<FrameworkResult>(
                () => Task.FromResult(new FrameworkResult("email: eve@example.com", 1)),
                extractText: r => r.Text));
    }

    [Fact]
    public async Task FuncOverload_NullSetText_ThrowsArgumentNullException()
    {
        using var shield = BuildShield(Stage5RedactYaml);
        Func<FrameworkResult, string, FrameworkResult> writer = null!;
        await Assert.ThrowsAsync<ArgumentNullException>(async () =>
            await shield.RunAsync<FrameworkResult>(
                () => Task.FromResult(new FrameworkResult("hi", 1)),
                extractText: r => r.Text,
                setText: writer));
    }

    [Fact]
    public async Task FuncOverload_NullExtractText_ThrowsArgumentNullException()
    {
        using var shield = BuildShield(Stage5RedactYaml);
        Func<FrameworkResult, string?> extractor = null!;
        await Assert.ThrowsAsync<ArgumentNullException>(async () =>
            await shield.RunAsync<FrameworkResult>(
                () => Task.FromResult(new FrameworkResult("hi", 1)),
                extractText: extractor,
                setText: (r, t) => r with { Text = t }));
    }

    [Fact]
    public async Task NaturalLambda_UserInputOverload_CompilesAndRuns()
    {
        using var shield = BuildShield(Stage5RedactYaml);
        var original = new FrameworkResult("email: frank@example.com", 5);

        var result = await shield.RunAsync<FrameworkResult>(
            "hello",
            () => Task.FromResult(original),
            extractText: r => r.Text,
            setText: (r, t) => r with { Text = t });

        Assert.DoesNotContain("frank@example.com", result.Text);
        Assert.Contains("[REDACTED]", result.Text);
        Assert.Equal(5, result.Tokens);
    }

    [Fact]
    public async Task NaturalLambda_UserInputThunkOverload_CompilesAndRuns()
    {
        using var shield = BuildShield(Stage5RedactYaml);

        var result = await shield.RunAsync<FrameworkResult>(
            "hello",
            input => Task.FromResult(new FrameworkResult($"email: gail@example.com ({input})", 3)),
            extractText: r => r.Text,
            setText: (r, t) => r with { Text = t });

        Assert.DoesNotContain("gail@example.com", result.Text);
        Assert.Contains("[REDACTED]", result.Text);
        Assert.Equal(3, result.Tokens);
    }
}

public class ToolCallBindingTests
{
    private const string FixtureYaml = """
metadata:
  name: "section-16-binding-parity"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test the binding contract invocation binding"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "send_email"
      description: "Send an email."
      permission: "execute"
post_tool_validation:
  guard_policies:
    - name: "result_recipient_must_match_call_recipient"
      applies_to:
        tools: ["send_email"]
      evaluate_when:
        - expression: 'endswith(@tool.params.recipient, "@example.com")'
          reason: "the binding contract: Stage 4 bound to the wrong invocation."
""";

    private static GuardrailsSession NewSession(GuardrailsRuntime rt)
    {
        var s = rt.NewSession();
        s.BeginTurn();
        return s;
    }

    private static GuardrailsRuntime BuildRuntime()
    {
        using var b = RuntimeBuilder.FromYamlStrings(new[] { FixtureYaml });
        return b.Build();
    }

    private static JsonElement Json(string raw) =>
        JsonDocument.Parse(raw).RootElement.Clone();

    [Fact]
    public void Stage3ThenStage4WithMatchingIdSurfacesHashes()
    {
        using var rt = BuildRuntime();
        using var s = NewSession(rt);

        var (callVerdict, _, h1) = s.ValidateToolCall(
            "send_email",
            Json("""{"recipient":"alice@example.com","body":"hi"}"""),
            "call_alice_1");
        Assert.True(callVerdict.Allowed, "the binding contract: Stage 3 should pass — no Stage-3 policies");

        var (outVerdict, _) = s.ValidateToolOutput(h1!.Value,
            Json("""{"matched_recipient":"alice@example.com","sent":true}"""));
        Assert.True(outVerdict.Allowed,
            $"the binding contract: Stage 4 must bind to the recorded Stage-3 invocation; verdict was {outVerdict}");
        Assert.False(string.IsNullOrEmpty(outVerdict.InvocationHash),
            "the binding contract: Stage 4 must surface InvocationHash when bound");
        Assert.False(string.IsNullOrEmpty(outVerdict.PostValidationInvocationHash),
            "the binding contract: Stage 4 must surface PostValidationInvocationHash");
    }

    [Fact]
    public void ParallelSameNameDistinctIdsBindIndependently()
    {
        using var rt = BuildRuntime();
        using var s = NewSession(rt);

        var (vCallA, _, hA) = s.ValidateToolCall(
            "send_email",
            Json("""{"recipient":"alice@example.com","body":"hi alice"}"""),
            "call_alice_1");
        Assert.True(vCallA.Allowed);

        var (vCallB, _, hB) = s.ValidateToolCall(
            "send_email",
            Json("""{"recipient":"bob@example.com","body":"hi bob"}"""),
            "call_bob_2");
        Assert.True(vCallB.Allowed);

        var (vOutB, _) = s.ValidateToolOutput(hB!.Value,
            Json("""{"matched_recipient":"bob@example.com","sent":true}"""));
        Assert.True(vOutB.Allowed,
            $"the binding contract: bob Stage 4 must bind to call_bob_2 invocation; verdict was {vOutB}");

        var (vOutA, _) = s.ValidateToolOutput(hA!.Value,
            Json("""{"matched_recipient":"alice@example.com","sent":true}"""));
        Assert.True(vOutA.Allowed,
            $"the binding contract: alice Stage 4 must bind to call_alice_1 invocation; verdict was {vOutA}");

        var hashA = vOutA.InvocationHash;
        var hashB = vOutB.InvocationHash;
        Assert.False(string.IsNullOrEmpty(hashA));
        Assert.False(string.IsNullOrEmpty(hashB));
        Assert.NotEqual(hashA, hashB);
    }

    [Fact]
    public void Stage4WithUnknownIdFailsClosed()
    {
        using var rt = BuildRuntime();
        using var s = NewSession(rt);

        var (verdict, _) = s.ValidateToolOutput("send_email",
            Json("""{"matched_recipient":"alice@example.com","sent":true}"""),
            "never_validated_call_id");
        Assert.False(verdict.Allowed);
        Assert.Equal("<binding>", verdict.Policy);
        Assert.Null(verdict.InvocationHash);
    }

    [Fact]
    public void Stage4WithMismatchedExplicitIdFailsClosed()
    {
        using var rt = BuildRuntime();
        using var s = NewSession(rt);

        s.ValidateToolCall(
            "send_email",
            Json("""{"recipient":"alice@example.com","body":"hi"}"""),
            "call_alice_1");

        var (verdict, _) = s.ValidateToolOutput("send_email",
            Json("""{"matched_recipient":"alice@example.com","sent":true}"""),
            "call_alice_2");
        Assert.False(verdict.Allowed);
        Assert.Equal("<binding>", verdict.Policy);
        Assert.Null(verdict.InvocationHash);
    }
}
