using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System;
using Xunit;

namespace AgentShield.Tests;

public class NoPiiSentinelTests
{
    private const string SentinelUserInput  = "SENTINEL_PII_USER_INPUT_xZk2";
    private const string SentinelToolArgs   = "SENTINEL_PII_TOOL_ARGS_8mNQ";
    private const string SentinelToolResult = "SENTINEL_PII_TOOL_RESULT_v3pL";
    private const string SentinelVarValue   = "SENTINEL_PII_VAR_VALUE_R7tF";

    private static readonly string[] AllSentinels =
    {
        SentinelUserInput, SentinelToolArgs, SentinelToolResult, SentinelVarValue,
    };

    [Fact(Skip = "Pending observability sink assertions; documents the contract")]
    public void NoPiiInInfoLogsDuringFullTurn()
    {
        var captured = new List<string>();
        AssertNoSentinel(captured);
    }

    [Fact(Skip = "Pending observability sink assertions; documents the contract")]
    public void NoPiiInProviderEmissionsDuringSwallowPaths()
    {
        var captured = new List<string>();
        AssertNoSentinel(captured);
    }

    private static void AssertNoSentinel(IEnumerable<string> captured)
    {
        foreach (var line in captured)
        {
            foreach (var sentinel in AllSentinels)
            {
                Assert.False(
                    line.Contains(sentinel, StringComparison.Ordinal),
                    $"sentinel '{sentinel}' leaked: {line}"
                );
            }
        }
    }
}

public class PerfTelemetryTests
{
    private static readonly string[] PerfEventTypes =
    {
        "stage_evaluated",
        "policy_evaluated",
        "llm_called",
        "classifier_called",
    };

    private static string FixturePath()
    {
        var dir = AppContext.BaseDirectory;
        while (dir != null && !File.Exists(Path.Combine(dir, "tests", "fixtures", "test-guardrails.yaml")))
            dir = Directory.GetParent(dir)?.FullName;
        if (dir == null)
            throw new FileNotFoundException("Could not locate tests/fixtures/test-guardrails.yaml");
        return Path.Combine(dir, "tests", "fixtures", "test-guardrails.yaml");
    }

    private sealed class CaptureProvider : IObservabilityProvider
    {
        public ConcurrentBag<JsonElement> Events { get; } = new();

        public void OnLogEvent(JsonElement eventJson)
        {
            Events.Add(eventJson.Clone());
        }

        public int CountPerf()
        {
            return Events.Count(e =>
                e.TryGetProperty("event_type", out var t)
                && t.ValueKind == JsonValueKind.String
                && PerfEventTypes.Contains(t.GetString()));
        }
    }

    [Fact]
    public void PerfTelemetryEnumValuesMatchWireBytes()
    {
        Assert.Equal((byte)0, (byte)PerfTelemetry.Off);
        Assert.Equal((byte)1, (byte)PerfTelemetry.External);
        Assert.Equal((byte)2, (byte)PerfTelemetry.Full);
    }

    [Fact]
    public void RuntimeBuilderWithPerfTelemetryAllModesBuildSuccessfully()
    {
        foreach (var mode in new[] { PerfTelemetry.Off, PerfTelemetry.External, PerfTelemetry.Full })
        {
            using var rb = RuntimeBuilder.FromYaml(FixturePath());
            rb.WithPerfTelemetry(mode);
            using var runtime = rb.Build();
            Assert.NotNull(runtime);
        }
    }

    [Fact]
    public void ShieldBuilderDefaultPerfTelemetryEmitsNoPerfEvents()
    {
        var provider = new CaptureProvider();
        using var shield = Shield.FromYaml(FixturePath())
            .WithObservability(provider)
            .Build();

        shield.Session.ValidateInput("hello");
        shield.Runtime.FlushObservability();

        Assert.Equal(0, provider.CountPerf());
    }

    [Fact]
    public void ShieldBuilderWithPerfTelemetryFullEmitsStageAndPolicyEvents()
    {
        var provider = new CaptureProvider();
        using var shield = Shield.FromYaml(FixturePath())
            .WithObservability(provider)
            .WithPerfTelemetry(PerfTelemetry.Full)
            .Build();

        shield.Session.ValidateInput("hello");
        shield.Runtime.FlushObservability();

        var emittedTypes = provider.Events
            .Select(e => e.GetProperty("event_type").GetString())
            .Where(t => t != null)
            .ToHashSet();
        Assert.Contains("stage_evaluated", emittedTypes);
        Assert.Contains("policy_evaluated", emittedTypes);
    }

    [Fact]
    public void ShieldBuilderWithPerfTelemetryExternalEmitsNoStageOrPolicyEvents()
    {
        var provider = new CaptureProvider();
        using var shield = Shield.FromYaml(FixturePath())
            .WithObservability(provider)
            .WithPerfTelemetry(PerfTelemetry.External)
            .Build();

        shield.Session.ValidateInput("hello");
        shield.Runtime.FlushObservability();

        Assert.Equal(0, provider.CountPerf());
    }
}
