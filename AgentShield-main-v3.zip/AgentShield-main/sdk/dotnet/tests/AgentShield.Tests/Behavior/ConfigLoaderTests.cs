using System.Collections.Generic;
using System.IO;
using System.Text.Json.Nodes;
using System;
using AgentShield;
using Xunit;

namespace AgentShield.Tests;

public class BuilderConsumeTests
{
    private const string ExpectedMessage =
        "ShieldBuilder.Build() can only be called once. " +
        "Call Shield.FromYaml(...) again to create a new builder.";

    private static string FixturePath()
    {
        var dir = AppContext.BaseDirectory;
        while (dir != null && !File.Exists(Path.Combine(dir, "tests", "fixtures", "test-guardrails.yaml")))
            dir = Directory.GetParent(dir)?.FullName;
        if (dir == null)
            throw new FileNotFoundException("Could not locate tests/fixtures/test-guardrails.yaml");
        return Path.Combine(dir, "tests", "fixtures", "test-guardrails.yaml");
    }

    [Fact]
    public void FirstBuildReturnsWorkingShield()
    {
        using var shield = Shield.FromYaml(FixturePath()).Build();
        Assert.NotNull(shield);
        Assert.NotNull(shield.Capabilities);
    }

    [Fact]
    public void SecondBuildThrowsInvalidOperationException()
    {
        var builder = Shield.FromYaml(FixturePath());
        using var first = builder.Build();

        var ex = Assert.Throws<InvalidOperationException>(() => builder.Build());
        Assert.Equal(ExpectedMessage, ex.Message);
    }

    [Fact]
    public void WithMethodAfterBuildThrowsInvalidOperationException()
    {
        var builder = Shield.FromYaml(FixturePath());
        using var first = builder.Build();

        var ex = Assert.Throws<InvalidOperationException>(() => builder.WithMode(ShieldMode.Monitor));
        Assert.Equal(ExpectedMessage, ex.Message);
    }

    [Fact]
    public void WithOnBlockAfterBuildThrowsInvalidOperationException()
    {
        var builder = Shield.FromYaml(FixturePath());
        using var first = builder.Build();

        var ex = Assert.Throws<InvalidOperationException>(
            () => builder.WithOnBlock(OnBlockPolicy.Raise));
        Assert.Equal(ExpectedMessage, ex.Message);
    }

    [Fact]
    public void FreshFromYamlAfterBuildProducesIndependentBuilder()
    {
        using var first = Shield.FromYaml(FixturePath()).Build();

        using var second = Shield.FromYaml(FixturePath()).WithMode(ShieldMode.Monitor).Build();
        Assert.NotNull(second);
    }
}

public class GuardrailsConfigTests
{
    private static readonly string MinimalFixture = Path.Combine(
        FindRepoRoot(),
        "tests", "fixtures", "smoke", "minimal.guardrails.yaml");

    private static string FindRepoRoot()
    {
        var dir = AppContext.BaseDirectory;
        while (dir is not null
               && !Directory.Exists(Path.Combine(dir, ".git"))
               && !File.Exists(Path.Combine(dir, ".git")))
        {
            dir = Path.GetDirectoryName(dir);
        }
        return dir ?? throw new InvalidOperationException("repo root not found");
    }

    [Fact]
    public void Load_FromPath()
    {
        var cfg = GuardrailsConfig.Load(MinimalFixture);
        Assert.Equal(1, cfg.Count);
    }

    [Fact]
    public void FromString_RawYaml()
    {
        var text = File.ReadAllText(MinimalFixture);
        var cfg = GuardrailsConfig.FromString(text);
        Assert.Equal(1, cfg.Count);
    }

    [Fact]
    public void FromObject_Dictionary()
    {
        var cfg = GuardrailsConfig.FromObject(new Dictionary<string, object?>
        {
            ["metadata"] = new Dictionary<string, object?>
            {
                ["name"] = "x",
                ["version"] = "0.1.0",
            },
        });
        Assert.Equal(1, cfg.Count);
    }

    [Fact]
    public void Compose_ChainsMultipleSources()
    {
        var cfg = GuardrailsConfig.Compose(
            MinimalFixture,
            new Dictionary<string, object?>
            {
                ["metadata"] = new Dictionary<string, object?>
                {
                    ["description"] = "overlay",
                },
            });
        Assert.Equal(2, cfg.Count);
    }

    [Fact]
    public void Compose_EmptyThrows()
    {
        Assert.Throws<ArgumentException>(() => GuardrailsConfig.Compose());
    }

    [Fact]
    public void Extend_ReturnsNewInstance()
    {
        var a = GuardrailsConfig.Load(MinimalFixture);
        var b = a.Extend(new Dictionary<string, object?>
        {
            ["metadata"] = new Dictionary<string, object?>
            {
                ["description"] = "leaf",
            },
        });
        Assert.Equal(1, a.Count);
        Assert.Equal(2, b.Count);
    }

    [Fact]
    public void WithOverrides_AppendsDictLayer()
    {
        var cfg = GuardrailsConfig.Load(MinimalFixture)
            .WithOverrides(new Dictionary<string, object?>
            {
                ["metadata"] = new Dictionary<string, object?>
                {
                    ["description"] = "monitoring",
                },
            });
        Assert.Equal(2, cfg.Count);
    }

    [Fact]
    public void WithPolicyPack_DictionaryPath()
    {
        var cfg = GuardrailsConfig.Load(MinimalFixture)
            .WithPolicyPack(new Dictionary<string, object?>
            {
                ["metadata"] = new Dictionary<string, object?>
                {
                    ["description"] = "tenant pack",
                },
            });
        Assert.Equal(2, cfg.Count);
    }

    [Fact]
    public void Compile_YieldsYamlStringsAndSha256()
    {
        var compiled = GuardrailsConfig.Load(MinimalFixture).Compile();
        Assert.Single(compiled.YamlStrings);
        Assert.Contains("smoke-minimal", compiled.YamlStrings[0]);
        Assert.Equal(64, compiled.Digest.Length);
        Assert.Matches("^[0-9a-f]+$", compiled.Digest);
        Assert.Equal(compiled.Digest, compiled.Hash);
    }

    [Fact]
    public void Compile_DeterministicForSameContent()
    {
        var a = GuardrailsConfig.Load(MinimalFixture).Compile();
        var b = GuardrailsConfig.Load(MinimalFixture).Compile();
        Assert.Equal(a, b);
        Assert.Equal(a.Digest, b.Digest);
        Assert.Equal(a.GetHashCode(), b.GetHashCode());
    }

    [Fact]
    public void Compile_DiffersWhenLayersChange()
    {
        var a = GuardrailsConfig.Load(MinimalFixture).Compile();
        var b = GuardrailsConfig.Load(MinimalFixture)
            .WithOverrides(new Dictionary<string, object?>
            {
                ["metadata"] = new Dictionary<string, object?>
                {
                    ["description"] = "different",
                },
            })
            .Compile();
        Assert.NotEqual(a, b);
        Assert.NotEqual(a.Digest, b.Digest);
    }

    [Fact]
    public void FromConfig_AcceptsCompiledPolicy()
    {
        var compiled = GuardrailsConfig.Load(MinimalFixture).Compile();
        using var rt = RuntimeBuilder.FromConfig(compiled).Build();
        Assert.NotNull(rt);
    }

    [Fact]
    public void FromConfig_AcceptsGuardrailsConfig()
    {
        var cfg = GuardrailsConfig.Load(MinimalFixture);
        using var rt = RuntimeBuilder.FromConfig(cfg).Build();
        Assert.NotNull(rt);
    }

    [Fact]
    public void FromYamlStrings_RoundTrips()
    {
        var text = File.ReadAllText(MinimalFixture);
        using var rt = RuntimeBuilder.FromYamlStrings(new[] { text }).Build();
        Assert.NotNull(rt);
    }

    [Fact]
    public void CompiledPolicy_CacheableByDigest()
    {
        var a = GuardrailsConfig.Load(MinimalFixture).Compile();
        var b = GuardrailsConfig.Load(MinimalFixture).Compile();
        var cache = new Dictionary<string, string>();
        cache[a.Digest] = "runtime-A";
        Assert.Equal("runtime-A", cache[b.Digest]);
    }
}

public class CapabilityReportTests
{
    [Fact]
    public void DefaultsAllStagesToFull()
    {
        var rep = new CapabilityReport("test");
        Assert.True(rep.IsFullCoverage());
    }

    [Fact]
    public void HonoursPerStageOverrides()
    {
        var rep = new CapabilityReport(
            "test",
            streamingOutput: CoverageLevel.Unsupported);
        Assert.False(rep.IsFullCoverage());
        Assert.Equal(CoverageLevel.Unsupported, rep.StreamingOutput);
    }

    [Fact]
    public void NotesAreCarriedThrough()
    {
        var rep = new CapabilityReport(
            "test",
            notes: new[] { "caveat 1", "caveat 2" });
        Assert.Equal(2, rep.Notes.Count);
        Assert.Contains("caveat 1", rep.Notes);
    }
}

public class AgentShieldBlockedExceptionTests
{
    [Fact]
    public void CarriesVerdictAndMessage()
    {
        var exc = new AgentShieldBlockedException(null, "blocked");
        Assert.Equal("blocked", exc.Message);
        Assert.Null(exc.Verdict);
        Assert.IsAssignableFrom<Exception>(exc);
    }
}

public class LoaderTypedErrorTests : IDisposable
{
    private readonly string _tmpDir;

    public LoaderTypedErrorTests()
    {
        _tmpDir = Path.Combine(
            Path.GetTempPath(),
            "agent-shield-loader-typed-" + Guid.NewGuid().ToString("N").Substring(0, 8));
        Directory.CreateDirectory(_tmpDir);
    }

    public void Dispose()
    {
        try { Directory.Delete(_tmpDir, recursive: true); } catch { /* best-effort */ }
        GC.SuppressFinalize(this);
    }

    private const string MinimalValid = """
metadata:
  name: "test-valid"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["pass"]
  forbidden: ["fail"]
resources:
  tools:
    - name: "echo"
      description: "echo"
      permission: "read_only"
""";

    private string WriteFixture(string name, string content)
    {
        var p = Path.Combine(_tmpDir, name);
        File.WriteAllText(p, content);
        return p;
    }

    [Fact]
    public void TypedExceptionIsSubclassOfGuardrailsConfigException()
    {
        var ex = new AgentShieldConfigException("boom");
        Assert.IsAssignableFrom<GuardrailsConfigException>(ex);
        Assert.IsAssignableFrom<GuardrailsException>(ex);
        Assert.IsAssignableFrom<Exception>(ex);
    }

    [Fact]
    public void UnparseableYamlThrowsTypedExceptionWithStructuredFields()
    {
        var path = WriteFixture(
            "unparseable.guardrails.yaml",
            "{this is: not yaml\n  - and: [broken");
        var ex = Assert.Throws<AgentShieldConfigException>(() =>
        {
            using var b = RuntimeBuilder.FromYaml(path);
        });
        Assert.Equal("unparseable_yaml", ex.Code);
        Assert.True(ex.Line.HasValue || ex.Column.HasValue,
            "Expected serde_yaml line/column to surface on the typed exception.");
    }

    [Fact]
    public void SchemaViolationCarriesPathAndCode()
    {
        var path = WriteFixture("bad-schema.guardrails.yaml", """
metadata:
  name: "x"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: "this should be a list"
  forbidden: ["fail"]
""");
        var ex = Assert.Throws<AgentShieldConfigException>(() =>
        {
            using var b = RuntimeBuilder.FromYaml(path);
        });
        Assert.Contains("bad-schema.guardrails.yaml", ex.Path ?? string.Empty);
        Assert.False(string.IsNullOrEmpty(ex.Code), "Expected a stable snake_case code.");
    }

    [Fact]
    public void UnknownResolverKindThrowsTypedException()
    {
        var path = WriteFixture("bad-resolver.guardrails.yaml", """
metadata:
  name: "x"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["pass"]
  forbidden: ["fail"]
resources:
  tools:
    - name: "echo"
      description: "echo"
      permission: "read_only"
resolvers:
  - id: "bad"
    kind: "telepathy"
""");
        var ex = Assert.Throws<AgentShieldConfigException>(() =>
        {
            using var b = RuntimeBuilder.FromYaml(path);
        });
        Assert.False(string.IsNullOrEmpty(ex.Code));
    }

    [Fact]
    public void ExtendsCycleThrowsTypedExceptionWithCycleCode()
    {
        var aPath = Path.Combine(_tmpDir, "cycle-a.guardrails.yaml");
        var bPath = Path.Combine(_tmpDir, "cycle-b.guardrails.yaml");
        File.WriteAllText(aPath, "extends: [\"./cycle-b.guardrails.yaml\"]\n" + MinimalValid);
        File.WriteAllText(bPath, "extends: [\"./cycle-a.guardrails.yaml\"]\n" + MinimalValid);

        var ex = Assert.Throws<AgentShieldConfigException>(() =>
        {
            using var b = RuntimeBuilder.FromYaml(aPath);
        });
        Assert.Matches("(?i)extends|cycle", ex.Message);
        Assert.Contains(ex.Code, new[] { "cycle_detected", "extends_cycle" });
    }

    [Fact]
    public void FromYamlChainSurfacesTypedExceptionOnMalformedLeaf()
    {
        var validPath = WriteFixture("chain-base.guardrails.yaml", MinimalValid);
        var badPath = WriteFixture("chain-bad.guardrails.yaml", "{nope: [");
        var ex = Assert.Throws<AgentShieldConfigException>(() =>
        {
            using var b = RuntimeBuilder.FromYamlChain(new[] { validPath, badPath });
        });
        Assert.False(string.IsNullOrEmpty(ex.Code));
    }

    [Fact]
    public void FromConfigTextSurfacesTypedExceptionOnMalformedYaml()
    {
        var ex = Assert.Throws<AgentShieldConfigException>(() =>
        {
            using var b = RuntimeBuilder.FromConfigText("{this is: not yaml\n  - [");
        });
        Assert.False(string.IsNullOrEmpty(ex.Code));
    }

    [Fact]
    public void NonExistentPathThrowsTypedExceptionWithIoCode()
    {
        var ex = Assert.Throws<AgentShieldConfigException>(() =>
        {
            using var b = RuntimeBuilder.FromYaml("/definitely/does/not/exist/anywhere.yaml");
        });
        Assert.Equal("io_error", ex.Code);
    }

    [Fact]
    public void TypedExceptionStillCatchableViaGuardrailsConfigException()
    {
        var ex = Assert.Throws<AgentShieldConfigException>(() =>
        {
            using var b = RuntimeBuilder.FromYaml("/no/such/file.yaml");
        });
        GuardrailsConfigException upcast = ex;
        Assert.NotNull(upcast);
        Assert.Equal(ex.Message, upcast.Message);
    }
}

public class RuntimeConfigurationLookupTests
{
    private const string ClassifierYaml = @"metadata:
  name: ""classifier-runtime-config-test""
  version: ""0.1.0""
  agent_shield_version: ""2.0""
objective:
  goal: [""test classifier callback""]
  forbidden: []
configurations:
  - id: ""aacs_main""
    type: classifier
    endpoint: ""https://example.cognitiveservices.azure.com/contentsafety/text:analyze""
    threshold: 0.6
    headers:
      Ocp-Apim-Subscription-Key: ""test-key-not-real""
      X-Test-Header: ""marker-runtime-config""
    category_thresholds:
      Hate: 0.5
      Violence: 0.7
    provider_config:
      categories: [""Hate"", ""Violence""]
      output_type: ""FourSeverityLevels""
output_validation:
  guard_policies:
    - name: ""aacs_output_check""
      evaluate_when:
        - classifier:
            configuration: ""aacs_main""
          reason: ""classifier flagged output""
";

    [Fact]
    public void Configuration_UnknownId_ReturnsNull()
    {
        using var rb = RuntimeBuilder.FromYamlStrings(new[] { ClassifierYaml });
        rb.RegisterClassifierCaller(new AllowClassifier());
        using var rt = rb.Build();

        Assert.Null(rt.Configuration("does-not-exist"));
    }

    [Fact]
    public void Configuration_ClassifierEntry_SurfacesEveryYamlField()
    {
        using var rb = RuntimeBuilder.FromYamlStrings(new[] { ClassifierYaml });
        rb.RegisterClassifierCaller(new AllowClassifier());
        using var rt = rb.Build();

        var cfg = rt.Configuration("aacs_main");
        Assert.NotNull(cfg);

        Assert.Equal("aacs_main", (string?)cfg!["id"]);
        Assert.Equal("classifier", (string?)cfg["type"]);
        Assert.Equal(
            "https://example.cognitiveservices.azure.com/contentsafety/text:analyze",
            (string?)cfg["endpoint"]);
        Assert.Equal(0.6, (double?)cfg["threshold"]);

        var headers = cfg["headers"]!.AsObject();
        Assert.Equal("test-key-not-real", (string?)headers["Ocp-Apim-Subscription-Key"]);
        Assert.Equal("marker-runtime-config", (string?)headers["X-Test-Header"]);

        var cats = cfg["category_thresholds"]!.AsObject();
        Assert.Equal(0.5, (double?)cats["Hate"]);
        Assert.Equal(0.7, (double?)cats["Violence"]);

        var pc = cfg["provider_config"]!.AsObject();
        Assert.Equal("FourSeverityLevels", (string?)pc["output_type"]);
        var categories = pc["categories"]!.AsArray();
        Assert.Equal(2, categories.Count);
        Assert.Equal("Hate", (string?)categories[0]);
        Assert.Equal("Violence", (string?)categories[1]);
    }

    [Fact]
    public void Configuration_ClassifierEntry_ExposesFieldsLlmConfigurationFiltersOut()
    {
        using var rb = RuntimeBuilder.FromYamlStrings(new[] { ClassifierYaml });
        rb.RegisterClassifierCaller(new AllowClassifier());
        using var rt = rb.Build();

        var cfg = rt.Configuration("aacs_main");
        Assert.NotNull(cfg);
        Assert.NotNull(cfg!["headers"]);
        Assert.NotNull(cfg["threshold"]);
        Assert.NotNull(cfg["category_thresholds"]);
        Assert.NotNull(cfg["provider_config"]);
    }

    [Fact]
    public void ClassifierCallback_CanReadYamlConfigurationByConfigurationId()
    {
        var holder = new RuntimeHolder();
        var captured = new System.Collections.Generic.List<(string Id, JsonNode? Cfg)>();
        var capturingCaller = new CapturingClassifier(req =>
        {
            var cfg = holder.Runtime?.Configuration(req.ConfigurationId ?? string.Empty);
            captured.Add((req.ConfigurationId ?? string.Empty, cfg));
            return new ClassifierVerdict(Score: 0.0, Threshold: 0.5, Flagged: false);
        });

        using var rb = RuntimeBuilder.FromYamlStrings(new[] { ClassifierYaml });
        rb.RegisterClassifierCaller(capturingCaller);
        using var runtime = rb.Build();
        holder.Runtime = runtime;

        using (var session = runtime.NewSession(new RequestContext(
            SessionId: "sess-runtime-config",
            CorrelationId: "corr-runtime-config")))
        {
            session.BeginTurn();
            session.ValidateOutput("hello world");
        }

        Assert.Single(captured);
        Assert.Equal("aacs_main", captured[0].Id);
        var cfg = captured[0].Cfg;
        Assert.NotNull(cfg);
        Assert.Equal("classifier", (string?)cfg!["type"]);
        Assert.Equal(
            "https://example.cognitiveservices.azure.com/contentsafety/text:analyze",
            (string?)cfg["endpoint"]);
        Assert.Equal(0.6, (double?)cfg["threshold"]);
        var headers = cfg["headers"]!.AsObject();
        Assert.Equal("test-key-not-real", (string?)headers["Ocp-Apim-Subscription-Key"]);
        var pc = cfg["provider_config"]!.AsObject();
        Assert.Equal("FourSeverityLevels", (string?)pc["output_type"]);
    }

    [Fact]
    public void Configuration_DisposedRuntime_Throws()
    {
        var rb = RuntimeBuilder.FromYamlStrings(new[] { ClassifierYaml });
        rb.RegisterClassifierCaller(new AllowClassifier());
        var rt = rb.Build();
        rt.Dispose();
        rb.Dispose();

        Assert.Throws<GuardrailsDisposedException>(() => rt.Configuration("aacs_main"));
    }

    private sealed class AllowClassifier : IClassifierCaller
    {
        public ClassifierVerdict Call(LlmRequest request) =>
            new ClassifierVerdict(Score: 0.0, Threshold: 0.5, Flagged: false);
    }

    private sealed class CapturingClassifier : IClassifierCaller
    {
        private readonly Func<LlmRequest, ClassifierVerdict> _impl;
        public CapturingClassifier(Func<LlmRequest, ClassifierVerdict> impl) => _impl = impl;
        public ClassifierVerdict Call(LlmRequest request) => _impl(request);
    }

    private sealed class RuntimeHolder
    {
        public GuardrailsRuntime? Runtime { get; set; }
    }
}
