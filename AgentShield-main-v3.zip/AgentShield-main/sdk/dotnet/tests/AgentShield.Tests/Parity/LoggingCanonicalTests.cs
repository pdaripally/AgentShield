using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System;
using AgentShield;
using Xunit;

namespace AgentShield.Tests.Parity;

public class LoggingCanonicalTests
{
    private const string MinimalYaml = @"
metadata:
  name: ""parity-logging-canonical""
  version: ""0.1.0""
  agent_shield_version: ""2.0""
objective:
  goal: [""parity test""]
  forbidden: [""nothing""]
resources:
  tools:
    - name: ""echo""
      description: ""Echo tool for the logging-canonical parity test.""
      permission: ""read_only""
";

    private static readonly HashSet<string> InfoPlusSeverities = new(StringComparer.Ordinal)
    {
        "info", "low", "medium", "high", "critical",
    };

    private sealed class CapturingProvider : IObservabilityProvider
    {
        public ConcurrentBag<JsonElement> Events { get; } = new();

        public void OnLogEvent(JsonElement eventJson)
        {
            using var doc = JsonDocument.Parse(eventJson.GetRawText());
            Events.Add(doc.RootElement.Clone());
        }
    }

    private static string FindRepoRoot()
    {
        var dir = AppContext.BaseDirectory;
        while (dir is not null
               && !Directory.Exists(Path.Combine(dir, ".git"))
               && !File.Exists(Path.Combine(dir, ".git")))
            dir = Path.GetDirectoryName(dir);
        return dir ?? throw new InvalidOperationException("repo root not found");
    }

    private static string FixturePath() =>
        Path.Combine(FindRepoRoot(), "tests", "parity", "logging_canonical.json");

    private static void AssertWireValueMatchesContract(
        string eventTypeForMessage,
        string jsonKey,
        JsonElement value,
        JsonElement spec
    )
    {
        var expectedType = spec.GetProperty("type").GetString()
            ?? throw new InvalidOperationException("required_fields[].type missing");

        switch (expectedType)
        {
            case "string":
            case "string-enum":
                Assert.True(
                    value.ValueKind == JsonValueKind.String,
                    $"Info+ event '{eventTypeForMessage}': field '{jsonKey}' must serialize as string, got {value.ValueKind}"
                );
                if (expectedType == "string-enum" && spec.TryGetProperty("values", out var allowedValues))
                {
                    var actual = value.GetString() ?? string.Empty;
                    var allowed = allowedValues
                        .EnumerateArray()
                        .Select(v => v.GetString() ?? string.Empty)
                        .ToArray();
                    Assert.Contains(actual, allowed);
                }
                break;

            default:
                throw new InvalidOperationException($"unsupported contract field type '{expectedType}'");
        }
    }

    [Fact]
    public void EveryInfoPlusEventCarriesTheCanonicalSevenFields()
    {
        var fixture = FixturePath();
        Assert.True(File.Exists(fixture), $"fixture not found at {fixture}");

        using var doc = JsonDocument.Parse(File.ReadAllText(fixture));
        var requiredFields = doc.RootElement.GetProperty("required_fields");

        var expectedNames = new[]
        {
            "session_id", "correlation_id", "stage", "action",
            "event_type", "severity", "agent_id",
        };
        var actualNames = requiredFields.EnumerateArray()
            .Select(f => f.GetProperty("name").GetString())
            .ToArray();
        Assert.Equal(expectedNames, actualNames);

        var provider = new CapturingProvider();
        DriveRepresentativeInteraction(provider);

        Assert.NotEmpty(provider.Events);

        var infoPlusSeen = 0;
        foreach (var ev in provider.Events)
        {
            var severity = ev.GetProperty("severity").GetString() ?? string.Empty;
            if (!InfoPlusSeverities.Contains(severity))
            {
                continue;
            }
            infoPlusSeen++;

            var eventTypeForMsg = ev.TryGetProperty("event_type", out var et)
                ? (et.ValueKind == JsonValueKind.String ? et.GetString() ?? "<unknown>" : et.ToString())
                : "<unknown>";

            foreach (var spec in requiredFields.EnumerateArray())
            {
                var fieldName = spec.GetProperty("dotnet_field").GetString()
                    ?? throw new InvalidOperationException("required_fields[].dotnet_field missing");
                var jsonKey = spec.GetProperty("name").GetString()
                    ?? throw new InvalidOperationException("required_fields[].name missing");
                var nullable = spec.TryGetProperty("nullable", out var n) && n.GetBoolean();
                var present = ev.TryGetProperty(jsonKey, out var value);

                if (!nullable)
                {
                    Assert.True(
                        present,
                        $"Info+ event '{eventTypeForMsg}' is missing required field '{jsonKey}' on the wire (dotnet_field: {fieldName})"
                    );

                    Assert.True(
                        value.ValueKind != JsonValueKind.Null,
                        $"Info+ event '{eventTypeForMsg}': required field '{jsonKey}' is null but contract says non-nullable"
                    );

                    if (value.ValueKind == JsonValueKind.String)
                    {
                        var s = value.GetString() ?? string.Empty;
                        Assert.True(
                            s.Length > 0,
                            $"Info+ event '{eventTypeForMsg}': required field '{jsonKey}' is empty string but contract says non-nullable"
                        );
                    }

                    AssertWireValueMatchesContract(eventTypeForMsg, jsonKey, value, spec);
                    continue;
                }

                if (present)
                {
                    Assert.True(
                        value.ValueKind != JsonValueKind.Null,
                        $"Info+ event '{eventTypeForMsg}': nullable field '{jsonKey}' must be omitted or typed on the wire, got null"
                    );
                    AssertWireValueMatchesContract(eventTypeForMsg, jsonKey, value, spec);
                }
            }
        }

        Assert.True(
            infoPlusSeen > 0,
            "expected at least one Info+ event in the captured stream"
        );
    }

    private static void DriveRepresentativeInteraction(CapturingProvider provider)
    {
        using var builder = RuntimeBuilder.FromYamlStrings(new[] { MinimalYaml });
        builder.RegisterObservabilityProvider(provider);
        using var runtime = builder.Build();
        using var session = runtime.NewSession(
            new RequestContext(SessionId: "sess-parity", CorrelationId: "corr-parity")
        );

        session.BeginTurn();
        session.ValidateInput("hello");
        var toolParams = JsonSerializer.SerializeToElement(new { msg = "ping" });
        session.ValidateToolCall("echo", toolParams, "tc-parity");
        var toolResult = JsonSerializer.SerializeToElement(new { @out = "pong" });
        session.RecordToolSuccess("echo", toolResult);
        session.ValidateOutput("agent said: pong");
        session.EndTurn();
    }
}
