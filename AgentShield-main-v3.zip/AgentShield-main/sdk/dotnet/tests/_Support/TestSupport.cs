using System.Text.Json;

namespace AgentShield.Tests.Support;

public static class TestPaths
{
    public static string RepoRoot
    {
        get
        {
            var dir = AppContext.BaseDirectory;
            while (dir != null && !File.Exists(Path.Combine(dir, "AgentShield.sln")))
            {
                dir = Directory.GetParent(dir)?.FullName;
            }

            return dir ?? throw new DirectoryNotFoundException("Could not locate the repository root.");
        }
    }

    public static string Fixture(string name) => Path.Combine(RepoRoot, "tests", "fixtures", name);

    public static string SmokeFixture(string name) => Path.Combine(RepoRoot, "tests", "fixtures", "smoke", name);

    public static string ContractFixture(string name) => Path.Combine(RepoRoot, "tests", "fixtures", "contract", name);

    public static string CaseDirectory => Path.Combine(RepoRoot, "tests", "cases");
}

public static class JsonTest
{
    public static JsonElement Parse(string json) => JsonDocument.Parse(json).RootElement.Clone();
}
