using System.IO;
using System;
using AgentShield.MCP;
using AgentShield;
using Xunit;

namespace AgentShield.MCP.Tests;

public class MCPShieldTests
{
    private static readonly string MinimalFixture = Path.Combine(
        FindRepoRoot(),
        "tests", "fixtures", "smoke", "minimal.guardrails.yaml");

    private static string FindRepoRoot()
    {
        var dir = AppContext.BaseDirectory;
        while (dir is not null
               && !Directory.Exists(Path.Combine(dir, ".git"))
               && !File.Exists(Path.Combine(dir, ".git")))
            dir = Path.GetDirectoryName(dir);
        return dir ?? throw new InvalidOperationException("repo root not found");
    }

    [Fact]
    public void CapabilityReport_DescribesMcpProfile()
    {
        using var shield = MCPShield.FromYaml(MinimalFixture).Build();
        var rep = shield.Capabilities;

        Assert.Equal("mcp", rep.Framework);
        Assert.Equal(CoverageLevel.Unsupported, rep.InputValidation);
        Assert.Equal(CoverageLevel.Unsupported, rep.OutputValidation);
        Assert.Equal(CoverageLevel.Unsupported, rep.StreamingOutput);
        Assert.Equal(CoverageLevel.Full, rep.ToolAuthorization);
        Assert.Equal(CoverageLevel.Full, rep.ToolExecutionValidation);
        Assert.Equal(CoverageLevel.Full, rep.ToolOutputValidation);
        Assert.NotEmpty(rep.Notes);
    }

    [Fact]
    public void ProtectTool_BlocksWithoutAuthorization()
    {
        using var shield = MCPShield.FromYaml(MinimalFixture).Build();
        using var session = shield.Runtime.NewSession();
        session.BeginTurn();

        var (allowed, _, msg) = shield.ProtectTool(
            "echo",
            "{\"msg\":\"hi\"}",
            "tc_block",
            session);

        Assert.False(allowed);
        Assert.NotNull(msg);
        Assert.Contains("GUARDRAIL", msg);
    }

    [Fact]
    public void ProtectTool_AllowsWhenAuthorized()
    {
        using var shield = MCPShield.FromYaml(MinimalFixture).Build();
        using var session = shield.Runtime.NewSession();
        session.BeginTurn();
        using var trueDoc = System.Text.Json.JsonDocument.Parse("true");
        session.SetVariable("authorized", trueDoc.RootElement.Clone());

        var (allowed, effective, msg) = shield.ProtectTool(
            "echo",
            "{\"msg\":\"hi\"}",
            "tc_allow",
            session);

        Assert.True(allowed);
        Assert.Null(msg);
        Assert.Contains("hi", effective);
    }

    [Fact]
    public void ProtectToolOutput_AllowsResult()
    {
        using var shield = MCPShield.FromYaml(MinimalFixture).Build();
        using var session = shield.Runtime.NewSession();
        session.BeginTurn();
        using var trueDoc = System.Text.Json.JsonDocument.Parse("true");
        session.SetVariable("authorized", trueDoc.RootElement.Clone());

        const string toolCallId = "tc_output";
        var (admitted, _, _) = shield.ProtectTool(
            "echo",
            "{\"msg\":\"hi\"}",
            toolCallId,
            session);
        Assert.True(admitted);

        var (allowed, output, msg) = shield.ProtectToolOutput(
            "echo",
            "result",
            toolCallId,
            session);

        Assert.True(allowed);
        Assert.Null(msg);
        Assert.Equal("result", output);
    }

    [Fact]
    public void ProtectTool_RequiresNonEmptyToolCallId_Section_16_0()
    {
        using var shield = MCPShield.FromYaml(MinimalFixture).Build();

        Assert.Throws<ArgumentNullException>(() =>
            shield.ProtectTool("echo", "{\"msg\":\"hi\"}", null!));
        Assert.Throws<ArgumentException>(() =>
            shield.ProtectTool("echo", "{\"msg\":\"hi\"}", ""));
        Assert.Throws<ArgumentException>(() =>
            shield.ProtectTool("echo", "{\"msg\":\"hi\"}", "   "));

        Assert.Throws<ArgumentNullException>(() =>
            shield.ProtectToolOutput("echo", "result", null!));
        Assert.Throws<ArgumentException>(() =>
            shield.ProtectToolOutput("echo", "result", ""));
    }

    [Fact]
    public void Builder_AcceptsGuardrailsConfig()
    {
        var cfg = GuardrailsConfig.Load(MinimalFixture);
        using var shield = MCPShield.FromConfig(cfg).Build();
        Assert.NotNull(shield.Runtime);
    }

    [Fact]
    public void MCPGuardrailBlockedException_IsExceptionSubclass()
    {
        var exc = new MCPGuardrailBlockedException("echo", "msg");
        Assert.IsAssignableFrom<Exception>(exc);
        Assert.Equal("echo", exc.ToolName);
        Assert.Equal("msg", exc.Message);
    }

    [Fact]
    public void Default_ScopeIsConnection_AndSessionStateSpansCalls()
    {
        using var shield = MCPShield.FromYaml(MinimalFixture).Build();
        Assert.Equal(SessionScope.Connection, shield.SessionScope);

        var sess = shield.Session;
        Assert.NotNull(sess);
        sess!.BeginTurn();
        using var trueDoc = System.Text.Json.JsonDocument.Parse("true");
        sess.SetVariable("authorized", trueDoc.RootElement.Clone());

        var (allowed1, _, _) = shield.ProtectTool("echo", "{\"msg\":\"first\"}", "tc_first");
        var (allowed2, _, _) = shield.ProtectTool("echo", "{\"msg\":\"second\"}", "tc_second");
        Assert.True(allowed1);
        Assert.True(allowed2);
    }

    [Fact]
    public void CallScope_DoesNotShareStateAcrossCalls()
    {
        using var shield = MCPShield.FromYaml(MinimalFixture)
            .WithSessionScope(SessionScope.Call)
            .Build();
        Assert.Equal(SessionScope.Call, shield.SessionScope);
        Assert.Null(shield.Session);

        var (allowed, _, msg) = shield.ProtectTool("echo", "{\"msg\":\"hi\"}", "tc_call_scope");
        Assert.False(allowed);
        Assert.NotNull(msg);
        Assert.Contains("GUARDRAIL", msg);
    }

    [Fact]
    public void ResetSession_DropsHeldSession()
    {
        using var shield = MCPShield.FromYaml(MinimalFixture).Build();
        var s1 = shield.Session;
        Assert.NotNull(s1);
        shield.ResetSession();
        var s2 = shield.Session;
        Assert.NotNull(s2);
        Assert.NotSame(s1, s2);
    }
}
