# Rust Anthropic adapter mediation

## Mediated paths
- `protect_tool(...)` and `protect_tool_output(...)` mediate Stage 2/3/4 at `sdk/rust/agent_shield_anthropic/src/lib.rs:118` and `sdk/rust/agent_shield_anthropic/src/lib.rs:132`.
- `guard_messages(...)` and `guard_response(...)` mediate Stage 1/5 at `sdk/rust/agent_shield_anthropic/src/lib.rs:162` and `sdk/rust/agent_shield_anthropic/src/lib.rs:195`.
- `protect_tool_executor(...)` wraps the async executor at `sdk/rust/agent_shield_anthropic/src/lib.rs:228`.

## Unsupported paths
- Direct tool execution that does not call `protect_tool_executor(...)`.
- Raw Anthropic message parsing outside `guard_messages(...)` / `guard_response(...)`.
- Framework-native streaming chunk surfaces beyond `stream_complete(...)`.

## Bypass risks
- Keeping the raw tool executor reachable after installing the guarded executor.
- Treating non-text content blocks as covered by the Stage-5 helper.
- Assuming streamed Stage-4 tool-result chunks are bound; the crate only validates the assembled result today.

## Streaming behavior
- Rule 1 — ✓ `stream_complete(...)` validates the accumulated text after chunk coalescing.
- Rule 2 — ✓ the public stream helper releases only validated final text, so the unvalidated window is zero.
- Rule 3 — ✓ `stream_complete(...)` now routes through the session-owned `StreamingGuard`, so policy stops emit `incident.stream_aborted` and the helper still buffers final output by default.
- Rule 4 — ✓ the same shared `StreamingGuard` emits `incident.stream_limit_exceeded` when the stream hits the core buffer bound.
- Rule 5 — ✓ Stage-4 tool outputs stay bound through `tool_call_id`; streamed Stage-4 chunks are not exposed separately.

## Unknown tool-call shapes
- Unknown/non-text blocks are ignored rather than fail-closed, so the crate does not yet emit `incident.unknown_invocation_shape`.

## See also

See [Post-tool limits and dangerous patterns](../../../docs/POST_TOOL_LIMITS.md) and the [adapter-mediated path matrix](../../../docs/adapter-mediated-paths.md).
