//! `Shield`-builder extension trait for the Anthropic adapter.
//!
//! Exports a [`CAPABILITY_REPORT`] constant and a [`ShieldAnthropicExt`]
//! trait that adds [`with_anthropic`](ShieldAnthropicExt::with_anthropic)
//! to [`agent_shield::ShieldBuilder`].
//!
//! # Example (≤ 5 lines)
//!
//! ```no_run
//! # fn ex() -> Result<(), Box<dyn std::error::Error>> {
//! use agent_shield::Shield;
//! use agent_shield_anthropic::ShieldAnthropicExt;
//! let shield = Shield::from_yaml(".guardrails.yaml").with_anthropic().build()?;
//! # let _ = shield; Ok(()) }
//! ```

use agent_shield::{CapabilityReport, CoverageLevel, ShieldBuilder};

/// Honest capability report for the Anthropic adapter.
///
/// Stage 2/3/4 work because the adapter wraps tool executors via
/// [`crate::protect_tool_executor`]. Streaming output is marked
/// `Partial` because the Anthropic streaming protocol delivers
/// `content_block_delta` events at character/token boundaries that
/// can split detection patterns across chunks; the adapter detects
/// final-message redactions after `message_stop`, but chunk-level
/// redaction is not reliable.
pub const CAPABILITY_REPORT: CapabilityReport = CapabilityReport {
    framework: String::new(),
    input_validation: Some(CoverageLevel::Full),
    state_validation: Some(CoverageLevel::Full),
    tool_authorization: Some(CoverageLevel::Full),
    tool_execution_validation: Some(CoverageLevel::Full),
    tool_output_validation: Some(CoverageLevel::Full),
    output_validation: Some(CoverageLevel::Full),
    streaming_output: Some(CoverageLevel::Partial),
    notes: Vec::new(),
};

fn report() -> CapabilityReport {
    CapabilityReport {
        framework: "anthropic".to_string(),
        notes: vec!["streaming_output is partial: chunk-level redaction across \
             content_block_delta events is not reliable; final-message \
             validation runs after message_stop"
            .to_string()],
        ..CAPABILITY_REPORT
    }
}

/// Extension trait adding `with_anthropic` to [`ShieldBuilder`].
pub trait ShieldAnthropicExt {
    /// Install the Anthropic capability report.
    fn with_anthropic(self) -> Self;
}

impl ShieldAnthropicExt for ShieldBuilder {
    fn with_anthropic(self) -> Self {
        self.with_capability(report())
    }
}
