#![forbid(unsafe_code)]
//! Agent Shield adapter for Anthropic Messages API integrations.
//!
//! Uses raw HTTP-compatible types and the Anthropic `tool_use.id` as the
//! Stage 3 ↔ Stage 4 binding id.

#![allow(clippy::result_large_err)]

pub mod shield_ext;

pub use shield_ext::{ShieldAnthropicExt, CAPABILITY_REPORT};

use std::sync::Arc;

use agent_shield_core::{
    guard_policy_runtime::streaming::StreamingTrigger, AdmissionHandle, GuardrailsSession,
    ObsStage, RuntimeError, StageVerdict, StreamChunkAction,
};
use serde::{Deserialize, Serialize};
use serde_json::Value;

// ── Data types ──────────────────────────────────────────────────────

/// Anthropic tool definition (matches the API's tool schema).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnthropicTool {
    pub name: String,
    #[serde(default)]
    pub description: String,
    pub input_schema: Value,
}

/// Content block in an Anthropic message.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type")]
pub enum ContentBlock {
    #[serde(rename = "text")]
    Text { text: String },
    #[serde(rename = "tool_use")]
    ToolUse {
        id: String,
        name: String,
        input: Value,
    },
    #[serde(rename = "tool_result")]
    ToolResult {
        tool_use_id: String,
        content: String,
    },
}

/// Async tool executor.
///
/// Arguments: `(tool_name, input, tool_call_id)`. Pass the Anthropic
/// `tool_use.id` from the model response as `tool_call_id`.
pub type ToolExecutor = Arc<
    dyn Fn(
            String,
            Value,
            String,
        )
            -> std::pin::Pin<Box<dyn std::future::Future<Output = Result<String, String>> + Send>>
        + Send
        + Sync,
>;

// ── Internal helpers ────────────────────────────────────────────────

fn format_tool_block(tool_name: &str, reason: &str) -> String {
    format!("[Agent Shield] Tool '{}' blocked: {}", tool_name, reason)
}

fn format_tool_output_block(tool_name: &str, reason: &str) -> String {
    format!(
        "[Agent Shield] Tool '{}' output blocked: {}",
        tool_name, reason
    )
}

fn format_tool_error(tool_name: &str, error: &str) -> String {
    format!("[Agent Shield] Tool '{}' error: {}", tool_name, error)
}

fn format_response_block(reason: &str) -> String {
    format!("[Agent Shield] Response blocked: {}", reason)
}

// ── Stage 2+3+4 helpers ─────────────────────────────────────────────

/// Stage 2+3 — guard a tool call.
///
/// Mutates `params` in-place when a Stage 3 transform applies. Returns
/// the verdict; the host runs the tool only when `verdict.allowed`.
/// Reuse `tool_call_id` for the matching Stage 4 [`protect_tool_output`].
pub fn protect_tool(
    session: &GuardrailsSession,
    tool_name: &str,
    params: &mut Value,
    tool_call_id: &str,
) -> StageVerdict {
    session
        .validate_tool_call(tool_name, params, tool_call_id)
        .0
}

/// Stage 4 — guard a tool result. Mutates `result` in-place when a
/// `redact:` transform applies. The host MUST also call
/// [`record_tool_success`] / [`record_tool_failure`] after actually
/// running the tool. `tool_call_id` MUST match the id passed to the
/// paired [`protect_tool`].
pub fn protect_tool_output(
    session: &GuardrailsSession,
    admission: AdmissionHandle,
    result: &mut Value,
) -> StageVerdict {
    session.validate_tool_output(admission, result)
}

/// Record a successful tool execution. Emits `tool.<name>.success`
/// and triggers `phase: after` populators.
pub fn record_tool_success(
    session: &GuardrailsSession,
    tool_name: &str,
    result: &Value,
) -> Result<(), RuntimeError> {
    session.record_tool_success(tool_name, result)
}

/// Record a failed tool execution. Emits `tool.<name>.failure`.
pub fn record_tool_failure(
    session: &GuardrailsSession,
    tool_name: &str,
    error: &str,
) -> Result<(), RuntimeError> {
    session.record_tool_failure(tool_name, error)
}

/// Stage 1 — guard the last user message in a list of Anthropic
/// messages. Returns `Ok(())` on allow, `Err(verdict)` on block.
pub fn guard_messages(
    session: &GuardrailsSession,
    messages: &[(String, Vec<ContentBlock>)],
) -> Result<(), StageVerdict> {
    let mut text = String::new();
    for (role, blocks) in messages.iter().rev() {
        if role == "user" {
            text = blocks
                .iter()
                .filter_map(|b| match b {
                    ContentBlock::Text { text } => Some(text.as_str()),
                    _ => None,
                })
                .collect::<Vec<_>>()
                .join(" ");
            break;
        }
    }
    if text.is_empty() {
        return Ok(());
    }
    let v = session.validate_input(&text);
    if v.allowed {
        Ok(())
    } else {
        Err(v)
    }
}

/// Stage 5 — guard an assistant response. Concatenates text content
/// blocks and validates. Mutates the returned response (a fresh
/// `String`) in-place per the contract; the original `content`
/// slice is untouched.
pub fn guard_response(
    session: &GuardrailsSession,
    content: &[ContentBlock],
) -> (StageVerdict, String) {
    let mut text: String = content
        .iter()
        .filter_map(|b| match b {
            ContentBlock::Text { text } => Some(text.as_str()),
            _ => None,
        })
        .collect::<Vec<_>>()
        .join("");
    if text.is_empty() {
        return (StageVerdict::allow(), text);
    }
    let v = session.validate_output(&mut text);
    (v, text)
}

// ── Tool wrapping ───────────────────────────────────────────────────

/// Wrap an async tool executor with guardrails.
///
/// The returned executor runs Stage 2+3 → real tool → Stage 4 →
/// `record_tool_success` / `record_tool_failure`.
///
/// The wrapped executor takes an `Arc<GuardrailsSession>` so the
/// host can re-use a single session across multiple tool calls inside
/// one Anthropic turn. The caller MUST forward the Anthropic
/// `tool_use.id` from the model response as the third argument so
/// Stage 3 and Stage 4 bind the same invocation.
pub fn protect_tool_executor<F>(session: Arc<GuardrailsSession>, tool_fn: F) -> ToolExecutor
where
    F: Fn(
            String,
            Value,
        )
            -> std::pin::Pin<Box<dyn std::future::Future<Output = Result<String, String>> + Send>>
        + Send
        + Sync
        + 'static,
{
    let exec = Arc::new(tool_fn);
    Arc::new(move |name: String, input: Value, tool_call_id: String| {
        let session = session.clone();
        let exec = exec.clone();
        Box::pin(async move {
            let mut params = input.clone();
            let (verdict, admission) =
                session.validate_tool_call(&name, &mut params, Some(tool_call_id.as_str()));
            if !verdict.allowed {
                return Ok(format_tool_block(
                    &name,
                    verdict.reason.as_deref().unwrap_or("blocked"),
                ));
            }

            let exec_name = name.clone();
            let exec_input = params.clone();
            let res = exec(exec_name, exec_input).await;
            match res {
                Ok(text) => {
                    let mut value = Value::String(text.clone());
                    let post = session.validate_tool_output(
                        admission.expect("allowed Stage 3 returns admission"),
                        &mut value,
                    );
                    if !post.allowed {
                        if let Err(e) = session.record_tool_failure(&name, "post-tool-blocked") {
                            log::warn!(target: "agent_shield::anthropic", "record_tool_failure failed: {e:?}");
                        }
                        return Ok(format_tool_output_block(
                            &name,
                            post.reason.as_deref().unwrap_or("blocked"),
                        ));
                    }
                    if let Err(e) = session.record_tool_success(&name, &value) {
                        log::warn!(target: "agent_shield::anthropic", "record_tool_success failed: {e:?}");
                    }
                    Ok(value.as_str().map(|s| s.to_string()).unwrap_or(text))
                }
                Err(e) => {
                    if let Some(handle) = admission {
                        session.evict_admission(handle);
                    }
                    if let Err(rec_err) = session.record_tool_failure(&name, &e) {
                        log::warn!(target: "agent_shield::anthropic", "record_tool_failure failed: {rec_err:?}");
                    }
                    Ok(format_tool_error(&name, &e))
                }
            }
        })
    })
}

// ── TurnGuard ───────────────────────────────────────────────────────

/// Per-turn guard — borrows a session and drives the boundary
/// events (`begin_turn` / `end_turn`).
///
/// The host can keep a long-lived session and start/stop
/// turns against it. Drop the guard to auto-end the turn.
pub struct TurnGuard<'a> {
    session: &'a GuardrailsSession,
    ended: std::cell::Cell<bool>,
}

impl<'a> TurnGuard<'a> {
    /// Begin a new turn against `session`, run Stage 1 against
    /// `user_input`, and return the guard. Returns `Err(verdict)` if
    /// Stage 1 blocks.
    pub fn begin(session: &'a GuardrailsSession, user_input: &str) -> Result<Self, StageVerdict> {
        if let Err(e) = session.begin_turn() {
            log::warn!(target: "agent_shield::anthropic", "begin_turn failed: {e:?}");
        }
        let v = session.validate_input(user_input);
        if !v.allowed {
            if let Err(e) = session.end_turn() {
                log::warn!(target: "agent_shield::anthropic", "end_turn failed: {e:?}");
            }
            return Err(v);
        }
        Ok(Self {
            session,
            ended: std::cell::Cell::new(false),
        })
    }

    /// Borrow the underlying session.
    pub fn session(&self) -> &GuardrailsSession {
        self.session
    }

    /// Stage 2+3 against the held session. Pair `tool_call_id` with
    /// the matching Stage 4 call.
    pub fn validate_tool_call(
        &self,
        name: &str,
        params: &mut Value,
        tool_call_id: &str,
    ) -> StageVerdict {
        self.session
            .validate_tool_call(name, params, tool_call_id)
            .0
    }

    /// Stage 4 against the held session. the Stage-4 admission handle must come from
    /// the paired Stage 3 call.
    pub fn validate_tool_output(
        &self,
        admission: AdmissionHandle,
        result: &mut Value,
    ) -> StageVerdict {
        self.session.validate_tool_output(admission, result)
    }

    /// Stage 5 against the held session.
    pub fn validate_output(&self, response: &mut String) -> StageVerdict {
        self.session.validate_output(response)
    }

    /// Construct a streaming guard for the given stage (Stage 4 or 5).
    pub fn streaming_session(&self, stage: ObsStage) -> agent_shield_core::StreamingGuard {
        self.session.streaming_session(stage)
    }

    /// Explicitly end the turn. Idempotent.
    pub fn end(&self) {
        if !self.ended.replace(true) {
            if let Err(e) = self.session.end_turn() {
                log::warn!(target: "agent_shield::anthropic", "end_turn failed: {e:?}");
            }
        }
    }
}

impl Drop for TurnGuard<'_> {
    fn drop(&mut self) {
        if !self.ended.replace(true) {
            if let Err(e) = self.session.end_turn() {
                log::warn!(target: "agent_shield::anthropic", "end_turn (Drop) failed: {e:?}");
            }
        }
    }
}

// ── Streaming ───────────────────────────────────────────────────────

/// Result of guarding a streamed Anthropic response.
pub enum GuardStreamResult {
    /// Stream passed; contains the accumulated text.
    Passed(String),
    /// Stream was redacted; contains the post-redaction text.
    Redacted(String),
    /// Stream was blocked; contains the block reason.
    Blocked(String),
}

/// Buffer an Anthropic stream and validate at end-of-stream against
/// Stage 5 using the streaming guard.
///
/// This helper uses `OnComplete` semantics. Hosts that need windowed
/// validation should drive the `StreamingGuard` directly via
/// [`TurnGuard::streaming_session`].
pub async fn stream_complete<C, F>(
    session: &GuardrailsSession,
    mut stream: futures::stream::BoxStream<'_, Result<C, String>>,
    extract_text: F,
) -> GuardStreamResult
where
    C: Send,
    F: Fn(&C) -> String,
{
    use futures::StreamExt;

    let mut guard = session
        .streaming_session(ObsStage::Output)
        .with_trigger(StreamingTrigger::OnComplete);
    while let Some(item) = stream.next().await {
        match item {
            Ok(chunk) => {
                let t = extract_text(&chunk);
                let result = guard.add_chunk(&t);
                if matches!(result.action, StreamChunkAction::Stop) {
                    return GuardStreamResult::Blocked(format_response_block(
                        result.reason.as_deref().unwrap_or("blocked"),
                    ));
                }
            }
            Err(e) => {
                log::warn!(target: "agent_shield::anthropic", "stream error — fail-closed: {e}");
                return GuardStreamResult::Blocked(format_response_block(
                    "stream error — fail-closed",
                ));
            }
        }
    }

    let final_result = guard.end_stream();
    match final_result.action {
        StreamChunkAction::Stop => GuardStreamResult::Blocked(format_response_block(
            final_result.reason.as_deref().unwrap_or("blocked"),
        )),
        StreamChunkAction::Replace => GuardStreamResult::Redacted(final_result.payload),
        StreamChunkAction::Pass => GuardStreamResult::Passed(final_result.payload),
    }
}
