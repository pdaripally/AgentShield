//! Cross-language adapter-scenario harness — Anthropic.
//!
//! See `sdk/rust/adapter_scenarios_common.rs` for the shared body.
//! Mirrors `tests/e2e/run_anthropic_agents.py` and
//! `tests/e2e/node/run-anthropic.test.mjs` so all four languages
//! assert byte-equivalent behaviour over the same shared fixture.

use agent_shield_anthropic::ShieldAnthropicExt;

#[path = "../../adapter_scenarios_common.rs"]
mod common;

#[tokio::test(flavor = "current_thread")]
async fn shared_adapter_scenarios() {
    common::run_with("anthropic", |b| b.with_anthropic()).await;
}
