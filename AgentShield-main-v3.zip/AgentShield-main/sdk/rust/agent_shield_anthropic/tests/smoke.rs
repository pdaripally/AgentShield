//! Smoke tests for the Anthropic adapter.

use std::path::PathBuf;
use std::sync::Arc;

use agent_shield_anthropic as guard;
use agent_shield_anthropic::ContentBlock;
use agent_shield_core::{GuardrailsRuntime, GuardrailsSession, RequestContext, RuntimeBuilder};
use serde_json::json;

fn fixture_path() -> PathBuf {
    let manifest = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    manifest
        .join("../../..")
        .join("tests/fixtures/smoke/minimal.guardrails.yaml")
}

fn build_runtime() -> Arc<GuardrailsRuntime> {
    RuntimeBuilder::from_yaml(fixture_path())
        .unwrap()
        .build()
        .expect("build runtime")
}

fn open_session(rt: &Arc<GuardrailsRuntime>) -> GuardrailsSession {
    rt.new_session(RequestContext::new("sess-1", "corr-1"))
}

#[test]
fn protect_tool_blocks_when_unauthorized() {
    let rt = build_runtime();
    let session = open_session(&rt);
    let mut params = json!({"msg": "hi"});
    let v = guard::protect_tool(&session, "echo", &mut params, "call_1");
    assert!(!v.allowed);
    assert_eq!(v.policy.as_deref(), Some("echo_only_when_authorized"));
}

#[test]
fn protect_tool_allows_when_authorized() {
    let rt = build_runtime();
    let session = open_session(&rt);
    session.set_variable("authorized", json!(true)).unwrap();
    let mut params = json!({"msg": "hi"});
    let v = guard::protect_tool(&session, "echo", &mut params, "call_1");
    assert!(v.allowed);
}

#[test]
fn record_tool_success_emits_event() {
    use agent_shield_core::{EventId, ToolEventKind};
    let rt = build_runtime();
    let session = open_session(&rt);
    let result = json!({"out": "ok"});
    guard::record_tool_success(&session, "echo", &result).unwrap();
    let id = EventId::Tool {
        name: "echo".into(),
        kind: ToolEventKind::Success,
    };
    assert!(rt.bus().fired_id(&id));
}

#[test]
fn record_tool_failure_emits_event() {
    use agent_shield_core::{EventId, ToolEventKind};
    let rt = build_runtime();
    let session = open_session(&rt);
    guard::record_tool_failure(&session, "echo", "boom").unwrap();
    let id = EventId::Tool {
        name: "echo".into(),
        kind: ToolEventKind::Failure,
    };
    assert!(rt.bus().fired_id(&id));
}

#[test]
fn guard_messages_passes_clean_user_text() {
    let rt = build_runtime();
    let session = open_session(&rt);
    let messages = vec![(
        "user".into(),
        vec![ContentBlock::Text {
            text: "hello".into(),
        }],
    )];
    guard::guard_messages(&session, &messages).expect("clean input must pass");
}

#[test]
fn guard_response_passes_clean_assistant_text() {
    let rt = build_runtime();
    let session = open_session(&rt);
    let content = vec![ContentBlock::Text {
        text: "hi there".into(),
    }];
    let (v, text) = guard::guard_response(&session, &content);
    assert!(v.allowed);
    assert_eq!(text, "hi there");
}

#[tokio::test(flavor = "multi_thread", worker_threads = 1)]
async fn turn_guard_drives_validate_tool_call() {
    let rt = build_runtime();
    let session = open_session(&rt);
    session.set_variable("authorized", json!(true)).unwrap();
    let turn = guard::TurnGuard::begin(&session, "hello").expect("input passes");
    let mut params = json!({"msg": "hi"});
    let v = turn.validate_tool_call("echo", &mut params, "call_1");
    assert!(v.allowed);
    turn.end();
}
