//! Smoke tests for the Anthropic `Shield` extension trait.

use std::path::PathBuf;

use agent_shield::{CoverageLevel, Shield};
use agent_shield_anthropic::{ShieldAnthropicExt, CAPABILITY_REPORT};

fn fixture() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("../../..")
        .join("tests/fixtures/smoke/minimal.guardrails.yaml")
}

#[test]
fn capability_report_has_partial_streaming() {
    assert_eq!(
        CAPABILITY_REPORT.streaming_output,
        Some(CoverageLevel::Partial)
    );
    assert_eq!(
        CAPABILITY_REPORT.tool_execution_validation,
        Some(CoverageLevel::Full)
    );
}

#[test]
fn with_anthropic_installs_capability() {
    let shield = Shield::from_yaml(fixture())
        .with_anthropic()
        .build()
        .expect("build");
    assert_eq!(shield.capabilities().framework, "anthropic");
    assert!(!shield.capabilities().notes.is_empty());
}
