//! Basic Agent Shield SDK example.
//!
//! Demonstrates the lifecycle: load YAML → spawn session →
//! validate input → validate tool → validate output.

use std::io::Write;

use agent_shield::{ConsoleObservabilityProvider, RequestContext, Shield};
use serde_json::json;

fn main() -> Result<(), agent_shield::ShieldError> {
    env_logger::init();

    let yaml = r#"
agent_shield_version: "2.0.0"

metadata:
  name: "basic-guard-example"
  version: "0.1.0"

resources:
  tools:
    - name: "web_search"
      description: "Search the web"
      permission: "read"

guard_policies:
  - name: "block_ssn"
    stage: "input"
    action: "block"
    evaluate_when:
      - regex:
          pattern: "\\b\\d{3}-\\d{2}-\\d{4}\\b"
"#;

    let mut tmpfile = tempfile::NamedTempFile::new().unwrap();
    tmpfile.write_all(yaml.as_bytes()).unwrap();

    let shield = Shield::from_yaml(tmpfile.path())
        .with_observability(ConsoleObservabilityProvider::new())
        .build()?;

    println!("✓ Shield loaded\n");

    // ── Turn 1: Clean input ─────────────────────────────────────────
    {
        let session = shield.new_session(RequestContext::new("sess-1", "corr-1"));
        let _ = session.begin_turn();

        let verdict = session.validate_input("What's the weather?");
        println!("Clean input: allowed={}", verdict.allowed);

        let mut params = json!({});
        let (verdict, _) = session.validate_tool_call("web_search", &mut params, "call_1");
        println!("Tool call:   allowed={}", verdict.allowed);

        let mut out = "The weather is sunny.".to_string();
        let verdict = session.validate_output(&mut out);
        println!("Output:      allowed={}", verdict.allowed);

        let _ = session.end_turn();
    }

    // ── Turn 2: Blocked input ───────────────────────────────────────
    {
        let session = shield.new_session(RequestContext::new("sess-2", "corr-2"));
        let _ = session.begin_turn();
        let verdict = session.validate_input("My SSN is 123-45-6789");
        println!(
            "\nSSN input:   allowed={} reason={:?}",
            verdict.allowed, verdict.reason
        );
        let _ = session.end_turn();
    }

    println!("\n✓ All done");
    Ok(())
}
