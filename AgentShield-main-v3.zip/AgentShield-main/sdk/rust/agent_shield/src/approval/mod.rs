//! Built-in `kind: human` resolver handlers.
//!
//! Re-exported from [`agent_shield_core::approval`] so customers can
//! continue importing them via `agent_shield::approval::*`. Hosts
//! choose one handler per runtime with
//! [`agent_shield_core::runtime::RuntimeBuilder::register_human_resolver`].

pub use agent_shield_core::approval::{
    AutoRejectHandler, CallbackApprovalHandler, ConsoleApprovalHandler, HumanRegistry,
    HumanResolveRequest, HumanResolver, HumanResolverFn, PromptReader, ResolverDecision,
    ResolverResponse, StdinPromptReader,
};

/// Console-handler submodule re-export — kept so existing imports
/// like `agent_shield::approval::console::ScriptedReader` continue to
/// work. Everything inside is in [`agent_shield_core::approval::console`].
pub use agent_shield_core::approval::console;
