#![forbid(unsafe_code)]
//! # Agent Shield SDK
//!
//! Ergonomic Rust facade over [`agent_shield_core`]: [`Shield`] /
//! [`ShieldBuilder`] load YAML, wire default delegates, expose turn/tool
//! brackets, register observability and resolver hooks, and surface adapter
//! [`CapabilityReport`]s. Missing LLM / human / agent hooks fail closed.
pub mod approval;
pub mod capabilities;
pub mod constants;
pub mod errors;
pub mod facade;
pub mod observability;
pub mod shield;

pub use capabilities::{CapabilityReport, CoverageLevel};
pub use errors::ShieldError;
pub use facade::GuardedTurn;
pub use observability::ConsoleObservabilityProvider;
pub use shield::{Shield, ShieldBuilder, ShieldMode, ToolWrapper};

// Re-export the core surface so users don't depend on agent_shield_core directly.
pub use agent_shield_core::{
    format_block_message, format_tool_block_message, make_configuration_caller, resolve_on_block,
    Action, AgentResolveRequest, AgentResolver, ClassifierCaller, ClassifierVerdict,
    CompiledPolicy, ConfigurationCaller, DelegateDispatcher, DelegateRequest, EventId,
    FailClosedLlmCaller, GuardrailsConfig, GuardrailsRuntime, GuardrailsSession, Invocation, Layer,
    LlmCaller, LlmDecision, LlmResponse, ObsStage, ObservabilityProvider, OnBlockOutcome,
    OnBlockPolicy, PendingResolution, PerfTelemetry, RequestContext, Resolver, ResolverDecision,
    ResolverResponse, RuntimeBuilder, ShieldLogEvent, StageVerdict, StreamingGuard,
    StreamingOptions, ASK_HUMAN_TOOL_NAME,
};
