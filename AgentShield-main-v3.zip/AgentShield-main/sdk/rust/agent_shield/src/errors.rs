//! `Shield`-level error envelope — the single error type returned by
//! every `Shield` / `ShieldBuilder` entry point.

use agent_shield_core::StageVerdict;

/// Error returned by every `Shield` / `ShieldBuilder` entry point —
/// `ShieldBuilder::build`, `Shield::run`, `Shield::guarded_run`,
/// `Shield::protect_tool`, etc.
#[derive(Debug, thiserror::Error)]
pub enum ShieldError {
    /// A stage verdict denied the action. Carries the canonical
    /// `[GUARDRAIL <ACTION>] <reason>` block message and the raw
    /// verdict for hosts that need to inspect policy / span / action.
    #[error("{message}")]
    Blocked {
        /// Pre-formatted block message (see
        /// [`agent_shield_core::format_block_message`]).
        message: String,
        /// The verdict that triggered the block. Wrapped in `Box` to
        /// keep the variant size small (clippy::result_large_err).
        verdict: Box<StageVerdict>,
    },

    /// Underlying runtime error (lifecycle, dispatch, etc.). Boxed to
    /// keep the variant size small (clippy::result_large_err).
    #[error(transparent)]
    Runtime(Box<agent_shield_core::RuntimeError>),

    /// Configuration loading error surfaced through Shield::from_yaml.
    /// Boxed to keep the variant size small (clippy::result_large_err).
    #[error(transparent)]
    Config(Box<agent_shield_core::ConfigError>),

    /// Auto-wiring failed during [`crate::ShieldBuilder::build`] — YAML
    /// load failure, runtime build failure, or hook misconfiguration
    /// (e.g. registering hooks on a [`crate::Shield::from_runtime`]
    /// builder).
    #[error("auto-wire failed: {0}")]
    AutoWire(String),

    /// Free-form failure (host callback panic conversion, etc.).
    #[error("{0}")]
    Other(String),
}

impl ShieldError {
    /// Construct a `Blocked` error from a verdict using the canonical
    /// block-message format.
    pub fn blocked(verdict: StageVerdict) -> Self {
        let message = agent_shield_core::format_block_message(&verdict);
        Self::Blocked {
            message,
            verdict: Box::new(verdict),
        }
    }

    /// Construct a `Blocked` error using the canonical tool block
    /// message that includes the tool name.
    pub fn blocked_tool(verdict: StageVerdict, tool_name: &str) -> Self {
        let message = agent_shield_core::format_tool_block_message(&verdict, tool_name);
        Self::Blocked {
            message,
            verdict: Box::new(verdict),
        }
    }
}

impl From<agent_shield_core::RuntimeError> for ShieldError {
    fn from(err: agent_shield_core::RuntimeError) -> Self {
        Self::Runtime(Box::new(err))
    }
}

impl From<agent_shield_core::ConfigError> for ShieldError {
    fn from(err: agent_shield_core::ConfigError) -> Self {
        Self::Config(Box::new(err))
    }
}
