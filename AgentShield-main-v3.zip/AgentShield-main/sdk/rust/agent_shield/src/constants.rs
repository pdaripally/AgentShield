//! Centralized constants for the Agent Shield facade SDK.
//!
//! Currently scoped to observability defaults; future bundled providers
//! may add their own families.

use std::time::Duration;

// ── Observability ──────────────────────────────────────────────────

/// Default CloudWatch Logs group name.
pub const DEFAULT_CW_LOG_GROUP: &str = "agent-shield";

/// Default CloudWatch Metrics namespace.
pub const DEFAULT_CW_NAMESPACE: &str = "AgentShield";

/// Default Azure Monitor log stream name.
pub const DEFAULT_AZURE_STREAM: &str = "Custom-AgentShield_CL";

/// Default OpenTelemetry meter name.
pub const DEFAULT_OTEL_METER_NAME: &str = "agent_shield";

/// Default flush interval for buffered observability providers.
pub const DEFAULT_FLUSH_INTERVAL_MS: u64 = 5000;

/// Default max buffer entries for buffered observability providers.
pub const DEFAULT_BUFFER_MAX: usize = 1000;

/// Default HTTP client timeout for cloud-backend flushes.
pub const DEFAULT_HTTP_TIMEOUT: Duration = Duration::from_secs(10);
