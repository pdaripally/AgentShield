//! `Shield` — the canonical orchestrator.
//!
//! `Shield` is the v1.0 ergonomic entry point; it wraps the
//! `Arc<GuardrailsRuntime>` from `agent_shield_core` with:
//!
//! - turn lifecycle helpers ([`Shield::run`], [`Shield::guarded_run`]);
//! - tool-call helpers ([`Shield::protect_tool`]) that bracket
//!   Stage 2/3 → execute → Stage 4 plus `record_tool_success` /
//!   `record_tool_failure`;
//! - a [`ToolWrapper`] hook for adapters' Pattern B fallback
//!   ([`Shield::protect_tools`]);
//! - the [`OnBlockPolicy`] dispatch surface (re-exported from
//!   `agent_shield_core::shield_primitives`);
//! - per-adapter [`crate::CapabilityReport`] surfacing.
//!
//! The legacy `AgentShield` / `AgentShieldBuilder` names are deprecated
//! type aliases for [`Shield`] / [`ShieldBuilder`]; existing call sites
//! continue to compile.

use std::future::Future;
use std::path::{Path, PathBuf};
use std::sync::Arc;

use agent_shield_core::{
    dispatch_stage_verdict, dispatch_tool_verdict, AgentResolver, ClassifierCaller,
    DelegateDispatcher, Extractor, GuardrailsRuntime, GuardrailsSession, LlmCaller,
    ObservabilityProvider, OnBlockPolicy, RequestContext, RuntimeBuilder,
    ShieldMode as CoreShieldMode, ToolStage,
};
use serde_json::Value;

use crate::capabilities::CapabilityReport;
use crate::errors::ShieldError;
use crate::facade::GuardedTurn;

// ── Modes ────────────────────────────────────────────────────────────

/// Enforcement mode for a [`Shield`].
///
/// This is a local re-declaration of [`agent_shield_core::ShieldMode`]
/// kept for API back-compat with the original Rust SDK shape (the SDK
/// shipped this enum before the core counterpart existed). The two
/// variants map 1:1; conversions are zero-cost.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum ShieldMode {
    /// Block at any stage that denies. This is the spec-default.
    #[default]
    Enforce,
    /// Shadow mode: every stage still runs, but blocks are logged and
    /// the host flow proceeds. Useful for staged rollouts.
    Monitor,
}

impl From<ShieldMode> for CoreShieldMode {
    fn from(m: ShieldMode) -> Self {
        match m {
            ShieldMode::Enforce => CoreShieldMode::Enforce,
            ShieldMode::Monitor => CoreShieldMode::Monitor,
        }
    }
}

// ── ToolWrapper ──────────────────────────────────────────────────────

/// Adapter-supplied trait for [`Shield::protect_tools`] (Pattern B).
///
/// Frameworks whose tool runtime does not support inline arg-mutation
/// (e.g. Rig 0.35) implement this trait so callers can wrap each tool
/// upfront and feed the wrapped tools into the framework as the tool
/// catalog. The wrapper is responsible for:
///
/// 1. Deserializing args.
/// 2. Calling Stage 2/3.
/// 3. Executing the inner tool with the (possibly mutated) args.
/// 4. Calling Stage 4.
/// 5. Recording success / failure.
pub trait ToolWrapper {
    /// The framework's native tool type (the user supplies a `Vec` of
    /// these).
    type Tool;
    /// The wrapped tool type returned to the host. Typically the same
    /// as `Self::Tool` so the wrapper drops in transparently.
    type Wrapped;

    /// Wrap a single tool against the supplied runtime.
    fn wrap(runtime: Arc<GuardrailsRuntime>, tool: Self::Tool) -> Self::Wrapped;
}

// ── Shield ───────────────────────────────────────────────────────────

/// The canonical Shield handle.
///
/// Cloning is cheap — both the runtime and the default session are
/// `Arc`-shared.
#[derive(Clone)]
pub struct Shield {
    runtime: Arc<GuardrailsRuntime>,
    session: Arc<GuardrailsSession>,
    mode: ShieldMode,
    on_block: OnBlockPolicy,
    capability: CapabilityReport,
}

impl std::fmt::Debug for Shield {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("Shield")
            .field("framework", &self.capability.framework)
            .field("mode", &self.mode)
            .field("on_block", &self.on_block)
            .finish()
    }
}

impl Shield {
    /// Start building a Shield from a single YAML config file. YAML
    /// parse errors surface at [`ShieldBuilder::build`] time.
    pub fn from_yaml(path: impl AsRef<Path>) -> ShieldBuilder {
        ShieldBuilder {
            source: BuildSource::SingleYaml(path.as_ref().to_path_buf()),
            ..ShieldBuilder::empty()
        }
    }

    /// Start building from a chain of YAML files (additive merge per
    /// `extends:` semantics).
    pub fn from_yaml_chain<P: AsRef<Path>>(paths: &[P]) -> ShieldBuilder {
        ShieldBuilder {
            source: BuildSource::YamlChain(
                paths.iter().map(|p| p.as_ref().to_path_buf()).collect(),
            ),
            ..ShieldBuilder::empty()
        }
    }

    /// Start building from an already-constructed
    /// `Arc<GuardrailsRuntime>`. Used by hosts that drive
    /// [`RuntimeBuilder`] directly. Resolver / observability hooks must
    /// be wired on the supplied runtime; the builder will reject any
    /// further hook registrations at `build()`.
    pub fn from_runtime(runtime: Arc<GuardrailsRuntime>) -> ShieldBuilder {
        ShieldBuilder {
            source: BuildSource::Prebuilt(runtime),
            ..ShieldBuilder::empty()
        }
    }

    /// Borrow the default session attached to this Shield. For
    /// multi-conversation hosts, prefer [`Shield::with_session`] to
    /// fork a Shield bound to a per-conversation session.
    pub fn session(&self) -> Arc<GuardrailsSession> {
        self.session.clone()
    }

    /// Borrow the underlying runtime for advanced wiring (e.g. spawning
    /// extra sessions).
    pub fn runtime(&self) -> Arc<GuardrailsRuntime> {
        self.runtime.clone()
    }

    /// Capability profile for this Shield (defaults to the framework-
    /// agnostic `core` profile when no adapter extension installs one).
    pub fn capabilities(&self) -> &CapabilityReport {
        &self.capability
    }

    /// Current enforcement mode.
    pub fn mode(&self) -> ShieldMode {
        self.mode
    }

    /// Current on-block policy.
    pub fn on_block_policy(&self) -> OnBlockPolicy {
        self.on_block
    }

    /// Fork a new Shield bound to a different session (e.g.
    /// per-conversation). Cheap: clones `Arc`s only.
    pub fn with_session(&self, session: Arc<GuardrailsSession>) -> Shield {
        Shield {
            runtime: self.runtime.clone(),
            session,
            mode: self.mode,
            on_block: self.on_block,
            capability: self.capability.clone(),
        }
    }

    /// Spawn a fresh per-conversation session.
    pub fn new_session(&self, ctx: RequestContext) -> GuardrailsSession {
        self.runtime.new_session(ctx)
    }

    /// Convenience: fork a new Shield bound to a brand-new
    /// session created with [`RequestContext::default`]. The original
    /// Shield (and its session) is unchanged. Equivalent to
    /// `self.with_session(Arc::new(self.new_session(RequestContext::default())))`.
    ///
    /// Use this when a host wants a clean per-conversation Shield
    /// without having to thread a `RequestContext` through the call
    /// site. For multi-tenant hosts that need a populated context,
    /// prefer the explicit `Shield::with_session` + `Shield::new_session(ctx)`
    /// pair.
    pub fn with_fresh_session(&self) -> Shield {
        let session = Arc::new(self.runtime.new_session(RequestContext::default()));
        self.with_session(session)
    }

    /// Convenience: open a session, call `begin_turn`, run Stage 1,
    /// and return a [`GuardedTurn`] handle.
    #[allow(clippy::result_large_err)]
    pub fn start_turn(
        &self,
        ctx: RequestContext,
        user_input: &str,
    ) -> Result<GuardedTurn, agent_shield_core::StageVerdict> {
        let session = self.runtime.new_session(ctx);
        if let Err(e) = session.begin_turn() {
            log::warn!(target: "agent_shield::shield", "begin_turn failed: {e:?}");
        }
        let verdict = session.validate_input(user_input);
        if !verdict.allowed {
            if let Err(e) = session.end_turn() {
                log::warn!(target: "agent_shield::shield", "end_turn failed: {e:?}");
            }
            return Err(verdict);
        }
        Ok(GuardedTurn::new(session, user_input.to_string()))
    }

    // ── Turn-lifecycle bracket ─────────────────────────────────────

    /// Pre-flight Stage 1 check. Returns `Ok(None)` when the input is
    /// allowed, or `Ok(Some(block_message))` when Stage 1 denies.
    /// Useful for "is this user input safe to even start processing?"
    /// guards at API entry points before any expensive agent work.
    ///
    /// Mirrors the Python / Node `before_invoke()` ergonomic helper.
    /// The block / proceed decision is delegated to
    /// [`agent_shield_core::dispatch_stage_verdict`] so the message
    /// format is byte-equivalent across SDKs.
    pub async fn before_invoke(&self, input: &str) -> Result<Option<String>, ShieldError> {
        if let Err(e) = self.session.begin_turn() {
            if self.mode == ShieldMode::Enforce {
                return Err(ShieldError::Runtime(Box::new(e)));
            }
            log::warn!(target: "agent_shield::shield", "begin_turn failed in monitor mode: {e:?}");
        }
        let verdict = self.session.validate_input(input);
        let dispatch = dispatch_stage_verdict(&verdict, self.on_block, self.mode.into());
        if let Err(e) = self.session.end_turn() {
            log::warn!(target: "agent_shield::shield", "end_turn failed: {e:?}");
        }
        if dispatch.override_to_proceed {
            return Ok(None);
        }
        match dispatch.action {
            agent_shield_core::DispatchAction::ReturnBlocked { message } => Ok(Some(message)),
            agent_shield_core::DispatchAction::Raise { .. } => Err(ShieldError::blocked(verdict)),
            agent_shield_core::DispatchAction::ReturnVerdict
            | agent_shield_core::DispatchAction::InvokeCustom { .. } => {
                Ok(Some(agent_shield_core::format_block_message(&verdict)))
            }
            _ => Ok(None),
        }
    }

    /// Bracket `begin_turn` / `end_turn` around a host-supplied async
    /// closure. The closure can drive Stage 1/5 against
    /// [`Shield::session`] (or against any other session of the host's
    /// choosing) — `run` itself is stage-agnostic.
    ///
    /// In [`ShieldMode::Monitor`] mode, runtime errors from
    /// `begin_turn` / `end_turn` are logged and ignored; the host
    /// flow always proceeds.
    pub async fn run<F, Fut, R>(&self, execute: F) -> Result<R, ShieldError>
    where
        F: FnOnce() -> Fut,
        Fut: Future<Output = R>,
    {
        if let Err(e) = self.session.begin_turn() {
            if self.mode == ShieldMode::Enforce {
                return Err(ShieldError::Runtime(Box::new(e)));
            }
            log::warn!(target: "agent_shield::shield", "begin_turn failed in monitor mode: {e:?}");
        }
        let result = execute().await;
        if let Err(e) = self.session.end_turn() {
            log::warn!(target: "agent_shield::shield", "end_turn failed: {e:?}");
        }
        Ok(result)
    }

    /// Stage-1-and-5 helper: run `validate_input` against `input`,
    /// invoke the host callback with the (possibly transformed) input,
    /// then run `validate_output` against the response. Brackets the
    /// turn lifecycle.
    ///
    /// The block / proceed / proceed-with-mutation decision is
    /// delegated to [`agent_shield_core::dispatch_stage_verdict`] so
    /// the orchestrator behaviour is byte-equivalent to the Python /
    /// Node /.NET SDKs.
    ///
    /// Returns `Ok(response)` on success or `Err(ShieldError::Blocked)`
    /// in [`ShieldMode::Enforce`] when any stage denies.
    pub async fn guarded_run<F, Fut>(&self, input: &str, execute: F) -> Result<String, ShieldError>
    where
        F: FnOnce(String) -> Fut,
        Fut: Future<Output = Result<String, ShieldError>>,
    {
        if let Err(e) = self.session.begin_turn() {
            log::warn!(target: "agent_shield::shield", "begin_turn failed: {e:?}");
        }

        let stage1 = self.session.validate_input(input);
        let stage1_dispatch = dispatch_stage_verdict(&stage1, self.on_block, self.mode.into());
        if matches!(
            stage1_dispatch.action,
            agent_shield_core::DispatchAction::ReturnBlocked { .. }
                | agent_shield_core::DispatchAction::Raise { .. }
                | agent_shield_core::DispatchAction::ReturnVerdict
                | agent_shield_core::DispatchAction::InvokeCustom { .. }
        ) && !stage1_dispatch.override_to_proceed
        {
            if let Err(e) = self.session.end_turn() {
                log::warn!(target: "agent_shield::shield", "end_turn failed: {e:?}");
            }
            return Err(ShieldError::blocked(stage1));
        }

        let validated_input = match &stage1_dispatch.action {
            agent_shield_core::DispatchAction::ProceedWithMutation { value } => value.clone(),
            _ => input.to_string(),
        };
        let exec_result = execute(validated_input).await;
        let mut response = match exec_result {
            Ok(s) => s,
            Err(e) => {
                if let Err(end_err) = self.session.end_turn() {
                    log::warn!(target: "agent_shield::shield", "end_turn failed: {end_err:?}");
                }
                return Err(e);
            }
        };

        let stage5 = self.session.validate_output(&mut response);
        let stage5_dispatch = dispatch_stage_verdict(&stage5, self.on_block, self.mode.into());
        if let Err(e) = self.session.end_turn() {
            log::warn!(target: "agent_shield::shield", "end_turn failed: {e:?}");
        }
        if matches!(
            stage5_dispatch.action,
            agent_shield_core::DispatchAction::ReturnBlocked { .. }
                | agent_shield_core::DispatchAction::Raise { .. }
                | agent_shield_core::DispatchAction::ReturnVerdict
                | agent_shield_core::DispatchAction::InvokeCustom { .. }
        ) && !stage5_dispatch.override_to_proceed
        {
            return Err(ShieldError::blocked(stage5));
        }
        Ok(response)
    }

    // ── Tool-call bracket ──────────────────────────────────────────

    /// Bracket Stage 2/3 → execute → Stage 4 around a single tool
    /// call. The closure receives the (possibly Stage-3-mutated)
    /// params and returns the tool result as a JSON value. On
    /// success, `record_tool_success` is emitted; on either tool
    /// failure or a Stage-4 deny, `record_tool_failure` is emitted.
    ///
    /// `tool_call_id` is REQUIRED; the same id is
    /// threaded through Stage 3 and Stage 4 so the post-validation
    /// invocation hashes the SAME canonical invocation Stage 3
    /// admitted. Pass the adapter-supplied id if the host framework
    /// provides one; synthesize a UUIDv4 unique within the turn
    /// otherwise.
    ///
    /// Stage 2/3/4 verdict-handling is delegated to
    /// [`agent_shield_core::dispatch_tool_verdict`]; this method only
    /// owns the async wiring (executing the tool, plumbing the
    /// resource-cycle records).
    ///
    /// In [`ShieldMode::Monitor`] mode, Stage 2/3/4 verdicts are still
    /// computed and logged but never short-circuit the call.
    pub async fn protect_tool<F, Fut>(
        &self,
        name: &str,
        params: &mut Value,
        tool_call_id: &str,
        exec: F,
    ) -> Result<Value, ShieldError>
    where
        F: FnOnce(Value) -> Fut,
        Fut: Future<Output = Result<Value, String>>,
    {
        let (stage23, admission) =
            self.session
                .validate_tool_call(name, params, Some(tool_call_id));
        let stage23_dispatch = dispatch_tool_verdict(
            &stage23,
            name,
            ToolStage::Call,
            self.on_block,
            self.mode.into(),
        );
        if matches!(
            stage23_dispatch.action,
            agent_shield_core::ToolDispatchAction::Blocked { .. }
        ) && !stage23_dispatch.override_to_proceed
        {
            return Err(ShieldError::blocked_tool(stage23, name));
        }

        let res = exec(params.clone()).await;
        let mut value = match res {
            Ok(v) => v,
            Err(e) => {
                if let Some(handle) = admission {
                    self.session.evict_admission(handle);
                }
                if let Err(rec_err) = self.session.record_tool_failure(name, &e) {
                    log::warn!(target: "agent_shield::shield", "record_tool_failure failed: {rec_err:?}");
                }
                return Err(ShieldError::Other(e));
            }
        };

        let Some(handle) = admission else {
            return Ok(value);
        };
        let stage4 = self.session.validate_tool_output(handle, &mut value);
        let stage4_dispatch = dispatch_tool_verdict(
            &stage4,
            name,
            ToolStage::Output,
            self.on_block,
            self.mode.into(),
        );
        if matches!(
            stage4_dispatch.action,
            agent_shield_core::ToolDispatchAction::Blocked { .. }
        ) {
            if stage4_dispatch.record_failure {
                if let Err(e) = self.session.record_tool_failure(name, "post-tool-blocked") {
                    log::warn!(target: "agent_shield::shield", "record_tool_failure failed: {e:?}");
                }
            }
            if !stage4_dispatch.override_to_proceed {
                return Err(ShieldError::blocked_tool(stage4, name));
            }
        } else if stage4_dispatch.record_success {
            if let Err(e) = self.session.record_tool_success(name, &value) {
                log::warn!(target: "agent_shield::shield", "record_tool_success failed: {e:?}");
            }
        }
        Ok(value)
    }

    /// Pattern B bulk wrap: hand each tool to the adapter-provided
    /// [`ToolWrapper`] and return the wrapped vector. Use this when a
    /// framework's runtime cannot reliably mutate args mid-flight
    /// (e.g. Rig 0.35) and the wrap-tools-up-front strategy is the
    /// only path to full Stage-3 coverage.
    pub fn protect_tools<T: ToolWrapper>(&self, tools: Vec<T::Tool>) -> Vec<T::Wrapped> {
        tools
            .into_iter()
            .map(|t| T::wrap(self.runtime.clone(), t))
            .collect()
    }
}

// ── ShieldBuilder ────────────────────────────────────────────────────

enum BuildSource {
    SingleYaml(PathBuf),
    YamlChain(Vec<PathBuf>),
    Prebuilt(Arc<GuardrailsRuntime>),
    Empty,
}

/// Builder for [`Shield`]. Created via [`Shield::from_yaml`] /
/// [`Shield::from_yaml_chain`] / [`Shield::from_runtime`].
pub struct ShieldBuilder {
    source: BuildSource,
    agent_resolver: Option<Arc<dyn AgentResolver>>,
    delegate_dispatcher: Option<Arc<dyn DelegateDispatcher>>,
    llm_caller: Option<Arc<dyn LlmCaller>>,
    classifier_caller: Option<Arc<dyn ClassifierCaller>>,
    human_resolver: Option<Arc<dyn agent_shield_core::resolver_runtime::HumanResolver>>,
    observability: Vec<Arc<dyn ObservabilityProvider>>,
    extractors: Vec<(String, Box<dyn Extractor>)>,
    tool_retry_limit: Option<usize>,
    /// PR6: perf-telemetry gating knob (default Off via `None`).
    perf_telemetry: Option<agent_shield_core::PerfTelemetry>,
    ctx: Option<RequestContext>,
    mode: ShieldMode,
    on_block: OnBlockPolicy,
    capability: Option<CapabilityReport>,
}

impl ShieldBuilder {
    fn empty() -> Self {
        Self {
            source: BuildSource::Empty,
            agent_resolver: None,
            delegate_dispatcher: None,
            llm_caller: None,
            classifier_caller: None,
            human_resolver: None,
            observability: Vec::new(),
            extractors: Vec::new(),
            tool_retry_limit: None,
            perf_telemetry: None,
            ctx: None,
            mode: ShieldMode::Enforce,
            on_block: OnBlockPolicy::ReturnBlocked,
            capability: None,
        }
    }

    // ── LLM / classifier ──────────────────────────────────────────

    /// Register an LLM caller. When unset, the core
    /// falls back to [`agent_shield_core::FailClosedLlmCaller`] so any
    /// `evaluate_when[].llm` entry blocks closed.
    pub fn with_llm(mut self, caller: impl LlmCaller + 'static) -> Self {
        self.llm_caller = Some(Arc::new(caller));
        self
    }

    /// Register a classifier caller.
    pub fn with_classifier(mut self, caller: impl ClassifierCaller + 'static) -> Self {
        self.classifier_caller = Some(Arc::new(caller));
        self
    }

    // ── Resolvers / dispatcher ────────────────────────────────────

    /// Register the agent-resolver hook.
    pub fn with_agent_resolver(mut self, resolver: impl AgentResolver + 'static) -> Self {
        self.agent_resolver = Some(Arc::new(resolver));
        self
    }

    /// Register a custom delegate dispatcher. When
    /// not registered, the core's `DefaultDelegateDispatcher` is used.
    pub fn with_delegate_dispatcher(
        mut self,
        dispatcher: impl DelegateDispatcher + 'static,
    ) -> Self {
        self.delegate_dispatcher = Some(Arc::new(dispatcher));
        self
    }

    /// Register the active `kind: human` resolver for this runtime.
    /// YAML no longer selects a handler by name; last call wins.
    pub fn with_human_resolver(
        mut self,
        handler: impl agent_shield_core::resolver_runtime::HumanResolver + 'static,
    ) -> Self {
        self.human_resolver = Some(Arc::new(handler));
        self
    }

    /// Pre-built variant of [`Self::with_human_resolver`] for hosts
    /// that need to share the same handler instance across multiple
    /// shields.
    pub fn with_human_resolver_arc(
        mut self,
        handler: Arc<dyn agent_shield_core::resolver_runtime::HumanResolver>,
    ) -> Self {
        self.human_resolver = Some(handler);
        self
    }

    // ── Extractor / observability / knobs ─────────────────────────

    /// Register a populator extractor ('s `extractor:` field).
    /// `extractor` returns `None` to signal "skip this populator".
    pub fn with_extractor<F>(mut self, name: &str, extractor: F) -> Self
    where
        F: Fn(&Value) -> Option<Value> + Send + Sync + 'static,
    {
        struct ClosureExtractor<F>(F);
        impl<F> Extractor for ClosureExtractor<F>
        where
            F: Fn(&Value) -> Option<Value> + Send + Sync + 'static,
        {
            fn extract(&self, raw: &Value) -> Option<Value> {
                (self.0)(raw)
            }
        }
        self.extractors
            .push((name.to_string(), Box::new(ClosureExtractor(extractor))));
        self
    }

    /// Register an observability provider. Multiple providers
    /// fan out — each call adds one.
    pub fn with_observability(mut self, provider: impl ObservabilityProvider + 'static) -> Self {
        self.observability.push(Arc::new(provider));
        self
    }

    /// Override the per-(turn, variable, tool) retry limit.
    pub fn with_tool_retry_limit(mut self, n: usize) -> Self {
        self.tool_retry_limit = Some(n);
        self
    }

    /// Opt into the v8 perf-logging instrumentation (PR5/PR6). The
    /// default is [`agent_shield_core::PerfTelemetry::Off`] — zero
    /// perf events emit. Pick [`agent_shield_core::PerfTelemetry::External`]
    /// for LLM + classifier cost signals only, or
    /// [`agent_shield_core::PerfTelemetry::Full`] for the complete
    /// stage / policy / detection / LLM / classifier event stream.
    /// See [`agent_shield_core::perf_telemetry`] for the gating table.
    pub fn with_perf_telemetry(mut self, mode: agent_shield_core::PerfTelemetry) -> Self {
        self.perf_telemetry = Some(mode);
        self
    }

    /// Set the [`RequestContext`] used when the Shield builds its
    /// default session. Defaults to [`RequestContext::default()`].
    pub fn with_request_context(mut self, ctx: RequestContext) -> Self {
        self.ctx = Some(ctx);
        self
    }

    /// Set the enforcement [`ShieldMode`].
    pub fn with_mode(mut self, mode: ShieldMode) -> Self {
        self.mode = mode;
        self
    }

    /// Set the on-block dispatch policy.
    pub fn with_on_block(mut self, policy: OnBlockPolicy) -> Self {
        self.on_block = policy;
        self
    }

    /// Override the capability report. Adapter `Shield<Framework>Ext`
    /// traits call this internally; hosts rarely need to call it
    /// directly.
    pub fn with_capability(mut self, report: CapabilityReport) -> Self {
        self.capability = Some(report);
        self
    }

    /// Build the Shield. All failures (YAML parse, runtime build,
    /// auto-wiring, mis-configured `from_runtime` hook chains) surface
    /// as [`ShieldError::AutoWire`] / [`ShieldError::Config`] /
    /// [`ShieldError::Runtime`].
    pub fn build(mut self) -> Result<Shield, ShieldError> {
        let source = std::mem::replace(&mut self.source, BuildSource::Empty);
        let runtime = match source {
            BuildSource::SingleYaml(path) => {
                let b = RuntimeBuilder::from_yaml(&path)
                    .map_err(|e| ShieldError::AutoWire(format!("yaml load failed: {e:?}")))?;
                apply_hooks(b, &mut self)
                    .build()
                    .map_err(|e| ShieldError::AutoWire(format!("build failed: {e:?}")))?
            }
            BuildSource::YamlChain(paths) => {
                let b = RuntimeBuilder::from_yaml_chain(&paths)
                    .map_err(|e| ShieldError::AutoWire(format!("chain load failed: {e:?}")))?;
                apply_hooks(b, &mut self)
                    .build()
                    .map_err(|e| ShieldError::AutoWire(format!("build failed: {e:?}")))?
            }
            BuildSource::Prebuilt(rt) => {
                if has_any_hook(&self) {
                    return Err(ShieldError::AutoWire(
                        "Shield::from_runtime accepts an already-built runtime — \
                         resolver / observability / extractor hooks must be wired \
                         on the RuntimeBuilder before calling from_runtime"
                            .into(),
                    ));
                }
                rt
            }
            BuildSource::Empty => {
                return Err(ShieldError::AutoWire(
                    "ShieldBuilder.build() can only be called once \
                     (builder already consumed). Call Shield::from_yaml(...) / \
                     Shield::from_yaml_chain(...) / Shield::from_runtime(...) again \
                     to create a new builder."
                        .into(),
                ));
            }
        };

        let ctx = self.ctx.unwrap_or_default();
        let session = Arc::new(runtime.new_session(ctx));
        let capability = self
            .capability
            .unwrap_or_else(|| CapabilityReport::new("core"));

        Ok(Shield {
            runtime,
            session,
            mode: self.mode,
            on_block: self.on_block,
            capability,
        })
    }
}

fn has_any_hook(b: &ShieldBuilder) -> bool {
    b.agent_resolver.is_some()
        || b.delegate_dispatcher.is_some()
        || b.llm_caller.is_some()
        || b.classifier_caller.is_some()
        || b.human_resolver.is_some()
        || !b.observability.is_empty()
        || !b.extractors.is_empty()
        || b.tool_retry_limit.is_some()
        || b.perf_telemetry.is_some()
}

fn apply_hooks(mut builder: RuntimeBuilder, b: &mut ShieldBuilder) -> RuntimeBuilder {
    if let Some(ar) = &b.agent_resolver {
        builder = builder.register_agent_resolver(ar.clone());
    }
    if let Some(dd) = &b.delegate_dispatcher {
        builder = builder.register_delegate_dispatcher(dd.clone());
    }
    if let Some(lc) = &b.llm_caller {
        builder = builder.register_llm_caller(lc.clone());
    }
    if let Some(cc) = &b.classifier_caller {
        builder = builder.register_classifier_caller(cc.clone());
    }
    if let Some(handler) = &b.human_resolver {
        builder = builder.register_human_resolver(handler.clone());
    }
    for p in &b.observability {
        builder = builder.register_provider(p.clone());
    }
    if let Some(n) = b.tool_retry_limit {
        builder = builder.tool_retry_limit(n);
    }
    if let Some(mode) = b.perf_telemetry {
        builder = builder.with_perf_telemetry(mode);
    }
    // Extractors are not cloneable (`Box<dyn Extractor>`); drain them.
    for (name, ext) in std::mem::take(&mut b.extractors) {
        builder = builder.register_extractor(&name, ext);
    }
    builder
}
