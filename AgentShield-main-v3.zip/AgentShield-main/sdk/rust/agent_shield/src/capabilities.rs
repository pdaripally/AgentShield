//! Adapter capability reports.
//!
//! Mirrors the wire schema at
//! `spec/schemas/wire/capability_report.schema.json`. Every framework
//! adapter exposes a `pub const CAPABILITY_REPORT: CapabilityReport`
//! declaring its honest per-stage coverage. Hosts surface this as
//! `shield.capabilities()` so callers can audit what an adapter
//! actually protects without reading the source.

use serde::{Deserialize, Serialize};

/// Per-stage coverage level. Values match the wire schema verbatim.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "snake_case")]
pub enum CoverageLevel {
    /// The adapter fully implements this stage end-to-end.
    Full,
    /// The adapter implements this stage with caveats (see `notes`).
    Partial,
    /// The adapter does not cover this stage. Hosts that need the
    /// stage must wire it themselves.
    #[default]
    Unsupported,
}

impl CoverageLevel {
    /// Canonical wire-shape string.
    pub fn as_wire_str(&self) -> &'static str {
        match self {
            Self::Full => "full",
            Self::Partial => "partial",
            Self::Unsupported => "unsupported",
        }
    }
}

/// Per-stage protection profile exposed by every framework adapter.
///
/// Field ordering and snake_case serialization match
/// `spec/schemas/wire/capability_report.schema.json`.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct CapabilityReport {
    /// Adapter identifier (e.g. `langchain`, `openai`, `anthropic`,
    /// `rig`).
    pub framework: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub input_validation: Option<CoverageLevel>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub state_validation: Option<CoverageLevel>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub tool_authorization: Option<CoverageLevel>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub tool_execution_validation: Option<CoverageLevel>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub tool_output_validation: Option<CoverageLevel>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub output_validation: Option<CoverageLevel>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub streaming_output: Option<CoverageLevel>,
    /// Free-form caveats explaining `partial` / `unsupported` coverage.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub notes: Vec<String>,
}

impl CapabilityReport {
    /// Build a report with every stage marked `Full`.
    pub fn full(framework: impl Into<String>) -> Self {
        Self {
            framework: framework.into(),
            input_validation: Some(CoverageLevel::Full),
            state_validation: Some(CoverageLevel::Full),
            tool_authorization: Some(CoverageLevel::Full),
            tool_execution_validation: Some(CoverageLevel::Full),
            tool_output_validation: Some(CoverageLevel::Full),
            output_validation: Some(CoverageLevel::Full),
            streaming_output: Some(CoverageLevel::Full),
            notes: Vec::new(),
        }
    }

    /// Build an empty report (every stage `None`) carrying just a name.
    pub fn new(framework: impl Into<String>) -> Self {
        Self {
            framework: framework.into(),
            input_validation: None,
            state_validation: None,
            tool_authorization: None,
            tool_execution_validation: None,
            tool_output_validation: None,
            output_validation: None,
            streaming_output: None,
            notes: Vec::new(),
        }
    }

    /// True iff every populated stage is `Full`. Stages left as `None`
    /// are treated as not-applicable for this adapter and do not
    /// downgrade the verdict.
    pub fn is_full_coverage(&self) -> bool {
        let stages = [
            self.input_validation,
            self.state_validation,
            self.tool_authorization,
            self.tool_execution_validation,
            self.tool_output_validation,
            self.output_validation,
            self.streaming_output,
        ];
        stages
            .iter()
            .filter_map(|s| *s)
            .all(|c| c == CoverageLevel::Full)
    }

    /// Append a note explaining a `partial` / `unsupported` stage.
    pub fn with_note(mut self, note: impl Into<String>) -> Self {
        self.notes.push(note.into());
        self
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn full_marks_every_stage_full() {
        let r = CapabilityReport::full("test");
        assert!(r.is_full_coverage());
        assert_eq!(r.framework, "test");
        assert_eq!(r.input_validation, Some(CoverageLevel::Full));
        assert_eq!(r.streaming_output, Some(CoverageLevel::Full));
    }

    #[test]
    fn partial_stage_downgrades_full_coverage() {
        let mut r = CapabilityReport::full("rig");
        r.tool_execution_validation = Some(CoverageLevel::Partial);
        assert!(!r.is_full_coverage());
    }

    #[test]
    fn none_stages_do_not_downgrade() {
        let mut r = CapabilityReport::full("partial");
        r.streaming_output = None;
        assert!(r.is_full_coverage());
    }

    #[test]
    fn coverage_level_wire_strings() {
        assert_eq!(CoverageLevel::Full.as_wire_str(), "full");
        assert_eq!(CoverageLevel::Partial.as_wire_str(), "partial");
        assert_eq!(CoverageLevel::Unsupported.as_wire_str(), "unsupported");
    }

    #[test]
    fn serializes_snake_case() {
        let r = CapabilityReport {
            framework: "langchain".into(),
            input_validation: Some(CoverageLevel::Full),
            state_validation: None,
            tool_authorization: Some(CoverageLevel::Full),
            tool_execution_validation: Some(CoverageLevel::Full),
            tool_output_validation: Some(CoverageLevel::Full),
            output_validation: Some(CoverageLevel::Full),
            streaming_output: Some(CoverageLevel::Partial),
            notes: vec!["streaming chunks not redacted".into()],
        };
        let json = serde_json::to_value(&r).unwrap();
        assert_eq!(json["framework"], "langchain");
        assert_eq!(json["streaming_output"], "partial");
        assert_eq!(json["notes"][0], "streaming chunks not redacted");
        assert!(json.get("state_validation").is_none());
    }
}
