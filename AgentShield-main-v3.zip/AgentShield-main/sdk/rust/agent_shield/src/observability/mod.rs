//! Built-in observability providers.
//!
//! [`ConsoleObservabilityProvider`] is always available; the three
//! cloud-vendor backends ([`AzureMonitorProvider`],
//! [`CloudWatchProvider`], [`OTelProvider`]) are gated behind their
//! own Cargo features so the default facade build stays lean.
//!
//! The buffered cloud backends synthesise metric-shaped JSON entries
//! directly from each emitted [`ShieldLogEvent`] so a single `emit()`
//! call on the trait delivers both the log line and any associated
//! metrics to the downstream pipeline.

mod console;

#[cfg(feature = "azure-monitor")]
mod azure_monitor;
#[cfg(feature = "cloudwatch")]
mod cloudwatch;
#[cfg(feature = "otel")]
mod otel;

pub use console::ConsoleObservabilityProvider;

#[cfg(feature = "azure-monitor")]
pub use azure_monitor::{AzureMonitorConfig, AzureMonitorProvider};
#[cfg(feature = "cloudwatch")]
pub use cloudwatch::{CloudWatchConfig, CloudWatchProvider};
#[cfg(feature = "otel")]
pub use otel::OTelProvider;

// Re-export the core trait + dispatcher for ergonomics.
pub use agent_shield_core::{ObservabilityDispatcher, ObservabilityProvider, ShieldLogEvent};
