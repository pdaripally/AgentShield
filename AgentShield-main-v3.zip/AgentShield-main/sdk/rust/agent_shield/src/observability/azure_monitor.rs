//! Azure Monitor observability backend.
//!
//! Buffers each emitted [`ShieldLogEvent`] as a single JSON entry and
//! additionally synthesises a metric-shaped JSON entry tagged
//! `agent_shield_<event_type>` so downstream pipelines get aggregable
//! counters alongside the log lines.
//!
//! ## Enabling
//!
//! ```toml
//! agent_shield = { version = "0.13", features = ["azure-monitor"] }
//! ```
//!
//! ## Construction
//!
//! Construction MUST happen inside a Tokio runtime — the periodic
//! flush task is spawned on the current runtime. The provider drains
//! its buffer on [`ObservabilityProvider::shutdown`] / `Drop`.

use std::sync::{Arc, Mutex};
use std::time::Duration;

use agent_shield_core::{ObservabilityProvider, ShieldLogEvent};

use crate::constants::{
    DEFAULT_AZURE_STREAM, DEFAULT_BUFFER_MAX, DEFAULT_FLUSH_INTERVAL_MS, DEFAULT_HTTP_TIMEOUT,
};

/// Configuration for [`AzureMonitorProvider`].
#[derive(Debug, Clone)]
pub struct AzureMonitorConfig {
    /// Data Collection Endpoint (DCE) URL —
    /// `https://<dce>.<region>.ingest.monitor.azure.com`.
    pub endpoint: String,
    /// Data Collection Rule (DCR) immutable id.
    pub rule_id: String,
    /// Stream name on the DCR (typically `Custom-<table>_CL`).
    pub stream_name: String,
    /// Bearer token for Authorization. Hosts using Azure Workload
    /// Identity / managed identity should mint this externally and
    /// rotate it before expiry.
    pub bearer_token: String,
    /// Periodic-flush interval (ms).
    pub flush_interval_ms: u64,
    /// Maximum buffered entries before back-pressure drops the
    /// oldest entry.
    pub max_buffer_size: usize,
}

impl Default for AzureMonitorConfig {
    fn default() -> Self {
        Self {
            endpoint: std::env::var("AZURE_MONITOR_ENDPOINT").unwrap_or_default(),
            rule_id: std::env::var("AZURE_MONITOR_RULE_ID").unwrap_or_default(),
            stream_name: DEFAULT_AZURE_STREAM.to_string(),
            bearer_token: std::env::var("AZURE_MONITOR_TOKEN").unwrap_or_default(),
            flush_interval_ms: DEFAULT_FLUSH_INTERVAL_MS,
            max_buffer_size: DEFAULT_BUFFER_MAX,
        }
    }
}

/// Azure Monitor Log Ingestion API provider — buffers events and
/// flushes them periodically.
pub struct AzureMonitorProvider {
    buffer: Arc<Mutex<Vec<serde_json::Value>>>,
    drop_count: Arc<Mutex<u64>>,
    max_buffer_size: usize,
    cancel: tokio::sync::watch::Sender<bool>,
}

impl AzureMonitorProvider {
    /// Construct a new provider and spawn its flush task. MUST be
    /// called from within a Tokio runtime.
    pub fn new(config: AzureMonitorConfig) -> Self {
        let buffer = Arc::new(Mutex::new(Vec::new()));
        let max_buffer_size = config.max_buffer_size;
        let (cancel_tx, cancel_rx) = tokio::sync::watch::channel(false);

        let provider = Self {
            buffer: buffer.clone(),
            drop_count: Arc::new(Mutex::new(0)),
            max_buffer_size,
            cancel: cancel_tx,
        };

        let endpoint = config.endpoint;
        let rule_id = config.rule_id;
        let stream = config.stream_name;
        let token = config.bearer_token;
        let interval = config.flush_interval_ms;
        let max_size = config.max_buffer_size;
        let mut cancel_rx = cancel_rx;

        tokio::spawn(async move {
            let client = reqwest::Client::new();
            let mut tick = tokio::time::interval(Duration::from_millis(interval));
            loop {
                tokio::select! {
                    _ = tick.tick() => {}
                    _ = cancel_rx.changed() => break,
                }

                let entries: Vec<serde_json::Value> = {
                    let mut buf = buffer.lock().unwrap();
                    if buf.is_empty() {
                        continue;
                    }
                    buf.drain(..).collect()
                };

                if endpoint.is_empty() || rule_id.is_empty() {
                    for entry in &entries {
                        log::info!(target: "agent_shield.azure_monitor", "{}", entry);
                    }
                    continue;
                }

                let url = format!(
                    "{}/dataCollectionRules/{}/streams/{}?api-version=2023-01-01",
                    endpoint, rule_id, stream
                );
                let body = serde_json::to_string(&entries).unwrap_or_default();

                let result = client
                    .post(&url)
                    .header("Content-Type", "application/json")
                    .header("Authorization", format!("Bearer {}", token))
                    .body(body)
                    .timeout(DEFAULT_HTTP_TIMEOUT)
                    .send()
                    .await;

                match result {
                    Ok(resp) if resp.status().is_success() => {}
                    Ok(resp) => {
                        log::error!(
                            "[agent-shield] Azure Monitor flush failed: HTTP {}",
                            resp.status()
                        );
                        Self::requeue(&buffer, entries, max_size);
                    }
                    Err(e) => {
                        log::error!("[agent-shield] Azure Monitor flush error: {e}");
                        Self::requeue(&buffer, entries, max_size);
                    }
                }
            }
        });

        provider
    }

    /// Construct from `AzureMonitorConfig::default()` (env-var based).
    pub fn with_defaults() -> Self {
        Self::new(AzureMonitorConfig::default())
    }

    fn requeue(
        buffer: &Arc<Mutex<Vec<serde_json::Value>>>,
        failed: Vec<serde_json::Value>,
        max_size: usize,
    ) {
        let mut buf = buffer.lock().unwrap();
        let mut restored = failed;
        restored.extend(buf.drain(..));
        if restored.len() > max_size {
            restored.drain(..restored.len() - max_size);
        }
        *buf = restored;
    }

    fn push_bounded(&self, entry: serde_json::Value) {
        let mut buf = self.buffer.lock().unwrap();
        if buf.len() >= self.max_buffer_size {
            buf.remove(0);
            let mut drops = self.drop_count.lock().unwrap();
            *drops += 1;
            if *drops == 1 || drops.is_multiple_of(1000) {
                log::warn!(
                    "[agent-shield] Azure Monitor buffer full ({}); dropped {} entries",
                    self.max_buffer_size,
                    *drops
                );
            }
        }
        buf.push(entry);
    }

    /// Test-only accessor that snapshots the current buffer without
    /// draining it. Used by the unit tests in this module.
    #[cfg(test)]
    pub(crate) fn buffer_snapshot(&self) -> Vec<serde_json::Value> {
        self.buffer.lock().unwrap().clone()
    }
}

impl ObservabilityProvider for AzureMonitorProvider {
    fn emit(&self, event: ShieldLogEvent) {
        // Buffer the event verbatim …
        self.push_bounded(
            serde_json::to_value(&event)
                .unwrap_or_else(|_| serde_json::json!({"raw": "parse error"})),
        );
        // … plus a metric-shaped sibling entry so downstream pipelines
        // can aggregate per-event-type counters without parsing the
        // log payload.
        let metric_name = format!("agent_shield_{}", event.event_type.as_str());
        self.push_bounded(serde_json::json!({
            "type": "metric",
            "name": metric_name,
            "value": 1.0_f64,
            "attributes": {
                "severity": event.severity.as_str(),
                "category": event.category,
                "session_id": event.session_id,
                "stage": event.stage.map(|s| s.as_str()).unwrap_or(""),
            },
        }));
    }

    fn shutdown(&self) {
        let _ = self.cancel.send(true);
        let entries: Vec<serde_json::Value> = {
            let mut buf = self.buffer.lock().unwrap();
            buf.drain(..).collect()
        };
        for entry in &entries {
            log::info!(target: "agent_shield.azure_monitor.shutdown", "{}", entry);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use agent_shield_core::observability::event::{EventType, Severity};

    fn ev() -> ShieldLogEvent {
        ShieldLogEvent::new(EventType::Info, Severity::Info, "test")
    }

    #[tokio::test]
    async fn emit_buffers_log_and_metric() {
        // No endpoint set → flush task falls back to log macros, but
        // buffer still records both entries.
        let cfg = AzureMonitorConfig {
            endpoint: "".into(),
            rule_id: "".into(),
            stream_name: "stream".into(),
            bearer_token: "".into(),
            flush_interval_ms: 60_000,
            max_buffer_size: 16,
        };
        let p = AzureMonitorProvider::new(cfg);
        p.emit(ev());
        let buf = p.buffer_snapshot();
        assert_eq!(buf.len(), 2);
        // First entry is the serialized event, second is the metric.
        assert_eq!(buf[1].get("type").and_then(|v| v.as_str()), Some("metric"));
        assert!(buf[1]
            .get("name")
            .and_then(|v| v.as_str())
            .unwrap()
            .starts_with("agent_shield_"));
    }

    #[tokio::test]
    async fn buffer_back_pressure_drops_oldest() {
        let cfg = AzureMonitorConfig {
            endpoint: "".into(),
            rule_id: "".into(),
            stream_name: "stream".into(),
            bearer_token: "".into(),
            flush_interval_ms: 60_000,
            max_buffer_size: 4, // tiny
        };
        let p = AzureMonitorProvider::new(cfg);
        // 6 emits ⇒ 12 entries pushed; bounded to 4.
        for _ in 0..6 {
            p.emit(ev());
        }
        let buf = p.buffer_snapshot();
        assert!(buf.len() <= 4);
    }
}
