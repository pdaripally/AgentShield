//! OpenTelemetry observability backend.
//!
//! Emits each event through `log` for OTel bridges and updates cached
//! per-event counters plus the `agent_shield_duration_ms` histogram. All OTel
//! instruments are built once in [`OTelProvider::new`]; hot-path emit performs
//! only map lookup + instrument update, and unknown event types do not allocate
//! lazy counters.

use std::collections::HashMap;

use agent_shield_core::observability::attributes::KEY_DURATION_MS;
use agent_shield_core::{ObservabilityProvider, ShieldLogEvent};

use opentelemetry::global;
use opentelemetry::metrics::{Counter, Histogram};
use opentelemetry::{InstrumentationScope, KeyValue};

use crate::constants::DEFAULT_OTEL_METER_NAME;

/// All known `EventType` wire strings. Used by [`OTelProvider::new`]
/// to pre-populate the per-event-type counter cache so emit is
/// lookup-only.
///
/// MUST stay in sync with `EventType::as_str()` in
/// `agent_shield_core::observability::event`. The
/// `all_known_event_types_have_cached_counters` test in this module
/// is the cross-check.
const KNOWN_EVENT_TYPE_WIRE_STRINGS: &[&str] = &[
    "validation_triggered",
    "call_blocked",
    "call_allowed",
    "resolution_invoked",
    "event_emitted",
    "event_cleared",
    "variable_changed",
    "guard_policy_activated",
    "guard_policy_deactivated",
    "guard_policy_passed",
    "guard_policy_failed",
    "approval_allowed",
    "approval_denied",
    "approval_cancelled",
    "incident_emitted",
    "load_error",
    "runtime_error",
    "warning",
    "info",
    // Perf instrumentation (v8 plan Phase 1, PR5 step 4):
    "stage_evaluated",
    "policy_evaluated",
    "llm_called",
    "classifier_called",
];

/// OpenTelemetry-based observability provider.
///
/// Routes Agent Shield events to the OTel logging pipeline (via the
/// `log` crate bridge) and synthesises per-event-type counters +
/// a duration histogram on the OTel metrics pipeline.
///
/// See the module docs for the AC22 / AC9 invariant: all instruments
/// are constructed exactly once at [`Self::new`] time; emit performs
/// no per-call instrument construction.
pub struct OTelProvider {
    /// Meter name used to construct the [`InstrumentationScope`].
    meter_name: String,
    /// Pre-built counter per known `EventType` wire string. The hot
    /// path does a single `HashMap::get` keyed by `event_type.as_str()`.
    counters: HashMap<String, Counter<f64>>,
    /// Pre-built histogram for the `KEY_DURATION_MS` attribute that
    /// PR6 perf events carry.
    duration_histogram: Histogram<f64>,
}

impl OTelProvider {
    /// Create a new OTel provider with the given meter name.
    ///
    /// At construction time:
    ///   - one [`InstrumentationScope`] is built,
    ///   - one [`global::meter_with_scope`] lookup runs,
    ///   - one counter is built per known `EventType` wire string,
    ///   - one histogram is built for `agent_shield_duration_ms`.
    ///
    /// All of these are stored on `self`; emit is hot-path
    /// lookup-only.
    pub fn new(meter_name: &str) -> Self {
        let scope = InstrumentationScope::builder(meter_name.to_string()).build();
        let meter = global::meter_with_scope(scope);

        let mut counters = HashMap::with_capacity(KNOWN_EVENT_TYPE_WIRE_STRINGS.len());
        for wire in KNOWN_EVENT_TYPE_WIRE_STRINGS {
            let name = format!("agent_shield_{wire}");
            let counter = meter.f64_counter(name).build();
            counters.insert((*wire).to_string(), counter);
        }

        let duration_histogram = meter.f64_histogram("agent_shield_duration_ms").build();

        Self {
            meter_name: meter_name.to_string(),
            counters,
            duration_histogram,
        }
    }

    pub fn meter_name(&self) -> &str {
        &self.meter_name
    }
}

impl Default for OTelProvider {
    fn default() -> Self {
        Self::new(DEFAULT_OTEL_METER_NAME)
    }
}

impl ObservabilityProvider for OTelProvider {
    fn emit(&self, event: ShieldLogEvent) {
        // 1. Log bridge — let the OTel SDK pick this up via the
        //    `log` -> OTLP appender that hosts wire externally.
        let event_type = event.event_type.as_str();
        let category = &event.category;
        let session_id = &event.session_id;
        match event.severity.as_str() {
            "critical" | "high" => log::error!(
                target: "agent_shield.otel",
                "{} category={} session_id={}",
                event_type, category, session_id
            ),
            "medium" => log::warn!(
                target: "agent_shield.otel",
                "{} category={} session_id={}",
                event_type, category, session_id
            ),
            _ => log::info!(
                target: "agent_shield.otel",
                "{} category={} session_id={}",
                event_type, category, session_id
            ),
        }

        // 2. Per-event-type counter — single HashMap::get on the hot
        //    path. Unknown wire strings (EventType::Unknown(s)) are
        //    skipped silently per AC22 / module docs.
        if let Some(counter) = self.counters.get(event_type) {
            let mut kvs: Vec<KeyValue> = Vec::with_capacity(4);
            kvs.push(KeyValue::new("severity", event.severity.as_str()));
            kvs.push(KeyValue::new("category", category.clone()));
            kvs.push(KeyValue::new("session_id", session_id.clone()));
            if let Some(stage) = event.stage {
                kvs.push(KeyValue::new("stage", stage.as_str()));
            }
            counter.add(1.0, &kvs);
        }

        // 3. Duration histogram — observes the agent_shield.duration_ms
        //    attribute when PR6 perf events carry it. Numeric values
        //    only; non-number attribute payloads are ignored.
        if let Some(value) = event.attributes.get(KEY_DURATION_MS) {
            if let Some(ms) = value.as_f64() {
                let mut kvs: Vec<KeyValue> = Vec::with_capacity(3);
                kvs.push(KeyValue::new("event_type", event_type.to_string()));
                if let Some(stage) = event.stage {
                    kvs.push(KeyValue::new("stage", stage.as_str()));
                }
                if let Some(p) = event.guard_policy.as_deref() {
                    kvs.push(KeyValue::new("guard_policy", p.to_string()));
                }
                self.duration_histogram.record(ms, &kvs);
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use agent_shield_core::observability::event::{EventType, Severity};

    #[test]
    fn emit_does_not_panic_without_otel_sdk_installed() {
        // Without an OTel pipeline configured, the meter calls are
        // no-ops via the SDK's NoopMeterProvider. Verify emit() is
        // panic-free in that path — the most common test environment.
        let p = OTelProvider::new("agent_shield_test");
        p.emit(ShieldLogEvent::new(
            EventType::Info,
            Severity::Info,
            "smoke",
        ));
        p.emit(ShieldLogEvent::new(
            EventType::GatingVerdict,
            Severity::High,
            "smoke",
        ));
    }

    #[test]
    fn default_uses_canonical_meter_name() {
        let p = OTelProvider::default();
        assert_eq!(p.meter_name(), DEFAULT_OTEL_METER_NAME);
        assert!(
            !p.counters.is_empty(),
            "default constructor must wire counters"
        );
        assert!(
            p.counters.contains_key("validation_triggered"),
            "canonical EventType wire strings (e.g. GuardrailEvaluation) must be cached"
        );
    }

    #[test]
    fn all_known_event_types_have_cached_counters() {
        // Cross-check that the wire-string list this module ships is
        // in sync with EventType::as_str(). If a future variant lands
        // in agent_shield_core without a matching entry here, this
        // test fails — the wire string from that variant would have
        // no cached counter and emit would silently drop the metric.
        let p = OTelProvider::new("agent_shield_test");
        let named = [
            EventType::GuardrailEvaluation,
            EventType::GatingVerdict,
            EventType::GatingAllowed,
            EventType::ResolverInvoked,
            EventType::EventEmitted,
            EventType::EventCleared,
            EventType::VariableChanged,
            EventType::GuardPolicyActivated,
            EventType::GuardPolicyDeactivated,
            EventType::GuardPolicyPassed,
            EventType::GuardPolicyFailed,
            EventType::ApprovalAllowed,
            EventType::ApprovalDenied,
            EventType::ApprovalCancelled,
            EventType::IncidentEmitted,
            EventType::LoadError,
            EventType::RuntimeError,
            EventType::Warning,
            EventType::Info,
            EventType::StageEvaluated,
            EventType::PolicyEvaluated,
            EventType::LlmCalled,
            EventType::ClassifierCalled,
        ];
        for et in &named {
            let wire = et.as_str();
            assert!(
                p.counters.contains_key(wire),
                "no cached counter for known EventType wire `{wire}` — \
                 add it to KNOWN_EVENT_TYPE_WIRE_STRINGS in otel.rs"
            );
        }
    }

    #[test]
    fn counters_cache_size_does_not_grow_during_emit() {
        // AC22 / AC9: instruments are constructed exactly once per
        // OTelProvider, not per emit. Lookup-only emit means the
        // cache size never grows after new() returns.
        let p = OTelProvider::new("agent_shield_test");
        let initial = p.counters.len();
        assert_eq!(initial, KNOWN_EVENT_TYPE_WIRE_STRINGS.len());

        for _ in 0..200 {
            p.emit(ShieldLogEvent::new(
                EventType::Info,
                Severity::Info,
                "smoke",
            ));
            p.emit(ShieldLogEvent::new(
                EventType::GuardPolicyPassed,
                Severity::Info,
                "smoke",
            ));
        }

        assert_eq!(
            p.counters.len(),
            initial,
            "counter cache must not grow during emit — AC22 / AC9 invariant"
        );
    }

    #[test]
    fn unknown_event_type_emit_is_silent_no_op_on_metrics() {
        // EventType::Unknown(s) wire strings have no pre-cached
        // counter. emit() must not panic and must not lazily build a
        // counter (which would re-introduce the per-emit cost AC22
        // deletes).
        let p = OTelProvider::new("agent_shield_test");
        let before = p.counters.len();
        p.emit(ShieldLogEvent::new(
            EventType::Unknown("future_event_v2".to_string()),
            Severity::Info,
            "smoke",
        ));
        assert_eq!(p.counters.len(), before, "Unknown variant must not insert");
    }
}
