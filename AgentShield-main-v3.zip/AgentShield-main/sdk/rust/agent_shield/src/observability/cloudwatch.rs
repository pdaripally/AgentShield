//! AWS CloudWatch Logs observability backend.
//!
//! Buffers each emitted [`ShieldLogEvent`] as a JSON line plus a
//! metric-shaped sibling entry tagged `agent_shield_<event_type>` so
//! downstream pipelines get aggregable counters alongside the log
//! lines.
//!
//! ## Enabling
//!
//! ```toml
//! agent_shield = { version = "0.13", features = ["cloudwatch"] }
//! ```

use std::sync::{Arc, Mutex};
use std::time::Duration;

use agent_shield_core::{ObservabilityProvider, ShieldLogEvent};

use crate::constants::{
    DEFAULT_BUFFER_MAX, DEFAULT_CW_LOG_GROUP, DEFAULT_CW_NAMESPACE, DEFAULT_FLUSH_INTERVAL_MS,
    DEFAULT_HTTP_TIMEOUT,
};

/// Configuration for [`CloudWatchProvider`].
#[derive(Debug, Clone)]
pub struct CloudWatchConfig {
    pub log_group_name: String,
    pub log_stream_name: String,
    pub namespace: String,
    pub endpoint_url: String,
    pub flush_interval_ms: u64,
    pub max_buffer_size: usize,
}

impl Default for CloudWatchConfig {
    fn default() -> Self {
        Self {
            log_group_name: DEFAULT_CW_LOG_GROUP.to_string(),
            log_stream_name: format!("rust-{}", std::process::id()),
            namespace: DEFAULT_CW_NAMESPACE.to_string(),
            endpoint_url: std::env::var("AGENT_SHIELD_CW_ENDPOINT").unwrap_or_default(),
            flush_interval_ms: DEFAULT_FLUSH_INTERVAL_MS,
            max_buffer_size: DEFAULT_BUFFER_MAX,
        }
    }
}

/// AWS CloudWatch Logs provider — buffers events and flushes them
/// periodically via PutLogEvents.
pub struct CloudWatchProvider {
    buffer: Arc<Mutex<Vec<(i64, String)>>>,
    drop_count: Arc<Mutex<u64>>,
    max_buffer_size: usize,
    namespace: String,
    cancel: tokio::sync::watch::Sender<bool>,
}

impl CloudWatchProvider {
    /// Construct and spawn flush task. MUST be called from within a
    /// Tokio runtime.
    pub fn new(config: CloudWatchConfig) -> Self {
        let buffer = Arc::new(Mutex::new(Vec::new()));
        let max_buffer_size = config.max_buffer_size;
        let (cancel_tx, cancel_rx) = tokio::sync::watch::channel(false);

        let provider = Self {
            buffer: buffer.clone(),
            drop_count: Arc::new(Mutex::new(0)),
            max_buffer_size,
            namespace: config.namespace.clone(),
            cancel: cancel_tx,
        };

        let log_group = config.log_group_name;
        let log_stream = config.log_stream_name;
        let endpoint_url = config.endpoint_url;
        let interval = config.flush_interval_ms;
        let max_size = config.max_buffer_size;
        let mut cancel_rx = cancel_rx;

        tokio::spawn(async move {
            let client = reqwest::Client::new();
            let mut tick = tokio::time::interval(Duration::from_millis(interval));
            loop {
                tokio::select! {
                    _ = tick.tick() => {}
                    _ = cancel_rx.changed() => break,
                }

                let entries: Vec<(i64, String)> = {
                    let mut buf = buffer.lock().unwrap();
                    if buf.is_empty() {
                        continue;
                    }
                    buf.drain(..).collect()
                };

                if endpoint_url.is_empty() {
                    for (_, msg) in &entries {
                        log::info!(target: "agent_shield.cloudwatch", "{}", msg);
                    }
                    continue;
                }

                let log_events: Vec<serde_json::Value> = entries
                    .iter()
                    .map(|(ts, msg)| serde_json::json!({"timestamp": ts, "message": msg}))
                    .collect();
                let body = serde_json::json!({
                    "logGroupName": log_group,
                    "logStreamName": log_stream,
                    "logEvents": log_events,
                });

                let result = client
                    .post(&endpoint_url)
                    .header("Content-Type", "application/x-amz-json-1.1")
                    .header("X-Amz-Target", "Logs_20140328.PutLogEvents")
                    .json(&body)
                    .timeout(DEFAULT_HTTP_TIMEOUT)
                    .send()
                    .await;

                match result {
                    Ok(resp) if resp.status().is_success() => {}
                    Ok(resp) => {
                        log::error!(
                            "[agent-shield] CloudWatch flush failed: HTTP {}",
                            resp.status()
                        );
                        Self::requeue(&buffer, entries, max_size);
                    }
                    Err(e) => {
                        log::error!("[agent-shield] CloudWatch flush error: {e}");
                        Self::requeue(&buffer, entries, max_size);
                    }
                }
            }
        });

        provider
    }

    pub fn with_defaults() -> Self {
        Self::new(CloudWatchConfig::default())
    }

    fn requeue(
        buffer: &Arc<Mutex<Vec<(i64, String)>>>,
        failed: Vec<(i64, String)>,
        max_size: usize,
    ) {
        let mut buf = buffer.lock().unwrap();
        let mut restored = failed;
        restored.extend(buf.drain(..));
        if restored.len() > max_size {
            restored.drain(..restored.len() - max_size);
        }
        *buf = restored;
    }

    fn push_bounded(&self, timestamp_ms: i64, entry: String) {
        let mut buf = self.buffer.lock().unwrap();
        if buf.len() >= self.max_buffer_size {
            buf.remove(0);
            let mut drops = self.drop_count.lock().unwrap();
            *drops += 1;
            if *drops == 1 || drops.is_multiple_of(1000) {
                log::warn!(
                    "[agent-shield] CloudWatch buffer full ({}); dropped {} entries",
                    self.max_buffer_size,
                    *drops
                );
            }
        }
        buf.push((timestamp_ms, entry));
    }

    #[cfg(test)]
    pub(crate) fn buffer_snapshot(&self) -> Vec<(i64, String)> {
        self.buffer.lock().unwrap().clone()
    }
}

impl ObservabilityProvider for CloudWatchProvider {
    fn emit(&self, event: ShieldLogEvent) {
        let ts = event.timestamp.timestamp_millis();
        self.push_bounded(ts, serde_json::to_string(&event).unwrap_or_default());
        // Mint a metric-shaped JSON line per emit so downstream
        // CloudWatch dashboards see aggregable counters alongside the
        // raw log lines.
        let metric_ts = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_millis() as i64;
        let metric_name = format!("agent_shield_{}", event.event_type.as_str());
        self.push_bounded(
            metric_ts,
            serde_json::json!({
                "type": "metric",
                "name": metric_name,
                "value": 1.0_f64,
                "namespace": self.namespace,
                "attributes": {
                    "severity": event.severity.as_str(),
                    "category": event.category,
                    "session_id": event.session_id,
                },
            })
            .to_string(),
        );
    }

    fn shutdown(&self) {
        let _ = self.cancel.send(true);
        let entries: Vec<(i64, String)> = {
            let mut buf = self.buffer.lock().unwrap();
            buf.drain(..).collect()
        };
        for (_, entry) in &entries {
            log::info!(target: "agent_shield.cloudwatch.shutdown", "{}", entry);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use agent_shield_core::observability::event::{EventType, Severity};

    fn ev() -> ShieldLogEvent {
        ShieldLogEvent::new(EventType::Info, Severity::Info, "test")
    }

    #[tokio::test]
    async fn emit_buffers_log_and_metric() {
        let cfg = CloudWatchConfig {
            log_group_name: "g".into(),
            log_stream_name: "s".into(),
            namespace: "AgentShield".into(),
            endpoint_url: "".into(),
            flush_interval_ms: 60_000,
            max_buffer_size: 16,
        };
        let p = CloudWatchProvider::new(cfg);
        p.emit(ev());
        let buf = p.buffer_snapshot();
        assert_eq!(buf.len(), 2);
        // The metric entry is the second line; verify by parsing back.
        let metric: serde_json::Value = serde_json::from_str(&buf[1].1).unwrap();
        assert_eq!(metric.get("type").and_then(|v| v.as_str()), Some("metric"));
        assert_eq!(
            metric.get("namespace").and_then(|v| v.as_str()),
            Some("AgentShield")
        );
    }

    #[tokio::test]
    async fn buffer_bounded_back_pressure() {
        let cfg = CloudWatchConfig {
            log_group_name: "g".into(),
            log_stream_name: "s".into(),
            namespace: "AS".into(),
            endpoint_url: "".into(),
            flush_interval_ms: 60_000,
            max_buffer_size: 4,
        };
        let p = CloudWatchProvider::new(cfg);
        for _ in 0..6 {
            p.emit(ev());
        }
        assert!(p.buffer_snapshot().len() <= 4);
    }
}
