//! Built-in observability providers.
//!
//! Hosts that need richer pipelines (Azure Monitor, OpenTelemetry,
//! CloudWatch, etc.) implement [`ObservabilityProvider`] directly — the
//! trait surface is sync, so async backends wrap a Tokio handle
//! internally.

use agent_shield_core::{ObservabilityProvider, ShieldLogEvent};

/// Console observability provider — fans events to the `log` crate.
///
/// Produces a single log line per emitted event with severity-mapped
/// log levels:
///
/// - `Critical` / `High`   → `error!`
/// - `Medium`              → `warn!`
/// - `Low` / `Info`        → `info!`
#[derive(Debug, Clone, Default)]
pub struct ConsoleObservabilityProvider {
    _private: (),
}

impl ConsoleObservabilityProvider {
    /// Create a new console provider.
    pub fn new() -> Self {
        Self { _private: () }
    }
}

impl ObservabilityProvider for ConsoleObservabilityProvider {
    fn emit(&self, event: ShieldLogEvent) {
        use agent_shield_core::ObsSeverity as Severity;

        let stage = event.stage.map(|s| s.as_str()).unwrap_or("");
        let action = event.action.as_ref().map(|a| a.as_str()).unwrap_or("");
        let resource = event
            .resource
            .as_ref()
            .map(|r| format!("{}:{}", r.kind.as_str(), r.name))
            .unwrap_or_default();

        let msg = format!(
            "[agent-shield] {event_type} stage={stage} action={action} resource={resource} \
             policy={policy} message={message}",
            event_type = event.event_type.as_str(),
            policy = event.guard_policy.as_deref().unwrap_or(""),
            message = event.message,
        );

        match event.severity {
            Severity::Critical | Severity::High => log::error!("{msg}"),
            Severity::Medium => log::warn!("{msg}"),
            Severity::Low | Severity::Info => log::info!("{msg}"),
        }
    }
}
