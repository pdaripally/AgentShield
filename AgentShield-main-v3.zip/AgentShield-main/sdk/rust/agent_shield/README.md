# Agent Shield — Rust SDK

Rust SDK for [Agent Shield](https://github.com/microsoft/AgentShield), an open specification and reference implementation for runtime security controls on AI agents. Loads a [`.guardrails.yaml`](../../../spec/SPECIFICATION.md) contract and enforces it across **5 validation stages** (Input → State → Tool execution → Post-tool → Output).

## Crates

| Crate | What it does |
|---|---|
| `agent_shield_core` | Reference engine: parser / evaluator, lifetime tracker, event bus, resolver runtime, guard-policy engine, observability. All other SDKs (Python, Node, .NET) wrap this via FFI. |
| `agent_shield` | Ergonomic Rust facade — `Shield` builder + bundled approval handlers + observability providers + per-stage helpers. |
| `agent_shield_openai` | Adapter for [`async-openai`](https://crates.io/crates/async-openai). |
| `agent_shield_anthropic` | Adapter for [`anthropic-sdk-rust`](https://crates.io/crates/anthropic-sdk). |
| `agent_shield_rig` | Adapter for [`rig-core`](https://crates.io/crates/rig-core) — the only production-viable Rust agent framework as of 2025. |
| `agent_shield_langchain` | Adapter for [`langchain-rust`](https://crates.io/crates/langchain-rust). |
| `agent_shield_mcp` | Adapter for the Model Context Protocol. |

## Install

This repo does not publish to crates.io — consume via git tag (see [`RELEASING.md`](../../../RELEASING.md)):

```toml
[dependencies]
agent_shield = { git = "https://github.com/microsoft/AgentShield", tag = "v<version>" }
# Add adapter crates as needed:
agent_shield_rig = { git = "https://github.com/microsoft/AgentShield", tag = "v<version>" }
```

## Quick start

```rust
use agent_shield::Shield;

#[tokio::main]
async fn main() -> Result<(), agent_shield::ShieldError> {
    let shield = Shield::from_yaml("guardrails.yaml").build()?;

    // Pattern C — Stage 1 + Stage 5 around an opaque agent thunk:
    let answer = shield.guarded_run("hello", |input| async move {
        // `input` is the effective value after Stage 1 mutations.
        // your model call here
        Ok::<_, agent_shield::ShieldError>(format!("you said: {input}"))
    }).await?;

    println!("{answer}");
    Ok(())
}
```

**Before shipping:** read [Post-tool limits and dangerous patterns](../../../docs/POST_TOOL_LIMITS.md) — it covers what AgentShield does and does not guarantee.

## Three integration patterns

The same conceptual model — **Patterns A / B / C** — applies across all four AgentShield SDKs (Python, Node, Rust, .NET); the *implementation shape* matches each ecosystem's idiomatic middleware surface. In Rust, that means:

### Pattern A — Guard the agent loop (full coverage)

For [`rig`](https://crates.io/crates/rig-core)-based agents, AgentShield provides a [`PromptHook`](https://docs.rs/rig-core/latest/rig/agent/trait.PromptHook.html) implementation that gates every model call and tool invocation:

```rust
use agent_shield::Shield;
use agent_shield_rig::ShieldHook;
use rig::{providers::openai, agent::PromptRequest};

let shield = Shield::from_yaml("guardrails.yaml").build()?;
let hook = ShieldHook::new(shield.runtime().clone());

let agent = openai::Client::from_env().agent("gpt-4o-mini").build();
let answer = PromptRequest::new(&agent, "user message")
    .with_hook(hook)
    .send().await?;
```

> **Coverage caveat for `rig`**: rig's `ToolCallHookAction` enum has no `Replace { args }` variant ([upstream issue 1744](https://github.com/0xPlaygrounds/rig/issues/1744)). Stage 3 mutated arguments cannot flow through the hook surface — for full Stage-3 coverage, use Pattern B below (`RigToolWrapper`).

### Pattern B — Protect individual tools

The full-coverage path for `rig` (and any framework whose hook surface lacks arg mutation). Wrap each tool before constructing the agent, then bracket `agent.prompt(...)` with `shield.run_rig(...)` so every wrapped tool shares one session and `per_session` state accumulates.

```rust
use std::sync::Arc;
use agent_shield::Shield;
use agent_shield_rig::{GuardedRigTool, ShieldRigExt, ShieldRigSessionExt};
use rig::tool::ToolDyn;

let shield = Shield::from_yaml("guardrails.yaml")
    .with_rig_full_coverage()   // promotes capability report to Full
    .build()?;

// Wrap each tool. rig 0.35's `AgentBuilder::tools` takes `Vec<Box<dyn ToolDyn>>`.
let guarded_tools: Vec<Box<dyn ToolDyn>> = my_tools
    .into_iter()
    .map(|t: Arc<dyn ToolDyn>| {
        Box::new(GuardedRigTool::new(shield.runtime(), t)) as Box<dyn ToolDyn>
    })
    .collect();

let agent = openai::Client::from_env()
    .agent("gpt-4o-mini")
    .tools(guarded_tools)
    .build();

// IMPORTANT: bracket every `agent.prompt(...)` cycle with
// `shield.run_rig(...)` so all `GuardedRigTool` invocations share one
// session. Without this, each tool call would silently fall back to a
// per-call session and `per_session` policies (rate limits, accumulators)
// would never fire. The default fails closed: an unbracketed
// `GuardedRigTool::call` returns a `ToolError` with a helpful message.
let answer = shield.run_rig(|| async {
    agent.prompt("user message").await
}).await?;
```

This mirrors the Python `shield.guard(agent)` ambient-session pattern and the Node `AsyncLocalStorage`-based equivalent — every SDK threads one session across the tools that run inside one prompt cycle.

### Pattern C — Stage 1 + 5 boundary (opaque loops)

For raw `async-openai` / `anthropic-sdk-rust` HTTP clients (which don't have agent-loop frameworks). Wrap your call site in `Shield::guarded_run` and wrap individual tool calls with `Shield::protect_tool`:

```rust
use agent_shield::Shield;

let shield = Shield::from_yaml("guardrails.yaml").build()?;

let answer = shield.guarded_run("user message", |input| async move {
    // `input` is the effective value after Stage 1 mutations.
    // your model call + custom loop here
    let result = client.chat(...).await?;
    Ok(result)
}).await?;

// And for individual tool calls inside the loop:
// `tool_call_id` is a per-call identifier you must supply — pass
// the tool-call id from your LLM provider's response (e.g.,
// OpenAI's `tool_calls[i].id`, Anthropic's `content[i].id`) or
// synthesize one yourself (e.g., `format!("{}-{}", name, idx)`)
// when the provider doesn't give you one. It scopes Stage-2/3
// admission to Stage-4 post-tool validation for the same call.
let tool_call_id = "send-email-0";
let safe = shield.protect_tool("send_email", &mut params, tool_call_id, |params| async move {
    actually_send(params).await
}).await?;
```

#### Framework result objects

Python (`shield.run`), Node (`shield.run`), and .NET (`Shield.RunAsync`) Pattern C surfaces accept an `extract_text` / `extractText` lens so framework result objects can be Stage-5-validated without unsafe stringification. They raise `AgentShieldUnsupportedOutputType*` unless the customer names the assistant-visible text field.

The Rust facade is type-safe at compile time on this front — `Shield::guarded_run<F, Fut>` is `String`-typed (`Fut: Future<Output = Result<String, ShieldError>>`), so the equivalent class of bug is a compile error rather than a silent runtime bypass. If you wrap a framework call inside `guarded_run`, project the assistant-visible text yourself before returning:

```rust
let answer = shield.guarded_run("user message", |input| async move {
    let result: SomeFrameworkResult = client.generate(input).await?;
    // Project the text field BEFORE handing to AgentShield so Stage 5
    // sees the assistant-visible content. Stash any other fields you
    // need to return via a side-channel or refactor the call site.
    Ok::<_, agent_shield::ShieldError>(result.text)
}).await?;
```

For richer Pattern A coverage with structured tool results, prefer `Pattern B` (`GuardedRigTool`) so each tool result is validated under Stage 4 with its native schema, rather than smuggling structured output through Stage 5.

#### Streaming safety

> **⚠️ DANGER — hand-rolled streaming wrappers around `Shield::guarded_run` / direct `validate_output` loops are unsafe by construction.**
>
> Stage 5 redaction requires the *full output context* to compute redaction spans. **Per-chunk Stage 5 cannot work** — you cannot know whether a substring is sensitive until you have seen enough surrounding text. **Per-stream-finalize Stage 5 emits raw chunks to the client *before* redaction runs** — the leak has already shipped over the wire by the time the final pass returns.
>
> Only an adapter that owns chunk emission (so it can buffer, validate, and *then* emit the safe-to-emit slice) can stream safely.
>
> **Safe options when a streaming adapter does not exist for your framework:**
>
> 1. Disable streaming and use the buffer-mode response.
> 2. Use the [LiteLLM Proxy plugin](../../../docs/integrations/litellm-proxy.md), which enforces Stage 5 in buffer-mode at the gateway.
> 3. Implement a sentinel-only stream and reveal the validated output after Stage 5 returns.
>
> **Streaming-adapter inventory (Rust):**
>
> | Crate | Streaming surface | Status |
> |---|---|---|
> | `agent_shield_anthropic` | buffered `stream_complete` | ✅ Partial — full-message validation |
> | `agent_shield_openai` | buffered `stream_complete` | ✅ Partial — full-message validation |
> | `agent_shield_langchain` | host-driven via shared core guard | ✅ Partial — Pattern B / explicit wrapper |
> | `agent_shield_rig` | hook + Pattern B `GuardedRigTool` | ⚠️ Partial — missing native streaming bridge (upstream rig limitation) |
> | `agent_shield_mcp` | not applicable | n/a — request/response |
> | Direct `async-openai` / SSE consumers | none | ❌ Not safe — pick one of the 3 safe options above |
>
> See [`docs/adapter-mediated-paths.md`](../../../docs/adapter-mediated-paths.md) for the cross-SDK matrix and [`docs/runbooks/incident-streaming-leak.md`](../../../docs/runbooks/incident-streaming-leak.md) for incident response.

## YAML auto-wiring

YAML configurations drive everything; no host code needed for the common case:

- **Runtime-bound `kind: human` handlers** — register `AutoRejectHandler`, `ConsoleApprovalHandler`, or a custom handler with `register_human_resolver` / `with_human_resolver`.
- **LLM clients** — `configurations: - {id, type: llm, provider, model, api_key_env}` auto-wire HTTP-based callers.
- **Classifiers** — `configurations: - {id, type: classifier, provider: lakera_guard | llama_guard | openai_moderation | perspective | aacs}` auto-wire HTTP-based callers (gated by Cargo features).

## Observability

`Shield::with_observability(ConsoleObservabilityProvider::new())` registers a console provider. Every emitted event carries [OpenTelemetry GenAI semantic-convention](https://opentelemetry.io/docs/specs/semconv/gen-ai/) attributes (`gen_ai.system="agent_shield"`, `gen_ai.operation.name="guard.<stage>"`, `gen_ai.response.finish_reason="content_filter"` on blocks), so any OTel exporter (Phoenix, Logfire, Honeycomb, Azure Monitor) sees AgentShield events with the same shape it sees LangChain / OpenAI / Anthropic telemetry.

For cloud backends:

```toml
agent_shield = { git = "...", tag = "v<version>", features = ["otel"] }            # OpenTelemetry SDK
agent_shield = { git = "...", tag = "v<version>", features = ["azure-monitor"] }   # Azure Monitor
agent_shield = { git = "...", tag = "v<version>", features = ["cloudwatch"] }      # AWS CloudWatch
```

## Testing locally

```sh
# Core
cd sdk/rust/agent_shield_core && cargo test --all-features

# Facade
cd sdk/rust/agent_shield && cargo test --all-features

# Per-adapter
cd sdk/rust/agent_shield_rig && cargo test
```

## More

- [Specification](../../../spec/SPECIFICATION.md) — the source of truth for `.guardrails.yaml` semantics.
- [Expression-language reference](../../../spec/expressions/LANGUAGE.md).
- [Examples](../../../examples/) — bank-manager, sensitive-documents, IFC, ask-human MCP server.
