//! Facade smoke tests for the `agent_shield` crate.
//!
//! Exercises [`agent_shield::Shield`] end-to-end against the
//! workspace-level `tests/fixtures/smoke/minimal.guardrails.yaml`
//! fixture. The tests confirm that the facade:
//!
//! 1. Loads a YAML config and builds an `Arc<GuardrailsRuntime>`.
//! 2. Spawns sessions tied to a [`RequestContext`].
//! 3. Drives Stage 1 (`validate_input`), Stage 2/3 (`validate_tool_call`),
//!    Stage 5 (`validate_output`).
//! 4. Honors registered observability providers (one event per stage).
//! 5. Honors registered human resolvers (sanity-only — the minimal
//!    fixture doesn't fire one).

use std::path::PathBuf;
use std::sync::{Arc, Mutex};

use agent_shield::{
    ConsoleObservabilityProvider, ObservabilityProvider, RequestContext, Shield, ShieldLogEvent,
};
use serde_json::json;

fn fixture_path() -> PathBuf {
    let manifest = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    manifest
        .join("../../..")
        .join("tests/fixtures/smoke/minimal.guardrails.yaml")
}

fn input_block_fixture_path() -> PathBuf {
    let manifest = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    manifest
        .join("../../..")
        .join("tests/fixtures/smoke/input-block.guardrails.yaml")
}

/// Test-only collector — captures every emitted event for assertions.
#[derive(Clone, Default)]
struct CapturingProvider {
    events: Arc<Mutex<Vec<ShieldLogEvent>>>,
}

impl ObservabilityProvider for CapturingProvider {
    fn emit(&self, event: ShieldLogEvent) {
        self.events.lock().unwrap().push(event);
    }
}

#[test]
fn loads_minimal_fixture_and_builds() {
    let shield = Shield::from_yaml(fixture_path())
        .build()
        .expect("facade should build minimal fixture");
    assert_eq!(shield.runtime().config().metadata.name, "smoke-minimal");
}

#[test]
fn validate_input_passes_clean_text() {
    let shield = Shield::from_yaml(fixture_path()).build().expect("build");
    let session = shield.new_session(RequestContext::new("s1", "c1"));
    let v = session.validate_input("hello world");
    assert!(v.allowed, "minimal fixture has no input policies");
}

#[test]
fn validate_tool_call_blocks_when_authorized_false() {
    // The minimal fixture's Stage 2 policy blocks `echo` unless
    // `authorized == true`. Default is `false`, so the call is blocked.
    let shield = Shield::from_yaml(fixture_path()).build().expect("build");
    let session = shield.new_session(RequestContext::new("s1", "c1"));
    let mut params = json!({"msg": "hi"});
    let (v, _) = session.validate_tool_call("echo", &mut params, "call_1");
    assert!(!v.allowed, "echo must block when not authorized");
    assert_eq!(v.policy.as_deref(), Some("echo_only_when_authorized"));
}

#[test]
fn validate_tool_call_passes_when_authorized_true() {
    let shield = Shield::from_yaml(fixture_path()).build().expect("build");
    let session = shield.new_session(RequestContext::new("s1", "c1"));
    session.set_variable("authorized", json!(true)).unwrap();
    let mut params = json!({"msg": "hi"});
    let (v, _) = session.validate_tool_call("echo", &mut params, "call_1");
    assert!(v.allowed);
}

#[test]
fn observability_provider_receives_events() {
    let provider = CapturingProvider::default();
    let events = provider.events.clone();
    let shield = Shield::from_yaml(fixture_path())
        .with_observability(provider)
        .build()
        .expect("build");
    let session = shield.new_session(RequestContext::new("s1", "c1"));
    session.set_variable("authorized", json!(true)).unwrap();
    let mut params = json!({"msg": "hi"});
    let _ = session.validate_tool_call("echo", &mut params, "call_1");
    shield.runtime().observability().flush();
    let captured = events.lock().unwrap();
    assert!(
        !captured.is_empty(),
        "provider must observe at least one event"
    );
}

#[test]
fn console_provider_can_be_registered() {
    // The console provider just logs — no panic / build error proves
    // wiring is sound.
    let shield = Shield::from_yaml(fixture_path())
        .with_observability(ConsoleObservabilityProvider::new())
        .build()
        .expect("build");
    let _session = shield.new_session(RequestContext::new("s1", "c1"));
}

#[test]
fn start_turn_returns_guarded_handle_when_input_passes() {
    let shield = Shield::from_yaml(fixture_path()).build().expect("build");
    let turn = shield
        .start_turn(RequestContext::new("s1", "c1"), "hello")
        .expect("input must pass minimal fixture");
    assert_eq!(turn.user_input(), "hello");
    let mut response = "ok".to_string();
    let v = turn.validate_output(&mut response);
    assert!(v.allowed);
    turn.end_turn();
}

#[test]
fn start_turn_closes_turn_on_stage_1_block() {
    // P11.1 amendment: when Stage 1 denies, `start_turn` must call
    // `end_turn` on the session it just opened so observers see the
    // matching `turn.end` event and the session is left in a sane
    // state.
    let provider = CapturingProvider::default();
    let events = provider.events.clone();
    let shield = Shield::from_yaml(input_block_fixture_path())
        .with_observability(provider)
        .build()
        .expect("build input-block fixture");
    let result = shield.start_turn(RequestContext::new("s1", "c1"), "DENY_ME please");
    assert!(result.is_err(), "DENY_ME must trigger Stage 1 block");
    shield.runtime().observability().flush();

    let captured = events.lock().unwrap();
    let ids: Vec<String> = captured.iter().filter_map(|e| e.event_id.clone()).collect();
    assert!(
        ids.iter().any(|k| k == "turn.start"),
        "expected turn.start event id, saw {ids:?}"
    );
    assert!(
        ids.iter().any(|k| k == "turn.end"),
        "expected turn.end event id after Stage 1 block, saw {ids:?}"
    );
}

#[test]
fn guarded_turn_drop_emits_turn_end() {
    // P11.2 amendment: dropping a `GuardedTurn` without an explicit
    // `end_turn()` must still fire `turn.end` via Drop.
    let provider = CapturingProvider::default();
    let events = provider.events.clone();
    let shield = Shield::from_yaml(fixture_path())
        .with_observability(provider)
        .build()
        .expect("build minimal fixture");
    {
        let _turn = shield
            .start_turn(RequestContext::new("s1", "c1"), "hello")
            .expect("Stage 1 must pass");
        // No explicit end_turn — Drop should fire it.
    }
    shield.runtime().observability().flush();
    let captured = events.lock().unwrap();
    let ids: Vec<String> = captured.iter().filter_map(|e| e.event_id.clone()).collect();
    assert!(
        ids.iter().any(|k| k == "turn.end"),
        "expected turn.end via Drop, saw {ids:?}"
    );
}

#[test]
fn guarded_turn_explicit_end_then_drop_is_idempotent() {
    // P11.2 amendment: Drop is safe after explicit end_turn (idempotent).
    let provider = CapturingProvider::default();
    let events = provider.events.clone();
    let shield = Shield::from_yaml(fixture_path())
        .with_observability(provider)
        .build()
        .expect("build minimal fixture");
    {
        let turn = shield
            .start_turn(RequestContext::new("s1", "c1"), "hello")
            .expect("Stage 1 must pass");
        turn.end_turn();
        // Drop fires at end of scope — must not panic and must not
        // double-emit beyond the idempotent end_turn contract.
    }
    shield.runtime().observability().flush();
    let captured = events.lock().unwrap();
    let turn_end_count = captured
        .iter()
        .filter(|e| e.event_id.as_deref() == Some("turn.end"))
        .count();
    assert!(
        turn_end_count >= 1,
        "expected at least one turn.end, saw none"
    );
}
