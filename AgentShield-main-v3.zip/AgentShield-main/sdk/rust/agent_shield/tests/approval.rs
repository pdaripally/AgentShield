//! End-to-end coverage for runtime-registered `kind: human` resolver
//! handlers. YAML declares the human gate; deployment code chooses the
//! active handler with `register_human_resolver`.

use std::fs;
use std::path::PathBuf;
use std::sync::Arc;
use std::time::Duration;

use agent_shield::approval::{
    AutoRejectHandler, CallbackApprovalHandler, ConsoleApprovalHandler, HumanResolveRequest,
    HumanResolverFn, ResolverDecision, ResolverResponse,
};
use agent_shield_core::resolver_runtime::HumanResolver;
use agent_shield_core::runtime::{RequestContext, RuntimeBuilder};
use serde_json::json;

const HUMAN_GATE_YAML: &str = r#"
metadata:
  name: "human-gate-fixture"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["only-when-approved tool calls"]
  forbidden: ["never"]
resources:
  tools:
    - name: "send_money"
      description: "send money"
      permission: "execute"
variables:
  - name: "send_authorized"
    type: "boolean"
    on_demand_by:
      kind: human
      prompt: "Authorize send_money?"
      timeout_ms: 5000
state_validation:
  guard_policies:
    - name: "send_requires_approval"
      applies_to:
        tools:
          - "send_money"
      evaluate_when:
        - expression: "send_authorized == true"
          reason: "send_money requires explicit approval"
      action: "block"
"#;

fn write_yaml(yaml: &str, name: &str) -> PathBuf {
    let manifest = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    let dir = manifest.join("target/test-yaml");
    fs::create_dir_all(&dir).unwrap();
    let path = dir.join(format!("{name}.guardrails.yaml"));
    fs::write(&path, yaml).unwrap();
    path
}

fn validate_send_money(
    runtime: &Arc<agent_shield_core::GuardrailsRuntime>,
) -> agent_shield_core::StageVerdict {
    let session = runtime.new_session(RequestContext::new("s1", "c1"));
    let mut params = json!({"amount": 100});
    let (v, _) = session.validate_tool_call("send_money", &mut params, "call_1");
    v
}

#[test]
fn auto_reject_handler_denies_tool_call() {
    let yaml_path = write_yaml(HUMAN_GATE_YAML, "auto_reject");
    let runtime = RuntimeBuilder::from_yaml(&yaml_path)
        .expect("yaml load")
        .register_human_resolver(Arc::new(AutoRejectHandler))
        .build()
        .expect("build");

    let v = validate_send_money(&runtime);
    assert!(!v.allowed, "auto_reject must deny");
    assert_eq!(v.policy.as_deref(), Some("send_requires_approval"));
}

#[test]
fn callback_handler_allows_when_closure_returns_allow() {
    let yaml_path = write_yaml(HUMAN_GATE_YAML, "callback_allow");
    let allow_handler =
        CallbackApprovalHandler::new(|_req: HumanResolveRequest| ResolverResponse {
            decision: ResolverDecision::Allow,
            value: Some(json!(true)),
            set_variables: Default::default(),
            reason: None,
        });
    let runtime = RuntimeBuilder::from_yaml(&yaml_path)
        .expect("yaml load")
        .register_human_resolver(Arc::new(allow_handler))
        .build()
        .expect("build");

    let v = validate_send_money(&runtime);
    assert!(v.allowed, "callback returning Allow should permit the call");
}

#[test]
fn callback_handler_blocks_when_closure_returns_deny() {
    let yaml_path = write_yaml(HUMAN_GATE_YAML, "callback_deny");
    let deny_handler = CallbackApprovalHandler::new(|_req: HumanResolveRequest| ResolverResponse {
        decision: ResolverDecision::Deny,
        value: None,
        set_variables: Default::default(),
        reason: Some("policy denies".into()),
    });
    let runtime = RuntimeBuilder::from_yaml(&yaml_path)
        .expect("yaml load")
        .register_human_resolver(Arc::new(deny_handler))
        .build()
        .expect("build");

    let v = validate_send_money(&runtime);
    assert!(!v.allowed);
}

#[test]
fn no_registered_human_resolver_fails_closed_through_gate() {
    let yaml_path = write_yaml(HUMAN_GATE_YAML, "unregistered");
    let runtime = RuntimeBuilder::from_yaml(&yaml_path)
        .expect("yaml load")
        .build()
        .expect("build");

    let v = validate_send_money(&runtime);
    assert!(!v.allowed, "missing human resolver must fail closed");
}

#[test]
fn console_handler_with_scripted_input_allows_on_o() {
    use agent_shield::approval::console::ScriptedReader;
    let yaml_path = write_yaml(HUMAN_GATE_YAML, "console_o");
    let reader = Arc::new(ScriptedReader::new(["o\n"]));
    let console = ConsoleApprovalHandler::with_reader(Duration::from_secs(1), reader);
    let runtime = RuntimeBuilder::from_yaml(&yaml_path)
        .expect("yaml load")
        .register_human_resolver(Arc::new(console))
        .build()
        .expect("build");

    let v = validate_send_money(&runtime);
    assert!(v.allowed, "console `o` (allow once) should permit the call");
}

#[test]
fn console_handler_with_scripted_input_blocks_on_n() {
    use agent_shield::approval::console::ScriptedReader;
    let yaml_path = write_yaml(HUMAN_GATE_YAML, "console_n");
    let reader = Arc::new(ScriptedReader::new(["n\n"]));
    let console = ConsoleApprovalHandler::with_reader(Duration::from_secs(1), reader);
    let runtime = RuntimeBuilder::from_yaml(&yaml_path)
        .expect("yaml load")
        .register_human_resolver(Arc::new(console))
        .build()
        .expect("build");

    let v = validate_send_money(&runtime);
    assert!(!v.allowed);
}

#[test]
fn last_registered_human_resolver_wins() {
    let yaml_path = write_yaml(HUMAN_GATE_YAML, "last_wins");
    let runtime = RuntimeBuilder::from_yaml(&yaml_path)
        .expect("yaml load")
        .register_human_resolver(Arc::new(HumanResolverFn(|_| ResolverResponse {
            decision: ResolverDecision::Deny,
            value: None,
            set_variables: Default::default(),
            reason: Some("first".into()),
        })))
        .register_human_resolver(Arc::new(HumanResolverFn(|_| ResolverResponse {
            decision: ResolverDecision::Allow,
            value: Some(json!(true)),
            set_variables: Default::default(),
            reason: Some("second".into()),
        })))
        .build()
        .expect("build");

    let v = validate_send_money(&runtime);
    assert!(v.allowed, "last registered handler should win");
}

#[test]
fn surface_check_handlers_implement_human_resolver() {
    let _: &dyn HumanResolver = &AutoRejectHandler;
    let _: &dyn HumanResolver = &ConsoleApprovalHandler::new();
    let _: &dyn HumanResolver = &CallbackApprovalHandler::new(|_| ResolverResponse {
        decision: ResolverDecision::Deny,
        value: None,
        set_variables: Default::default(),
        reason: None,
    });
}

#[test]
fn human_resolver_provider_field_is_rejected() {
    let yaml = HUMAN_GATE_YAML.replace(
        "      prompt:",
        "      provider: auto_reject\n      prompt:",
    );
    let yaml_path = write_yaml(&yaml, "provider_rejected");
    let err = RuntimeBuilder::from_yaml(&yaml_path).unwrap_err();
    let msg = err.to_string();
    assert!(
        msg.contains("provider") && msg.contains("not allowed"),
        "{msg}"
    );
}

#[test]
fn human_resolver_name_field_is_rejected() {
    let yaml = HUMAN_GATE_YAML.replace("      prompt:", "      name: user_approval\n      prompt:");
    let yaml_path = write_yaml(&yaml, "name_rejected");
    let err = RuntimeBuilder::from_yaml(&yaml_path).unwrap_err();
    let msg = err.to_string();
    assert!(msg.contains("name") && msg.contains("not allowed"), "{msg}");
}
