//! Cross-language Shield/ShieldBuilder method-parity test for the Rust SDK.
//!
//! Unlike the Python/Node tests, Rust enforces method parity at *compile
//! time* by taking a function pointer to every canonical method. If a
//! canonical method is renamed, removed, or has its signature changed, this
//! test fails to compile — the strongest form of drift detection.
//!
//! The runtime portion of the test loads `tests/parity/shield_canonical_api.json`
//! verifies, for every entry where `must_exist_in` includes `"rust"`,
//! that the Rust alias listed in the canonical file matches one of the
//! compile-time-checked names below. This catches the canonical file falling
//! out of sync with what Rust actually exports.
//!
//! See `tests/parity/README.md` for the cross-language story.

use std::collections::HashSet;
use std::fs;
use std::path::PathBuf;
use std::sync::Arc;

use agent_shield::{
    AgentResolver, CapabilityReport, ClassifierCaller, DelegateDispatcher, LlmCaller,
    ObservabilityProvider, OnBlockPolicy, RequestContext, Shield, ShieldBuilder, ShieldMode,
    ToolWrapper,
};
use agent_shield_core::GuardrailsRuntime;

const LANG: &str = "rust";

fn repo_root() -> PathBuf {
    // CARGO_MANIFEST_DIR points at sdk/rust/agent_shield. The repo root is
    // four levels up.
    let mut p = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    for _ in 0..3 {
        p.pop();
    }
    p
}

fn load_canonical() -> serde_json::Value {
    let path = repo_root()
        .join("tests")
        .join("parity")
        .join("shield_canonical_api.json");
    let raw = fs::read_to_string(&path).unwrap_or_else(|e| {
        panic!("could not read {}: {e}", path.display());
    });
    serde_json::from_str(&raw).expect("canonical JSON does not parse")
}

// ─── Compile-time presence: every canonical method gets a function-pointer
//     reference. If a method is removed/renamed/has its signature changed,
//     this module fails to compile — the strongest possible drift signal. ───

#[allow(dead_code)]
mod compile_time_shape {
    use super::*;
    use std::path::Path;

    // ── Shield static factories ──
    pub const FROM_YAML: fn(&Path) -> ShieldBuilder = |p| Shield::from_yaml(p);
    pub const FROM_YAML_CHAIN: fn(&[&Path]) -> ShieldBuilder =
        |paths| Shield::from_yaml_chain(paths);
    pub const FROM_RUNTIME: fn(Arc<GuardrailsRuntime>) -> ShieldBuilder = Shield::from_runtime;

    // ── Shield instance accessors / methods ──
    pub fn use_accessors(s: &Shield) {
        let _: &CapabilityReport = s.capabilities();
        let _: ShieldMode = s.mode();
        let _: OnBlockPolicy = s.on_block_policy();
        let _: Arc<agent_shield_core::GuardrailsSession> = s.session();
        let _: Arc<GuardrailsRuntime> = s.runtime();
    }

    pub fn use_with_session(
        s: &Shield,
        session: Arc<agent_shield_core::GuardrailsSession>,
    ) -> Shield {
        s.with_session(session)
    }

    pub fn use_with_fresh_session(s: &Shield) -> Shield {
        s.with_fresh_session()
    }

    pub async fn use_before_invoke(s: &Shield, input: &str) -> Option<String> {
        s.before_invoke(input).await.unwrap()
    }

    pub fn use_protect_tools<T: ToolWrapper>(s: &Shield, tools: Vec<T::Tool>) -> Vec<T::Wrapped> {
        s.protect_tools::<T>(tools)
    }

    // ── ShieldBuilder methods ──
    pub fn use_builder_methods(b: ShieldBuilder) {
        fn _swallow<T>(_: T) {}
        let b = b.with_mode(ShieldMode::Enforce);
        let b = b.with_on_block(OnBlockPolicy::ReturnBlocked);
        let b = b.with_capability(CapabilityReport::full("test"));
        let b = b.with_request_context(RequestContext::default());
        let b = b.with_tool_retry_limit(3);
        // Resolver / caller hooks all take `impl Trait + 'static` — a
        // signature change to any of them fails this module to compile.
        fn _llm<C: LlmCaller + 'static>(b: ShieldBuilder, c: C) -> ShieldBuilder {
            b.with_llm(c)
        }
        fn _agent<R: AgentResolver + 'static>(b: ShieldBuilder, r: R) -> ShieldBuilder {
            b.with_agent_resolver(r)
        }
        fn _delegate<D: DelegateDispatcher + 'static>(b: ShieldBuilder, d: D) -> ShieldBuilder {
            b.with_delegate_dispatcher(d)
        }
        fn _classifier<C: ClassifierCaller + 'static>(b: ShieldBuilder, c: C) -> ShieldBuilder {
            b.with_classifier(c)
        }
        fn _obs<P: ObservabilityProvider + 'static>(b: ShieldBuilder, p: P) -> ShieldBuilder {
            b.with_observability(p)
        }
        // with_extractor takes a closure.
        let b = b.with_extractor("noop", |v: &serde_json::Value| Some(v.clone()));
        let b = b.with_observability(agent_shield::ConsoleObservabilityProvider::new());
        let _: Result<Shield, _> = b.build();
        _swallow(_llm::<NoopLlm>);
        _swallow(_agent::<NoopAgentResolver>);
        _swallow(_delegate::<NoopDelegateDispatcher>);
        _swallow(_classifier::<NoopClassifierCaller>);
        _swallow(_obs::<agent_shield::ConsoleObservabilityProvider>);
    }
}

// ── Type-only stubs so the compile-time block can name a concrete
//     type for each generic call. They are never instantiated. ──
fn _noop_response() -> agent_shield::ResolverResponse {
    agent_shield::ResolverResponse {
        decision: agent_shield::ResolverDecision::Deny,
        value: None,
        set_variables: std::collections::HashMap::new(),
        reason: Some("noop".into()),
    }
}

#[allow(dead_code)]
struct NoopLlm;
impl LlmCaller for NoopLlm {
    fn call(&self, _cfg: Option<&str>, _prompt: &str) -> Result<agent_shield::LlmResponse, String> {
        Err("noop".into())
    }
}
#[allow(dead_code)]
struct NoopAgentResolver;
impl AgentResolver for NoopAgentResolver {
    fn resolve(
        &self,
        _req: agent_shield::AgentResolveRequest,
    ) -> Result<agent_shield::ResolverResponse, agent_shield_core::ResolverRuntimeError> {
        Ok(_noop_response())
    }
}
#[allow(dead_code)]
struct NoopDelegateDispatcher;
impl DelegateDispatcher for NoopDelegateDispatcher {
    fn dispatch(
        &self,
        _req: agent_shield::DelegateRequest,
    ) -> Result<agent_shield::ResolverResponse, agent_shield_core::ResolverRuntimeError> {
        Ok(_noop_response())
    }
}
#[allow(dead_code)]
struct NoopClassifierCaller;
impl ClassifierCaller for NoopClassifierCaller {
    fn classify(
        &self,
        _cfg: &str,
        _subject: &str,
    ) -> Result<agent_shield::ClassifierVerdict, String> {
        Err("noop".into())
    }
}

#[test]
fn canonical_rust_aliases_are_recognised_methods() {
    let canonical = load_canonical();

    // The set of method names the compile-time block above references. If
    // the canonical JSON's `aliases.rust` slot lists a name that isn't in
    // this set, either:
    //   - the canonical file is wrong (rename it), or
    //   - the compile-time block is missing a reference (add one).
    let compile_time_known: HashSet<&'static str> = [
        // Shield:
        "from_yaml",
        "from_yaml_chain",
        "from_runtime",
        "with_session",
        "with_fresh_session",
        "mode",
        "on_block_policy",
        "session",
        "runtime",
        "capabilities",
        "protect_tools",
        "protect_tool",
        "run",
        "guarded_run",
        "before_invoke",
        "new_session",
        "start_turn",
        // ShieldBuilder:
        "build",
        "with_mode",
        "with_on_block",
        "with_perf_telemetry",
        "with_capability",
        "with_request_context",
        "with_tool_retry_limit",
        "with_llm",
        "with_agent_resolver",
        "with_delegate_dispatcher",
        "with_classifier",
        "with_extractor",
        "with_observability",
        "empty",
    ]
    .into_iter()
    .collect();

    let mut missing: Vec<(String, String)> = Vec::new();
    for key in ["shield_methods", "shield_builder_methods"] {
        let entries = canonical[key].as_array().expect("array");
        for entry in entries {
            let must = entry["must_exist_in"]
                .as_array()
                .unwrap()
                .iter()
                .any(|v| v.as_str() == Some(LANG));
            if !must {
                continue;
            }
            let alias = entry["aliases"][LANG].as_str().unwrap_or("");
            if !compile_time_known.contains(alias) {
                missing.push((
                    entry["name"].as_str().unwrap().to_string(),
                    alias.to_string(),
                ));
            }
        }
    }

    assert!(
        missing.is_empty(),
        "Canonical Rust aliases not present in the compile-time-checked surface: {missing:?}. \
         Either fix the alias in tests/parity/shield_canonical_api.json or add a function-pointer \
         reference for it in `compile_time_shape` in tests/parity_api.rs."
    );
}

#[test]
fn rust_specific_extensions_are_real_methods() {
    let canonical = load_canonical();
    let extensions = &canonical["language_specific_extensions"][LANG];

    let compile_time_known: HashSet<&'static str> = [
        // Shield extensions:
        "guarded_run",
        "new_session",
        "on_block_policy",
        "start_turn",
        // ShieldBuilder extensions:
        "empty",
        "with_request_context",
        "with_tool_retry_limit",
    ]
    .into_iter()
    .collect();

    for kind in ["shield", "shield_builder"] {
        let names = extensions[kind].as_array().expect("array");
        for n in names {
            let name = n.as_str().unwrap();
            assert!(
                compile_time_known.contains(name),
                "Rust extension `{name}` (declared in language_specific_extensions.{LANG}.{kind}) \
                 is not in the compile-time-known set in tests/parity_api.rs. Either remove the \
                 entry from the canonical or add it to the compile-time-known set."
            );
        }
    }
}
