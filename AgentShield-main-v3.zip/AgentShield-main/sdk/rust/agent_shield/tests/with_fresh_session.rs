//! Tests for `Shield::with_fresh_session`.
//!
//! Verifies the post-build immutability contract:
//!
//! 1. `with_fresh_session()` returns a NEW `Shield` (different session
//!    pointer from the original).
//! 2. The original Shield's session is untouched (variables / state
//!    set on it remain readable).
//! 3. The new Shield has a fresh, independent session.
//! 4. Both Shields share the same underlying `GuardrailsRuntime`
//!    (cheap fork, no double-build).
//!
//! Mirrors the `withFreshSession` / `with_fresh_session` /
//! `WithFreshSession` tests in the Node, Python, and .NET SDKs.

use std::path::PathBuf;
use std::sync::Arc;

use agent_shield::Shield;

fn fixture_path(name: &str) -> PathBuf {
    let manifest = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    manifest
        .join("../../..")
        .join("tests/fixtures/smoke")
        .join(name)
}

#[test]
fn with_fresh_session_returns_a_new_shield() {
    let original = Shield::from_yaml(fixture_path("minimal.guardrails.yaml"))
        .build()
        .expect("build should succeed");
    let original_session = original.session();

    let forked = original.with_fresh_session();
    let forked_session = forked.session();

    // (1) Different session — the fork did not mutate the original.
    assert!(
        !Arc::ptr_eq(&original_session, &forked_session),
        "with_fresh_session() must return a Shield bound to a new Session, \
         not the same Arc<GuardrailsSession>",
    );

    // (2) The original Shield's session is still the one we captured
    // before the fork (no in-place swap).
    assert!(
        Arc::ptr_eq(&original_session, &original.session()),
        "original Shield's session must not be swapped by with_fresh_session()",
    );

    // (4) Both Shields share the same runtime — forking is cheap and
    // does not rebuild the policy graph.
    assert!(
        Arc::ptr_eq(&original.runtime(), &forked.runtime()),
        "with_fresh_session() must share the underlying runtime",
    );
}

#[test]
fn original_session_state_survives_fork() {
    let original = Shield::from_yaml(fixture_path("minimal.guardrails.yaml"))
        .build()
        .expect("build should succeed");

    let original_session_arc = original.session();

    // Open a turn on the original session — this advances
    // `current_turn_id` from 0 to 1 on this specific Session value.
    // (Per-session state, not shared via the runtime tracker.)
    let original_turn = original
        .session()
        .begin_turn()
        .expect("begin_turn on original");
    assert_eq!(original_turn, 1);
    assert_eq!(original.session().current_turn_id(), 1);

    // Fork — must NOT touch the original session.
    let forked = original.with_fresh_session();

    // (2) Original Shield's Arc<Session> pointer is preserved (no
    // in-place swap), and its mid-turn state is intact.
    assert!(
        Arc::ptr_eq(&original_session_arc, &original.session()),
        "with_fresh_session() must NOT swap the original Shield's session",
    );
    assert_eq!(
        original.session().current_turn_id(),
        1,
        "original session must still be on turn 1 after the fork",
    );

    // (3) Forked Shield's session is a brand-new Session (turn id 0,
    // unaffected by the original's open turn).
    assert_eq!(
        forked.session().current_turn_id(),
        0,
        "forked Shield must start with a fresh session (turn id 0)",
    );

    // Tidy up.
    let _ = original.session().end_turn();
}
