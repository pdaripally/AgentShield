//! v8 perf-logging PR6 — Rust SDK surface test.
//!
//! Verifies that `ShieldBuilder::with_perf_telemetry` round-trips the
//! gating knob into the underlying [`agent_shield_core::GuardrailsRuntime`]
//! for all three modes. The full event catalogue (per-stage, per-policy,
//! AC10-Corr correlation) is covered by
//! `agent_shield_core/tests/perf_telemetry.rs`; this file just pins
//! the wrapper-level delegation.

use std::sync::{Arc, Mutex};

use agent_shield::{ObservabilityProvider, PerfTelemetry, Shield, ShieldLogEvent};
use agent_shield_core::ObsEventType as EventType;

/// Cloneable handle to a shared event buffer; the
/// `ObservabilityProvider` impl below lives on `Capture` while the
/// test retains a `CaptureHandle` so it can read after the builder
/// has consumed the provider.
#[derive(Clone)]
struct CaptureHandle {
    events: Arc<Mutex<Vec<ShieldLogEvent>>>,
}

impl CaptureHandle {
    fn new() -> Self {
        Self {
            events: Arc::new(Mutex::new(Vec::new())),
        }
    }
    fn count_perf(&self) -> usize {
        self.events
            .lock()
            .unwrap()
            .iter()
            .filter(|e| {
                matches!(
                    e.event_type,
                    EventType::StageEvaluated
                        | EventType::PolicyEvaluated
                        | EventType::LlmCalled
                        | EventType::ClassifierCalled
                )
            })
            .count()
    }
}

/// Owned provider. `ShieldBuilder::with_observability` takes
/// `impl ObservabilityProvider + 'static` so we hand it the owning
/// struct; the test retains a `CaptureHandle` for assertions.
struct Capture(CaptureHandle);
impl ObservabilityProvider for Capture {
    fn emit(&self, event: ShieldLogEvent) {
        self.0.events.lock().unwrap().push(event);
    }
}

const YAML: &str = r#"
metadata:
  name: shield-perf
  version: "1.0.0"
input_validation:
  guard_policies:
    - name: pii_regex
      evaluate_when:
        - pattern: '\d{3}-\d{2}-\d{4}'
          reason: 'SSN'
          action: block
"#;

/// Materialise the policy YAML to a temp file inside a `TempDir` so
/// the directory is removed automatically when the handle drops at
/// the end of each test. Earlier drafts used `std::env::temp_dir()`
/// directly, which left `agent-shield-perf-*` directories piling up
/// on developer machines after every run (caught in Copilot's PR #138
/// review).
fn yaml_to_temp() -> (tempfile::TempDir, std::path::PathBuf) {
    let dir = tempfile::Builder::new()
        .prefix("agent-shield-perf-")
        .tempdir()
        .expect("create temp dir");
    let path = dir.path().join("shield.guardrails.yaml");
    std::fs::write(&path, YAML).expect("write yaml");
    (dir, path)
}

#[test]
fn shield_builder_with_perf_telemetry_off_emits_no_perf_events() {
    let handle = CaptureHandle::new();
    // Default: build() without with_perf_telemetry → Off.
    let (_tmp, path) = yaml_to_temp();
    let shield = Shield::from_yaml(&path)
        .with_observability(Capture(handle.clone()))
        .build()
        .expect("build");
    let session = shield.session();
    let _ = session.validate_input("hello");
    shield.runtime().observability().flush();
    assert_eq!(
        handle.count_perf(),
        0,
        "Off (default) must emit zero perf events"
    );
}

#[test]
fn shield_builder_with_perf_telemetry_full_emits_perf_events() {
    let handle = CaptureHandle::new();
    let (_tmp, path) = yaml_to_temp();
    let shield = Shield::from_yaml(&path)
        .with_observability(Capture(handle.clone()))
        .with_perf_telemetry(PerfTelemetry::Full)
        .build()
        .expect("build");
    let session = shield.session();
    let _ = session.validate_input("hello");
    shield.runtime().observability().flush();
    assert!(
        handle.count_perf() >= 1,
        "Full must emit at least one perf event"
    );
}

#[test]
fn shield_builder_with_perf_telemetry_external_emits_no_stage_or_policy_events() {
    let handle = CaptureHandle::new();
    let (_tmp, path) = yaml_to_temp();
    let shield = Shield::from_yaml(&path)
        .with_observability(Capture(handle.clone()))
        .with_perf_telemetry(PerfTelemetry::External)
        .build()
        .expect("build");
    let session = shield.session();
    let _ = session.validate_input("hello");
    shield.runtime().observability().flush();
    // External MUST emit zero stage/policy events. This YAML uses only
    // regex detection, so it also emits zero LLM / classifier events —
    // the perf count is zero overall.
    assert_eq!(
        handle.count_perf(),
        0,
        "External + regex-only policy must emit zero perf events"
    );
}
