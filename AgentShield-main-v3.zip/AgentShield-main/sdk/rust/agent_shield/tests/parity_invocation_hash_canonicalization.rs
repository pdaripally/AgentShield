use std::fs;
use std::path::PathBuf;

use agent_shield::{RequestContext, Shield};
use serde::Deserialize;
use serde_json::Value;

#[derive(Debug, Deserialize)]
struct Fixture {
    cases: Vec<Case>,
}

#[derive(Debug, Deserialize)]
struct Case {
    name: String,
    fixture: String,
    tool_name: String,
    tool_call_id: String,
    params: Value,
    expected: Expected,
}

#[derive(Debug, Deserialize)]
struct Expected {
    invocation_hash: String,
    post_validation_invocation_hash: String,
    effective_params: Option<Value>,
}

fn repo_root() -> PathBuf {
    let mut dir = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    while !dir.join(".git").exists() {
        if !dir.pop() {
            panic!("repo root not found");
        }
    }
    dir
}

fn load_fixture() -> Fixture {
    let path = repo_root()
        .join("tests")
        .join("parity")
        .join("invocation_hash_canonicalization.json");
    serde_json::from_str(&fs::read_to_string(path).expect("read fixture")).expect("parse fixture")
}

#[test]
fn validate_tool_call_matches_canonical_hashes() {
    for case in load_fixture().cases {
        let shield = Shield::from_yaml(repo_root().join(&case.fixture))
            .build()
            .expect("build parity fixture");
        let session = shield.new_session(RequestContext::new(
            format!("sess-{}", case.name),
            format!("corr-{}", case.name),
        ));
        let mut params = case.params.clone();
        let (verdict, _) =
            session.validate_tool_call(&case.tool_name, &mut params, case.tool_call_id.as_str());
        assert!(verdict.allowed, "{}", case.name);
        assert_eq!(
            verdict.invocation_hash.as_deref(),
            Some(case.expected.invocation_hash.as_str())
        );
        assert_eq!(
            verdict.post_validation_invocation_hash.as_deref(),
            Some(case.expected.post_validation_invocation_hash.as_str())
        );
        if let Some(expected) = case.expected.effective_params {
            assert_eq!(params, expected, "{}", case.name);
        }
    }
}
