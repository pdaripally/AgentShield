//! Tests for `ShieldBuilder` consume-on-build semantics.
//!
//! In Rust this invariant is enforced at compile time — `pub fn build(mut self)`
//! takes ownership, so a second `.build()` call simply does not type-check.
//! This file verifies:
//!
//! 1. The happy path: a single `.build()` call returns a working Shield.
//! 2. A fresh `Shield::from_yaml(...)` call after a successful `.build()` yields
//!    a fresh, independent builder that builds successfully.
//! 3. The defensive `BuildSource::Empty` arm carries a clear "builder already
//!    consumed" message, surfaced through the `ShieldError::AutoWire` envelope.
//!
//! The compile-time guarantee is documented in a `compile_fail` doctest below
//! so the contract is checked on every `cargo test`.

use std::path::PathBuf;

use agent_shield::Shield;

fn fixture_path(name: &str) -> PathBuf {
    let manifest = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    manifest
        .join("../../..")
        .join("tests/fixtures/smoke")
        .join(name)
}

#[test]
fn first_build_succeeds() {
    let shield = Shield::from_yaml(fixture_path("minimal.guardrails.yaml"))
        .build()
        .expect("first build should succeed");
    assert_eq!(shield.capabilities().framework, "core");
}

#[test]
fn fresh_from_yaml_produces_fresh_independent_builder() {
    let path = fixture_path("minimal.guardrails.yaml");
    let _first = Shield::from_yaml(&path)
        .build()
        .expect("first build should succeed");
    let _second = Shield::from_yaml(&path)
        .build()
        .expect("a fresh from_yaml() must always produce a buildable builder");
}

// `pub fn build(mut self)` consumes the builder by value, so the
// compiler rejects any second `.build()` on the same binding. This is
// the source-of-truth for the Rust contract; the other SDKs replicate
// the runtime check.
//
// The following snippet does **not** type-check (kept as documentation):
//
//     use agent_shield::Shield;
//     let builder = Shield::from_yaml("does-not-matter.yaml");
//     let _ = builder.build();
//     // Second call: error[E0382]: use of moved value: `builder`
//     let _ = builder.build();
