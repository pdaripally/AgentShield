//! Cross-language CapabilityReport conformance test for the Rust SDK.
//!
//! For every adapter the canonical matrix says Rust implements, this test
//! loads the adapter's `with_<framework>()` extension, builds a Shield with
//! a deliberately-unwired runtime, reads the live `CapabilityReport`, and
//! asserts it matches `apply_overrides(canonical, "rust")`.
//!
//! Adding a new `language_overrides.rust` entry in
//! `tests/parity/capability_canonical.json` documents accepted divergence;
//! removing one forces the Rust adapter crate to align.

use std::collections::BTreeMap;
use std::fs;
use std::path::PathBuf;

use agent_shield::{CapabilityReport, CoverageLevel, Shield};

const LANG: &str = "rust";

const STAGE_FIELDS: &[&str] = &[
    "input_validation",
    "state_validation",
    "tool_authorization",
    "tool_execution_validation",
    "tool_output_validation",
    "output_validation",
    "streaming_output",
];

fn repo_root() -> PathBuf {
    let mut p = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    for _ in 0..3 {
        p.pop();
    }
    p
}

fn fixture_path() -> PathBuf {
    repo_root()
        .join("tests")
        .join("fixtures")
        .join("smoke")
        .join("minimal.guardrails.yaml")
}

fn load_canonical() -> serde_json::Value {
    let path = repo_root()
        .join("tests")
        .join("parity")
        .join("capability_canonical.json");
    let raw = fs::read_to_string(&path).unwrap_or_else(|e| {
        panic!("could not read {}: {e}", path.display());
    });
    serde_json::from_str(&raw).expect("canonical JSON does not parse")
}

fn level_to_str(level: CoverageLevel) -> &'static str {
    match level {
        CoverageLevel::Full => "full",
        CoverageLevel::Partial => "partial",
        CoverageLevel::Unsupported => "unsupported",
    }
}

fn report_to_dict(report: &CapabilityReport) -> BTreeMap<String, String> {
    let mut out = BTreeMap::new();
    out.insert("framework".into(), report.framework.clone());
    let stages = [
        ("input_validation", report.input_validation),
        ("state_validation", report.state_validation),
        ("tool_authorization", report.tool_authorization),
        (
            "tool_execution_validation",
            report.tool_execution_validation,
        ),
        ("tool_output_validation", report.tool_output_validation),
        ("output_validation", report.output_validation),
        ("streaming_output", report.streaming_output),
    ];
    for (name, level) in stages {
        if let Some(level) = level {
            out.insert(name.into(), level_to_str(level).into());
        } else {
            // None means "stage not declared". Encode as `<unset>` so a
            // canonical claim of e.g. `"streaming_output": "full"` against
            // an unset Rust report fails loudly rather than silently.
            out.insert(name.into(), "<unset>".into());
        }
    }
    out
}

fn expected_for(canonical: &serde_json::Value, fw: &str) -> BTreeMap<String, String> {
    let entry = &canonical["frameworks"][fw];
    let mut out = BTreeMap::new();
    out.insert(
        "framework".into(),
        entry["canonical"]["framework"]
            .as_str()
            .unwrap()
            .to_string(),
    );
    for stage in STAGE_FIELDS {
        let v = &entry["canonical"][*stage];
        if let Some(s) = v.as_str() {
            out.insert((*stage).into(), s.to_string());
        }
    }
    if let Some(overrides) = entry["language_overrides"][LANG].as_object() {
        for (k, v) in overrides {
            if k.starts_with('$') {
                continue;
            }
            if let Some(s) = v.as_str() {
                out.insert(k.clone(), s.to_string());
            }
        }
    }
    out
}

fn assert_matches(framework: &str, expected: &BTreeMap<String, String>, actual: &CapabilityReport) {
    let actual_d = report_to_dict(actual);
    let exp_fw = expected.get("framework").cloned().unwrap_or_default();
    assert_eq!(
        actual.framework, exp_fw,
        "[{framework}] framework name drift: actual={:?} expected={exp_fw:?}. \
         Either update the Rust adapter or move this divergence into \
         language_overrides.{LANG} in tests/parity/capability_canonical.json.",
        actual.framework
    );

    let mut diffs = Vec::new();
    for stage in STAGE_FIELDS {
        let exp = expected.get(*stage).cloned();
        let act = actual_d.get(*stage).cloned();
        if exp != act {
            diffs.push(format!("  {stage}: actual={act:?} expected={exp:?}"));
        }
    }
    assert!(
        diffs.is_empty(),
        "[{framework}] capability drift between Rust and the canonical matrix:\n{}\n\
         To accept this divergence, add the field to \
         `frameworks.{framework}.language_overrides.{LANG}` in \
         tests/parity/capability_canonical.json.",
        diffs.join("\n")
    );
}

fn build_shield_with<F>(install: F) -> Shield
where
    F: FnOnce(agent_shield::ShieldBuilder) -> agent_shield::ShieldBuilder,
{
    let builder = Shield::from_yaml(fixture_path());
    install(builder).build().expect("Shield builds")
}

#[test]
fn langchain_capability_matches_canonical() {
    use agent_shield_langchain::ShieldLangChainExt;
    let canonical = load_canonical();
    let shield = build_shield_with(|b| b.with_langchain());
    assert_matches(
        "langchain",
        &expected_for(&canonical, "langchain"),
        shield.capabilities(),
    );
}

#[test]
fn openai_capability_matches_canonical() {
    use agent_shield_openai::ShieldOpenAIExt;
    let canonical = load_canonical();
    let shield = build_shield_with(|b| b.with_openai());
    assert_matches(
        "openai_agents",
        &expected_for(&canonical, "openai_agents"),
        shield.capabilities(),
    );
}

#[test]
fn anthropic_capability_matches_canonical() {
    use agent_shield_anthropic::ShieldAnthropicExt;
    let canonical = load_canonical();
    let shield = build_shield_with(|b| b.with_anthropic());
    assert_matches(
        "anthropic_agents",
        &expected_for(&canonical, "anthropic_agents"),
        shield.capabilities(),
    );
}

#[test]
fn rig_capability_matches_canonical() {
    use agent_shield_rig::ShieldRigExt;
    let canonical = load_canonical();
    let shield = build_shield_with(|b| b.with_rig());
    assert_matches(
        "rig",
        &expected_for(&canonical, "rig"),
        shield.capabilities(),
    );
}

/// Sanity check: every framework the canonical matrix says Rust implements
/// has a dedicated `_capability_matches_canonical` test above. Surfaces
/// missing test coverage when someone adds a new entry to the matrix.
#[test]
fn every_rust_framework_in_canonical_has_a_test() {
    let canonical = load_canonical();
    let mut declared: Vec<String> = Vec::new();
    for (fw, entry) in canonical["frameworks"].as_object().unwrap() {
        let implemented = entry["implemented_in"]
            .as_array()
            .unwrap()
            .iter()
            .any(|v| v.as_str() == Some(LANG));
        if implemented {
            declared.push(fw.clone());
        }
    }
    declared.sort();
    let expected_tests: Vec<&str> = vec!["anthropic_agents", "langchain", "openai_agents", "rig"];
    let actual: Vec<&str> = declared.iter().map(|s| s.as_str()).collect();
    assert_eq!(
        actual, expected_tests,
        "Rust frameworks declared in capability_canonical.json have changed. Update \
         tests/parity_capability.rs to add or remove `*_capability_matches_canonical` tests \
         and update the `expected_tests` list."
    );
}
