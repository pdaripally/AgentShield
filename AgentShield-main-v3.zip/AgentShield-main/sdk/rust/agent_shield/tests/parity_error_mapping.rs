use std::fs;
use std::path::PathBuf;

use agent_shield::{Shield, ShieldError};
use serde::Deserialize;

#[derive(Debug, Deserialize)]
struct Fixture {
    cases: Vec<Case>,
}

#[derive(Debug, Deserialize)]
struct Case {
    name: String,
    fixture: String,
    expected: Expected,
}

#[derive(Debug, Deserialize)]
struct Expected {
    rust: String,
}

fn repo_root() -> PathBuf {
    let mut dir = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    while !dir.join(".git").exists() {
        if !dir.pop() {
            panic!("repo root not found");
        }
    }
    dir
}

fn load_fixture() -> Fixture {
    let path = repo_root()
        .join("tests")
        .join("parity")
        .join("error_mapping_parity.json");
    serde_json::from_str(&fs::read_to_string(path).expect("read fixture")).expect("parse fixture")
}

#[tokio::test]
async fn shield_blocked_raise_maps_to_expected_variant() {
    let case = load_fixture()
        .cases
        .into_iter()
        .find(|c| c.name == "shield_blocked_raise")
        .expect("shield case");
    let shield = Shield::from_yaml(repo_root().join(case.fixture))
        .build()
        .expect("build fixture");
    let result = shield
        .guarded_run("DENY_ME please", |_| async move {
            Ok::<String, ShieldError>("never runs".to_string())
        })
        .await;
    match result {
        Err(ShieldError::Blocked { .. }) => assert_eq!(case.expected.rust, "ShieldError::Blocked"),
        other => panic!("expected ShieldError::Blocked, got {other:?}"),
    }
}

#[test]
fn mcp_case_is_documented_as_intentional_asymmetry() {
    let case = load_fixture()
        .cases
        .into_iter()
        .find(|c| c.name == "mcp_blocked_raise")
        .expect("mcp case");
    assert_eq!(case.expected.rust, "n/a");
}
