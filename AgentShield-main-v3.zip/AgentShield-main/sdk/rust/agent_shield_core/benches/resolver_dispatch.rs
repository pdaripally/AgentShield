//! Criterion benchmark: synchronous resolver dispatch.
//!
//! Drives [`agent_shield_core::shield_primitives::dispatch_tool_verdict`]
//! across a handful of (verdict, stage, policy, mode) shapes to pin
//! the latency budget of the Stage 3 admit / Stage 4 post-validation
//! verdict-dispatch hot paths. No I/O.

use agent_shield_core::guard_policy_runtime::StageVerdict;
use agent_shield_core::shield_primitives::{
    dispatch_tool_verdict, OnBlockPolicy, ShieldMode, ToolStage,
};
use criterion::{black_box, criterion_group, criterion_main, Criterion};

fn allow_verdict() -> StageVerdict {
    StageVerdict::allow()
}

fn block_verdict() -> StageVerdict {
    StageVerdict::block("require_approval", "send_email blocked", Some(0))
}

fn bench_tool_allow_call(c: &mut Criterion) {
    let v = allow_verdict();
    c.bench_function("dispatch_tool_verdict allow (Stage 3 call)", |b| {
        b.iter(|| {
            let _ = black_box(dispatch_tool_verdict(
                &v,
                "send_email",
                ToolStage::Call,
                OnBlockPolicy::ReturnBlocked,
                ShieldMode::Enforce,
            ));
        });
    });
}

fn bench_tool_block_call(c: &mut Criterion) {
    let v = block_verdict();
    c.bench_function("dispatch_tool_verdict block (Stage 3 call)", |b| {
        b.iter(|| {
            let _ = black_box(dispatch_tool_verdict(
                &v,
                "send_email",
                ToolStage::Call,
                OnBlockPolicy::ReturnBlocked,
                ShieldMode::Enforce,
            ));
        });
    });
}

fn bench_tool_block_output(c: &mut Criterion) {
    let v = block_verdict();
    c.bench_function("dispatch_tool_verdict block (Stage 4 output)", |b| {
        b.iter(|| {
            let _ = black_box(dispatch_tool_verdict(
                &v,
                "send_email",
                ToolStage::Output,
                OnBlockPolicy::ReturnBlocked,
                ShieldMode::Enforce,
            ));
        });
    });
}

criterion_group!(
    benches,
    bench_tool_allow_call,
    bench_tool_block_call,
    bench_tool_block_output
);
criterion_main!(benches);
