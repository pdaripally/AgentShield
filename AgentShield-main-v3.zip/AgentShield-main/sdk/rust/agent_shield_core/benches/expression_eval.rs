//! Criterion benchmark: expression-language evaluation.
//!
//! Runs a representative bag of guard-policy expressions through the
//! parser + evaluator under the default `Limits::max_expression_eval_steps`
//! budget. Hits arithmetic, boolean composition, string predicates,
//! list/quantifier macros, and dotted access. The
//! CI threshold is a 15% p95 regression failure.

use std::collections::HashMap;

use agent_shield_core::expressions::eval::{evaluate_with, EvalContext};
use agent_shield_core::expressions::parser::parse;
use criterion::{black_box, criterion_group, criterion_main, Criterion};

/// Representative expressions covering the parser/evaluator surface.
/// Order is stable so a per-expression regression is reproducible.
const EXPRS: &[&str] = &[
    // Arithmetic + comparison
    "x + y > 10",
    "x * y - z == 0",
    "x / 2 > 5",
    // Boolean composition
    "a and b or c",
    "not (a and b)",
    "(a or b) and not c",
    // String predicates
    "contains(name, 'admin')",
    "startswith(role, 'super_')",
    "regex.match('^[a-z]+$', name)",
    // List / quantifier
    "any(roles, r -> r == 'admin')",
    "all(scores, s -> s > 0)",
    "count_where(items, i -> i.flagged) > 0",
    // Dotted access + null fallback
    "user.profile.country == 'US'",
    "user.profile.country in ['US', 'CA', 'MX']",
    // Ternary
    "x > 0 ? x : -x",
    // Sugar
    "defined(x) and not denied(y)",
];

fn build_attrs() -> HashMap<String, serde_json::Value> {
    use serde_json::json;
    let mut m: HashMap<String, serde_json::Value> = HashMap::new();
    m.insert("x".into(), json!(42));
    m.insert("y".into(), json!(7));
    m.insert("z".into(), json!(294));
    m.insert("a".into(), json!(true));
    m.insert("b".into(), json!(false));
    m.insert("c".into(), json!(true));
    m.insert("name".into(), json!("admin_user"));
    m.insert("role".into(), json!("super_user"));
    m.insert("roles".into(), json!(["user", "admin", "viewer"]));
    m.insert("scores".into(), json!([1, 2, 3, 4, 5]));
    m.insert(
        "items".into(),
        json!([
            {"flagged": true},
            {"flagged": false},
            {"flagged": true}
        ]),
    );
    m.insert(
        "user".into(),
        json!({
            "profile": {"country": "US", "tier": "gold"},
            "id": 1234
        }),
    );
    m
}

fn bench_parse(c: &mut Criterion) {
    c.bench_function("expression_parse (16 reps)", |b| {
        b.iter(|| {
            for e in EXPRS {
                let _ = black_box(parse(e));
            }
        });
    });
}

fn bench_evaluate(c: &mut Criterion) {
    let attrs = build_attrs();
    c.bench_function("expression_evaluate (16 reps)", |b| {
        b.iter(|| {
            let ctx = EvalContext::from_attrs(&attrs);
            for e in EXPRS {
                let _ = black_box(evaluate_with(e, &ctx));
            }
        });
    });
}

criterion_group!(benches, bench_parse, bench_evaluate);
criterion_main!(benches);
