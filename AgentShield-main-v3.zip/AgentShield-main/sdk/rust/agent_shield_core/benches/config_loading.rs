//! Criterion benchmark: `.guardrails.yaml` config loading.
//!
//! Drives [`agent_shield_core::load_chain`] across every fixture under
//! `tests/fixtures/smoke/` so a regression to the loader's hot path
//! (extends-chain merge, schema validation, IFC compilation,
//! invariant checks) shows up here. The CI
//! threshold is a 15% p95 regression failure; the threshold itself is
//! enforced in the perf-logging CI infrastructure.

use std::path::{Path, PathBuf};

use agent_shield_core::load_chain;
use criterion::{black_box, criterion_group, criterion_main, Criterion};

fn fixtures_dir() -> PathBuf {
    // sdk/rust/agent_shield_core/benches/<this file>
    // → ascend four levels to repo root, then tests/fixtures/smoke/
    let here = Path::new(env!("CARGO_MANIFEST_DIR"));
    here.join("..")
        .join("..")
        .join("..")
        .join("tests")
        .join("fixtures")
        .join("smoke")
}

fn collect_fixtures() -> Vec<PathBuf> {
    let mut paths: Vec<PathBuf> = Vec::new();
    let dir = fixtures_dir();
    if !dir.is_dir() {
        return paths;
    }
    let mut stack = vec![dir];
    while let Some(d) = stack.pop() {
        let Ok(entries) = std::fs::read_dir(&d) else {
            continue;
        };
        for e in entries.flatten() {
            let p = e.path();
            if p.is_dir() {
                stack.push(p);
            } else if p.extension().and_then(|s| s.to_str()) == Some("yaml")
                && p.file_name()
                    .and_then(|s| s.to_str())
                    .map(|n| !n.starts_with('.'))
                    .unwrap_or(false)
            {
                paths.push(p);
            }
        }
    }
    paths.sort();
    paths
}

fn bench_load_chain(c: &mut Criterion) {
    let fixtures = collect_fixtures();
    if fixtures.is_empty() {
        return;
    }
    let n = fixtures.len();
    c.bench_function(&format!("load_chain ({n} fixtures)"), |b| {
        b.iter(|| {
            for p in &fixtures {
                // Ignore loader errors — some fixtures intentionally fail
                // to validate so the loader bench measures both happy and
                // sad paths uniformly.
                let _ = black_box(load_chain(p));
            }
        });
    });
}

criterion_group!(benches, bench_load_chain);
criterion_main!(benches);
