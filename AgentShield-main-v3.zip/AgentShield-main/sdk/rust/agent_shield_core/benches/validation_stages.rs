//! Criterion benchmark: validation-stage decision latencies.
//!
//! Pins the deterministic latency of the verdict-dispatch and
//! observability-emit hot paths that every stage hits. The CI
//! threshold is a 15% p95 regression failure.

use agent_shield_core::guard_policy_runtime::StageVerdict;
use agent_shield_core::observability::{
    EventType, ObservabilityDispatcher, Severity, ShieldLogEvent, TelemetryPolicy,
};
use agent_shield_core::shield_primitives::{dispatch_stage_verdict, OnBlockPolicy, ShieldMode};
use agent_shield_core::EventBus;
use criterion::{black_box, criterion_group, criterion_main, Criterion};

fn clean_allow_verdict() -> StageVerdict {
    StageVerdict::allow()
}

fn block_verdict() -> StageVerdict {
    StageVerdict::block("p1", "blocked by p1", Some(0))
}

fn bench_dispatch_stage_allow(c: &mut Criterion) {
    let v = clean_allow_verdict();
    c.bench_function("dispatch_stage_verdict allow", |b| {
        b.iter(|| {
            let _ = black_box(dispatch_stage_verdict(
                &v,
                OnBlockPolicy::ReturnBlocked,
                ShieldMode::Enforce,
            ));
        });
    });
}

fn bench_dispatch_stage_block(c: &mut Criterion) {
    let v = block_verdict();
    c.bench_function("dispatch_stage_verdict block", |b| {
        b.iter(|| {
            let _ = black_box(dispatch_stage_verdict(
                &v,
                OnBlockPolicy::ReturnBlocked,
                ShieldMode::Enforce,
            ));
        });
    });
}

fn bench_emit_log_event(c: &mut Criterion) {
    let bus = EventBus::new();
    let dispatcher = ObservabilityDispatcher::with_agent_id_mode_policy_and_cap(
        bus,
        "bench-agent",
        agent_shield_core::RuntimeMode::Active,
        TelemetryPolicy::fail_closed(),
        65536,
    );
    c.bench_function("dispatcher.emit (info, no provider)", |b| {
        b.iter(|| {
            let mut ev = ShieldLogEvent::new(EventType::Info, Severity::Info, "audit");
            ev.session_id = "sess-bench".into();
            ev.correlation_id = "corr-bench".into();
            ev.message = "stage 1 admitted".into();
            let _ = dispatcher.emit(black_box(ev));
        });
    });
}

criterion_group!(
    benches,
    bench_dispatch_stage_allow,
    bench_dispatch_stage_block,
    bench_emit_log_event
);
criterion_main!(benches);
