use std::fmt;

/// Position in the source expression for error reporting.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Span {
    pub start: usize,
    pub end: usize,
}

/// Token produced by the expression tokenizer.
#[derive(Debug, Clone, PartialEq)]
pub enum Token {
    // Literals
    Ident(String),
    Str(String),
    Number(f64),
    Bool(bool),
    Null,

    // Comparison operators
    Eq,  // ==
    Neq, // !=
    Lt,  // <
    Lte, // <=
    Gt,  // >
    Gte, // >=

    // Logical operators
    And,
    Or,
    Not,

    // Collection membership
    In,

    // Arithmetic
    Plus,
    Minus,
    Star,
    Slash,
    Percent, // %

    // Assignment
    ColonEq, // :=

    // Ternary punctuation
    Question, // ?
    Colon,    // :

    // Grouping / punctuation
    LParen,
    RParen,
    LBracket,
    RBracket,
    Comma,
    Dot,
    Semicolon, // ; (conjunction, same as and)
    At,        // @ (metadata namespace prefix, LANGUAGE.md §4.7)
    Arrow,     // -> (quantifier macro binding, LANGUAGE.md §5.8)
}

impl fmt::Display for Token {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Token::Ident(s) => write!(f, "{s}"),
            Token::Str(s) => write!(f, "'{s}'"),
            Token::Number(n) => write!(f, "{n}"),
            Token::Bool(b) => write!(f, "{b}"),
            Token::Null => write!(f, "null"),
            Token::Eq => write!(f, "=="),
            Token::Neq => write!(f, "!="),
            Token::Lt => write!(f, "<"),
            Token::Lte => write!(f, "<="),
            Token::Gt => write!(f, ">"),
            Token::Gte => write!(f, ">="),
            Token::And => write!(f, "and"),
            Token::Or => write!(f, "or"),
            Token::Not => write!(f, "not"),
            Token::In => write!(f, "in"),
            Token::Plus => write!(f, "+"),
            Token::Minus => write!(f, "-"),
            Token::Star => write!(f, "*"),
            Token::Slash => write!(f, "/"),
            Token::Percent => write!(f, "%"),
            Token::ColonEq => write!(f, ":="),
            Token::Question => write!(f, "?"),
            Token::Colon => write!(f, ":"),
            Token::LParen => write!(f, "("),
            Token::RParen => write!(f, ")"),
            Token::LBracket => write!(f, "["),
            Token::RBracket => write!(f, "]"),
            Token::Comma => write!(f, ","),
            Token::Dot => write!(f, "."),
            Token::Semicolon => write!(f, ";"),
            Token::At => write!(f, "@"),
            Token::Arrow => write!(f, "->"),
        }
    }
}

/// Error from the tokenizer with position information.
#[derive(Debug, Clone)]
pub struct TokenError {
    pub message: String,
    pub position: usize,
}

impl fmt::Display for TokenError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "at position {}: {}", self.position, self.message)
    }
}

impl std::error::Error for TokenError {}

/// Tokenize an expression string into a sequence of tokens.
pub fn tokenize(input: &str) -> Result<Vec<Token>, TokenError> {
    let chars: Vec<char> = input.chars().collect();
    let len = chars.len();
    let mut tokens = Vec::new();
    let mut pos = 0;

    while pos < len {
        let ch = chars[pos];

        // Skip whitespace
        if ch.is_ascii_whitespace() {
            pos += 1;
            continue;
        }

        // Two-character operators
        if pos + 1 < len {
            let two = format!("{}{}", ch, chars[pos + 1]);
            match two.as_str() {
                "==" => {
                    tokens.push(Token::Eq);
                    pos += 2;
                    continue;
                }
                "!=" => {
                    tokens.push(Token::Neq);
                    pos += 2;
                    continue;
                }
                "<=" => {
                    tokens.push(Token::Lte);
                    pos += 2;
                    continue;
                }
                ">=" => {
                    tokens.push(Token::Gte);
                    pos += 2;
                    continue;
                }
                ":=" => {
                    tokens.push(Token::ColonEq);
                    pos += 2;
                    continue;
                }
                "&&" => {
                    tokens.push(Token::And);
                    pos += 2;
                    continue;
                }
                "||" => {
                    tokens.push(Token::Or);
                    pos += 2;
                    continue;
                }
                "->" => {
                    // Arrow is the quantifier-macro binding operator
                    // (LANGUAGE.md §5.8). Only emitted when `-` is *immediately*
                    // followed by `>` with no intervening whitespace.
                    tokens.push(Token::Arrow);
                    pos += 2;
                    continue;
                }
                _ => {}
            }
        }

        // Single-character operators / punctuation
        match ch {
            '<' => {
                tokens.push(Token::Lt);
                pos += 1;
                continue;
            }
            '>' => {
                tokens.push(Token::Gt);
                pos += 1;
                continue;
            }
            '+' => {
                tokens.push(Token::Plus);
                pos += 1;
                continue;
            }
            '-' => {
                tokens.push(Token::Minus);
                pos += 1;
                continue;
            }
            '*' => {
                tokens.push(Token::Star);
                pos += 1;
                continue;
            }
            '/' => {
                tokens.push(Token::Slash);
                pos += 1;
                continue;
            }
            '%' => {
                tokens.push(Token::Percent);
                pos += 1;
                continue;
            }
            '(' => {
                tokens.push(Token::LParen);
                pos += 1;
                continue;
            }
            ')' => {
                tokens.push(Token::RParen);
                pos += 1;
                continue;
            }
            '[' => {
                tokens.push(Token::LBracket);
                pos += 1;
                continue;
            }
            ']' => {
                tokens.push(Token::RBracket);
                pos += 1;
                continue;
            }
            ',' => {
                tokens.push(Token::Comma);
                pos += 1;
                continue;
            }
            '.' => {
                tokens.push(Token::Dot);
                pos += 1;
                continue;
            }
            ';' => {
                tokens.push(Token::Semicolon);
                pos += 1;
                continue;
            }
            '?' => {
                tokens.push(Token::Question);
                pos += 1;
                continue;
            }
            ':' => {
                tokens.push(Token::Colon);
                pos += 1;
                continue;
            }
            '!' => {
                tokens.push(Token::Not);
                pos += 1;
                continue;
            }
            '@' => {
                tokens.push(Token::At);
                pos += 1;
                continue;
            }
            _ => {}
        }

        // String literals (single or double quotes)
        if ch == '\'' || ch == '"' {
            let quote = ch;
            let start = pos;
            let is_raw = quote == '\''; // single-quoted strings are raw literals
            pos += 1;
            let mut s = String::new();
            let mut found_end = false;
            while pos < len {
                if chars[pos] == '\\' && !is_raw {
                    // Escape sequences in double-quoted strings only
                    if pos + 1 >= len {
                        return Err(TokenError {
                            message: "unterminated escape sequence at end of string".into(),
                            position: pos,
                        });
                    }
                    let esc = chars[pos + 1];
                    match esc {
                        '\\' => {
                            s.push('\\');
                            pos += 2;
                        }
                        '"' => {
                            s.push('"');
                            pos += 2;
                        }
                        '0' => {
                            s.push('\0');
                            pos += 2;
                        }
                        'n' => {
                            s.push('\n');
                            pos += 2;
                        }
                        't' => {
                            s.push('\t');
                            pos += 2;
                        }
                        'r' => {
                            s.push('\r');
                            pos += 2;
                        }
                        'x' | 'X' => {
                            // \xHH — two hex digits → code point U+0000–U+00FF
                            if pos + 3 >= len {
                                return Err(TokenError {
                                    message: "incomplete \\x escape: expected 2 hex digits".into(),
                                    position: pos,
                                });
                            }
                            let hex: String = chars[pos + 2..pos + 4].iter().collect();
                            let cp = u32::from_str_radix(&hex, 16).map_err(|_| TokenError {
                                message: format!("invalid hex escape \\x{hex}"),
                                position: pos,
                            })?;
                            let c = char::from_u32(cp).ok_or_else(|| TokenError {
                                message: format!("invalid code point in \\x{hex}"),
                                position: pos,
                            })?;
                            s.push(c);
                            pos += 4;
                        }
                        'u' => {
                            // \uHHHH — four hex digits → BMP code point
                            if pos + 5 >= len {
                                return Err(TokenError {
                                    message: "incomplete \\u escape: expected 4 hex digits".into(),
                                    position: pos,
                                });
                            }
                            let hex: String = chars[pos + 2..pos + 6].iter().collect();
                            let cp = u32::from_str_radix(&hex, 16).map_err(|_| TokenError {
                                message: format!("invalid hex escape \\u{hex}"),
                                position: pos,
                            })?;
                            // Reject UTF-16 surrogates (U+D800–U+DFFF)
                            if (0xD800..=0xDFFF).contains(&cp) {
                                return Err(TokenError {
                                    message: format!("surrogate code point U+{cp:04X} is not allowed in \\u escape"),
                                    position: pos,
                                });
                            }
                            let c = char::from_u32(cp).ok_or_else(|| TokenError {
                                message: format!("invalid code point U+{cp:04X} in \\u escape"),
                                position: pos,
                            })?;
                            s.push(c);
                            pos += 6;
                        }
                        'U' => {
                            // \UHHHHHHHH — eight hex digits → any Unicode code point
                            if pos + 9 >= len {
                                return Err(TokenError {
                                    message: "incomplete \\U escape: expected 8 hex digits".into(),
                                    position: pos,
                                });
                            }
                            let hex: String = chars[pos + 2..pos + 10].iter().collect();
                            let cp = u32::from_str_radix(&hex, 16).map_err(|_| TokenError {
                                message: format!("invalid hex escape \\U{hex}"),
                                position: pos,
                            })?;
                            // Reject UTF-16 surrogates (U+D800–U+DFFF)
                            if (0xD800..=0xDFFF).contains(&cp) {
                                return Err(TokenError {
                                    message: format!("surrogate code point U+{cp:04X} is not allowed in \\U escape"),
                                    position: pos,
                                });
                            }
                            let c = char::from_u32(cp).ok_or_else(|| TokenError {
                                message: format!("invalid code point U+{cp:08X} in \\U escape"),
                                position: pos,
                            })?;
                            s.push(c);
                            pos += 10;
                        }
                        _ => {
                            // Fail-closed: reject unknown escape sequences
                            return Err(TokenError {
                                message: format!("invalid escape sequence '\\{esc}'"),
                                position: pos,
                            });
                        }
                    }
                } else if chars[pos] == '\\' && is_raw && pos + 1 < len && chars[pos + 1] == quote {
                    // In raw (single-quoted) strings, only allow escaping the quote itself
                    s.push(quote);
                    pos += 2;
                } else if chars[pos] == quote {
                    found_end = true;
                    pos += 1;
                    break;
                } else {
                    s.push(chars[pos]);
                    pos += 1;
                }
            }
            if !found_end {
                return Err(TokenError {
                    message: format!("unterminated string starting with {quote}"),
                    position: start,
                });
            }
            tokens.push(Token::Str(s));
            continue;
        }

        // Numbers (integers and floats)
        if ch.is_ascii_digit() {
            let start = pos;
            while pos < len && (chars[pos].is_ascii_digit() || chars[pos] == '.') {
                pos += 1;
            }
            let num_str: String = chars[start..pos].iter().collect();
            let n: f64 = num_str.parse().map_err(|_| TokenError {
                message: format!("invalid number '{num_str}'"),
                position: start,
            })?;
            tokens.push(Token::Number(n));
            continue;
        }

        // Identifiers and keywords
        if ch.is_ascii_alphabetic() || ch == '_' {
            let start = pos;
            while pos < len && (chars[pos].is_ascii_alphanumeric() || chars[pos] == '_') {
                pos += 1;
            }
            let word: String = chars[start..pos].iter().collect();
            // Keywords are lowercase-only (Rego-aligned)
            let token = match word.as_str() {
                "and" => Token::And,
                "or" => Token::Or,
                "not" => Token::Not,
                "in" => Token::In,
                "null" => Token::Null,
                "true" => Token::Bool(true),
                "false" => Token::Bool(false),
                _ => Token::Ident(word),
            };
            tokens.push(token);
            continue;
        }

        return Err(TokenError {
            message: format!("unexpected character '{ch}'"),
            position: pos,
        });
    }

    Ok(tokens)
}

#[cfg(test)]
mod tests {
    use super::*;

    // ── Happy path: operator variety ──────────────────────────────

    #[test]
    fn test_simple_equality() {
        let tokens = tokenize("admin == true").unwrap();
        assert_eq!(
            tokens,
            vec![Token::Ident("admin".into()), Token::Eq, Token::Bool(true)]
        );
    }

    #[test]
    fn test_compound_expression() {
        let tokens = tokenize("age >= 18 and role in ['admin', 'mod']").unwrap();
        assert_eq!(
            tokens,
            vec![
                Token::Ident("age".into()),
                Token::Gte,
                Token::Number(18.0),
                Token::And,
                Token::Ident("role".into()),
                Token::In,
                Token::LBracket,
                Token::Str("admin".into()),
                Token::Comma,
                Token::Str("mod".into()),
                Token::RBracket,
            ]
        );
    }

    #[test]
    fn test_dotted_function_call() {
        let tokens = tokenize("time.now()").unwrap();
        assert_eq!(
            tokens,
            vec![
                Token::Ident("time".into()),
                Token::Dot,
                Token::Ident("now".into()),
                Token::LParen,
                Token::RParen,
            ]
        );
    }

    #[test]
    fn test_dotted_access_with_function() {
        let tokens = tokenize("time.now().hour").unwrap();
        assert_eq!(
            tokens,
            vec![
                Token::Ident("time".into()),
                Token::Dot,
                Token::Ident("now".into()),
                Token::LParen,
                Token::RParen,
                Token::Dot,
                Token::Ident("hour".into()),
            ]
        );
    }

    #[test]
    fn test_function_call_contains() {
        assert_eq!(
            tokenize("contains(name, 'test')").unwrap(),
            vec![
                Token::Ident("contains".into()),
                Token::LParen,
                Token::Ident("name".into()),
                Token::Comma,
                Token::Str("test".into()),
                Token::RParen,
            ]
        );
    }

    #[test]
    fn test_regex_match_function() {
        // Single-quoted strings are raw: \d+ in expression text stays as \d+
        assert_eq!(
            tokenize("regex.match('\\d+', data)").unwrap(),
            vec![
                Token::Ident("regex".into()),
                Token::Dot,
                Token::Ident("match".into()),
                Token::LParen,
                Token::Str("\\d+".into()),
                Token::Comma,
                Token::Ident("data".into()),
                Token::RParen,
            ]
        );
    }

    #[test]
    fn test_null_comparison() {
        assert_eq!(
            tokenize("x == null").unwrap(),
            vec![Token::Ident("x".into()), Token::Eq, Token::Null]
        );
    }

    #[test]
    fn test_is_null_function() {
        assert_eq!(
            tokenize("is_null(x)").unwrap(),
            vec![
                Token::Ident("is_null".into()),
                Token::LParen,
                Token::Ident("x".into()),
                Token::RParen,
            ]
        );
    }

    #[test]
    fn test_not_in() {
        assert_eq!(
            tokenize("not role in ['guest']").unwrap(),
            vec![
                Token::Not,
                Token::Ident("role".into()),
                Token::In,
                Token::LBracket,
                Token::Str("guest".into()),
                Token::RBracket,
            ]
        );
    }

    #[test]
    fn test_semicolon_conjunction() {
        assert_eq!(
            tokenize("a > 5; b < 10").unwrap(),
            vec![
                Token::Ident("a".into()),
                Token::Gt,
                Token::Number(5.0),
                Token::Semicolon,
                Token::Ident("b".into()),
                Token::Lt,
                Token::Number(10.0),
            ]
        );
    }

    #[test]
    fn test_percent_modulo() {
        assert_eq!(
            tokenize("x % 2 == 0").unwrap(),
            vec![
                Token::Ident("x".into()),
                Token::Percent,
                Token::Number(2.0),
                Token::Eq,
                Token::Number(0.0),
            ]
        );
    }

    #[test]
    fn test_colon_eq_assignment() {
        assert_eq!(
            tokenize("bal := account.balance").unwrap(),
            vec![
                Token::Ident("bal".into()),
                Token::ColonEq,
                Token::Ident("account".into()),
                Token::Dot,
                Token::Ident("balance".into()),
            ]
        );
    }

    #[test]
    fn test_double_ampersand_as_and() {
        let tokens = tokenize("a && b").unwrap();
        assert_eq!(
            tokens,
            vec![
                Token::Ident("a".into()),
                Token::And,
                Token::Ident("b".into())
            ]
        );
    }

    #[test]
    fn test_double_pipe_as_or() {
        let tokens = tokenize("a || b").unwrap();
        assert_eq!(
            tokens,
            vec![
                Token::Ident("a".into()),
                Token::Or,
                Token::Ident("b".into())
            ]
        );
    }

    #[test]
    fn test_bang_as_not() {
        let tokens = tokenize("!x").unwrap();
        assert_eq!(tokens, vec![Token::Not, Token::Ident("x".into())]);
    }

    #[test]
    fn test_bang_eq_still_works() {
        let tokens = tokenize("a != b").unwrap();
        assert_eq!(
            tokens,
            vec![
                Token::Ident("a".into()),
                Token::Neq,
                Token::Ident("b".into())
            ]
        );
    }

    #[test]
    fn test_ternary_tokens() {
        let tokens = tokenize("x ? 1 : 0").unwrap();
        assert_eq!(
            tokens,
            vec![
                Token::Ident("x".into()),
                Token::Question,
                Token::Number(1.0),
                Token::Colon,
                Token::Number(0.0),
            ]
        );
    }

    #[test]
    fn test_colon_eq_still_works() {
        let tokens = tokenize("x := 5").unwrap();
        assert_eq!(
            tokens,
            vec![Token::Ident("x".into()), Token::ColonEq, Token::Number(5.0)]
        );
    }

    #[test]
    fn test_mixed_symbolic_and_keyword_operators() {
        let tokens = tokenize("a && b || !c").unwrap();
        assert_eq!(
            tokens,
            vec![
                Token::Ident("a".into()),
                Token::And,
                Token::Ident("b".into()),
                Token::Or,
                Token::Not,
                Token::Ident("c".into()),
            ]
        );
    }

    // ── Numeric edge cases ────────────────────────────────────────

    #[test]
    fn test_negative_number() {
        // Unary minus is handled by parser, tokenizer sees Minus + Number
        assert_eq!(
            tokenize("-5").unwrap(),
            vec![Token::Minus, Token::Number(5.0)]
        );
    }

    #[test]
    fn test_float_number() {
        assert_eq!(
            tokenize("score >= 0.85").unwrap(),
            vec![
                Token::Ident("score".into()),
                Token::Gte,
                Token::Number(0.85),
            ]
        );
    }

    #[test]
    fn test_duration_function() {
        assert_eq!(
            tokenize("time.duration('30m')").unwrap(),
            vec![
                Token::Ident("time".into()),
                Token::Dot,
                Token::Ident("duration".into()),
                Token::LParen,
                Token::Str("30m".into()),
                Token::RParen,
            ]
        );
    }

    // ── Error cases ───────────────────────────────────────────────

    #[test]
    fn test_unterminated_string_single_quote() {
        let err = tokenize("name == 'hello").unwrap_err();
        assert!(err.message.contains("unterminated"));
        assert_eq!(err.position, 8); // position of opening quote
    }

    #[test]
    fn test_unterminated_string_double_quote() {
        let err = tokenize(r#"name == "hello"#).unwrap_err();
        assert!(err.message.contains("unterminated"));
    }

    #[test]
    fn test_empty_expression() {
        assert_eq!(tokenize("").unwrap(), vec![]);
    }

    #[test]
    fn test_whitespace_only() {
        assert_eq!(tokenize("   \t\n  ").unwrap(), vec![]);
    }

    #[test]
    fn test_unknown_character() {
        let err = tokenize("a § b").unwrap_err();
        assert!(err.message.contains('§'));
    }

    // ── Uppercase keywords are now identifiers (breaking change) ──

    #[test]
    fn test_uppercase_and_is_identifier() {
        let tokens = tokenize("AND").unwrap();
        assert_eq!(tokens, vec![Token::Ident("AND".into())]);
    }

    #[test]
    fn test_uppercase_not_is_identifier() {
        let tokens = tokenize("NOT").unwrap();
        assert_eq!(tokens, vec![Token::Ident("NOT".into())]);
    }

    // ── Real-world expressions from bank-manager YAML ─────────────

    #[test]
    fn test_bank_fraud_expression() {
        let tokens = tokenize("fraud_score >= 50").unwrap();
        assert_eq!(
            tokens,
            vec![
                Token::Ident("fraud_score".into()),
                Token::Gte,
                Token::Number(50.0),
            ]
        );
    }

    #[test]
    fn test_bank_compound_requires() {
        let tokens = tokenize(
            "fraud_score < 75 and transaction_velocity < 10 and geographic_anomaly == false",
        )
        .unwrap();
        assert_eq!(tokens.len(), 11);
        assert_eq!(tokens[0], Token::Ident("fraud_score".into()));
        assert_eq!(tokens[1], Token::Lt);
        assert_eq!(tokens[2], Token::Number(75.0));
        assert_eq!(tokens[3], Token::And);
        assert_eq!(tokens[4], Token::Ident("transaction_velocity".into()));
        assert_eq!(tokens[7], Token::And);
        assert_eq!(tokens[10], Token::Bool(false));
    }

    #[test]
    fn test_sensitivity_in_list() {
        let tokens = tokenize("account_sensitivity in ['vip', 'high_net_worth']").unwrap();
        assert_eq!(
            tokens,
            vec![
                Token::Ident("account_sensitivity".into()),
                Token::In,
                Token::LBracket,
                Token::Str("vip".into()),
                Token::Comma,
                Token::Str("high_net_worth".into()),
                Token::RBracket,
            ]
        );
    }

    // ── Escaped strings ───────────────────────────────────────────

    #[test]
    fn test_escaped_quote_in_string() {
        // Single-quoted raw string: only \' is recognized as escape
        let tokens = tokenize(r"name == 'it\'s'").unwrap();
        assert_eq!(tokens[2], Token::Str("it's".into()));
    }

    // ── Single-quoted raw strings (no escape processing) ──────────

    #[test]
    fn test_single_quote_raw_no_escape_n() {
        // \n in single-quoted string should be literal backslash + n
        let tokens = tokenize(r"'hello\nworld'").unwrap();
        assert_eq!(tokens[0], Token::Str(r"hello\nworld".into()));
    }

    #[test]
    fn test_single_quote_raw_no_escape_t() {
        let tokens = tokenize(r"'tab\there'").unwrap();
        assert_eq!(tokens[0], Token::Str(r"tab\there".into()));
    }

    #[test]
    fn test_single_quote_raw_backslash_preserved() {
        let tokens = tokenize(r"'C:\\docs\\file'").unwrap();
        assert_eq!(tokens[0], Token::Str(r"C:\\docs\\file".into()));
    }

    #[test]
    fn test_single_quote_raw_unknown_escape_preserved() {
        // \z is not valid, but in raw strings it's kept literally
        let tokens = tokenize(r"'foo\zbar'").unwrap();
        assert_eq!(tokens[0], Token::Str(r"foo\zbar".into()));
    }

    // ── Double-quoted string escape sequences ─────────────────────

    #[test]
    fn test_double_quote_escape_backslash() {
        let tokens = tokenize(r#""a\\b""#).unwrap();
        assert_eq!(tokens[0], Token::Str("a\\b".into()));
    }

    #[test]
    fn test_double_quote_escape_double_quote() {
        let tokens = tokenize(r#""say \"hello\"""#).unwrap();
        assert_eq!(tokens[0], Token::Str("say \"hello\"".into()));
    }

    #[test]
    fn test_double_quote_escape_null() {
        let tokens = tokenize(r#""null\0char""#).unwrap();
        assert_eq!(tokens[0], Token::Str("null\0char".into()));
    }

    #[test]
    fn test_double_quote_escape_newline() {
        let tokens = tokenize(r#""line1\nline2""#).unwrap();
        assert_eq!(tokens[0], Token::Str("line1\nline2".into()));
    }

    #[test]
    fn test_double_quote_escape_tab() {
        let tokens = tokenize(r#""col1\tcol2""#).unwrap();
        assert_eq!(tokens[0], Token::Str("col1\tcol2".into()));
    }

    #[test]
    fn test_double_quote_escape_carriage_return() {
        let tokens = tokenize(r#""dos\r\n""#).unwrap();
        assert_eq!(tokens[0], Token::Str("dos\r\n".into()));
    }

    // ── Hex escapes \xHH ──────────────────────────────────────────

    #[test]
    fn test_hex_escape_lowercase() {
        let tokens = tokenize(r#""\x41""#).unwrap(); // 'A'
        assert_eq!(tokens[0], Token::Str("A".into()));
    }

    #[test]
    fn test_hex_escape_uppercase_x() {
        let tokens = tokenize(r#""\X42""#).unwrap(); // 'B'
        assert_eq!(tokens[0], Token::Str("B".into()));
    }

    #[test]
    fn test_hex_escape_mixed_case_digits() {
        let tokens = tokenize(r#""\xfF""#).unwrap(); // U+00FF = 'ÿ'
        assert_eq!(tokens[0], Token::Str("\u{00FF}".into()));
    }

    #[test]
    fn test_hex_escape_null_byte() {
        let tokens = tokenize(r#""\x00""#).unwrap();
        assert_eq!(tokens[0], Token::Str("\0".into()));
    }

    #[test]
    fn test_hex_escape_incomplete() {
        let err = tokenize(r#""\x4""#).unwrap_err();
        assert!(err.message.contains("\\x"));
    }

    // ── Unicode escapes \uHHHH ────────────────────────────────────

    #[test]
    fn test_unicode_bmp_escape() {
        let tokens = tokenize(r#""\u00C9""#).unwrap(); // É
        assert_eq!(tokens[0], Token::Str("É".into()));
    }

    #[test]
    fn test_unicode_bmp_escape_lowercase() {
        let tokens = tokenize(r#""\u00e9""#).unwrap(); // é
        assert_eq!(tokens[0], Token::Str("é".into()));
    }

    #[test]
    fn test_unicode_bmp_escape_cjk() {
        let tokens = tokenize(r#""\u4e16""#).unwrap(); // 世
        assert_eq!(tokens[0], Token::Str("世".into()));
    }

    #[test]
    fn test_unicode_bmp_incomplete() {
        let err = tokenize(r#""\u00C""#).unwrap_err();
        assert!(err.message.contains("\\u"));
    }

    #[test]
    fn test_unicode_surrogate_rejected() {
        let err = tokenize(r#""\uD800""#).unwrap_err();
        assert!(err.message.contains("surrogate"));
    }

    #[test]
    fn test_unicode_surrogate_high_end_rejected() {
        let err = tokenize(r#""\uDFFF""#).unwrap_err();
        assert!(err.message.contains("surrogate"));
    }

    // ── Full Unicode escapes \UHHHHHHHH ───────────────────────────

    #[test]
    fn test_unicode_full_escape_emoji() {
        let tokens = tokenize(r#""\U0001F600""#).unwrap(); // 😀
        assert_eq!(tokens[0], Token::Str("😀".into()));
    }

    #[test]
    fn test_unicode_full_escape_bmp() {
        let tokens = tokenize(r#""\U000000C9""#).unwrap(); // É via 8-digit form
        assert_eq!(tokens[0], Token::Str("É".into()));
    }

    #[test]
    fn test_unicode_full_surrogate_rejected() {
        let err = tokenize(r#""\U0000D800""#).unwrap_err();
        assert!(err.message.contains("surrogate"));
    }

    #[test]
    fn test_unicode_full_out_of_range() {
        let err = tokenize(r#""\U00110000""#).unwrap_err();
        assert!(err.message.contains("invalid"));
    }

    #[test]
    fn test_unicode_full_incomplete() {
        let err = tokenize(r#""\U0001F60""#).unwrap_err();
        assert!(err.message.contains("\\U"));
    }

    // ── Invalid escape rejection (fail-closed) ────────────────────

    #[test]
    fn test_invalid_escape_z_rejected() {
        let err = tokenize(r#""\z""#).unwrap_err();
        assert!(err.message.contains("invalid escape"));
    }

    #[test]
    fn test_invalid_escape_s_rejected() {
        let err = tokenize(r#""\s""#).unwrap_err();
        assert!(err.message.contains("invalid escape"));
    }

    #[test]
    fn test_invalid_escape_a_rejected() {
        let err = tokenize(r#""\a""#).unwrap_err();
        assert!(err.message.contains("invalid escape"));
    }

    #[test]
    fn test_invalid_escape_single_quote_in_double() {
        // \' is not a valid escape in double-quoted strings
        let err = tokenize(r#""it\'s""#).unwrap_err();
        assert!(err.message.contains("invalid escape"));
    }

    // ── Combined / real-world scenarios ───────────────────────────

    #[test]
    fn test_mixed_escapes_in_double_quoted() {
        let tokens = tokenize(r#""line1\nline2\ttab\\end""#).unwrap();
        assert_eq!(tokens[0], Token::Str("line1\nline2\ttab\\end".into()));
    }

    #[test]
    fn test_regex_in_single_quote_preserved() {
        // Regex patterns in single-quoted strings pass through literally
        let tokens = tokenize(r"regex.match('^\d{3}-\d{2}-\d{4}$', ssn)").unwrap();
        assert_eq!(tokens[4], Token::Str(r"^\d{3}-\d{2}-\d{4}$".into()));
    }

    #[test]
    fn test_all_comparison_operators() {
        let tokens = tokenize("a == b != c < d <= e > f >= g").unwrap();
        let ops: Vec<&Token> = tokens
            .iter()
            .filter(|t| {
                matches!(
                    t,
                    Token::Eq | Token::Neq | Token::Lt | Token::Lte | Token::Gt | Token::Gte
                )
            })
            .collect();
        assert_eq!(
            ops,
            vec![
                &Token::Eq,
                &Token::Neq,
                &Token::Lt,
                &Token::Lte,
                &Token::Gt,
                &Token::Gte
            ]
        );
    }

    #[test]
    fn test_symbolic_and_keyword_operator_mix() {
        let tokens = tokenize("a && b or c").unwrap();
        assert_eq!(
            tokens,
            vec![
                Token::Ident("a".into()),
                Token::And,
                Token::Ident("b".into()),
                Token::Or,
                Token::Ident("c".into()),
            ]
        );
    }

    #[test]
    fn test_ternary_tokens_without_spaces() {
        let tokens = tokenize("x?1:0").unwrap();
        assert_eq!(
            tokens,
            vec![
                Token::Ident("x".into()),
                Token::Question,
                Token::Number(1.0),
                Token::Colon,
                Token::Number(0.0),
            ]
        );
    }
}
