/// AST nodes produced by the expression parser.
#[derive(Debug, Clone, PartialEq)]
pub enum Expr {
    /// A literal value: string, number, bool, or null.
    Literal(LitValue),

    /// A simple identifier: `role`, `fraud_score`.
    Ident(String),

    /// Dotted access: `user.role`, `account.owner.region`.
    DottedAccess { root: Box<Expr>, path: Vec<String> },

    /// Binary operation: `a and b`, `x > 5`, `a + b`.
    BinaryOp {
        op: BinOp,
        left: Box<Expr>,
        right: Box<Expr>,
    },

    /// Unary operation: `not x`, `-5`.
    UnaryOp { op: UnOp, operand: Box<Expr> },

    /// Function call: `time.now()`, `contains(a, b)`, `regex.match(p, s)`.
    FnCall { name: String, args: Vec<Expr> },

    /// Ternary conditional: `cond? then_expr: else_expr`.
    Ternary {
        condition: Box<Expr>,
        then_expr: Box<Expr>,
        else_expr: Box<Expr>,
    },

    /// List literal: `[1, 2, 3]`, `['admin', 'mod']`.
    List(Vec<Expr>),

    /// Index access: `arr[0]`, `map["key"]`.
    Index { object: Box<Expr>, index: Box<Expr> },

    /// Variable binding: `name:= expr`.
    Assignment { name: String, value: Box<Expr> },

    /// Quantifier macro: `all|any|count_where(coll, var -> pred)`.
    /// Per LANGUAGE.md the bound variable is scoped to the predicate only.
    Quantifier {
        kind: QuantifierKind,
        collection: Box<Expr>,
        var: String,
        predicate: Box<Expr>,
    },

    /// Variable metadata read: `var.@field`.
    /// Only valid on a bare variable identifier; the parser rejects
    /// `(expr).@field` at parse time. Reads MUST NOT trigger auto-resolution.
    MetaField { var: String, field: String },
}

/// Quantifier macro kinds.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum QuantifierKind {
    All,
    Any,
    CountWhere,
}

/// Literal values in expressions.
#[derive(Debug, Clone, PartialEq)]
pub enum LitValue {
    Str(String),
    Number(f64),
    Bool(bool),
    Null,
}

/// Binary operators, ordered by typical precedence grouping.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BinOp {
    // Logical (lowest precedence)
    Or,
    And,

    // Comparison
    Eq,
    Neq,
    Lt,
    Lte,
    Gt,
    Gte,

    // Collection membership
    In,

    // Arithmetic (highest precedence among binary)
    Add,
    Sub,
    Mul,
    Div,
    Mod,
}

/// Unary operators.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum UnOp {
    Not,
    Neg,
}

impl Expr {
    /// Recursively count AST nodes (used by,
    /// `Limits::max_expression_ast_nodes` enforcement at parse time).
    /// Counts every variant — literals, identifiers, binary/unary
    /// ops, function calls, ternaries, list elements, quantifier
    /// bodies, etc — as 1 plus the sum of its children.
    pub fn count_nodes(&self) -> usize {
        match self {
            Expr::Literal(_) | Expr::Ident(_) | Expr::MetaField { .. } => 1,
            Expr::DottedAccess { root, .. } => 1 + root.count_nodes(),
            Expr::BinaryOp { left, right, .. } => 1 + left.count_nodes() + right.count_nodes(),
            Expr::UnaryOp { operand, .. } => 1 + operand.count_nodes(),
            Expr::FnCall { args, .. } => 1 + args.iter().map(|a| a.count_nodes()).sum::<usize>(),
            Expr::Ternary {
                condition,
                then_expr,
                else_expr,
            } => 1 + condition.count_nodes() + then_expr.count_nodes() + else_expr.count_nodes(),
            Expr::List(items) => 1 + items.iter().map(|i| i.count_nodes()).sum::<usize>(),
            Expr::Index { object, index } => 1 + object.count_nodes() + index.count_nodes(),
            Expr::Assignment { value, .. } => 1 + value.count_nodes(),
            Expr::Quantifier {
                collection,
                predicate,
                ..
            } => 1 + collection.count_nodes() + predicate.count_nodes(),
        }
    }
}
