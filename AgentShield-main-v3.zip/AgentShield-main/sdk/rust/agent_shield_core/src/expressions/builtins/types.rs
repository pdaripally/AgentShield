//! Type-introspection and conversion builtins (LANGUAGE.md §5.2, §5.3, §5.6).
//!
//! `is_string`, `is_number`, `is_boolean`, `is_null`, `is_array`,
//! `is_object`, `is_datetime`, `is_duration`, `is_integer`, `is_enum`,
//! `has`, `integer`, `number`, `string`, `boolean`, `type_name`,
//! `coalesce`.

use std::collections::HashMap;

use super::super::ast::Expr;
use super::super::eval::{eval_expr, EvalContext, EvalResult};

pub(super) fn try_dispatch(
    name: &str,
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> Option<EvalResult> {
    let r = match name {
        "coalesce" => coalesce(args, ctx, bindings),
        "is_string" => is_string(args, ctx, bindings),
        "is_number" => is_number(args, ctx, bindings),
        "is_boolean" => is_boolean(args, ctx, bindings),
        "is_null" => is_null(args, ctx, bindings),
        "is_array" => is_array(args, ctx, bindings),
        "is_object" => is_object(args, ctx, bindings),
        "is_datetime" => is_datetime(args, ctx, bindings),
        "is_duration" => is_duration(args, ctx, bindings),
        "is_integer" => is_integer(args, ctx, bindings),
        "is_enum" => is_enum(args, ctx, bindings),
        "has" => has(args, ctx, bindings),
        "integer" => integer(args, ctx, bindings),
        "number" => number(args, ctx, bindings),
        "string" => string(args, ctx, bindings),
        "boolean" => boolean(args, ctx, bindings),
        "type_name" => type_name(args, ctx, bindings),
        _ => return None,
    };
    Some(r)
}

fn coalesce(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() < 2 {
        return EvalResult::Null;
    }
    for arg in args {
        let val = eval_expr(arg, ctx, bindings);
        if !val.is_null() {
            return val;
        }
    }
    EvalResult::Null
}

fn is_string(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Bool(false);
    }
    let a = eval_expr(&args[0], ctx, bindings);
    EvalResult::Bool(matches!(a, EvalResult::Str(_)))
}

fn is_number(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Bool(false);
    }
    let a = eval_expr(&args[0], ctx, bindings);
    EvalResult::Bool(matches!(a, EvalResult::Number(_)))
}

fn is_boolean(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Bool(false);
    }
    let a = eval_expr(&args[0], ctx, bindings);
    EvalResult::Bool(matches!(a, EvalResult::Bool(_)))
}

fn is_null(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Bool(false);
    }
    let a = eval_expr(&args[0], ctx, bindings);
    EvalResult::Bool(a.is_null())
}

fn is_array(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Bool(false);
    }
    let a = eval_expr(&args[0], ctx, bindings);
    EvalResult::Bool(matches!(a, EvalResult::List(_)))
}

fn is_object(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Bool(false);
    }
    let a = eval_expr(&args[0], ctx, bindings);
    EvalResult::Bool(matches!(a, EvalResult::Map(_)))
}

fn is_datetime(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Bool(false);
    }
    let a = eval_expr(&args[0], ctx, bindings);
    EvalResult::Bool(matches!(a, EvalResult::DateTime(_)))
}

fn is_duration(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Bool(false);
    }
    let a = eval_expr(&args[0], ctx, bindings);
    EvalResult::Bool(matches!(a, EvalResult::Duration(_)))
}

fn is_integer(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Bool(false);
    }
    let a = eval_expr(&args[0], ctx, bindings);
    match a {
        EvalResult::Number(n) => EvalResult::Bool(n.is_finite() && n.fract() == 0.0),
        _ => EvalResult::Bool(false),
    }
}

fn is_enum(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    // §7.4 / LANGUAGE.md §5.2 — true only for values stored under
    // an `enum`-typed variable. The evaluator does not currently
    // carry an enum-tag at runtime; it is a stub that always
    // returns false until §10 enum support lands. Type-inspection
    // contract: never null, always boolean.
    if args.len() != 1 {
        return EvalResult::Bool(false);
    }
    let _ = eval_expr(&args[0], ctx, bindings);
    EvalResult::Bool(false)
}

fn has(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 2 {
        return EvalResult::Bool(false);
    }
    let obj = eval_expr(&args[0], ctx, bindings);
    let key = eval_expr(&args[1], ctx, bindings);
    match (&obj, key.as_str()) {
        (EvalResult::Map(map), Some(k)) => EvalResult::Bool(map.contains_key(k)),
        _ => EvalResult::Bool(false),
    }
}

fn integer(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    let a = eval_expr(&args[0], ctx, bindings);
    match a {
        EvalResult::Number(n) => EvalResult::Number(n.trunc()),
        EvalResult::Str(s) => {
            // Only accept decimal integer strings, not floats
            match s.parse::<i64>() {
                Ok(n) => EvalResult::Number(n as f64),
                Err(_) => EvalResult::Null,
            }
        }
        EvalResult::Bool(b) => EvalResult::Number(if b { 1.0 } else { 0.0 }),
        _ => EvalResult::Null,
    }
}

fn number(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    let a = eval_expr(&args[0], ctx, bindings);
    match a {
        EvalResult::Number(n) => EvalResult::Number(n),
        EvalResult::Str(s) => match s.parse::<f64>() {
            Ok(n) => EvalResult::Number(n),
            Err(_) => EvalResult::Null,
        },
        EvalResult::Bool(b) => EvalResult::Number(if b { 1.0 } else { 0.0 }),
        _ => EvalResult::Null,
    }
}

fn string(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    let a = eval_expr(&args[0], ctx, bindings);
    match a {
        EvalResult::Str(s) => EvalResult::Str(s),
        EvalResult::Number(n) => {
            if n.is_finite() && n.fract() == 0.0 && n.abs() < (i64::MAX as f64) {
                EvalResult::Str(format!("{}", n as i64))
            } else {
                EvalResult::Str(format!("{n}"))
            }
        }
        EvalResult::Bool(b) => EvalResult::Str(format!("{b}")),
        EvalResult::DateTime(dt) => {
            EvalResult::Str(dt.to_rfc3339_opts(chrono::SecondsFormat::Secs, true))
        }
        EvalResult::Duration(d) => {
            let secs = d.num_seconds();
            if secs % 86400 == 0 && secs != 0 {
                EvalResult::Str(format!("{}d", secs / 86400))
            } else if secs % 3600 == 0 && secs != 0 {
                EvalResult::Str(format!("{}h", secs / 3600))
            } else if secs % 60 == 0 && secs != 0 {
                EvalResult::Str(format!("{}m", secs / 60))
            } else {
                EvalResult::Str(format!("{}s", secs))
            }
        }
        EvalResult::Null => EvalResult::Null,
        _ => EvalResult::Null,
    }
}

fn boolean(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    let a = eval_expr(&args[0], ctx, bindings);
    match a {
        EvalResult::Bool(b) => EvalResult::Bool(b),
        EvalResult::Str(s) => match s.as_str() {
            "true" => EvalResult::Bool(true),
            "false" => EvalResult::Bool(false),
            _ => EvalResult::Null,
        },
        _ => EvalResult::Null,
    }
}

fn type_name(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    let a = eval_expr(&args[0], ctx, bindings);
    let name = match a {
        EvalResult::Str(_) => "string",
        EvalResult::Number(_) => "number",
        EvalResult::Bool(_) => "boolean",
        EvalResult::List(_) => "array",
        EvalResult::Map(_) => "object",
        EvalResult::Null => "null",
        EvalResult::DateTime(_) => "datetime",
        EvalResult::Duration(_) => "duration",
    };
    EvalResult::Str(name.to_string())
}
