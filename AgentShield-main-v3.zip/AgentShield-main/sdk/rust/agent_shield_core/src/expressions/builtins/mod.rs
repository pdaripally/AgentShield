//! Builtin-function dispatcher for the expression language.
//!
//! This module hosts the giant `match name {... }` that previously lived
//! inline in [`super::eval::eval_function`]. The dispatch is split into
//! per-family submodules (`strings`, `regex`, `time`, `types`,
//! `collections`, `objects`, `math`); each module owns its own arms and
//! exposes a `try_dispatch` returning `Option<EvalResult>` for the names
//! it recognises. The top-level [`eval_function`] walks the family
//! dispatchers in declaration order, then falls back to the runtime-bound
//! `@event.fired` arm, the `defined/unset/denied/present` status sugar,
//! finally the host-extension registry.
//!
//! Behavior is byte-identical to the previous monolithic implementation;
//! this module is a pure mechanical relocation.

use std::collections::HashMap;

use super::ast::{Expr, LitValue};
use super::eval::{eval_expr, EvalContext, EvalResult, VariableStatus};
use super::extensions;

mod collections;
mod math;
mod objects;
mod strings;
mod time;
mod types;

/// Dispatch a function call. The dispatcher is exhaustive over the
/// builtin registry; unknown names fall through to the host extension
/// table ([`super::extensions::eval_extension`]) and ultimately to
/// `EvalResult::Null`.
pub(super) fn eval_function(
    name: &str,
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if let Some(r) = time::try_dispatch(name, args, ctx, bindings) {
        return r;
    }
    if let Some(r) = strings::try_dispatch(name, args, ctx, bindings) {
        return r;
    }
    if let Some(r) = types::try_dispatch(name, args, ctx, bindings) {
        return r;
    }
    if let Some(r) = collections::try_dispatch(name, args, ctx, bindings) {
        return r;
    }
    if let Some(r) = objects::try_dispatch(name, args, ctx, bindings) {
        return r;
    }
    if let Some(r) = math::try_dispatch(name, args, ctx, bindings) {
        return r;
    }

    match name {
        // ── Event observation ────────────────
        // Spec / LANGUAGE.md: the event predicate is runtime-
        // bound and accessed through the `@event.*` metadata namespace.
        "@event.fired" => eval_event_fired(args, ctx),

        // ── Variable status sugar ───────────
        "defined" | "unset" | "denied" | "present" => {
            EvalResult::Bool(eval_var_status(name, args, ctx))
        }

        // ── Legacy compat: uppercase NOW/DURATION still work as identifiers
        // but should be called as time.now() / time.duration() now
        _ => {
            let evaluated_args: Vec<EvalResult> = args
                .iter()
                .map(|arg| eval_expr(arg, ctx, bindings))
                .collect();
            match extensions::eval_extension(name, &evaluated_args) {
                Some(result) => result,
                None => EvalResult::Null,
            }
        }
    }
}

/// Closed registry of every function name the evaluator's
/// `eval_function` dispatcher can recognise. Includes the core
/// standard library (`time.*`, `strings`, `types`, `collections`,
/// `objects`, `math` families), runtime-bound helpers
/// (`@event.fired`), variable-status sugar
/// (`defined`, `unset`, `denied`, `present`), and the host extension
/// table from [`super::extensions::eval_extension`].
///
/// Note: `all`, `any`, and `count_where` are NOT in this list — they
/// are quantifier syntax (parsed to `Expr::Quantifier`), not
/// function calls.
///
/// Used by the loader to reject `Expr::FnCall { name,.. }` whose
/// `name` is not a known built-in. Without this check, a typo like
/// `time.parse(...)` silently falls through to `EvalResult::Null` at
/// runtime — turning a misconfigured gate into a silent false-deny.
pub(crate) fn is_known_builtin(name: &str) -> bool {
    matches!(
        name,
        // ── Time ──
        "time.now"
            | "time.duration"
            | "time.weekday"
            | "time.clock"
            // ── Strings / regex match ──
            | "contains"
            | "startswith"
            | "endswith"
            | "regex.match"
            | "lower"
            | "upper"
            // ── Types & conversion ──
            | "coalesce"
            | "is_string"
            | "is_number"
            | "is_boolean"
            | "is_null"
            | "is_array"
            | "is_object"
            | "is_datetime"
            | "is_duration"
            | "is_integer"
            | "is_enum"
            | "has"
            | "integer"
            | "number"
            | "string"
            | "boolean"
            | "type_name"
            // ── Collections ──
            | "count"
            | "sum"
            | "max"
            | "min"
            | "union"
            | "intersect"
            | "subset"
            | "superset"
            // ── Objects ──
            | "object.get"
            | "object.keys"
            | "object.values"
            | "object.entries"
            | "object.merge_patch"
            // ── Math ──
            | "abs"
            | "round"
            | "ceil"
            | "floor"
            // ── Event observation ──
            | "@event.fired"
            // ── Variable-status sugar ──
            | "defined"
            | "unset"
            | "denied"
            | "present"
            // ── Host extensions (extensions.rs) ──
            | "charAt"
            | "indexOf"
            | "lastIndexOf"
            | "join"
            | "split"
            | "substring"
            | "trim"
            | "replace"
            | "reverse_string"
            | "quote"
            | "format"
            | "sort"
            | "distinct"
            | "flatten"
            | "slice"
            | "reverse_list"
            | "range"
            | "regex.replace"
            | "regex.extract"
            | "regex.extract_all"
            | "parse_json"
            | "to_json"
            | "uri.scheme"
            | "uri.host"
            | "uri.port"
            | "uri.path"
            | "uri.query"
    )
}

// ═══════════════════════════════════════════════════════════════
// `@event.fired(<event_id>)` (LANGUAGE.md /)
// ═══════════════════════════════════════════════════════════════
/// `@event.fired(<id>)` accepts a string-literal event id only. Expression
/// args are rejected at evaluation. The event id is validated against the
/// closed namespace via [`crate::events::EventId::parse`]; an
/// out-of-namespace id emits a structured warning and returns `false`. With
/// no [`super::eval::EventFiredHook`] registered, returns `false`
/// (fail-closed).
fn eval_event_fired(args: &[Expr], ctx: &EvalContext<'_>) -> EvalResult {
    if args.len() != 1 {
        log::warn!(
            target: "agent_shield::expressions",
            "@event.fired() expects exactly one string-literal argument; got {} args",
            args.len()
        );
        return EvalResult::Bool(false);
    }
    let event_id: &str = match &args[0] {
        Expr::Literal(LitValue::Str(s)) => s.as_str(),
        _ => {
            log::warn!(
                target: "agent_shield::expressions",
                "@event.fired() requires a string-literal argument; expression args are rejected"
            );
            return EvalResult::Bool(false);
        }
    };
    if let Err(e) = crate::events::EventId::parse(event_id) {
        log::warn!(
            target: "agent_shield::expressions",
            "@event.fired('{}') is outside the closed event namespace: {}",
            event_id,
            e
        );
        return EvalResult::Bool(false);
    }
    let fired = ctx.event_fired.map(|h| h.fired(event_id)).unwrap_or(false);
    EvalResult::Bool(fired)
}

// ═══════════════════════════════════════════════════════════════
// Variable-status sugar functions
// ═══════════════════════════════════════════════════════════════
/// Evaluate `defined(x)` / `unset(x)` / `denied(x)` / `present(x)`.
///
/// The argument MUST be a bare variable identifier.
/// Anything else evaluates to `false` (fail-closed). With a registered
/// [`super::eval::StatusLookup`] hook, status is read via
/// `sl.status(var)`. Without a hook, the value is inspected directly:
///
///   - `defined(x)` ≈ attr present and non-null
///   - `unset(x)` ≈ attr missing or null
///   - `denied(x)` ≈ false (no value-based way to know)
///   - `present(x)` ≈ defined(x) AND value not in {"", [], {}}
///
/// All four MUST always return a boolean.
/// Reading status MUST NOT trigger auto-resolution.
fn eval_var_status(fn_name: &str, args: &[Expr], ctx: &EvalContext<'_>) -> bool {
    if args.len() != 1 {
        log::warn!(
            target: "agent_shield::expressions",
            "{}() expects exactly one argument (a bare variable identifier)",
            fn_name
        );
        return false;
    }
    let var = match &args[0] {
        Expr::Ident(name) => name,
        _ => {
            log::warn!(
                target: "agent_shield::expressions",
                "{}() requires a bare variable identifier; arbitrary expressions are rejected",
                fn_name
            );
            return false;
        }
    };

    // Status-lookup hook path (runtime).
    if let Some(sl) = ctx.status_lookup {
        // P2.6 / LANGUAGE.md: undeclared variables return `false`
        // for all four sugar functions, never `true` for `unset`.
        if !sl.is_declared(var) {
            return false;
        }
        let status = sl.status(var).unwrap_or(VariableStatus::Unset);
        return match fn_name {
            "defined" => matches!(status, VariableStatus::Resolved),
            "unset" => matches!(status, VariableStatus::Unset),
            "denied" => matches!(status, VariableStatus::Denied),
            "present" => {
                if !matches!(status, VariableStatus::Resolved) {
                    return false;
                }
                match ctx.attrs.get(var) {
                    Some(v) => !v.is_null(),
                    None => false,
                }
            }
            _ => false,
        };
    }

    // Transitional value-based heuristic when no hook is registered.
    // The host runtime registers a StatusLookup hook so this branch
    // is not taken at gating sites; tests and direct evaluator use
    // without a tracker fall through here.
    let val = ctx.attrs.get(var);
    let is_null = val.map(|v| v.is_null()).unwrap_or(true);
    match fn_name {
        "defined" => !is_null,
        "unset" => is_null,
        "denied" => false,
        "present" => match val {
            None => false,
            Some(serde_json::Value::Null) => false,
            Some(serde_json::Value::String(s)) => !s.is_empty(),
            Some(serde_json::Value::Array(a)) => !a.is_empty(),
            Some(serde_json::Value::Object(o)) => !o.is_empty(),
            Some(_) => true,
        },
        _ => false,
    }
}
