//! String and regex builtin functions (LANGUAGE.md §5.4 / §5.5).
//!
//! `contains`, `startswith`, `endswith`, `regex.match`, `lower`, `upper`.
//! Behavior is byte-identical to the previous inline implementation in
//! `eval.rs`; this module only relocates the dispatch arms.

use std::collections::HashMap;

use regex::Regex;

use super::super::ast::Expr;
use super::super::eval::{eval_expr, EvalContext, EvalResult};
use crate::constants::expressions::MAX_REGEX_LENGTH;

pub(super) fn try_dispatch(
    name: &str,
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> Option<EvalResult> {
    let r = match name {
        "contains" => contains(args, ctx, bindings),
        "startswith" => startswith(args, ctx, bindings),
        "endswith" => endswith(args, ctx, bindings),
        "regex.match" => regex_match(args, ctx, bindings),
        "lower" => lower(args, ctx, bindings),
        "upper" => upper(args, ctx, bindings),
        _ => return None,
    };
    Some(r)
}

fn contains(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 2 {
        return EvalResult::Bool(false);
    }
    let a = eval_expr(&args[0], ctx, bindings);
    let b = eval_expr(&args[1], ctx, bindings);
    match (a.as_str(), b.as_str()) {
        (Some(h), Some(n)) => EvalResult::Bool(h.contains(n)),
        _ => EvalResult::Null, // null propagation — fail-closed under `not`
    }
}

fn startswith(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 2 {
        return EvalResult::Bool(false);
    }
    let a = eval_expr(&args[0], ctx, bindings);
    let b = eval_expr(&args[1], ctx, bindings);
    match (a.as_str(), b.as_str()) {
        (Some(h), Some(n)) => EvalResult::Bool(h.starts_with(n)),
        _ => EvalResult::Null,
    }
}

fn endswith(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 2 {
        return EvalResult::Bool(false);
    }
    let a = eval_expr(&args[0], ctx, bindings);
    let b = eval_expr(&args[1], ctx, bindings);
    match (a.as_str(), b.as_str()) {
        (Some(h), Some(n)) => EvalResult::Bool(h.ends_with(n)),
        _ => EvalResult::Null,
    }
}

fn regex_match(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    // Rego arg order: pattern first, then value
    if args.len() != 2 {
        return EvalResult::Bool(false);
    }
    let pattern = eval_expr(&args[0], ctx, bindings);
    let value = eval_expr(&args[1], ctx, bindings);
    match (pattern.as_str(), value.as_str()) {
        (Some(p), Some(v)) => {
            if p.len() > MAX_REGEX_LENGTH {
                return EvalResult::Bool(false);
            }
            match Regex::new(p) {
                Ok(re) => EvalResult::Bool(re.is_match(v)),
                Err(_) => EvalResult::Bool(false),
            }
        }
        _ => EvalResult::Null,
    }
}

fn lower(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    let a = eval_expr(&args[0], ctx, bindings);
    match a.as_str() {
        Some(s) => EvalResult::Str(s.to_lowercase()),
        None => EvalResult::Null,
    }
}

fn upper(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    let a = eval_expr(&args[0], ctx, bindings);
    match a.as_str() {
        Some(s) => EvalResult::Str(s.to_uppercase()),
        None => EvalResult::Null,
    }
}
