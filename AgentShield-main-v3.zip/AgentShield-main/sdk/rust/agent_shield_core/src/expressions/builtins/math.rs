//! Numeric builtins (LANGUAGE.md §5.3).
//!
//! `abs`, `round`, `ceil`, `floor`.

use std::collections::HashMap;

use super::super::ast::Expr;
use super::super::eval::{eval_expr, EvalContext, EvalResult};

pub(super) fn try_dispatch(
    name: &str,
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> Option<EvalResult> {
    let r = match name {
        "abs" => abs(args, ctx, bindings),
        "round" => round(args, ctx, bindings),
        "ceil" => ceil(args, ctx, bindings),
        "floor" => floor(args, ctx, bindings),
        _ => return None,
    };
    Some(r)
}

fn abs(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    let a = eval_expr(&args[0], ctx, bindings);
    match a.as_number() {
        Some(n) => EvalResult::Number(n.abs()),
        None => EvalResult::Null,
    }
}

fn round(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    let a = eval_expr(&args[0], ctx, bindings);
    match a.as_number() {
        Some(n) => EvalResult::Number(n.round()),
        None => EvalResult::Null,
    }
}

fn ceil(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    let a = eval_expr(&args[0], ctx, bindings);
    match a.as_number() {
        Some(n) => EvalResult::Number(n.ceil()),
        None => EvalResult::Null,
    }
}

fn floor(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    let a = eval_expr(&args[0], ctx, bindings);
    match a.as_number() {
        Some(n) => EvalResult::Number(n.floor()),
        None => EvalResult::Null,
    }
}
