//! Collection / set builtins.
//!
//! `count`, `sum`, `max`, `min`, `union`, `intersect`.

use std::collections::HashMap;

use super::super::ast::Expr;
use super::super::eval::{
    enum_aware_max_min, eval_expr, eval_results_equal, EvalContext, EvalResult,
};

pub(super) fn try_dispatch(
    name: &str,
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> Option<EvalResult> {
    let r = match name {
        "count" => count(args, ctx, bindings),
        "sum" => sum(args, ctx, bindings),
        "max" => max(args, ctx, bindings),
        "min" => min(args, ctx, bindings),
        "union" => union(args, ctx, bindings),
        "intersect" => intersect(args, ctx, bindings),
        "subset" => subset(args, ctx, bindings),
        "superset" => superset(args, ctx, bindings),
        _ => return None,
    };
    Some(r)
}

fn count(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    let a = eval_expr(&args[0], ctx, bindings);
    match a {
        EvalResult::List(items) => EvalResult::Number(items.len() as f64),
        // LANGUAGE.md /: count(string) MUST return the number of
        // Unicode code points (not UTF-8 bytes). Using `s.len()` would
        // return byte count, which breaks for multi-byte characters
        // (e.g., `count('é') == 1` is true, not `count('é') == 2`).
        EvalResult::Str(s) => EvalResult::Number(s.chars().count() as f64),
        EvalResult::Map(m) => EvalResult::Number(m.len() as f64),
        _ => EvalResult::Null,
    }
}

fn sum(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    let a = eval_expr(&args[0], ctx, bindings);
    match a {
        EvalResult::List(items) => {
            let mut total = 0.0;
            for item in &items {
                match item.as_number() {
                    Some(n) => total += n,
                    None => return EvalResult::Null,
                }
            }
            EvalResult::Number(total)
        }
        _ => EvalResult::Null,
    }
}

fn max(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    // `max()` accepts either a non-empty array of numbers or two scalar
    // arguments. The two-scalar form is used by `update:` expressions such
    // as `max(@current, @incoming)`.
    match args.len() {
        1 => {
            let a = eval_expr(&args[0], ctx, bindings);
            match a {
                EvalResult::List(items) if !items.is_empty() => {
                    let mut max_val: Option<f64> = None;
                    for item in &items {
                        match item.as_number() {
                            Some(n) => max_val = Some(max_val.map_or(n, |m: f64| m.max(n))),
                            None => return EvalResult::Null,
                        }
                    }
                    max_val.map_or(EvalResult::Null, EvalResult::Number)
                }
                _ => EvalResult::Null,
            }
        }
        2 => {
            let a = eval_expr(&args[0], ctx, bindings);
            let b = eval_expr(&args[1], ctx, bindings);
            enum_aware_max_min(&a, &b, /*pick_larger*/ true, ctx)
        }
        _ => EvalResult::Null,
    }
}

fn min(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    match args.len() {
        1 => {
            let a = eval_expr(&args[0], ctx, bindings);
            match a {
                EvalResult::List(items) if !items.is_empty() => {
                    let mut min_val: Option<f64> = None;
                    for item in &items {
                        match item.as_number() {
                            Some(n) => min_val = Some(min_val.map_or(n, |m: f64| m.min(n))),
                            None => return EvalResult::Null,
                        }
                    }
                    min_val.map_or(EvalResult::Null, EvalResult::Number)
                }
                _ => EvalResult::Null,
            }
        }
        2 => {
            let a = eval_expr(&args[0], ctx, bindings);
            let b = eval_expr(&args[1], ctx, bindings);
            enum_aware_max_min(&a, &b, /*pick_larger*/ false, ctx)
        }
        _ => EvalResult::Null,
    }
}

fn union(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    // Set-union of two arrays, deduplicated and preserving order: a's
    // elements first, then b's new elements. Either argument may be null
    // and is treated as the empty array.
    if args.len() != 2 {
        return EvalResult::Null;
    }
    let a = eval_expr(&args[0], ctx, bindings);
    let b = eval_expr(&args[1], ctx, bindings);
    let coerce = |v: EvalResult| -> Option<Vec<EvalResult>> {
        match v {
            EvalResult::Null => Some(Vec::new()),
            EvalResult::List(items) => Some(items),
            _ => None,
        }
    };
    let (Some(av), Some(bv)) = (coerce(a), coerce(b)) else {
        return EvalResult::Null;
    };
    let mut out: Vec<EvalResult> = Vec::with_capacity(av.len() + bv.len());
    for item in av.into_iter().chain(bv) {
        if !out
            .iter()
            .any(|existing| eval_results_equal(existing, &item))
        {
            out.push(item);
        }
    }
    EvalResult::List(out)
}

fn intersect(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    // Set-intersection of two arrays. Output preserves the order of the
    // first argument and deduplicates. Either argument may be null and is
    // treated as the empty array, matching `union`'s null-handling.
    //
    // The classic IFC pattern is a labels variable that uses
    // `update: 'intersect(@current, @incoming)'` so each tool
    // result can only NARROW the trust set, never widen it. Once a
    // label is dropped it cannot reappear within the lifetime.
    if args.len() != 2 {
        return EvalResult::Null;
    }
    let a = eval_expr(&args[0], ctx, bindings);
    let b = eval_expr(&args[1], ctx, bindings);
    let coerce = |v: EvalResult| -> Option<Vec<EvalResult>> {
        match v {
            EvalResult::Null => Some(Vec::new()),
            EvalResult::List(items) => Some(items),
            _ => None,
        }
    };
    let (Some(av), Some(bv)) = (coerce(a), coerce(b)) else {
        return EvalResult::Null;
    };
    let mut out: Vec<EvalResult> = Vec::with_capacity(av.len().min(bv.len()));
    for item in av {
        let in_b = bv.iter().any(|other| eval_results_equal(&item, other));
        let already = out
            .iter()
            .any(|existing| eval_results_equal(existing, &item));
        if in_b && !already {
            out.push(item);
        }
    }
    EvalResult::List(out)
}

fn subset(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    // `subset(a, b)` returns `true` iff every element of `a` is also in
    // `b` using the same value-equality as `union` and `intersect`.
    //
    // LANGUAGE.md /: `subset()` MUST return `null` when either
    // operand is `null` or a non-`array`. Unlike `union()` (which spec
    // explicitly says treats `null` as `[]`), `subset()` does NOT
    // null-coerce to the empty array — that would silently return
    // `true` for any RHS (since `[] <= x` is `true`) and let a
    // missing LHS variable satisfy a "subset" check. The null result
    // folds to `false` in boolean context (/), so guard
    // policies fail closed when either operand is missing.
    if args.len() != 2 {
        return EvalResult::Null;
    }
    let a = eval_expr(&args[0], ctx, bindings);
    let b = eval_expr(&args[1], ctx, bindings);
    let coerce = |v: EvalResult| -> Option<Vec<EvalResult>> {
        match v {
            EvalResult::List(items) => Some(items),
            _ => None, // null or non-array → null result
        }
    };
    let (Some(av), Some(bv)) = (coerce(a), coerce(b)) else {
        return EvalResult::Null;
    };
    let all_in_b = av
        .iter()
        .all(|x| bv.iter().any(|y| eval_results_equal(x, y)));
    EvalResult::Bool(all_in_b)
}

fn superset(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    // `superset(a, b)` is the same as `subset(b, a)`. It exists so
    // guard-policy expressions can read naturally.
    //
    // Same null/non-array rule as `subset()`: LANGUAGE.md / // require `null` on null or non-array operands so missing data
    // fails closed rather than spuriously satisfying the relation via
    // empty-array coercion.
    if args.len() != 2 {
        return EvalResult::Null;
    }
    let a = eval_expr(&args[0], ctx, bindings);
    let b = eval_expr(&args[1], ctx, bindings);
    let coerce = |v: EvalResult| -> Option<Vec<EvalResult>> {
        match v {
            EvalResult::List(items) => Some(items),
            _ => None, // null or non-array → null result
        }
    };
    let (Some(av), Some(bv)) = (coerce(a), coerce(b)) else {
        return EvalResult::Null;
    };
    let all_b_in_a = bv
        .iter()
        .all(|x| av.iter().any(|y| eval_results_equal(x, y)));
    EvalResult::Bool(all_b_in_a)
}
