//! Time / duration builtins (LANGUAGE.md §5.7).
//!
//! `time.now`, `time.duration`, `time.weekday`, `time.clock`. The clock
//! is injected through [`super::super::eval::now`] so tests can override
//! it via [`super::super::eval::set_now_factory`].

use std::collections::HashMap;

use chrono::{Datelike, Timelike};

use super::super::ast::Expr;
use super::super::eval::{eval_expr, now, EvalContext, EvalResult};

pub(super) fn try_dispatch(
    name: &str,
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> Option<EvalResult> {
    let r = match name {
        "time.now" => EvalResult::DateTime(now()),
        "time.duration" => time_duration(args, ctx, bindings),
        "time.weekday" => time_weekday(args, ctx, bindings),
        "time.clock" => time_clock(args, ctx, bindings),
        _ => return None,
    };
    Some(r)
}

fn time_duration(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    let arg = eval_expr(&args[0], ctx, bindings);
    match arg.as_str() {
        Some(s) => parse_duration(s),
        None => EvalResult::Null,
    }
}

fn time_weekday(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    let arg = eval_expr(&args[0], ctx, bindings);
    match arg {
        EvalResult::DateTime(dt) => EvalResult::Str(
            match dt.weekday() {
                chrono::Weekday::Mon => "Monday",
                chrono::Weekday::Tue => "Tuesday",
                chrono::Weekday::Wed => "Wednesday",
                chrono::Weekday::Thu => "Thursday",
                chrono::Weekday::Fri => "Friday",
                chrono::Weekday::Sat => "Saturday",
                chrono::Weekday::Sun => "Sunday",
            }
            .to_string(),
        ),
        _ => EvalResult::Null,
    }
}

fn time_clock(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    let arg = eval_expr(&args[0], ctx, bindings);
    match arg {
        EvalResult::DateTime(dt) => EvalResult::List(vec![
            EvalResult::Number(dt.hour() as f64),
            EvalResult::Number(dt.minute() as f64),
            EvalResult::Number(dt.second() as f64),
        ]),
        _ => EvalResult::Null,
    }
}

fn parse_duration(s: &str) -> EvalResult {
    let s = s.trim();
    if s.is_empty() {
        return EvalResult::Null;
    }

    let (num_str, unit) = s.split_at(s.len() - 1);
    let num: i64 = match num_str.parse() {
        Ok(n) => n,
        Err(_) => return EvalResult::Null,
    };

    let duration = match unit {
        "s" => chrono::Duration::seconds(num),
        "m" => chrono::Duration::minutes(num),
        "h" => chrono::Duration::hours(num),
        "d" => chrono::Duration::days(num),
        _ => return EvalResult::Null,
    };

    EvalResult::Duration(duration)
}
