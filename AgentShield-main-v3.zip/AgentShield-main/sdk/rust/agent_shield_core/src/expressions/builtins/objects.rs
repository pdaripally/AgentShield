//! Object / map builtins (LANGUAGE.md §5.4).
//!
//! `object.get`, `object.keys`, `object.values`, `object.entries`,
//! `object.merge_patch`.

use std::collections::HashMap;

use serde_json::Value;

use super::super::ast::Expr;
use super::super::eval::{eval_expr, value_to_eval, EvalContext, EvalResult};

pub(super) fn try_dispatch(
    name: &str,
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> Option<EvalResult> {
    let r = match name {
        "object.get" => object_get(args, ctx, bindings),
        "object.keys" => object_keys(args, ctx, bindings),
        "object.values" => object_values(args, ctx, bindings),
        "object.entries" => object_entries(args, ctx, bindings),
        "object.merge_patch" => object_merge_patch(args, ctx, bindings),
        _ => return None,
    };
    Some(r)
}

fn object_get(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 3 {
        return EvalResult::Null;
    }
    let obj = eval_expr(&args[0], ctx, bindings);
    let key = eval_expr(&args[1], ctx, bindings);
    let default = eval_expr(&args[2], ctx, bindings);
    match (&obj, key.as_str()) {
        (EvalResult::Map(map), Some(k)) => match map.get(k) {
            Some(val) if !val.is_null() => value_to_eval(val),
            _ => default,
        },
        _ => default, // null object → return default
    }
}

fn object_keys(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    let obj = eval_expr(&args[0], ctx, bindings);
    match obj {
        EvalResult::Map(map) => {
            let keys: Vec<EvalResult> = map.keys().map(|k| EvalResult::Str(k.clone())).collect();
            EvalResult::List(keys)
        }
        _ => EvalResult::Null,
    }
}

fn object_values(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    let obj = eval_expr(&args[0], ctx, bindings);
    match obj {
        EvalResult::Map(map) => {
            let values: Vec<EvalResult> = map.values().map(value_to_eval).collect();
            EvalResult::List(values)
        }
        _ => EvalResult::Null,
    }
}

fn object_entries(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    let obj = eval_expr(&args[0], ctx, bindings);
    match obj {
        EvalResult::Map(map) => {
            let entries: Vec<EvalResult> = map
                .iter()
                .map(|(k, v)| {
                    let mut entry: HashMap<String, Value> = HashMap::with_capacity(2);
                    entry.insert("key".to_string(), Value::String(k.clone()));
                    entry.insert("value".to_string(), v.clone());
                    EvalResult::Map(entry)
                })
                .collect();
            EvalResult::List(entries)
        }
        _ => EvalResult::Null,
    }
}

fn object_merge_patch(
    args: &[Expr],
    ctx: &EvalContext<'_>,
    bindings: &mut HashMap<String, EvalResult>,
) -> EvalResult {
    // §7.4 — RFC 7396 Merge Patch deep-merge: null values in `b`
    // delete the corresponding key in `a`; nested objects merge
    // recursively; arrays and scalars in `b` replace the
    // corresponding value in `a`. Required by §10.2 `update:`
    // expressions like `object.merge_patch(@current, @incoming)`.
    //
    // Spec §10.2 nesting limit: support at least 10 levels.
    if args.len() != 2 {
        return EvalResult::Null;
    }
    let a = eval_expr(&args[0], ctx, bindings);
    let b = eval_expr(&args[1], ctx, bindings);
    let av = match a {
        EvalResult::Map(m) => m,
        EvalResult::Null => HashMap::new(),
        _ => return EvalResult::Null,
    };
    let bv = match b {
        EvalResult::Map(m) => m,
        EvalResult::Null => return EvalResult::Map(av),
        _ => return EvalResult::Null,
    };
    EvalResult::Map(merge_patch_maps(av, bv, /*depth*/ 0))
}

fn merge_patch_maps(
    mut target: HashMap<String, Value>,
    patch: HashMap<String, Value>,
    depth: usize,
) -> HashMap<String, Value> {
    if depth >= crate::constants::merge::MAX_OBJECT_DEPTH {
        return target;
    }
    for (k, patch_v) in patch {
        match patch_v {
            Value::Null => {
                target.remove(&k);
            }
            Value::Object(patch_map) => {
                // If target's existing value at k is also an object,
                // merge recursively; otherwise the patch object replaces
                // whatever is there.
                let existing = target.remove(&k);
                let merged = match existing {
                    Some(Value::Object(target_map)) => {
                        let target_hm: HashMap<String, Value> = target_map.into_iter().collect();
                        let patch_hm: HashMap<String, Value> = patch_map.into_iter().collect();
                        let merged_hm = merge_patch_maps(target_hm, patch_hm, depth + 1);
                        let mut json_map = serde_json::Map::new();
                        for (k2, v2) in merged_hm {
                            json_map.insert(k2, v2);
                        }
                        Value::Object(json_map)
                    }
                    _ => Value::Object(patch_map),
                };
                target.insert(k, merged);
            }
            other => {
                target.insert(k, other);
            }
        }
    }
    target
}
