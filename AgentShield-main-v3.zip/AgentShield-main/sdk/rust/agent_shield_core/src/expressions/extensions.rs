use super::eval::EvalResult;
use chrono::SecondsFormat;
use regex::Regex;
use serde_json::Value;
use std::cmp::Ordering;
use std::collections::HashMap;
use url::Url;

const MAX_REGEX_LENGTH: usize = 500;
const MAX_FORMAT_PRECISION: usize = 100;
const MAX_FORMAT_OUTPUT: usize = 4096;
const MAX_RANGE_ELEMENTS: usize = 64;
const MAX_JSON_INPUT: usize = 65536;
const MAX_JSON_OUTPUT: usize = 65536;
const MAX_JSON_DEPTH: usize = 32;
const MAX_URI_INPUT: usize = 4096;

/// Try to evaluate an extension function. Returns Some(result) if the function
/// name matches an extension, None otherwise.
pub(crate) fn eval_extension(name: &str, evaluated_args: &[EvalResult]) -> Option<EvalResult> {
    match name {
        // String extensions
        "charAt" => Some(ext_char_at(evaluated_args)),
        "indexOf" => Some(ext_index_of(evaluated_args)),
        "lastIndexOf" => Some(ext_last_index_of(evaluated_args)),
        "join" => Some(ext_join(evaluated_args)),
        "split" => Some(ext_split(evaluated_args)),
        "substring" => Some(ext_substring(evaluated_args)),
        "trim" => Some(ext_trim(evaluated_args)),
        "replace" => Some(ext_replace(evaluated_args)),
        "reverse_string" => Some(ext_reverse_string(evaluated_args)),
        "quote" => Some(ext_quote(evaluated_args)),
        "format" => Some(ext_format(evaluated_args)),

        // List extensions
        "sort" => Some(ext_sort(evaluated_args)),
        "distinct" => Some(ext_distinct(evaluated_args)),
        "flatten" => Some(ext_flatten(evaluated_args)),
        "slice" => Some(ext_slice(evaluated_args)),
        "reverse_list" => Some(ext_reverse_list(evaluated_args)),
        "range" => Some(ext_range(evaluated_args)),

        // Regex extensions
        "regex.replace" => Some(ext_regex_replace(evaluated_args)),
        "regex.extract" => Some(ext_regex_extract(evaluated_args)),
        "regex.extract_all" => Some(ext_regex_extract_all(evaluated_args)),

        // Data interchange extensions
        "parse_json" => Some(ext_parse_json(evaluated_args)),
        "to_json" => Some(ext_to_json(evaluated_args)),

        // URI extensions
        "uri.scheme" => Some(ext_uri_scheme(evaluated_args)),
        "uri.host" => Some(ext_uri_host(evaluated_args)),
        "uri.port" => Some(ext_uri_port(evaluated_args)),
        "uri.path" => Some(ext_uri_path(evaluated_args)),
        "uri.query" => Some(ext_uri_query(evaluated_args)),

        _ => None,
    }
}

fn ext_char_at(args: &[EvalResult]) -> EvalResult {
    if args.len() != 2 {
        return EvalResult::Null;
    }
    match (&args[0], &args[1]) {
        (EvalResult::Str(s), EvalResult::Number(n)) => match exact_usize(*n) {
            Some(i) => s
                .chars()
                .nth(i)
                .map(|c| EvalResult::Str(c.to_string()))
                .unwrap_or(EvalResult::Null),
            None => EvalResult::Null,
        },
        _ => EvalResult::Null,
    }
}

fn ext_index_of(args: &[EvalResult]) -> EvalResult {
    if args.len() != 2 {
        return EvalResult::Null;
    }
    match (&args[0], &args[1]) {
        (EvalResult::Str(s), EvalResult::Str(sub)) => {
            EvalResult::Number(s.find(sub.as_str()).map(|i| i as f64).unwrap_or(-1.0))
        }
        _ => EvalResult::Null,
    }
}

fn ext_last_index_of(args: &[EvalResult]) -> EvalResult {
    if args.len() != 2 {
        return EvalResult::Null;
    }
    match (&args[0], &args[1]) {
        (EvalResult::Str(s), EvalResult::Str(sub)) => {
            EvalResult::Number(s.rfind(sub.as_str()).map(|i| i as f64).unwrap_or(-1.0))
        }
        _ => EvalResult::Null,
    }
}

fn ext_join(args: &[EvalResult]) -> EvalResult {
    if args.len() != 2 {
        return EvalResult::Null;
    }
    match (&args[0], &args[1]) {
        (EvalResult::List(items), EvalResult::Str(sep)) => {
            let mut parts = Vec::with_capacity(items.len());
            for item in items {
                match item {
                    EvalResult::Str(s) => parts.push(s.clone()),
                    _ => return EvalResult::Null,
                }
            }
            EvalResult::Str(parts.join(sep))
        }
        _ => EvalResult::Null,
    }
}

fn ext_split(args: &[EvalResult]) -> EvalResult {
    if args.len() != 2 {
        return EvalResult::Null;
    }
    match (&args[0], &args[1]) {
        (EvalResult::Str(s), EvalResult::Str(sep)) => EvalResult::List(
            s.split(sep.as_str())
                .map(|part| EvalResult::Str(part.to_string()))
                .collect(),
        ),
        _ => EvalResult::Null,
    }
}

fn ext_substring(args: &[EvalResult]) -> EvalResult {
    if args.len() != 3 {
        return EvalResult::Null;
    }
    match (&args[0], &args[1], &args[2]) {
        (EvalResult::Str(s), EvalResult::Number(start), EvalResult::Number(end)) => {
            let Some(start) = exact_usize(*start) else {
                return EvalResult::Null;
            };
            let Some(end) = exact_usize(*end) else {
                return EvalResult::Null;
            };
            let len = s.chars().count();
            let start = start.min(len);
            let end = end.min(len);
            if start > end {
                return EvalResult::Str(String::new());
            }
            EvalResult::Str(s.chars().skip(start).take(end - start).collect())
        }
        _ => EvalResult::Null,
    }
}

fn ext_trim(args: &[EvalResult]) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    match &args[0] {
        EvalResult::Str(s) => EvalResult::Str(s.trim().to_string()),
        _ => EvalResult::Null,
    }
}

fn ext_replace(args: &[EvalResult]) -> EvalResult {
    if args.len() != 3 {
        return EvalResult::Null;
    }
    match (&args[0], &args[1], &args[2]) {
        (EvalResult::Str(s), EvalResult::Str(old), EvalResult::Str(new)) => {
            EvalResult::Str(s.replace(old.as_str(), new.as_str()))
        }
        _ => EvalResult::Null,
    }
}

fn ext_reverse_string(args: &[EvalResult]) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    match &args[0] {
        EvalResult::Str(s) => EvalResult::Str(s.chars().rev().collect()),
        _ => EvalResult::Null,
    }
}

fn ext_quote(args: &[EvalResult]) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    match &args[0] {
        EvalResult::Str(s) => {
            let mut escaped = String::with_capacity(s.len() + 2);
            for c in s.chars() {
                match c {
                    '\\' => escaped.push_str("\\\\"),
                    '"' => escaped.push_str("\\\""),
                    '\0' => escaped.push_str("\\0"),
                    '\n' => escaped.push_str("\\n"),
                    '\t' => escaped.push_str("\\t"),
                    '\r' => escaped.push_str("\\r"),
                    _ => escaped.push(c),
                }
            }
            EvalResult::Str(format!("\"{escaped}\""))
        }
        _ => EvalResult::Null,
    }
}

fn ext_format(args: &[EvalResult]) -> EvalResult {
    if args.len() != 2 {
        return EvalResult::Null;
    }
    match (&args[0], &args[1]) {
        (EvalResult::Str(fmt), EvalResult::List(format_args)) => {
            let chars: Vec<char> = fmt.chars().collect();
            let mut result = String::new();
            let mut i = 0usize;
            let mut arg_idx = 0usize;

            while i < chars.len() {
                if chars[i] != '%' {
                    result.push(chars[i]);
                    if result.len() > MAX_FORMAT_OUTPUT {
                        return EvalResult::Null;
                    }
                    i += 1;
                    continue;
                }

                if i + 1 >= chars.len() {
                    result.push('%');
                    if result.len() > MAX_FORMAT_OUTPUT {
                        return EvalResult::Null;
                    }
                    break;
                }

                match chars[i + 1] {
                    '%' => {
                        result.push('%');
                        i += 2;
                    }
                    's' => {
                        if let Some(arg) = format_args.get(arg_idx) {
                            let formatted = match arg {
                                EvalResult::Str(s) => s.clone(),
                                EvalResult::Number(n) => format!("{n}"),
                                EvalResult::Bool(b) => format!("{b}"),
                                _ => "null".to_string(),
                            };
                            result.push_str(&formatted);
                            arg_idx += 1;
                        }
                        i += 2;
                    }
                    'd' => {
                        if let Some(EvalResult::Number(n)) = format_args.get(arg_idx) {
                            result.push_str(&format!("{}", *n as i64));
                            arg_idx += 1;
                        }
                        i += 2;
                    }
                    'f' => {
                        if let Some(EvalResult::Number(n)) = format_args.get(arg_idx) {
                            result.push_str(&format!("{n}"));
                            arg_idx += 1;
                        }
                        i += 2;
                    }
                    '.' => {
                        let mut j = i + 2;
                        let mut digits = String::new();
                        while j < chars.len() && chars[j].is_ascii_digit() {
                            digits.push(chars[j]);
                            j += 1;
                        }
                        if digits.is_empty() || j >= chars.len() || chars[j] != 'f' {
                            result.push('%');
                            i += 1;
                        } else {
                            let Ok(precision) = digits.parse::<usize>() else {
                                return EvalResult::Null;
                            };
                            if precision > MAX_FORMAT_PRECISION {
                                return EvalResult::Null;
                            }
                            if let Some(EvalResult::Number(n)) = format_args.get(arg_idx) {
                                result.push_str(&format!("{n:.precision$}"));
                                arg_idx += 1;
                            }
                            i = j + 1;
                        }
                    }
                    _ => {
                        result.push('%');
                        i += 1;
                    }
                }

                if result.len() > MAX_FORMAT_OUTPUT {
                    return EvalResult::Null;
                }
            }

            EvalResult::Str(result)
        }
        _ => EvalResult::Null,
    }
}

fn ext_sort(args: &[EvalResult]) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    match &args[0] {
        EvalResult::List(items) => {
            if items.is_empty() {
                return EvalResult::List(vec![]);
            }
            if items
                .iter()
                .all(|item| matches!(item, EvalResult::Number(_)))
            {
                let mut nums: Vec<f64> = items
                    .iter()
                    .filter_map(|item| match item {
                        EvalResult::Number(n) => Some(*n),
                        _ => None,
                    })
                    .collect();
                nums.sort_by(|a, b| a.partial_cmp(b).unwrap_or(Ordering::Equal));
                EvalResult::List(nums.into_iter().map(EvalResult::Number).collect())
            } else if items.iter().all(|item| matches!(item, EvalResult::Str(_))) {
                let mut strings: Vec<String> = items
                    .iter()
                    .filter_map(|item| match item {
                        EvalResult::Str(s) => Some(s.clone()),
                        _ => None,
                    })
                    .collect();
                strings.sort();
                EvalResult::List(strings.into_iter().map(EvalResult::Str).collect())
            } else {
                EvalResult::Null
            }
        }
        _ => EvalResult::Null,
    }
}

fn ext_distinct(args: &[EvalResult]) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    match &args[0] {
        EvalResult::List(items) => {
            let mut seen = Vec::new();
            let mut result = Vec::new();
            for item in items {
                let key = stable_key(item);
                if !seen.contains(&key) {
                    seen.push(key);
                    result.push(item.clone());
                }
            }
            EvalResult::List(result)
        }
        _ => EvalResult::Null,
    }
}

fn ext_flatten(args: &[EvalResult]) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    match &args[0] {
        EvalResult::List(items) => {
            let mut result = Vec::new();
            for item in items {
                match item {
                    EvalResult::List(inner) => result.extend(inner.clone()),
                    other => result.push(other.clone()),
                }
            }
            EvalResult::List(result)
        }
        _ => EvalResult::Null,
    }
}

fn ext_slice(args: &[EvalResult]) -> EvalResult {
    if args.len() != 3 {
        return EvalResult::Null;
    }
    match (&args[0], &args[1], &args[2]) {
        (EvalResult::List(items), EvalResult::Number(start), EvalResult::Number(end)) => {
            let Some(start) = exact_usize(*start) else {
                return EvalResult::Null;
            };
            let Some(end) = exact_usize(*end) else {
                return EvalResult::Null;
            };
            let len = items.len();
            let start = start.min(len);
            let end = end.min(len);
            if start > end {
                return EvalResult::List(vec![]);
            }
            EvalResult::List(items[start..end].to_vec())
        }
        _ => EvalResult::Null,
    }
}

fn ext_reverse_list(args: &[EvalResult]) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    match &args[0] {
        EvalResult::List(items) => {
            let mut reversed = items.clone();
            reversed.reverse();
            EvalResult::List(reversed)
        }
        _ => EvalResult::Null,
    }
}

fn ext_range(args: &[EvalResult]) -> EvalResult {
    if args.len() != 2 {
        return EvalResult::Null;
    }
    match (&args[0], &args[1]) {
        (EvalResult::Number(start), EvalResult::Number(end)) => {
            let Some(start) = exact_i64(*start) else {
                return EvalResult::Null;
            };
            let Some(end) = exact_i64(*end) else {
                return EvalResult::Null;
            };
            let count = (end - start).unsigned_abs() as usize;
            if count > MAX_RANGE_ELEMENTS {
                return EvalResult::Null;
            }
            EvalResult::List((start..end).map(|i| EvalResult::Number(i as f64)).collect())
        }
        _ => EvalResult::Null,
    }
}

fn ext_regex_replace(args: &[EvalResult]) -> EvalResult {
    if args.len() != 3 {
        return EvalResult::Null;
    }
    match (&args[0], &args[1], &args[2]) {
        (EvalResult::Str(pattern), EvalResult::Str(s), EvalResult::Str(replacement)) => {
            if pattern.len() > MAX_REGEX_LENGTH {
                return EvalResult::Null;
            }
            match Regex::new(pattern) {
                Ok(re) => EvalResult::Str(re.replace_all(s, replacement.as_str()).to_string()),
                Err(_) => EvalResult::Null,
            }
        }
        _ => EvalResult::Null,
    }
}

fn ext_regex_extract(args: &[EvalResult]) -> EvalResult {
    if args.len() != 2 {
        return EvalResult::Null;
    }
    match (&args[0], &args[1]) {
        (EvalResult::Str(pattern), EvalResult::Str(s)) => {
            if pattern.len() > MAX_REGEX_LENGTH {
                return EvalResult::Null;
            }
            match Regex::new(pattern) {
                Ok(re) => re
                    .find(s)
                    .map(|m| EvalResult::Str(m.as_str().to_string()))
                    .unwrap_or(EvalResult::Null),
                Err(_) => EvalResult::Null,
            }
        }
        _ => EvalResult::Null,
    }
}

fn ext_regex_extract_all(args: &[EvalResult]) -> EvalResult {
    if args.len() != 2 {
        return EvalResult::Null;
    }
    match (&args[0], &args[1]) {
        (EvalResult::Str(pattern), EvalResult::Str(s)) => {
            if pattern.len() > MAX_REGEX_LENGTH {
                return EvalResult::Null;
            }
            match Regex::new(pattern) {
                Ok(re) => EvalResult::List(
                    re.find_iter(s)
                        .map(|m| EvalResult::Str(m.as_str().to_string()))
                        .collect(),
                ),
                Err(_) => EvalResult::Null,
            }
        }
        _ => EvalResult::Null,
    }
}

fn exact_usize(n: f64) -> Option<usize> {
    if !n.is_finite() || n < 0.0 || n.fract().abs() >= f64::EPSILON || n > usize::MAX as f64 {
        return None;
    }
    Some(n as usize)
}

fn exact_i64(n: f64) -> Option<i64> {
    if !n.is_finite()
        || n.fract().abs() >= f64::EPSILON
        || n < i64::MIN as f64
        || n > i64::MAX as f64
    {
        return None;
    }
    Some(n as i64)
}

// ── Data interchange extensions ─────────────────────────────

fn check_json_depth(value: &Value, max_depth: usize) -> bool {
    if max_depth == 0 {
        return !matches!(value, Value::Array(_) | Value::Object(_));
    }
    match value {
        Value::Array(arr) => arr.iter().all(|v| check_json_depth(v, max_depth - 1)),
        Value::Object(map) => map.values().all(|v| check_json_depth(v, max_depth - 1)),
        _ => true,
    }
}

fn json_value_to_eval(value: &Value) -> EvalResult {
    match value {
        Value::Null => EvalResult::Null,
        Value::Bool(b) => EvalResult::Bool(*b),
        Value::Number(n) => EvalResult::Number(n.as_f64().unwrap_or(0.0)),
        Value::String(s) => EvalResult::Str(s.clone()),
        Value::Array(arr) => EvalResult::List(arr.iter().map(json_value_to_eval).collect()),
        Value::Object(_) => {
            let map: HashMap<String, Value> = match serde_json::from_value(value.clone()) {
                Ok(m) => m,
                Err(_) => return EvalResult::Null,
            };
            EvalResult::Map(map)
        }
    }
}

fn eval_to_json_value(eval: &EvalResult) -> Option<Value> {
    match eval {
        EvalResult::Null => Some(Value::Null),
        EvalResult::Bool(b) => Some(Value::Bool(*b)),
        EvalResult::Number(n) => {
            // Preserve integer representation for integer-valued f64
            if n.is_finite()
                && n.fract() == 0.0
                && *n >= (i64::MIN as f64)
                && *n <= (i64::MAX as f64)
            {
                Some(Value::Number(serde_json::Number::from(*n as i64)))
            } else {
                serde_json::Number::from_f64(*n).map(Value::Number)
            }
        }
        EvalResult::Str(s) => Some(Value::String(s.clone())),
        EvalResult::List(items) => {
            let arr: Option<Vec<Value>> = items.iter().map(eval_to_json_value).collect();
            arr.map(Value::Array)
        }
        EvalResult::Map(map) => {
            let obj = serde_json::Map::from_iter(map.iter().map(|(k, v)| (k.clone(), v.clone())));
            Some(Value::Object(obj))
        }
        EvalResult::DateTime(dt) => {
            Some(Value::String(dt.to_rfc3339_opts(SecondsFormat::Secs, true)))
        }
        EvalResult::Duration(d) => {
            let secs = d.num_seconds();
            let s = if secs % 86400 == 0 && secs != 0 {
                format!("{}d", secs / 86400)
            } else if secs % 3600 == 0 && secs != 0 {
                format!("{}h", secs / 3600)
            } else if secs % 60 == 0 && secs != 0 {
                format!("{}m", secs / 60)
            } else {
                format!("{}s", secs)
            };
            Some(Value::String(s))
        }
    }
}

fn ext_parse_json(args: &[EvalResult]) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    match &args[0] {
        EvalResult::Str(s) => {
            if s.len() > MAX_JSON_INPUT {
                return EvalResult::Null;
            }
            let value: Value = match serde_json::from_str(s) {
                Ok(v) => v,
                Err(_) => return EvalResult::Null,
            };
            if !check_json_depth(&value, MAX_JSON_DEPTH) {
                return EvalResult::Null;
            }
            json_value_to_eval(&value)
        }
        EvalResult::Null => EvalResult::Null,
        _ => EvalResult::Null,
    }
}

fn ext_to_json(args: &[EvalResult]) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    let json_val = match eval_to_json_value(&args[0]) {
        Some(v) => v,
        None => return EvalResult::Null,
    };
    // Sort keys for deterministic output
    let output = canonical_json(&json_val);
    if output.len() > MAX_JSON_OUTPUT {
        return EvalResult::Null;
    }
    EvalResult::Str(output)
}

fn canonical_json(value: &Value) -> String {
    match value {
        Value::Null => "null".to_string(),
        Value::Bool(b) => format!("{b}"),
        Value::Number(n) => format!("{n}"),
        Value::String(s) => serde_json::to_string(s).unwrap_or_default(),
        Value::Array(arr) => {
            let items: Vec<String> = arr.iter().map(canonical_json).collect();
            format!("[{}]", items.join(","))
        }
        Value::Object(map) => {
            let mut entries: Vec<(&String, &Value)> = map.iter().collect();
            entries.sort_by(|a, b| a.0.cmp(b.0));
            let pairs: Vec<String> = entries
                .iter()
                .map(|(k, v)| {
                    format!(
                        "{}:{}",
                        serde_json::to_string(k).unwrap_or_default(),
                        canonical_json(v)
                    )
                })
                .collect();
            format!("{{{}}}", pairs.join(","))
        }
    }
}

// ── URI extensions ──────────────────────────────────────────

fn ext_uri_scheme(args: &[EvalResult]) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    match &args[0] {
        EvalResult::Str(s) => {
            if s.len() > MAX_URI_INPUT {
                return EvalResult::Null;
            }
            match Url::parse(s) {
                Ok(url) => EvalResult::Str(url.scheme().to_lowercase()),
                Err(_) => EvalResult::Null,
            }
        }
        EvalResult::Null => EvalResult::Null,
        _ => EvalResult::Null,
    }
}

fn ext_uri_host(args: &[EvalResult]) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    match &args[0] {
        EvalResult::Str(s) => {
            if s.len() > MAX_URI_INPUT {
                return EvalResult::Null;
            }
            match Url::parse(s) {
                Ok(url) => match url.host_str() {
                    Some(h) => EvalResult::Str(h.to_lowercase()),
                    None => EvalResult::Str(String::new()),
                },
                Err(_) => EvalResult::Null,
            }
        }
        EvalResult::Null => EvalResult::Null,
        _ => EvalResult::Null,
    }
}

fn ext_uri_port(args: &[EvalResult]) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    match &args[0] {
        EvalResult::Str(s) => {
            if s.len() > MAX_URI_INPUT {
                return EvalResult::Null;
            }
            match Url::parse(s) {
                Ok(url) => match url.port() {
                    Some(p) => EvalResult::Number(p as f64),
                    None => EvalResult::Null,
                },
                Err(_) => EvalResult::Null,
            }
        }
        EvalResult::Null => EvalResult::Null,
        _ => EvalResult::Null,
    }
}

fn ext_uri_path(args: &[EvalResult]) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    match &args[0] {
        EvalResult::Str(s) => {
            if s.len() > MAX_URI_INPUT {
                return EvalResult::Null;
            }
            match Url::parse(s) {
                Ok(url) => {
                    let path = percent_decode(url.path());
                    EvalResult::Str(path)
                }
                Err(_) => EvalResult::Null,
            }
        }
        EvalResult::Null => EvalResult::Null,
        _ => EvalResult::Null,
    }
}

fn ext_uri_query(args: &[EvalResult]) -> EvalResult {
    if args.len() != 1 {
        return EvalResult::Null;
    }
    match &args[0] {
        EvalResult::Str(s) => {
            if s.len() > MAX_URI_INPUT {
                return EvalResult::Null;
            }
            match Url::parse(s) {
                Ok(url) => match url.query() {
                    Some(q) => EvalResult::Str(q.to_string()),
                    None => EvalResult::Null,
                },
                Err(_) => EvalResult::Null,
            }
        }
        EvalResult::Null => EvalResult::Null,
        _ => EvalResult::Null,
    }
}

fn percent_decode(s: &str) -> String {
    let mut result = String::with_capacity(s.len());
    let bytes = s.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'%' && i + 2 < bytes.len() {
            if let (Some(hi), Some(lo)) = (hex_val(bytes[i + 1]), hex_val(bytes[i + 2])) {
                result.push((hi << 4 | lo) as char);
                i += 3;
                continue;
            }
        }
        result.push(bytes[i] as char);
        i += 1;
    }
    result
}

fn hex_val(b: u8) -> Option<u8> {
    match b {
        b'0'..=b'9' => Some(b - b'0'),
        b'a'..=b'f' => Some(b - b'a' + 10),
        b'A'..=b'F' => Some(b - b'A' + 10),
        _ => None,
    }
}

fn stable_key(value: &EvalResult) -> String {
    match value {
        EvalResult::Bool(b) => format!("bool:{b}"),
        EvalResult::Number(n) => format!("number:{}", n.to_bits()),
        EvalResult::Str(s) => format!("string:{s:?}"),
        EvalResult::DateTime(dt) => format!("datetime:{}", dt.to_rfc3339()),
        EvalResult::Duration(duration) => {
            format!(
                "duration:{}",
                duration.num_nanoseconds().unwrap_or_default()
            )
        }
        EvalResult::List(items) => format!(
            "list:[{}]",
            items.iter().map(stable_key).collect::<Vec<_>>().join(",")
        ),
        EvalResult::Map(map) => {
            let mut entries: Vec<(&String, &Value)> = map.iter().collect();
            entries.sort_by(|a, b| a.0.cmp(b.0));
            format!(
                "map:{{{}}}",
                entries
                    .into_iter()
                    .map(|(k, v)| format!("{k}:{}", stable_json(v)))
                    .collect::<Vec<_>>()
                    .join(",")
            )
        }
        EvalResult::Null => "null".to_string(),
    }
}

fn stable_json(value: &Value) -> String {
    match value {
        Value::Null => "null".to_string(),
        Value::Bool(b) => format!("bool:{b}"),
        Value::Number(n) => format!("number:{n}"),
        Value::String(s) => format!("string:{s:?}"),
        Value::Array(items) => format!(
            "array:[{}]",
            items.iter().map(stable_json).collect::<Vec<_>>().join(",")
        ),
        Value::Object(map) => {
            let mut entries: Vec<_> = map.iter().collect();
            entries.sort_by(|a, b| a.0.cmp(b.0));
            format!(
                "object:{{{}}}",
                entries
                    .into_iter()
                    .map(|(k, v)| format!("{k}:{}", stable_json(v)))
                    .collect::<Vec<_>>()
                    .join(",")
            )
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::expressions::eval::evaluate;
    use serde_json::json;
    use std::collections::HashMap;

    fn attrs(pairs: &[(&str, Value)]) -> HashMap<String, Value> {
        pairs
            .iter()
            .map(|(k, v)| (k.to_string(), v.clone()))
            .collect()
    }

    #[test]
    fn test_char_at() {
        let a = attrs(&[("s", json!("hello"))]);
        assert!(evaluate("charAt(s, 0) == 'h'", &a));
        assert!(evaluate("charAt(s, 4) == 'o'", &a));
        assert!(evaluate("is_null(charAt(s, 99))", &a));
    }

    #[test]
    fn test_index_of() {
        let a = attrs(&[("s", json!("hello world"))]);
        assert!(evaluate("indexOf(s, 'world') == 6", &a));
        assert!(evaluate("indexOf(s, 'xyz') == -1", &a));
    }

    #[test]
    fn test_last_index_of() {
        let a = attrs(&[("s", json!("abcabc"))]);
        assert!(evaluate("lastIndexOf(s, 'abc') == 3", &a));
    }

    #[test]
    fn test_join() {
        let a = attrs(&[("arr", json!(["a", "b", "c"]))]);
        assert!(evaluate("join(arr, '-') == 'a-b-c'", &a));
    }

    #[test]
    fn test_split() {
        let a = attrs(&[("s", json!("a,b,c"))]);
        assert!(evaluate("count(split(s, ',')) == 3", &a));
    }

    #[test]
    fn test_substring() {
        let a = attrs(&[("s", json!("hello world"))]);
        assert!(evaluate("substring(s, 0, 5) == 'hello'", &a));
    }

    #[test]
    fn test_trim() {
        let a = attrs(&[("s", json!("  hello  "))]);
        assert!(evaluate("trim(s) == 'hello'", &a));
    }

    #[test]
    fn test_replace() {
        let a = attrs(&[("s", json!("hello world"))]);
        assert!(evaluate("replace(s, 'world', 'rust') == 'hello rust'", &a));
    }

    #[test]
    fn test_reverse_string() {
        let a = attrs(&[("s", json!("abc"))]);
        assert!(evaluate("reverse_string(s) == 'cba'", &a));
    }

    #[test]
    fn test_quote() {
        let a = attrs(&[("s", json!("hello"))]);
        assert!(evaluate("contains(quote(s), 'hello')", &a));
    }

    #[test]
    fn test_format() {
        let a = attrs(&[("s", json!("world")), ("n", json!(12.3456))]);
        assert!(evaluate(
            "format('hello %s %.2f', [s, n]) == 'hello world 12.35'",
            &a
        ));
    }

    #[test]
    fn test_sort_numbers() {
        let a = attrs(&[("arr", json!([3, 1, 2]))]);
        assert!(evaluate("sort(arr)[0] == 1", &a));
    }

    #[test]
    fn test_distinct() {
        let a = attrs(&[("arr", json!([1, 2, 2, 3, 3]))]);
        assert!(evaluate("count(distinct(arr)) == 3", &a));
    }

    #[test]
    fn test_flatten() {
        let a = attrs(&[("arr", json!([[1, 2], [3, 4]]))]);
        assert!(evaluate("count(flatten(arr)) == 4", &a));
    }

    #[test]
    fn test_slice() {
        let a = attrs(&[("arr", json!([1, 2, 3, 4, 5]))]);
        assert!(evaluate("count(slice(arr, 1, 3)) == 2", &a));
    }

    #[test]
    fn test_reverse_list() {
        let a = attrs(&[("arr", json!([1, 2, 3]))]);
        assert!(evaluate("reverse_list(arr)[0] == 3", &a));
    }

    #[test]
    fn test_range() {
        assert!(evaluate("count(range(0, 5)) == 5", &HashMap::new()));
    }

    #[test]
    fn test_range_limit() {
        assert!(!evaluate("count(range(0, 100)) > 0", &HashMap::new()));
    }

    #[test]
    fn test_regex_replace() {
        // Single-quoted strings are raw: \d+ passes through literally
        let a = attrs(&[("s", json!("hello 123 world 456"))]);
        assert!(evaluate(
            "regex.replace('\\d+', s, 'X') == 'hello X world X'",
            &a
        ));
    }

    #[test]
    fn test_regex_extract() {
        // Single-quoted strings are raw: \d+ passes through literally
        let a = attrs(&[("s", json!("order-12345"))]);
        assert!(evaluate("regex.extract('\\d+', s) == '12345'", &a));
    }

    #[test]
    fn test_regex_extract_no_match() {
        let a = attrs(&[("s", json!("no numbers"))]);
        assert!(evaluate("is_null(regex.extract('\\\\d+', s))", &a));
    }

    #[test]
    fn test_regex_extract_all() {
        // Single-quoted strings are raw: \d passes through literally
        let a = attrs(&[("s", json!("a1b2c3"))]);
        assert!(evaluate("count(regex.extract_all('\\d', s)) == 3", &a));
    }

    #[test]
    fn test_extension_null_propagation() {
        assert!(evaluate("is_null(trim(missing))", &HashMap::new()));
        assert!(evaluate("is_null(split(missing, ','))", &HashMap::new()));
        assert!(evaluate("is_null(indexOf(missing, 'x'))", &HashMap::new()));
    }

    // ═══════════════════════════════════════════════════════════════
    // parse_json / to_json
    // ═══════════════════════════════════════════════════════════════

    #[test]
    fn test_parse_json_object() {
        let a = attrs(&[("s", json!("{\"a\":1,\"b\":2}"))]);
        assert!(evaluate("is_object(parse_json(s))", &a));
        assert!(evaluate("has(parse_json(s), 'a')", &a));
    }

    #[test]
    fn test_parse_json_array() {
        let a = attrs(&[("s", json!("[1,2,3]"))]);
        assert!(evaluate("is_array(parse_json(s))", &a));
        assert!(evaluate("count(parse_json(s)) == 3", &a));
    }

    #[test]
    fn test_parse_json_string() {
        let a = attrs(&[("s", json!("\"hello\""))]);
        assert!(evaluate("parse_json(s) == 'hello'", &a));
    }

    #[test]
    fn test_parse_json_number() {
        let a = attrs(&[("s", json!("42"))]);
        assert!(evaluate("parse_json(s) == 42", &a));
    }

    #[test]
    fn test_parse_json_boolean() {
        let a = attrs(&[("s", json!("true"))]);
        assert!(evaluate("parse_json(s) == true", &a));
    }

    #[test]
    fn test_parse_json_null_literal() {
        let a = attrs(&[("s", json!("null"))]);
        assert!(evaluate("is_null(parse_json(s))", &a));
    }

    #[test]
    fn test_parse_json_invalid() {
        let a = attrs(&[("s", json!("not json"))]);
        assert!(evaluate("is_null(parse_json(s))", &a));
    }

    #[test]
    fn test_parse_json_null_input() {
        assert!(evaluate("is_null(parse_json(missing))", &HashMap::new()));
    }

    #[test]
    fn test_to_json_object() {
        let a = attrs(&[("obj", json!({"a": 1}))]);
        assert!(evaluate("is_string(to_json(obj))", &a));
        // Keys sorted: {"a":1}
        assert!(evaluate("contains(to_json(obj), '\"a\"')", &a));
    }

    #[test]
    fn test_to_json_array() {
        let a = attrs(&[("arr", json!([1, 2, 3]))]);
        assert!(evaluate("to_json(arr) == '[1,2,3]'", &a));
    }

    #[test]
    fn test_to_json_string() {
        let a = attrs(&[("s", json!("hello"))]);
        assert!(evaluate("to_json(s) == '\"hello\"'", &a));
    }

    #[test]
    fn test_to_json_null() {
        let a = attrs(&[("x", json!(null))]);
        assert!(evaluate("to_json(x) == 'null'", &a));
    }

    #[test]
    fn test_parse_json_roundtrip() {
        let a = attrs(&[("s", json!("{\"a\":1}"))]);
        assert!(evaluate("to_json(parse_json(s)) == '{\"a\":1}'", &a));
    }

    // ═══════════════════════════════════════════════════════════════
    // URI extensions
    // ═══════════════════════════════════════════════════════════════

    #[test]
    fn test_uri_scheme_https() {
        let a = attrs(&[("u", json!("https://example.com/path"))]);
        assert!(evaluate("uri.scheme(u) == 'https'", &a));
    }

    #[test]
    fn test_uri_scheme_file() {
        let a = attrs(&[("u", json!("file:///tmp/a.txt"))]);
        assert!(evaluate("uri.scheme(u) == 'file'", &a));
    }

    #[test]
    fn test_uri_scheme_invalid() {
        let a = attrs(&[("u", json!("not-a-uri"))]);
        assert!(evaluate("is_null(uri.scheme(u))", &a));
    }

    #[test]
    fn test_uri_scheme_null() {
        assert!(evaluate("is_null(uri.scheme(missing))", &HashMap::new()));
    }

    #[test]
    fn test_uri_host() {
        let a = attrs(&[("u", json!("https://Example.COM:8080/path"))]);
        assert!(evaluate("uri.host(u) == 'example.com'", &a));
    }

    #[test]
    fn test_uri_host_null() {
        assert!(evaluate("is_null(uri.host(missing))", &HashMap::new()));
    }

    #[test]
    fn test_uri_port_present() {
        let a = attrs(&[("u", json!("https://example.com:8080/path"))]);
        assert!(evaluate("uri.port(u) == 8080", &a));
    }

    #[test]
    fn test_uri_port_absent() {
        let a = attrs(&[("u", json!("https://example.com/path"))]);
        assert!(evaluate("is_null(uri.port(u))", &a));
    }

    #[test]
    fn test_uri_path() {
        let a = attrs(&[("u", json!("https://example.com/a/b?q=1"))]);
        assert!(evaluate("uri.path(u) == '/a/b'", &a));
    }

    #[test]
    fn test_uri_path_decoded() {
        let a = attrs(&[("u", json!("https://example.com/a%20b"))]);
        assert!(evaluate("uri.path(u) == '/a b'", &a));
    }

    #[test]
    fn test_uri_query_present() {
        let a = attrs(&[("u", json!("https://example.com/a?q=1&r=2"))]);
        assert!(evaluate("uri.query(u) == 'q=1&r=2'", &a));
    }

    #[test]
    fn test_uri_query_absent() {
        let a = attrs(&[("u", json!("https://example.com/a"))]);
        assert!(evaluate("is_null(uri.query(u))", &a));
    }

    #[test]
    fn test_uri_query_null() {
        assert!(evaluate("is_null(uri.query(missing))", &HashMap::new()));
    }

    #[test]
    fn test_uri_host_in_allowlist() {
        // Practical use-case: restrict tool access by host
        let a = attrs(&[("u", json!("https://api.internal.com/v2/data"))]);
        assert!(evaluate(
            "uri.host(u) in ['api.internal.com', 'storage.internal.com']",
            &a
        ));
    }

    #[test]
    fn test_uri_scheme_security_check() {
        // Practical use-case: only allow HTTPS resources
        let a = attrs(&[("u", json!("http://insecure.com/data"))]);
        assert!(!evaluate("uri.scheme(u) == 'https'", &a));
    }

    #[test]
    fn test_uri_path_prefix_check() {
        let a = attrs(&[("u", json!("https://api.example.com/api/v2/users"))]);
        assert!(evaluate("startswith(uri.path(u), '/api/v2/')", &a));
    }

    // ═══════════════════════════════════════════════════════════════
    // New extension null propagation
    // ═══════════════════════════════════════════════════════════════

    #[test]
    fn test_parse_json_to_json_null_propagation() {
        assert!(evaluate("is_null(parse_json(missing))", &HashMap::new()));
    }

    #[test]
    fn test_uri_null_propagation() {
        assert!(evaluate("is_null(uri.scheme(missing))", &HashMap::new()));
        assert!(evaluate("is_null(uri.host(missing))", &HashMap::new()));
        assert!(evaluate("is_null(uri.port(missing))", &HashMap::new()));
        assert!(evaluate("is_null(uri.path(missing))", &HashMap::new()));
        assert!(evaluate("is_null(uri.query(missing))", &HashMap::new()));
    }
}
