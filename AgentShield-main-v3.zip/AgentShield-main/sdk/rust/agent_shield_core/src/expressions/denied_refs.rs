//! AST walker that flags references to denied/cancelled variables.
//!
//! Backs the gate-level check: whenever a guard policy's
//! `evaluate_when[].expression`, `allowed_when:`, or `active_if:` reads
//! a variable whose `@status ∈ {denied, cancelled}`, the gate MUST
//! treat the predicate as triggering the block path regardless of the
//! computed truthiness. This prevents null-tolerant predicates
//! (`approval == null`, `not approval`, `approval == false`) from
//! laundering a resolver's final `deny`/`cancelled` outcome into an
//! allow.
//!
//! a denied variable is terminal — neither
//! `evaluate_when[].expression:` nor `allowed_when:` may auto-resolve
//! past it (the resolver hook returns `None`), and the stored `value`
//! (typically `null`) can compare truthily through null-tolerant
//! expression shapes. The runtime therefore inspects the AST for
//! denied references before delegating to the evaluator.
//!
//! Metadata reads (`var.@status`, `var.@deny_reason`, etc.) are
//! INTENTIONAL inspections of the denied state and are not flagged
//! here; the gate may deliberately interrogate `@status == 'denied'`
//! to surface a remediation message.
//!
//! predicate bodies fire too, transitively (spec //!): when an `evaluate_when[].expression:` /
//! `allowed_when:` / `active_if:` references a predicate by bare
//! name, the walker recursively expands the predicate's body AST
//! inspects its identifiers for denied references. This
//! prevents a predicate wrapper (e.g. `predicates: approval_ok:
//! "approval == true"` referenced from `evaluate_when:
//! "approval_ok"`) from hiding the denied variable from the
//! poison check — without the expansion, the walker would only
//! see the predicate name `approval_ok` (which is not a declared
//! variable) and miss the underlying `approval` denial. A
//! visited-set guards against pathological predicate cycles
//! (the loader's cycle detector should normally prevent this).

use super::ast::Expr;
use super::eval::{EvalResult, PredicateLookup, StatusLookup, VariableStatus};
use super::parser::parse;
use std::collections::HashSet;

/// A denied/cancelled variable surfaced inside a gating expression.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DeniedRef {
    /// Name of the declared variable whose `@status` is denied/cancelled.
    pub variable: String,
    /// `'deny'` or `'cancelled'` — sourced from `@deny_kind` when the
    /// adapter exposes it; falls back to `'denied'` otherwise. Always
    /// non-empty.
    pub deny_kind: String,
    /// `@deny_reason` text from the resolver chain's final outcome, if
    /// the StatusLookup adapter surfaces it. Empty when unavailable.
    pub deny_reason: String,
}

/// Walk `expr_src` and return the first declared variable whose
/// `@status` is `denied`. Returns `None` when:
///
/// - `status_lookup` is `None` (transitional path — no adapter wired),
/// - the expression fails to parse (the caller's evaluator will fail
///   closed via its own parse-error handling),
/// - no referenced declared variable is denied.
///
/// Only declared variables are inspected — `is_declared` discriminates
/// against scope-namespace roots (`tool`, `endpoint`, `agent`,
/// `context`, `result`), predicate names, local `:=` bindings, and
/// quantifier-bound names. Metadata reads (`var.@field`) are skipped
/// per the module docs.
///
/// when `predicates` is `Some`, identifiers that are NOT
/// declared variables are tried as predicate names. If the lookup
/// returns a body, that body's AST is recursively walked under the
/// same denied-poison rules. A visited-set prevents pathological
/// cycles. Passing `predicates: None` keeps the legacy
/// declared-variable-only behaviour (used by call sites that don't
/// have a PredicateLookup available, e.g. internal unit tests).
pub fn first_denied_ref(
    expr_src: &str,
    status_lookup: &dyn StatusLookup,
    predicates: Option<&dyn PredicateLookup>,
) -> Option<DeniedRef> {
    let ast = parse(expr_src).ok()?;
    let mut visited: HashSet<String> = HashSet::new();
    walk_for_denied(&ast, status_lookup, predicates, &mut visited)
}

/// Recursive worker for [`first_denied_ref`]. Collects bare value
/// idents in `expr`, checks each one for a denied declared variable,
/// and (when `predicates` is `Some`) transitively expands predicate
/// references into their parsed bodies under a cycle guard.
fn walk_for_denied(
    expr: &Expr,
    status_lookup: &dyn StatusLookup,
    predicates: Option<&dyn PredicateLookup>,
    visited_predicates: &mut HashSet<String>,
) -> Option<DeniedRef> {
    let mut names: Vec<String> = Vec::new();
    let mut seen: HashSet<String> = HashSet::new();
    collect_value_idents(expr, &mut names, &mut seen);

    for name in names {
        if status_lookup.is_declared(&name) {
            if let Some(VariableStatus::Denied) = status_lookup.status(&name) {
                let deny_kind = match status_lookup.meta(&name, "deny_kind") {
                    Some(EvalResult::Str(s)) if !s.is_empty() => s,
                    _ => "denied".to_string(),
                };
                let deny_reason = match status_lookup.meta(&name, "deny_reason") {
                    Some(EvalResult::Str(s)) => s,
                    _ => String::new(),
                };
                return Some(DeniedRef {
                    variable: name,
                    deny_kind,
                    deny_reason,
                });
            }
            continue;
        }

        // not a declared variable; try as a predicate name and
        // recursively walk the body AST. Visited-set keeps cycles
        // bounded even though the loader's cycle detector should
        // already prevent them.
        let Some(pl) = predicates else { continue };
        if !visited_predicates.insert(name.clone()) {
            continue;
        }
        let Some(body_src) = pl.body(&name) else {
            continue;
        };
        let Ok(body_ast) = parse(body_src) else {
            continue;
        };
        if let Some(d) = walk_for_denied(&body_ast, status_lookup, predicates, visited_predicates) {
            return Some(d);
        }
    }
    None
}

/// Format the citation suffix appended to a gate's `reason:` text.
/// Renders `" (variable '<name>' is <deny_kind>: <deny_reason>)"` when
/// `deny_reason` is present, or `" (variable '<name>' is <deny_kind>)"`
/// otherwise. Kept as a free function so call sites stay one line.
pub fn format_denied_citation(d: &DeniedRef) -> String {
    if d.deny_reason.is_empty() {
        format!(" (variable '{}' is {})", d.variable, d.deny_kind)
    } else {
        format!(
            " (variable '{}' is {}: {})",
            d.variable, d.deny_kind, d.deny_reason
        )
    }
}

/// Recursively collect bare-identifier value reads from `expr` into
/// `out` (deduplicated via `seen`). Only Idents that look like value
/// reads are collected — metadata reads (`Expr::MetaField`), literals,
/// and synthesized binding names (the LHS of `Expr::Assignment`, the
/// bound name on `Expr::Quantifier`) are skipped. DottedAccess roots
/// are followed: `user.role` collects `user`.
fn collect_value_idents(expr: &Expr, out: &mut Vec<String>, seen: &mut HashSet<String>) {
    match expr {
        Expr::Literal(_) => {}
        Expr::Ident(name) => {
            if seen.insert(name.clone()) {
                out.push(name.clone());
            }
        }
        Expr::DottedAccess { root, .. } => collect_value_idents(root, out, seen),
        Expr::BinaryOp { left, right, .. } => {
            collect_value_idents(left, out, seen);
            collect_value_idents(right, out, seen);
        }
        Expr::UnaryOp { operand, .. } => collect_value_idents(operand, out, seen),
        Expr::FnCall { name, args } => {
            // LANGUAGE.md — the four status-sugar functions are
            // sugar over `<name>.@status` reads. Their bare-ident
            // argument inspects the variable's status, not its value,
            // so it MUST NOT participate in the denied-poison
            // walk for the same reason `Expr::MetaField` is exempt:
            // the gate may deliberately interrogate the denied state
            // (e.g. `evaluate_when[].expression: "denied(approval)"`
            // or `allowed_when: "not denied(transfer_authorized)"`).
            // Other function calls (`not`, `count`, `regex.match`,
            // `@event.fired`, ...) continue to walk their args.
            if matches!(name.as_str(), "defined" | "unset" | "denied" | "present") {
                return;
            }
            for a in args {
                collect_value_idents(a, out, seen);
            }
        }
        Expr::Ternary {
            condition,
            then_expr,
            else_expr,
        } => {
            collect_value_idents(condition, out, seen);
            collect_value_idents(then_expr, out, seen);
            collect_value_idents(else_expr, out, seen);
        }
        Expr::List(items) => {
            for i in items {
                collect_value_idents(i, out, seen);
            }
        }
        Expr::Index { object, index } => {
            collect_value_idents(object, out, seen);
            collect_value_idents(index, out, seen);
        }
        Expr::Assignment { value, .. } => collect_value_idents(value, out, seen),
        Expr::Quantifier {
            collection,
            predicate,
            ..
        } => {
            collect_value_idents(collection, out, seen);
            collect_value_idents(predicate, out, seen);
        }
        // metadata reads are INTENTIONAL inspections of the
        // denied state and MUST NOT trigger the denied-poison check.
        Expr::MetaField { .. } => {}
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::expressions::eval::EvalResult;
    use std::cell::RefCell;
    use std::collections::HashMap;

    struct FakeLookup {
        statuses: HashMap<String, VariableStatus>,
        deny_reasons: HashMap<String, String>,
        deny_kinds: HashMap<String, String>,
        declared: std::collections::HashSet<String>,
        meta_calls: RefCell<Vec<(String, String)>>,
    }

    impl FakeLookup {
        fn new() -> Self {
            Self {
                statuses: HashMap::new(),
                deny_reasons: HashMap::new(),
                deny_kinds: HashMap::new(),
                declared: std::collections::HashSet::new(),
                meta_calls: RefCell::new(Vec::new()),
            }
        }
        fn with_var(mut self, name: &str, status: VariableStatus) -> Self {
            self.declared.insert(name.into());
            self.statuses.insert(name.into(), status);
            self
        }
        fn with_deny_reason(mut self, name: &str, reason: &str) -> Self {
            self.deny_reasons.insert(name.into(), reason.into());
            self
        }
        fn with_deny_kind(mut self, name: &str, kind: &str) -> Self {
            self.deny_kinds.insert(name.into(), kind.into());
            self
        }
    }

    impl StatusLookup for FakeLookup {
        fn status(&self, var: &str) -> Option<VariableStatus> {
            self.statuses.get(var).copied()
        }
        fn meta(&self, var: &str, field: &str) -> Option<EvalResult> {
            self.meta_calls
                .borrow_mut()
                .push((var.to_string(), field.to_string()));
            match field {
                "deny_reason" => self.deny_reasons.get(var).cloned().map(EvalResult::Str),
                "deny_kind" => self.deny_kinds.get(var).cloned().map(EvalResult::Str),
                _ => None,
            }
        }
        fn is_declared(&self, var: &str) -> bool {
            self.declared.contains(var)
        }
    }

    #[test]
    fn null_compare_flags_denied_variable() {
        let sl = FakeLookup::new()
            .with_var("approval", VariableStatus::Denied)
            .with_deny_reason("approval", "user said no")
            .with_deny_kind("approval", "deny");
        let r = first_denied_ref("approval == null", &sl, None).expect("must flag");
        assert_eq!(r.variable, "approval");
        assert_eq!(r.deny_kind, "deny");
        assert_eq!(r.deny_reason, "user said no");
    }

    #[test]
    fn not_operator_flags_denied_variable() {
        let sl = FakeLookup::new().with_var("approval", VariableStatus::Denied);
        let r = first_denied_ref("not approval", &sl, None).expect("must flag");
        assert_eq!(r.variable, "approval");
    }

    #[test]
    fn equals_false_flags_denied_variable() {
        let sl = FakeLookup::new().with_var("approval", VariableStatus::Denied);
        let r = first_denied_ref("approval == false", &sl, None).expect("must flag");
        assert_eq!(r.variable, "approval");
    }

    #[test]
    fn unrelated_predicate_returns_none() {
        let sl = FakeLookup::new()
            .with_var("approval", VariableStatus::Denied)
            .with_var("other", VariableStatus::Resolved);
        assert!(first_denied_ref("other == true", &sl, None).is_none());
    }

    #[test]
    fn undeclared_name_skipped() {
        // `tool` is the namespace root; a real adapter's `is_declared`
        // returns false. The fake doesn't declare it either.
        let sl = FakeLookup::new();
        assert!(first_denied_ref("tool.name == 'pay'", &sl, None).is_none());
    }

    #[test]
    fn metadata_read_not_flagged() {
        // Reading `var.@status` is the intentional inspection idiom and
        // MUST NOT poison the gate.
        let sl = FakeLookup::new().with_var("approval", VariableStatus::Denied);
        assert!(first_denied_ref("approval.@status == 'denied'", &sl, None).is_none());
    }

    #[test]
    fn resolved_variable_not_flagged() {
        let sl = FakeLookup::new().with_var("approval", VariableStatus::Resolved);
        assert!(first_denied_ref("approval == null", &sl, None).is_none());
    }

    #[test]
    fn unset_variable_not_flagged() {
        let sl = FakeLookup::new().with_var("approval", VariableStatus::Unset);
        assert!(first_denied_ref("approval == null", &sl, None).is_none());
    }

    #[test]
    fn parse_error_returns_none() {
        let sl = FakeLookup::new().with_var("x", VariableStatus::Denied);
        assert!(first_denied_ref("x ===", &sl, None).is_none());
    }

    #[test]
    fn format_citation_with_reason() {
        let d = DeniedRef {
            variable: "approval".into(),
            deny_kind: "deny".into(),
            deny_reason: "no".into(),
        };
        assert_eq!(
            format_denied_citation(&d),
            " (variable 'approval' is deny: no)"
        );
    }

    #[test]
    fn format_citation_without_reason() {
        let d = DeniedRef {
            variable: "approval".into(),
            deny_kind: "cancelled".into(),
            deny_reason: String::new(),
        };
        assert_eq!(
            format_denied_citation(&d),
            " (variable 'approval' is cancelled)"
        );
    }

    // ───────────────────────────────────────────────────────────────
    // status-sugar functions are
    // intentional inspections of `@status`, like `var.@status`
    // metadata reads, and MUST NOT be flagged by the denied-poison
    // walk. Only `defined`, `unset`, `denied`, `present` are exempt;
    // every other function call still walks its args.
    // ───────────────────────────────────────────────────────────────

    #[test]
    fn status_sugar_denied_not_flagged() {
        let sl = FakeLookup::new().with_var("v", VariableStatus::Denied);
        assert!(
            first_denied_ref("denied(v)", &sl, None).is_none(),
            "`denied(v)` is the spec-intended way to interrogate denial; it MUST NOT poison"
        );
    }

    #[test]
    fn status_sugar_introspection_not_flagged() {
        // `defined`, `unset`, `present` all read `@status` and are
        // exempt for the same reason as `denied`.
        let sl = FakeLookup::new().with_var("v", VariableStatus::Denied);
        assert!(first_denied_ref("defined(v)", &sl, None).is_none());
        assert!(first_denied_ref("unset(v)", &sl, None).is_none());
        assert!(first_denied_ref("present(v)", &sl, None).is_none());
    }

    #[test]
    fn negated_status_sugar_not_flagged() {
        // `not denied(v)` is the canonical "bypass when not denied"
        // idiom (LANGUAGE.md example) — the `not` walks into the
        // FnCall, which short-circuits before reaching the arg, so `v`
        // is never collected.
        let sl = FakeLookup::new().with_var("v", VariableStatus::Denied);
        assert!(first_denied_ref("not denied(v)", &sl, None).is_none());
    }

    #[test]
    fn composite_status_sugar_only_exempts_sugar_arg() {
        // `denied(approval)` is exempt, but the bare value-read of
        // `other_denied_var` in the surrounding expression still
        // poisons — the exemption is scoped strictly to the sugar's
        // direct arg, not the whole expression.
        let sl = FakeLookup::new()
            .with_var("approval", VariableStatus::Denied)
            .with_var("other_denied_var", VariableStatus::Denied);
        let r = first_denied_ref("denied(approval) and not other_denied_var", &sl, None)
            .expect("other_denied_var must still flag");
        assert_eq!(r.variable, "other_denied_var");
    }

    #[test]
    fn non_sugar_function_still_walks_args() {
        // Regression guard: only the four status sugar names are
        // exempt. `count(...)`, `regex.match(...)`, `@event.fired(...)`,
        // and the boolean `not` MUST still walk their args so that a
        // denied variable surfaced through e.g. `count(denied_arr)`
        // continues to poison.
        let sl = FakeLookup::new().with_var("denied_arr", VariableStatus::Denied);
        let r = first_denied_ref("count(denied_arr) > 0", &sl, None)
            .expect("count(...) MUST still poison its denied arg");
        assert_eq!(r.variable, "denied_arr");
    }

    // ───────────────────────────────────────────────────────────────
    // predicate bodies fire transitively. A predicate referenced
    // from a gating site MUST be expanded so the walker sees through
    // the predicate-name wrapper to the declared variables underneath.
    // Without this, a YAML
    // like `predicates: approval_ok: "approval == true"` referenced
    // from `evaluate_when: "approval_ok"` would let a resolver deny
    // be laundered by `allowed_when: "true"`.
    // ───────────────────────────────────────────────────────────────

    struct FakePredicates {
        bodies: HashMap<String, String>,
    }

    impl FakePredicates {
        fn new() -> Self {
            Self {
                bodies: HashMap::new(),
            }
        }
        fn with(mut self, name: &str, body: &str) -> Self {
            self.bodies.insert(name.into(), body.into());
            self
        }
    }

    impl PredicateLookup for FakePredicates {
        fn body(&self, name: &str) -> Option<&str> {
            self.bodies.get(name).map(|s| s.as_str())
        }
    }

    #[test]
    fn predicate_wrapping_denied_variable_flags_through_predicate() {
        // case (a) — bare predicate call at the gating site
        // expands to its body, which reads the denied variable.
        let sl = FakeLookup::new()
            .with_var("approval", VariableStatus::Denied)
            .with_deny_reason("approval", "operator denied")
            .with_deny_kind("approval", "deny");
        let pl = FakePredicates::new().with("approval_ok", "approval == true");
        let r = first_denied_ref("approval_ok", &sl, Some(&pl))
            .expect("predicate body MUST surface the denied variable");
        assert_eq!(r.variable, "approval");
        assert_eq!(r.deny_kind, "deny");
        assert_eq!(r.deny_reason, "operator denied");
    }

    #[test]
    fn nested_predicate_chain_flags_through_all_levels() {
        // case (b) — predicate calling predicate calling the
        // denied variable. Each level must transitively expand.
        let sl = FakeLookup::new().with_var("approval", VariableStatus::Denied);
        let pl = FakePredicates::new()
            .with("outer", "middle")
            .with("middle", "inner")
            .with("inner", "approval == true");
        let r = first_denied_ref("outer", &sl, Some(&pl))
            .expect("nested predicate chain MUST surface the denied variable");
        assert_eq!(r.variable, "approval");
    }

    #[test]
    fn status_sugar_inside_predicate_body_not_flagged() {
        // case (c) — a predicate body that uses `denied(x)` is
        // an intentional status interrogation and MUST NOT trigger
        // the terminal-deny path, even when expanded through a
        // predicate wrapper. The sugar exemption is preserved
        // transitively.
        let sl = FakeLookup::new().with_var("approval", VariableStatus::Denied);
        let pl = FakePredicates::new().with("needs_remediation", "denied(approval)");
        assert!(
            first_denied_ref("needs_remediation", &sl, Some(&pl)).is_none(),
            "`denied(approval)` inside a predicate body MUST remain a non-poisoning status check"
        );
    }

    #[test]
    fn predicate_expansion_handles_compound_bodies() {
        // Compound body using `and`: one side reads a resolved
        // variable, the other reads a denied one. The walker MUST
        // surface the denied variable regardless of evaluation order.
        let sl = FakeLookup::new()
            .with_var("session_ok", VariableStatus::Resolved)
            .with_var("approval", VariableStatus::Denied);
        let pl = FakePredicates::new().with("guard", "session_ok and approval");
        let r = first_denied_ref("guard", &sl, Some(&pl))
            .expect("compound predicate body MUST flag the denied side");
        assert_eq!(r.variable, "approval");
    }

    #[test]
    fn predicate_cycle_does_not_loop_forever() {
        // The loader's cycle detector should normally prevent this,
        // but the walker still guards defensively with a visited-set.
        // Cyclic chain with no denied variable returns None instead
        // of looping.
        let sl = FakeLookup::new().with_var("approval", VariableStatus::Resolved);
        let pl = FakePredicates::new().with("a", "b").with("b", "a");
        // Must terminate; no denied var reachable.
        assert!(first_denied_ref("a", &sl, Some(&pl)).is_none());
    }

    #[test]
    fn predicate_cycle_still_surfaces_denied_variable_before_cycling() {
        // If the cycle includes a path to a denied variable, the
        // walker MUST still surface it before the visited-set kicks
        // in.
        let sl = FakeLookup::new().with_var("approval", VariableStatus::Denied);
        let pl = FakePredicates::new()
            .with("a", "b or approval")
            .with("b", "a");
        let r = first_denied_ref("a", &sl, Some(&pl)).expect("denied side must surface");
        assert_eq!(r.variable, "approval");
    }

    #[test]
    fn predicate_lookup_none_keeps_legacy_behaviour() {
        // Passing None for predicates preserves the previous behavior:
        // predicate-name idents that don't match a declared
        // variable are silently skipped (used by internal call sites
        // unit tests that don't have a PredicateLookup available).
        let sl = FakeLookup::new().with_var("approval", VariableStatus::Denied);
        assert!(
            first_denied_ref("approval_ok", &sl, None).is_none(),
            "without a PredicateLookup, predicate names are unknown idents"
        );
    }

    #[test]
    fn unknown_predicate_name_does_not_flag() {
        // PredicateLookup returns None for an unknown name — walker
        // continues without poisoning.
        let sl = FakeLookup::new().with_var("approval", VariableStatus::Denied);
        let pl = FakePredicates::new();
        assert!(first_denied_ref("approval_ok", &sl, Some(&pl)).is_none());
    }
}
