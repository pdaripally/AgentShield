use super::ast::*;
use super::tokenizer::{tokenize, Token, TokenError};
use std::fmt;

const MAX_EXPRESSION_LENGTH: usize = 4096;
const MAX_NESTING_DEPTH: usize = 32;
const MAX_LIST_ELEMENTS: usize = 64;
const MAX_FUNCTION_ARGS: usize = 16;

/// Parse error with context.
#[derive(Debug, Clone)]
pub struct ParseError {
    pub message: String,
}

impl fmt::Display for ParseError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "parse error: {}", self.message)
    }
}

impl std::error::Error for ParseError {}

impl From<TokenError> for ParseError {
    fn from(e: TokenError) -> Self {
        ParseError {
            message: e.to_string(),
        }
    }
}

/// Recognize the names of quantifier-macro invocations. Used by the parser
/// to distinguish `all(coll, x -> p)` (macro form) from a plain function call
/// to a same-named user identifier.
fn quantifier_kind(name: &str) -> Option<QuantifierKind> {
    match name {
        "all" => Some(QuantifierKind::All),
        "any" => Some(QuantifierKind::Any),
        "count_where" => Some(QuantifierKind::CountWhere),
        _ => None,
    }
}

/// Parse an expression string into an AST.
///
/// Applies the AST-node cap from one of the following sources (highest
/// priority first):
///
/// 1. The thread-local `ACTIVE_LIMITS` set by
///    [`crate::expressions::eval::with_active_limits`] (i.e., the
///    YAML-configured `limits.max_expression_ast_nodes` for the
///    enclosing stage/populator call).
/// 2. The spec default
///    [`crate::limits::DEFAULT_MAX_EXPRESSION_AST_NODES`].
///
/// Callers that want an explicit cap (e.g. tests, or hosts that need
/// to bypass enforcement) MUST use [`parse_with_node_cap`] directly.
pub fn parse(input: &str) -> Result<Expr, ParseError> {
    let cap = crate::expressions::eval::active_limits()
        .map(|l| l.max_expression_ast_nodes)
        .unwrap_or(crate::limits::DEFAULT_MAX_EXPRESSION_AST_NODES);
    parse_with_node_cap(input, cap)
}

/// Parse an expression string into an AST under the supplied AST-node
/// cap (`Limits::max_expression_ast_nodes`). A cap of
/// `usize::MAX` disables the check (used internally by parser tests
/// that intentionally build huge expressions).
pub fn parse_with_node_cap(input: &str, max_nodes: usize) -> Result<Expr, ParseError> {
    if input.len() > MAX_EXPRESSION_LENGTH {
        return Err(ParseError {
            message: format!(
                "expression exceeds maximum length of {MAX_EXPRESSION_LENGTH} characters"
            ),
        });
    }

    let tokens = tokenize(input)?;
    if tokens.is_empty() {
        return Ok(Expr::Literal(LitValue::Bool(true)));
    }
    let mut parser = Parser::new(tokens);
    let expr = parser.parse_expression()?;
    if parser.pos < parser.tokens.len() {
        return Err(ParseError {
            message: format!(
                "unexpected token '{}' at position {}",
                parser.tokens[parser.pos], parser.pos
            ),
        });
    }
    if max_nodes != usize::MAX {
        let nodes = expr.count_nodes();
        if nodes > max_nodes {
            return Err(ParseError {
                message: format!("expression exceeds the {max_nodes}-node AST cap ({nodes} nodes)"),
            });
        }
    }
    Ok(expr)
}

struct Parser {
    tokens: Vec<Token>,
    pos: usize,
    depth: usize,
}

impl Parser {
    fn new(tokens: Vec<Token>) -> Self {
        Self {
            tokens,
            pos: 0,
            depth: 0,
        }
    }

    fn enter_depth(&mut self) -> Result<(), ParseError> {
        self.depth += 1;
        if self.depth > MAX_NESTING_DEPTH {
            Err(ParseError {
                message: format!("expression exceeds maximum nesting depth of {MAX_NESTING_DEPTH}"),
            })
        } else {
            Ok(())
        }
    }

    fn exit_depth(&mut self) {
        self.depth -= 1;
    }

    fn with_depth<T>(
        &mut self,
        f: impl FnOnce(&mut Self) -> Result<T, ParseError>,
    ) -> Result<T, ParseError> {
        self.enter_depth()?;
        let result = f(self);
        self.exit_depth();
        result
    }

    fn peek(&self) -> Option<&Token> {
        self.tokens.get(self.pos)
    }

    fn advance(&mut self) -> Option<Token> {
        if self.pos < self.tokens.len() {
            let tok = self.tokens[self.pos].clone();
            self.pos += 1;
            Some(tok)
        } else {
            None
        }
    }

    fn expect(&mut self, expected: &Token) -> Result<(), ParseError> {
        match self.advance() {
            Some(ref tok) if tok == expected => Ok(()),
            Some(tok) => Err(ParseError {
                message: format!("expected '{expected}', got '{tok}'"),
            }),
            None => Err(ParseError {
                message: format!("expected '{expected}', got end of expression"),
            }),
        }
    }

    fn parse_function_args(&mut self) -> Result<Vec<Expr>, ParseError> {
        self.expect(&Token::LParen)?;
        let args = if matches!(self.peek(), Some(Token::RParen)) {
            Vec::new()
        } else {
            self.with_depth(|parser| {
                let mut args = Vec::new();
                args.push(parser.parse_ternary()?);
                if args.len() > MAX_FUNCTION_ARGS {
                    return Err(ParseError {
                        message: format!(
                            "function exceeds maximum of {MAX_FUNCTION_ARGS} arguments"
                        ),
                    });
                }
                while matches!(parser.peek(), Some(Token::Comma)) {
                    parser.advance();
                    args.push(parser.parse_ternary()?);
                    if args.len() > MAX_FUNCTION_ARGS {
                        return Err(ParseError {
                            message: format!(
                                "function exceeds maximum of {MAX_FUNCTION_ARGS} arguments"
                            ),
                        });
                    }
                }
                Ok(args)
            })?
        };
        self.expect(&Token::RParen)?;
        Ok(args)
    }

    /// Lookahead: detect the quantifier macro shape `(<expr>, <ident> -> <expr>)`.
    /// Scans forward from the current position (which is at the `(`) looking
    /// for the first top-level `,` followed by `Ident`, `Arrow`. This is a
    /// purely structural check; the actual parse is done by
    /// [`Self::parse_quantifier`]. Used by `parse_primary` for `all`/`any`/
    /// `count_where`.
    fn peek_quantifier_shape(&self) -> bool {
        let mut i = self.pos;
        if !matches!(self.tokens.get(i), Some(Token::LParen)) {
            return false;
        }
        i += 1;
        let mut depth: i32 = 0;
        while let Some(tok) = self.tokens.get(i) {
            match tok {
                Token::LParen | Token::LBracket => depth += 1,
                Token::RParen | Token::RBracket => {
                    if depth == 0 {
                        return false;
                    }
                    depth -= 1;
                }
                Token::Comma if depth == 0 => {
                    return matches!(
                        (self.tokens.get(i + 1), self.tokens.get(i + 2)),
                        (Some(Token::Ident(_)), Some(Token::Arrow))
                    );
                }
                _ => {}
            }
            i += 1;
        }
        false
    }

    /// Parse `(<collection>, <ident> -> <predicate>)`. The leading function
    /// name has already been consumed; the next token MUST be `(`.
    fn parse_quantifier(&mut self, kind: QuantifierKind) -> Result<Expr, ParseError> {
        self.expect(&Token::LParen)?;
        let (collection, var, predicate) = self.with_depth(|parser| {
            let collection = parser.parse_ternary()?;
            parser.expect(&Token::Comma)?;
            let var = match parser.advance() {
                Some(Token::Ident(name)) => name,
                Some(tok) => {
                    return Err(ParseError {
                        message: format!(
                            "expected identifier as quantifier bound variable, got '{tok}'"
                        ),
                    })
                }
                None => {
                    return Err(ParseError {
                        message: "expected identifier as quantifier bound variable".into(),
                    })
                }
            };
            parser.expect(&Token::Arrow)?;
            // The predicate is a full expression, so
            // local `:=` bindings are accepted inside quantifier predicates.
            let predicate = parser.parse_expression()?;
            Ok((collection, var, predicate))
        })?;
        self.expect(&Token::RParen)?;
        Ok(Expr::Quantifier {
            kind,
            collection: Box::new(collection),
            var,
            predicate: Box::new(predicate),
        })
    }

    // Precedence levels (lowest to highest):
    // 1.:= (assignment)
    // 2.?: (ternary)
    // 3. or
    // 4. and /;
    // 5. not (prefix)
    // 6. Comparison (==,!=, <, <=, >, >=, in) — non-associative
    // 7. Addition/Subtraction
    // 8. Multiplication/Division/Modulo
    // 9. Unary minus
    // 10. Postfix (dotted access, function calls, indexing)
    // 11. Primary (literals, idents, parens, lists)

    /// Top-level: handles leading assignments followed by a ternary_expr.
    /// Assignments are separated from the rest by `;`. The remaining
    /// expression (including any `;` as AND) is parsed via `parse_ternary`
    /// which delegates to `parse_or` and `parse_and` where `;` has the
    /// same precedence as `and`.
    fn parse_expression(&mut self) -> Result<Expr, ParseError> {
        if self.is_assignment_ahead() {
            let assign = self.parse_assignment()?;
            if matches!(self.peek(), Some(Token::Semicolon)) {
                self.advance();
                let rest = self.parse_expression()?;
                Ok(Expr::BinaryOp {
                    op: BinOp::And,
                    left: Box::new(assign),
                    right: Box::new(rest),
                })
            } else {
                Ok(assign)
            }
        } else {
            self.parse_ternary()
        }
    }

    fn is_assignment_ahead(&self) -> bool {
        matches!(
            (self.tokens.get(self.pos), self.tokens.get(self.pos + 1)),
            (Some(Token::Ident(_)), Some(Token::ColonEq))
        )
    }

    fn parse_assignment(&mut self) -> Result<Expr, ParseError> {
        let name = match self.advance() {
            Some(Token::Ident(n)) => n,
            _ => unreachable!(),
        };
        self.expect(&Token::ColonEq)?;
        // RHS consumes ternary/or/and but stops at `;` (which separates the
        // assignment from subsequent expressions in parse_expression).
        let value = self.parse_ternary_no_semi()?;
        Ok(Expr::Assignment {
            name,
            value: Box::new(value),
        })
    }

    fn parse_ternary(&mut self) -> Result<Expr, ParseError> {
        let expr = self.parse_or()?;
        if matches!(self.peek(), Some(Token::Question)) {
            self.advance();
            let then_expr = self.with_depth(|parser| parser.parse_ternary())?;
            self.expect(&Token::Colon)?;
            let else_expr = self.with_depth(|parser| parser.parse_ternary())?;
            Ok(Expr::Ternary {
                condition: Box::new(expr),
                then_expr: Box::new(then_expr),
                else_expr: Box::new(else_expr),
            })
        } else {
            Ok(expr)
        }
    }

    fn parse_ternary_no_semi(&mut self) -> Result<Expr, ParseError> {
        let expr = self.parse_or_no_semi()?;
        if matches!(self.peek(), Some(Token::Question)) {
            self.advance();
            let then_expr = self.with_depth(|parser| parser.parse_ternary_no_semi())?;
            self.expect(&Token::Colon)?;
            let else_expr = self.with_depth(|parser| parser.parse_ternary_no_semi())?;
            Ok(Expr::Ternary {
                condition: Box::new(expr),
                then_expr: Box::new(then_expr),
                else_expr: Box::new(else_expr),
            })
        } else {
            Ok(expr)
        }
    }

    fn parse_or(&mut self) -> Result<Expr, ParseError> {
        let mut left = self.parse_and()?;
        while matches!(self.peek(), Some(Token::Or)) {
            self.advance();
            let right = self.parse_and()?;
            left = Expr::BinaryOp {
                op: BinOp::Or,
                left: Box::new(left),
                right: Box::new(right),
            };
        }
        Ok(left)
    }

    /// Like `parse_or` but the inner `and` level does NOT consume `;`.
    /// Used for the RHS of `:=` so `x:= a or b; c` parses as `(x:= (a or b)); c`.
    fn parse_or_no_semi(&mut self) -> Result<Expr, ParseError> {
        let mut left = self.parse_and_no_semi()?;
        while matches!(self.peek(), Some(Token::Or)) {
            self.advance();
            let right = self.parse_and_no_semi()?;
            left = Expr::BinaryOp {
                op: BinOp::Or,
                left: Box::new(left),
                right: Box::new(right),
            };
        }
        Ok(left)
    }

    fn parse_and(&mut self) -> Result<Expr, ParseError> {
        let mut left = self.parse_not()?;
        // `;` and `and` have the same precedence (the spec level 7)
        while matches!(self.peek(), Some(Token::And) | Some(Token::Semicolon)) {
            self.advance();
            let right = self.parse_not()?;
            left = Expr::BinaryOp {
                op: BinOp::And,
                left: Box::new(left),
                right: Box::new(right),
            };
        }
        Ok(left)
    }

    /// Like `parse_and` but only consumes `and` keyword, NOT `;`.
    fn parse_and_no_semi(&mut self) -> Result<Expr, ParseError> {
        let mut left = self.parse_not()?;
        while matches!(self.peek(), Some(Token::And)) {
            self.advance();
            let right = self.parse_not()?;
            left = Expr::BinaryOp {
                op: BinOp::And,
                left: Box::new(left),
                right: Box::new(right),
            };
        }
        Ok(left)
    }

    fn parse_not(&mut self) -> Result<Expr, ParseError> {
        if matches!(self.peek(), Some(Token::Not)) {
            self.advance();
            let operand = self.with_depth(|parser| parser.parse_not())?;
            Ok(Expr::UnaryOp {
                op: UnOp::Not,
                operand: Box::new(operand),
            })
        } else {
            self.parse_comparison()
        }
    }

    fn parse_comparison(&mut self) -> Result<Expr, ParseError> {
        let left = self.parse_addition()?;

        // Non-associative: only one comparison operator allowed
        match self.peek() {
            Some(Token::Eq) => {
                self.advance();
                let right = self.parse_addition()?;
                Ok(Expr::BinaryOp {
                    op: BinOp::Eq,
                    left: Box::new(left),
                    right: Box::new(right),
                })
            }
            Some(Token::Neq) => {
                self.advance();
                let right = self.parse_addition()?;
                Ok(Expr::BinaryOp {
                    op: BinOp::Neq,
                    left: Box::new(left),
                    right: Box::new(right),
                })
            }
            Some(Token::Lt) => {
                self.advance();
                let right = self.parse_addition()?;
                Ok(Expr::BinaryOp {
                    op: BinOp::Lt,
                    left: Box::new(left),
                    right: Box::new(right),
                })
            }
            Some(Token::Lte) => {
                self.advance();
                let right = self.parse_addition()?;
                Ok(Expr::BinaryOp {
                    op: BinOp::Lte,
                    left: Box::new(left),
                    right: Box::new(right),
                })
            }
            Some(Token::Gt) => {
                self.advance();
                let right = self.parse_addition()?;
                Ok(Expr::BinaryOp {
                    op: BinOp::Gt,
                    left: Box::new(left),
                    right: Box::new(right),
                })
            }
            Some(Token::Gte) => {
                self.advance();
                let right = self.parse_addition()?;
                Ok(Expr::BinaryOp {
                    op: BinOp::Gte,
                    left: Box::new(left),
                    right: Box::new(right),
                })
            }
            Some(Token::In) => {
                self.advance();
                let right = self.parse_addition()?;
                Ok(Expr::BinaryOp {
                    op: BinOp::In,
                    left: Box::new(left),
                    right: Box::new(right),
                })
            }
            _ => Ok(left),
        }
    }

    fn parse_addition(&mut self) -> Result<Expr, ParseError> {
        let mut left = self.parse_multiplication()?;
        while matches!(self.peek(), Some(Token::Plus) | Some(Token::Minus)) {
            let op = match self.advance().unwrap() {
                Token::Plus => BinOp::Add,
                Token::Minus => BinOp::Sub,
                _ => unreachable!(),
            };
            let right = self.parse_multiplication()?;
            left = Expr::BinaryOp {
                op,
                left: Box::new(left),
                right: Box::new(right),
            };
        }
        Ok(left)
    }

    fn parse_multiplication(&mut self) -> Result<Expr, ParseError> {
        let mut left = self.parse_unary_minus()?;
        while matches!(
            self.peek(),
            Some(Token::Star) | Some(Token::Slash) | Some(Token::Percent)
        ) {
            let op = match self.advance().unwrap() {
                Token::Star => BinOp::Mul,
                Token::Slash => BinOp::Div,
                Token::Percent => BinOp::Mod,
                _ => unreachable!(),
            };
            let right = self.parse_unary_minus()?;
            left = Expr::BinaryOp {
                op,
                left: Box::new(left),
                right: Box::new(right),
            };
        }
        Ok(left)
    }

    fn parse_unary_minus(&mut self) -> Result<Expr, ParseError> {
        if matches!(self.peek(), Some(Token::Minus)) {
            self.advance();
            let operand = self.with_depth(|parser| parser.parse_unary_minus())?;
            Ok(Expr::UnaryOp {
                op: UnOp::Neg,
                operand: Box::new(operand),
            })
        } else {
            self.parse_postfix()
        }
    }

    fn parse_postfix(&mut self) -> Result<Expr, ParseError> {
        let mut expr = self.parse_primary()?;

        while matches!(self.peek(), Some(Token::Dot) | Some(Token::LBracket)) {
            if matches!(self.peek(), Some(Token::LBracket)) {
                self.advance();
                let index = self.with_depth(|parser| parser.parse_ternary())?;
                self.expect(&Token::RBracket)?;
                expr = Expr::Index {
                    object: Box::new(expr),
                    index: Box::new(index),
                };
                continue;
            }

            self.advance();

            // `<ident>.@<field>` reads variable metadata.
            // Only valid when the LHS is a bare identifier — `(expr).@field`
            // is a parse error so the namespace check stays statically
            // resolvable to a declared variable.
            if matches!(self.peek(), Some(Token::At)) {
                self.advance();
                let field = match self.advance() {
                    Some(Token::Ident(name)) => name,
                    Some(tok) => {
                        return Err(ParseError {
                            message: format!("expected identifier after '.@', got '{tok}'"),
                        })
                    }
                    None => {
                        return Err(ParseError {
                            message: "expected identifier after '.@'".into(),
                        })
                    }
                };
                let var =
                    match expr {
                        Expr::Ident(name) => name,
                        _ => return Err(ParseError {
                            message:
                                "metadata namespace '@' is only valid on a bare variable identifier"
                                    .into(),
                        }),
                    };
                expr = Expr::MetaField { var, field };
                continue;
            }

            let field = match self.advance() {
                Some(Token::Ident(name)) => name,
                Some(tok) => {
                    return Err(ParseError {
                        message: format!("expected identifier after '.', got '{tok}'"),
                    })
                }
                None => {
                    return Err(ParseError {
                        message: "expected identifier after '.'".into(),
                    })
                }
            };

            if matches!(self.peek(), Some(Token::LParen)) {
                let args = self.parse_function_args()?;

                let fn_name = match &expr {
                    Expr::Ident(root) => format!("{root}.{field}"),
                    Expr::DottedAccess { root, path } => {
                        if let Expr::Ident(root_name) = root.as_ref() {
                            let mut name = root_name.clone();
                            for p in path {
                                name.push('.');
                                name.push_str(p);
                            }
                            name.push('.');
                            name.push_str(&field);
                            name
                        } else {
                            field.clone()
                        }
                    }
                    _ => field.clone(),
                };
                // Spec/expressions/LANGUAGE.md: event metadata is
                // accessed through the @-prefixed metadata namespace.
                if fn_name == "event.fired" {
                    return Err(ParseError {
                        message: "event.fired must be written as @event.fired (the @-prefix marks metadata access). See spec/expressions/LANGUAGE.md.".into(),
                    });
                }
                expr = Expr::FnCall {
                    name: fn_name,
                    args,
                };
            } else {
                match expr {
                    Expr::DottedAccess { root, mut path } => {
                        path.push(field);
                        expr = Expr::DottedAccess { root, path };
                    }
                    other => {
                        expr = Expr::DottedAccess {
                            root: Box::new(other),
                            path: vec![field],
                        };
                    }
                }
            }
        }

        Ok(expr)
    }

    fn parse_primary(&mut self) -> Result<Expr, ParseError> {
        match self.peek().cloned() {
            Some(Token::Number(n)) => {
                self.advance();
                Ok(Expr::Literal(LitValue::Number(n)))
            }
            Some(Token::Str(s)) => {
                self.advance();
                Ok(Expr::Literal(LitValue::Str(s)))
            }
            Some(Token::Bool(b)) => {
                self.advance();
                Ok(Expr::Literal(LitValue::Bool(b)))
            }
            Some(Token::Null) => {
                self.advance();
                Ok(Expr::Literal(LitValue::Null))
            }
            Some(Token::Ident(name)) => {
                self.advance();
                if matches!(self.peek(), Some(Token::LParen)) {
                    // Quantifier macros are recognized only when followed by
                    // `(` AND the second arg starts with `<ident> ->...`.
                    // Otherwise fall through to a normal function call so a
                    // user-declared variable named `all`/`any`/`count_where`
                    // resolves correctly (LANGUAGE.md last paragraph).
                    if let Some(kind) = quantifier_kind(&name) {
                        if self.peek_quantifier_shape() {
                            return self.parse_quantifier(kind);
                        }
                    }
                    let args = self.parse_function_args()?;
                    Ok(Expr::FnCall { name, args })
                } else {
                    Ok(Expr::Ident(name))
                }
            }
            Some(Token::At) => {
                // `@`-prefixed identifier: a runtime-bound name
                // (one of @tool / @endpoint / @agent / @context / @result,
                // the @event function namespace, or the @current /
                // @incoming merge locals inside `update:` expressions).
                // The leading `@` cannot collide with author-declared
                // names, so the parser produces an `Expr::Ident` whose
                // name carries the `@` prefix verbatim — downstream
                // resolution in the evaluator dispatches by that prefix.
                self.advance();
                let raw = match self.advance() {
                    Some(Token::Ident(name)) => name,
                    Some(tok) => {
                        return Err(ParseError {
                            message: format!("expected identifier after '@', got '{tok}'"),
                        })
                    }
                    None => {
                        return Err(ParseError {
                            message: "expected identifier after '@'".into(),
                        })
                    }
                };
                let prefixed = format!("@{raw}");
                if matches!(self.peek(), Some(Token::LParen)) {
                    let args = self.parse_function_args()?;
                    Ok(Expr::FnCall {
                        name: prefixed,
                        args,
                    })
                } else {
                    Ok(Expr::Ident(prefixed))
                }
            }
            Some(Token::LParen) => {
                self.advance();
                let expr = self.with_depth(|parser| parser.parse_ternary())?;
                self.expect(&Token::RParen)?;
                Ok(expr)
            }
            Some(Token::LBracket) => {
                self.advance();
                let items = if matches!(self.peek(), Some(Token::RBracket)) {
                    Vec::new()
                } else {
                    self.with_depth(|parser| {
                        let mut items = Vec::new();
                        items.push(parser.parse_ternary()?);
                        if items.len() > MAX_LIST_ELEMENTS {
                            return Err(ParseError {
                                message: format!(
                                    "list exceeds maximum of {MAX_LIST_ELEMENTS} elements"
                                ),
                            });
                        }
                        while matches!(parser.peek(), Some(Token::Comma)) {
                            parser.advance();
                            items.push(parser.parse_ternary()?);
                            if items.len() > MAX_LIST_ELEMENTS {
                                return Err(ParseError {
                                    message: format!(
                                        "list exceeds maximum of {MAX_LIST_ELEMENTS} elements"
                                    ),
                                });
                            }
                        }
                        Ok(items)
                    })?
                };
                self.expect(&Token::RBracket)?;
                Ok(Expr::List(items))
            }
            Some(tok) => Err(ParseError {
                message: format!("unexpected token '{tok}'"),
            }),
            None => Err(ParseError {
                message: "unexpected end of expression".into(),
            }),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    // Helper to reduce test verbosity
    fn lit_num(n: f64) -> Expr {
        Expr::Literal(LitValue::Number(n))
    }
    fn lit_str(s: &str) -> Expr {
        Expr::Literal(LitValue::Str(s.into()))
    }
    fn lit_bool(b: bool) -> Expr {
        Expr::Literal(LitValue::Bool(b))
    }
    fn ident(s: &str) -> Expr {
        Expr::Ident(s.into())
    }
    fn bin(op: BinOp, left: Expr, right: Expr) -> Expr {
        Expr::BinaryOp {
            op,
            left: Box::new(left),
            right: Box::new(right),
        }
    }

    // ── Operator Precedence ─────────────────────────────────────

    #[test]
    fn test_and_binds_tighter_than_or() {
        // "a and b or c" → Or(And(a, b), c)
        let ast = parse("a and b or c").unwrap();
        assert_eq!(
            ast,
            bin(
                BinOp::Or,
                bin(BinOp::And, ident("a"), ident("b")),
                ident("c")
            )
        );
    }

    #[test]
    fn test_or_is_left_associative() {
        // "a or b or c" → Or(Or(a, b), c)
        let ast = parse("a or b or c").unwrap();
        assert_eq!(
            ast,
            bin(
                BinOp::Or,
                bin(BinOp::Or, ident("a"), ident("b")),
                ident("c")
            )
        );
    }

    #[test]
    fn test_comparison_before_logical() {
        // "x > 5 and y < 10" → And(Gt(x, 5), Lt(y, 10))
        let ast = parse("x > 5 and y < 10").unwrap();
        assert_eq!(
            ast,
            bin(
                BinOp::And,
                bin(BinOp::Gt, ident("x"), lit_num(5.0)),
                bin(BinOp::Lt, ident("y"), lit_num(10.0))
            )
        );
    }

    #[test]
    fn test_arithmetic_precedence() {
        // "a + b * c" → Add(a, Mul(b, c))
        let ast = parse("a + b * c").unwrap();
        assert_eq!(
            ast,
            bin(
                BinOp::Add,
                ident("a"),
                bin(BinOp::Mul, ident("b"), ident("c"))
            )
        );
    }

    #[test]
    fn test_not_unary() {
        // "not x" → Not(x)
        let ast = parse("not x").unwrap();
        assert_eq!(
            ast,
            Expr::UnaryOp {
                op: UnOp::Not,
                operand: Box::new(ident("x")),
            }
        );
    }

    #[test]
    fn test_not_below_comparison() {
        // "not a == b" → Not(Eq(a, b)) — not wraps the full comparison
        // This is the NEW behavior: not is below comparison in precedence
        let ast = parse("not a == b").unwrap();
        assert_eq!(
            ast,
            Expr::UnaryOp {
                op: UnOp::Not,
                operand: Box::new(bin(BinOp::Eq, ident("a"), ident("b"))),
            }
        );
    }

    #[test]
    fn test_not_in_decomposed() {
        // "not x in ['a']" → Not(In(x, ['a']))
        // Decomposed negation: not is prefix, in is comparison
        let ast = parse("not x in ['a']").unwrap();
        assert_eq!(
            ast,
            Expr::UnaryOp {
                op: UnOp::Not,
                operand: Box::new(bin(BinOp::In, ident("x"), Expr::List(vec![lit_str("a")]))),
            }
        );
    }

    // ── Semicolon as AND ────────────────────────────────────────

    #[test]
    fn test_semicolon_as_and() {
        let ast = parse("a > 5; b < 10").unwrap();
        assert_eq!(
            ast,
            bin(
                BinOp::And,
                bin(BinOp::Gt, ident("a"), lit_num(5.0)),
                bin(BinOp::Lt, ident("b"), lit_num(10.0))
            )
        );
    }

    #[test]
    fn test_semicolon_same_precedence_as_and() {
        // "a; b or c" should parse like "a and b or c" → Or(And(a, b), c)
        let ast = parse("a; b or c").unwrap();
        assert_eq!(
            ast,
            bin(
                BinOp::Or,
                bin(BinOp::And, ident("a"), ident("b")),
                ident("c")
            )
        );
    }

    #[test]
    fn test_semicolon_inside_parens() {
        // `;` works inside parentheses (same level as `and`)
        let ast = parse("(a; b)").unwrap();
        assert_eq!(ast, bin(BinOp::And, ident("a"), ident("b")));
    }

    // ── Modulo ──────────────────────────────────────────────────

    #[test]
    fn test_modulo_precedence() {
        // "x % 2 == 0" → Eq(Mod(x, 2), 0)
        let ast = parse("x % 2 == 0").unwrap();
        assert_eq!(
            ast,
            bin(
                BinOp::Eq,
                bin(BinOp::Mod, ident("x"), lit_num(2.0)),
                lit_num(0.0)
            )
        );
    }

    // ── Variable Binding ────────────────────────────────────────

    #[test]
    fn test_assignment() {
        let ast = parse("bal := 100").unwrap();
        assert_eq!(
            ast,
            Expr::Assignment {
                name: "bal".into(),
                value: Box::new(lit_num(100.0)),
            }
        );
    }

    #[test]
    fn test_ternary_simple() {
        let ast = parse("x ? 1 : 0").unwrap();
        assert_eq!(
            ast,
            Expr::Ternary {
                condition: Box::new(ident("x")),
                then_expr: Box::new(lit_num(1.0)),
                else_expr: Box::new(lit_num(0.0)),
            }
        );
    }

    #[test]
    fn test_ternary_right_associative() {
        let ast = parse("a ? b : c ? d : e").unwrap();
        assert_eq!(
            ast,
            Expr::Ternary {
                condition: Box::new(ident("a")),
                then_expr: Box::new(ident("b")),
                else_expr: Box::new(Expr::Ternary {
                    condition: Box::new(ident("c")),
                    then_expr: Box::new(ident("d")),
                    else_expr: Box::new(ident("e")),
                }),
            }
        );
    }

    #[test]
    fn test_ternary_with_comparison() {
        let ast = parse("x > 0 ? 'positive' : 'non-positive'").unwrap();
        match ast {
            Expr::Ternary { condition, .. } => {
                assert!(matches!(*condition, Expr::BinaryOp { op: BinOp::Gt, .. }));
            }
            _ => panic!("expected ternary"),
        }
    }

    // ── Collection Operators ────────────────────────────────────

    #[test]
    fn test_in_with_list() {
        let ast = parse("x in [1, 2, 3]").unwrap();
        assert_eq!(
            ast,
            bin(
                BinOp::In,
                ident("x"),
                Expr::List(vec![lit_num(1.0), lit_num(2.0), lit_num(3.0)])
            )
        );
    }

    #[test]
    fn test_in_with_identifier_rhs() {
        // "'HIPAA' in active_compliance_contexts"
        let ast = parse("'HIPAA' in active_compliance_contexts").unwrap();
        assert_eq!(
            ast,
            bin(
                BinOp::In,
                lit_str("HIPAA"),
                ident("active_compliance_contexts")
            )
        );
    }

    #[test]
    fn test_index_number() {
        let ast = parse("arr[0]").unwrap();
        assert_eq!(
            ast,
            Expr::Index {
                object: Box::new(ident("arr")),
                index: Box::new(lit_num(0.0)),
            }
        );
    }

    #[test]
    fn test_index_string_key() {
        let ast = parse("obj['key']").unwrap();
        assert_eq!(
            ast,
            Expr::Index {
                object: Box::new(ident("obj")),
                index: Box::new(lit_str("key")),
            }
        );
    }

    #[test]
    fn test_chained_index() {
        let ast = parse("a[0][1]").unwrap();
        assert_eq!(
            ast,
            Expr::Index {
                object: Box::new(Expr::Index {
                    object: Box::new(ident("a")),
                    index: Box::new(lit_num(0.0)),
                }),
                index: Box::new(lit_num(1.0)),
            }
        );
    }

    // ── Dotted Access ───────────────────────────────────────────

    #[test]
    fn test_dotted_two_levels() {
        let ast = parse("user.role").unwrap();
        assert_eq!(
            ast,
            Expr::DottedAccess {
                root: Box::new(ident("user")),
                path: vec!["role".into()],
            }
        );
    }

    #[test]
    fn test_dotted_three_levels() {
        let ast = parse("account.owner.region").unwrap();
        assert_eq!(
            ast,
            Expr::DottedAccess {
                root: Box::new(ident("account")),
                path: vec!["owner".into(), "region".into()],
            }
        );
    }

    #[test]
    fn test_dotted_in_comparison() {
        let ast = parse("user.role == 'admin'").unwrap();
        assert_eq!(
            ast,
            bin(
                BinOp::Eq,
                Expr::DottedAccess {
                    root: Box::new(ident("user")),
                    path: vec!["role".into()],
                },
                lit_str("admin")
            )
        );
    }

    // ── Functions ───────────────────────────────────────────────

    #[test]
    fn test_simple_function() {
        let ast = parse("contains(name, 'test')").unwrap();
        assert_eq!(
            ast,
            Expr::FnCall {
                name: "contains".into(),
                args: vec![ident("name"), lit_str("test")],
            }
        );
    }

    #[test]
    fn test_dotted_function_time_now() {
        let ast = parse("time.now()").unwrap();
        assert_eq!(
            ast,
            Expr::FnCall {
                name: "time.now".into(),
                args: vec![],
            }
        );
    }

    #[test]
    fn test_dotted_function_regex_match() {
        // Single-quoted strings are raw: \d+ passes through literally
        let ast = parse("regex.match('\\d+', x)").unwrap();
        assert_eq!(
            ast,
            Expr::FnCall {
                name: "regex.match".into(),
                args: vec![lit_str("\\d+"), ident("x")],
            }
        );
    }

    #[test]
    fn test_dotted_function_object_get() {
        let ast = parse("object.get(account, 'balance', 0)").unwrap();
        assert_eq!(
            ast,
            Expr::FnCall {
                name: "object.get".into(),
                args: vec![ident("account"), lit_str("balance"), lit_num(0.0)],
            }
        );
    }

    #[test]
    fn test_at_event_fired_function() {
        let ast = parse("@event.fired('session.start')").unwrap();
        assert_eq!(
            ast,
            Expr::FnCall {
                name: "@event.fired".into(),
                args: vec![lit_str("session.start")],
            }
        );
    }

    #[test]
    fn test_bare_event_fired_rejected() {
        let err = parse("event.fired('session.start')").unwrap_err();
        assert_eq!(
            err.message,
            "event.fired must be written as @event.fired (the @-prefix marks metadata access). See spec/expressions/LANGUAGE.md."
        );
    }

    #[test]
    fn test_time_now_dotted_access() {
        // "time.now().hour >= 9" — function call followed by dotted access
        let ast = parse("time.now().hour >= 9").unwrap();
        assert_eq!(
            ast,
            bin(
                BinOp::Gte,
                Expr::DottedAccess {
                    root: Box::new(Expr::FnCall {
                        name: "time.now".into(),
                        args: vec![],
                    }),
                    path: vec!["hour".into()],
                },
                lit_num(9.0)
            )
        );
    }

    #[test]
    fn test_time_duration_with_arg() {
        let ast = parse("time.duration('30m')").unwrap();
        assert_eq!(
            ast,
            Expr::FnCall {
                name: "time.duration".into(),
                args: vec![lit_str("30m")],
            }
        );
    }

    #[test]
    fn test_duration_arithmetic() {
        // "time.now - session_start < time.duration('30m')"
        let ast = parse("time.now() - session_start < time.duration('30m')").unwrap();
        assert_eq!(
            ast,
            bin(
                BinOp::Lt,
                bin(
                    BinOp::Sub,
                    Expr::FnCall {
                        name: "time.now".into(),
                        args: vec![],
                    },
                    ident("session_start"),
                ),
                Expr::FnCall {
                    name: "time.duration".into(),
                    args: vec![lit_str("30m")],
                },
            )
        );
    }

    // ── Null comparisons (replacing IS NULL / IS NOT NULL) ──────

    #[test]
    fn test_null_equality() {
        let ast = parse("x == null").unwrap();
        assert_eq!(
            ast,
            bin(BinOp::Eq, ident("x"), Expr::Literal(LitValue::Null))
        );
    }

    #[test]
    fn test_null_inequality() {
        let ast = parse("x != null").unwrap();
        assert_eq!(
            ast,
            bin(BinOp::Neq, ident("x"), Expr::Literal(LitValue::Null))
        );
    }

    #[test]
    fn test_is_null_function() {
        let ast = parse("is_null(x)").unwrap();
        assert_eq!(
            ast,
            Expr::FnCall {
                name: "is_null".into(),
                args: vec![ident("x")],
            }
        );
    }

    // ── Error Recovery ──────────────────────────────────────────

    #[test]
    fn test_empty_input_is_true() {
        // Empty expression evaluates as "no constraint" → true
        let ast = parse("").unwrap();
        assert_eq!(ast, lit_bool(true));
    }

    #[test]
    fn test_trailing_operator_error() {
        let err = parse("a and").unwrap_err();
        assert!(
            err.message.contains("unexpected end"),
            "got: {}",
            err.message
        );
    }

    #[test]
    fn test_mismatched_bracket_error() {
        let err = parse("x in [1, 2").unwrap_err();
        assert!(
            err.message.contains(']') || err.message.contains("expected"),
            "got: {}",
            err.message
        );
    }

    #[test]
    fn test_expression_too_long() {
        let long = "a".repeat(4097);
        assert!(parse(&long).is_err());
    }

    #[test]
    fn test_nesting_depth_limit() {
        let expr = "(".repeat(33) + "x" + &")".repeat(33);
        assert!(parse(&expr).is_err());
    }

    #[test]
    fn test_deeply_nested_function_calls() {
        let mut expr = "x".to_string();
        for _ in 0..33 {
            expr = format!("abs({expr})");
        }
        assert!(parse(&expr).is_err());
    }

    #[test]
    fn test_deeply_nested_indexing() {
        let mut expr = "x".to_string();
        for _ in 0..33 {
            expr = format!("a[{expr}]");
        }
        assert!(parse(&expr).is_err());
    }

    #[test]
    fn test_moderate_nesting_works() {
        let mut expr = "x".to_string();
        for _ in 0..15 {
            expr = format!("({expr})");
        }
        assert!(parse(&expr).is_ok());
    }

    // ── Complex Real-World ──────────────────────────────────────

    #[test]
    fn test_bank_transfer_requires() {
        let ast =
            parse("fraud_score < 75 and transaction_velocity < 10 and geographic_anomaly == false")
                .unwrap();
        assert_eq!(
            ast,
            bin(
                BinOp::And,
                bin(
                    BinOp::And,
                    bin(BinOp::Lt, ident("fraud_score"), lit_num(75.0)),
                    bin(BinOp::Lt, ident("transaction_velocity"), lit_num(10.0)),
                ),
                bin(BinOp::Eq, ident("geographic_anomaly"), lit_bool(false)),
            )
        );
    }

    #[test]
    fn test_parenthesized_override() {
        // "a or (b and c)" → Or(a, And(b, c))
        let ast = parse("a or (b and c)").unwrap();
        assert_eq!(
            ast,
            bin(
                BinOp::Or,
                ident("a"),
                bin(BinOp::And, ident("b"), ident("c"))
            )
        );
    }

    #[test]
    fn test_unary_minus() {
        let ast = parse("-5").unwrap();
        assert_eq!(
            ast,
            Expr::UnaryOp {
                op: UnOp::Neg,
                operand: Box::new(lit_num(5.0)),
            }
        );
    }

    // ── Precedence: not below comparison ────────────────────────

    #[test]
    fn test_not_negates_in_check() {
        // "not x in ['a', 'b']" → not (x in ['a', 'b'])
        let ast = parse("not x in ['a', 'b']").unwrap();
        assert_eq!(
            ast,
            Expr::UnaryOp {
                op: UnOp::Not,
                operand: Box::new(bin(
                    BinOp::In,
                    ident("x"),
                    Expr::List(vec![lit_str("a"), lit_str("b")])
                )),
            }
        );
    }

    #[test]
    fn test_a_or_b_and_c_precedence() {
        // "a or b and c" → Or(a, And(b, c))
        let ast = parse("a or b and c").unwrap();
        assert_eq!(
            ast,
            bin(
                BinOp::Or,
                ident("a"),
                bin(BinOp::And, ident("b"), ident("c"))
            )
        );
    }

    #[test]
    fn test_arithmetic_comparison_logical_precedence() {
        // "a + b < 100 and c" → And(Lt(Add(a, b), 100), c)
        let ast = parse("a + b < 100 and c").unwrap();
        assert_eq!(
            ast,
            bin(
                BinOp::And,
                bin(
                    BinOp::Lt,
                    bin(BinOp::Add, ident("a"), ident("b")),
                    lit_num(100.0)
                ),
                ident("c")
            )
        );
    }

    #[test]
    fn test_ternary_with_index() {
        let ast = parse("arr[0] ? 'yes' : 'no'").unwrap();
        match ast {
            Expr::Ternary { condition, .. } => {
                assert!(matches!(*condition, Expr::Index { .. }));
            }
            _ => panic!("expected ternary"),
        }
    }

    #[test]
    fn test_ternary_nested_in_function_args() {
        let ast = parse("f(x ? 1 : 0)").unwrap();
        assert_eq!(
            ast,
            Expr::FnCall {
                name: "f".into(),
                args: vec![Expr::Ternary {
                    condition: Box::new(ident("x")),
                    then_expr: Box::new(lit_num(1.0)),
                    else_expr: Box::new(lit_num(0.0)),
                }],
            }
        );
    }

    #[test]
    fn test_index_on_function_result() {
        let ast = parse("f()[0]").unwrap();
        assert_eq!(
            ast,
            Expr::Index {
                object: Box::new(Expr::FnCall {
                    name: "f".into(),
                    args: vec![],
                }),
                index: Box::new(lit_num(0.0)),
            }
        );
    }

    #[test]
    fn test_assignment_with_ternary_rhs() {
        let ast = parse("v := x ? 1 : 0; v > 0").unwrap();
        assert_eq!(
            ast,
            Expr::BinaryOp {
                op: BinOp::And,
                left: Box::new(Expr::Assignment {
                    name: "v".into(),
                    value: Box::new(Expr::Ternary {
                        condition: Box::new(ident("x")),
                        then_expr: Box::new(lit_num(1.0)),
                        else_expr: Box::new(lit_num(0.0)),
                    }),
                }),
                right: Box::new(bin(BinOp::Gt, ident("v"), lit_num(0.0))),
            }
        );
    }

    #[test]
    fn test_list_literal_limit() {
        let expr = format!(
            "[{}]",
            (0..65)
                .map(|n| n.to_string())
                .collect::<Vec<_>>()
                .join(", ")
        );
        let err = parse(&expr).unwrap_err();
        assert!(err.message.contains("list exceeds maximum"));
    }
}
