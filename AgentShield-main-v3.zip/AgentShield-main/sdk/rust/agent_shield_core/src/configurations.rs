//! `configurations[]` block — type-discriminated routing.
//!
//! This module models the static configuration shape; runtime dispatch
//! lives in [`crate::resolver_runtime::delegate_kind`]. The deserializer
//! enforces the routing matrix:
//!
//! - `llm` requires `model`
//! - `http_endpoint` requires `endpoint`
//! - `mcp_server` requires `tool` plus an endpoint or registered provider
//! - `a2a_agent` requires `agent_id` plus endpoint/provider
//! - `default: true` is rejected on `http_endpoint`/`mcp_server`/`a2a_agent`
//!
//! Same-`id` redefinition across the `extends:` chain is last-wins per
//! field, but `type:` MUST NOT change — enforced in `merge.rs`.

use std::collections::HashMap;

use serde::{Deserialize, Serialize};

use super::resources::LogBlock;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ConfigurationType {
    Llm,
    Classifier,
    HttpEndpoint,
    McpServer,
    A2aAgent,
}

impl ConfigurationType {
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Llm => "llm",
            Self::Classifier => "classifier",
            Self::HttpEndpoint => "http_endpoint",
            Self::McpServer => "mcp_server",
            Self::A2aAgent => "a2a_agent",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "UPPERCASE")]
pub enum HttpMethod {
    Get,
    Post,
}

/// `on_error` policy on a configuration entry.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ConfigOnError {
    Block,
    Allow,
}

/// One entry in the `configurations[]` block.
///
/// Field validity per the routing matrix is enforced at deserialization time.
/// Any field set on the wrong type raises a clear schema error.
#[derive(Debug, Clone, Serialize, PartialEq)]
#[serde(deny_unknown_fields)]
pub struct ShieldConfiguration {
    pub id: String,
    #[serde(rename = "type")]
    pub config_type: ConfigurationType,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub default: Option<bool>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub provider: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub provider_config: Option<serde_json::Value>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub endpoint: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub timeout: Option<u32>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub on_error: Option<ConfigOnError>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub on_error_log: Option<LogBlock>,
    #[serde(default, skip_serializing_if = "HashMap::is_empty")]
    pub headers: HashMap<String, String>,

    /// Transport-level trust-boundary hardening.
    /// When omitted the runtime applies the fail-closed default:
    /// HTTPS required for any non-localhost URL, system trust store
    /// only, no retry on transport failures. Optional, but the
    /// loader will still enforce the HTTPS requirement against
    /// `endpoint` even when the block is absent — the block is
    /// only how authors opt in to looser behavior.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub transport: Option<crate::resolver_trust::TransportConfig>,

    // type=llm
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub model: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub max_tokens: Option<u32>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub api_key_env: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub metadata: Option<serde_json::Value>,

    // type=classifier
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub threshold: Option<f64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub method: Option<HttpMethod>,
    /// Per-category score thresholds for classifiers that emit
    /// per-category scores. When present and non-empty,
    /// the bundled provider implementations restrict their failure
    /// check to listed categories — unlisted high scores cannot
    /// trigger the verdict via the global `threshold` field. When
    /// absent or empty, the global `threshold` plus the provider's
    /// native flagging signal apply.
    #[serde(default, skip_serializing_if = "HashMap::is_empty")]
    pub category_thresholds: HashMap<String, f64>,

    // type=a2a_agent
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub agent_id: Option<String>,

    // type=mcp_server
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub tool: Option<String>,
}

impl ShieldConfiguration {
    /// Validates required fields on a merged configuration.
    /// Must be called post-merge ([`crate::merge::merge_chain`]); a child overlay
    /// may legitimately omit fields the parent supplied.
    pub fn validate_required_fields(&self) -> std::result::Result<(), String> {
        match self.config_type {
            ConfigurationType::Llm => {
                if self.model.is_none() {
                    return Err(format!(
                        "configuration `{}` of type `llm`: `model` is required",
                        self.id
                    ));
                }
            }
            ConfigurationType::Classifier => {
                // endpoint OR registered provider; we cannot verify provider
                // registration at load time without a registry, so accept
                // either being present.
                if self.endpoint.is_none() && self.provider.is_none() {
                    return Err(format!(
                        "configuration `{}` of type `classifier`: requires `endpoint` or a registered `provider`",
                        self.id
                    ));
                }
            }
            ConfigurationType::HttpEndpoint => {
                if self.endpoint.is_none() {
                    return Err(format!(
                        "configuration `{}` of type `http_endpoint`: `endpoint` is required",
                        self.id
                    ));
                }
            }
            ConfigurationType::McpServer => {
                if self.tool.is_none() {
                    return Err(format!(
                        "configuration `{}` of type `mcp_server`: `tool` is required",
                        self.id
                    ));
                }
                if self.endpoint.is_none() && self.provider.is_none() {
                    return Err(format!(
                        "configuration `{}` of type `mcp_server`: requires `endpoint` or a registered `provider`",
                        self.id
                    ));
                }
            }
            ConfigurationType::A2aAgent => {
                if self.agent_id.is_none() {
                    return Err(format!(
                        "configuration `{}` of type `a2a_agent`: `agent_id` is required",
                        self.id
                    ));
                }
                if self.endpoint.is_none() && self.provider.is_none() {
                    return Err(format!(
                        "configuration `{}` of type `a2a_agent`: requires `endpoint` or a registered `provider`",
                        self.id
                    ));
                }
            }
        }
        Ok(())
    }
    /// Post-interpolation validation. Called after
    /// [`crate::merge::interpolate_env`] has resolved every
    /// `${@env.NAME}` placeholder.
    ///
    /// Two checks:
    ///
    /// 1. Endpoint scheme/host validation — deferred from the per-file
    ///    deserializer because authors may write `endpoint: "${@env.MY_URL}"`.
    ///
    /// 2. Sensitive-header empty-value rejection — an empty resolved value
    ///    in a header whose name matches `^(authorization|x-api-key|x-auth-token|cookie)$`
    ///    (case-insensitive) MUST fail rather than transmit a blank header.
    pub(crate) fn validate_after_interpolation(&self) -> std::result::Result<(), String> {
        if let Some(endpoint) = self.endpoint.as_deref() {
            let transport = self.transport.clone().unwrap_or_default();
            transport
                .validate_endpoint(endpoint)
                .map_err(|e| format!("configuration `{}`: {}", self.id, e))?;
        }
        for (name, value) in &self.headers {
            if is_sensitive_header_name(name) && value.trim().is_empty() {
                return Err(format!(
                    "configuration `{}`: header `{}` resolved to an empty value after \
                     `${{@env.*}}` interpolation; sensitive auth headers MUST NOT be \
                     transmitted blank",
                    self.id, name
                ));
            }
        }
        Ok(())
    }
}

impl ShieldConfiguration {
    /// Serialize this entry into a `serde_json::Value` containing every
    /// populated field across every `type:` variant — including
    /// classifier-specific (`headers`, `threshold`, `category_thresholds`,
    /// `method`), HTTP-endpoint, MCP, and A2A fields — so language
    /// bindings that need the full untyped view (notably the Node /
    /// .NET / Python `Runtime.configuration(id)` accessor) share one
    /// canonical shape and cannot drift.
    ///
    /// Absent optionals are omitted entirely (not emitted as `null`)
    /// so hosts can use idiomatic `get(key, default)` lookups without
    /// distinguishing "missing" from "explicitly null". Field ordering
    /// is insertion-stable per `serde_json::Map`'s default behavior,
    /// matching the byte layout the Python pyo3 helper produces. This
    /// is the language-agnostic counterpart to the pyo3
    /// `shield_configuration_to_pyobject` helper.
    ///
    /// Cross-SDK byte equivalence: every binding (pyo3 / napi-rs /
    /// C ABI for .NET) routes through this single function so
    /// `Runtime.configuration(id)` returns identical JSON across
    /// Python, Node, and .NET for the same merged YAML.
    pub fn to_full_json_value(&self) -> serde_json::Value {
        let mut map = serde_json::Map::new();
        map.insert("id".into(), serde_json::Value::String(self.id.clone()));
        map.insert(
            "type".into(),
            serde_json::Value::String(self.config_type.as_str().to_string()),
        );
        if let Some(def) = self.default {
            map.insert("default".into(), serde_json::Value::Bool(def));
        }
        if let Some(ref p) = self.provider {
            map.insert("provider".into(), serde_json::Value::String(p.clone()));
        }
        if let Some(ref pc) = self.provider_config {
            map.insert("provider_config".into(), pc.clone());
        }
        if let Some(ref e) = self.endpoint {
            map.insert("endpoint".into(), serde_json::Value::String(e.clone()));
        }
        if let Some(t) = self.timeout {
            map.insert("timeout".into(), serde_json::Value::Number(t.into()));
        }
        if !self.headers.is_empty() {
            let mut h = serde_json::Map::new();
            for (k, v) in &self.headers {
                h.insert(k.clone(), serde_json::Value::String(v.clone()));
            }
            map.insert("headers".into(), serde_json::Value::Object(h));
        }
        if let Some(ref m) = self.model {
            map.insert("model".into(), serde_json::Value::String(m.clone()));
        }
        if let Some(mt) = self.max_tokens {
            map.insert("max_tokens".into(), serde_json::Value::Number(mt.into()));
        }
        if let Some(ref env) = self.api_key_env {
            map.insert("api_key_env".into(), serde_json::Value::String(env.clone()));
        }
        if let Some(ref meta) = self.metadata {
            map.insert("metadata".into(), meta.clone());
        }
        if let Some(t) = self.threshold {
            map.insert(
                "threshold".into(),
                serde_json::Number::from_f64(t)
                    .map(serde_json::Value::Number)
                    .unwrap_or(serde_json::Value::Null),
            );
        }
        if !self.category_thresholds.is_empty() {
            let mut ct = serde_json::Map::new();
            for (k, v) in &self.category_thresholds {
                let n = serde_json::Number::from_f64(*v)
                    .map(serde_json::Value::Number)
                    .unwrap_or(serde_json::Value::Null);
                ct.insert(k.clone(), n);
            }
            map.insert("category_thresholds".into(), serde_json::Value::Object(ct));
        }
        if let Some(m) = self.method {
            map.insert(
                "method".into(),
                serde_json::Value::String(
                    match m {
                        HttpMethod::Get => "GET",
                        HttpMethod::Post => "POST",
                    }
                    .to_string(),
                ),
            );
        }
        if let Some(ref a) = self.agent_id {
            map.insert("agent_id".into(), serde_json::Value::String(a.clone()));
        }
        if let Some(ref t) = self.tool {
            map.insert("tool".into(), serde_json::Value::String(t.clone()));
        }
        serde_json::Value::Object(map)
    }
}

/// Sensitive-header name predicate. Case-insensitive match against the
/// fixed list. Deployments MAY extend; they MUST NOT shrink.
pub(crate) fn is_sensitive_header_name(name: &str) -> bool {
    matches!(
        name.to_ascii_lowercase().as_str(),
        "authorization" | "x-api-key" | "x-auth-token" | "cookie"
    )
}

impl<'de> Deserialize<'de> for ShieldConfiguration {
    fn deserialize<D: serde::Deserializer<'de>>(de: D) -> std::result::Result<Self, D::Error> {
        // Helper struct mirrors the public fields with serde defaults.
        #[derive(Deserialize)]
        #[serde(deny_unknown_fields)]
        struct H {
            id: String,
            #[serde(rename = "type")]
            config_type: ConfigurationType,
            #[serde(default)]
            default: Option<bool>,
            #[serde(default)]
            provider: Option<String>,
            #[serde(default)]
            provider_config: Option<serde_json::Value>,
            #[serde(default)]
            endpoint: Option<String>,
            #[serde(default)]
            timeout: Option<u32>,
            #[serde(default)]
            on_error: Option<ConfigOnError>,
            #[serde(default)]
            on_error_log: Option<LogBlock>,
            #[serde(default)]
            headers: HashMap<String, String>,
            #[serde(default)]
            transport: Option<crate::resolver_trust::TransportConfig>,
            #[serde(default)]
            model: Option<String>,
            #[serde(default)]
            max_tokens: Option<u32>,
            #[serde(default)]
            api_key_env: Option<String>,
            #[serde(default)]
            metadata: Option<serde_json::Value>,
            #[serde(default)]
            threshold: Option<f64>,
            #[serde(default)]
            method: Option<HttpMethod>,
            #[serde(default)]
            category_thresholds: HashMap<String, f64>,
            #[serde(default)]
            agent_id: Option<String>,
            #[serde(default)]
            tool: Option<String>,
        }

        let h = H::deserialize(de)?;

        let kind = h.config_type;
        let id = &h.id;

        if id.is_empty() {
            return Err(serde::de::Error::custom(
                "configuration: `id` must be non-empty",
            ));
        }

        if h.default == Some(true)
            && matches!(
                kind,
                ConfigurationType::HttpEndpoint
                    | ConfigurationType::McpServer
                    | ConfigurationType::A2aAgent,
            )
        {
            return Err(serde::de::Error::custom(format!(
                "configuration `{}`: `default: true` is permitted only on `llm` or `classifier`",
                id
            )));
        }

        // Required-field validation is deliberately deferred to post-merge.
        // A child overlay may legitimately omit fields the parent supplies
        // (e.g. flipping `default: true` to `default: false` without
        // restating `provider:` / `model:`); enforcing required fields per
        // file would reject such partial overlays. The merged catalog
        // is checked in [`crate::merge::merge_chain`] via
        // [`ShieldConfiguration::validate_required_fields`].

        if let Some(t) = h.timeout {
            if t == 0 {
                return Err(serde::de::Error::custom(format!(
                    "configuration `{}`: `timeout` must be a positive integer",
                    id
                )));
            }
            // `timeout` is in milliseconds (matches the documented
            // semantic at every consumption site — see
            // crate::resolver_runtime::delegate_kind and the
            // classifier providers, which all read it as `timeout_ms`).
            // Cap at MAX_RESOLVER_TIMEOUT_MS (5 min).
            if t > crate::resolver_trust::MAX_RESOLVER_TIMEOUT_MS {
                return Err(serde::de::Error::custom(format!(
                    "configuration `{}`: `timeout` {}ms exceeds the {}ms cap",
                    id,
                    t,
                    crate::resolver_trust::MAX_RESOLVER_TIMEOUT_MS
                )));
            }
        }

        // Transport-level hardening: the HTTPS-required check on
        // `endpoint:` is deferred until AFTER `${@env.*}` interpolation
        // (see [`crate::merge::interpolate_env`] and
        // [`crate::merge::validate_after_interpolation`]). Authors are
        // permitted to write `endpoint: "${@env.MY_URL}"`; rejecting the
        // literal placeholder here would shadow that contract.
        //
        // Other transport-level checks (well-formed PEM trust anchors,
        // retry block validity, circuit-breaker validity) don't reference
        // env vars and stay here so per-file authoring errors surface
        // at parse time.
        let transport_owned = h.transport.clone().unwrap_or_default();
        transport_owned
            .validate_trust_anchors()
            .map_err(|e| serde::de::Error::custom(format!("configuration `{}`: {}", id, e)))?;
        if let Some(retry) = transport_owned.retry.as_ref() {
            retry
                .validate()
                .map_err(|e| serde::de::Error::custom(format!("configuration `{}`: {}", id, e)))?;
        }
        transport_owned
            .circuit_breaker
            .validate()
            .map_err(|e| serde::de::Error::custom(format!("configuration `{}`: {}", id, e)))?;

        Ok(ShieldConfiguration {
            id: h.id,
            config_type: h.config_type,
            default: h.default,
            provider: h.provider,
            provider_config: h.provider_config,
            endpoint: h.endpoint,
            timeout: h.timeout,
            on_error: h.on_error,
            on_error_log: h.on_error_log,
            headers: h.headers,
            transport: h.transport,
            model: h.model,
            max_tokens: h.max_tokens,
            api_key_env: h.api_key_env,
            metadata: h.metadata,
            threshold: h.threshold,
            method: h.method,
            category_thresholds: h.category_thresholds,
            agent_id: h.agent_id,
            tool: h.tool,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_llm_config() {
        let yaml = "
id: default-llm
type: llm
provider: anthropic.claude
model: claude-3-5-haiku
default: true
";
        let c: ShieldConfiguration = serde_yaml::from_str(yaml).unwrap();
        assert_eq!(c.config_type, ConfigurationType::Llm);
        assert_eq!(c.default, Some(true));
    }

    /// The language-agnostic `to_full_json_value` helper is the
    /// single source of truth for `Runtime.configuration(id)` across
    /// Python, Node, and .NET. Every populated YAML field across every
    /// `type:` variant must appear in the output object, and absent
    /// optionals must be omitted entirely (not emitted as `null`) so
    /// hosts can use idiomatic `get(key, default)` lookups without
    /// distinguishing missing from explicitly-null.
    #[test]
    fn to_full_json_value_emits_every_populated_classifier_field() {
        let yaml = "
id: aacs_main
type: classifier
endpoint: \"https://example.cognitiveservices.azure.com/contentsafety/text:analyze\"
threshold: 0.6
headers:
  Ocp-Apim-Subscription-Key: \"test-key-not-real\"
  X-Test-Header: \"marker-r97-6\"
category_thresholds:
  Hate: 0.5
  Violence: 0.7
provider_config:
  categories: [\"Hate\", \"Violence\"]
  output_type: \"FourSeverityLevels\"
";
        let c: ShieldConfiguration = serde_yaml::from_str(yaml).unwrap();
        let v = c.to_full_json_value();
        let obj = v.as_object().expect("object");

        assert_eq!(obj.get("id").and_then(|v| v.as_str()), Some("aacs_main"));
        assert_eq!(obj.get("type").and_then(|v| v.as_str()), Some("classifier"));
        assert_eq!(
            obj.get("endpoint").and_then(|v| v.as_str()),
            Some("https://example.cognitiveservices.azure.com/contentsafety/text:analyze")
        );
        assert_eq!(obj.get("threshold").and_then(|v| v.as_f64()), Some(0.6));

        let headers = obj.get("headers").unwrap().as_object().unwrap();
        assert_eq!(
            headers
                .get("Ocp-Apim-Subscription-Key")
                .and_then(|v| v.as_str()),
            Some("test-key-not-real")
        );
        assert_eq!(
            headers.get("X-Test-Header").and_then(|v| v.as_str()),
            Some("marker-r97-6")
        );

        let ct = obj.get("category_thresholds").unwrap().as_object().unwrap();
        assert_eq!(ct.get("Hate").and_then(|v| v.as_f64()), Some(0.5));
        assert_eq!(ct.get("Violence").and_then(|v| v.as_f64()), Some(0.7));

        let pc = obj.get("provider_config").unwrap().as_object().unwrap();
        assert_eq!(
            pc.get("output_type").and_then(|v| v.as_str()),
            Some("FourSeverityLevels")
        );

        // Absent optionals MUST be omitted entirely (not present as null)
        // so the host-side `get(k, default)` lookups don't have to
        // distinguish missing-vs-explicitly-null. Locks in the
        // cross-SDK byte-equivalence contract.
        assert!(!obj.contains_key("model"));
        assert!(!obj.contains_key("max_tokens"));
        assert!(!obj.contains_key("provider"));
        assert!(!obj.contains_key("default"));
        assert!(!obj.contains_key("agent_id"));
        assert!(!obj.contains_key("tool"));
        assert!(!obj.contains_key("api_key_env"));
        assert!(!obj.contains_key("metadata"));
        assert!(!obj.contains_key("timeout"));
        assert!(!obj.contains_key("method"));
    }

    #[test]
    fn to_full_json_value_omits_empty_collections() {
        let yaml = "
id: minimal-llm
type: llm
model: gpt-4o
";
        let c: ShieldConfiguration = serde_yaml::from_str(yaml).unwrap();
        let v = c.to_full_json_value();
        let obj = v.as_object().expect("object");
        // Empty maps MUST NOT appear (so hosts can use truthy checks
        // for "did the YAML actually declare this?").
        assert!(!obj.contains_key("headers"));
        assert!(!obj.contains_key("category_thresholds"));
        assert_eq!(obj.get("id").and_then(|v| v.as_str()), Some("minimal-llm"));
        assert_eq!(obj.get("type").and_then(|v| v.as_str()), Some("llm"));
        assert_eq!(obj.get("model").and_then(|v| v.as_str()), Some("gpt-4o"));
    }

    #[test]
    fn deserializes_partial_llm_without_model_for_overlay_merge() {
        // Required fields are validated post-merge on the merged catalog,
        // not per file. A child overlay declaring just `{id, type}` must
        // deserialize cleanly so `crate::merge::merge_chain` can fill
        // gaps from the parent.
        let c: ShieldConfiguration =
            serde_yaml::from_str("id: x\ntype: llm\n").expect("partial overlay parses");
        assert_eq!(c.config_type, ConfigurationType::Llm);
        assert!(c.model.is_none());
    }

    #[test]
    fn validate_required_fields_flags_llm_without_model() {
        // Same `{id, type}` partial, when treated as the merged result,
        // must fail the post-merge check.
        let c: ShieldConfiguration = serde_yaml::from_str("id: x\ntype: llm\n").unwrap();
        let err = c.validate_required_fields().unwrap_err();
        assert!(err.contains("`model` is required"), "{err}");
    }

    #[test]
    fn rejects_default_on_http_endpoint() {
        let yaml = "
id: x
type: http_endpoint
endpoint: \"https://example.com\"
default: true
";
        let err = serde_yaml::from_str::<ShieldConfiguration>(yaml)
            .unwrap_err()
            .to_string();
        assert!(err.contains("default"));
    }

    #[test]
    fn validate_required_fields_flags_a2a_without_agent_id() {
        let c: ShieldConfiguration =
            serde_yaml::from_str("id: x\ntype: a2a_agent\nendpoint: https://e\n").unwrap();
        let err = c.validate_required_fields().unwrap_err();
        assert!(err.contains("agent_id"), "{err}");
    }

    #[test]
    fn rejects_zero_timeout() {
        let yaml = "id: x\ntype: llm\nmodel: m\ntimeout: 0\n";
        let err = serde_yaml::from_str::<ShieldConfiguration>(yaml)
            .unwrap_err()
            .to_string();
        assert!(err.contains("timeout"));
    }

    #[test]
    fn rejects_unknown_field() {
        let yaml = "id: x\ntype: llm\nmodel: m\nbogus: 1\n";
        let err = serde_yaml::from_str::<ShieldConfiguration>(yaml)
            .unwrap_err()
            .to_string();
        assert!(err.contains("bogus"));
    }

    #[test]
    fn rejects_invalid_circuit_breaker_threshold() {
        let yaml = r#"
id: x
type: http_endpoint
endpoint: "https://example.com"
transport:
  circuit_breaker:
    failure_threshold: 0
"#;
        let err = serde_yaml::from_str::<ShieldConfiguration>(yaml)
            .unwrap_err()
            .to_string();
        assert!(err.contains("circuit_breaker.failure_threshold"));
    }
}
