//! Canonical runtime error taxonomy.
//!
//! [`AgentShieldError`] is the stable, discriminant-bearing error
//! envelope every FFI surface returns. Hosts (Python / Node /.NET)
//! map each variant to an idiomatic language-native exception that
//! preserves both the variant kind and the canonical reason string.
//! A `deny` verdict produced by a `BindingViolation` MUST NOT
//! collapse into a generic `RuntimeError` at the language boundary.
//!
//! ## Wire shape
//!
//! Every variant serializes to JSON via [`AgentShieldError::to_wire`]
//! as:
//!
//! ```json
//! {"code": "<stable_discriminant>", "reason": "<canonical_reason>",
//! "detail": "<optional free-form detail>" }
//! ```
//!
//! `code` is the field SDK adapters dispatch on. `reason` is the
//! canonical string that appears in audit logs (`agent_shield.reason`)
//! on Stage verdicts. `detail` is optional free-form context
//! useful to operators but NOT load-bearing for dispatch.
//!
//! ## Variant inventory
//!
//! The variant set is closed and STABLE across the v2 series. Adding
//! a new variant requires bumping the FFI ABI version
//! ([`crate::ffi::shield_version`]) and updating every SDK adapter.

use serde::{Deserialize, Serialize};

// ── Canonical reason constants ───────────────────────────────────────
//
// These are the reason strings that appear on Stage verdicts and in
// audit logs. SDK adapters and conformance fixtures compare against
// these constants — never use a free-form string for a code path that
// could fire these.

/// Generic internal failure (FFI panic, runtime invariant break).
pub const REASON_INTERNAL_RUNTIME_FAILURE: &str = "internal_runtime_failure";

/// Per-stage limit exceeded; the specific limit is recorded in
/// `agent_shield.limit.name` on the audit event.
pub const REASON_LIMIT_EXCEEDED_PREFIX: &str = "limit_";

/// Stage-4 verdict whose `invocation_id` does not match a prior
/// Stage-3 admission within the same `turn_id`.
pub const REASON_INVOCATION_BINDING_VIOLATION: &str = "invocation_binding_violation";

/// Resolver response failed JSON-Schema validation.
pub const REASON_RESOLVER_RESPONSE_SCHEMA_VIOLATION: &str = "resolver_response_schema_violation";

/// Resolver response signature verification failed.
pub const REASON_RESOLVER_SIGNATURE_INVALID: &str = "resolver_signature_invalid";

/// Approval response carried a nonce that did not match the still-pending
/// invocation (replay attempt).
pub const REASON_APPROVAL_NONCE_MISMATCH: &str = "approval_nonce_mismatch";

/// Effective-policy hash (`epid`) on a Stage-4 verdict did not match
/// the `epid` of the corresponding Stage-3 admission — a policy
/// reload happened mid-turn.
pub const REASON_EPID_MISMATCH: &str = "epid_mismatch";

// ── AgentShieldError ─────────────────────────────────────────────────

/// Stable runtime error taxonomy crossed across every FFI surface.
///
/// Each variant carries enough context for the SDK adapter to map to
/// the appropriate language-native exception type while preserving
/// the canonical [`Self::code`] discriminant and [`Self::reason`]
/// string.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "kind")]
pub enum AgentShieldError {
    /// FFI panic caught at the language boundary. The caller MUST
    /// convert this to a fail-closed block verdict, never propagate
    /// the panic into the host's framework error handlers (a
    /// framework that interprets a panic as a recoverable error
    /// would retry the gated call).
    InternalRuntimeFailure { detail: String },

    /// A configured resource limit was exceeded
    /// ([`crate::limits::Limits`]). The specific limit name lives in
    /// [`Self::LimitExceeded::limit`].
    LimitExceeded { limit: String, detail: String },

    /// Stage-4 invocation binding violation: `invocation_id`
    /// missing or `invocation_hash` mismatch.
    InvocationBindingViolation {
        invocation_id: Option<String>,
        detail: String,
    },

    /// Resolver response failed JSON-Schema validation.
    ResolverResponseSchemaViolation { resolver: String, detail: String },

    /// Resolver response signature verification failed.
    ResolverSignatureInvalid { resolver: String, detail: String },

    /// Approval nonce did not match a pending invocation.
    ApprovalNonceMismatch { variable: String, detail: String },

    /// Effective-policy hash mismatch between Stage 3 admission and
    /// Stage 4 validation.
    EpidMismatch { expected: String, observed: String },

    /// Catch-all for errors that cross the FFI boundary but do not
    /// map to a specific variant above (e.g. an upstream
    /// [`crate::errors::ConfigError`] surfaced at a runtime API
    /// boundary). Hosts MUST still surface this as a structured
    /// failure (not a `null` / silent success).
    Other { detail: String },
}

impl AgentShieldError {
    /// The stable code string for this variant. Hosts dispatch on
    /// this to choose the appropriate language-native exception type.
    pub fn code(&self) -> &'static str {
        match self {
            AgentShieldError::InternalRuntimeFailure { .. } => "internal_runtime_failure",
            AgentShieldError::LimitExceeded { .. } => "limit_exceeded",
            AgentShieldError::InvocationBindingViolation { .. } => "invocation_binding_violation",
            AgentShieldError::ResolverResponseSchemaViolation { .. } => {
                "resolver_response_schema_violation"
            }
            AgentShieldError::ResolverSignatureInvalid { .. } => "resolver_signature_invalid",
            AgentShieldError::ApprovalNonceMismatch { .. } => "approval_nonce_mismatch",
            AgentShieldError::EpidMismatch { .. } => "epid_mismatch",
            AgentShieldError::Other { .. } => "other",
        }
    }

    /// The canonical reason string for this variant. This string
    /// appears on Stage verdicts and in audit logs
    /// (`agent_shield.reason`); SDK adapters MUST NOT translate it.
    pub fn reason(&self) -> String {
        match self {
            AgentShieldError::InternalRuntimeFailure { .. } => {
                REASON_INTERNAL_RUNTIME_FAILURE.to_string()
            }
            AgentShieldError::LimitExceeded { limit, .. } => {
                format!("{}{}_exceeded", REASON_LIMIT_EXCEEDED_PREFIX, limit)
            }
            AgentShieldError::InvocationBindingViolation { .. } => {
                REASON_INVOCATION_BINDING_VIOLATION.to_string()
            }
            AgentShieldError::ResolverResponseSchemaViolation { .. } => {
                REASON_RESOLVER_RESPONSE_SCHEMA_VIOLATION.to_string()
            }
            AgentShieldError::ResolverSignatureInvalid { .. } => {
                REASON_RESOLVER_SIGNATURE_INVALID.to_string()
            }
            AgentShieldError::ApprovalNonceMismatch { .. } => {
                REASON_APPROVAL_NONCE_MISMATCH.to_string()
            }
            AgentShieldError::EpidMismatch { .. } => REASON_EPID_MISMATCH.to_string(),
            AgentShieldError::Other { detail } => detail.clone(),
        }
    }

    /// Optional free-form detail. Surfaced in audit logs and human
    /// error messages; NOT load-bearing for dispatch.
    pub fn detail(&self) -> &str {
        match self {
            AgentShieldError::InternalRuntimeFailure { detail }
            | AgentShieldError::LimitExceeded { detail, .. }
            | AgentShieldError::InvocationBindingViolation { detail, .. }
            | AgentShieldError::ResolverResponseSchemaViolation { detail, .. }
            | AgentShieldError::ResolverSignatureInvalid { detail, .. }
            | AgentShieldError::ApprovalNonceMismatch { detail, .. }
            | AgentShieldError::Other { detail } => detail,
            AgentShieldError::EpidMismatch { .. } => "",
        }
    }

    /// The canonical wire shape — a JSON object with `code`, `reason`,
    /// and `detail` keys. Used by [`crate::ffi::shield_format_error`]
    /// to populate FFI `**err` slots.
    pub fn to_wire(&self) -> serde_json::Value {
        serde_json::json!({
            "code": self.code(),
            "reason": self.reason(),
            "detail": self.detail(),
        })
    }

    /// Helper for the FFI panic handler. Builds an
    /// [`Self::InternalRuntimeFailure`] from a panic payload.
    pub fn from_panic_payload(payload: &Box<dyn std::any::Any + Send>) -> Self {
        let msg = if let Some(s) = payload.downcast_ref::<&'static str>() {
            (*s).to_string()
        } else if let Some(s) = payload.downcast_ref::<String>() {
            s.clone()
        } else {
            "panic with non-string payload".to_string()
        };
        AgentShieldError::InternalRuntimeFailure { detail: msg }
    }
}

impl std::fmt::Display for AgentShieldError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let d = self.detail();
        if d.is_empty() {
            write!(f, "[{}] {}", self.code(), self.reason())
        } else {
            write!(f, "[{}] {} ({})", self.code(), self.reason(), d)
        }
    }
}

impl std::error::Error for AgentShieldError {}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn code_and_reason_for_each_variant() {
        let e = AgentShieldError::InternalRuntimeFailure {
            detail: "test".into(),
        };
        assert_eq!(e.code(), "internal_runtime_failure");
        assert_eq!(e.reason(), "internal_runtime_failure");
        assert_eq!(e.detail(), "test");

        let e = AgentShieldError::LimitExceeded {
            limit: "prompt_bytes".into(),
            detail: "1MiB".into(),
        };
        assert_eq!(e.code(), "limit_exceeded");
        assert_eq!(e.reason(), "limit_prompt_bytes_exceeded");

        let e = AgentShieldError::InvocationBindingViolation {
            invocation_id: Some("inv-1".into()),
            detail: "no Stage 3 admission".into(),
        };
        assert_eq!(e.code(), "invocation_binding_violation");
        assert_eq!(e.reason(), "invocation_binding_violation");
    }

    #[test]
    fn wire_shape_is_stable() {
        let e = AgentShieldError::ApprovalNonceMismatch {
            variable: "user_approves".into(),
            detail: "nonce mismatch".into(),
        };
        let w = e.to_wire();
        assert_eq!(w["code"], "approval_nonce_mismatch");
        assert_eq!(w["reason"], "approval_nonce_mismatch");
        assert_eq!(w["detail"], "nonce mismatch");
    }

    #[test]
    fn display_uses_code_and_reason() {
        let e = AgentShieldError::EpidMismatch {
            expected: "epid:sha256:aaa".into(),
            observed: "epid:sha256:bbb".into(),
        };
        let s = e.to_string();
        assert!(s.contains("epid_mismatch"), "got: {s}");
    }
}
