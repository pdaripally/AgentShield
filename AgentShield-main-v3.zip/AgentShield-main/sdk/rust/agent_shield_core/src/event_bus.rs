//! In-memory pub/sub event bus with latching, lifetime expiry, and the closed
//! event namespace.
//!
//! ## Spec mapping
//!
//! - — closed event namespace ([`EventId`] enforces this at parse time;
//!   this module accepts only typed [`EventId`] values for static-namespace
//!   events plus parsed `incident.<name>` strings).
//! - — latching, the three clearing operations:
//!   1. `session.end` clears all latched events ([`EventBus::end_session`]).
//!   2. [`EventBus::clear_event`] clears a specific latch.
//!   3. Per-event lifetime expiry clears the latch on the next read or emit.
//! - — event lifetimes (bare-form only — map form is rejected for events).
//! - — required emitter sites (`emit_session_*`, `emit_turn_*`,
//!   `emit_request_*`, `emit_tool_*`, `emit_endpoint_*`, `emit_agent_*`,
//!   `emit_variable_changed`, `emit_guard_policy_*`, `emit_approval_*`,
//!   `emit_incident`).
//! - — runtime API surface (`emit_event` / `clear_event`).
//!
//! The bus is `Send + Sync`. All mutable state lives behind a single mutex on
//! the inner record. Subscribers are dispatched **after** the mutex is
//! released so a subscriber may safely call back into the bus.
//!
//! ## Coordination with the expression evaluator (P2)
//!
//! `@event.fired(<id>)` in expressions calls into a [`EventFiredHook`].
//! The canonical definition lives in [`crate::expressions::eval::EventFiredHook`]
//! (P2). [`EventBus`] (and `Arc<EventBus>`) implement that trait so the
//! evaluator can call straight into the bus without an extra adapter.

use std::cell::{Cell, RefCell};
use std::collections::{HashMap, VecDeque};
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::sync::{Arc, Mutex};

use chrono::{DateTime, Utc};
use serde_json::Value;

use super::events::{ApprovalEventKind, EventId, EventIdError, GpEventKind, ToolEventKind};
use super::lifetime::{BareLifetime, Lifetime};
use super::session_id::SessionId;
pub use crate::expressions::eval::EventFiredHook;

// ── Errors ───────────────────────────────────────────────────────────

/// Build the spec-shaped audit payload for `guard_policy.<name>.redacted`
/// Payload keys (snake_case, in the order specified by):
/// - `stage`: literal stage name — `"input_validation"`,
///   `"tool_invocation_validation"`, `"post_invocation_validation"`,
///   or `"output_validation"`.
/// - `tool_name` / `endpoint_id` / `agent_name`: present per the gated
///   subject's resource kind (mutually exclusive; the others omitted).
/// - `spans_removed_count`: the number of distinct text spans replaced.
/// - `redacted_at`: ISO-8601 wall-clock timestamp.
pub fn build_guard_policy_redacted_payload(
    stage: &'static str,
    tool_name: Option<&str>,
    endpoint_id: Option<&str>,
    agent_name: Option<&str>,
    spans_removed_count: usize,
    redacted_at: DateTime<Utc>,
) -> Value {
    let mut obj = serde_json::Map::new();
    obj.insert("stage".into(), Value::String(stage.to_string()));
    if let Some(t) = tool_name {
        obj.insert("tool_name".into(), Value::String(t.to_string()));
    }
    if let Some(e) = endpoint_id {
        obj.insert("endpoint_id".into(), Value::String(e.to_string()));
    }
    if let Some(a) = agent_name {
        obj.insert("agent_name".into(), Value::String(a.to_string()));
    }
    obj.insert(
        "spans_removed_count".into(),
        Value::Number(serde_json::Number::from(spans_removed_count)),
    );
    obj.insert(
        "redacted_at".into(),
        Value::String(redacted_at.to_rfc3339_opts(chrono::SecondsFormat::AutoSi, true)),
    );
    Value::Object(obj)
}

/// Errors raised at emission time.
#[derive(Debug, thiserror::Error, Clone)]
pub enum EmitError {
    #[error("event identifier `{0}` is invalid: {1}")]
    InvalidEventId(String, EventIdError),

    #[error("events do not accept the lifetime map form; use a bare lifetime")]
    MapLifetimeRejected,
}

// ── Bus event (subscriber payload) ───────────────────────────────────

/// What a subscriber sees on each bus notification.
#[derive(Debug, Clone)]
pub enum BusEvent {
    /// A fresh emission was latched (or an existing latch was refreshed with
    /// a new lifetime).
    Emitted {
        /// Session that owns the latch. Subscribers MUST use this to
        /// scope any session-keyed state they mutate in response.
        session_id: SessionId,
        event_id: EventId,
        payload: Option<Value>,
        /// Was this a re-emission of an already-latched event?
        refreshed: bool,
    },
    /// An event's latch was cleared. `cause` records why.
    Cleared {
        session_id: SessionId,
        event_id: EventId,
        cause: ClearCause,
    },
}

impl BusEvent {
    fn event_id(&self) -> &EventId {
        match self {
            Self::Emitted { event_id, .. } | Self::Cleared { event_id, .. } => event_id,
        }
    }
}

/// Why a latched event was cleared.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ClearCause {
    /// Host called [`EventBus::clear_event`].
    Explicit,
    /// `session.end` was emitted.
    SessionEnd,
    /// Latched event's `lifetime: for: <duration>` elapsed.
    Expired,
    /// Latched event's `until_event:` trigger fired.
    UntilEventTriggered,
}

// ── Subscribers ──────────────────────────────────────────────────────

type SubscriberFn = dyn FnMut(&BusEvent) + Send;
type PredicateFn = dyn Fn(&BusEvent) -> bool + Send + Sync;

/// One subscriber slot snapshot held briefly during dispatch.
type SubscriberSnapshot = (
    Option<Arc<PredicateFn>>,
    Arc<Mutex<Box<SubscriberFn>>>,
    Arc<std::sync::atomic::AtomicBool>,
);

thread_local! {
    static DISPATCH_DEPTH: Cell<usize> = const { Cell::new(0) };
    static DEFERRED_DISPATCH: RefCell<VecDeque<BusEvent>> = const { RefCell::new(VecDeque::new()) };
}

struct DispatchGuard;

impl Drop for DispatchGuard {
    fn drop(&mut self) {
        DISPATCH_DEPTH.with(|depth| depth.set(0));
        DEFERRED_DISPATCH.with(|pending| pending.borrow_mut().clear());
    }
}

/// One subscriber slot. The callback is wrapped in an inner `Mutex` so
/// `dispatch` can clone the `Arc` (taking only a cheap snapshot of the
/// subscriber set) and release the bus's outer mutex before invoking the
/// callback. This lets a callback safely re-enter the bus via `emit`,
/// `clear_event`, or any public method without deadlocking, and ensures
/// re-entrant emits still see every registered subscriber.
struct Subscriber {
    id: u64,
    /// Optional predicate: only fires when this returns true. `None` ≡ always.
    predicate: Option<Arc<PredicateFn>>,
    callback: Arc<Mutex<Box<SubscriberFn>>>,
    /// Set to `false` by `unsubscribe`. We mark-and-sweep so concurrent
    /// dispatch can recognize cancelled subscribers and skip them.
    active: Arc<std::sync::atomic::AtomicBool>,
}

/// Opaque handle for unregistering a subscriber.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SubscriberHandle(u64);

// ── Latched entries ──────────────────────────────────────────────────

#[derive(Debug, Clone)]
struct LatchedEntry {
    payload: Option<Value>,
    expires_at: Option<DateTime<Utc>>,
    /// Trigger ids for `until_event:` clearing.
    until_events: Vec<EventId>,
    /// Scope lifetime (P3.2 /): tracks `per_call|per_turn|per_session
    /// |per_request` so the runtime can clear matching latches at the
    /// matching boundary via [`EventBus::clear_per_call`] etc. `For`/
    /// `UntilEvent` are encoded via `expires_at` / `until_events` and have
    /// no scope component here.
    scope_lifetime: Option<BareLifetime>,
}

// ── Inner state ──────────────────────────────────────────────────────

type ClockFn = Arc<dyn Fn() -> DateTime<Utc> + Send + Sync>;

struct Inner {
    /// Latched event entries keyed by `(session_id, event_id)` so each
    /// [`crate::runtime::GuardrailsSession`] sees only its own latches
    /// Legacy callers that don't thread a session id
    /// fall back to [`SessionId::default`] (the empty-string anonymous
    /// session) — a single global namespace for back-compat with
    /// pre-refactor tests.
    latched: HashMap<(SessionId, EventId), LatchedEntry>,
    subscribers: Vec<Subscriber>,
    next_subscriber_id: u64,
    clock: ClockFn,
}

impl Inner {
    fn now(&self) -> DateTime<Utc> {
        (self.clock)()
    }
}

/// Public facade.
#[derive(Clone)]
pub struct EventBus {
    inner: Arc<Mutex<Inner>>,
}

impl std::fmt::Debug for EventBus {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("EventBus").finish_non_exhaustive()
    }
}

impl Default for EventBus {
    fn default() -> Self {
        Self::new()
    }
}

impl EventBus {
    /// New bus using `chrono::Utc::now` as the clock.
    pub fn new() -> Self {
        Self::with_clock(Arc::new(Utc::now))
    }

    /// New bus with a configurable clock — used by tests for deterministic
    /// expiry assertions.
    pub fn with_clock(clock: ClockFn) -> Self {
        let inner = Inner {
            latched: HashMap::new(),
            subscribers: Vec::new(),
            next_subscriber_id: 0,
            clock,
        };
        Self {
            inner: Arc::new(Mutex::new(inner)),
        }
    }

    /// Replace the clock at runtime. Tests use this to advance "now" between
    /// emissions.
    pub fn set_clock(&self, clock: ClockFn) {
        self.inner.lock().unwrap().clock = clock;
    }

    // ── Emission ────────────────────────────────────────────────────

    /// Emit an event. `lifetime` accepts the bare-form grammar only; map-form
    /// is rejected. When `lifetime` is `None`, the event latches
    /// with `per_session` semantics — i.e., it stays latched until `session.end`
    /// or an explicit `clear_event`.
    /// Side effects:
    /// 1. Latches the event in the named session (or refreshes an
    ///    existing latch's lifetime).
    /// 2. Fires `until_event:` triggers — any other latched event whose
    ///    `until_event:` list contains `event_id` (within the same
    ///    session) is cleared.
    /// 3. Dispatches `BusEvent::Emitted` carrying the session id so
    ///    subscribers (e.g., the lifetime tracker) only mutate the
    ///    matching session's state.
    /// 4. If `event_id == EventId::SessionEnd`, clears every latched
    ///    event for that session (including `session.end` itself) per
    pub fn emit_in(
        &self,
        session_id: &SessionId,
        event_id: EventId,
        lifetime: Option<Lifetime>,
        payload: Option<Value>,
    ) -> Result<(), EmitError> {
        // P3.5: every emission round-trips through `EventId::parse` so an
        // invalid identifier built via a public field constructor (e.g.
        // `EventId::Incident { name: "Bad-Name".into() }`) is rejected
        // before any state mutation.
        if let Err(e) = EventId::parse(&event_id.to_string()) {
            return Err(EmitError::InvalidEventId(event_id.to_string(), e));
        }

        let bare = match lifetime {
            None => None,
            Some(Lifetime::Bare(b)) => Some(b),
            Some(Lifetime::Map(_)) => return Err(EmitError::MapLifetimeRejected),
        };

        let mut deferred: Vec<BusEvent> = Vec::new();

        // ── Phase 1: under lock, mutate state and accumulate notifications.
        {
            let mut inner = self.inner.lock().unwrap();
            let now = inner.now();

            // Compute lifetime metadata for the new latch.
            let (expires_at, until_events, scope_lifetime) = match &bare {
                Some(BareLifetime::For(d)) => (Some(now + *d), Vec::new(), None),
                Some(BareLifetime::UntilEvent(ids)) => (None, ids.clone(), None),
                Some(
                    scope @ (BareLifetime::PerCall
                    | BareLifetime::PerTurn
                    | BareLifetime::PerSession
                    | BareLifetime::PerRequest),
                ) => (None, Vec::new(), Some(scope.clone())),
                None => (None, Vec::new(), None),
            };

            let key = (session_id.clone(), event_id.clone());
            let was_latched = inner.latched.contains_key(&key);
            inner.latched.insert(
                key.clone(),
                LatchedEntry {
                    payload: payload.clone(),
                    expires_at,
                    until_events,
                    scope_lifetime,
                },
            );

            deferred.push(BusEvent::Emitted {
                session_id: session_id.clone(),
                event_id: event_id.clone(),
                payload,
                refreshed: was_latched,
            });

            // until_event: cascade — any *other* latched event in the
            // SAME session waiting on this id is cleared.
            let triggered: Vec<EventId> = inner
                .latched
                .iter()
                .filter_map(|((sid, id), e)| {
                    if sid == session_id && id != &event_id && e.until_events.contains(&event_id) {
                        Some(id.clone())
                    } else {
                        None
                    }
                })
                .collect();
            for id in triggered {
                inner.latched.remove(&(session_id.clone(), id.clone()));
                deferred.push(BusEvent::Cleared {
                    session_id: session_id.clone(),
                    event_id: id,
                    cause: ClearCause::UntilEventTriggered,
                });
            }

            // session.end semantics.4: clears EVERY latch in this
            // session, including session.end itself, after dispatching
            // the emission. Other sessions' latches are untouched.
            if matches!(event_id, EventId::SessionEnd) {
                let to_clear: Vec<EventId> = inner
                    .latched
                    .keys()
                    .filter_map(|(sid, id)| {
                        if sid == session_id {
                            Some(id.clone())
                        } else {
                            None
                        }
                    })
                    .collect();
                for id in to_clear {
                    inner.latched.remove(&(session_id.clone(), id.clone()));
                    deferred.push(BusEvent::Cleared {
                        session_id: session_id.clone(),
                        event_id: id,
                        cause: ClearCause::SessionEnd,
                    });
                }
            }
        }

        // ── Phase 2: dispatch outside the lock.
        for ev in deferred {
            self.dispatch(&ev);
        }
        Ok(())
    }

    /// Legacy session-blind `emit` — equivalent to
    /// [`Self::emit_in`] with [`SessionId::default`]. Kept for back-compat
    /// with existing tests and the C-ABI surface that don't yet thread
    /// a session id.
    pub fn emit(
        &self,
        event_id: EventId,
        lifetime: Option<Lifetime>,
        payload: Option<Value>,
    ) -> Result<(), EmitError> {
        self.emit_in(&SessionId::default(), event_id, lifetime, payload)
    }

    /// Convenience: emit with `lifetime: None`, no payload.
    pub fn emit_simple(&self, event_id: EventId) -> Result<(), EmitError> {
        self.emit(event_id, None, None)
    }

    /// Session-scoped variant of [`Self::emit_simple`].
    pub fn emit_simple_in(
        &self,
        session_id: &SessionId,
        event_id: EventId,
    ) -> Result<(), EmitError> {
        self.emit_in(session_id, event_id, None, None)
    }

    /// Emit an `incident.<name>` event after parsing & validating the name
    /// against the grammar.
    pub fn emit_incident(
        &self,
        full_id: &str,
        lifetime: Option<Lifetime>,
        payload: Option<Value>,
    ) -> Result<(), EmitError> {
        self.emit_incident_in(&SessionId::default(), full_id, lifetime, payload)
    }

    /// Session-scoped variant of [`Self::emit_incident`].
    pub fn emit_incident_in(
        &self,
        session_id: &SessionId,
        full_id: &str,
        lifetime: Option<Lifetime>,
        payload: Option<Value>,
    ) -> Result<(), EmitError> {
        let id = EventId::parse(full_id)
            .map_err(|e| EmitError::InvalidEventId(full_id.to_string(), e))?;
        if !matches!(id, EventId::Incident { .. }) {
            return Err(EmitError::InvalidEventId(
                full_id.to_string(),
                EventIdError::UnknownPrefix(full_id.to_string()),
            ));
        }
        self.emit_in(session_id, id, lifetime, payload)
    }

    // ── Required-emitter helpers ────────────────────────────

    pub fn emit_session_start(&self) -> Result<(), EmitError> {
        self.emit_simple(EventId::SessionStart)
    }

    pub fn emit_session_start_in(&self, session_id: &SessionId) -> Result<(), EmitError> {
        self.emit_simple_in(session_id, EventId::SessionStart)
    }

    /// `session.end` — also clears all latched events.
    pub fn emit_session_end(&self) -> Result<(), EmitError> {
        self.emit_simple(EventId::SessionEnd)
    }

    pub fn emit_session_end_in(&self, session_id: &SessionId) -> Result<(), EmitError> {
        self.emit_simple_in(session_id, EventId::SessionEnd)
    }

    pub fn emit_turn_start(&self) -> Result<(), EmitError> {
        self.emit_simple(EventId::TurnStart)
    }

    pub fn emit_turn_start_in(&self, session_id: &SessionId) -> Result<(), EmitError> {
        self.emit_simple_in(session_id, EventId::TurnStart)
    }

    pub fn emit_turn_end(&self) -> Result<(), EmitError> {
        self.emit_simple(EventId::TurnEnd)
    }

    pub fn emit_turn_end_in(&self, session_id: &SessionId) -> Result<(), EmitError> {
        self.emit_simple_in(session_id, EventId::TurnEnd)
    }

    pub fn emit_request_start(&self) -> Result<(), EmitError> {
        self.emit_simple(EventId::RequestStart)
    }

    pub fn emit_request_start_in(&self, session_id: &SessionId) -> Result<(), EmitError> {
        self.emit_simple_in(session_id, EventId::RequestStart)
    }

    pub fn emit_request_end(&self) -> Result<(), EmitError> {
        self.emit_simple(EventId::RequestEnd)
    }

    pub fn emit_request_end_in(&self, session_id: &SessionId) -> Result<(), EmitError> {
        self.emit_simple_in(session_id, EventId::RequestEnd)
    }

    pub fn emit_tool_called(&self, name: impl Into<String>) -> Result<(), EmitError> {
        self.emit_simple(EventId::Tool {
            name: name.into(),
            kind: ToolEventKind::Called,
        })
    }

    pub fn emit_tool_called_in(
        &self,
        session_id: &SessionId,
        name: impl Into<String>,
    ) -> Result<(), EmitError> {
        self.emit_simple_in(
            session_id,
            EventId::Tool {
                name: name.into(),
                kind: ToolEventKind::Called,
            },
        )
    }

    pub fn emit_tool_success(&self, name: impl Into<String>) -> Result<(), EmitError> {
        self.emit_simple(EventId::Tool {
            name: name.into(),
            kind: ToolEventKind::Success,
        })
    }

    pub fn emit_tool_success_in(
        &self,
        session_id: &SessionId,
        name: impl Into<String>,
    ) -> Result<(), EmitError> {
        self.emit_simple_in(
            session_id,
            EventId::Tool {
                name: name.into(),
                kind: ToolEventKind::Success,
            },
        )
    }

    pub fn emit_tool_failure(&self, name: impl Into<String>) -> Result<(), EmitError> {
        self.emit_simple(EventId::Tool {
            name: name.into(),
            kind: ToolEventKind::Failure,
        })
    }

    pub fn emit_tool_failure_in(
        &self,
        session_id: &SessionId,
        name: impl Into<String>,
    ) -> Result<(), EmitError> {
        self.emit_simple_in(
            session_id,
            EventId::Tool {
                name: name.into(),
                kind: ToolEventKind::Failure,
            },
        )
    }

    pub fn emit_endpoint_called(&self, pattern: impl Into<String>) -> Result<(), EmitError> {
        self.emit_simple(EventId::Endpoint {
            pattern: pattern.into(),
            kind: ToolEventKind::Called,
        })
    }

    pub fn emit_endpoint_called_in(
        &self,
        session_id: &SessionId,
        pattern: impl Into<String>,
    ) -> Result<(), EmitError> {
        self.emit_simple_in(
            session_id,
            EventId::Endpoint {
                pattern: pattern.into(),
                kind: ToolEventKind::Called,
            },
        )
    }

    pub fn emit_endpoint_success(&self, pattern: impl Into<String>) -> Result<(), EmitError> {
        self.emit_simple(EventId::Endpoint {
            pattern: pattern.into(),
            kind: ToolEventKind::Success,
        })
    }

    pub fn emit_endpoint_failure(&self, pattern: impl Into<String>) -> Result<(), EmitError> {
        self.emit_simple(EventId::Endpoint {
            pattern: pattern.into(),
            kind: ToolEventKind::Failure,
        })
    }

    /// Session-scoped variant of [`Self::emit_endpoint_failure`].
    pub fn emit_endpoint_failure_in(
        &self,
        session_id: &SessionId,
        pattern: impl Into<String>,
    ) -> Result<(), EmitError> {
        self.emit_simple_in(
            session_id,
            EventId::Endpoint {
                pattern: pattern.into(),
                kind: ToolEventKind::Failure,
            },
        )
    }

    pub fn emit_agent_called(&self, name: impl Into<String>) -> Result<(), EmitError> {
        self.emit_simple(EventId::Agent {
            name: name.into(),
            kind: ToolEventKind::Called,
        })
    }

    pub fn emit_agent_called_in(
        &self,
        session_id: &SessionId,
        name: impl Into<String>,
    ) -> Result<(), EmitError> {
        self.emit_simple_in(
            session_id,
            EventId::Agent {
                name: name.into(),
                kind: ToolEventKind::Called,
            },
        )
    }

    pub fn emit_agent_success(&self, name: impl Into<String>) -> Result<(), EmitError> {
        self.emit_simple(EventId::Agent {
            name: name.into(),
            kind: ToolEventKind::Success,
        })
    }

    pub fn emit_agent_failure(&self, name: impl Into<String>) -> Result<(), EmitError> {
        self.emit_simple(EventId::Agent {
            name: name.into(),
            kind: ToolEventKind::Failure,
        })
    }

    /// Session-scoped variant of [`Self::emit_agent_failure`].
    pub fn emit_agent_failure_in(
        &self,
        session_id: &SessionId,
        name: impl Into<String>,
    ) -> Result<(), EmitError> {
        self.emit_simple_in(
            session_id,
            EventId::Agent {
                name: name.into(),
                kind: ToolEventKind::Failure,
            },
        )
    }

    pub fn emit_variable_changed(&self, name: impl Into<String>) -> Result<(), EmitError> {
        self.emit_simple(EventId::VariableChanged { name: name.into() })
    }

    /// emit `variable.<name>.changed` with an optional payload
    /// carrying `{ key: <value> }` for keyed variables. The runtime
    /// adapter calls this from [`crate::lifetime_tracker::LifetimeTracker::set_variable_keyed`]
    /// so subscribers can disambiguate per-key writes from each other.
    pub fn emit_variable_changed_with_payload(
        &self,
        name: impl Into<String>,
        payload: Option<serde_json::Value>,
    ) -> Result<(), EmitError> {
        self.emit(
            EventId::VariableChanged { name: name.into() },
            None,
            payload,
        )
    }

    /// Session-scoped variant of [`Self::emit_variable_changed_with_payload`].
    pub fn emit_variable_changed_with_payload_in(
        &self,
        session_id: &SessionId,
        name: impl Into<String>,
        payload: Option<serde_json::Value>,
    ) -> Result<(), EmitError> {
        self.emit_in(
            session_id,
            EventId::VariableChanged { name: name.into() },
            None,
            payload,
        )
    }

    pub fn emit_guard_policy_activated(&self, name: impl Into<String>) -> Result<(), EmitError> {
        self.emit_simple(EventId::GuardPolicy {
            name: name.into(),
            kind: GpEventKind::Activated,
        })
    }

    pub fn emit_guard_policy_activated_in(
        &self,
        session_id: &SessionId,
        name: impl Into<String>,
    ) -> Result<(), EmitError> {
        self.emit_simple_in(
            session_id,
            EventId::GuardPolicy {
                name: name.into(),
                kind: GpEventKind::Activated,
            },
        )
    }

    pub fn emit_guard_policy_deactivated(&self, name: impl Into<String>) -> Result<(), EmitError> {
        self.emit_simple(EventId::GuardPolicy {
            name: name.into(),
            kind: GpEventKind::Deactivated,
        })
    }

    pub fn emit_guard_policy_deactivated_in(
        &self,
        session_id: &SessionId,
        name: impl Into<String>,
    ) -> Result<(), EmitError> {
        self.emit_simple_in(
            session_id,
            EventId::GuardPolicy {
                name: name.into(),
                kind: GpEventKind::Deactivated,
            },
        )
    }

    /// Session-scoped variant of [`Self::emit_guard_policy_deactivated_in`]
    /// that carries a structured diagnostic payload. The payload
    /// shape mirrors envelope conventions and surfaces the
    /// `active_if:` expression plus the `@status` of every referenced
    /// variable so developers can see *why* a policy was deactivated
    /// (e.g. `{"active_if": "vip_context == 'sensitive'", "result":
    /// false, "referenced_variables": [{"name": "vip_context",
    /// "status": "unset"}]}`).
    pub fn emit_guard_policy_deactivated_with_payload_in(
        &self,
        session_id: &SessionId,
        name: impl Into<String>,
        payload: Option<Value>,
    ) -> Result<(), EmitError> {
        self.emit_in(
            session_id,
            EventId::GuardPolicy {
                name: name.into(),
                kind: GpEventKind::Deactivated,
            },
            None,
            payload,
        )
    }

    pub fn emit_guard_policy_passed(&self, name: impl Into<String>) -> Result<(), EmitError> {
        self.emit_simple(EventId::GuardPolicy {
            name: name.into(),
            kind: GpEventKind::Passed,
        })
    }

    pub fn emit_guard_policy_passed_in(
        &self,
        session_id: &SessionId,
        name: impl Into<String>,
    ) -> Result<(), EmitError> {
        self.emit_simple_in(
            session_id,
            EventId::GuardPolicy {
                name: name.into(),
                kind: GpEventKind::Passed,
            },
        )
    }

    pub fn emit_guard_policy_failed(&self, name: impl Into<String>) -> Result<(), EmitError> {
        self.emit_simple(EventId::GuardPolicy {
            name: name.into(),
            kind: GpEventKind::Failed,
        })
    }

    pub fn emit_guard_policy_failed_in(
        &self,
        session_id: &SessionId,
        name: impl Into<String>,
    ) -> Result<(), EmitError> {
        self.emit_simple_in(
            session_id,
            EventId::GuardPolicy {
                name: name.into(),
                kind: GpEventKind::Failed,
            },
        )
    }

    /// `guard_policy.<name>.redacted` — emitted when an `action: redact`
    /// entry successfully replaced at least one span of the gated
    /// subject. The runtime is
    /// responsible for guarding this call so it MUST NOT fire when
    /// `spans_removed_count == 0` (no-op redactions are not signal).
    /// `payload` carries the spec-required keys
    /// `{ stage, tool_name?, endpoint_id?, agent_name?, spans_removed_count, redacted_at }`
    /// and is constructed by [`build_guard_policy_redacted_payload`].
    pub fn emit_guard_policy_redacted_in(
        &self,
        session_id: &SessionId,
        name: impl Into<String>,
        payload: Value,
    ) -> Result<(), EmitError> {
        self.emit_in(
            session_id,
            EventId::GuardPolicy {
                name: name.into(),
                kind: GpEventKind::Redacted,
            },
            None,
            Some(payload),
        )
    }

    /// Emit `approval.<variable>.<kind>` with optional payload.
    /// Auto-flip of the bound variable is implemented in
    /// [`crate::lifetime_tracker::LifetimeTracker`] as a subscriber.
    pub fn emit_approval(
        &self,
        variable: impl Into<String>,
        kind: ApprovalEventKind,
        lifetime: Option<Lifetime>,
        payload: Option<Value>,
    ) -> Result<(), EmitError> {
        self.emit(
            EventId::Approval {
                variable: variable.into(),
                kind,
            },
            lifetime,
            payload,
        )
    }

    /// Session-scoped variant of [`Self::emit_approval`].
    pub fn emit_approval_in(
        &self,
        session_id: &SessionId,
        variable: impl Into<String>,
        kind: ApprovalEventKind,
        lifetime: Option<Lifetime>,
        payload: Option<Value>,
    ) -> Result<(), EmitError> {
        self.emit_in(
            session_id,
            EventId::Approval {
                variable: variable.into(),
                kind,
            },
            lifetime,
            payload,
        )
    }

    // ── Reads & clearing ────────────────────────────────────────────

    /// True when the named event is latched in the given session and not
    /// expired. Expired latches are evicted lazily on this call.
    pub fn fired_id_in(&self, session_id: &SessionId, event_id: &EventId) -> bool {
        let mut inner = self.inner.lock().unwrap();
        let now = inner.now();
        let key = (session_id.clone(), event_id.clone());
        if let Some(entry) = inner.latched.get(&key) {
            if let Some(exp) = entry.expires_at {
                if now >= exp {
                    inner.latched.remove(&key);
                    drop(inner);
                    self.dispatch(&BusEvent::Cleared {
                        session_id: session_id.clone(),
                        event_id: event_id.clone(),
                        cause: ClearCause::Expired,
                    });
                    return false;
                }
            }
            true
        } else {
            false
        }
    }

    /// True when the named event is latched in **any** session and not
    /// expired. Cross-session aggregator used by:
    /// - Diagnostic queries from `runtime.bus().fired_id(...)` that need
    ///   a fleet-wide view.
    /// - Existing tests and the C-ABI surface that haven't yet been
    ///   updated to thread a session id.
    /// For session-scoped checks (the spec default — every variable
    /// event lifetime is per-session), use [`Self::fired_id_in`].
    pub fn fired_id(&self, event_id: &EventId) -> bool {
        // Eagerly reap expired entries so subsequent reads agree with
        // the contract that expired latches are observable
        // as "not fired".
        let mut to_clear: Vec<(SessionId, EventId)> = Vec::new();
        let mut any_alive = false;
        {
            let mut inner = self.inner.lock().unwrap();
            let now = inner.now();
            // First pass: collect expired entries that match this id.
            for ((sid, id), entry) in inner.latched.iter() {
                if id != event_id {
                    continue;
                }
                if let Some(exp) = entry.expires_at {
                    if now >= exp {
                        to_clear.push((sid.clone(), id.clone()));
                        continue;
                    }
                }
                any_alive = true;
            }
            for k in &to_clear {
                inner.latched.remove(k);
            }
        }
        for (sid, id) in to_clear {
            self.dispatch(&BusEvent::Cleared {
                session_id: sid,
                event_id: id,
                cause: ClearCause::Expired,
            });
        }
        any_alive
    }

    /// Clear a specific latched event from the given session. Returns
    /// `true` if it was latched.
    pub fn clear_event_in(&self, session_id: &SessionId, event_id: &EventId) -> bool {
        let removed = {
            let mut inner = self.inner.lock().unwrap();
            inner
                .latched
                .remove(&(session_id.clone(), event_id.clone()))
                .is_some()
        };
        if removed {
            self.dispatch(&BusEvent::Cleared {
                session_id: session_id.clone(),
                event_id: event_id.clone(),
                cause: ClearCause::Explicit,
            });
        }
        removed
    }

    /// Legacy session-blind variant — clears the latch in the default
    /// session only. New callers should use [`Self::clear_event_in`].
    pub fn clear_event(&self, event_id: &EventId) -> bool {
        self.clear_event_in(&SessionId::default(), event_id)
    }

    /// `session.end` semantics surfaced as a method (also performed
    /// automatically when [`EventBus::emit_session_end`] is called).
    /// Clears every session's latches.
    pub fn clear_all(&self) {
        let cleared: Vec<(SessionId, EventId)> = {
            let mut inner = self.inner.lock().unwrap();
            let keys: Vec<(SessionId, EventId)> = inner.latched.keys().cloned().collect();
            for k in &keys {
                inner.latched.remove(k);
            }
            keys
        };
        for (sid, id) in cleared {
            self.dispatch(&BusEvent::Cleared {
                session_id: sid,
                event_id: id,
                cause: ClearCause::SessionEnd,
            });
        }
    }

    /// Drop every latched entry belonging to `session_id`. Called when a
    /// [`crate::runtime::GuardrailsSession`] is dropped or closed so
    /// dangling latches don't accumulate. Subscribers see a `Cleared`
    /// notification per dropped latch (cause: `SessionEnd`).
    pub fn cleanup_session(&self, session_id: &SessionId) {
        let cleared: Vec<EventId> = {
            let mut inner = self.inner.lock().unwrap();
            let keys: Vec<EventId> = inner
                .latched
                .keys()
                .filter_map(|(sid, id)| {
                    if sid == session_id {
                        Some(id.clone())
                    } else {
                        None
                    }
                })
                .collect();
            for id in &keys {
                inner.latched.remove(&(session_id.clone(), id.clone()));
            }
            keys
        };
        for id in cleared {
            self.dispatch(&BusEvent::Cleared {
                session_id: session_id.clone(),
                event_id: id,
                cause: ClearCause::SessionEnd,
            });
        }
    }

    /// Clear every latched event whose scope lifetime is `per_call`
    /// (P3.2 /). Hosts call this at the matching boundary; the
    /// runtime's `Session` is the canonical caller.
    pub fn clear_per_call(&self) {
        self.clear_per_call_in(&SessionId::default());
    }

    /// Session-scoped variant of [`Self::clear_per_call`].
    pub fn clear_per_call_in(&self, session_id: &SessionId) {
        self.clear_by_scope(Some(session_id), BareLifetime::PerCall);
    }

    /// Clear every latched event whose scope lifetime is `per_turn`.
    pub fn clear_per_turn(&self) {
        self.clear_per_turn_in(&SessionId::default());
    }

    pub fn clear_per_turn_in(&self, session_id: &SessionId) {
        self.clear_by_scope(Some(session_id), BareLifetime::PerTurn);
    }

    /// Clear every latched event whose scope lifetime is `per_request`.
    pub fn clear_per_request(&self) {
        self.clear_per_request_in(&SessionId::default());
    }

    pub fn clear_per_request_in(&self, session_id: &SessionId) {
        self.clear_by_scope(Some(session_id), BareLifetime::PerRequest);
    }

    /// Clear every latched event whose scope lifetime is `per_session`.
    pub fn clear_per_session(&self) {
        self.clear_per_session_in(&SessionId::default());
    }

    pub fn clear_per_session_in(&self, session_id: &SessionId) {
        self.clear_by_scope(Some(session_id), BareLifetime::PerSession);
    }

    fn clear_by_scope(&self, session_id: Option<&SessionId>, scope: BareLifetime) {
        let cleared: Vec<(SessionId, EventId)> = {
            let mut inner = self.inner.lock().unwrap();
            let keys: Vec<(SessionId, EventId)> = inner
                .latched
                .iter()
                .filter_map(|((sid, id), entry)| {
                    let scope_match = entry
                        .scope_lifetime
                        .as_ref()
                        .map(|s| std::mem::discriminant(s) == std::mem::discriminant(&scope))
                        .unwrap_or(false);
                    let session_match = session_id.map(|s| s == sid).unwrap_or(true);
                    if scope_match && session_match {
                        Some((sid.clone(), id.clone()))
                    } else {
                        None
                    }
                })
                .collect();
            for k in &keys {
                inner.latched.remove(k);
            }
            keys
        };
        for (sid, id) in cleared {
            self.dispatch(&BusEvent::Cleared {
                session_id: sid,
                event_id: id,
                cause: ClearCause::Expired,
            });
        }
    }

    /// True iff any event is currently latched. Diagnostic helper.
    pub fn has_any_latched(&self) -> bool {
        !self.inner.lock().unwrap().latched.is_empty()
    }

    /// Snapshot of latched event ids for testing / introspection
    /// (cross-session view).
    pub fn latched_ids(&self) -> Vec<EventId> {
        self.inner
            .lock()
            .unwrap()
            .latched
            .keys()
            .map(|(_, id)| id.clone())
            .collect()
    }

    /// Snapshot of latched event ids belonging to `session_id`.
    pub fn latched_ids_in(&self, session_id: &SessionId) -> Vec<EventId> {
        self.inner
            .lock()
            .unwrap()
            .latched
            .keys()
            .filter_map(|(sid, id)| {
                if sid == session_id {
                    Some(id.clone())
                } else {
                    None
                }
            })
            .collect()
    }

    /// Read the payload of a latched event in the given session.
    pub fn payload_of_in(&self, session_id: &SessionId, event_id: &EventId) -> Option<Value> {
        self.inner
            .lock()
            .unwrap()
            .latched
            .get(&(session_id.clone(), event_id.clone()))
            .and_then(|e| e.payload.clone())
    }

    /// Read the payload of a latched event. Searches all sessions and
    /// returns the first match — convenience for legacy callers and
    /// tests that don't yet thread a session id.
    pub fn payload_of(&self, event_id: &EventId) -> Option<Value> {
        let inner = self.inner.lock().unwrap();
        for ((_, id), entry) in inner.latched.iter() {
            if id == event_id {
                return entry.payload.clone();
            }
        }
        None
    }

    // ── Subscribers ─────────────────────────────────────────────────

    /// Register a subscriber. `predicate` may filter what the callback sees;
    /// pass `None` to receive every event.
    pub fn subscribe<F>(&self, predicate: Option<Box<PredicateFn>>, callback: F) -> SubscriberHandle
    where
        F: FnMut(&BusEvent) + Send + 'static,
    {
        let mut inner = self.inner.lock().unwrap();
        let id = inner.next_subscriber_id;
        inner.next_subscriber_id += 1;
        inner.subscribers.push(Subscriber {
            id,
            predicate: predicate.map(Arc::from),
            callback: Arc::new(Mutex::new(Box::new(callback))),
            active: Arc::new(std::sync::atomic::AtomicBool::new(true)),
        });
        SubscriberHandle(id)
    }

    /// Unregister a subscriber. Returns `true` if it was present. Safe to
    /// call mid-dispatch: the in-flight callback (if any) will run, but no
    /// further notifications reach this subscriber.
    pub fn unsubscribe(&self, handle: SubscriberHandle) -> bool {
        let mut inner = self.inner.lock().unwrap();
        let before = inner.subscribers.len();
        // Mark inactive so any concurrent `dispatch` skips us.
        for s in &inner.subscribers {
            if s.id == handle.0 {
                s.active.store(false, std::sync::atomic::Ordering::SeqCst);
            }
        }
        inner.subscribers.retain(|s| s.id != handle.0);
        before != inner.subscribers.len()
    }

    fn dispatch(&self, ev: &BusEvent) {
        if DISPATCH_DEPTH.with(|depth| depth.get() > 0) {
            DEFERRED_DISPATCH.with(|pending| pending.borrow_mut().push_back(ev.clone()));
            return;
        }

        DISPATCH_DEPTH.with(|depth| depth.set(1));
        let _guard = DispatchGuard;
        let mut current = Some(ev.clone());
        while let Some(ev) = current {
            if catch_unwind(AssertUnwindSafe(|| self.dispatch_now(&ev))).is_err() {
                log::error!(
                    target: "agent_shield::event_bus",
                    "subscriber panicked during dispatch of event {}; continuing drain",
                    ev.event_id()
                );
            }
            current = DEFERRED_DISPATCH.with(|pending| pending.borrow_mut().pop_front());
        }
    }

    fn dispatch_now(&self, ev: &BusEvent) {
        // P3.3: snapshot Arc handles to every subscriber under the lock,
        // then release the lock before invoking each callback. This keeps
        // the registry intact so a re-entrant emit() inside a callback
        // sees the full subscriber set, and the per-subscriber callback
        // mutex prevents reentrancy on the same callback while still
        // allowing other subscribers to be invoked.
        let snapshot: Vec<SubscriberSnapshot> = {
            let g = self.inner.lock().unwrap();
            g.subscribers
                .iter()
                .map(|s| (s.predicate.clone(), s.callback.clone(), s.active.clone()))
                .collect()
        };
        for (pred, cb, active) in snapshot {
            if !active.load(std::sync::atomic::Ordering::SeqCst) {
                continue;
            }
            if catch_unwind(AssertUnwindSafe(|| {
                let pred_ok = pred.as_ref().is_none_or(|p| p(ev));
                if pred_ok {
                    let mut guard = cb.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
                    (guard)(ev);
                }
            }))
            .is_err()
            {
                log::error!(
                    target: "agent_shield::event_bus",
                    "subscriber panicked during dispatch of event {}; continuing drain",
                    ev.event_id()
                );
            }
        }
    }
}

// ── EventFiredHook impl ──────────────────────────────────────────────

impl EventFiredHook for EventBus {
    fn fired(&self, event_id: &str) -> bool {
        match EventId::parse(event_id) {
            Ok(id) => self.fired_id(&id),
            Err(_) => false,
        }
    }
}

impl EventFiredHook for Arc<EventBus> {
    fn fired(&self, event_id: &str) -> bool {
        EventBus::fired(self.as_ref(), event_id)
    }
}

// ── Tests ────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::Duration;
    use std::sync::atomic::{AtomicI64, Ordering};
    use std::sync::Arc;

    fn make_clock(t0: DateTime<Utc>) -> (ClockFn, Arc<AtomicI64>) {
        let secs = Arc::new(AtomicI64::new(t0.timestamp()));
        let secs_for_clock = secs.clone();
        let f: ClockFn = Arc::new(move || {
            DateTime::<Utc>::from_timestamp(secs_for_clock.load(Ordering::SeqCst), 0).unwrap()
        });
        (f, secs)
    }

    fn t0() -> DateTime<Utc> {
        DateTime::<Utc>::from_timestamp(1_700_000_000, 0).unwrap()
    }

    #[test]
    fn emit_then_fired_returns_true() {
        let bus = EventBus::new();
        bus.emit_turn_start().unwrap();
        assert!(bus.fired("turn.start"));
        assert!(!bus.fired("turn.end"));
    }

    #[test]
    fn fired_returns_false_for_invalid_id() {
        let bus = EventBus::new();
        assert!(!bus.fired("not.a.real.event"));
        assert!(!bus.fired("custom.foo"));
    }

    #[test]
    fn session_end_clears_all_latched_including_itself() {
        let bus = EventBus::new();
        bus.emit_turn_start().unwrap();
        bus.emit_request_start().unwrap();
        bus.emit_tool_called("send_email").unwrap();
        assert!(bus.has_any_latched());

        bus.emit_session_end().unwrap();
        // P3.4: session.end clears EVERY latch including itself.
        assert!(!bus.fired("turn.start"));
        assert!(!bus.fired("request.start"));
        assert!(!bus.fired("tool.send_email.called"));
        assert!(!bus.fired("session.end"));
        assert!(!bus.has_any_latched());
    }

    #[test]
    fn clear_event_clears_specific_latch() {
        let bus = EventBus::new();
        bus.emit_turn_start().unwrap();
        bus.emit_request_start().unwrap();
        assert!(bus.clear_event(&EventId::TurnStart));
        assert!(!bus.fired("turn.start"));
        assert!(bus.fired("request.start"));
    }

    #[test]
    fn clear_event_returns_false_when_not_latched() {
        let bus = EventBus::new();
        assert!(!bus.clear_event(&EventId::TurnStart));
    }

    #[test]
    fn for_lifetime_expires_on_read() {
        let (clock, secs) = make_clock(t0());
        let bus = EventBus::with_clock(clock);
        let lt = Lifetime::Bare(BareLifetime::For(Duration::seconds(60)));
        bus.emit(EventId::TurnStart, Some(lt), None).unwrap();
        assert!(bus.fired("turn.start"));

        // Advance past expiry.
        secs.store(t0().timestamp() + 61, Ordering::SeqCst);
        assert!(!bus.fired("turn.start"));
    }

    #[test]
    fn for_lifetime_does_not_expire_before_deadline() {
        let (clock, secs) = make_clock(t0());
        let bus = EventBus::with_clock(clock);
        let lt = Lifetime::Bare(BareLifetime::For(Duration::seconds(60)));
        bus.emit(EventId::TurnStart, Some(lt), None).unwrap();

        secs.store(t0().timestamp() + 30, Ordering::SeqCst);
        assert!(bus.fired("turn.start"));
    }

    #[test]
    fn until_event_triggers_clear() {
        let bus = EventBus::new();
        let lt = Lifetime::Bare(BareLifetime::UntilEvent(vec![EventId::TurnEnd]));
        bus.emit(EventId::TurnStart, Some(lt), None).unwrap();
        assert!(bus.fired("turn.start"));

        bus.emit_turn_end().unwrap();
        assert!(!bus.fired("turn.start"));
        assert!(bus.fired("turn.end"));
    }

    #[test]
    fn until_event_with_multiple_triggers() {
        let bus = EventBus::new();
        let lt = Lifetime::Bare(BareLifetime::UntilEvent(vec![
            EventId::TurnEnd,
            EventId::SessionEnd,
        ]));
        bus.emit(EventId::TurnStart, Some(lt), None).unwrap();

        bus.emit_turn_end().unwrap();
        assert!(!bus.fired("turn.start"));
    }

    #[test]
    fn map_lifetime_rejected_for_events() {
        use crate::lifetime::{LifetimeBranch, LifetimeMap};
        let bus = EventBus::new();
        let lt = Lifetime::Map(LifetimeMap {
            allow: LifetimeBranch::Bare(BareLifetime::PerCall),
            deny: LifetimeBranch::Bare(BareLifetime::PerCall),
            cancelled: None,
        });
        let err = bus.emit(EventId::TurnStart, Some(lt), None).unwrap_err();
        assert!(matches!(err, EmitError::MapLifetimeRejected));
    }

    #[test]
    fn incident_event_round_trips() {
        let bus = EventBus::new();
        bus.emit_incident("incident.threat_detected", None, None)
            .unwrap();
        assert!(bus.fired("incident.threat_detected"));
    }

    #[test]
    fn incident_event_rejects_invalid_grammar() {
        let bus = EventBus::new();
        assert!(bus.emit_incident("incident.Foo", None, None).is_err());
        assert!(bus.emit_incident("incident.", None, None).is_err());
        assert!(bus.emit_incident("custom.foo", None, None).is_err());
    }

    #[test]
    fn payload_round_trips() {
        let bus = EventBus::new();
        let payload = serde_json::json!({"value": 42});
        bus.emit_approval(
            "deploy_prod",
            ApprovalEventKind::Allow,
            None,
            Some(payload.clone()),
        )
        .unwrap();
        let id = EventId::Approval {
            variable: "deploy_prod".into(),
            kind: ApprovalEventKind::Allow,
        };
        assert_eq!(bus.payload_of(&id), Some(payload));
    }

    #[test]
    fn subscriber_receives_emit_and_clear() {
        let bus = EventBus::new();
        let log = Arc::new(Mutex::new(Vec::<String>::new()));
        let log_cb = log.clone();
        bus.subscribe(None, move |ev| match ev {
            BusEvent::Emitted { event_id, .. } => {
                log_cb.lock().unwrap().push(format!("emit:{}", event_id));
            }
            BusEvent::Cleared { event_id, .. } => {
                log_cb.lock().unwrap().push(format!("clear:{}", event_id));
            }
        });

        bus.emit_turn_start().unwrap();
        bus.clear_event(&EventId::TurnStart);
        let entries = log.lock().unwrap().clone();
        assert_eq!(
            entries,
            vec!["emit:turn.start".to_string(), "clear:turn.start".into()]
        );
    }

    #[test]
    fn subscriber_predicate_filters() {
        let bus = EventBus::new();
        let count = Arc::new(Mutex::new(0u32));
        let count_cb = count.clone();
        bus.subscribe(
            Some(Box::new(|ev| matches!(ev, BusEvent::Emitted { .. }))),
            move |_| {
                *count_cb.lock().unwrap() += 1;
            },
        );
        bus.emit_turn_start().unwrap();
        bus.clear_event(&EventId::TurnStart);
        assert_eq!(*count.lock().unwrap(), 1);
    }

    #[test]
    fn unsubscribe_removes_listener() {
        let bus = EventBus::new();
        let count = Arc::new(Mutex::new(0u32));
        let count_cb = count.clone();
        let h = bus.subscribe(None, move |_| {
            *count_cb.lock().unwrap() += 1;
        });
        bus.emit_turn_start().unwrap();
        assert!(bus.unsubscribe(h));
        bus.emit_turn_end().unwrap();
        assert_eq!(*count.lock().unwrap(), 1);
    }

    #[test]
    fn re_emission_marks_refreshed() {
        let bus = EventBus::new();
        let seen = Arc::new(Mutex::new(Vec::<bool>::new()));
        let seen_cb = seen.clone();
        bus.subscribe(None, move |ev| {
            if let BusEvent::Emitted { refreshed, .. } = ev {
                seen_cb.lock().unwrap().push(*refreshed);
            }
        });
        bus.emit_turn_start().unwrap();
        bus.emit_turn_start().unwrap();
        let v = seen.lock().unwrap().clone();
        assert_eq!(v, vec![false, true]);
    }

    #[test]
    fn re_emission_replaces_lifetime() {
        let (clock, secs) = make_clock(t0());
        let bus = EventBus::with_clock(clock);
        bus.emit(
            EventId::TurnStart,
            Some(Lifetime::Bare(BareLifetime::For(Duration::seconds(10)))),
            None,
        )
        .unwrap();
        // Re-emit with a much longer lifetime.
        bus.emit(
            EventId::TurnStart,
            Some(Lifetime::Bare(BareLifetime::For(Duration::seconds(1_000)))),
            None,
        )
        .unwrap();
        secs.store(t0().timestamp() + 100, Ordering::SeqCst);
        // Without the replacement we'd be expired by now.
        assert!(bus.fired("turn.start"));
    }

    #[test]
    fn required_emitter_helpers_match_event_ids() {
        let bus = EventBus::new();
        bus.emit_session_start().unwrap();
        bus.emit_turn_start().unwrap();
        bus.emit_request_start().unwrap();
        bus.emit_tool_called("t").unwrap();
        bus.emit_tool_success("t").unwrap();
        bus.emit_tool_failure("t").unwrap();
        bus.emit_endpoint_called("/v1/x").unwrap();
        bus.emit_endpoint_success("/v1/x").unwrap();
        bus.emit_endpoint_failure("/v1/x").unwrap();
        bus.emit_agent_called("a").unwrap();
        bus.emit_agent_success("a").unwrap();
        bus.emit_agent_failure("a").unwrap();
        bus.emit_variable_changed("v").unwrap();
        bus.emit_guard_policy_activated("g").unwrap();
        bus.emit_guard_policy_deactivated("g").unwrap();
        bus.emit_guard_policy_passed("g").unwrap();
        bus.emit_guard_policy_failed("g").unwrap();
        bus.emit_approval("v", ApprovalEventKind::Allow, None, None)
            .unwrap();

        for id in [
            "session.start",
            "turn.start",
            "request.start",
            "tool.t.called",
            "tool.t.success",
            "tool.t.failure",
            "endpoint./v1/x.called",
            "endpoint./v1/x.success",
            "endpoint./v1/x.failure",
            "agent.a.called",
            "agent.a.success",
            "agent.a.failure",
            "variable.v.changed",
            "guard_policy.g.activated",
            "guard_policy.g.deactivated",
            "guard_policy.g.passed",
            "guard_policy.g.failed",
            "approval.v.allow",
        ] {
            assert!(bus.fired(id), "missing latch for {}", id);
        }
    }

    #[test]
    fn event_fired_hook_trait_implemented() {
        let bus: Arc<EventBus> = Arc::new(EventBus::new());
        bus.emit_turn_start().unwrap();
        let hook: &dyn EventFiredHook = &bus;
        assert!(hook.fired("turn.start"));
        assert!(!hook.fired("turn.end"));
    }

    /// A subscriber whose callback re-enters the bus should NOT deadlock.
    #[test]
    fn subscriber_can_re_enter_bus() {
        let bus = Arc::new(EventBus::new());
        let bus_cb = bus.clone();
        bus.subscribe(
            Some(Box::new(|ev| {
                matches!(ev, BusEvent::Emitted { event_id, .. } if matches!(event_id, EventId::TurnStart))
            })),
            move |_| {
                let _ = bus_cb.fired("turn.start");
                let _ = bus_cb.emit_turn_end();
            },
        );
        bus.emit_turn_start().unwrap();
        assert!(bus.fired("turn.end"));
    }

    #[test]
    fn dispatch_reentrant_does_not_deadlock_and_preserves_fifo() {
        let bus = Arc::new(EventBus::new());
        let seen = Arc::new(Mutex::new(Vec::<String>::new()));

        let bus_cb = bus.clone();
        let seen_cb = seen.clone();
        bus.subscribe(None, move |ev| {
            if let BusEvent::Emitted { event_id, .. } = ev {
                seen_cb.lock().unwrap().push(event_id.to_string());
                if matches!(event_id, EventId::TurnStart) {
                    bus_cb.emit_turn_end().unwrap();
                    bus_cb.emit_request_start().unwrap();
                }
            }
        });

        bus.emit_turn_start().unwrap();
        assert_eq!(
            *seen.lock().unwrap(),
            vec![
                "turn.start".to_string(),
                "turn.end".to_string(),
                "request.start".to_string(),
            ]
        );
    }

    #[test]
    fn dispatch_depth_reset_after_clean_dispatch() {
        let bus = EventBus::new();
        bus.emit_turn_start().unwrap();

        let seen = Arc::new(Mutex::new(Vec::<String>::new()));
        let seen_cb = seen.clone();
        bus.subscribe(None, move |ev| {
            if let BusEvent::Emitted { event_id, .. } = ev {
                seen_cb.lock().unwrap().push(event_id.to_string());
            }
        });

        bus.emit_turn_end().unwrap();
        assert_eq!(*seen.lock().unwrap(), vec!["turn.end".to_string()]);
        DISPATCH_DEPTH.with(|depth| assert_eq!(depth.get(), 0));
        DEFERRED_DISPATCH.with(|pending| assert!(pending.borrow().is_empty()));
    }

    #[test]
    fn defer_during_replay_chains_correctly() {
        let bus = Arc::new(EventBus::new());
        let seen = Arc::new(Mutex::new(Vec::<String>::new()));

        let bus_cb = bus.clone();
        let seen_cb = seen.clone();
        bus.subscribe(None, move |ev| {
            if let BusEvent::Emitted { event_id, .. } = ev {
                seen_cb.lock().unwrap().push(event_id.to_string());
                match event_id {
                    EventId::TurnStart => bus_cb.emit_turn_end().unwrap(),
                    EventId::TurnEnd => bus_cb.emit_request_start().unwrap(),
                    _ => {}
                }
            }
        });

        bus.emit_turn_start().unwrap();
        assert_eq!(
            *seen.lock().unwrap(),
            vec![
                "turn.start".to_string(),
                "turn.end".to_string(),
                "request.start".to_string(),
            ]
        );
    }

    #[test]
    fn panicking_subscriber_does_not_break_subsequent_dispatch() {
        let bus = EventBus::new();
        let seen = Arc::new(Mutex::new(Vec::<String>::new()));

        let seen_a = seen.clone();
        bus.subscribe(None, move |ev| {
            if let BusEvent::Emitted { event_id, .. } = ev {
                seen_a.lock().unwrap().push(format!("a:{event_id}"));
                if matches!(event_id, EventId::TurnStart) {
                    panic!("subscriber A panicked on X");
                }
            }
        });

        let seen_b = seen.clone();
        bus.subscribe(None, move |ev| {
            if let BusEvent::Emitted { event_id, .. } = ev {
                seen_b.lock().unwrap().push(format!("b:{event_id}"));
            }
        });

        bus.emit_turn_start().unwrap();
        bus.emit_turn_end().unwrap();

        assert_eq!(
            *seen.lock().unwrap(),
            vec![
                "a:turn.start".to_string(),
                "b:turn.start".to_string(),
                "a:turn.end".to_string(),
                "b:turn.end".to_string(),
            ]
        );
        DISPATCH_DEPTH.with(|depth| assert_eq!(depth.get(), 0));
        DEFERRED_DISPATCH.with(|pending| assert!(pending.borrow().is_empty()));
    }

    #[test]
    fn cross_thread_dispatch_serializes_per_subscriber() {
        use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};

        let bus = Arc::new(EventBus::new());
        let in_callback = Arc::new(AtomicBool::new(false));
        let interleaved = Arc::new(AtomicBool::new(false));
        let count = Arc::new(AtomicUsize::new(0));

        let in_callback_cb = in_callback.clone();
        let interleaved_cb = interleaved.clone();
        let count_cb = count.clone();
        bus.subscribe(None, move |_| {
            if in_callback_cb.swap(true, Ordering::SeqCst) {
                interleaved_cb.store(true, Ordering::SeqCst);
            }
            std::thread::sleep(std::time::Duration::from_millis(1));
            count_cb.fetch_add(1, Ordering::SeqCst);
            in_callback_cb.store(false, Ordering::SeqCst);
        });

        let t1_bus = bus.clone();
        let t1 = std::thread::spawn(move || {
            for i in 0..10 {
                t1_bus
                    .emit_incident(&format!("incident.thread_one_{i}"), None, None)
                    .unwrap();
            }
        });
        let t2_bus = bus.clone();
        let t2 = std::thread::spawn(move || {
            for i in 0..10 {
                t2_bus
                    .emit_incident(&format!("incident.thread_two_{i}"), None, None)
                    .unwrap();
            }
        });

        t1.join().unwrap();
        t2.join().unwrap();
        assert_eq!(count.load(Ordering::SeqCst), 20);
        assert!(!interleaved.load(Ordering::SeqCst));
    }

    // ── Review-amendment tests (P3.2, P3.3, P3.4, P3.5) ─────────────

    /// P3.2: per_turn-scoped event clears via `clear_per_turn`.
    #[test]
    fn p3_2_per_turn_event_cleared_at_turn_boundary() {
        let bus = EventBus::new();
        bus.emit(
            EventId::Tool {
                name: "foo".into(),
                kind: ToolEventKind::Success,
            },
            Some(Lifetime::Bare(BareLifetime::PerTurn)),
            None,
        )
        .unwrap();
        assert!(bus.fired("tool.foo.success"));
        bus.clear_per_turn();
        assert!(!bus.fired("tool.foo.success"));
    }

    /// P3.2: per_call-scoped event clears via `clear_per_call`.
    #[test]
    fn p3_2_per_call_event_cleared() {
        let bus = EventBus::new();
        bus.emit(
            EventId::Tool {
                name: "bar".into(),
                kind: ToolEventKind::Success,
            },
            Some(Lifetime::Bare(BareLifetime::PerCall)),
            None,
        )
        .unwrap();
        assert!(bus.fired("tool.bar.success"));
        bus.clear_per_call();
        assert!(!bus.fired("tool.bar.success"));
        // A per-turn clear MUST NOT affect per-call latches (no scope match).
    }

    /// P3.2: per_request-scoped event clears via `clear_per_request`.
    #[test]
    fn p3_2_per_request_event_cleared() {
        let bus = EventBus::new();
        bus.emit(
            EventId::Tool {
                name: "baz".into(),
                kind: ToolEventKind::Success,
            },
            Some(Lifetime::Bare(BareLifetime::PerRequest)),
            None,
        )
        .unwrap();
        assert!(bus.fired("tool.baz.success"));
        // Different scope clear MUST NOT touch this latch.
        bus.clear_per_turn();
        assert!(bus.fired("tool.baz.success"));
        bus.clear_per_request();
        assert!(!bus.fired("tool.baz.success"));
    }

    /// P3.3: a callback emitting a second event sees other subscribers
    /// receive the nested notification — the registry stays intact.
    #[test]
    fn p3_3_nested_emit_reaches_other_subscribers() {
        use std::sync::atomic::{AtomicU32, Ordering};
        let bus = Arc::new(EventBus::new());

        let b_count = Arc::new(AtomicU32::new(0));
        let b_count_cb = b_count.clone();
        // Subscriber B watches turn.end (the nested event).
        bus.subscribe(
            Some(Box::new(|ev| {
                matches!(ev, BusEvent::Emitted { event_id, .. } if matches!(event_id, EventId::TurnEnd))
            })),
            move |_| {
                b_count_cb.fetch_add(1, Ordering::SeqCst);
            },
        );

        // Subscriber A watches turn.start and emits turn.end during its
        // callback — B must receive turn.end.
        let bus_cb = bus.clone();
        bus.subscribe(
            Some(Box::new(|ev| {
                matches!(ev, BusEvent::Emitted { event_id, .. } if matches!(event_id, EventId::TurnStart))
            })),
            move |_| {
                let _ = bus_cb.emit_turn_end();
            },
        );

        bus.emit_turn_start().unwrap();
        assert_eq!(
            b_count.load(Ordering::SeqCst),
            1,
            "nested emit didn't reach subscriber B"
        );
    }

    /// P3.3: unsubscribe via SubscriberHandle works mid-dispatch.
    #[test]
    fn p3_3_unsubscribe_mid_dispatch_takes_effect() {
        use std::sync::atomic::{AtomicU32, Ordering};
        let bus = Arc::new(EventBus::new());

        let count = Arc::new(AtomicU32::new(0));
        let count_cb = count.clone();
        let h = bus.subscribe(None, move |_| {
            count_cb.fetch_add(1, Ordering::SeqCst);
        });

        bus.emit_turn_start().unwrap();
        assert_eq!(count.load(Ordering::SeqCst), 1);

        assert!(bus.unsubscribe(h));
        bus.emit_turn_end().unwrap();
        assert_eq!(count.load(Ordering::SeqCst), 1);
    }

    /// P3.5: an EventId constructed with an invalid Incident name is
    /// rejected at emit time.
    #[test]
    fn p3_5_invalid_incident_name_rejected_at_emit() {
        let bus = EventBus::new();
        let result = bus.emit(
            EventId::Incident {
                name: "Bad-Name".into(),
            },
            None,
            None,
        );
        assert!(matches!(result, Err(EmitError::InvalidEventId(..))));
    }

    /// P3.5: `emit_approval` with an invalid variable name is rejected.
    #[test]
    fn p3_5_invalid_approval_variable_rejected() {
        let bus = EventBus::new();
        let result = bus.emit_approval("Bad-Name", ApprovalEventKind::Allow, None, None);
        assert!(matches!(result, Err(EmitError::InvalidEventId(..))));
    }
}
