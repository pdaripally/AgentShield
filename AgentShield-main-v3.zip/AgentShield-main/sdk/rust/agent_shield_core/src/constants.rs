//! Canonical home for runtime numeric and string defaults.
//!
//! Constants are grouped by subsystem so the call sites can `use
//! crate::constants::loader::MAX_EXTENDS_DEPTH;` (etc.) and so adding
//! a new constant has an obvious place to live.
//!
//! Spec section anchors are recorded next to each value — change them
//! together when the spec moves.

/// Loader / `extends:` chain limits.
pub mod loader {
    /// Maximum `extends:` chain depth. implementations
    /// to support at least 10 levels.
    pub const MAX_EXTENDS_DEPTH: usize = 10;

    /// Maximum number of remote `extends:` fetches per top-level load.
    /// Bounds total HTTP traffic for a single configuration load
    /// regardless of chain shape; a remote-heavy chain failing this
    /// cap is a load-time error. Spec.
    pub const MAX_REMOTE_FETCHES: usize = 32;

    /// Maximum body size (bytes) accepted from a single remote
    /// `extends:` fetch. The cap is enforced while reading the
    /// response body — over-cap responses fail closed without
    /// buffering. Spec.
    pub const MAX_REMOTE_BODY_BYTES: usize = 1_048_576; // 1 MiB

    /// Maximum cumulative bytes across all remote `extends:` fetches
    /// for a single top-level load. Spec.
    pub const MAX_REMOTE_TOTAL_BYTES: usize = 8 * 1_048_576; // 8 MiB

    /// Per-fetch HTTP timeout (seconds). Spec.
    pub const REMOTE_FETCH_TIMEOUT_SECS: u64 = 30;

    /// Maximum HTTP redirects accepted per remote `extends:` fetch.
    /// All redirects MUST stay on `https://`. Spec.
    pub const MAX_REMOTE_REDIRECTS: usize = 5;

    /// Maximum byte size of a UTF-8 prompt file loaded via
    /// `evaluate_when[].llm.prompt_path`. The cap is enforced
    /// while reading — over-cap files fail closed without buffering the
    /// full contents. Spec SHOULD: "implementation-defined, at
    /// least 64 KiB"; this is the floor.
    pub const MAX_PROMPT_FILE_BYTES: usize = 64 * 1024;
}

/// Variable-merge engine limits.
pub mod merge {
    /// Maximum object-nesting depth allowed in a merged value.
    /// Spec last paragraph requires implementations to support
    /// at least 10 levels; we accept up to 10 and reject at 11+.
    /// `Value::Object` levels accumulate; arrays do not count.
    pub const MAX_OBJECT_DEPTH: usize = 10;
}

/// Stage-3 (`tool_execution_validation`) prompt-enrichment tunables.
pub mod stage_tool_exec {
    /// Per-prior-tool-result truncation cap when enriching `{user_input}`
    /// with `## START TOOL RESPONSE: <name> ##` boundary markers.
    /// Spec SHOULD: "tool result content, truncated to a reasonable
    /// maximum (e.g., 2000 characters each)."
    pub const TOOL_RESULT_TRUNCATION: usize = 2000;

    /// Maximum number of prior tool results retained for enrichment in
    /// the current turn. Bounds the per-turn buffer so a verbose tool
    /// loop cannot grow it unboundedly. Older entries are dropped FIFO.
    pub const MAX_RETAINED_RESULTS: usize = 32;
}

/// Streaming guard tunables (Stages 4 & 5; spec).
///
/// The spec doesn't pin a chunk boundary; these are the chosen
/// defaults. Hosts override per-stage via [`crate::runtime::builder::StreamingOptions`].
pub mod streaming {
    /// Maximum buffer size before the stream guard fails closed (1 MiB).
    pub const STREAM_BUFFER_MAX_BYTES: usize = 1_048_576;
    /// Default window size for `Windowed` mode (bytes).
    pub const DEFAULT_WINDOW_SIZE: usize = 1000;
    /// Default overlap between successive validations (bytes).
    pub const DEFAULT_OVERLAP: usize = 200;
    /// How far we look back when snapping to a natural boundary.
    pub const LOOKBACK_WINDOW: usize = 64;
}

/// Resolver runtime limits.
pub mod resolver {
    /// Maximum resolver-fallback chain depth. /// implementations to support at least 5 links; we cap at 16 to
    /// guard against runaway recursion if cycle detection misses a
    /// degenerate case.
    pub const MAX_CHAIN_DEPTH: usize = 16;

    /// Default retry limit per (turn, variable, tool) for `kind: tool`
    /// resolvers. Spec RECOMMENDED value is 3.
    pub const DEFAULT_TOOL_RETRY_LIMIT: u32 = 3;
}

/// Default per-protocol timeouts for `kind: delegate` resolvers.
pub mod delegate {
    /// Default HTTP-endpoint dispatch timeout.
    pub const HTTP_DEFAULT_TIMEOUT_MS: u32 = 30_000;
    /// Default MCP-server dispatch timeout.
    pub const MCP_DEFAULT_TIMEOUT_MS: u32 = 30_000;
    /// Default A2A-agent dispatch timeout.
    pub const A2A_DEFAULT_TIMEOUT_MS: u32 = 30_000;
    /// Default classifier-config dispatch timeout.
    pub const CLASSIFIER_DEFAULT_TIMEOUT_MS: u32 = 30_000;
}

/// Default timeout for host-supplied populator [`Extractor`] callbacks.
///
/// [`Extractor`]: crate::populator::Extractor
pub mod populator {
    /// Default wall-clock deadline for a host-supplied
    /// [`crate::populator::Extractor`] callback. Spec /// mandates that "A populator MUST NOT block the call"; the
    /// reference runtime enforces this by wrapping each registry
    /// extractor on a worker thread and waiting at most this many
    /// milliseconds for it to return. On expiry the populator fails
    /// through the existing fail-closed path (IFC variables escalate
    /// to the lattice top via `variable.<name>.populator_null`;
    /// non-IFC variables retain their prior state). 5 s is generous
    /// for pure data extraction — well-behaved extractors return in
    /// microseconds.
    pub const EXTRACTOR_DEFAULT_TIMEOUT_MS: u32 = 5_000;
}

/// Default timeouts for `evaluate_when[].llm` / `evaluate_when[].classifier`
/// detector callbacks (/). `configurations[].timeout`
/// as a positive ms timeout for provider calls and requires those calls to be
/// wrapped with the timeout and routed through `on_error`. When the
/// configuration omits `timeout:` the runtime falls back to these per-kind
/// defaults (30 000 ms each, matching the `delegate` HTTP defaults).
pub mod detector {
    /// Default `evaluate_when[].llm` host-caller wall-clock timeout.
    /// Matches [`super::delegate::HTTP_DEFAULT_TIMEOUT_MS`] — the LLM
    /// detection path is HTTP-shaped at the wire level and shares the
    /// same fail-closed posture.
    pub const LLM_DEFAULT_TIMEOUT_MS: u32 = 30_000;
    /// Default `evaluate_when[].classifier` host-caller wall-clock timeout.
    /// Matches [`super::delegate::CLASSIFIER_DEFAULT_TIMEOUT_MS`].
    pub const CLASSIFIER_DEFAULT_TIMEOUT_MS: u32 = 30_000;
}

/// Default timeout for `kind: agent` resolvers.
pub mod agent {
    /// Default `kind: agent` host-channel response timeout. Spec /// "Default timeouts" table fixes the reference-runtime value at
    /// 60 000 ms; the Pure Specification requirement is only that every
    /// resolver kind has a *finite* timeout and that timeout failures
    /// are routed through the resolver's `on_error:` policy.
    pub const AGENT_DEFAULT_TIMEOUT_MS: u32 = 60_000;
}

/// Expression-language evaluator limits.
pub mod expressions {
    /// Maximum allowed regex pattern length to prevent ReDoS attacks.
    pub const MAX_REGEX_LENGTH: usize = 500;
    /// Maximum predicate-name resolution depth.
    pub const MAX_PREDICATE_DEPTH: usize = 10;
    /// Scope-namespace identifiers that MUST NOT trigger resolver
    /// auto-resolution or fall through to predicate lookup
    /// All `@`-prefixed runtime namespaces
    /// of the spec.
    pub const SCOPE_NAMESPACES: &[&str] = &["@tool", "@endpoint", "@agent", "@context", "@result"];
}
