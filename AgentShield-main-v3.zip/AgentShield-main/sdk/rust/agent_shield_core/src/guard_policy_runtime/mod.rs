//! guard-policy runtime engine — the unified gating dispatcher.
//!
//! This module turns a merged [`crate::merge::MergedConfig`] plus
//! per-call runtime context into pass/fail verdicts for each of the five
//! validation stages defined in–of the spec.
//!
//! ## Public surface
//!
//! - [`GuardPolicyEngine`] — the dispatcher. One instance per session.
//! - [`GuardPolicyDeps`] — construction-time wiring (config, bus, tracker,
//!   resolver, observability).
//! - [`EvalRuntime`] — per-call attribute snapshot.
//! - [`StageVerdict`] — the result of every `evaluate_*` call.
//! - [`StreamingGuard`] — chunk-aware wrapper for Stages 4 & 5.
//!
//! ## Spec alignment
//!
//! | Spec section | Module |
//! |--------------|--------|
//! | (selectors) / (specificity) | [`selector`] |
//! | (active_if) | [`activation`] |
//! | (evaluate_when) / (semantics) | [`evaluate_when`] |
//! | (detection kinds) | [`detection`] |
//! | (allowed_when) | [`allowed_when`] |
//! | (action modes) / (spans) | [`action`] |
//! | (parameter transforms) | [`transforms`] |
//! | (per-stage rules) | [`stage_input`], [`stage_state`], [`stage_tool_exec`], [`stage_post_tool`], [`stage_output`] |
//! | streaming | [`streaming`] |
//!
//! ## Spec ambiguities & resolutions
//!
//! - **Classifier contract**: "Score ≥ threshold ⇒
//!   fail", but the threshold can live on the configuration entry rather
//!   than the policy. We expose both: hosts return a [`detection::ClassifierVerdict`]
//!   carrying `score`, `threshold`, and an explicit `flagged` bool. The
//!   entry fails when either condition is true. This lets label-based
//!   classifiers (which don't emit per-span offsets) report through the
//!   same interface.
//! - **Multi-policy ordering** (): "Implementations MAY run
//!   independent entries in parallel for performance, but the *visible*
//!   verdict-resolution order MUST be declaration order." We evaluate
//!   policies sequentially in merged-file declaration order — the order
//!   that comes out of [`crate::merge::merge_chain`].
//! - **Streaming windowing**: the spec doesn't pin a chunk
//!   boundary. See [`streaming::DEFAULT_WINDOW_SIZE`] /
//!   [`streaming::DEFAULT_OVERLAP`] / [`streaming::LOOKBACK_WINDOW`] /
//!   [`streaming::STREAM_BUFFER_MAX_BYTES`] for the chosen defaults.

pub mod action;
pub mod activation;
pub mod allowed_when;
pub mod detection;
pub mod errors;
pub mod evaluate_when;
pub mod runtime_hooks;
pub mod selector;
pub mod stage_common;
pub mod stage_input;
pub mod stage_output;
pub mod stage_post_tool;
pub mod stage_state;
pub(crate) mod stage_timing;
pub mod stage_tool_exec;
pub mod streaming;
pub mod transforms;

#[cfg(test)]
mod tests_support;

#[cfg(test)]
mod tests_engine;

pub use action::{apply_prepend_append, apply_redactions};
pub use activation::ActivationCache;
pub use allowed_when::evaluate_allowed_when;
pub use detection::{
    detect, ClassifierCaller, ClassifierCallerArc, ClassifierError, ClassifierVerdict,
    DetectionDeps, DetectionVerdict, LlmCaller, LlmCallerArc, LlmDecision, LlmResponse, RegexCache,
    Span,
};
pub use errors::GuardPolicyRuntimeError;
pub use evaluate_when::{
    effective_action, effective_replacement, run_evaluate_when, AllowedWhenDeps, BlockedEntry,
    EvaluationOutcome, TransformText, TriggeredEntry,
};
pub use selector::{applies_to_matches, pick_best_endpoint, ListedNames, SelectorSubject};
pub use streaming::{StreamChunkAction, StreamChunkResult, StreamingGuard};

use std::collections::HashMap;
use std::sync::Arc;

use serde_json::Value;

use crate::clock::Clock;
use crate::event_bus::EventBus;
use crate::guard_policy::Action;
use crate::lifetime_tracker::LifetimeTracker;
use crate::merge::MergedConfig;
use crate::observability::{ObservabilityDispatcher, Stage as ObsStage};
use crate::perf_telemetry::PerfTelemetry;
use crate::populator::Invocation;
use crate::resolver_runtime::ResolverDispatcher;

/// Construction-time dependencies for [`GuardPolicyEngine`].
pub struct GuardPolicyDeps {
    pub config: Arc<MergedConfig>,
    pub event_bus: EventBus,
    pub tracker: Arc<LifetimeTracker>,
    pub resolver: Arc<ResolverDispatcher>,
    pub observability: Arc<ObservabilityDispatcher>,
    /// Optional host-supplied LLM caller used by `llm:` detection entries.
    /// When `None`, `llm:` entries fail closed (block) and emit a warning.
    pub llm_caller: Option<Arc<dyn LlmCaller>>,
    /// Optional host-supplied classifier caller used by `classifier:`
    /// entries. When `None`, those entries fail closed.
    pub classifier_caller: Option<Arc<dyn ClassifierCaller>>,
    /// Clock used by the perf-telemetry instrumentation (v8 plan PR6)
    /// to measure stage / policy / detection / LLM / classifier
    /// latency. Defaults to [`crate::clock::SystemClock`] via
    /// [`crate::runtime::RuntimeBuilder`]; tests override with
    /// [`crate::clock::MockClock`] for determinism.
    pub clock: Arc<dyn Clock>,
    /// Perf-telemetry gating knob (v8 plan PR5/PR6). Default
    /// [`PerfTelemetry::Off`] — the stage runners short-circuit every
    /// new perf emission. See [`crate::perf_telemetry`] for the
    /// per-event gating table.
    pub perf_telemetry: PerfTelemetry,
}

/// Per-call runtime snapshot. Reused across stages within a single tool
/// invocation. The engine reads `request_context` as `context.*` in
/// expressions.
pub struct EvalRuntime<'a> {
    pub session_id: &'a str,
    pub correlation_id: &'a str,
    pub user_id: Option<&'a str>,
    pub tenant_id: Option<&'a str>,
    pub request_context: Value,
    pub turn_id: u64,
    /// Objective text — bound into prompts as `{objective}`.
    pub objective: &'a str,
    /// Forbidden goals — bound as `{forbidden}`.
    pub forbidden: &'a [String],
    /// User input for the current turn — bound as `{user_input}` and
    /// surfaces in the canonical template variable set. For Stage-3
    /// LLM detection prompts the session enriches this string with
    /// `## START TOOL RESPONSE: <tool> ##` boundary markers
    /// before constructing the runtime.
    pub user_input: &'a str,
    /// Comma-separated list of currently-active guard-policy names —
    /// bound as the `{active_guard_policies}` template variable.
    /// Empty string at non-Stage-3 entry points.
    pub active_guard_policies: &'a str,
    /// JSON-encoded snapshot of every variable currently `Resolved` —
    /// bound as the `{variables}` template variable. Empty string
    /// at non-Stage-3 entry points.
    pub variables_snapshot: &'a str,
    /// Plain-English summary of Stage-2 (`state_validation`) guard
    /// policies that ran for the current invocation — bound as the
    /// `{prior_checks_summary}` template variable. Empty string
    /// at non-Stage-3 entry points.
    pub prior_checks_summary: &'a str,
}

impl<'a> EvalRuntime<'a> {
    pub fn minimal(session_id: &'a str, correlation_id: &'a str) -> Self {
        Self {
            session_id,
            correlation_id,
            user_id: None,
            tenant_id: None,
            request_context: Value::Null,
            turn_id: 0,
            objective: "",
            forbidden: &[],
            user_input: "",
            active_guard_policies: "",
            variables_snapshot: "",
            prior_checks_summary: "",
        }
    }

    /// Build the attribute namespace seen by expression evaluation.
    /// Binds `context.*` from `request_context` plus the
    /// well-known `tool` / `endpoint` / `agent` namespaces.
    pub fn build_base_attrs(&self) -> HashMap<String, Value> {
        let mut attrs: HashMap<String, Value> = HashMap::new();
        if !matches!(self.request_context, Value::Null) {
            attrs.insert("@context".into(), self.request_context.clone());
        }
        let mut session = serde_json::Map::new();
        session.insert("id".into(), Value::String(self.session_id.to_string()));
        if let Some(uid) = self.user_id {
            session.insert("user_id".into(), Value::String(uid.to_string()));
        }
        if let Some(tid) = self.tenant_id {
            session.insert("tenant_id".into(), Value::String(tid.to_string()));
        }
        attrs.insert("session".into(), Value::Object(session));
        attrs.insert(
            "correlation_id".into(),
            Value::String(self.correlation_id.to_string()),
        );
        attrs
    }
}

/// One redaction / append / prepend transform that fired during a stage
/// evaluation, captured for audit and developer-UX purposes. Each entry
/// carries enough provenance to answer "which policy
/// rewrote which byte range with what?" — the spec already supports
/// per-policy span tracking via [`EvaluationOutcome::redactions_by_entry`],
/// but previously the verdict surface dropped it.
///
/// For redactions, `span_start` / `span_end` are inclusive-start /
/// exclusive-end **character (codepoint)** offsets against the
/// pre-transform subject (matching [`Span`]). For `append` / `prepend`
/// transforms the spans are `None` and `text` carries the appended /
/// prepended string instead.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AppliedTransform {
    /// Guard policy that produced this transform.
    pub policy: String,
    /// Index of the originating `evaluate_when[]` entry within `policy`.
    pub evaluate_when_index: usize,
    /// Which action was applied — `Redact`, `Append`, or `Prepend`.
    pub action: Action,
    /// Codepoint offset at which the transform begins (redactions only).
    pub span_start: Option<usize>,
    /// Codepoint offset (exclusive) at which the transform ends
    /// (redactions only).
    pub span_end: Option<usize>,
    /// Replacement substring for `Redact`. For `Append` / `Prepend` this
    /// holds the appended / prepended text.
    pub replacement: Option<String>,
}

/// Verdict produced by every per-stage `evaluate_*` method. Mirrors
/// `StageVerdict` from the runtime API description.
#[derive(Debug, Clone)]
pub struct StageVerdict {
    /// `true` ⇒ the call may proceed.
    pub allowed: bool,
    /// The action that determined the verdict (Block when blocked; None
    /// when the call passed cleanly; warn/redact/append/prepend when a
    /// transform fired but the call still passes).
    pub action: Option<Action>,
    /// Resolved reason text. `None` when allowed with no transform.
    pub reason: Option<String>,
    /// Failing policy name, when applicable. For `redact` / `warn` /
    /// `append` / `prepend` verdicts (where multiple policies may have
    /// fired) this names the **last** policy that contributed a
    /// transform — the full manifest lives in `applied_transforms`.
    pub policy: Option<String>,
    /// Index of the failing `evaluate_when[]` entry, when applicable.
    /// Mirrors `policy`: for multi-policy transform verdicts this is the
    /// index of the last contributing entry; consult
    /// `applied_transforms` for the full provenance.
    pub evaluate_when_index: Option<usize>,
    /// `true` if the gate would have failed but was bypassed via
    /// `allowed_when:`. Always logged as an `allow`.
    pub bypassed_by_allowed_when: bool,
    /// `Some(...)` when a `redact` transform produced a final string for
    /// content stages (Stages 1, 4, 5). For Stage 3 the host reads the
    /// transformed `Invocation.params` directly.
    pub redaction: Option<String>,
    /// Final text after `append` was applied (Stage 5; Stage 4 inline).
    pub appended: Option<String>,
    /// Final text after `prepend` was applied (Stage 5; Stage 4 inline).
    pub prepended: Option<String>,
    /// Side-channel description of a deny that was caused by a
    /// `kind: tool` (or synthesised `kind: human`) resolver suspending
    /// while waiting for the agent to call its tool. The host is
    /// expected to surface this to the agent's framework so the agent's
    /// LLM calls the named tool with the rendered prompt; the tool's
    /// `populated_by:` writes the response into the variable; the gate
    /// retries successfully on the next evaluation. `None` for non-deny
    /// verdicts and for denies that did not arise from suspension.
    pub pending_resolution: Option<crate::resolver_runtime::PendingResolution>,
    /// Canonical hash of the invocation before policy evaluation for
    /// invocation-bound stages. Hosts should compare this with the
    /// invocation they execute to prevent validate-then-mutate bugs.
    pub invocation_hash: Option<String>,
    /// Canonical hash after policy evaluation. This differs from
    /// `invocation_hash` only when a Stage 3 transform intentionally
    /// mutates the invocation parameters.
    pub post_validation_invocation_hash: Option<String>,
    /// Ordered manifest of every transform that fired during this
    /// stage. Each entry attributes a redaction span (or append /
    /// prepend text) back to the policy + `evaluate_when[]` entry that
    /// produced it. Order is the **application order** the runtime used
    /// to mutate the subject — redactions in source declaration order
    /// (step 5a), followed by appends in declaration order
    /// and prepends in reverse-declaration order (step 5b).
    /// Empty when the verdict is a clean `allow` or a `block`.
    pub applied_transforms: Vec<AppliedTransform>,
}

impl StageVerdict {
    pub fn allow() -> Self {
        Self {
            allowed: true,
            action: None,
            reason: None,
            policy: None,
            evaluate_when_index: None,
            bypassed_by_allowed_when: false,
            redaction: None,
            appended: None,
            prepended: None,
            pending_resolution: None,
            invocation_hash: None,
            post_validation_invocation_hash: None,
            applied_transforms: Vec::new(),
        }
    }

    pub fn block(policy: impl Into<String>, reason: impl Into<String>, idx: Option<usize>) -> Self {
        Self {
            allowed: false,
            action: Some(Action::Block),
            reason: Some(reason.into()),
            policy: Some(policy.into()),
            evaluate_when_index: idx,
            bypassed_by_allowed_when: false,
            redaction: None,
            appended: None,
            prepended: None,
            pending_resolution: None,
            invocation_hash: None,
            post_validation_invocation_hash: None,
            applied_transforms: Vec::new(),
        }
    }

    pub fn with_invocation_hashes(mut self, before: String, after: String) -> Self {
        self.invocation_hash = Some(before);
        self.post_validation_invocation_hash = Some(after);
        self
    }

    pub fn with_invocation_hash(mut self, hash: String) -> Self {
        self.invocation_hash = Some(hash.clone());
        self.post_validation_invocation_hash = Some(hash);
        self
    }

    /// Attach a [`PendingResolution`] to a deny verdict.
    ///
    /// [`PendingResolution`]: crate::resolver_runtime::PendingResolution
    pub fn with_pending_resolution(
        mut self,
        pending: Option<crate::resolver_runtime::PendingResolution>,
    ) -> Self {
        self.pending_resolution = pending;
        self
    }
}

/// The unified gating engine.
pub struct GuardPolicyEngine {
    deps: GuardPolicyDeps,
    activation: ActivationCache,
    regex_cache: RegexCache,
    listed_names: ListedNames,
}

impl GuardPolicyEngine {
    pub fn new(deps: GuardPolicyDeps) -> Arc<Self> {
        let listed_names = ListedNames::from_config(deps.config.as_ref());
        Arc::new(Self {
            deps,
            activation: ActivationCache::new(),
            regex_cache: RegexCache::new(),
            listed_names,
        })
    }

    /// Snapshot accessor used by per-stage runners.
    pub(crate) fn deps(&self) -> &GuardPolicyDeps {
        &self.deps
    }
    pub(crate) fn activation(&self) -> &ActivationCache {
        &self.activation
    }

    /// Public accessor for the latched activation snapshot. Used by the
    /// session to compute `{active_guard_policies}` and
    /// `{prior_checks_summary}` for Stage-3 prompt enrichment.
    pub fn activation_snapshot(&self) -> std::collections::HashMap<String, bool> {
        self.activation.snapshot()
    }

    /// Session-scoped activation snapshot. Returns the latched
    /// `active_if:` truthiness for every policy seen by `session_id`.
    pub fn activation_snapshot_in(
        &self,
        session_id: &crate::session_id::SessionId,
    ) -> std::collections::HashMap<String, bool> {
        self.activation.snapshot_in(session_id)
    }

    /// Drop every cached activation entry for `session_id`. Called when
    /// a [`crate::runtime::GuardrailsSession`] is dropped or closed.
    pub fn cleanup_session(&self, session_id: &crate::session_id::SessionId) {
        self.activation.cleanup_session(session_id);
    }

    /// Borrow the merged config the engine was constructed against.
    /// Used by the session to look up `tool_permission` /
    /// `tool_description` from the resources catalog when building the
    /// Stage-3 template variables, and to enumerate
    /// `state_validation.guard_policies` for the prior-checks summary.
    pub fn config(&self) -> &MergedConfig {
        &self.deps.config
    }

    pub(crate) fn regex_cache(&self) -> &RegexCache {
        &self.regex_cache
    }
    pub(crate) fn listed_names(&self) -> &ListedNames {
        &self.listed_names
    }

    // ── Per-stage entry points ──────────────────────────────────────

    pub fn evaluate_input(&self, input: &str, ctx: &EvalRuntime<'_>) -> StageVerdict {
        stage_input::evaluate(self, input, ctx)
    }

    pub fn evaluate_state(&self, invocation: &Invocation, ctx: &EvalRuntime<'_>) -> StageVerdict {
        stage_state::evaluate(self, invocation, ctx)
    }

    pub fn evaluate_tool_execution(
        &self,
        invocation: &mut Invocation,
        ctx: &EvalRuntime<'_>,
    ) -> StageVerdict {
        stage_tool_exec::evaluate(self, invocation, ctx)
    }

    pub fn evaluate_post_tool(
        &self,
        invocation: &Invocation,
        result: &mut Value,
        ctx: &EvalRuntime<'_>,
    ) -> StageVerdict {
        stage_post_tool::evaluate(self, invocation, result, ctx)
    }

    pub fn evaluate_output(&self, response: &mut String, ctx: &EvalRuntime<'_>) -> StageVerdict {
        stage_output::evaluate(self, response, ctx)
    }

    /// Build a streaming session for Stages 4 or 5. The session buffers
    /// chunks and runs the stage's content policies on each emission.
    pub fn streaming_session(
        self: &Arc<Self>,
        stage: ObsStage,
        ctx_owned: streaming::OwnedEvalRuntime,
    ) -> StreamingGuard {
        StreamingGuard::new(self.clone(), stage, ctx_owned)
    }
}

// ── Internal helpers shared across stages ───────────────────────────

/// Bind a [`crate::populator::Invocation`] into the attribute map so
/// expressions like `tool.name`, `tool.params.amount`, `endpoint.method`
/// resolve. Mirrors [`crate::populator::bind_invocation_attrs`] which
/// is `pub(crate)`-only — we re-implement the binding here without
/// adding a new pub surface to populator.
pub(crate) fn bind_invocation_into(attrs: &mut HashMap<String, Value>, inv: &Invocation) {
    use crate::variables::ResourceKind;
    match inv.kind {
        ResourceKind::Tool => {
            let mut tool = serde_json::Map::new();
            if let Some(n) = &inv.name {
                tool.insert("name".into(), Value::String(n.clone()));
            }
            tool.insert("params".into(), inv.params.clone());
            attrs.insert("@tool".into(), Value::Object(tool));
        }
        ResourceKind::Agent => {
            let mut agent = serde_json::Map::new();
            if let Some(n) = &inv.name {
                agent.insert("name".into(), Value::String(n.clone()));
            }
            agent.insert("payload".into(), inv.params.clone());
            attrs.insert("@agent".into(), Value::Object(agent));
        }
        ResourceKind::Endpoint => {
            let mut ep = serde_json::Map::new();
            if let Some(m) = &inv.method {
                ep.insert("method".into(), Value::String(m.clone()));
            }
            if let Some(u) = &inv.uri {
                ep.insert("uri".into(), Value::String(u.clone()));
            }
            ep.insert("body".into(), inv.params.clone());
            ep.insert("params".into(), inv.params.clone());
            attrs.insert("@endpoint".into(), Value::Object(ep));
        }
    }
}

/// Translate an [`Invocation`] into a [`SelectorSubject`].
pub(crate) fn invocation_subject<'a>(inv: &'a Invocation) -> SelectorSubject<'a> {
    use crate::variables::ResourceKind;
    match inv.kind {
        ResourceKind::Tool => SelectorSubject::Tool {
            name: inv.name.as_deref().unwrap_or(""),
        },
        ResourceKind::Agent => SelectorSubject::Agent {
            name: inv.name.as_deref().unwrap_or(""),
        },
        ResourceKind::Endpoint => SelectorSubject::Endpoint {
            method: inv.method.as_deref().unwrap_or(""),
            uri: inv.uri.as_deref().unwrap_or(""),
        },
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn build_base_attrs_includes_session_and_correlation() {
        let ctx = EvalRuntime {
            session_id: "s1",
            correlation_id: "c1",
            user_id: Some("u1"),
            tenant_id: None,
            request_context: serde_json::json!({"role":"admin"}),
            turn_id: 0,
            objective: "",
            forbidden: &[],
            user_input: "",
            active_guard_policies: "",
            variables_snapshot: "",
            prior_checks_summary: "",
        };
        let attrs = ctx.build_base_attrs();
        assert!(attrs.contains_key("session"));
        assert!(attrs.contains_key("correlation_id"));
        assert!(attrs.contains_key("@context"));
    }
}
