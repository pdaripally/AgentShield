//! Apply an effective action (`block` / `redact` / `warn` / `append` /
//! `prepend`) to a subject.
//!
//! The runtime calls into here once it has determined the failing entry's
//! action and any spans / text to apply. Stage runners aggregate redaction
//! spans first (step 5a), then prepends, then appends.

use super::detection::Span;

/// A single candidate redaction span produced by some
/// `evaluate_when[]` entry across the policies of one stage. Carries
/// the originating provenance plus a stable global declaration index so
/// the wider-spans-win selector ([`select_winning_spans`]) can break
/// ties deterministically.
///
/// when two policies (or two entries) match overlapping regions
/// of the same subject, the **wider** span must win — narrower
/// detectors (e.g., a surname tokenizer) must NOT preempt a broader
/// detector (e.g., full-name) and leak the adjacent identifier through.
/// only the surviving spans are reported in
/// `StageVerdict::applied_transforms`; dropped overlap-losers and
/// zero-width spans are excluded.
#[derive(Debug, Clone)]
pub struct RedactionCandidate {
    pub span: Span,
    pub replacement: String,
    pub policy_name: String,
    pub entry_index: usize,
    /// Monotonic global declaration index used as the final tie-breaker
    /// (stable across the sort). Earlier declared = lower index =
    /// preferred when width and start agree.
    pub declaration_order: usize,
}

/// Wider-spans-win greedy non-overlap selector.
///
/// Algorithm:
///
/// 1. Drop zero-width spans (`end <= start`) up front — they never
///    mutate the subject and so MUST NOT appear in
/// `applied_transforms`.
/// 2. Sort candidates by `(width DESC, start ASC, declaration_order ASC)`
///    so the widest span at any position is considered first.
/// 3. Greedy: keep the next candidate iff it does not overlap any
///    already-kept span. "Overlap" is the half-open
///    `a.start < b.end && a.end > b.start`.
/// 4. Re-sort the kept set by `(start ASC, declaration_order ASC)` so
///    downstream consumers see a deterministic, position-ordered
///    manifest.
///
/// Edge-case behavior:
/// - **Identical extent, different replacements**: the earlier declared
///   policy wins (stable declaration_order tie-break).
/// - **Containment** (`[100,150]` contains `[120,126]`): the wider
///   outer span wins; the inner span is dropped from both the applied
///   set and the metadata.
/// - **Partial overlap** (`[0,5]` and `[2,10]`, neither containing the
///   other): the wider one wins; the narrower one is dropped.
/// - **Non-overlapping**: every span survives.
pub fn select_winning_spans(mut candidates: Vec<RedactionCandidate>) -> Vec<RedactionCandidate> {
    candidates.retain(|c| c.span.end > c.span.start);

    candidates.sort_by(|a, b| {
        let wa = a.span.end.saturating_sub(a.span.start);
        let wb = b.span.end.saturating_sub(b.span.start);
        wb.cmp(&wa)
            .then(a.span.start.cmp(&b.span.start))
            .then(a.declaration_order.cmp(&b.declaration_order))
    });

    let mut kept: Vec<RedactionCandidate> = Vec::with_capacity(candidates.len());
    for cand in candidates {
        let overlaps = kept
            .iter()
            .any(|k| cand.span.start < k.span.end && cand.span.end > k.span.start);
        if !overlaps {
            kept.push(cand);
        }
    }

    kept.sort_by(|a, b| {
        a.span
            .start
            .cmp(&b.span.start)
            .then(a.declaration_order.cmp(&b.declaration_order))
    });
    kept
}

/// In-place text mutator: replace a list of spans with a replacement
/// string. Spans use **character (codepoint) offsets**, not byte offsets
/// — per spec the runtime computes spans against `chars()` so non-ASCII
/// subjects redact predictably. Non-overlapping spans are applied
/// right-to-left so subsequent offsets don't shift.
///
/// each entry sees the **original** subject — the caller is
/// responsible for collecting all spans first, then asking us to apply
/// them in one shot.
pub fn apply_redactions(subject: &str, spans: &[(Span, String)]) -> String {
    if spans.is_empty() {
        return subject.to_string();
    }
    // Sort by start ascending, with the original index as tie-breaker.
    let mut indexed: Vec<(usize, &(Span, String))> = spans.iter().enumerate().collect();
    indexed.sort_by_key(|(idx, (s, _))| (s.start, *idx));

    // Filter overlaps: among overlapping spans, the earliest-starting wins
    // (with declaration-order tie-break). says overlap behavior is
    // implementation-defined but must be deterministic.
    let mut owned: Vec<(Span, String)> = Vec::new();
    let mut cursor: usize = 0;
    for (_, (s, repl)) in &indexed {
        if s.start < cursor {
            continue;
        }
        owned.push(((*s).clone(), repl.clone()));
        cursor = s.end;
    }

    // Pre-compute the char-to-byte index table once so we can translate
    // every span without re-walking the string. Append `subject.len()`
    // as the sentinel for "one past the last char".
    let char_to_byte: Vec<usize> = subject
        .char_indices()
        .map(|(b, _)| b)
        .chain(std::iter::once(subject.len()))
        .collect();
    let char_count = char_to_byte.len() - 1;

    // Apply right-to-left so offsets stay valid as we mutate.
    let mut buf = subject.to_string();
    for (span, repl) in owned.iter().rev() {
        if span.end <= span.start || span.end > char_count {
            // Invalid char range — drop rather than clamp
            // intent (avoids partial-grapheme corruption).
            //
            // defense-in-depth: emit a `debug` log so customers
            // who passed byte offsets (or otherwise mis-sized spans)
            // can diagnose the silent miss. The payload carries the
            // span coordinates and the subject's char_count only —
            // never any slice of the subject text or replacement
            // string (per the logging style guide; no PII at info+
            // and we deliberately keep secrets out of debug too,
            // because the dropped span by definition references
            // content the policy considered sensitive).
            let reason = if span.end <= span.start {
                "end_le_start"
            } else {
                "end_gt_char_count"
            };
            log::debug!(
                "guard_policy.redaction_span_dropped: start={} end={} char_count={} reason={}",
                span.start,
                span.end,
                char_count,
                reason,
            );
            continue;
        }
        let start = char_to_byte[span.start];
        let end = char_to_byte[span.end];
        buf.replace_range(start..end, repl);
    }
    buf
}

/// Apply prepends and appends in declaration order to a text subject.
/// `prepends` are stacked (last-declared ends up at the very front per
/// step 5b). Returns the transformed string.
pub fn apply_prepend_append(subject: &str, prepends: &[String], appends: &[String]) -> String {
    let mut buf = String::with_capacity(subject.len());
    // Stack prepends: last-declared appears first, so iterate in reverse
    // and accumulate.
    for p in prepends.iter().rev() {
        buf.push_str(p);
    }
    buf.push_str(subject);
    for a in appends {
        buf.push_str(a);
    }
    buf
}

#[cfg(test)]
mod tests {
    use super::*;

    fn span(start: usize, end: usize) -> Span {
        Span {
            start,
            end,
            replacement: None,
        }
    }

    #[test]
    fn no_spans_returns_original() {
        assert_eq!(apply_redactions("hello", &[]), "hello");
    }

    #[test]
    fn single_span_replaced() {
        let result = apply_redactions("my ssn is 123-45-6789 ok", &[(span(10, 21), "[X]".into())]);
        assert_eq!(result, "my ssn is [X] ok");
    }

    #[test]
    fn multiple_non_overlapping_spans_replaced() {
        let result = apply_redactions(
            "abc XXX def YYY ghi",
            &[(span(4, 7), "[1]".into()), (span(12, 15), "[2]".into())],
        );
        assert_eq!(result, "abc [1] def [2] ghi");
    }

    #[test]
    fn overlap_dropped_first_wins() {
        // Two spans at offsets 0..5 and 2..7 — keep the first, drop second.
        let result = apply_redactions(
            "abcdefghi",
            &[(span(0, 5), "[A]".into()), (span(2, 7), "[B]".into())],
        );
        assert_eq!(result, "[A]fghi");
    }

    #[test]
    fn append_only() {
        let v = apply_prepend_append("abc", &[], &["x".into(), "y".into()]);
        assert_eq!(v, "abcxy");
    }

    #[test]
    fn prepend_only_stacks_reverse() {
        // step 5b: "the last-declared prepend ends up at the very front."
        let v = apply_prepend_append("abc", &["[1]".into(), "[2]".into()], &[]);
        assert_eq!(v, "[2][1]abc");
    }

    #[test]
    fn mixed_prepend_then_append() {
        let v = apply_prepend_append("abc", &["[P]".into()], &["[A]".into()]);
        assert_eq!(v, "[P]abc[A]");
    }

    // P6.7 — spans are character offsets, not byte offsets. `é` is 2
    // bytes in UTF-8 but a single character; a span 0..5 must redact 5
    // characters, not 5 bytes.
    #[test]
    fn redaction_uses_char_offsets_not_byte_offsets() {
        let result = apply_redactions("héllo world", &[(span(0, 5), "[X]".into())]);
        assert_eq!(result, "[X] world");
    }

    #[test]
    fn redaction_ignores_spans_past_char_count() {
        // "héllo" is 5 chars / 6 bytes. A span 0..6 (over by one char) is
        // invalid and dropped rather than clamped.
        let result = apply_redactions("héllo", &[(span(0, 6), "[X]".into())]);
        assert_eq!(result, "héllo");
    }

    #[test]
    fn redaction_invalid_zero_width_span_dropped() {
        let result = apply_redactions("héllo", &[(span(2, 2), "[X]".into())]);
        assert_eq!(result, "héllo");
    }

    // ── Wider-spans-win selector ──────────────────────

    fn cand(start: usize, end: usize, repl: &str, policy: &str, decl: usize) -> RedactionCandidate {
        RedactionCandidate {
            span: Span {
                start,
                end,
                replacement: None,
            },
            replacement: repl.to_string(),
            policy_name: policy.to_string(),
            entry_index: 0,
            declaration_order: decl,
        }
    }

    #[test]
    fn select_wider_wins_for_same_start() {
        // surname `Doe` 12..15 vs name `John Doe` 7..15 → wider (7..15) wins.
        let kept = select_winning_spans(vec![
            cand(12, 15, "[SURNAME]", "surname", 0),
            cand(7, 15, "[NAME]", "name", 1),
        ]);
        assert_eq!(kept.len(), 1);
        assert_eq!(kept[0].span.start, 7);
        assert_eq!(kept[0].span.end, 15);
        assert_eq!(kept[0].replacement, "[NAME]");
    }

    #[test]
    fn select_wider_wins_for_containment() {
        // classifier span [100, 150] contains regex span [120, 126].
        let kept = select_winning_spans(vec![
            cand(100, 150, "[CLASS]", "classifier", 0),
            cand(120, 126, "[REGEX]", "regex", 1),
        ]);
        assert_eq!(kept.len(), 1);
        assert_eq!(kept[0].span.start, 100);
        assert_eq!(kept[0].span.end, 150);
        assert_eq!(kept[0].replacement, "[CLASS]");
    }

    #[test]
    fn select_wider_wins_for_partial_overlap() {
        // [0,5] (width 5) vs [2,10] (width 8) — neither contains the
        // other, but the wider one wins.
        let kept = select_winning_spans(vec![
            cand(0, 5, "[A]", "p1", 0),
            cand(2, 10, "[B]", "p2", 1),
        ]);
        assert_eq!(kept.len(), 1);
        assert_eq!(kept[0].span.start, 2);
        assert_eq!(kept[0].span.end, 10);
        assert_eq!(kept[0].replacement, "[B]");
    }

    #[test]
    fn select_identical_extent_first_declared_wins() {
        // Same span, two replacements — declaration order tie-break.
        let kept = select_winning_spans(vec![
            cand(0, 5, "[FIRST]", "p1", 0),
            cand(0, 5, "[SECOND]", "p2", 1),
        ]);
        assert_eq!(kept.len(), 1);
        assert_eq!(kept[0].replacement, "[FIRST]");
    }

    #[test]
    fn select_non_overlapping_all_kept() {
        // Independent spans — every one survives.
        let kept = select_winning_spans(vec![
            cand(0, 5, "[A]", "p1", 0),
            cand(10, 15, "[B]", "p2", 1),
            cand(20, 25, "[C]", "p3", 2),
        ]);
        assert_eq!(kept.len(), 3);
        assert_eq!(kept[0].span.start, 0);
        assert_eq!(kept[1].span.start, 10);
        assert_eq!(kept[2].span.start, 20);
    }

    #[test]
    fn select_drops_zero_width_spans() {
        // zero-width pattern matches must not appear in the
        // applied manifest. `^` reporting span 0..0 is dropped.
        let kept = select_winning_spans(vec![
            cand(0, 0, "[ZERO]", "anchor", 0),
            cand(5, 10, "[REAL]", "real", 1),
        ]);
        assert_eq!(kept.len(), 1);
        assert_eq!(kept[0].span.start, 5);
        assert_eq!(kept[0].span.end, 10);
    }

    #[test]
    fn select_output_sorted_by_start() {
        // Even if candidates arrive out of order, the surviving set is
        // returned sorted by start so audit consumers see a predictable
        // manifest order.
        let kept = select_winning_spans(vec![
            cand(20, 25, "[C]", "p3", 2),
            cand(0, 5, "[A]", "p1", 0),
            cand(10, 15, "[B]", "p2", 1),
        ]);
        let starts: Vec<usize> = kept.iter().map(|c| c.span.start).collect();
        assert_eq!(starts, vec![0, 10, 20]);
    }
}
