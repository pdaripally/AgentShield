//! Adapters bridging runtime state into the expression evaluator's
//! hook traits.
//!
//! The expression module defines four hook traits — [`StatusLookup`],
//! [`EventFiredHook`], [`PredicateLookup`], and [`ResolverHook`] — that
//! callers populate per-evaluation. This module owns the
//! implementations:
//!
//! - [`TrackerStatusLookup`] wraps a [`LifetimeTracker`] reference.
//! - [`PredicateMapLookup`] wraps a [`PredicateMap`] reference.
//! - The [`crate::resolver_runtime::AutoResolveAdapter`] is reused
//!   directly for resolver auto-resolution.
//!
//! Hosts shouldn't need to use these directly — the per-stage runners
//! build them fresh per-call.

use crate::event_bus::EventBus;
use crate::events::EventId;
use crate::expressions::eval::{
    evaluate_to_value, EvalContext, EvalResult, EventFiredHook, PredicateLookup, StatusLookup,
    VariableStatus,
};
use crate::lifetime_tracker::{DenyKind, LifetimeTracker};
use crate::predicates::PredicateMap;
use crate::session_id::SessionId;
use crate::variables::Variable;
use serde_json::Value;
use std::collections::HashMap;

/// Adapter that satisfies [`StatusLookup`] by reading from a
/// [`LifetimeTracker`] scoped to a specific session.
///
/// **Keyed-variable awareness.** When constructed via
/// [`Self::new_keyed_in`], the adapter holds borrowed references to the
/// declared variable registry and an OWNED snapshot of the per-stage
/// `attrs` map. For any declared variable carrying a `key:` expression,
/// `status()`, `meta()`, and `value()` evaluate the key against the
/// owned `attrs` snapshot (matching the projection in
/// [`super::stage_common::bind_resolved_variables_in`]) and route the
/// read through [`LifetimeTracker::read_variable_keyed_in`] with the
/// resolved key. Non-keyed variables continue to use the non-keyed
/// accessor — no regression. A `null`-valued key folds to `unset` per
///
/// The hook-less [`Self::new_in`] / [`Self::new`] constructors are kept
/// for tests and non-gating callers that don't have a registry handy;
/// those reads continue to hit the non-keyed slot exclusively.
///
/// The snapshot is owned (not borrowed) because the per-stage runners
/// mutate their `attrs` map during transform application (Stage 3
/// `redact` / `append` / `prepend`); a borrowed `&attrs` here would
/// deadlock the borrow checker against the post-transform
/// [`super::bind_invocation_into`] re-bind. Authors who need
/// transform-aware keyed lookups can rebuild the adapter after each
/// mutation — see the redaction paths in `stage_tool_exec`.
pub struct TrackerStatusLookup<'a> {
    pub tracker: &'a LifetimeTracker,
    pub session_id: SessionId,
    /// Declared-variable registry — used to detect `key:` and evaluate it.
    /// `None` on hook-less constructors (tests / legacy callers).
    pub variables: Option<&'a [Variable]>,
    /// Owned snapshot of the per-stage bound `attrs` — the namespace
    /// the `key:` expression sees. `None` on hook-less constructors.
    pub attrs: Option<HashMap<String, Value>>,
}

impl<'a> TrackerStatusLookup<'a> {
    pub fn new(tracker: &'a LifetimeTracker) -> Self {
        Self {
            tracker,
            session_id: SessionId::default(),
            variables: None,
            attrs: None,
        }
    }

    pub fn new_in(tracker: &'a LifetimeTracker, session_id: SessionId) -> Self {
        Self {
            tracker,
            session_id,
            variables: None,
            attrs: None,
        }
    }

    /// Key-aware constructor used by the per-stage runners. The
    /// `variables` registry is borrowed for the adapter's lifetime; the
    /// `attrs` snapshot is cloned so the runner can keep mutating its
    /// own attrs map (e.g. for Stage-3 transforms). Reads for declared
    /// keyed variables evaluate `key:` against the snapshot and route
    /// to [`LifetimeTracker::read_variable_keyed_in`].
    pub fn new_keyed_in(
        tracker: &'a LifetimeTracker,
        session_id: SessionId,
        variables: &'a [Variable],
        attrs: &HashMap<String, Value>,
    ) -> Self {
        Self {
            tracker,
            session_id,
            variables: Some(variables),
            attrs: Some(attrs.clone()),
        }
    }

    /// Resolve the keyed slot to read from for `var`. Returns:
    /// - `Some(Some(key))` — keyed variable with a non-null key.
    /// - `Some(None)` — keyed variable whose `key:` folded to
    /// `null`; readers MUST treat this as the unset slot.
    /// - `None` — variable is not declared keyed (or the
    ///   adapter was built without a registry); readers fall back to
    ///   the non-keyed accessor.
    fn resolve_key_for(&self, var: &str) -> Option<Option<Value>> {
        let variables = self.variables?;
        let attrs = self.attrs.as_ref()?;
        let decl = variables.iter().find(|v| v.name == var)?;
        let key_expr = decl.key.as_deref()?;
        let ctx = EvalContext::from_attrs(attrs);
        let key_value = evaluate_to_value(key_expr, &ctx);
        Some(key_value.filter(|v| !v.is_null()))
    }
}

impl<'a> StatusLookup for TrackerStatusLookup<'a> {
    fn status(&self, var: &str) -> Option<VariableStatus> {
        // /: keyed variables route metadata reads
        // through the keyed slot. A null-evaluating `key:` folds to
        // unset; pre-fix this code always called the non-keyed
        // `read_variable_in` and surfaced the (empty) key=None slot.
        let st = match self.resolve_key_for(var) {
            Some(Some(key)) => {
                self.tracker
                    .read_variable_keyed_in(&self.session_id, var, Some(&key))
            }
            Some(None) => {
                // null-key keyed read: unset short-circuit.
                return Some(VariableStatus::Unset);
            }
            None => self.tracker.read_variable_in(&self.session_id, var),
        };
        Some(match st.status {
            VariableStatus::Unset => VariableStatus::Unset,
            VariableStatus::Resolved => VariableStatus::Resolved,
            VariableStatus::Denied => VariableStatus::Denied,
        })
    }

    fn is_declared(&self, var: &str) -> bool {
        // Override the default impl (which returns true for any name
        // because `status()` returns `Some(Unset)` for non-declared
        // variables): query the registry directly so undeclared names
        // (predicates, locals, scope-namespace roots) are excluded.
        // Declared-ness is per-name, not per-key — no key awareness
        // needed here.
        self.tracker.is_variable_declared(var)
    }

    fn meta(&self, var: &str, field: &str) -> Option<EvalResult> {
        // keyed metadata reads MUST consult the keyed slot.
        // Pre-fix this code always called the non-keyed accessor, so
        // `.@status`, `.@source_params`, etc. read from key=None and
        // appeared unset for keyed variables.
        let (st, resolved_key) = match self.resolve_key_for(var) {
            Some(Some(key)) => {
                let st = self
                    .tracker
                    .read_variable_keyed_in(&self.session_id, var, Some(&key));
                (st, Some(key))
            }
            Some(None) => {
                // null-key: the read is unset. Return None
                // for every field except `status`, which surfaces
                // `'unset'` explicitly to mirror the non-keyed unset
                // shape.
                if field == "status" {
                    return Some(EvalResult::Str("unset".to_string()));
                }
                return None;
            }
            None => (self.tracker.read_variable_in(&self.session_id, var), None),
        };

        match field {
            "status" => Some(EvalResult::Str(
                match st.status {
                    VariableStatus::Unset => "unset",
                    VariableStatus::Resolved => "resolved",
                    VariableStatus::Denied => "denied",
                }
                .to_string(),
            )),
            "set_at" => Some(EvalResult::DateTime(st.set_at)),
            "expires_at" => st.expires_at.map(EvalResult::DateTime),
            "source_kind" => st.source_kind.map(EvalResult::Str),
            "set_by" => st.set_by.map(EvalResult::Str),
            "deny_reason" => st.deny_reason.map(EvalResult::Str),
            // v2 metadata fields:
            //
            // `@key` — the key under which the current read resolved.
            //   For keyed variables, surface the evaluated key value;
            //   for non-keyed variables this is None.
            "key" => resolved_key.map(|k| {
                use crate::expressions::eval::value_to_eval;
                value_to_eval(&k)
            }),
            // `@deny_kind` — present when `@status == 'denied'`, valued
            //   as `'deny'` or `'cancelled'`. The tracker records the
            //   terminal outcome alongside the status flip (auto-flip
            //   subscriber + resolver/runtime write paths populate it
            //   from the originating `ApprovalEventKind` /
            // `ResolverOutcome`). — previously hard-coded to
            //   `'deny'`, collapsing the cancellation outcome into the
            // spec `deny` form. Defensive
            //   fallback: when status is denied but the discriminator
            //   is somehow absent, report `'deny'` — the more
            //   restrictive interpretation matches a denied-poisoned
            //   reader's expectation that the gate stays blocked.
            "deny_kind" => match (st.status, st.deny_kind) {
                (VariableStatus::Denied, Some(DenyKind::Cancelled)) => {
                    Some(EvalResult::Str("cancelled".to_string()))
                }
                (VariableStatus::Denied, _) => Some(EvalResult::Str("deny".to_string())),
                _ => None,
            },
            // `@source_reason` — alias of `deny_reason` in the v2
            //   nomenclature for consistency across writers (resolver,
            //   host, populator).
            "source_reason" => st.deny_reason.map(EvalResult::Str),
            // `@source_params` — snapshot captured by the populator /
            //   resolver write.
            "source_params" => st.source_params.map(|v| {
                use crate::expressions::eval::value_to_eval;
                value_to_eval(&v)
            }),
            _ => None,
        }
    }

    /// surface the tracker's currently-stored value when the
    /// variable is `Resolved`, so reads from a stage `attrs` snapshot
    /// that pre-dates a mid-walk auto-resolution can recover the value
    /// without re-firing the resolver.
    fn value(&self, var: &str) -> Option<Value> {
        // Keyed-aware: read from the per-key slot so a keyed read
        // backstop doesn't silently surface the
        // non-keyed slot for a keyed variable.
        let st = match self.resolve_key_for(var) {
            Some(Some(key)) => {
                self.tracker
                    .read_variable_keyed_in(&self.session_id, var, Some(&key))
            }
            Some(None) => return None,
            None => self.tracker.read_variable_in(&self.session_id, var),
        };
        match st.status {
            VariableStatus::Resolved => Some(st.value),
            VariableStatus::Unset | VariableStatus::Denied => None,
        }
    }
}

/// Adapter that satisfies [`PredicateLookup`] by reading from a
/// [`PredicateMap`].
pub struct PredicateMapLookup<'a> {
    pub map: &'a PredicateMap,
}

impl<'a> PredicateMapLookup<'a> {
    pub fn new(map: &'a PredicateMap) -> Self {
        Self { map }
    }
}

impl<'a> PredicateLookup for PredicateMapLookup<'a> {
    fn body(&self, name: &str) -> Option<&str> {
        self.map
            .entries
            .get(name)
            .map(|e| e.body.expression.as_str())
    }
}

/// Session-scoped [`EventFiredHook`] used by every per-stage runner so
/// `@event.fired(<id>)` calls inside expressions consult only the
/// emitting session's latches. The legacy
/// [`EventFiredHook for EventBus`] aggregates across sessions; the
/// stage runners never use that direct impl.
pub struct SessionScopedEventFired<'a> {
    pub bus: &'a EventBus,
    pub session_id: SessionId,
}

impl<'a> SessionScopedEventFired<'a> {
    pub fn new(bus: &'a EventBus, session_id: SessionId) -> Self {
        Self { bus, session_id }
    }
}

impl<'a> EventFiredHook for SessionScopedEventFired<'a> {
    fn fired(&self, event_id: &str) -> bool {
        match EventId::parse(event_id) {
            Ok(id) => self.bus.fired_id_in(&self.session_id, &id),
            Err(_) => false,
        }
    }
}

#[cfg(test)]
mod tests {
    //! `@deny_kind` metadata round-trip.
    //!
    //! The [`TrackerStatusLookup::meta`] adapter MUST surface the
    //! `DenyKind` stored on [`crate::lifetime_tracker::VariableState`]
    //! so an expression like `var.@deny_kind == 'cancelled'` evaluates
    //! `true` when the resolver returned `decision: cancelled`. Spec
    //!.
    use super::*;
    use crate::event_bus::EventBus;
    use crate::events::ApprovalEventKind;
    use crate::expressions::eval::StatusLookup;
    use crate::lifetime_tracker::LifetimeTracker;
    use crate::session_id::SessionId;
    use crate::variables::{Variable, VariableType};
    use chrono::{DateTime, Utc};
    use std::collections::HashMap;
    use std::sync::Arc;

    fn fixed_clock() -> Arc<dyn Fn() -> DateTime<Utc> + Send + Sync> {
        Arc::new(|| DateTime::<Utc>::from_timestamp(1_700_000_000, 0).unwrap())
    }

    fn boolean_var(name: &str) -> Variable {
        Variable {
            name: name.to_string(),
            var_type: VariableType::Boolean,
            description: None,
            default: None,
            members: None,
            vocabulary: None,
            strict_resource_coverage: None,
            update: None,
            key: None,
            lifetime: None,
            on_demand_by: None,
            populated_by: vec![],
        }
    }

    fn tracker_with(bus: EventBus, decls: Vec<Variable>) -> Arc<LifetimeTracker> {
        let registry: HashMap<String, Variable> =
            decls.into_iter().map(|v| (v.name.clone(), v)).collect();
        LifetimeTracker::with_clock(bus, registry, fixed_clock())
    }

    #[test]
    fn deny_kind_returns_cancelled_for_cancelled_outcome() {
        let bus = EventBus::with_clock(fixed_clock());
        let t = tracker_with(bus.clone(), vec![boolean_var("approved")]);
        bus.emit_approval(
            "approved",
            ApprovalEventKind::Cancelled,
            None,
            Some(serde_json::json!({"reason": "operator closed dialog"})),
        )
        .unwrap();

        let lookup = TrackerStatusLookup::new_in(&t, SessionId::default());
        match lookup.meta("approved", "deny_kind") {
            Some(EvalResult::Str(s)) => assert_eq!(s, "cancelled"),
            other => panic!("expected Some(Str(\"cancelled\")), got {other:?}"),
        }
    }

    #[test]
    fn deny_kind_returns_deny_for_deny_outcome() {
        let bus = EventBus::with_clock(fixed_clock());
        let t = tracker_with(bus.clone(), vec![boolean_var("approved")]);
        bus.emit_approval(
            "approved",
            ApprovalEventKind::Deny,
            None,
            Some(serde_json::json!({"reason": "policy violation"})),
        )
        .unwrap();

        let lookup = TrackerStatusLookup::new_in(&t, SessionId::default());
        match lookup.meta("approved", "deny_kind") {
            Some(EvalResult::Str(s)) => assert_eq!(s, "deny"),
            other => panic!("expected Some(Str(\"deny\")), got {other:?}"),
        }
    }

    #[test]
    fn deny_kind_returns_none_for_resolved_variable() {
        let bus = EventBus::with_clock(fixed_clock());
        let t = tracker_with(bus.clone(), vec![boolean_var("approved")]);
        bus.emit_approval("approved", ApprovalEventKind::Allow, None, None)
            .unwrap();

        let lookup = TrackerStatusLookup::new_in(&t, SessionId::default());
        assert!(lookup.meta("approved", "deny_kind").is_none());
    }

    #[test]
    fn deny_kind_returns_none_for_unset_variable() {
        let bus = EventBus::with_clock(fixed_clock());
        let t = tracker_with(bus.clone(), vec![boolean_var("approved")]);

        let lookup = TrackerStatusLookup::new_in(&t, SessionId::default());
        assert!(lookup.meta("approved", "deny_kind").is_none());
    }
}
