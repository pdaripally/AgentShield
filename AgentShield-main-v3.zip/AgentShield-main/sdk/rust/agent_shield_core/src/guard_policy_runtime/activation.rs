//! `active_if:` evaluation and activation events.
//!
//! `active_if:` is observational — it MUST NOT trigger auto-resolution.
//! The evaluator runs with `is_gating_site = false` and a hookless
//! [`crate::expressions::eval::ResolverHook`]. Per-policy activation
//! state is latched here so we emit `guard_policy.<name>.activated` /
//! `.deactivated` exactly once per transition.
//!
//! State is keyed by `(SessionId, policy_name)` so two
//! [`crate::runtime::GuardrailsSession`]s on the same runtime each
//! observe their own activation transitions. Activation events emitted
//! by transitions carry the originating session id.
//!
//! ### Diagnostic emission on first inactive evaluation
//!
//! the strict reading of "transition" excludes the
//! `unobserved → inactive` first emission, but in practice this means
//! a misconfigured `active_if:` (e.g. one that references an `unset`
//! variable and silently folds to `false`) produces ZERO observability
//! signal — the developer has no way to discover the policy was even
//! considered. [`ActivationCache::evaluate_and_emit_with_diagnostics_in`]
//! treats first-eval-inactive as a transition from an implicit
//! "considered" state to `inactive` and emits
//! `guard_policy.<name>.deactivated` exactly once, carrying a payload
//! that names the predicate, its result, and the `@status` of every
//! referenced variable. The latch then suppresses any further
//! emissions until activation state genuinely changes — so the event
//! is signal, not noise.

use std::collections::HashMap;
use std::sync::Mutex;

use serde_json::{json, Value};

use crate::event_bus::EventBus;
use crate::expressions::ast::Expr;
use crate::expressions::eval::{
    evaluate_with, EvalContext, EventFiredHook, PredicateLookup, StatusLookup, VariableStatus,
};
use crate::expressions::parser::parse;
use crate::session_id::SessionId;
use crate::variables::Variable;

/// Per-engine cache of last-evaluated `active_if` truthiness, keyed by
/// `(session_id, guard_policy_name)`. Initialized lazily on first
/// evaluation per session.
#[derive(Debug, Default)]
pub struct ActivationCache {
    last_state: Mutex<HashMap<(SessionId, String), bool>>,
}

impl ActivationCache {
    pub fn new() -> Self {
        Self::default()
    }

    /// Evaluate a policy's `active_if:` (or treat as always-active when
    /// absent) and emit transition events on the bus when the latched
    /// state changes. Returns the new active flag.
    ///
    /// Legacy session-blind variant — equivalent to
    /// [`Self::evaluate_and_emit_in`] with [`SessionId::default`].
    pub fn evaluate_and_emit(
        &self,
        policy_name: &str,
        active_if: Option<&str>,
        attrs: &HashMap<String, Value>,
        predicates: Option<&dyn PredicateLookup>,
        event_fired: Option<&dyn EventFiredHook>,
        bus: &EventBus,
    ) -> bool {
        self.evaluate_and_emit_in(
            &SessionId::default(),
            policy_name,
            active_if,
            attrs,
            predicates,
            event_fired,
            bus,
        )
    }

    /// Session-scoped variant of [`Self::evaluate_and_emit`]. The
    /// transition latch is keyed by `(session_id, policy_name)` so
    /// each session sees its own first-activation emission. Activation
    /// events are emitted on the bus carrying `session_id`.
    #[allow(clippy::too_many_arguments)]
    pub fn evaluate_and_emit_in(
        &self,
        session_id: &SessionId,
        policy_name: &str,
        active_if: Option<&str>,
        attrs: &HashMap<String, Value>,
        predicates: Option<&dyn PredicateLookup>,
        event_fired: Option<&dyn EventFiredHook>,
        bus: &EventBus,
    ) -> bool {
        self.evaluate_and_emit_with_diagnostics_in(
            session_id,
            policy_name,
            active_if,
            attrs,
            predicates,
            event_fired,
            None,
            &[],
            bus,
        )
    }

    /// Like [`Self::evaluate_and_emit_in`] but enriches the emitted
    /// `guard_policy.<name>.deactivated` event with a diagnostic
    /// payload built from `status_lookup` + the declared `variables`
    /// list. Also emits `.deactivated` on the FIRST evaluation that
    /// returns inactive — without this, a misconfigured `active_if:`
    /// produces no observability signal at all.
    ///
    /// `variables` is the list of declared variables in the merged
    /// configuration; it is used to filter expression identifiers
    /// down to the names that actually refer to runtime variables
    /// (excluding namespaces like `tool`, `endpoint`, `agent`,
    /// `session`, `context`, and `result`, plus expression keywords).
    /// `status_lookup` reads the variable `@status` so the payload
    /// reflects state at the moment of evaluation. Passing
    /// `status_lookup: None` or an empty `variables` slice still
    /// emits the event but with an empty `referenced_variables` list.
    #[allow(clippy::too_many_arguments)]
    pub fn evaluate_and_emit_with_diagnostics_in(
        &self,
        session_id: &SessionId,
        policy_name: &str,
        active_if: Option<&str>,
        attrs: &HashMap<String, Value>,
        predicates: Option<&dyn PredicateLookup>,
        event_fired: Option<&dyn EventFiredHook>,
        status_lookup: Option<&dyn StatusLookup>,
        variables: &[Variable],
        bus: &EventBus,
    ) -> bool {
        let active = match active_if {
            None => true,
            Some(expr) => {
                // when active_if references a declared variable
                // whose @status is `denied`, treat the gate as inactive.
                // The denied state is terminal so the only safe
                // posture is to step out of the gating site rather than
                // let the predicate's stored-value comparison decide
                // activation. active_if is non-resolving so this never
                // triggers auto-resolution.
                if let Some(sl) = status_lookup {
                    if crate::expressions::denied_refs::first_denied_ref(expr, sl, predicates)
                        .is_some()
                    {
                        false
                    } else {
                        let mut ctx = EvalContext::from_attrs(attrs);
                        ctx.predicates = predicates;
                        ctx.event_fired = event_fired;
                        ctx.status_lookup = Some(sl);
                        ctx.is_gating_site = false; // observational only
                        evaluate_with(expr, &ctx)
                    }
                } else {
                    let mut ctx = EvalContext::from_attrs(attrs);
                    ctx.predicates = predicates;
                    ctx.event_fired = event_fired;
                    ctx.is_gating_site = false; // observational only
                    evaluate_with(expr, &ctx)
                }
            }
        };

        let mut guard = self.last_state.lock().unwrap();
        let key = (session_id.clone(), policy_name.to_string());
        match guard.get(&key).copied() {
            None => {
                guard.insert(key, active);
                drop(guard);
                if active {
                    let _ = bus.emit_guard_policy_activated_in(session_id, policy_name.to_string());
                } else {
                    // emit `.deactivated` on first-eval-inactive too,
                    // with a structured payload that surfaces the predicate
                    // and the @status of every referenced variable. Without
                    // this, a misconfigured active_if (e.g. referencing an
                    // unset variable that silently folds to null/false)
                    // would produce zero observability signal.
                    let payload = build_deactivation_payload(active_if, status_lookup, variables);
                    let _ = bus.emit_guard_policy_deactivated_with_payload_in(
                        session_id,
                        policy_name.to_string(),
                        payload,
                    );
                }
            }
            Some(prev) if prev != active => {
                guard.insert(key, active);
                drop(guard);
                if active {
                    let _ = bus.emit_guard_policy_activated_in(session_id, policy_name.to_string());
                } else {
                    let payload = build_deactivation_payload(active_if, status_lookup, variables);
                    let _ = bus.emit_guard_policy_deactivated_with_payload_in(
                        session_id,
                        policy_name.to_string(),
                        payload,
                    );
                }
            }
            _ => {}
        }
        active
    }

    /// Test-only inspection helper.
    #[cfg(test)]
    pub fn current_state(&self, policy_name: &str) -> Option<bool> {
        self.current_state_in(&SessionId::default(), policy_name)
    }

    #[cfg(test)]
    pub fn current_state_in(&self, session_id: &SessionId, policy_name: &str) -> Option<bool> {
        self.last_state
            .lock()
            .unwrap()
            .get(&(session_id.clone(), policy_name.to_string()))
            .copied()
    }

    /// Read-only snapshot of the latched activation state for the
    /// default session. Kept for back-compat with pre-refactor tests.
    pub fn snapshot(&self) -> HashMap<String, bool> {
        self.snapshot_in(&SessionId::default())
    }

    /// Read-only snapshot of the latched activation state for
    /// `session_id`. Returned map holds the most recent `active_if:`
    /// evaluation outcome for every policy name the cache has seen
    /// since session start. Used by the session to compute
    /// `{active_guard_policies}` and `{prior_checks_summary}` for
    /// Stage-3 prompt enrichment.
    pub fn snapshot_in(&self, session_id: &SessionId) -> HashMap<String, bool> {
        self.last_state
            .lock()
            .unwrap()
            .iter()
            .filter_map(|((sid, name), v)| {
                if sid == session_id {
                    Some((name.clone(), *v))
                } else {
                    None
                }
            })
            .collect()
    }

    /// Drop every latched activation entry belonging to `session_id`.
    /// Called when a [`crate::runtime::GuardrailsSession`] is dropped
    /// or closed. Idempotent.
    pub fn cleanup_session(&self, session_id: &SessionId) {
        let mut guard = self.last_state.lock().unwrap();
        guard.retain(|(sid, _), _| sid != session_id);
    }
}

/// Build the diagnostic payload for a
/// `guard_policy.<name>.deactivated` emission. Returns `None` when the
/// policy has no `active_if:` (no diagnostic story to tell). Otherwise
/// the payload carries the source expression, the literal `false`
/// result, and one entry per referenced variable naming its current
/// `@status`. Unknown identifiers (built-in functions, namespace
/// roots, quantifier-bound variables) are filtered out so the payload
/// surfaces only declared variables — the names the operator can act
/// on.
fn build_deactivation_payload(
    active_if: Option<&str>,
    status_lookup: Option<&dyn StatusLookup>,
    variables: &[Variable],
) -> Option<Value> {
    let expr_src = active_if?;
    let referenced = collect_referenced_variables(expr_src, variables);
    let referenced_payload: Vec<Value> = referenced
        .iter()
        .map(|name| {
            let status = status_lookup
                .and_then(|sl| sl.status(name))
                .map(variable_status_str)
                .unwrap_or("unknown");
            json!({
                "name": name,
                "status": status,
            })
        })
        .collect();
    Some(json!({
        "active_if": expr_src,
        "result": false,
        "referenced_variables": referenced_payload,
    }))
}

fn variable_status_str(s: VariableStatus) -> &'static str {
    match s {
        VariableStatus::Unset => "unset",
        VariableStatus::Resolved => "resolved",
        VariableStatus::Denied => "denied",
    }
}

/// Parse `expression` and return the (deduplicated, sorted) names of
/// declared variables it references. Identifiers that are not in
/// `variables` — namespace roots like `tool`, `endpoint`, `session`,
/// `agent`, `context`, `result`; function names; quantifier-bound
/// variables; literals — are filtered out. On parse error returns the
/// empty vec rather than failing, so observability emission never
/// blocks on a malformed expression (which the loader should have
/// already rejected anyway).
fn collect_referenced_variables(expression: &str, variables: &[Variable]) -> Vec<String> {
    let Ok(ast) = parse(expression) else {
        return Vec::new();
    };
    let declared: std::collections::HashSet<&str> =
        variables.iter().map(|v| v.name.as_str()).collect();
    let mut found: std::collections::BTreeSet<String> = std::collections::BTreeSet::new();
    walk_expr_collect_idents(&ast, &declared, &mut found);
    found.into_iter().collect()
}

fn walk_expr_collect_idents(
    expr: &Expr,
    declared: &std::collections::HashSet<&str>,
    found: &mut std::collections::BTreeSet<String>,
) {
    match expr {
        Expr::Literal(_) => {}
        Expr::Ident(name) => {
            if declared.contains(name.as_str()) {
                found.insert(name.clone());
            }
        }
        Expr::DottedAccess { root, .. } => {
            // Only the root identifier matters for variable attribution
            // — paths like `customer.email` reach into structured data
            // hanging off `customer`. Reserved namespace roots (tool,
            // endpoint, …) are filtered by the `declared` set.
            if let Expr::Ident(name) = root.as_ref() {
                if declared.contains(name.as_str()) {
                    found.insert(name.clone());
                }
            } else {
                walk_expr_collect_idents(root, declared, found);
            }
        }
        Expr::MetaField { var, .. } => {
            if declared.contains(var.as_str()) {
                found.insert(var.clone());
            }
        }
        Expr::BinaryOp { left, right, .. } => {
            walk_expr_collect_idents(left, declared, found);
            walk_expr_collect_idents(right, declared, found);
        }
        Expr::UnaryOp { operand, .. } => {
            walk_expr_collect_idents(operand, declared, found);
        }
        Expr::FnCall { args, .. } => {
            for a in args {
                walk_expr_collect_idents(a, declared, found);
            }
        }
        Expr::Ternary {
            condition,
            then_expr,
            else_expr,
        } => {
            walk_expr_collect_idents(condition, declared, found);
            walk_expr_collect_idents(then_expr, declared, found);
            walk_expr_collect_idents(else_expr, declared, found);
        }
        Expr::List(items) => {
            for i in items {
                walk_expr_collect_idents(i, declared, found);
            }
        }
        Expr::Index { object, index } => {
            walk_expr_collect_idents(object, declared, found);
            walk_expr_collect_idents(index, declared, found);
        }
        Expr::Assignment { value, .. } => {
            walk_expr_collect_idents(value, declared, found);
        }
        Expr::Quantifier {
            collection,
            predicate,
            ..
        } => {
            // The bound variable shadows any outer identifier of the
            // same name inside `predicate`, but since we filter by the
            // declared-variable set anyway, that shadowing has no
            // practical effect on what we collect — bound vars don't
            // appear in `declared`.
            walk_expr_collect_idents(collection, declared, found);
            walk_expr_collect_idents(predicate, declared, found);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::event_bus::{BusEvent, EventBus};
    use serde_json::json;
    use std::sync::Arc;

    fn capture_events() -> (EventBus, Arc<Mutex<Vec<BusEvent>>>) {
        let bus = EventBus::new();
        let captured: Arc<Mutex<Vec<BusEvent>>> = Arc::new(Mutex::new(Vec::new()));
        let cap = captured.clone();
        bus.subscribe(None, move |ev: &BusEvent| {
            cap.lock().unwrap().push(ev.clone());
        });
        (bus, captured)
    }

    fn count_gp_kind(events: &[BusEvent], expected: crate::events::GpEventKind) -> usize {
        events
            .iter()
            .filter(|e| {
                matches!(
                    e,
                    BusEvent::Emitted {
                        event_id: crate::events::EventId::GuardPolicy { kind, .. },
                        ..
                    } if *kind == expected
                )
            })
            .count()
    }

    #[test]
    fn omitted_active_if_is_always_active() {
        let cache = ActivationCache::new();
        let (bus, _) = capture_events();
        let attrs = HashMap::new();
        assert!(cache.evaluate_and_emit("p", None, &attrs, None, None, &bus));
    }

    #[test]
    fn first_active_emits_activated() {
        let cache = ActivationCache::new();
        let (bus, captured) = capture_events();
        let attrs = HashMap::new();
        cache.evaluate_and_emit("p", Some("true"), &attrs, None, None, &bus);
        let events = captured.lock().unwrap();
        assert_eq!(
            count_gp_kind(&events, crate::events::GpEventKind::Activated),
            1
        );
    }

    #[test]
    fn transition_to_inactive_emits_deactivated() {
        let cache = ActivationCache::new();
        let (bus, captured) = capture_events();
        let mut attrs = HashMap::new();
        attrs.insert("flag".to_string(), json!(true));
        cache.evaluate_and_emit("p", Some("flag == true"), &attrs, None, None, &bus);
        attrs.insert("flag".to_string(), json!(false));
        cache.evaluate_and_emit("p", Some("flag == true"), &attrs, None, None, &bus);
        let events = captured.lock().unwrap();
        assert_eq!(
            count_gp_kind(&events, crate::events::GpEventKind::Deactivated),
            1
        );
    }

    #[test]
    fn no_repeat_event_when_state_unchanged() {
        let cache = ActivationCache::new();
        let (bus, captured) = capture_events();
        let attrs = HashMap::new();
        cache.evaluate_and_emit("p", Some("true"), &attrs, None, None, &bus);
        cache.evaluate_and_emit("p", Some("true"), &attrs, None, None, &bus);
        let events = captured.lock().unwrap();
        assert_eq!(
            count_gp_kind(&events, crate::events::GpEventKind::Activated),
            1
        );
    }

    #[test]
    fn first_inactive_emits_deactivated_with_payload() {
        // first-eval-inactive used to emit nothing, leaving
        // developers with no signal that the policy was even
        // considered. We now emit `.deactivated` carrying the
        // diagnostic payload so the silent-inactivation footgun is
        // visible in observability.
        let cache = ActivationCache::new();
        let (bus, captured) = capture_events();
        let mut attrs = HashMap::new();
        attrs.insert("flag".to_string(), json!(false));
        let active = cache.evaluate_and_emit("p", Some("flag == true"), &attrs, None, None, &bus);
        assert!(!active);
        let events = captured.lock().unwrap();
        assert_eq!(
            count_gp_kind(&events, crate::events::GpEventKind::Activated),
            0
        );
        assert_eq!(
            count_gp_kind(&events, crate::events::GpEventKind::Deactivated),
            1
        );
    }

    #[test]
    fn first_inactive_emits_once_only() {
        // The latch must suppress re-emissions when the state stays
        // inactive — the event is signal, not a per-evaluation alarm.
        let cache = ActivationCache::new();
        let (bus, captured) = capture_events();
        let mut attrs = HashMap::new();
        attrs.insert("flag".to_string(), json!(false));
        for _ in 0..5 {
            cache.evaluate_and_emit("p", Some("flag == true"), &attrs, None, None, &bus);
        }
        let events = captured.lock().unwrap();
        assert_eq!(
            count_gp_kind(&events, crate::events::GpEventKind::Deactivated),
            1
        );
    }

    // ── Diagnostic payload shape ───────────────────────────

    use crate::expressions::eval::{StatusLookup, VariableStatus};
    use crate::variables::{Variable, VariableType};

    struct FakeStatusLookup<'a>(&'a HashMap<String, VariableStatus>);
    impl<'a> StatusLookup for FakeStatusLookup<'a> {
        fn status(&self, var: &str) -> Option<VariableStatus> {
            self.0.get(var).copied()
        }
        fn meta(&self, _var: &str, _field: &str) -> Option<crate::expressions::eval::EvalResult> {
            None
        }
        fn value(&self, _var: &str) -> Option<Value> {
            None
        }
    }

    fn make_variable(name: &str) -> Variable {
        Variable {
            name: name.to_string(),
            var_type: VariableType::String,
            description: None,
            default: None,
            members: None,
            vocabulary: None,
            strict_resource_coverage: None,
            update: None,
            key: None,
            lifetime: None,
            on_demand_by: None,
            populated_by: Vec::new(),
        }
    }

    fn deactivated_payload(events: &[BusEvent]) -> Option<Value> {
        events.iter().find_map(|e| match e {
            BusEvent::Emitted {
                event_id: crate::events::EventId::GuardPolicy { kind, .. },
                payload,
                ..
            } if *kind == crate::events::GpEventKind::Deactivated => payload.clone(),
            _ => None,
        })
    }

    #[test]
    fn deactivation_payload_lists_unset_referenced_variable() {
        let cache = ActivationCache::new();
        let (bus, captured) = capture_events();
        // `vip_context` is declared but `@status == 'unset'` ⇒
        // active_if folds to false. The payload MUST surface
        // `vip_context.@status=unset` so the developer knows why.
        let attrs = HashMap::new();
        let vars = vec![make_variable("vip_context")];
        let mut statuses = HashMap::new();
        statuses.insert("vip_context".to_string(), VariableStatus::Unset);
        let sl = FakeStatusLookup(&statuses);
        let active = cache.evaluate_and_emit_with_diagnostics_in(
            &SessionId::default(),
            "vip_redact",
            Some("vip_context == 'sensitive'"),
            &attrs,
            None,
            None,
            Some(&sl as &dyn StatusLookup),
            &vars,
            &bus,
        );
        assert!(!active);
        let events = captured.lock().unwrap();
        let payload = deactivated_payload(&events).expect("payload present");
        assert_eq!(payload["active_if"], json!("vip_context == 'sensitive'"));
        assert_eq!(payload["result"], json!(false));
        let refs = payload["referenced_variables"].as_array().unwrap();
        assert_eq!(refs.len(), 1);
        assert_eq!(refs[0]["name"], json!("vip_context"));
        assert_eq!(refs[0]["status"], json!("unset"));
    }

    #[test]
    fn deactivation_payload_filters_reserved_namespaces() {
        // `tool` is a namespace root, not a declared variable — it must
        // not appear in `referenced_variables`.
        let cache = ActivationCache::new();
        let (bus, captured) = capture_events();
        let mut attrs = HashMap::new();
        attrs.insert("tool".to_string(), json!({"params": {"amount": 5}}));
        let vars: Vec<Variable> = Vec::new();
        let active = cache.evaluate_and_emit_with_diagnostics_in(
            &SessionId::default(),
            "amount_gate",
            Some("tool.params.amount > 100"),
            &attrs,
            None,
            None,
            None,
            &vars,
            &bus,
        );
        assert!(!active);
        let events = captured.lock().unwrap();
        let payload = deactivated_payload(&events).expect("payload present");
        let refs = payload["referenced_variables"].as_array().unwrap();
        assert!(refs.is_empty());
    }

    #[test]
    fn deactivation_payload_omits_when_no_active_if() {
        // A policy without `active_if:` is statically active — we never
        // reach the deactivated branch. Helper returns None to make
        // emission a no-op in case of future plumbing changes.
        let payload = build_deactivation_payload(None, None, &[]);
        assert!(payload.is_none());
    }

    #[test]
    fn collect_referenced_variables_finds_dotted_root() {
        let vars = vec![make_variable("customer")];
        let names = collect_referenced_variables("customer.email == 'x@y'", &vars);
        assert_eq!(names, vec!["customer".to_string()]);
    }

    #[test]
    fn collect_referenced_variables_finds_meta_field() {
        let vars = vec![make_variable("approval")];
        let names = collect_referenced_variables("approval.@status == 'resolved'", &vars);
        assert_eq!(names, vec!["approval".to_string()]);
    }

    #[test]
    fn collect_referenced_variables_dedupes_and_sorts() {
        let vars = vec![make_variable("a"), make_variable("b")];
        let names = collect_referenced_variables("a == 1 and b == 2 and a == 3", &vars);
        assert_eq!(names, vec!["a".to_string(), "b".to_string()]);
    }
}
