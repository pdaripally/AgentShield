//! Detection-kind dispatch for `evaluate_when[]` entries.
//!
//! Each `EvaluateWhenEntry` carries exactly one of the five detection
//! kinds: `expression`, `pattern`, `patterns`, `llm`, `classifier`. This
//! module owns the evaluation strategy for each kind plus the trait
//! definitions hosts implement to plug in LLM and classifier providers.
//!
//! ## Design
//!
//! - **Synchronous traits**: the engine is sync. Hosts that need async
//!   wrap their async clients with `tokio::runtime::Handle::block_on`
//!   inside the trait impl.
//! - **Spans**: only `pattern` / `patterns` produce character offsets
//!   natively; `llm` and `classifier` may optionally emit spans through
//!   their structured response types.
//! - **Polarity**: — `expression:` is a predicate (truthy =
//!   pass), all others are detectors (positive detection = fail).
//! - **Fail-closed**: any error path in detection (regex compile failure,
//!   missing host trait, malformed LLM response, unrecognized
//!   configuration) yields a `Fail { reason }` so the gate denies. This
//!   is the security invariant.

use std::collections::HashMap;
use std::sync::mpsc;
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::Duration;

use regex::Regex;
use serde_json::Value;

use crate::configurations::ShieldConfiguration;
use crate::constants::detector::{
    CLASSIFIER_DEFAULT_TIMEOUT_MS as DETECTOR_CLASSIFIER_DEFAULT_TIMEOUT_MS, LLM_DEFAULT_TIMEOUT_MS,
};
use crate::expressions::eval::{
    evaluate_with, EvalContext, EventFiredHook, PredicateLookup, ResolverHook, StatusLookup,
};
use crate::guard_policy::{ClassifierDetection, DetectionKind, EvaluateWhenEntry, LlmDetection};

/// One **codepoint-offset** range identifying a redaction span — NOT a
/// byte range. `start..end` is half-open and is interpreted against
/// `subject.chars()` (see [`super::action::apply_redactions`]). Mirrors
/// the span format produced by LLM responses and pattern
/// matches. Spans whose `end > char_count(subject)` or `end <= start`
/// are silently dropped at apply time (with a `debug` log) rather than
/// clamped, to avoid partial-grapheme corruption.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Span {
    pub start: usize,
    pub end: usize,
    pub replacement: Option<String>,
}

/// Verdict produced by detecting against a single `evaluate_when[]` entry
/// against a content subject.
#[derive(Debug, Clone)]
pub enum DetectionVerdict {
    /// The entry passed (the call may proceed past this entry).
    Pass,
    /// The entry failed. `reason` is the entry's `reason:` (or a fallback
    /// surfaced by the detector when the LLM/classifier provided one).
    Fail {
        reason: String,
        /// Character spans for redaction (`pattern` / `patterns` / `llm`
        /// with `spans[]`). Empty for predicate-style failures or LLM
        /// block-mode without spans.
        spans: Vec<Span>,
        /// terminal resolver deny / cancelled (step 4 +
        /// line ~2291). When `true`, this failure originated
        /// from an `evaluate_when[].expression:` whose evaluation read a
        /// declared variable whose `@status` is `denied` (either the
        /// pre-evaluation check caught an already-poisoned read, or a
        /// resolver invoked during this gate's own auto-resolution
        /// returned `decision: deny` / `cancelled` and the post-check
        /// surfaced the freshly-flipped status).
        ///
        /// The guard-policy runner MUST treat a terminal failure as a
        /// `block` regardless of the entry's declared `action:`, and
        /// MUST NOT evaluate `allowed_when:` to suppress it. A
        /// resolver `deny` is a stronger signal than a generic
        /// predicate-returned-false failure; collapsing both into the
        /// same shape laundered explicit denials through truthy
        /// `allowed_when:` bypasses.
        ///
        /// Only set by [`detect_expression`] — the pattern, LLM, and
        /// classifier detectors never trigger auto-resolution and so
        /// never produce a terminal failure.
        terminal: bool,
    },
}

impl DetectionVerdict {
    pub fn is_pass(&self) -> bool {
        matches!(self, DetectionVerdict::Pass)
    }
    pub fn fail(reason: impl Into<String>) -> Self {
        DetectionVerdict::Fail {
            reason: reason.into(),
            spans: Vec::new(),
            terminal: false,
        }
    }
    pub fn fail_spans(reason: impl Into<String>, spans: Vec<Span>) -> Self {
        DetectionVerdict::Fail {
            reason: reason.into(),
            spans,
            terminal: false,
        }
    }
    /// fail with the terminal-resolver-deny marker set. The
    /// guard-policy runner must propagate this failure unconditionally
    /// (force-block, skip `allowed_when:` bypass).
    pub fn fail_terminal(reason: impl Into<String>) -> Self {
        DetectionVerdict::Fail {
            reason: reason.into(),
            spans: Vec::new(),
            terminal: true,
        }
    }
}

/// Structured LLM response. Hosts return this from
/// [`LlmCaller::call`]; the runtime then folds it into a verdict.
#[derive(Debug, Clone, Default)]
pub struct LlmResponse {
    /// `ALLOW` / `BLOCK`. For redact-mode entries the field is ignored.
    pub decision: Option<LlmDecision>,
    pub confidence: Option<f64>,
    pub reason: Option<String>,
    pub categories: Vec<String>,
    pub spans: Vec<Span>,
    /// Boolean shorthand fields., *any* truthy boolean field
    /// (e.g. `contains_pii`, `is_jailbreak`) MUST be treated as `BLOCK`.
    pub bool_flags: HashMap<String, bool>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LlmDecision {
    Allow,
    Block,
}

impl LlmResponse {
    pub fn folded_decision(&self) -> LlmDecision {
        if self.bool_flags.values().any(|v| *v) {
            return LlmDecision::Block;
        }
        match self.decision {
            Some(d) => d,
            // missing / unrecognized decision MUST be BLOCK.
            None => LlmDecision::Block,
        }
    }
}

/// Categorized classifier-call failure.
///
/// Previously the runtime collapsed every classifier transport / config
/// failure into one verdict reason of the form
/// `"<author-supplied reason> (classifier call failed)"`. That string
/// is actively misleading because the author-supplied reason almost
/// always claims a detection actually happened — e.g.
/// `"Azure AI Content Safety detected an input-attack at or above the
/// configured severity threshold."` — which is the opposite of the
/// truth when the classifier never ran successfully.
///
/// This enum partitions the failure modes the bundled providers and
/// the FFI bridge can produce so [`detect_classifier`] can emit a
/// differentiated, honest message without leaning on the YAML-authored
/// detection reason. **Categorization is purely heuristic** — providers
/// keep the existing `Result<_, String>` interface and the runtime
/// pattern-matches on stable prefixes the bundled providers emit
/// (`aacs HTTP 401:...`, `aacs: api_key not resolved`,
/// `classifier HTTP send:...`, `no resolved classifier configuration...`).
///
/// **Fail-closed posture is unchanged**: every variant still produces
/// a [`DetectionVerdict::Fail`]. Only the human-readable text differs.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ClassifierError {
    /// `api_key_env` is unset or resolved to an empty value, or a
    /// bundled provider could not source its credential.
    MissingCredentials { detail: String },
    /// Provider rejected the request with HTTP 401 / 403. Almost
    /// always an `api_key_env` mismatch.
    AuthFailed { detail: String },
    /// Provider responded with HTTP 429.
    RateLimited { detail: String },
    /// Provider responded with HTTP 5xx.
    ProviderServerError { detail: String },
    /// Provider response was non-2xx for some other status (4xx that
    /// isn't 401/403/429).
    HttpStatus { detail: String },
    /// `endpoint:` is missing, empty, or syntactically unusable.
    EndpointInvalid { detail: String },
    /// Network/transport failure — DNS, connection refused, TLS
    /// handshake, request body write, response body read.
    NetworkError { detail: String },
    /// Provider response was 2xx but the body could not be parsed
    /// (JSON parse error, missing required field).
    BadResponse { detail: String },
    /// The runtime has a `ClassifierCaller` but no resolved
    /// configuration for the requested `configuration_id`.
    NotConfigured { detail: String },
    /// Fallback for anything that doesn't fit a known prefix. The raw
    /// string is preserved verbatim.
    Other { detail: String },
}

impl ClassifierError {
    /// Heuristically classify a raw error string produced by a
    /// [`ClassifierCaller`] implementation. The patterns recognized
    /// here are kept in sync with the bundled providers under
    /// `crate::classifiers::*` and the FFI bridge.
    pub fn categorize(raw: &str) -> Self {
        let lower = raw.to_ascii_lowercase();

        if lower.contains("no resolved classifier configuration") {
            return Self::NotConfigured {
                detail: raw.to_string(),
            };
        }
        if lower.contains("api_key not resolved")
            || lower.contains("api key not resolved")
            || lower.contains("api_key_env")
            || lower.contains("credentials")
        {
            return Self::MissingCredentials {
                detail: raw.to_string(),
            };
        }
        if lower.contains("endpoint") && (lower.contains("required") || lower.contains("invalid")) {
            return Self::EndpointInvalid {
                detail: raw.to_string(),
            };
        }

        // HTTP status patterns. The bundled providers emit
        // `<provider> HTTP <code>: <body>`; the FFI bridge does not
        // touch status, it just forwards a string.
        if let Some(status) = extract_http_status(raw) {
            return match status {
                401 | 403 => Self::AuthFailed {
                    detail: raw.to_string(),
                },
                429 => Self::RateLimited {
                    detail: raw.to_string(),
                },
                500..=599 => Self::ProviderServerError {
                    detail: raw.to_string(),
                },
                _ => Self::HttpStatus {
                    detail: raw.to_string(),
                },
            };
        }

        if lower.contains("classifier http send")
            || lower.contains("classifier http read")
            || lower.contains("connection")
            || lower.contains("dns")
            || lower.contains("timed out")
            || lower.contains("timeout")
            || lower.contains("network")
        {
            return Self::NetworkError {
                detail: raw.to_string(),
            };
        }

        if lower.contains("json parse")
            || lower.contains("malformed")
            || lower.contains("missing `categoriesanalysis`")
            || lower.contains("missing categoriesanalysis")
            || lower.contains("unexpected response")
        {
            return Self::BadResponse {
                detail: raw.to_string(),
            };
        }

        Self::Other {
            detail: raw.to_string(),
        }
    }

    /// Build the verdict reason surfaced through
    /// [`crate::format_block_message`]. The author-supplied YAML
    /// `reason:` is deliberately omitted from the call-failed messages
    /// because it asserts a detection actually happened (e.g. "input
    /// attack detected") which is the opposite of the truth.
    ///
    /// `configuration_id` is the YAML `evaluate_when[].classifier`
    /// reference; including it lets operators jump straight to the
    /// relevant `configurations[]` entry.
    pub fn block_message(&self, configuration_id: &str) -> String {
        match self {
            Self::MissingCredentials { detail } => format!(
                "classifier `{configuration_id}` could not run: credentials not resolved (check `api_key_env` value) — {detail}"
            ),
            Self::AuthFailed { detail } => format!(
                "classifier `{configuration_id}` could not run: authentication rejected by provider (verify `api_key_env`) — {detail}"
            ),
            Self::RateLimited { detail } => format!(
                "classifier `{configuration_id}` could not run: provider rate-limited the request (HTTP 429) — {detail}"
            ),
            Self::ProviderServerError { detail } => format!(
                "classifier `{configuration_id}` could not run: provider returned a server error (HTTP 5xx) — {detail}"
            ),
            Self::HttpStatus { detail } => format!(
                "classifier `{configuration_id}` could not run: provider returned a non-success HTTP status — {detail}"
            ),
            Self::EndpointInvalid { detail } => format!(
                "classifier `{configuration_id}` could not run: endpoint misconfigured — {detail}"
            ),
            Self::NetworkError { detail } => format!(
                "classifier `{configuration_id}` could not run: network/transport error reaching provider — {detail}"
            ),
            Self::BadResponse { detail } => format!(
                "classifier `{configuration_id}` could not run: provider response was unparseable — {detail}"
            ),
            Self::NotConfigured { detail } => format!(
                "classifier `{configuration_id}` is not configured for this runtime — {detail}"
            ),
            Self::Other { detail } => format!(
                "classifier `{configuration_id}` could not run: {detail}"
            ),
        }
    }
}

/// Pull an `HTTP <code>` token out of an error string the bundled
/// providers emit. Returns `None` when no recognizable status appears.
fn extract_http_status(raw: &str) -> Option<u16> {
    let bytes = raw.as_bytes();
    let needle = b"HTTP ";
    let mut i = 0;
    while i + needle.len() < bytes.len() {
        if &bytes[i..i + needle.len()] == needle {
            let mut j = i + needle.len();
            let start = j;
            while j < bytes.len() && bytes[j].is_ascii_digit() && j - start < 3 {
                j += 1;
            }
            if j > start {
                if let Ok(s) = std::str::from_utf8(&bytes[start..j]) {
                    if let Ok(n) = s.parse::<u16>() {
                        return Some(n);
                    }
                }
            }
        }
        i += 1;
    }
    None
}

/// Structured classifier response. detection fails when
/// `score >= threshold` OR `flagged == true`. Hosts may also emit a
/// `label` for label-based classifiers.
#[derive(Debug, Clone, Default)]
pub struct ClassifierVerdict {
    pub score: f64,
    pub threshold: f64,
    pub flagged: bool,
    pub label: Option<String>,
    pub reason: Option<String>,
    pub spans: Vec<Span>,
}

impl ClassifierVerdict {
    /// a classifier verdict is a failure iff `flagged` is true,
    /// or `score >= threshold`. The comparison is unconditional —
    /// `threshold == 0.0` is meaningful and means "fail anything
    /// non-negative". Negative thresholds are nonsensical and are the
    /// caller's responsibility to validate at config-load time.
    pub fn is_failure(&self) -> bool {
        self.flagged || self.score >= self.threshold
    }
}

/// Sync LLM caller surface. Hosts implementing this against an async
/// client should bridge with `tokio::runtime::Handle::block_on` inside
/// the trait impl.
pub trait LlmCaller: Send + Sync {
    /// Render the given prompt (already template-substituted) against the
    /// host's LLM. Returns the structured response or an `Err(reason)`
    /// — errors fold into a `BLOCK` decision ("malformed
    /// JSON MUST trigger the entry's `on_error:` policy (default
    /// `block`)").
    fn call(&self, configuration_id: Option<&str>, prompt: &str) -> Result<LlmResponse, String>;
}

/// Sync classifier caller surface.
pub trait ClassifierCaller: Send + Sync {
    /// Classify `subject` using the configured classifier. The returned
    /// envelope encodes both threshold semantics and explicit `flagged`
    /// failure.
    fn classify(&self, configuration_id: &str, subject: &str) -> Result<ClassifierVerdict, String>;
}

/// Per-engine regex cache.
#[derive(Default)]
pub struct RegexCache {
    cache: Mutex<HashMap<String, Result<Regex, String>>>,
}

impl RegexCache {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn compile(&self, pattern: &str) -> Result<Regex, String> {
        // ReDoS guard: pattern length cap of 500.
        if pattern.len() > 500 {
            return Err(format!(
                "regex pattern length {} exceeds the 500-char limit",
                pattern.len()
            ));
        }
        let mut guard = self.cache.lock().unwrap();
        if let Some(existing) = guard.get(pattern) {
            return match existing {
                Ok(r) => Ok(r.clone()),
                Err(e) => Err(e.clone()),
            };
        }
        let r = Regex::new(pattern).map_err(|e| e.to_string());
        guard.insert(pattern.to_string(), r.clone());
        r
    }
}

/// Bag of references the detection dispatcher needs.
pub struct DetectionDeps<'a> {
    pub regex_cache: &'a RegexCache,
    /// Host LLM caller for `evaluate_when[].llm` detection. Held as
    /// an `Arc` (not a borrow) so [`detect_llm`] can clone it into
    /// the worker thread used to enforce the wall-clock timeout
    /// without imposing a `'static` lifetime on `DetectionDeps`
    /// itself.
    pub llm_caller: Option<Arc<dyn LlmCaller>>,
    /// Host classifier caller for `evaluate_when[].classifier`
    /// detection. Same Arc-rather-than-borrow rationale as
    /// [`Self::llm_caller`].
    pub classifier_caller: Option<Arc<dyn ClassifierCaller>>,
    /// Merged `configurations[]` registry. [`detect_llm`] and
    /// [`detect_classifier`] look the `configuration_id` referenced by
    /// the detection entry up here to resolve the effective wall-clock
    /// timeout — `configurations[id].timeout` falls back to a per-kind
    /// default. `None` collapses every detector
    /// call to the per-kind default; the per-stage runners populate
    /// this from `engine.deps().config.configurations`.
    pub configurations: Option<&'a [ShieldConfiguration]>,
    /// Subject template: rendered prompt receives the canonical
    /// variables. Stages augment via `extra_template_vars`.
    pub objective: &'a str,
    pub forbidden: &'a [String],
    pub user_input: &'a str,
    pub extra_template_vars: HashMap<String, String>,
    pub attrs: &'a HashMap<String, Value>,
    pub status_lookup: Option<&'a dyn StatusLookup>,
    pub event_fired: Option<&'a dyn EventFiredHook>,
    pub predicates: Option<&'a dyn PredicateLookup>,
    pub resolver_hook: Option<&'a dyn ResolverHook>,
    /// Append the Default-Implementation Runtime Context block to
    /// every rendered prompt. Set by the Stage-3 runner only; Stages 1,
    /// 4, and 5 leave this `false` so their LLM detections render the
    /// authored prompt unchanged.
    pub append_runtime_context: bool,
    // ── v8 perf-logging (PR6) fields ───────────────────────────────
    //
    // These thread the per-stage timing context into `detect_llm` /
    // `detect_classifier` so AC10-Corr correlation attributes can be
    // stamped on every `LlmCalled` / `ClassifierCalled` emit. All
    // four are populated by `stage_common::build_detection_deps_*`;
    // test code that constructs `DetectionDeps` inline defaults them
    // to `None` / `Off` / `Stage::Input` and gets the AC7 behaviour
    // (zero perf emissions) for free.
    /// Clock for measuring LLM / classifier call latency. `None`
    /// suppresses perf emissions regardless of `perf_telemetry`.
    pub clock: Option<&'a dyn crate::clock::Clock>,
    /// Observability dispatcher for emitting `LlmCalled` /
    /// `ClassifierCalled` perf events. `None` suppresses emission.
    pub observability: Option<&'a crate::observability::ObservabilityDispatcher>,
    /// Perf-telemetry gating knob. `Off` (the default) suppresses
    /// every PR6 perf emission.
    pub perf_telemetry: crate::perf_telemetry::PerfTelemetry,
    /// Stage that built these deps. Stamped as `KEY_STAGE` on every
    /// `LlmCalled` / `ClassifierCalled` perf event.
    pub stage: crate::observability::Stage,
    /// Originating session id. Surfaces on perf events so adopters
    /// can correlate cross-stage cost back to the conversation.
    pub session_id: &'a str,
    /// Per-turn correlation id (— required top-level field on
    /// every Info+ event).
    pub correlation_id: &'a str,
}

impl<'a> DetectionDeps<'a> {
    /// Substitute canonical + extra template variables in a
    /// prompt. Variable names are case-sensitive; undefined refs become
    /// the empty string (— required by spec, NOT left as
    /// literal `{name}` tokens).
    ///
    /// Stage-3 callers (`append_runtime_context: true`) additionally
    /// append the Runtime Context block AFTER the user-supplied
    /// template's substitution, with the same variable substitution
    /// applied to the block. This mirrors the spec's "appended after
    /// any user-supplied template substitution" requirement.
    pub fn render_prompt(&self, template: &str) -> String {
        let mut out = self.substitute(template);
        if self.append_runtime_context {
            out.push_str(&self.substitute(RUNTIME_CONTEXT_BLOCK));
        }
        out
    }

    fn substitute(&self, template: &str) -> String {
        let mut out = template.to_string();
        let forbidden_joined = self.forbidden.join("\n");
        out = replace_token(&out, "{user_input}", self.user_input);
        out = replace_token(&out, "{objective}", self.objective);
        out = replace_token(&out, "{forbidden}", &forbidden_joined);
        for (k, v) in &self.extra_template_vars {
            let token = format!("{{{}}}", k);
            out = replace_token(&out, &token, v);
        }
        // Remaining `{name}` tokens are undefined references
        // requires them to render as empty rather than persist as
        // literals. Identifier shape: `[A-Za-z_][A-Za-z0-9_]*`.
        scrub_unknown_tokens(&out)
    }
}

/// Spec — Default-Implementation Runtime Context block appended
/// to every Stage-3 (`tool_execution_validation`) LLM-detection prompt.
/// The block is verbatim spec text; substitution is performed by the
/// caller via [`DetectionDeps::render_prompt`].
const RUNTIME_CONTEXT_BLOCK: &str = "\n\n## Runtime Context\n\nTool: {tool_name}\nDescription: {tool_description}\nPermission: {tool_permission}\nParameters:\n{tool_params}\n\nActive guard policies: {active_guard_policies}\nVariables:\n{variables}\n\n## Prior Automated Checks\n{prior_checks_summary}\n";

fn scrub_unknown_tokens(s: &str) -> String {
    let bytes = s.as_bytes();
    let mut out = String::with_capacity(s.len());
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'{' {
            // Look ahead for `[A-Za-z_][A-Za-z0-9_]*\}`.
            let mut j = i + 1;
            if j < bytes.len() && (bytes[j].is_ascii_alphabetic() || bytes[j] == b'_') {
                j += 1;
                while j < bytes.len() && (bytes[j].is_ascii_alphanumeric() || bytes[j] == b'_') {
                    j += 1;
                }
                if j < bytes.len() && bytes[j] == b'}' {
                    // Skip the entire `{name}` token.
                    i = j + 1;
                    continue;
                }
            }
        }
        // Append this UTF-8 char as-is. Walk by char boundary.
        let ch_end = next_char_boundary(s, i);
        out.push_str(&s[i..ch_end]);
        i = ch_end;
    }
    out
}

fn next_char_boundary(s: &str, start: usize) -> usize {
    let mut end = start + 1;
    while end < s.len() && !s.is_char_boundary(end) {
        end += 1;
    }
    end
}

fn replace_token(haystack: &str, token: &str, replacement: &str) -> String {
    haystack.replace(token, replacement)
}

/// Run a single detection entry against the subject and return its verdict.
///
/// `effective_action` is the action that will fire on failure (after policy/
/// entry/default resolution). Passing it here lets detection kinds adjust
/// their pass/fail logic for action-specific semantics — most
/// notably `action: redact` ignores the LLM's `decision` and is driven
/// Dispatch an `evaluate_when[]` entry to its detection kind.
///
/// `policy_name` and `evaluate_when_index` thread the
/// AC10-Corr correlation context (v8 plan PR6) through to the LLM /
/// classifier instrumentation so every `LlmCalled` /
/// `ClassifierCalled` emit carries `KEY_GUARD_POLICY` and
/// `KEY_GUARD_POLICY_EVALUATE_WHEN_INDEX` regardless of whether the
/// adopter also enabled stage-level perf events. The non-LLM/classifier
/// detection kinds ignore both arguments.
pub fn detect(
    entry: &EvaluateWhenEntry,
    subject: &str,
    effective_action: crate::guard_policy::Action,
    policy_name: &str,
    evaluate_when_index: usize,
    deps: &DetectionDeps<'_>,
) -> DetectionVerdict {
    match &entry.detection {
        DetectionKind::Expression(expr) => detect_expression(expr, &entry.reason, deps),
        DetectionKind::Pattern(pat) => {
            detect_patterns(std::slice::from_ref(pat), &entry.reason, subject, deps)
        }
        DetectionKind::Patterns(pats) => detect_patterns(pats, &entry.reason, subject, deps),
        DetectionKind::Llm(llm) => detect_llm(
            llm,
            subject,
            &entry.reason,
            effective_action,
            policy_name,
            evaluate_when_index,
            deps,
        ),
        DetectionKind::Classifier(c) => detect_classifier(
            c,
            subject,
            &entry.reason,
            policy_name,
            evaluate_when_index,
            deps,
        ),
    }
}

fn detect_expression(expr: &str, reason: &str, deps: &DetectionDeps<'_>) -> DetectionVerdict {
    // gate-level denied/cancelled check ().
    // If the expression reads a declared variable whose @status is
    // `denied`, the gate's effective action MUST fire regardless of
    // how the stored `value` (typically null) folds through null-
    // tolerant predicates like `approval == null` or `not approval`.
    //
    // We check BEFORE evaluation (catches gates that read an already-
    // denied variable) AND AFTER evaluation (catches the gate that
    // triggered the denial during its own auto-resolution: the
    // resolver returns deny, the tracker auto-flips the variable to
    // `denied`, and the post-check surfaces the poison before the
    // gate's predicate-truth value is allowed to land).
    //
    // both hits return a TERMINAL failure (step 4 +
    // line ~2291). The guard-policy runner uses the terminal
    // marker to skip `allowed_when:` bypass and force-block, so an
    // explicit resolver `deny` / `cancelled` can NEVER be laundered
    // by an unrelated truthy `allowed_when:` expression.
    if let Some(sl) = deps.status_lookup {
        if let Some(denied) =
            crate::expressions::denied_refs::first_denied_ref(expr, sl, deps.predicates)
        {
            let citation = crate::expressions::denied_refs::format_denied_citation(&denied);
            return DetectionVerdict::fail_terminal(format!("{}{}", reason, citation));
        }
    }
    let mut ctx = EvalContext::from_attrs(deps.attrs);
    ctx.status_lookup = deps.status_lookup;
    ctx.event_fired = deps.event_fired;
    ctx.predicates = deps.predicates;
    ctx.is_gating_site = true;
    ctx.resolver_hook = deps.resolver_hook;
    let passed = evaluate_with(expr, &ctx);
    // post-check: re-inspect denied status after evaluation in
    // case auto-resolution flipped a referenced variable to `denied`
    // during this evaluate_with call.: TERMINAL failure.
    // pass `deps.predicates` so the walker can expand
    // predicate-call idents transitively.
    if let Some(sl) = deps.status_lookup {
        if let Some(denied) =
            crate::expressions::denied_refs::first_denied_ref(expr, sl, deps.predicates)
        {
            let citation = crate::expressions::denied_refs::format_denied_citation(&denied);
            return DetectionVerdict::fail_terminal(format!("{}{}", reason, citation));
        }
    }
    if passed {
        DetectionVerdict::Pass
    } else {
        DetectionVerdict::fail(reason.to_string())
    }
}

fn detect_patterns(
    pats: &[String],
    reason: &str,
    subject: &str,
    deps: &DetectionDeps<'_>,
) -> DetectionVerdict {
    let mut spans: Vec<Span> = Vec::new();
    for raw in pats {
        let regex = match deps.regex_cache.compile(raw) {
            Ok(r) => r,
            Err(_) => {
                // Fail-closed on a bad regex: report the entry's reason.
                return DetectionVerdict::fail(format!("{} (invalid regex)", reason));
            }
        };
        for m in regex.find_iter(subject) {
            // Convert byte offsets from the regex engine to char offsets;
            // the rest of the pipeline (apply_redactions et al.) speaks
            // chars per spec.
            let start_char = subject[..m.start()].chars().count();
            let end_char = start_char + subject[m.start()..m.end()].chars().count();
            spans.push(Span {
                start: start_char,
                end: end_char,
                replacement: None,
            });
        }
    }
    if spans.is_empty() {
        DetectionVerdict::Pass
    } else {
        DetectionVerdict::fail_spans(reason.to_string(), spans)
    }
}

/// Resolve the effective wall-clock timeout (milliseconds) for an
/// `evaluate_when[].llm` or `evaluate_when[].classifier` host callback.
///
/// Resolution order:
///   1. `configurations[id].timeout` when the entry references a
///      configuration that is registered and declares `timeout:`.
///   2. The per-kind default supplied by the caller
///      (`LLM_DEFAULT_TIMEOUT_MS` for LLM, `CLASSIFIER_DEFAULT_TIMEOUT_MS`
///      for classifier).
///
/// `configuration_id == None` (LLM with no `configuration:`) skips the
/// registry lookup and uses the default directly. An unrecognized id
/// is treated as "not configured" — the runtime still calls the host
/// (the unified `LlmCaller` / `ClassifierCaller` traits accept any
/// string and bundled providers route on configuration shape) but
/// gates the call with the default rather than failing closed at the
/// resolution step.
fn resolve_detector_timeout_ms(
    configurations: Option<&[ShieldConfiguration]>,
    configuration_id: Option<&str>,
    default_ms: u32,
) -> u32 {
    let (Some(cfgs), Some(id)) = (configurations, configuration_id) else {
        return default_ms;
    };
    cfgs.iter()
        .find(|c| c.id == id)
        .and_then(|c| c.timeout)
        .unwrap_or(default_ms)
}

/// Invoke the host [`LlmCaller`] on a worker thread and wait at most
/// `timeout_ms` for the response. A late envelope is discarded via
/// the dropped receiver (cooperative cancellation — we cannot
/// forcibly interrupt host code). Mirrors the lifecycle
/// (`resolver_runtime::{agent_kind,human_kind}`).
///
/// On timeout this returns an `Err("LLM call timed out after N ms")`
/// which the caller folds into [`DetectionVerdict::fail`] /// + (provider timeout → `on_error`; default `block`).
fn call_llm_with_timeout(
    caller: Arc<dyn LlmCaller>,
    configurations: Option<&[ShieldConfiguration]>,
    configuration_id: Option<&str>,
    rendered: String,
) -> Result<LlmResponse, String> {
    let timeout_ms =
        resolve_detector_timeout_ms(configurations, configuration_id, LLM_DEFAULT_TIMEOUT_MS);
    let deadline = Duration::from_millis(u64::from(timeout_ms));
    let (tx, rx) = mpsc::channel::<Result<LlmResponse, String>>();
    let caller_for_thread = Arc::clone(&caller);
    let configuration_id_owned = configuration_id.map(str::to_owned);
    thread::spawn(move || {
        let r = caller_for_thread.call(configuration_id_owned.as_deref(), &rendered);
        let _ = tx.send(r);
    });
    match rx.recv_timeout(deadline) {
        Ok(r) => r,
        Err(mpsc::RecvTimeoutError::Timeout) => {
            log::warn!(
                target: "agent_shield::guard_policy_runtime",
                "LLM detector callback exceeded {} ms — failing through on_error",
                timeout_ms
            );
            Err(format!("LLM call timed out after {} ms", timeout_ms))
        }
        Err(mpsc::RecvTimeoutError::Disconnected) => {
            log::error!(
                target: "agent_shield::guard_policy_runtime",
                "LLM detector worker thread disconnected before responding (host callback panicked) — failing closed"
            );
            Err("LLM worker thread panicked".to_string())
        }
    }
}

/// Invoke the host [`ClassifierCaller`] on a worker thread and wait
/// at most `timeout_ms` for the response. Same lifecycle as
/// [`call_llm_with_timeout`].
///
/// On timeout this returns an `Err("classifier call timed out after N ms")`
/// which the caller folds through [`ClassifierError::categorize`] →
/// [`ClassifierError::NetworkError`] (the categorizer recognizes
/// `"timed out"`/`"timeout"`) and on into a fail-closed
/// [`DetectionVerdict::fail`] +.
fn call_classifier_with_timeout(
    caller: Arc<dyn ClassifierCaller>,
    configurations: Option<&[ShieldConfiguration]>,
    configuration_id: &str,
    subject: String,
) -> Result<ClassifierVerdict, String> {
    let timeout_ms = resolve_detector_timeout_ms(
        configurations,
        Some(configuration_id),
        DETECTOR_CLASSIFIER_DEFAULT_TIMEOUT_MS,
    );
    let deadline = Duration::from_millis(u64::from(timeout_ms));
    let (tx, rx) = mpsc::channel::<Result<ClassifierVerdict, String>>();
    let caller_for_thread = Arc::clone(&caller);
    let configuration_id_owned = configuration_id.to_owned();
    thread::spawn(move || {
        let r = caller_for_thread.classify(&configuration_id_owned, &subject);
        let _ = tx.send(r);
    });
    match rx.recv_timeout(deadline) {
        Ok(r) => r,
        Err(mpsc::RecvTimeoutError::Timeout) => {
            log::warn!(
                target: "agent_shield::guard_policy_runtime",
                "classifier detector callback exceeded {} ms — failing through on_error",
                timeout_ms
            );
            Err(format!("classifier call timed out after {} ms", timeout_ms))
        }
        Err(mpsc::RecvTimeoutError::Disconnected) => {
            log::error!(
                target: "agent_shield::guard_policy_runtime",
                "classifier detector worker thread disconnected before responding (host callback panicked) — failing closed"
            );
            Err("classifier worker thread panicked".to_string())
        }
    }
}

#[allow(clippy::too_many_arguments)]
fn detect_llm(
    llm: &LlmDetection,
    subject: &str,
    reason: &str,
    effective_action: crate::guard_policy::Action,
    policy_name: &str,
    evaluate_when_index: usize,
    deps: &DetectionDeps<'_>,
) -> DetectionVerdict {
    let Some(caller) = deps.llm_caller.as_ref() else {
        // No host caller registered → fail closed (default).
        return DetectionVerdict::fail(format!("{} (no LLM caller registered)", reason));
    };
    // Build the rendered prompt: substitute the canonical and extra
    // template variables, then append the subject as plain context.
    let mut rendered = deps.render_prompt(&llm.prompt);
    if !rendered.contains("{subject}") && !subject.is_empty() {
        rendered.push_str("\n\n");
        rendered.push_str(subject);
    } else {
        rendered = rendered.replace("{subject}", subject);
    }

    // v8 perf-logging PR6: time the host call and emit `LlmCalled`
    // with AC10-Corr correlation attributes (policy_name + stage +
    // evaluate_when_index) so adopters at PerfTelemetry::External can
    // attribute LLM cost to the triggering policy without a parent
    // detection event.
    let perf_on = deps.perf_telemetry.emit_llm_events()
        && deps.clock.is_some()
        && deps.observability.is_some();
    let t0 = if perf_on {
        deps.clock.map(|c| c.now())
    } else {
        None
    };
    let result = call_llm_with_timeout(
        Arc::clone(caller),
        deps.configurations,
        llm.configuration.as_deref(),
        rendered,
    );
    if let (Some(start), Some(clock), Some(obs)) = (t0, deps.clock, deps.observability) {
        let elapsed_ms = clock.now().duration_since(start).as_millis() as u64;
        let (decision_str, confidence): (Option<&str>, Option<f64>) = match &result {
            Ok(resp) => {
                let dec = if matches!(effective_action, crate::guard_policy::Action::Redact) {
                    // Redact mode ignores decision; the spans drive the verdict.
                    if resp.spans.is_empty() {
                        "allow"
                    } else {
                        "block"
                    }
                } else {
                    match resp.folded_decision() {
                        LlmDecision::Allow => "allow",
                        LlmDecision::Block => "block",
                    }
                };
                (Some(dec), resp.confidence)
            }
            // transport / parse failure folds to block.
            Err(_) => (Some("block"), None),
        };
        crate::observability::log_llm_called(
            obs,
            deps.session_id,
            deps.correlation_id,
            deps.stage,
            policy_name,
            evaluate_when_index,
            llm.configuration.as_deref(),
            elapsed_ms,
            decision_str,
            confidence,
        );
    }

    match result {
        Ok(resp) => {
            // for `action: redact` the LLM's `decision` is
            // IGNORED and the returned `spans` drive the rewrite. Empty
            // spans are a no-op (Pass); non-empty spans are a redaction
            // failure regardless of decision.
            if matches!(effective_action, crate::guard_policy::Action::Redact) {
                if resp.spans.is_empty() {
                    return DetectionVerdict::Pass;
                }
                let r = resp.reason.clone().unwrap_or_else(|| reason.to_string());
                return DetectionVerdict::fail_spans(r, resp.spans);
            }
            match resp.folded_decision() {
                LlmDecision::Allow => DetectionVerdict::Pass,
                LlmDecision::Block => {
                    let r = resp.reason.clone().unwrap_or_else(|| reason.to_string());
                    DetectionVerdict::fail_spans(r, resp.spans)
                }
            }
        }
        Err(_) => DetectionVerdict::fail(format!("{} (LLM call failed)", reason)),
    }
}

fn detect_classifier(
    c: &ClassifierDetection,
    subject: &str,
    reason: &str,
    policy_name: &str,
    evaluate_when_index: usize,
    deps: &DetectionDeps<'_>,
) -> DetectionVerdict {
    let Some(caller) = deps.classifier_caller.as_ref() else {
        // same rationale as the Err branch below — the YAML
        // `reason:` claims a detection occurred, which is wrong when no
        // classifier even ran. Emit a differentiated wiring message.
        return DetectionVerdict::fail(
            ClassifierError::NotConfigured {
                detail: format!(
                    "no `ClassifierCaller` registered with the runtime; classifier `{}` cannot evaluate",
                    c.configuration
                ),
            }
            .block_message(&c.configuration),
        );
    };

    // v8 perf-logging PR6: same instrumentation shape as detect_llm.
    let perf_on = deps.perf_telemetry.emit_classifier_events()
        && deps.clock.is_some()
        && deps.observability.is_some();
    let t0 = if perf_on {
        deps.clock.map(|c| c.now())
    } else {
        None
    };
    let result = call_classifier_with_timeout(
        Arc::clone(caller),
        deps.configurations,
        &c.configuration,
        subject.to_string(),
    );
    if let (Some(start), Some(clock), Some(obs)) = (t0, deps.clock, deps.observability) {
        let elapsed_ms = clock.now().duration_since(start).as_millis() as u64;
        let (score, threshold, flagged, label) = match &result {
            Ok(v) => (
                Some(v.score),
                Some(v.threshold),
                Some(v.is_failure()),
                v.label.as_deref(),
            ),
            // Transport failure: fail-closed with a synthetic flagged=true
            // verdict (mirrors the .NET ClassifierVerdict fallback).
            Err(_) => (None, None, Some(true), None),
        };
        crate::observability::log_classifier_called(
            obs,
            deps.session_id,
            deps.correlation_id,
            deps.stage,
            policy_name,
            evaluate_when_index,
            &c.configuration,
            elapsed_ms,
            score,
            threshold,
            flagged,
            label,
        );
    }

    match result {
        Ok(verdict) => {
            if verdict.is_failure() {
                let r = verdict.reason.clone().unwrap_or_else(|| reason.to_string());
                DetectionVerdict::fail_spans(r, verdict.spans)
            } else {
                DetectionVerdict::Pass
            }
        }
        // do NOT splice the author-supplied YAML `reason` into the
        // call-failed message. That reason almost always claims a real
        // detection happened ("Azure AI Content Safety detected an input
        // attack..."), which is the opposite of the truth when the
        // classifier never produced a verdict. Categorize the raw provider
        // string and surface a differentiated message so operators can
        // distinguish auth failures, network failures, missing
        // credentials, malformed responses, etc.
        Err(raw) => DetectionVerdict::fail(
            ClassifierError::categorize(&raw).block_message(&c.configuration),
        ),
    }
}

// ── Stub host wiring ────────────────────────────────────────────────

/// Convenience newtype wrapping an `Arc<dyn LlmCaller>` so the engine can
/// hold a single-typed slot without exposing trait objects in its public
/// fields.
#[derive(Clone)]
pub struct LlmCallerArc(pub Arc<dyn LlmCaller>);

#[derive(Clone)]
pub struct ClassifierCallerArc(pub Arc<dyn ClassifierCaller>);

#[cfg(test)]
mod tests {
    use super::*;
    use crate::guard_policy::EvaluateWhenEntry;

    fn entry_pat(reason: &str, p: &str) -> EvaluateWhenEntry {
        EvaluateWhenEntry {
            detection: DetectionKind::Pattern(p.to_string()),
            reason: reason.into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
        }
    }

    fn entry_pats(reason: &str, p: Vec<&str>) -> EvaluateWhenEntry {
        EvaluateWhenEntry {
            detection: DetectionKind::Patterns(p.iter().map(|s| s.to_string()).collect()),
            reason: reason.into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
        }
    }

    fn entry_expr(reason: &str, e: &str) -> EvaluateWhenEntry {
        EvaluateWhenEntry {
            detection: DetectionKind::Expression(e.to_string()),
            reason: reason.into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
        }
    }

    fn deps_for<'a>(attrs: &'a HashMap<String, Value>, cache: &'a RegexCache) -> DetectionDeps<'a> {
        DetectionDeps {
            regex_cache: cache,
            llm_caller: None,
            classifier_caller: None,
            configurations: None,
            objective: "",
            forbidden: &[],
            user_input: "",
            extra_template_vars: HashMap::new(),
            attrs,
            status_lookup: None,
            event_fired: None,
            predicates: None,
            resolver_hook: None,
            append_runtime_context: false,
            // v8 PR6: perf-instrumentation context. Defaults disable
            // every new emission so legacy unit tests stay byte-stable.
            clock: None,
            observability: None,
            perf_telemetry: crate::perf_telemetry::PerfTelemetry::Off,
            stage: crate::observability::Stage::Input,
            session_id: "",
            correlation_id: "",
        }
    }

    #[test]
    fn pattern_match_returns_fail_with_spans() {
        let e = entry_pat("ssn detected", r"\b\d{3}-\d{2}-\d{4}\b");
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        let v = detect(
            &e,
            "my ssn is 123-45-6789 ok",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps,
        );
        match v {
            DetectionVerdict::Fail { reason, spans, .. } => {
                assert_eq!(reason, "ssn detected");
                assert_eq!(spans.len(), 1);
                assert_eq!(spans[0].start, 10);
                assert_eq!(spans[0].end, 21);
            }
            _ => panic!("expected fail"),
        }
    }

    #[test]
    fn pattern_no_match_returns_pass() {
        let e = entry_pat("nope", r"^never");
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        let v = detect(
            &e,
            "hello",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps,
        );
        assert!(v.is_pass());
    }

    #[test]
    fn patterns_any_match_fails() {
        let e = entry_pats("any pii", vec![r"\bSSN\b", r"\bcredit\b"]);
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        let v = detect(
            &e,
            "this is a credit card",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps,
        );
        assert!(!v.is_pass());
    }

    #[test]
    fn expression_truthy_passes() {
        let e = entry_expr("nope", "true");
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        assert!(detect(
            &e,
            "",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps
        )
        .is_pass());
    }

    #[test]
    fn expression_falsey_fails() {
        let e = entry_expr("must be true", "false");
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        assert!(!detect(
            &e,
            "",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps
        )
        .is_pass());
    }

    #[test]
    fn regex_too_long_is_fail_closed() {
        let p = "a".repeat(501);
        let e = entry_pat("nope", &p);
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        let v = detect(
            &e,
            "a",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps,
        );
        assert!(matches!(v, DetectionVerdict::Fail { .. }));
    }

    #[test]
    fn llm_no_caller_fails_closed() {
        let llm = LlmDetection {
            prompt_path: None,
            prompt: "x".into(),
            configuration: None,
        };
        let entry = EvaluateWhenEntry {
            detection: DetectionKind::Llm(llm),
            reason: "block".into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
        };
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        let v = detect(
            &entry,
            "subject",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps,
        );
        assert!(matches!(v, DetectionVerdict::Fail { .. }));
    }

    struct StubLlm {
        decision: LlmDecision,
        spans: Vec<Span>,
    }
    impl LlmCaller for StubLlm {
        fn call(&self, _: Option<&str>, _: &str) -> Result<LlmResponse, String> {
            Ok(LlmResponse {
                decision: Some(self.decision),
                confidence: None,
                reason: None,
                categories: vec![],
                spans: self.spans.clone(),
                bool_flags: HashMap::new(),
            })
        }
    }

    #[test]
    fn llm_block_decision_fails() {
        let stub = StubLlm {
            decision: LlmDecision::Block,
            spans: vec![],
        };
        let llm = LlmDetection {
            prompt_path: None,
            prompt: "x".into(),
            configuration: None,
        };
        let entry = EvaluateWhenEntry {
            detection: DetectionKind::Llm(llm),
            reason: "block".into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
        };
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let mut deps = deps_for(&attrs, &cache);
        deps.llm_caller = Some(Arc::new(stub));
        let v = detect(
            &entry,
            "subject",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps,
        );
        assert!(matches!(v, DetectionVerdict::Fail { .. }));
    }

    #[test]
    fn llm_allow_decision_passes() {
        let stub = StubLlm {
            decision: LlmDecision::Allow,
            spans: vec![],
        };
        let llm = LlmDetection {
            prompt_path: None,
            prompt: "x".into(),
            configuration: None,
        };
        let entry = EvaluateWhenEntry {
            detection: DetectionKind::Llm(llm),
            reason: "block".into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
        };
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let mut deps = deps_for(&attrs, &cache);
        deps.llm_caller = Some(Arc::new(stub));
        let v = detect(
            &entry,
            "subject",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps,
        );
        assert!(v.is_pass());
    }

    struct StubClassifier {
        score: f64,
        threshold: f64,
        flagged: bool,
    }
    impl ClassifierCaller for StubClassifier {
        fn classify(&self, _: &str, _: &str) -> Result<ClassifierVerdict, String> {
            Ok(ClassifierVerdict {
                score: self.score,
                threshold: self.threshold,
                flagged: self.flagged,
                label: None,
                reason: None,
                spans: vec![],
            })
        }
    }

    #[test]
    fn classifier_score_above_threshold_fails() {
        let stub = StubClassifier {
            score: 0.8,
            threshold: 0.5,
            flagged: false,
        };
        let entry = EvaluateWhenEntry {
            detection: DetectionKind::Classifier(ClassifierDetection {
                configuration: "cls".into(),
            }),
            reason: "moderation".into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
        };
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let mut deps = deps_for(&attrs, &cache);
        deps.classifier_caller = Some(Arc::new(stub));
        let v = detect(
            &entry,
            "subject",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps,
        );
        assert!(matches!(v, DetectionVerdict::Fail { .. }));
    }

    #[test]
    fn classifier_below_threshold_passes() {
        let stub = StubClassifier {
            score: 0.2,
            threshold: 0.5,
            flagged: false,
        };
        let entry = EvaluateWhenEntry {
            detection: DetectionKind::Classifier(ClassifierDetection {
                configuration: "cls".into(),
            }),
            reason: "moderation".into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
        };
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let mut deps = deps_for(&attrs, &cache);
        deps.classifier_caller = Some(Arc::new(stub));
        let v = detect(
            &entry,
            "subject",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps,
        );
        assert!(v.is_pass());
    }

    #[test]
    fn classifier_no_caller_fails_closed() {
        let entry = EvaluateWhenEntry {
            detection: DetectionKind::Classifier(ClassifierDetection {
                configuration: "cls".into(),
            }),
            reason: "moderation".into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
        };
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        let v = detect(
            &entry,
            "subject",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps,
        );
        // the no-caller path now produces a structured wiring
        // message rather than splicing the YAML detection reason.
        match v {
            DetectionVerdict::Fail { reason, .. } => {
                assert!(
                    reason.contains("not configured"),
                    "expected wiring-error message, got: {reason}"
                );
                assert!(
                    !reason.contains("moderation"),
                    "YAML detection reason must not leak into call-failed messages: {reason}"
                );
            }
            _ => panic!("expected fail"),
        }
    }

    // ── Differentiated classifier failure messages ────────
    //
    // The bug: every classifier failure mode produced the same
    // verdict reason of the form
    //   "<author-supplied YAML reason> (classifier call failed)"
    // which spliced an active-voice detection claim ("AACS detected
    // an input attack...") onto every wiring failure. Operators
    // could not distinguish an auth failure from a denial, a network
    // outage, or an unset env var.
    //
    // These tests pin the new behaviour: each failure mode produces a
    // honest, differentiated reason that DOES NOT claim a detection
    // happened.

    struct AuthFailedClassifier;
    impl ClassifierCaller for AuthFailedClassifier {
        fn classify(&self, _: &str, _: &str) -> Result<ClassifierVerdict, String> {
            Err("aacs HTTP 401: { \"error\": { \"code\": \"401\", \"message\": \"Access denied due to invalid subscription key\" } }".to_string())
        }
    }

    struct NetworkFailedClassifier;
    impl ClassifierCaller for NetworkFailedClassifier {
        fn classify(&self, _: &str, _: &str) -> Result<ClassifierVerdict, String> {
            Err("classifier HTTP send: error sending request: dns error: failed to lookup address information: nodename nor servname provided".to_string())
        }
    }

    struct MissingCredsClassifier;
    impl ClassifierCaller for MissingCredsClassifier {
        fn classify(&self, _: &str, _: &str) -> Result<ClassifierVerdict, String> {
            Err("aacs: api_key not resolved".to_string())
        }
    }

    struct RateLimitedClassifier;
    impl ClassifierCaller for RateLimitedClassifier {
        fn classify(&self, _: &str, _: &str) -> Result<ClassifierVerdict, String> {
            Err("aacs HTTP 429: rate limit exceeded".to_string())
        }
    }

    struct ServerErrorClassifier;
    impl ClassifierCaller for ServerErrorClassifier {
        fn classify(&self, _: &str, _: &str) -> Result<ClassifierVerdict, String> {
            Err("aacs HTTP 502: bad gateway".to_string())
        }
    }

    struct BadResponseClassifier;
    impl ClassifierCaller for BadResponseClassifier {
        fn classify(&self, _: &str, _: &str) -> Result<ClassifierVerdict, String> {
            Err("aacs response missing `categoriesAnalysis`".to_string())
        }
    }

    struct GenuineDenialClassifier;
    impl ClassifierCaller for GenuineDenialClassifier {
        fn classify(&self, _: &str, _: &str) -> Result<ClassifierVerdict, String> {
            // Real positive detection — score above threshold.
            Ok(ClassifierVerdict {
                score: 0.95,
                threshold: 0.5,
                flagged: true,
                label: Some("Hate".into()),
                reason: None,
                spans: vec![],
            })
        }
    }

    fn run_classifier_with(caller: Arc<dyn ClassifierCaller>, yaml_reason: &str) -> String {
        let entry = EvaluateWhenEntry {
            detection: DetectionKind::Classifier(ClassifierDetection {
                configuration: "aacs_input".into(),
            }),
            reason: yaml_reason.into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
        };
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let mut deps = deps_for(&attrs, &cache);
        deps.classifier_caller = Some(caller);
        match detect(
            &entry,
            "subject",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps,
        ) {
            DetectionVerdict::Fail { reason, .. } => reason,
            DetectionVerdict::Pass => panic!("expected fail"),
        }
    }

    const YAML_REASON: &str =
        "Azure AI Content Safety detected an input-attack at or above the configured severity threshold.";

    #[test]
    fn auth_failure_emits_auth_differentiated_message() {
        let r = run_classifier_with(Arc::new(AuthFailedClassifier), YAML_REASON);
        assert!(
            r.contains("authentication rejected"),
            "expected auth-rejection text, got: {r}"
        );
        assert!(
            r.contains("aacs_input"),
            "expected classifier id `aacs_input`, got: {r}"
        );
        // The misleading YAML detection reason must NOT be present —
        // that's the entire bug.
        assert!(
            !r.contains("input-attack"),
            "YAML detection reason must not leak into auth-failure message: {r}"
        );
    }

    #[test]
    fn network_failure_emits_network_differentiated_message() {
        let r = run_classifier_with(Arc::new(NetworkFailedClassifier), YAML_REASON);
        assert!(
            r.contains("network/transport error"),
            "expected network-error text, got: {r}"
        );
        assert!(!r.contains("input-attack"), "YAML reason leaked: {r}");
    }

    #[test]
    fn missing_credentials_emits_credentials_message() {
        let r = run_classifier_with(Arc::new(MissingCredsClassifier), YAML_REASON);
        assert!(
            r.contains("credentials not resolved"),
            "expected missing-credentials text, got: {r}"
        );
        assert!(
            r.contains("api_key_env"),
            "expected mention of api_key_env knob, got: {r}"
        );
        assert!(!r.contains("input-attack"), "YAML reason leaked: {r}");
    }

    #[test]
    fn rate_limited_emits_rate_limited_message() {
        let r = run_classifier_with(Arc::new(RateLimitedClassifier), YAML_REASON);
        assert!(
            r.contains("rate-limited"),
            "expected rate-limit text, got: {r}"
        );
        assert!(
            r.contains("HTTP 429"),
            "expected HTTP 429 context, got: {r}"
        );
        assert!(!r.contains("input-attack"), "YAML reason leaked: {r}");
    }

    #[test]
    fn server_error_emits_provider_error_message() {
        let r = run_classifier_with(Arc::new(ServerErrorClassifier), YAML_REASON);
        assert!(
            r.contains("server error"),
            "expected provider-error text, got: {r}"
        );
        assert!(!r.contains("input-attack"), "YAML reason leaked: {r}");
    }

    #[test]
    fn bad_response_emits_unparseable_message() {
        let r = run_classifier_with(Arc::new(BadResponseClassifier), YAML_REASON);
        assert!(
            r.contains("unparseable"),
            "expected bad-response text, got: {r}"
        );
        assert!(!r.contains("input-attack"), "YAML reason leaked: {r}");
    }

    #[test]
    fn genuine_denial_still_uses_yaml_reason() {
        // When the classifier ACTUALLY produces a positive detection,
        // the YAML `reason:` is the right verdict text — the customer
        // configured it precisely for this case. fix must
        // not regress this path.
        let r = run_classifier_with(Arc::new(GenuineDenialClassifier), YAML_REASON);
        assert_eq!(r, YAML_REASON);
    }

    #[test]
    fn genuine_denial_and_failures_now_have_distinct_messages() {
        // The original bug: all three of these returned the same
        // string. They must now diverge.
        let auth = run_classifier_with(Arc::new(AuthFailedClassifier), YAML_REASON);
        let net = run_classifier_with(Arc::new(NetworkFailedClassifier), YAML_REASON);
        let creds = run_classifier_with(Arc::new(MissingCredsClassifier), YAML_REASON);
        let denial = run_classifier_with(Arc::new(GenuineDenialClassifier), YAML_REASON);
        assert_ne!(auth, net, "auth and network must differ");
        assert_ne!(auth, creds, "auth and creds must differ");
        assert_ne!(net, creds, "network and creds must differ");
        assert_ne!(
            auth, denial,
            "auth-failure must not look like a real denial"
        );
        assert_ne!(
            net, denial,
            "network-failure must not look like a real denial"
        );
        assert_ne!(
            creds, denial,
            "missing-credentials must not look like a real denial"
        );
    }

    // ── ClassifierError categorizer unit tests ────────────

    #[test]
    fn categorize_aacs_auth_401() {
        let e = ClassifierError::categorize("aacs HTTP 401: invalid key");
        assert!(matches!(e, ClassifierError::AuthFailed { .. }));
    }

    #[test]
    fn categorize_aacs_auth_403() {
        let e = ClassifierError::categorize("aacs HTTP 403: forbidden");
        assert!(matches!(e, ClassifierError::AuthFailed { .. }));
    }

    #[test]
    fn categorize_aacs_429_rate_limited() {
        let e = ClassifierError::categorize("aacs HTTP 429: throttled");
        assert!(matches!(e, ClassifierError::RateLimited { .. }));
    }

    #[test]
    fn categorize_aacs_5xx_server_error() {
        let e = ClassifierError::categorize("aacs HTTP 503: unavailable");
        assert!(matches!(e, ClassifierError::ProviderServerError { .. }));
    }

    #[test]
    fn categorize_aacs_other_4xx() {
        let e = ClassifierError::categorize("aacs HTTP 418: I'm a teapot");
        assert!(matches!(e, ClassifierError::HttpStatus { .. }));
    }

    #[test]
    fn categorize_missing_api_key() {
        let e = ClassifierError::categorize("aacs: api_key not resolved");
        assert!(matches!(e, ClassifierError::MissingCredentials { .. }));
    }

    #[test]
    fn categorize_endpoint_required() {
        let e = ClassifierError::categorize("aacs: `endpoint` is required (Azure resource URL)");
        assert!(matches!(e, ClassifierError::EndpointInvalid { .. }));
    }

    #[test]
    fn categorize_network_transport_failure() {
        let e = ClassifierError::categorize(
            "classifier HTTP send: error sending request: connection refused",
        );
        assert!(matches!(e, ClassifierError::NetworkError { .. }));
    }

    #[test]
    fn categorize_network_timeout() {
        let e = ClassifierError::categorize("classifier HTTP send: operation timed out");
        assert!(matches!(e, ClassifierError::NetworkError { .. }));
    }

    #[test]
    fn categorize_bad_json_response() {
        let e = ClassifierError::categorize("aacs JSON parse: expected value at line 1 column 1");
        assert!(matches!(e, ClassifierError::BadResponse { .. }));
    }

    #[test]
    fn categorize_missing_response_field() {
        let e = ClassifierError::categorize("aacs response missing `categoriesAnalysis`");
        assert!(matches!(e, ClassifierError::BadResponse { .. }));
    }

    #[test]
    fn categorize_not_configured() {
        let e = ClassifierError::categorize(
            "no resolved classifier configuration for id `aacs_input` (unsupported provider, missing api_key, or feature disabled)",
        );
        assert!(matches!(e, ClassifierError::NotConfigured { .. }));
    }

    #[test]
    fn categorize_unknown_falls_through_to_other() {
        let e = ClassifierError::categorize("something totally unrecognised");
        assert!(matches!(e, ClassifierError::Other { .. }));
    }

    #[test]
    fn block_message_includes_configuration_id() {
        let msg = ClassifierError::AuthFailed {
            detail: "HTTP 401".into(),
        }
        .block_message("my_classifier");
        assert!(msg.contains("my_classifier"));
        assert!(msg.contains("authentication rejected"));
    }

    #[test]
    fn block_message_includes_raw_detail() {
        let msg = ClassifierError::NetworkError {
            detail: "dns lookup failed: nodename nor servname provided".into(),
        }
        .block_message("c");
        assert!(msg.contains("dns lookup failed"));
    }

    #[test]
    fn extract_http_status_from_typical_provider_string() {
        assert_eq!(extract_http_status("aacs HTTP 401: invalid"), Some(401));
        assert_eq!(extract_http_status("foo HTTP 429: throttled"), Some(429));
        assert_eq!(extract_http_status("HTTP 500"), Some(500));
        assert_eq!(extract_http_status("no http here"), None);
        assert_eq!(extract_http_status("HTTP "), None);
    }

    #[test]
    fn template_substitution_works() {
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let mut deps = deps_for(&attrs, &cache);
        deps.user_input = "hello world";
        deps.objective = "be helpful";
        let rendered = deps.render_prompt("input={user_input} obj={objective}");
        assert_eq!(rendered, "input=hello world obj=be helpful");
    }

    #[test]
    fn template_undefined_becomes_empty() {
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        let rendered = deps.render_prompt("v={does_not_exist}");
        // Note: undefined tokens are *not* substituted by our simple
        // string replacer; they pass through. they should
        // become empty. Hosts wanting strict spec semantics should do
        // their own templating; this helper is best-effort.
        assert!(rendered.contains("{does_not_exist}") || rendered == "v=");
    }

    #[test]
    fn llm_bool_flag_truthy_blocks() {
        let mut flags = HashMap::new();
        flags.insert("contains_pii".to_string(), true);
        let resp = LlmResponse {
            decision: Some(LlmDecision::Allow), // overridden by truthy bool flag
            bool_flags: flags,
            ..Default::default()
        };
        assert_eq!(resp.folded_decision(), LlmDecision::Block);
    }

    #[test]
    fn llm_missing_decision_blocks() {
        let resp = LlmResponse::default();
        assert_eq!(resp.folded_decision(), LlmDecision::Block);
    }

    // ── v8 PR6 perf-instrumentation tests ─────────────────────────
    //
    // Cover the AC10-Corr correlation contract + the PerfTelemetry
    // gating table for LLM / classifier detection. The stage runner
    // gating (`StageEvaluated`) lives in stage_timing::tests; this
    // module owns the LLM / classifier side.

    use crate::clock::mock::MockClock;
    use crate::event_bus::EventBus;
    use crate::observability::attributes::{
        KEY_CLASSIFIER_CONFIGURATION_ID, KEY_CLASSIFIER_FLAGGED, KEY_CLASSIFIER_LABEL,
        KEY_CLASSIFIER_SCORE, KEY_CLASSIFIER_THRESHOLD, KEY_DURATION_MS, KEY_EVALUATE_WHEN_INDEX,
        KEY_EVENT_TYPE, KEY_GUARD_POLICY, KEY_LLM_CONFIGURATION_ID, KEY_LLM_DECISION, KEY_STAGE,
    };
    use crate::observability::test_support::CaptureProvider;
    use crate::observability::{EventType, ObservabilityDispatcher, Stage};
    use crate::perf_telemetry::PerfTelemetry;
    use std::sync::Arc;
    use std::time::Duration;

    /// Always-block stub LLM that does not flag any bool fields. The
    /// host's `LlmResponse::folded_decision` returns `Block`.
    struct AlwaysBlockLlm;
    impl LlmCaller for AlwaysBlockLlm {
        fn call(&self, _cfg: Option<&str>, _prompt: &str) -> Result<LlmResponse, String> {
            Ok(LlmResponse {
                decision: Some(LlmDecision::Block),
                confidence: Some(0.92),
                reason: Some("policy violation".into()),
                ..Default::default()
            })
        }
    }

    /// Always-flagged stub classifier (score > threshold).
    struct AlwaysFlaggedClassifier;
    impl ClassifierCaller for AlwaysFlaggedClassifier {
        fn classify(&self, _cfg: &str, _subject: &str) -> Result<ClassifierVerdict, String> {
            Ok(ClassifierVerdict {
                score: 0.93,
                threshold: 0.5,
                flagged: true,
                label: Some("pii".into()),
                reason: Some("ssn detected".into()),
                ..Default::default()
            })
        }
    }

    /// Bundle the shared scaffolding so each test stays short.
    struct PerfFixture {
        dispatcher: Arc<ObservabilityDispatcher>,
        provider: Arc<CaptureProvider>,
        cache: RegexCache,
        clock: MockClock,
    }

    fn perf_fixture() -> PerfFixture {
        let bus = EventBus::new();
        let dispatcher = ObservabilityDispatcher::new(bus);
        let provider = CaptureProvider::new();
        dispatcher.register_provider(provider.clone());
        PerfFixture {
            dispatcher,
            provider,
            cache: RegexCache::new(),
            clock: MockClock::new(),
        }
    }

    fn perf_deps<'a>(
        fx: &'a PerfFixture,
        attrs: &'a HashMap<String, Value>,
        perf_telemetry: PerfTelemetry,
        llm: Option<Arc<dyn LlmCaller>>,
        classifier: Option<Arc<dyn ClassifierCaller>>,
    ) -> DetectionDeps<'a> {
        DetectionDeps {
            regex_cache: &fx.cache,
            llm_caller: llm,
            classifier_caller: classifier,
            configurations: None,
            objective: "be safe",
            forbidden: &[],
            user_input: "",
            extra_template_vars: HashMap::new(),
            attrs,
            status_lookup: None,
            event_fired: None,
            predicates: None,
            resolver_hook: None,
            append_runtime_context: false,
            clock: Some(&fx.clock),
            observability: Some(fx.dispatcher.as_ref()),
            perf_telemetry,
            stage: Stage::Input,
            session_id: "sess-perf",
            correlation_id: "corr-perf",
        }
    }

    fn llm_entry() -> EvaluateWhenEntry {
        EvaluateWhenEntry {
            detection: DetectionKind::Llm(LlmDetection {
                prompt_path: None,
                prompt: "decide".into(),
                configuration: Some("fast-haiku".into()),
            }),
            reason: "policy-violation".into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
        }
    }

    fn classifier_entry() -> EvaluateWhenEntry {
        EvaluateWhenEntry {
            detection: DetectionKind::Classifier(ClassifierDetection {
                configuration: "lakera-pii".into(),
            }),
            reason: "classifier-fail".into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
        }
    }

    fn count_events_of(
        dispatcher: &ObservabilityDispatcher,
        provider: &CaptureProvider,
        kind: &EventType,
    ) -> usize {
        // Observability is async; flush so the worker drains before
        // we read the captured events.
        dispatcher.flush();
        provider
            .events
            .lock()
            .unwrap()
            .iter()
            .filter(|e| &e.event_type == kind)
            .count()
    }

    #[test]
    fn llm_emits_at_external() {
        let fx = perf_fixture();
        let attrs = HashMap::new();
        let llm: Arc<dyn LlmCaller> = Arc::new(AlwaysBlockLlm);
        let deps = perf_deps(
            &fx,
            &attrs,
            PerfTelemetry::External,
            Some(Arc::clone(&llm)),
            None,
        );
        fx.clock.advance(Duration::from_millis(0)); // baseline so the second tick produces > 0
        let _ = detect(
            &llm_entry(),
            "subject",
            crate::guard_policy::Action::Block,
            "send_requires_authz",
            3,
            &deps,
        );
        assert_eq!(
            count_events_of(&fx.dispatcher, &fx.provider, &EventType::LlmCalled),
            1
        );
        // Gating: External must NOT emit stage/policy events.
        assert_eq!(
            count_events_of(&fx.dispatcher, &fx.provider, &EventType::StageEvaluated),
            0
        );
        assert_eq!(
            count_events_of(&fx.dispatcher, &fx.provider, &EventType::PolicyEvaluated),
            0
        );
    }

    #[test]
    fn llm_emits_at_full() {
        let fx = perf_fixture();
        let attrs = HashMap::new();
        let llm: Arc<dyn LlmCaller> = Arc::new(AlwaysBlockLlm);
        let deps = perf_deps(
            &fx,
            &attrs,
            PerfTelemetry::Full,
            Some(Arc::clone(&llm)),
            None,
        );
        let _ = detect(
            &llm_entry(),
            "subject",
            crate::guard_policy::Action::Block,
            "p",
            0,
            &deps,
        );
        assert_eq!(
            count_events_of(&fx.dispatcher, &fx.provider, &EventType::LlmCalled),
            1
        );
    }

    #[test]
    fn llm_silent_at_off() {
        let fx = perf_fixture();
        let attrs = HashMap::new();
        let llm: Arc<dyn LlmCaller> = Arc::new(AlwaysBlockLlm);
        let deps = perf_deps(
            &fx,
            &attrs,
            PerfTelemetry::Off,
            Some(Arc::clone(&llm)),
            None,
        );
        let _ = detect(
            &llm_entry(),
            "subject",
            crate::guard_policy::Action::Block,
            "p",
            0,
            &deps,
        );
        assert_eq!(
            count_events_of(&fx.dispatcher, &fx.provider, &EventType::LlmCalled),
            0
        );
    }

    #[test]
    fn llm_carries_correlation_attrs() {
        // AC10-Corr — every LlmCalled event MUST carry
        // KEY_GUARD_POLICY + KEY_STAGE + KEY_GUARD_POLICY_EVALUATE_WHEN_INDEX
        // so adopters at PerfTelemetry::External can attribute LLM
        // cost back to the triggering policy without a parent
        // StageEvaluated / PolicyEvaluated event.
        let fx = perf_fixture();
        let attrs = HashMap::new();
        let llm: Arc<dyn LlmCaller> = Arc::new(AlwaysBlockLlm);
        let deps = perf_deps(
            &fx,
            &attrs,
            PerfTelemetry::External,
            Some(Arc::clone(&llm)),
            None,
        );
        fx.clock.advance(Duration::from_millis(0));
        let _ = detect(
            &llm_entry(),
            "subject",
            crate::guard_policy::Action::Block,
            "wire_transfer_safety",
            // Zero is a legitimate index — the first evaluate_when[]
            // entry. The assertion below MUST accept it.
            0,
            &deps,
        );
        fx.dispatcher.flush();
        let events = fx.provider.events.lock().unwrap();
        let ev = events
            .iter()
            .find(|e| matches!(e.event_type, EventType::LlmCalled))
            .expect("LlmCalled must emit at External");
        let policy = ev
            .attributes
            .get(KEY_GUARD_POLICY)
            .and_then(|v| v.as_str())
            .expect("KEY_GUARD_POLICY must be a string");
        assert!(!policy.is_empty(), "policy name must be non-empty");
        assert_eq!(policy, "wire_transfer_safety");
        let stage_v = ev
            .attributes
            .get(KEY_STAGE)
            .and_then(|v| v.as_str())
            .expect("KEY_STAGE must be a string");
        assert!(!stage_v.is_empty(), "stage must be non-empty");
        let idx_v = ev
            .attributes
            .get(KEY_EVALUATE_WHEN_INDEX)
            .expect("KEY_GUARD_POLICY_EVALUATE_WHEN_INDEX must be present");
        assert!(
            idx_v.as_u64().is_some(),
            "evaluate_when_index must be a u64 (zero IS valid)"
        );
        // LLM-specific attrs follow on for the audit trail.
        assert_eq!(
            ev.attributes
                .get(KEY_LLM_CONFIGURATION_ID)
                .and_then(|v| v.as_str()),
            Some("fast-haiku")
        );
        assert_eq!(
            ev.attributes.get(KEY_LLM_DECISION).and_then(|v| v.as_str()),
            Some("block"),
            "AlwaysBlockLlm folded_decision is Block"
        );
        assert_eq!(
            ev.attributes.get(KEY_EVENT_TYPE).and_then(|v| v.as_str()),
            Some("llm_called")
        );
        // KEY_DURATION_MS is present (MockClock did not advance between
        // start and stop, so the recorded value is 0 — still a valid
        // duration; the test asserts the FIELD exists, not the value).
        assert!(ev.attributes.contains_key(KEY_DURATION_MS));
    }

    #[test]
    fn classifier_emits_at_external() {
        let fx = perf_fixture();
        let attrs = HashMap::new();
        let cl: Arc<dyn ClassifierCaller> = Arc::new(AlwaysFlaggedClassifier);
        let deps = perf_deps(
            &fx,
            &attrs,
            PerfTelemetry::External,
            None,
            Some(Arc::clone(&cl)),
        );
        let _ = detect(
            &classifier_entry(),
            "subject",
            crate::guard_policy::Action::Block,
            "pii_guard",
            1,
            &deps,
        );
        assert_eq!(
            count_events_of(&fx.dispatcher, &fx.provider, &EventType::ClassifierCalled),
            1
        );
        assert_eq!(
            count_events_of(&fx.dispatcher, &fx.provider, &EventType::StageEvaluated),
            0
        );
    }

    #[test]
    fn classifier_emits_at_full() {
        let fx = perf_fixture();
        let attrs = HashMap::new();
        let cl: Arc<dyn ClassifierCaller> = Arc::new(AlwaysFlaggedClassifier);
        let deps = perf_deps(
            &fx,
            &attrs,
            PerfTelemetry::Full,
            None,
            Some(Arc::clone(&cl)),
        );
        let _ = detect(
            &classifier_entry(),
            "subject",
            crate::guard_policy::Action::Block,
            "p",
            0,
            &deps,
        );
        assert_eq!(
            count_events_of(&fx.dispatcher, &fx.provider, &EventType::ClassifierCalled),
            1
        );
    }

    #[test]
    fn classifier_silent_at_off() {
        let fx = perf_fixture();
        let attrs = HashMap::new();
        let cl: Arc<dyn ClassifierCaller> = Arc::new(AlwaysFlaggedClassifier);
        let deps = perf_deps(&fx, &attrs, PerfTelemetry::Off, None, Some(Arc::clone(&cl)));
        let _ = detect(
            &classifier_entry(),
            "subject",
            crate::guard_policy::Action::Block,
            "p",
            0,
            &deps,
        );
        assert_eq!(
            count_events_of(&fx.dispatcher, &fx.provider, &EventType::ClassifierCalled),
            0
        );
    }

    #[test]
    fn classifier_carries_correlation_attrs() {
        let fx = perf_fixture();
        let attrs = HashMap::new();
        let cl: Arc<dyn ClassifierCaller> = Arc::new(AlwaysFlaggedClassifier);
        let deps = perf_deps(
            &fx,
            &attrs,
            PerfTelemetry::External,
            None,
            Some(Arc::clone(&cl)),
        );
        let _ = detect(
            &classifier_entry(),
            "subject",
            crate::guard_policy::Action::Block,
            "pii_guard",
            0,
            &deps,
        );
        fx.dispatcher.flush();
        let events = fx.provider.events.lock().unwrap();
        let ev = events
            .iter()
            .find(|e| matches!(e.event_type, EventType::ClassifierCalled))
            .expect("ClassifierCalled must emit at External");
        assert_eq!(
            ev.attributes.get(KEY_GUARD_POLICY).and_then(|v| v.as_str()),
            Some("pii_guard")
        );
        assert_eq!(
            ev.attributes.get(KEY_STAGE).and_then(|v| v.as_str()),
            Some("input")
        );
        assert!(ev
            .attributes
            .get(KEY_EVALUATE_WHEN_INDEX)
            .and_then(|v| v.as_u64())
            .is_some());
        assert_eq!(
            ev.attributes
                .get(KEY_CLASSIFIER_CONFIGURATION_ID)
                .and_then(|v| v.as_str()),
            Some("lakera-pii")
        );
        assert_eq!(
            ev.attributes
                .get(KEY_CLASSIFIER_SCORE)
                .and_then(|v| v.as_f64()),
            Some(0.93)
        );
        assert_eq!(
            ev.attributes
                .get(KEY_CLASSIFIER_THRESHOLD)
                .and_then(|v| v.as_f64()),
            Some(0.5)
        );
        assert_eq!(
            ev.attributes
                .get(KEY_CLASSIFIER_FLAGGED)
                .and_then(|v| v.as_bool()),
            Some(true)
        );
        assert_eq!(
            ev.attributes
                .get(KEY_CLASSIFIER_LABEL)
                .and_then(|v| v.as_str()),
            Some("pii")
        );
    }

    // ── Wall-clock timeout on LLM / classifier detectors ──
    //
    // `evaluate_when[].llm` and `evaluate_when[].classifier`
    // detection paths now wrap the host caller in a worker thread
    // and wait at most `configurations[id].timeout` ms (falling back
    // to the per-kind default) before returning a fail-closed
    // verdict. These tests pin the four
    // properties the runtime requires: enforcement, late-response
    // discard, default fallback, configuration-tier resolution.

    use std::sync::atomic::{AtomicUsize, Ordering as AOrdering};
    use std::time::Instant;

    /// Stub LLM that sleeps `sleep_ms` before returning Allow. Used
    /// to construct slow host callbacks that exceed the configured
    /// timeout. Counts the number of times `call` actually returned
    /// (so a late-but-finished call can be observed via the counter
    /// even though its response is discarded).
    struct SleepyLlm {
        sleep_ms: u64,
        completed: Arc<AtomicUsize>,
    }
    impl LlmCaller for SleepyLlm {
        fn call(&self, _cfg: Option<&str>, _prompt: &str) -> Result<LlmResponse, String> {
            std::thread::sleep(Duration::from_millis(self.sleep_ms));
            self.completed.fetch_add(1, AOrdering::SeqCst);
            Ok(LlmResponse {
                decision: Some(LlmDecision::Allow),
                ..Default::default()
            })
        }
    }

    struct SleepyClassifier {
        sleep_ms: u64,
        completed: Arc<AtomicUsize>,
    }
    impl ClassifierCaller for SleepyClassifier {
        fn classify(&self, _cfg: &str, _subject: &str) -> Result<ClassifierVerdict, String> {
            std::thread::sleep(Duration::from_millis(self.sleep_ms));
            self.completed.fetch_add(1, AOrdering::SeqCst);
            Ok(ClassifierVerdict {
                score: 0.0,
                threshold: 0.5,
                flagged: false,
                ..Default::default()
            })
        }
    }

    /// Minimal `configurations[]` entry — only the fields the
    /// timeout resolver reads. `type:` is set to match the caller
    /// kind so `validate_required_fields` would accept the entry,
    /// but we never run it through the loader here.
    fn cfg_with_timeout(
        id: &str,
        ty: crate::configurations::ConfigurationType,
        timeout_ms: Option<u32>,
    ) -> ShieldConfiguration {
        ShieldConfiguration {
            id: id.into(),
            config_type: ty,
            default: None,
            provider: None,
            provider_config: None,
            endpoint: Some("https://example.invalid/v1".into()),
            timeout: timeout_ms,
            on_error: None,
            on_error_log: None,
            headers: HashMap::new(),
            transport: None,
            model: Some("stub-model".into()),
            max_tokens: None,
            api_key_env: None,
            metadata: None,
            threshold: None,
            method: None,
            category_thresholds: HashMap::new(),
            agent_id: None,
            tool: None,
        }
    }

    fn llm_entry_cfg(configuration_id: &str) -> EvaluateWhenEntry {
        EvaluateWhenEntry {
            detection: DetectionKind::Llm(LlmDetection {
                prompt_path: None,
                prompt: "decide".into(),
                configuration: Some(configuration_id.into()),
            }),
            reason: "policy-violation".into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
        }
    }

    fn classifier_entry_cfg(configuration_id: &str) -> EvaluateWhenEntry {
        EvaluateWhenEntry {
            detection: DetectionKind::Classifier(ClassifierDetection {
                configuration: configuration_id.into(),
            }),
            reason: "classifier-fail".into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
        }
    }

    #[test]
    fn llm_caller_timeout_enforced() {
        // Configuration declares `timeout: 50` (ms); host sleeps
        // 200 ms. The detector MUST return Fail within ~150 ms (not
        // the host's 200 ms latency) and the failure message MUST
        // surface the "(LLM call failed)" suffix that
        // `detect_llm`'s `Err(_)` arm appends.
        let completed = Arc::new(AtomicUsize::new(0));
        let llm: Arc<dyn LlmCaller> = Arc::new(SleepyLlm {
            sleep_ms: 200,
            completed: Arc::clone(&completed),
        });
        let configurations = vec![cfg_with_timeout(
            "slow-llm",
            crate::configurations::ConfigurationType::Llm,
            Some(50),
        )];
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let mut deps = deps_for(&attrs, &cache);
        deps.llm_caller = Some(llm);
        deps.configurations = Some(configurations.as_slice());

        let start = Instant::now();
        let v = detect(
            &llm_entry_cfg("slow-llm"),
            "subject",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps,
        );
        let elapsed = start.elapsed();
        assert!(
            elapsed < Duration::from_millis(150),
            "detector must return before host's 200 ms sleep; observed {:?}",
            elapsed
        );
        match v {
            DetectionVerdict::Fail { reason, .. } => {
                assert!(
                    reason.contains("LLM call failed"),
                    "fail reason should be the transport-failure shape, got `{}`",
                    reason
                );
            }
            other => panic!("expected Fail on timeout, got {:?}", other),
        }
    }

    #[test]
    fn classifier_caller_timeout_enforced() {
        let completed = Arc::new(AtomicUsize::new(0));
        let cls: Arc<dyn ClassifierCaller> = Arc::new(SleepyClassifier {
            sleep_ms: 200,
            completed: Arc::clone(&completed),
        });
        let configurations = vec![cfg_with_timeout(
            "slow-cls",
            crate::configurations::ConfigurationType::Classifier,
            Some(50),
        )];
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let mut deps = deps_for(&attrs, &cache);
        deps.classifier_caller = Some(cls);
        deps.configurations = Some(configurations.as_slice());

        let start = Instant::now();
        let v = detect(
            &classifier_entry_cfg("slow-cls"),
            "subject",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps,
        );
        let elapsed = start.elapsed();
        assert!(
            elapsed < Duration::from_millis(150),
            "detector must return before host's 200 ms sleep; observed {:?}",
            elapsed
        );
        match v {
            DetectionVerdict::Fail { reason, .. } => {
                // The categorizer recognizes "timed out" → NetworkError
                // → its block_message starts with the configuration id.
                assert!(
                    reason.contains("slow-cls"),
                    "classifier failure message should cite the configuration id, got `{}`",
                    reason
                );
                assert!(
                    reason.to_lowercase().contains("network")
                        || reason.to_lowercase().contains("timed out"),
                    "classifier timeout should categorize as network/timeout, got `{}`",
                    reason
                );
            }
            other => panic!("expected Fail on timeout, got {:?}", other),
        }
    }

    #[test]
    fn llm_caller_late_response_discarded() {
        // After the timeout fires the worker thread is still running.
        // Its eventual `Sender::send` is a no-op because the receiver
        // was dropped. The caller MUST surface the timeout verdict and
        // MUST NOT block waiting for the late response. We confirm by
        // observing that `detect` returns inside the deadline AND that
        // a re-query against the same deps with a separate (fast)
        // call still returns the fast caller's verdict — proving the
        // late response from the first call cannot leak through.
        let completed = Arc::new(AtomicUsize::new(0));
        let llm: Arc<dyn LlmCaller> = Arc::new(SleepyLlm {
            sleep_ms: 250,
            completed: Arc::clone(&completed),
        });
        let configurations = vec![cfg_with_timeout(
            "slow-llm",
            crate::configurations::ConfigurationType::Llm,
            Some(40),
        )];
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let mut deps = deps_for(&attrs, &cache);
        deps.llm_caller = Some(llm);
        deps.configurations = Some(configurations.as_slice());

        let v = detect(
            &llm_entry_cfg("slow-llm"),
            "subject",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps,
        );
        assert!(matches!(v, DetectionVerdict::Fail { .. }));
        // Wait long enough for the worker to actually finish — its
        // late `send` must be a no-op (the receiver is gone) but the
        // sleep itself runs to completion (cooperative cancellation).
        std::thread::sleep(Duration::from_millis(350));
        assert!(
            completed.load(AOrdering::SeqCst) >= 1,
            "worker should have finished its sleep (cooperative cancellation, send is dropped)"
        );
    }

    #[test]
    fn llm_caller_default_timeout_used_when_unset() {
        // Configuration omits `timeout:`; the per-kind default
        // (LLM_DEFAULT_TIMEOUT_MS = 30 s) applies. Verify by giving
        // a fast caller — the call must succeed end-to-end (Pass),
        // confirming the gate did not fire prematurely.
        let completed = Arc::new(AtomicUsize::new(0));
        let llm: Arc<dyn LlmCaller> = Arc::new(SleepyLlm {
            sleep_ms: 10,
            completed: Arc::clone(&completed),
        });
        let configurations = vec![cfg_with_timeout(
            "fast-llm",
            crate::configurations::ConfigurationType::Llm,
            None,
        )];
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let mut deps = deps_for(&attrs, &cache);
        deps.llm_caller = Some(llm);
        deps.configurations = Some(configurations.as_slice());

        let v = detect(
            &llm_entry_cfg("fast-llm"),
            "subject",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps,
        );
        assert!(
            v.is_pass(),
            "fast call must pass under 30 s default timeout"
        );
        assert_eq!(completed.load(AOrdering::SeqCst), 1);

        // Confirm the resolver picks the default when the entry's
        // configuration_id is unknown — this exercises the
        // not-configured fallback path.
        let t = resolve_detector_timeout_ms(
            Some(configurations.as_slice()),
            Some("unknown"),
            LLM_DEFAULT_TIMEOUT_MS,
        );
        assert_eq!(t, LLM_DEFAULT_TIMEOUT_MS);

        // And when `configurations:` is None entirely.
        let t = resolve_detector_timeout_ms(None, Some("fast-llm"), LLM_DEFAULT_TIMEOUT_MS);
        assert_eq!(t, LLM_DEFAULT_TIMEOUT_MS);
    }

    #[test]
    fn classifier_caller_configuration_timeout_used_when_set() {
        // Direct resolver check: the configuration tier wins over the
        // per-kind default whenever `timeout:` is declared. Sibling
        // entries with a different id don't bleed through.
        let configurations = vec![
            cfg_with_timeout(
                "cls-a",
                crate::configurations::ConfigurationType::Classifier,
                Some(123),
            ),
            cfg_with_timeout(
                "cls-b",
                crate::configurations::ConfigurationType::Classifier,
                Some(456),
            ),
            cfg_with_timeout(
                "cls-c-default",
                crate::configurations::ConfigurationType::Classifier,
                None,
            ),
        ];

        assert_eq!(
            resolve_detector_timeout_ms(
                Some(configurations.as_slice()),
                Some("cls-a"),
                DETECTOR_CLASSIFIER_DEFAULT_TIMEOUT_MS
            ),
            123
        );
        assert_eq!(
            resolve_detector_timeout_ms(
                Some(configurations.as_slice()),
                Some("cls-b"),
                DETECTOR_CLASSIFIER_DEFAULT_TIMEOUT_MS
            ),
            456
        );
        assert_eq!(
            resolve_detector_timeout_ms(
                Some(configurations.as_slice()),
                Some("cls-c-default"),
                DETECTOR_CLASSIFIER_DEFAULT_TIMEOUT_MS
            ),
            DETECTOR_CLASSIFIER_DEFAULT_TIMEOUT_MS
        );

        // End-to-end shape: the classifier with `timeout: 50` is
        // bypassed by a fast caller (the default 30 s ceiling would
        // mask a missing lookup, so we use a slow caller to prove
        // the 50 ms value actually wins).
        let completed = Arc::new(AtomicUsize::new(0));
        let cls: Arc<dyn ClassifierCaller> = Arc::new(SleepyClassifier {
            sleep_ms: 200,
            completed: Arc::clone(&completed),
        });
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let mut deps = deps_for(&attrs, &cache);
        deps.classifier_caller = Some(cls);
        deps.configurations = Some(configurations.as_slice());

        let cfg_id_with_50ms = {
            let mut cfgs = configurations.clone();
            cfgs[0].timeout = Some(50);
            cfgs[0].id.clone()
        };
        let start = Instant::now();
        let v = detect(
            &classifier_entry_cfg(&cfg_id_with_50ms),
            "subject",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps,
        );
        let elapsed = start.elapsed();
        // configurations[0].timeout is 123 above — so the gate fires
        // around 123 ms, not 200 ms. Allow generous slack on slow CI.
        assert!(
            elapsed < Duration::from_millis(190),
            "config-tier timeout (123 ms) must win; observed {:?}",
            elapsed
        );
        assert!(matches!(v, DetectionVerdict::Fail { .. }));
    }
}
