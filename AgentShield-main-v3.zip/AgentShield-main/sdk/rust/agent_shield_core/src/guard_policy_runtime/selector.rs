//! `applies_to:` matching for tools, agents, and endpoints.
//!
//! Tool, agent, and endpoint selectors are OR-joined within a guard policy.
//! Endpoint specificity only matters when one policy carries multiple
//! endpoint patterns.

use crate::guard_policy::AppliesTo;
use crate::merge::MergedConfig;
use crate::populator::pattern_matches_uri;
use crate::selectors::{EndpointSelector, EndpointSelectorSet, Selector};

/// Pre-computed sets of "literal" resource names used for `Unlisted`
/// matching. Built once from the merged config, reused across all
/// guard-policy evaluations in a stage.
pub struct ListedNames {
    pub tool_names: std::collections::HashSet<String>,
    pub agent_names: std::collections::HashSet<String>,
    /// Literal (exact / parameterized — not glob) endpoint matchers.
    pub endpoint_matchers: Vec<EndpointSelector>,
}

impl ListedNames {
    /// Build from the merged config. Literal tool/agent names are those
    /// without `*` wildcards; literal endpoint matchers are those whose
    /// `pattern` does not contain `**`.
    pub fn from_config(config: &MergedConfig) -> Self {
        let tool_names = config
            .resources
            .tools
            .iter()
            .filter(|t| !t.name.contains('*'))
            .map(|t| t.name.clone())
            .collect();
        let agent_names = config
            .resources
            .agents
            .iter()
            .filter(|a| !a.name.contains('*'))
            .map(|a| a.name.clone())
            .collect();
        let endpoint_matchers = config
            .resources
            .endpoints
            .iter()
            .filter(|e| !e.pattern.contains("**"))
            .map(|e| EndpointSelector {
                pattern: e.pattern.clone(),
                methods: e.methods.clone(),
            })
            .collect();
        Self {
            tool_names,
            agent_names,
            endpoint_matchers,
        }
    }

    pub fn tool_set(&self) -> std::collections::HashSet<&str> {
        self.tool_names.iter().map(|s| s.as_str()).collect()
    }

    pub fn agent_set(&self) -> std::collections::HashSet<&str> {
        self.agent_names.iter().map(|s| s.as_str()).collect()
    }
}

/// What kind of resource the runtime is gating right now.
#[derive(Debug, Clone)]
pub enum SelectorSubject<'a> {
    Tool {
        name: &'a str,
    },
    Agent {
        name: &'a str,
    },
    Endpoint {
        method: &'a str,
        uri: &'a str,
    },
    /// Stages 1 and 5 don't bind to a resource. `applies_to:` is rejected
    /// at load there, so the matcher always returns `true`.
    None,
}

/// Test whether `applies_to` matches `subject`. When `applies_to` is
/// `None` (the field was omitted), the guard policy applies to **all**
/// resources for the stage — Stage 3 / Stage 4 default behavior per §12.3.1.
///
/// `listed_tool_names` and `listed_agent_names` are the sets of literal
/// (non-wildcard) resource names declared in `resources.tools[]` /
/// `resources.agents[]`. Required to evaluate `Selector::Unlisted` entries.
/// Pass empty sets if not available; Unlisted will then match everything.
///
/// `listed_endpoint_matchers` is the slice of literal (exact / parameterized)
/// endpoint matchers from `resources.endpoints[]`. Used for
/// `EndpointSelectorSet::Unlisted`.
pub fn applies_to_matches<T, U>(
    applies_to: Option<&AppliesTo>,
    subject: &SelectorSubject<'_>,
    listed_tool_names: &std::collections::HashSet<T>,
    listed_agent_names: &std::collections::HashSet<U>,
    listed_endpoint_matchers: &[EndpointSelector],
) -> bool
where
    T: std::borrow::Borrow<str> + Eq + std::hash::Hash,
    U: std::borrow::Borrow<str> + Eq + std::hash::Hash,
{
    let Some(at) = applies_to else {
        return true;
    };
    if at.is_empty() {
        return true;
    }
    match subject {
        SelectorSubject::Tool { name } => match_tool(at.tools.as_ref(), name, listed_tool_names),
        SelectorSubject::Agent { name } => {
            match_agent(at.agents.as_ref(), name, listed_agent_names)
        }
        SelectorSubject::Endpoint { method, uri } => {
            match_endpoint(at.endpoints.as_ref(), method, uri, listed_endpoint_matchers)
        }
        SelectorSubject::None => false,
    }
}

fn match_tool<T>(
    selector: Option<&Selector>,
    name: &str,
    listed: &std::collections::HashSet<T>,
) -> bool
where
    T: std::borrow::Borrow<str> + Eq + std::hash::Hash,
{
    match selector {
        Some(sel) => sel.matches(name, listed),
        None => false,
    }
}

fn match_agent<T>(
    selector: Option<&Selector>,
    name: &str,
    listed: &std::collections::HashSet<T>,
) -> bool
where
    T: std::borrow::Borrow<str> + Eq + std::hash::Hash,
{
    match selector {
        Some(sel) => sel.matches(name, listed),
        None => false,
    }
}

fn match_endpoint(
    selector: Option<&EndpointSelectorSet>,
    method: &str,
    uri: &str,
    listed: &[EndpointSelector],
) -> bool {
    match selector {
        Some(sel) => sel.matches_endpoint(method, uri, endpoint_element_matches, listed),
        None => false,
    }
}

pub(crate) fn endpoint_element_matches(sel: &EndpointSelector, method: &str, uri: &str) -> bool {
    if !sel.methods.is_empty()
        && !sel
            .methods
            .iter()
            .any(|m| m == "*" || m.eq_ignore_ascii_case(method))
    {
        return false;
    }
    pattern_matches_uri(&sel.pattern, uri)
}

/// §13.4 pattern mode (exact > parameterized > glob).
fn pattern_mode(pattern: &str) -> u8 {
    if pattern.contains("**") {
        0 // glob
    } else if pattern.contains('{') && pattern.contains('}') {
        1 // parameterized
    } else {
        2 // exact
    }
}

/// §13.4 specificity = literal segments − parameter segments.
fn specificity(pattern: &str) -> i32 {
    let mut literals = 0i32;
    let mut params = 0i32;
    for seg in pattern.trim_start_matches('/').split('/') {
        if seg == "**" {
            // glob is its own bucket; don't count
        } else if seg.starts_with('{') && seg.ends_with('}') {
            params += 1;
        } else if !seg.is_empty() {
            literals += 1;
        }
    }
    literals - params
}

/// §13.4 method-exact wins over `["*"]`.
fn method_specificity(methods: &[String]) -> u8 {
    if methods.iter().any(|m| m == "*") && methods.len() == 1 {
        0
    } else {
        1
    }
}

/// Pick the most specific matching endpoint inside an `applies_to:` block.
/// Returns its index. Uses (mode, specificity, method-specificity, declared
/// order) tuple ordering per §13.4.
pub fn pick_best_endpoint(
    endpoints: &[EndpointSelector],
    method: &str,
    uri: &str,
) -> Option<usize> {
    endpoints
        .iter()
        .enumerate()
        .filter(|(_, e)| endpoint_element_matches(e, method, uri))
        .max_by_key(|(idx, e)| {
            (
                pattern_mode(&e.pattern),
                specificity(&e.pattern),
                method_specificity(&e.methods),
                // declared order: earlier wins on tie ⇒ negate index
                -(*idx as i64),
            )
        })
        .map(|(i, _)| i)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::selectors::{EndpointSelector, EndpointSelectorSet, Selector};

    fn empty_tools() -> std::collections::HashSet<&'static str> {
        std::collections::HashSet::new()
    }
    fn empty_agents() -> std::collections::HashSet<&'static str> {
        std::collections::HashSet::new()
    }
    fn no_endpoints() -> Vec<EndpointSelector> {
        vec![]
    }

    fn at_tool(t: &str) -> AppliesTo {
        AppliesTo {
            tools: Some(Selector::single(t)),
            ..Default::default()
        }
    }
    fn at_agent(a: &str) -> AppliesTo {
        AppliesTo {
            agents: Some(Selector::single(a)),
            ..Default::default()
        }
    }
    fn at_endpoint(p: &str, methods: &[&str]) -> AppliesTo {
        AppliesTo {
            endpoints: Some(EndpointSelectorSet::List {
                include: vec![EndpointSelector {
                    pattern: p.into(),
                    methods: methods.iter().map(|s| s.to_string()).collect(),
                }],
                exclude: vec![],
            }),
            ..Default::default()
        }
    }

    #[test]
    fn tool_exact_match() {
        let at = at_tool("send_email");
        assert!(applies_to_matches(
            Some(&at),
            &SelectorSubject::Tool { name: "send_email" },
            &empty_tools(),
            &empty_agents(),
            &no_endpoints(),
        ));
        assert!(!applies_to_matches(
            Some(&at),
            &SelectorSubject::Tool { name: "send_other" },
            &empty_tools(),
            &empty_agents(),
            &no_endpoints(),
        ));
    }

    #[test]
    fn tool_wildcard_match() {
        let at = at_tool("*");
        assert!(applies_to_matches(
            Some(&at),
            &SelectorSubject::Tool { name: "anything" },
            &empty_tools(),
            &empty_agents(),
            &no_endpoints(),
        ));
    }

    #[test]
    fn agent_match() {
        let at = at_agent("fraud_agent");
        assert!(applies_to_matches(
            Some(&at),
            &SelectorSubject::Agent {
                name: "fraud_agent"
            },
            &empty_tools(),
            &empty_agents(),
            &no_endpoints(),
        ));
        assert!(!applies_to_matches(
            Some(&at),
            &SelectorSubject::Tool {
                name: "fraud_agent"
            },
            &empty_tools(),
            &empty_agents(),
            &no_endpoints(),
        ));
    }

    #[test]
    fn endpoint_pattern_match() {
        let at = at_endpoint("/api/v1/users/{id}", &["GET", "POST"]);
        assert!(applies_to_matches(
            Some(&at),
            &SelectorSubject::Endpoint {
                method: "GET",
                uri: "/api/v1/users/42"
            },
            &empty_tools(),
            &empty_agents(),
            &no_endpoints(),
        ));
        assert!(!applies_to_matches(
            Some(&at),
            &SelectorSubject::Endpoint {
                method: "DELETE",
                uri: "/api/v1/users/42"
            },
            &empty_tools(),
            &empty_agents(),
            &no_endpoints(),
        ));
    }

    #[test]
    fn endpoint_method_wildcard() {
        let at = at_endpoint("/api/v1/external/**", &["*"]);
        assert!(applies_to_matches(
            Some(&at),
            &SelectorSubject::Endpoint {
                method: "DELETE",
                uri: "/api/v1/external/foo/bar"
            },
            &empty_tools(),
            &empty_agents(),
            &no_endpoints(),
        ));
    }

    #[test]
    fn omitted_applies_to_matches_anything() {
        assert!(applies_to_matches(
            None,
            &SelectorSubject::Tool { name: "x" },
            &empty_tools(),
            &empty_agents(),
            &no_endpoints(),
        ));
    }

    #[test]
    fn empty_applies_to_matches_anything() {
        let at = AppliesTo::default();
        assert!(applies_to_matches(
            Some(&at),
            &SelectorSubject::Tool { name: "x" },
            &empty_tools(),
            &empty_agents(),
            &no_endpoints(),
        ));
    }

    #[test]
    fn endpoint_specificity_exact_beats_param() {
        let endpoints = vec![
            EndpointSelector {
                pattern: "/api/v1/users/{id}".into(),
                methods: vec!["GET".into()],
            },
            EndpointSelector {
                pattern: "/api/v1/users/me".into(),
                methods: vec!["GET".into()],
            },
        ];
        let pick = pick_best_endpoint(&endpoints, "GET", "/api/v1/users/me");
        assert_eq!(pick, Some(1));
    }

    #[test]
    fn endpoint_specificity_param_beats_glob() {
        let endpoints = vec![
            EndpointSelector {
                pattern: "/api/v1/**".into(),
                methods: vec!["*".into()],
            },
            EndpointSelector {
                pattern: "/api/v1/users/{id}".into(),
                methods: vec!["GET".into()],
            },
        ];
        let pick = pick_best_endpoint(&endpoints, "GET", "/api/v1/users/42");
        assert_eq!(pick, Some(1));
    }

    #[test]
    fn endpoint_method_exact_beats_wildcard() {
        let endpoints = vec![
            EndpointSelector {
                pattern: "/api/v1/users/me".into(),
                methods: vec!["*".into()],
            },
            EndpointSelector {
                pattern: "/api/v1/users/me".into(),
                methods: vec!["GET".into()],
            },
        ];
        let pick = pick_best_endpoint(&endpoints, "GET", "/api/v1/users/me");
        assert_eq!(pick, Some(1));
    }

    #[test]
    fn endpoint_tie_break_first_wins() {
        let endpoints = vec![
            EndpointSelector {
                pattern: "/api/v1/users/{id}".into(),
                methods: vec!["GET".into()],
            },
            EndpointSelector {
                pattern: "/api/v1/users/{id}".into(),
                methods: vec!["GET".into()],
            },
        ];
        let pick = pick_best_endpoint(&endpoints, "GET", "/api/v1/users/42");
        // declared-first wins on equal specificity (§13.4)
        assert_eq!(pick, Some(0));
    }

    #[test]
    fn tool_unlisted_selector() {
        let listed: std::collections::HashSet<&str> =
            ["send_email", "fetch_data"].iter().copied().collect();
        let at = AppliesTo {
            tools: Some(Selector::Unlisted),
            ..Default::default()
        };
        // "new_tool" is not listed → unlisted matches
        assert!(applies_to_matches(
            Some(&at),
            &SelectorSubject::Tool { name: "new_tool" },
            &listed,
            &empty_agents(),
            &no_endpoints(),
        ));
        // "send_email" IS listed → unlisted does not match
        assert!(!applies_to_matches(
            Some(&at),
            &SelectorSubject::Tool { name: "send_email" },
            &listed,
            &empty_agents(),
            &no_endpoints(),
        ));
    }

    #[test]
    fn endpoint_unlisted_selector() {
        use crate::selectors::EndpointSelectorSet;

        let literal_endpoints = vec![EndpointSelector {
            pattern: "/api/v1/payments/{id}".into(),
            methods: vec!["POST".into()],
        }];
        let at = AppliesTo {
            endpoints: Some(EndpointSelectorSet::Unlisted),
            ..Default::default()
        };
        // /api/v1/payments/123 POST is covered by the literal → not unlisted
        assert!(!applies_to_matches(
            Some(&at),
            &SelectorSubject::Endpoint {
                method: "POST",
                uri: "/api/v1/payments/abc"
            },
            &empty_tools(),
            &empty_agents(),
            &literal_endpoints,
        ));
        // /api/v1/new/endpoint GET is not covered → unlisted
        assert!(applies_to_matches(
            Some(&at),
            &SelectorSubject::Endpoint {
                method: "GET",
                uri: "/api/v1/new/endpoint"
            },
            &empty_tools(),
            &empty_agents(),
            &literal_endpoints,
        ));
    }
}
