//! `allowed_when:` bypass evaluation.
//!
//! When an `evaluate_when[]` entry fails, the runtime calls into here to
//! check whether the guard policy's `allowed_when:` predicate suppresses
//! the failure. Auto-resolution **does** fire on these reads (in contrast
//! to `active_if:`), so we evaluate with `is_gating_site = true` and the
//! engine's resolver hook attached.

use std::collections::HashMap;

use serde_json::Value;

use crate::expressions::eval::{
    evaluate_with, EvalContext, EventFiredHook, PredicateLookup, ResolverHook, StatusLookup,
};

/// Evaluate `allowed_when:` truthiness. Returns `false` when the
/// predicate is absent (no bypass declared). Auto-resolution fires per
/// ///
/// fail-closed: when the predicate references a declared variable
/// whose `@status` is `denied`, the bypass MUST NOT fire. Otherwise an
/// `allowed_when:` like `approval == null` would silently launder a
/// resolver denial into a bypass.
#[allow(clippy::too_many_arguments)]
pub fn evaluate_allowed_when(
    expr: Option<&str>,
    attrs: &HashMap<String, Value>,
    status_lookup: Option<&dyn StatusLookup>,
    event_fired: Option<&dyn EventFiredHook>,
    predicates: Option<&dyn PredicateLookup>,
    resolver_hook: Option<&dyn ResolverHook>,
) -> bool {
    let Some(e) = expr else {
        return false;
    };
    if let Some(sl) = status_lookup {
        if crate::expressions::denied_refs::first_denied_ref(e, sl, predicates).is_some() {
            return false;
        }
    }
    let mut ctx = EvalContext::from_attrs(attrs);
    ctx.status_lookup = status_lookup;
    ctx.event_fired = event_fired;
    ctx.predicates = predicates;
    ctx.is_gating_site = true;
    ctx.resolver_hook = resolver_hook;
    let truthy = evaluate_with(e, &ctx);
    // post-check: auto-resolution inside the bypass evaluation
    // may have just flipped a referenced variable to `denied`. The
    // bypass MUST NOT fire on that state.
    // pass `predicates` so the walker expands predicate
    // wrappers transitively.
    if let Some(sl) = status_lookup {
        if crate::expressions::denied_refs::first_denied_ref(e, sl, predicates).is_some() {
            return false;
        }
    }
    truthy
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    #[test]
    fn absent_returns_false() {
        let attrs = HashMap::new();
        assert!(!evaluate_allowed_when(None, &attrs, None, None, None, None));
    }

    #[test]
    fn truthy_returns_true() {
        let mut attrs = HashMap::new();
        attrs.insert("approved".into(), json!(true));
        assert!(evaluate_allowed_when(
            Some("approved == true"),
            &attrs,
            None,
            None,
            None,
            None,
        ));
    }

    #[test]
    fn falsey_returns_false() {
        let mut attrs = HashMap::new();
        attrs.insert("approved".into(), json!(false));
        assert!(!evaluate_allowed_when(
            Some("approved == true"),
            &attrs,
            None,
            None,
            None,
            None,
        ));
    }
}
