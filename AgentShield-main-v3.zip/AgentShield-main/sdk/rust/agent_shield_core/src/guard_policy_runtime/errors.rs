//! Error types for the guard-policy runtime engine.

use thiserror::Error;

/// Errors produced by [`super::GuardPolicyEngine`] during gate evaluation.
///
/// The engine generally avoids returning `Err` for spec-defined "fail
/// closed" cases (a missing LLM caller, an unparseable expression, etc.)
/// — those collapse to a `block` verdict so the caller can react with the
/// same code path it uses for any other guard-policy failure. `Err` is
/// reserved for programmer mistakes (e.g., invoking a stage method against
/// a [`super::EvalRuntime`] that's missing required attribute roots).
#[derive(Debug, Error)]
pub enum GuardPolicyRuntimeError {
    #[error("regex pattern exceeds the §5.1 ReDoS guard ({0} > 500 chars)")]
    PatternTooLong(usize),

    #[error("regex pattern failed to compile: {0}")]
    InvalidRegex(String),

    #[error("evaluate_when entry missing required field for action: {0}")]
    MissingTransformField(&'static str),

    #[error("internal: {0}")]
    Internal(String),
}
