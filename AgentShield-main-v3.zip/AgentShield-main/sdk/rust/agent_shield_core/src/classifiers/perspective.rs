//! Google Perspective API (commentanalyzer.googleapis.com).
//!
//! Endpoint: `https://commentanalyzer.googleapis.com/v1alpha1/comments:analyze?key=<API_KEY>`.
//! Request body lists `requestedAttributes` per category. Response
//! shape: `{ "attributeScores": {<cat>: { "summaryScore": { "value": float } }} }`.

use std::collections::HashMap;

use serde_json::{json, Value};

use crate::classifiers::auto::BundledProvider;
use crate::classifiers::transport::{HttpTransport, TransportRequest};
use crate::classifiers::verdict::{fold_score_verdict, ResolvedClassifierConfig};
use crate::guard_policy_runtime::ClassifierVerdict;

const DEFAULT_ENDPOINT: &str = "https://commentanalyzer.googleapis.com/v1alpha1/comments:analyze";
const DEFAULT_ATTRIBUTES: &[&str] = &[
    "TOXICITY",
    "SEVERE_TOXICITY",
    "INSULT",
    "THREAT",
    "IDENTITY_ATTACK",
    "PROFANITY",
];

pub struct PerspectiveProvider;

impl BundledProvider for PerspectiveProvider {
    fn classify(
        &self,
        cfg: &ResolvedClassifierConfig,
        subject: &str,
        transport: &dyn HttpTransport,
    ) -> Result<ClassifierVerdict, String> {
        let api_key = cfg
            .api_key
            .as_deref()
            .ok_or("perspective: api_key not resolved")?;
        let base = if cfg.endpoint.is_empty() {
            DEFAULT_ENDPOINT
        } else {
            cfg.endpoint.as_str()
        };
        let url = if base.contains("?key=") {
            base.to_string()
        } else {
            format!("{base}?key={api_key}")
        };

        // Attributes: prefer category_thresholds keys (uppercase),
        // else provider_config.attributes, else defaults.
        let mut attrs_obj = serde_json::Map::new();
        let attrs_iter: Vec<String> = if !cfg.category_thresholds.is_empty() {
            cfg.category_thresholds
                .keys()
                .map(|k| k.to_ascii_uppercase())
                .collect()
        } else if let Some(arr) = cfg
            .provider_config
            .get("attributes")
            .and_then(|v| v.as_array())
        {
            arr.iter()
                .filter_map(|v| v.as_str().map(|s| s.to_ascii_uppercase()))
                .collect()
        } else {
            DEFAULT_ATTRIBUTES.iter().map(|s| s.to_string()).collect()
        };
        for a in &attrs_iter {
            attrs_obj.insert(a.clone(), json!({}));
        }

        let body = json!({
            "comment": { "text": subject },
            "requestedAttributes": attrs_obj,
            "languages": cfg.provider_config.get("languages").cloned().unwrap_or(json!(["en"])),
        });

        let mut req = TransportRequest::post(url)
            .header("Content-Type", "application/json")
            .json(body)
            .timeout_ms(cfg.timeout_ms);
        for (k, v) in &cfg.headers {
            req = req.header(k.as_str(), v.clone());
        }

        let (status, body) = transport.send(req)?;
        if !(200..300).contains(&status) {
            return Err(format!("perspective HTTP {status}: {body}"));
        }
        parse(cfg, &body)
    }
}

fn parse(cfg: &ResolvedClassifierConfig, body: &str) -> Result<ClassifierVerdict, String> {
    let json: Value =
        serde_json::from_str(body).map_err(|e| format!("perspective JSON parse: {e}"))?;
    let attribute_scores = json
        .get("attributeScores")
        .and_then(|v| v.as_object())
        .ok_or_else(|| "perspective response missing `attributeScores`".to_string())?;
    let mut scores: HashMap<String, f64> = HashMap::new();
    for (cat, val) in attribute_scores {
        if let Some(score) = val
            .get("summaryScore")
            .and_then(|s| s.get("value"))
            .and_then(|v| v.as_f64())
        {
            // Normalize to lower-snake-case so YAML authors can mirror
            // Perspective's category names with conventional snake_case.
            scores.insert(cat.to_ascii_lowercase(), score);
        }
    }
    Ok(fold_score_verdict(cfg, &scores, false))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::classifiers::transport::StubHttpTransport;

    fn cfg() -> ResolvedClassifierConfig {
        let mut cats = HashMap::new();
        cats.insert("toxicity".into(), 0.7);
        ResolvedClassifierConfig {
            id: "p".into(),
            provider: "perspective".into(),
            endpoint: "".into(),
            api_key: Some("k".into()),
            timeout_ms: 1000,
            threshold: 0.5,
            category_thresholds: cats,
            provider_config: Value::Null,
            headers: HashMap::new(),
        }
    }

    #[test]
    fn allow_when_score_below_threshold() {
        let body = r#"{
            "attributeScores": {
                "TOXICITY": { "summaryScore": { "value": 0.1 } }
            }
        }"#;
        let t = StubHttpTransport::with_response(200, body);
        let v = PerspectiveProvider.classify(&cfg(), "hi", &t).unwrap();
        assert!(!v.is_failure());
    }

    #[test]
    fn deny_when_score_meets_threshold() {
        let body = r#"{
            "attributeScores": {
                "TOXICITY": { "summaryScore": { "value": 0.85 } }
            }
        }"#;
        let t = StubHttpTransport::with_response(200, body);
        let v = PerspectiveProvider.classify(&cfg(), "hi", &t).unwrap();
        assert!(v.is_failure());
    }

    #[test]
    fn http_4xx_is_fail_closed() {
        let t = StubHttpTransport::with_response(403, "forbidden");
        let err = PerspectiveProvider.classify(&cfg(), "x", &t).unwrap_err();
        assert!(err.contains("HTTP 403"));
    }

    #[test]
    fn malformed_response_is_fail_closed() {
        let t = StubHttpTransport::with_response(200, r#"{"foo":"bar"}"#);
        let err = PerspectiveProvider.classify(&cfg(), "x", &t).unwrap_err();
        assert!(err.contains("missing `attributeScores`"));
    }

    #[test]
    fn appends_api_key_to_url_when_absent() {
        let body = r#"{"attributeScores":{"TOXICITY":{"summaryScore":{"value":0.0}}}}"#;
        let t = StubHttpTransport::with_response(200, body);
        let _ = PerspectiveProvider.classify(&cfg(), "hi", &t).unwrap();
        let req = t.last_request().unwrap();
        assert!(req.url.contains("?key=k"));
    }
}
