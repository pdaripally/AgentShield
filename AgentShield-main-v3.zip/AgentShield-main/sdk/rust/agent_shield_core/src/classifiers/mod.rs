//! Bundled moderation-classifier providers.
//!
//! Five HTTP-backed classifier adapters that route through the
//! [`crate::guard_policy_runtime::ClassifierCaller`] trait so YAML
//! authors can write
//!
//! ```yaml
//! configurations:
//!   - id: pii_scan
//!     type: classifier
//!     provider: lakera_guard          # bundled, gated by Cargo feature
//!     api_key_env: LAKERA_API_KEY
//!     category_thresholds:
//!       pii: 0.7
//!       prompt_injection: 0.8
//! ```
//!
//! and the bundled provider handles the request body shape, response
//! parsing, and §11.12.4 verdict folding without any per-user HTTP code.
//!
//! ## Cargo features
//!
//! Each provider lives behind its own feature so the default build stays
//! minimal:
//!
//! - `aacs`              → Azure AI Content Safety
//! - `lakera-guard`      → Lakera Guard (prompt-injection detection)
//! - `llama-guard`       → Meta Llama Guard (self-hosted safety)
//! - `openai-moderation` → OpenAI `/v1/moderations`
//! - `perspective`       → Google Perspective API
//!
//! Enable any combination at depend-time (`agent_shield_core =
//! { features = ["lakera-guard", "openai-moderation"] }`).
//!
//! ## Wiring
//!
//! Auto-installation parallels the LLM auto-wire path
//! ([`crate::runtime::llm_auto::AutoWiredLlmCaller`]). When the host
//! does not call [`crate::runtime::RuntimeBuilder::register_classifier_caller`]
//! and the merged config contains at least one `type: classifier` entry
//! whose `provider:` matches a bundled implementation that is enabled
//! via a Cargo feature **and** whose credentials resolve, the runtime
//! installs an [`AutoWiredClassifierCaller`] for the duration of the
//! runtime.
//!
//! ## Fail-closed semantics (security-critical)
//!
//! Every error path — unknown configuration id, unsupported provider,
//! missing model / key, HTTP transport failure, non-2xx response,
//! malformed body, missing decision field — surfaces as
//! `Err(reason)` from [`crate::guard_policy_runtime::ClassifierCaller::classify`],
//! which the [`crate::guard_policy_runtime::GuardPolicyEngine`] folds
//! into a `BLOCK` verdict per §11.12.4 ¶3 / §12.5.1.

#[cfg(feature = "http")]
mod auto;
#[cfg(feature = "http")]
mod transport;
#[cfg(feature = "http")]
mod verdict;

#[cfg(feature = "aacs")]
pub mod aacs;
#[cfg(feature = "lakera-guard")]
pub mod lakera_guard;
#[cfg(feature = "llama-guard")]
pub mod llama_guard;
#[cfg(feature = "openai-moderation")]
pub mod openai_moderation;
#[cfg(feature = "perspective")]
pub mod perspective;

#[cfg(feature = "http")]
pub use auto::AutoWiredClassifierCaller;
#[cfg(feature = "http")]
pub use transport::{HttpTransport, ReqwestHttpTransport, StubHttpTransport, TransportRequest};
#[cfg(feature = "http")]
pub use verdict::{fold_score_verdict, ResolvedClassifierConfig};
