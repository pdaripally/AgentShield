//! OpenAI Moderation API (`/v1/moderations`).

use std::collections::HashMap;

use serde_json::Value;

use crate::classifiers::auto::BundledProvider;
use crate::classifiers::transport::{HttpTransport, TransportRequest};
use crate::classifiers::verdict::{fold_score_verdict, ResolvedClassifierConfig};
use crate::guard_policy_runtime::ClassifierVerdict;

const DEFAULT_ENDPOINT: &str = "https://api.openai.com/v1/moderations";
const DEFAULT_MODEL: &str = "omni-moderation-latest";

pub struct OpenAiModerationProvider;

impl BundledProvider for OpenAiModerationProvider {
    fn classify(
        &self,
        cfg: &ResolvedClassifierConfig,
        subject: &str,
        transport: &dyn HttpTransport,
    ) -> Result<ClassifierVerdict, String> {
        let api_key = cfg
            .api_key
            .as_deref()
            .ok_or("openai_moderation: api_key not resolved")?;
        let url = if cfg.endpoint.is_empty() {
            DEFAULT_ENDPOINT.to_string()
        } else {
            cfg.endpoint.clone()
        };
        let model = cfg
            .provider_config
            .get("model")
            .and_then(|v| v.as_str())
            .unwrap_or(DEFAULT_MODEL);
        let mut req = TransportRequest::post(url)
            .header("Content-Type", "application/json")
            .header("Authorization", format!("Bearer {api_key}"))
            .json(serde_json::json!({ "model": model, "input": subject }))
            .timeout_ms(cfg.timeout_ms);
        for (k, v) in &cfg.headers {
            req = req.header(k.as_str(), v.clone());
        }
        let (status, body) = transport.send(req)?;
        if !(200..300).contains(&status) {
            return Err(format!("openai_moderation HTTP {status}: {body}"));
        }
        parse(cfg, &body)
    }
}

fn parse(cfg: &ResolvedClassifierConfig, body: &str) -> Result<ClassifierVerdict, String> {
    let json: Value =
        serde_json::from_str(body).map_err(|e| format!("openai_moderation JSON parse: {e}"))?;
    let result = json
        .get("results")
        .and_then(|r| r.as_array())
        .and_then(|arr| arr.first())
        .ok_or_else(|| "openai_moderation response missing `results[0]`".to_string())?;
    let flagged = result
        .get("flagged")
        .and_then(|v| v.as_bool())
        .unwrap_or(false);
    let mut scores: HashMap<String, f64> = HashMap::new();
    if let Some(map) = result.get("category_scores").and_then(|v| v.as_object()) {
        for (k, v) in map {
            if let Some(f) = v.as_f64() {
                scores.insert(k.clone(), f);
            }
        }
    }
    Ok(fold_score_verdict(cfg, &scores, flagged))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::classifiers::transport::StubHttpTransport;

    fn cfg() -> ResolvedClassifierConfig {
        ResolvedClassifierConfig {
            id: "om".into(),
            provider: "openai_moderation".into(),
            endpoint: "".into(),
            api_key: Some("k".into()),
            timeout_ms: 1000,
            threshold: 0.5,
            category_thresholds: HashMap::new(),
            provider_config: Value::Null,
            headers: HashMap::new(),
        }
    }

    #[test]
    fn allow_when_not_flagged_and_below_threshold() {
        let body = r#"{
            "results":[{"flagged":false,"category_scores":{"hate":0.01}}]
        }"#;
        let t = StubHttpTransport::with_response(200, body);
        let v = OpenAiModerationProvider.classify(&cfg(), "hi", &t).unwrap();
        assert!(!v.is_failure());
    }

    #[test]
    fn deny_when_native_flagged() {
        let body = r#"{
            "results":[{"flagged":true,"category_scores":{"hate":0.05}}]
        }"#;
        let t = StubHttpTransport::with_response(200, body);
        let v = OpenAiModerationProvider.classify(&cfg(), "hi", &t).unwrap();
        assert!(v.is_failure());
    }

    #[test]
    fn deny_when_max_score_exceeds_global_threshold() {
        let body = r#"{
            "results":[{"flagged":false,"category_scores":{"hate":0.99}}]
        }"#;
        let t = StubHttpTransport::with_response(200, body);
        let v = OpenAiModerationProvider.classify(&cfg(), "hi", &t).unwrap();
        assert!(v.is_failure());
    }

    #[test]
    fn http_4xx_is_fail_closed() {
        let t = StubHttpTransport::with_response(401, "unauthorized");
        let err = OpenAiModerationProvider
            .classify(&cfg(), "x", &t)
            .unwrap_err();
        assert!(err.contains("HTTP 401"));
    }

    #[test]
    fn malformed_json_is_fail_closed() {
        let t = StubHttpTransport::with_response(200, "not json");
        let err = OpenAiModerationProvider
            .classify(&cfg(), "x", &t)
            .unwrap_err();
        assert!(err.contains("JSON parse"));
    }
}
