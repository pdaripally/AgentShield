//! HTTP transport abstraction for bundled classifier providers.
//!
//! Stubbable trait so per-provider tests can swap canned responses
//! without spinning up a network listener. Production code uses
//! [`ReqwestHttpTransport`] which wraps the existing `reqwest`
//! dependency.

use std::collections::HashMap;
use std::sync::Mutex;
use std::time::Duration;

const DEFAULT_TIMEOUT: Duration = Duration::from_secs(10);

/// One outbound HTTP request prepared by a provider.
#[derive(Debug, Clone)]
pub struct TransportRequest {
    pub method: &'static str, // "POST" or "GET"
    pub url: String,
    pub headers: HashMap<String, String>,
    pub body: Option<serde_json::Value>,
    pub timeout_ms: u32,
}

impl TransportRequest {
    pub fn post(url: impl Into<String>) -> Self {
        Self {
            method: "POST",
            url: url.into(),
            headers: HashMap::new(),
            body: None,
            timeout_ms: DEFAULT_TIMEOUT.as_millis() as u32,
        }
    }

    pub fn header(mut self, k: &str, v: impl Into<String>) -> Self {
        self.headers.insert(k.to_string(), v.into());
        self
    }

    pub fn json(mut self, body: serde_json::Value) -> Self {
        self.body = Some(body);
        self
    }

    pub fn timeout_ms(mut self, ms: u32) -> Self {
        self.timeout_ms = ms;
        self
    }
}

/// Minimal HTTP transport surface — `(status, body)` on success, an
/// error message on transport failure / timeout. Body is the raw bytes
/// as UTF-8; non-UTF-8 responses surface as a transport error.
pub trait HttpTransport: Send + Sync {
    fn send(&self, req: TransportRequest) -> Result<(u16, String), String>;
}

/// Production transport built on the crate-wide [`reqwest::Client`]
/// plus a private current-thread tokio runtime (mirroring
/// [`crate::runtime::delegate_default::DefaultDelegateDispatcher`]).
pub struct ReqwestHttpTransport;

impl HttpTransport for ReqwestHttpTransport {
    fn send(&self, req: TransportRequest) -> Result<(u16, String), String> {
        let rt = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .map_err(|e| format!("tokio runtime build: {e}"))?;
        rt.block_on(async move {
            let client = reqwest::Client::builder()
                .timeout(Duration::from_millis(req.timeout_ms.max(1) as u64))
                .build()
                .map_err(|e| format!("reqwest client build: {e}"))?;
            let mut builder = match req.method {
                "POST" => client.post(&req.url),
                "GET" => client.get(&req.url),
                other => return Err(format!("unsupported HTTP method: {other}")),
            };
            for (k, v) in &req.headers {
                builder = builder.header(k, v);
            }
            if let Some(body) = req.body {
                builder = builder.json(&body);
            }
            let resp = builder
                .send()
                .await
                .map_err(|e| format!("classifier HTTP send: {e}"))?;
            let status = resp.status().as_u16();
            let text = resp
                .text()
                .await
                .map_err(|e| format!("classifier HTTP read: {e}"))?;
            Ok((status, text))
        })
    }
}

/// Stub transport for tests — drains a queue of canned `(status, body)`
/// responses in FIFO order and records every request for later
/// inspection. Used by every per-provider unit test in this module.
pub struct StubHttpTransport {
    inner: Mutex<StubInner>,
}

struct StubInner {
    responses: Vec<Result<(u16, String), String>>,
    sent: Vec<TransportRequest>,
}

impl StubHttpTransport {
    pub fn with_response(status: u16, body: impl Into<String>) -> Self {
        Self {
            inner: Mutex::new(StubInner {
                responses: vec![Ok((status, body.into()))],
                sent: Vec::new(),
            }),
        }
    }

    pub fn with_responses<I>(responses: I) -> Self
    where
        I: IntoIterator<Item = Result<(u16, String), String>>,
    {
        Self {
            inner: Mutex::new(StubInner {
                responses: responses.into_iter().collect(),
                sent: Vec::new(),
            }),
        }
    }

    pub fn last_request(&self) -> Option<TransportRequest> {
        self.inner.lock().unwrap().sent.last().cloned()
    }

    pub fn requests(&self) -> Vec<TransportRequest> {
        self.inner.lock().unwrap().sent.clone()
    }
}

impl HttpTransport for StubHttpTransport {
    fn send(&self, req: TransportRequest) -> Result<(u16, String), String> {
        let mut inner = self.inner.lock().unwrap();
        inner.sent.push(req);
        if inner.responses.is_empty() {
            return Err("StubHttpTransport: response queue exhausted".into());
        }
        inner.responses.remove(0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn stub_returns_canned_response() {
        let t = StubHttpTransport::with_response(200, r#"{"ok":true}"#);
        let r = t.send(TransportRequest::post("http://x")).unwrap();
        assert_eq!(r.0, 200);
        assert!(r.1.contains("ok"));
        assert_eq!(t.requests().len(), 1);
    }

    #[test]
    fn stub_drains_in_order() {
        let t = StubHttpTransport::with_responses(vec![
            Ok((200, "first".into())),
            Ok((500, "second".into())),
        ]);
        assert_eq!(
            t.send(TransportRequest::post("http://x")).unwrap().1,
            "first"
        );
        assert_eq!(t.send(TransportRequest::post("http://x")).unwrap().0, 500);
        assert!(t.send(TransportRequest::post("http://x")).is_err());
    }
}
