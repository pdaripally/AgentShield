//! Lakera Guard — prompt-injection / jailbreak detection.
//!
//! Endpoint: `https://api.lakera.ai/v1/guard` (override via
//! `endpoint:`). Request body: `{ "input": "<subject>" }`. Response
//! shape: `{ "results": [{ "flagged": bool, "categories": {<cat>: bool},
//! "category_scores": {<cat>: float} }] }`.
use std::collections::HashMap;

use serde_json::Value;

use crate::classifiers::auto::BundledProvider;
use crate::classifiers::transport::{HttpTransport, TransportRequest};
use crate::classifiers::verdict::{fold_score_verdict, ResolvedClassifierConfig};
use crate::guard_policy_runtime::ClassifierVerdict;

const DEFAULT_ENDPOINT: &str = "https://api.lakera.ai/v1/guard";

pub struct LakeraGuardProvider;

impl BundledProvider for LakeraGuardProvider {
    fn classify(
        &self,
        cfg: &ResolvedClassifierConfig,
        subject: &str,
        transport: &dyn HttpTransport,
    ) -> Result<ClassifierVerdict, String> {
        let api_key = cfg
            .api_key
            .as_deref()
            .ok_or("lakera_guard: api_key not resolved")?;
        let url = if cfg.endpoint.is_empty() {
            DEFAULT_ENDPOINT.to_string()
        } else {
            cfg.endpoint.clone()
        };
        let mut req = TransportRequest::post(url)
            .header("Content-Type", "application/json")
            .header("Authorization", format!("Bearer {api_key}"))
            .json(serde_json::json!({ "input": subject }))
            .timeout_ms(cfg.timeout_ms);
        for (k, v) in &cfg.headers {
            req = req.header(k.as_str(), v.clone());
        }

        let (status, body) = transport.send(req)?;
        if !(200..300).contains(&status) {
            return Err(format!("lakera_guard HTTP {status}: {body}"));
        }
        parse(cfg, &body)
    }
}

fn parse(cfg: &ResolvedClassifierConfig, body: &str) -> Result<ClassifierVerdict, String> {
    let json: Value =
        serde_json::from_str(body).map_err(|e| format!("lakera_guard JSON parse: {e}"))?;
    let result = json
        .get("results")
        .and_then(|r| r.as_array())
        .and_then(|arr| arr.first())
        .ok_or_else(|| "lakera_guard response missing `results[0]` (malformed)".to_string())?;

    let flagged = result
        .get("flagged")
        .and_then(|v| v.as_bool())
        .unwrap_or(false);
    let mut scores: HashMap<String, f64> = HashMap::new();
    if let Some(map) = result.get("category_scores").and_then(|v| v.as_object()) {
        for (k, v) in map {
            if let Some(f) = v.as_f64() {
                scores.insert(k.clone(), f);
            }
        }
    }

    Ok(fold_score_verdict(cfg, &scores, flagged))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::classifiers::transport::StubHttpTransport;

    fn cfg() -> ResolvedClassifierConfig {
        let mut cats = HashMap::new();
        cats.insert("prompt_injection".into(), 0.7);
        ResolvedClassifierConfig {
            id: "lk".into(),
            provider: "lakera_guard".into(),
            endpoint: "".into(),
            api_key: Some("k".into()),
            timeout_ms: 1000,
            threshold: 0.5,
            category_thresholds: cats,
            provider_config: Value::Null,
            headers: HashMap::new(),
        }
    }

    #[test]
    fn allow_when_scores_below_thresholds() {
        let body = r#"{
            "results": [{
                "flagged": false,
                "category_scores": { "prompt_injection": 0.1 }
            }]
        }"#;
        let t = StubHttpTransport::with_response(200, body);
        let v = LakeraGuardProvider.classify(&cfg(), "hello", &t).unwrap();
        assert!(!v.is_failure());
    }

    #[test]
    fn deny_when_listed_category_exceeds_threshold() {
        let body = r#"{
            "results": [{
                "flagged": true,
                "category_scores": { "prompt_injection": 0.95 }
            }]
        }"#;
        let t = StubHttpTransport::with_response(200, body);
        let v = LakeraGuardProvider.classify(&cfg(), "hello", &t).unwrap();
        assert!(v.is_failure());
        assert_eq!(v.label.as_deref(), Some("prompt_injection"));
    }

    #[test]
    fn http_5xx_is_fail_closed() {
        let t = StubHttpTransport::with_response(503, "service unavailable");
        let err = LakeraGuardProvider.classify(&cfg(), "x", &t).unwrap_err();
        assert!(err.contains("HTTP 503"));
    }

    #[test]
    fn malformed_json_is_fail_closed() {
        let t = StubHttpTransport::with_response(200, "{not-json");
        let err = LakeraGuardProvider.classify(&cfg(), "x", &t).unwrap_err();
        assert!(err.contains("JSON parse"));
    }

    #[test]
    fn missing_results_key_is_fail_closed() {
        let t = StubHttpTransport::with_response(200, r#"{"foo":1}"#);
        let err = LakeraGuardProvider.classify(&cfg(), "x", &t).unwrap_err();
        assert!(err.contains("missing `results[0]`"));
    }

    #[test]
    fn missing_api_key_is_fail_closed() {
        let mut c = cfg();
        c.api_key = None;
        let t = StubHttpTransport::with_response(200, "{}");
        let err = LakeraGuardProvider.classify(&c, "x", &t).unwrap_err();
        assert!(err.contains("api_key not resolved"));
    }

    #[test]
    fn sets_authorization_header_and_body() {
        let body = r#"{"results":[{"flagged":false,"category_scores":{}}]}"#;
        let t = StubHttpTransport::with_response(200, body);
        let _ = LakeraGuardProvider.classify(&cfg(), "hello", &t).unwrap();
        let req = t.last_request().unwrap();
        assert_eq!(req.method, "POST");
        assert_eq!(req.url, DEFAULT_ENDPOINT);
        assert_eq!(
            req.headers.get("Authorization").map(String::as_str),
            Some("Bearer k")
        );
        assert_eq!(
            req.body
                .as_ref()
                .and_then(|b| b.get("input"))
                .and_then(|v| v.as_str()),
            Some("hello")
        );
    }
}
