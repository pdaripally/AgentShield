//! Shared verdict-folding helpers for bundled classifier providers.

use std::collections::HashMap;

use crate::configurations::ShieldConfiguration;
use crate::guard_policy_runtime::ClassifierVerdict;

/// A snapshot of one classifier configuration with the fields the
/// bundled providers actually need. Built once per
/// [`crate::classifiers::AutoWiredClassifierCaller::from_configurations`]
/// call so providers don't re-resolve env vars on every classify.
#[derive(Debug, Clone)]
pub struct ResolvedClassifierConfig {
    pub id: String,
    pub provider: String,
    pub endpoint: String,
    pub api_key: Option<String>,
    pub timeout_ms: u32,
    /// Global threshold. Per-category thresholds
    /// override this for listed categories.
    pub threshold: f64,
    /// Per-category thresholds. Empty when authors haven't supplied
    /// any — providers fall back to native flagging plus the global
    /// threshold against the maximum category score.
    pub category_thresholds: HashMap<String, f64>,
    /// Carrier for arbitrary extra config knobs (the
    /// `provider_config:` block) — providers parse this on demand.
    pub provider_config: serde_json::Value,
    /// Author-supplied headers to merge into every request.
    pub headers: HashMap<String, String>,
}

impl ResolvedClassifierConfig {
    /// Build a snapshot from a `type: classifier` configuration. Returns
    /// `None` when the provider is unknown, when `api_key_env:` is
    /// declared but resolves to an empty value at build time (so the
    /// auto-wired caller never registers configurations whose
    /// credentials cannot be sourced — letting the runtime builder's
    /// `validate_classifier_wiring` check produce an actionable
    /// load-time error rather than a per-call surprise), or when the
    /// provider is gated by a Cargo feature not compiled into this
    /// build. Providers that legitimately run
    /// without a credential (e.g. self-hosted Llama Guard) declare so
    /// by omitting `api_key_env:` entirely.
    pub fn from_configuration(cfg: &ShieldConfiguration) -> Option<Self> {
        let provider = cfg.provider.as_deref()?.to_lowercase();
        let endpoint = cfg.endpoint.as_deref().unwrap_or("").to_string();
        let api_key = match cfg.api_key_env.as_deref() {
            None | Some("") => None,
            Some(name) => match std::env::var(name) {
                Ok(v) if !v.is_empty() => Some(v),
                // Dropping the entry here is the load-time signal the
                // wiring check uses to produce
                // a clear "env var unset" error instead of letting
                // the provider fail at first classify with
                // "<provider>: api_key not resolved".
                _ => return None,
            },
        };
        Some(Self {
            id: cfg.id.clone(),
            provider,
            endpoint,
            api_key,
            timeout_ms: cfg.timeout.unwrap_or(10_000),
            threshold: cfg.threshold.unwrap_or(0.5),
            category_thresholds: cfg.category_thresholds.clone(),
            provider_config: cfg
                .provider_config
                .clone()
                .unwrap_or(serde_json::Value::Null),
            headers: cfg.headers.clone(),
        })
    }
}

/// fold a per-category score map into a [`ClassifierVerdict`].
///
/// Semantics:
/// 1. If `category_thresholds` is non-empty, only listed categories are
///    monitored. Failure when *any* listed category's score meets or
///    exceeds its threshold. Unlisted high scores are ignored.
/// 2. Otherwise the global `threshold` applies to the *max* category
///    score, and the provider's native `flagged` boolean (if any)
///    forces a failure independent of the threshold.
pub fn fold_score_verdict(
    cfg: &ResolvedClassifierConfig,
    category_scores: &HashMap<String, f64>,
    native_flagged: bool,
) -> ClassifierVerdict {
    let max_score = category_scores.values().copied().fold(0.0_f64, f64::max);

    if !cfg.category_thresholds.is_empty() {
        let mut flagged = false;
        let mut top_label: Option<&str> = None;
        let mut top_score: f64 = 0.0;
        let mut reasons: Vec<String> = Vec::new();
        for (cat, thr) in &cfg.category_thresholds {
            if let Some(score) = category_scores.get(cat) {
                if *score >= *thr {
                    flagged = true;
                    if *score >= top_score {
                        top_score = *score;
                        top_label = Some(cat.as_str());
                    }
                    reasons.push(format!("{cat} {score:.3} >= {thr:.3}"));
                }
            }
        }
        return ClassifierVerdict {
            score: top_score,
            threshold: top_label
                .and_then(|c| cfg.category_thresholds.get(c).copied())
                .unwrap_or(cfg.threshold),
            flagged,
            label: top_label.map(str::to_string),
            reason: if reasons.is_empty() {
                None
            } else {
                Some(reasons.join("; "))
            },
            spans: Vec::new(),
        };
    }

    let mut top_label: Option<&str> = None;
    for (cat, score) in category_scores {
        if *score >= max_score {
            top_label = Some(cat.as_str());
        }
    }
    ClassifierVerdict {
        score: max_score,
        threshold: cfg.threshold,
        flagged: native_flagged,
        label: top_label.map(str::to_string),
        reason: None,
        spans: Vec::new(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn cfg_with(thresholds: &[(&str, f64)], global: f64) -> ResolvedClassifierConfig {
        let mut map = HashMap::new();
        for (k, v) in thresholds {
            map.insert((*k).to_string(), *v);
        }
        ResolvedClassifierConfig {
            id: "x".into(),
            provider: "stub".into(),
            endpoint: "http://stub".into(),
            api_key: None,
            timeout_ms: 1000,
            threshold: global,
            category_thresholds: map,
            provider_config: serde_json::Value::Null,
            headers: HashMap::new(),
        }
    }

    #[test]
    fn category_thresholds_select_only_listed() {
        let cfg = cfg_with(&[("pii", 0.7)], 0.5);
        let mut scores = HashMap::new();
        scores.insert("pii".into(), 0.4); // below
        scores.insert("hate".into(), 0.95); // not listed → ignored
        let v = fold_score_verdict(&cfg, &scores, false);
        assert!(!v.is_failure());
    }

    #[test]
    fn category_thresholds_fire_on_listed_match() {
        let cfg = cfg_with(&[("pii", 0.7)], 0.5);
        let mut scores = HashMap::new();
        scores.insert("pii".into(), 0.8);
        let v = fold_score_verdict(&cfg, &scores, false);
        assert!(v.is_failure());
        assert_eq!(v.label.as_deref(), Some("pii"));
    }

    #[test]
    fn no_category_thresholds_uses_max_with_native_flagged() {
        let cfg = cfg_with(&[], 0.7);
        let mut scores = HashMap::new();
        scores.insert("pii".into(), 0.5);
        let v = fold_score_verdict(&cfg, &scores, true);
        assert!(v.is_failure());
    }

    #[test]
    fn no_category_thresholds_uses_max_for_threshold() {
        let cfg = cfg_with(&[], 0.7);
        let mut scores = HashMap::new();
        scores.insert("pii".into(), 0.95);
        let v = fold_score_verdict(&cfg, &scores, false);
        assert!(v.is_failure());
    }
}
