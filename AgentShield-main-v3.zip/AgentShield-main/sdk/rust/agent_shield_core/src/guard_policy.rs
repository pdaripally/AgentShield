//! Guard policies — the unified gating surface.
//!
//! Two flavors differ only in which detection kinds and action modes
//! they accept:
//!   - **State** (Stage 2): `expression`-only detection; `block`/`warn`.
//!   - **Content** (Stages 1, 3, 4, 5): all detection kinds; all action modes.
//!
//! This module defines the static guard-policy schema. The runtime that
//! evaluates policies lives in [`crate::guard_policy_runtime`].

use serde::{Deserialize, Serialize};

use super::resources::LogBlock;
use crate::selectors::{EndpointSelectorSet, Selector};

// Re-export `EndpointSelector` from selectors so downstream code that
// previously imported it from `guard_policy` keeps working.
pub use crate::selectors::EndpointSelector;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Action {
    Block,
    Redact,
    Warn,
    Append,
    Prepend,
    DeclassifyTo,
}

/// `applies_to:` selector block for guard policies.
///
/// The three axes are OR-joined by resource kind: `tools` selects tool
/// invocations, `agents` selects agent invocations, and `endpoints` selects
/// endpoint invocations. An omitted field does not participate on that axis;
/// only declared axes contribute matches. When the entire `applies_to:` block
/// is omitted (or all three fields are omitted), the policy is unscoped and
/// therefore matches every resource for the stage.
///
/// Tools and agents use the unified string [`Selector`] grammar.
/// Endpoints use [`EndpointSelectorSet`] because endpoint elements carry
/// `{pattern, methods}` rather than bare strings.
#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq)]
#[serde(deny_unknown_fields)]
pub struct AppliesTo {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub tools: Option<Selector>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub agents: Option<Selector>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub endpoints: Option<EndpointSelectorSet>,
}

impl AppliesTo {
    pub fn is_empty(&self) -> bool {
        self.tools.is_none() && self.agents.is_none() && self.endpoints.is_none()
    }
}

/// LLM detection arm of an `evaluate_when[]` entry.
///
/// `prompt_path:` is a load-time-only authoring convenience for
/// referring to a prompt file on disk; the loader reads the file in
/// `walk_extends_inner` (before `parse_yaml_strict` runs) and replaces
/// `prompt_path: <p>` with `prompt: <contents>` in the YAML so that
/// downstream `serde` sees a fully-inlined detection. The runtime
/// guarantee is therefore: **post-load, `prompt_path` is always `None`
/// `prompt` is the inlined text**..
///
/// `#[serde(default)]` on `prompt` allows YAMLs that supply
/// `prompt_path:` instead — the loader's pre-`parse_yaml_strict`
/// inlining pass (B.4.2 in the design notes) replaces it before serde
/// runs. `#[serde(skip_serializing_if = "Option::is_none")]` on
/// `prompt_path` keeps the canonical wire output of a loaded
/// `LlmDetection` clean (no spurious `prompt_path: null`).
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct LlmDetection {
    #[serde(default)]
    pub prompt: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub prompt_path: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub configuration: Option<String>,
}

/// Classifier detection arm.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct ClassifierDetection {
    pub configuration: String,
}

/// The detection kind of an `evaluate_when[]` entry. Exactly one of the
/// variants is set per entry.
#[derive(Debug, Clone, PartialEq)]
pub enum DetectionKind {
    Expression(String),
    Pattern(String),
    Patterns(Vec<String>),
    Llm(LlmDetection),
    Classifier(ClassifierDetection),
}

/// Single entry in an `evaluate_when[]` list.
#[derive(Debug, Clone, PartialEq)]
pub struct EvaluateWhenEntry {
    pub detection: DetectionKind,
    pub reason: String,
    pub action: Option<Action>,
    pub replacement: Option<String>,
    pub text: Option<String>,
    pub paths: Vec<String>,
    pub log: Option<LogBlock>,
}

impl<'de> Deserialize<'de> for EvaluateWhenEntry {
    fn deserialize<D: serde::Deserializer<'de>>(de: D) -> std::result::Result<Self, D::Error> {
        #[derive(Deserialize)]
        #[serde(deny_unknown_fields)]
        struct H {
            #[serde(default)]
            expression: Option<String>,
            #[serde(default)]
            pattern: Option<String>,
            #[serde(default)]
            patterns: Option<Vec<String>>,
            #[serde(default)]
            llm: Option<LlmDetection>,
            #[serde(default)]
            classifier: Option<ClassifierDetection>,
            reason: String,
            #[serde(default)]
            action: Option<Action>,
            #[serde(default)]
            replacement: Option<String>,
            #[serde(default)]
            text: Option<String>,
            #[serde(default)]
            paths: Vec<String>,
            #[serde(default)]
            log: Option<LogBlock>,
        }
        let h = H::deserialize(de)?;

        // Exactly one detection kind.
        let count = [
            h.expression.is_some(),
            h.pattern.is_some(),
            h.patterns.is_some(),
            h.llm.is_some(),
            h.classifier.is_some(),
        ]
        .iter()
        .filter(|b| **b)
        .count();
        if count != 1 {
            return Err(serde::de::Error::custom(format!(
                "evaluate_when[] entry must declare exactly one of \
                 `expression`/`pattern`/`patterns`/`llm`/`classifier` (found {}).1",
                count
            )));
        }

        if h.reason.is_empty() {
            return Err(serde::de::Error::custom(
                "evaluate_when[] entry: `reason` is required",
            ));
        }

        let detection = if let Some(e) = h.expression {
            if e.is_empty() {
                return Err(serde::de::Error::custom(
                    "evaluate_when[].expression must be non-empty",
                ));
            }
            DetectionKind::Expression(e)
        } else if let Some(p) = h.pattern {
            DetectionKind::Pattern(p)
        } else if let Some(ps) = h.patterns {
            if ps.is_empty() {
                return Err(serde::de::Error::custom(
                    "evaluate_when[].patterns must not be empty",
                ));
            }
            DetectionKind::Patterns(ps)
        } else if let Some(l) = h.llm {
            DetectionKind::Llm(l)
        } else {
            DetectionKind::Classifier(h.classifier.unwrap())
        };

        Ok(EvaluateWhenEntry {
            detection,
            reason: h.reason,
            action: h.action,
            replacement: h.replacement,
            text: h.text,
            paths: h.paths,
            log: h.log,
        })
    }
}

impl Serialize for EvaluateWhenEntry {
    fn serialize<S: serde::Serializer>(&self, ser: S) -> std::result::Result<S::Ok, S::Error> {
        use serde::ser::SerializeMap;
        let mut m = ser.serialize_map(None)?;
        match &self.detection {
            DetectionKind::Expression(e) => m.serialize_entry("expression", e)?,
            DetectionKind::Pattern(p) => m.serialize_entry("pattern", p)?,
            DetectionKind::Patterns(ps) => m.serialize_entry("patterns", ps)?,
            DetectionKind::Llm(l) => m.serialize_entry("llm", l)?,
            DetectionKind::Classifier(c) => m.serialize_entry("classifier", c)?,
        }
        m.serialize_entry("reason", &self.reason)?;
        if let Some(a) = &self.action {
            m.serialize_entry("action", a)?;
        }
        if let Some(r) = &self.replacement {
            m.serialize_entry("replacement", r)?;
        }
        if let Some(t) = &self.text {
            m.serialize_entry("text", t)?;
        }
        if !self.paths.is_empty() {
            m.serialize_entry("paths", &self.paths)?;
        }
        if let Some(l) = &self.log {
            m.serialize_entry("log", l)?;
        }
        m.end()
    }
}

/// Per-stage flavor metadata used for shape-validation when we know which
/// stage a guard policy comes from.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum StageFlavor {
    /// Stage 1: input validation; `applies_to:` REJECTED.
    Input,
    /// Stage 2: state validation; `applies_to:` REQUIRED; expression-only.
    State,
    /// Stage 3: tool-execution validation; `applies_to:` optional.
    ToolExecution,
    /// Stage 4: post-tool validation; `applies_to:` optional.
    PostTool,
    /// Stage 5: output validation; `applies_to:` REJECTED.
    Output,
}

impl StageFlavor {
    pub fn applies_to_required(&self) -> bool {
        matches!(self, StageFlavor::State)
    }
    pub fn applies_to_rejected(&self) -> bool {
        matches!(self, StageFlavor::Input | StageFlavor::Output)
    }
    /// State flavor: only `expression` detection allowed.
    pub fn expression_only(&self) -> bool {
        matches!(self, StageFlavor::State)
    }
    /// State flavor: only `block` and `warn` action modes allowed.
    pub fn state_actions_only(&self) -> bool {
        matches!(self, StageFlavor::State)
    }
    /// Stages where `append`/`prepend` are forbidden. Only Stage 3
    /// (tool-execution) accepts mutating-style transforms; every other
    /// stage rejects them at load time.
    pub fn append_prepend_rejected(&self) -> bool {
        !matches!(self, StageFlavor::ToolExecution)
    }
    /// Human-readable stage label for diagnostics.
    pub fn label(&self) -> &'static str {
        match self {
            StageFlavor::Input => "input",
            StageFlavor::State => "state",
            StageFlavor::ToolExecution => "tool_execution",
            StageFlavor::PostTool => "post_tool",
            StageFlavor::Output => "output",
        }
    }
}

fn action_str(a: Action) -> &'static str {
    match a {
        Action::Block => "block",
        Action::Redact => "redact",
        Action::Warn => "warn",
        Action::Append => "append",
        Action::Prepend => "prepend",
        Action::DeclassifyTo => "declassify_to",
    }
}

/// A single guard policy. Stage-specific shape constraints are
/// enforced by the loader after deserialization, since YAML doesn't tell
/// us which stage the entry belongs to.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(deny_unknown_fields)]
pub struct GuardPolicy {
    pub name: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub description: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub applies_to: Option<AppliesTo>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub active_if: Option<String>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub evaluate_when: Vec<EvaluateWhenEntry>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub allowed_when: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub action: Option<Action>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub reason: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub replacement: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub log: Option<LogBlock>,
}

impl GuardPolicy {
    /// Apply per-stage shape constraints. Returns a
    /// human-readable error if the shape doesn't match the flavor.
    pub fn validate_for_stage(&self, flavor: StageFlavor) -> std::result::Result<(), String> {
        if flavor.applies_to_required()
            && self
                .applies_to
                .as_ref()
                .map(|a| a.is_empty())
                .unwrap_or(true)
        {
            return Err(format!(
                "guard policy `{}`: stage requires non-empty `applies_to:`",
                self.name
            ));
        }
        if flavor.applies_to_rejected() && self.applies_to.is_some() {
            return Err(format!(
                "guard policy `{}`: stage rejects `applies_to:`",
                self.name
            ));
        }
        if flavor.expression_only() {
            for (i, e) in self.evaluate_when.iter().enumerate() {
                if !matches!(e.detection, DetectionKind::Expression(_)) {
                    return Err(format!(
                        "guard policy `{}`: state-stage entry [{}] must use `expression:` only",
                        self.name, i
                    ));
                }
            }
        }
        if let Some(a) = self.action {
            if matches!(a, Action::DeclassifyTo) {
                return Err(format!(
                    "guard policy `{}`: action `{}` is not valid in guard policies",
                    self.name,
                    action_str(a)
                ));
            }
        }
        for (i, e) in self.evaluate_when.iter().enumerate() {
            if let Some(a) = e.action {
                if matches!(a, Action::DeclassifyTo) {
                    return Err(format!(
                        "guard policy `{}`: entry [{}] action `{}` is not valid in guard policies",
                        self.name,
                        i,
                        action_str(a)
                    ));
                }
            }
        }
        if flavor.state_actions_only() {
            // Outer action and per-entry actions must be Block or Warn.
            if let Some(a) = self.action {
                if !matches!(a, Action::Block | Action::Warn) {
                    return Err(format!(
                        "guard policy `{}`: state-stage `action:` must be `block` or `warn`",
                        self.name
                    ));
                }
            }
            for (i, e) in self.evaluate_when.iter().enumerate() {
                if let Some(a) = e.action {
                    if !matches!(a, Action::Block | Action::Warn) {
                        return Err(format!(
                            "guard policy `{}`: state-stage entry [{}] action must be `block` or `warn`",
                            self.name, i
                        ));
                    }
                }
            }
        }
        // append/prepend are only valid on Stage 3 (tool-execution).
        // Reject them outright on every other stage. Outer action and
        // every per-entry action are checked.
        if flavor.append_prepend_rejected() {
            if let Some(a) = self.action {
                if matches!(a, Action::Append | Action::Prepend) {
                    return Err(format!(
                        "guard policy `{}`: action `{}` is forbidden on stage `{}` (— append/prepend are Stage 3 only)",
                        self.name, action_str(a), flavor.label()
                    ));
                }
            }
            for (i, e) in self.evaluate_when.iter().enumerate() {
                if let Some(a) = e.action {
                    if matches!(a, Action::Append | Action::Prepend) {
                        return Err(format!(
                            "guard policy `{}`: entry [{}] action `{}` is forbidden on stage `{}` (— append/prepend are Stage 3 only)",
                            self.name, i, action_str(a), flavor.label()
                        ));
                    }
                }
            }
        }
        // append/prepend on Stage 3 entries REQUIRE non-empty
        // `paths:` (you must say where the appended text is inserted) AND
        // a non-empty `text:` (the text to insert). Without these the
        // runtime no-ops silently — fail closed at load time.
        if matches!(flavor, StageFlavor::ToolExecution) {
            for (i, e) in self.evaluate_when.iter().enumerate() {
                if let Some(a) = e.action {
                    if matches!(a, Action::Append | Action::Prepend) {
                        if e.paths.is_empty() {
                            return Err(format!(
                                "guard policy `{}`: entry [{}] action `{}` requires non-empty `paths:`",
                                self.name, i, action_str(a)
                            ));
                        }
                        if e.text.as_ref().map(|t| t.is_empty()).unwrap_or(true) {
                            return Err(format!(
                                "guard policy `{}`: entry [{}] action `{}` requires non-empty `text:`",
                                self.name, i, action_str(a)
                            ));
                        }
                    }
                }
                // every Stage-3 transform `paths:` element MUST
                // start with one of the recognized roots. Before this
                // fix the runtime accepted any string and silently
                // no-opped at apply time when it didn't match a known
                // prefix; that turned `paths: ["@tool.params.body"]`
                // (the spec-form example-2644) into a
                // silent no-op. Validate here so authoring mistakes —
                // including the JSONPath-style `$.body` form that
                // looks plausible but isn't supported — surface at
                // load time.
                for (pi, p) in e.paths.iter().enumerate() {
                    if !is_valid_transform_path(p) {
                        return Err(format!(
                            "guard policy `{}`: entry [{}] `paths[{}]` = `{}` does not start with a recognized root; \
                             expected one of `@tool.params.`, `@endpoint.params.`, `@endpoint.body.`, `@agent.params.`, `@agent.payload.` \
                             (or the legacy non-`@` equivalents)",
                            self.name, i, pi, p
                        ));
                    }
                }
            }
        }
        // +: `action: redact` is only meaningful on entries
        // whose detection produces span output (pattern, patterns, llm,
        // classifier). An `expression:` detection has no span surface, so
        // redact would silently no-op the policy — fail closed at load.
        for (i, e) in self.evaluate_when.iter().enumerate() {
            if let Some(Action::Redact) = e.action {
                if matches!(e.detection, DetectionKind::Expression(_)) {
                    return Err(format!(
                        "guard policy `{}`: entry [{}] uses `action: redact` with `expression:` detection — \
                         redact requires a span-producing detector (`pattern`, `patterns`, `llm`, or `classifier`)",
                        self.name, i
                    ));
                }
            }
        }
        // the redactor `replacement:` is a LITERAL string —
        // capture-group templates (`$N`, `${N}`, `${name}`) are NOT
        // supported. Detecting them at load time prevents the silent
        // "literal `${3}` ends up in the output" footgun where authors
        // writing the common SSN-last-4 preserve pattern got a literal
        // `${3}` instead of group 3 in
        // their output. The only allowed `$` usage is `$$`, which
        // unescapes to a literal `$` at apply time.
        if let Some(r) = &self.replacement {
            if let Err(msg) = validate_redactor_replacement(r) {
                return Err(format!(
                    "guard policy `{}`: top-level `replacement:` — {}",
                    self.name, msg
                ));
            }
        }
        for (i, e) in self.evaluate_when.iter().enumerate() {
            if let Some(r) = &e.replacement {
                if let Err(msg) = validate_redactor_replacement(r) {
                    return Err(format!(
                        "guard policy `{}`: entry [{}] `replacement:` — {}",
                        self.name, i, msg
                    ));
                }
            }
        }
        // every redactor regex MUST compile at load time
        // — a malformed `pattern:` (e.g. `[unclosed`) or an unsupported
        // construct (lookbehind/lookahead like `(?=x)`) silently
        // disabled the redactor at runtime, leaving the PHI un-redacted
        // with no observable signal. The pattern length cap is
        // also enforced here so the load-time error surface mirrors the
        // runtime cache's behavior.
        for (i, e) in self.evaluate_when.iter().enumerate() {
            match &e.detection {
                DetectionKind::Pattern(p) => {
                    if let Err(msg) = validate_redactor_pattern(p) {
                        return Err(format!(
                            "guard policy `{}`: entry [{}] `pattern:` — {}",
                            self.name, i, msg
                        ));
                    }
                }
                DetectionKind::Patterns(ps) => {
                    for (j, p) in ps.iter().enumerate() {
                        if let Err(msg) = validate_redactor_pattern(p) {
                            return Err(format!(
                                "guard policy `{}`: entry [{}] `patterns[{}]` — {}",
                                self.name, i, j, msg
                            ));
                        }
                    }
                }
                _ => {}
            }
        }
        Ok(())
    }
}

/// Stage-3 transform `paths:` must start with one of the
/// recognized template roots. Mirrors the runtime's `strip_root` list
/// in [`crate::guard_policy_runtime::transforms`] so an authoring
/// mistake (typo, unsupported JSONPath-style `$.body`, bare key)
/// surfaces at load time instead of silently no-opping at apply.
///
/// Accepts both the canonical spec-form `@`-prefixed roots (spec /// examples) and the legacy non-`@` forms that earlier runtime
/// versions accepted, kept for backward compatibility.
pub fn is_valid_transform_path(path: &str) -> bool {
    const RECOGNIZED: &[&str] = &[
        // Spec-form — preferred.
        "@tool.params.",
        "@endpoint.params.",
        "@endpoint.body.",
        "@agent.params.",
        "@agent.payload.",
        // Legacy non-@ forms (backward-compat).
        "tool.params.",
        "endpoint.params.",
        "endpoint.body.",
        "agent.params.",
        "agent.payload.",
        "params.",
    ];
    RECOGNIZED.iter().any(|p| path.starts_with(p))
}

/// author-supplied redactor `replacement:` MUST NOT contain
/// regex capture-group templates (`$N`, `${N}`, `${name}`). /// the replacement is a literal string; we accept `$$` as the
/// escape for a literal `$`, but every other `$` usage is rejected at
/// load time to prevent the silent-pass-through footgun.
///
/// Allowed: `"[REDACTED]"`, `"***-**-XXXX"`, `"cost: $$5"` (which
/// becomes literal `"cost: $5"` after `unescape_redactor_replacement`).
///
/// Rejected: `"$1"`, `"${3}"`, `"${name}"`, `"$"` (lone — no escape).
pub fn validate_redactor_replacement(repl: &str) -> std::result::Result<(), String> {
    let bytes = repl.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'$' {
            match bytes.get(i + 1) {
                Some(b'$') => {
                    i += 2;
                    continue;
                }
                Some(c) => {
                    return Err(format!(
                        "redactor template references are not supported (got `${}` at position {}); \
                          the replacement is a literal string. Use `$$` to write a literal `$`; \
                         capture-group references like `$N`, `${{N}}`, or `${{name}}` are NOT supported",
                        *c as char, i
                    ));
                }
                None => {
                    return Err(format!(
                        "redactor replacement ends with a lone `$` at position {} (no escape); \
                         use `$$` to write a literal `$` ",
                        i
                    ));
                }
            }
        }
        i += 1;
    }
    Ok(())
}

/// Apply the `$$` -> `$` unescape rule documented in
/// [`validate_redactor_replacement`]. Pure string replace — never
/// touches non-`$` characters.
pub fn unescape_redactor_replacement(repl: &str) -> String {
    if repl.contains('$') {
        repl.replace("$$", "$")
    } else {
        repl.to_string()
    }
}

/// every author-supplied redactor regex MUST compile (with the
/// same length cap the runtime cache uses). Compilation failures
/// (unbalanced brackets, lookbehind/lookahead, unknown escapes) become
/// load-time errors instead of silent runtime no-ops.
pub fn validate_redactor_pattern(pattern: &str) -> std::result::Result<(), String> {
    if pattern.len() > 500 {
        return Err(format!(
            "pattern length {} exceeds the 500-char limit",
            pattern.len()
        ));
    }
    regex::Regex::new(pattern).map(|_| ()).map_err(|e| {
        format!(
            "regex `{}` failed to compile: {} (the Rust `regex` crate does NOT support \
             lookbehind/lookahead — `(?=...)` / `(?<=...)` are rejected; check brackets and escapes)",
            pattern, e
        )
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_basic_guard_policy() {
        let yaml = "
name: x
applies_to:
  tools: [t1]
evaluate_when:
  - expression: \"y == 1\"
    reason: \"because\"
action: block
";
        let g: GuardPolicy = serde_yaml::from_str(yaml).unwrap();
        assert_eq!(g.name, "x");
        assert_eq!(g.evaluate_when.len(), 1);
    }

    #[test]
    fn rejects_multi_kind_in_evaluate_when_entry() {
        let yaml = "
name: x
evaluate_when:
  - expression: \"y\"
    pattern: \"abc\"
    reason: r
";
        let err = serde_yaml::from_str::<GuardPolicy>(yaml)
            .unwrap_err()
            .to_string();
        assert!(err.contains("exactly one"));
    }

    #[test]
    fn rejects_missing_reason() {
        let yaml = "
name: x
evaluate_when:
  - expression: \"y\"
";
        let err = serde_yaml::from_str::<GuardPolicy>(yaml)
            .unwrap_err()
            .to_string();
        assert!(err.contains("reason"));
    }

    #[test]
    fn validate_for_stage_state_requires_applies_to() {
        let g: GuardPolicy =
            serde_yaml::from_str("name: x\nevaluate_when:\n  - expression: y\n    reason: r\n")
                .unwrap();
        let err = g.validate_for_stage(StageFlavor::State).unwrap_err();
        assert!(err.contains("applies_to"));
    }

    #[test]
    fn validate_for_stage_input_rejects_applies_to() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\napplies_to:\n  tools: [t]\nevaluate_when:\n  - pattern: x\n    reason: r\n",
        )
        .unwrap();
        let err = g.validate_for_stage(StageFlavor::Input).unwrap_err();
        assert!(err.contains("rejects"));
    }

    #[test]
    fn validate_for_stage_state_rejects_pattern() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\napplies_to:\n  tools: [t]\nevaluate_when:\n  - pattern: \"abc\"\n    reason: r\n",
        )
        .unwrap();
        let err = g.validate_for_stage(StageFlavor::State).unwrap_err();
        assert!(err.contains("expression"));
    }

    #[test]
    fn validate_for_stage_input_rejects_append_outer_action() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - pattern: \"abc\"\n    reason: r\naction: append\n",
        )
        .unwrap();
        let err = g.validate_for_stage(StageFlavor::Input).unwrap_err();
        assert!(err.contains("append"), "got: {err}");
        assert!(err.contains("input"), "got: {err}");
    }

    #[test]
    fn validate_for_stage_post_tool_rejects_prepend_entry_action() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - pattern: \"abc\"\n    reason: r\n    action: prepend\n",
        )
        .unwrap();
        let err = g.validate_for_stage(StageFlavor::PostTool).unwrap_err();
        assert!(err.contains("prepend"), "got: {err}");
        assert!(err.contains("post_tool"), "got: {err}");
    }

    #[test]
    fn validate_for_stage_tool_exec_requires_paths_for_append() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - pattern: \"abc\"\n    reason: r\n    action: append\n    text: hi\n",
        )
        .unwrap();
        let err = g
            .validate_for_stage(StageFlavor::ToolExecution)
            .unwrap_err();
        assert!(err.contains("paths"), "got: {err}");
    }

    #[test]
    fn validate_for_stage_tool_exec_requires_text_for_prepend() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - pattern: \"abc\"\n    reason: r\n    action: prepend\n    paths: [\"@tool.params.body\"]\n",
        )
        .unwrap();
        let err = g
            .validate_for_stage(StageFlavor::ToolExecution)
            .unwrap_err();
        assert!(err.contains("text"), "got: {err}");
    }

    #[test]
    fn validate_for_stage_tool_exec_accepts_complete_append() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - pattern: \"abc\"\n    reason: r\n    action: append\n    text: \"hi\"\n    paths: [\"@tool.params.body\"]\n",
        )
        .unwrap();
        g.validate_for_stage(StageFlavor::ToolExecution).unwrap();
    }

    #[test]
    fn validate_for_stage_tool_exec_accepts_legacy_non_at_path() {
        // the non-@ legacy form remains valid for backward
        // compatibility with pre-fix configurations.
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - pattern: \"abc\"\n    reason: r\n    action: append\n    text: \"hi\"\n    paths: [\"tool.params.body\"]\n",
        )
        .unwrap();
        g.validate_for_stage(StageFlavor::ToolExecution).unwrap();
    }

    #[test]
    fn stage3_transform_with_unknown_path_root_rejected_at_load() {
        // previously `paths: ["$.body"]` was accepted at load
        // and silently no-opped at runtime; now load-time validation
        // requires a recognized root.
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - pattern: \"abc\"\n    reason: r\n    action: append\n    text: \"hi\"\n    paths: [\"$.body\"]\n",
        )
        .unwrap();
        let err = g
            .validate_for_stage(StageFlavor::ToolExecution)
            .unwrap_err();
        assert!(err.contains("$.body"), "got: {err}");
        assert!(err.contains("recognized root"), "got: {err}");
        assert!(err.contains("@tool.params."), "got: {err}");
    }

    #[test]
    fn stage3_transform_with_bare_key_path_rejected_at_load() {
        // Plain `body` (no root) is rejected — authors must declare
        // which template namespace the path targets.
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - pattern: \"abc\"\n    reason: r\n    action: redact\n    paths: [\"body\"]\n",
        )
        .unwrap();
        let err = g
            .validate_for_stage(StageFlavor::ToolExecution)
            .unwrap_err();
        assert!(err.contains("recognized root"), "got: {err}");
    }

    #[test]
    fn stage3_transform_with_spec_form_at_prefix_accepted_at_load() {
        // happy path: the spec example uses `@tool.params.body`
        // and load-time validation must accept it.
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - expression: \"true\"\n    reason: r\n    action: append\n    text: \"!\"\n    paths: [\"@tool.params.body\"]\n",
        )
        .unwrap();
        g.validate_for_stage(StageFlavor::ToolExecution).unwrap();
    }

    #[test]
    fn validate_rejects_redact_with_expression_detection() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - expression: \"y == 1\"\n    reason: r\n    action: redact\n",
        )
        .unwrap();
        let err = g.validate_for_stage(StageFlavor::Output).unwrap_err();
        assert!(err.contains("redact"), "got: {err}");
        assert!(err.contains("expression"), "got: {err}");
    }

    // ── Capture-group templates in redactor replacement ───────

    /// exact repro: `replacement: '***-**-${3}'` MUST be rejected
    /// at load time. Before the fix, this loaded fine and the runtime
    /// emitted a literal `${3}` because `apply_redactions` uses
    /// `String::replace_range` (no template substitution), leaving the
    /// last-4-SSN preserve pattern silently broken.
    #[test]
    fn rejects_dollar_brace_capture_reference_in_replacement() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - pattern: '\\\\b(\\\\d{3})-(\\\\d{2})-(\\\\d{4})\\\\b'\n    reason: r\n    action: redact\n    replacement: '***-**-${3}'\n",
        )
        .unwrap();
        let err = g.validate_for_stage(StageFlavor::Output).unwrap_err();
        assert!(err.contains("template"), "got: {err}");
        assert!(err.contains("$$"), "got: {err}");
    }

    /// `$N` (without braces) is also rejected.
    #[test]
    fn rejects_dollar_digit_capture_reference_in_replacement() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - pattern: '\\\\b(\\\\d{3})-(\\\\d{2})-(\\\\d{4})\\\\b'\n    reason: r\n    action: redact\n    replacement: '***-**-$3'\n",
        )
        .unwrap();
        let err = g.validate_for_stage(StageFlavor::Output).unwrap_err();
        assert!(err.contains("template"), "got: {err}");
    }

    /// `${name}` named-capture references are also rejected.
    #[test]
    fn rejects_named_capture_reference_in_replacement() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - pattern: 'abc'\n    reason: r\n    action: redact\n    replacement: '${name}'\n",
        )
        .unwrap();
        let err = g.validate_for_stage(StageFlavor::Output).unwrap_err();
        assert!(err.contains("template"), "got: {err}");
    }

    /// top-level guard-policy `replacement:` is validated too.
    #[test]
    fn rejects_top_level_replacement_template() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - pattern: 'abc'\n    reason: r\n    action: redact\nreplacement: 'first=$1'\n",
        )
        .unwrap();
        let err = g.validate_for_stage(StageFlavor::Output).unwrap_err();
        assert!(err.contains("template"), "got: {err}");
    }

    /// `$$` is the literal-`$` escape. Loads successfully and
    /// `unescape_redactor_replacement` produces the literal output.
    #[test]
    fn accepts_dollar_escape_for_literal_dollar() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - pattern: '\\\\d+'\n    reason: r\n    action: redact\n    replacement: 'cost: $$5'\n",
        )
        .unwrap();
        g.validate_for_stage(StageFlavor::Output).unwrap();
        let raw = g.evaluate_when[0].replacement.as_ref().unwrap();
        assert_eq!(unescape_redactor_replacement(raw), "cost: $5");
    }

    /// replacement with no `$` at all is loaded as a pure
    /// literal.
    #[test]
    fn accepts_replacement_without_dollar() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - pattern: '\\\\d+'\n    reason: r\n    action: redact\n    replacement: 'no_dollar_at_all'\n",
        )
        .unwrap();
        g.validate_for_stage(StageFlavor::Output).unwrap();
        let raw = g.evaluate_when[0].replacement.as_ref().unwrap();
        assert_eq!(unescape_redactor_replacement(raw), "no_dollar_at_all");
    }

    /// a lone `$` at end-of-string is rejected (no escape).
    #[test]
    fn rejects_lone_trailing_dollar() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - pattern: 'abc'\n    reason: r\n    action: redact\n    replacement: 'cost: $'\n",
        )
        .unwrap();
        let err = g.validate_for_stage(StageFlavor::Output).unwrap_err();
        assert!(
            err.contains("lone `$`") || err.contains("template"),
            "got: {err}"
        );
    }

    // ── Malformed/unsupported regex in redactor patterns ──────

    /// exact repro: an unclosed character class MUST be rejected
    /// at load time. Before the fix this loaded fine and the redactor
    /// silently no-op'd at runtime, leaving the PHI un-redacted.
    #[test]
    fn rejects_unclosed_character_class_at_load() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - pattern: '[unclosed'\n    reason: r\n    action: redact\n    replacement: '[X]'\n",
        )
        .unwrap();
        let err = g.validate_for_stage(StageFlavor::Output).unwrap_err();
        assert!(err.contains("failed to compile"), "got: {err}");
    }

    /// Rust's `regex` crate does NOT support
    /// lookbehind/lookahead. A pattern like `(?=x)` MUST be rejected at
    /// load time rather than silently no-op'd at runtime.
    #[test]
    fn rejects_lookahead_at_load() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - pattern: '(?=x)'\n    reason: r\n    action: redact\n    replacement: '[X]'\n",
        )
        .unwrap();
        let err = g.validate_for_stage(StageFlavor::Output).unwrap_err();
        assert!(err.contains("failed to compile"), "got: {err}");
        // The diagnostic must mention the unsupported construct so
        // healthcare-team authors recognize they need to refactor.
        assert!(
            err.contains("lookbehind") || err.contains("look-around") || err.contains("look"),
            "diagnostic should hint at the lookbehind/lookahead limitation; got: {err}"
        );
    }

    /// every pattern in a `patterns:` list is validated.
    #[test]
    fn rejects_invalid_pattern_inside_patterns_list() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - patterns:\n      - 'valid_pattern'\n      - '[unclosed'\n    reason: r\n    action: redact\n    replacement: '[X]'\n",
        )
        .unwrap();
        let err = g.validate_for_stage(StageFlavor::Output).unwrap_err();
        assert!(err.contains("failed to compile"), "got: {err}");
        assert!(
            err.contains("patterns[1]"),
            "should name the failing index; got: {err}"
        );
    }

    /// a valid pattern still loads and applies correctly (the
    /// validation rule does not over-fire).
    #[test]
    fn valid_regex_still_loads() {
        let g: GuardPolicy = serde_yaml::from_str(
            "name: x\nevaluate_when:\n  - pattern: '\\\\b\\\\d{3}-\\\\d{2}-\\\\d{4}\\\\b'\n    reason: r\n    action: redact\n    replacement: '[REDACTED]'\n",
        )
        .unwrap();
        g.validate_for_stage(StageFlavor::Output).unwrap();
    }

    /// pattern length cap mirrors the runtime cap so the
    /// load-time and runtime error surfaces agree.
    #[test]
    fn rejects_pattern_exceeding_length_cap() {
        let long = "a".repeat(501);
        let yaml = format!(
            "name: x\nevaluate_when:\n  - pattern: '{}'\n    reason: r\n    action: redact\n    replacement: '[X]'\n",
            long
        );
        let g: GuardPolicy = serde_yaml::from_str(&yaml).unwrap();
        let err = g.validate_for_stage(StageFlavor::Output).unwrap_err();
        assert!(err.contains("500-char"), "got: {err}");
    }
}
