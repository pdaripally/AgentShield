//! Monotonic clock abstraction for perf instrumentation.
//!
//! Provides a [`Clock`] trait + [`SystemClock`] (production) + a
//! [`mock::MockClock`] (test infrastructure) so that the stage / policy /
//! detection / LLM / classifier timing code added in PR6 can be exercised
//! deterministically.
//!
//! Why a trait rather than calling [`Instant::now`] directly:
//!
//! - Tests need to assert that `KEY_DURATION_MS == 5` after a controlled
//!   `clock.advance(Duration::from_millis(5))` — impossible with real
//!   [`Instant::now`].
//! - The same pattern is required by the AC8 byte-identity test in PR6
//!   (compare verdicts across `PerfTelemetry::Off` vs `Full` runtimes —
//!   timing must not leak into the enforcement path).
//!
//! This is **monotonic** time only (perf measurement). The existing
//! `ClockFn = Arc<dyn Fn() -> DateTime<Utc>>` pattern in [`event_bus`] and
//! [`lifetime_tracker`] handles wall-clock concerns (event expiry, lifetime
//! tracking) and is intentionally untouched.
//!
//! [`event_bus`]: crate::event_bus
//! [`lifetime_tracker`]: crate::lifetime_tracker

use std::sync::Arc;
use std::time::Instant;

/// A monotonic clock used for perf instrumentation.
///
/// Implementations must be `Send + Sync` so they can be embedded in
/// `Arc`-shared runtime state.
pub trait Clock: Send + Sync + std::fmt::Debug {
    /// Returns the current monotonic instant.
    fn now(&self) -> Instant;
}

/// Production clock backed by [`Instant::now`].
#[derive(Debug, Default, Clone, Copy)]
pub struct SystemClock;

impl Clock for SystemClock {
    fn now(&self) -> Instant {
        Instant::now()
    }
}

impl SystemClock {
    /// Construct a new [`SystemClock`]. Equivalent to
    /// [`SystemClock::default`].
    pub const fn new() -> Self {
        SystemClock
    }
}

/// Convenience: an `Arc<dyn Clock>` wrapping a [`SystemClock`].
pub fn system_clock() -> Arc<dyn Clock> {
    Arc::new(SystemClock::new())
}

/// Mock clock used by tests. Lives in its own submodule so production
/// code that imports the [`clock`](self) module does not accidentally
/// reach for it.
pub mod mock {
    use super::Clock;
    use std::sync::Mutex;
    use std::time::{Duration, Instant};

    /// A controllable monotonic clock for tests.
    ///
    /// Constructs an internal base [`Instant`] at creation time and
    /// returns `base + advance_counter` from [`Clock::now`]. Calling
    /// [`MockClock::advance`] increases the counter; the clock never
    /// goes backwards.
    ///
    /// ```ignore
    /// use std::time::Duration;
    /// use agent_shield_core::clock::{Clock, mock::MockClock};
    ///
    /// let clock = MockClock::new();
    /// let t0 = clock.now();
    /// clock.advance(Duration::from_millis(5));
    /// let t1 = clock.now();
    /// assert_eq!(t1 - t0, Duration::from_millis(5));
    /// ```
    #[derive(Debug)]
    pub struct MockClock {
        base: Instant,
        offset: Mutex<Duration>,
    }

    impl MockClock {
        /// Construct a new [`MockClock`] at offset `Duration::ZERO`.
        pub fn new() -> Self {
            Self {
                base: Instant::now(),
                offset: Mutex::new(Duration::ZERO),
            }
        }

        /// Advance the clock by `d`. Subsequent calls to [`Clock::now`]
        /// will reflect the new offset.
        pub fn advance(&self, d: Duration) {
            let mut g = self.offset.lock().expect("MockClock offset poisoned");
            *g = g
                .checked_add(d)
                .expect("MockClock offset overflowed Duration::MAX");
        }

        /// Returns the current accumulated offset since construction.
        pub fn elapsed(&self) -> Duration {
            *self.offset.lock().expect("MockClock offset poisoned")
        }
    }

    impl Default for MockClock {
        fn default() -> Self {
            Self::new()
        }
    }

    impl Clock for MockClock {
        fn now(&self) -> Instant {
            self.base + self.elapsed()
        }
    }
}

#[cfg(test)]
mod tests {
    use super::mock::MockClock;
    use super::*;
    use std::time::Duration;

    #[test]
    fn system_clock_advances_monotonically() {
        let clock = SystemClock::new();
        let t0 = clock.now();
        // Busy-wait briefly to ensure the monotonic clock ticks at least
        // once; `Instant::now()` resolution is typically nanoseconds, so
        // even a tight loop will produce a non-zero delta.
        for _ in 0..1_000 {
            std::hint::black_box(());
        }
        let t1 = clock.now();
        assert!(t1 >= t0, "SystemClock went backwards: t1 < t0");
    }

    #[test]
    fn mock_clock_advance_returns_exact_value() {
        let clock = MockClock::new();
        let t0 = clock.now();
        clock.advance(Duration::from_millis(5));
        let t1 = clock.now();
        assert_eq!(t1 - t0, Duration::from_millis(5));
    }

    #[test]
    fn mock_clock_advance_accumulates() {
        let clock = MockClock::new();
        let t0 = clock.now();
        clock.advance(Duration::from_millis(3));
        clock.advance(Duration::from_millis(7));
        let t1 = clock.now();
        assert_eq!(t1 - t0, Duration::from_millis(10));
    }

    #[test]
    fn mock_clock_never_goes_backwards() {
        let clock = MockClock::new();
        let t0 = clock.now();
        clock.advance(Duration::from_millis(2));
        let t1 = clock.now();
        // No advance between t1 and t2; should be equal.
        let t2 = clock.now();
        assert_eq!(t1, t2);
        assert!(t2 >= t0);
    }

    #[test]
    fn system_clock_is_send_sync() {
        fn assert_send_sync<T: Send + Sync>() {}
        assert_send_sync::<SystemClock>();
    }

    #[test]
    fn mock_clock_is_send_sync() {
        fn assert_send_sync<T: Send + Sync>() {}
        assert_send_sync::<MockClock>();
    }

    #[test]
    fn system_clock_factory_returns_arc_dyn() {
        let clock = system_clock();
        let t0 = clock.now();
        let t1 = clock.now();
        assert!(t1 >= t0);
    }
}
