//! Closure-based `kind: human` handler.
//!
//! Wraps a host-supplied closure as a [`HumanResolver`]. The closure
//! receives the [`HumanResolveRequest`] verbatim and returns a
//! [`ResolverResponse`].

use std::sync::Arc;

use crate::resolver::ResolverResponse;
use crate::resolver_runtime::{HumanResolveRequest, HumanResolver, ResolverRuntimeError};

type SyncCallback = dyn Fn(HumanResolveRequest) -> ResolverResponse + Send + Sync;

/// `kind: human` handler backed by a host-supplied closure.
pub struct CallbackApprovalHandler {
    callback: Arc<SyncCallback>,
}

impl CallbackApprovalHandler {
    /// Construct from a synchronous closure that receives the full
    /// request payload (resource refs, requested key, timeout, …) and
    /// returns the structured response.
    pub fn new<F>(f: F) -> Self
    where
        F: Fn(HumanResolveRequest) -> ResolverResponse + Send + Sync + 'static,
    {
        Self {
            callback: Arc::new(f),
        }
    }
}

impl HumanResolver for CallbackApprovalHandler {
    fn resolve(&self, req: HumanResolveRequest) -> Result<ResolverResponse, ResolverRuntimeError> {
        Ok((self.callback)(req))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::resolver::ResolverDecision;
    use serde_json::Map;
    use std::collections::HashMap;

    fn req(tool: &str) -> HumanResolveRequest {
        HumanResolveRequest {
            request_id: "r1".into(),
            variable: Some("v".into()),
            resource_kind: None,
            resource_name: Some(tool.into()),
            resource_params: Some(serde_json::json!({"amount": 100})),
            invocation_hash: Some(format!("hash-{tool}")),
            approval_nonce: format!("nonce-{tool}"),
            session_id: None,
            prompt: Some("approve?".into()),
            reason: Some("policy".into()),
            context: Map::new(),
            requested_key: None,
            timeout_ms: None,
        }
    }

    #[test]
    fn closure_returns_allow() {
        let h = CallbackApprovalHandler::new(|_req| ResolverResponse {
            decision: ResolverDecision::Allow,
            value: Some(serde_json::json!(true)),
            set_variables: HashMap::new(),
            reason: None,
        });
        let r = h.resolve(req("send")).unwrap();
        assert_eq!(r.decision, ResolverDecision::Allow);
    }

    #[test]
    fn closure_can_set_variables() {
        let h = CallbackApprovalHandler::new(|_req| {
            let mut sets = HashMap::new();
            sets.insert("approver".into(), serde_json::json!("alice"));
            ResolverResponse {
                decision: ResolverDecision::Allow,
                value: Some(serde_json::json!(true)),
                set_variables: sets,
                reason: None,
            }
        });
        let r = h.resolve(req("send")).unwrap();
        assert_eq!(
            r.set_variables.get("approver"),
            Some(&serde_json::json!("alice")),
        );
    }
}
