//! Built-in `kind: human` resolver handlers.
//!
//! These ship as public handler implementations that hosts can choose
//! at runtime via [`crate::runtime::RuntimeBuilder::register_human_resolver`].
//! YAML no longer names bundled providers; policy declares only
//! `kind: human` plus the prompt/context, while deployment code decides
//! whether to install [`AutoRejectHandler`], [`ConsoleApprovalHandler`],
//! or a [`CallbackApprovalHandler`].

mod auto_reject;
mod callback;
pub mod console;

pub use auto_reject::AutoRejectHandler;
pub use callback::CallbackApprovalHandler;
pub use console::{ConsoleApprovalHandler, PromptReader, StdinPromptReader};

// Re-export for ergonomic consumption.
pub use crate::resolver::{ResolverDecision, ResolverResponse};
pub use crate::resolver_runtime::{
    HumanRegistry, HumanResolveRequest, HumanResolver, HumanResolverFn,
};
