//! Console-based `kind: human` handler — prompts the operator on
//! stdin/stdout.
//!
//! Menu:
//!
//! ```text
//! (a)llow — allow this and future calls in this session
//! (o)nce — allow this call only
//! (b)lock — block this and future calls in this session
//! (n)o — block this call only
//! (c)ancel — cancel the operation
//! ```
//!
//! Because `Resolver::Human` carries a single `lifetime:` declared at
//! YAML load time (so handlers cannot dynamically scope a decision to
//! "session" vs "call"), this handler implements the
//! "always allow / always block" behaviour internally: it caches the
//! `a` / `b` choice per `(session_id, variable_name)` and short-
//! circuits subsequent calls without re-prompting the operator. The
//! `o` / `n` choices are not cached. Timeout always blocks
//! (fail-closed).
//!
//! ## Stdin abstraction for testing
//!
//! Stdin is read through the [`PromptReader`] trait so tests can
//! inject scripted input. Production code uses
//! [`StdinPromptReader`].

use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use std::time::Duration;

use crate::observability::{redact_display, redact_value_display, RawCategory, TelemetryPolicy};
use crate::resolver::{ResolverDecision, ResolverResponse};
use crate::resolver_runtime::{HumanResolveRequest, HumanResolver, ResolverRuntimeError};

const DEFAULT_TIMEOUT: Duration = Duration::from_secs(60);

/// Cache key for `ConsoleApprovalHandler`'s "always allow / always
/// block" memo. The five components are the same identifying tuple
/// the resolver runtime uses to scope a `kind: human` decision:
/// `(session_id, variable_name, resolver_id, prompt, lifetime)`.
/// Extracted as a type alias to silence clippy's `type_complexity`
/// lint on the `Mutex<HashMap<...>>` field.
type ApprovalCacheKey = (String, String, String, String, String);

/// Cache map type for the approval handler's per-session memo. See
/// [`ApprovalCacheKey`] for the tuple shape.
type ApprovalCache = HashMap<ApprovalCacheKey, ResolverDecision>;

/// Trait that reads one decision token from stdin (or a stub).
/// Returns `None` on EOF / timeout.
pub trait PromptReader: Send + Sync {
    fn read_decision(&self, timeout: Duration) -> Option<String>;
}

/// Production reader — blocks on stdin in a worker thread, with a
/// timeout via [`std::sync::mpsc::Receiver::recv_timeout`].
pub struct StdinPromptReader;

impl PromptReader for StdinPromptReader {
    fn read_decision(&self, timeout: Duration) -> Option<String> {
        let (tx, rx) = std::sync::mpsc::channel::<String>();
        std::thread::spawn(move || {
            let mut input = String::new();
            if std::io::stdin().read_line(&mut input).is_ok() {
                let _ = tx.send(input);
            }
        });
        rx.recv_timeout(timeout).ok()
    }
}

/// Console-based `kind: human` handler.
pub struct ConsoleApprovalHandler {
    timeout: Duration,
    reader: Arc<dyn PromptReader>,
    /// `(session_id, variable_name, resolver_id, prompt, lifetime)` →
    /// cached "always" decision. Populated on `a` / `b`; consulted
    /// before re-prompting.
    cache: Mutex<ApprovalCache>,
    /// Telemetry redaction policy applied to the stderr-bound
    /// approval prompt. The default ([`TelemetryPolicy::fail_closed`])
    /// suppresses every `RawContent` category so tool params and the
    /// approval prompt text are replaced with a `<redacted...: N
    /// bytes>` marker on stderr — capture pipelines (journald, Docker
    /// logs, CI runners) MUST NOT see raw payloads from this
    /// handler. Hosts that intentionally want a verbose console
    /// (interactive operator on a real tty, no log shipper) can opt
    /// in via [`ConsoleApprovalHandler::with_telemetry_policy`].
    telemetry_policy: TelemetryPolicy,
}

impl Default for ConsoleApprovalHandler {
    fn default() -> Self {
        Self::new()
    }
}

impl ConsoleApprovalHandler {
    /// Construct with the default 60-second timeout, stdin reader, and
    /// fail-closed redaction policy.
    pub fn new() -> Self {
        Self {
            timeout: DEFAULT_TIMEOUT,
            reader: Arc::new(StdinPromptReader),
            cache: Mutex::new(HashMap::new()),
            telemetry_policy: TelemetryPolicy::fail_closed(),
        }
    }

    /// Construct with a custom timeout.
    pub fn with_timeout(timeout: Duration) -> Self {
        Self {
            timeout,
            reader: Arc::new(StdinPromptReader),
            cache: Mutex::new(HashMap::new()),
            telemetry_policy: TelemetryPolicy::fail_closed(),
        }
    }

    /// Construct with a custom [`PromptReader`] — tests use
    /// [`ScriptedReader`] to feed predetermined input.
    pub fn with_reader(timeout: Duration, reader: Arc<dyn PromptReader>) -> Self {
        Self {
            timeout,
            reader,
            cache: Mutex::new(HashMap::new()),
            telemetry_policy: TelemetryPolicy::fail_closed(),
        }
    }

    /// Override the redaction policy applied to the stderr-bound
    /// approval prompt. The default is [`TelemetryPolicy::fail_closed`],
    /// which suppresses every `RawContent` category and replaces tool
    /// params + approval prompt text with a `<redacted...: N bytes>`
    /// marker. Hosts that genuinely need a verbose console (e.g. an
    /// interactive operator on a real tty with no log capture) may
    /// opt into specific categories via
    /// [`TelemetryPolicy::allow_all_raw`] or by toggling individual
    /// flags on [`TelemetryPolicy::allow_raw`].
    ///
    /// This is a privacy lever, not a functional one: the approval
    /// decision flow (cache, timeout, fail-closed semantics) is
    /// unaffected.
    pub fn with_telemetry_policy(mut self, policy: TelemetryPolicy) -> Self {
        self.telemetry_policy = policy;
        self
    }

    fn cache_key(&self, req: &HumanResolveRequest) -> (String, String, String, String, String) {
        // the "always" cache MUST be keyed by the SESSION the
        // user is approving from, not by `request_id`. `request_id` is
        // regenerated by the resolver runtime for every dispatch (see
        // `auto_resolution.rs::rebuild_context`), so keying by it
        // means the cache can never hit: the user's "always" choice
        // would be re-prompted on every subsequent call. The session
        // id is stable for the lifetime of the agent session, which
        // is the natural scope for "always for this session".
        let session = req
            .session_id
            .as_ref()
            .map(|s| s.as_str().to_string())
            .unwrap_or_default();
        (
            session,
            req.variable.clone().unwrap_or_default(),
            req.resource_name.clone().unwrap_or_default(),
            req.invocation_hash.clone().unwrap_or_else(|| {
                req.resource_params
                    .as_ref()
                    .map(|value| value.to_string())
                    .unwrap_or_default()
            }),
            req.requested_key
                .as_ref()
                .map(|value| value.to_string())
                .unwrap_or_default(),
        )
    }

    fn lookup_cached(&self, req: &HumanResolveRequest) -> Option<ResolverDecision> {
        self.cache
            .lock()
            .unwrap()
            .get(&self.cache_key(req))
            .copied()
    }

    fn cache_decision(&self, req: &HumanResolveRequest, decision: ResolverDecision) {
        self.cache
            .lock()
            .unwrap()
            .insert(self.cache_key(req), decision);
    }

    /// Build the operator-facing prompt text. Split from
    /// [`Self::print_prompt`] so tests can assert on the formatted
    /// output without capturing stderr. Public so integration tests
    /// in downstream crates can pin the redaction contract.
    ///
    /// **Redaction**: `params` and `prompt` are `RawContent(ApprovalPayloads)`
    /// per `observability::classification`. They are redacted with
    /// [`redact_display`] / [`redact_value_display`] against the
    /// handler's [`TelemetryPolicy`] (default: fail-closed). The
    /// `resource`, `reason`, and `invocation_hash` fields are
    /// classified `Derived` / `Metadata` / `Identifier` respectively
    /// and are kept verbatim — they are the audit contract.
    pub fn format_prompt(&self, req: &HumanResolveRequest) -> String {
        let policy = &self.telemetry_policy;
        let tool = req
            .resource_name
            .as_deref()
            .unwrap_or_else(|| req.variable.as_deref().unwrap_or("(unknown)"));
        let params = req
            .resource_params
            .as_ref()
            .map(|v| redact_value_display(v, RawCategory::ApprovalPayloads, policy))
            .unwrap_or_else(|| "(none)".into());
        let reason = req.reason.as_deref().unwrap_or("");
        let prompt_raw = req.prompt.as_deref().unwrap_or("Approval required");
        let prompt = redact_display(prompt_raw, RawCategory::ApprovalPayloads, policy);

        let mut out = String::new();
        out.push_str("\n[AGENT SHIELD] Approval required:\n");
        out.push_str(&format!("  Resource: {tool}\n"));
        out.push_str(&format!("  Params:   {params}\n"));
        if let Some(hash) = req.invocation_hash.as_deref() {
            out.push_str(&format!("  Invocation hash: {hash}\n"));
        }
        if !reason.is_empty() {
            out.push_str(&format!("  Reason:   {reason}\n"));
        }
        out.push_str(&format!("  Prompt:   {prompt}\n"));
        out.push('\n');
        out.push_str("  (a)llow     — allow this and future calls\n");
        out.push_str("  (o)nce      — allow this call only\n");
        out.push_str("  (b)lock     — block this and future calls\n");
        out.push_str("  (n)o        — block this call only\n");
        out.push_str("  (c)ancel    — cancel the operation\n");
        out.push_str("\n  Decision: ");
        out
    }

    fn print_prompt(&self, req: &HumanResolveRequest) {
        eprint!("{}", self.format_prompt(req));
    }
}

impl HumanResolver for ConsoleApprovalHandler {
    fn resolve(&self, req: HumanResolveRequest) -> Result<ResolverResponse, ResolverRuntimeError> {
        if let Some(cached) = self.lookup_cached(&req) {
            return Ok(wrap_decision(
                cached,
                Some("console: cached session decision".into()),
            ));
        }

        self.print_prompt(&req);
        let timeout = req
            .timeout_ms
            .map(|ms| Duration::from_millis(ms as u64))
            .unwrap_or(self.timeout);
        let input = match self.reader.read_decision(timeout) {
            Some(s) => s,
            None => {
                eprintln!("  [timed out — fail-closed deny]");
                return Ok(wrap_decision(
                    ResolverDecision::Deny,
                    Some("console: timed out (fail-closed)".into()),
                ));
            }
        };

        Ok(match input.trim().to_lowercase().as_str() {
            "a" | "allow" => {
                self.cache_decision(&req, ResolverDecision::Allow);
                wrap_decision(
                    ResolverDecision::Allow,
                    Some("console: allow always".into()),
                )
            }
            "o" | "once" | "y" | "yes" => {
                wrap_decision(ResolverDecision::Allow, Some("console: allow once".into()))
            }
            "b" | "block" | "x" => {
                self.cache_decision(&req, ResolverDecision::Deny);
                wrap_decision(ResolverDecision::Deny, Some("console: block always".into()))
            }
            "n" | "no" | "r" | "reject" => {
                wrap_decision(ResolverDecision::Deny, Some("console: block once".into()))
            }
            "c" | "cancel" | "cancelled" => wrap_decision(
                ResolverDecision::Cancelled,
                Some("console: cancelled by operator".into()),
            ),
            other => {
                eprintln!("  [unrecognized input `{other}` — fail-closed deny]");
                wrap_decision(
                    ResolverDecision::Deny,
                    Some(format!(
                        "console: unrecognized input `{other}` (fail-closed)"
                    )),
                )
            }
        })
    }
}

fn wrap_decision(decision: ResolverDecision, reason: Option<String>) -> ResolverResponse {
    let value = match decision {
        ResolverDecision::Allow => Some(serde_json::json!(true)),
        ResolverDecision::Deny | ResolverDecision::Cancelled => None,
    };
    ResolverResponse {
        decision,
        value,
        set_variables: HashMap::new(),
        reason,
    }
}

// ── Test harness ────────────────────────────────────────────────────

/// Test reader that returns a queue of pre-scripted strings.
pub struct ScriptedReader {
    inner: Mutex<Vec<String>>,
}

impl ScriptedReader {
    pub fn new<I, S>(lines: I) -> Self
    where
        I: IntoIterator<Item = S>,
        S: Into<String>,
    {
        Self {
            inner: Mutex::new(lines.into_iter().map(Into::into).collect()),
        }
    }
}

impl PromptReader for ScriptedReader {
    fn read_decision(&self, _timeout: Duration) -> Option<String> {
        let mut q = self.inner.lock().unwrap();
        if q.is_empty() {
            None
        } else {
            Some(q.remove(0))
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::Map;

    fn req(request_id: &str, variable: &str) -> HumanResolveRequest {
        HumanResolveRequest {
            request_id: request_id.into(),
            variable: Some(variable.into()),
            resource_kind: None,
            resource_name: Some("send".into()),
            resource_params: Some(serde_json::json!({"amount": 100})),
            invocation_hash: Some(format!("hash-{request_id}-{variable}")),
            approval_nonce: format!("nonce-{request_id}-{variable}"),
            session_id: None,
            prompt: Some("approve?".into()),
            reason: Some("policy".into()),
            context: Map::new(),
            requested_key: None,
            timeout_ms: None,
        }
    }

    /// Build a request that fixes the invocation-hash and variable
    /// (so the cache key's hash slot is stable) but binds it to a
    /// caller-supplied session id and request id.
    fn req_for_session(
        request_id: &str,
        variable: &str,
        session_id: Option<&str>,
    ) -> HumanResolveRequest {
        HumanResolveRequest {
            request_id: request_id.into(),
            variable: Some(variable.into()),
            resource_kind: None,
            resource_name: Some("send".into()),
            resource_params: Some(serde_json::json!({"amount": 100})),
            // Fixed across distinct request_ids so the cache key only
            // varies on the session slot.
            invocation_hash: Some(format!("hash-fixed-{variable}")),
            approval_nonce: format!("nonce-fixed-{variable}"),
            session_id: session_id.map(crate::session_id::SessionId::new),
            prompt: Some("approve?".into()),
            reason: Some("policy".into()),
            context: Map::new(),
            requested_key: None,
            timeout_ms: None,
        }
    }

    #[test]
    fn allow_once_returns_allow_no_cache() {
        let reader = Arc::new(ScriptedReader::new(["o\n", "o\n"]));
        let h = ConsoleApprovalHandler::with_reader(Duration::from_secs(1), reader);
        // Two distinct request ids — each prompts.
        let r1 = h.resolve(req("r1", "v")).unwrap();
        assert_eq!(r1.decision, ResolverDecision::Allow);
        let r2 = h.resolve(req("r2", "v")).unwrap();
        assert_eq!(r2.decision, ResolverDecision::Allow);
    }

    #[test]
    fn allow_always_caches_per_session() {
        let reader = Arc::new(ScriptedReader::new(["a\n"]));
        let h = ConsoleApprovalHandler::with_reader(Duration::from_secs(1), reader);
        // Same request id ⇒ second call hits cache (no second script line needed).
        let r1 = h.resolve(req("r-session", "v")).unwrap();
        assert_eq!(r1.decision, ResolverDecision::Allow);
        let r2 = h.resolve(req("r-session", "v")).unwrap();
        assert_eq!(r2.decision, ResolverDecision::Allow);
        assert!(r2.reason.unwrap().contains("cached"));
    }

    #[test]
    fn block_always_caches_per_session() {
        let reader = Arc::new(ScriptedReader::new(["b\n"]));
        let h = ConsoleApprovalHandler::with_reader(Duration::from_secs(1), reader);
        let r1 = h.resolve(req("r-blk", "v")).unwrap();
        assert_eq!(r1.decision, ResolverDecision::Deny);
        let r2 = h.resolve(req("r-blk", "v")).unwrap();
        assert_eq!(r2.decision, ResolverDecision::Deny);
    }

    #[test]
    fn block_once_does_not_cache() {
        let reader = Arc::new(ScriptedReader::new(["n\n", "o\n"]));
        let h = ConsoleApprovalHandler::with_reader(Duration::from_secs(1), reader);
        let r1 = h.resolve(req("r-once", "v")).unwrap();
        assert_eq!(r1.decision, ResolverDecision::Deny);
        // No cache → second call reads next line, returns Allow.
        let r2 = h.resolve(req("r-once", "v")).unwrap();
        assert_eq!(r2.decision, ResolverDecision::Allow);
    }

    #[test]
    fn cancel_returns_cancelled() {
        let reader = Arc::new(ScriptedReader::new(["c\n"]));
        let h = ConsoleApprovalHandler::with_reader(Duration::from_secs(1), reader);
        let r = h.resolve(req("r1", "v")).unwrap();
        assert_eq!(r.decision, ResolverDecision::Cancelled);
    }

    #[test]
    fn timeout_is_fail_closed() {
        // Empty queue → reader returns None → handler treats as timeout.
        let reader = Arc::new(ScriptedReader::new::<[&str; 0], &str>([]));
        let h = ConsoleApprovalHandler::with_reader(Duration::from_millis(10), reader);
        let r = h.resolve(req("r1", "v")).unwrap();
        assert_eq!(r.decision, ResolverDecision::Deny);
        assert!(r.reason.unwrap().contains("timed out"));
    }

    #[test]
    fn unrecognized_input_is_fail_closed() {
        let reader = Arc::new(ScriptedReader::new(["maybe\n"]));
        let h = ConsoleApprovalHandler::with_reader(Duration::from_secs(1), reader);
        let r = h.resolve(req("r1", "v")).unwrap();
        assert_eq!(r.decision, ResolverDecision::Deny);
        assert!(r.reason.unwrap().contains("unrecognized"));
    }

    fn req_with_hash(request_id: &str, variable: &str, hash: &str) -> HumanResolveRequest {
        let mut request = req(request_id, variable);
        request.invocation_hash = Some(hash.into());
        request.approval_nonce = format!("nonce-{hash}");
        request
    }

    #[test]
    fn allow_always_cache_is_bound_to_invocation_hash() {
        let reader = Arc::new(ScriptedReader::new([
            "a
", "n
",
        ]));
        let h = ConsoleApprovalHandler::with_reader(Duration::from_secs(1), reader);
        let r1 = h
            .resolve(req_with_hash("session", "v", "hash-original"))
            .unwrap();
        assert_eq!(r1.decision, ResolverDecision::Allow);
        let r2 = h
            .resolve(req_with_hash("session", "v", "hash-tampered"))
            .unwrap();
        assert_eq!(r2.decision, ResolverDecision::Deny);
        assert!(!r2.reason.unwrap_or_default().contains("cached"));
    }

    #[test]
    fn block_always_cache_is_bound_to_invocation_hash() {
        let reader = Arc::new(ScriptedReader::new([
            "b
", "o
",
        ]));
        let h = ConsoleApprovalHandler::with_reader(Duration::from_secs(1), reader);
        let r1 = h
            .resolve(req_with_hash("session", "v", "hash-blocked"))
            .unwrap();
        assert_eq!(r1.decision, ResolverDecision::Deny);
        let r2 = h
            .resolve(req_with_hash("session", "v", "hash-other"))
            .unwrap();
        assert_eq!(r2.decision, ResolverDecision::Allow);
    }

    #[test]
    fn distinct_variables_have_separate_caches() {
        let reader = Arc::new(ScriptedReader::new(["a\n", "b\n"]));
        let h = ConsoleApprovalHandler::with_reader(Duration::from_secs(1), reader);
        let r1 = h.resolve(req("r1", "var_a")).unwrap(); // a → Allow + cache
        assert_eq!(r1.decision, ResolverDecision::Allow);
        let r2 = h.resolve(req("r1", "var_b")).unwrap(); // b → Deny + cache (different var)
        assert_eq!(r2.decision, ResolverDecision::Deny);
        // Re-asking var_a still returns the cached Allow.
        let r3 = h.resolve(req("r1", "var_a")).unwrap();
        assert_eq!(r3.decision, ResolverDecision::Allow);
    }

    /// regression: the "always" cache MUST be keyed by SESSION,
    /// not by `request_id`. The runtime regenerates `request_id` on
    /// every dispatch (see `auto_resolution::rebuild_context`), so a
    /// request-id-keyed cache could never hit and the user would be
    /// re-prompted for every `policy: always` decision.
    ///
    /// Scenario: same session, same variable, same invocation hash,
    /// but two different `request_id`s. After the user picks "a"
    /// (always allow) on the first call, the second call MUST hit the
    /// cache and resolve without consulting the reader.
    #[test]
    fn always_cache_keyed_by_session_not_request_id() {
        // Single reader line — if the cache misses on the second call
        // the handler will block on an empty reader and fail closed
        // with a timeout, NOT return Allow.
        let reader = Arc::new(ScriptedReader::new(["a\n"]));
        let h = ConsoleApprovalHandler::with_reader(Duration::from_secs(1), reader);

        // Different `request_id`s, same session_id, same variable.
        let r1 = h
            .resolve(req_for_session("req-first", "v", Some("sess-A")))
            .unwrap();
        assert_eq!(r1.decision, ResolverDecision::Allow);

        let r2 = h
            .resolve(req_for_session(
                "req-second-different-id",
                "v",
                Some("sess-A"),
            ))
            .unwrap();
        assert_eq!(
            r2.decision,
            ResolverDecision::Allow,
            ": cache must be keyed by session_id, not request_id; got: {:?}",
            r2
        );
        assert!(
            r2.reason.clone().unwrap_or_default().contains("cached"),
            "second call must hit the cache; reason was: {:?}",
            r2.reason
        );
    }

    /// distinct sessions MUST have distinct cache scopes.
    /// User-A's "always allow" in session-A MUST NOT carry over into
    /// session-B.
    #[test]
    fn always_cache_is_isolated_across_sessions() {
        // Two reader lines: "a" for session A, "n" for session B. A
        // collision (false sharing across sessions) would let session
        // B inherit session A's Allow, never consult the reader, and
        // return Allow — the assertion below would fail.
        let reader = Arc::new(ScriptedReader::new(["a\n", "n\n"]));
        let h = ConsoleApprovalHandler::with_reader(Duration::from_secs(1), reader);

        let r_a = h
            .resolve(req_for_session("any", "v", Some("sess-A")))
            .unwrap();
        assert_eq!(r_a.decision, ResolverDecision::Allow);

        let r_b = h
            .resolve(req_for_session("any", "v", Some("sess-B")))
            .unwrap();
        assert_eq!(
            r_b.decision,
            ResolverDecision::Deny,
            ": distinct sessions must NOT share approval cache entries"
        );
    }
}
