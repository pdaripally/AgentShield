//! Auto-reject `kind: human` handler — every approval request denies.

use std::collections::HashMap;

use crate::resolver::{ResolverDecision, ResolverResponse};
use crate::resolver_runtime::{HumanResolveRequest, HumanResolver, ResolverRuntimeError};

/// Always returns `Deny`. Useful for tests and environments where no
/// human-approval channel is wired (CI, deterministic regression
/// suites, locked-down production deployments).
#[derive(Debug, Clone, Copy, Default)]
pub struct AutoRejectHandler;

impl HumanResolver for AutoRejectHandler {
    fn resolve(&self, _req: HumanResolveRequest) -> Result<ResolverResponse, ResolverRuntimeError> {
        Ok(ResolverResponse {
            decision: ResolverDecision::Deny,
            value: None,
            set_variables: HashMap::new(),
            reason: Some("auto_reject: human approval channel disabled".into()),
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::Map;

    fn req() -> HumanResolveRequest {
        HumanResolveRequest {
            request_id: "r1".into(),
            variable: Some("v".into()),
            resource_kind: None,
            resource_name: None,
            resource_params: None,
            invocation_hash: None,
            approval_nonce: "nonce".into(),
            session_id: None,
            prompt: Some("approve?".into()),
            reason: None,
            context: Map::new(),
            requested_key: None,
            timeout_ms: None,
        }
    }

    #[test]
    fn always_denies() {
        let h = AutoRejectHandler;
        let r = h.resolve(req()).unwrap();
        assert_eq!(r.decision, ResolverDecision::Deny);
        assert!(r.reason.unwrap().contains("auto_reject"));
    }
}
