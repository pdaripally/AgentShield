//! Load-time errors for the guardrails loader.
//!
//! Every error preserves enough provenance (file path + serde-yaml line/column
//! when available) to point the author at the offending input.

#![allow(clippy::result_large_err)]

use std::path::PathBuf;

use serde::Serialize;
use thiserror::Error;

/// A source location used to enrich error messages.
#[derive(Debug, Clone, Default)]
pub struct SourceLoc {
    pub path: Option<PathBuf>,
    pub line: Option<usize>,
    pub column: Option<usize>,
}

impl SourceLoc {
    pub fn new(path: Option<PathBuf>, line: Option<usize>, column: Option<usize>) -> Self {
        Self { path, line, column }
    }

    pub fn from_path(path: PathBuf) -> Self {
        Self {
            path: Some(path),
            line: None,
            column: None,
        }
    }
}

impl std::fmt::Display for SourceLoc {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match (&self.path, self.line, self.column) {
            (Some(p), Some(line), Some(col)) => write!(f, "{}:{}:{}", p.display(), line, col),
            (Some(p), Some(line), None) => write!(f, "{}:{}", p.display(), line),
            (Some(p), _, _) => write!(f, "{}", p.display()),
            (None, Some(line), Some(col)) => write!(f, "line {}, column {}", line, col),
            (None, Some(line), _) => write!(f, "line {}", line),
            _ => write!(f, "<unknown location>"),
        }
    }
}

/// Append an educational hint to YAML parse errors that match common
/// authoring mistakes. Today this covers the most-frequently-reported
/// case: regex patterns written inside double-quoted YAML scalars that
/// trip on backslash escapes (`(?i)ignore\s+previous` produces serde-yaml's
/// `found unknown escape character` message).
///
/// The hint is intentionally narrow — only "unknown escape character"
/// errors get extra text, so generic YAML errors stay terse.
fn yaml_parse_hint(source: &serde_yaml::Error) -> String {
    let msg = source.to_string();
    if msg.contains("unknown escape character") {
        return "\n\nHint: regex patterns in YAML need either single quotes \
                (recommended):\n    \
                pattern: '(?i)ignore\\s+previous'\n\
                or doubled backslashes inside double quotes:\n    \
                pattern: \"(?i)ignore\\\\s+previous\""
            .to_string();
    }
    String::new()
}

/// Top-level load-time error type. Each variant carries enough context
/// to pinpoint the file, key, or chain step that failed.
#[derive(Debug, Error)]
pub enum ConfigError {
    #[error("loader: file I/O error at {path}: {source}")]
    Io {
        path: PathBuf,
        #[source]
        source: std::io::Error,
    },

    #[error(
        "loader: YAML parse error at {loc}: {source}{}",
        yaml_parse_hint(source)
    )]
    Yaml {
        loc: SourceLoc,
        #[source]
        source: serde_yaml::Error,
    },

    #[error("loader: schema error at {loc}: {message}")]
    Schema { loc: SourceLoc, message: String },

    #[error(
        "loader: rejected legacy vocabulary at {loc}: `{key}` is no longer valid \
         (the current schema is declared via `agent_shield_version`). \
         Migration hint: {hint}"
    )]
    V1Vocabulary {
        loc: SourceLoc,
        key: String,
        hint: String,
    },

    #[error("loader: invalid agent_shield_version `{value}` at {loc}: {message}")]
    InvalidAgentShieldVersion {
        loc: SourceLoc,
        value: String,
        message: String,
    },

    #[error(
        "loader: declared agent_shield_version `{declared}` is not satisfied by \
         runtime spec version `{runtime}` at {loc}"
    )]
    IncompatibleAgentShieldVersion {
        loc: SourceLoc,
        declared: String,
        runtime: String,
    },

    #[error(
        "loader: agent_shield_version `{a}` (in {a_loc}) and `{b}` (in {b_loc}) are \
         in incompatible compatibility bands"
    )]
    IncompatibleVersionBands {
        a: String,
        a_loc: SourceLoc,
        b: String,
        b_loc: SourceLoc,
    },

    #[error("loader: extends-chain cycle detected: {path}")]
    ExtendsCycle { path: String },

    #[error(
        "loader: variable `{name}` redefined in {second_file}; same-name variable \
         redefinition across files is forbidden (originally declared in {first_file})"
    )]
    DuplicateVariable {
        name: String,
        first_file: PathBuf,
        second_file: PathBuf,
    },

    #[error(
        "loader: unresolved {kind} reference `{name}` at {loc}: \
         the referenced {kind} is not declared"
    )]
    UnresolvedReference {
        loc: SourceLoc,
        kind: &'static str,
        name: String,
    },

    #[error(
        "loader: unknown event identifier `{id}` at {location}: \
         `@event.fired()` arguments must name a declared event"
    )]
    UnknownEventId { id: String, location: String },

    #[error(
        "loader: event identifier `{id}` at {location} references {namespace} \
         `{name}`, which is not declared in this configuration. Declare the \
         {namespace} under `{declare_under}` or remove the reference."
    )]
    UnknownEventResourceName {
        id: String,
        namespace: &'static str,
        name: String,
        declare_under: &'static str,
        location: String,
    },

    #[error(
        "loader: invalid expression syntax at {location}: {message} \
         (expression: `{expression}`)"
    )]
    InvalidExpressionSyntax {
        location: String,
        expression: String,
        message: String,
    },

    #[error(
        "loader: undeclared variable reference `{name}` at {location}: \
         the identifier is used in a value position but is not declared in \
         `variables:` (expression: `{expression}`). Declare the variable \
         under `variables:` or remove the reference."
    )]
    UndeclaredVariableReference {
        name: String,
        location: String,
        expression: String,
    },

    #[error(
        "loader: undeclared predicate reference `{name}` at {location}: \
         the identifier is used in a boolean position but is not declared in \
         `variables:` or `predicates:` (expression: `{expression}`). Declare \
         the predicate under `predicates:` or the variable under \
         `variables:`, or remove the reference."
    )]
    UndeclaredPredicateReference {
        name: String,
        location: String,
        expression: String,
    },

    #[error("loader: extends-chain depth exceeded ({depth} > {max}); deepest path: {path}")]
    ExtendsDepthExceeded {
        depth: usize,
        max: usize,
        path: String,
    },

    #[error(
        "loader: predicate `{name}` redefined in {leaf}; same-name predicate \
         redefinition across files is forbidden (originally declared in {origin})"
    )]
    PredicateRedefinition {
        name: String,
        origin: PathBuf,
        leaf: PathBuf,
    },

    #[error(
        "loader: guard policy `{name}` redefines parent's `active_if` in {leaf} \
         (originally declared in {origin}); parent `active_if` is immutable"
    )]
    GuardPolicyActiveIfImmutable {
        name: String,
        origin: PathBuf,
        leaf: PathBuf,
    },

    #[error(
        "loader: guard policy `{name}`: child file {leaf} declares `active_if: {child_value}` \
         on a same-name policy inherited from {origin} (parent declared `active_if: {parent_display}`). \
         Per a parent's `active_if` predicate is immutable across the extends chain — \
         child redefinition (or introduction, when the parent had none) is a load-time error \
         because it would silently change the gate's engagement scope. To declare a separate \
         gate with a different engagement predicate, use a different `name:`."
    )]
    GuardPolicyActiveIfChildDeclared {
        name: String,
        origin: PathBuf,
        leaf: PathBuf,
        parent_value: Option<String>,
        parent_display: String,
        child_value: String,
    },

    #[error(
        "loader: guard policy `{name}`: action `{child_action}` ({leaf}) weakens \
         `{parent_action}` ({origin}). The monotone ladder permits same-rung \
         or stronger redeclaration only — strongest wins, weakening is a load-time error. \
         Ladder, strongest → weakest: block > redact > append/prepend > warn. \
         To roll out a weaker disposition in shadow mode, declare a NEW guard policy with \
         a different `name:` so the parent's stronger disposition is preserved."
    )]
    GuardPolicyActionWeakened {
        name: String,
        origin: PathBuf,
        leaf: PathBuf,
        parent_action: String,
        child_action: String,
    },

    #[error(
        "loader: guard policy `{name}` ({stage}): child file {leaf} adds \
         `applies_to.{axis}.exclude` element(s) {offending_excludes:?} on a same-name \
         policy inherited from {origin}; the merge would carve {carved_resources:?} out of \
         the parent's effective match set. Per the merged selector's effective match \
         set MUST be a superset of the parent's — a descendant tier may not narrow coverage \
         a parent gate already provided. To gate a NARROWER scope, declare a NEW guard policy \
         with a different `name:` so the parent's broader scope is preserved."
    )]
    GuardPolicyAppliesToCarveOut {
        name: String,
        stage: String,
        axis: String,
        origin: PathBuf,
        leaf: PathBuf,
        offending_excludes: Vec<String>,
        carved_resources: Vec<String>,
    },

    #[error(
        "loader: resource `{name}`: child file {leaf} sets `permission: {child_permission}` \
         on a same-identity entry inherited from {origin} (parent declared \
         `permission: {parent_permission}`). Per `permission` is last-wins but MUST NOT \
         broaden — child files may only re-declare the same tier or narrow to a lower-privilege \
         one. The advisory tier ladder, weakest → strongest: read_only < read_write < execute \
         < destructive. To grant a more permissive disposition, declare a NEW resource entry \
         with a different `name:` so the parent's narrower permission is preserved."
    )]
    ResourcePermissionBroadened {
        name: String,
        origin: PathBuf,
        leaf: PathBuf,
        parent_permission: String,
        child_permission: String,
    },

    #[error(
        "loader: resource `{name}`: child file {leaf} sets `protocol: {child_protocol}` \
         on a same-identity entry inherited from {origin} (parent declared \
         `protocol: {parent_protocol}`). Per `protocol` must match across the extends \
         chain — child redeclaration with a different value is a load-time error. To declare \
         a separate transport binding, use a different `name:` so the parent's protocol tag \
         is preserved."
    )]
    ResourceProtocolMismatch {
        name: String,
        origin: PathBuf,
        leaf: PathBuf,
        parent_protocol: String,
        child_protocol: String,
    },

    #[error("loader: invalid event identifier `{value}` at {loc}: {message}")]
    InvalidEventId {
        loc: SourceLoc,
        value: String,
        message: String,
    },

    #[error("loader: invalid duration literal `{value}` at {loc}: {message}")]
    InvalidDuration {
        loc: SourceLoc,
        value: String,
        message: String,
    },

    #[error("loader: resolver dependency cycle through variable `{path}` (defined at {loc})")]
    ResolverCycle { loc: SourceLoc, path: String },

    #[error(
        "loader: circular predicate reference: {path}. \
         Predicates may reference other predicates, but circular \
         references MUST be detected and rejected at build time. \
         Break the cycle by inlining one of the predicates, or by \
         removing the back-edge so the reference graph is acyclic."
    )]
    PredicateCycle { path: String },

    #[error("loader: configuration `{id}` rejected at {loc}: {message}")]
    InvalidConfiguration {
        loc: SourceLoc,
        id: String,
        message: String,
    },

    #[error(
        "loader: evaluate_when entry at {loc} must declare exactly one of \
         `expression`/`pattern`/`patterns`/`llm`/`classifier` (found {count})"
    )]
    EvaluateWhenKindMismatch { loc: SourceLoc, count: usize },

    #[error("loader: missing required field `{field}` at {loc}")]
    MissingField { loc: SourceLoc, field: String },

    #[error(
        "loader: expression at {location} references namespace `{namespace}` \
         which is not bound in this context ({context}). \
         Per every expression context binds at most one resource-bound \
         namespace (whichever of `@tool.*` / `@endpoint.*` / `@agent.*` matches \
         the resource kind being gated) plus `@context.*` and (only inside \
         `populated_by[].expression:` with `phase: after`) `@result.*`. \
         Referencing a namespace not bound for the current context MUST be a \
         load-time error. \
         (expression: `{expression}`)"
    )]
    ExpressionNamespaceUnbound {
        location: String,
        namespace: String,
        context: String,
        expression: String,
    },

    #[error(
        "loader: expression at {location} calls unknown built-in function \
         `{name}(...)`{suggestion_hint}. LANGUAGE.md defines the closed \
         standard library; calls to names outside that registry silently \
         evaluate to `null` -> `false` at runtime, which turns a typo \
         into a false-deny. Either correct the spelling, or — for a \
         host-specific function — register it via the extension table. \
         (expression: `{expression}`)"
    )]
    UnknownBuiltinCall {
        location: String,
        name: String,
        suggestion_hint: String,
        expression: String,
    },

    #[error(
        "loader: variable `{variable}` `update:` expression references forbidden \
         invocation-bound namespace `{namespace}` (expression: `{expression}`). \
         `update:` may read only `@current`, `@incoming`, declared \
         session variables, and predicates; the invocation-bound namespaces \
         `@tool.*`, `@endpoint.*`, `@agent.*`, `@result.*`, and `@context.*` are \
         forbidden because `update:` is a merge function over variable state, \
         not a value source."
    )]
    UpdateExpressionForbiddenNamespace {
        variable: String,
        namespace: String,
        expression: String,
    },

    // ── Remote `extends:` errors ─────────────────────────────────
    #[error(
        "loader: remote `extends:` entry at {loc} must be the object form \
         `{{ url: <https://…>, integrity: sha256-<base64> }}`. Plain URL \
         strings are rejected because integrity must be explicit."
    )]
    UrlExtendsRequiresIntegrity { loc: SourceLoc, url: String },

    #[error(
        "loader: remote `extends:` entry for `{url}` at {loc} declares both \
         `integrity:` and `unverified: true`; the trust model must be \
         exactly one of pinned or unverified."
    )]
    UrlExtendsConflictingTrust { loc: SourceLoc, url: String },

    #[error(
        "loader: remote `extends:` entry for `{url}` at {loc} declares \
         neither `integrity:` nor `unverified: true`; the trust model \
         must be explicit. Use `integrity: sha256-<base64>` to pin the \
         body, or `unverified: true` to acknowledge the load is not \
         byte-verified."
    )]
    UrlExtendsMissingTrust { loc: SourceLoc, url: String },

    #[error(
        "loader: remote `extends:` URL `{url}` at {loc} uses unsupported \
         scheme: only `https://` is accepted"
    )]
    UrlExtendsBadScheme { loc: SourceLoc, url: String },

    #[error(
        "loader: remote `extends:` URL `{url}` at {loc} carries forbidden \
         components (credentials or fragment); strip them"
    )]
    UrlExtendsForbiddenComponents { loc: SourceLoc, url: String },

    #[error(
        "loader: remote `extends:` integrity literal `{value}` at {loc} is \
         malformed: expected `sha256-<base64>` (SRI form)"
    )]
    UrlExtendsBadIntegrity { loc: SourceLoc, value: String },

    #[error(
        "loader: remote `extends:` relative URL `{url}` at {loc} requires \
         a remote parent file as its base"
    )]
    RelativeUrlNeedsRemoteParent { loc: SourceLoc, url: String },

    #[error("loader: remote `extends:` fetch of `{url}` failed: {message}")]
    RemoteFetch { url: String, message: String },

    #[error(
        "loader: remote `extends:` integrity mismatch for `{url}`: \
         expected {expected}, got {actual}"
    )]
    IntegrityMismatch {
        url: String,
        expected: String,
        actual: String,
    },

    #[error(
        "loader: remote `extends:` URL `{url}` declared with conflicting \
         integrity values across the chain: first {first}, now {second}"
    )]
    IntegrityConflict {
        url: String,
        first: String,
        second: String,
    },

    #[error(
        "loader: remote `extends:` body for `{url}` exceeds the {max}-byte \
         cap"
    )]
    RemoteBodyTooLarge { url: String, max: usize },

    /// Per-load fetch-count cap (`MAX_REMOTE_FETCHES`) exceeded.
    ///
    /// Field semantics (note the asymmetry vs. `RemoteBytesBudgetExceeded`):
    /// - `count`: the would-be attempt number that tripped the guard
    ///   (i.e. `fetch_count + 1`, since the cap check fires BEFORE the
    ///   fetch is attempted).
    /// - `max`: the configured fetch-count cap (`MAX_REMOTE_FETCHES`).
    /// - `bytes_total`: the cumulative bytes admitted by prior fetches
    ///   in this load. The failed fetch contributes nothing because no
    ///   socket was opened.
    #[error(
        "loader: too many remote `extends:` fetches in this load \
         ({count} > {max}); cumulative bytes {bytes_total}"
    )]
    RemoteFetchCountBudgetExceeded {
        count: usize,
        max: usize,
        bytes_total: usize,
    },

    /// Per-load cumulative-bytes cap (`MAX_REMOTE_TOTAL_BYTES`) would be
    /// exceeded by an in-flight fetch.
    ///
    /// Field semantics (note the asymmetry vs. `RemoteFetchCountBudgetExceeded`):
    /// - `count`: the in-flight fetch number whose body would breach
    ///   the cap (`fetch_count + 1`); this fetch's bytes are NOT
    ///   admitted to the cache or counters.
    /// - `max_bytes`: the configured cumulative-bytes cap
    ///   (`MAX_REMOTE_TOTAL_BYTES`).
    /// - `bytes_total`: the value `bytes_total` WOULD reach if the
    ///   in-flight body were admitted (i.e. prior bytes + this body's
    ///   length). The body is not actually admitted; this is reported
    ///   to make the diagnostic concrete about the overshoot.
    #[error(
        "loader: cumulative remote `extends:` body bytes in this load \
         exceeds the {max_bytes}-byte cap (would reach {bytes_total} \
         after fetch #{count})"
    )]
    RemoteBytesBudgetExceeded {
        count: usize,
        max_bytes: usize,
        bytes_total: usize,
    },

    #[error(
        "loader: remote `extends:` requires the `http` feature; rebuild \
         `agent_shield_core` with `--features http` or remove the URL \
         entry at {loc}"
    )]
    RemoteExtendsFeatureDisabled { loc: SourceLoc },

    // ── prompt_path errors ──────────────────────────────────────
    #[error("loader: prompt file error at {loc}: {kind} (path: {path})")]
    PromptFile {
        loc: SourceLoc,
        path: PathBuf,
        kind: PromptFileErrorKind,
    },

    // ── IFC variable subtype errors ────────────────────────────────
    /// IFC variable declared with `update:` / `on_demand_by:` / `key:`
    /// outside the populator path. Reason code:
    /// `ifc_variable_not_populator_only`.
    #[error(
        "loader: ifc_variable_not_populator_only — variable `{name}` at {loc}: \
         `type: {var_type}` does not permit `{fields}` \
         (IFC variables compose via the lattice join applied by `populated_by[]`)"
    )]
    IfcVariableNotPopulatorOnly {
        loc: SourceLoc,
        name: String,
        var_type: String,
        fields: String,
    },

    // ── Populator write ambiguity ───────────────────────────────────
    /// Populator declares both `expression:` and `value:`. Reason code:
    /// `populator_write_ambiguous`.
    #[error(
        "loader: populator_write_ambiguous at {loc}: \
         `expression:` and `value:` are mutually exclusive"
    )]
    PopulatorWriteAmbiguous { loc: SourceLoc },

    // ── Selector shape errors ───────────────────────────────────────
    /// Selector mixes `unlisted: true` with `include:`/`exclude:`.
    /// Reason code: `selector_unlisted_with_include_exclude`.
    #[error(
        "loader: selector_unlisted_with_include_exclude at {loc}: \
         `unlisted: true` cannot be combined with `include:` or `exclude:`"
    )]
    SelectorUnlistedWithIncludeExclude { loc: SourceLoc },

    // ── Strict resource coverage ────────────────────────────────────
    /// `strict_resource_coverage.stages` named a non-resource-bound stage.
    /// Reason code: `strict_resource_coverage_invalid_stage`.
    #[error(
        "loader: strict_resource_coverage_invalid_stage — variable `{variable}` at {loc}: \
         `strict_resource_coverage.stages` may only contain \
         `state_validation`, `tool_execution_validation`, or `post_tool_validation`; \
         stage `{stage}` is not resource-bound"
    )]
    StrictResourceCoverageInvalidStage {
        loc: SourceLoc,
        variable: String,
        stage: String,
    },

    /// One or more resources are not covered by any referencing guard policy.
    /// Reason code: `strict_resource_coverage_uncovered`.
    #[error(
        "loader: strict_resource_coverage_uncovered — variable `{variable}` at {loc}: \
         the following resources are not covered by any guard policy that references it: {resources}"
    )]
    StrictResourceCoverageUncovered {
        loc: SourceLoc,
        variable: String,
        resources: String,
    },

    // ── Unknown-field errors ─────────────────────────────────────────
    /// Unknown field on a resource entry (tool, endpoint, or agent).
    /// Reason code: `unknown_resource_field`.
    #[error(
        "loader: unknown_resource_field `{field}` on resource `{resource}` at {loc}: \
         remove or rename this field"
    )]
    UnknownResourceField {
        loc: SourceLoc,
        resource: String,
        field: String,
    },

    /// Unknown top-level YAML key. Reason code: `unknown_top_level_field`.
    #[error(
        "loader: unknown_top_level_field `{field}` at {loc}: \
         this key is not part of the guardrails schema"
    )]
    UnknownTopLevelField { loc: SourceLoc, field: String },

    /// One or more `guard_policies[].evaluate_when[].classifier`
    /// references cannot be served by any caller — neither a
    /// host-registered `ClassifierCaller` nor the bundled auto-wired
    /// provider for the referenced `configurations[]` entry. Surfaced
    /// at `RuntimeBuilder::build()` time so the failure is loud and
    /// actionable instead of producing
    /// `(no classifier caller registered)` on every benign tool call.
    /// Reason code: `classifier_wiring_missing`.
    ///
    /// Each `details` line names the configuration id, the policy that
    /// references it, and (when available) the specific reason
    /// auto-wire couldn't produce a caller — missing `api_key_env`
    /// variable, unsupported provider, Cargo feature disabled, or no
    /// matching `configurations[]` entry at all. Customers fix this
    /// by setting the env var, building the SDK with the feature
    /// enabled, registering a custom `ClassifierCaller`, or removing
    /// the policy reference.
    #[error(
        "loader: classifier_wiring_missing — guard policy classifier references cannot be served:\n{details}\n\
         remediation:\n  \
         (1) set the named env var(s) so the bundled provider auto-wires,\n  \
         (2) register a custom classifier caller before .build() \
         (Python: `RuntimeBuilder.register_classifier_caller(...)`, \
         Node: `.registerClassifierCaller(...)`), or\n  \
         (3) remove the `classifier:` reference from the listed policies."
    )]
    ClassifierWiringMissing { details: String },

    /// One or more `guard_policies[].evaluate_when[].classifier`
    /// entries are paired with `action: redact` but the referenced
    /// configuration's provider cannot emit per-span character offsets.
    /// classifiers whose providers emit only a
    /// global score (no per-span offsets) MUST NOT be used in redact
    /// mode; doing so MUST be a load-time configuration error. Reason
    /// code: `classifier_redact_unsupported`.
    ///
    /// Each `details` line names the configuration id, the provider,
    /// and the stage/policy where the misconfiguration was found.
    /// Customers fix this by switching the policy's `action:` to
    /// `block` or `warn` (which only need a verdict, not spans), or by
    /// using a span-producing detector (`pattern` / `patterns` /
    /// `llm` with `spans[]`) instead.
    #[error(
        "loader: classifier_redact_unsupported — `action: redact` is invalid for classifier configurations whose provider cannot emit per-span character offsets:\n{details}\n\
         remediation:\n  \
         (1) change the guard policy's `action:` to `block` or `warn` (verdict-only, no spans needed), or\n  \
         (2) replace the `classifier:` detector with a span-producing detector (`pattern` / `patterns` / `llm` returning `spans[]`)."
    )]
    ClassifierRedactUnsupported { details: String },
}

/// Why a `prompt_path:` (or post-load `prompt_path` invariant check)
/// failed. Spec.
#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum PromptFileErrorKind {
    #[error("`prompt:` and `prompt_path:` are mutually exclusive")]
    BothSet,
    #[error("exactly one of `prompt:` or `prompt_path:` is required")]
    NeitherSet,
    #[error("file not found or not readable: {message}")]
    NotFound { message: String },
    #[error("path is not a regular file")]
    NotRegularFile,
    #[error("file exceeds the {max}-byte cap")]
    TooLarge { max: usize },
    #[error("file is not valid UTF-8")]
    NotUtf8,
    #[error("file is empty")]
    EmptyFile,
    #[error("`prompt_path:` is not supported for string-input loads (no anchor directory)")]
    NoAnchorDir,
    #[error("`prompt_path:` is not supported for remote (HTTPS) extends: in this spec version")]
    RemoteNotSupported,
    #[error(
        "loaded config still carries an unresolved `prompt_path` — this MergedConfig \
         was hand-constructed or routed past the loader's inlining pass"
    )]
    UnresolvedPromptPath,
}

impl ConfigError {
    pub fn schema(loc: SourceLoc, message: impl Into<String>) -> Self {
        Self::Schema {
            loc,
            message: message.into(),
        }
    }

    pub fn v1_vocab(loc: SourceLoc, key: impl Into<String>, hint: impl Into<String>) -> Self {
        Self::V1Vocabulary {
            loc,
            key: key.into(),
            hint: hint.into(),
        }
    }

    /// Return the stable snake_case reason code for this error variant, or
    /// `None` for variants that do not have a single-word discriminant.
    ///
    /// Downstream SDK error-mapping code MAY match on this string to provide
    /// a typed exception class. The FFI boundary also embeds this string in
    /// every error message so a string-grep fallback works when the typed
    /// match is not available.
    pub fn reason_code(&self) -> Option<&'static str> {
        match self {
            Self::IfcVariableNotPopulatorOnly { .. } => Some("ifc_variable_not_populator_only"),
            Self::PopulatorWriteAmbiguous { .. } => Some("populator_write_ambiguous"),
            Self::SelectorUnlistedWithIncludeExclude { .. } => {
                Some("selector_unlisted_with_include_exclude")
            }
            Self::StrictResourceCoverageInvalidStage { .. } => {
                Some("strict_resource_coverage_invalid_stage")
            }
            Self::StrictResourceCoverageUncovered { .. } => {
                Some("strict_resource_coverage_uncovered")
            }
            Self::UnknownResourceField { .. } => Some("unknown_resource_field"),
            Self::UnknownTopLevelField { .. } => Some("unknown_top_level_field"),
            Self::ClassifierWiringMissing { .. } => Some("classifier_wiring_missing"),
            Self::ClassifierRedactUnsupported { .. } => Some("classifier_redact_unsupported"),
            // ── Loader-error cluster codes. SDK wrappers map these to a typed
            // `AgentShieldConfigError` / `AgentShieldConfigException`.
            Self::Io { .. } => Some("io_error"),
            Self::Yaml { .. } => Some("unparseable_yaml"),
            Self::Schema { .. } => Some("schema_violation"),
            Self::V1Vocabulary { .. } => Some("v1_vocabulary"),
            Self::InvalidAgentShieldVersion { .. } => Some("invalid_agent_shield_version"),
            Self::IncompatibleAgentShieldVersion { .. } => {
                Some("incompatible_agent_shield_version")
            }
            Self::IncompatibleVersionBands { .. } => Some("incompatible_version_bands"),
            Self::ExtendsCycle { .. } => Some("cycle_detected"),
            Self::DuplicateVariable { .. } => Some("duplicate_variable"),
            Self::UnresolvedReference { .. } => Some("unresolved_reference"),
            Self::UnknownEventId { .. } => Some("unknown_event"),
            Self::UnknownEventResourceName { .. } => Some("unknown_event_resource_name"),
            Self::InvalidExpressionSyntax { .. } => Some("invalid_expression"),
            Self::UndeclaredVariableReference { .. } => Some("undeclared_variable_reference"),
            Self::UndeclaredPredicateReference { .. } => Some("undeclared_predicate_reference"),
            Self::ExtendsDepthExceeded { .. } => Some("extends_depth_exceeded"),
            Self::PredicateRedefinition { .. } => Some("predicate_redefinition"),
            Self::GuardPolicyActiveIfImmutable { .. } => Some("guard_policy_active_if_immutable"),
            Self::GuardPolicyActiveIfChildDeclared { .. } => {
                Some("guard_policy_active_if_immutable")
            }
            Self::GuardPolicyActionWeakened { .. } => Some("guard_policy_action_weakened"),
            Self::GuardPolicyAppliesToCarveOut { .. } => Some("guard_policy_applies_to_carve_out"),
            Self::ResourcePermissionBroadened { .. } => Some("resource_permission_broadened"),
            Self::ResourceProtocolMismatch { .. } => Some("resource_protocol_mismatch"),
            Self::InvalidEventId { .. } => Some("invalid_event_id"),
            Self::InvalidDuration { .. } => Some("invalid_duration"),
            Self::ResolverCycle { .. } => Some("cycle_detected"),
            Self::PredicateCycle { .. } => Some("cycle_detected"),
            Self::InvalidConfiguration { .. } => Some("invalid_configuration"),
            Self::EvaluateWhenKindMismatch { .. } => Some("evaluate_when_kind_mismatch"),
            Self::MissingField { .. } => Some("missing_field"),
            Self::UpdateExpressionForbiddenNamespace { .. } => {
                Some("update_expression_forbidden_namespace")
            }
            Self::ExpressionNamespaceUnbound { .. } => Some("expression_namespace_unbound"),
            Self::UnknownBuiltinCall { .. } => Some("unknown_builtin_call"),
            Self::UrlExtendsRequiresIntegrity { .. } => Some("url_extends_requires_integrity"),
            Self::UrlExtendsConflictingTrust { .. } => Some("url_extends_conflicting_trust"),
            Self::UrlExtendsMissingTrust { .. } => Some("url_extends_missing_trust"),
            Self::UrlExtendsBadScheme { .. } => Some("url_extends_bad_scheme"),
            Self::UrlExtendsForbiddenComponents { .. } => Some("url_extends_forbidden_components"),
            Self::UrlExtendsBadIntegrity { .. } => Some("url_extends_bad_integrity"),
            Self::RelativeUrlNeedsRemoteParent { .. } => Some("relative_url_needs_remote_parent"),
            Self::RemoteFetch { .. } => Some("remote_fetch_failed"),
            Self::IntegrityMismatch { .. } => Some("integrity_mismatch"),
            Self::IntegrityConflict { .. } => Some("integrity_conflict"),
            Self::RemoteBodyTooLarge { .. } => Some("remote_body_too_large"),
            Self::RemoteFetchCountBudgetExceeded { .. } => {
                Some("remote_fetch_count_budget_exceeded")
            }
            Self::RemoteBytesBudgetExceeded { .. } => Some("remote_bytes_budget_exceeded"),
            Self::RemoteExtendsFeatureDisabled { .. } => Some("remote_extends_feature_disabled"),
            Self::PromptFile { .. } => Some("prompt_file_error"),
        }
    }

    /// Project this [`ConfigError`] into a stable, FFI-safe wire shape
    /// that SDK wrappers (Python / Node /.NET) translate into a
    /// language-native typed exception.
    ///
    /// The wire shape is intentionally minimal — five fields:
    ///
    /// * `path` filesystem path of the failing YAML, when known
    /// * `line` 1-based source line, when the parser reports one
    /// * `column` 1-based column, when the parser reports one
    /// * `field` a short locator for the offending YAML element
    ///                 (free-form: e.g. `guard_policies[0].evaluate_when[1]`,
    ///                 a key name, a resolver kind, a configuration id)
    /// * `code` snake_case discriminant; see [`Self::reason_code`]
    ///                 for the closed registry
    /// * `message` canonical human-readable rendering (identical to
    ///                 the `Display` impl — preserved verbatim so any
    ///                 substring-grep tests written against the legacy
    ///                 bare-exception message continue to pass)
    /// * `remediation` optional one-line hint; today we surface the
    ///                 prompt-file failure detail and a couple of
    ///                 self-documenting hints, but most variants leave
    ///                 this `None` (the canonical message already
    ///                 contains the actionable text)
    ///
    /// The shape is intentionally not a tagged union: SDKs dispatch
    /// purely on `code` and treat the other fields as enrichment.
    pub fn to_loader_wire(&self) -> LoaderErrorWire {
        let loc = self.source_loc();
        let (mut path, mut line, mut column) = match loc {
            Some(l) => (
                l.path.as_ref().map(|p| p.display().to_string()),
                l.line,
                l.column,
            ),
            None => (None, None, None),
        };

        // For YAML parse errors, the underlying `serde_yaml::Error`
        // carries its own line/column. Lift them into the wire shape
        // so the typed exception surfaces them as structured fields
        if let Self::Yaml { source, .. } = self {
            if line.is_none() {
                if let Some(loc_yaml) = source.location() {
                    line = Some(loc_yaml.line());
                    column = Some(loc_yaml.column());
                }
            }
        }

        // Lift path-bearing variants that carry the failing file
        // outside of `SourceLoc` so the typed exception always has
        // `path` populated when a filesystem location is known.
        if path.is_none() {
            path = match self {
                Self::Io { path: p, .. } => Some(p.display().to_string()),
                Self::DuplicateVariable { second_file: p, .. } => Some(p.display().to_string()),
                Self::PredicateRedefinition { leaf: p, .. } => Some(p.display().to_string()),
                Self::GuardPolicyActiveIfImmutable { leaf: p, .. }
                | Self::GuardPolicyActiveIfChildDeclared { leaf: p, .. }
                | Self::GuardPolicyActionWeakened { leaf: p, .. }
                | Self::GuardPolicyAppliesToCarveOut { leaf: p, .. }
                | Self::ResourcePermissionBroadened { leaf: p, .. }
                | Self::ResourceProtocolMismatch { leaf: p, .. } => Some(p.display().to_string()),
                Self::PromptFile { path: p, .. } => Some(p.display().to_string()),
                _ => None,
            };
        }

        LoaderErrorWire {
            path,
            line,
            column,
            field: self.field_locator(),
            code: self.reason_code().unwrap_or("loader_error").to_string(),
            message: self.to_string(),
            remediation: self.remediation_hint(),
        }
    }

    /// Return the [`SourceLoc`] embedded in this variant, when one is
    /// carried structurally. Variants whose location is only embedded
    /// inside a free-form `location: String` field return `None` —
    /// SDK wrappers fall back to parsing the message in those cases.
    fn source_loc(&self) -> Option<&SourceLoc> {
        match self {
            Self::Yaml { loc, .. }
            | Self::Schema { loc, .. }
            | Self::V1Vocabulary { loc, .. }
            | Self::InvalidAgentShieldVersion { loc, .. }
            | Self::IncompatibleAgentShieldVersion { loc, .. }
            | Self::UnresolvedReference { loc, .. }
            | Self::InvalidEventId { loc, .. }
            | Self::InvalidDuration { loc, .. }
            | Self::ResolverCycle { loc, .. }
            | Self::InvalidConfiguration { loc, .. }
            | Self::EvaluateWhenKindMismatch { loc, .. }
            | Self::MissingField { loc, .. }
            | Self::UrlExtendsRequiresIntegrity { loc, .. }
            | Self::UrlExtendsConflictingTrust { loc, .. }
            | Self::UrlExtendsMissingTrust { loc, .. }
            | Self::UrlExtendsBadScheme { loc, .. }
            | Self::UrlExtendsForbiddenComponents { loc, .. }
            | Self::UrlExtendsBadIntegrity { loc, .. }
            | Self::RelativeUrlNeedsRemoteParent { loc, .. }
            | Self::RemoteExtendsFeatureDisabled { loc, .. }
            | Self::PromptFile { loc, .. }
            | Self::IfcVariableNotPopulatorOnly { loc, .. }
            | Self::PopulatorWriteAmbiguous { loc, .. }
            | Self::SelectorUnlistedWithIncludeExclude { loc, .. }
            | Self::StrictResourceCoverageInvalidStage { loc, .. }
            | Self::StrictResourceCoverageUncovered { loc, .. }
            | Self::UnknownResourceField { loc, .. }
            | Self::UnknownTopLevelField { loc, .. } => Some(loc),
            _ => None,
        }
    }

    /// A short YAML-field locator describing what the error scopes to.
    /// Free-form — SDKs surface it as `field`. Returns `None` when no
    /// useful per-variant locator is available; SDK consumers can fall
    /// back to `path:line:column` from [`SourceLoc`] in that case.
    fn field_locator(&self) -> Option<String> {
        match self {
            Self::V1Vocabulary { key, .. } => Some(key.clone()),
            Self::InvalidAgentShieldVersion { .. } => Some("agent_shield_version".to_string()),
            Self::IncompatibleAgentShieldVersion { .. } => Some("agent_shield_version".to_string()),
            Self::IncompatibleVersionBands { .. } => Some("agent_shield_version".to_string()),
            Self::DuplicateVariable { name, .. } => Some(format!("variables.{}", name)),
            Self::UnresolvedReference { kind, name, .. } => Some(format!("{}:{}", kind, name)),
            Self::UnknownEventId { id, .. } => Some(id.clone()),
            Self::UnknownEventResourceName { id, .. } => Some(id.clone()),
            Self::InvalidExpressionSyntax { location, .. } => Some(location.clone()),
            Self::UndeclaredVariableReference { name, location, .. } => {
                Some(format!("{}@{}", name, location))
            }
            Self::UndeclaredPredicateReference { name, location, .. } => {
                Some(format!("{}@{}", name, location))
            }
            Self::PredicateRedefinition { name, .. } => Some(format!("predicates.{}", name)),
            Self::GuardPolicyActiveIfImmutable { name, .. }
            | Self::GuardPolicyActiveIfChildDeclared { name, .. }
            | Self::GuardPolicyActionWeakened { name, .. } => {
                Some(format!("guard_policies.{}", name))
            }
            Self::GuardPolicyAppliesToCarveOut { name, axis, .. } => {
                Some(format!("guard_policies.{}.applies_to.{}", name, axis))
            }
            Self::ResourcePermissionBroadened { name, .. } => {
                Some(format!("resources.tools.{}.permission", name))
            }
            Self::ResourceProtocolMismatch { name, .. } => {
                Some(format!("resources.tools.{}.protocol", name))
            }
            Self::InvalidEventId { value, .. } => Some(value.clone()),
            Self::InvalidDuration { value, .. } => Some(value.clone()),
            Self::ResolverCycle { path, .. } => Some(format!("variables.{}", path)),
            Self::PredicateCycle { path, .. } => Some(format!("predicates.{}", path)),
            Self::InvalidConfiguration { id, .. } => Some(format!("configurations.{}", id)),
            Self::MissingField { field, .. } => Some(field.clone()),
            Self::UpdateExpressionForbiddenNamespace {
                variable,
                namespace,
                ..
            } => Some(format!("variables.{}.update[{}]", variable, namespace)),
            Self::ExpressionNamespaceUnbound {
                location,
                namespace,
                ..
            } => Some(format!("{}[{}]", location, namespace)),
            Self::UnknownBuiltinCall { location, name, .. } => {
                Some(format!("{}[{}()]", location, name))
            }
            Self::UnknownResourceField {
                resource, field, ..
            } => Some(format!("{}.{}", resource, field)),
            Self::UnknownTopLevelField { field, .. } => Some(field.clone()),
            Self::IfcVariableNotPopulatorOnly { name, fields, .. } => {
                Some(format!("variables.{}.[{}]", name, fields))
            }
            Self::StrictResourceCoverageInvalidStage {
                variable, stage, ..
            } => Some(format!(
                "variables.{}.strict_resource_coverage.stages[{}]",
                variable, stage
            )),
            Self::StrictResourceCoverageUncovered { variable, .. } => {
                Some(format!("variables.{}.strict_resource_coverage", variable))
            }
            Self::PromptFile { path, .. } => Some(path.display().to_string()),
            Self::UrlExtendsRequiresIntegrity { url, .. }
            | Self::UrlExtendsConflictingTrust { url, .. }
            | Self::UrlExtendsMissingTrust { url, .. }
            | Self::UrlExtendsBadScheme { url, .. }
            | Self::UrlExtendsForbiddenComponents { url, .. }
            | Self::RelativeUrlNeedsRemoteParent { url, .. }
            | Self::RemoteFetch { url, .. }
            | Self::IntegrityMismatch { url, .. }
            | Self::IntegrityConflict { url, .. }
            | Self::RemoteBodyTooLarge { url, .. } => Some(format!("extends:{}", url)),
            Self::UrlExtendsBadIntegrity { value, .. } => Some(value.clone()),
            _ => None,
        }
    }

    /// Optional one-line remediation hint surfaced on the typed
    /// exception. Most variants leave this empty — the canonical
    /// message already contains the actionable text.
    fn remediation_hint(&self) -> Option<String> {
        match self {
            Self::V1Vocabulary { hint, .. } => Some(hint.clone()),
            Self::IncompatibleAgentShieldVersion {
                declared, runtime, ..
            } => Some(format!(
                "declared `agent_shield_version: {}` but runtime ships spec `{}`",
                declared, runtime
            )),
            Self::ClassifierWiringMissing { .. } => Some(
                "set the named env var(s), register a custom classifier caller \
                 before .build(), or remove the `classifier:` reference"
                    .to_string(),
            ),
            Self::ClassifierRedactUnsupported { .. } => Some(
                "change `action:` to `block` or `warn`, or use a span-producing \
                 detector (`pattern` / `patterns` / `llm`)"
                    .to_string(),
            ),
            Self::Yaml { .. } => Some(
                "fix the YAML syntax; for regex patterns prefer single-quoted scalars \
                 to avoid backslash-escape pitfalls"
                    .to_string(),
            ),
            Self::ExtendsCycle { .. } | Self::ResolverCycle { .. } => {
                Some("break the cycle so each entry has an acyclic dependency chain".to_string())
            }
            _ => None,
        }
    }
}

/// FFI-safe wire shape for a loader error.
///
/// SDK wrappers (Python `AgentShieldConfigError`, Node
/// `AgentShieldConfigError`,.NET `AgentShieldConfigException`) project
/// the structured fields of a [`ConfigError`] into this shape and
/// raise an idiomatic typed exception that carries each field as a
/// public attribute / property.
///
/// The shape is intentionally a flat record (not a tagged union) so
/// every SDK can deserialize it with one-line JSON parsing.
#[derive(Debug, Clone, Serialize)]
pub struct LoaderErrorWire {
    /// Filesystem path of the YAML file that failed to load, when
    /// known. `None` for string-input loads (`load_from_str`,
    /// `from_yaml_strings`).
    pub path: Option<String>,
    /// 1-based line number, when the parser provides one.
    pub line: Option<usize>,
    /// 1-based column number, when the parser provides one.
    pub column: Option<usize>,
    /// Short YAML-field locator (e.g. `guard_policies[0].evaluate_when`)
    /// or a string id (resolver name, configuration id). Free-form;
    /// `None` when no per-variant locator is meaningful.
    pub field: Option<String>,
    /// Stable snake_case discriminant. See [`ConfigError::reason_code`]
    /// for the closed registry. Defaults to `"loader_error"` for
    /// variants that lack a single-word discriminant.
    pub code: String,
    /// Canonical human-readable message — identical to the
    /// [`ConfigError`] `Display` rendering. Preserved verbatim so any
    /// substring-grep tests written against the legacy bare-exception
    /// message continue to pass after SDKs upgrade to the typed shape.
    pub message: String,
    /// Optional one-line remediation hint; many variants leave this
    /// `None` because the canonical message already contains the
    /// actionable text.
    pub remediation: Option<String>,
}

impl LoaderErrorWire {
    /// Serialize the wire shape to a single-line JSON string suitable
    /// for embedding inside an FFI `**err` C-string. The shape is
    /// stable across the v2 series.
    pub fn to_json(&self) -> String {
        serde_json::to_string(self).unwrap_or_else(|_| "{}".to_string())
    }
}

pub type Result<T> = std::result::Result<T, ConfigError>;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn source_loc_display_path_only() {
        let s = SourceLoc::from_path(PathBuf::from("/tmp/x.yaml")).to_string();
        assert!(s.contains("x.yaml"));
    }

    #[test]
    fn config_error_messages_contain_provenance() {
        let err = ConfigError::v1_vocab(
            SourceLoc::from_path(PathBuf::from("a.yaml")),
            "agentShieldVersion",
            "rename to `agent_shield_version`",
        );
        let msg = err.to_string();
        assert!(msg.contains("agentShieldVersion"));
        assert!(msg.contains("a.yaml"));
        assert!(msg.contains("rename"));
    }

    #[test]
    fn reason_code_ifc_variable_not_populator_only() {
        let err = ConfigError::IfcVariableNotPopulatorOnly {
            loc: SourceLoc::default(),
            name: "my_level".into(),
            var_type: "level".into(),
            fields: "update".into(),
        };
        assert_eq!(err.reason_code(), Some("ifc_variable_not_populator_only"));
        assert!(err.to_string().contains("ifc_variable_not_populator_only"));
        assert!(err.to_string().contains("my_level"));
    }

    #[test]
    fn reason_code_populator_write_ambiguous() {
        let err = ConfigError::PopulatorWriteAmbiguous {
            loc: SourceLoc::default(),
        };
        assert_eq!(err.reason_code(), Some("populator_write_ambiguous"));
        assert!(err.to_string().contains("populator_write_ambiguous"));
    }

    #[test]
    fn reason_code_selector_unlisted_with_include_exclude() {
        let err = ConfigError::SelectorUnlistedWithIncludeExclude {
            loc: SourceLoc::default(),
        };
        assert_eq!(
            err.reason_code(),
            Some("selector_unlisted_with_include_exclude")
        );
        assert!(err
            .to_string()
            .contains("selector_unlisted_with_include_exclude"));
    }

    #[test]
    fn reason_code_strict_resource_coverage_invalid_stage() {
        let err = ConfigError::StrictResourceCoverageInvalidStage {
            loc: SourceLoc::default(),
            variable: "trust".into(),
            stage: "input_validation".into(),
        };
        assert_eq!(
            err.reason_code(),
            Some("strict_resource_coverage_invalid_stage")
        );
        assert!(err
            .to_string()
            .contains("strict_resource_coverage_invalid_stage"));
        assert!(err.to_string().contains("trust"));
    }

    #[test]
    fn reason_code_strict_resource_coverage_uncovered() {
        let err = ConfigError::StrictResourceCoverageUncovered {
            loc: SourceLoc::default(),
            variable: "trust".into(),
            resources: "tool:send_email".into(),
        };
        assert_eq!(
            err.reason_code(),
            Some("strict_resource_coverage_uncovered")
        );
        assert!(err
            .to_string()
            .contains("strict_resource_coverage_uncovered"));
        assert!(err.to_string().contains("tool:send_email"));
    }

    #[test]
    fn reason_code_unknown_resource_field() {
        let err = ConfigError::UnknownResourceField {
            loc: SourceLoc::default(),
            resource: "tool:send_email".into(),
            field: "labels".into(),
        };
        assert_eq!(err.reason_code(), Some("unknown_resource_field"));
        assert!(err.to_string().contains("unknown_resource_field"));
        assert!(err.to_string().contains("labels"));
    }

    #[test]
    fn reason_code_unknown_top_level_field() {
        let err = ConfigError::UnknownTopLevelField {
            loc: SourceLoc::default(),
            field: "ifc".into(),
        };
        assert_eq!(err.reason_code(), Some("unknown_top_level_field"));
        assert!(err.to_string().contains("unknown_top_level_field"));
        assert!(err.to_string().contains("ifc"));
    }

    #[test]
    fn non_discriminant_variants_return_none() {
        // Every `ConfigError` variant carries a stable
        // `reason_code()` so SDK wrappers can dispatch on it. The
        // assertion below pins the closed-registry invariant: a
        // representative variant returns Some(_) with a snake_case
        // discriminant.
        let err = ConfigError::Schema {
            loc: SourceLoc::default(),
            message: "generic".into(),
        };
        assert_eq!(err.reason_code(), Some("schema_violation"));
    }

    #[test]
    fn to_loader_wire_carries_path_line_column_and_code() {
        let err = ConfigError::Schema {
            loc: SourceLoc {
                path: Some(PathBuf::from("/tmp/x.yaml")),
                line: Some(7),
                column: Some(3),
            },
            message: "guard policy 'foo': missing required field".into(),
        };
        let wire = err.to_loader_wire();
        assert_eq!(wire.code, "schema_violation");
        assert_eq!(wire.path.as_deref(), Some("/tmp/x.yaml"));
        assert_eq!(wire.line, Some(7));
        assert_eq!(wire.column, Some(3));
        assert!(wire.message.contains("guard policy 'foo'"));
        // JSON round-trip.
        let json = wire.to_json();
        let v: serde_json::Value = serde_json::from_str(&json).unwrap();
        assert_eq!(v["code"], "schema_violation");
        assert_eq!(v["path"], "/tmp/x.yaml");
        assert_eq!(v["line"], 7);
    }

    #[test]
    fn to_loader_wire_handles_missing_loc_gracefully() {
        let err = ConfigError::ExtendsCycle {
            path: "a.yaml -> b.yaml -> a.yaml".into(),
        };
        let wire = err.to_loader_wire();
        assert_eq!(wire.code, "cycle_detected");
        assert!(wire.path.is_none());
        assert!(wire.line.is_none());
        assert!(wire.remediation.is_some()); // cycle has a hint
        assert!(wire.message.contains("cycle"));
    }

    #[test]
    fn yaml_unknown_escape_appends_regex_hint() {
        // Exercise a regex written inside a
        // double-quoted YAML scalar with a raw `\s` escape.
        let yaml = "metadata:\n  name: \"(?i)ignore\\s+previous\"\n";
        let err = serde_yaml::from_str::<serde_yaml::Value>(yaml).unwrap_err();
        let wrapped = ConfigError::Yaml {
            loc: SourceLoc::from_path(PathBuf::from("bad.yaml")),
            source: err,
        };
        let msg = wrapped.to_string();
        assert!(
            msg.contains("unknown escape character"),
            "expected underlying serde-yaml message, got: {msg}"
        );
        assert!(
            msg.contains("single quotes"),
            "expected single-quote hint, got: {msg}"
        );
        assert!(
            msg.contains("doubled backslashes"),
            "expected doubled-backslash hint, got: {msg}"
        );
    }

    #[test]
    fn yaml_generic_error_has_no_regex_hint() {
        // Generic YAML errors (e.g. plain syntax problems) must NOT get
        // the regex hint — keep the default error terse.
        let yaml = "foo: [unterminated";
        let err = serde_yaml::from_str::<serde_yaml::Value>(yaml).unwrap_err();
        let wrapped = ConfigError::Yaml {
            loc: SourceLoc::from_path(PathBuf::from("bad.yaml")),
            source: err,
        };
        let msg = wrapped.to_string();
        assert!(
            !msg.contains("single quotes"),
            "regex hint should not fire on unrelated YAML errors, got: {msg}"
        );
    }
}
