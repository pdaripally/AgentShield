//! End-to-end smoke for issue #26 — remote `extends:` over real HTTPS.
//!
//! Drives `agent_shield_core::loader::load_from_path` against a leaf
//! `.guardrails.yaml` that pulls a parent file from a real public URL
//! (`gist.githubusercontent.com`). Verifies four behaviours:
//!
//!   1. **Happy path** — correct SRI loads and merges.
//!   2. **Tamper detection** — flipped SRI fails with `IntegrityMismatch`.
//!   3. **TLS-only redirects** — `http://` URL fails with `UrlExtendsBadScheme`
//!      *without* opening a socket (caught at the resolve_child shape check).
//!   4. **`unverified: true` opt-out** — the same URL loads without a
//!      pin and the merged config still contains the remote tier's content.
//!
//! Run with: `cargo run -p agent_shield_core --example remote_extends_smoke -- <url> <sri>`

use std::env;
use std::path::PathBuf;

use agent_shield_core::errors::ConfigError;
use agent_shield_core::loader::load_from_path;

fn write_leaf(dir: &PathBuf, name: &str, contents: &str) -> PathBuf {
    std::fs::create_dir_all(dir).unwrap();
    let p = dir.join(name);
    std::fs::write(&p, contents).unwrap();
    p
}

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() < 3 {
        eprintln!(
            "usage: {} <https-url> <sha256-sri> [expected-policy-name]\n\
             \n\
             The optional third argument lets the smoke test verify that a\n\
             specific guard policy name from the remote file survives into the\n\
             merged config. Omit it to only verify that the merge succeeds and\n\
             that the remote tier merged into the objective (tier count >= 2).\n",
            args[0]
        );
        std::process::exit(2);
    }
    let url = &args[1];
    let sri = &args[2];
    let expected_policy: Option<&str> = args.get(3).map(String::as_str);

    let dir = std::env::temp_dir().join("agent_shield_remote_smoke");
    let _ = std::fs::remove_dir_all(&dir);
    println!("tmpdir: {}", dir.display());
    println!("remote url: {url}");
    println!("declared SRI: {sri}");
    if let Some(p) = expected_policy {
        println!("expected policy name: {p}");
    }
    println!();

    // ── Scenario 1: happy path ──────────────────────────────────────────
    let leaf = write_leaf(
        &dir,
        "leaf-good.guardrails.yaml",
        &format!(
            r#"extends:
  - url: "{url}"
    integrity: "{sri}"

metadata:
  name: "leaf-good"
  version: "0.1.0"
  agent_shield_version: "1.0"

objective:
  goal:
    - "App-specific overlay on top of the remote org baseline."
"#
        ),
    );

    println!("[1/4] happy path: loading leaf that extends real public URL with valid SRI...");
    match load_from_path(&leaf) {
        Ok(merged) => {
            println!(
                "      ✅ load OK. merged.metadata.name = {:?}",
                merged.metadata.name
            );
            println!(
                "      merged.input_validation.guard_policies.len() = {}",
                merged.input_validation.guard_policies.len()
            );
            let policy_names: Vec<&str> = merged
                .input_validation
                .guard_policies
                .iter()
                .map(|gp| gp.name.as_str())
                .collect();
            println!("      input-stage policies after merge: {:?}", policy_names);
            if let Some(expected) = expected_policy {
                assert!(
                    policy_names.iter().any(|n| *n == expected),
                    "expected the remote `{expected}` guard policy to be present in the merged config"
                );
            }
            // The remote tier should appear in the merged objective.
            // We can't assume specific text without forcing every smoke
            // run to point at the same fixture, so we just assert that
            // there is more than one tier — the leaf contributes one,
            // any successful remote merge contributes at least one
            // more.
            assert!(
                merged.objective.tiers.len() >= 2,
                "expected the remote tier to merge into the objective; got {} tier(s)",
                merged.objective.tiers.len()
            );
            println!("      ✅ remote bytes verifiably present in merged config");
        }
        Err(e) => {
            eprintln!("      ❌ unexpected failure on happy path: {e}");
            std::process::exit(1);
        }
    }
    println!();

    // ── Scenario 2: tampered SRI (one-character flip) ───────────────────
    let mut tampered = sri.to_string();
    // Flip the last non-padding base64 char by one position. Keep length and
    // alphabet valid so we hit `IntegrityMismatch` (digest verification),
    // not `UrlExtendsBadIntegrity` (SRI literal shape).
    let bytes: Vec<char> = tampered.chars().collect();
    let mut idx = bytes.len() - 1;
    while idx > 0 && (bytes[idx] == '=' || !bytes[idx].is_ascii_alphanumeric()) {
        idx -= 1;
    }
    let flip = if bytes[idx] == 'A' { 'B' } else { 'A' };
    tampered = bytes
        .iter()
        .enumerate()
        .map(|(i, c)| if i == idx { flip } else { *c })
        .collect();

    let leaf_tampered = write_leaf(
        &dir,
        "leaf-tampered.guardrails.yaml",
        &format!(
            r#"extends:
  - url: "{url}"
    integrity: "{tampered}"

metadata:
  name: "leaf-tampered"
  version: "0.1.0"
  agent_shield_version: "1.0"
"#
        ),
    );

    println!("[2/4] tamper detection: same URL, one-char-flipped SRI ({tampered})...");
    match load_from_path(&leaf_tampered) {
        Ok(_) => {
            eprintln!("      ❌ load succeeded; tampered SRI should have been rejected");
            std::process::exit(1);
        }
        Err(ConfigError::IntegrityMismatch {
            url: u,
            expected,
            actual,
        }) => {
            println!("      ✅ IntegrityMismatch as expected");
            println!("      url: {u}");
            println!("      declared: {expected}");
            println!("      actual:   {actual}");
        }
        Err(e) => {
            eprintln!("      ❌ wrong error variant: {e:?}");
            std::process::exit(1);
        }
    }
    println!();

    // ── Scenario 3: http:// is rejected without opening a socket ────────
    let http_url = url.replacen("https://", "http://", 1);
    let leaf_http = write_leaf(
        &dir,
        "leaf-http.guardrails.yaml",
        &format!(
            r#"extends:
  - url: "{http_url}"
    integrity: "{sri}"

metadata:
  name: "leaf-http"
  version: "0.1.0"
  agent_shield_version: "1.0"
"#
        ),
    );

    println!("[3/4] http:// rejection: same content via plaintext URL...");
    match load_from_path(&leaf_http) {
        Ok(_) => {
            eprintln!("      ❌ load succeeded; http:// URL should have been rejected");
            std::process::exit(1);
        }
        Err(ConfigError::UrlExtendsBadScheme { url: u, .. }) => {
            println!("      ✅ UrlExtendsBadScheme as expected (no socket opened)");
            println!("      url: {u}");
        }
        Err(e) => {
            eprintln!("      ❌ wrong error variant: {e:?}");
            std::process::exit(1);
        }
    }
    println!();

    // ── Scenario 4: unverified: true loads without a pin ───────────────
    let leaf_unverified = write_leaf(
        &dir,
        "leaf-unverified.guardrails.yaml",
        &format!(
            r#"extends:
  - url: "{url}"
    unverified: true

metadata:
  name: "leaf-unverified"
  version: "0.1.0"
  agent_shield_version: "1.0"

objective:
  goal:
    - "Trust deferred to deployment-time controls (e.g., internal mirror)."
"#
        ),
    );

    println!("[4/4] `unverified: true` opt-out: same URL, no integrity pin...");
    match load_from_path(&leaf_unverified) {
        Ok(merged) => {
            println!(
                "      ✅ load OK. merged.metadata.name = {:?}",
                merged.metadata.name
            );
            let policy_names: Vec<&str> = merged
                .input_validation
                .guard_policies
                .iter()
                .map(|gp| gp.name.as_str())
                .collect();
            println!("      input-stage policies after merge: {:?}", policy_names);
            if let Some(expected) = expected_policy {
                assert!(
                    policy_names.iter().any(|n| *n == expected),
                    "expected the remote `{expected}` guard policy to be present in the merged config"
                );
            }
            // Same invariant as the pinned happy path: leaf contributes
            // one tier, any successful remote merge contributes at
            // least one more. Confirms the unverified bytes actually
            // landed in the merged config rather than being silently
            // dropped.
            assert!(
                merged.objective.tiers.len() >= 2,
                "expected the remote tier to merge into the objective on the unverified path; got {} tier(s)",
                merged.objective.tiers.len()
            );
            println!("      ✅ remote bytes present even though byte check was opted out");
        }
        Err(e) => {
            eprintln!("      ❌ unexpected failure on unverified path: {e}");
            std::process::exit(1);
        }
    }

    println!();
    println!("all four scenarios passed against the live URL.");
}
