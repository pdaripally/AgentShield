"""Internal helpers for canonicalising the wire shape between the Rust
core and the Python surface.

The Rust core emits snake_case JSON for every envelope. Python's
dataclasses use snake_case attributes, so the only real work
``from_dict`` does is filter unexpected keys and let collection-typed
fields fall back to their ``default_factory`` when the wire payload
carries ``null``.

Rather than hand-roll a per-class ``from_dict`` body, every dataclass
that mirrors a wire envelope routes through :func:`from_wire_dict`.
"""
from __future__ import annotations

import dataclasses
from typing import Any, Dict, Mapping, Type, TypeVar

T = TypeVar("T")


def from_wire_dict(cls: Type[T], data: Mapping[str, Any] | None) -> T:
    """Build a dataclass instance from a wire payload dict.

    * Keys present in ``data`` but not declared on the dataclass are
      dropped — forward-compatible with new core fields.
    * ``None`` for a field with a ``default_factory`` (collection
      defaults) is replaced by the factory value, matching the
      previous defensive ``dict(d.get(k) or {})`` pattern.
    """
    if data is None:
        data = {}
    field_defs = {f.name: f for f in dataclasses.fields(cls)}  # type: ignore[arg-type]
    kwargs: Dict[str, Any] = {}
    for k, v in data.items():
        f = field_defs.get(k)
        if f is None:
            continue
        if v is None and f.default_factory is not dataclasses.MISSING:  # type: ignore[misc]
            continue
        kwargs[k] = v
    return cls(**kwargs)  # type: ignore[call-arg]
