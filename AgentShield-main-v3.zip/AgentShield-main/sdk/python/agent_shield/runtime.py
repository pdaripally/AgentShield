"""High-level Pythonic wrapper over the native runtime.

The wrapper presents:

* :class:`RuntimeBuilder` — fluent builder, hooks accept either Protocol
  implementations or plain callables.
* :class:`Runtime` — built (immutable) runtime; spawns sessions.
* :class:`Session` — per-conversation session with context-manager
  support.
* :class:`StageVerdict` — typed verdict dataclass returned by every
  ``validate_*`` call.
* :class:`Lifetime` — small helper for the runtime lifetime grammar.
* :class:`PerfTelemetry` — three-state opt-in for the v8 perf-logging
  instrumentation.
"""
from __future__ import annotations

import inspect
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Mapping, Optional, Union

from .hooks import (
    AgentResolver,
    AgentResolverCallable,
    ClassifierCaller,
    ClassifierCallable,
    ClassifierVerdict,
    DelegateDispatcher,
    DelegateDispatcherCallable,
    DelegateRequest,
    HumanResolveRequest,
    HumanResolver,
    HumanResolverCallable,
    LlmCallable,
    LlmCaller,
    LlmResponse,
    ResolverRequest,
    ResolverResponse,
)
from .observability import (
    ObservabilityProvider,
    ShieldLogEvent,
    make_provider,
)
from .streaming import StreamingGuard
from ._wire import from_wire_dict

if TYPE_CHECKING:
    from .config import CompiledPolicy, GuardrailsConfig

# Native module — guarded so import failure surfaces cleanly.
try:
    from agent_shield import _native  # type: ignore[attr-defined]
except (ImportError, AttributeError) as e:  # pragma: no cover
    raise ImportError(
        "agent_shield native module not available — run "
        "`maturin develop` in sdk/python/ first"
    ) from e


# ── Lifetime helper ─────────────────────────────────────────────────────


@dataclass
class Lifetime:
    """Small helper for the runtime lifetime grammar.

    Use the class methods to construct each form, then pass the
    instance (or its serialized form) to :meth:`Session.emit_event`::

        Lifetime.per_session()
        Lifetime.until_event("incident.threat_cleared")
        Lifetime.for_duration("PT5M")
        Lifetime.map(allow="per_call", deny="per_session")

    The runtime accepts either a :class:`Lifetime` instance or a raw
    string / dict matching the YAML grammar.
    """

    payload: Union[str, Dict[str, Any]]

    @classmethod
    def per_call(cls) -> "Lifetime":
        return cls("per_call")

    @classmethod
    def per_turn(cls) -> "Lifetime":
        return cls("per_turn")

    @classmethod
    def per_session(cls) -> "Lifetime":
        return cls("per_session")

    @classmethod
    def per_request(cls) -> "Lifetime":
        return cls("per_request")

    @classmethod
    def for_duration(cls, duration: str) -> "Lifetime":
        return cls({"for": duration})

    @classmethod
    def until_event(cls, *events: str) -> "Lifetime":
        # P12.6: reject the empty case so we surface a clear Python-side
        # ValueError instead of forwarding `[]` to the loader (which
        # rejects empty `until_event` lists).
        if not events:
            raise ValueError(
                "Lifetime.until_event requires at least one event id"
            )
        if len(events) == 1:
            return cls({"until_event": events[0]})
        return cls({"until_event": list(events)})

    @classmethod
    def map(
        cls,
        *,
        allow: Union[str, Dict[str, Any]],
        deny: Union[str, Dict[str, Any]],
        cancelled: Optional[Union[str, Dict[str, Any]]] = None,
    ) -> "Lifetime":
        m: Dict[str, Any] = {"allow": allow, "deny": deny}
        if cancelled is not None:
            m["cancelled"] = cancelled
        return cls(m)

    def to_native(self) -> Union[str, Dict[str, Any]]:
        return self.payload


def _coerce_lifetime(
    lifetime: Optional[Union[Lifetime, str, Dict[str, Any]]],
) -> Optional[Union[str, Dict[str, Any]]]:
    # Thin wrapper around the canonical native parser shared by every
    # SDK (`agent_shield_core::lifetime::parse_lifetime`). The PyO3
    # binding accepts the bare keyword / map / `for:` / `until_event:`
    # shapes directly and returns the canonical Python value.
    if lifetime is None:
        return None
    if isinstance(lifetime, Lifetime):
        lifetime = lifetime.to_native()
    return _native.parse_lifetime(lifetime)


# ── PerfTelemetry (v8 perf-logging Phase 1) ─────────────────────────────


class PerfTelemetry(str, Enum):
    """Gating level for the v8 perf-logging instrumentation (PR5/PR6).

    Default is :attr:`OFF` — zero perf events emit, the legacy event
    stream is byte-identical to the pre-v8 baseline. Pick
    :attr:`EXTERNAL` if you only want LLM + classifier cost signals
    (the predicted common-case ask); pick :attr:`FULL` for the
    complete stage / policy / detection / LLM / classifier event
    stream (diagnostic mode).

    Used by :meth:`RuntimeBuilder.with_perf_telemetry`. The wire
    representation is the snake_case string used at the FFI / spec
    boundary; subclassing :class:`str` makes the enum trivially
    serialisable.
    """

    OFF = "off"
    EXTERNAL = "external"
    FULL = "full"


# ── StageVerdict ─────────────────────────────────────────────────────────


@dataclass
class StageVerdict:
    """Typed verdict returned by every ``validate_*`` call."""

    allowed: bool
    action: Optional[str] = None
    reason: Optional[str] = None
    policy: Optional[str] = None
    evaluate_when_index: Optional[int] = None
    bypassed_by_allowed_when: bool = False
    redaction: Optional[str] = None
    appended: Optional[str] = None
    prepended: Optional[str] = None
    #: Side-channel description of a deny that was caused by a
    #``kind: tool`` (or synthesised ``kind: human``) resolver
    #: suspending while waiting for the agent to call its tool. The
    #: dict shape is ``{"tool", "variable", "prompt", "request_id",
    #"kind"}``. The host is expected to surface this to the agent's
    #: framework so the agent's LLM calls the named tool with the
    #: rendered prompt; the tool's ``populated_by:`` writes the
    #: response back into the variable, which unblocks the next gate
    #: evaluation. ``None`` for non-deny verdicts and for denies that
    #: did not arise from suspension.
    pending_resolution: Optional[Dict[str, Any]] = None
    #: Canonical SHA-256 hash of the invocation BEFORE policy
    #: evaluation, for invocation-bound stages. Hosts SHOULD
    #: compare this against the invocation they actually execute to
    #: detect validate-then-mutate bugs. ``None`` for non-invocation
    #: stages (input / output) and for verdicts emitted before the
    #: branch's ``5ae96a2`` Rust core landed.
    invocation_hash: Optional[str] = None
    #: Canonical hash AFTER policy evaluation. Differs from
    #``invocation_hash`` only when a Stage 3 transform intentionally
    #: rewrote the invocation parameters (``redact`` / ``append`` /
    #``prepend``). The host MUST execute the
    #: post-validation invocation, not the pre-validation one.
    post_validation_invocation_hash: Optional[str] = None
    #: Ordered manifest of every transform applied during this stage
    #: Each entry attributes a redaction span — or an
    #: append / prepend text — back to the policy + ``evaluate_when[]``
    #: entry that produced it. Each dict has keys:
    #: ``policy``, ``evaluate_when_index``, ``action``,
    #: ``span_start``, ``span_end``, ``replacement``. ``span_start`` and
    #: ``span_end`` are codepoint offsets into the pre-transform subject
    #: are ``None`` for ``append`` / ``prepend`` actions (in which
    #: case ``replacement`` carries the appended / prepended text).
    #: Empty list when the verdict is a clean ``allow`` or a ``block``.
    applied_transforms: List[Dict[str, Any]] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "StageVerdict":
        return from_wire_dict(cls, d)

    def __bool__(self) -> bool:  # truthy when the call may proceed.
        return self.allowed


# ── Variable state ──────────────────────────────────────────────────────


@dataclass
class VariableState:
    """Snapshot of a variable's tracker entry."""

    value: Any = None
    status: str = "unset"
    set_at: Optional[str] = None
    expires_at: Optional[str] = None
    deny_reason: Optional[str] = None
    # Spec: when ``status == 'denied'``
    # this discriminates between the two terminal resolver outcomes —
    # ``'deny'`` (the resolver returned ``decision: deny``) or
    # ``'cancelled'`` (the resolver / human / operator returned
    # ``decision: cancelled``). ``None`` while ``status!= 'denied'``.
    deny_kind: Optional[str] = None
    source_kind: Optional[str] = None
    set_by: Optional[str] = None
    source_params: Optional[Any] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "VariableState":
        return from_wire_dict(cls, d)


# ── Resolver bridge helpers ──────────────────────────────────────────────


# The canonical envelope field set. Mirrors Rust core's
# ``deny_unknown_fields`` on ``ResolverResponse``: any dict key outside
# this set in a Python resolver callback's return value is a hard error
# at the SDK boundary, not a silent drop.
_RESOLVER_ENVELOPE_FIELDS = frozenset({"decision", "value", "set_variables", "reason"})


def _coerce_resolver_response(value: Any) -> Dict[str, Any]:
    """Normalize a hook return value into a wire dict.

    Spec envelope shape:

        {decision, value, set_variables, reason}

    The ``ResolverResponse`` dataclass is the typed entry point and is
    accepted verbatim (callers using the typed API have made an explicit
    choice; ``value=None`` from the dataclass is treated as an explicit
    null).

    For the loose dict path, fail closed when ``decision == 'allow'``
    is returned without an explicit ``value`` field — previously the SDK
    silently normalized that to a resolved variable with ``value: None``,
    which is a fail-open contract violation if the resolver author simply
    forgot to publish the value.

    ``deny`` / ``cancelled`` envelopes are unaffected by the value check
    — neither sets a variable value, so ``value`` remains optional there.

    The Rust wire type (``crate::resolver::ResolverResponse`` in
    ``agent_shield_core``) is ``serde(deny_unknown_fields)`` — any field
    outside the canonical four is a hard parse error. The Python loose-
    dict path used to silently drop unknown keys, so a typo like
    ``{"descision": "allow", "value": True}`` passed through as
    "envelope missing decision" rather than the diagnostic the author
    would expect. Mirror Rust's behaviour: reject unknown fields with a
    fail-closed envelope error that lists both the offending key(s) and
    the canonical field set, so typos surface at the resolver boundary
    rather than as confusing downstream failures.
    """
    if isinstance(value, ResolverResponse):
        return value.to_dict()
    if isinstance(value, dict):
        unknown = set(value.keys()) - _RESOLVER_ENVELOPE_FIELDS
        if unknown:
            from .errors import AgentShieldResolverEnvelopeError
            raise AgentShieldResolverEnvelopeError.unknown_fields(unknown)
        decision = value.get("decision")
        if decision == "allow" and "value" not in value:
            from .errors import AgentShieldResolverEnvelopeError
            raise AgentShieldResolverEnvelopeError(decision="allow")
        return value
    raise TypeError(
        f"resolver hook returned {type(value).__name__}; "
        f"expected ResolverResponse or dict"
    )


def _wrap_resolver(
    target: Union[AgentResolver, AgentResolverCallable],
    method_name: str,
) -> Callable[[Dict[str, Any]], Dict[str, Any]]:
    """Wrap a resolver Protocol/callable into a ``(dict) -> dict`` bridge."""

    def callable_form(req_dict: Dict[str, Any]) -> Dict[str, Any]:
        request = ResolverRequest.from_dict(req_dict)
        if hasattr(target, method_name) and callable(getattr(target, method_name)):
            response = getattr(target, method_name)(request)
        elif callable(target):
            response = target(request)
        else:
            raise TypeError(
                f"resolver target must implement `{method_name}` or be callable"
            )
        return _coerce_resolver_response(response)

    return callable_form


def _wrap_dispatcher(
    target: Union[DelegateDispatcher, DelegateDispatcherCallable],
) -> Callable[[Dict[str, Any]], Dict[str, Any]]:
    def callable_form(req_dict: Dict[str, Any]) -> Dict[str, Any]:
        request = DelegateRequest.from_dict(req_dict)
        if hasattr(target, "dispatch") and callable(target.dispatch):  # type: ignore[union-attr]
            response = target.dispatch(request)  # type: ignore[union-attr]
        elif callable(target):
            response = target(request)
        else:
            raise TypeError("delegate dispatcher must have `dispatch` or be callable")
        return _coerce_resolver_response(response)

    return callable_form


def _wrap_human_resolver(
    target: Union[HumanResolver, HumanResolverCallable],
) -> Callable[[Dict[str, Any]], Dict[str, Any]]:
    """Wrap a human-resolver Protocol/callable into a
    ``(dict) -> dict`` bridge. Mirrors :func:`_wrap_resolver` but
    constructs the typed :class:`HumanResolveRequest` envelope (which
    carries spec ``approval_nonce`` and related anti-replay
    fields), then validates the response envelope through the
    same :func:`_coerce_resolver_response` path as agent / delegate
    resolvers so the fail-closed resolver-envelope contract applies uniformly."""

    def callable_form(req_dict: Dict[str, Any]) -> Dict[str, Any]:
        request = HumanResolveRequest.from_dict(req_dict)
        if hasattr(target, "resolve") and callable(target.resolve):
            response = target.resolve(request)  # type: ignore[union-attr]
        elif callable(target):
            response = target(request)
        else:
            raise TypeError(
                "human resolver target must implement `resolve` or be callable"
            )
        return _coerce_resolver_response(response)

    return callable_form


def _wrap_llm_caller(
    target: Union[LlmCaller, LlmCallable],
) -> Callable[[Optional[str], str], Any]:
    def callable_form(configuration_id: Optional[str], prompt: str) -> Any:
        if hasattr(target, "call") and callable(target.call):  # type: ignore[union-attr]
            out = target.call(configuration_id, prompt)  # type: ignore[union-attr]
        elif callable(target):
            out = target(configuration_id, prompt)
        else:
            raise TypeError("LLM caller must have `call` or be callable")
        if isinstance(out, LlmResponse):
            return out.to_dict()
        return out

    return callable_form


def _wrap_classifier(
    target: Union[ClassifierCaller, ClassifierCallable],
    configuration_resolver: Optional[
        Callable[[str], Optional[Dict[str, Any]]]
    ] = None,
) -> Callable[[str, str], Any]:
    """Bridge a Python classifier caller to the runtime's wire shape.

    The runtime invokes registered classifier callers with the canonical
    ``(configuration_id, subject)`` pair. This wrapper translates that
    into one of two host-facing call shapes, picked per-target via
    :func:`inspect.signature` at registration time (cached on the
    closure):

    * 2-arg (legacy): ``caller(configuration_id, subject) -> Verdict``
    * 3-arg (new): ``caller(configuration_id, subject, configuration) -> Verdict``

    The 3-arg form receives the resolved YAML ``configurations[]`` entry
    so the host can read ``endpoint``, ``headers``, ``provider_config``,
    ``threshold``, ``category_thresholds`` etc. without re-parsing YAML
    or hard-coding values. When ``configuration_resolver`` is omitted
    (or returns ``None`` for the active id) the 3-arg form receives an
    empty dict so it never silently sees stale data.

    Mirrors the arity-flexible pattern already used by
    :func:`_call_thunk_with_optional_input` (`_shield.py`) and by the
    LLM caller's optional ``configuration_resolver`` kwarg.
    """
    # Resolve the concrete callable once: prefer `target.classify` when
    # present (Protocol path), else the target itself (plain callable).
    if hasattr(target, "classify") and callable(target.classify):  # type: ignore[arg-type]
        actual: Callable[..., Any] = target.classify  # type: ignore[union-attr]
    elif callable(target):
        actual = target  # type: ignore[assignment]
    else:
        raise TypeError("classifier caller must have `classify` or be callable")

    arity = _classifier_positional_arity(actual)

    def callable_form(configuration_id: str, subject: str) -> Any:
        if arity >= 3:
            cfg: Dict[str, Any] = {}
            if configuration_resolver is not None:
                try:
                    resolved = configuration_resolver(configuration_id)
                except Exception:
                    resolved = None
                if isinstance(resolved, dict):
                    cfg = resolved
            out = actual(configuration_id, subject, cfg)
        else:
            out = actual(configuration_id, subject)
        if isinstance(out, ClassifierVerdict):
            return out.to_dict()
        return out

    return callable_form


def _classifier_positional_arity(fn: Callable[..., Any]) -> int:
    """Return the count of positional parameters ``fn`` accepts.

    Returns 3 (matches the 3-arg form) when the callable accepts at
    least three positional parameters or declares ``*args``. Returns 2
    when it accepts exactly two. Falls back to 2 — the back-compatible
    shape — whenever :func:`inspect.signature` raises (built-ins,
    certain C-implemented bound methods) so legacy hosts continue to
    work unchanged.
    """
    try:
        sig = inspect.signature(fn)
    except (TypeError, ValueError):
        return 2
    count = 0
    for param in sig.parameters.values():
        if param.kind == inspect.Parameter.VAR_POSITIONAL:
            return 3
        if param.kind in (
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
        ):
            count += 1
    return 3 if count >= 3 else 2


# ── Public per-configuration LLM caller dispatcher ───────────────────────


def make_configuration_caller(
    callers: Mapping[str, Callable[[str], Any]],
    *,
    default: Optional[Callable[[str], Any]] = None,
) -> Callable[[Optional[str], str], Any]:
    """Build an LLM caller that routes by EXACT ``configuration_id`` match.

    The runtime invokes registered LLM callers with the canonical
    ``(configuration_id, prompt)`` signature (see
    :meth:`RuntimeBuilder.register_llm_caller`). When a host wants
    different underlying callers per YAML ``configurations[]`` entry
    (different model, different mocked response, different LLM
    provider) this helper produces the single dispatcher object the
    runtime expects.

    Args:
        callers: Mapping of YAML ``configurations[].id`` to a
            single-argument caller of shape ``(prompt: str) -> str``
            (or any object the runtime accepts). Routing is by exact
            match — no substring hints, no Stage-name aliases.
        default: Fallback caller used when ``configuration_id`` is
            ``None`` or absent from ``callers``. When omitted and an
            unknown id is dispatched, the dispatcher raises
            :class:`RuntimeError`.

    Returns:
        A callable matching the runtime's ``(configuration_id, prompt)
        -> str`` signature, ready to pass to
        :meth:`RuntimeBuilder.register_llm_caller`.

    Prefer the ``configuration_resolver`` kwarg on
    :meth:`agent_shield.adapters._capabilities.LlmCallerFactory.make_caller`
    when you just need to honour YAML-declared ``model:`` /
    ``provider:`` / ``max_tokens:`` selection through the same client;
    use this helper only when the host genuinely needs distinct caller
    objects per configuration id.
    """
    routes: Dict[str, Callable[[str], Any]] = dict(callers)

    def dispatcher(configuration_id: Optional[str], prompt: str) -> Any:
        if configuration_id is not None:
            caller = routes.get(configuration_id)
            if caller is not None:
                return caller(prompt)
        if default is not None:
            return default(prompt)
        # Cross-SDK parity: render the missing id as `null` (matching
        # Rust/.NET/Node) rather than Python's native `None`. Known ids
        # are single-quoted to match Rust/.NET; Node uses double quotes
        # but the structure is otherwise identical.
        id_repr = "null" if configuration_id is None else f"'{configuration_id}'"
        known = ", ".join(f"'{k}'" for k in sorted(routes))
        raise RuntimeError(
            f"no LLM caller registered for configuration_id={id_repr}; "
            f"known ids: [{known}]; no default provided",
        )

    return dispatcher


# ── Public RuntimeBuilder ────────────────────────────────────────────────


class RuntimeBuilder:
    """Fluent builder for :class:`Runtime`.

    Hosts construct one builder per agent, register their hooks, and
    call :meth:`build` to obtain the immutable runtime.
    """

    def __init__(self, native_builder: Any) -> None:
        self._native = native_builder

    # ── Constructors ────────────────────────────────────────────────

    @classmethod
    def from_yaml(cls, path: str) -> "RuntimeBuilder":
        return cls(_native.RuntimeBuilder.from_yaml(str(path)))

    @classmethod
    def from_yaml_chain(cls, paths: List[str]) -> "RuntimeBuilder":
        return cls(_native.RuntimeBuilder.from_yaml_chain([str(p) for p in paths]))

    @classmethod
    def from_yaml_strings(cls, yamls: List[str]) -> "RuntimeBuilder":
        """Load a chain of YAML *strings* (no filesystem access).

        The rightmost string is the leaf; preceding strings are merged
        as ancestors with leaf-wins semantics. ``extends:`` is not
        supported on string inputs — callers building chains in memory
        should curate the order explicitly.
        """
        return cls(_native.RuntimeBuilder.from_yaml_strings([str(y) for y in yamls]))

    @classmethod
    def from_config(
        cls, config: Union[str, List[str], "GuardrailsConfig", "CompiledPolicy"],
    ) -> "RuntimeBuilder":
        """Construct a builder from any supported configuration shape.

        Accepts:

        * a single YAML path (``str`` / ``Path``)
        * a list of YAML paths (chain — leaf last)
        * a :class:`GuardrailsConfig` (composable object model)
        * a :class:`CompiledPolicy` (the materialised, hashable form
          returned by :meth:`GuardrailsConfig.compile`)
        """
        # Local import to avoid a circular import at module load.
        from agent_shield.config import CompiledPolicy, GuardrailsConfig

        if isinstance(config, CompiledPolicy):
            return cls(_native.RuntimeBuilder.from_compiled_policy(config._native_handle))
        if isinstance(config, GuardrailsConfig):
            return cls.from_config(config.compile())
        if isinstance(config, list):
            return cls.from_yaml_chain(config)
        return cls.from_yaml(config)

    # ── Hook registration ───────────────────────────────────────────

    def register_agent_resolver(
        self,
        target: Union[AgentResolver, AgentResolverCallable],
    ) -> "RuntimeBuilder":
        self._native.register_agent_resolver(_wrap_resolver(target, "resolve"))
        return self

    def register_human_resolver(
        self,
        target: Union[HumanResolver, HumanResolverCallable],
    ) -> "RuntimeBuilder":
        """Register the runtime's active ``kind: human`` resolver
        callback. Last call wins.

        YAML declares only the human resolver policy fields::

            on_demand_by:
              kind: human
              prompt: "Approve sending email to ${@tool.params.to}?"
              timeout_ms: 60000

        The runtime calls the registered callback synchronously with a
        :class:`HumanResolveRequest` and applies the returned         envelope to the variable. If no callback is registered,
        ``kind: human`` denies fail-closed.
        """
        self._native.register_human_resolver(_wrap_human_resolver(target))
        return self

    def register_delegate_dispatcher(
        self,
        target: Union[DelegateDispatcher, DelegateDispatcherCallable],
    ) -> "RuntimeBuilder":
        self._native.register_delegate_dispatcher(_wrap_dispatcher(target))
        return self

    def register_llm_caller(
        self,
        target: Union[LlmCaller, LlmCallable],
    ) -> "RuntimeBuilder":
        self._native.register_llm_caller(_wrap_llm_caller(target))
        return self

    def register_classifier_caller(
        self,
        target: Union[ClassifierCaller, ClassifierCallable],
        *,
        configuration_resolver: Optional[
            Callable[[str], Optional[Dict[str, Any]]]
        ] = None,
    ) -> "RuntimeBuilder":
        """Register a classifier caller used by ``classifier`` guard
        policies (spec +).

        ``target`` may be a Protocol implementation (with a
        ``classify(configuration_id, subject) -> Verdict`` method) or a
        plain callable. The runtime detects the callable's positional
        arity at registration time and dispatches accordingly:

        * 2-arg form (legacy): ``(configuration_id, subject)`` — the
          back-compatible shape every existing host uses.
        * 3-arg form (new): ``(configuration_id, subject, configuration)``
          — receives the resolved YAML ``configurations[]`` entry
          (``endpoint``, ``headers``, ``provider_config``, ``threshold``,
          ``category_thresholds`` …) so the host can drive Azure AI
          Content Safety, Bedrock Guardrails, or any other HTTP
          classifier directly from YAML without re-parsing.

        ``configuration_resolver`` is an optional callback that maps a
        ``configuration_id`` to the corresponding YAML configuration
        dict. When omitted, the runtime falls back to its own snapshot
        of ``configurations[]`` taken at build time, so the common
        case "just register a 3-arg callback" works without any extra
        wiring.
        """
        # Snapshot the YAML `configurations[]` at register time so the
        # 3-arg form has a working resolver even when the host did not
        # provide one. The native builder exposes the parsed list via
        # `configurations()`; we index it by id once and serve dict
        # lookups from the closure.
        resolver = configuration_resolver
        if resolver is None:
            try:
                snapshot: Dict[str, Dict[str, Any]] = {
                    c["id"]: c for c in self._native.configurations() if "id" in c
                }
            except Exception:
                snapshot = {}

            def _default_resolver(cid: str) -> Optional[Dict[str, Any]]:
                return snapshot.get(cid)

            resolver = _default_resolver
        self._native.register_classifier_caller(
            _wrap_classifier(target, configuration_resolver=resolver),
        )
        return self

    def register_observability_provider(
        self,
        target: Union[ObservabilityProvider, Callable[[ShieldLogEvent], None]],
    ) -> "RuntimeBuilder":
        provider = make_provider(target)

        # Wrap so we deliver a typed dataclass to the host.
        class _Bridge:
            def __init__(self, p: ObservabilityProvider) -> None:
                self._p = p

            def emit(self, event_dict: Dict[str, Any]) -> None:
                self._p.emit(ShieldLogEvent.from_dict(event_dict))

            def shutdown(self) -> None:
                self._p.shutdown()

        self._native.register_observability_provider(_Bridge(provider))
        return self

    def register_extractor(
        self,
        name: str,
        extractor: Callable[[Any], Any],
    ) -> "RuntimeBuilder":
        self._native.register_extractor(name, extractor)
        return self

    def tool_retry_limit(self, n: int) -> "RuntimeBuilder":
        self._native.tool_retry_limit(int(n))
        return self

    def with_mode(self, mode: str) -> "RuntimeBuilder":
        """Set the runtime's effective enforcement mode (#14).

        ``mode`` is ``"active"`` (default) or ``"shadow"``. ``shadow``
        evaluates every validation stage, emits fully populated audit
        events, but never blocks, never invokes side-effecting
        resolvers, and never applies in-place transforms. The
        ``AGENT_SHIELD_MODE`` env var, when set, takes precedence
        over this call.
        """
        self._native.with_mode(str(mode))
        return self

    def with_perf_telemetry(
        self, mode: Union[PerfTelemetry, str],
    ) -> "RuntimeBuilder":
        """Opt into the v8 perf-logging instrumentation (PR5/PR6).

        ``mode`` is a :class:`PerfTelemetry` enum value (recommended)
        or its lower-case wire string (``"off"`` / ``"external"`` /
        ``"full"``). Default — when this method is never called — is
        :attr:`PerfTelemetry.OFF`, which emits zero perf events.

        - :attr:`PerfTelemetry.OFF` — diagnostic events fully
          suppressed; the event stream is byte-identical to the
          pre-v8 baseline.
        - :attr:`PerfTelemetry.EXTERNAL` — only ``llm_called`` and
          ``classifier_called`` events emit. Predicted common-case
          for adopters who want external-service cost signals
          without being drowned by stage / policy / detection events.
        - :attr:`PerfTelemetry.FULL` — every perf event emits
          (stage / policy / detection / LLM / classifier).

        See ``spec/SPECIFICATION.md`` for the per-event gating
        table.
        """
        if isinstance(mode, PerfTelemetry):
            wire = mode.value
        else:
            wire = str(mode).lower()
        self._native.with_perf_telemetry(wire)
        return self

    def supports_context_reset(self, supports: bool = True) -> "RuntimeBuilder":
        """Declare host capability for sub-session IFC scope reset
        (proof TC-3). Required when the merged config declares
        ``ifc.scope: per_turn`` or ``per_request``. Hosts that retain
        LLM context across these boundaries (LangChain memory,
        AutoGen group chats, persistent conversation IDs) MUST NOT
        call this with ``True``.
        """
        self._native.supports_context_reset(bool(supports))
        return self

    # ── Build ───────────────────────────────────────────────────────

    def build(self) -> "Runtime":
        return Runtime(self._native.build())


# ── Public Runtime ───────────────────────────────────────────────────────


class Runtime:
    """Immutable runtime — spawns one :class:`Session` per agent
    conversation."""

    def __init__(self, native_runtime: Any) -> None:
        self._native = native_runtime

    @staticmethod
    def configure_logging(level: Optional[str] = None) -> None:
        """Set up a sensible default logging config for Agent Shield.

        Reads :envvar:`AGENT_SHIELD_LOG_LEVEL` (DEBUG / INFO / WARNING /
        ERROR) when ``level`` is not provided. Idempotent — calling
        twice is harmless. Customer demos are the primary caller.
        """
        import logging
        import os

        resolved = (level or os.getenv("AGENT_SHIELD_LOG_LEVEL", "WARNING")).upper()
        numeric = getattr(logging, resolved, None)
        if not isinstance(numeric, int):
            numeric = logging.WARNING
        logger = logging.getLogger("agent_shield")
        if not logger.handlers:
            handler = logging.StreamHandler()
            handler.setFormatter(
                logging.Formatter("%(asctime)s [%(name)s] %(levelname)s: %(message)s")
            )
            logger.addHandler(handler)
        logger.setLevel(numeric)

    @property
    def metadata_name(self) -> str:
        return self._native.metadata_name()

    def flush_observability(self) -> None:
        """Block until every registered observability provider has
        drained its asynchronous worker queue.

        Tests that assert on captured events after performing
        :meth:`Session.validate_input` / ``validate_tool_call`` etc.
        must call this first because providers receive events through
        per-provider worker threads. :meth:`Session.__exit__` calls
        this automatically so the common
        ``with rt.new_session() as session: ...`` pattern sees
        synchronous semantics on exit.
        """
        self._native.flush_observability()

    @property
    def variable_names(self) -> List[str]:
        return list(self._native.variable_names())

    @property
    def mode(self) -> str:
        """Effective runtime mode (#14): ``"active"`` or ``"shadow"``.

        YAML ``mode:`` with ``AGENT_SHIELD_MODE`` env override. SDK
        orchestrators force ``ShieldMode.MONITOR`` in shadow mode.
        """
        return self._native.mode()

    def llm_configuration(self, configuration_id: str) -> Optional[Dict[str, Any]]:
        """Look up an LLM `configurations[]` entry by id.

        Returns ``None`` when no entry matches *or* when the matching
        entry is not of type ``llm``. Used by adapter LLM-caller
        closures to honour the YAML's per-stage ``model:`` / ``provider:``
        / ``max_tokens:`` selection rather than hard-coding a model.
        """
        cfg = self._native.llm_configuration(configuration_id)
        if cfg is None:
            return None
        # Filter to `type: llm` so callers don't accidentally pick up
        # classifier / a2a / mcp entries that share an id namespace.
        if cfg.get("type") != "llm":
            return None
        return cfg

    def configuration(self, configuration_id: str) -> Optional[Dict[str, Any]]:
        """Look up any ``configurations[]`` entry by id, regardless of
        ``type:``.

        Returns the full dict including classifier-specific fields
        (``headers``, ``threshold``, ``category_thresholds``,
        ``method``) and HTTP-endpoint fields, so callers built outside
        the LLM path — notably classifier callers driving Azure AI
        Content Safety — can read endpoint / headers / thresholds
        directly from YAML. See :meth:`llm_configuration` for the
        LLM-filtered variant.
        """
        return self._native.configuration(configuration_id)

    def new_session(
        self,
        *,
        session_id: Optional[str] = None,
        correlation_id: Optional[str] = None,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        extensions: Optional[Dict[str, Any]] = None,
        request_context: Optional[Dict[str, Any]] = None,
    ) -> "Session":
        ctx: Dict[str, Any] = dict(request_context or {})
        if session_id is not None:
            ctx["session_id"] = session_id
        if correlation_id is not None:
            ctx["correlation_id"] = correlation_id
        if user_id is not None:
            ctx["user_id"] = user_id
        if tenant_id is not None:
            ctx["tenant_id"] = tenant_id
        if extensions is not None:
            ctx["extensions"] = extensions
        session = Session(self._native.new_session(ctx if ctx else None))
        if correlation_id is not None:
            session.set_correlation_id(correlation_id)
        return session


# ── Public Session ───────────────────────────────────────────────────────


class MissingAdmissionHandleError(RuntimeError):
    """Raised when legacy Stage 4 lookup cannot find an admission handle."""


class Session:
    """Per-conversation gating session.

    Use as a context manager so dangling boundary scopes are closed
    automatically::

        with runtime.new_session(session_id="...") as session:
            session.begin_turn()
            verdict = session.validate_input("user message")
            ...
    """

    def __init__(self, native_session: Any) -> None:
        self._native = native_session
        self._closed = False
        self._admissions: Dict[tuple[str, str], int] = {}

    # Context-manager support.
    def __enter__(self) -> "Session":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        # Don't try to call into a partially-collapsed runtime if an
        # exception unwound through us.
        if self._closed:
            return
        try:
            self.end_turn()
        except Exception:  # noqa: BLE001
            pass
        try:
            self.end_request()
        except Exception:  # noqa: BLE001
            pass
        # Drain any pending async observability deliveries so callers
        # exiting the `with` block see all events the session emitted.
        # Without this flush, downstream readers of `capture.events`
        # can race the provider worker thread.
        try:
            self._native.flush_observability()
        except Exception:  # noqa: BLE001
            pass
        # close() is idempotent (no-ops when already closed) and is
        # the canonical path for releasing the underlying native session.
        self.close()

    # ── Variable ops ────────────────────────────────────────────────

    def flush_observability(self) -> None:
        """Block until every registered observability provider on this
        session's runtime has drained its asynchronous worker queue.
        See :meth:`Runtime.flush_observability` for rationale.
        """
        self._native.flush_observability()

    def set_correlation_id(self, value: Optional[str]) -> None:
        self._native.set_correlation_id(value)

    def set_variable(self, name: str, value: Any) -> None:
        self._native.set_variable(name, value)

    def reset_variable(self, name: str) -> None:
        self._native.reset_variable(name)

    def resolve_variable(self, name: str) -> Optional[Any]:
        return self._native.resolve_variable(name)

    def read_variable(self, name: str) -> Optional[VariableState]:
        d = self._native.read_variable(name)
        if d is None:
            return None
        return VariableState.from_dict(d)

    # ── Event ops ───────────────────────────────────────────────────

    def emit_event(
        self,
        event_id: str,
        *,
        lifetime: Optional[Union[Lifetime, str, Dict[str, Any]]] = None,
        payload: Any = None,
    ) -> None:
        self._native.emit_event(event_id, _coerce_lifetime(lifetime), payload)

    def clear_event(self, event_id: str) -> None:
        self._native.clear_event(event_id)

    def emit_incident(self, name: str, payload: Any = None) -> None:
        self._native.emit_incident(name, payload)

    def complete_pending_resolution(
        self,
        request_id: str,
        decision: str,
        value: Any = None,
        set_variables: Optional[Dict[str, Any]] = None,
        reason: Optional[str] = None,
    ) -> Any:
        return self._native.complete_pending_resolution(
            request_id, decision, value, set_variables, reason
        )

    # ── Boundary ops ────────────────────────────────────────────────

    def begin_turn(self) -> int:
        return int(self._native.begin_turn())

    def end_turn(self) -> None:
        self._admissions.clear()
        self._native.end_turn()

    def begin_request(self) -> int:
        return int(self._native.begin_request())

    def end_request(self) -> None:
        self._native.end_request()

    def close(self) -> None:
        if self._closed:
            return
        self._native.close()
        self._closed = True

    @property
    def current_turn_id(self) -> int:
        return int(self._native.current_turn_id())

    @property
    def current_request_id(self) -> int:
        return int(self._native.current_request_id())

    # ── Stage validation ────────────────────────────────────────────

    def validate_input(self, user_input: str) -> StageVerdict:
        return StageVerdict.from_dict(self._native.validate_input(user_input))

    def validate_tool_call(
        self,
        tool: str,
        params: Optional[Dict[str, Any]] = None,
        *,
        tool_call_id: Optional[str] = None,
    ) -> "ToolCallOutcome":
        if tool_call_id is not None and not isinstance(tool_call_id, str):
            raise TypeError("tool_call_id must be a str or None")
        verdict_dict, mutated, admission_id = self._native.validate_tool_call(
            tool, params or {}, tool_call_id
        )
        if admission_id is not None and tool_call_id is not None:
            self._admissions[(tool, tool_call_id)] = int(admission_id)
        return ToolCallOutcome(StageVerdict.from_dict(verdict_dict), mutated, admission_id)

    def validate_tool_output(
        self,
        admission_id: Union[int, str],
        result: Any,
        *,
        tool_call_id: Optional[str] = None,
    ) -> "ToolOutputOutcome":
        # New API: validate_tool_output(admission_id, result).
        # Legacy lookup is supported when a matching Stage-3 admission
        # was observed locally. On a miss, fall back to a sentinel u64
        # so the runtime emits incident.unguarded_tool_dispatch and
        # returns the <binding> verdict — preserves the security
        # observability contract while still rejecting the call.
        if isinstance(admission_id, str):
            if tool_call_id is None:
                raise MissingAdmissionHandleError(
                    "validate_tool_output(tool, result, ...) requires tool_call_id; "
                    "migrate to validate_tool_output(admission_id, result)"
                )
            resolved = self._admissions.pop(
                (admission_id, tool_call_id),
                (1 << 64) - 1,  # u64::MAX sentinel; unknown admission
            )
        else:
            resolved = int(admission_id)
        verdict_dict, mutated = self._native.validate_tool_output(resolved, result)
        # When the host handed Stage 4 a structured tool result
        # (dict / list / tuple) and the Rust core flattened it to a
        # JSON string because at least one redactor fired, attempt to
        # recover the original container shape and apply redactions
        # only to string leaves (per the structured-output expectation).
        #
        # Strategy: use the verdict's ``applied_transforms`` (canonical
        # char-spans into the rendered JSON) to distinguish redactions
        # that landed on string-leaf content from those that landed on
        # numeric literals, structural punctuation, or dict keys. The
        # former are reapplied to the original structure's string
        # leaves; the latter are dropped (the structured-output "redact only
        # string leaves" expectation).
        #
        # If shape recovery is not safely possible (e.g. canonical
        # serialisation cannot be reproduced byte-for-byte, or the
        # value contains an unrepresentable type) we fall through to
        # the legacy stringified result — never a silent partial
        # redaction.
        if (
            isinstance(result, (dict, list, tuple))
            and isinstance(mutated, str)
        ):
            from ._stage4_shape import recover_structured_redactions

            transforms = verdict_dict.get("applied_transforms") or []
            recovered = recover_structured_redactions(result, transforms)
            if recovered is not None:
                mutated = recovered
        return ToolOutputOutcome(StageVerdict.from_dict(verdict_dict), mutated)

    def evict_admission(self, admission_id: int) -> None:
        self._native.evict_admission(int(admission_id))

    def validate_endpoint_call(
        self,
        method: str,
        uri: str,
        body: Optional[Dict[str, Any]] = None,
        *,
        tool_call_id: Optional[str] = None,
    ) -> "EndpointCallOutcome":
        if tool_call_id is not None and not isinstance(tool_call_id, str):
            raise TypeError("tool_call_id must be a str or None")
        verdict_dict, mutated = self._native.validate_endpoint_call(
            method, uri, body or {}, tool_call_id
        )
        return EndpointCallOutcome(StageVerdict.from_dict(verdict_dict), mutated)

    def validate_agent_call(
        self,
        agent: str,
        params: Optional[Dict[str, Any]] = None,
        *,
        tool_call_id: Optional[str] = None,
    ) -> "AgentCallOutcome":
        if tool_call_id is not None and not isinstance(tool_call_id, str):
            raise TypeError("tool_call_id must be a str or None")
        verdict_dict, mutated = self._native.validate_agent_call(
            agent, params or {}, tool_call_id
        )
        return AgentCallOutcome(StageVerdict.from_dict(verdict_dict), mutated)

    def validate_output(self, response: str) -> "OutputOutcome":
        verdict_dict, mutated = self._native.validate_output(response)
        return OutputOutcome(StageVerdict.from_dict(verdict_dict), mutated)

    # ── Resource cycle helpers ─────────────────────────────────────

    def record_tool_success(self, tool: str, result: Any) -> None:
        self._native.record_tool_success(tool, result)

    def record_tool_failure(self, tool: str, error: str) -> None:
        self._native.record_tool_failure(tool, error)

    def record_endpoint_success(self, method: str, pattern: str, result: Any) -> None:
        self._native.record_endpoint_success(method, pattern, result)

    def record_endpoint_failure(self, method: str, pattern: str, error: str) -> None:
        self._native.record_endpoint_failure(method, pattern, error)

    def record_agent_success(self, agent: str, result: Any) -> None:
        self._native.record_agent_success(agent, result)

    def record_agent_failure(self, agent: str, error: str) -> None:
        self._native.record_agent_failure(agent, error)

    # ── Streaming ───────────────────────────────────────────────────

    def streaming_session(self, stage: Union[int, str]) -> StreamingGuard:
        """Create a streaming guard for Stage 4 or Stage 5.

        ``stage`` may be ``4`` / ``5`` or ``"post_tool"`` / ``"output"``.
        The returned wrapper exposes the streamed-output validation
        surface. ``incident.stream_aborted`` and
        ``incident.stream_limit_exceeded`` are emitted by the
        core/native dispatcher, not by this Python wrapper.
        """
        return StreamingGuard(self._native.streaming_session(stage))


# ── Stage outcome wrappers ──────────────────────────────────────────────


@dataclass
class ToolCallOutcome:
    """Verdict + (possibly mutated) tool params from Stage 3."""

    verdict: StageVerdict
    params: Dict[str, Any] = field(default_factory=dict)
    admission_id: Optional[int] = None

    def __bool__(self) -> bool:
        return self.verdict.allowed


@dataclass
class ToolOutputOutcome:
    """Verdict + (possibly redacted) tool result from Stage 4."""

    verdict: StageVerdict
    result: Any = None

    def __bool__(self) -> bool:
        return self.verdict.allowed


@dataclass
class EndpointCallOutcome:
    """Verdict + body from Stage 3 endpoint check."""

    verdict: StageVerdict
    body: Any = None

    def __bool__(self) -> bool:
        return self.verdict.allowed


@dataclass
class AgentCallOutcome:
    """Verdict + params from Stage 3 agent call check."""

    verdict: StageVerdict
    params: Any = None

    def __bool__(self) -> bool:
        return self.verdict.allowed


@dataclass
class OutputOutcome:
    """Verdict + (possibly transformed) response text from Stage 5."""

    verdict: StageVerdict
    response: str = ""

    def __bool__(self) -> bool:
        return self.verdict.allowed


__all__ = [
    "RuntimeBuilder",
    "Runtime",
    "Session",
    "StageVerdict",
    "VariableState",
    "Lifetime",
    "ToolCallOutcome",
    "ToolOutputOutcome",
    "EndpointCallOutcome",
    "AgentCallOutcome",
    "OutputOutcome",
]
