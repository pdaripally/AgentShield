# Python MCP integration mediation

## Mediated paths
- `protect_tool(...)` and `protect_tool_output(...)` mediate Stage 2/3/4 at `sdk/python/agent_shield/mcp/__init__.py:138` and `sdk/python/agent_shield/mcp/__init__.py:161`.
- `MCPShield.protect_tool(...)` / `MCPShield.protect_tool_output(...)` delegate through the same helpers at `sdk/python/agent_shield/mcp/__init__.py:262` and `sdk/python/agent_shield/mcp/__init__.py:279`.
- `protect_server()` / `protect_tools()` wrap server registries and `(name, callable)` pairs via `_wrap_callable()` at `sdk/python/agent_shield/mcp/__init__.py:359`.

## Unsupported paths
- Inputs before the MCP server boundary and final assistant outputs after the server returns.
- Direct access to raw callables left in the MCP server registry.
- Network hops or remote MCP servers not wrapped in-process.

## Bypass risks
- Leaving both wrapped and unwrapped callables in the server registry.
- Replacing the wrapped callable with the original function after `protect_server()`.
- Treating connection-scope state as per-request isolation without opting into `session_scope="call"`.

## Streaming behavior
- The Python MCP integration does not expose Stage-4/5 streaming. Rules 1-5 are not applicable on this surface.

## Unknown tool-call shapes
- Non-object arguments are normalized before Stage 3, and malformed upstream tool metadata is rejected by the helper APIs, but the integration does not currently emit `incident.unknown_invocation_shape` for unexpected host-side call shapes.

## See also

See [Post-tool limits and dangerous patterns](../../../../docs/POST_TOOL_LIMITS.md) and the [adapter-mediated path matrix](../../../../docs/adapter-mediated-paths.md).
