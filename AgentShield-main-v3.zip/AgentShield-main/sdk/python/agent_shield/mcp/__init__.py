"""Agent Shield for MCP (Model Context Protocol) servers.

MCP servers are tool providers, not agent loops, so this integration is
a sibling to the framework adapters in :mod:`agent_shield.adapters`.
There is no Stage 1 input boundary or Stage 5 output boundary to
attach because the MCP server never sees a user-facing prompt or
assistant message — it only receives tool calls and returns tool
results.

Capability profile (always reported, see :attr:`MCPShield.capabilities`)::

    input_validation:           unsupported
    state_validation:           full
    tool_authorization:         full
    tool_execution_validation:  full
    tool_output_validation:     full
    output_validation:          unsupported
    streaming_output:           unsupported

Session scope
-------------

By default a single :class:`~agent_shield.Session` is held for the
lifetime of the :class:`MCPShield` instance — i.e. one session per MCP
connection. State predicates (variables set on a previous tool call)
therefore span subsequent tool calls on the same connection. Pass
``session_scope="call"`` to opt out and create a fresh session per
call (the legacy stateless behaviour).

 auto-open session for MCP-server calls
----------------------------------------------

MCP servers have no agent loop. Customers were previously forced to
wrap each request in their own ``shield.guard(agent)`` context (or
manually push the ambient :data:`current_session` ContextVar) because
:func:`agent_shield.adapters._orchestration.guarded_tool` fails closed
without a resolvable session. The wrapper now binds the MCPShield's
held connection session explicitly and manages
:meth:`Session.begin_turn` / :meth:`Session.end_turn` per call so
``per_turn`` lifetimes reset correctly. Customers who DO push an
ambient session (e.g. inside a host-level guarded agent) still win:
the ambient session is preferred when present.

 block surfacing
-----------------------

Each ``tools/call`` whose Stage 2/3/4 verdict blocks would otherwise
surface as a plain string ``[GUARDRAIL BLOCK] ...`` that FastMCP wraps
in a ``CallToolResult(isError=True, content=[TextContent])`` — making
it indistinguishable on the wire from a tool that legitimately
returned a string error. The new default ``on_block="error_envelope"``
returns a ``CallToolResult(isError=True, structuredContent={...})``
whose ``structuredContent`` payload includes ``{"shield": "blocked",
"tool", "stage", "message", "pending_resolution"}`` so MCP clients
can branch reliably on the tagged shape without substring-matching
the block message.

FastMCP cannot emit a true JSON-RPC ``error`` envelope from a tool
handler — the lowlevel ``call_tool`` decorator catches every
``Exception`` and converts it to ``CallToolResult(isError=True)``. The
structured envelope is the tightest shape we can guarantee on the
wire.

 structured tool outputs
-------------------------------

Stage 4 (``Session.validate_tool_output``) preserves ``list`` / ``dict``
/ ``None`` shapes today, but Pydantic ``BaseModel`` instances are
stringified by the underlying runtime. The wrapper dumps Pydantic
models before Stage 4, runs validation against the JSON-safe dict,
and round-trips the redacted payload back to the model class so MCP
clients see the same Pydantic shape the tool returned. ``preserve_raw_result``
threads through :func:`guarded_tool` so dict / list / None shapes flow
through without ``str()`` coercion.

 pending_resolution surfacing
------------------------------------

:meth:`MCPShield.last_pending_resolution` mirrors the Node MCP
adapter's ``lastPendingResolution()``: when a Stage 2/3/4 block is
caused by a resolver awaiting external input (``kind: human``
approval, ``kind: tool`` awaiting a named tool call), the structured
envelope is latched on the shield and the next read clears it.
Hosts can also pass ``pending_resolution_sink=`` for a push callback.

Public API
----------

* :func:`shield_server` — wrap every tool registered on a FastMCP /
  generic MCP server with Stage 2 + 3 + 4 enforcement.
* :func:`protect_tool` / :func:`protect_tool_output` — manual stage
  validation helpers.
* :class:`MCPShield` — composable shield with capability report.
"""
from __future__ import annotations

import inspect
import json
import logging
import uuid
import warnings
from typing import Any, Callable, Dict, List, Literal, Optional, Tuple, Union

from agent_shield import Runtime, RuntimeBuilder, Session
from agent_shield.adapters._capabilities import (
    CapabilityReport,
    CoverageLevel,
)
from agent_shield.adapters._orchestration import (
    _format_block_message,
    current_session,
)
from agent_shield.adapters._shield import (
    _pydantic_dump,
    _pydantic_round_trip,
    _try_import_pydantic_basemodel,
)

logger = logging.getLogger("agent_shield.mcp")

SessionScope = Literal["connection", "call"]

# block delivery modes.
#
# * ``"raise"`` — throw :class:`MCPGuardrailBlocked`. FastMCP wraps the
#   exception as ``ToolError(...)`` and the lowlevel ``call_tool``
#   handler converts that to ``CallToolResult(isError=True,
#   content=[TextContent])``. Backward-compatible with legacy callers.
# * ``"return_message"`` — return the canonical ``[GUARDRAIL...]``
#   block message string in place of the tool's normal output.
# * ``"error_envelope"`` — return a ``CallToolResult(isError=True,
#   content=[TextContent(json)], structuredContent={"shield":
#   "blocked",...})``. Default for :func:`shield_server` and
#   :meth:`MCPShield.protect_server`. Requires the ``mcp`` package to
#   be importable for the canonical ``CallToolResult`` shape; falls
#   back transparently to the ``"raise"`` shape when the import fails.
OnBlock = Literal["raise", "return_message", "error_envelope"]

# Module-level sentinel for "stage attribution" — Stage 2 + 3 collapse
# at the MCP boundary because ``validate_tool_call`` returns one
# verdict for both, but Stage 4 is distinct.
_STAGE_TOOL_CALL = "stage_2_3"
_STAGE_TOOL_OUTPUT = "stage_4"


# ---------------------------------------------------------------------------
# Capability profile
# ---------------------------------------------------------------------------

_MCP_CAPABILITIES = CapabilityReport(
    framework="mcp",
    input_validation=CoverageLevel.UNSUPPORTED,
    state_validation=CoverageLevel.FULL,
    tool_authorization=CoverageLevel.FULL,
    tool_execution_validation=CoverageLevel.FULL,
    tool_output_validation=CoverageLevel.FULL,
    output_validation=CoverageLevel.UNSUPPORTED,
    streaming_output=CoverageLevel.UNSUPPORTED,
    notes=[
        "MCP is a tool-provider integration; no user-facing input or "
        "assistant-output boundary exists for Stage 1 / Stage 5 / "
        "streaming",
    ],
)


# ---------------------------------------------------------------------------
# Block-envelope helpers
# ---------------------------------------------------------------------------


def _build_blocked_payload(
    tool_name: str,
    stage: str,
    message: str,
    pending_resolution: Optional[dict],
) -> dict:
    """Canonical structured payload for a Stage 2/3/4 MCP block.

    Returned as ``CallToolResult.structuredContent`` and serialised
    into the ``TextContent`` content slot so MCP clients can branch
    reliably on the ``shield`` discriminator without substring-matching
    the human-readable block message.
    """
    return {
        "shield": "blocked",
        "tool": tool_name,
        "stage": stage,
        "message": message,
        "pending_resolution": pending_resolution,
    }


def _try_build_error_envelope(
    tool_name: str,
    stage: str,
    message: str,
    pending_resolution: Optional[dict],
) -> Optional[Any]:
    """Construct a ``mcp.types.CallToolResult`` carrying the structured
    block payload.

    Returns ``None`` when the ``mcp`` package is not importable so the
    caller can fall back to raising :class:`MCPGuardrailBlocked` (the
    legacy shape) without breaking environments where ``mcp`` is not
    a runtime dependency (``agent_shield.mcp`` works against fakes for
    in-process tests).
    """
    try:  # noqa: SIM105 — explicit ImportError handling
        from mcp.types import CallToolResult, TextContent
    except Exception:  # noqa: BLE001 — mcp not installed / version mismatch
        return None
    payload = _build_blocked_payload(
        tool_name, stage, message, pending_resolution,
    )
    text_json = json.dumps(payload, default=str)
    try:
        return CallToolResult(
            content=[TextContent(type="text", text=text_json)],
            structuredContent=payload,
            isError=True,
        )
    except Exception:  # noqa: BLE001 — older mcp may not accept structuredContent
        try:
            return CallToolResult(
                content=[TextContent(type="text", text=text_json)],
                isError=True,
            )
        except Exception:  # noqa: BLE001
            return None


# ---------------------------------------------------------------------------
# shape-preserving Stage 4 redaction
# ---------------------------------------------------------------------------


def _try_import_mcp_text_content() -> Optional[type]:
    """Return ``mcp.types.TextContent`` when the ``mcp`` package is
    importable, else ``None``. Decoupled from
    :func:`_try_import_call_tool_result` so a host can have one without
    the other (older mcp versions etc.)."""
    try:
        from mcp.types import TextContent
        return TextContent
    except Exception:  # noqa: BLE001
        return None


def _try_import_call_tool_result() -> Optional[type]:
    """Return ``mcp.types.CallToolResult`` when the ``mcp`` package is
    importable, else ``None``."""
    try:
        from mcp.types import CallToolResult
        return CallToolResult
    except Exception:  # noqa: BLE001
        return None


def _model_copy_update(model: Any, update: Dict[str, Any]) -> Any:
    """Cross-version ``.copy(update=...)`` shim.

    Pydantic v2 uses ``model_copy(update=...)``; v1 uses
    ``copy(update=...)``. We try v2 first, fall back to v1, and as a
    final fallback return the original model unchanged so a frozen /
    non-Pydantic shape is never silently mutated.
    """
    copier = getattr(model, "model_copy", None)
    if callable(copier):
        try:
            return copier(update=update)
        except Exception:  # noqa: BLE001
            logger.debug(
                "model_copy failed for %s; trying v1 fallback",
                type(model).__name__,
                exc_info=True,
            )
    copier = getattr(model, "copy", None)
    if callable(copier):
        try:
            return copier(update=update)
        except Exception:  # noqa: BLE001
            logger.debug(
                "v1 copy failed for %s; returning original",
                type(model).__name__,
                exc_info=True,
            )
    return model


def _redact_call_tool_result(result: Any, redactor: Callable[[Any], Any]) -> Any:
    """Walk a :class:`mcp.types.CallToolResult` and apply ``redactor``
    only to redactable fields, preserving the original wire shape.

    Per  spec:

    * ``content[i]`` of type :class:`mcp.types.TextContent` has its
      ``text`` field redacted.
    * Other content blocks (``ImageContent``, ``EmbeddedResource``,
      ``AudioContent``, …) pass through unchanged — Stage 4 must never
      stringify or run regex against binary / base64 payloads (false
      positives would silently corrupt the content).
    * ``structuredContent`` is recursed as a generic JSON-safe object.
    * ``meta`` / ``_meta`` is passed through unchanged.
    * ``isError`` is preserved verbatim.
    """
    text_content_cls = _try_import_mcp_text_content()
    text_blocks: List[str] = []
    text_indices: List[int] = []
    for idx, block in enumerate(result.content or []):
        if text_content_cls is not None and isinstance(block, text_content_cls):
            text_blocks.append(getattr(block, "text", ""))
            text_indices.append(idx)

    pseudo: Dict[str, Any] = {}
    if text_blocks:
        pseudo["__texts__"] = text_blocks
    sc = getattr(result, "structuredContent", None)
    if sc is not None:
        pseudo["__sc__"] = sc

    redacted_texts: List[str] = text_blocks
    redacted_sc: Any = sc
    if pseudo:
        redacted_pseudo = redactor(pseudo)
        if isinstance(redacted_pseudo, str):
            try:
                redacted_pseudo = json.loads(redacted_pseudo)
            except Exception:  # noqa: BLE001
                logger.debug(
                    "CallToolResult redact: pseudo JSON unparseable; "
                    "leaving fields unredacted",
                    exc_info=True,
                )
                redacted_pseudo = pseudo
        if isinstance(redacted_pseudo, dict):
            redacted_texts = redacted_pseudo.get("__texts__", text_blocks)
            redacted_sc = redacted_pseudo.get("__sc__", sc)

    new_content = list(result.content or [])
    for slot, idx in enumerate(text_indices):
        if slot < len(redacted_texts):
            new_content[idx] = _model_copy_update(
                new_content[idx], {"text": redacted_texts[slot]},
            )

    update: Dict[str, Any] = {"content": new_content}
    if sc is not None:
        update["structuredContent"] = redacted_sc
    return _model_copy_update(result, update)


def _apply_redactor_preserve_shape(
    value: Any, redactor: Callable[[Any], Any],
) -> Any:
    """Apply Stage-4 redaction (``redactor``) to ``value`` while
    preserving the original Python container shape.

    The Rust Stage-4 runtime stringifies non-string inputs to JSON
    internally and applies redact patterns against the serialised
    form, so its raw return for a ``dict`` / ``list`` input is a JSON
    string — losing the original Python container shape. This walker:

    * For ``str`` → calls ``redactor`` directly (Stage 4 returns a
      string).
    * For ``dict`` / ``list`` → calls ``redactor`` once on the
      container, re-parses the returned JSON string, and reassembles
      the same Python container type.
    * For ``tuple`` → same as ``list`` but re-wraps as a tuple.
    * For Pydantic ``BaseModel`` (v1 and v2) — including
      :class:`mcp.types.CallToolResult` and other MCP types — dumps
      to dict via :func:`_pydantic_dump`, redacts, and re-validates
      via :func:`_pydantic_round_trip` so the caller sees the same
      model class.
    * For :class:`mcp.types.CallToolResult` specifically — recursed
      field-by-field via :func:`_redact_call_tool_result` so
      non-text content blocks (``ImageContent`` etc.) are never
      submitted to Stage 4's regex engine.
    * For primitives (``int`` / ``float`` / ``bool`` / ``None`` /
      ``bytes``) — pass through unchanged.
    * For any other type — log at ``info`` level (type name only, no
      value content) and fall back to ``redactor(str(value))``.

    ``redactor`` MUST be a function that takes a JSON-safe Python
    value (str / dict / list / scalar) and returns the Stage-4
    redacted form (a str when input is non-str, str when input is
    str). Typically bound to
    ``lambda v: session.validate_tool_output(admit, v).result``.
    """
    if isinstance(value, str):
        return redactor(value)

    if value is None or isinstance(value, (bool, int, float, bytes)):
        return value

    call_tool_result_cls = _try_import_call_tool_result()
    if (
        call_tool_result_cls is not None
        and isinstance(value, call_tool_result_cls)
    ):
        return _redact_call_tool_result(value, redactor)

    base_model = _try_import_pydantic_basemodel()
    if base_model is not None and isinstance(value, base_model):
        cls = type(value)
        dumped = _pydantic_dump(value)
        redacted = redactor(dumped)
        if isinstance(redacted, str):
            try:
                redacted = json.loads(redacted)
            except Exception:  # noqa: BLE001
                logger.debug(
                    "Pydantic redact: JSON re-parse failed for %s",
                    cls.__name__,
                    exc_info=True,
                )
                return redacted
        try:
            return _pydantic_round_trip(cls, redacted)
        except Exception:  # noqa: BLE001
            logger.debug(
                "Pydantic round-trip failed for %s; returning dict",
                cls.__name__,
                exc_info=True,
            )
            return redacted

    if isinstance(value, dict):
        redacted = redactor(value)
        if isinstance(redacted, str):
            try:
                return json.loads(redacted)
            except Exception:  # noqa: BLE001
                logger.debug(
                    "dict redact: JSON re-parse failed",
                    exc_info=True,
                )
                return redacted
        return redacted

    if isinstance(value, (list, tuple)):
        as_list = list(value)
        redacted = redactor(as_list)
        if isinstance(redacted, str):
            try:
                redacted = json.loads(redacted)
            except Exception:  # noqa: BLE001
                logger.debug(
                    "list redact: JSON re-parse failed",
                    exc_info=True,
                )
                return redacted
        if isinstance(value, tuple) and isinstance(redacted, list):
            return tuple(redacted)
        return redacted

    # Unknown type — never silently stringify sensitive content at
    # info+ (logging-style guide); log type name only.
    logger.info(
        "Shape-preserving redactor: unknown type %s; coercing to str",
        type(value).__name__,
    )
    return redactor(str(value))


def _do_protect_tool_output_preserve_shape(
    session: Session,
    tool_name: str,
    admission_id: Optional[int],
    output: Any,
    *,
    record: bool,
    pending_resolution_sink: Optional[Callable[[dict], None]] = None,
) -> Tuple[bool, Any, Optional[str], Optional[dict]]:
    """Stage 4 — like :func:`_do_protect_tool_output` but the return
    value preserves the input's Python container shape via
    :func:`_apply_redactor_preserve_shape`.

    Returns ``(allowed, value, msg, pending)`` where ``value`` is the
    Stage-4 redacted result with the original Python shape (dict ↔
    dict, Pydantic model ↔ same Pydantic class, ``CallToolResult`` ↔
    ``CallToolResult`` with non-text content untouched, etc.).
    """
    if admission_id is None:
        raise RuntimeError(
            "Stage 4 requires a Stage 3 admission_id; "
            "call _do_protect_tool first.",
        )

    # Capture verdict + pending out of band so the redactor closure
    # only has to return the Stage-4 result value.
    captured: Dict[str, Any] = {
        "allowed": True,
        "pending": None,
        "verdict": None,
    }

    def _redactor(value: Any) -> Any:
        outcome = session.validate_tool_output(admission_id, value)
        captured["verdict"] = outcome.verdict
        captured["allowed"] = bool(outcome.verdict.allowed)
        captured["pending"] = getattr(
            outcome.verdict, "pending_resolution", None,
        )
        return outcome.result if outcome.result is not None else value

    final = _apply_redactor_preserve_shape(output, _redactor)

    pending = captured["pending"]
    verdict = captured["verdict"]
    if pending and pending_resolution_sink is not None:
        try:
            pending_resolution_sink(pending)
        except Exception:  # noqa: BLE001
            logger.debug("pending_resolution_sink raised", exc_info=True)

    if not captured["allowed"]:
        if record and verdict is not None:
            try:
                session.record_tool_failure(
                    tool_name, verdict.reason or "blocked",
                )
            except Exception:  # noqa: BLE001
                logger.debug("record_tool_failure raised", exc_info=True)
        msg = _format_block_message(verdict) if verdict is not None else "blocked"
        return False, output, msg, pending

    if record:
        try:
            text = final if isinstance(final, str) else str(final)
            session.record_tool_success(tool_name, text)
        except Exception:  # noqa: BLE001
            logger.debug("record_tool_success raised", exc_info=True)

    return True, final, None, None


# ---------------------------------------------------------------------------
# Stage helpers — reused by module-level helpers and MCPShield methods.
# ---------------------------------------------------------------------------


def _do_protect_tool(
    session: Session,
    tool_name: str,
    args: dict,
    tool_call_id: str,
    *,
    pending_resolution_sink: Optional[Callable[[dict], None]] = None,
) -> tuple[bool, dict, Optional[str], Optional[dict], Optional[int]]:
    """Stage 2 + 3 — returns ``(allowed, effective_args, msg, pending, admission_id)``.

    ``pending`` is the verdict's structured ``pending_resolution`` dict
    when one is attached (``kind: human``, ``kind: tool``…) and ``None``
    otherwise. ``admission_id`` is the Stage 3 admit handle to thread
    through Stage 4 (Section 16.0 mandatory binding).
    """
    if not tool_call_id:
        raise TypeError("tool_call_id is required and must be non-empty")
    cleaned = {k: v for k, v in (args or {}).items() if v is not None}
    outcome = session.validate_tool_call(
        tool_name, cleaned, tool_call_id=tool_call_id,
    )
    pending = getattr(outcome.verdict, "pending_resolution", None)
    if pending and pending_resolution_sink is not None:
        try:
            pending_resolution_sink(pending)
        except Exception:  # noqa: BLE001
            logger.debug("pending_resolution_sink raised", exc_info=True)
    if not outcome.verdict.allowed:
        return (
            False,
            cleaned,
            _format_block_message(outcome.verdict),
            pending,
            None,
        )
    effective = outcome.params if outcome.params is not None else cleaned
    return True, effective, None, None, outcome.admission_id


def _do_protect_tool_output(
    session: Session,
    tool_name: str,
    admission_id: Optional[int],
    output: Any,
    *,
    record: bool,
    pending_resolution_sink: Optional[Callable[[dict], None]] = None,
    preserve_raw_result: bool = False,
) -> tuple[bool, Any, Optional[str], Optional[dict]]:
    """Stage 4 — returns ``(allowed, value, msg, pending)``.

    ``value`` is the Stage-4 redacted result. With
    ``preserve_raw_result=True`` the original Python shape
    (dict / list / None / scalar) is preserved; without it the legacy
    ``str()`` coercion is applied so back-compat callers see the
    legacy string contract.
    """
    if admission_id is None:
        # No Stage 3 admission means we cannot bind Stage 4 to the
        # canonical invocation. Caller must have used the legacy
        # tool-call-id path; emit a deterministic fail-closed message
        # rather than silently re-binding.
        raise RuntimeError(
            "Stage 4 requires a Stage 3 admission_id; "
            "call _do_protect_tool first.",
        )
    outcome = session.validate_tool_output(admission_id, output)
    pending = getattr(outcome.verdict, "pending_resolution", None)
    if pending and pending_resolution_sink is not None:
        try:
            pending_resolution_sink(pending)
        except Exception:  # noqa: BLE001
            logger.debug("pending_resolution_sink raised", exc_info=True)
    if not outcome.verdict.allowed:
        if record:
            try:
                session.record_tool_failure(
                    tool_name, outcome.verdict.reason or "blocked",
                )
            except Exception:  # noqa: BLE001
                logger.debug("record_tool_failure raised", exc_info=True)
        return False, output, _format_block_message(outcome.verdict), pending
    final = outcome.result if outcome.result is not None else output
    if record:
        try:
            text = final if isinstance(final, str) else str(final)
            session.record_tool_success(tool_name, text)
        except Exception:  # noqa: BLE001
            logger.debug("record_tool_success raised", exc_info=True)
    if preserve_raw_result:
        return True, final, None, None
    final_str = final if isinstance(final, str) else str(final)
    return True, final_str, None, None


# ---------------------------------------------------------------------------
# Legacy module-level helpers — unchanged public contract for callers
# who manually drive Stage 2/3 + Stage 4 (no MCPShield instance).
# ---------------------------------------------------------------------------


async def protect_tool(
    runtime: Runtime,
    tool_name: str,
    args: dict,
    tool_call_id: str,
    *,
    session: Optional[Session] = None,
) -> tuple[bool, dict, Optional[str]]:
    """Stage 2 + 3 — guard an inbound MCP tool call.

    ``tool_call_id`` is REQUIRED (Section 16.0 mandatory binding):
    the same id MUST be threaded through the matching
    :func:`protect_tool_output` call so Stage 4 binds against the
    canonical invocation Stage 3 admitted. When the host framework
    does not surface a native id (e.g. raw MCP without a request id),
    mint one with ``uuid.uuid4().hex`` per call.

    Returns ``(allowed, effective_args, block_message)``.
    """
    sess = session if session is not None else runtime.new_session()
    allowed, effective, msg, _pending, _admit = _do_protect_tool(
        sess, tool_name, args, tool_call_id,
    )
    return allowed, effective, msg


async def protect_tool_output(
    runtime: Runtime,
    tool_name: str,
    output: Any,
    tool_call_id: str,
    *,
    session: Optional[Session] = None,
    record: bool = True,
) -> tuple[bool, Any, Optional[str]]:
    """Stage 4 — guard an outbound MCP tool result.

    ``tool_call_id`` MUST match the id passed to :func:`protect_tool`
    in the same logical invocation (Section 16.0 mandatory binding).
    Without that pairing the helper does its own Stage 3 prebind so
    Stage 4 has an admission_id to bind against — back-compat shim for
    callers that historically only invoked the output helper.

    When ``record`` is True the resource cycle bookkeeping fires
    (``record_tool_success`` on allow, ``record_tool_failure`` on
    block).

     the returned ``value`` preserves the input's Python
    container shape. Passing a ``dict`` returns a ``dict``; passing a
    Pydantic model returns the same model class; passing
    :class:`mcp.types.CallToolResult` returns a ``CallToolResult``
    with non-text content blocks untouched. Previously the helper
    stringified non-str inputs (``str(output)``) which destroyed
    typed MCP responses.
    """
    if not tool_call_id:
        raise TypeError("tool_call_id is required and must be non-empty")
    sess = session if session is not None else runtime.new_session()
    outcome = sess.validate_tool_call(tool_name, {}, tool_call_id=tool_call_id)
    admit = outcome.admission_id
    if admit is None:
        msg = _format_block_message(outcome.verdict)
        return False, output, msg
    allowed, value, msg, _pending = _do_protect_tool_output_preserve_shape(
        sess, tool_name, admit, output, record=record,
    )
    return allowed, value, msg


# ---------------------------------------------------------------------------
# MCPShield — composable shield for MCP servers
# ---------------------------------------------------------------------------


class MCPShield:
    """Composable shield for MCP servers.

    Holds a single long-lived :class:`Session` per MCP connection by
    default so state predicates span tool calls. Pass
    ``session_scope="call"`` to opt out and force a fresh session per
    call.

    Per-MCP-connection session scoping (v1):
        One session per :class:`MCPShield` instance. Sufficient for the
        common "one shield, one server" deployment. Per-connection
        sessions (i.e. one session per inbound MCP transport
        connection) are a v2 enhancement tracked separately — they
        require a per-request context extractor analogous to.
    """

    def __init__(
        self,
        runtime: Runtime,
        *,
        capabilities: CapabilityReport = _MCP_CAPABILITIES,
        session_scope: SessionScope = "call",
    ) -> None:
        if session_scope not in ("connection", "call"):
            raise ValueError(
                f"session_scope must be 'connection' or 'call', "
                f"got {session_scope!r}",
            )
        self.runtime = runtime
        self._capabilities = capabilities
        self._session_scope: SessionScope = session_scope
        self._session: Optional[Session] = None
        # last pending_resolution envelope surfaced by a Stage
        # 2/3/4 block routed through this shield. Read-and-clear via
        # :meth:`last_pending_resolution`.
        self._last_pending_resolution: Optional[dict] = None
        # optional push-style callback fired alongside the
        # internal latch. Set via :meth:`pending_resolution_sink`
        # setter.
        self._pending_resolution_sink: Optional[Callable[[dict], None]] = None

    @classmethod
    def from_yaml(cls, path: Union[str, List[str]]) -> "MCPShieldBuilder":
        """Create a builder from a single YAML file or a chain."""
        if isinstance(path, list):
            b = MCPShieldBuilder("")
            b._yaml_chain = list(path)
            return b
        return MCPShieldBuilder(path)

    @property
    def capabilities(self) -> CapabilityReport:
        return self._capabilities

    @property
    def session_scope(self) -> SessionScope:
        return self._session_scope

    @property
    def session(self) -> Optional[Session]:
        """The held connection session, or ``None`` when scope is ``"call"``.

        Lazily created on first access in connection mode. Use
        :meth:`reset_session` to drop it (e.g. for connection pooling).
        """
        if self._session_scope != "connection":
            return None
        if self._session is None:
            self._session = self.runtime.new_session()
        return self._session

    def reset_session(self) -> None:
        """Drop the held connection session.

        The next ``protect_tool`` / ``protect_tool_output`` call will
        lazily create a fresh session. No-op when ``session_scope`` is
        ``"call"``.
        """
        self._session = None

    # ── — pending_resolution surfacing ───────────────────────

    def last_pending_resolution(self) -> Optional[dict]:
        """Peek at the most recent ``pending_resolution`` envelope
        surfaced by a Stage 2/3/4 block on a tool routed through
        :meth:`protect_tool`, :meth:`protect_tool_output`,
        :meth:`protect_tools`, or :meth:`protect_server` on this
        shield.

        Mirrors :meth:`Shield.last_pending_resolution` and the Node
        MCP adapter's ``lastPendingResolution()``.

        ** — non-destructive peek.** Reading the latch does NOT
        clear it. The documented inspect-then-resume flow

            pending = mcp_shield.last_pending_resolution()
            if pending is not None:
                # show pending["prompt"] / pending["request_id"] in a UI
                # operator approves out-of-band; resume by retrying the
                # tool through protect_tool / protect_server
                ...

        relies on this method being idempotent — multiple peeks return
        the same envelope until either (a) the next ``protect_tool`` /
        ``protect_tool_output`` (or wrapped-tool dispatch) starts a
        fresh validation pass and clears the latch, or (b) a fresh
        block overwrites it with a new envelope.

        An MCP host can read this after observing the
        ``[GUARDRAIL ...]`` block string to drive a human-approval UI
        (look up the named tool's resolver, prompt the operator, etc.)
        without substring-matching the block message.
        """
        return self._last_pending_resolution

    # ── — host-driven pending resolution ─────────────────────

    async def resolve_pending(
        self,
        decision: Literal["allow", "deny"],
        value: Any = None,
    ) -> None:
        """Resolve the latched pending human-approval envelope.

        Mirrors :meth:`agent_shield.Shield.resolve_pending` in shape
        but drives the resolution through the canonical resolver path
        (emits ``approval.<var>.<outcome>`` with a
        ``{kind: "human", set_by: "human:<var>"}`` payload) so the
        unblocked variable is stamped with ``@source_kind: "human"``
        and ``@set_by: "human:<var>"`` — matching the
        provenance contract.

        Hosts that previously worked around the missing API by calling
        ``shield.session.set_variable(name, True)`` directly were
        bypassing the resolver chain and stamping
        ``@source_kind: "host_api"`` (the host-API fallback),
        which dropped the human-provenance signal.

        Args:
            decision: ``"allow"`` or ``"deny"`` — the operator's
                decision. When ``value`` is omitted, ``"allow"``
                resolves the variable to ``True`` and ``"deny"`` to
                ``False`` (matches the boolean-approval convention in
                :meth:`Shield.resolve_pending`).
            value: Optional explicit value to write to the variable
                named by the latched ``pending_resolution`` envelope.
                Use this for non-boolean variables (numeric limits,
                structured objects, etc.).

        Raises:
            RuntimeError: No ``pending_resolution`` is latched, or the
                shield has no session through which to drive the
                approval emission (``session_scope="call"`` without a
                prior ``protect_tool`` to materialise the latched
                session reference).
            ValueError: ``decision`` is neither ``"allow"`` nor
                ``"deny"``.
        """
        if decision not in ("allow", "deny"):
            raise ValueError(
                f"MCPShield.resolve_pending(decision=...): decision "
                f"must be 'allow' or 'deny', got {decision!r}",
            )
        pending = self._last_pending_resolution
        if pending is None:
            raise RuntimeError(
                "MCPShield.resolve_pending: no `pending_resolution` "
                "is latched. Trigger a Stage 2/3/4 block via "
                "`protect_tool` / `protect_tool_output` / "
                "`protect_server` first (the latch is populated when "
                "a block verdict carries a `pending_resolution` "
                "envelope).",
            )
        request_id = pending.get("request_id")
        if not request_id:
            raise RuntimeError(
                "MCPShield.resolve_pending: latched "
                "`pending_resolution` has no `request_id` field; cannot "
                "complete it.",
            )
        sess = self._resolve_session_for_resolution()
        if sess is None:
            raise RuntimeError(
                "MCPShield.resolve_pending: no session is available "
                "to apply the resolution. In `session_scope=\"call\"` "
                "mode the host MUST keep a reference to the session "
                "used for the blocked `protect_tool` call and pass it "
                "back explicitly (see future API).",
            )
        resolved = value
        if resolved is None:
            resolved = True if decision == "allow" else False
        try:
            sess.complete_pending_resolution(request_id, decision, resolved, None, None)
        except RuntimeError as exc:
            if "UnknownRequestId" not in str(exc):
                raise
            variable_name = pending.get("variable")
            if not variable_name:
                raise
            kind = pending.get("kind") or "human"
            payload: Dict[str, Any] = {"kind": kind, "set_by": f"{kind}:{variable_name}"}
            if decision == "allow":
                payload["value"] = resolved
            sess.emit_event(f"approval.{variable_name}.{decision}", payload=payload)
        # Clear the latch — the next protect_tool call will start fresh.
        self._last_pending_resolution = None

    def _resolve_session_for_resolution(self) -> Optional[Session]:
        """Pick the session through which :meth:`resolve_pending`
        drives the approval emission.

        In ``"connection"`` scope the long-lived held session is the
        only candidate. In ``"call"`` scope there is no persistent
        session — the per-call session was already torn down when
        ``protect_tool`` returned — so the caller is responsible for
        re-driving the resolution through whatever bookkeeping it
        maintains; we return ``None`` and let :meth:`resolve_pending`
        raise a structured error.
        """
        if self._session_scope == "connection":
            return self.session
        return None

    def _reset_pending_for_new_call(self) -> None:
        """Clear the pending-resolution latch at the start of a fresh
        ``protect_tool`` / ``protect_tool_output`` / wrapped-tool
        dispatch boundary.

        Mirrors the Shield-level reset in
        :meth:`Shield._guarded_turn_async` (see ``_shield.py``: "reset
        the shield-level latch at the start of each new guarded
        turn") so a successful follow-up call does not leave the
        prior block's ``pending_resolution`` lingering on
        :meth:`last_pending_resolution`. The latch will be re-set
        below if the new pass surfaces a fresh envelope via
        :meth:`_capture_pending`.
        """
        self._last_pending_resolution = None

    @property
    def pending_resolution_sink(self) -> Optional[Callable[[dict], None]]:
        """Push-style callback fired alongside the internal latch.

        See :meth:`last_pending_resolution` for the latch contract.
        The sink runs AFTER the internal latch so a misbehaving sink
        cannot mask the canonical surfacing path.
        """
        return self._pending_resolution_sink

    @pending_resolution_sink.setter
    def pending_resolution_sink(
        self, sink: Optional[Callable[[dict], None]],
    ) -> None:
        self._pending_resolution_sink = sink

    def _capture_pending(self, pending: dict) -> None:
        """Internal sink: latch + fire the host-supplied sink."""
        self._last_pending_resolution = pending
        if self._pending_resolution_sink is not None:
            try:
                self._pending_resolution_sink(pending)
            except Exception:  # noqa: BLE001
                logger.debug(
                    "host pending_resolution_sink raised", exc_info=True,
                )

    def _resolve_session(self, explicit: Optional[Session]) -> Session:
        if explicit is not None:
            return explicit
        if self._session_scope == "connection":
            return self.session  # type: ignore[return-value]
        return self.runtime.new_session()

    async def protect_tool(
        self,
        tool_name: str,
        args: dict,
        tool_call_id: str,
        *,
        session: Optional[Session] = None,
    ) -> tuple[bool, dict, Optional[str]]:
        """Stage 2 + 3 validation for an inbound MCP tool call.

        ``tool_call_id`` is REQUIRED (Section 16.0). Reuse the same id
        when calling :meth:`protect_tool_output`.
        """
        # reset the pending latch at the start of each fresh
        # validation pass so a successful call does not leave the
        # prior block's envelope lingering on ``last_pending_resolution``.
        self._reset_pending_for_new_call()
        allowed, effective, msg, _pending, _admit = _do_protect_tool(
            self._resolve_session(session),
            tool_name, args, tool_call_id,
            pending_resolution_sink=self._capture_pending,
        )
        return allowed, effective, msg

    async def protect_tool_output(
        self,
        tool_name: str,
        output: Any,
        tool_call_id: str,
        *,
        session: Optional[Session] = None,
        record: bool = True,
    ) -> tuple[bool, Any, Optional[str]]:
        """Stage 4 validation for an outbound MCP tool result.

        ``tool_call_id`` MUST match the id passed to
        :meth:`protect_tool`. When the caller did not paired
        :meth:`protect_tool` first, this helper does its own Stage 3
        prebind so Stage 4 has an admission to bind against.

         the returned ``value`` preserves the input's Python
        container shape (dict ↔ dict, Pydantic ↔ same Pydantic class,
        :class:`mcp.types.CallToolResult` ↔ ``CallToolResult`` with
        non-text content untouched). Previously ``MCPShield`` coerced
        every non-str result to ``str(output)``, destroying typed MCP
        responses.
        """
        if not tool_call_id:
            raise TypeError("tool_call_id is required and must be non-empty")
        # See :meth:`protect_tool` for the reset rationale.
        self._reset_pending_for_new_call()
        sess = self._resolve_session(session)
        outcome = sess.validate_tool_call(
            tool_name, {}, tool_call_id=tool_call_id,
        )
        admit = outcome.admission_id
        if admit is None:
            msg = _format_block_message(outcome.verdict)
            return False, output, msg
        allowed, value, msg, _pending = _do_protect_tool_output_preserve_shape(
            sess, tool_name, admit, output,
            record=record,
            pending_resolution_sink=self._capture_pending,
        )
        return allowed, value, msg

    # ── Server / tool wrappers ───────────────────────────────────

    def protect_server(
        self, server: Any, *, on_block: OnBlock = "error_envelope",
    ) -> Any:
        """Wrap every tool on ``server`` with Stage 2/3/4 enforcement.

        Supports any MCP server that exposes either a ``_tool_manager``
        with a ``_tools`` dict (FastMCP) or a top-level ``tools``
        registry.

        ``on_block`` defaults to ``"error_envelope"`` —
        blocked tool calls return ``CallToolResult(isError=True,
        structuredContent={"shield": "blocked", ...})`` so MCP clients
        can branch reliably on the structured shape. Pass
        ``on_block="raise"`` for the legacy shape (raises
        :class:`MCPGuardrailBlocked`, which FastMCP serialises as a
        plain isError=True text content) or
        ``on_block="return_message"`` to return the formatted
        ``[GUARDRAIL ...]`` string.
        """
        registry = self._find_tool_registry(server)
        self._wrap_registry(registry, on_block=on_block)
        return server

    def protect_tools(
        self, tools: List[tuple], *, on_block: OnBlock = "error_envelope",
    ) -> List[tuple]:
        """Wrap a list of ``(name, callable)`` pairs.

        See :meth:`protect_server` for the ``on_block`` semantics.
        """
        return [
            (name, self._wrap_callable(name, fn, on_block=on_block))
            for name, fn in tools
        ]

    @staticmethod
    def _find_tool_registry(server: Any) -> Any:
        tm = getattr(server, "_tool_manager", None)
        if tm is not None and hasattr(tm, "_tools"):
            return tm._tools
        if hasattr(server, "tools"):
            return server.tools
        raise TypeError(
            f"Cannot find tool registry on MCP server "
            f"{type(server).__name__!r}. Pass tools explicitly via "
            f"protect_tools().",
        )

    def _wrap_registry(self, registry: Any, *, on_block: OnBlock) -> None:
        items = (
            list(registry.items())
            if isinstance(registry, dict)
            else [(getattr(t, "name", None), t) for t in registry]
        )
        for name, tool in items:
            if name is None:
                continue
            fn = (
                getattr(tool, "fn", None)
                or getattr(tool, "func", None)
                or tool
            )
            if fn is None:
                continue
            wrapped = self._wrap_callable(name, fn, on_block=on_block)
            if hasattr(tool, "fn"):
                tool.fn = wrapped
            elif hasattr(tool, "func"):
                tool.func = wrapped
            elif isinstance(registry, dict):
                registry[name] = wrapped

    # ── Internal orchestration ───────────────────────────────────

    def _acquire_call_session(self) -> tuple[Session, bool]:
        """Return ``(session, owns_turn)``.

        Resolution order:

        1. Ambient :data:`current_session` ContextVar — preserves
           existing host-managed session contexts (e.g. when an MCP
           server is invoked inside an outer ``shield.guard(agent)``).
           Caller owns the turn boundary so we MUST NOT call
           ``begin_turn`` / ``end_turn``.
        2. MCPShield's held connection session (or fresh per-call
           session in ``session_scope="call"`` mode). The wrapper
           manages turn boundaries: per-MCP-tools/call turns reset
           ``per_turn`` lifetimes correctly without requiring the host
           to enter a ``shield.guard(agent)`` context.

        Returns the session and a flag indicating whether the wrapper
        owns the turn lifecycle for this call.
        """
        ambient = current_session.get(None)
        if ambient is not None:
            return ambient, False
        sess = self._resolve_session(None)
        sess.begin_turn()
        return sess, True

    def _handle_block(
        self,
        tool_name: str,
        stage: str,
        message: str,
        pending_resolution: Optional[dict],
        on_block: OnBlock,
    ) -> Any:
        """Convert a Stage 2/3/4 block into the configured surface shape."""
        if on_block == "return_message":
            return message
        if on_block == "error_envelope":
            envelope = _try_build_error_envelope(
                tool_name, stage, message, pending_resolution,
            )
            if envelope is not None:
                return envelope
            # mcp package unavailable — fall through to raise so the
            # block is not silently dropped.
        # "raise" (default fallback path)
        raise MCPGuardrailBlocked(
            tool_name,
            message,
            stage=stage,
            pending_resolution=pending_resolution,
        )

    def _maybe_pydantic_round_trip(
        self, raw_class: Optional[type], output: Any,
    ) -> Any:
        """Re-validate redacted dict back into the Pydantic
        model class the tool originally returned. Returns the raw
        ``output`` unchanged on import failure or validation error
        (a redacted leaf may legitimately violate a strict field
        validator; in that case the dict form survives so structured
        info is not lost)."""
        if raw_class is None:
            return output
        if not isinstance(output, dict):
            return output
        try:
            return _pydantic_round_trip(raw_class, output)
        except Exception:  # noqa: BLE001
            logger.debug(
                "Pydantic round-trip failed for %s; returning dict",
                raw_class.__name__,
                exc_info=True,
            )
            return output

    async def _run_guarded_call_async(
        self,
        tool_name: str,
        kwargs: dict,
        fn: Callable[..., Any],
        on_block: OnBlock,
    ) -> Any:
        # See :meth:`protect_tool` for the reset rationale.
        self._reset_pending_for_new_call()
        sess, owns_turn = self._acquire_call_session()
        try:
            # binding: mint a per-call id so Stage 3 + Stage 4
            # bind against the same canonical invocation.
            call_id = uuid.uuid4().hex
            allowed, effective, msg, pending, admit = _do_protect_tool(
                sess, tool_name, kwargs, call_id,
                pending_resolution_sink=self._capture_pending,
            )
            if not allowed:
                return self._handle_block(
                    tool_name, _STAGE_TOOL_CALL, msg or "", pending, on_block,
                )
            try:
                raw_output = await fn(**effective)
            except Exception as exc:  # noqa: BLE001 — Stage 4 over error text
                logger.warning(
                    "Tool '%s' raised %s", tool_name, type(exc).__name__,
                )
                logger.debug(
                    "Tool '%s' raised: %s", tool_name, exc, exc_info=True,
                )
                error_text = f"[tool error] {tool_name}: {exc}"
                try:
                    sess.record_tool_failure(tool_name, str(exc))
                except Exception:  # noqa: BLE001
                    logger.debug("record_tool_failure raised", exc_info=True)
                allowed_out, value, err_msg, _pending = _do_protect_tool_output(
                    sess, tool_name, admit, error_text,
                    record=False,
                    pending_resolution_sink=self._capture_pending,
                    preserve_raw_result=False,
                )
                if not allowed_out:
                    return self._handle_block(
                        tool_name, _STAGE_TOOL_OUTPUT, err_msg or "",
                        _pending, on_block,
                    )
                return value
            # shape-preserving Stage 4 walker handles Pydantic
            # models (including mcp.types.CallToolResult), dicts,
            # lists, and tuples uniformly while preserving the original
            # Python container type. Replaces the Pydantic-only
            # round-trip + post-processing dance.
            allowed_out, value, err_msg, pending_out = (
                _do_protect_tool_output_preserve_shape(
                    sess, tool_name, admit, raw_output,
                    record=True,
                    pending_resolution_sink=self._capture_pending,
                )
            )
            if not allowed_out:
                return self._handle_block(
                    tool_name, _STAGE_TOOL_OUTPUT, err_msg or "",
                    pending_out, on_block,
                )
            return value
        finally:
            if owns_turn:
                try:
                    sess.end_turn()
                except Exception:  # noqa: BLE001
                    logger.debug("end_turn() raised; ignoring", exc_info=True)

    def _run_guarded_call_sync(
        self,
        tool_name: str,
        kwargs: dict,
        fn: Callable[..., Any],
        on_block: OnBlock,
    ) -> Any:
        # See :meth:`protect_tool` for the reset rationale.
        self._reset_pending_for_new_call()
        sess, owns_turn = self._acquire_call_session()
        try:
            call_id = uuid.uuid4().hex
            allowed, effective, msg, pending, admit = _do_protect_tool(
                sess, tool_name, kwargs, call_id,
                pending_resolution_sink=self._capture_pending,
            )
            if not allowed:
                return self._handle_block(
                    tool_name, _STAGE_TOOL_CALL, msg or "", pending, on_block,
                )
            try:
                raw_output = fn(**effective)
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "Tool '%s' raised %s", tool_name, type(exc).__name__,
                )
                logger.debug(
                    "Tool '%s' raised: %s", tool_name, exc, exc_info=True,
                )
                error_text = f"[tool error] {tool_name}: {exc}"
                try:
                    sess.record_tool_failure(tool_name, str(exc))
                except Exception:  # noqa: BLE001
                    logger.debug("record_tool_failure raised", exc_info=True)
                allowed_out, value, err_msg, _pending = _do_protect_tool_output(
                    sess, tool_name, admit, error_text,
                    record=False,
                    pending_resolution_sink=self._capture_pending,
                    preserve_raw_result=False,
                )
                if not allowed_out:
                    return self._handle_block(
                        tool_name, _STAGE_TOOL_OUTPUT, err_msg or "",
                        _pending, on_block,
                    )
                return value
            # shape-preserving Stage 4 walker (see async path).
            allowed_out, value, err_msg, pending_out = (
                _do_protect_tool_output_preserve_shape(
                    sess, tool_name, admit, raw_output,
                    record=True,
                    pending_resolution_sink=self._capture_pending,
                )
            )
            if not allowed_out:
                return self._handle_block(
                    tool_name, _STAGE_TOOL_OUTPUT, err_msg or "",
                    pending_out, on_block,
                )
            return value
        finally:
            if owns_turn:
                try:
                    sess.end_turn()
                except Exception:  # noqa: BLE001
                    logger.debug("end_turn() raised; ignoring", exc_info=True)

    def _wrap_callable(
        self,
        tool_name: str,
        fn: Callable[..., Any],
        *,
        on_block: OnBlock,
    ) -> Callable[..., Any]:
        if inspect.iscoroutinefunction(fn):
            async def _async(**kwargs: Any) -> Any:
                return await self._run_guarded_call_async(
                    tool_name, kwargs, fn, on_block,
                )
            return _async

        def _sync(**kwargs: Any) -> Any:
            return self._run_guarded_call_sync(
                tool_name, kwargs, fn, on_block,
            )
        return _sync


# ---------------------------------------------------------------------------
# MCPShieldBuilder — fluent builder for MCPShield
# ---------------------------------------------------------------------------


class MCPShieldBuilder:
    """Fluent builder for :class:`MCPShield`."""

    def __init__(self, path: str) -> None:
        self._path = path
        self._yaml_chain: Optional[List[str]] = None
        self._observability_providers: list = []
        self._llm_caller: Optional[Callable] = None
        self._extra_register: list = []
        # default flipped to per-call isolation. The previous
        # ``"connection"`` default leaked session variables across
        # remote clients in any hosted multi-tenant MCP server
        # ("approval state from client A is read by client B's
        # request"). Customers who genuinely want a single long-lived
        # session per :class:`MCPShield` instance must now opt in
        # explicitly via :meth:`with_session_scope("connection")` and
        # will receive a :class:`DeprecationWarning` pointing at the
        # multi-tenant risk.
        self._session_scope: SessionScope = "call"

    def with_observability(
        self, provider: Any,
    ) -> "MCPShieldBuilder":
        """Register a single observability provider. Chain to register more."""
        self._observability_providers.append(provider)
        return self

    def with_llm_caller(
        self, caller: Callable[..., str],
    ) -> "MCPShieldBuilder":
        self._llm_caller = caller
        return self

    def with_extension(
        self, hook: Callable[[RuntimeBuilder], None],
    ) -> "MCPShieldBuilder":
        self._extra_register.append(hook)
        return self

    def with_session_scope(self, scope: SessionScope) -> "MCPShieldBuilder":
        """Override the default ``"call"`` scope.

         the default was changed from ``"connection"`` to
        ``"call"`` because the connection-scoped session is shared
        across every remote client of a hosted MCP server, leaking
        approval state, per-session variables, and event latches
        across tenants.

        Passing ``scope="connection"`` is still supported (legacy
        single-process MCP server use cases — local dev tools, IDE
        sidecar processes) but emits a :class:`DeprecationWarning`
        directing the customer at the multi-tenant risk so the
        opt-in is deliberate.
        """
        if scope == "connection":
            warnings.warn(
                "MCPShield.with_session_scope('connection') retains a "
                "single long-lived Session across every tool call routed "
                "through this shield. In a multi-tenant MCP server "
                "deployment (one MCPShield instance, many remote "
                "clients) this leaks approval state, per-session "
                "variables, and event latches across clients — Client "
                "A's `hr_approved=true` is visible to Client B's next "
                "request.  changed the default to 'call' for "
                "per-call isolation; explicitly request 'connection' "
                "ONLY when the shield is bound to a single trusted "
                "process (local dev tool, IDE sidecar).",
                DeprecationWarning,
                stacklevel=2,
            )
        self._session_scope = scope
        return self

    def build(self) -> MCPShield:
        if self._yaml_chain is not None:
            builder = RuntimeBuilder.from_yaml_chain(self._yaml_chain)
        else:
            builder = RuntimeBuilder.from_yaml(self._path)
        for provider in self._observability_providers:
            builder.register_observability_provider(provider)
        if self._llm_caller is not None:
            builder.register_llm_caller(self._llm_caller)
        for hook in self._extra_register:
            hook(builder)
        return MCPShield(builder.build(), session_scope=self._session_scope)


# ---------------------------------------------------------------------------
# Convenience API
# ---------------------------------------------------------------------------


def shield_server(
    server: Any,
    config: Union[str, MCPShield],
    *,
    on_block: OnBlock = "error_envelope",
) -> MCPShield:
    """Wrap an MCP server with Agent Shield in one call.

    ``on_block`` defaults to ``"error_envelope"``  so blocked
    tool calls return a structured ``CallToolResult(isError=True,
    structuredContent=...)`` rather than a free-form
    ``[GUARDRAIL ...]`` text-only error a client could mistake for a
    legitimate tool-side error. Pass ``on_block="raise"`` for the
    legacy shape (back-compat — raises
    :class:`MCPGuardrailBlocked` in-process; FastMCP wraps the
    exception as ``isError=True`` text on the wire).
    """
    shield = (
        config if isinstance(config, MCPShield)
        else MCPShield.from_yaml(config).build()
    )
    shield.protect_server(server, on_block=on_block)
    return shield


class MCPGuardrailBlocked(Exception):
    """Raised when an MCP tool call is blocked by guardrails.

    Attributes:
        tool_name: The blocked tool's name.
        message: The canonical ``[GUARDRAIL ...]`` block message
            string (also the exception's ``args[0]`` for
            backward compatibility).
        stage: Which stage produced the block — ``"stage_2_3"`` for a
            Stage 2/3 (state / tool-call authorization) block,
            ``"stage_4"`` for a Stage 4 (post-tool output) block. None
            when the caller did not propagate stage information (e.g.
            legacy call sites).
        pending_resolution: For ``kind: human`` / ``kind: tool``
            resolvers that surface a structured pending-resolution
            envelope, the verdict carries a ``pending_resolution`` dict
            shape ``{tool, variable, prompt, request_id, kind}``.
            Lets a customer ``except MCPGuardrailBlocked`` handler
            drive an approval UI without round-tripping through
            :meth:`MCPShield.last_pending_resolution`. None when the
            block has no pending-resolution shape.
    """

    def __init__(
        self,
        tool_name: str,
        message: str,
        *,
        stage: Optional[str] = None,
        pending_resolution: Optional[dict] = None,
    ) -> None:
        super().__init__(message)
        self.tool_name = tool_name
        self.message = message
        self.stage = stage
        self.pending_resolution = pending_resolution


__all__ = [
    "MCPGuardrailBlocked",
    "MCPShield",
    "MCPShieldBuilder",
    "OnBlock",
    "SessionScope",
    "protect_tool",
    "protect_tool_output",
    "shield_server",
]
