"""Composable guardrails configuration — thin wrapper over the Rust core.

Composition, merge, and SHA-256 digesting all live in
``agent_shield_core::config``. This module is just the typed Python
facade: it forwards to ``_NativeGuardrailsConfig`` /
``_NativeCompiledPolicy`` while preserving the public surface
(``GuardrailsConfig``, ``CompiledPolicy``, ``ConfigSource``, the
``layers`` / ``yaml_strings`` introspection points).
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple, Union

import yaml

from ._native import _NativeCompiledPolicy, _NativeGuardrailsConfig

ConfigSource = Union[str, Path, "GuardrailsConfig", Dict[str, Any]]


@dataclass(frozen=True)
class _Layer:
    kind: str  # "path" | "string" | "dict"
    source: Any
    description: str = ""


class CompiledPolicy:
    """Materialised, hashable policy. Digest is computed in Rust; the
    validated ``_NativeCompiledPolicy`` is built lazily on first runtime
    build so introspection-only callers don't pay the validation cost."""

    __slots__ = ("yaml_strings", "_source", "_compiled")

    def __init__(self, yaml_strings: Sequence[str], source: _NativeGuardrailsConfig) -> None:
        self.yaml_strings: Tuple[str, ...] = tuple(yaml_strings)
        self._source = source
        self._compiled: Optional[_NativeCompiledPolicy] = None

    @property
    def digest(self) -> str: return self._source.digest()
    @property
    def hash(self) -> str: return self.digest

    @property
    def _native_handle(self) -> _NativeCompiledPolicy:
        if self._compiled is None:
            self._compiled = self._source.compile()
        return self._compiled

    def __hash__(self) -> int: return int(self.digest[:16], 16)
    def __eq__(self, other: Any) -> bool:
        return isinstance(other, CompiledPolicy) and self.digest == other.digest
    def __repr__(self) -> str:
        return f"CompiledPolicy(layers={len(self.yaml_strings)}, digest={self.digest[:16]}…)"


class GuardrailsConfig:
    """Composable, immutable-by-convention guardrails configuration."""

    __slots__ = ("_native", "_layers", "_yaml_strings")

    def __init__(
        self,
        _native: Optional[_NativeGuardrailsConfig] = None,
        _layers: Sequence[_Layer] = (),
        _yaml_strings: Sequence[str] = (),
    ) -> None:
        self._native = _native
        self._layers: Tuple[_Layer, ...] = tuple(_layers)
        self._yaml_strings: Tuple[str, ...] = tuple(_yaml_strings)

    # ── Constructors ─────────────────────────────────────────────────

    @classmethod
    def load(cls, path: Union[str, Path]) -> "GuardrailsConfig":
        text = Path(path).read_text(encoding="utf-8")
        return cls(_NativeGuardrailsConfig.load(str(path)), (_Layer("path", str(path)),), (text,))

    @classmethod
    def from_string(cls, yaml_text: str, *, description: str = "") -> "GuardrailsConfig":
        return cls(
            _NativeGuardrailsConfig.from_string(yaml_text),
            (_Layer("string", yaml_text, description),),
            (yaml_text,),
        )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any], *, description: str = "") -> "GuardrailsConfig":
        snapshot = dict(data)
        return cls(
            _NativeGuardrailsConfig.from_value(snapshot),
            (_Layer("dict", snapshot, description),),
            (yaml.safe_dump(snapshot, sort_keys=False),),
        )

    @classmethod
    def compose(cls, *sources: ConfigSource) -> "GuardrailsConfig":
        if not sources:
            raise ValueError("compose() requires at least one source")
        first, *rest = sources
        cfg = cls._from_source(first)
        for src in rest:
            cfg = cfg.extend(src)
        return cfg

    # ── Fluent extension ────────────────────────────────────────────

    def extend(self, source: ConfigSource) -> "GuardrailsConfig":
        if not isinstance(source, GuardrailsConfig):
            return self.extend(GuardrailsConfig._from_source(source))
        if self._native is None:
            return GuardrailsConfig(source._native, source._layers, source._yaml_strings)
        if source._native is None:
            return self
        return GuardrailsConfig(
            self._native.extend(source._native),
            self._layers + source._layers,
            self._yaml_strings + source._yaml_strings,
        )

    def with_overrides(
        self, overrides: Mapping[str, Any], *, description: str = "overrides",
    ) -> "GuardrailsConfig":
        return self.extend(GuardrailsConfig.from_dict(overrides, description=description))

    def with_policy_pack(
        self, pack: ConfigSource, *, description: str = "policy_pack",
    ) -> "GuardrailsConfig":
        if isinstance(pack, Mapping) and not isinstance(pack, GuardrailsConfig):
            return self.extend(GuardrailsConfig.from_dict(pack, description=description))
        return self.extend(pack)

    # ── Inspection ──────────────────────────────────────────────────

    @property
    def layers(self) -> Tuple[_Layer, ...]: return self._layers
    def __len__(self) -> int: return len(self._layers)
    def __repr__(self) -> str:
        return f"GuardrailsConfig(layers=[{', '.join(l.kind for l in self._layers)}])"

    # ── Compilation ─────────────────────────────────────────────────

    def compile(self) -> CompiledPolicy:
        if self._native is None or not self._layers:
            raise ValueError("GuardrailsConfig.compile(): no layers to compile")
        return CompiledPolicy(self._yaml_strings, self._native)

    # ── Internal helpers ────────────────────────────────────────────

    @staticmethod
    def _from_source(source: ConfigSource) -> "GuardrailsConfig":
        if isinstance(source, GuardrailsConfig):
            return source
        if isinstance(source, (str, Path)):
            text = str(source)
            if "\n" in text or "\r" in text:
                return GuardrailsConfig.from_string(text)
            return GuardrailsConfig.load(text)
        if isinstance(source, Mapping):
            return GuardrailsConfig.from_dict(source)
        raise TypeError(f"Cannot construct GuardrailsConfig from {type(source).__name__}")


__all__ = ["CompiledPolicy", "ConfigSource", "GuardrailsConfig"]
