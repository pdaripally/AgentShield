"""Stage-4 shape-preserving recovery for tool outputs.

The Rust core's Stage-4 runtime (``stage_post_tool.rs``) serialises any
non-string tool result to a JSON string via ``serde_json::to_string``,
runs detection regexes against that flat text, applies redaction spans,
and — when at least one redaction fires — writes the whole result back
as a single ``Value::String``. The original Python container shape
(dict / list / tuple) is lost, and detectors can match characters that
are part of the JSON serialisation itself (numeric literals, dict-key
quotes, structural punctuation), which can leak
"stringification" semantics into healthcare pipelines
that expect structured tool results.

The Rust core boundary is settled — verdict-handling decisions live
in core; only host-runtime async glue (and now: per-language shape
restoration) lives in the SDK. This module is the Python side of that
restoration: given the original raw Python value plus the verdict's
``applied_transforms`` (canonical char-spans against the rendered
JSON), it walks the value, distinguishes string-leaf content ranges
from non-string regions in the canonical serialisation, and rebuilds
a fresh structure where:

* string leaves get redacted according to spans that fall fully
  within their content range (between the leaf's surrounding
  ``"`` quotes);
* non-string scalars (numeric, bool, null), dict keys, and
  structural punctuation never receive a redaction — spans that
  fall on those regions are dropped (the structured-output "redact only
  string leaves" expectation);
* the container types (dict / list / tuple) are preserved.

The canonical JSON form built here mirrors ``serde_json``'s default
(``BTreeMap``-ordered keys, no whitespace, escapes only for control
chars / ``"`` / ``\\``). When the original value contains a type the
canonicaliser cannot match byte-for-byte against Rust's output (e.g.
floats with unusual repr, ``NaN``/``Infinity``, dict keys that are not
strings), :func:`recover_structured_redactions` returns ``None`` and
the caller falls back to the legacy stringified result — no silent
mis-redaction.
"""
from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Optional, Sequence, Tuple

logger = logging.getLogger("agent_shield")


# ---------------------------------------------------------------------------
# Canonical JSON building (matches serde_json default output)
# ---------------------------------------------------------------------------


def _escape_json_string(s: str) -> str:
    """Escape `s` the same way ``serde_json`` does by default.

    serde_json escapes control characters (< 0x20), ``"``, and ``\\``;
    non-ASCII bytes pass through unmodified. The function returns the
    inner escaped form WITHOUT surrounding quotes.
    """
    out: List[str] = []
    for ch in s:
        code = ord(ch)
        if ch == '"':
            out.append('\\"')
        elif ch == '\\':
            out.append('\\\\')
        elif ch == '\n':
            out.append('\\n')
        elif ch == '\r':
            out.append('\\r')
        elif ch == '\t':
            out.append('\\t')
        elif ch == '\b':
            out.append('\\b')
        elif ch == '\f':
            out.append('\\f')
        elif code < 0x20:
            out.append(f'\\u{code:04x}')
        else:
            out.append(ch)
    return "".join(out)


# A leaf range entry: (path_tuple, content_start, content_end).
# content_start / content_end are char offsets in the canonical form
# pointing at the FIRST char of the string's escaped content and the
# char immediately AFTER the last char of that content (i.e. the
# closing quote position). They exclude the surrounding ``"`` quotes.
LeafRange = Tuple[Tuple[Any, ...], int, int]


def build_canonical_with_leaf_ranges(
    value: Any,
) -> Optional[Tuple[str, List[LeafRange]]]:
    """Build a canonical JSON form of ``value`` matching ``serde_json``'s
    default output and collect the char-ranges of every string leaf's
    content (excluding surrounding quotes).

    Returns ``(canonical_str, leaf_ranges)`` on success, or ``None`` if
    ``value`` contains a type that cannot be represented byte-equivalent
    to ``serde_json`` (e.g. a float that doesn't round-trip cleanly,
    non-string dict keys, or an arbitrary user object).
    """
    parts: List[str] = []
    leaf_ranges: List[LeafRange] = []
    pos = [0]  # Mutable accumulator captured by the inner closures.

    def emit(s: str) -> None:
        parts.append(s)
        pos[0] += len(s)

    # Internal sentinel raised when canonicalisation cannot proceed safely.
    class _Unrepresentable(Exception):
        pass

    def build(v: Any, path: Tuple[Any, ...]) -> None:
        if v is None:
            emit("null")
            return
        if isinstance(v, bool):
            emit("true" if v else "false")
            return
        if isinstance(v, int):
            emit(str(v))
            return
        if isinstance(v, float):
            if v != v or v == float("inf") or v == float("-inf"):
                raise _Unrepresentable("NaN/Infinity not representable")
            # serde_json with default settings renders f64 via ryu —
            # the shortest decimal that round-trips. Python's repr
            # has the same property for f64 since 3.1. The strings
            # match for the vast majority of finite f64s; for the
            # rare divergence (e.g. negative zero rendered as "0.0"
            # in one and "-0.0" in the other), the caller's offset
            # math would silently mis-map redactions, so we bail.
            emit(repr(v))
            return
        if isinstance(v, str):
            emit('"')
            escaped = _escape_json_string(v)
            start = pos[0]
            emit(escaped)
            end = pos[0]
            emit('"')
            leaf_ranges.append((path, start, end))
            return
        if isinstance(v, dict):
            emit("{")
            try:
                items = sorted(v.items(), key=lambda kv: kv[0])
            except TypeError as exc:
                raise _Unrepresentable("non-sortable dict keys") from exc
            first = True
            for k, val in items:
                if not isinstance(k, str):
                    raise _Unrepresentable("non-string dict key")
                if not first:
                    emit(",")
                first = False
                emit('"')
                emit(_escape_json_string(k))
                emit('"')
                emit(":")
                build(val, path + (k,))
            emit("}")
            return
        if isinstance(v, (list, tuple)):
            emit("[")
            first = True
            for i, item in enumerate(v):
                if not first:
                    emit(",")
                first = False
                build(item, path + (i,))
            emit("]")
            return
        raise _Unrepresentable(f"unsupported type: {type(v).__name__}")

    try:
        build(value, ())
    except _Unrepresentable as exc:
        logger.debug(
            "Stage 4 canonicaliser bailed: %s; falling back to stringified result",
            exc,
        )
        return None

    return "".join(parts), leaf_ranges


# ---------------------------------------------------------------------------
# Span-based redaction reconstruction
# ---------------------------------------------------------------------------


# Applied-transform shape (from ``stage_verdict_to_py`` in src/lib.rs):
#   { "policy": str,
#     "evaluate_when_index": int,
#     "action": "redact" |...,
#     "span_start": int,
#     "span_end": int,
#     "replacement": str }
#
# Spans are char offsets against the canonical-rendered text computed
# by Rust's ``render_result_as_text`` (which equals
# ``serde_json::to_string(original)`` for non-string inputs).


def recover_structured_redactions(
    original: Any,
    applied_transforms: Sequence[Dict[str, Any]],
) -> Optional[Any]:
    """Rebuild a structured value of the same shape as ``original`` with
    string-leaf-only redactions applied per ``applied_transforms``.

    Each transform's ``[span_start, span_end)`` is checked against the
    string-leaf content ranges in the canonical JSON of ``original``.
    Transforms that fall fully inside a single leaf's content are
    applied to that leaf (with offsets translated to leaf-relative).
    Transforms that fall on non-string regions (numeric literals,
    booleans, structural punctuation, dict keys) — or that straddle
    leaf boundaries — are DROPPED.

    Returns the recovered value on success, or ``None`` when canonical
    reconstruction is not possible (caller should fall back to the
    legacy stringified result).
    """
    if not isinstance(original, (dict, list, tuple)):
        # Scalars don't have shape; nothing to recover.
        return None

    built = build_canonical_with_leaf_ranges(original)
    if built is None:
        return None
    _canonical, leaf_ranges = built

    # Group transforms by their target leaf path.
    per_leaf: Dict[Tuple[Any, ...], List[Tuple[int, int, str]]] = {}
    for t in applied_transforms:
        ts = t.get("span_start")
        te = t.get("span_end")
        # serde returns the redaction's replacement in ``replacement``.
        repl = t.get("replacement", "") or ""
        if not isinstance(ts, int) or not isinstance(te, int) or ts > te:
            continue
        host_leaf: Optional[Tuple[Any, ...]] = None
        host_lstart = 0
        for (path, lstart, lend) in leaf_ranges:
            if lstart <= ts and te <= lend:
                host_leaf = path
                host_lstart = lstart
                break
        if host_leaf is None:
            # Span falls outside any string leaf's content (e.g. on a
            # numeric literal like `42`, on structural punctuation, on
            # a dict key, or straddles a leaf boundary). Only string
            # leaves may be redacted, so drop the transform.
            logger.debug(
                "Stage 4 dropping transform [%d, %d) — not within a string leaf",
                ts,
                te,
            )
            continue
        per_leaf.setdefault(host_leaf, []).append(
            (ts - host_lstart, te - host_lstart, repl),
        )

    return _rebuild_with_redactions(original, per_leaf, ())


def _rebuild_with_redactions(
    value: Any,
    per_leaf: Dict[Tuple[Any, ...], List[Tuple[int, int, str]]],
    path: Tuple[Any, ...],
) -> Any:
    if isinstance(value, dict):
        return {
            k: _rebuild_with_redactions(v, per_leaf, path + (k,))
            for k, v in value.items()
        }
    if isinstance(value, list):
        return [
            _rebuild_with_redactions(item, per_leaf, path + (i,))
            for i, item in enumerate(value)
        ]
    if isinstance(value, tuple):
        return tuple(
            _rebuild_with_redactions(item, per_leaf, path + (i,))
            for i, item in enumerate(value)
        )
    if isinstance(value, str):
        transforms = per_leaf.get(path)
        if not transforms:
            return value
        return _apply_leaf_transforms(value, transforms)
    return value


def _apply_leaf_transforms(
    original: str,
    transforms: List[Tuple[int, int, str]],
) -> str:
    """Apply ``transforms`` (start, end, replacement) to ``original``.

    Offsets are in the ESCAPED (canonical JSON) form. We escape
    ``original``, splice in the replacements (in reverse-start order so
    earlier offsets remain valid), then JSON-decode the resulting
    quoted form to recover a Python string. If the redaction broke
    JSON escape syntax (e.g. replacement injected an unescaped ``"``
    or trailing ``\\``), we return the redacted-escaped form raw.
    """
    escaped = _escape_json_string(original)
    # Reverse-sort by start so splices don't invalidate later offsets.
    transforms = sorted(transforms, key=lambda x: x[0], reverse=True)
    out = escaped
    for ts, te, repl in transforms:
        if ts < 0 or te > len(out) or ts > te:
            # Defensive: out-of-range span. Drop the splice and keep
            # whatever was already applied — failing-open here would
            # leave PHI in place, so we leave the partial redaction.
            logger.debug(
                "Stage 4 dropping out-of-range leaf splice [%d, %d) (len=%d)",
                ts,
                te,
                len(out),
            )
            continue
        out = out[:ts] + repl + out[te:]
    try:
        return json.loads('"' + out + '"')
    except json.JSONDecodeError:
        logger.debug(
            "Stage 4 JSON-unescape failed for redacted leaf; returning raw escaped",
        )
        return out
