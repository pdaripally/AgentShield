# Python CrewAI adapter mediation

## Mediated paths
- `ShieldBuilder.with_crewai()` installs the bundle; Crew kickoff / agent execution routes through `sdk/python/agent_shield/adapters/crewai.py:452`.
- CrewAI tools are wrapped at `sdk/python/agent_shield/adapters/crewai.py:404`.
- `create_crewai_agent()` / `guard_crew()` are installed from the adapter bundle at `sdk/python/agent_shield/adapters/crewai.py:670`.

## Unsupported paths
- Calling the original tool's `_run(...)` directly.
- Running `Crew.kickoff(...)` or custom Crew orchestration on raw tools.
- Streaming output paths; this adapter declares streaming unsupported.

## Bypass risks
- Keeping raw CrewAI tool instances in the crew after wrapping.
- Replacing a wrapped tool mid-run with the original `_run` implementation.
- Calling the underlying LLM/tool backend directly and assuming Stage 1/5 coverage still applies.

## Streaming behavior
- Streaming is not supported on this adapter. Rules 1-5 are therefore not applicable on the shipped surface.

## Unknown tool-call shapes
- CrewAI tools forward kwargs through the adapter-owned wrapper, but there is no separate fail-closed branch for unknown framework tool-call shapes or `incident.unknown_invocation_shape` emission yet.

## See also

See [Post-tool limits and dangerous patterns](../../../../../docs/POST_TOOL_LIMITS.md) and the [adapter-mediated path matrix](../../../../../docs/adapter-mediated-paths.md).
