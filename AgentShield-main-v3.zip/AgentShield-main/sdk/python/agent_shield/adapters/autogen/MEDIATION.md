# Python AutoGen adapter mediation

## Mediated paths
- `ShieldBuilder.with_autogen()` installs the bundle; guarded agent execution goes through `sdk/python/agent_shield/adapters/autogen.py:231`.
- AutoGen tool calls are wrapped at `sdk/python/agent_shield/adapters/autogen.py:195`.
- The adapter's buffered stream shim lives at `sdk/python/agent_shield/adapters/autogen.py:293`, but the capability report still marks streaming unsupported.
- `Shield.create_autogen_team(team)`  wraps a `BaseGroupChat` so every participant's tool calls share ONE `Session`; per-session variables populated by one agent's tool are visible to the next agent's Stage 2 / Stage 3 `evaluate_when` predicates within the same team run.

## Cross-agent variable persistence

```python
from autogen_agentchat.teams import RoundRobinGroupChat

team = RoundRobinGroupChat([intake_agent, kyc_agent, account_agent])
guarded = shield.create_autogen_team(team)
await guarded.run(task="Open a savings account for ...")
```

For ad-hoc multi-agent flows that do NOT assemble into a `BaseGroupChat`, pass the same explicit `session=` to each `shield.create_autogen_agent(...)` / `shield.guard(agent, session=...)` call to share state by hand.

## Tool return shape

`FunctionTool`s whose callable returns a `dict` or Pydantic `BaseModel` now reach the post-tool variable engine with their original Python shape — not `str(value)` — so populators of the form `@result.<field>` extract correctly.

## Unsupported paths
- Calling the original `BaseTool.run(...)` directly.
- Framework streaming paths beyond the adapter's documented buffered shim.
- Any AutoGen execution path that bypasses `shield.guard(...)` / `shield.protect_tools(...)`.

## Bypass risks
- Registering raw and wrapped AutoGen tools side by side.
- Swapping a wrapped tool back to the raw object after agent construction.
- Assuming the buffered shim upgrades AutoGen to full streaming coverage; it does not.

## Streaming behavior
- Streaming is documented as unsupported for this adapter. The buffered helper is compatibility glue, not a conformance claim, so the streaming-stage rules are not claimed here.

## Unknown tool-call shapes
- Argument validation falls back from `model_validate(...)` to constructor binding in `sdk/python/agent_shield/adapters/autogen.py:184`; truly unknown shapes therefore do not yet emit `incident.unknown_invocation_shape`.

## See also

See [Post-tool limits and dangerous patterns](../../../../../docs/POST_TOOL_LIMITS.md) and the [adapter-mediated path matrix](../../../../../docs/adapter-mediated-paths.md).
