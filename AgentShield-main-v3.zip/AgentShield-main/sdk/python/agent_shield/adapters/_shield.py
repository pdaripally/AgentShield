"""Framework-agnostic shield orchestrator.

:class:`Shield` is the single class that drives every guarded turn for
every framework. It is parameterised by a :class:`FrameworkBundle` and
delegates only the framework-specific shape translation to the bundle's
four capabilities.

What lives here (framework-neutral):

* Stage sequencing and ``begin_turn`` / ``end_turn`` invariants
* Session resolution and ``ContextVar`` propagation
* :func:`guarded_turn` / :func:`guarded_tool` orchestration
* ``record_tool_success`` / ``record_tool_failure`` bookkeeping
* On-block policy (``raise`` / ``return_verdict`` / ``monitor`` / callable)
* Mode (``enforce`` / ``monitor``)
* Capability report exposure

What does *not* live here:

* How to extract a tool's name/description/schema (→ ToolWrapper)
* How to read the LLM client's chat completion response (→ LlmCallerFactory)
* How to invoke the framework's agent and reshape its result
  (→ AgentBoundary)
* How streaming chunks are shaped (→ StreamingAdapter)
"""
from __future__ import annotations

import asyncio
import inspect
import logging
import re
import threading
import uuid
import weakref
from enum import Enum
from typing import Any, Awaitable, Callable, Dict, List, Optional, Union

from agent_shield import (
    PerfTelemetry,
    Runtime,
    RuntimeBuilder,
    Session,
)
from agent_shield.errors import (
    AgentShieldConfigError,
    AgentShieldLensIncomplete,
    AgentShieldUnsupportedOutputType,
    _make_config_error,
)

from ._capabilities import (
    AgentBoundary,
    CapabilityReport,
    FrameworkBundle,
    StreamingAdapter,
    StreamingPushResult,
    ToolMetadata,
    ToolWrapper,
)
from ._orchestration import (
    AgentShieldBlocked as _OrchestrationAgentShieldBlocked,
    _dispatch_stage,
    check_stage1,
    current_session,
    current_user_input,
    guarded_tool,
    guarded_turn,
)

logger = logging.getLogger("agent_shield.shield")


# ---------------------------------------------------------------------------
# Friendlier loader error for approval.* event identifiers
# ---------------------------------------------------------------------------


_APPROVAL_MALFORMED_RE = re.compile(
    r"event identifier `(approval\.[^`]+)` is malformed"
)
_APPROVAL_INVALID_SUFFIX_RE = re.compile(
    r"event identifier `(approval\.[^`]+)` has invalid suffix `([^`]+)`"
)
_APPROVAL_VALID_SUFFIXES = ("allow", "deny", "cancelled")


def _enrich_loader_error(exc: BaseException) -> BaseException:
    """Return a friendlier :class:`AgentShieldConfigError` when the
    loader raises a malformed ``approval.*`` event identifier.

    Spec reserves ``approval.<name>.<allow|deny|cancelled>`` as
    the only valid suffixes under the closed ``approval.*`` namespace.
    First-time authors hitting two load failures (typo ``approval.X``
    or ``approval.X.approved``) before discovering the canonical
    shape is a known onboarding-friction class.

    Returns the original exception unchanged when no approval-shape
    pattern matches — so non-approval loader errors are not rephrased.
    """
    if not isinstance(exc, AgentShieldConfigError):
        return exc
    message = str(exc)

    malformed = _APPROVAL_MALFORMED_RE.search(message)
    if malformed is not None:
        bad = malformed.group(1)
        # `approval.cfo_approved` -> the customer probably meant
        # `approval.cfo_approved.allow` (the most common case).
        # Strip the `approval.` prefix to derive the name; if the
        # remainder contains dots, take the first segment.
        name = bad[len("approval."):].split(".", 1)[0]
        hint = (
            f"event identifier `{bad}` is malformed.\n\n"
            f"Expected shape: `<prefix>.<name>.<suffix>`\n"
            f"For approvals, the only valid suffixes are: "
            f"{', '.join(_APPROVAL_VALID_SUFFIXES)}\n\n"
            f"Try: `approval.{name}.allow`\n"
            f"     `approval.{name}.deny`\n"
            f"     `approval.{name}.cancelled`\n\n"
            f"See spec (closed event namespace) for the full list."
        )
        return _make_config_error(
            f"{message}\n\n{hint}",
            code="loader_error",
        )

    invalid_suffix = _APPROVAL_INVALID_SUFFIX_RE.search(message)
    if invalid_suffix is not None:
        bad = invalid_suffix.group(1)
        suffix = invalid_suffix.group(2)
        prefix_and_name = bad.rsplit(".", 1)[0]
        hint = (
            f"event identifier `{bad}` has an unrecognised suffix "
            f"`{suffix}`.\n\n"
            f"For approvals, the only valid suffixes are: "
            f"{', '.join(_APPROVAL_VALID_SUFFIXES)}\n\n"
            f"Try: `{prefix_and_name}.allow`\n"
            f"     `{prefix_and_name}.deny`\n"
            f"     `{prefix_and_name}.cancelled`\n\n"
            f"See spec (closed event namespace) for the full list."
        )
        return _make_config_error(
            f"{message}\n\n{hint}",
            code="loader_error",
        )

    return exc


def _load_runtime_builder(
    *, path: Optional[str], chain: Optional[List[str]],
) -> "RuntimeBuilder":
    """Call ``RuntimeBuilder.from_yaml`` / ``from_yaml_chain`` with
    loader-error enrichment applied."""
    try:
        if chain is not None:
            return RuntimeBuilder.from_yaml_chain(chain)
        return RuntimeBuilder.from_yaml(path)  # type: ignore[arg-type]
    except AgentShieldConfigError as exc:
        enriched = _enrich_loader_error(exc)
        if enriched is exc:
            raise
        raise enriched from exc


# ---------------------------------------------------------------------------
# Mode / on-block policy
# ---------------------------------------------------------------------------


class ShieldMode(str, Enum):
    """Whether the shield enforces blocks or only records them.

    * ``ENFORCE`` — blocked actions short-circuit the run and the
      framework receives a blocked result (or an exception, depending
      on the on-block policy).
    * ``MONITOR`` — every blocked action is logged through observability
      providers but the run proceeds as if the verdict was allowed.
      Used for safe rollout of new policies in production.
    """

    ENFORCE = "enforce"
    MONITOR = "monitor"


OnBlockPolicy = Union[str, Callable[[Any], Any]]
"""Customer-controlled handling of blocked verdicts.

* ``"return_blocked"`` (default) — return the framework's blocked
  result shape (``AgentBoundary.make_blocked``). Preserves the historic
  behaviour of every adapter.
* ``"return_verdict"`` — return the raw :class:`StageVerdict` so the
  caller can branch on it explicitly.
* ``"raise"`` — raise :class:`AgentShieldBlocked` so the caller can
  ``except`` on it.
* callable — invoked as ``policy(verdict_or_message)`` and its return
  value is forwarded to the framework. The orchestrator passes either
  a verdict object or, when only a formatted message is available, the
  message string.
"""


class AgentShieldBlocked(Exception):  # pragma: no cover
    """Deprecated stub — replaced at import time with the canonical class.

    The single canonical :class:`AgentShieldBlocked` lives in
    :mod:`agent_shield.adapters._orchestration` and is rebound to this
    module-level name immediately below. Kept as a class-shaped stub
    so docs that point at this symbol still resolve; the rebind
    guarantees ``isinstance`` checks work whether downstream imports
    came from the orchestration module or this module.
    """


# Rebind to the canonical class so all references — including
# ``except AgentShieldBlocked`` blocks reached from either module's
# import — resolve to the SAME class. Previously the two
# modules each defined a separate ``AgentShieldBlocked`` with a
# different ``__init__`` signature, which silently broke cross-module
# ``except`` blocks (the CrewAI adapter caught exceptions of the
# orchestration class, but the tool-wrapper raised the shield class).
AgentShieldBlocked = _OrchestrationAgentShieldBlocked  # noqa: F811


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _resolve_block(
    policy: OnBlockPolicy,
    *,
    framework_blocked: Any,
    verdict: Any,
    message: str,
) -> Any:
    """Apply the on-block policy and produce the value to return.

    ``framework_blocked`` is the value the AgentBoundary would have
    returned (``make_blocked(message)``); we use it for the default path
    so existing callers see no behavioural change.
    """
    if callable(policy):
        return policy(verdict if verdict is not None else message)
    if policy == "raise":
        raise AgentShieldBlocked(verdict, message)
    if policy == "return_verdict":
        return verdict
    # default
    return framework_blocked


def _flush_runtime_observability(runtime: Any) -> None:
    """Drain async observability queues on ``runtime`` if exposed.

    Per-provider worker queues make provider delivery asynchronous.
    After orchestrator boundaries (run / run_streamed)
    we drain so callers reading registered observability providers
    immediately afterwards see every event the turn emitted.

    Best-effort: skips silently if the runtime predates the queue
    surface, so this helper stays safe to call against test fakes.
    """
    flush = getattr(runtime, "flush_observability", None)
    if flush is None:
        return
    try:
        flush()
    except Exception:  # noqa: BLE001
        pass


def _thunk_accepts_positional_arg(execute: Callable[..., Any]) -> bool:
    """Decide whether ``execute`` accepts a positional argument.

    Used by :meth:`Shield.run` to thread the Stage 1
    effective ``user_input`` into thunks whose signature is
    ``execute(input)`` while preserving zero-arg backwards
    compatibility. Returns ``True`` when ``execute`` declares at
    least one parameter that can be filled positionally
    (``POSITIONAL_ONLY``, ``POSITIONAL_OR_KEYWORD``, or
    ``VAR_POSITIONAL``). Returns ``False`` when the signature is
    not inspectable (built-ins, certain C-implemented bound
    methods) so we fall back to the legacy zero-arg call shape.
    """
    try:
        sig = inspect.signature(execute)
    except (TypeError, ValueError):
        return False
    for param in sig.parameters.values():
        if param.kind in (
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            inspect.Parameter.VAR_POSITIONAL,
        ):
            return True
    return False


async def _call_thunk_with_optional_input(
    execute: Callable[..., Any],
    effective_input: str,
) -> Any:
    """Invoke ``execute`` with the Stage 1 effective input when accepted.

    Pattern C thunks that have closed over the original
    (unvalidated) prompt would silently bypass Stage 1 redactions if
    we always called them with zero arguments. We use
    :func:`inspect.signature` to opt the thunk into a one-arg call
    shape when it declares at least one positional parameter; the
    legacy ``execute()`` shape is preserved for thunks that don't.

    The thunk's return value (or awaitable) is awaited here so
    sync-and-async callables both work without the caller branching.
    """
    if _thunk_accepts_positional_arg(execute):
        result = execute(effective_input)
    else:
        result = execute()
    if inspect.isawaitable(result):
        return await result
    return result


def _try_import_pydantic_basemodel() -> Optional[type]:
    """Return :class:`pydantic.BaseModel` or ``None`` when Pydantic
    is not installed.

    Both Pydantic v1 and v2 expose ``BaseModel`` at the top level;
    callers must dispatch on the presence of ``model_dump`` /
    ``model_validate`` (v2) vs ``dict`` / ``parse_obj`` (v1).
    """
    try:
        from pydantic import BaseModel
        return BaseModel
    except Exception:  # noqa: BLE001
        return None


def _pydantic_dump(model: Any) -> Any:
    """Serialise a Pydantic model to a JSON-safe dict.

    Supports Pydantic v2 (``model_dump(mode='json')``) and v1
    (``dict()``). The result is a plain ``dict`` / ``list`` /
    scalar tree suitable for recursive Stage 5 redaction or for
    Stage 4's ``@result.<field>`` extractors.
    """
    dump = getattr(model, "model_dump", None)
    if callable(dump):
        try:
            return dump(mode="json")
        except TypeError:
            return dump()
    legacy_dict = getattr(model, "dict", None)
    if callable(legacy_dict):
        return legacy_dict()
    raise TypeError(
        f"cannot serialise Pydantic model of type {type(model).__name__}"
    )


def _pydantic_round_trip(model_cls: type, value: Any) -> Any:
    """Re-validate *value* against *model_cls*. Supports v1 + v2."""
    validate = getattr(model_cls, "model_validate", None)
    if callable(validate):
        return validate(value)
    parse_obj = getattr(model_cls, "parse_obj", None)
    if callable(parse_obj):
        return parse_obj(value)
    raise TypeError(
        f"cannot re-validate Pydantic model of type {model_cls.__name__}"
    )


def _default_set_text(result: Any, redacted: str) -> Any:
    """Default ``set_text`` writer for :meth:`Shield.run` ``extract_text=``.

    This helper is no longer the implicit fallback when
    ``set_text=`` is omitted; supplying ``extract_text`` without
    ``set_text`` now raises :class:`AgentShieldLensIncomplete`. The
    function is retained because customers can still opt into the
    legacy side-channel write-to-``.text`` semantics by passing
    ``set_text=_default_set_text`` explicitly (or, more idiomatically,
    a lambda that targets the field they want).

    Mutates ``result.text`` in place and returns ``None`` so the
    original (mutated) reference flows back to the caller. Matches the
    Vercel AI SDK ``GenerateTextResult``, LangChain ``AgentExecutor``
    output, OpenAI Assistants ``Run`` and Pydantic ``BaseModel``
    shapes that expose mutable ``text`` fields.

    For immutable / frozen result types (``@dataclass(frozen=True)``,
    ``NamedTuple``) or for ``dict``-shaped results pass a custom
    callable that returns a new instance::

        # frozen dataclass
        set_text=lambda r, t: dataclasses.replace(r, text=t)

        # plain dict
        set_text=lambda r, t: {**r, 'text': t}
    """
    result.text = redacted
    return None


# Sentinel used to distinguish "set_text was not supplied at
# all" (caller forgot — fail-closed) from "set_text=None was passed
# explicitly" (caller acknowledged advisory-only mode). Module-level
# singleton; identity-checked via ``is`` inside :meth:`Shield.run`.
_SET_TEXT_UNSET: Any = object()


def _stage5_walk_structure(sess: Any, raw: Any) -> tuple[bool, Any]:
    """Walk *raw* and run ``validate_output`` on every string leaf
    while preserving the shape of structured returns.

    The pre-fix Stage 5 path in :meth:`Shield.run` stringified the
    final value via ``str(raw)`` so a LangGraph ``State`` dict came
    back to the caller as the Python repr of that dict — destroying
    the structure downstream code expected (TypedDict / dataclass /
    Pydantic).  This helper traverses *raw* and validates each string
    leaf individually so the same shape flows back with PHI redacted
    in place.

    Dispatch:

    * ``str`` → ``validate_output(leaf)``; block message OR
      redacted string in place.
    * ``None`` / ``bool`` / ``int`` / ``float`` → unchanged (no text
      to scan; Stage 5 expression-only policies still fire when
      ``raw`` is itself a string elsewhere in the tree).
    * ``dict`` → recurse on each value, preserve key order.
    * ``list`` / ``tuple`` → recurse, preserve container type.
    * Pydantic ``BaseModel`` (v1 or v2) → dump → recurse →
      re-validate. When re-validation fails (e.g. a strict-typed
      field rejects the redacted placeholder) we log a warning and
      return the redacted dict form instead of the original model.
    * Anything else → ``str(raw)`` and validate as a single string
      (legacy fallback; preserves behaviour for arbitrary user
      classes).

    The first leaf whose verdict denies short-circuits the walk and
    returns ``(True, block_message)``. On success returns
    ``(False, redacted_value)`` with the same shape as *raw*.

    Cross-leaf detection (e.g. a regex spanning two dict fields) is
    intentionally NOT supported. Each leaf is its own logical chunk of
    output text, and the historic "stringify the whole thing" path
    detected such patterns only by accident — its repr layout was an
    implementation detail, not a guarantee.
    """
    if isinstance(raw, str):
        return _stage5_validate_string_leaf(sess, raw)
    if raw is None or isinstance(raw, (bool, int, float)):
        return False, raw
    if isinstance(raw, dict):
        out: dict = {}
        for k, v in raw.items():
            blocked, new_v = _stage5_walk_structure(sess, v)
            if blocked:
                return True, new_v
            out[k] = new_v
        return False, out
    if isinstance(raw, (list, tuple)):
        items: list = []
        for v in raw:
            blocked, new_v = _stage5_walk_structure(sess, v)
            if blocked:
                return True, new_v
            items.append(new_v)
        return False, (tuple(items) if isinstance(raw, tuple) else items)
    base_model = _try_import_pydantic_basemodel()
    if base_model is not None and isinstance(raw, base_model):
        try:
            dumped = _pydantic_dump(raw)
        except Exception:  # noqa: BLE001
            logger.warning(
                "Stage 5 redaction could not dump Pydantic model %s; "
                "falling back to stringify path",
                type(raw).__name__,
            )
            return _stage5_validate_string_leaf(sess, str(raw))
        blocked, new_v = _stage5_walk_structure(sess, dumped)
        if blocked:
            return True, new_v
        try:
            return False, _pydantic_round_trip(type(raw), new_v)
        except Exception:  # noqa: BLE001
            logger.warning(
                "Stage 5 redaction could not round-trip Pydantic model %s "
                "(redacted value rejected by model validators); returning "
                "redacted dict",
                type(raw).__name__,
            )
            return False, new_v
    # Unknown type — close the silent-bypass class where the
    # walker fell back to ``_stage5_validate_string_leaf(sess, str(raw))``
    # for arbitrary user / framework classes. The default ``str()`` of
    # a class without a custom ``__str__`` yields
    # ``<Foo object at 0x...>`` — a string that contains none of the
    # assistant-visible text the policy was supposed to redact, and so
    # Stage 5 silently returned the unredacted result back to the
    # caller. Raise a typed error pointing at the ``extract_text=``
    # opt-in (handled by :meth:`Shield.run`).
    raise AgentShieldUnsupportedOutputType(type(raw).__name__)


def _stage5_validate_string_leaf(sess: Any, text: str) -> tuple[bool, str]:
    """Run Stage 5 ``validate_output`` on a single string leaf.

    Returns ``(blocked, value)``. *blocked* is ``True`` when the
    verdict denies; *value* is then the canonical block message.
    Otherwise *value* is the redacted string (or the original text on
    a clean proceed). Empty strings short-circuit to ``(False, "")``
    matching the legacy empty-output early return in
    :func:`Shield.run`'s inner ``_stage5_pass``.
    """
    if not text:
        return False, text
    outcome = sess.validate_output(text)
    decision = _dispatch_stage(outcome.verdict)
    action = decision["action"]
    kind = action["kind"]
    if kind == "return_blocked":
        return True, action["message"]
    if kind == "proceed_with_mutation":
        return False, (outcome.response if outcome.response is not None else text)
    return False, text


# ---------------------------------------------------------------------------
# Generic guarded runner
# ---------------------------------------------------------------------------


class GuardedRunner:
    """Framework-agnostic wrapper around an agent run.

    Every per-framework ``GuardedAgent`` / ``GuardedRunner`` /
    ``GuardedCrew`` reduces to this class plus an
    :class:`AgentBoundary` from the bundle. Per-framework subclasses
    may add extras (e.g. CrewAI exposes ``kickoff`` in addition to
    ``run``) but the core ``run`` / ``run_streamed`` flow lives here.
    """

    def __init__(
        self,
        runtime: Runtime,
        agent: Any,
        boundary: AgentBoundary,
        streaming: Optional[StreamingAdapter] = None,
        *,
        mode: ShieldMode = ShieldMode.ENFORCE,
        on_block: OnBlockPolicy = "return_blocked",
        streaming_config: Optional[dict] = None,
        session: Optional[Session] = None,
    ) -> None:
        if boundary is None:
            raise TypeError(
                "GuardedRunner requires an AgentBoundary capability; "
                "this framework adapter does not support agent run wrapping."
            )
        self._runtime = runtime
        self._agent = agent
        self._boundary = boundary
        self._streaming = streaming
        # Shadow mode (#14) forces MONITOR.
        try:
            runtime_mode = runtime.mode
        except AttributeError:
            runtime_mode = "active"
        self._mode = ShieldMode.MONITOR if runtime_mode == "shadow" else mode
        self._on_block = on_block
        self._streaming_config = streaming_config
        # Accept an explicit ``session=`` so multi-agent
        # callers (e.g. an AutoGen team built from several
        # ``create_autogen_agent`` calls) can SHARE one ``Session``
        # across runners. Per-session variables (``per_session`` lifetime,
        # event latches, populator state) then persist across agents.
        # When ``None`` (the default), each runner owns its own session.
        self._session: Session = (
            session if session is not None else self._runtime.new_session()
        )

    @property
    def agent(self) -> Any:
        """The underlying framework agent."""
        return self._agent

    def with_fresh_session(self) -> "GuardedRunner":
        """Return a NEW :class:`GuardedRunner` bound to a fresh session.

        The original runner — and any in-flight conversation it owns —
        is not mutated. Use this to start a new conversation cleanly
        without the destructive in-place reset footgun.

        Mirrors the Rust ``Shield::with_fresh_session``, .NET
        ``Shield.WithFreshSession``, and Node
        ``GuardedRunner.withFreshSession`` APIs.
        """
        return type(self)(
            self._runtime,
            self._agent,
            self._boundary,
            self._streaming,
            mode=self._mode,
            on_block=self._on_block,
            streaming_config=self._streaming_config,
        )

    async def run(
        self,
        input_text: str,
        *,
        session: Optional[Session] = None,
        agent_calls: Any = None,
        **kwargs: Any,
    ) -> Any:
        """Run the agent with Stage 1 + Stage 5 enforcement.

        ``agent_calls`` is an optional sequence of
        ``(recipient_agent_name, params)`` tuples for inbound
        inter-agent messages (AutoGen / CrewAI style). When supplied,
        each pair triggers :meth:`Session.validate_agent_call` BEFORE
        Stage 1 so guard policies with ``applies_to.agents: [...]``
        actually fire on the documented ``shield.guard(agent)`` path.
        """
        sess = session or self._session
        boundary = self._boundary
        mode = self._mode
        on_block = self._on_block

        async def _execute(effective_input: str) -> Any:
            return await boundary.run(self._agent, effective_input, **kwargs)

        try:
            if mode is ShieldMode.MONITOR:
                return await _execute_with_monitor(
                    sess, input_text, _execute, boundary,
                    agent_calls=agent_calls,
                )

            def _make_blocked_with_policy(message: str) -> Any:
                framework_blocked = boundary.make_blocked(message)
                return _resolve_block(
                    on_block,
                    framework_blocked=framework_blocked,
                    verdict=None,  # guarded_turn folds verdict→message internally
                    message=message,
                )

            return await guarded_turn(
                sess,
                input_text,
                execute=_execute,
                extract_output=boundary.extract_output,
                apply_redaction=boundary.apply_redaction,
                make_blocked=_make_blocked_with_policy,
                agent_calls=agent_calls,
            )
        finally:
            # Drain pending observability deliveries so callers
            # inspecting registered providers (for example,
            # `CapturingProvider`) immediately after `await run(...)`
            # see every event this turn emitted.
            _flush_runtime_observability(self._runtime)

    async def run_streamed(
        self,
        input_text: str,
        *,
        session: Optional[Session] = None,
        **kwargs: Any,
    ):
        """Run the agent with streaming Stage 5 enforcement.

        Emission scheduling honours the streaming guard's configured
        mode ( :attr:`StreamingGuard.mode`). When the mode is
        ``on_complete`` the orchestrator pushes every text-bearing
        chunk through the engine for accumulation but emits NOTHING to
        the consumer until ``validator.finish()`` resolves — that final
        call yields a single terminal chunk carrying the
        validated/redacted text (or a block message if Stage 5 stopped
        the buffer). When the mode is ``per_chunk`` or ``windowed`` the
        framework adapter forwards validated chunks in real time.

        Metadata-only chunks (no text content) are always passed
        through promptly because they are not security-relevant.
        """
        if self._streaming is None:
            raise NotImplementedError(
                "streaming is unsupported for this framework "
                "(no StreamingAdapter in bundle)"
            )

        sess = session or self._session
        boundary = self._boundary
        streaming = self._streaming

        sess.begin_turn()
        try:
            # Shadow / Monitor (#14): run Stage 1 for observability but
            # never short-circuit; stream through a monitor validator
            # that pushes chunks to the real Stage-5 streaming guard
            # for audit events but always emits the original chunks.
            if self._mode is ShieldMode.MONITOR:
                sess.validate_input(input_text or "")
                sess_token = current_session.set(sess)
                input_token = current_user_input.set(input_text or "")
                try:
                    # Open the Stage-5 streaming guard; fall back to
                    # no-guard observability only if the runtime
                    # cannot create one. Stream / customer exceptions
                    # propagate normally — we do NOT swallow them.
                    try:
                        guard_cm = sess.streaming_session(stage=5)
                    except Exception:  # noqa: BLE001
                        logger.debug("monitor streaming_session raised", exc_info=True)
                        guard_cm = None
                    if guard_cm is not None:
                        with guard_cm as guard:
                            mon = _MonitorStreamingValidator(boundary, guard)
                            async for emission in streaming.stream(
                                self._agent, input_text, mon, **kwargs,
                            ):
                                yield emission
                            try:
                                mon.finish()
                            except Exception:  # noqa: BLE001
                                pass
                    else:
                        mon = _MonitorStreamingValidator(boundary, None)
                        async for emission in streaming.stream(
                            self._agent, input_text, mon, **kwargs,
                        ):
                            yield emission
                finally:
                    current_user_input.reset(input_token)
                    current_session.reset(sess_token)
                return

            stage1 = check_stage1(sess, input_text)
            if stage1.is_blocked:
                # Block notifications go through the observability sink
                # (the dispatcher already emits a structured
                # ``guard_policy.<name>.evaluated`` event with the same
                # facts). Emitting an extra ``logger.warning`` here
                # double-reports and, with Python's default ``lastResort``
                # handler, leaks an unstructured ``[Stage 1] Input
                # blocked:...`` line to stderr in hosts that never
                # configured logging. See logging-style-guide.md
                # Rule 5.
                logger.debug("[Stage 1] Input blocked: %s", stage1.block_message)
                yield boundary.make_blocked(stage1.block_message)
                return

            # Spec: Stage 1 ``redact`` rewrites the
            # subject and "the rewritten subject continues through
            # downstream stages." Forward the post-Stage-1 effective
            # input (which equals ``input_text`` when no redaction
            # applied) to the streaming adapter so the agent never
            # sees the unredacted subject.
            effective_input = stage1.effective_input if stage1.effective_input is not None else input_text

            sess_token = current_session.set(sess)
            input_token = current_user_input.set(effective_input or "")
            try:
                with sess.streaming_session(stage=5) as guard:
                    validator = _OrchestratorStreamingValidator(
                        guard, boundary,
                    )
                    async for emission in streaming.stream(
                        self._agent, effective_input, validator, **kwargs,
                    ):
                        yield emission
            finally:
                current_user_input.reset(input_token)
                current_session.reset(sess_token)
        finally:
            try:
                sess.end_turn()
            except Exception:  # noqa: BLE001
                logger.debug("end_turn() raised", exc_info=True)
            _flush_runtime_observability(self._runtime)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._agent, name)

    def __repr__(self) -> str:
        return (
            f"GuardedRunner(runtime=..., agent={self._agent!r}, "
            f"mode={self._mode.value})"
        )


class _OrchestratorStreamingValidator:
    """Bridges :class:`Session.streaming_session` to the
    :class:`StreamingValidator` Protocol.

    Owned by the orchestrator and passed into
    :meth:`StreamingAdapter.stream`; collapses the
    ``streaming_session`` API plus the bundle's ``AgentBoundary`` into
    the four operations adapters need (``push`` / ``finish`` /
    ``make_blocked`` / ``apply_redaction``).
    """

    def __init__(self, guard: Any, boundary: AgentBoundary) -> None:
        self._guard = guard
        self._boundary = boundary

    @property
    def mode(self) -> str:
        return getattr(self._guard, "mode", "on_complete")

    def push(self, text: str) -> StreamingPushResult:
        result = self._guard.push(text)
        action = getattr(result, "action", None) or "pass"
        return StreamingPushResult(
            payload=result.payload,
            stopped=result.stopped,
            reason=getattr(result, "reason", None),
            action=action,
        )

    def finish(self) -> StreamingPushResult:
        tail = self._guard.finish()
        action = getattr(tail, "action", None) or "pass"
        return StreamingPushResult(
            payload=tail.payload,
            stopped=tail.stopped,
            reason=getattr(tail, "reason", None),
            action=action,
        )

    def make_blocked(self, message: str) -> Any:
        return self._boundary.make_blocked(message)

    def apply_redaction(self, framework_chunk: Any, text: str) -> Any:
        return self._boundary.apply_redaction(framework_chunk, text)


class _MonitorStreamingValidator:
    """Monitor-mode streaming validator (#14).

    Pushes chunks through the real Stage-5 streaming guard for
    observability, logs a warning when the guard would have blocked
    or redacted, but always emits the ORIGINAL chunk text and never
    reports `stopped`. `finish()` is idempotent: the streaming adapter
    typically calls it at the end of `stream()`, and the orchestrator
    may call it again for tail drain; the second call is a no-op so
    we don't emit a false "stream already ended" warning.
    """

    def __init__(self, boundary: AgentBoundary, guard: Any) -> None:
        self._boundary = boundary
        self._guard = guard  # may be None when caller couldn't open one
        self._finished = False

    @property
    def mode(self) -> str:
        # Per-chunk so the adapter never buffers customer output.
        return "per_chunk"

    def push(self, text: str) -> StreamingPushResult:
        if self._guard is not None:
            try:
                self._guard.push(text)
            except Exception:  # noqa: BLE001 — observability best-effort
                logger.debug("monitor guard.push raised", exc_info=True)
        return StreamingPushResult(
            payload=text, stopped=False, reason=None, action="pass",
        )

    def finish(self) -> StreamingPushResult:
        if self._finished:
            return StreamingPushResult(
                payload=None, stopped=False, reason=None, action="pass",
            )
        self._finished = True
        if self._guard is not None:
            try:
                self._guard.finish()
            except Exception:  # noqa: BLE001
                logger.debug("monitor guard.finish raised", exc_info=True)
        return StreamingPushResult(
            payload=None, stopped=False, reason=None, action="pass",
        )

    def make_blocked(self, message: str) -> Any:
        return self._boundary.make_blocked(message)

    def apply_redaction(self, framework_chunk: Any, text: str) -> Any:
        return self._boundary.apply_redaction(framework_chunk, text)


async def _execute_with_monitor(
    session: Any,
    input_text: str,
    execute: Callable[[str], Any],
    boundary: AgentBoundary,
    *,
    agent_calls: Any = None,
) -> Any:
    """Monitor-mode equivalent of guarded_turn — record but never block.

    Stage 1 and Stage 5 still run so observability captures them; the
    verdict.allowed value is ignored. Stage-3 redaction is also bypassed
    so monitor-mode never alters customer payloads. Inbound inter-agent
    messages (``agent_calls=[(name, params), ...]``) are
    also run through :meth:`Session.validate_agent_call` so monitor-mode
    audit events are emitted; verdicts are recorded but not enforced.
    """
    session.begin_turn()
    try:
        if agent_calls:
            for agent_name, agent_params in agent_calls:
                try:
                    session.validate_agent_call(
                        agent_name, agent_params or {},
                    )
                except Exception:  # noqa: BLE001
                    logger.debug(
                        "monitor validate_agent_call raised", exc_info=True,
                    )
        session.validate_input(input_text or "")

        sess_token = current_session.set(session)
        input_token = current_user_input.set(input_text or "")
        try:
            result = await execute(input_text or "")
        finally:
            current_user_input.reset(input_token)
            current_session.reset(sess_token)

        output_text = boundary.extract_output(result)
        if output_text and isinstance(output_text, str):
            session.validate_output(output_text)

        return result
    finally:
        try:
            session.end_turn()
        except Exception:  # noqa: BLE001
            logger.debug("end_turn() raised", exc_info=True)


async def _execute_run_monitor(
    session: Any,
    user_input: str,
    execute: Callable[[], Awaitable[Any]],
) -> Any:
    """Monitor-mode equivalent of :meth:`Shield.run` (Pattern C, no bundle).

    Stage 1 and Stage 5 still run for observability; the core
    observability dispatcher emits structured audit events stamped
    with ``mode: shadow`` + ``enforced: false`` for any subscribed
    provider. The thunk's return value is forwarded verbatim (no
    Stage-5 redaction applied).
    """
    sess_token = current_session.set(session)
    try:
        session.begin_turn()
        try:
            if user_input:
                session.validate_input(user_input)
            raw = await execute()
            text = "" if raw is None else str(raw)
            if text:
                session.validate_output(text)
            return raw
        finally:
            try:
                session.end_turn()
            except Exception:  # noqa: BLE001
                logger.debug("end_turn() raised", exc_info=True)
    finally:
        current_session.reset(sess_token)


# ---------------------------------------------------------------------------
# Generic Shield orchestrator
# ---------------------------------------------------------------------------


class Shield:
    """Framework-agnostic shield orchestrator.

    Construct via the composition pattern::

        Shield.from_yaml(path).with_<framework>().build()

    Each adapter module installs its own ``with_<framework>`` method on
    :class:`ShieldBuilder` and a ``create_<framework>_agent`` factory on
    :class:`Shield` at import time.
    """

    def __init__(
        self,
        runtime: Runtime,
        *,
        bundle: Optional[FrameworkBundle] = None,
        client: Any = None,
        streaming_config: Optional[dict] = None,
        mode: ShieldMode = ShieldMode.ENFORCE,
        on_block: OnBlockPolicy = "return_blocked",
    ) -> None:
        # `bundle` is optional: the framework-agnostic methods
        # (`run`, `protect_tool`, `before_invoke`) work without one.
        # Methods that need a bundle (`guard`, `protect_tools`,
        # `capabilities`) raise a clear error at call time.
        self.runtime = runtime
        self._bundle = bundle
        self._client = client
        self._streaming_config = streaming_config
        # Shadow mode (#14) forces MONITOR regardless of `mode` arg.
        try:
            runtime_mode = runtime.mode
        except AttributeError:
            runtime_mode = "active"
        self._mode = ShieldMode.MONITOR if runtime_mode == "shadow" else mode
        self._on_block = on_block
        # weak to mirror the historic per-adapter behaviour
        self._guarded_runners: weakref.WeakSet = weakref.WeakSet()
        # per-session asyncio.Lock that serialises the
        # ``begin_turn → validate_tool_call → execute →
        # validate_tool_output → end_turn`` critical section in
        # :meth:`protect_tool` when the customer binds multiple
        # concurrent calls to the SAME explicit ``session=``. The
        # Rust admission registry is keyed per-session, so overlapping
        # turns on one session race the registry and Stage 4 reports
        # ``binding missing (unknown_admission N)``. Serialising at
        # the SDK boundary mirrors the per-session turn-slot guarantee
        # callers already get from ``shield.run`` / ``shield.guard``
        # (which open at most one turn at a time on a session through
        # the framework's outer loop).
        #
        # Locks are keyed by :class:`Session` identity through a
        # :class:`weakref.WeakKeyDictionary` so closing a session
        # releases the lock entry. ``_session_locks_guard`` is a
        # plain ``threading.Lock`` so concurrent dict mutation from
        # multiple threads (rare, but the shield does not forbid it)
        # cannot lose a lock entry — the lock returned is still an
        # ``asyncio.Lock`` bound to the running loop on first await.
        self._session_locks: "weakref.WeakKeyDictionary[Session, asyncio.Lock]" = (
            weakref.WeakKeyDictionary()
        )
        self._session_locks_guard = threading.Lock()
        # most recent ``pending_resolution`` dict surfaced by
        # a Stage 2/3 block on tools wrapped via :meth:`protect_tools`.
        # Hosts read this after a guarded tool call returns a
        # ``[GUARDRAIL...]`` string to retrieve the structured shape
        # (``{tool, variable, prompt, request_id, kind}``) without
        # parsing the block message. Reset by
        # :meth:`last_pending_resolution`.
        self._last_pending_resolution: Optional[dict] = None
        # the :class:`Session` that produced the most recent
        # ``pending_resolution`` envelope. Captured at latch time via
        # :meth:`_latch_pending_resolution` so :meth:`resolve_pending`
        # can write the resolver outcome back to the SAME session even
        # when called from outside the originating guarded turn (e.g.
        # the host shows the operator UI, then calls
        # ``shield.resolve_pending("allow")`` between two ``runner.run``
        # invocations of a Pattern A guarded agent). When ``None``,
        # :meth:`resolve_pending` falls back to the ambient
        # ``current_session`` ContextVar.
        self._last_pending_session: Optional[Session] = None

    # ── Construction ───────────────────────────────────────────────

    @classmethod
    def from_yaml(cls, path: str, *, auto_bind: bool = True) -> "ShieldBuilder":
        """Start a builder for the given guardrails YAML.

        When exactly one adapter module is imported, the bundle is
        auto-bound and ``.with_<framework>()`` ceremony can be skipped.
        When multiple adapters are imported the auto-bind is ambiguous
        and the call raises
        :class:`~agent_shield.AmbientBundleAmbiguityError`. Pass
        ``auto_bind=False`` to bypass the ambient lookup and bind
        explicitly via ``.with_<framework>()``.
        """
        return ShieldBuilder(path=path, auto_bind=auto_bind)

    @classmethod
    def from_yaml_chain(
        cls, paths: List[str], *, auto_bind: bool = True,
    ) -> "ShieldBuilder":
        b = ShieldBuilder(path=paths[0] if paths else "", auto_bind=auto_bind)
        b._yaml_chain = list(paths)
        return b

    # ── Public surface ─────────────────────────────────────────────

    @property
    def capabilities(self) -> CapabilityReport:
        """The protection profile of this adapter."""
        if self._bundle is None:
            raise RuntimeError(
                "Shield has no capability bundle: call `.with_<framework>()` on "
                "the builder (e.g. `.with_langchain()`, `.with_openai_agents()`, "
                "`.with_anthropic()`) before `.build()` to expose framework "
                "capabilities, or use the framework-agnostic methods "
                "(`run`, `protect_tool`, `before_invoke`) which don't need one."
            )
        return self._bundle.capabilities

    @property
    def mode(self) -> ShieldMode:
        return self._mode

    def protect_tools(
        self,
        tools: list,
        user_input_getter: Optional[Callable[[], str]] = None,
        *,
        allow_unguarded: bool = False,
        session: Optional[Session] = None,
    ) -> list:
        """Wrap framework tools with Stages 2 + 3 + 4 enforcement.

        The wrapped tools are intended to be handed to a framework
        agent that is itself wrapped via :meth:`guard` (Pattern A), so
        every tool call runs inside the agent's guarded turn and sees
        per_turn / per_session variables, event latches, and approval
        state.

        When a wrapped tool is invoked **outside** any guarded session
        the default behavior is fail-closed: the call raises
        :class:`~agent_shield.adapters.UnguardedToolInvocation` so a
        forgotten ``shield.guard(agent)`` cannot silently neuter
        stateful guardrails.

        Pass ``allow_unguarded=True`` to opt back into the
        ad-hoc-invocation path: a fresh session is minted per call
        (warning logged). Use this only when you intentionally want a
        one-shot invocation with no carried-over state.

        Pass ``session=<Session>`` to bind the wrapped tools
        to a customer-owned :class:`~agent_shield.Session`. Every
        invocation of the wrapped tools then executes against that
        session, so per_session variables, event latches, and
        populator state persist across calls — the canonical hook
        for frameworks that drive the agent loop themselves (e.g.
        LangGraph nodes that share state via the graph's reducer).
        ``session=`` takes precedence over the ambient session and
        over ``allow_unguarded``. The customer owns the session's
        lifecycle: create it via :meth:`create_session` (or
        :meth:`session` for a context-managed scope) and call
        :meth:`Session.close` (or exit the ``with`` block) when done.
        Each wrapped-tool invocation opens its own turn on the
        bound session (begin_turn / end_turn around the call) so
        per_turn variables remain per-call but per_session state
        carries.
        """
        if self._bundle is None:
            raise RuntimeError(
                "Shield.protect_tools requires a framework bundle. Call "
                "`.with_<framework>()` on the builder before `.build()`, or "
                "use `Shield.protect_tool(name, params, fn)` which works "
                "without a bundle."
            )
        wrapper = self._bundle.tool_wrapper
        if wrapper is None:
            raise NotImplementedError(
                f"{self._bundle.name} does not support tool wrapping"
            )

        def _sink(pr: dict) -> None:
            # Capture the most recent pending_resolution from
            # any Stage 2/3 block on a wrapped tool so the host can
            # retrieve the structured shape via
            # :meth:`last_pending_resolution` without parsing the
            # block message returned to the LLM.
            self._latch_pending_resolution(pr)

        return _protect_tools_via_wrapper(
            self.runtime, tools, wrapper, user_input_getter,
            mode=self._mode,
            allow_unguarded=allow_unguarded,
            session=session,
            pending_resolution_sink=_sink,
            raise_on_block=getattr(
                self._bundle, "tool_wrapper_raise_on_block", False,
            ),
            preserve_raw_result=getattr(
                self._bundle, "tool_wrapper_preserve_raw_result", False,
            ),
        )

    def _get_session_lock(self, session: Session) -> asyncio.Lock:
        """Return the :class:`asyncio.Lock` that serialises
        :meth:`protect_tool` calls bound to ``session``.

        Lazily created and cached in a :class:`weakref.WeakKeyDictionary`
        keyed by :class:`Session` identity, so closing a session frees
        the entry automatically. ``asyncio.Lock()`` is constructed
        eagerly (CPython 3.10+ binds the lock to the running loop on
        first ``await acquire()``, not at construction time, so this
        is safe to call from synchronous code).

        The dict mutation is guarded by a :class:`threading.Lock` so
        a Shield shared across threads cannot race the cache and hand
        out two different locks for the same session. The returned
        :class:`asyncio.Lock` itself is event-loop-bound and intended
        for single-loop use; callers driving the Shield from multiple
        asyncio loops should mint per-loop sessions.

        See :meth:`protect_tool` for the concurrency context.
        """
        with self._session_locks_guard:
            lock = self._session_locks.get(session)
            if lock is None:
                lock = asyncio.Lock()
                self._session_locks[session] = lock
            return lock

    def _latch_pending_resolution(self, pr: Optional[dict]) -> None:
        """Latch ``pending_resolution`` onto the shield-level slot.

        Single entry point used by every code path that surfaces a
        ``pending_resolution`` envelope from the Rust core — the
        plural :meth:`protect_tools` wrapper, the singular
        :meth:`protect_tool`, and Stage 1 latching inside
        :meth:`run` / :meth:`run_with_session`. Keeping the latch
        write in one place guarantees that every host call to
        :meth:`last_pending_resolution` observes the same envelope
        regardless of which surface produced the block.

        Also captures a reference to the active session (via the
        ambient :data:`current_session` ContextVar) so
        :meth:`resolve_pending` can target the same session that
        produced the suspension even when the host's resume call
        happens outside any guarded turn.

        ``None`` is a no-op so callers can pass through
        ``getattr(verdict, "pending_resolution", None)`` without
        guarding.
        """
        if pr is None:
            return
        self._last_pending_resolution = pr
        active = current_session.get(None)
        if active is not None:
            self._last_pending_session = active

    def current_effective_input(self) -> str:
        """Return the Stage 1-effective user input for the current turn.

        Inside a :meth:`run` / :meth:`run_with_session` thunk this is
        the (possibly Stage-1-redacted) text the orchestrator
        produced — the same value that is passed positionally to
        thunks whose signature accepts an argument. Outside
        a guarded turn this returns the empty string.

        Use this from Pattern C closures that have already captured
        the original prompt and therefore cannot be restructured to
        accept the redacted text as an argument. Calling the LLM with
        the value returned here ensures Stage 1 redactions actually
        reach the model::

            async def my_thunk() -> str:
                prompt = shield.current_effective_input()
                return await llm.complete(prompt)

            await shield.run(my_thunk, user_input=raw_prompt)

        For new code that can accept the input as an argument,
        prefer the thunk-arg shape — it makes the data flow explicit
        and removes the ContextVar read.
        """
        return current_user_input.get("")

    def last_pending_resolution(self) -> Optional[dict]:
        """Peek at the most recent ``pending_resolution`` envelope.

        When a tool wrapped via :meth:`protect_tools` is blocked at
        Stage 2/3 by a resolver that suspends pending external input
        (e.g. a ``kind: human`` resolver waiting on operator approval,
        or a ``kind: tool`` resolver waiting on the agent to call a
        named tool), the verdict carries a structured ``pending_resolution``
        shape::

            {
                "tool": "agent_shield.ask_human",
                "variable": "trade_authorized",
                "prompt": "Authorize this trade?",
                "request_id": "req-7f3c",
                "kind": "human",
            }

        The block message returned through the framework's tool-call
        boundary is shaped for the LLM trajectory; this method gives
        the host a programmatic handle on the same suspension so it
        can drive the human-approval UI (or look up the named tool's
        resolver, prompt the operator, etc.) without substring-matching
        the block message.

        **Non-destructive peek.** Reading the latch does NOT
        clear it. The documented inspect-then-resolve flow

            pending = shield.last_pending_resolution()
            if pending is not None:
                # show pending["prompt"] / pending["request_id"] in a UI
                await shield.resolve_pending("allow", value=True)

        relies on this method being idempotent — multiple peeks return
        the same envelope until :meth:`resolve_pending` (or another
        guarded turn) consumes it. Only :meth:`resolve_pending` (or
        an explicit successful turn that latches a fresh envelope)
        clears the latch.

        Returns ``None`` when no recent block carried a pending
        resolution.
        """
        return self._last_pending_resolution

    async def resolve_pending(
        self,
        decision: str,
        *,
        value: Any = None,
        set_variables: Optional[Dict[str, Any]] = None,
        reason: Optional[str] = None,
    ) -> None:
        """Resolve a previously-surfaced pending resolution.

        Writes the resolver outcome back to the variable that suspended
        a Stage 1/2/3/4 evaluation, so the next ``protect_tool`` /
        ``run`` / Pattern A entry inside the same ambient session sees
        the resolved value and proceeds without re-prompting.

        Convenience shape (single-variable case)::

            shield = (
                Shield.from_yaml("guardrails.yaml")
                .with_openai_agents()
                .build()
            )
            agent = shield.create_openai_agents_agent(tools, model=...)

            result = await agent.run("Place a trade for MSFT")
            pending = shield.last_pending_resolution()
            if pending is not None:
                # Operator UI:
                #   pending["variable"], pending["prompt"], pending["kind"]
                await shield.resolve_pending("allow", value=True)
                # Same agent, same retained session → resumes:
                result = await agent.run("Place a trade for MSFT")

        Args:
            decision: ``"allow"`` or ``"deny"`` — the operator's
                decision. When ``value`` is omitted, ``"allow"``
                resolves the variable to ``True`` and ``"deny"`` to
                ``False`` (matches the canonical wire-shape of a
                boolean approval gate).
            value: Optional explicit value to write to the variable
                named by the latched ``pending_resolution`` envelope.
                Use this for non-boolean variables (e.g. a numeric
                limit, a list, a structured object).
            set_variables: Optional ``{variable: value}`` map to write
                multiple variables in one call. When supplied, the
                latched ``pending_resolution`` envelope is ignored —
                use this when an ``on_demand_by`` resolver was
                configured with ``set_variables`` and the operator
                resolves several variables at once. ``decision`` is
                still recorded for audit but does not influence the
                write.
            reason: Optional free-form audit string. Reserved for
                future observability — currently logged at DEBUG only.

        Resolution targets (in priority order):
            1. Ambient :data:`current_session` (set by
               :meth:`Shield.run` and :meth:`Shield.guard` runners).
            2. The session captured at latch time
               ( :attr:`_last_pending_session`) — covers the case where
               the host calls ``resolve_pending`` between two Pattern A
               agent invocations, outside any active guarded turn.

        Raises:
            ValueError: ``decision`` is neither ``"allow"`` nor
                ``"deny"``.
            RuntimeError: No active session could be resolved (no
                ambient turn AND no prior pending resolution to anchor
                a captured session reference), or no
                ``pending_resolution`` is latched and no explicit
                ``set_variables`` mapping was supplied.
        """
        if decision not in ("allow", "deny"):
            raise ValueError(
                f"Shield.resolve_pending(decision=...): decision must be "
                f"'allow' or 'deny', got {decision!r}",
            )

        sess = current_session.get(None)
        if sess is None:
            sess = self._last_pending_session
        if sess is None:
            raise RuntimeError(
                "Shield.resolve_pending: no active session is available. "
                "Either call from inside a guarded turn (Pattern A "
                "`shield.guard(...).run()`, Pattern C `shield.run(...)`) "
                "OR call after a Stage 1/2/3/4 block surfaced a "
                "`pending_resolution` envelope (the latched session is "
                "then used).",
            )

        pending = self._last_pending_resolution

        if set_variables is not None:
            for name, val in set_variables.items():
                sess.set_variable(name, val)
        elif pending is None:
            raise RuntimeError(
                "Shield.resolve_pending: no `pending_resolution` is "
                "latched. Trigger a Stage 2/3/4 block via a guarded "
                "turn first (the latch is populated when a block "
                "verdict carries a `pending_resolution` envelope), "
                "or pass `set_variables={...}` explicitly to write "
                "the resolution variables yourself.",
            )
        else:
            request_id = pending.get("request_id")
            if not request_id:
                raise RuntimeError(
                    "Shield.resolve_pending: latched `pending_resolution` "
                    "has no `request_id` field; cannot complete it.",
                )
            resolved = value
            if resolved is None and set_variables is None:
                resolved = True if decision == "allow" else False
            try:
                sess.complete_pending_resolution(
                    request_id,
                    decision,
                    resolved,
                    None,
                    reason,
                )
            except RuntimeError as exc:
                if "UnknownRequestId" not in str(exc):
                    raise
                variable_name = pending.get("variable")
                if not variable_name:
                    raise
                payload: Dict[str, Any] = {
                    "kind": pending.get("kind") or "human",
                    "set_by": f"{pending.get('kind') or 'human'}:{variable_name}",
                }
                if decision == "allow":
                    payload["value"] = resolved
                sess.emit_event(f"approval.{variable_name}.{decision}", payload=payload)

        if reason:
            logger.debug(
                "Shield.resolve_pending: decision=%s reason=%s",
                decision, reason,
            )

        # Clear the latch so a subsequent successful turn does not
        # look like another pending block, and so the captured-session
        # reference is released for garbage collection.
        self._last_pending_resolution = None
        self._last_pending_session = None

    def guard(self, agent: Any, **runner_kwargs: Any) -> GuardedRunner:
        """Wrap a framework agent with Stage 1 + Stage 5 enforcement.

        Returns the bundle's ``guarded_runner_cls`` (when set) so
        adapters can ship framework-flavoured runners (LangChain's
        ``ainvoke``/``astream``, AutoGen's ``on_messages``, etc.)
        without subclassing :class:`Shield`. Extra kwargs are forwarded
        to the runner constructor — adapters that need per-run defaults
        (Anthropic's ``tools``/``model``/``system``) accept them via
        ``**runner_kwargs``.

        Pass ``session=<Session>`` to bind the new runner to an
        explicit pre-allocated session. When multiple
        agents in a multi-agent flow are each wrapped via ``guard`` and
        share the same ``session=`` instance, per-session variables,
        event latches, and populator state persist across agents. Omit
        ``session=`` (the default) to let each runner allocate its own
        fresh session — the original single-agent shape.
        """
        if self._bundle is None:
            raise RuntimeError(
                "Shield.guard requires a framework bundle. Call "
                "`.with_<framework>()` on the builder before `.build()`."
            )
        runner_cls = self._bundle.guarded_runner_cls or GuardedRunner
        runner = runner_cls(
            self.runtime,
            agent,
            self._bundle.agent_boundary,
            self._bundle.streaming_adapter,
            mode=self._mode,
            on_block=self._on_block,
            streaming_config=self._streaming_config,
            **runner_kwargs,
        )
        self._guarded_runners.add(runner)
        return runner

    async def before_invoke(
        self, user_input: str, *, session: Optional[Session] = None,
    ) -> Optional[str]:
        """Stage 1 only — for adapters whose ``before_invoke`` hook just
        wants a yes/no answer."""
        # Shadow / Monitor (#14): run Stage 1 for observability and
        # always return None (never block) so the caller proceeds.
        if self._mode is ShieldMode.MONITOR:
            sess = session if session is not None else self.runtime.new_session()
            if session is None:
                sess.begin_turn()
            try:
                sess.validate_input(user_input or "")
            finally:
                if session is None:
                    try:
                        sess.end_turn()
                    except Exception:  # noqa: BLE001
                        pass
            return None

        if session is None:
            with self.runtime.new_session() as s:
                s.begin_turn()
                return check_stage1(s, user_input).block_message
        return check_stage1(session, user_input).block_message

    async def run(
        self,
        execute: Callable[[], Awaitable[Any]],
        *,
        user_input: str = "",
        session: Optional[Session] = None,
        on_block: Optional[OnBlockPolicy] = None,
        extract_text: Optional[Callable[[Any], Optional[str]]] = None,
        set_text: Any = _SET_TEXT_UNSET,
    ) -> Any:
        """Stage 1 + Stage 5 around an opaque thunk. Mirrors the Node /
        Rust / .NET ``run`` (or ``RunAsync``) entry points.

        Use this when the customer's agent is a black-box callable and
        Pattern A's :meth:`guard` doesn't fit (no framework bundle, or
        the agent's shape doesn't match any installed bundle). The
        thunk runs once; its return value is rendered to a string for
        Stage 5 validation, and the (possibly redacted) result is
        returned to the caller.

        For Stage 2 / 3 / 4 protection of individual tool calls inside
        the thunk, use :meth:`protect_tool` (or ambient session via
        ``current_session``).

        Thunk signatures:
            * Zero-arg ``execute()`` — historical shape; still
              supported with no behaviour change.
            * One-arg ``execute(effective_input)`` — the Stage 1
              effective text (possibly redacted by a Stage 1 policy)
              is passed positionally. Use this so the customer's
              call to the LLM uses the redacted prompt rather than
              the unvalidated text captured by a closure.

            The signature is inspected via :func:`inspect.signature`
            once per call. Callables whose signature cannot be
            inspected (built-ins, certain bound methods) fall back to
            the zero-arg path. Within the thunk, the same value is
            also available via :meth:`current_effective_input`.

        Block dispatch (Pattern C surface change):
            * ``on_block=None`` (the new default) → a Stage 1 or
              Stage 5 block raises :class:`AgentShieldBlocked` so
              host code cannot silently mishandle the block-message
              string as if it were a real result.
            * ``on_block="return_blocked"`` (the legacy default)
              preserves the legacy behaviour: a block returns the
              canonical ``[GUARDRAIL ...]`` block string.
            * ``on_block="return_verdict"`` / ``on_block=<callable>``
              honour the same shapes documented in
              :data:`OnBlockPolicy` for the Pattern A surfaces.

            Per the project's "Don't ship safety as opt-in" doctrine,
            the default flipped
            to raise. Customers who explicitly opted into the legacy
            shape via :meth:`ShieldBuilder.with_on_block` keep that
            value — the per-call argument only overrides the shield's
            on_block when supplied.

        Stage 5 text-extraction lens for object-returning
        thunks:
            * ``extract_text=None`` (default) → Stage 5 walks the raw
              result. ``str`` / ``dict`` / ``list`` / ``tuple`` /
              Pydantic ``BaseModel`` / primitives are handled by the
              structured-value walker. Arbitrary user / framework classes raise
              :class:`~agent_shield.errors.AgentShieldUnsupportedOutputType`
              (rather than silently bypassing redaction by validating
              ``str(result)`` — typically a ``<Foo object at 0x...>``
              repr containing no PII).
            * ``extract_text=<callable>`` → call ``extract_text(raw)``
              to obtain the assistant-visible text; run Stage 5 over
              the extracted string; on a clean proceed or
              ``proceed_with_mutation`` use ``set_text(raw, redacted)``
              to mutate (or replace) the result and return it.
              ``set_text`` defaults to ``setattr(raw, 'text', redacted)``
              which matches Vercel AI SDK, LangChain ``AgentExecutor``
              output, OpenAI Assistants and Pydantic ``RunResult``
              shapes. Pass a custom callable for immutable / frozen
              result types (e.g.
              ``set_text=lambda r, t: dataclasses.replace(r, text=t)``)
              or for ``dict``-shaped results
              (``set_text=lambda r, t: {**r, 'text': t}``).
              When ``set_text`` returns a non-``None`` value that
              value becomes the new result; otherwise the original
              (mutated in place) result is returned.
        """
        if not callable(execute):
            raise TypeError("Shield.run(execute): execute must be callable")
        sess = session if session is not None else self.runtime.new_session()

        # Per-call argument always wins; otherwise default to
        # "raise" (the new safer default). The shield-level
        # ``self._on_block`` is intentionally NOT consulted here: this
        # method is the Pattern C surface that this change explicitly
        # retargets. Pattern A adapters (``shield.guard``,
        # ``run_<framework>_agent``) keep using ``self._on_block`` for
        # back-compat with framework-shaped blocked results.
        resolved_on_block: OnBlockPolicy = (
            on_block if on_block is not None else "raise"
        )

        # Shadow / Monitor (#14): record verdicts but never block.
        if self._mode is ShieldMode.MONITOR:
            return await _execute_run_monitor(sess, user_input, execute)

        # Optional Stage 5 text-extraction lens for thunks that
        # return framework-specific result objects (Vercel AI SDK
        # ``GenerateTextResult``, LangChain ``AgentExecutor`` output,
        # OpenAI Assistants, Pydantic ``RunResult``, etc.). When the
        # caller supplies ``extract_text=``, Stage 5 is applied to the
        # extracted string and the redacted text is written back via
        # ``set_text``.
        #
        # ``set_text=`` is now a *required pair* with
        # ``extract_text=``. The previous implicit default
        # (``setattr(result, 'text', redacted)``) silently wrote into a
        # fresh ``.text`` attribute when the customer's extract source
        # was elsewhere (e.g. ``r.choices[0].message.content``), leaving
        # the assistant-visible location unredacted. Absent ``set_text``,
        # this would re-open the same silent-bypass class at
        # the opt-in surface. Raise fail-closed.
        if extract_text is not None and not callable(extract_text):
            raise TypeError(
                "Shield.run(extract_text=): must be a callable returning str",
            )
        if extract_text is not None and set_text is _SET_TEXT_UNSET:
            raise AgentShieldLensIncomplete()
        if (
            set_text is not _SET_TEXT_UNSET
            and set_text is not None
            and not callable(set_text)
        ):
            raise TypeError(
                "Shield.run(set_text=): must be a callable (result, str) -> Optional[result]",
            )
        # ``effective_set_text`` is either a callable (legacy mutate +
        # return) or ``None`` (advisory-only mode — the customer passed
        # ``set_text=None`` explicitly, acknowledging Stage 5 will not
        # mutate the result).
        effective_set_text: Optional[Callable[[Any, str], Any]] = (
            set_text if (set_text is not _SET_TEXT_UNSET and set_text is not None) else None
        )
        advisory_only: bool = (set_text is None)

        async def _stage5_pass(raw: Any) -> Any:
            # extract_text opt-in path. When provided, the
            # walker is bypassed entirely because the customer has
            # explicitly identified the assistant-visible field. The
            # extracted string is validated by Stage 5; on a clean
            # proceed or ``proceed_with_mutation`` the (possibly
            # redacted) text is written back via ``set_text`` and the
            # mutated result is returned.
            if extract_text is not None:
                if raw is None:
                    return raw
                extracted = extract_text(raw)
                if extracted is None:
                    return raw
                if not isinstance(extracted, str):
                    raise TypeError(
                        "Shield.run(extract_text=): callable must return "
                        f"str (or None), got {type(extracted).__name__}",
                    )
                if not extracted:
                    return raw
                outcome = sess.validate_output(extracted)
                decision = _dispatch_stage(outcome.verdict)
                action = decision["action"]
                if action["kind"] == "return_blocked":
                    return _resolve_block(
                        resolved_on_block,
                        framework_blocked=action["message"],
                        verdict=outcome.verdict,
                        message=action["message"],
                    )
                if action["kind"] == "proceed_with_mutation":
                    redacted = (
                        outcome.response
                        if outcome.response is not None
                        else extracted
                    )
                    if advisory_only:
                        # Customer explicitly opted into
                        # advisory-only mode via ``set_text=None``.
                        # Stage 5 evaluated the extracted text but the
                        # result object is intentionally NOT mutated.
                        return raw
                    assert effective_set_text is not None  # established at entry
                    replaced = effective_set_text(raw, redacted)
                    return replaced if replaced is not None else raw
                return raw
            # Strings + None keep the legacy single-shot path
            # (canonical chat-text case; most common shape; most
            # heavily tested). Structured returns (dict / list / tuple
            # / Pydantic BaseModel) are walked through
            # :func:`_stage5_walk_structure` so each string leaf is
            # redacted in place and the same shape flows back to the
            # caller (e.g. a LangGraph State dict survives Stage 5).
            if raw is None:
                return raw
            if isinstance(raw, str):
                text = raw
                if not text:
                    return raw
                outcome = sess.validate_output(text)
                decision = _dispatch_stage(outcome.verdict)
                action = decision["action"]
                if action["kind"] == "return_blocked":
                    # Apply the resolved on_block policy.
                    return _resolve_block(
                        resolved_on_block,
                        framework_blocked=action["message"],
                        verdict=outcome.verdict,
                        message=action["message"],
                    )
                if action["kind"] == "proceed_with_mutation":
                    return outcome.response if outcome.response is not None else text
                return raw
            # Structured values keep their shape; the walker returns
            # the first leaf-level block message unchanged.
            _blocked, value = _stage5_walk_structure(sess, raw)
            if _blocked:
                # The structured-value walker returns the
                # canonical block string on the first leaf block.
                # Route it through the resolved on_block policy so
                # ``on_block="raise"`` raises here too.
                return _resolve_block(
                    resolved_on_block,
                    framework_blocked=value,
                    verdict=None,
                    message=value if isinstance(value, str) else str(value),
                )
            return value

        # Reset the shield-level latch at the start of each
        # new guarded turn so a successful turn does not leave the
        # prior block's ``pending_resolution`` lingering on
        # :meth:`last_pending_resolution`. The latch will be
        # re-populated below if Stage 1 surfaces a pending
        # resolution; downstream :meth:`protect_tool` calls inside
        # the thunk also latch through ``_latch_pending_resolution``.
        self._last_pending_resolution = None
        self._last_pending_session = None

        token = current_session.set(sess)
        try:
            sess.begin_turn()
            try:
                effective_input = user_input or ""
                if user_input:
                    verdict = sess.validate_input(user_input)
                    # Surface Stage 1 ``pending_resolution`` to
                    # the shield-level slot exactly as Stage 2/3/4
                    # blocks do via the ``pending_resolution_sink``.
                    # Whether or not the verdict ultimately blocks,
                    # any envelope on the verdict is latched so the
                    # host can drive the human / tool resolution UI.
                    self._latch_pending_resolution(
                        getattr(verdict, "pending_resolution", None),
                    )
                    decision = _dispatch_stage(
                        verdict,
                        "return_blocked",
                        self._mode.value,
                    )
                    action = decision["action"]
                    if (
                        action["kind"] == "return_blocked"
                        and not decision.get("override_to_proceed", False)
                    ):
                        # Apply the resolved on_block policy.
                        return _resolve_block(
                            resolved_on_block,
                            framework_blocked=action["message"],
                            verdict=verdict,
                            message=action["message"],
                        )
                    if action["kind"] == "proceed_with_mutation":
                        effective_input = str(
                            action.get("value") or effective_input,
                        )
                input_token = current_user_input.set(effective_input)
                try:
                    # Thread the Stage 1 effective input to
                    # the thunk when (a) the caller supplied a
                    # ``user_input`` (so there is something to forward)
                    # AND (b) the thunk's signature accepts a
                    # positional arg. Zero-arg thunks and thunks
                    # invoked without ``user_input=`` keep the
                    # historical call shape so customers using
                    # ``Shield.run(thunk)`` for pure Stage-5
                    # validation (no Stage 1 input) see no
                    # behavioural change — e.g. closures that
                    # capture loop variables via
                    # ``async def _thunk(v: Any = value)`` continue
                    # to receive their default rather than ``""``.
                    if user_input:
                        raw = await _call_thunk_with_optional_input(
                            execute, effective_input,
                        )
                    else:
                        result = execute()
                        raw = (
                            await result
                            if inspect.isawaitable(result)
                            else result
                        )
                finally:
                    current_user_input.reset(input_token)
                return await _stage5_pass(raw)
            finally:
                try:
                    sess.end_turn()
                except Exception:  # noqa: BLE001
                    pass
        finally:
            current_session.reset(token)

    async def protect_tool(
        self,
        name: str,
        params: Optional[dict],
        execute: Callable[..., Awaitable[Any]],
        *,
        session: Optional[Session] = None,
        tool_call_id: Optional[str] = None,
    ) -> tuple[bool, Any]:
        """Stages 2 + 3 + 4 around a single tool call. Mirrors the Node
        / Rust / .NET ``protect_tool`` (or ``ProtectToolAsync``) entry
        points.

        Returns ``(blocked, output)`` — ``blocked`` is True when the
        tool was denied or its result blocked, in which case ``output``
        is the canonical block message (always a string); otherwise
        ``output`` is the **raw** value the ``execute`` callable
        returned.

        Raw-result preservation:
            The pre-fix implementation stringified the success-path
            result via ``str(value)`` so a tool returning
            ``{"score": 0.91, ...}`` produced a Python-repr string the
            customer had to ``ast.literal_eval`` to recover. The plural
            :meth:`protect_tools` already passes raw shapes through
            ``_ToolWrapper.invoke``; the singular path now matches that
            contract. Pydantic
            ``BaseModel`` returns are normalised via
            ``model_dump(mode='json')`` (v2) or ``dict()`` (v1) so the
            same shape Stage 4 extractors see is also what flows back
            to the caller. Other types (``dict`` / ``list`` /
            primitives / arbitrary classes) pass through unchanged.

        Session resolution:

        * ``session=<Session>`` (explicit) — bind this call to the
          customer-owned session. Per-session variables, event
          latches, and populator state persist across multiple
          ``protect_tool`` calls that share the same instance. Each
          call opens its own turn (begin_turn / end_turn) UNLESS the
          bound session is also the current ambient session (in
          which case the outer turn is reused, mirroring Pattern A).
          Takes precedence over the ambient :data:`current_session`;
          a debug log is emitted when the explicit and ambient
          sessions differ.
        * Ambient ``current_session`` set — reuse the outer turn (the
          canonical Pattern A happy path inside ``shield.guard(...)``).
        * Otherwise — allocate a fresh per-call session (legacy
          ad-hoc shape; per_turn / per_session state will NOT carry
          across calls).

        Pass *tool_call_id* (the upstream model's tool-call handle, e.g.
        OpenAI ``tool_call.id`` or Anthropic ``tool_use.id``) so
        Stage 4 binding can find the same canonical invocation
        admitted at Stage 3 under concurrent same-name calls. When
        omitted, a stable per-call id is minted automatically so this
        path never collides with another same-name call.
        """
        if not callable(execute):
            raise TypeError(
                "Shield.protect_tool(name, params, execute): execute must be callable",
            )
        ambient = current_session.get(None)
        own_turn = False
        token = None
        # When the customer threads an explicit ``session=`` we
        # may be one of N concurrent ``protect_tool`` calls bound to
        # the SAME session. The Rust admission registry is per-session,
        # so overlapping ``begin_turn → validate_tool_call →
        # validate_tool_output → end_turn`` sequences race: a later
        # ``begin_turn`` invalidates an earlier admission and Stage 4
        # reports ``binding missing (unknown_admission N)``. The
        # per-session :class:`asyncio.Lock` serialises the critical
        # section so all calls succeed; non-contended single-session
        # use and concurrent calls on DIFFERENT sessions are
        # unaffected (each session has its own lock). The lock is
        # acquired BEFORE ``begin_turn`` and released AFTER
        # ``end_turn`` so the entire admission lifecycle is covered.
        share_lock = session is not None and ambient is not session
        session_lock = self._get_session_lock(session) if share_lock else None
        if session_lock is not None:
            await session_lock.acquire()
        try:
            if session is not None:
                # Explicit customer-owned session wins.
                if ambient is not None and ambient is not session:
                    logger.debug(
                        "Tool '%s': explicit session= overrides ambient "
                        "current_session (different Session instance).",
                        name,
                    )
                sess = session
                if ambient is not session:
                    # Bound session is NOT the ambient one (or no ambient
                    # exists) — we own a turn around this call so per_turn
                    # variables are scoped per-invocation and the
                    # ContextVar is pinned so any nested call sees the
                    # bound session as ambient.
                    sess.begin_turn()
                    own_turn = True
                    token = current_session.set(sess)
                # else: explicit session matches ambient → reuse outer turn.
            elif ambient is not None:
                sess = ambient
            else:
                sess = self.runtime.new_session()
                sess.begin_turn()
                own_turn = True
                token = current_session.set(sess)
            # Always pass a tool_call_id so parallel same-name
            # calls bind correctly; honor the customer's id if supplied.
            bound_id = tool_call_id if tool_call_id is not None else uuid.uuid4().hex

            # Stage 4 already sees the raw Python value (the
            # populator binds ``@result`` against the unmarshalled
            # object), so the only legacy stringification was in the
            # ``(blocked, output)`` return tuple. Pydantic models are
            # normalised to dicts here so both the Stage 4 binding shape
            # and the caller-visible return shape match the plural
            # ``protect_tools`` path established in ``a2222c5``.
            async def _execute_normalised(eff_params: dict) -> Any:
                raw = await execute(eff_params)
                base_model = _try_import_pydantic_basemodel()
                if base_model is not None and isinstance(raw, base_model):
                    try:
                        return _pydantic_dump(raw)
                    except Exception:  # noqa: BLE001
                        logger.debug(
                            "protect_tool: Pydantic model.dump failed for "
                            "tool '%s'; passing model through unchanged",
                            name,
                            exc_info=True,
                        )
                        return raw
                return raw

            try:
                # Shadow / Monitor (#14): execute the tool unconditionally
                # but still run Stage 3 / Stage 4 for observability AND
                # record success / failure so populator extractors and
                # `tool.<name>.success` / `failure` events fire identically
                # to active.
                if self._mode is ShieldMode.MONITOR:
                    eff_params = dict(params or {})
                    sess.validate_tool_call(name, eff_params, tool_call_id=bound_id)
                    try:
                        raw = await _execute_normalised(params or {})
                    except Exception as exc:  # noqa: BLE001
                        err_text = f"[tool error] {name}: {exc}"
                        sess.validate_tool_output(name, err_text, tool_call_id=bound_id)
                        try:
                            sess.record_tool_failure(name, str(exc))
                        except Exception:  # noqa: BLE001
                            logger.debug("monitor record_tool_failure raised", exc_info=True)
                        return (False, err_text)
                    sess.validate_tool_output(name, raw, tool_call_id=bound_id)
                    try:
                        sess.record_tool_success(name, raw)
                    except Exception:  # noqa: BLE001
                        logger.debug("monitor record_tool_success raised", exc_info=True)
                    # Return the raw value (dict / list /
                    # primitive). Block-path messages are still strings;
                    # callers branch on ``blocked`` to distinguish.
                    return (False, raw)
                return await guarded_tool(
                    name,
                    params or {},
                    _execute_normalised,
                    session=sess,
                    tool_call_id=bound_id,
                    preserve_raw_result=True,
                    pending_resolution_sink=self._latch_pending_resolution,
                )
            finally:
                if own_turn:
                    try:
                        sess.end_turn()
                    except Exception:  # noqa: BLE001
                        pass
                if token is not None:
                    current_session.reset(token)
        finally:
            if session_lock is not None:
                session_lock.release()

    def create_session(
        self,
        *,
        session_id: Optional[str] = None,
        correlation_id: Optional[str] = None,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        extensions: Optional[Dict[str, Any]] = None,
        request_context: Optional[Dict[str, Any]] = None,
    ) -> Session:
        """Allocate a new :class:`~agent_shield.Session` bound to this
        shield's runtime.

        Convenience facade over :meth:`Runtime.new_session` so customer
        code that drives the agent loop themselves can mint a session
        without reaching through ``shield.runtime``. The session is
        customer-owned — pass it as ``session=`` to
        :meth:`protect_tools` / :meth:`protect_tool` /
        :meth:`run_with_session` to thread state across calls, and
        close it (or use the :meth:`session` context manager) when
        the conversation completes.

        See :meth:`Runtime.new_session` for the metadata kwargs.
        """
        return self.runtime.new_session(
            session_id=session_id,
            correlation_id=correlation_id,
            user_id=user_id,
            tenant_id=tenant_id,
            extensions=extensions,
            request_context=request_context,
        )

    def session(
        self,
        *,
        session_id: Optional[str] = None,
        correlation_id: Optional[str] = None,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        extensions: Optional[Dict[str, Any]] = None,
        request_context: Optional[Dict[str, Any]] = None,
    ) -> Session:
        """Return a customer-owned :class:`Session` as a context manager.

        Sugar for the common scope::

            with shield.session(session_id="thread-42") as sess:
                protected_classify = shield.protect_tools(
                    [classify_tool], session=sess
                )[0]
                ...

        The returned :class:`~agent_shield.Session` already supports
        ``__enter__`` / ``__exit__`` (closing the native handle on
        scope exit); this method is a one-line alias so the intent is
        legible at the call site.
        """
        return self.create_session(
            session_id=session_id,
            correlation_id=correlation_id,
            user_id=user_id,
            tenant_id=tenant_id,
            extensions=extensions,
            request_context=request_context,
        )

    async def run_with_session(
        self,
        session: Session,
        execute: Callable[[], Awaitable[Any]],
        *,
        user_input: str = "",
        on_block: Optional[OnBlockPolicy] = None,
    ) -> Any:
        """Stage 1 + Stage 5 around a thunk, bound to a customer-owned
        :class:`Session`.

        Equivalent to :meth:`run` but pins the session explicitly so
        the customer can run a Stage-5-only redaction pass over a
        final assistant message AFTER a sequence of
        :meth:`protect_tools` / :meth:`protect_tool` calls that shared
        the same session. Per-session variables populated by those
        prior tool calls remain visible to Stage 1 / Stage 5
        guard-policy expressions.

        Accepts the same ``on_block`` per-call override as
        :meth:`run`; default is ``"raise"``.
        """
        if session is None:
            raise TypeError(
                "Shield.run_with_session(session, execute): session must not be None",
            )
        return await self.run(
            execute,
            user_input=user_input,
            session=session,
            on_block=on_block,
        )


    def with_fresh_session(self) -> "Shield":
        """Return a NEW :class:`Shield` with the same runtime + bundle
        but no carried-over runner state.

        The new Shield shares the underlying :class:`Runtime` reference
        (so policies, observability providers, and human resolvers are
        still wired up) but starts with an empty
        :attr:`_guarded_runners` set. The original Shield — and the
        runners spawned from it — is not mutated.

        This is the canonical post-build-immutable way to "start a new
        conversation context" for an existing Shield without
        rebuilding the policy graph. Mirrors the Rust
        ``Shield::with_fresh_session``, the .NET
        ``Shield.WithFreshSession``, and the Node
        ``shield.withFreshSession`` APIs.
        """
        return Shield(
            self.runtime,
            bundle=self._bundle,
            client=self._client,
            streaming_config=self._streaming_config,
            mode=self._mode,
            on_block=self._on_block,
        )


# ---------------------------------------------------------------------------
# Tool wrapping (delegates to ToolWrapper for shape translation only)
# ---------------------------------------------------------------------------


def _protect_tools_via_wrapper(
    runtime: Runtime,
    tools: list,
    wrapper: ToolWrapper,
    user_input_getter: Optional[Callable[[], str]] = None,
    *,
    mode: ShieldMode = ShieldMode.ENFORCE,
    allow_unguarded: bool = False,
    session: Optional[Session] = None,
    pending_resolution_sink: Optional[Callable[[dict], None]] = None,
    raise_on_block: bool = False,
    preserve_raw_result: bool = False,
) -> list:
    """Build a list of guarded tools using ``wrapper`` for shape ops.

    The orchestrator owns Stage 2/3/4 + record_tool_*; the wrapper
    translates between the framework's tool object and the
    ``(params: dict, user_input: str) -> output_text`` shape, and owns
    invocation of the original framework tool via :meth:`ToolWrapper.invoke`.

    *allow_unguarded* — see :meth:`Shield.protect_tools`. When
    ``False`` (default), wrapped tools invoked outside a guarded
    session raise
    :class:`~agent_shield.adapters.UnguardedToolInvocation`.

    *session* — when supplied, every invocation of every
    wrapped tool runs against this customer-owned session. Takes
    precedence over the ambient :data:`current_session` and over
    ``allow_unguarded``. Each call opens its own turn (begin_turn /
    end_turn) on the bound session so per_turn variables remain
    per-call but per_session variables, event latches, and populator
    state persist across calls. Designed for frameworks that drive
    the agent loop themselves (LangGraph nodes, customer-owned
    AutoGen pipelines, etc.) where Pattern A's ``shield.guard``
    wrapper isn't a natural fit.

    *pending_resolution_sink* — optional callback that receives the
    verdict's ``pending_resolution`` dict on any Stage 2/3 block that
    carries one (e.g. a ``kind: human`` resolver suspending). Forwarded
    verbatim to :func:`guarded_tool`.

    *raise_on_block* — when ``True``, a Stage 2/3/4 block raises
    :class:`~agent_shield.adapters._orchestration.AgentShieldBlocked`
    instead of letting the wrapped tool return the block message as a
    normal observation string. Adapters bound to frameworks whose
    tool-error channel halts the agent loop (LangChain ``ToolException``,
    CrewAI ``ToolUsage._use``, AutoGen ``FunctionExecutionResult(is_error=True)``,
    OpenAI Agents ``Runner`` error handling) set
    ``tool_wrapper_raise_on_block=True`` on the bundle so blocks
    surface as structural failures rather than text the LLM can
    treat as an ordinary observation and respond to with affirmative
    narrative.

    *preserve_raw_result* — when ``True``, the success-path
    return is the raw Stage-4 output (``dict`` / ``list`` /
    ``BaseModel``-dumped object / scalar) rather than the stringified
    canonical form. Adapters set
    ``tool_wrapper_preserve_raw_result=True`` on the bundle for
    framework tool-call boundaries that return to a customer Python
    pipeline (e.g. CrewAI's ``BaseTool._run``), where a structured
    return is what downstream consumers expect. Forwarded verbatim
    to :func:`guarded_tool`.
    """
    out: list = []
    for tool in tools:
        meta = wrapper.extract(tool)

        async def _invoke(
            params: dict,
            user_input: str,
            _orig: Any = tool,
            _meta: ToolMetadata = meta,
            _wrapper: ToolWrapper = wrapper,
            _runtime: Runtime = runtime,
            _input_getter: Optional[Callable[[], str]] = user_input_getter,
            _mode: ShieldMode = mode,
            _allow_unguarded: bool = allow_unguarded,
            _bound_session: Optional[Session] = session,
            _pending_sink: Optional[Callable[[dict], None]] = pending_resolution_sink,
            _raise_on_block: bool = raise_on_block,
            _preserve_raw: bool = preserve_raw_result,
        ) -> Any:
            async def _execute(effective_params: dict) -> Any:
                return await _wrapper.invoke(_orig, effective_params)

            text_input = (
                _input_getter() if _input_getter else user_input
            )
            # Bound session path. When the customer supplied
            # an explicit ``session=`` to ``protect_tools``, route
            # every call through that session: bypass ambient lookup
            # and ``allow_unguarded`` entirely. The session is
            # customer-owned (created via ``shield.create_session``
            # or ``runtime.new_session``); we begin/end a turn around
            # each call so per_turn variables are still scoped but
            # per_session state persists across calls.
            if _bound_session is not None:
                ambient = current_session.get(None)
                if ambient is not None and ambient is not _bound_session:
                    logger.debug(
                        "Tool '%s': explicit session= overrides ambient "
                        "current_session (different Session instance).",
                        _meta.name,
                    )
                sess = _bound_session
                sess.begin_turn()
                sess_token = current_session.set(sess)
                try:
                    if _mode is ShieldMode.MONITOR:
                        eff_params = dict(params or {})
                        _mon_call_id = uuid.uuid4().hex
                        sess.validate_tool_call(
                            _meta.name, eff_params, tool_call_id=_mon_call_id,
                        )
                        try:
                            raw = await _execute(params)
                        except Exception as exc:  # noqa: BLE001
                            err_text = f"[tool error] {_meta.name}: {exc}"
                            sess.validate_tool_output(
                                _meta.name, err_text, tool_call_id=_mon_call_id,
                            )
                            try:
                                sess.record_tool_failure(_meta.name, str(exc))
                            except Exception:  # noqa: BLE001
                                logger.debug(
                                    "monitor record_tool_failure raised",
                                    exc_info=True,
                                )
                            return err_text
                        sess.validate_tool_output(
                            _meta.name, raw, tool_call_id=_mon_call_id,
                        )
                        try:
                            sess.record_tool_success(_meta.name, raw)
                        except Exception:  # noqa: BLE001
                            logger.debug(
                                "monitor record_tool_success raised",
                                exc_info=True,
                            )
                        return str(raw) if not isinstance(raw, str) else raw

                    _call_id = uuid.uuid4().hex
                    _blocked, output = await guarded_tool(
                        _meta.name,
                        params,
                        execute=_execute,
                        user_input=text_input,
                        session=sess,
                        tool_call_id=_call_id,
                        pending_resolution_sink=_pending_sink,
                        preserve_raw_result=_preserve_raw,
                    )
                    if _blocked and _raise_on_block:
                        raise AgentShieldBlocked(
                            _meta.name,
                            output if isinstance(output, str) else str(output),
                        )
                    return output
                finally:
                    try:
                        sess.end_turn()
                    except Exception:  # noqa: BLE001
                        logger.debug(
                            "end_turn() on bound session raised; ignoring",
                            exc_info=True,
                        )
                    current_session.reset(sess_token)

            if _mode is ShieldMode.MONITOR:
                # Shadow / Monitor (#14): run Stage 3 / Stage 4 for
                # observability, never block, never mutate `params`.
                # Mirror active's session-resolution: pick up ambient,
                # else open a fresh session + own a turn around it so
                # the validation has a session to log against.
                ambient = current_session.get(None)
                own_turn = False
                if ambient is not None:
                    sess = ambient
                    sess_token = None
                else:
                    sess = _runtime.new_session()
                    sess.begin_turn()
                    own_turn = True
                    sess_token = current_session.set(sess)
                try:
                    eff_params = dict(params or {})
                    # Mint a per-call id so concurrent same-name
                    # MONITOR calls bind correctly through Stage 3 →
                    # Stage 4 instead of poisoning the no-id slot.
                    _mon_call_id = uuid.uuid4().hex
                    sess.validate_tool_call(_meta.name, eff_params, tool_call_id=_mon_call_id)
                    try:
                        raw = await _execute(params)
                    except Exception as exc:  # noqa: BLE001
                        err_text = f"[tool error] {_meta.name}: {exc}"
                        sess.validate_tool_output(_meta.name, err_text, tool_call_id=_mon_call_id)
                        try:
                            sess.record_tool_failure(_meta.name, str(exc))
                        except Exception:  # noqa: BLE001
                            logger.debug(
                                "monitor record_tool_failure raised",
                                exc_info=True,
                            )
                        return err_text
                    sess.validate_tool_output(_meta.name, raw, tool_call_id=_mon_call_id)
                    try:
                        sess.record_tool_success(_meta.name, raw)
                    except Exception:  # noqa: BLE001
                        logger.debug(
                            "monitor record_tool_success raised",
                            exc_info=True,
                        )
                    return str(raw) if not isinstance(raw, str) else raw
                finally:
                    if own_turn:
                        try:
                            sess.end_turn()
                        except Exception:  # noqa: BLE001
                            pass
                        if sess_token is not None:
                            current_session.reset(sess_token)

            # Binding invariant: Python framework adapters don't see the
            # upstream model's tool_call.id at the framework-owned tool
            # boundary (the framework calls the wrapper as `tool.run`
            # with no id). Mint a stable per-call UUIDv4 so concurrent
            # same-name calls each carry a unique binding handle and
            # cannot poison each other's Stage 3/Stage 4 binding slot.
            _call_id = uuid.uuid4().hex
            # Capture pending_resolution as we sink it, so we can
            # attach it to ``AgentShieldBlocked`` if the verdict comes
            # back as a block. Wrap the user-supplied sink so we
            # observe what guarded_tool dispatches without changing
            # the existing surface.
            _captured_pr: dict[str, Any] = {}

            def _sink_with_capture(pr: dict) -> None:
                _captured_pr["pr"] = pr
                if _pending_sink is not None:
                    _pending_sink(pr)

            _blocked, output = await guarded_tool(
                _meta.name,
                params,
                execute=_execute,
                user_input=text_input,
                runtime=_runtime,
                tool_call_id=_call_id,
                allow_unguarded=_allow_unguarded,
                pending_resolution_sink=_sink_with_capture,
                preserve_raw_result=_preserve_raw,
            )
            if _blocked and _raise_on_block:
                # Surface the block as a typed exception
                # the host framework treats as a structural tool
                # failure (LangChain ToolException, AutoGen
                # FunctionExecutionResult(is_error=True), OpenAI
                # Agents Runner error path, Anthropic
                # tool_result(is_error=True), CrewAI ToolUsage._use
                # error counter), so the agent loop CANNOT feed the
                # block message back to the LLM as a normal
                # observation. ``output`` here is always the
                # canonical ``[GUARDRAIL BLOCK]...`` string from
                # ``dispatch_*_verdict``.
                raise AgentShieldBlocked(
                    _meta.name,
                    output if isinstance(output, str) else str(output),
                    pending_resolution=_captured_pr.get("pr"),
                )
            return output

        guarded = wrapper.wrap(tool, meta, _invoke)
        out.append(guarded)

    logger.info(
        "Protected %d tools: %s",
        len(out), [getattr(t, "name", "?") for t in out],
    )
    return out


# ---------------------------------------------------------------------------
# Generic builder
# ---------------------------------------------------------------------------


class _ConfigurationResolverHolder:
    """Mutable indirection between an LLM-caller closure and the runtime.

    Adapter LLM-caller factories build their caller closure in
    :meth:`ShieldBuilder._bind_caller`, which fires the moment a client
    is wired — typically *before* :meth:`ShieldBuilder.build` produces
    the runtime. The closure therefore can't capture
    ``Runtime.llm_configuration`` directly. This holder is registered
    with the factory at make-caller time and populated in
    :meth:`ShieldBuilder.build` once the runtime exists, so calls to
    ``configuration_resolver(configuration_id)`` start returning the
    real ``configurations[]`` entry as soon as the first stage runs.
    """

    def __init__(self) -> None:
        self._lookup: Optional[Callable[[str], Optional[Dict[str, Any]]]] = None

    def bind(self, runtime: Runtime) -> None:
        self._lookup = runtime.llm_configuration

    def __call__(
        self, configuration_id: Optional[str],
    ) -> Optional[Dict[str, Any]]:
        if self._lookup is None or not configuration_id:
            return None
        try:
            return self._lookup(configuration_id)
        except Exception:
            logger.exception(
                "configuration resolver: lookup failed for configuration_id=%r",
                configuration_id,
            )
            return None


class ShieldBuilder:
    """Framework-agnostic builder for :class:`Shield`.

    Construct via ``Shield.from_yaml(path)``. When exactly one adapter
    module is imported (e.g. ``import agent_shield.adapters.langchain``)
    the bundle is auto-bound and the three-line drop-in works without
    any explicit ``.with_<framework>()`` call. When two or more
    adapters are imported, auto-bind is ambiguous and the constructor
    raises :class:`~agent_shield.AmbientBundleAmbiguityError` — fail-fast
    on the spot rather than silently depending on import order.

    Recover from ambiguity by passing ``auto_bind=False`` (skips the
    ambient lookup) and then calling ``.with_<framework>()`` explicitly
    to pin a specific bundle. Clients passed via ``with_client()``
    before the bundle is set are buffered and (re)bound when the bundle
    becomes available.
    """

    def __init__(
        self,
        path: str = "",
        *,
        auto_bind: bool = True,
    ) -> None:
        # When `auto_bind` is True (the default) we look up the
        # ambient bundle so the three-line drop-in works. When two or
        # more adapters are imported, `active_bundle()` raises
        # `AmbientBundleAmbiguityError` and we let it propagate
        # immediately — silently picking one would silently depend on
        # import order and break fail-closed defaults.
        if auto_bind:
            from . import _bundle_registry

            self._bundle: Optional[FrameworkBundle] = (
                _bundle_registry.active_bundle()
            )
        else:
            self._bundle = None
        self._path = path
        self._yaml_chain: Optional[List[str]] = None
        self._client: Any = None
        # Single LLM caller built from `with_client(client)` + the framework
        # bundle's `make_caller`. Per-stage dispatch is YAML-driven via
        # `configurations: <id>` references; the host's caller receives the
        # `configuration_id` and decides what to do (typically: ignore it
        # and use the same client for every stage). Customers needing
        # different clients per configuration drop down to
        # `RuntimeBuilder.register_llm_caller(my_dispatcher)` directly.
        self._llm_caller: Optional[Callable[[Optional[str], str], str]] = None
        # Mutable holder so the LLM-caller closure (built BEFORE the
        # runtime exists) can look up `configurations[]` entries AFTER
        # `build()` populates it via ``Runtime.llm_configuration``.
        # Without this, adapter factories would have no way to honour
        # YAML-declared per-stage `model:` selections.
        self._configuration_resolver: _ConfigurationResolverHolder = (
            _ConfigurationResolverHolder()
        )
        self._observability_providers: List[Any] = []
        self._streaming_config: Optional[dict] = None
        self._extra_register: List[Callable[[RuntimeBuilder], None]] = []
        self._mode: ShieldMode = ShieldMode.ENFORCE
        self._on_block: OnBlockPolicy = "return_blocked"
        self._consumed: bool = False

    # ── Consume-on-build guard ────────────────────────────────────

    def _check_consumed(self) -> None:
        if self._consumed:
            raise RuntimeError(
                "ShieldBuilder.build() can only be called once. "
                "Call Shield.from_yaml(...) again to create a new builder.",
            )

    # ── Bundle binding (composition pattern) ───────────────────────

    def _bind_to_bundle(self, bundle: FrameworkBundle) -> "ShieldBuilder":
        """Attach a framework bundle and (re)bind the client if set.

        Called by the adapter-installed ``with_<framework>()`` methods.
        Idempotent — calling twice with the same bundle is a no-op.
        """
        self._check_consumed()
        self._bundle = bundle
        self._bind_caller()
        return self

    def _bind_caller(self) -> None:
        if self._bundle is None or self._client is None:
            return
        # Forward the YAML configuration resolver to the factory so the
        # adapter's caller closure can honour per-stage `model:` /
        # `max_tokens:` selections. Older third-party factories that
        # don't accept the kwarg gracefully fall back to the legacy
        # client-only signature.
        try:
            self._llm_caller = self._bundle.llm_caller_factory.make_caller(
                self._client,
                configuration_resolver=self._configuration_resolver,
            )
        except TypeError:
            self._llm_caller = self._bundle.llm_caller_factory.make_caller(
                self._client,
            )

    # ── LLM client wiring ──────────────────────────────────────────

    def with_client(self, client: Any) -> "ShieldBuilder":
        """Set the LLM client used by every validation stage's
        ``evaluate_when[].llm`` invocation. The host's caller receives the
        YAML-declared ``configuration_id`` as its first argument; per-stage
        variation is driven entirely from YAML
        (``configurations: - {id, type: llm, provider, model, api_key_env}``)
        and the per-stage ``configuration:`` references in
        ``input_validation`` / ``state_validation`` /
        ``tool_execution_validation`` / ``post_tool_validation`` /
        ``output_validation``.

        If no bundle has been attached yet (composition pattern), the client
        is buffered and bound when ``with_<framework>()`` is called.
        """
        self._check_consumed()
        self._client = client
        self._bind_caller()
        return self

    # ── Streaming / observability / extension hooks ───────────────

    def with_streaming(self, **kwargs: Any) -> "ShieldBuilder":
        self._check_consumed()
        self._streaming_config = kwargs
        return self

    def with_observability(
        self, provider: Any,
    ) -> "ShieldBuilder":
        """Register a single observability provider. Chain to register more."""
        self._check_consumed()
        self._observability_providers.append(provider)
        return self

    def with_extension(
        self, hook: Callable[[RuntimeBuilder], None],
    ) -> "ShieldBuilder":
        self._check_consumed()
        self._extra_register.append(hook)
        return self

    # ── Host-callback registration ────────────────────────────────
    # These mirror Rust+.NET ShieldBuilder.with_* hooks. They register
    # host implementations for resolver/extractor/observability kinds
    # declared in YAML. Each delegates to the underlying RuntimeBuilder
    # at build() time via the _extra_register hook chain.

    def with_agent_resolver(
        self, resolver: Any,
    ) -> "ShieldBuilder":
        """Register a host implementation for ``kind: agent`` resolvers
        declared in YAML. ``resolver`` is the same shape accepted by
        :meth:`Runtime.register_agent_resolver` — typically an object
        with ``resolve(request) -> ResolverResponse``, or a plain
        callable with that signature.

        Mirrors ``Shield::with_agent_resolver`` in Rust and
        ``ShieldBuilder.WithAgentResolver`` in .NET.
        """
        self._check_consumed()
        self._extra_register.append(
            lambda rb: rb.register_agent_resolver(resolver),
        )
        return self

    def with_classifier_caller(
        self,
        callback: Any,
    ) -> "ShieldBuilder":
        """Register a host implementation for ``classifier`` guard
        policies declared in YAML (spec +).

        ``callback`` may have either signature:

        * 2-arg (legacy): ``(configuration_id, subject) -> Verdict``
        * 3-arg (new): ``(configuration_id, subject, configuration: dict) -> Verdict``

        The 3-arg form receives the resolved YAML ``configurations[]``
        entry (``endpoint``, ``headers``, ``provider_config``,
        ``threshold``, ``category_thresholds`` …) so the callback can
        drive Azure AI Content Safety, Bedrock Guardrails, or any
        HTTP classifier without re-parsing YAML or hard-coding
        endpoint / header values. ``Verdict`` is a
        :class:`~agent_shield.hooks.ClassifierVerdict` or a dict the
        canonical wire-shape parser accepts (``classification: "allow"``
        or ``"block"`` + optional ``score`` / ``categories`` /
        ``reason``).

        The arity is detected once via :func:`inspect.signature` and
        cached on the closure — no per-call inspection cost.

        Mirrors :meth:`with_agent_resolver`'s registration pattern.
        Prefer this over ``with_extension(lambda rb: rb.register_classifier_caller(fn))``
        when you just need to wire a single classifier.
        """
        self._check_consumed()
        self._extra_register.append(
            lambda rb: rb.register_classifier_caller(callback),
        )
        return self

    def with_aacs_caller(
        self,
        callback: Any,
    ) -> "ShieldBuilder":
        """Register an Azure AI Content Safety classifier callback.

        Convenience alias for :meth:`with_classifier_caller` named for
        the most common classifier integration. The 3-arg callback
        contract is recommended so the callback can read the YAML
        ``endpoint`` (e.g. ``https://<region>.api.cognitive.microsoft.com``),
        ``headers`` (typically ``Ocp-Apim-Subscription-Key``), ``threshold``,
        ``category_thresholds``, and ``provider_config`` directly from
        the merged YAML at call time::

            def aacs(configuration_id, subject, configuration):
                endpoint = configuration["endpoint"]
                headers  = configuration.get("headers", {})
                threshold = configuration.get("threshold", 4)
                # POST `<endpoint>/contentsafety/text:analyze?api-version=...`
                # with `headers` and parse the response.
                ...

            shield = (
                Shield.from_yaml("guardrails.yaml")
                .with_openai_agents().with_client(llm_client)
                .with_aacs_caller(aacs)
                .build()
            )

        Use :meth:`with_classifier_caller` directly for non-AACS
        classifiers (Bedrock Guardrails, custom HTTP services). Both
        methods route through the same registration; the name is
        purely a discoverability aid for hosts that grep for ``aacs``
        when wiring Azure AI Content Safety.
        """
        return self.with_classifier_caller(callback)

    # ── Behavioural policy ────────────────────────────────────────

    def with_mode(self, mode: Union[ShieldMode, str]) -> "ShieldBuilder":
        """Set ``"enforce"`` or ``"monitor"``."""
        self._check_consumed()
        if isinstance(mode, str):
            mode = ShieldMode(mode.lower())
        self._mode = mode
        return self

    def with_on_block(self, policy: OnBlockPolicy) -> "ShieldBuilder":
        """Set how blocks should be surfaced (see :data:`OnBlockPolicy`)."""
        self._check_consumed()
        self._on_block = policy
        return self

    # ── Framework adapter shortcuts (lazy-import fallback) ─────────
    #
    # The canonical ``with_<framework>()`` methods are installed by the
    # adapter module's ``_install()`` at import time. The defaults
    # below exist so customers who copy-paste the three-line drop-in
    #
    #     shield = Shield.from_yaml(".guardrails.yaml").with_langchain().build()
    #
    # don't have to also remember to add ``import
    # agent_shield.adapters.langchain``. The first call to
    # ``.with_langchain()`` imports the adapter (which monkey-patches
    # the *real* ``with_langchain`` onto the class and registers the
    # bundle), then this fallback dispatches to the freshly-installed
    # method. Subsequent calls hit the real method directly.
    #
    # The fallback only knows about adapters that ship with this
    # package; third-party adapters still register via their own
    # ``_install()`` at import time and don't need a stub here.

    def _lazy_install_adapter(
        self, module_suffix: str, method_name: str,
    ) -> "ShieldBuilder":
        import importlib

        cls = type(self)
        # Snapshot the current binding so we can detect whether the
        # adapter actually overwrote it. ``_install()`` in every shipped
        # adapter rebinds ``ShieldBuilder.<method_name>`` to its own
        # function; if that didn't happen we'd recurse forever, so
        # surface the bug explicitly.
        before = cls.__dict__.get(method_name)
        importlib.import_module(f"agent_shield.adapters.{module_suffix}")
        after = cls.__dict__.get(method_name)
        if after is None or after is before:
            raise RuntimeError(
                f"agent_shield.adapters.{module_suffix} did not install "
                f"ShieldBuilder.{method_name}. This is an internal "
                f"packaging bug; please file an issue.",
            )
        return after(self)

    def with_langchain(self) -> "ShieldBuilder":
        """Bind to the LangChain framework bundle.

        Auto-imports ``agent_shield.adapters.langchain`` on first call
        so the three-line drop-in works without an explicit side-effect
        import. Requires the ``[langchain]`` extra.
        """
        return self._lazy_install_adapter("langchain", "with_langchain")

    def with_openai_agents(self) -> "ShieldBuilder":
        """Bind to the OpenAI Agents SDK framework bundle.

        Auto-imports ``agent_shield.adapters.openai_agents`` on first
        call. Requires the ``[openai-agents]`` extra.
        """
        return self._lazy_install_adapter(
            "openai_agents", "with_openai_agents",
        )

    def with_anthropic_agents(self) -> "ShieldBuilder":
        """Bind to the Anthropic Agents SDK framework bundle.

        Auto-imports ``agent_shield.adapters.anthropic_agents`` on
        first call. Requires the ``[anthropic-agents]`` extra.
        """
        return self._lazy_install_adapter(
            "anthropic_agents", "with_anthropic_agents",
        )

    # ``.with_anthropic()`` is the name customers reach for
    # by analogy with ``.with_langchain()`` / ``.with_openai_agents()``
    # (and matches the error message in :meth:`capabilities`). The
    # canonical method is :meth:`with_anthropic_agents` (named after
    # the upstream `anthropic.agents` SDK module); this alias
    # delegates to it so both spellings work. The lazy-import
    # stub pattern is preserved — calling ``.with_anthropic()``
    # triggers the same adapter import the canonical method does.
    def with_anthropic(self) -> "ShieldBuilder":
        """Alias for :meth:`with_anthropic_agents`.

        The canonical method name is ``with_anthropic_agents``
        (matching the Python ``anthropic.agents`` SDK module). This
        alias exists because customers — and the builder's own
        error message in :attr:`capabilities` — naturally reach for
        the shorter ``.with_anthropic()``. Both spellings install
        the same Anthropic Agents adapter.
        """
        return self.with_anthropic_agents()

    def with_autogen(self) -> "ShieldBuilder":
        """Bind to the AutoGen framework bundle.

        Auto-imports ``agent_shield.adapters.autogen`` on first call.
        Requires the ``[autogen]`` extra.
        """
        return self._lazy_install_adapter("autogen", "with_autogen")

    def with_crewai(self) -> "ShieldBuilder":
        """Bind to the CrewAI framework bundle.

        Auto-imports ``agent_shield.adapters.crewai`` on first call.
        Requires the ``[crewai]`` extra.
        """
        return self._lazy_install_adapter("crewai", "with_crewai")

    def with_semantic_kernel(self) -> "ShieldBuilder":
        """Bind to the Semantic Kernel framework bundle.

        Auto-imports ``agent_shield.adapters.semantic_kernel`` on
        first call. Requires the ``[semantic-kernel]`` extra.
        """
        return self._lazy_install_adapter(
            "semantic_kernel", "with_semantic_kernel",
        )

    def with_perf_telemetry(
        self,
        mode: "Union[PerfTelemetry, str]",
    ) -> "ShieldBuilder":
        """Opt into the v8 perf-logging instrumentation (PR5/PR6).

        Delegates to :meth:`RuntimeBuilder.with_perf_telemetry` when
        the underlying runtime is built. See that method's docstring
        for the gating table; default is :attr:`PerfTelemetry.OFF`
        — zero perf events emit.
        """
        self._check_consumed()
        # Capture the value (not the enum object) so the closure stays
        # picklable / repr-stable regardless of how callers pass the
        # mode in (enum vs string).
        if isinstance(mode, PerfTelemetry):
            wire = mode.value
        else:
            wire = str(mode).lower()
        self._extra_register.append(
            lambda rb: rb.with_perf_telemetry(wire),
        )
        return self

    # ── Build ─────────────────────────────────────────────────────

    def build(self) -> Shield:
        self._check_consumed()
        # A null bundle is allowed: framework-agnostic operations
        # (`Shield.run`, `Shield.protect_tool`, `Shield.before_invoke`)
        # don't need a bundle. Methods that DO need one (`Shield.guard`,
        # `Shield.protect_tools`, `Shield.capabilities`) fail with a
        # clear message at call time. Mirrors the Node SDK's behaviour.
        if self._yaml_chain is not None:
            builder = _load_runtime_builder(path=None, chain=self._yaml_chain)
        else:
            builder = _load_runtime_builder(path=self._path, chain=None)

        if self._llm_caller is not None:
            builder.register_llm_caller(self._llm_caller)
        for provider in self._observability_providers:
            builder.register_observability_provider(provider)
        for hook in self._extra_register:
            hook(builder)

        rt = builder.build()
        # Now that the runtime exists, fill in the LLM configuration
        # resolver so caller closures resolve `configurations[]` entries
        # at call time. Must happen BEFORE the first stage runs.
        self._configuration_resolver.bind(rt)
        shield = Shield(
            rt,
            bundle=self._bundle,
            client=self._client,
            streaming_config=self._streaming_config,
            mode=self._mode,
            on_block=self._on_block,
        )
        self._consumed = True
        return shield


__all__ = [
    "AgentShieldBlocked",
    "GuardedRunner",
    "OnBlockPolicy",
    "Shield",
    "ShieldBuilder",
    "ShieldMode",
]
