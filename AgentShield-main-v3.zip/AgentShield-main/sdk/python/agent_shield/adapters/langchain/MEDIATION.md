# Python LangChain adapter mediation

## Mediated paths
- `ShieldBuilder.with_langchain()` installs the bundle; `Shield.guard(agent)` / `GuardedAgent.ainvoke()` route Stage 1 and Stage 5 through `sdk/python/agent_shield/adapters/langchain.py:237` and `sdk/python/agent_shield/adapters/langchain.py:412`.
- `Shield.protect_tools()` wraps `StructuredTool` instances at `sdk/python/agent_shield/adapters/langchain.py:207`.
- Streaming runs through the buffered adapter at `sdk/python/agent_shield/adapters/langchain.py:323`.

## Unsupported paths
- Calling the original tool's `.func`, `.coroutine`, or `.ainvoke()` directly.
- Running the raw LangChain/LangGraph agent without `shield.guard(...)`.
- Custom callback or transport paths the adapter never sees.

## Bypass risks
- Keeping both raw and wrapped tools registered in the same agent.
- Replacing a wrapped tool with the original object after agent construction.
- Treating raw model-client calls as covered just because the tool list was wrapped.

## Streaming behavior
- Rule 1 — ✓ extracts complete message-text units before validation.
- Rule 2 — ✓ default adapter buffers chunks and releases only validated text, so the unvalidated window is effectively zero.
- Rule 3 — ✓ by construction in the default buffered mode; a deny happens before any validated text is released, so there is no partial stream to abort.
- Rule 4 — ✓ the shared `StreamingGuard` now emits `incident.stream_limit_exceeded` when the stream hits the core buffer bound.
- Rule 5 — ✓ Stage-4 tool outputs are still non-streaming and remain bound through the normal `tool_call_id` path.

## Unknown tool-call shapes
- The wrapper is fail-closed only for the LangChain tool surfaces it knows (`StructuredTool` kwargs / `.ainvoke`). Unknown result-message shapes are ignored by `_extract_message_text`, so they do not currently emit `incident.unknown_invocation_shape`.

## See also

See [Post-tool limits and dangerous patterns](../../../../../docs/POST_TOOL_LIMITS.md) and the [adapter-mediated path matrix](../../../../../docs/adapter-mediated-paths.md).
