# Python OpenAI Agents adapter mediation

## Mediated paths
- `ShieldBuilder.with_openai_agents()` installs the bundle; `Shield.guard(agent)` / `GuardedAgent.run()` route Stage 1 and Stage 5 through `sdk/python/agent_shield/adapters/openai_agents.py:223`.
- Direct `GuardedAgent(runtime, agent)` construction preserves the bundle defaults at `sdk/python/agent_shield/adapters/openai_agents.py:321`.
- `Shield.protect_tools()` re-wraps `FunctionTool.on_invoke_tool` at `sdk/python/agent_shield/adapters/openai_agents.py:195`.
- Native guardrail objects come from `as_input_guardrail()` / `as_output_guardrail()` at `sdk/python/agent_shield/adapters/openai_agents.py:410`.
- Streaming runs through `Runner.run_streamed(...).stream_events()` at `sdk/python/agent_shield/adapters/openai_agents.py:260`.

## Unsupported paths
- Calling the original `FunctionTool.on_invoke_tool` directly.
- Running `Runner.run(...)` / `Runner.run_streamed(...)` on an unguarded agent.
- Direct OpenAI SDK or Responses API calls outside the adapter-owned agent loop.

## Bypass risks
- Supplying raw tools via `agent_config.tools` after wrapping a guarded set.
- Replacing the wrapped tool object with the original tool mid-session.
- Treating streamed tool-call deltas as guarded before the assembled call reaches Stage 2/3/4.

## Streaming behavior
- Rule 1 — ✓ validates text deltas as whole event payloads.
- Rule 2 — ✓ enforced by the core streaming guard's finite per-chunk/windowed buffering.
- Rule 3 — ✓ `incident.stream_aborted` is emitted by the core dispatcher when `agent_shield.streaming.StreamingGuard.push()` / `finish()` observe `action == "stop"` (implemented in PR #107).
- Rule 4 — ✓ `incident.stream_limit_exceeded` is emitted by the core dispatcher when the shared `StreamingGuard` hits the core buffer bound.
- Rule 5 — ✗ streamed Stage-4 tool-result chunks are not surfaced as invocation-bound units; tool calls stay non-streaming until assembled.

## Unknown tool-call shapes
- Malformed JSON tool arguments are coerced to `{}` at `sdk/python/agent_shield/adapters/openai_agents.py:203`; that preserves mediation but is not the required fail-closed `incident.unknown_invocation_shape` behavior.

## See also

See [Post-tool limits and dangerous patterns](../../../../../docs/POST_TOOL_LIMITS.md) and the [adapter-mediated path matrix](../../../../../docs/adapter-mediated-paths.md).
