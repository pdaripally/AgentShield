"""Anthropic SDK integration for Agent Shield guardrails.

Capability-based adapter that plugs into the framework-agnostic
:class:`~agent_shield.adapters._shield.Shield` orchestrator.

Anthropic differs from chat-completion-style frameworks in that there
is no long-lived "agent" object — each run constructs a
``BetaAsyncToolRunner`` from a client + tools + model + system. The
``GuardedRunner`` here is therefore stateful (it holds the client and
default tools/model/system) and ``boundary.run`` builds the per-run
tool runner inside ``_execute``.

**Level 2 — Shield helper** (recommended)::

    from agent_shield import Shield
    import agent_shield.adapters.anthropic_agents  # side-effect import

    shield = (
        Shield.from_yaml("guardrails.yaml")
        .with_anthropic_agents()
        .with_client(client)
        .build()
    )
    tools  = shield.protect_tools(tools)
    runner = shield.guard(client, tools=tools, model="claude-sonnet-4-20250514")
    result = await runner.run("What is the weather?")

**Level 3 — two-liner**::

    shield = (
        Shield.from_yaml("guardrails.yaml")
        .with_anthropic_agents()
        .with_client(client)
        .build()
    )
    runner = shield.create_anthropic_agents_agent(tools, system_prompt="...")
    result = await runner.run("What is the weather?")
"""
from __future__ import annotations

import inspect
import logging
from typing import Any, AsyncIterator, Awaitable, Callable, Mapping, Optional, Union

from agent_shield import Runtime, Session
from agent_shield.errors import StreamingReplaceNotSupportedError

from ._capabilities import (
    AgentBoundary,
    CapabilityReport,
    ConfigurationMissingModelError,
    CoverageLevel,
    FrameworkBundle,
    GuardedInvoke,
    LlmCallerFactory,
    StreamingAdapter,
    StreamingValidator,
    ToolMetadata,
    ToolWrapper,
)
from ._orchestration import AgentShieldBlocked, check_stage1, current_session
from ._shield import (
    GuardedRunner as _GenericGuardedRunner,
    Shield,
    ShieldBuilder,
    _protect_tools_via_wrapper,
)

logger = logging.getLogger("agent_shield.anthropic_agents")


# Lazy import — module imports cleanly even when ``anthropic`` is not
# installed; only call paths that need the real class do the import.
try:
    from anthropic.lib.tools import (
        BetaAsyncBuiltinFunctionTool as _BuiltinToolBase,
        ToolError as _ToolError,
    )
except ImportError:  # pragma: no cover
    _BuiltinToolBase = object  # type: ignore[misc,assignment]
    _ToolError = Exception  # type: ignore[misc,assignment]


# ---------------------------------------------------------------------------
# Capability 1 — LLM caller factory
# ---------------------------------------------------------------------------


class _LlmCallerFactory(LlmCallerFactory):
    """Adapt an Anthropic client (sync or async) to the runtime caller shape.

    The Rust validation engine invokes LLM callers synchronously, so an
    ``AsyncAnthropic`` client is paired with a sync clone of itself to
    avoid ``asyncio.run()`` inside a running loop.

    When the optional ``configuration_resolver`` is supplied, the
    produced caller looks up the YAML's ``configurations[]`` entry by
    ``configuration_id`` at call time and uses its ``model:`` /
    ``max_tokens:`` fields — so a ``.guardrails.yaml`` like
    ``configurations: [{id: stage3-judge, type: llm, model:
    claude-3-5-sonnet-latest}]`` actually drives that model.

    Model selection is **strict**: the resolved configuration MUST
    declare ``model:``. When ``model:`` is missing — or no matching
    entry exists — the caller raises
    :class:`ConfigurationMissingModelError` instead of silently
    falling back to a hard-coded SKU. The schema in
    ``spec/schema/guardrails.schema.json`` enforces this at load time.

    ``max_tokens`` is treated differently because the Anthropic
    Messages API rejects requests without it but the choice of *how
    many* tokens to allow is not security-sensitive. When the
    resolved configuration omits ``max_tokens:`` the caller falls
    back to :attr:`DEFAULT_FALLBACK_MAX_TOKENS` (1024 — the historical
    default) rather than raising.
    """

    #: Anthropic's ``messages.create`` requires ``max_tokens``; this is
    #: the fallback when the YAML configuration does not declare one.
    #: The numeric budget is not a security-sensitive choice (unlike
    #: model selection), so defaulting it is acceptable.
    DEFAULT_FALLBACK_MAX_TOKENS = 1024

    def make_caller(
        self,
        client: Any,
        configuration_resolver: Optional[
            Callable[[Optional[str]], Optional[dict]]
        ] = None,
    ) -> Callable[[Optional[str], str], str]:
        sync_client = client
        if hasattr(client, "_client") and "Async" in type(client).__name__:
            import anthropic  # pragma: no cover

            init_kwargs: dict = {"api_key": client.api_key}
            if hasattr(client, "base_url") and client.base_url:
                init_kwargs["base_url"] = str(client.base_url)
            sync_client = anthropic.Anthropic(**init_kwargs)

        fallback_max_tokens = self.DEFAULT_FALLBACK_MAX_TOKENS

        def caller(configuration_id: Optional[str], prompt: str) -> str:
            cfg: Optional[dict] = None
            if configuration_resolver is not None and configuration_id:
                try:
                    cfg = configuration_resolver(configuration_id)
                except Exception:
                    # Resolver lookup must never break the LLM caller with
                    # an internal error — surface the missing-model
                    # condition directly so SREs see a load-time-shaped
                    # message rather than a transport failure.
                    logger.exception(
                        "anthropic_agents llm caller: configuration_resolver "
                        "raised for configuration_id=%r",
                        configuration_id,
                    )
                    cfg = None

            if cfg is None or not cfg.get("model"):
                raise ConfigurationMissingModelError(configuration_id)
            model = cfg["model"]

            if cfg.get("max_tokens") is not None:
                max_tokens = cfg["max_tokens"]
            else:
                max_tokens = fallback_max_tokens

            kwargs: dict = {
                "model": model,
                "max_tokens": max_tokens,
                "messages": [{"role": "user", "content": prompt}],
            }
            if cfg.get("temperature") is not None:
                kwargs["temperature"] = cfg["temperature"]

            response = sync_client.messages.create(**kwargs)
            block = response.content[0] if response.content else None
            return getattr(block, "text", "") if block else ""

        return caller


# ---------------------------------------------------------------------------
# Capability 2 — Tool wrapper
# ---------------------------------------------------------------------------


class _ToolWrapper(ToolWrapper):
    """Wrap an Anthropic tool with a :class:`_GuardedAsyncTool` subclass.

    Anthropic's ``BetaAsyncToolRunner`` discovers tools by inheritance —
    the guarded tool must subclass the framework's builtin base. The
    wrapper builds a per-tool subclass whose ``call`` method dispatches
    through the orchestrator-provided ``guarded_invoke``.
    """

    def extract(self, tool: Any) -> ToolMetadata:
        if isinstance(tool, dict):
            # The Anthropic Messages API takes a list of dicts shaped
            # like ``{"name":..., "description":..., "input_schema": {...}}``
            # — that's what every customer of ``client.messages.create``
            # writes. The historical:meth:`Shield.protect_tools` was
            # built for ``BetaAsyncBuiltinFunctionTool`` objects (which
            # carry an executable ``.call``); a bare dict has no
            # executable, so wrapping it here without a ``dispatch``
            # callable would silently produce a tool that cannot run.
            # Steer the caller to the dict-aware surface that pairs the
            # tool spec with a dispatch callable.
            raise TypeError(
                "Shield.protect_tools(...) received an Anthropic Messages "
                "API tool dict (e.g. {'name': ..., 'input_schema': ...}). "
                "Bare dicts have no executable to invoke — use "
                "Shield.protect_anthropic_tools(tools, dispatch=...) to "
                "pair the dict tools with a dispatch callable, or "
                "Shield.run_anthropic_agent(client=..., tools=..., "
                "dispatch=..., messages=...) to drive the full "
                "messages.create() loop with guardrails applied."
            )
        return ToolMetadata(
            name=tool.name,
            description=getattr(tool, "description", tool.name),
            extras={"to_dict": getattr(tool, "to_dict", lambda: {})},
        )

    async def invoke(self, original: Any, params: dict) -> Any:
        return await original.call(input=params)

    def wrap(
        self,
        original: Any,
        metadata: ToolMetadata,
        guarded_invoke: GuardedInvoke,
    ) -> Any:
        return _GuardedAsyncTool(original, metadata, guarded_invoke)


class _GuardedAsyncTool(_BuiltinToolBase):  # type: ignore[misc]
    """Anthropic-shaped guarded tool.

    Subclasses ``BetaAsyncBuiltinFunctionTool`` so the
    ``BetaAsyncToolRunner`` recognises it as a callable tool. The
    ``call()`` override delegates to the orchestrator-provided
    ``guarded_invoke`` and translates orchestrator blocks into
    Anthropic's ``ToolError``.
    """

    def __init__(
        self,
        original: Any,
        metadata: ToolMetadata,
        guarded_invoke: GuardedInvoke,
    ) -> None:
        self._original = original
        self._metadata = metadata
        self._guarded_invoke = guarded_invoke

    @property
    def name(self) -> str:  # type: ignore[override]
        return self._metadata.name

    def to_dict(self) -> Any:
        return self._metadata.extras.get("to_dict", lambda: {})()

    async def call(self, *, input: Any) -> Any:  # type: ignore[override]
        params = dict(input) if input else {}
        # With ``tool_wrapper_raise_on_block=True`` on
        # the bundle, the orchestrator raises ``AgentShieldBlocked``
        # on Stage 2/3/4 blocks instead of returning the canonical
        # ``[GUARDRAIL BLOCK]...`` string. Translate to
        # ``_ToolError`` so Anthropic's ``BetaAsyncToolRunner``
        # records the call as a tool failure (an ``is_error`` content
        # block on the next ``tool_result``) rather than letting the
        # block message flow back as ordinary tool output the LLM
        # then narrates over. See
        # the block-to-observation silent-bypass class.
        try:
            output = await self._guarded_invoke(params, "")
        except AgentShieldBlocked as exc:
            raise _ToolError(exc.message) from exc
        # Defensive — older orchestrator paths can still surface the
        # formatted block string as the output text on a block; keep
        # the legacy translation so a mixed-version install does not
        # silently bypass.
        if isinstance(output, str) and output.startswith("[GUARDRAIL"):
            raise _ToolError(output)
        return output


# ---------------------------------------------------------------------------
# Capability 3 — Agent boundary
# ---------------------------------------------------------------------------


#: Keys that belong in the ``BetaAsyncToolRunner`` *constructor* envelope
#(alongside ``params``/``client``/``tools``), not inside the
#``params=`` dict that gets spread into ``client.beta.messages.parse``.
_RUNNER_TOP_LEVEL_KEYS = frozenset({
    "max_iterations",
    "compaction_control",
    "options",
})

#: Default ``max_tokens`` for the per-run Anthropic message create. The
#: Anthropic Messages API rejects requests without ``max_tokens``; the
#: numeric budget is not a security-sensitive choice (unlike model
#: selection), so defaulting it here is acceptable.
_DEFAULT_MAX_TOKENS = 4096

#: Default Claude SKU used by the boundary when the caller did not
#: supply a ``model=`` kwarg. ``GuardedRunner.run`` always forwards
#``model=`` (its own default is ``claude-sonnet-4-20250514``) so this
#: is just a defensive fallback for direct boundary callers.
_DEFAULT_MODEL = "claude-sonnet-4-20250514"


def _build_runner_kwargs(
    *,
    client: Any,
    tools: list,
    input_text: str,
    kwargs: dict[str, Any],
) -> dict[str, Any]:
    """Translate adapter-shaped kwargs into ``BetaAsyncToolRunner`` shape.

    Since anthropic 0.68 the runner's signature is::

        BetaAsyncToolRunner(*, params, options, tools, client,
                            max_iterations=None, compaction_control=None)

    where ``params`` is a ``ParseMessageCreateParamsBase``-style dict
    holding ``model`` / ``messages`` / ``system`` / ``max_tokens`` /
    etc. The adapter's public surface still accepts the historical
    ``model=`` / ``system=`` / ``max_tokens=`` keyword arguments; this
    helper packs them into the ``params`` envelope and routes
    constructor-only kwargs (``max_iterations``, ``compaction_control``,
    ``options``) to the top level.
    """
    model = kwargs.pop("model", None) or _DEFAULT_MODEL
    system = kwargs.pop("system", None)
    messages = kwargs.pop("messages", None) or [
        {"role": "user", "content": input_text}
    ]
    max_tokens = kwargs.pop("max_tokens", _DEFAULT_MAX_TOKENS)

    params: dict[str, Any] = {
        "model": model,
        "messages": messages,
        "max_tokens": max_tokens,
    }
    if system is not None:
        params["system"] = system

    top_level: dict[str, Any] = {}
    for key in list(kwargs):
        if key in _RUNNER_TOP_LEVEL_KEYS:
            top_level[key] = kwargs.pop(key)

    # Anything else the caller passed (temperature, tool_choice,
    # thinking, betas, …) belongs inside ``params`` — those are
    # message-create fields, not runner-construction fields.
    params.update(kwargs)

    runner_kwargs: dict[str, Any] = {
        "client": client,
        "tools": tools,
        "params": params,
        "options": top_level.pop("options", {}),
    }
    runner_kwargs.update(top_level)
    return runner_kwargs


class _AgentBoundary(AgentBoundary):
    """Build a per-run ``BetaAsyncToolRunner`` and execute it.

    The "agent" parameter for Anthropic is the async client; per-run
    parameters (``tools``, ``model``, ``system``) ride in via kwargs
    set by :class:`GuardedRunner`.
    """

    async def run(
        self, agent: Any, input_text: str, **kwargs: Any,
    ) -> Any:
        from anthropic.lib.tools import BetaAsyncToolRunner

        client = agent
        tools = kwargs.pop("tools", None) or []
        runner_kwargs = _build_runner_kwargs(
            client=client, tools=tools, input_text=input_text, kwargs=kwargs,
        )
        runner = BetaAsyncToolRunner(**runner_kwargs)
        return await runner.get_final_message()

    def extract_output(self, result: Any) -> Optional[str]:
        return _extract_text(result)

    def apply_redaction(self, result: Any, redacted_text: str) -> Any:
        return _RedactedResult(result, redacted_text)

    def make_blocked(self, message: str) -> Any:
        return _BlockedResult(message)


def _extract_text(message: Any) -> str:
    """Concatenate text blocks from an Anthropic ``Message``."""
    if not hasattr(message, "content"):
        return str(message)
    parts: list[str] = []
    for block in message.content:
        if hasattr(block, "text"):
            parts.append(block.text)
    return "".join(parts)


class _BlockedResult:
    """Stand-in for a ``Message`` when input/output is blocked."""

    def __init__(self, message: str) -> None:
        self.final_output = message

    def __repr__(self) -> str:
        return f"BlockedResult({self.final_output!r})"


class _RedactedResult:
    """Wraps an Anthropic ``Message`` with redacted text output."""

    def __init__(self, original: Any, redacted_text: str) -> None:
        self._original = original
        self.final_output = redacted_text

    def __getattr__(self, name: str) -> Any:
        return getattr(self._original, name)

    def __repr__(self) -> str:
        return f"RedactedResult({self.final_output!r})"


# ---------------------------------------------------------------------------
# Capability 4 — Streaming adapter
# ---------------------------------------------------------------------------


class _StreamingAdapter(StreamingAdapter):
    """Anthropic streaming via ``get_final_message`` push.

    The Anthropic tool-runner returns a complete message rather than a
    token stream, so the "stream" is a single push of the final
    message's text through the validator. Adapters that move to true
    SSE streaming can revisit this once the framework exposes it.
    """

    async def stream(
        self,
        agent: Any,
        input_text: str,
        validator: StreamingValidator,
        **kwargs: Any,
    ) -> AsyncIterator[Any]:
        from anthropic.lib.tools import BetaAsyncToolRunner

        client = agent
        tools = kwargs.pop("tools", None) or []
        runner_kwargs = _build_runner_kwargs(
            client=client, tools=tools, input_text=input_text, kwargs=kwargs,
        )
        runner = BetaAsyncToolRunner(**runner_kwargs)
        final = await runner.get_final_message()
        text = _extract_text(final)

        result = validator.push(text)
        if result.action == "replace":
            # Anthropic streaming yields message text directly to the
            # consumer; a `replace` action means "retract every
            # previously-yielded byte" which we physically cannot do
            # once delivered. Fail loudly so the host
            # switches to `on_complete` cadence (the default) instead
            # of silently rendering a leaked-then-redacted blob.
            raise StreamingReplaceNotSupportedError(
                "Anthropic streaming adapter received a `replace` "
                "action from the Stage-5 guard, but message text is "
                "yielded directly to the consumer and cannot be "
                "retracted. Switch the streaming cadence to "
                "`on_complete` (default) or disable streaming. "
                "Reason: " + (result.reason or "<no reason supplied>")
            )
        if result.payload:
            yield result.payload
        if result.stopped:
            yield validator.make_blocked(
                result.reason or "Stage 5 streaming guard stopped the stream.",
            )
            return
        tail = validator.finish()
        if tail.stopped:
            yield validator.make_blocked(
                tail.reason or "Stage 5 streaming guard stopped the stream.",
            )
            return
        if tail.action == "replace":
            raise StreamingReplaceNotSupportedError(
                "Anthropic streaming adapter received a `replace` "
                "action at finish(), but message text is yielded "
                "directly to the consumer and cannot be retracted. "
                "Switch the streaming cadence to `on_complete` "
                "(default) or disable streaming. Reason: "
                + (tail.reason or "<no reason supplied>")
            )
        if tail.payload:
            yield tail.payload


# ---------------------------------------------------------------------------
# Bundle
# ---------------------------------------------------------------------------


class GuardedRunner(_GenericGuardedRunner):
    """Anthropic-named guarded runner with stateful per-run defaults.

    Holds the Anthropic client plus default ``tools`` / ``model`` /
    ``system``; each ``run()`` call may override them. The orchestrator
    framework runs the boundary's ``run()`` which builds and drives the
    underlying ``BetaAsyncToolRunner``.
    """

    def __init__(
        self,
        runtime: Runtime,
        client: Any,
        boundary: AgentBoundary,
        streaming: Optional[StreamingAdapter] = None,
        *,
        tools: list | None = None,
        model: str = "claude-sonnet-4-20250514",
        system: str | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(runtime, client, boundary, streaming, **kwargs)
        self._default_tools = tools or []
        self._default_model = model
        self._default_system = system

    @property
    def client(self) -> Any:
        return self._agent

    async def run(  # type: ignore[override]
        self,
        input_text: str,
        *,
        session: Session | None = None,
        tools: list | None = None,
        model: str | None = None,
        system: str | None = None,
        **kwargs: Any,
    ) -> Any:
        """Run with Stage 1 + Stage 5 enforcement."""
        return await super().run(
            input_text,
            session=session,
            tools=tools if tools is not None else self._default_tools,
            model=model or self._default_model,
            system=system if system is not None else self._default_system,
            **kwargs,
        )

    async def run_streamed(  # type: ignore[override]
        self,
        input_text: str,
        *,
        session: Session | None = None,
        tools: list | None = None,
        model: str | None = None,
        system: str | None = None,
        **kwargs: Any,
    ):
        """Stream with Stage 1 + Stage 5 enforcement."""
        async for emission in super().run_streamed(
            input_text,
            session=session,
            tools=tools if tools is not None else self._default_tools,
            model=model or self._default_model,
            system=system if system is not None else self._default_system,
            **kwargs,
        ):
            yield emission


_BUNDLE = FrameworkBundle(
    name="anthropic_agents",
    llm_caller_factory=_LlmCallerFactory(),
    tool_wrapper=_ToolWrapper(),
    agent_boundary=_AgentBoundary(),
    streaming_adapter=_StreamingAdapter(),
    capabilities=CapabilityReport(
        framework="anthropic_agents",
        # Anthropic's tool runner only exposes complete messages — true
        # token streaming is partial through this adapter.
        streaming_output=CoverageLevel.PARTIAL,
        notes=["streaming yields the full final message in one chunk"],
    ),
    guarded_runner_cls=GuardedRunner,
    # Stage 2/3/4 blocks raise ``AgentShieldBlocked``
    # from ``_GuardedAsyncTool.call``, which is translated to
    # ``anthropic.lib.tools.ToolError`` for the typed runner path and
    # propagated for the bare ``messages.create()`` loop in
    # :func:`run_anthropic_agent` (which marks the ``tool_result``
    # block with ``is_error: True``). See
    # the block-to-observation silent-bypass class.
    tool_wrapper_raise_on_block=True,
)


# ---------------------------------------------------------------------------
# Composition pattern — install with_anthropic_agents() and
# create_anthropic_agents_agent() at import time.
# ---------------------------------------------------------------------------


def _install() -> None:
    """Monkey-install :meth:`ShieldBuilder.with_anthropic_agents` and
    :meth:`Shield.create_anthropic_agents_agent`."""

    def with_anthropic_agents(self: ShieldBuilder) -> ShieldBuilder:
        """Bind this builder to the Anthropic Agents framework bundle."""
        return self._bind_to_bundle(_BUNDLE)

    def create_anthropic_agents_agent(
        self: Shield,
        tools: list,
        *,
        model: str,
        client: Any = None,
        system_prompt: str = "",
    ) -> Any:
        """Build a fully guarded Anthropic tool runner in one call (Pattern A).

        ``model`` is the *customer agent's* model — the Claude SKU that
        drives the agent's own reasoning loop. It is **required**: a
        security library MUST NOT pick a model on the customer's
        behalf. Note: composes through :meth:`Shield.protect_tools` and
        constructs the underlying client-bound runner. The Anthropic
        client must be supplied here or via ``with_client(...)``.
        """
        protected = self.protect_tools(tools)
        c = client if client is not None else self._client
        if c is None:
            raise ValueError(
                "create_anthropic_agents_agent requires an Anthropic client; "
                "pass client=... or set one via with_client(...)."
            )
        return self.guard(
            c,
            tools=protected,
            model=model,
            system=system_prompt,
        )

    ShieldBuilder.with_anthropic_agents = with_anthropic_agents
    Shield.create_anthropic_agents_agent = create_anthropic_agents_agent
    Shield.protect_anthropic_tools = protect_anthropic_tools
    Shield.run_anthropic_agent = run_anthropic_agent


# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# Dict-shaped tool support — Anthropic Messages API native shape
# ---------------------------------------------------------------------------
#
# Pair each Anthropic tool-spec dict with a minimal sync/async dispatch
# callable. The helper automates the native tool_use/tool_result loop with full
# Stage 1→5 enforcement and uses the same wrapper pipeline as object-shaped
# tools, so pending_resolution latching stays identical.

#: Type alias for the dispatch contract — a callable that, given a tool
#: name and an arguments dict, returns either the tool result or an
#: awaitable that resolves to the tool result.
AnthropicDispatch = Callable[[str, dict], Union[Any, Awaitable[Any]]]


class _DictToolAdapter:
    """Wrap a Messages-API tool dict + dispatch callable as a tool object.

    The historical ``_GuardedAsyncTool`` (and the ``_ToolWrapper`` it
    plugs into) expect tool objects exposing ``.name`` / ``.description``
    / ``.input_schema`` / ``.to_dict()`` / async ``.call(input=...)`` —
    the shape ``BetaAsyncBuiltinFunctionTool`` provides. This adapter
    presents the same interface around a customer-written dict spec +
    a dispatch callable, so dict tools flow through the existing
    ``_protect_tools_via_wrapper`` pipeline unchanged.

    The adapter never subclasses Anthropic's builtin tool base — it's
    a plain duck-typed object. The orchestrator's wrap step then
    produces the real ``_GuardedAsyncTool`` (which *does* subclass the
    builtin base), so the resulting guarded tool is usable with
    ``BetaAsyncToolRunner`` *and* with the bare ``messages.create()``
    loop driven by :func:`run_anthropic_agent`.
    """

    def __init__(self, spec: Mapping[str, Any], dispatch: AnthropicDispatch) -> None:
        if "name" not in spec:
            raise ValueError(
                "Anthropic tool dict missing required 'name' field: "
                f"{dict(spec)!r}"
            )
        self._spec = dict(spec)
        self._dispatch = dispatch
        self.name = spec["name"]
        self.description = spec.get("description", "") or self.name
        self.input_schema = spec.get("input_schema", {}) or {}

    def to_dict(self) -> dict:
        return dict(self._spec)

    async def call(self, *, input: Any) -> Any:
        params = dict(input) if input else {}
        result = self._dispatch(self.name, params)
        if inspect.isawaitable(result):
            result = await result
        return result


def _is_dict_tool(tool: Any) -> bool:
    return isinstance(tool, dict) and "name" in tool


def protect_anthropic_tools(
    self: Shield,
    tools: list,
    dispatch: Optional[AnthropicDispatch] = None,
    *,
    user_input_getter: Optional[Callable[[], str]] = None,
    allow_unguarded: bool = False,
) -> AnthropicDispatch:
    """Guard a list of Anthropic Messages API tool dicts.

    Accepts the standard ``client.messages.create(tools=[...])`` shape
    — a list of dicts like
    ``{"name": ..., "description": ..., "input_schema": {...}}`` — plus
    a ``dispatch`` callable that executes the named tool with the
    LLM-supplied params. Returns a *guarded dispatcher* with the same
    ``(name, params) -> Any`` contract; every invocation routes
    through Stages 2 + 3 + 4 on a wrapped tool, picking up
    Stage-3 redaction-mutation and Stage-4 deny / human-approval
    surfacing on the way.

    Object-shaped tools (``BetaAsyncBuiltinFunctionTool``) are passed
    through to :meth:`Shield.protect_tools` for backward compatibility
    — they bring their own ``.call`` so ``dispatch`` is not needed
    for them. ``dispatch`` is still required when *any* dict tool is
    present.

    The returned guarded dispatcher is what customers wire into their
    own ``messages.create()`` loop — see
    :func:`run_anthropic_agent` for a turnkey runner that drives the
    full loop with this dispatcher applied.

    On a Stage 2/3 ``kind: human`` block the structured
    ``pending_resolution`` is captured via
    :meth:`Shield.last_pending_resolution`; the block message returned to the LLM
    trajectory is the canonical ``[GUARDRAIL ...]`` string.
    """
    has_dict = any(_is_dict_tool(t) for t in tools)
    if has_dict and dispatch is None:
        raise ValueError(
            "protect_anthropic_tools(tools, dispatch=...) requires a "
            "dispatch callable when any tool is a Messages API dict. "
            "Pass dispatch=lambda name, params: ... to execute the "
            "named tool, or convert your tools to "
            "BetaAsyncBuiltinFunctionTool subclasses."
        )

    adapted: list = []
    for t in tools:
        if _is_dict_tool(t):
            adapted.append(_DictToolAdapter(t, dispatch))  # type: ignore[arg-type]
        else:
            adapted.append(t)

    if self._bundle is None:
        raise RuntimeError(
            "Shield.protect_anthropic_tools requires the Anthropic bundle. "
            "Call `.with_anthropic_agents()` on the builder before `.build()`."
        )

    def _sink(pr: dict) -> None:
        # Capture pending_resolution on any Stage 2/3 block on
        # a dict-shaped wrapped tool, identical to the object-shape
        # path through Shield.protect_tools.
        self._last_pending_resolution = pr

    wrapped = _protect_tools_via_wrapper(
        self.runtime,
        adapted,
        self._bundle.tool_wrapper,
        user_input_getter,
        mode=self._mode,
        allow_unguarded=allow_unguarded,
        pending_resolution_sink=_sink,
    )
    name_to_wrapped: dict[str, Any] = {w.name: w for w in wrapped}

    async def guarded_dispatch(name: str, params: dict) -> Any:
        w = name_to_wrapped.get(name)
        if w is None:
            raise KeyError(
                f"unknown Anthropic tool: {name!r}; "
                f"known: {sorted(name_to_wrapped)!r}"
            )
        try:
            return await w.call(input=dict(params or {}))
        except AgentShieldBlocked:
            # Propagate up to the caller (typically
            # :func:`run_anthropic_agent`, which emits a
            # ``tool_result`` content block with ``is_error: True``).
            # Returning the block as a plain string here would let
            # the next ``messages.create`` turn observe an ordinary
            # tool result and produce affirmative narrative that
            # contradicts the block — the block-to-observation
            # silent-bypass class.
            raise
        except _ToolError as te:
            # ``_GuardedAsyncTool.call`` translates a Stage 2/3/4
            # block into ``anthropic.lib.tools.ToolError`` — the
            # contract Anthropic's ``BetaAsyncToolRunner`` expects.
            # If the ``_ToolError`` was caused by an
            # ``AgentShieldBlocked`` (chained via ``from exc``),
            # re-raise the structured exception so the bare
            # ``messages.create()`` loop can mark the tool result as
            # an error block instead of letting the block message
            # flow back as ordinary content.
            cause = te.__cause__
            if isinstance(cause, AgentShieldBlocked):
                raise cause from te
            # Non-block tool failure: the bare ``messages.create()``
            # flow threads the message into the next turn as
            # ``tool_result.content`` (a string), so translate the
            # exception back into the string here. The structured
            # ``pending_resolution`` is already latched on
            # :meth:`Shield.last_pending_resolution` via the sink
            # wired above.
            return str(te)

    return guarded_dispatch


def _user_text_from_messages(messages: list) -> str:
    """Extract the most recent ``role: user`` text turn for Stage 1.

    Anthropic messages carry ``content`` as either a string or a list
    of content blocks; this concatenates the text portion of the
    latest user turn. Multimodal content is ignored for Stage 1
    purposes (the spec's input-validation surface is text-only).
    """
    for msg in reversed(messages or []):
        if not isinstance(msg, dict) or msg.get("role") != "user":
            continue
        content = msg.get("content")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts: list[str] = []
            for block in content:
                if isinstance(block, dict) and block.get("type") == "text":
                    parts.append(str(block.get("text", "")))
                elif isinstance(block, str):
                    parts.append(block)
            if parts:
                return "".join(parts)
        return ""
    return ""


async def run_anthropic_agent(
    self: Shield,
    *,
    client: Any,
    model: str,
    tools: list,
    dispatch: Optional[AnthropicDispatch],
    messages: list,
    system: Optional[str] = None,
    max_tokens: int = 1024,
    max_iterations: int = 10,
    **extra: Any,
) -> Any:
    """Pattern A runner for the bare ``client.messages.create()`` flow.

    Owns the multi-turn ``messages.create()`` → tool-dispatch →
    ``messages.create()`` loop the Anthropic Messages API requires,
    with full guardrails applied:

    - Stage 1 against the most recent user-turn text.
    - Stages 2/3/4 around every tool ``dispatch`` call.
    - Stage 5 against the final assistant text on ``end_turn``.

    ``tools`` is the same list of Messages API dicts that goes into
    ``client.messages.create(tools=...)`` — no rewriting required.
    ``dispatch`` is a ``(name, params) -> Any | Awaitable[Any]``
    callable that executes the named tool; the runner threads it
    through :func:`protect_anthropic_tools` so every tool call is
    guarded.

    On a Stage 2/3 ``kind: human`` block the latch on
    :meth:`Shield.last_pending_resolution` is populated as on every
    other path. Hosts read it after the call to drive their approval
    UI, then resume by calling :func:`run_anthropic_agent` again with
    the same ``messages``.

    Returns the final ``Message`` object from the Anthropic client
    (the same shape ``client.messages.create()`` returns) when the
    loop terminates with ``stop_reason != "tool_use"``. Returns a
    :class:`_BlockedResult` when Stage 1 / Stage 5 blocks.

    ``max_iterations`` caps the tool-use loop so a runaway agent
    cannot spin forever; default 10.
    """
    guarded_dispatch = self.protect_anthropic_tools(tools, dispatch)

    runtime = self.runtime
    with runtime.new_session() as sess:
        sess.begin_turn()
        session_token = current_session.set(sess)
        try:
            user_text = _user_text_from_messages(messages)
            blocked = check_stage1(sess, user_text).block_message
            if blocked is not None:
                logger.warning("[Stage 1] Anthropic input blocked: %s", blocked)
                return _BlockedResult(blocked)

            convo: list = list(messages)
            final: Any = None
            for _ in range(max_iterations):
                kwargs: dict[str, Any] = {
                    "model": model,
                    "messages": convo,
                    "max_tokens": max_tokens,
                }
                if tools:
                    kwargs["tools"] = tools
                if system is not None:
                    kwargs["system"] = system
                kwargs.update(extra)

                resp = client.messages.create(**kwargs)
                if inspect.isawaitable(resp):
                    resp = await resp

                if getattr(resp, "stop_reason", None) != "tool_use":
                    final = resp
                    break

                # Append assistant turn so the next messages.create()
                # call sees the tool_use blocks it just emitted.
                convo.append({
                    "role": "assistant",
                    "content": list(resp.content),
                })
                tool_results: list = []
                for block in resp.content:
                    if getattr(block, "type", None) != "tool_use":
                        continue
                    tu_name = getattr(block, "name", None) or ""
                    tu_input = getattr(block, "input", {}) or {}
                    tu_id = getattr(block, "id", None) or ""
                    is_error_block = False
                    try:
                        out = await guarded_dispatch(tu_name, dict(tu_input))
                    except AgentShieldBlocked as exc:
                        # Stage 2/3/4 block propagated
                        # from ``guarded_dispatch``. Emit a
                        # ``tool_result`` with ``is_error: True`` so
                        # the next ``messages.create`` turn observes
                        # an explicit tool error rather than treating
                        # the formatted block message as ordinary
                        # tool output and producing affirmative
                        # narrative that contradicts the block. The
                        # structured ``pending_resolution`` is
                        # already latched on
                        # :meth:`Shield.last_pending_resolution`
                        # via the wrapper sink, avoiding the block-to-observation
                        # silent-bypass class.
                        logger.info(
                            "run_anthropic_agent: tool %r blocked by guardrail",
                            tu_name,
                        )
                        out = exc.message
                        is_error_block = True
                    except Exception as exc:  # noqa: BLE001
                        logger.exception(
                            "run_anthropic_agent: dispatch raised for tool %r",
                            tu_name,
                        )
                        out = f"[tool error] {tu_name}: {exc}"
                        is_error_block = True
                    result_block: dict[str, Any] = {
                        "type": "tool_result",
                        "tool_use_id": tu_id,
                        "content": out if isinstance(out, str) else str(out),
                    }
                    if is_error_block:
                        result_block["is_error"] = True
                    tool_results.append(result_block)
                convo.append({"role": "user", "content": tool_results})
            else:
                logger.warning(
                    "run_anthropic_agent: max_iterations=%d exhausted",
                    max_iterations,
                )

            if final is None:
                return _BlockedResult(
                    "[GUARDRAIL] run_anthropic_agent: tool-use loop "
                    f"exceeded max_iterations={max_iterations}"
                )

            output_text = _extract_text(final)
            if output_text:
                outcome = sess.validate_output(output_text)
                verdict = outcome.verdict
                if not verdict.allowed and verdict.action == "block":
                    logger.warning(
                        "[Stage 5] Anthropic output blocked: %s",
                        verdict.reason,
                    )
                    return _BlockedResult(
                        f"[GUARDRAIL BLOCK] {verdict.reason or 'output blocked'}"
                    )
                if verdict.action == "redact":
                    redacted = getattr(outcome, "redacted_text", None) or output_text
                    return _RedactedResult(final, redacted)
            return final
        finally:
            current_session.reset(session_token)
            sess.end_turn()


_install()

# Register this bundle as the auto-bind default for new ShieldBuilder instances.
from . import _bundle_registry as _registry  # noqa: E402
_registry.register(_BUNDLE)


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


def make_llm_caller(
    client: Any,
    configuration_resolver: Optional[
        Callable[[Optional[str]], Optional[dict]]
    ] = None,
) -> Callable[[Optional[str], str], str]:
    """Create an LLM caller from an Anthropic client.

    Module-level shortcut for :meth:`_LlmCallerFactory.make_caller`.
    Pass ``configuration_resolver=runtime.llm_configuration`` to honour
    the YAML's per-stage ``model:`` / ``max_tokens:`` selection. When
    the resolver returns a configuration without ``model:`` (or no
    matching entry at all) the caller raises
    :class:`ConfigurationMissingModelError`. Missing ``max_tokens:``
    falls back to :attr:`_LlmCallerFactory.DEFAULT_FALLBACK_MAX_TOKENS`
    (1024) — the token budget is not security-sensitive, unlike model
    selection, so defaulting it is acceptable.
    """
    return _BUNDLE.llm_caller_factory.make_caller(
        client, configuration_resolver=configuration_resolver,
    )


def protect_tools(
    runtime: Runtime,
    tools: list,
    user_input_getter: Optional[Callable[[], str]] = None,
    *,
    allow_unguarded: bool = False,
) -> list:
    """Wrap Anthropic tools with Stages 2 + 3 + 4 enforcement.

    See :meth:`agent_shield.Shield.protect_tools` for the
    ``allow_unguarded`` flag.
    """
    return _protect_tools_via_wrapper(
        runtime, tools, _BUNDLE.tool_wrapper, user_input_getter,
        allow_unguarded=allow_unguarded,
    )


__all__ = [
    "AnthropicDispatch",
    "GuardedRunner",
    "make_llm_caller",
    "protect_tools",
]
