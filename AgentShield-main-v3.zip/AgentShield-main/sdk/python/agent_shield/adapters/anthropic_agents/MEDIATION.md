# Python Anthropic adapter mediation

## Mediated paths
- `ShieldBuilder.with_anthropic_agents()` installs the bundle; `GuardedRunner.run()` drives the Anthropic tool runner at `sdk/python/agent_shield/adapters/anthropic_agents.py:256`.
- Built-in Anthropic tools are wrapped by `_GuardedAsyncTool.call()` at `sdk/python/agent_shield/adapters/anthropic_agents.py:240`.
- The adapter's streaming surface is the single-final-message path at `sdk/python/agent_shield/adapters/anthropic_agents.py:338`.

## Unsupported paths
- Calling the original tool's `.call(input=...)` directly.
- Instantiating and using `BetaAsyncToolRunner` without the guarded wrapper.
- Direct Messages API usage outside the adapter-owned runner.

## Bypass risks
- Mixing raw Anthropic tools with wrapped ones in the same `tools=` list.
- Swapping the guarded tool out of the runner after construction.
- Assuming raw SSE or SDK-level streaming hooks are covered; this adapter only mediates the documented runner path.

## Streaming behavior
- Rule 1 — ✓ validates the final message text as a whole unit.
- Rule 2 — ✓ buffered final-message mode keeps the unvalidated window at zero.
- Rule 3 — ✓ by construction in the current buffered surface; denies occur before anything is released.
- Rule 4 — ✓ the shared `StreamingGuard` now emits `incident.stream_limit_exceeded` when the stream hits the core buffer bound.
- Rule 5 — ✓ tool-result chunks are not streamed; Stage-4 binding still goes through the normal `tool_use.id` / `tool_call_id` path.

## Unknown tool-call shapes
- The wrapped tool converts `input` with `dict(input) if input else {}` at `sdk/python/agent_shield/adapters/anthropic_agents.py:240`; unknown/non-mapping shapes therefore do not yet fail closed with `incident.unknown_invocation_shape`.

## See also

See [Post-tool limits and dangerous patterns](../../../../../docs/POST_TOOL_LIMITS.md) and the [adapter-mediated path matrix](../../../../../docs/adapter-mediated-paths.md).
