"""OpenAI Agents SDK adapter.

This adapter is a small set of capability implementations
( :class:`_LlmCallerFactory`, :class:`_ToolWrapper`, :class:`_AgentBoundary`,
:class:`_StreamingAdapter`) that plug into the framework-agnostic
:class:`~agent_shield.adapters._shield.Shield` orchestrator. Stage
sequencing, ``begin_turn`` / ``end_turn``, redaction, ``record_tool_*``,
``on_block`` policy, and monitor mode all live in the orchestrator.

Three usage levels:

**Level 1 — functions** (full control)::

    runtime = (
        RuntimeBuilder.from_yaml("guardrails.yaml")
        .register_llm_caller(make_llm_caller(client))
        .build()
    )
    protected = protect_tools(runtime, tools)

**Level 2 — Shield helper** (recommended)::

    from agent_shield import Shield
    import agent_shield.adapters.openai_agents  # side-effect import

    shield = (
        Shield.from_yaml("guardrails.yaml")
        .with_openai_agents()
        .with_client(client)
        .build()
    )
    tools  = shield.protect_tools(tools)
    agent  = shield.guard(agent)

**Level 3 — two-liner** (most turnkey)::

    shield = (
        Shield.from_yaml("guardrails.yaml")
        .with_openai_agents()
        .with_client(client)
        .build()
    )
    agent  = shield.create_openai_agents_agent(tools, system_prompt="...")

Wiring classifier callers (Azure AI Content Safety, etc.)
---------------------------------------------------------

When the YAML declares a ``classifier:`` evaluate_when entry whose
``configurations[]`` provider is not bundled (or you want to drive a
custom HTTP service), register a host caller through the
``ShieldBuilder.with_classifier_caller(callback)`` helper — or its
named alias ``with_aacs_caller(callback)`` for Azure AI Content
Safety::

    def aacs(configuration_id, subject, configuration):
        endpoint = configuration["endpoint"]
        headers  = configuration.get("headers", {})
        threshold = configuration.get("threshold", 4)
        # POST <endpoint>/contentsafety/text:analyze with headers...
        return {"classification": "block" if score >= threshold else "allow"}

    shield = (
        Shield.from_yaml("guardrails.yaml")
        .with_openai_agents().with_client(client)
        .with_aacs_caller(aacs)
        .build()
    )

The callback accepts either the legacy 2-arg
``(configuration_id, subject)`` shape or the new 3-arg
``(configuration_id, subject, configuration: dict)`` shape — arity
is detected and cached at registration time. The 3-arg form receives
the resolved YAML configuration so the host can read endpoint,
headers, threshold, and provider_config without re-parsing YAML.

Pending-approval surfacing
------------------------------------------

When a Stage 2/3 policy on a wrapped tool blocks because a resolver
(typically ``kind: human`` or ``kind: tool``) is suspended waiting for
external input, the wrapped tool returns the canonical
``[GUARDRAIL BLOCK] ...`` string to the agent — that's the
openai-agents ``FunctionTool.on_invoke_tool`` contract. The host can
retrieve the structured ``pending_resolution`` shape — without
substring-matching the block message — via
:meth:`agent_shield.Shield.last_pending_resolution`, and resolve it
back into the shield's retained session via
:meth:`agent_shield.Shield.resolve_pending`::

    guarded = shield.create_openai_agents_agent(tools, model="gpt-4o", system_prompt="...")
    result  = await guarded.run("Place a trade for MSFT")
    pending = shield.last_pending_resolution()
    if pending is not None:
        # {"tool": "agent_shield.ask_human", "variable":...,
        #  "prompt":..., "request_id":..., "kind": "human"}
        approval = await prompt_operator(pending["prompt"])
        await shield.resolve_pending("allow" if approval else "deny", value=approval)
        result = await guarded.run("Place a trade for MSFT")  # resume

The latch is cleared on read so a subsequent successful tool call
does not look like another pending block.
"""
from __future__ import annotations

import contextvars
import inspect
import json
import logging
from typing import Any, AsyncIterator, Callable, Optional

from agent_shield import Runtime
from agent_shield.errors import StreamingReplaceNotSupportedError

from ._capabilities import (
    AgentBoundary,
    CapabilityReport,
    ConfigurationMissingModelError,
    CoverageLevel,
    FrameworkBundle,
    GuardedInvoke,
    LlmCallerFactory,
    StreamingAdapter,
    StreamingValidator,
    ToolMetadata,
    ToolWrapper,
)
from ._shield import (
    GuardedRunner,
    Shield,
    ShieldBuilder,
    _protect_tools_via_wrapper,
)
from ._orchestration import AgentShieldBlocked, check_stage1

logger = logging.getLogger("agent_shield.openai_agents")


# ---------------------------------------------------------------------------
# Ctx-forwarding side channel
# ---------------------------------------------------------------------------
#
# The OpenAI Agents SDK invokes a ``FunctionTool`` as
# ``await tool.on_invoke_tool(ctx, input_json)`` where ``ctx`` is a
# ``ToolContext`` / ``RunContextWrapper`` carrying the active
# ``run_config`` and other runtime-only state. ``@function_tool``-decorated
# callables read ``ctx.run_config`` (e.g. for sandbox policy) and crash
# with ``'NoneType' object has no attribute 'run_config'`` if ``ctx`` is
# ``None``.
#
# The wrapper produced by :class:`_ToolWrapper.wrap` is the framework's
# entry point and receives the real ``ctx``, but the orchestrator's
# generic ``(params, user_input) -> output_text`` contract has no slot
# for it. This per-task ContextVar carries ``ctx`` across the
# ``guarded_invoke → _ToolWrapper.invoke → original.on_invoke_tool``
# call chain so the underlying tool sees the framework-supplied ctx
# instead of ``None``.
_current_oai_ctx: contextvars.ContextVar[Any] = contextvars.ContextVar(
    "_current_oai_ctx", default=None,
)


# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# Async → sync client cloning
# ---------------------------------------------------------------------------
#
# The sync Rust LLM-caller path needs a sync OpenAI/Azure client. Preserve
# Azure-only private attrs (api version, endpoint, auth token/provider,
# deployment) when cloning so Stage 1/3/5 judge calls target the same service.


class AzureClientMissingApiVersionError(RuntimeError):
    """Raised when an Azure async client lacks ``api_version``.

    The Azure OpenAI SDK requires ``api_version`` on every request and
    will raise ``ValueError`` on the first ``chat.completions.create()``
    call without it. The adapter detects the missing value at
    clone-time and surfaces this typed error so the customer sees a
    targeted recovery hint instead of a transport-shaped failure.

    Recovery: set ``api_version`` on the source ``AsyncAzureOpenAI``::

        client = AsyncAzureOpenAI(
            azure_endpoint=...,
            api_key=...,
            api_version="2025-04-01-preview",
        )

    The adapter intentionally does **not** silently fall back to the
    ``OPENAI_API_VERSION`` environment variable — implicit env lookup
    here would mask configuration drift in CI / staging / production.
    """


# Azure clients constructed without an ``api_key`` synthesise a
# sentinel string for diagnostics; treat values that start with ``<``
# as absent so we don't propagate the placeholder onto the clone.
_AZURE_MISSING_API_KEY_SENTINEL = "<missing API key>"


def _attr(client: Any, *names: str) -> Any:
    """Return the first truthy attribute among ``names``.

    The ``openai`` Python SDK stores Azure-specific configuration on
    private attributes (``_api_version``, ``_azure_endpoint``, ...).
    Try the private name first, then the public name for forward
    compatibility if the SDK ever promotes the field.
    """
    for name in names:
        value = getattr(client, name, None)
        if value:
            return value
    return None


def _real_api_key(client: Any) -> Optional[str]:
    """Return ``client.api_key`` only when it's a real value.

    Azure clients constructed with ``azure_ad_token`` (no ``api_key``)
    expose ``api_key == "<missing API key>"``. Passing that sentinel
    back into ``AzureOpenAI(api_key=...)`` would round-trip the
    placeholder; instead, treat it as absent so the clone uses the
    AAD token / token provider for auth.
    """
    api_key = getattr(client, "api_key", None)
    if not api_key:
        return None
    if isinstance(api_key, str) and api_key.startswith("<") and "missing" in api_key.lower():
        return None
    return api_key


def _clone_async_openai_client_as_sync(client: Any) -> Any:
    """Build a sync clone of an ``Async{Azure,}OpenAI`` client.

    Preserves all auth + targeting knobs that the customer set on the
    source. For Azure, this is the full set required for a working
    sync client:

    * ``api_version`` — **required** by the Azure SDK; missing values
      raise :class:`AzureClientMissingApiVersionError`.
    * ``azure_endpoint`` — Azure resource URL (distinct from
      ``base_url``; the Azure SDK rejects mixing them).
    * ``azure_ad_token`` / ``azure_ad_token_provider`` — AAD auth.
    * ``azure_deployment`` — default deployment for the client.
    * ``api_key`` — when not using AAD.
    * ``organization`` / ``project`` — billing / routing scope.

    For direct OpenAI, preserves ``api_key`` / ``base_url`` /
    ``organization`` / ``project``.
    """
    import openai

    is_azure = "Azure" in type(client).__name__
    init_kwargs: dict = {}

    api_key = _real_api_key(client)
    if api_key:
        init_kwargs["api_key"] = api_key

    organization = getattr(client, "organization", None)
    if organization:
        init_kwargs["organization"] = organization
    project = getattr(client, "project", None)
    if project:
        init_kwargs["project"] = project

    if is_azure:
        api_version = _attr(client, "_api_version", "api_version")
        if not api_version:
            raise AzureClientMissingApiVersionError(
                "AsyncAzureOpenAI source client has no api_version set; "
                "the Azure SDK requires it on every request. Construct "
                "the client with api_version=\"<your-version>\" "
                "(e.g. \"2025-04-01-preview\") before passing it to "
                "Shield.with_client()."
            )
        init_kwargs["api_version"] = api_version

        azure_endpoint = _attr(client, "_azure_endpoint", "azure_endpoint")
        if azure_endpoint:
            init_kwargs["azure_endpoint"] = str(azure_endpoint)
        else:
            # Rare HTTP-override case where only base_url is set.
            base_url = getattr(client, "base_url", None)
            if base_url:
                init_kwargs["base_url"] = str(base_url)

        azure_ad_token = _attr(client, "_azure_ad_token", "azure_ad_token")
        if azure_ad_token:
            init_kwargs["azure_ad_token"] = azure_ad_token
        azure_ad_token_provider = _attr(
            client, "_azure_ad_token_provider", "azure_ad_token_provider",
        )
        if azure_ad_token_provider:
            init_kwargs["azure_ad_token_provider"] = azure_ad_token_provider
        azure_deployment = _attr(
            client, "_azure_deployment", "azure_deployment",
        )
        if azure_deployment:
            init_kwargs["azure_deployment"] = azure_deployment

        return openai.AzureOpenAI(**init_kwargs)

    base_url = getattr(client, "base_url", None)
    if base_url:
        init_kwargs["base_url"] = str(base_url)
    return openai.OpenAI(**init_kwargs)


# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# FunctionTool kwarg compatibility shim
# ---------------------------------------------------------------------------
#
# openai-agents 0.17 renamed the failure-renderer kwargs. Disable both the
# custom and default renderers so AgentShieldBlocked escapes the runner instead
# of becoming an LLM-visible tool-result string; cache detection per class so
# tests with substitute FunctionTool types do not poison the real SDK path.
_FUNCTION_TOOL_FAILURE_KWARGS_CACHE: dict = {}


def _function_tool_failure_kwargs(function_tool_cls: type) -> dict:
    """Return the kwargs dict that disables failure error rendering.

    Picks the kwarg shape ``openai-agents`` exposes:

    * ``0.16.x`` (public): ``{"failure_error_function": None}``
    * ``0.17.x`` (private + default-disable flag):
      ``{"_failure_error_function": None,
         "_use_default_failure_error_function": False}``

    Returns an empty dict on builds that expose neither (forward-compat
    fallback). The signature inspection happens once per class per
    process and the resolved kwargs are cached.
    """
    cached = _FUNCTION_TOOL_FAILURE_KWARGS_CACHE.get(function_tool_cls)
    if cached is not None:
        return cached

    try:
        params = inspect.signature(function_tool_cls.__init__).parameters
    except (TypeError, ValueError):  # pragma: no cover — defensive
        resolved: dict = {}
    else:
        if "failure_error_function" in params:
            resolved = {"failure_error_function": None}
        elif "_failure_error_function" in params:
            resolved = {"_failure_error_function": None}
            if "_use_default_failure_error_function" in params:
                resolved["_use_default_failure_error_function"] = False
        else:
            resolved = {}

    _FUNCTION_TOOL_FAILURE_KWARGS_CACHE[function_tool_cls] = resolved
    return resolved


def _reset_function_tool_failure_kwargs_cache() -> None:
    """Test-only hook to clear the inspection cache between cases."""
    _FUNCTION_TOOL_FAILURE_KWARGS_CACHE.clear()


# ---------------------------------------------------------------------------
# Capability 1 — LLM caller factory
# ---------------------------------------------------------------------------


class _LlmCallerFactory(LlmCallerFactory):
    """Adapt an OpenAI client (sync or async) to the runtime caller shape.

    The Rust validation engine invokes LLM callers synchronously, so an
    ``AsyncOpenAI`` client is paired with a sync clone of itself to
    avoid ``asyncio.run()`` inside a running loop.

    When the optional ``configuration_resolver`` is supplied, the
    produced caller looks up the YAML's ``configurations[]`` entry by
    ``configuration_id`` at call time and uses its ``model:`` /
    ``max_tokens:`` fields — so a ``.guardrails.yaml`` like
    ``configurations: [{id: stage3-judge, type: llm, model: gpt-4o}]``
    actually drives ``gpt-4o``.

    Model selection is **strict**: the resolved configuration MUST
    declare ``model:``. When ``model:`` is missing — or no matching
    entry exists — the caller raises
    :class:`ConfigurationMissingModelError` instead of silently
    falling back to a hard-coded SKU. The schema in
    ``spec/schema/guardrails.schema.json`` enforces this at load time,
    so a correctly-built guardrails file never reaches the error
    branch in normal operation.
    """

    def make_caller(
        self,
        client: Any,
        configuration_resolver: Optional[
            Callable[[Optional[str]], Optional[dict]]
        ] = None,
    ) -> Callable[[Optional[str], str], str]:
        sync_client = client
        if "Async" in type(client).__name__:
            sync_client = _clone_async_openai_client_as_sync(client)

        def caller(configuration_id: Optional[str], prompt: str) -> str:
            cfg: Optional[dict] = None
            if configuration_resolver is not None and configuration_id:
                try:
                    cfg = configuration_resolver(configuration_id)
                except Exception:
                    # Resolver lookup must never break the LLM caller with
                    # an internal error — surface the missing-model
                    # condition directly so SREs see a load-time-shaped
                    # message rather than a transport failure.
                    logger.exception(
                        "openai_agents llm caller: configuration_resolver "
                        "raised for configuration_id=%r",
                        configuration_id,
                    )
                    cfg = None

            # — `model:` is the identifier passed verbatim to the
            # provider SDK. For direct OpenAI it's a model name; for
            # Azure OpenAI it's a deployment name (Azure's OpenAI SDK
            # takes the deployment in the `model=` kwarg). The runtime
            # treats it as opaque.
            if cfg is None or not cfg.get("model"):
                raise ConfigurationMissingModelError(configuration_id)
            model = cfg["model"]

            kwargs: dict = {
                "model": model,
                "messages": [{"role": "user", "content": prompt}],
            }
            if cfg.get("max_tokens") is not None:
                kwargs["max_tokens"] = cfg["max_tokens"]

            response = sync_client.chat.completions.create(**kwargs)
            return response.choices[0].message.content or ""

        return caller


# ---------------------------------------------------------------------------
# Capability 2 — Tool wrapper
# ---------------------------------------------------------------------------


class _ToolWrapper(ToolWrapper):
    """Translate between OpenAI ``FunctionTool`` and the orchestrator shape.

    The OpenAI Agents SDK invokes tools as
    ``on_invoke_tool(ctx, input_json: str) -> str``. The wrapper
    converts that envelope to/from the orchestrator's
    ``(params: dict, user_input: str) -> str`` shape, and re-serialises
    the (possibly Stage-3-mutated) effective params before calling the
    original tool — so redacted/replaced params reach the framework.

    ``ctx`` is the framework's runtime context (``ToolContext`` /
    ``RunContextWrapper``); the orchestrator boundary does NOT take
    a ctx slot, so the wrapper threads the framework-supplied ctx
    across the orchestrator via the :data:`_current_oai_ctx`
    ContextVar. ``@function_tool``-decorated callables read
    ``ctx.run_config`` and would crash with ``AttributeError`` if the
    wrapper called the underlying tool with ``ctx=None``.
    """

    def extract(self, tool: Any) -> ToolMetadata:
        return ToolMetadata(
            name=tool.name,
            description=getattr(tool, "description", tool.name),
            params_schema=getattr(tool, "params_json_schema", {}),
            # Stash the original so :meth:`invoke` and :meth:`wrap`
            # can preserve framework-specific fields (strict mode,
            # explicit-namespacing flags) that aren't part of the
            # orchestrator's neutral ``ToolMetadata``.
            extras={"original": tool},
        )

    async def invoke(self, original: Any, params: dict) -> Any:
        # OpenAI's FunctionTool wants a JSON envelope; re-serialise so
        # Stage-3-mutated params reach the framework. The ctx is
        # threaded via :data:`_current_oai_ctx` so ``@function_tool``
        # callables that read ``ctx.run_config`` keep working.
        effective_json = json.dumps(params) if params else "{}"
        ctx = _current_oai_ctx.get(None)
        return await original.on_invoke_tool(ctx, effective_json)

    def wrap(
        self,
        original: Any,
        metadata: ToolMetadata,
        guarded_invoke: GuardedInvoke,
    ) -> Any:
        from agents import FunctionTool

        async def _on_invoke(ctx: Any, input_json: str) -> str:
            try:
                params = json.loads(input_json) if input_json else {}
            except json.JSONDecodeError:
                params = {}
            # publish the framework-supplied ctx so the
            # underlying tool sees the same object the framework
            # would have passed without AgentShield wrapping.
            token = _current_oai_ctx.set(ctx)
            try:
                return await guarded_invoke(params, "")
            except AgentShieldBlocked:
                # propagate so the Runner halts the
                # agent loop rather than serialising the block
                # message into a tool result the LLM treats as an
                # ordinary observation. ``FunctionTool`` is built
                # below with ``failure_error_function=None`` so this
                # exception isn't recovered into a tool-error string
                # — ``Runner.run`` re-raises it to the caller.
                raise
            finally:
                _current_oai_ctx.reset(token)

        # The original's schema is already strict-mode-shaped if the
        # source tool was built with ``strict_json_schema=True``;
        # preserving the original's flag avoids re-applying the strict
        # transformation in ``FunctionTool.__post_init__`` for tools
        # the customer explicitly opted out of strict mode.
        strict = getattr(original, "strict_json_schema", True)
        # disable the SDK's default tool-error
        # renderer so a raised ``AgentShieldBlocked`` propagates out of
        # ``Runner.run`` instead of being formatted back to the LLM as
        # an ordinary tool-result string the model treats as an
        # observation (the silent-bypass class). The exact kwargs
        # differ between ``openai-agents`` 0.16.x (public
        # ``failure_error_function``) and 0.17.x (private
        # ``_failure_error_function`` + ``_use_default_failure_error_function``);
        # :func:`_function_tool_failure_kwargs` inspects ``FunctionTool``'s
        # signature once and caches the right shape. See
        # the block-to-observation silent-bypass class.
        failure_kwargs = _function_tool_failure_kwargs(FunctionTool)
        return FunctionTool(
            name=metadata.name,
            description=metadata.description,
            params_json_schema=metadata.params_schema,
            on_invoke_tool=_on_invoke,
            strict_json_schema=strict,
            **failure_kwargs,
        )


# ---------------------------------------------------------------------------
# Capability 3 — Agent boundary (Stages 1 + 5 around Runner.run)
# ---------------------------------------------------------------------------


class _AgentBoundary(AgentBoundary):
    """Run an OpenAI Agent and reshape its result for redaction / blocking."""

    async def run(
        self, agent: Any, input_text: str, **kwargs: Any,
    ) -> Any:
        from agents import Runner

        return await Runner.run(agent, input_text, **kwargs)

    def extract_output(self, result: Any) -> Optional[str]:
        return getattr(result, "final_output", None)

    def apply_redaction(self, result: Any, redacted_text: str) -> Any:
        result.final_output = redacted_text
        return result

    def make_blocked(self, message: str) -> Any:
        return _BlockedResult(message)


class _BlockedResult:
    """Minimal stand-in for an OpenAI ``RunResult`` in the blocked path."""

    def __init__(self, message: str) -> None:
        self.final_output = message
        self._final_output_override = None

    def __repr__(self) -> str:
        return f"BlockedResult({self.final_output!r})"


# ---------------------------------------------------------------------------
# Capability 4 — Streaming adapter
# ---------------------------------------------------------------------------


class _StreamingAdapter(StreamingAdapter):
    """Drive an OpenAI Agents streaming run with Stage-5 enforcement.

    OpenAI's framework yields plain text deltas, so this adapter yields
    safe payloads per chunk. Stage-1 (input check) and the
    streaming-session pipeline are owned by the orchestrator; this loop
    only does extraction + validator dispatch.
    """

    async def stream(
        self,
        agent: Any,
        input_text: str,
        validator: StreamingValidator,
        **kwargs: Any,
    ) -> AsyncIterator[Any]:
        from agents import Runner

        streamed = Runner.run_streamed(agent, input_text, **kwargs)
        async for event in streamed.stream_events():
            text = _extract_event_text(event)
            if not text:
                continue
            result = validator.push(text)
            if result.action == "replace":
                # OpenAI Agents streaming yields deltas directly to the
                # consumer (append-only sink). A `replace` action means
                # "retract every previously-yielded byte" which we
                # physically cannot do once the consumer has rendered
                # them. Fail loudly so the host switches to
                # `on_complete` cadence (the default) instead of
                # silently rendering the leaked-then-redacted blob.
                raise StreamingReplaceNotSupportedError(
                    "OpenAI Agents streaming adapter received a "
                    "`replace` action from the Stage-5 guard, but "
                    "deltas are yielded directly to the consumer and "
                    "cannot be retracted. Switch the streaming cadence "
                    "to `on_complete` (default) or disable streaming. "
                    "Reason: " + (result.reason or "<no reason supplied>")
                )
            if result.payload:
                yield result.payload
            if result.stopped:
                yield validator.make_blocked(
                    result.reason or "Stage 5 streaming guard stopped.",
                )
                return
        tail = validator.finish()
        if tail.stopped:
            yield validator.make_blocked(
                tail.reason or "Stage 5 streaming guard stopped.",
            )
            return
        if tail.action == "replace":
            raise StreamingReplaceNotSupportedError(
                "OpenAI Agents streaming adapter received a `replace` "
                "action at finish(), but deltas are yielded directly "
                "to the consumer and cannot be retracted. Switch the "
                "streaming cadence to `on_complete` or disable "
                "streaming. Reason: "
                + (tail.reason or "<no reason supplied>")
            )
        if tail.payload:
            yield tail.payload


def _extract_event_text(event: Any) -> str:
    """Best-effort extraction of streamed text from an OpenAI Agents event."""
    text = getattr(event, "delta", None)
    if isinstance(text, str):
        return text
    data = getattr(event, "data", None)
    if isinstance(data, str):
        return data
    if hasattr(event, "text"):
        v = event.text
        if isinstance(v, str):
            return v
    return ""


# ---------------------------------------------------------------------------
# Bundle
# ---------------------------------------------------------------------------


class GuardedAgent(GuardedRunner):
    """OpenAI-named wrapper around :class:`GuardedRunner`.

    Preserves the historic ``GuardedAgent(runtime, agent)`` constructor
    by auto-supplying the OpenAI bundle's boundary + streaming adapter
    when callers instantiate it directly instead of going through
    ``Shield.guard(...)``.
    """

    def __init__(
        self,
        runtime: Runtime,
        agent: Any,
        boundary: "AgentBoundary | None" = None,
        streaming: Optional[StreamingAdapter] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            runtime,
            agent,
            boundary if boundary is not None else _BUNDLE.agent_boundary,
            streaming if streaming is not None else _BUNDLE.streaming_adapter,
            **kwargs,
        )


_BUNDLE = FrameworkBundle(
    name="openai_agents",
    llm_caller_factory=_LlmCallerFactory(),
    tool_wrapper=_ToolWrapper(),
    agent_boundary=_AgentBoundary(),
    streaming_adapter=_StreamingAdapter(),
    capabilities=CapabilityReport(
        framework="openai_agents",
        # Streaming chunk-level Stage 5 covers OpenAI text deltas
        # only; tool_call argument deltas are validated post-completion
        # (Stage 2/3/4 fire on the assembled call). Marked partial.
        streaming_output=CoverageLevel.PARTIAL,
    ),
    guarded_runner_cls=GuardedAgent,
    # Stage 2/3/4 blocks raise ``AgentShieldBlocked``
    # from the wrapped ``FunctionTool.on_invoke_tool``; combined with
    # ``failure_error_function=None`` set on the wrapped tool, this
    # forces ``Runner.run`` to halt instead of relaying the block as
    # an ordinary tool result. See
    # the block-to-observation silent-bypass class.
    tool_wrapper_raise_on_block=True,
)


# ---------------------------------------------------------------------------
# Composition pattern — install with_openai_agents() and
# create_openai_agents_agent() at import time.
# ---------------------------------------------------------------------------


def _install() -> None:
    """Monkey-install :meth:`ShieldBuilder.with_openai_agents`,
    :meth:`Shield.create_openai_agents_agent`,
    :meth:`Shield.as_input_guardrail`, and
    :meth:`Shield.as_output_guardrail`."""

    def with_openai_agents(self: ShieldBuilder) -> ShieldBuilder:
        """Bind this builder to the OpenAI Agents framework bundle."""
        return self._bind_to_bundle(_BUNDLE)

    def create_openai_agents_agent(
        self: Shield,
        tools: list,
        *,
        model: str,
        system_prompt: str = "",
        name: str = "assistant",
        **agent_kwargs: Any,
    ) -> Any:
        """Build a fully guarded OpenAI Agent in one call (Pattern A).

        ``model`` is the *customer agent's* model — the LLM that drives
        the agent's own reasoning loop. It is **required**: a security
        library MUST NOT pick a model on the customer's behalf. It is
        **not** the model used by the AgentShield validation stages
        (those are driven by the ``configurations[]`` block in
        ``.guardrails.yaml`` and resolved per-stage via the runtime).
        """
        from agents import Agent

        protected = self.protect_tools(tools)
        agent = Agent(
            name=name,
            instructions=system_prompt,
            tools=protected,
            model=model,
            **agent_kwargs,
        )
        return self.guard(agent)

    def as_input_guardrail(self: Shield) -> Any:
        """Return an OpenAI Agents SDK ``@input_guardrail``-decorated
        function that runs Stage 1 (input validation) against the
        user's input. The returned object can be passed directly to
        ``Agent(input_guardrails=[...])``::

            from agents import Agent, Runner
            from agent_shield import Shield
            import agent_shield.adapters.openai_agents

            shield = (
                Shield.from_yaml("guardrails.yaml")
                .with_openai_agents()
                .with_client(client)
                .build()
            )
            agent = Agent(
                name="assistant",
                instructions="...",
                tools=[...],
                input_guardrails=[shield.as_input_guardrail()],
                output_guardrails=[shield.as_output_guardrail()],
            )
            # OAI Runner enforces Stage 1 / Stage 5 natively; tripped
            # guardrails raise InputGuardrailTripwireTriggered /
            # OutputGuardrailTripwireTriggered which the host catches.
            result = await Runner.run(agent, "user input")

        This is the most idiomatic OAI Agents SDK integration — it
        doesn't require ``shield.guard(agent)`` wrapping. Use it when
        you want AgentShield to participate in OAI's native guardrail
        contract; use :meth:`guard` when you also want bundle-driven
        tool wrapping (Stages 2/3/4).

        Coverage: Full for Stage 1 (the OAI Runner enforces tripwires
        as gates).
        """
        try:
            from agents import GuardrailFunctionOutput, input_guardrail
        except ImportError as e:
            raise RuntimeError(
                "openai-agents package is not installed. "
                "Install with `pip install openai-agents`."
            ) from e

        runtime = self.runtime

        async def _shield_input_guardrail(_ctx: Any, _agent: Any, user_input: Any) -> Any:
            text = user_input if isinstance(user_input, str) else str(user_input or "")
            with runtime.new_session() as session:
                session.begin_turn()
                blocked_message = check_stage1(session, text).block_message
            return GuardrailFunctionOutput(
                output_info={
                    "guardrail": "agent_shield",
                    "stage": "input",
                    "reason": blocked_message,
                },
                tripwire_triggered=blocked_message is not None,
            )

        return input_guardrail(_shield_input_guardrail)

    def as_output_guardrail(self: Shield) -> Any:
        """Return an OpenAI Agents SDK ``@output_guardrail``-decorated
        function that runs Stage 5 (output validation + redaction)
        against the agent's final output. See :meth:`as_input_guardrail`
        for usage.

        Coverage: Full for Stage 5 trip detection. Note: redactions
        from Stage 5 cannot be applied to the OAI agent's output stream
        because the SDK's guardrail contract only signals tripwire
        (block) — it has no mechanism to mutate the output. Use
        :meth:`guard` (Pattern A) if you need redaction propagation.
        """
        try:
            from agents import GuardrailFunctionOutput, output_guardrail
        except ImportError as e:
            raise RuntimeError(
                "openai-agents package is not installed. "
                "Install with `pip install openai-agents`."
            ) from e

        runtime = self.runtime

        async def _shield_output_guardrail(_ctx: Any, _agent: Any, output: Any) -> Any:
            text = output if isinstance(output, str) else str(output or "")
            tripped = False
            reason: Optional[str] = None
            with runtime.new_session() as session:
                session.begin_turn()
                outcome = session.validate_output(text)
                if not outcome.verdict.allowed and outcome.verdict.action == "block":
                    tripped = True
                    reason = outcome.verdict.reason or "blocked by output_validation"
            return GuardrailFunctionOutput(
                output_info={
                    "guardrail": "agent_shield",
                    "stage": "output",
                    "reason": reason,
                },
                tripwire_triggered=tripped,
            )

        return output_guardrail(_shield_output_guardrail)

    ShieldBuilder.with_openai_agents = with_openai_agents
    Shield.create_openai_agents_agent = create_openai_agents_agent
    Shield.as_input_guardrail = as_input_guardrail
    Shield.as_output_guardrail = as_output_guardrail


_install()


def _install_runner_shim() -> None:
    """Make ``Runner.run(guarded, input, ...)`` work like ``guarded.run(input, ...)``.

    The OpenAI Agents SDK's canonical entry point is
    ``Runner.run(agent, input)``. ``GuardedRunner`` / ``GuardedAgent``
    instead expose ``guarded.run(input)`` which drives the full
    Stage 1 → execute → Stage 5 critical section and sets the
    ``current_session`` ContextVar that wrapped tools read.

    Without this shim, customers naturally reach for
    ``Runner.run(guarded, "...")`` — which works syntactically (the
    ``GuardedRunner.__getattr__`` proxy makes ``guarded.tools`` /
    ``guarded.model`` / ``guarded.instructions`` resolve to the wrapped
    agent's attributes) but bypasses every AgentShield stage:

    * Stage 1 (input validation) never runs.
    * The ``current_session`` ContextVar is never set, so wrapped
      tools fail-closed with ``UnguardedToolInvocation``.
    * Stage 5 (output validation / redaction) never runs.

    The fix intercepts ``Runner.run`` (and ``Runner.run_sync``) at
    adapter import time. When the first positional argument is a
    ``GuardedRunner``, the call is forwarded to ``guarded.run(input,
    **kwargs)`` — which is the documented Pattern A path. Plain
    ``Agent`` instances pass through to the original ``Runner.run``
    unchanged.

    Re-import safe: a sentinel attribute on the patched function
    prevents double-patching if the adapter module is reloaded.

    Why this isn't ``RunHooks``: openai-agents ``RunHooks`` /
    ``AgentHooks`` callbacks cannot block a turn before the LLM call
    (they have no return value), cannot synthesise a
    ``_BlockedResult`` shape, and cannot mutate the input or output
    in-flight. Dispatching to ``guarded.run`` re-uses the
    battle-tested critical section instead of re-implementing it on
    top of the hooks contract.

    Why not just rely on the customer calling ``guarded.run``: the
    OpenAI Agents SDK's docs, examples, and IDE autocomplete all
    point at ``Runner.run(agent, input)`` as the canonical entry
    point. A security library that silently fails-closed when
    customers use the framework's canonical entry point is a
    usability bug.
    """
    try:
        from agents import Runner
    except ImportError:
        # openai-agents not installed at adapter import time — nothing
        # to patch. Re-attempt on next import (the shim is idempotent).
        return

    if getattr(getattr(Runner, "run", None), "__agent_shield_shimmed__", False):
        return

    # ``Runner.run`` and ``Runner.run_sync`` are classmethods; unwrap
    # to the underlying functions so the shim can pass ``cls`` through
    # when forwarding to the original.
    try:
        _orig_run = Runner.run.__func__
        _orig_run_sync = Runner.run_sync.__func__
    except AttributeError:
        # Future versions might change Runner.run to a regular method
        # or staticmethod. In that case, skip patching rather than
        # corrupt the contract — the improved error message at
        # ``_unguarded_message`` still tells the customer what to do.
        logger.debug(
            "agents.Runner.run/run_sync is not a classmethod; "
            "skipping Runner shim install.",
        )
        return

    async def run(cls, starting_agent, input, **kwargs):
        if isinstance(starting_agent, GuardedRunner):
            # Hand off to the GuardedRunner's full Stage 1 / Stage 5
            # critical section. ``guarded.run`` forwards remaining
            # kwargs (``max_turns``, ``context``, ``hooks``, ...) to
            # the framework via ``boundary.run`` → ``Runner.run``,
            # where THIS shim's ``isinstance`` check will see the
            # underlying ``Agent`` (not a ``GuardedRunner``) and fall
            # through to the original implementation — so no infinite
            # recursion.
            return await starting_agent.run(input, **kwargs)
        return await _orig_run(cls, starting_agent, input, **kwargs)

    run.__name__ = _orig_run.__name__
    run.__qualname__ = _orig_run.__qualname__
    run.__doc__ = _orig_run.__doc__
    run.__wrapped__ = _orig_run
    run.__agent_shield_shimmed__ = True

    def run_sync(cls, starting_agent, input, **kwargs):
        if isinstance(starting_agent, GuardedRunner):
            import asyncio as _asyncio

            return _asyncio.run(starting_agent.run(input, **kwargs))
        return _orig_run_sync(cls, starting_agent, input, **kwargs)

    run_sync.__name__ = _orig_run_sync.__name__
    run_sync.__qualname__ = _orig_run_sync.__qualname__
    run_sync.__doc__ = _orig_run_sync.__doc__
    run_sync.__wrapped__ = _orig_run_sync
    run_sync.__agent_shield_shimmed__ = True

    Runner.run = classmethod(run)
    Runner.run_sync = classmethod(run_sync)


_install_runner_shim()

# Register this bundle as the auto-bind default for new ShieldBuilder instances.
from . import _bundle_registry as _registry  # noqa: E402
_registry.register(_BUNDLE)


# ---------------------------------------------------------------------------
# Module-level helpers (Level 1 API)
# ---------------------------------------------------------------------------


def make_llm_caller(
    client: Any,
    configuration_resolver: Optional[
        Callable[[Optional[str]], Optional[dict]]
    ] = None,
) -> Callable[[Optional[str], str], str]:
    """Create an LLM caller from an OpenAI client.

    Module-level shortcut for :meth:`_LlmCallerFactory.make_caller`.
    Pass ``configuration_resolver=runtime.llm_configuration`` to honour
    the YAML's per-stage ``model:`` selection. When the resolver
    returns a configuration without ``model:`` (or no matching entry
    at all), the caller raises
    :class:`ConfigurationMissingModelError` rather than silently
    picking a model on the customer's behalf.
    """
    return _BUNDLE.llm_caller_factory.make_caller(
        client, configuration_resolver=configuration_resolver,
    )


def protect_tools(
    runtime: Runtime,
    tools: list,
    user_input_getter: Optional[Callable[[], str]] = None,
    *,
    allow_unguarded: bool = False,
) -> list:
    """Wrap OpenAI Agents tools with Stages 2 + 3 + 4 enforcement.

    Module-level shortcut for callers that want to use the runtime
    builder directly without going through :class:`Shield`. See
    :meth:`agent_shield.Shield.protect_tools` for the
    ``allow_unguarded`` flag.
    """
    return _protect_tools_via_wrapper(
        runtime, tools, _BUNDLE.tool_wrapper, user_input_getter,
        allow_unguarded=allow_unguarded,
    )


__all__ = [
    "GuardedAgent",
    "make_llm_caller",
    "protect_tools",
]
