"""CrewAI integration for Agent Shield guardrails.

Capability-based adapter that plugs into the framework-agnostic
:class:`~agent_shield.adapters._shield.Shield` orchestrator.

CrewAI tools execute synchronously (``BaseTool._run``) and CrewAI
exposes two distinct guard targets:

* :class:`GuardedAgent` — Stage 1 / Stage 5 helper methods you call
  manually around a CrewAI ``Agent`` (CrewAI agents don't expose a
  generic ``run``/``invoke``).
* :class:`GuardedCrew` — wraps ``Crew.kickoff`` with full Stage 1 +
  Stage 5 enforcement.

Because CrewAI tools are sync, the wrapper sidesteps the orchestrator's
async ``invoke`` flow and uses the sync orchestration helper directly.

**Level 2 — Shield helper** (recommended)::

    from agent_shield import Shield
    import agent_shield.adapters.crewai  # side-effect import

    shield = (
        Shield.from_yaml("guardrails.yaml")
        .with_crewai()
        .with_client(llm)
        .build()
    )
    tools  = shield.protect_tools(tools)
    crew   = shield.guard_crew(crew)
"""
from __future__ import annotations

import asyncio
import logging
import sys
from typing import Any, AsyncIterator, Callable, Optional

from agent_shield import Runtime, Session

from ._capabilities import (
    AgentBoundary,
    CapabilityReport,
    CoverageLevel,
    FrameworkBundle,
    GuardedInvoke,
    LlmCallerFactory,
    StreamingAdapter,
    StreamingValidator,
    ToolMetadata,
    ToolWrapper,
)
from ._orchestration import (
    AgentShieldBlocked,
    _format_block_message,
    check_stage1,
    current_session,
    current_user_input,
)
from ._shield import (
    Shield,
    ShieldBuilder,
    _protect_tools_via_wrapper,
)

logger = logging.getLogger("agent_shield.crewai")


# ---------------------------------------------------------------------------
# Capability 1 — LLM caller factory
# ---------------------------------------------------------------------------


#: Litellm-supported kwargs the adapter forwards from YAML
#``configurations[]`` entries when present in cfg. ``api_key`` is
#: deliberately omitted: the spec's YAML schema only allows
#``api_key_env`` (an *env var name* indirection), and silently
#: forwarding raw keys from a hand-rolled resolver would be an
#: easy-to-miss secrets-in-config foot-gun. Customers who need a
#: per-stage API key should set it via the environment / litellm
#: provider config.
_LITELLM_COMPLETION_KWARGS: tuple[str, ...] = (
    "max_tokens",
    "temperature",
    "top_p",
    "frequency_penalty",
    "presence_penalty",
    "stop",
    "api_base",
)


def _filter_litellm_kwargs(
    cfg: Optional[dict], model: Optional[str],
) -> dict[str, Any]:
    """Build the ``litellm.completion(...)`` kwargs subset from cfg.

    Returns only kwargs whose values are not ``None`` and which appear
    in :data:`_LITELLM_COMPLETION_KWARGS`. When ``model`` is provided
    and ``litellm.get_supported_openai_params`` is available, the
    returned set is intersected with the model's per-provider
    supported-params list so that, e.g., a Gemini deployment doesn't
    receive ``frequency_penalty`` it would error on. Falls back to the
    static list if introspection is unavailable.
    """
    if not cfg:
        return {}

    supported: Optional[set[str]] = None
    if model:
        try:
            import litellm  # local import — only when cfg is non-empty

            params = litellm.get_supported_openai_params(model=model)
            if params:
                supported = set(params)
        except Exception:
            logger.debug(
                "crewai llm caller: litellm.get_supported_openai_params"
                "(model=%r) failed; falling back to the static "
                "kwargs list.",
                model, exc_info=True,
            )
            supported = None

    out: dict[str, Any] = {}
    for key in _LITELLM_COMPLETION_KWARGS:
        value = cfg.get(key)
        if value is None:
            continue
        if supported is not None and key not in supported:
            logger.debug(
                "crewai llm caller: dropping cfg kwarg %r (model %r "
                "does not list it in litellm's supported params).",
                key, model,
            )
            continue
        out[key] = value
    return out


def _build_crewai_llm_override(llm: Any, cfg: Optional[dict]) -> Any:
    """Return a per-call ``crewai.LLM`` clone with cfg overrides applied.

    Uses pydantic v2's ``model_copy(update={...})`` so the customer's
    LLM instance is not mutated across stages. Falls back to the
    original instance if the LLM doesn't expose ``model_copy``
    (defensive — older / forked LLM types).
    """
    if not cfg:
        return llm

    fields = getattr(type(llm), "model_fields", None)
    if not fields:
        return llm

    candidate_keys = (
        "model",
        "max_tokens",
        "temperature",
        "top_p",
        "frequency_penalty",
        "presence_penalty",
        "stop",
        "api_base",
    )
    update: dict[str, Any] = {}
    for key in candidate_keys:
        value = cfg.get(key)
        if value is None:
            continue
        if key in fields:
            update[key] = value

    if not update:
        return llm

    copy = getattr(llm, "model_copy", None)
    if copy is None or not callable(copy):
        logger.debug(
            "crewai llm caller: crewai.LLM lacks model_copy; "
            "skipping cfg overrides for this call.",
        )
        return llm
    try:
        return copy(update=update)
    except Exception:
        logger.debug(
            "crewai llm caller: crewai.LLM.model_copy(update=%r) "
            "raised; falling back to the un-overridden instance.",
            update, exc_info=True,
        )
        return llm


def _bind_langchain_overrides(llm: Any, cfg: Optional[dict]) -> Any:
    """Best-effort ``.bind(...)`` for LangChain ``Runnable`` shapes.

    Mirrors the LangChain adapter's caller (``langchain.py``): forwards
    only ``max_tokens`` and ``temperature``. ``model`` is intentionally
    NOT bound — a pre-constructed ``BaseChatModel`` has the provider's
    API key / endpoint / deployment locked to the model the customer
    chose, and silently swapping the model would bypass that.
    """
    if not cfg:
        return llm
    bind = getattr(llm, "bind", None)
    if bind is None or not callable(bind):
        return llm
    bind_kwargs: dict[str, Any] = {}
    if cfg.get("max_tokens") is not None:
        bind_kwargs["max_tokens"] = cfg["max_tokens"]
    if cfg.get("temperature") is not None:
        bind_kwargs["temperature"] = cfg["temperature"]
    if not bind_kwargs:
        return llm
    try:
        return bind(**bind_kwargs)
    except Exception:
        logger.debug(
            "crewai llm caller: BaseChatModel.bind(%r) raised; "
            "falling back to the un-bound instance.",
            bind_kwargs, exc_info=True,
        )
        return llm


class _LlmCallerFactory(LlmCallerFactory):
    """Adapt a CrewAI-compatible LLM (LLM / string / langchain / callable).

    CrewAI accepts five LLM shapes. The ``configuration_resolver``
    plumbs YAML ``configurations[]`` overrides through where each
    shape allows:

    * ``str`` (litellm model name) — every kwarg in
      :data:`_LITELLM_COMPLETION_KWARGS` (plus ``model``) is forwarded
      to ``litellm.completion``. The kwargs are filtered against
      ``litellm.get_supported_openai_params(model)`` at call time so
      that, e.g., a Gemini model doesn't receive ``presence_penalty``
      it can't honor.
    * ``crewai.LLM`` — per-call ``model_copy(update={...})`` clone
      with cfg overrides applied to the matching pydantic fields
      (``model``, ``max_tokens``, ``temperature``, ``top_p``,
      ``frequency_penalty``, ``presence_penalty``, ``stop``,
      ``api_base``). The customer instance is not mutated.
    * LangChain ``BaseChatModel`` (``.invoke``) — best-effort
      ``.bind(max_tokens=..., temperature=...)``; ``model`` is left
      alone (provider config is bound on the customer's instance).
    * Generic ``.call``-shaped LLM — no-op. The contract on ``.call``
      is a chat-message list only; the model is bound on the customer
      object and there's no provider-agnostic way to override.
    * Plain callable ``llm(prompt)`` — no-op. The callable signature
      is a single string in / string out; there's nowhere to plumb cfg.

    For the no-op shapes the fallback DEBUG log still fires so
    customers can correlate stage routing with their LLM choice.

    ``DEFAULT_FALLBACK_MODEL`` is a documentation marker for the
    diagnostic log; it does not override the customer's bound model.
    """

    #: Documentation marker — used only in fallback DEBUG logs to
    #: correlate stage routing with the customer's LLM choice. For
    #: the ``str``-shaped LLM, the customer-supplied string is the
    #: actual default and this constant is unused at call time.
    DEFAULT_FALLBACK_MODEL = "customer-supplied CrewAI LLM"

    def make_caller(
        self,
        llm: Any,
        *,
        configuration_resolver: Optional[
            Callable[[Optional[str]], Optional[dict]]
        ] = None,
    ) -> Callable[[Optional[str], str], str]:
        fallback_model = self.DEFAULT_FALLBACK_MODEL

        def caller(configuration_id: Optional[str], prompt: str) -> str:
            cfg: Optional[dict] = None
            if configuration_resolver is not None and configuration_id:
                try:
                    cfg = configuration_resolver(configuration_id)
                except Exception:
                    # Resolver lookup must never break the LLM caller —
                    # fall through to the documented fallback path.
                    logger.exception(
                        "crewai llm caller: configuration_resolver "
                        "raised for configuration_id=%r; falling back to "
                        "the customer-supplied LLM (%r).",
                        configuration_id,
                        fallback_model,
                    )
                    cfg = None

            if cfg is None and configuration_id:
                # Only DEBUG-log on the genuine SRE signal — a stage
                # asked for routing and didn't get it. The "no
                # routing requested" case (configuration_id ``None``
                # / ``""``) is a legitimate fallback. Mirrors the
                # OpenAI / Anthropic / SK Python adapters.
                logger.debug(
                    "crewai llm caller: no `configurations[]` entry "
                    "matched configuration_id=%r; invoking the customer-"
                    "supplied LLM without per-call overrides. Declare "
                    "`configurations: - {id: %s, type: llm, model: ..., "
                    "max_tokens: ..., temperature: ...}` in "
                    "`.guardrails.yaml` to forward invocation params "
                    "(model only applies when the customer-supplied LLM "
                    "is a litellm model-name string or a crewai.LLM).",
                    configuration_id,
                    configuration_id or "<unset>",
                )

            try:
                # Use ``BaseLLM`` (not ``LLM``): ``crewai.LLM(model=...)``
                # returns a provider-specific subclass (e.g.
                # ``OpenAICompletion``), not a ``LLM`` instance, so an
                # ``isinstance(llm, LLM)`` check is dead code. Every
                # crewai LLM subclass — including ``LLM`` itself — is a
                # pydantic ``BaseLLM``, which exposes
                # ``model_copy(update={...})`` for per-call overrides.
                from crewai import BaseLLM

                if isinstance(llm, BaseLLM):
                    target = _build_crewai_llm_override(llm, cfg)
                    response = target.call(
                        [{"role": "user", "content": prompt}],
                    )
                    return response if isinstance(response, str) else str(response)
            except ImportError:
                pass

            if isinstance(llm, str):
                from litellm import completion

                resolved_model = (cfg.get("model") if cfg else None) or llm
                completion_kwargs: dict = {
                    "model": resolved_model,
                    "messages": [{"role": "user", "content": prompt}],
                }
                completion_kwargs.update(
                    _filter_litellm_kwargs(cfg, resolved_model),
                )
                response = completion(**completion_kwargs)
                return response.choices[0].message.content or ""

            if hasattr(llm, "call"):
                # ``.call``-shaped LLM (non-crewai.LLM): the contract is
                # a chat-message list only — no per-call kwarg surface,
                # so cfg overrides are a no-op for this shape. The
                # diagnostic DEBUG log above still fires on fallback so
                # customers see stage routing.
                response = llm.call([{"role": "user", "content": prompt}])
                return response if isinstance(response, str) else str(response)

            if hasattr(llm, "invoke"):
                from langchain_core.messages import HumanMessage

                target = _bind_langchain_overrides(llm, cfg)
                response = target.invoke([HumanMessage(content=prompt)])
                return str(getattr(response, "content", response))

            if callable(llm):
                # Bare callable ``llm(prompt) -> str``: the signature has
                # no kwargs surface, so cfg overrides are a no-op for
                # this shape. The diagnostic DEBUG log above still fires.
                response = llm(prompt)
                return response if isinstance(response, str) else str(response)

            raise TypeError(
                f"Cannot create LLM caller from {type(llm).__name__}. "
                f"Expected a CrewAI LLM, a LangChain model, a string model "
                f"name, or a callable."
            )

        return caller


# ---------------------------------------------------------------------------
# Caller-agent discovery
# ---------------------------------------------------------------------------

#: Variable name the runtime exposes to ``allowed_when:`` /
#``evaluate_when[].expression:`` / ``applies_to.agents`` so policies
#: can gate on **which CrewAI agent** is dispatching the protected
#: tool (e.g. ``caller_agent == 'Editor'``). The CLI design-agent emits
#: this name in generated YAML for Editor-vs-Writer-style scenarios; the
#: adapter is what makes that gate actually fire.
_CALLER_AGENT_VAR = "caller_agent"


def _current_crewai_agent_role() -> Optional[str]:
    """Best-effort discovery of the CrewAI agent dispatching the current tool.

    CrewAI does not expose a public "currently executing agent" API.
    The ``crewai.tools.tool_usage.ToolUsage`` instance that dispatches
    ``tool.invoke(...)`` (and therefore our wrapped tool's ``_run``)
    carries the executing agent on ``self.agent``; we walk the live
    Python call stack to find that frame and read ``self.agent.role``.

    Class names are matched by string (not ``isinstance``) so the
    adapter does not impose a top-level ``import crewai.tools.tool_usage``
    on customers and does not break when CrewAI reshuffles internal
    module paths between minor versions. Both the standard ``Agent``
    (``BaseAgent``) and ``LiteAgent`` paths expose ``.role``.

    Returns ``None`` when no CrewAI agent is on the stack (e.g. a
    protected tool was invoked outside any crew, or via a non-standard
    dispatcher). The caller treats ``None`` as "leave the variable
    unset" so guard-policy expressions like ``caller_agent == 'Editor'``
    fail-closed (an unset variable resolves to ``null``,
    and ``null == 'Editor'`` is ``false``).
    """
    try:
        frame = sys._getframe(1)
    except ValueError:  # pragma: no cover — interpreter shutdown
        return None

    # Walk up the stack. Bound the depth to avoid pathological loops.
    depth = 0
    while frame is not None and depth < 100:
        local_self = frame.f_locals.get("self")
        if local_self is not None:
            cls_name = type(local_self).__name__
            # The CrewAI dispatch class: ``crewai.tools.tool_usage.ToolUsage``
            # is the only frame that owns the executing agent reference.
            # ``BaseAgentTool`` (delegate / ask-question) wraps a
            # downstream ToolUsage internally so the same matcher
            # still finds the *direct* executor's role.
            if cls_name == "ToolUsage":
                agent = getattr(local_self, "agent", None)
                if agent is not None:
                    role = getattr(agent, "role", None)
                    if isinstance(role, str) and role:
                        return role
        frame = frame.f_back
        depth += 1
    return None


def _bind_caller_agent_if_present(session: Any) -> Optional[str]:
    """Read the executing CrewAI agent role and bind it to ``caller_agent``.

    Returns the role string (so callers can reset it later) or ``None``
    when no CrewAI agent was found on the stack. When ``None`` is
    returned the variable is **left unset** so policies fail-closed
    (null semantics).
    """
    role = _current_crewai_agent_role()
    if role is None:
        return None
    try:
        session.set_variable(_CALLER_AGENT_VAR, role)
    except Exception:  # noqa: BLE001 — never fail the tool over telemetry
        logger.debug(
            "set_variable(%r, ...) raised; caller_agent binding skipped",
            _CALLER_AGENT_VAR, exc_info=True,
        )
        return None
    return role


# ---------------------------------------------------------------------------
# Capability 2 — Tool wrapper (sync)
# ---------------------------------------------------------------------------


class _ToolWrapper(ToolWrapper):
    """Wrap a CrewAI ``BaseTool`` with a sync guarded subclass.

    CrewAI tools execute synchronously. ``_run`` drives the
    orchestrator-provided async ``guarded_invoke`` (which has runtime,
    ``allow_unguarded``, and verdict dispatch baked in) via a dedicated
    ``asyncio`` event loop so the SDK never reimplements the fail-closed
    session resolution or Stage 2/3/4 wiring.
    """

    def extract(self, tool: Any) -> ToolMetadata:
        return ToolMetadata(
            name=tool.name,
            description=tool.description,
            extras={"args_schema": getattr(tool, "args_schema", None)},
        )

    async def invoke(self, original: Any, params: dict) -> Any:
        # Hand back the RAW Python value (whatever ``_run``
        # produced) so the post-tool variable engine and any
        # ``preserve_raw_result=True`` consumer see the structured
        # shape rather than a stringified Python repr. Pydantic
        # ``BaseModel`` outputs are normalised to a plain ``dict``
        # via ``model_dump(mode="json")`` so the pyo3 ``py_to_json_value``
        # bridge can lift them into ``Value::Object`` directly — without
        # this, ``BaseModel`` instances fall back to the ``obj.str()``
        # FFI path (Python repr; single-quoted; ``True`` not ``true``)
        # which defeats ``@result.X`` extraction. ``dict``, ``list``,
        # and primitive scalars pass through unchanged. Mirrors the
        # AutoGen ``_ToolWrapper.invoke`` behavior.
        output = original._run(**params)
        try:
            from pydantic import BaseModel
        except Exception:  # noqa: BLE001
            BaseModel = None  # type: ignore[assignment]
        if BaseModel is not None and isinstance(output, BaseModel):
            return output.model_dump(mode="json")
        return output

    def wrap(
        self,
        original: Any,
        metadata: ToolMetadata,
        guarded_invoke: GuardedInvoke,
    ) -> Any:
        from crewai.tools import BaseTool

        _orig = original
        _name = metadata.name
        _desc = metadata.description
        _guarded = guarded_invoke

        class _GuardedTool(BaseTool):
            name: str = _name
            description: str = _desc
            model_config = {"arbitrary_types_allowed": True}

            def _run(self, **kwargs: Any) -> Any:
                user_input = current_user_input.get("")

                # Bind ``caller_agent`` from the executing
                # CrewAI agent's role BEFORE Stage 2/3 so policies
                # with ``allowed_when: caller_agent == 'Editor'`` (or
                # ``applies_to.agents``) see the right value. The
                # variable is left unset when no CrewAI agent is on the
                # stack so ``caller_agent == 'Editor'`` fail-closes to
                # ``false`` null semantics — a tool invoked
                # outside a Crew cannot accidentally pass an
                # Editor-only gate.
                _session = current_session.get(None)
                if _session is not None:
                    _bind_caller_agent_if_present(_session)

                # Drive sync CrewAI tool dispatch through a dedicated event loop
                # and the preconfigured guarded_invoke closure. Blocks raise so
                # CrewAI treats them as structural tool failures, while successful
                # Stage-4 results preserve their raw structured Python shape.
                _loop = asyncio.new_event_loop()
                try:
                    return _loop.run_until_complete(
                        _guarded(kwargs, user_input),
                    )
                except AgentShieldBlocked as exc:
                    if _session is not None:
                        try:
                            _session.emit_event(
                                "incident.tool_blocked",
                                payload={
                                    "tool": exc.tool_name,
                                    "reason": exc.verdict_reason or exc.message,
                                },
                            )
                        except Exception:  # noqa: BLE001 — telemetry,
                            # never fail the raise over event emission
                            logger.debug(
                                "emit_event('incident.tool_blocked') raised",
                                exc_info=True,
                            )
                    raise
                finally:
                    _loop.close()

        init_kwargs: dict[str, Any] = {}
        schema = metadata.extras.get("args_schema")
        if schema is not None:
            init_kwargs["args_schema"] = schema
        return _GuardedTool(**init_kwargs)


# ---------------------------------------------------------------------------
# Capability 3 — Agent boundary (drives Crew.kickoff)
# ---------------------------------------------------------------------------


class _AgentBoundary(AgentBoundary):
    """Run a CrewAI ``Crew`` via ``kickoff`` and reshape its result.

    The "agent" parameter here is a CrewAI ``Crew`` (not a CrewAI
    ``Agent``). CrewAI Agents don't have a generic run/invoke surface;
    their orchestrated execution lives at the Crew level.
    """

    async def run(
        self, agent: Any, input_text: str, **kwargs: Any,
    ) -> Any:
        # CrewAI's kickoff is sync — call it directly.
        inputs = kwargs.pop("inputs", None)
        return agent.kickoff(inputs=inputs)

    def extract_output(self, result: Any) -> Optional[str]:
        return str(result) if result else None

    def apply_redaction(self, result: Any, redacted_text: str) -> Any:
        # CrewAI's kickoff returns plain text/CrewOutput; we surface
        # the redacted text directly.
        return redacted_text

    def make_blocked(self, message: str) -> Any:
        return message


# ---------------------------------------------------------------------------
# Capability 4 — Streaming (unsupported)
# ---------------------------------------------------------------------------


class _StreamingAdapter(StreamingAdapter):
    """CrewAI does not expose a streaming kickoff API."""

    async def stream(
        self,
        agent: Any,
        input_text: str,
        validator: StreamingValidator,
        **kwargs: Any,
    ) -> AsyncIterator[Any]:
        raise NotImplementedError(
            "CrewAI does not expose a streaming kickoff API"
        )
        yield  # pragma: no cover — make this a generator function


# ---------------------------------------------------------------------------
# Bundle
# ---------------------------------------------------------------------------


_BUNDLE = FrameworkBundle(
    name="crewai",
    llm_caller_factory=_LlmCallerFactory(),
    tool_wrapper=_ToolWrapper(),
    agent_boundary=_AgentBoundary(),
    streaming_adapter=None,
    capabilities=CapabilityReport(
        framework="crewai",
        streaming_output=CoverageLevel.UNSUPPORTED,
        notes=["CrewAI has no streaming kickoff API"],
    ),
    # CrewAI's ``BaseTool._run`` returns to the customer's
    # Python pipeline (Crew kickoff returns the tool outputs through
    # the agents' final answers), so structured returns must survive
    # without an ``ast.literal_eval`` round-trip on the customer's side.
    tool_wrapper_preserve_raw_result=True,
    # CrewAI's ``ToolUsage._use`` catches exceptions and treats
    # them as tool errors (incrementing the task's tool error counter
    # and surfacing the error message in a structurally distinct frame),
    # which is the right channel for a guardrail block — returning the
    # block message as the tool's normal observation lets the LLM
    # produce a confident-sounding final answer that contradicts the
    # block (silent-bypass class).
    tool_wrapper_raise_on_block=True,
)


# ---------------------------------------------------------------------------
# CrewAI-flavoured GuardedAgent (helpers, not a runner)
# ---------------------------------------------------------------------------


class GuardedAgent:
    """Wraps a CrewAI ``Agent`` with manual Stage 1 / Stage 5 helpers.

    CrewAI agents don't expose a clean ``invoke`` interface — most
    integrations validate at the crew/task level. This wrapper provides
    explicit ``validate_input`` / ``validate_output`` helpers so callers
    can wire them in by hand.
    """

    def __init__(
        self,
        runtime: Runtime,
        agent: Any,
        streaming_config: dict[str, Any] | None = None,
    ) -> None:
        self._runtime = runtime
        self._agent = agent
        self._streaming_config = streaming_config
        self._session: Session = self._runtime.new_session()
        try:
            self._session.begin_turn()
        except Exception:  # noqa: BLE001
            logger.debug("begin_turn raised; continuing", exc_info=True)

    def validate_input(self, user_input: str) -> str | None:
        """Stage 1 input validation (sync). Returns ``None`` if allowed."""
        token = current_session.set(self._session)
        try:
            return check_stage1(self._session, user_input).block_message
        finally:
            current_session.reset(token)

    def validate_output(
        self, output: str, user_input: str = "",
    ) -> tuple[bool, str]:
        """Stage 5 output validation (sync)."""
        outcome = self._session.validate_output(output)
        if not outcome.verdict.allowed:
            logger.warning(
                "[Stage 5] Output blocked (%s): %s",
                outcome.verdict.action, outcome.verdict.reason,
            )
            return False, _format_block_message(outcome.verdict)
        if outcome.response != output:
            logger.info("[Stage 5] Output redacted before delivery")
        return True, outcome.response

    @property
    def agent(self) -> Any:
        return self._agent

    def __getattr__(self, name: str) -> Any:
        return getattr(self._agent, name)

    def reset(self) -> None:
        try:
            self._session.end_turn()
        except Exception:  # noqa: BLE001
            pass
        self._session = self._runtime.new_session()
        try:
            self._session.begin_turn()
        except Exception:  # noqa: BLE001
            pass

    def __repr__(self) -> str:
        return f"GuardedAgent(runtime=..., agent={self._agent!r})"


# ---------------------------------------------------------------------------
# CrewAI-flavoured GuardedCrew (kickoff with Stage 1 + Stage 5)
# ---------------------------------------------------------------------------


class GuardedCrew:
    """Wraps a CrewAI ``Crew`` with Stage 1 + Stage 5 validation."""

    def __init__(self, runtime: Runtime, crew: Any) -> None:
        self._runtime = runtime
        self._crew = crew
        # The session is built lazily per-kickoff so the Request Context
        # envelope (/) can be populated with the kickoff's
        # user input — see ``kickoff()`` for details.
        self._session: Session = self._runtime.new_session()

    @staticmethod
    def _extract_user_input(inputs: Optional[dict[str, Any]]) -> str:
        """Concatenate string-valued inputs into the Stage 1 user_input string.

        CrewAI passes templating variables as a flat dict to
        ``Crew.kickoff(inputs=...)``. The customer brief usually keeps
        the user's free-form text in a single key (``"topic"``,
        ``"competitor_brief"``, ``"query"``), but no convention forces
        that — so we concatenate every string-valued entry in dict
        order. Non-string values are skipped (they're typically config
        knobs like model name / temperature, not user content).
        """
        if not inputs:
            return ""
        parts: list[str] = []
        for value in inputs.values():
            if isinstance(value, str) and value.strip():
                parts.append(value)
        return "\n".join(parts)

    def kickoff(self, inputs: dict[str, Any] | None = None) -> Any:
        """Run the crew with Stage 1 + Stage 5 validation.

        Each call rebuilds the session with the kickoff's user input
        bound on the Request Context envelope as
        ``extensions.user_input`` — surfaced to expressions as
        ``@context.extensions.user_input``. Without this
        binding, Stage 1 policies that gate on the kickoff input
        cannot read it: the runtime has no other channel from the
        Crew-orchestration boundary down to the policy evaluator.

        Spec basis: ``@context.*`` is the host-supplied
        Request Context surfaced as a read-only namespace.
        The fixed top-level fields are ``user_id`` / ``tenant_id`` /
        ``session_id`` / ``correlation_id`` / ``extensions``;
        arbitrary host-supplied data MUST go under
        ``extensions``. That makes the spec-compliant read path
        ``@context.extensions.user_input``. (CLI-generated YAML
        emitting ``@context.user_input`` directly is non-spec; the
        CLI design-agent prompt documents the correct shape.)

        Per-kickoff session rebuild is a deliberate behaviour change
        from the previous adapter behavior: ``per_session`` state will not
        carry across kickoffs. CrewAI's execution model treats each
        kickoff as a self-contained run, so per-session collapses to
        per-kickoff in this adapter.
        """
        user_input = self._extract_user_input(inputs)

        # Replace the session with one whose Request Context carries
        # the user input under ``extensions.user_input`` (the
        # spec-compliant slot for host-supplied custom fields per
        #). The well-known ``session_id`` / ``correlation_id``
        # are populated by the runtime when not supplied.
        extensions: dict[str, Any] = {}
        if user_input:
            extensions["user_input"] = user_input
        session = self._runtime.new_session(
            extensions=extensions or None,
        )
        self._session = session

        session.begin_turn()
        token = current_session.set(session)
        input_token = current_user_input.set("")
        try:
            if inputs:
                for key, value in inputs.items():
                    if isinstance(value, str) and value.strip():
                        verdict = session.validate_input(value)
                        if not verdict.allowed:
                            logger.warning(
                                "[Stage 1] Input '%s' blocked (%s): %s",
                                key, verdict.action, verdict.reason,
                            )
                            return _format_block_message(verdict)
                current_user_input.set(user_input)

            result = self._crew.kickoff(inputs=inputs)

            output_text = str(result) if result else ""
            if output_text:
                outcome = session.validate_output(output_text)
                if not outcome.verdict.allowed:
                    logger.warning(
                        "[Stage 5] Output blocked (%s): %s",
                        outcome.verdict.action, outcome.verdict.reason,
                    )
                    return _format_block_message(outcome.verdict)
                if outcome.response != output_text:
                    logger.info("[Stage 5] Output redacted before delivery")
                    return outcome.response

            return result
        finally:
            current_user_input.reset(input_token)
            current_session.reset(token)
            try:
                session.end_turn()
            except Exception:  # noqa: BLE001
                logger.debug("end_turn raised", exc_info=True)

    @property
    def crew(self) -> Any:
        return self._crew

    def __getattr__(self, name: str) -> Any:
        return getattr(self._crew, name)

    def reset(self) -> None:
        self._session = self._runtime.new_session()

    def __repr__(self) -> str:
        return f"GuardedCrew(runtime=..., crew={self._crew!r})"


# ---------------------------------------------------------------------------
# Composition pattern — install with_crewai() and create_crewai_agent().
# ---------------------------------------------------------------------------


def _install() -> None:
    """Monkey-install :meth:`ShieldBuilder.with_crewai`,
    :meth:`Shield.create_crewai_agent`, and :meth:`Shield.guard_crew`."""

    def with_crewai(self: ShieldBuilder) -> ShieldBuilder:
        """Bind this builder to the CrewAI framework bundle."""
        return self._bind_to_bundle(_BUNDLE)

    def create_crewai_agent(
        self: Shield,
        tools: list,
        *,
        role: str = "assistant",
        goal: str = "",
        backstory: str = "",
        llm: Any = None,
        **agent_kwargs: Any,
    ) -> Any:
        """Build a fully guarded native CrewAI ``Agent`` in one call.

        Returns a native :class:`crewai.Agent` instance whose ``tools``
        list has been rewrapped through :meth:`Shield.protect_tools`
        (Stages 2/3/4 enforcement semantics). Stage 1 and
        Stage 5 enforcement happen at the crew level via
        :meth:`Shield.guard_crew`; this matches CrewAI's execution
        model (agents don't have a generic ``invoke``/``run`` surface,
        and orchestrated execution lives at the Crew boundary).

        Returning a native ``Agent`` (vs. a custom wrapper) is required
        for downstream CrewAI APIs (``Task(agent=...)``,
        ``Crew(agents=[...], ...)``) — those validate their inputs
        through Pydantic and reject any object that isn't a real
        ``Agent`` instance.
        """
        from crewai import Agent

        protected = self.protect_tools(tools)
        return Agent(
            role=role,
            goal=goal,
            backstory=backstory,
            tools=protected,
            llm=llm,
            **agent_kwargs,
        )

    def guard_crew(self: Shield, crew: Any) -> "GuardedCrew":
        """Wrap a CrewAI Crew with Stages 1 + 5 enforcement."""
        gc = GuardedCrew(self.runtime, crew)
        # GuardedCrew is not a GuardedRunner — track via the same weakset
        # so observability and lifecycle callers still see it.
        self._guarded_runners.add(gc)
        return gc

    ShieldBuilder.with_crewai = with_crewai
    Shield.create_crewai_agent = create_crewai_agent
    Shield.guard_crew = guard_crew


_install()

# Register this bundle as the auto-bind default for new ShieldBuilder instances.
from . import _bundle_registry as _registry  # noqa: E402
_registry.register(_BUNDLE)


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


def make_llm_caller(
    llm: Any,
    configuration_resolver: Optional[
        Callable[[Optional[str]], Optional[dict]]
    ] = None,
) -> Callable[[Optional[str], str], str]:
    """Create an LLM caller from a CrewAI-compatible LLM.

    Pass ``configuration_resolver=runtime.llm_configuration`` to honour
    the YAML's per-stage selection. Forwarded cfg fields depend on the
    LLM shape; see :class:`_LlmCallerFactory` for the per-shape matrix.
    For ``str`` and ``crewai.LLM`` shapes ``model`` / ``max_tokens`` /
    ``temperature`` / ``top_p`` / ``frequency_penalty`` /
    ``presence_penalty`` / ``stop`` / ``api_base`` are honored; for
    LangChain shapes ``max_tokens`` / ``temperature`` are bound
    best-effort; for the ``.call`` / bare-callable shapes the resolver
    is informational and only the diagnostic DEBUG log fires.
    """
    return _BUNDLE.llm_caller_factory.make_caller(
        llm, configuration_resolver=configuration_resolver,
    )


def protect_tools(
    runtime: Runtime,
    tools: list,
    user_input_getter: Optional[Callable[[], str]] = None,
    *,
    allow_unguarded: bool = False,
    preserve_raw_result: bool = True,
    raise_on_block: bool = True,
) -> list:
    """Wrap CrewAI tools with Stages 2 + 3 + 4 enforcement.

    See :meth:`agent_shield.Shield.protect_tools` for the
    ``allow_unguarded`` flag.

    *preserve_raw_result* — when ``True`` (the default for
    CrewAI), the wrapped tool's ``_run`` returns the raw Stage-4
    result value (dict / list / etc.) instead of a stringified form.
    This matches CrewAI's tool-boundary semantics: ``BaseTool._run``
    returns to the customer's Python pipeline, not to an LLM
    trajectory, so structured returns survive without an
    ``ast.literal_eval`` round-trip.

    *raise_on_block* — when ``True`` (the default for CrewAI),
    a Stage 2/3/4 block raises :class:`AgentShieldBlocked` from
    ``_run`` instead of returning the block message as the tool's
    normal observation. CrewAI's ``ToolUsage._use`` catches the
    exception and treats the call as a tool error (incrementing
    ``Task.tools_errors`` and surfacing it through a distinct error
    channel) — closing the silent-bypass class where an LLM observed
    the block message string and produced a confident final answer
    that contradicted the block.

    Set both to ``False`` to restore the legacy contract (e.g. for
    tests that pin the historical string-observation shape).
    """
    return _protect_tools_via_wrapper(
        runtime, tools, _BUNDLE.tool_wrapper, user_input_getter,
        allow_unguarded=allow_unguarded,
        preserve_raw_result=preserve_raw_result,
        raise_on_block=raise_on_block,
    )


__all__ = [
    "AgentShieldBlocked",
    "GuardedAgent",
    "GuardedCrew",
    "make_llm_caller",
    "protect_tools",
]
