# Python Semantic Kernel adapter mediation

## Mediated paths
- `ShieldBuilder.with_semantic_kernel()` installs the bundle and wraps `KernelFunction` objects at `sdk/python/agent_shield/adapters/semantic_kernel.py:291`.
- `Shield.guard(agent)` / `create_semantic_kernel_agent()` route Stage 1 and Stage 5 through `sdk/python/agent_shield/adapters/semantic_kernel.py:372`.
- Plugin/function wrapping lives in `sdk/python/agent_shield/adapters/semantic_kernel.py:480`.

## Unsupported paths
- Invoking the original `KernelFunction` / plugin method directly.
- Using Semantic Kernel's streaming APIs; this adapter marks streaming unsupported.
- Running a raw kernel/agent without `shield.guard(...)` or wrapped plugin registration.

## Bypass risks
- Holding onto the original `KernelFunction` after `protect_plugin()` / `protect_functions()` returns a wrapped version.
- Replacing wrapped plugin functions in the kernel after the shield is installed.
- Assuming custom kernel middleware not wired through the adapter is mediated.

## Streaming behavior
- Streaming is not supported on the Python Semantic Kernel adapter. Rules 1-5 are therefore not applicable on this surface.

## Unknown tool-call shapes
- Stage-3 mutations that cannot be re-applied to Semantic Kernel arguments raise `AdapterStageMutationError` and fail closed, but there is no adapter-owned `incident.unknown_invocation_shape` emission for novel framework shapes.

## See also

See [Post-tool limits and dangerous patterns](../../../../../docs/POST_TOOL_LIMITS.md) and the [adapter-mediated path matrix](../../../../../docs/adapter-mediated-paths.md).
