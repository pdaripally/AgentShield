"""Shared orchestration helpers for the framework adapters.

These functions encapsulate the common Stage 1→5 and Stage 2→3→4
validation flows for the unified-resolver runtime
( :mod:`agent_shield`).  Framework-specific adapters supply hooks
for input/output extraction and blocked response formatting.

The helpers:

* Call :meth:`Session.begin_turn` / :meth:`Session.end_turn` around
  every guarded turn so the runtime sees turn boundaries.
* Use the verdict shapes ( :class:`StageVerdict` /
  :class:`ToolCallOutcome` / :class:`ToolOutputOutcome`).
* Record tool results via :meth:`Session.record_tool_success` /
  :meth:`Session.record_tool_failure`.

Verdict-handling decisions (block message formatting, "what should the
orchestrator do for this verdict") are delegated to
:func:`agent_shield._native.dispatch_stage_verdict` and
:func:`agent_shield._native.dispatch_tool_verdict`. Those are the
canonical, byte-equivalent decisions every SDK shares; only the
async wiring (begin_turn → execute → end_turn / record_tool_*) lives
here.
"""
from __future__ import annotations

import asyncio
import contextvars
import logging
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Optional, Sequence, Tuple

from agent_shield._native import (
    dispatch_stage_verdict as _native_dispatch_stage,
    dispatch_tool_verdict as _native_dispatch_tool,
    format_block_message as _native_format_block_message,
)

from ._capabilities import AdapterStageMutationError

logger = logging.getLogger("agent_shield")


@asynccontextmanager
async def _turn_lease(session: Any):
    if current_session.get(None) is session:
        yield
        return
    token = 0
    native = getattr(session, "_native", None)
    if native is None or not hasattr(native, "try_acquire_turn_lease"):
        yield
        return
    while token == 0:
        token = int(native.try_acquire_turn_lease())
        if token == 0:
            await asyncio.sleep(0)
    try:
        yield
    finally:
        try:
            native.release_turn_lease(token)
        except Exception:  # noqa: BLE001 — stale/closed release is best-effort
            logger.debug("turn lease release failed; ignoring", exc_info=True)

# Sentinel for the ``verdict=`` keyword arg in ``AgentShieldBlocked``.
# Distinguishes "caller did not pass ``verdict``" from "caller
# explicitly passed ``verdict=None``" (the legacy Stage-1/5 shape).
_UNSET: Any = object()


class AgentShieldBlocked(RuntimeError):
    """Raised when Agent Shield blocks an action.

    Used in two distinct contexts:

    1. **Stage 1 / Stage 5 verdict** — when a :class:`Shield` is built
       with ``on_block="raise"`` and a stage verdict denies an action,
       the orchestrator raises this exception with the stage's
       :class:`StageVerdict` attached on ``verdict`` (the
       ``tool_name`` is ``None`` in this case).

    2. **Stage 2 / 3 / 4 tool block** — when a framework tool
       wrapper (e.g. CrewAI's ``_GuardedTool._run``) has
       ``raise_on_block=True`` configured, a tool-call block raises
       this exception with the blocked tool's name on ``tool_name``.
       Lets the host framework treat the block as a structural failure
       of the tool call (CrewAI's ``ToolUsage._use`` catches it,
       increments ``Task.tools_errors``, and surfaces the error
       through a distinct channel) rather than as a normal observation
       string fed back to the LLM as the tool's return value.

    Attributes:
        tool_name: The blocked tool's name (Stage 2/3/4 path) or
            ``None`` (Stage 1/5 path).
        message: The canonical block message
            (``[GUARDRAIL BLOCK] ...``).
        verdict: The full :class:`StageVerdict` (Stage 1/5 path) or
            ``None`` (Stage 2/3/4 path; the tool-call dispatcher works
            with a verdict dict rather than the dataclass).
        verdict_action: The verdict's ``action`` field
            (``"block"`` / ``"warn"`` / etc.) where available.
        verdict_reason: The verdict's ``reason`` field where available.
        pending_resolution: For ``kind: human`` (and other resolvers
            that surface a structured pending-resolution envelope) the
            verdict carries a ``pending_resolution`` dict. Adapters
            stash it on the exception so a customer ``except
            AgentShieldBlocked`` handler can drive an approval UI
            without round-tripping through ``shield.last_pending_resolution``.
            ``None`` when the block has no pending-resolution shape.
        stage: Which stage produced the block —
            ``"stage_2"`` (state), ``"stage_3"`` (tool authorization),
            ``"stage_4"`` (post-tool) for the tool-block path; ``"stage_1"``
            or ``"stage_5"`` for the input/output path. ``None`` if the
            adapter that raised did not record the stage.

    Why returning the block as an exception (vs. a sentinel value)
    matters for the tool-block case:
        Returning the block message as the tool's normal return value
        lets the host framework feed the string to the LLM as an
        ordinary observation. For a destructive tool like
        ``approve_payment``, an LLM that sees
        ``[GUARDRAIL BLOCK] Tool 'approve_payment' blocked: ...`` as
        an observation can — and in practice does — produce a final
        answer that says "Approved" anyway, despite the underlying
        action having been blocked. Downstream consumers (audit logs,
        dashboards, alert pipelines) then see "Approved" and act on
        it. That is a SILENT BYPASS of the guardrail. Raising this
        exception escapes the normal tool-result channel.

    Defense-in-depth pairs with this exception:
        * Adapters MAY emit ``incident.tool_blocked`` on the session
          when this exception is raised so YAML Stage 5 policies can
          gate downstream output (``event.fired("incident.tool_blocked")``)
          on whether *any* tool was blocked in the current turn.
        * Hosts MAY catch :class:`AgentShieldBlocked` at the
          task/agent boundary to fail the entire task instead of
          letting the LLM produce a final answer at all.
    """

    def __init__(
        self,
        tool_name_or_verdict: Any = None,
        message: str = "",
        *,
        verdict: Any = _UNSET,
        verdict_action: Optional[str] = None,
        verdict_reason: Optional[str] = None,
        pending_resolution: Optional[dict] = None,
        stage: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        # Two-shape constructor:
        #   * positional string ⇒ tool-block path,
        #     ``tool_name_or_verdict`` is the blocked tool name.
        #   * ``verdict=`` keyword OR positional non-string ⇒
        #     Stage-1/5 verdict path (the historical shape that
        #     ``_resolve_block`` uses when ``on_block="raise"``).
        if verdict is not _UNSET:
            self.verdict: Any = verdict
            self.tool_name: Optional[str] = (
                tool_name_or_verdict
                if isinstance(tool_name_or_verdict, str)
                else None
            )
        elif isinstance(tool_name_or_verdict, str):
            self.tool_name = tool_name_or_verdict
            self.verdict = None
        else:
            self.tool_name = None
            self.verdict = tool_name_or_verdict
        self.verdict_action = verdict_action
        self.verdict_reason = verdict_reason
        self.pending_resolution = pending_resolution
        self.stage = stage


class UnguardedToolInvocation(RuntimeError):
    """A guarded tool was invoked outside any guarded session.

    Raised by :func:`_resolve_session` (and therefore by
    :func:`guarded_tool` / :func:`guarded_tool_sync` and the framework
    wrappers built by :func:`_protect_tools_via_wrapper`) when a tool
    produced by ``shield.protect_tools(...)`` is invoked with no
    explicit ``session=`` argument and no ambient session from
    :func:`guarded_turn` / :meth:`Shield.guard` / :meth:`Shield.run`.

    Why fail-closed by default:
        Silently minting a fresh :class:`~agent_shield.Session` drops
        every per-turn / per-session / multi-call variable, event
        latch, and approval state. A customer wiring stateful
        guardrails ("ask for human approval before issuing a refund",
        "rate-limit tool calls per session") would have those policies
        silently bypassed on any ad-hoc invocation.

        AGENTS.md "Sensible defaults > flags. The default behavior
        must match the spec's security posture (fail-closed)." So the
        fresh-session path is now opt-in via ``allow_unguarded=True``;
        the default raises.

    Customers who legitimately want one-shot ad-hoc invocations can
    opt in via ``shield.protect_tools(tools, allow_unguarded=True)``.
    """


def _unguarded_message(tool_name: str) -> str:
    return (
        f"Tool '{tool_name}' was invoked outside a guarded session. "
        "Wrap your agent with `shield.guard(agent)` so the wrapped tool "
        "runs inside the agent's guarded turn, or pass "
        "`allow_unguarded=True` to `shield.protect_tools(...)` to opt "
        "into ad-hoc invocation (fresh session per call; per_turn / "
        "per_session state will NOT carry across calls).\n\n"
        "OpenAI Agents SDK note: ``Runner.run(guarded, input)`` is "
        "supported via the adapter's runner shim, which is installed "
        "automatically when you ``import agent_shield.adapters.openai_agents`` "
        "(``Shield.with_openai_agents()`` imports it for you). If you "
        "are seeing this error from a wrapped tool invoked through "
        "``Runner.run(guarded, ...)``, confirm the adapter module is "
        "imported BEFORE the ``agents`` package's ``Runner`` is captured "
        "into a local variable; otherwise call ``guarded.run(input)`` "
        "directly so the ambient ``current_session`` ContextVar is set."
    )


# ---------------------------------------------------------------------------
# Per-turn ContextVars — set by guarded_turn, read by guarded_tool
# ---------------------------------------------------------------------------

current_session: contextvars.ContextVar = contextvars.ContextVar(
    "guardrail_session", default=None,
)
current_user_input: contextvars.ContextVar[str] = contextvars.ContextVar(
    "guardrail_user_input", default="",
)


# ---------------------------------------------------------------------------
# Verdict ↔ wire-shape bridge + canonical dispatch helpers
# ---------------------------------------------------------------------------

def _verdict_to_wire(verdict: Any) -> dict:
    """Convert a :class:`StageVerdict` dataclass to the canonical wire dict.

    Field names match the wire shape exactly so this is a 1:1 projection.
    Used as the input to the core dispatch FFI.
    """
    return {
        "allowed": getattr(verdict, "allowed", False),
        "action": getattr(verdict, "action", None),
        "reason": getattr(verdict, "reason", None),
        "policy": getattr(verdict, "policy", None),
        "evaluate_when_index": getattr(verdict, "evaluate_when_index", None),
        "bypassed_by_allowed_when": getattr(
            verdict, "bypassed_by_allowed_when", False,
        ),
        "redaction": getattr(verdict, "redaction", None),
        "appended": getattr(verdict, "appended", None),
        "prepended": getattr(verdict, "prepended", None),
    }


def _format_block_message(verdict: Any, *, prefix: str = "GUARDRAIL") -> str:
    """Build the canonical ``[GUARDRAIL ACTION] reason`` string.

    Thin bridge over :func:`agent_shield._native.format_block_message`
    so every SDK produces byte-equivalent strings. The ``prefix``
    parameter is preserved for back-compat but the canonical core
    formatter always emits ``GUARDRAIL``; non-default prefixes are
    rewritten on the result string.
    """
    msg = _native_format_block_message(_verdict_to_wire(verdict))
    if prefix != "GUARDRAIL" and msg.startswith("[GUARDRAIL "):
        msg = "[" + prefix + msg[len("[GUARDRAIL"):]
    return msg


def _dispatch_stage(
    verdict: Any,
    policy: str = "return_blocked",
    mode: str = "enforce",
) -> dict:
    """Canonical Stage 1 / Stage 5 verdict-handling decision.

    Returns the raw dict from the core dispatcher: ``{action: {kind,
    value?, message?}, record_block, override_to_proceed}``. Callers
    branch on ``action.kind`` to decide what to do.
    """
    return _native_dispatch_stage(_verdict_to_wire(verdict), policy, mode)


def _dispatch_tool(
    verdict: Any,
    tool_name: str,
    stage: str = "output",
    policy: str = "return_blocked",
    mode: str = "enforce",
) -> dict:
    """Canonical Stage 2/3/4 (tool-call) verdict-handling decision."""
    return _native_dispatch_tool(
        _verdict_to_wire(verdict), tool_name, stage, policy, mode,
    )


# ---------------------------------------------------------------------------
# guarded_turn — Stage 1 → execute → Stage 5 (with begin/end_turn)
# ---------------------------------------------------------------------------

async def guarded_turn(
    session: Any,
    user_input: str,
    execute: Callable[[str], Awaitable[Any]],
    extract_output: Callable[[Any], Optional[str]],
    apply_redaction: Callable[[Any, str], Any],
    make_blocked: Callable[[str], Any],
    *,
    agent_calls: Optional[Sequence[Tuple[str, dict]]] = None,
) -> Any:
    """Execute a full guarded agent turn through the runtime.

    Order of operations::

        begin_turn()
            (optional) validate_agent_call() — one per inbound inter-agent message
            Stage 1 — validate_input(user_input)
            execute()
            Stage 5 — validate_output(extract_output(result))
        end_turn()

    The Stage 1 / Stage 5 decision (block vs proceed vs
    proceed-with-mutation) is delegated to the canonical core
    dispatcher; only the async wiring lives here.

    Args:
        session: A :class:`~agent_shield.Session`.
        user_input: The user's input text.
        execute: Async callable that runs the framework agent with the
            post-Stage-1 effective input.
        extract_output: Extracts final text from the framework result.
        apply_redaction: Returns a modified result with redacted output.
        make_blocked: Creates a blocked response from a reason string.
        agent_calls: Optional sequence of ``(recipient_agent_name, params)``
            pairs for inbound inter-agent messages (AutoGen / CrewAI
            ``on_messages`` style). Each pair triggers
            :meth:`Session.validate_agent_call` BEFORE Stage 1, so guard
            policies with ``applies_to.agents: [...]`` actually fire when
            a sub-agent is invoked through the ``shield.guard(agent)``
            path. The first DENY short-circuits the turn — Stage 1
            (and the agent execution itself) do not run.
    """
    async with _turn_lease(session):
        session.begin_turn()
        try:
            # Pre-Stage-1: agent-call gates for inbound inter-agent messages.
            # Each (name, params) pair is one call into the recipient agent,
            # so each gets its own canonical invocation hash and verdict.
            if agent_calls:
                for agent_name, agent_params in agent_calls:
                    ac_outcome = session.validate_agent_call(
                        agent_name, agent_params or {},
                    )
                    ac_decision = _dispatch_stage(ac_outcome.verdict)
                    ac_action = ac_decision["action"]
                    if ac_action["kind"] == "return_blocked":
                        logger.warning(
                            "[Agent-call] Invocation of agent '%s' blocked: %s",
                            agent_name, ac_outcome.verdict.reason,
                        )
                        return make_blocked(ac_action["message"])
                    # `proceed_with_mutation` for agent calls is not threaded
                    # back into the framework's message containers today —
                    # mutated params live on `ac_outcome.params` for
                    # observability; mutation-aware re-routing is a future
                    # extension (see MEDIATION.md).

            # Stage 1
            verdict = session.validate_input(user_input or "")
            decision = _dispatch_stage(verdict)
            action = decision["action"]
            kind = action["kind"]
            if kind == "return_blocked":
                # Block notifications already flow through the
                # observability dispatcher as
                # ``guard_policy.<name>.evaluated`` events. Demote to
                # debug so hosts that never configured logging don't
                # see an unstructured ``[Stage 1] Input blocked:...``
                # line leak to stderr via Python's ``lastResort``
                # handler. See logging-style-guide.md Rule 5.
                logger.debug(
                    "[Stage 1] Input blocked (%s): %s",
                    verdict.action, verdict.reason,
                )
                return make_blocked(action["message"])
            effective_input = user_input or ""
            if kind == "proceed_with_mutation":
                effective_input = str(action.get("value") or effective_input)

            # Set context for tool closures
            session_token = current_session.set(session)
            input_token = current_user_input.set(effective_input)
            try:
                result = await execute(effective_input)
            finally:
                current_user_input.reset(input_token)
                current_session.reset(session_token)

            # Stage 5
            output_text = extract_output(result)
            if output_text and isinstance(output_text, str):
                outcome = session.validate_output(output_text)
                stage5 = _dispatch_stage(outcome.verdict)
                stage5_action = stage5["action"]
                stage5_kind = stage5_action["kind"]
                if stage5_kind == "return_blocked":
                    # See note on Stage 1 above — block notifications are
                    # canonical observability events; demote to debug to
                    # avoid leaking an unstructured ``[Stage 5] Output
                    # blocked:...`` line via the default ``lastResort``
                    # handler.
                    logger.debug(
                        "[Stage 5] Output blocked: %s", outcome.verdict.reason,
                    )
                    return make_blocked(stage5_action["message"])
                if stage5_kind == "proceed_with_mutation":
                    logger.info("[Stage 5] Output redacted before delivery")
                    # Use the runtime response as the canonical Stage-5 mutation.
                    result = apply_redaction(result, outcome.response)

            return result
        finally:
            try:
                session.end_turn()
            except Exception:  # noqa: BLE001 — best-effort end-of-turn
                logger.debug("end_turn() raised; ignoring", exc_info=True)


# ---------------------------------------------------------------------------
# Tool-call helpers — shared by sync and async paths
# ---------------------------------------------------------------------------

def _resolve_session(
    session: Any,
    runtime: Any,
    tool_name: str,
    create_warning: bool = True,
    *,
    allow_unguarded: bool = False,
) -> Any:
    """Pick the session to use for a tool invocation.

    Resolution order:
    1. Explicit ``session`` parameter
    2. Ambient session from :data:`current_session` (set by :func:`guarded_turn`)
    3. Fresh session from ``runtime.new_session()`` — **only when**
       ``allow_unguarded=True``. Otherwise raises
       :class:`UnguardedToolInvocation` (fail-closed default).
    """
    if session is not None:
        return session
    sess = current_session.get(None)
    if sess is not None:
        return sess
    if runtime is None:
        raise RuntimeError(
            "guarded_tool requires a session (pass session= or runtime=, "
            "or call from within guarded_turn)"
        )
    if not allow_unguarded:
        raise UnguardedToolInvocation(_unguarded_message(tool_name))
    if create_warning:
        logger.warning(
            "Tool '%s' invoked without ambient session — creating fresh "
            "session. State-dependent guardrails may not see prior context.",
            tool_name,
        )
    return runtime.new_session()


def _clean_params(params: Optional[dict]) -> dict:
    """Strip ``None`` values from params before validation.

    ``None`` entries can confuse the Stage 3 adversarial detector into
    flagging missing required inputs as parameter integrity issues.
    """
    if not params:
        return {}
    return {k: v for k, v in params.items() if v is not None}


def _execute_accepts_params(execute: Callable[..., Any]) -> bool:
    """Return ``True`` if ``execute`` accepts at least one positional arg.

    Falls back to ``False`` when the signature can't be inspected
    (e.g. some C-implemented callables) — preserves the legacy zero-arg
    behaviour for old callers.
    """
    import inspect

    try:
        sig = inspect.signature(execute)
    except (TypeError, ValueError):
        return False
    for p in sig.parameters.values():
        if p.kind in (
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            inspect.Parameter.VAR_POSITIONAL,
        ):
            return True
    return False


async def _invoke_execute(
    execute: Callable[..., Awaitable[Any]],
    effective_params: dict,
) -> Any:
    """Call ``execute`` with the Stage-3 *effective_params* if accepted.

    P12.5.3: framework adapters that pass a one-arg callable get the
    transformed params; legacy zero-arg callables keep working but
    forfeit Stage-3 transforms (only the orchestration helper itself
    can decide whether to pass them through).
    """
    if _execute_accepts_params(execute):
        return await execute(effective_params)
    return await execute()


def _invoke_execute_sync(
    execute: Callable[..., Any],
    effective_params: dict,
) -> Any:
    """Sync counterpart of :func:`_invoke_execute`."""
    if _execute_accepts_params(execute):
        return execute(effective_params)
    return execute()


def _adapter_mutation_block(
    tool_name: str, exc: AdapterStageMutationError,
) -> tuple[bool, str]:
    """Build the canonical block message for an adapter Stage-3 failure.

    Used when an adapter cannot honour Stage-3 ``redact`` / ``replace``
    transforms (e.g. it cannot mutate the framework's parameter
    container). Treated as a fail-closed Stage-3 block so a tool whose
    Stage-3 transform failed never runs with the un-transformed params.
    """
    reason = (
        f"Stage-3 transform failed for tool {tool_name}: {exc.cause}"
    )
    logger.warning(
        "[GUARDRAIL BLOCK] Tool '%s' blocked: %s", tool_name, reason,
    )
    verdict_wire = {
        "allowed": False,
        "action": "block",
        "reason": reason,
        "policy": None,
        "evaluate_when_index": None,
        "bypassed_by_allowed_when": False,
        "redaction": None,
        "appended": None,
        "prepended": None,
    }
    message = _native_format_block_message(verdict_wire)
    return True, message


async def guarded_tool(
    tool_name: str,
    params: dict,
    execute: Callable[..., Awaitable[Any]],
    user_input: str = "",
    *,
    session: Any = None,
    runtime: Any = None,
    tool_call_id: str | None = None,
    allow_unguarded: bool = False,
    pending_resolution_sink: Optional[Callable[[dict], None]] = None,
    preserve_raw_result: bool = False,
) -> tuple[bool, Any]:
    """Execute a guarded tool call through the runtime (async).

    Pipeline::

        Stage 2+3 — validate_tool_call(tool, params)
        execute(effective_params)
        Stage 4   — validate_tool_output(tool, output)
        record_tool_success / record_tool_failure

    The Stage 2/3/4 verdict-handling decision is delegated to the
    canonical :func:`agent_shield._native.dispatch_tool_verdict`; only
    the async wiring (executing the tool, recording resource-cycle
    events) lives here.

    *tool_call_id* — optional binding handle. When passed,
    Stage 4 uses it to find the SAME canonical invocation Stage 3
    admitted, even under concurrent same-name calls. Adapters should
    pass the upstream model's tool-call id (OpenAI ``tool_call.id``,
    Anthropic ``tool_use.id``, LangChain ``tool_call_id``, etc.).
    Omitting the id mints a per-call UUIDv4; a stable model-supplied
    id is preferred where available so traces and incidents can be
    correlated end-to-end.

    *allow_unguarded* — when ``True``, fall back to a fresh
    ``runtime.new_session()`` if no explicit ``session=`` and no
    ambient session are available (warning logged). When ``False``
    (the default), raise :class:`UnguardedToolInvocation` instead so
    stateful guardrails (per_turn / per_session) cannot be silently
    bypassed.

    *pending_resolution_sink* — optional callback invoked with the
    verdict's ``pending_resolution`` dict (shape: ``{tool, variable,
    prompt, request_id, kind}``) when a Stage 2/3 block carries one.
    Lets adapters surface the structured suspension shape to the host
    so the human-approval / tool-resolution UI can be driven without
    substring-matching the block message. Only fired on
    blocks; ``None`` verdicts do not invoke the sink.

    *preserve_raw_result* — when ``True``, the success-path return
    tuple's second element is the **raw** Stage-4 result value (dict /
    list / BaseModel / etc.) rather than the canonicalised string.
    The block-path message is still a string. Adapters whose tool
    boundary returns to Python user code (vs. the LLM trajectory)
    set this so structured returns survive the orchestration layer.
    Default ``False`` preserves the legacy string contract.

    Returns:
        ``(blocked, output)`` — when *blocked* is ``True`` the *output*
        is the block message that should be surfaced to the LLM agent.
        When *blocked* is ``False`` and *preserve_raw_result* is
        ``False`` the *output* is the (possibly redacted) tool result
        rendered as a string; when *preserve_raw_result* is ``True``
        the *output* is the raw Stage-4 result value.
    """
    sess = _resolve_session(
        session, runtime, tool_name, allow_unguarded=allow_unguarded,
    )
    if not user_input:
        user_input = current_user_input.get("")

    cleaned = _clean_params(params)
    # Stage 2 + 3
    call_outcome = sess.validate_tool_call(tool_name, cleaned, tool_call_id=tool_call_id)
    call_decision = _dispatch_tool(call_outcome.verdict, tool_name, stage="call")
    call_action = call_decision["action"]
    if call_action["kind"] == "blocked":
        verdict = call_outcome.verdict
        # Tool-call blocks are routine policy decisions; the
        # observability dispatcher already emits
        # ``tool.<name>.called`` + ``guard_policy.<name>.evaluated``
        # events for the same fact. Emitting a ``logger.warning`` on
        # the default ``lastResort`` handler additionally leaks an
        # unstructured ``[GUARDRAIL BLOCK] Tool '...' blocked:...``
        # line to stderr for hosts that never configured the
        # ``agent_shield`` logger. Route the diagnostic through
        # ``debug`` so opt-in operators still see it. See
        # logging-style-guide.md Rule 5.
        logger.debug(
            "[GUARDRAIL %s] Tool '%s' %sed: %s",
            (verdict.action or "block").upper(),
            tool_name,
            verdict.action or "block",
            verdict.reason,
        )
        # Surface the structured pending_resolution shape
        # (when present) to adapters so hosts can drive the human /
        # tool resolution UI without parsing the block message string.
        pending = getattr(verdict, "pending_resolution", None)
        if pending and pending_resolution_sink is not None:
            try:
                pending_resolution_sink(pending)
            except Exception:  # noqa: BLE001 — sink errors must not
                # mask the guardrail block; adapters that fail to
                # store the pending shape log debug-only.
                logger.debug(
                    "pending_resolution_sink raised", exc_info=True,
                )
        return True, call_action["message"]

    # Use any mutated params produced by Stage 3 (e.g. coerced types).
    effective_params = (
        call_outcome.params if call_outcome.params is not None else cleaned
    )

    # Execute the underlying tool.
    try:
        raw_output = await _invoke_execute(execute, effective_params)
    except AdapterStageMutationError as ame:
        # The adapter could not apply Stage-3 param transforms; treat
        # as a fail-closed Stage-3 block. The tool did NOT run, so we
        # deliberately skip Stage 4 and do not record success/failure
        # on the resource cycle.
        return _adapter_mutation_block(tool_name, ame)
    except Exception as exc:  # noqa: BLE001 — bubble up via Stage 4
        # Defensive PR3: ``str(exc)`` for arbitrary tool exceptions may
        # include the tool's input args in the message body (depends on
        # the tool author's exception class). Warn carries only the
        # exception type discriminator; the full message is debug-only.
        # The exc text still flows into Stage 4 via ``error_text`` for
        # the runtime to gate on — it is not lost, just not at info+.
        logger.warning("Tool '%s' raised %s", tool_name, type(exc).__name__)
        logger.debug("Tool '%s' raised: %s", tool_name, exc, exc_info=True)
        error_text = f"[tool error] {tool_name}: {exc}"
        try:
            sess.record_tool_failure(tool_name, str(exc))
        except Exception:  # noqa: BLE001
            logger.debug("record_tool_failure raised", exc_info=True)
        if call_outcome.admission_id is None:
            raise RuntimeError("Stage 3 allowed without admission_id") from None
        out_outcome = sess.validate_tool_output(call_outcome.admission_id, error_text)
        # Stage 4 over the error text. Use the bare-stage dispatcher so
        # the tool-name suffix doesn't appear twice on the inner block
        # message (we already include the tool in the error_text).
        err_decision = _dispatch_stage(out_outcome.verdict)
        if err_decision["action"]["kind"] == "return_blocked":
            return True, err_decision["action"]["message"]
        return False, str(out_outcome.result)

    # Stage 4: hand the RAW Python return value (dict / list /
    # BaseModel / str / etc.) to ``validate_tool_output`` instead of
    # eagerly stringifying. The post-tool variable engine extracts
    # `@result.X` field paths against the parsed shape, so a
    # ``FunctionTool`` that returns ``{'kyc_token': '...'}`` must reach
    # the extractor as an object — not as a Python-repr string like
    # ``"{'kyc_token': '...'}"`` (which fails ``DefaultExtractor`` JSON
    # parse because Python ``str(dict)`` is single-quoted, not JSON).
    # ``py_to_json_value`` accepts arbitrary Python values and falls
    # back to ``str()`` for non-JSON-serialisable inputs, so other
    # adapters whose tools already return strings see no behaviour
    # change.
    if call_outcome.admission_id is None:
        raise RuntimeError("Stage 3 allowed without admission_id")
    out_outcome = sess.validate_tool_output(call_outcome.admission_id, raw_output)
    out_decision = _dispatch_tool(out_outcome.verdict, tool_name, stage="output")
    out_action = out_decision["action"]
    if out_action["kind"] == "blocked":
        if out_decision["record_failure"]:
            try:
                sess.record_tool_failure(
                    tool_name, out_outcome.verdict.reason or "blocked",
                )
            except Exception:  # noqa: BLE001
                logger.debug("record_tool_failure raised", exc_info=True)
        return True, out_action["message"]

    # Stage 4 may have redacted the result. Use whichever shape Stage 4
    # produced and record a success on the resource cycle. The
    # framework-side return is always a string (the LLM trajectory's
    # tool-result slot is text); render the canonical shape via
    # ``str()`` so dict / list returns flow through unchanged. Adapters
    # that route the tool's return value back to Python user code (vs.
    # the LLM trajectory) set ``preserve_raw_result=True`` to suppress
    # the stringification and bubble the structured value up.
    final = out_outcome.result if out_outcome.result is not None else raw_output
    final_str = final if isinstance(final, str) else str(final)
    if out_decision["record_success"]:
        try:
            sess.record_tool_success(tool_name, final_str)
        except Exception:  # noqa: BLE001
            logger.debug("record_tool_success raised", exc_info=True)
    return False, (final if preserve_raw_result else final_str)


def guarded_tool_sync(
    tool_name: str,
    params: dict,
    execute: Callable[[], Any],
    user_input: str = "",
    *,
    session: Any = None,
    runtime: Any = None,
    tool_call_id: str | None = None,
    allow_unguarded: bool = False,
    pending_resolution_sink: Optional[Callable[[dict], None]] = None,
    preserve_raw_result: bool = False,
) -> tuple[bool, Any]:
    """Synchronous variant of :func:`guarded_tool` for sync-only frameworks.

    Same session resolution and pipeline as :func:`guarded_tool`. See
    :func:`guarded_tool` for the *tool_call_id*, *allow_unguarded*,
    *pending_resolution_sink*, and *preserve_raw_result* parameters.

    Returns:
        ``(blocked, output)`` — when *blocked* is ``True`` the *output*
        is the block message. When *blocked* is ``False`` the *output*
        shape depends on *preserve_raw_result* (default: stringified
        result; ``True``: raw Stage-4 result value).
    """
    sess = _resolve_session(
        session, runtime, tool_name, allow_unguarded=allow_unguarded,
    )
    if not user_input:
        user_input = current_user_input.get("")

    cleaned = _clean_params(params)
    # Stage 2 + 3
    call_outcome = sess.validate_tool_call(tool_name, cleaned, tool_call_id=tool_call_id)
    call_decision = _dispatch_tool(call_outcome.verdict, tool_name, stage="call")
    call_action = call_decision["action"]
    if call_action["kind"] == "blocked":
        verdict = call_outcome.verdict
        # See :func:`guarded_tool` for the routing rationale — block
        # notifications are observability events; demoted here to
        # avoid leaking an unstructured ``[GUARDRAIL BLOCK] Tool '...'
        # blocked:...`` line to stderr when the host hasn't
        # configured logging. See logging-style-guide.md Rule 5.
        logger.debug(
            "[GUARDRAIL %s] Tool '%s' %sed: %s",
            (verdict.action or "block").upper(),
            tool_name,
            verdict.action or "block",
            verdict.reason,
        )
        # See :func:`guarded_tool` for rationale.
        pending = getattr(verdict, "pending_resolution", None)
        if pending and pending_resolution_sink is not None:
            try:
                pending_resolution_sink(pending)
            except Exception:  # noqa: BLE001
                logger.debug(
                    "pending_resolution_sink raised", exc_info=True,
                )
        return True, call_action["message"]

    # P12.5.3: pass Stage-3 mutated params through to the framework
    # execute so redact/replace transforms reach the tool.
    effective_params = (
        call_outcome.params if call_outcome.params is not None else cleaned
    )

    # Execute the underlying tool.
    try:
        raw_output = _invoke_execute_sync(execute, effective_params)
    except AdapterStageMutationError as ame:
        # Fail-closed Stage-3 block — see guarded_tool() for rationale.
        return _adapter_mutation_block(tool_name, ame)
    except Exception as exc:  # noqa: BLE001
        # Defensive PR3: ``str(exc)`` for arbitrary tool exceptions may
        # include the tool's input args in the message body (depends on
        # the tool author's exception class). Warn carries only the
        # exception type discriminator; the full message is debug-only.
        # The exc text still flows into Stage 4 via ``error_text`` for
        # the runtime to gate on — it is not lost, just not at info+.
        logger.warning("Tool '%s' raised %s", tool_name, type(exc).__name__)
        logger.debug("Tool '%s' raised: %s", tool_name, exc, exc_info=True)
        error_text = f"[tool error] {tool_name}: {exc}"
        try:
            sess.record_tool_failure(tool_name, str(exc))
        except Exception:  # noqa: BLE001
            logger.debug("record_tool_failure raised", exc_info=True)
        if call_outcome.admission_id is None:
            raise RuntimeError("Stage 3 allowed without admission_id") from None
        out_outcome = sess.validate_tool_output(call_outcome.admission_id, error_text)
        err_decision = _dispatch_stage(out_outcome.verdict)
        if err_decision["action"]["kind"] == "return_blocked":
            return True, err_decision["action"]["message"]
        return False, str(out_outcome.result)

    # Hand the RAW Python return value to ``validate_tool_output``;
    # see :func:`guarded_tool` for the full rationale.
    if call_outcome.admission_id is None:
        raise RuntimeError("Stage 3 allowed without admission_id")
    out_outcome = sess.validate_tool_output(call_outcome.admission_id, raw_output)
    out_decision = _dispatch_tool(out_outcome.verdict, tool_name, stage="output")
    out_action = out_decision["action"]
    if out_action["kind"] == "blocked":
        if out_decision["record_failure"]:
            try:
                sess.record_tool_failure(
                    tool_name, out_outcome.verdict.reason or "blocked",
                )
            except Exception:  # noqa: BLE001
                logger.debug("record_tool_failure raised", exc_info=True)
        return True, out_action["message"]

    final = out_outcome.result if out_outcome.result is not None else raw_output
    final_str = final if isinstance(final, str) else str(final)
    if out_decision["record_success"]:
        try:
            sess.record_tool_success(tool_name, final_str)
        except Exception:  # noqa: BLE001
            logger.debug("record_tool_success raised", exc_info=True)
    return False, (final if preserve_raw_result else final_str)


# ---------------------------------------------------------------------------
# Stage 1 helper — pre-invoke check for adapters that don't run a full turn
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Stage1Decision:
    """Result of a Stage 1 (``input_validation``) pre-invoke check.

    Spec: a ``redact`` action on a content stage
    rewrites the subject and "the rewritten subject continues through
    downstream stages." Callers that own the agent invocation must
    forward :attr:`effective_input` (not the original ``user_input``)
    to the framework so the redacted text flows into the agent.

    Attributes
    ----------
    kind
        ``"proceed"`` when the input is allowed (possibly after
        redaction); ``"block"`` when Stage 1 returned a block verdict.
    effective_input
        On ``proceed``, the post-Stage-1 input the agent should see
        (the redacted subject if Stage 1 rewrote it, otherwise the
        original input). ``None`` on ``block``.
    block_message
        On ``block``, the formatted block message; ``None`` on
        ``proceed``.
    """

    kind: str
    effective_input: Optional[str]
    block_message: Optional[str]

    @property
    def is_blocked(self) -> bool:
        return self.kind == "block"


def check_stage1(session: Any, user_input: Optional[str]) -> Stage1Decision:
    """Run Stage 1 input validation only.

    Returns a :class:`Stage1Decision` describing whether the call may
    proceed and, on ``proceed``, the post-Stage-1 ``effective_input``
    that downstream stages must see.
    Designed for adapters whose ``before_invoke`` hook needs a
    decision ahead of the framework call.
    """
    if not user_input:
        return Stage1Decision(kind="proceed", effective_input=user_input, block_message=None)
    verdict = session.validate_input(user_input)
    decision = _dispatch_stage(verdict)
    action = decision["action"]
    kind = action["kind"]
    if kind == "return_blocked":
        return Stage1Decision(
            kind="block", effective_input=None, block_message=action["message"],
        )
    effective_input = user_input
    if kind == "proceed_with_mutation":
        effective_input = str(action.get("value") or user_input)
    return Stage1Decision(
        kind="proceed", effective_input=effective_input, block_message=None,
    )


__all__ = [
    "AgentShieldBlocked",
    "UnguardedToolInvocation",
    "current_session",
    "current_user_input",
    "guarded_turn",
    "guarded_tool",
    "guarded_tool_sync",
    "check_stage1",
    "Stage1Decision",
]
