"""AutoGen integration for Agent Shield guardrails.

Capability-based adapter that plugs into the framework-agnostic
:class:`~agent_shield.adapters._shield.Shield` orchestrator.

**Level 2 — Shield helper** (recommended)::

    from agent_shield import Shield
    import agent_shield.adapters.autogen  # side-effect import

    shield = (
        Shield.from_yaml("guardrails.yaml")
        .with_autogen()
        .with_client(model_client)
        .build()
    )
    tools  = shield.protect_tools(tools)
    agent  = shield.guard(agent)

**Level 3 — two-liner**::

    shield = (
        Shield.from_yaml("guardrails.yaml")
        .with_autogen()
        .with_client(model_client)
        .build()
    )
    agent = shield.create_autogen_agent(model_client, tools, system_message="...")
"""
from __future__ import annotations

import asyncio
import atexit
import concurrent.futures
import logging
from typing import Any, AsyncIterator, Callable, Optional

from agent_shield import Runtime

from ._capabilities import (
    AgentBoundary,
    CapabilityReport,
    CoverageLevel,
    FrameworkBundle,
    GuardedInvoke,
    LlmCallerFactory,
    StreamingAdapter,
    StreamingValidator,
    ToolMetadata,
    ToolWrapper,
)
from ._orchestration import (
    _dispatch_stage,
    current_session,
    current_user_input,
)
from ._shield import (
    GuardedRunner,
    Shield,
    ShieldBuilder,
    _protect_tools_via_wrapper,
)

logger = logging.getLogger("agent_shield.autogen")

# Shared thread pool for running async AutoGen callers synchronously.
_AUTOGEN_EXECUTOR = concurrent.futures.ThreadPoolExecutor(max_workers=1)
atexit.register(_AUTOGEN_EXECUTOR.shutdown, wait=False)


# ---------------------------------------------------------------------------
# Capability 1 — LLM caller factory
# ---------------------------------------------------------------------------


class _LlmCallerFactory(LlmCallerFactory):
    """Adapt an AutoGen ``ChatCompletionClient`` to the runtime caller shape.

    Unlike the OpenAI / Anthropic adapters, the model name is **not**
    set per-call here — the AutoGen ``ChatCompletionClient`` is
    constructed by the customer with the model bound at construction
    time (e.g. ``OpenAIChatCompletionClient(model="gpt-4o")``), and
    ``ChatCompletionClient.create(...)`` has no model override.
    ``configuration_resolver`` is therefore used best-effort:
    ``max_tokens`` / ``temperature`` from the YAML
    ``configurations[]`` entry are forwarded via
    ``extra_create_args``. ``DEFAULT_FALLBACK_MODEL`` is a
    documentation marker only.
    """

    #: Documentation marker for the AutoGen customer-supplied client's
    #: expected default. The adapter does NOT enforce this — it
    #: surfaces only in the fallback DEBUG log so customers can
    #: correlate stage routing with their own model choice.
    DEFAULT_FALLBACK_MODEL = "customer-bound ChatCompletionClient"

    def make_caller(
        self,
        model_client: Any,
        *,
        configuration_resolver: Optional[
            Callable[[Optional[str]], Optional[dict]]
        ] = None,
    ) -> Callable[[Optional[str], str], str]:
        from autogen_core.models import UserMessage

        fallback_model = self.DEFAULT_FALLBACK_MODEL

        def caller(configuration_id: Optional[str], prompt: str) -> str:
            cfg: Optional[dict] = None
            if configuration_resolver is not None and configuration_id:
                try:
                    cfg = configuration_resolver(configuration_id)
                except Exception:
                    # Resolver lookup must never break the LLM caller —
                    # fall through to the documented fallback path.
                    logger.exception(
                        "autogen llm caller: configuration_resolver "
                        "raised for configuration_id=%r; falling back to "
                        "the customer's pre-bound ChatCompletionClient "
                        "(%r).",
                        configuration_id,
                        fallback_model,
                    )
                    cfg = None

            extra_create_args: dict = {}
            if cfg is not None:
                if cfg.get("max_tokens") is not None:
                    extra_create_args["max_tokens"] = cfg["max_tokens"]
                if cfg.get("temperature") is not None:
                    extra_create_args["temperature"] = cfg["temperature"]
                # cfg["model"] intentionally NOT applied — see class
                # docstring; AutoGen binds the model at client
                # construction.
            else:
                logger.debug(
                    "autogen llm caller: no `configurations[]` entry "
                    "matched configuration_id=%r; invoking the customer's "
                    "pre-bound ChatCompletionClient without per-call "
                    "overrides. Declare `configurations: - {id: %s, "
                    "type: llm, max_tokens: ..., temperature: ...}` in "
                    "`.guardrails.yaml` to forward invocation params.",
                    configuration_id,
                    configuration_id or "<unset>",
                )

            messages = [UserMessage(content=prompt, source="agent_shield")]

            async def _create() -> Any:
                if extra_create_args:
                    return await model_client.create(
                        messages, extra_create_args=extra_create_args,
                    )
                return await model_client.create(messages)

            future = _AUTOGEN_EXECUTOR.submit(
                lambda: asyncio.run(_create())
            )
            result = future.result()
            return result.content

        return caller


# ---------------------------------------------------------------------------
# Capability 2 — Tool wrapper
# ---------------------------------------------------------------------------


class _ToolWrapper(ToolWrapper):
    """Wrap an AutoGen ``BaseTool`` with a guarded subclass.

    AutoGen tools take a typed ``args`` object (Pydantic-style); the
    wrapper rebuilds the typed object from Stage-3-mutated params via
    ``args.model_validate`` so redactions reach the framework.
    """

    def extract(self, tool: Any) -> ToolMetadata:
        return ToolMetadata(
            name=tool.name,
            description=tool.description,
            extras={
                "args_type": tool._args_type,
                "return_type": getattr(tool, "_return_type", str),
            },
        )

    async def invoke(self, original: Any, params: dict) -> Any:
        # AutoGen tools take a typed args object; rebuild it from params,
        # return the raw Python output so @result paths bind against structure,
        # and normalize Pydantic BaseModel outputs to dicts for the pyo3 JSON
        # bridge instead of falling back to repr strings.
        args_type = original._args_type
        try:
            args = args_type.model_validate(params)
        except Exception:  # noqa: BLE001
            args = args_type(**params)
        output = await original.run(args, None)
        try:
            from pydantic import BaseModel
        except Exception:  # noqa: BLE001
            BaseModel = None  # type: ignore[assignment]
        if BaseModel is not None and isinstance(output, BaseModel):
            return output.model_dump(mode="json")
        return output

    def wrap(
        self,
        original: Any,
        metadata: ToolMetadata,
        guarded_invoke: GuardedInvoke,
    ) -> Any:
        from autogen_core.tools import BaseTool

        class _GuardedTool(BaseTool):
            def __init__(
                self,
                _original: Any = original,
                _metadata: ToolMetadata = metadata,
                _guarded: GuardedInvoke = guarded_invoke,
            ) -> None:
                super().__init__(
                    args_type=_original._args_type,
                    return_type=getattr(_original, "_return_type", str),
                    name=_metadata.name,
                    description=_metadata.description,
                )
                self._original = _original
                self._guarded = _guarded

            async def run(self, args: Any, cancellation_token: Any) -> Any:
                params = args.model_dump() if hasattr(args, "model_dump") else {}
                return await self._guarded(params, "")

        return _GuardedTool()


# ---------------------------------------------------------------------------
# Capability 3 — Agent boundary
# ---------------------------------------------------------------------------


class _AgentBoundary(AgentBoundary):
    """Run an AutoGen agent's ``on_messages`` and reshape its result."""

    async def run(
        self, agent: Any, input_text: str, **kwargs: Any,
    ) -> Any:
        messages = kwargs.pop("messages", None)
        cancellation_token = kwargs.pop("cancellation_token", None)
        if messages is None:
            from autogen_agentchat.messages import TextMessage

            messages = [TextMessage(content=input_text, source="user")]
        return await agent.on_messages(messages, cancellation_token, **kwargs)

    def extract_output(self, result: Any) -> Optional[str]:
        if hasattr(result, "chat_message") and hasattr(result.chat_message, "content"):
            return str(result.chat_message.content)
        return None

    def apply_redaction(self, result: Any, redacted_text: str) -> Any:
        from autogen_agentchat.messages import TextMessage
        from autogen_agentchat.base import Response

        return Response(
            chat_message=TextMessage(
                content=redacted_text,
                source=result.chat_message.source,
            ),
            inner_messages=getattr(result, "inner_messages", None),
        )

    def make_blocked(self, message: str) -> Any:
        from autogen_agentchat.messages import TextMessage
        from autogen_agentchat.base import Response

        return Response(
            chat_message=TextMessage(content=message, source="guarded_agent"),
        )


def _extract_user_input_from_messages(messages: Any) -> str:
    """Find the most recent user/human message text."""
    if not messages:
        return ""
    for msg in reversed(list(messages)):
        if hasattr(msg, "source") and hasattr(msg, "content"):
            src = str(getattr(msg, "source", ""))
            if src.lower() in ("user", "human", "user_proxy"):
                return str(msg.content)
        type_name = type(msg).__name__.lower()
        if "user" in type_name or "human" in type_name:
            content = getattr(msg, "content", "")
            return str(content)
    last = messages[-1] if isinstance(messages, list) else list(messages)[-1]
    return str(getattr(last, "content", ""))


#: Sources whose messages are treated as direct user input (gated by
#: Stage 1 ``validate_input``) rather than inbound inter-agent calls
#(gated by ``validate_agent_call``). Anything outside this set —
#: including a sibling AutoGen agent's name — is treated as an
#: inter-agent invocation.
_USER_SOURCES = frozenset({"user", "human", "user_proxy"})


def _extract_inter_agent_calls(
    messages: Any, recipient_name: str,
) -> list[tuple[str, dict]]:
    """Build the agent-call list for ``shield.guard(agent).on_messages(...)``.

    Returns one ``(recipient_name, {"message": content, "source": src})``
    tuple per inbound message whose ``source`` is neither the human
    user nor the recipient itself. Order matches message order so the
    first DENY in :func:`guarded_turn` short-circuits the turn before
    Stage 1 or agent execution runs.

    The recipient agent's own name is filtered out so an agent
    forwarded its own prior turn does not gate against itself; the
    selector-engine side of ``applies_to.agents`` is the authoritative
    check — when no matching policy exists the runtime no-ops on a
    proceed verdict, so this list is safe to populate generously.

    """
    if not messages:
        return []
    calls: list[tuple[str, dict]] = []
    recipient_lower = (recipient_name or "").lower()
    for msg in messages:
        src = str(getattr(msg, "source", "") or "")
        content = getattr(msg, "content", None)
        if content is None:
            continue
        src_lower = src.lower()
        if src_lower in _USER_SOURCES or src_lower == recipient_lower:
            continue
        calls.append(
            (
                recipient_name,
                {"message": str(content), "source": src},
            )
        )
    return calls


# ---------------------------------------------------------------------------
# Capability 4 — Streaming adapter (AutoGen buffers, yields once)
# ---------------------------------------------------------------------------


class _StreamingAdapter(StreamingAdapter):
    """AutoGen streaming: buffer all safe chunks, emit a single Response."""

    async def stream(
        self,
        agent: Any,
        input_text: str,
        validator: StreamingValidator,
        **kwargs: Any,
    ) -> AsyncIterator[Any]:
        from autogen_agentchat.base import Response
        from autogen_agentchat.messages import TextMessage

        messages = kwargs.pop("messages", None)
        cancellation_token = kwargs.pop("cancellation_token", None)
        if messages is None:
            messages = [TextMessage(content=input_text, source="user")]

        safe_parts: list[str] = []
        last_response: Any = None
        async for chunk in agent.on_messages_stream(
            messages, cancellation_token, **kwargs,
        ):
            if not isinstance(chunk, Response):
                continue
            last_response = chunk
            text_value = chunk.chat_message.content if hasattr(
                chunk.chat_message, "content",
            ) else None
            text = str(text_value) if text_value else ""
            if not text:
                continue
            result = validator.push(text)
            if result.action == "replace":
                # Stage-5 validator rewrote the buffer (redaction); the
                # payload supersedes everything buffered so far. Reset
                # the accumulator instead of appending so the final
                # `apply_redaction` doesn't render leaked-then-redacted
                # content.
                safe_parts = [result.payload] if result.payload else []
            elif result.payload:
                safe_parts.append(result.payload)
            if result.stopped:
                yield validator.make_blocked(
                    result.reason or "Stage 5 streaming guard stopped the stream.",
                )
                return

        tail = validator.finish()
        if tail.stopped:
            yield validator.make_blocked(
                tail.reason or "Stage 5 streaming guard stopped the stream.",
            )
            return
        if tail.action == "replace":
            safe_parts = [tail.payload] if tail.payload else []
        elif tail.payload:
            safe_parts.append(tail.payload)

        final_text = "".join(safe_parts)
        if last_response is not None:
            yield validator.apply_redaction(last_response, final_text)
        else:
            yield validator.make_blocked(final_text)


# ---------------------------------------------------------------------------
# Bundle
# ---------------------------------------------------------------------------


class GuardedAgent(GuardedRunner):
    """AutoGen-named guarded runner — adds ``on_messages`` / ``on_messages_stream``."""

    @property
    def name(self) -> str:
        return getattr(self._agent, "name", "guarded_agent")

    @property
    def produced_message_types(self) -> Any:
        return getattr(self._agent, "produced_message_types", [])

    async def on_messages(
        self,
        messages: Any,
        cancellation_token: Any = None,
        **kwargs: Any,
    ) -> Any:
        user_input = _extract_user_input_from_messages(messages)
        agent_calls = _extract_inter_agent_calls(messages, self.name)
        return await self.run(
            user_input,
            messages=messages,
            cancellation_token=cancellation_token,
            agent_calls=agent_calls or None,
            **kwargs,
        )

    async def on_messages_stream(
        self,
        messages: Any,
        cancellation_token: Any = None,
        **kwargs: Any,
    ):
        user_input = _extract_user_input_from_messages(messages)
        async for emission in self.run_streamed(
            user_input,
            messages=messages,
            cancellation_token=cancellation_token,
            **kwargs,
        ):
            yield emission


_BUNDLE = FrameworkBundle(
    name="autogen",
    llm_caller_factory=_LlmCallerFactory(),
    tool_wrapper=_ToolWrapper(),
    agent_boundary=_AgentBoundary(),
    streaming_adapter=_StreamingAdapter(),
    capabilities=CapabilityReport(
        framework="autogen",
        # Stage 2-4 require the customer's tools to all flow through
        # `protect_tools(...)` — partial because the adapter cannot
        # enforce that on tools added via AutoGen's runtime APIs.
        state_validation=CoverageLevel.PARTIAL,
        tool_authorization=CoverageLevel.PARTIAL,
        tool_execution_validation=CoverageLevel.PARTIAL,
        tool_output_validation=CoverageLevel.PARTIAL,
        # AutoGen's `Response`-based stream emits one final response
        # per tool turn (not chunk-level), so streaming Stage 5 maps
        # to "validate the final response" rather than chunk-level
        # validation. Marked unsupported per the canonical claim.
        streaming_output=CoverageLevel.UNSUPPORTED,
    ),
    guarded_runner_cls=GuardedAgent,
    # Stage 2/3/4 blocks raise ``AgentShieldBlocked``
    # from the wrapped ``BaseTool.run``. AutoGen's ``AssistantAgent``
    # catches the exception inside its function-call executor and
    # records it as ``FunctionExecutionResult(content=str(e),
    # is_error=True)`` — the LLM sees an explicit tool error rather
    # than the formatted block message as ordinary observation, so
    # it cannot produce affirmative final narrative that contradicts
    # the block (the silent-bypass class). See
    # the block-to-observation silent-bypass class.
    tool_wrapper_raise_on_block=True,
)


# ---------------------------------------------------------------------------
# Intermediate inter-agent chat-message redaction helpers
# ---------------------------------------------------------------------------


def _redactable_message_type_names() -> tuple[str, ...]:
    """Names of :class:`BaseChatMessage` subclasses that carry
    free-text content emitted by participants (not tool I/O or
    configuration). Stage 5 fires for each one.

    Other AutoGen message types are skipped:

    * ``ToolCallSummaryMessage`` / ``ToolCallRequestEvent`` /
      ``ToolCallExecutionEvent`` — tool I/O is already gated at
      Stage 4 inside :meth:`Shield.protect_tools`. Re-running Stage 5
      here would double-redact.
    * ``StopMessage`` — termination configuration, not data.
    * ``HandoffMessage`` — agent handoff target; the content is
      ``"target: X"`` configuration (the conversation data lives in
      ``HandoffMessage.context`` LLM messages which are not the chat
      surface).
    * ``ModelClientStreamingChunkEvent`` / ``ThoughtEvent`` /
      ``SelectSpeakerEvent`` / ``MemoryQueryEvent`` etc. —
      observability events, not chat data flow.
    """
    return (
        "TextMessage",
        "MultiModalMessage",
        "StructuredMessage",
    )


def _is_tool_or_config_message(msg: Any) -> bool:
    """Skip messages already gated at Stage 4 (tool surface) or that
    are framework configuration (stop / handoff)."""
    type_name = type(msg).__name__
    return type_name in {
        "ToolCallSummaryMessage",
        "ToolCallRequestEvent",
        "ToolCallExecutionEvent",
        "CodeGenerationEvent",
        "CodeExecutionEvent",
        "StopMessage",
        "HandoffMessage",
        "ModelClientStreamingChunkEvent",
        "ThoughtEvent",
        "SelectSpeakerEvent",
        "SelectorEvent",
        "MemoryQueryEvent",
        "UserInputRequestedEvent",
    }


def _is_block_marker_message(msg: Any) -> bool:
    """A message synthesized by Agent Shield itself (Stage 1 block
    text, Stage 5 block appendage). Skip these to avoid validating
    the block boilerplate as if it were participant output."""
    source = getattr(msg, "source", None)
    return source == "agent_shield"


def _apply_stage5_to_text(
    session: Any, mode_value: str, text: str,
) -> tuple[bool, Optional[str], str]:
    """Run Stage 5 against ``text``.

    Returns ``(blocked, block_message, effective_text)``.

    * ``blocked=True`` — Stage 5 demanded a block; ``block_message``
      carries the canonical text and ``effective_text`` falls back to
      the block message (callers writing into a chat message replace
      content with the block text to avoid leaking the raw original).
    * ``blocked=False, block_message=None, effective_text=<original
      or redacted>`` — proceed; ``effective_text`` is the post-Stage-5
      string (unchanged when no redaction rules apply).
    """
    if not isinstance(text, str) or not text:
        return False, None, text
    outcome = session.validate_output(text)
    decision = _dispatch_stage(outcome.verdict, "return_blocked", mode_value)
    action = decision["action"]
    kind = action["kind"]
    if (
        kind == "return_blocked"
        and not decision.get("override_to_proceed", False)
    ):
        block_message = str(action["message"])
        return True, block_message, block_message
    if kind == "proceed_with_mutation":
        mutated = action.get("value")
        if mutated is None:
            mutated = (
                outcome.response if outcome.response is not None else text
            )
        return False, None, str(mutated)
    return False, None, text


def _redact_chat_message_in_place(
    session: Any, mode: Any, msg: Any,
) -> None:
    """Apply Stage 5 to a :class:`BaseChatMessage`-shaped object in
    place, when its content is free-text participant output.

    Tool I/O, system / configuration, and Agent-Shield-synthesized
    block messages are skipped. ``MultiModalMessage`` text blocks are
    redacted element-wise; image blocks are passed through unchanged.
    """
    if msg is None or _is_tool_or_config_message(msg) or _is_block_marker_message(msg):
        return
    mode_value = getattr(mode, "value", mode if isinstance(mode, str) else "enforce")

    content = getattr(msg, "content", None)

    if isinstance(content, str):
        blocked, block_message, redacted = _apply_stage5_to_text(
            session, mode_value, content,
        )
        if blocked:
            # Intermediate-message block: replace the content with the
            # canonical block text so downstream participants see the
            # block payload, not the original PII.
            try:
                msg.content = block_message or ""  # type: ignore[attr-defined]
            except Exception:  # noqa: BLE001
                logger.debug(
                    "AutoGen redaction: could not mutate content on %s (immutable?)",
                    type(msg).__name__,
                    exc_info=True,
                )
            return
        if redacted != content:
            try:
                msg.content = redacted  # type: ignore[attr-defined]
            except Exception:  # noqa: BLE001
                logger.debug(
                    "AutoGen redaction: could not mutate content on %s (immutable?)",
                    type(msg).__name__,
                    exc_info=True,
                )
        return

    if isinstance(content, list):
        new_content: list[Any] = []
        mutated_any = False
        for block in content:
            if isinstance(block, str):
                blocked, block_message, redacted = _apply_stage5_to_text(
                    session, mode_value, block,
                )
                if blocked:
                    new_content.append(block_message or "")
                    mutated_any = True
                else:
                    new_content.append(redacted)
                    if redacted != block:
                        mutated_any = True
            else:
                new_content.append(block)
        if mutated_any:
            try:
                msg.content = new_content  # type: ignore[attr-defined]
            except Exception:  # noqa: BLE001
                logger.debug(
                    "AutoGen redaction: could not mutate multi-modal content on %s "
                    "(immutable?)",
                    type(msg).__name__,
                    exc_info=True,
                )


class _RedactingChatAgent:
    """Wraps an AutoGen :class:`autogen_agentchat.base.ChatAgent` so
    its outbound :attr:`Response.chat_message` (and any text-bearing
    inner messages) are run through Stage 5 redaction BEFORE the
    team manager publishes them to the group topic.

    This is the canonical interception point for closing the
    silent intra-team PII leak where Stage 5 was previously applied
    only to the final ``TaskResult``. Other participants subscribed
    to the group topic call :meth:`ChatAgentContainer.handle_agent_response`
    which buffers ``response.chat_message`` into their context for
    the next turn. By the time the message reaches that handler, the
    content has already been redacted by this wrapper.

    The wrapper preserves the underlying agent's :attr:`name`,
    :attr:`description`, :attr:`produced_message_types`, and lifecycle
    hooks (``on_reset`` / ``on_pause`` / ``on_resume`` /
    ``save_state`` / ``load_state`` / ``close``). The wrapped
    instance's ``_tools`` / ``_workbench`` attributes are still
    accessible for the pre-existing
    :func:`_attach_shared_session_to_participants` tool-rewrapping
    pass.
    """

    component_type = "agent"

    def __init__(self, inner: Any, shield: "Shield", session: Any) -> None:
        self._inner = inner
        self._shield = shield
        self._session = session
        self._mode = shield._mode

    # ── Identity passthrough ─────────────────────────────────────
    @property
    def name(self) -> str:
        return self._inner.name

    @property
    def description(self) -> str:
        return self._inner.description

    @property
    def produced_message_types(self) -> Any:
        return self._inner.produced_message_types

    def __getattr__(self, item: str) -> Any:
        # Forward attribute access (e.g. `_tools`, `_workbench`,
        # `model_client`) to the wrapped agent so the existing
        # `_attach_shared_session_to_participants` tool-rewrap pass
        # continues to work transparently.
        return getattr(self._inner, item)

    # ── Message handling — Stage 5 around the response ─────────
    async def on_messages(self, messages: Any, cancellation_token: Any) -> Any:
        response = await self._inner.on_messages(messages, cancellation_token)
        self._redact_response_in_place(response)
        return response

    async def on_messages_stream(self, messages: Any, cancellation_token: Any):
        from autogen_agentchat.base import Response

        async for emission in self._inner.on_messages_stream(
            messages, cancellation_token,
        ):
            if isinstance(emission, Response):
                self._redact_response_in_place(emission)
            else:
                # BaseChatMessage / BaseAgentEvent — redact text-bearing
                # chat messages, pass tool / system events through.
                _redact_chat_message_in_place(
                    self._session, self._mode, emission,
                )
            yield emission

    def _redact_response_in_place(self, response: Any) -> None:
        chat_message = getattr(response, "chat_message", None)
        if chat_message is not None:
            _redact_chat_message_in_place(self._session, self._mode, chat_message)
        inner = getattr(response, "inner_messages", None) or []
        for msg in inner:
            _redact_chat_message_in_place(self._session, self._mode, msg)

    # ── Lifecycle passthrough ────────────────────────────────────
    async def on_reset(self, cancellation_token: Any) -> None:
        if hasattr(self._inner, "on_reset"):
            return await self._inner.on_reset(cancellation_token)

    async def on_pause(self, cancellation_token: Any) -> None:
        if hasattr(self._inner, "on_pause"):
            return await self._inner.on_pause(cancellation_token)

    async def on_resume(self, cancellation_token: Any) -> None:
        if hasattr(self._inner, "on_resume"):
            return await self._inner.on_resume(cancellation_token)

    async def save_state(self) -> Any:
        if hasattr(self._inner, "save_state"):
            return await self._inner.save_state()
        return {}

    async def load_state(self, state: Any) -> None:
        if hasattr(self._inner, "load_state"):
            return await self._inner.load_state(state)

    async def close(self) -> None:
        if hasattr(self._inner, "close"):
            return await self._inner.close()


# ---------------------------------------------------------------------------
# Team wrapper — shared session
# ---------------------------------------------------------------------------


class GuardedAutoGenTeam:
    """Guarded wrapper around an AutoGen ``BaseGroupChat`` team.

    Multi-agent AutoGen flows (``RoundRobinGroupChat`` /
    ``SelectorGroupChat`` / ``Swarm`` / etc.) decompose a single user
    turn into many inter-agent messages and many tool calls across
    different participants. Wrapping each participant separately via
    :meth:`Shield.create_autogen_agent` allocates one
    :class:`~agent_shield.runtime.Session` per agent, so per-session
    variables populated by Agent A's tool call (for example, a
    ``kyc_token`` written by a post-tool extractor) are INVISIBLE to
    Agent B's later guard policies — Stage 2/3 ``evaluate_when``
    blocks fire on ``kyc_token=unset`` even when KYC just succeeded.
    This wrapper closes that shared-session gap.

    :meth:`Shield.create_autogen_team` returns this wrapper. It owns
    ONE shared session for the entire team run; every member agent's
    tool call (Stages 2/3/4) sees that session as ambient via
    :data:`current_session`. Stage 1 fires once on the team's task
    input; Stage 5 fires once on the team's final message at the end
    of :meth:`run` / :meth:`run_stream`. The underlying
    ``BaseGroupChat`` is unchanged — its existing
    ``cancellation_token`` / ``output_task_messages`` plumbing flows
    through.

    **Intermediate inter-agent chat-message redaction.** Each
    participant's ``ChatAgent`` is wrapped via :class:`_RedactingChatAgent`
    so its outbound :class:`autogen_agentchat.base.Response.chat_message`
    is run through Stage 5 redaction BEFORE the team manager publishes
    it to the group topic. Downstream participants subscribed to the
    group topic therefore observe only redacted content — closing the
    silent intra-team PII leak where Stage 5 was previously applied
    only to the final ``TaskResult``. The same redaction sweep is
    applied to every text message in the final ``TaskResult.messages``
    list (not just the last) so the visible transcript matches what
    participants actually saw. Tool-call / tool-result / system /
    stop / handoff configuration messages are skipped to avoid
    double-redaction (tool I/O is gated at Stage 4) and to avoid
    redacting non-data configuration messages.
    """

    def __init__(
        self,
        shield: "Shield",
        team: Any,
        session: Any,
    ) -> None:
        self._shield = shield
        self._team = team
        self._session = session
        self._mode = shield._mode

    @property
    def team(self) -> Any:
        """The underlying AutoGen ``BaseGroupChat`` instance."""
        return self._team

    @property
    def session(self) -> Any:
        """The shared :class:`~agent_shield.runtime.Session` instance.

        Every member agent's tool call inside :meth:`run` /
        :meth:`run_stream` resolves to this session, so per-session
        variables persist across the team turn.
        """
        return self._session

    @property
    def name(self) -> str:
        return getattr(self._team, "name", "guarded_team")

    @property
    def description(self) -> str:
        return getattr(self._team, "description", "")

    @staticmethod
    def _task_to_text(task: Any) -> str:
        """Best-effort string extraction from a ``task=`` argument.

        AutoGen accepts ``str | BaseChatMessage | Sequence[BaseChatMessage] |
        None`` — return the concatenated text for Stage 1 input
        validation. ``None`` collapses to ``""`` (Stage 1 is skipped).
        """
        if task is None:
            return ""
        if isinstance(task, str):
            return task
        if isinstance(task, (list, tuple)):
            parts: list[str] = []
            for item in task:
                content = getattr(item, "content", None)
                if content is None:
                    continue
                parts.append(str(content))
            return "\n".join(parts)
        content = getattr(task, "content", None)
        if content is not None:
            return str(content)
        return str(task)

    @staticmethod
    def _last_text_message(result: Any) -> tuple[Any, Optional[str]]:
        """Return ``(message, content_text)`` for the final emitted text
        message in a ``TaskResult``, or ``(None, None)`` if absent.

        Stage 5 redaction needs to replace the content on the SAME
        message object that the customer reads off
        ``result.messages[-1]``; returning the bare message lets the
        caller mutate in place rather than reconstruct the chain.
        """
        msgs = getattr(result, "messages", None)
        if not msgs:
            return None, None
        for msg in reversed(list(msgs)):
            content = getattr(msg, "content", None)
            if isinstance(content, str):
                return msg, content
        return None, None

    async def run(
        self,
        *,
        task: Any = None,
        cancellation_token: Any = None,
        **kwargs: Any,
    ) -> Any:
        """Run the team with Stage 1 (input) + Stage 5 (output) enforcement.

        ``task`` / ``cancellation_token`` / ``output_task_messages``
        and any other keyword arguments are forwarded verbatim to
        ``BaseGroupChat.run``.
        """
        return await self._run_inner(
            task=task,
            cancellation_token=cancellation_token,
            **kwargs,
        )

    async def run_stream(
        self,
        *,
        task: Any = None,
        cancellation_token: Any = None,
        **kwargs: Any,
    ):
        """Run the team's stream with Stage 1 + Stage 5 enforcement.

        Stage 1 fires before the underlying ``run_stream`` begins;
        Stage 5 fires on the final ``TaskResult`` emitted. Intermediate
        ``BaseAgentEvent`` / ``BaseChatMessage`` chunks pass through
        unchanged — chunk-level Stage 5 is marked
        :attr:`CoverageLevel.UNSUPPORTED` in the AutoGen
        :class:`CapabilityReport`.
        """
        from autogen_agentchat.base import TaskResult

        sess = self._session
        sess_token = current_session.set(sess)
        sess.begin_turn()
        try:
            input_text = self._task_to_text(task)
            input_token = current_user_input.set(input_text)
            try:
                effective_task = task
                if input_text:
                    block = self._stage1_block_message(input_text)
                    if block is not None:
                        yield TaskResult(
                            messages=[
                                self._blocked_text_message(block),
                            ],
                            stop_reason="agent_shield: stage1 block",
                        )
                        return

                async for emission in self._team.run_stream(
                    task=effective_task,
                    cancellation_token=cancellation_token,
                    **kwargs,
                ):
                    if isinstance(emission, TaskResult):
                        gated = self._apply_stage5(emission)
                        yield gated
                    else:
                        yield emission
            finally:
                current_user_input.reset(input_token)
        finally:
            try:
                sess.end_turn()
            except Exception:  # noqa: BLE001
                pass
            current_session.reset(sess_token)

    async def _run_inner(
        self,
        *,
        task: Any,
        cancellation_token: Any,
        **kwargs: Any,
    ) -> Any:
        from autogen_agentchat.base import TaskResult

        sess = self._session
        sess_token = current_session.set(sess)
        sess.begin_turn()
        try:
            input_text = self._task_to_text(task)
            input_token = current_user_input.set(input_text)
            try:
                if input_text:
                    block = self._stage1_block_message(input_text)
                    if block is not None:
                        return TaskResult(
                            messages=[
                                self._blocked_text_message(block),
                            ],
                            stop_reason="agent_shield: stage1 block",
                        )
                result = await self._team.run(
                    task=task,
                    cancellation_token=cancellation_token,
                    **kwargs,
                )
                return self._apply_stage5(result)
            finally:
                current_user_input.reset(input_token)
        finally:
            try:
                sess.end_turn()
            except Exception:  # noqa: BLE001
                pass
            current_session.reset(sess_token)

    def _stage1_block_message(self, user_input: str) -> Optional[str]:
        """Run Stage 1 on ``user_input``; return a block message or
        ``None`` to proceed."""
        sess = self._session
        verdict = sess.validate_input(user_input)
        decision = _dispatch_stage(verdict, "return_blocked", self._mode.value)
        action = decision["action"]
        if (
            action["kind"] == "return_blocked"
            and not decision.get("override_to_proceed", False)
        ):
            return str(action["message"])
        return None

    def _apply_stage5(self, result: Any) -> Any:
        """Run Stage 5 against the messages in a ``TaskResult``.

        Previously this method redacted only the FINAL text message —
        the visible customer transcript — which silently masked the
        intra-team leak where intermediate participants had already
        observed raw PII before the final reduction. The fix sweeps
        every text-bearing :class:`BaseChatMessage` in
        ``result.messages`` and applies Stage 5 in place, so the
        transcript surfaces the same redacted content participants
        saw via :class:`_RedactingChatAgent`. Tool-call /
        tool-result / system / handoff messages are skipped — those
        are configuration or already-redacted Stage 4 surfaces.

        On block (against the final text message specifically): the
        canonical block message is appended and ``stop_reason`` is
        flipped to ``agent_shield: stage5 block``. Intermediate-message
        blocks are folded into in-place content replacement (the same
        behaviour applied at the participant boundary) so the
        ``TaskResult`` still flows back to the caller.
        """
        # Sweep every intermediate text-bearing chat message.
        msgs = getattr(result, "messages", None) or []
        for msg in msgs:
            _redact_chat_message_in_place(self._session, self._mode, msg)

        # The final-text-message block path still wins: if the LAST
        # text message tripped a block (rather than a redact), surface
        # the block via stop_reason + an appended block message.
        last_msg, last_text = self._last_text_message(result)
        if last_text is None or last_msg is None:
            return result
        sess = self._session
        outcome = sess.validate_output(last_text)
        decision = _dispatch_stage(outcome.verdict, "return_blocked", self._mode.value)
        action = decision["action"]
        if action["kind"] == "return_blocked":
            block = self._blocked_text_message(str(action["message"]))
            try:
                msgs_list = list(result.messages)
                msgs_list.append(block)
                result.messages = msgs_list  # type: ignore[attr-defined]
            except Exception:  # noqa: BLE001
                pass
            try:
                result.stop_reason = "agent_shield: stage5 block"  # type: ignore[attr-defined]
            except Exception:  # noqa: BLE001
                pass
            return result
        # `proceed_with_mutation` was already applied by the sweep
        # above (final message is in `msgs`). Nothing further to do.
        return result

    @staticmethod
    def _blocked_text_message(text: str) -> Any:
        """Build the AutoGen ``TextMessage`` carrying a block payload."""
        from autogen_agentchat.messages import TextMessage

        return TextMessage(content=text, source="agent_shield")


def _attach_shared_session_to_participants(shield: "Shield", team: Any, session: Any = None) -> None:
    """Re-wrap each member agent's tools through ``shield.protect_tools``
    so they pick up the shared ambient session set in
    :meth:`GuardedAutoGenTeam._run_inner`, and wrap each
    participant in :class:`_RedactingChatAgent` so its outbound
    chat messages are Stage 5-redacted BEFORE the team manager
    publishes them to the group topic.

    The tool-list replacement is in place: ``participant._tools`` is
    reassigned and (when the agent's workbench was the default static
    workbench for the original tool list) ``participant._workbench``
    is rebuilt from the wrapped tools. Custom workbenches are left
    alone — the customer must wire shared-session protection through
    their own workbench shape.

    The participant wrapping replaces ``team._participants[i]`` with
    :class:`_RedactingChatAgent` only for participants that look like
    real :class:`autogen_agentchat.base.ChatAgent` instances (have
    ``on_messages`` / ``on_messages_stream``). Test mocks that lack
    those hooks are left in place — they cannot route inter-agent
    messages via the AutoGen runtime anyway, so the Stage 5 sweep on
    the final ``TaskResult.messages`` is the operative gate.
    """
    try:
        from autogen_core.tools import StaticStreamWorkbench
    except Exception:  # noqa: BLE001
        StaticStreamWorkbench = None  # type: ignore[assignment]

    participants = getattr(team, "_participants", None)
    if not participants:
        return
    # First pass — tool rewrap (existing behaviour).
    for participant in participants:
        tools = getattr(participant, "_tools", None)
        if not tools:
            continue
        wrapped = shield.protect_tools(list(tools))
        try:
            participant._tools = wrapped  # type: ignore[attr-defined]
        except Exception:  # noqa: BLE001,S112
            continue
        if StaticStreamWorkbench is None:
            continue
        workbench = getattr(participant, "_workbench", None)
        if workbench is None:
            continue
        rebuildable = (
            isinstance(workbench, list)
            and len(workbench) == 1
            and isinstance(workbench[0], StaticStreamWorkbench)
        )
        if rebuildable:
            try:
                participant._workbench = [StaticStreamWorkbench(wrapped)]  # type: ignore[attr-defined]
            except Exception:  # noqa: BLE001
                logger.debug(
                    "create_autogen_team: could not rebuild static "
                    "workbench for participant %r; leaving in place",
                    getattr(participant, "name", "?"),
                    exc_info=True,
                )

    # Second pass — wrap each participant in
    # _RedactingChatAgent so inter-agent message publish carries
    # redacted content. We only wrap participants that already
    # implement the ChatAgent message hooks; SimpleNamespace mocks
    # without `on_messages_stream` are left untouched (no inter-agent
    # routing surface to protect, and the result-sweep below catches
    # them).
    if session is None:
        return

    def _is_chat_agent_shaped(p: Any) -> bool:
        return (
            hasattr(p, "on_messages")
            and hasattr(p, "on_messages_stream")
            and not isinstance(p, _RedactingChatAgent)
        )

    try:
        for i, participant in enumerate(list(participants)):
            if _is_chat_agent_shaped(participant):
                participants[i] = _RedactingChatAgent(participant, shield, session)
    except Exception:  # noqa: BLE001
        logger.debug(
            "create_autogen_team: could not install _RedactingChatAgent "
            "wrappers on team._participants; intermediate-message Stage 5 "
            "will fall back to the final TaskResult sweep",
            exc_info=True,
        )


# ---------------------------------------------------------------------------
# Composition pattern — install with_autogen() and create_autogen_agent().
# ---------------------------------------------------------------------------


def _install() -> None:
    """Monkey-install :meth:`ShieldBuilder.with_autogen` and
    :meth:`Shield.create_autogen_agent`."""

    def with_autogen(self: ShieldBuilder) -> ShieldBuilder:
        """Bind this builder to the AutoGen framework bundle."""
        return self._bind_to_bundle(_BUNDLE)

    def create_autogen_agent(
        self: Shield,
        model_client: Any,
        tools: list,
        *,
        system_message: str = "",
        name: str = "assistant",
        session: Any = None,
        **agent_kwargs: Any,
    ) -> Any:
        """Build a fully guarded AutoGen agent in one call (Pattern A).

        Pass ``session=<Session>`` to bind this agent's
        :class:`~agent_shield.adapters._shield.GuardedRunner` to an
        explicit pre-allocated session. When several
        ``create_autogen_agent`` calls share the same ``session=``
        instance, per-session variables, event latches, and populator
        state persist across agents — the manual escape hatch for
        multi-agent flows that do NOT assemble into an AgentChat
        ``BaseGroupChat`` team. For team flows, prefer
        :meth:`Shield.create_autogen_team` which handles the shared
        session automatically.
        """
        from autogen_agentchat.agents import AssistantAgent

        protected = self.protect_tools(tools)
        agent = AssistantAgent(
            name=name,
            model_client=model_client,
            tools=protected,
            system_message=system_message,
            **agent_kwargs,
        )
        if session is not None:
            return self.guard(agent, session=session)
        return self.guard(agent)

    def create_autogen_team(
        self: Shield,
        team: Any,
        *,
        session: Any = None,
    ) -> GuardedAutoGenTeam:
        """Wrap an AutoGen ``BaseGroupChat`` team with a SHARED session
        across all member agents.

        Each participant's tool list is re-wrapped through
        :meth:`Shield.protect_tools` and the team's
        :meth:`GuardedAutoGenTeam.run` / :meth:`run_stream` set the
        shared session as ambient (:data:`current_session`) for the
        duration of the team run. Every tool call from any participant
        therefore resolves to the SAME session, and per-session
        variables (for example, a ``kyc_token`` written by a Stage 4
        post-tool extractor on Agent A) are visible to Agent B's
        Stage 2/3 ``evaluate_when`` predicates later in the turn.

        Stage 1 fires once on the team's ``task`` input; Stage 5 fires
        once on the last text message of the team's final
        ``TaskResult``. Stages 2/3/4 fire per-tool-call as usual,
        threaded through the shared session.

        Pass ``session=<Session>`` to reuse a pre-allocated session
        (carry per-session state across multiple team turns / pair
        with a single-agent call); omit it to let the helper mint a
        fresh session for this team.

        Customers using ``create_autogen_agent`` followed by
        ``RoundRobinGroupChat([guarded1, guarded2, ...])`` should
        instead build the team from the RAW
        ``autogen_agentchat.agents.AssistantAgent`` instances and pass
        the team here — :class:`~agent_shield.adapters._shield.GuardedRunner`
        is not a :class:`~autogen_agentchat.base.ChatAgent` and will
        not pass the team's ``isinstance`` check.
        """
        shared = session if session is not None else self.runtime.new_session()
        _attach_shared_session_to_participants(self, team, shared)
        return GuardedAutoGenTeam(self, team, shared)

    ShieldBuilder.with_autogen = with_autogen
    Shield.create_autogen_agent = create_autogen_agent
    Shield.create_autogen_team = create_autogen_team


_install()

# Register this bundle as the auto-bind default for new ShieldBuilder instances.
from . import _bundle_registry as _registry  # noqa: E402
_registry.register(_BUNDLE)


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


def make_llm_caller(
    model_client: Any,
    configuration_resolver: Optional[
        Callable[[Optional[str]], Optional[dict]]
    ] = None,
) -> Callable[[Optional[str], str], str]:
    """Create an LLM caller from an AutoGen ``ChatCompletionClient``.

    Pass ``configuration_resolver=runtime.llm_configuration`` to honour
    the YAML's per-stage ``max_tokens:`` / ``temperature:`` selection
    via ``extra_create_args``. Model selection is left to the
    customer's pre-bound ``ChatCompletionClient`` — see
    :class:`_LlmCallerFactory` for rationale.
    """
    return _BUNDLE.llm_caller_factory.make_caller(
        model_client, configuration_resolver=configuration_resolver,
    )


def protect_tools(
    runtime: Runtime,
    tools: list,
    user_input_getter: Optional[Callable[[], str]] = None,
    *,
    allow_unguarded: bool = False,
) -> list:
    """Wrap AutoGen tools with Stages 2 + 3 + 4 enforcement.

    See :meth:`agent_shield.Shield.protect_tools` for the
    ``allow_unguarded`` flag.
    """
    return _protect_tools_via_wrapper(
        runtime, tools, _BUNDLE.tool_wrapper, user_input_getter,
        allow_unguarded=allow_unguarded,
    )


__all__ = [
    "GuardedAgent",
    "GuardedAutoGenTeam",
    "make_llm_caller",
    "protect_tools",
]
