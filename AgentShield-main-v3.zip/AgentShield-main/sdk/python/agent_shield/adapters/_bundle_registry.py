"""Module-level registry of installed framework bundles.

Adapter modules call :func:`register` at import time to publish their
:class:`FrameworkBundle`. :class:`ShieldBuilder` calls
:func:`active_bundle` at construction time so customers don't have to
sprinkle ``.with_<framework>()`` ceremony into every demo.

When multiple adapter modules are imported into the same process
(``langchain`` + ``openai_agents`` etc.), :func:`active_bundle` raises
:class:`AmbientBundleAmbiguityError` rather than silently picking one —
fail-closed defaults beat behaviour that depends on import order.
Customers in that situation call ``Shield.from_yaml(...,
auto_bind=False).with_<framework>()`` to pin a specific bundle.
"""
from __future__ import annotations

from typing import Dict, List, Optional

from ._capabilities import AmbientBundleAmbiguityError, FrameworkBundle

_REGISTERED: Dict[str, FrameworkBundle] = {}


def register(bundle: FrameworkBundle) -> None:
    """Publish ``bundle`` so that new :class:`ShieldBuilder` instances
    can auto-bind it when it is the only registered adapter.

    Idempotent: re-registering the same bundle name overwrites the
    previous entry (the typical case when an adapter module is
    re-imported in tests).
    """
    _REGISTERED[bundle.name] = bundle


def active_bundle() -> Optional[FrameworkBundle]:
    """Return the unique registered bundle, or ``None`` when no adapter
    has been imported.

    Raises:
        AmbientBundleAmbiguityError: when two or more adapter bundles
            are registered. Auto-binding any of them would silently
            depend on import order, so the registry refuses to guess.
    """
    if not _REGISTERED:
        return None
    if len(_REGISTERED) == 1:
        return next(iter(_REGISTERED.values()))
    raise AmbientBundleAmbiguityError(list(_REGISTERED))


def registered_names() -> List[str]:
    """Sorted list of currently registered adapter bundle names."""
    return sorted(_REGISTERED)


def reset() -> None:
    """Test-only helper to clear the registry."""
    _REGISTERED.clear()
