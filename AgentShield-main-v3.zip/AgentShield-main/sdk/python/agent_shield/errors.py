"""Typed exception classes raised by the Agent Shield Python SDK.

This module hosts the user-facing exception types that the SDK raises
when loading or building a guardrails runtime. The flagship class is
:class:`AgentShieldConfigError`, which surfaces structured information
about loader / build failures so callers can program against typed
fields instead of pattern-matching on free-form messages.
"""

from __future__ import annotations

# ``AgentShieldConfigError`` is defined in the native module as a
# subclass of ``BaseException`` (via PyO3 ``create_exception!``) and
# re-exported here under the public ``agent_shield`` namespace. The
# Rust SDK boundary populates the structured attributes
# ``message``, ``path``, ``line``, ``column``, ``field``, ``code``,
# and ``remediation`` on each raised instance via ``setattr`` —
# customers catch the same class identity here regardless of whether
# the exception was raised from Rust or hand-constructed in Python.
from agent_shield._native import AgentShieldConfigError as _NativeAgentShieldConfigError

# Customer-facing alias — `agent_shield.AgentShieldConfigError` is the
# canonical spelling.
AgentShieldConfigError = _NativeAgentShieldConfigError


def _make_config_error(
    message: str,
    *,
    path=None,
    line=None,
    column=None,
    field=None,
    code: str = "loader_error",
    remediation=None,
):
    """Construct an :class:`AgentShieldConfigError` with structured fields.

    Used internally by the SDK (and by tests). Customers typically only
    catch the exception; they don't construct it.
    """
    exc = AgentShieldConfigError(message)
    exc.message = message
    exc.path = path
    exc.line = line
    exc.column = column
    exc.field = field
    exc.code = code
    exc.remediation = remediation
    return exc


__all__ = [
    "AgentShieldConfigError",
    "AgentShieldLensIncomplete",
    "AgentShieldResolverEnvelopeError",
    "AgentShieldUnsupportedOutputType",
    "StreamingReplaceNotSupportedError",
]


class StreamingReplaceNotSupportedError(RuntimeError):
    """Raised when an append-only streaming sink receives a ``Replace`` action.

    Stage-5 streaming guards may emit ``action == "replace"`` when the
    validator rewrites buffered output (for example, after a later chunk
    closes a redaction window). ``replace`` means: *discard every byte
    already emitted for this stream and substitute ``payload`` in its
    place.*

    Sinks that cannot retract bytes already delivered to the consumer
    — HTTP SSE without rewind support, stdout, terminal renderers,
    any UI that immediately paints each delta — would otherwise leave
    the leaked PHI/secret on screen with the redacted version appended
    after it. The SDK raises this exception at the FIRST such event so
    the consumer fails loudly instead of silently rendering stale
    sensitive text.

    Mitigation:

    * Switch the streaming cadence to ``on_complete`` (the default) so
      no text-bearing chunks ever leave the guard until ``finish()``
      returns the fully validated payload — that is the spec's safe
      default and the only mode whose output is byte-equivalent to the
      non-streaming path.
    * Or wrap the sink in an in-memory buffer that the SDK can rewrite
      cleanly on ``Replace`` (see :meth:`StreamingGuard.push` and the
      ``buffer`` accessor) before flushing to the customer.
    """


class AgentShieldResolverEnvelopeError(ValueError):
    """Raised when a resolver callback returns a malformed envelope.

    the resolver wire envelope as:

        { "decision": "allow"|"deny"|"cancelled",
          "value":    <typed value matching the variable, or null>,
          "set_variables": { ... },
          "reason":   "<human-readable explanation>" }

    On ``decision: "allow"`` the ``value`` field is REQUIRED — the spec
    permits ``value: null`` only as an explicit, deliberately-supplied
    sentinel for boolean-resolved variables. A dict envelope that omits
    the ``value`` key altogether on ``allow`` is silently fail-open
    (previously the SDK normalized it to ``VariableState(value=None,
    status='resolved')`` regardless of whether the resolver author
    intended to publish ``null``).

    The SDK closes that gap: an ``allow`` envelope without a ``value`` key
    raises this error at the SDK surface, before the response reaches
    the Rust core. Resolvers that legitimately resolve to ``null`` must
    state the intent explicitly:

        return {"decision": "allow", "value": None, "set_variables": {...}}

    ``deny`` / ``cancelled`` envelopes are unaffected — neither sets a
    variable value, so ``value`` is optional.

    Attributes:
        message: Human-readable description with a migration hint.
    """

    def __init__(self, *, decision: str = "allow", hint: str | None = None) -> None:
        base = (
            f"resolver callback returned `decision: {decision!r}` without a "
            f"`value` field; the value field on `allow`."
        )
        migration = hint or (
            "If your resolver is a side-effect-only gate (the variable's "
            "type is boolean and the policy intent is `value: null` means "
            "`allow`), state that explicitly:\n\n"
            "    return {\n"
            "        \"decision\": \"allow\",\n"
            "        \"value\": None,\n"
            "        \"set_variables\": {...},\n"
            "    }\n\n"
            "If the resolver was meant to deny, return\n"
            "    {\"decision\": \"deny\", \"reason\": \"...\"}\n"
            "instead — `deny` does not require `value`."
        )
        self.message = f"{base}\n\n{migration}"
        super().__init__(self.message)

    @classmethod
    def unknown_fields(cls, unknown: object) -> "AgentShieldResolverEnvelopeError":
        """Build an error for a resolver dict that carries unknown keys.

        This mirrors the Rust core wire type's
        ``serde(deny_unknown_fields)``. Previously the Python loose-dict
        path silently discarded any key outside the canonical four, so a
        resolver author who typed ``{"descision": "allow"}`` (typo)
        would see a confusing "envelope missing decision" rather than a
        targeted "unknown field 'descision' — did you mean 'decision'?"
        This constructor surfaces the offending keys, the canonical
        field set, and (when the typo is close to a canonical name) a
        suggestion the author can act on.
        """
        from difflib import get_close_matches

        canonical = ["decision", "value", "set_variables", "reason"]
        if isinstance(unknown, str):
            unknown_list = [unknown]
        else:
            unknown_list = sorted(str(k) for k in unknown)
        if not unknown_list:
            return cls(
                decision="allow",
                hint="(internal) unknown_fields called with empty key set",
            )

        suggestions: list[str] = []
        for key in unknown_list:
            close = get_close_matches(key, canonical, n=1, cutoff=0.6)
            if close:
                suggestions.append(f"{key!r} (did you mean {close[0]!r}?)")
            else:
                suggestions.append(repr(key))

        unknown_clause = (
            f"unknown field {suggestions[0]}"
            if len(suggestions) == 1
            else "unknown fields " + ", ".join(suggestions)
        )
        msg = (
            f"resolver callback returned envelope with {unknown_clause}; "
            f"the resolver wire envelope as "
            f"{{decision, value, set_variables, reason}}. "
            f"The Rust core wire type rejects unknown fields "
            f"(`serde(deny_unknown_fields)`); the Python SDK mirrors that "
            f"contract so typos surface at the boundary instead of as "
            f"silently-dropped fields downstream."
        )

        err = cls.__new__(cls)
        err.message = msg
        ValueError.__init__(err, msg)
        return err

class AgentShieldUnsupportedOutputType(TypeError):
    """Raised by Shield.run when a thunk returned a value Stage 5 cannot
    validate without an explicit text-extraction lens.

    Closes the silent-bypass class where a Pattern C thunk returning a
    framework result object (Vercel AI SDK ``GenerateTextResult``,
    LangChain ``AgentExecutor`` output, OpenAI Assistants ``Run``,
    Pydantic ``RunResult``, etc.) caused Stage 5 to validate ``str(obj)``
    — typically the literal ``<Foo object at 0x...>`` repr that contains
    none of the assistant-visible text the policy was supposed to redact.

    Native walker shapes (``str`` / ``dict`` / ``list`` / ``tuple`` /
    Pydantic ``BaseModel`` / ``None`` / ``bool`` / ``int`` / ``float``)
    continue to work unchanged. This exception fires only when the thunk
    returns an arbitrary user / framework class and no ``extract_text=``
    callable was supplied.

    Attributes:
        result_type: Python type name of the unsupported result.
        message: human-readable description with a migration hint
            pointing at the ``extract_text=`` keyword on
            :meth:`Shield.run`.
    """

    def __init__(self, result_type: str) -> None:
        self.result_type = result_type
        self.message = (
            f"Shield.run: Stage 5 cannot validate a result of type "
            f"`{result_type}`. The walker natively handles str / dict / "
            f"list / tuple / Pydantic BaseModel; other shapes would "
            f"otherwise be coerced via str(result) and silently bypass "
            f"Stage 5 redaction. To wrap framework calls that return "
            f"structured objects (Vercel AI SDK, LangChain, OpenAI "
            f"Assistants, Pydantic RunResult, etc.), pass an `extract_text=` "
            f"callable that returns the assistant-visible text:\n\n"
            f"    result = await shield.run(thunk, extract_text=lambda r: r.text)\n\n"
            f"When `extract_text=` is supplied, Stage 5 is applied to "
            f"the extracted string and the redacted text is set back on "
            f"the original result via `set_text` (default: setattr "
            f"`result.text = redacted`). Pass a custom `set_text=` for "
            f"immutable / frozen result types (e.g. "
            f"`set_text=lambda r, t: dataclasses.replace(r, text=t)`)."
        )
        super().__init__(self.message)


class AgentShieldLensIncomplete(TypeError):
    """Raised by Shield.run when a customer supplies ``extract_text=`` but
    no matching ``set_text=`` writer.

    This closes the silent-bypass class where a non-string framework
    result silently flowed back unredacted. The opt-in
    ``extract_text=`` / ``set_text=`` lens lets the customer name the
    assistant-visible text field on a framework result. But there is a
    second-order silent-bypass at the lens surface itself: if a customer
    passes ``extract_text=lambda r: r.choices[0].message.content`` but
    forgets ``set_text=``, the previous default
    :func:`_default_set_text` writes redacted text into a fresh
    ``result.text`` attribute — leaving the original location (e.g.
    ``r.choices[0].message.content``) untouched. The customer sees no
    exception, believes Stage 5 succeeded, and ships the unredacted
    text downstream.

    This closes the gap fail-closed: the absence of ``set_text=`` is
    treated as a configuration error, not as an implicit "use the
    default". Customers who *want* Stage 5 to be advisory-only (no
    write-back) must opt in explicitly via ``set_text=None``.

    Behavioural matrix:

    * ``extract_text=None`` (default) — non-string results raise
      :class:`AgentShieldUnsupportedOutputType`. String / dict /
      list / Pydantic results flow through the walker unchanged.
    * ``extract_text=<cb>`` AND ``set_text=<cb>`` — lens fires; redacted
      text written back through ``set_text``.
    * ``extract_text=<cb>`` AND ``set_text`` not in kwargs — raises
      :class:`AgentShieldLensIncomplete` (fail-closed).
    * ``extract_text=<cb>`` AND ``set_text=None`` (explicit) —
      advisory-only mode. Stage 5 runs over the extracted text but the
      result object is NOT mutated. The original (potentially unredacted)
      text remains where the customer's ``extract_text`` read it from.
      Pick this only when downstream code does not consume the
      framework-shaped result directly.

    Attributes:
        message: human-readable description with the migration hint
            pointing at both the ``set_text=`` and ``set_text=None``
            opt-in paths.
    """

    def __init__(self) -> None:
        self.message = (
            "Shield.run: `extract_text=` was supplied without `set_text=`. "
            "Previously the runtime silently wrote redacted text into a "
            "fresh `result.text` attribute via the default mutator, "
            "leaving the original `extract_text` source location (e.g. "
            "`r.choices[0].message.content`) unredacted — a silent "
            "Stage 5 bypass at the opt-in lens surface. Pair "
            "`extract_text` with `set_text` to ensure redacted text is "
            "written back to the assistant-visible location:\n\n"
            "    await shield.run(\n"
            "        thunk,\n"
            "        extract_text=lambda r: r.choices[0].message.content,\n"
            "        set_text=lambda r, t: setattr(\n"
            "            r.choices[0].message, 'content', t\n"
            "        ),\n"
            "    )\n\n"
            "To override fail-closed behavior, pass `set_text=None` "
            "explicitly (acknowledging Stage 5 will not modify the "
            "result; the original text remains in place)."
        )
        super().__init__(self.message)


