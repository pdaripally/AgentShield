"""Hook protocols and resolver envelope dataclasses for the API.

The host-implemented surfaces are deliberately small. Each hook is
defined here as both:

* a :class:`typing.Protocol` describing the shape any host implementation
  must satisfy, and
* (where applicable) a :class:`~dataclasses.dataclass` describing the
  request / response envelope.

Hosts may either implement the full protocol or pass a plain ``callable``
into the :class:`~agent_shield.runtime.RuntimeBuilder` registration
methods — both are accepted.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Literal, Optional, Protocol, Union, runtime_checkable

from ._wire import from_wire_dict


# ── Resolver envelope ───────────────────────────────────────────────────

ResolverDecision = Literal["allow", "deny", "cancelled"]


@dataclass
class ResolverRequest:
    """Envelope delivered to every resolver hook invocation.

    The flat ``resource_kind`` / ``resource_name`` fields are retained
    for backward compatibility with legacy callbacks. The canonical
    spec shape is the nested ``resource: {kind, name, params}``
    envelope — new code SHOULD prefer ``resource``, which
    additionally surfaces the resource invocation ``params`` that the
    flat form drops. ``requested_key`` is populated when the target
    variable declares ``key:`` (+); the resolver MUST scope
    its response to that key.
    """

    request_id: str
    variable: Optional[str] = None
    resource_kind: Optional[str] = None
    resource_name: Optional[str] = None
    resource: Optional[Dict[str, Any]] = None
    requested_key: Any = None
    prompt: Optional[str] = None
    reason: Optional[str] = None
    context: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ResolverRequest":
        return from_wire_dict(cls, d)


@dataclass
class ResolverResponse:
    """Wire envelope returned by every resolver hook.

    ``decision`` is required; ``value`` and ``set_variables`` are optional.
    Unknown / malformed envelopes are rejected fail-closed by the runtime.
    """

    decision: ResolverDecision
    value: Any = None
    set_variables: Dict[str, Any] = field(default_factory=dict)
    reason: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        out: Dict[str, Any] = {"decision": self.decision}
        # Spec: `value` is REQUIRED in the wire envelope on
        # `decision: "allow"` (it MAY be `null`, but the key must be
        # present). On `deny`/`cancelled` the key is OPTIONAL — neither
        # writes the variable. Keep the historical "omit None" behavior
        # for non-allow decisions to avoid noisy diffs.
        if self.decision == "allow":
            out["value"] = self.value
        elif self.value is not None:
            out["value"] = self.value
        if self.set_variables:
            out["set_variables"] = dict(self.set_variables)
        if self.reason is not None:
            out["reason"] = self.reason
        return out


@dataclass
class DelegateRequest:
    """Envelope delivered to :class:`DelegateDispatcher`.

    The flat ``resource_kind`` / ``resource_name`` fields are retained
    for backward compatibility with legacy callbacks. New code
    SHOULD prefer the nested ``resource: {kind, name, params}``
    envelope, which additionally surfaces the resource invocation
    ``params``. ``requested_key`` and ``lifetime``
    mirror the on-wire HTTP / MCP / A2A delegate request body — the
    former scopes the variable when ``key:`` is declared, the
    latter forwards the resolver's ``lifetime:`` hint verbatim so the
    delegate can mint a matching envelope.
    """

    request_id: str
    variable: Optional[str] = None
    configuration: Dict[str, Any] = field(default_factory=dict)
    effective_timeout_ms: int = 0
    resource_kind: Optional[str] = None
    resource_name: Optional[str] = None
    resource: Optional[Dict[str, Any]] = None
    requested_key: Any = None
    lifetime: Any = None
    prompt: Optional[str] = None
    reason: Optional[str] = None
    context: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "DelegateRequest":
        return from_wire_dict(cls, d)


@dataclass
class HumanResolveRequest:
    """Envelope delivered to a registered :class:`HumanResolver`
    callback. Mirrors :class:`ResolverRequest` in shape so
    hosts can share helper code across ``kind: human`` and
    ``kind: agent`` resolvers; carries an additional
    ``approval_nonce`` anti-replay token that the host MUST echo back
    on the response.
    """

    request_id: str
    variable: Optional[str] = None
    resource_kind: Optional[str] = None
    resource_name: Optional[str] = None
    resource: Optional[Dict[str, Any]] = None
    prompt: Optional[str] = None
    reason: Optional[str] = None
    context: Dict[str, Any] = field(default_factory=dict)
    approval_nonce: Optional[str] = None
    invocation_hash: Optional[str] = None
    session_id: Optional[str] = None
    requested_key: Any = None
    timeout_ms: Optional[int] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "HumanResolveRequest":
        return from_wire_dict(cls, d)


# ── Protocols ────────────────────────────────────────────────────────────


@runtime_checkable
class AgentResolver(Protocol):
    """Host integration for ``kind: agent`` resolvers."""

    def resolve(self, request: ResolverRequest) -> ResolverResponse: ...


@runtime_checkable
class DelegateDispatcher(Protocol):
    """Host integration for ``kind: delegate`` resolvers."""

    def dispatch(self, request: DelegateRequest) -> ResolverResponse: ...


@runtime_checkable
class HumanResolver(Protocol):
    """Host integration for ``kind: human`` resolvers.

    Registered via
    :meth:`agent_shield.RuntimeBuilder.register_human_resolver`. YAML
    does not name the handler; if none is registered, the resolver
    denies fail-closed.
    """

    def resolve(self, request: HumanResolveRequest) -> ResolverResponse: ...


# Hook callables (alternative to Protocol implementations).
AgentResolverCallable = Callable[[ResolverRequest], ResolverResponse]
DelegateDispatcherCallable = Callable[[DelegateRequest], ResolverResponse]
HumanResolverCallable = Callable[[HumanResolveRequest], ResolverResponse]


# ── LLM / classifier ─────────────────────────────────────────────────────


@dataclass
class RedactionSpan:
    """Half-open ``[start, end)`` **codepoint (character) range** over the
    input text — NOT a byte range. Drives Stage-3 redact policies:
    when a redact-mode policy receives spans from an LLM or classifier
    caller, the runtime substitutes ``replacement`` (default empty) for
    the matched slice of input.

    The Rust core (see
    ``sdk/rust/agent_shield_core/src/guard_policy_runtime/action.rs``)
    computes spans against ``str::chars()`` so non-ASCII subjects redact
    predictably. Spans whose ``end`` exceeds the subject's character
    count — or whose ``end <= start`` — are **silently dropped** rather
    than clamped (the dropped span emits a ``debug``-level log entry from
    the core to aid diagnosis).

    Pitfall: do not use ``str.encode("utf-8").index(...)`` to locate
    offsets. Use ``str.index(...)`` / character positions instead.

    Worked example (Unicode-prefixed secret)::

        text = "name: 田中 太郎 SSN: 123-45-6789"
        # WRONG — byte offsets (works for ASCII, silently fails here):
        #   text.encode("utf-8").index(b"123") == 27
        #   RedactionSpan(start=27, end=38) # end > char_count — dropped!
        # RIGHT — codepoint offsets:
        start = text.index("123-45-6789")    # 17
        end   = start + len("123-45-6789")   # 28
        span  = RedactionSpan(start=start, end=end, replacement="[SSN]")
    """

    start: int
    end: int
    replacement: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        out: Dict[str, Any] = {"start": self.start, "end": self.end}
        if self.replacement is not None:
            out["replacement"] = self.replacement
        return out


@dataclass
class LlmResponse:
    """Structured LLM caller response.

    ``decision`` is the canonical allow / block flag. Any truthy value in
    ``bool_flags`` MUST be treated as ``block``. ``spans``
    drives Stage-3 redact policies — when populated and ``decision`` is
    ``"allow"``, the runtime applies each span to the input.
    """

    decision: Optional[Literal["allow", "block"]] = None
    confidence: Optional[float] = None
    reason: Optional[str] = None
    categories: List[str] = field(default_factory=list)
    bool_flags: Dict[str, bool] = field(default_factory=dict)
    spans: List[RedactionSpan] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        out: Dict[str, Any] = {}
        if self.decision is not None:
            out["decision"] = self.decision
        if self.confidence is not None:
            out["confidence"] = self.confidence
        if self.reason is not None:
            out["reason"] = self.reason
        if self.categories:
            out["categories"] = list(self.categories)
        if self.bool_flags:
            out["bool_flags"] = dict(self.bool_flags)
        if self.spans:
            out["spans"] = [s.to_dict() for s in self.spans]
        return out


@dataclass
class ClassifierVerdict:
    """Structured classifier response.

    ``spans`` drives Stage-3 redact policies the same way as
    :class:`LlmResponse.spans`.
    """

    score: float = 0.0
    threshold: float = 0.0
    flagged: bool = False
    label: Optional[str] = None
    reason: Optional[str] = None
    spans: List[RedactionSpan] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        out: Dict[str, Any] = {
            "score": self.score,
            "threshold": self.threshold,
            "flagged": self.flagged,
        }
        if self.label is not None:
            out["label"] = self.label
        if self.reason is not None:
            out["reason"] = self.reason
        if self.spans:
            out["spans"] = [s.to_dict() for s in self.spans]
        return out


LlmCallable = Callable[[Optional[str], str], Union[LlmResponse, Dict[str, Any], str]]
ClassifierCallable = Callable[[str, str], Union[ClassifierVerdict, Dict[str, Any]]]


@runtime_checkable
class LlmCaller(Protocol):
    """Host integration for ``llm:`` detection entries."""

    def call(
        self, configuration_id: Optional[str], prompt: str
    ) -> Union[LlmResponse, Dict[str, Any], str]: ...


@runtime_checkable
class ClassifierCaller(Protocol):
    """Host integration for ``classifier:`` detection entries."""

    def classify(
        self, configuration_id: str, subject: str
    ) -> Union[ClassifierVerdict, Dict[str, Any]]: ...


__all__ = [
    "ResolverDecision",
    "ResolverRequest",
    "ResolverResponse",
    "DelegateRequest",
    "HumanResolveRequest",
    "AgentResolver",
    "DelegateDispatcher",
    "HumanResolver",
    "AgentResolverCallable",
    "DelegateDispatcherCallable",
    "HumanResolverCallable",
    "LlmResponse",
    "ClassifierVerdict",
    "LlmCallable",
    "ClassifierCallable",
    "LlmCaller",
    "ClassifierCaller",
]
