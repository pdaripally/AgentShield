"""Out-of-process integrations for Agent Shield.

Adapters under :mod:`agent_shield.adapters` wrap framework objects you
construct in-process (LangChain runnables, Anthropic agents, etc.).
Integrations under this package plug Agent Shield into separate
*services* — proxies, gateways, sidecars — that sit between agents and
their LLMs or tools, and enforce a ``.guardrails.yaml`` at that
boundary instead of in the agent's own process.

Currently shipped:

* :mod:`agent_shield.integrations.litellm_proxy` — a
  ``litellm.integrations.custom_guardrail.CustomGuardrail`` subclass
  that wires the five Agent Shield validation stages into LiteLLM
  Proxy's native ``guardrails:`` config block.
"""
