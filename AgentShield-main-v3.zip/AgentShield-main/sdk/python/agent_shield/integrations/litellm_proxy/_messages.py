"""Pure-data helpers for translating between OpenAI-Chat shapes and
Agent Shield calls.

These functions never call the Agent Shield runtime — they're shape
translators, used by :mod:`_guardrail` and :mod:`_streaming`. Keeping
them isolated makes the guardrail class itself read top-to-bottom as a
linear stage pipeline.

Shapes we handle:

* Incoming request — ``data["messages"]`` is a list of OpenAI-Chat
  message dicts with ``role`` in ``{"system", "user", "assistant",
  "tool"}``. Assistant messages may carry ``tool_calls`` (each with
  ``id``, ``type``, ``function.{name, arguments}``). Tool messages
  carry ``tool_call_id`` + ``content``.
* Outgoing response — a ``ModelResponse`` (LiteLLM type) or a plain
  dict. We tolerate both: LiteLLM hooks sometimes hand us pydantic
  models, sometimes raw dicts (depending on which proxy code path).
"""
from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("agent_shield.litellm_proxy")


# ── Pydantic vs dict adapters ───────────────────────────────────────────

def _as_dict(obj: Any) -> Dict[str, Any]:
    """Return ``obj`` as a plain dict regardless of pydantic/dataclass.

    LiteLLM's ``ModelResponse`` / ``Choices`` / ``Message`` /
    ``ChatCompletionMessageToolCall`` are pydantic v2 models; the
    proxy code path sometimes hands us their ``.model_dump()``, other
    times the live instances. Handle both transparently.
    """
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return obj
    dump = getattr(obj, "model_dump", None)
    if callable(dump):
        return dump()
    # last-resort attribute walk
    return {k: getattr(obj, k) for k in getattr(obj, "__dict__", {})}


# ── Stage 1: extract user-input text ────────────────────────────────────

def is_new_user_turn(messages: List[Dict[str, Any]]) -> bool:
    """``True`` iff the last message in the request is ``role=user``.

    This is the signal that a *new* agent turn just started — the
    client is sending the very first prompt of the turn (or a
    continuation prompt). Subsequent in-turn requests (where the
    client is sending tool results back to the LLM) have ``role=tool``
    as their *last* message.
    """
    if not messages:
        return False
    return _role(messages[-1]) == "user"


def last_user_content(messages: List[Dict[str, Any]]) -> str:
    """Return the text content of the last ``role=user`` message.

    Tolerates the multimodal shape where ``content`` is a list of
    content-part dicts — concatenates the text parts in order. Returns
    ``""`` if no user message is present.
    """
    for msg in reversed(messages):
        if _role(msg) != "user":
            continue
        return _flatten_content(msg.get("content"))
    return ""


# ── Stage 4: walk role=tool messages, replace content ───────────────────

def trailing_tool_messages(
    messages: List[Dict[str, Any]],
) -> List[Tuple[int, Dict[str, Any]]]:
    """Indices + dicts of the *trailing* ``role=tool`` messages.

    LiteLLM clients typically send one or more ``role=tool`` messages
    back-to-back (one per pending tool_call), followed by another LLM
    call. Stage 4 fires on those trailing messages only — older
    ``role=tool`` messages further up the history were already
    validated on a previous request.
    """
    out: List[Tuple[int, Dict[str, Any]]] = []
    for idx in range(len(messages) - 1, -1, -1):
        if _role(messages[idx]) != "tool":
            break
        out.append((idx, messages[idx]))
    out.reverse()
    return out


def replace_message_content(
    messages: List[Dict[str, Any]], index: int, new_content: str,
) -> None:
    """Replace ``messages[index]["content"]`` in-place with a flat string.

    Multimodal lists are collapsed to a single text string — the block
    message is plain text and we don't try to preserve image parts.
    """
    if 0 <= index < len(messages):
        messages[index] = {**messages[index], "content": new_content}


# ── Stage 2/3 + 5: walk an assistant response ───────────────────────────

def response_choice_count(response: Any) -> int:
    """Return the number of choices on ``response``.

    Used by the guardrail to fail-closed-block any response that
    carries more than one choice — the integration only validates
    ``choices[0]``, so a response with ``len(choices) > 1`` would
    leak unvalidated content in ``choices[1..N]``.
    """
    resp = _as_dict(response)
    choices = resp.get("choices") or []
    return len(choices) if isinstance(choices, list) else 0


def response_assistant_message(response: Any) -> Optional[Dict[str, Any]]:
    """Return ``response.choices[0].message`` as a plain dict, or ``None``."""
    resp = _as_dict(response)
    choices = resp.get("choices") or []
    if not choices:
        return None
    msg = _as_dict(choices[0]).get("message")
    return _as_dict(msg) if msg is not None else None


def response_tool_calls(response: Any) -> List[Dict[str, Any]]:
    """Return ``response.choices[0].message.tool_calls`` as a list of dicts.

    Returns ``[]`` for any response that does not carry a tool-call
    block. Each returned dict has ``id``, ``type``, and
    ``function.{name, arguments}`` keys; ``arguments`` is a JSON
    *string* (per the OpenAI spec).
    """
    msg = response_assistant_message(response)
    if msg is None:
        return []
    calls = msg.get("tool_calls") or []
    return [_as_dict(c) for c in calls]


def response_content(response: Any) -> str:
    """Return ``response.choices[0].message.content`` as a flat string."""
    msg = response_assistant_message(response)
    if msg is None:
        return ""
    return _flatten_content(msg.get("content"))


def parse_tool_arguments(arguments: Any) -> Tuple[Dict[str, Any], bool]:
    """Decode a tool-call ``function.arguments`` field to a dict.

    Returns ``(decoded_dict, was_malformed)``. ``was_malformed`` is
    ``True`` when the upstream argument string was non-empty but not a
    valid JSON object — the caller should treat that as a fail-closed
    Stage-3 block, because the original argument string would otherwise
    travel to the tool executor unchanged and bypass argument-level
    policies.

    Parameter-free calls legitimately carry ``""`` or ``"{}"``; those
    are normalised to ``({}, False)``.
    """
    if arguments is None or arguments == "":
        return {}, False
    if isinstance(arguments, dict):
        return arguments, False
    if not isinstance(arguments, str):
        return {}, True
    try:
        decoded = json.loads(arguments)
    except json.JSONDecodeError:
        logger.warning(
            "litellm-proxy: malformed tool-call arguments JSON; "
            "treating as a fail-closed block: %r", arguments,
        )
        return {}, True
    if not isinstance(decoded, dict):
        return {}, True
    return decoded, False


def serialise_tool_arguments(params: Dict[str, Any]) -> Optional[str]:
    """Encode mutated Stage-3 params back into a JSON string.

    Returns ``None`` if serialisation fails — the caller should treat
    that as a fail-closed Stage-3 block, since shipping un-encodable
    params to the agent would be silently incorrect.
    """
    try:
        return json.dumps(params, ensure_ascii=False)
    except (TypeError, ValueError) as exc:
        logger.warning(
            "litellm-proxy: could not re-encode Stage-3 mutated params "
            "(%s); failing closed", exc,
        )
        return None


# ── Response rewriting (Stage 2/3 + 5 block / mutate) ───────────────────

def rewrite_response_as_block(response: Any, block_message: str) -> Any:
    """Mutate ``response`` into a single-choice assistant block message.

    Replaces the response's ``choices`` list with one block choice:
    drops any ``tool_calls`` on the (now-only) choice, sets ``content``
    to the block string, switches ``finish_reason`` to ``"stop"``, and
    truncates any extra choices that may have been present (so a
    multi-choice response can never leak ``choices[1..N]`` content
    past Agent Shield).

    Mutates the response in-place when it's a pydantic model so
    LiteLLM sees the change; falls back to dict mutation for the
    dict-y path.

    Returns the (possibly new) response object the caller should
    forward to LiteLLM.
    """
    response = _mutate_assistant_message(
        response,
        content=block_message,
        clear_tool_calls=True,
        finish_reason="stop",
    )
    return _truncate_to_single_choice(response)


def rewrite_response_content(response: Any, new_content: str) -> Any:
    """Replace the assistant ``content`` while preserving ``tool_calls``.

    Used for Stage-5 ``proceed_with_mutation`` (redact / append /
    prepend) on a final assistant message.
    """
    return _mutate_assistant_message(
        response, content=new_content, clear_tool_calls=False,
    )


def rewrite_tool_call_id(
    response: Any, index: int, new_id: str,
) -> Any:
    """Replace ``tool_calls[index].id`` with ``new_id``.

    Used when the integration synthesises a tool_call_id (because the
    upstream model omitted it) so the agent can later echo the same
    id on its ``role=tool`` reply and Stage 4 can correlate.
    """
    pmodel = _pydantic_message(response)
    if pmodel is not None and getattr(pmodel, "tool_calls", None):
        try:
            pmodel.tool_calls[index].id = new_id
            return response
        except Exception:  # noqa: BLE001 — dict fallback
            logger.debug(
                "litellm-proxy: pydantic tool_call id assignment "
                "failed; using dict path", exc_info=True,
            )
    resp_dict = _as_dict(response)
    try:
        resp_dict["choices"][0]["message"]["tool_calls"][index]["id"] = new_id
    except (KeyError, IndexError, TypeError):
        logger.warning(
            "litellm-proxy: could not write synthesised tool_call_id "
            "(index %d)", index,
        )
    return resp_dict


def rewrite_tool_call_arguments(
    response: Any, index: int, new_arguments_json: str,
) -> Any:
    """Replace ``tool_calls[index].function.arguments`` with the JSON string.

    Used for Stage-3 ``proceed_with_mutation``. The response must
    already carry a ``tool_calls`` list at the given index.
    """
    msg = response_assistant_message(response)
    if msg is None:
        return response
    calls = msg.get("tool_calls") or []
    if not (0 <= index < len(calls)):
        return response

    # Mutate via the underlying pydantic object when present so the
    # proxy sees the change on serialisation.
    pmodel = _pydantic_message(response)
    if pmodel is not None and getattr(pmodel, "tool_calls", None):
        call_obj = pmodel.tool_calls[index]
        fn = getattr(call_obj, "function", None)
        if fn is not None:
            try:
                fn.arguments = new_arguments_json
            except Exception:  # noqa: BLE001 — fall through to dict path
                logger.debug(
                    "litellm-proxy: tool-call arguments assignment failed "
                    "on pydantic path; using dict path",
                    exc_info=True,
                )
            else:
                return response

    # Dict fallback.
    resp_dict = _as_dict(response)
    try:
        resp_dict["choices"][0]["message"]["tool_calls"][index][
            "function"
        ]["arguments"] = new_arguments_json
    except (KeyError, IndexError, TypeError):
        logger.warning(
            "litellm-proxy: could not write back mutated tool-call "
            "arguments (index %d)", index,
        )
    return resp_dict


# ── Internal helpers ────────────────────────────────────────────────────

def _role(msg: Any) -> str:
    if isinstance(msg, dict):
        return str(msg.get("role") or "")
    return str(getattr(msg, "role", "") or "")


def _flatten_content(content: Any) -> str:
    """Collapse an OpenAI ``content`` field (string OR list of parts)."""
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: List[str] = []
        for part in content:
            d = _as_dict(part) if not isinstance(part, dict) else part
            text = d.get("text") or d.get("content")
            if isinstance(text, str):
                parts.append(text)
        return "".join(parts)
    return str(content)


def _pydantic_message(response: Any) -> Any:
    """Return the live pydantic ``Message`` instance on ``response``.

    Returns ``None`` if ``response`` is a dict or if its ``choices`` /
    ``message`` chain is missing.
    """
    choices = getattr(response, "choices", None)
    if not choices:
        return None
    first = choices[0] if len(choices) > 0 else None
    return getattr(first, "message", None) if first is not None else None


def _truncate_to_single_choice(response: Any) -> Any:
    """Drop any ``choices`` beyond index 0 in-place.

    Used by the multi-choice block path: once Stage 5 rewrites
    ``choices[0]`` into a block message, the surviving
    ``choices[1..N]`` would still carry the original unvalidated
    content. This helper truncates the list so the block is the
    *only* choice the client sees.

    No-op when there's already exactly one choice — returns the
    original ``response`` unchanged so single-choice call sites
    (which are the common case) don't get silently coerced into
    a dict.

    Operates on the live pydantic model when present and falls
    back to dict mutation otherwise.
    """
    choices = getattr(response, "choices", None)
    if isinstance(choices, list) and len(choices) > 1:
        try:
            del choices[1:]
            return response
        except Exception:  # noqa: BLE001 — fall through to dict path
            logger.debug(
                "litellm-proxy: pydantic choices truncation failed; "
                "using dict path", exc_info=True,
            )
    elif isinstance(choices, list):
        # Already a single choice — nothing to truncate, preserve
        # the original (possibly pydantic) shape.
        return response
    # Dict-shaped path (or pydantic truncation fell through).
    resp_dict = _as_dict(response)
    dchoices = resp_dict.get("choices")
    if isinstance(dchoices, list) and len(dchoices) > 1:
        resp_dict["choices"] = dchoices[:1]
    return resp_dict


def _mutate_assistant_message(
    response: Any,
    *,
    content: str,
    clear_tool_calls: bool = False,
    finish_reason: Optional[str] = None,
) -> Any:
    """Apply a content/tool_calls/finish_reason mutation to a response.

    Operates on the live pydantic model when present (so LiteLLM
    serialises the change) and falls back to a dict mutation for
    callers that handed us a dict.
    """
    pmsg = _pydantic_message(response)
    if pmsg is not None:
        try:
            pmsg.content = content
            if clear_tool_calls:
                pmsg.tool_calls = None
            if finish_reason is not None:
                response.choices[0].finish_reason = finish_reason
            return response
        except Exception:  # noqa: BLE001 — fall through to dict path
            logger.debug(
                "litellm-proxy: pydantic mutation failed; falling back to "
                "dict path", exc_info=True,
            )

    resp_dict = _as_dict(response)
    try:
        first = resp_dict.setdefault("choices", [{}])[0]
    except (IndexError, TypeError):
        first = {}
        resp_dict["choices"] = [first]
    msg = first.setdefault("message", {})
    msg["content"] = content
    msg["role"] = msg.get("role") or "assistant"
    if clear_tool_calls:
        msg.pop("tool_calls", None)
    if finish_reason is not None:
        first["finish_reason"] = finish_reason
    return resp_dict


__all__ = [
    "is_new_user_turn",
    "last_user_content",
    "trailing_tool_messages",
    "replace_message_content",
    "response_assistant_message",
    "response_choice_count",
    "response_tool_calls",
    "response_content",
    "parse_tool_arguments",
    "serialise_tool_arguments",
    "rewrite_response_as_block",
    "rewrite_response_content",
    "rewrite_tool_call_arguments",
    "rewrite_tool_call_id",
]
