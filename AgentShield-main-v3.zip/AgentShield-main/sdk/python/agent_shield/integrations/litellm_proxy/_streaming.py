"""Buffer-mode streaming assembler for the LiteLLM Proxy guardrail.

LiteLLM's ``async_post_call_streaming_iterator_hook`` is required to
``yield`` the post-guardrail chunk sequence. The proxy owns SSE framing,
so the callback never writes raw ``[DONE]``; it just emits
``ModelResponseStream`` (or compatible) objects in the order the
client should see them.

Buffer-mode strategy:

1. Drain the upstream iterator, accumulating ``delta.content`` and
   reassembling chunked ``tool_calls`` keyed by their ``index`` (per
   the OpenAI streaming spec, ``function.arguments`` strings are
   delivered split across many deltas).
2. After EOF, return the assembled state to the caller so Stages 2/3 /
   5 can validate it.
3. The caller decides whether to replay the original chunks
   (``allow``) or emit a single synthesised block / mutation chunk.

Why buffer-mode rather than per-chunk inline gating: Stage 5
detection patterns (regex, classifier, semantic) need the full
response or partial matches race the verdict; Stage 2/3 needs
complete ``function.arguments`` JSON to validate at all; mutation
and block paths can't unsay bytes already streamed to the client.
The trade-off is TTFT going from first-token to full-response; the
correctness win is what makes Stage 5 enforceable at all.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Dict, List, Optional

from ._messages import _as_dict

logger = logging.getLogger("agent_shield.litellm_proxy")


# ── Assembled-stream state ──────────────────────────────────────────────

@dataclass
class _ToolCallBuilder:
    """Per-tool-call accumulator keyed by ``tool_calls[*].index``."""

    id: Optional[str] = None
    type: Optional[str] = None
    name: Optional[str] = None
    arguments: str = ""

    def as_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id or "",
            "type": self.type or "function",
            "function": {
                "name": self.name or "",
                "arguments": self.arguments,
            },
        }


@dataclass
class AssembledStream:
    """Result of draining a streaming response.

    Attributes:
        content: Concatenated ``delta.content`` across every chunk.
        tool_calls: One entry per ``tool_calls[*].index``, in index
            order. Each entry is the OpenAI-Chat tool-call dict
            (``{id, type, function: {name, arguments}}``).
        finish_reason: The last non-``None`` ``finish_reason`` seen
            on the upstream stream — usually ``"stop"`` for plain text
            and ``"tool_calls"`` when the model emitted a tool call.
        original_chunks: The chunks we drained, in order. Yielded
            verbatim on the allow path so callers see byte-equivalent
            output.
        template_chunk: A reference chunk we use to mint replacement
            chunks for block/mutate paths (so ``id``, ``model``, and
            ``created`` match the upstream identifiers).
        saw_extra_choices: ``True`` when any upstream chunk carried
            a ``choice`` with ``index > 0`` or more than one
            ``choices`` entry. The guardrail uses this to fail-closed
            on multi-choice streams, same as the non-streaming path.
    """

    content: str = ""
    tool_calls: List[Dict[str, Any]] = field(default_factory=list)
    finish_reason: Optional[str] = None
    original_chunks: List[Any] = field(default_factory=list)
    template_chunk: Optional[Any] = None
    saw_extra_choices: bool = False


async def drain_stream(upstream: AsyncIterator[Any]) -> AssembledStream:
    """Drain ``upstream`` into an :class:`AssembledStream`.

    Tolerates both pydantic ``ModelResponseStream`` chunks and plain
    dicts in the same stream — necessary because some LiteLLM versions
    mix the two.
    """
    state = AssembledStream()
    builders: Dict[int, _ToolCallBuilder] = {}

    async for chunk in upstream:
        state.original_chunks.append(chunk)
        if state.template_chunk is None:
            state.template_chunk = chunk

        chunk_dict = _as_dict(chunk)
        choices = chunk_dict.get("choices") or []
        if not choices:
            continue
        if isinstance(choices, list) and len(choices) > 1:
            state.saw_extra_choices = True
        first = _as_dict(choices[0])
        # Flag any explicit non-zero choice index (some providers
        # spread multi-choice across separate chunks rather than a
        # single chunk with len(choices) > 1).
        idx_field = first.get("index")
        if isinstance(idx_field, int) and idx_field > 0:
            state.saw_extra_choices = True
        delta = _as_dict(first.get("delta"))

        content = delta.get("content")
        if isinstance(content, str):
            state.content += content

        finish = first.get("finish_reason")
        if finish is not None:
            state.finish_reason = finish

        deltas = delta.get("tool_calls") or []
        for tc_delta in deltas:
            tcd = _as_dict(tc_delta)
            idx = tcd.get("index")
            if not isinstance(idx, int):
                # OpenAI streaming guarantees ``index`` on every
                # tool_call delta; if a provider drops it, fall back
                # to the order of arrival.
                idx = len(builders)
            builder = builders.setdefault(idx, _ToolCallBuilder())
            if tcd.get("id"):
                builder.id = tcd["id"]
            if tcd.get("type"):
                builder.type = tcd["type"]
            fn = _as_dict(tcd.get("function"))
            if fn.get("name"):
                builder.name = fn["name"]
            if isinstance(fn.get("arguments"), str):
                builder.arguments += fn["arguments"]

    state.tool_calls = [
        builders[i].as_dict() for i in sorted(builders.keys())
    ]
    return state


# ── Chunk minting helpers ───────────────────────────────────────────────

def _model_response_stream_cls() -> Any:
    """Return the LiteLLM ``ModelResponseStream`` class, or ``None``.

    Imported lazily so this module stays importable without litellm
    (the rest of the integration package is also import-time safe).
    """
    try:
        from litellm.types.utils import ModelResponseStream
        return ModelResponseStream
    except ImportError:  # pragma: no cover — litellm always present in real flows
        return None


def make_block_chunk(template: Any, message: str) -> Any:
    """Mint a single replacement chunk carrying a block / mutation string.

    The returned chunk:
      * has the same ``id`` / ``created`` / ``model`` as ``template``
        (so the SSE stream looks like a regular completion to clients
        that key off those fields);
      * carries ``delta.content = message``, no ``tool_calls``;
      * sets ``finish_reason = "stop"`` so OpenAI-spec-compliant
        clients close the stream cleanly.
    """
    cls = _model_response_stream_cls()
    template_dict = _as_dict(template) if template is not None else {}
    chunk_id = template_dict.get("id")
    created = template_dict.get("created")
    model = template_dict.get("model")

    delta = {"content": message, "role": "assistant", "tool_calls": None}
    choice = {"index": 0, "delta": delta, "finish_reason": "stop"}

    if cls is not None:
        try:
            return cls(
                id=chunk_id,
                created=created,
                model=model,
                choices=[choice],
            )
        except Exception:  # noqa: BLE001 — fall through to dict shape
            logger.debug(
                "litellm-proxy: could not mint ModelResponseStream chunk; "
                "falling back to dict shape", exc_info=True,
            )

    return {
        "id": chunk_id,
        "created": created,
        "model": model,
        "object": "chat.completion.chunk",
        "choices": [choice],
    }


def make_tool_call_chunk(
    template: Any, tool_calls: List[Dict[str, Any]],
) -> Any:
    """Mint a single replacement chunk carrying mutated ``tool_calls``.

    Used when Stage 3 rewrote tool-call arguments on a streamed
    response: replaying the original chunks would leak the
    un-mutated arguments, so we collapse the whole stream into one
    final chunk carrying the canonical mutated tool_calls and
    ``finish_reason="tool_calls"``.

    Each tool-call dict must have ``id``, ``type``, and
    ``function.{name, arguments}`` keys (the same shape produced by
    :class:`AssembledStream`).
    """
    cls = _model_response_stream_cls()
    template_dict = _as_dict(template) if template is not None else {}
    chunk_id = template_dict.get("id")
    created = template_dict.get("created")
    model = template_dict.get("model")

    # Build the streaming-shape tool_calls list with explicit indices.
    deltas: List[Dict[str, Any]] = []
    for i, tc in enumerate(tool_calls):
        deltas.append({
            "index": i,
            "id": tc.get("id"),
            "type": tc.get("type") or "function",
            "function": {
                "name": tc.get("function", {}).get("name") or "",
                "arguments": tc.get("function", {}).get("arguments") or "",
            },
        })

    delta = {
        "content": None,
        "role": "assistant",
        "tool_calls": deltas,
    }
    choice = {
        "index": 0,
        "delta": delta,
        "finish_reason": "tool_calls",
    }

    if cls is not None:
        try:
            return cls(
                id=chunk_id,
                created=created,
                model=model,
                choices=[choice],
            )
        except Exception:  # noqa: BLE001 — dict fallback
            logger.debug(
                "litellm-proxy: could not mint ModelResponseStream "
                "tool-call chunk; using dict shape", exc_info=True,
            )

    return {
        "id": chunk_id,
        "created": created,
        "model": model,
        "object": "chat.completion.chunk",
        "choices": [choice],
    }


async def replay_chunks(chunks: List[Any]) -> AsyncIterator[Any]:
    """Yield the captured chunks in order (allow path)."""
    for chunk in chunks:
        yield chunk


async def emit_block(template: Any, message: str) -> AsyncIterator[Any]:
    """Yield a single block-chunk built from ``template`` (block path)."""
    yield make_block_chunk(template, message)


__all__ = [
    "AssembledStream",
    "drain_stream",
    "make_block_chunk",
    "make_tool_call_chunk",
    "replay_chunks",
    "emit_block",
]
