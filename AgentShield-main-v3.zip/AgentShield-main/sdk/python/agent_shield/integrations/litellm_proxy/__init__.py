"""Agent Shield ↔ LiteLLM Proxy integration.

Drop-in :class:`litellm.integrations.custom_guardrail.CustomGuardrail`
subclass that wires the five Agent Shield validation stages into
LiteLLM Proxy. Install with::

    pip install agent-shield[litellm-proxy]

Then in your LiteLLM Proxy ``config.yaml`` add either::

    litellm_settings:
      callbacks:
        - agent_shield.integrations.litellm_proxy.agentshield_guardrail

or, to use LiteLLM's native ``guardrails:`` config (recommended — gives
operators per-route ``mode:`` selectors and the proxy's guardrail
metrics surface)::

    guardrails:
      - guardrail_name: agent_shield
        litellm_params:
          guardrail: agent_shield.integrations.litellm_proxy.AgentShieldLiteLLMGuardrail
          mode: ["pre_call", "post_call"]
          guardrails_path: /etc/agent-shield/guardrails.yaml

See ``docs/integrations/litellm-proxy.md`` for the threat model,
stage-coverage matrix, and the streaming / human-approval caveats.
"""
from __future__ import annotations

from ._guardrail import (
    AgentShieldLiteLLMGuardrail,
    agentshield_guardrail,
    make_guardrail,
)

__all__ = [
    "AgentShieldLiteLLMGuardrail",
    "make_guardrail",
    "agentshield_guardrail",
]
