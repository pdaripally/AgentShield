"""Per-session state cache for the LiteLLM Proxy integration.

Thin wrapper around :class:`agent_shield._native.HookSessionRegistry`
from the Rust core. The registry owns the bounded LRU, lease-aware
eviction, TTL sweep, and the cross-hook in-flight request token.
This module adds only what is genuinely host-language: the
per-session :class:`asyncio.Lock` (Python-side async serialisation of
hook callbacks) and the public :class:`agent_shield.Session` view used
by the integration for direct ``validate_*`` / ``record_*`` calls.

Both the lock and the ``Session`` view share a single underlying
:class:`agent_shield._native.HookSession` per ``session_id`` for the
duration of one acquire, so turn / request lifecycle and stage
validation always refer to the same canonical state.
"""
from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from typing import Any, AsyncIterator, Dict, Iterator

import agent_shield._native as _native

logger = logging.getLogger("agent_shield.litellm_proxy")


class _Entry:
    """Per-session carrier returned by :meth:`SessionCache.acquire`.

    Three attributes:

    * :attr:`hook` — the native :class:`HookSession` lease. Owns turn
      lifecycle, the cross-hook request token, and the per-turn
      scratch K/V (used here for the ``tool_call_id -> tool_name``
      map). Released automatically when the ``async with`` block on
      :meth:`SessionCache.acquire` exits.
    * :attr:`session` — a :class:`agent_shield.Session` view over the
      same underlying core session as :attr:`hook`, used for direct
      ``validate_*`` / ``record_*`` calls.
    * :attr:`lock` — per-session :class:`asyncio.Lock` so concurrent
      hook callbacks for the same session id serialise.

    Read-only properties (:attr:`turn_open`, :attr:`pending_tool_calls`,
    :attr:`in_flight_token`) proxy onto the underlying ``hook`` so
    existing call sites that inspected the prior dataclass shape
    continue to work.
    """

    __slots__ = ("hook", "session", "lock")

    _PENDING_TOOL_CALLS_KEY = "litellm.pending_tool_calls"

    def __init__(
        self,
        hook: "_native.HookSession",
        session: Any,
        lock: asyncio.Lock,
    ) -> None:
        self.hook = hook
        self.session = session
        self.lock = lock

    @property
    def turn_open(self) -> bool:
        return self.hook.turn_is_open()

    @turn_open.setter
    def turn_open(self, value: bool) -> None:
        # Back-compat: pre-extraction code set this flag manually
        # alongside ``entry.session.begin_turn()`` / ``end_turn()``.
        # Now turn state is owned by the underlying session and
        # already reflects the begin_turn / end_turn calls; the
        # setter is a no-op when the requested state matches what
        # the session reports, and otherwise drives the turn through
        # the right HookSession method to keep state consistent.
        current = self.hook.turn_is_open()
        if value == current:
            return
        if value:
            self.hook.begin_turn()
        else:
            self.hook.end_turn()

    @property
    def pending_tool_calls(self) -> Dict[str, str]:
        v = self.hook.turn_kv_get(self._PENDING_TOOL_CALLS_KEY)
        return v if isinstance(v, dict) else {}

    @property
    def in_flight_token(self) -> Any:
        # Truthy iff a request scope is open. The actual numeric
        # token lives inside the Rust HookSession; this property
        # only exists for back-compat with code that checked
        # ``if entry.in_flight_token is not None``.
        return "open" if self.hook.request_is_open() else None


class SessionCache:
    """Bounded LRU of ``session_id -> _Entry``.

    Cache mechanics (LRU eviction, lease counter, TTL sweep,
    in-flight stale-token recovery) live in
    :class:`agent_shield._native.HookSessionRegistry`. This wrapper
    adds the per-session :class:`asyncio.Lock` and constructs the
    public :class:`agent_shield.Session` view per acquire.

    Args:
        runtime: An :class:`agent_shield.Runtime` produced by
            :class:`agent_shield.RuntimeBuilder`. The cache uses its
            underlying native runtime.
        max_size: LRU capacity passed to the registry.
        ttl_seconds: Idle TTL passed to the registry. ``0`` disables.
        in_flight_timeout_seconds: Stale-token timeout for the
            cross-hook request scope. Default 5 min.
    """

    def __init__(
        self,
        runtime: Any,
        *,
        max_size: int = 512,
        ttl_seconds: float = 1800.0,
        in_flight_timeout_seconds: float = 300.0,
    ) -> None:
        if max_size < 1:
            raise ValueError("max_size must be >= 1")
        native_runtime = runtime._native if hasattr(runtime, "_native") else runtime
        self._registry = _native.HookSessionRegistry(
            native_runtime,
            max_size=max_size,
            ttl_seconds=int(ttl_seconds),
            in_flight_timeout_seconds=int(in_flight_timeout_seconds),
        )
        # Per-session async locks. Outlive any single acquire so
        # concurrent callers serialise.
        self._locks: Dict[str, asyncio.Lock] = {}
        # Per-session Python ``Session`` wrappers, cached so callers
        # that monkey-patch methods on a Session see the patches
        # persist across hook invocations.
        self._sessions: Dict[str, Any] = {}

    def _build_entry(self, session_id: str) -> "_Entry":
        hook = self._registry.acquire(session_id, {"session_id": session_id})
        py_session = self._sessions.get(session_id)
        if py_session is None:
            from agent_shield.runtime import Session as _PySession

            py_session = _PySession(hook.guardrails_session())
            self._sessions[session_id] = py_session
        lock = self._locks.setdefault(session_id, asyncio.Lock())
        return _Entry(hook=hook, session=py_session, lock=lock)

    def __len__(self) -> int:
        return len(self._registry)

    def __contains__(self, session_id: object) -> bool:
        return session_id in self._locks

    def __iter__(self) -> Iterator[str]:
        return iter(list(self._locks.keys()))

    def get_or_create(self, session_id: str) -> _Entry:
        """Synchronous accessor for inspecting / interacting with a
        cached session.

        Returns an :class:`_Entry` whose underlying lease is held
        until the entry is garbage-collected or its ``hook.release()``
        is called explicitly. Intended for tests and one-off
        inspection; production hook callbacks should always use
        :meth:`acquire` so the lease is released deterministically.
        """
        return self._build_entry(session_id)

    def drop(self, session_id: str) -> None:
        """Forget the per-session asyncio.Lock and Session wrapper
        entries. The Rust registry handles its own session eviction;
        this releases the integration-side bookkeeping so it doesn't
        accumulate when a session id is gone for good."""
        self._locks.pop(session_id, None)
        self._sessions.pop(session_id, None)

    @asynccontextmanager
    async def acquire(self, session_id: str) -> AsyncIterator[_Entry]:
        """Resolve + lock a session entry for the duration of one hook.

        Order matters:

        1. Take the per-session :class:`asyncio.Lock` first so
           concurrent callers serialise in arrival order.
        2. Acquire the native :class:`HookSession` lease inside the
           lock so we don't hold the eviction-protection counter
           while queued.
        3. Build a :class:`agent_shield.Session` view over the same
           underlying core session as the lease.
        4. Yield. On exit, release the lease (the lock is released
           by ``async with``).
        """
        lock = self._locks.setdefault(session_id, asyncio.Lock())
        async with lock:
            entry = self._build_entry(session_id)
            try:
                yield entry
            finally:
                entry.hook.release()


def _safe_end_turn(entry: _Entry) -> None:
    """Best-effort ``end_turn`` on a cache entry.

    The Rust ``end_turn`` is a no-op when no turn is open; we still
    swallow exceptions so a teardown error never breaks the calling
    hook.
    """
    if not entry.hook.turn_is_open():
        return
    try:
        entry.hook.end_turn()
    except Exception:  # noqa: BLE001 — best-effort
        logger.debug(
            "litellm-proxy: end_turn raised during cleanup; ignoring",
            exc_info=True,
        )


__all__ = ["SessionCache", "_Entry", "_safe_end_turn"]
