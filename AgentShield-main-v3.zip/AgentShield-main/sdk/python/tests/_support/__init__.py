"""Shared helpers for Python SDK tests."""
