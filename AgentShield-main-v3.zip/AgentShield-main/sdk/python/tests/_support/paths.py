"""Stable paths used by Python SDK tests."""
from __future__ import annotations

from pathlib import Path

TESTS_ROOT = Path(__file__).resolve().parents[1]
PYTHON_ROOT = TESTS_ROOT.parent
SDK_ROOT = PYTHON_ROOT.parent
REPO_ROOT = SDK_ROOT.parent
GLOBAL_FIXTURES = REPO_ROOT / "tests" / "fixtures"
LOCAL_FIXTURES = TESTS_ROOT / "fixtures_smoke"
