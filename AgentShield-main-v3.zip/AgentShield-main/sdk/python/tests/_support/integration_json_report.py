from __future__ import annotations

import json
import os
import tomllib
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from .paths import REPO_ROOT

DEFAULT_VERSION = "0.13.0"
PYTHON_PYPROJECT = REPO_ROOT / "sdk" / "python" / "pyproject.toml"


@dataclass
class IntegrationResultRecord:
    suite: str
    case: str
    status: Optional[str] = None
    duration_ms: float = 0.0
    error_detail: Optional[str] = None
    xfail_reason: Optional[str] = None


class IntegrationJsonReporter:
    def __init__(self, output_path: str | None) -> None:
        self.output_path = Path(output_path) if output_path else None
        self._records: dict[str, IntegrationResultRecord] = {}
        self._order: list[str] = []
        self._sdk_version, self._core_version = _load_versions()

    @property
    def enabled(self) -> bool:
        return self.output_path is not None

    def register_case(self, nodeid: str, *, suite: str, case: str, xfail_reason: str | None = None) -> None:
        if nodeid in self._records:
            return
        self._records[nodeid] = IntegrationResultRecord(
            suite=suite,
            case=case,
            xfail_reason=xfail_reason,
        )
        self._order.append(nodeid)

    def add_duration(self, nodeid: str, duration_s: float) -> None:
        record = self._records.get(nodeid)
        if record is None:
            return
        record.duration_ms += max(duration_s, 0.0) * 1000.0

    def apply_report(self, nodeid: str, report: Any, call: Any) -> None:
        record = self._records.get(nodeid)
        if record is None:
            return

        status, detail = classify_report(report, call)
        if status is None:
            return

        if report.when == "teardown" and record.status is not None:
            return
        if report.when == "setup" and record.status in {"pass", "fail", "skip", "xfail", "unknown_action"}:
            return

        record.status = status
        record.error_detail = _normalize_detail(detail)

    def build_payload(self) -> dict[str, Any]:
        return {
            "sdk": "python",
            "sdk_version": self._sdk_version,
            "core_version": self._core_version,
            "timestamp": datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
            "results": [
                {
                    "suite": self._records[nodeid].suite,
                    "case": self._records[nodeid].case,
                    "status": self._records[nodeid].status or "error",
                    "duration_ms": int(round(self._records[nodeid].duration_ms)),
                    "error_detail": self._records[nodeid].error_detail,
                }
                for nodeid in self._order
            ],
        }

    def write_json(self) -> None:
        if not self.output_path:
            return
        self.output_path.parent.mkdir(parents=True, exist_ok=True)
        with self.output_path.open("w", encoding="utf-8") as handle:
            json.dump(self.build_payload(), handle, indent=2)
            handle.write("\n")


def classify_report(report: Any, call: Any) -> tuple[str | None, str | None]:
    wasxfail = getattr(report, "wasxfail", None)
    if wasxfail:
        if getattr(report, "skipped", False):
            return "xfail", str(wasxfail)
        return "fail", _report_text(report)

    if getattr(report, "skipped", False):
        return "skip", _report_text(report)

    if not getattr(report, "failed", False):
        if getattr(report, "passed", False) and getattr(report, "when", None) == "call":
            return "pass", None
        return None, None

    excinfo = getattr(call, "excinfo", None)
    if getattr(report, "when", None) != "call":
        return "error", _exception_message(excinfo) or _report_text(report)

    if _is_unknown_action_failure(excinfo, report):
        return "unknown_action", _exception_message(excinfo) or _report_text(report)
    if _is_assertion_failure(excinfo):
        return "fail", _exception_message(excinfo) or _report_text(report)
    return "error", _exception_message(excinfo) or _report_text(report)


def _is_assertion_failure(excinfo: Any) -> bool:
    if excinfo is None or getattr(excinfo, "type", None) is None:
        return False
    exc_type = excinfo.type
    return issubclass(exc_type, AssertionError) or exc_type.__name__ == "Failed"


def _is_unknown_action_failure(excinfo: Any, report: Any) -> bool:
    if excinfo is not None and getattr(excinfo, "type", None) is not None:
        exc_type = excinfo.type
        if exc_type.__name__ == "UnknownActionError":
            return True
        value = getattr(excinfo, "value", None)
        if value is not None and "Unknown action verb:" in str(value):
            return True
    return "Unknown action verb:" in _report_text(report)


def _exception_message(excinfo: Any) -> str | None:
    value = getattr(excinfo, "value", None)
    if value is None:
        return None
    return str(value)


def _report_text(report: Any) -> str | None:
    if hasattr(report, "longreprtext"):
        return report.longreprtext
    longrepr = getattr(report, "longrepr", None)
    if longrepr is None:
        return None
    return str(longrepr)


def _normalize_detail(detail: str | None) -> str | None:
    if detail is None:
        return None
    stripped = detail.strip()
    return stripped or None


def _load_versions() -> tuple[str, str]:
    env_version = os.environ.get("AGENT_SHIELD_CORE_VERSION")
    if PYTHON_PYPROJECT.is_file():
        try:
            with PYTHON_PYPROJECT.open("rb") as handle:
                data = tomllib.load(handle)
            sdk_version = str(data.get("project", {}).get("version") or DEFAULT_VERSION)
            return sdk_version, env_version or sdk_version
        except Exception:
            pass
    return DEFAULT_VERSION, env_version or DEFAULT_VERSION
