"""YAML fixture helpers for Python SDK tests."""
from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml


def write_guardrails_yaml(tmp_path: Path, text: str, *, name: str = "guardrails") -> str:
    path = tmp_path / f"{name}.guardrails.yaml"
    path.write_text(text, encoding="utf-8")
    return str(path)


def make_guardrails_yaml(
    tmp_path: Path,
    *,
    resources: list[dict[str, Any]] | None = None,
    input_validators: list[dict[str, Any]] | None = None,
    output_validators: list[dict[str, Any]] | None = None,
    post_tool_validators: list[dict[str, Any]] | None = None,
    attributes: list[dict[str, Any]] | None = None,
    states: list[dict[str, Any]] | None = None,
    objective_goal: str = "Test agent",
    objective_forbidden: list[str] | None = None,
    name: str = "test-agent",
) -> str:
    config: dict[str, Any] = {
        "metadata": {"name": name, "version": "1.0.0"},
        "objective": {
            "goal": objective_goal,
            "forbidden": objective_forbidden or [],
        },
    }

    if resources is not None:
        config["resources"] = {"tools": list(resources)}
    if input_validators is not None:
        config["input_validation"] = {"validators": input_validators}
    if output_validators is not None:
        config["output_validation"] = {"validators": output_validators}
    if post_tool_validators is not None:
        config["post_tool_validation"] = {"validators": post_tool_validators}
    if attributes is not None:
        config["attributes"] = attributes
    if states is not None:
        config["state_validation"] = {"states": states}

    path = tmp_path / f"{name}.guardrails.yaml"
    path.write_text(yaml.dump(config, default_flow_style=False), encoding="utf-8")
    return str(path)
