"""Cross-SDK logging-parity test (Python side).

Reads the canonical fixture in ``tests/parity/logging_canonical.json``
and asserts every Info+ ``ShieldLogEvent`` emitted during a
representative end-to-end interaction carries the canonical 7 fields.

Mirror of the Rust runner at
``sdk/rust/agent_shield/tests/parity_logging_canonical.rs`` and the
.NET runner at
``sdk/dotnet/tests/AgentShield.Tests/Parity/LoggingCanonicalTests.cs``.
All three load the SAME ``tests/parity/logging_canonical.json`` so
the contract stays byte-aligned across languages.

Why this test exists:

- Logging parity ships no
  deprecation shims. But the parity contract is still load-bearing:
  it prevents one SDK silently dropping a required top-level field
  when adding new event emissions.

- The fixture documents WHICH 7 fields are required and WHY (per
  behavior contract). All three SDK runners assert against the same JSON,
  so the contract is byte-aligned across languages.
"""

from __future__ import annotations

import dataclasses
import json
from pathlib import Path
from typing import Any, Dict, List

import pytest

from agent_shield import RuntimeBuilder
from agent_shield.observability import CapturingProvider, ShieldLogEvent

MINIMAL_YAML = """
metadata:
  name: "parity-logging-canonical"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["parity test"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "echo"
      description: "Echo tool for the logging-canonical parity test."
      permission: "read_only"
"""

# Severities that count as "Info+" per docs/logging-style-guide.md
# Rule 3. Mirrors the Rust runner's ``is_info_plus`` filter.
INFO_PLUS_SEVERITIES = frozenset({"info", "low", "medium", "high", "critical"})


def _fixture_path() -> Path:
    """Walk up from this file to find the repo root (marked by .git),
    then resolve tests/parity/logging_canonical.json."""
    here = Path(__file__).resolve()
    for parent in here.parents:
        if (parent / ".git").exists():
            return parent / "tests" / "parity" / "logging_canonical.json"
    pytest.skip("repo root not found (no .git in any parent)")


def _drive_representative_interaction(provider: CapturingProvider) -> None:
    """Drive the runtime through a representative end-to-end
    interaction so the capturing provider sees a varied event stream."""
    runtime = (
        RuntimeBuilder.from_yaml_strings([MINIMAL_YAML])
        .register_observability_provider(provider)
        .build()
    )
    with runtime.new_session(
        session_id="sess-parity", correlation_id="corr-parity"
    ) as session:
        session.begin_turn()
        session.validate_input("hello")
        session.validate_tool_call("echo", {"msg": "ping"}, tool_call_id="tc-parity")
        session.record_tool_success("echo", {"out": "pong"})
        session.validate_output("agent said: pong")
        session.end_turn()


def _event_to_dict(event: ShieldLogEvent) -> Dict[str, Any]:
    """Project a ShieldLogEvent dataclass to a dict mirroring the
    Rust serde wire shape: nullable fields with ``None`` values are
    OMITTED from the dict (matching Rust's
    ``skip_serializing_if = "Option::is_none"``). Required fields
    stay even when their value is the empty string."""
    out: Dict[str, Any] = {}
    nullable_fields = {
        "stage",
        "action",
        "guard_policy",
        "evaluate_when_index",
        "resource",
        "variable",
        "event_id",
        "agent_id",
        "user_id",
        "tenant_id",
    }
    for f in dataclasses.fields(event):
        v = getattr(event, f.name)
        if f.name in nullable_fields and v is None:
            continue
        out[f.name] = v
    return out


def _assert_wire_value_matches_contract(
    event_type: str, field_name: str, value: Any, spec: Dict[str, Any]
) -> None:
    expected_type = spec["type"]

    if expected_type in {"string", "string-enum"}:
        assert isinstance(value, str), (
            f"Info+ event {event_type!r}: field {field_name!r} must serialize "
            f"as str, got {type(value).__name__}"
        )
        if expected_type == "string-enum" and "values" in spec:
            allowed = spec["values"]
            assert value in allowed, (
                f"Info+ event {event_type!r}: field {field_name!r} had value "
                f"{value!r} outside {allowed!r}"
            )
        return

    raise AssertionError(f"unsupported contract field type: {expected_type!r}")


def test_every_info_plus_event_carries_the_canonical_seven_fields() -> None:
    fixture = _fixture_path()
    if not fixture.exists():
        pytest.skip(f"logging_canonical.json not found at {fixture}")
    doc = json.loads(fixture.read_text(encoding="utf-8"))
    required_fields: List[Dict[str, Any]] = doc["required_fields"]

    # Sanity: the contract must list exactly the seven field names
    # we care about, in the established order.
    expected_names = [
        "session_id",
        "correlation_id",
        "stage",
        "action",
        "event_type",
        "severity",
        "agent_id",
    ]
    actual_names = [f["name"] for f in required_fields]
    assert actual_names == expected_names, (
        "logging_canonical.json field-list drift; update the fixture "
        "AND all three SDK runners together"
    )

    provider = CapturingProvider()
    _drive_representative_interaction(provider)

    captured = provider.events
    assert captured, "expected at least one event from a representative interaction"

    info_plus_seen = 0
    for event in captured:
        if event.severity not in INFO_PLUS_SEVERITIES:
            continue
        info_plus_seen += 1
        wire = _event_to_dict(event)

        for spec in required_fields:
            field_name = spec["python_field"]
            nullable = bool(spec.get("nullable", False))
            if not nullable:
                assert field_name in wire, (
                    f"Info+ event {event.event_type!r} is missing required "
                    f"field {field_name!r} on the wire"
                )
                value = wire[field_name]
                assert value is not None, (
                    f"Info+ event {event.event_type!r}: required field "
                    f"{field_name!r} is None but contract says non-nullable"
                )
                if isinstance(value, str):
                    assert value != "", (
                        f"Info+ event {event.event_type!r}: required field "
                        f"{field_name!r} is empty string but contract says non-nullable"
                    )
                _assert_wire_value_matches_contract(event.event_type, field_name, value, spec)
                continue

            if field_name in wire:
                value = wire[field_name]
                assert value is not None, (
                    f"Info+ event {event.event_type!r}: nullable field "
                    f"{field_name!r} must be omitted or typed on the wire, got None"
                )
                _assert_wire_value_matches_contract(event.event_type, field_name, value, spec)

    assert info_plus_seen > 0, (
        "expected at least one Info+ event in the captured stream"
    )
