"""Cross-language parity tests for the Python SDK.

See `tests/parity/README.md` for the full architecture. The canonical
contracts live at `tests/parity/shield_canonical_api.json` and
`tests/parity/capability_canonical.json`.
"""
