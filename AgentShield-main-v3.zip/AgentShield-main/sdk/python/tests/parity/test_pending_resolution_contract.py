"""Behavior tests consolidated into parity/test_pending_resolution_contract.py."""
from __future__ import annotations
from .._support.paths import REPO_ROOT
import asyncio
import sys
import types
import pytest
from agent_shield import RuntimeBuilder
_contract_pending_resolution_REPO_ROOT = REPO_ROOT
_contract_pending_resolution_FIXTURE_PATH = _contract_pending_resolution_REPO_ROOT / 'tests' / 'fixtures' / 'contract' / 'pending_resolution.guardrails.yaml'

def _contract_pending_resolution_assert_pending_shape(pending) -> None:
    """`kind: human` no longer surfaces pending_resolution; missing
    runtime handlers fail closed without a resumable MCP envelope."""
    assert pending is None, (
        "kind: human without a registered runtime handler must deny "
        "fail-closed without pending_resolution"
    )

@pytest.fixture
def _contract_pending_resolution_stub_agents_module(monkeypatch):
    fake = types.ModuleType('agents')

    class FunctionTool:

        def __init__(self, *, name, description='', params_json_schema=None, on_invoke_tool=None, strict_json_schema=True, failure_error_function=None):
            self.name = name
            self.description = description
            self.params_json_schema = params_json_schema or {}
            self.on_invoke_tool = on_invoke_tool
            self.strict_json_schema = strict_json_schema
            self.failure_error_function = failure_error_function

    class RunContextWrapper:

        def __init__(self, run_config=None):
            self.run_config = run_config

    class GuardrailFunctionOutput:

        def __init__(self, output_info, tripwire_triggered):
            self.output_info = output_info
            self.tripwire_triggered = tripwire_triggered
    fake.FunctionTool = FunctionTool
    fake.RunContextWrapper = RunContextWrapper
    fake.GuardrailFunctionOutput = GuardrailFunctionOutput
    fake.input_guardrail = lambda fn: fn
    fake.output_guardrail = lambda fn: fn
    monkeypatch.setitem(sys.modules, 'agents', fake)
    return fake

class TestContractPendingResolutionPythonDirectShield:
    """``GuardrailsSession.validate_tool_call`` — the lowest-level
    Python surface. Mirrors the regression case but pinned against
    the canonical cross-SDK fixture (every other SDK loads the same
    YAML)."""

    def test_validate_tool_call_carries_pending_resolution(self):
        runtime = RuntimeBuilder.from_yaml(str(_contract_pending_resolution_FIXTURE_PATH)).build()
        with runtime.new_session() as session:
            session.begin_turn()
            outcome = session.validate_tool_call('send_email', {'to': 'alice@example.com', 'subject': 'Hi'}, tool_call_id='contract-1')
        assert outcome.verdict.allowed is False, 'kind: human gate must block on first attempt'
        _contract_pending_resolution_assert_pending_shape(outcome.verdict.pending_resolution)

    def test_resume_via_set_variable_clears_pending(self):
        runtime = RuntimeBuilder.from_yaml(str(_contract_pending_resolution_FIXTURE_PATH)).build()
        with runtime.new_session() as session:
            session.begin_turn()
            blocked = session.validate_tool_call('send_email', {'to': 'alice@example.com'}, tool_call_id='contract-2a')
            assert blocked.verdict.allowed is False
            _contract_pending_resolution_assert_pending_shape(blocked.verdict.pending_resolution)
            session.set_variable('send_email_approved', True)
            allowed = session.validate_tool_call('send_email', {'to': 'alice@example.com'}, tool_call_id='contract-2b')
            assert allowed.verdict.allowed is True
            assert allowed.verdict.pending_resolution is None

class TestContractPendingResolutionPythonOpenaiAgentsLastPending:
    """``Shield.last_pending_resolution()`` after a Stage 3 block on a
    tool wrapped via ``protect_tools()``. This is the regression reference
    surface; the orchestrator must keep this working forever."""

    def test_protect_tools_last_pending_resolution(self, _contract_pending_resolution_stub_agents_module):
        from agent_shield import Shield
        shield = Shield.from_yaml(str(_contract_pending_resolution_FIXTURE_PATH), auto_bind=False).with_openai_agents().build()

        async def _execute(ctx, input_json):
            raise AssertionError('underlying tool must not execute on Stage 3 block')
        original = _contract_pending_resolution_stub_agents_module.FunctionTool(name='send_email', description='send email', params_json_schema={'type': 'object'}, on_invoke_tool=_execute)
        protected = shield.protect_tools([original])[0]
        ctx = _contract_pending_resolution_stub_agents_module.RunContextWrapper(run_config={})
        runtime = shield.runtime
        sess = runtime.new_session()
        sess.begin_turn()
        try:
            from agent_shield.adapters._orchestration import AgentShieldBlocked, current_session
            token = current_session.set(sess)
            try:
                with pytest.raises(AgentShieldBlocked) as exc_info:
                    asyncio.run(protected.on_invoke_tool(ctx, '{"to":"alice@example.com","subject":"Hi"}'))
            finally:
                current_session.reset(token)
        finally:
            sess.end_turn()
        message = exc_info.value.message
        assert 'GUARDRAIL' in message or 'blocked' in message.lower(), 'OpenAI Agents adapter must surface the block message via AgentShieldBlocked so Runner.run halts instead of feeding the message back to the LLM as a tool result.'
        pending = shield.last_pending_resolution()
        _contract_pending_resolution_assert_pending_shape(pending)

class TestContractPendingResolutionPythonAnthropicAgentsProtectTools:
    """``Shield.last_pending_resolution()`` after ``protect_tools()``
    on the Anthropic Agents adapter. The Anthropic adapter routes
    through the same ``_protect_tools_via_wrapper`` plumbing as
    OpenAI Agents, so this surface SHOULD already work."""

    def test_anthropic_protect_tools_last_pending_resolution(self, monkeypatch):
        fake_anthropic = types.ModuleType('anthropic')
        fake_anthropic_types = types.ModuleType('anthropic.types')
        fake_beta = types.ModuleType('anthropic.types.beta')

        class _BetaAsyncBuiltinFunctionTool:

            def __init__(self, *args, **kwargs):
                pass
        fake_beta.BetaAsyncBuiltinFunctionTool = _BetaAsyncBuiltinFunctionTool
        fake_anthropic_types.beta = fake_beta
        fake_anthropic.types = fake_anthropic_types
        monkeypatch.setitem(sys.modules, 'anthropic', fake_anthropic)
        monkeypatch.setitem(sys.modules, 'anthropic.types', fake_anthropic_types)
        monkeypatch.setitem(sys.modules, 'anthropic.types.beta', fake_beta)
        from agent_shield import Shield
        try:
            pass
        except Exception as exc:
            pytest.skip(f'anthropic_agents adapter could not be imported with stubs: {exc}')
        shield = Shield.from_yaml(str(_contract_pending_resolution_FIXTURE_PATH), auto_bind=False).with_anthropic_agents().build()

        class _DuckTool:
            name = 'send_email'
            description = 'send email'

            async def call(self, params):
                raise AssertionError('tool must not run on Stage 3 block')
        try:
            protected = shield.protect_tools([_DuckTool()])
        except Exception as exc:
            pytest.skip(f'Anthropic adapter rejected the duck-typed tool shape used by this contract test: {exc}. When fix-anthropic-dict-tools lands (regression), this test should be updated to use the canonical accepted shape.')
        assert len(protected) == 1
        wrapped_tool = protected[0]
        runtime = shield.runtime
        sess = runtime.new_session()
        sess.begin_turn()
        try:
            from agent_shield.adapters._orchestration import current_session
            token = current_session.set(sess)
            try:
                call_fn = getattr(wrapped_tool, 'call', None)
                if call_fn is None:
                    pytest.skip('Anthropic wrapped tool shape lacks .call(); adapter changed — update this contract test.')

                async def _call():
                    try:
                        await call_fn(input={'to': 'alice@example.com', 'subject': 'Hi'})
                    except Exception as err:
                        if 'GUARDRAIL' not in str(err):
                            raise
                asyncio.run(_call())
            finally:
                current_session.reset(token)
        finally:
            sess.end_turn()
        pending = shield.last_pending_resolution()
        _contract_pending_resolution_assert_pending_shape(pending)

class TestContractPendingResolutionPythonAnthropicAgentsRunAgent:
    """``shield.run_anthropic_agent(...)`` — the regression entry-point for
    the canonical Anthropic Messages API loop. Drives the full
    ``messages.create()`` → tool dispatch → ``messages.create()`` cycle
    against a mock client and asserts the ``kind: human`` block at the
    tool-dispatch boundary surfaces ``pending_resolution`` via
    ``Shield.last_pending_resolution()`` exactly as every other SDK
    surface does (parity with regression / regression / regression)."""

    def test_run_anthropic_agent_last_pending_resolution(self, monkeypatch):
        fake_anthropic = types.ModuleType('anthropic')
        fake_anthropic_types = types.ModuleType('anthropic.types')
        fake_beta = types.ModuleType('anthropic.types.beta')

        class _BetaAsyncBuiltinFunctionTool:

            def __init__(self, *args, **kwargs):
                pass
        fake_beta.BetaAsyncBuiltinFunctionTool = _BetaAsyncBuiltinFunctionTool
        fake_anthropic_types.beta = fake_beta
        fake_anthropic.types = fake_anthropic_types
        monkeypatch.setitem(sys.modules, 'anthropic', fake_anthropic)
        monkeypatch.setitem(sys.modules, 'anthropic.types', fake_anthropic_types)
        monkeypatch.setitem(sys.modules, 'anthropic.types.beta', fake_beta)
        from agent_shield import Shield
        try:
            pass
        except Exception as exc:
            pytest.skip(f'anthropic_agents adapter import failed: {exc}')
        shield = Shield.from_yaml(str(_contract_pending_resolution_FIXTURE_PATH), auto_bind=False).with_anthropic_agents().build()
        run = getattr(shield, 'run_anthropic_agent', None)
        if run is None:
            pytest.xfail('regression — `shield.run_anthropic_agent` not yet installed by the Anthropic adapter. Drop this xfail once the fix-anthropic-dict-tools agent lands the symbol.')

        class _ToolUseBlock:
            type = 'tool_use'

            def __init__(self, id, name, input):
                self.id = id
                self.name = name
                self.input = input

        class _TextBlock:
            type = 'text'

            def __init__(self, text):
                self.text = text

        class _Message:

            def __init__(self, content, stop_reason):
                self.content = content
                self.stop_reason = stop_reason

        class _Messages:

            def __init__(self):
                self.calls = []
                self._scripted = [([_ToolUseBlock('tu_1', 'send_email', {'to': 'alice@example.com', 'subject': 'Hi'})], 'tool_use'), ([_TextBlock('Email blocked.')], 'end_turn')]

            def create(self, **kwargs):
                self.calls.append(kwargs)
                if not self._scripted:
                    raise AssertionError('ran out of scripted responses')
                content, stop_reason = self._scripted.pop(0)
                return _Message(content, stop_reason)

        class _Anthropic:

            def __init__(self):
                self.messages = _Messages()

        def dispatch(name, params):
            raise AssertionError('dispatch must not execute on a Stage 3 kind: human block')
        tool_dict = {'name': 'send_email', 'description': 'Send an email.', 'input_schema': {'type': 'object', 'properties': {'to': {'type': 'string'}, 'subject': {'type': 'string'}}, 'required': ['to']}}
        asyncio.run(run(client=_Anthropic(), model='claude-sonnet-4-20250514', tools=[tool_dict], dispatch=dispatch, messages=[{'role': 'user', 'content': 'Send an email to alice.'}], max_tokens=128, max_iterations=2))
        pending = shield.last_pending_resolution()
        _contract_pending_resolution_assert_pending_shape(pending)

class TestContractPendingResolutionPythonLangchainLastPending:
    """LangChain adapter — ``Shield.last_pending_resolution()`` after a
    Stage 3 block on a tool wrapped via ``protect_tools()``. The
    LangChain adapter shares ``_protect_tools_via_wrapper`` with
    OpenAI Agents, so this SHOULD already work."""

    def test_langchain_protect_tools_last_pending_resolution(self, monkeypatch):
        try:
            from langchain_core.tools import StructuredTool
        except Exception as exc:
            pytest.skip(f"langchain_core.tools not importable in this env: {exc}. Install with: pip install 'agent-shield[langchain]'.")
        from agent_shield import Shield
        from langchain_core.tools import StructuredTool
        try:
            pass
        except Exception as exc:
            pytest.skip(f'langchain adapter import failed: {exc}')
        shield = Shield.from_yaml(str(_contract_pending_resolution_FIXTURE_PATH), auto_bind=False).with_langchain().build()

        def _execute(**kwargs):
            raise AssertionError('underlying tool must not execute on Stage 3 block')
        original = StructuredTool.from_function(func=_execute, name='send_email', description='Send email')
        protected = shield.protect_tools([original])[0]
        runtime = shield.runtime
        sess = runtime.new_session()
        sess.begin_turn()
        try:
            from agent_shield.adapters._orchestration import current_session
            token = current_session.set(sess)
            try:
                with pytest.raises(Exception):
                    if hasattr(protected, 'ainvoke'):
                        asyncio.run(protected.ainvoke({'to': 'alice@example.com', 'subject': 'Hi'}))
                    elif hasattr(protected, 'invoke'):
                        protected.invoke({'to': 'alice@example.com', 'subject': 'Hi'})
                    elif hasattr(protected, 'run'):
                        protected.run({'to': 'alice@example.com', 'subject': 'Hi'})
                    else:
                        pytest.skip('Wrapped LangChain tool exposes neither invoke nor run — adapter shape changed; update this test.')
            finally:
                current_session.reset(token)
        finally:
            sess.end_turn()
        pending = shield.last_pending_resolution()
        _contract_pending_resolution_assert_pending_shape(pending)
