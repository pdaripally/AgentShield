"""Shield / ShieldBuilder method-parity test for the Python SDK.

Asserts every canonical method declared with ``must_exist_in: [..., 'python', ...]``
in ``tests/parity/shield_canonical_api.json`` is present on the live
``Shield`` and ``ShieldBuilder`` classes under the Python alias.

Methods that exist in only some SDKs are tracked via ``must_exist_in``
itself — this test does not enforce them across languages, only inside
Python. Cross-language drift is read from the canonical file's
``drift_catalog`` block (the actionable artifact for the team).

The test is *additive* — extra Python-only methods are reported as
warnings (so we surface accidental API additions) unless they are
listed in the canonical file's ``language_specific_extensions.python``
block.
"""
from __future__ import annotations

import inspect
import json

import pytest


from .._support.paths import REPO_ROOT
CANONICAL_PATH = REPO_ROOT / "tests" / "parity" / "shield_canonical_api.json"
LANG = "python"


@pytest.fixture(scope="module")
def canonical() -> dict:
    with open(CANONICAL_PATH, encoding="utf-8") as f:
        return json.load(f)


@pytest.fixture(scope="module")
def shield_classes():
    """Import Shield + ShieldBuilder with every adapter installed.

    Importing the adapter modules monkey-installs ``with_<framework>()``
    methods on ``ShieldBuilder`` and ``create_<framework>_agent`` factories
    on ``Shield``. The parity test runs against the *fully-loaded* surface
    so the canonical can pin those installed methods too.
    """
    from agent_shield.adapters._shield import Shield, ShieldBuilder

    # Side-effect imports: install with_<framework>() / create_<framework>_agent().

    return Shield, ShieldBuilder


def _public_members(cls) -> set[str]:
    """Public attribute / method / property names on ``cls``.

    Also detects instance attributes assigned in ``__init__`` via a simple
    ``self.<name> =`` source-text probe — those don't surface on the class
    object via ``inspect`` but are still part of the public surface.
    """
    out: set[str] = set()
    for name, member in inspect.getmembers(cls):
        if name.startswith("_"):
            continue
        if (
            inspect.isfunction(member)
            or inspect.ismethod(member)
            or isinstance(member, (property, classmethod, staticmethod))
        ):
            out.add(name)

    # Probe __init__ source for `self.<name> =...` assignments.
    try:
        src = inspect.getsource(cls.__init__)
    except (OSError, TypeError):
        src = ""
    import re

    for match in re.finditer(r"self\.([a-zA-Z][a-zA-Z0-9_]*)\s*=", src):
        name = match.group(1)
        if not name.startswith("_"):
            out.add(name)
    return out


def _required_methods(canonical: dict, key: str) -> list[dict]:
    return [m for m in canonical[key] if LANG in m["must_exist_in"]]


def test_shield_canonical_methods_present(canonical, shield_classes):
    Shield, _ = shield_classes
    members = _public_members(Shield)
    missing: list[tuple[str, str]] = []
    for entry in _required_methods(canonical, "shield_methods"):
        alias = entry["aliases"][LANG]
        if alias not in members:
            missing.append((entry["name"], alias))

    assert not missing, (
        f"Shield is missing {len(missing)} canonical method(s) under their "
        f"Python aliases: {missing}. Either add the method to "
        f"agent_shield.adapters._shield.Shield or remove '{LANG}' from "
        f"`must_exist_in` in tests/parity/shield_canonical_api.json (and "
        f"document the drift in `drift_catalog.method_drift`)."
    )


def test_shield_builder_canonical_methods_present(canonical, shield_classes):
    _, ShieldBuilder = shield_classes
    members = _public_members(ShieldBuilder)
    missing: list[tuple[str, str]] = []
    for entry in _required_methods(canonical, "shield_builder_methods"):
        alias = entry["aliases"][LANG]
        if alias not in members:
            missing.append((entry["name"], alias))

    assert not missing, (
        f"ShieldBuilder is missing {len(missing)} canonical method(s) under "
        f"their Python aliases: {missing}. Either add the method to "
        f"agent_shield.adapters._shield.ShieldBuilder or remove '{LANG}' "
        f"from `must_exist_in` in tests/parity/shield_canonical_api.json."
    )


def test_no_undeclared_python_extensions(canonical, shield_classes):
    """Python-only public methods must be either canonical or declared.

    Surfaces accidental API additions: any new public method on Shield or
    ShieldBuilder that isn't in the canonical method list AND isn't in the
    declared ``language_specific_extensions.python`` block fails this test.
    Adding a method intentionally? Add it to either block.
    """
    Shield, ShieldBuilder = shield_classes

    canonical_shield = {
        e["aliases"][LANG]
        for e in canonical["shield_methods"]
        if LANG in e["aliases"]
    }
    canonical_builder = {
        e["aliases"][LANG]
        for e in canonical["shield_builder_methods"]
        if LANG in e["aliases"]
    }
    declared_extensions = canonical["language_specific_extensions"][LANG]
    extra_shield = set(declared_extensions.get("shield", []))
    extra_builder = set(declared_extensions.get("shield_builder", []))

    shield_actual = _public_members(Shield)
    builder_actual = _public_members(ShieldBuilder)

    undeclared_shield = (
        shield_actual - canonical_shield - extra_shield
    )
    undeclared_builder = (
        builder_actual - canonical_builder - extra_builder
    )

    msg_parts = []
    if undeclared_shield:
        msg_parts.append(
            f"Shield has {len(undeclared_shield)} undeclared public "
            f"method(s): {sorted(undeclared_shield)}"
        )
    if undeclared_builder:
        msg_parts.append(
            f"ShieldBuilder has {len(undeclared_builder)} undeclared public "
            f"method(s): {sorted(undeclared_builder)}"
        )

    assert not msg_parts, (
        "Undeclared public surface in Python — every public method must be "
        "either in `shield_methods`/`shield_builder_methods` (cross-language "
        "canonical) or in `language_specific_extensions.python` (Python-only) "
        "in tests/parity/shield_canonical_api.json. Found:\n  - "
        + "\n  - ".join(msg_parts)
    )
