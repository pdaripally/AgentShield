"""Cross-SDK telemetry-redaction parity test.

Reads ``tests/parity/telemetry_redaction_canonical.json`` and drives
each (policy, input_attributes) pair through the canonical core
redactor (via the PyO3 ``redact_log_event`` binding). The expected
post-redaction shape is asserted attribute-by-attribute so a failure
points at the exact key that diverged from the canonical output.

The Node, .NET, and Rust SDKs run the equivalent test against the same
fixture so the four SDKs stay byte-aligned on telemetry redaction
decisions.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from agent_shield._native import redact_log_event


def _fixture_path() -> Path:
    here = Path(__file__).resolve()
    # tests/parity/telemetry_redaction_canonical.json at repo root
    repo_root = here.parents[4]
    return repo_root / "tests" / "parity" / "telemetry_redaction_canonical.json"


_FIXTURE = (
    json.loads(_fixture_path().read_text()) if _fixture_path().exists() else {"cases": []}
)


def _build_event(input_attributes: dict) -> dict:
    """Synthesize a ShieldLogEvent dict carrying the case's attributes.

    The redactor only cares about ``message`` and ``attributes``; the
    other typed fields are populated with sentinel values so the
    serde round-trip succeeds.
    """
    return {
        "timestamp": "2026-05-19T00:00:00Z",
        "severity": "info",
        "event_type": "info",
        "category": "audit",
        "correlation_id": "test-corr",
        "session_id": "test-sess",
        "message": "parity test event",
        "attributes": input_attributes,
    }


@pytest.mark.parametrize(
    "case",
    _FIXTURE["cases"],
    ids=lambda c: c["name"],
)
def test_redaction_matches_canonical(case):
    event = _build_event(case["input_attributes"])
    out = redact_log_event(event, case["policy"])
    out_attrs = out["attributes"]

    expected = case["expected_attribute_shape"]
    for key, want in expected.items():
        got = out_attrs.get(key)
        if want.get("kept"):
            assert got == want["literal"], (
                f"{case['name']} key={key}: expected literal {want['literal']!r}, "
                f"got {got!r}"
            )
        else:
            assert isinstance(got, dict), (
                f"{case['name']} key={key}: expected redaction marker object, got {got!r}"
            )
            assert got.get("redacted") is True, (
                f"{case['name']} key={key}: marker missing `redacted: true` ({got!r})"
            )
            assert got.get("category") == want["category"], (
                f"{case['name']} key={key}: expected category {want['category']!r}, "
                f"got {got.get('category')!r}"
            )
            assert isinstance(got.get("byte_size"), int), (
                f"{case['name']} key={key}: marker missing integer byte_size ({got!r})"
            )

    # No extra keys leaked through that the fixture didn't anticipate.
    expected_keys = set(expected.keys())
    actual_keys = set(out_attrs.keys())
    extra = actual_keys - expected_keys
    assert not extra, (
        f"{case['name']}: unexpected attribute keys in output: {sorted(extra)}"
    )
