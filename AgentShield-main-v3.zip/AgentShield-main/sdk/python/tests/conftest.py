"""Shared fixtures for Agent Shield SDK tests.

After the standalone Python core deletion, fixtures that constructed
in-memory config objects are removed.  Tests should use YAML files
(from tests/fixtures/) or mock the Rust-backed runtime directly.

Prerequisites:
    pip install maturin pytest pyyaml
    cd sdk/python
    maturin develop --release
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from ._support.integration_json_report import IntegrationJsonReporter

# ---------------------------------------------------------------------------
# Helper: build YAML from resource dicts
# ---------------------------------------------------------------------------

def make_guardrails_yaml(
    tmp_path,
    *,
    resources=None,
    input_validators=None,
    output_validators=None,
    post_tool_validators=None,
    attributes=None,
    states=None,
    objective_goal="Test agent",
    objective_forbidden=None,
    name="test-agent",
):
    """Build a guardrails YAML file from keyword arguments.

    Convenience helper for tests that need a config without authoring
    the full YAML by hand.
    """
    import yaml

    config = {
        "metadata": {"name": name, "version": "1.0.0"},
        "objective": {
            "goal": objective_goal,
            "forbidden": objective_forbidden or [],
        },
    }

    if resources is not None:
        tools = []
        for r in resources:
            if isinstance(r, dict):
                tools.append(r)
            else:
                raise TypeError(f"resource must be a dict, got {type(r)}")
        config["resources"] = {"tools": tools}

    if input_validators is not None:
        config["input_validation"] = {"validators": input_validators}

    if output_validators is not None:
        config["output_validation"] = {"validators": output_validators}

    if post_tool_validators is not None:
        config["post_tool_validation"] = {"validators": post_tool_validators}

    if attributes is not None:
        config["attributes"] = attributes

    if states is not None:
        config["state_validation"] = {"states": states}

    path = tmp_path / f"{name}.guardrails.yaml"
    path.write_text(yaml.dump(config, default_flow_style=False), encoding="utf-8")
    return str(path)


_REPORTER_KEY = "_agent_shield_integration_json_reporter"


def _integration_case_metadata(item: pytest.Item):
    if Path(str(item.fspath)).name != "test_integration_cases.py":
        return None
    callspec = getattr(item, "callspec", None)
    if callspec is None:
        return None

    case_id = callspec.params.get("case_id")
    case = callspec.params.get("case") or {}
    if not isinstance(case_id, str) or not isinstance(case, dict):
        return None

    suite, _, case_name = case_id.partition("::")
    suite = str(case.get("_suite_name") or suite)
    case_name = str(case.get("name") or case_name or item.name)
    xfail_raw = case.get("xfail")
    xfail_entry = xfail_raw.get("python") if isinstance(xfail_raw, dict) else None
    xfail_reason = None
    if isinstance(xfail_entry, dict):
        issue = xfail_entry.get("issue")
        reason = xfail_entry.get("reason")
        parts = [str(part) for part in (issue, reason) if part]
        xfail_reason = ": ".join(parts) if parts else None
    return {
        "suite": suite,
        "case": case_name,
        "xfail_reason": xfail_reason,
    }


def pytest_configure(config: pytest.Config) -> None:
    setattr(config, _REPORTER_KEY, IntegrationJsonReporter(os.environ.get("AGENT_SHIELD_REPORT_JSON")))


def pytest_collection_modifyitems(config: pytest.Config, items: list[pytest.Item]) -> None:
    reporter = getattr(config, _REPORTER_KEY, None)
    if reporter is None:
        return

    for item in items:
        metadata = _integration_case_metadata(item)
        if metadata is None:
            continue
        reporter.register_case(item.nodeid, **metadata)
        if metadata["xfail_reason"]:
            item.add_marker(pytest.mark.xfail(reason=metadata["xfail_reason"], strict=True))


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item: pytest.Item, call: pytest.CallInfo[object]):
    outcome = yield
    report = outcome.get_result()

    reporter = getattr(item.config, _REPORTER_KEY, None)
    if reporter is None:
        return

    reporter.add_duration(item.nodeid, getattr(report, "duration", 0.0))
    reporter.apply_report(item.nodeid, report, call)


def pytest_sessionfinish(session: pytest.Session, exitstatus: int) -> None:
    reporter = getattr(session.config, _REPORTER_KEY, None)
    if reporter is None:
        return
    reporter.write_json()
