"""Behavior tests for `kind: human` after runtime-bound handler refactor."""
from __future__ import annotations

import asyncio
import os
import tempfile
from typing import Iterator

import pytest

from agent_shield import RuntimeBuilder, Shield

SEND_EMAIL_YAML = """
metadata:
  name: "human-runtime-bound"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["send email only after explicit approval"]
  forbidden: ["send without approval"]
resources:
  tools:
    - name: "send_email"
      description: "Send email."
      permission: "execute"
variables:
  - name: "send_email_authorized"
    type: "boolean"
    on_demand_by:
      kind: "human"
      prompt: "Approve sending email to ${@tool.params.to}?"
    lifetime: "per_session"
state_validation:
  guard_policies:
    - name: "send_email_requires_approval"
      applies_to:
        tools: ["send_email"]
      evaluate_when:
        - expression: "send_email_authorized == true"
          reason: "Sending email requires explicit user confirmation"
      action: "block"
"""


@pytest.fixture
def send_email_yaml_path() -> Iterator[str]:
    with tempfile.NamedTemporaryFile("w", suffix=".guardrails.yaml", delete=False) as f:
        f.write(SEND_EMAIL_YAML)
        path = f.name
    try:
        yield path
    finally:
        os.unlink(path)


def test_kind_human_block_has_no_pending_resolution(send_email_yaml_path: str) -> None:
    runtime = RuntimeBuilder.from_yaml(send_email_yaml_path).build()
    with runtime.new_session(session_id="s", correlation_id="c") as session:
        session.begin_turn()
        outcome = session.validate_tool_call(
            "send_email", {"to": "alice@example.com"}, tool_call_id="call-1"
        )
        verdict = outcome.verdict
        assert verdict.allowed is False
        assert hasattr(verdict, "pending_resolution")
        assert verdict.pending_resolution is None


def test_manual_set_variable_true_resumes_the_blocked_gate(send_email_yaml_path: str) -> None:
    runtime = RuntimeBuilder.from_yaml(send_email_yaml_path).build()
    with runtime.new_session(session_id="s", correlation_id="c") as session:
        session.begin_turn()
        params = {"to": "alice@example.com"}
        blocked = session.validate_tool_call("send_email", params, tool_call_id="call-1")
        assert blocked.verdict.allowed is False
        assert blocked.verdict.pending_resolution is None
        session.set_variable("send_email_authorized", True)
        resumed = session.validate_tool_call("send_email", params, tool_call_id="call-2")
        assert resumed.verdict.allowed is True
        assert resumed.verdict.pending_resolution is None


def test_shield_last_pending_resolution_stays_none(send_email_yaml_path: str) -> None:
    shield = Shield.from_yaml(send_email_yaml_path, auto_bind=False).build()

    async def _execute(params: dict) -> dict:
        return {"status": "sent", "to": params["to"]}

    async def _drive() -> None:
        with shield.runtime.new_session(session_id="s") as session:
            session.begin_request()
            blocked, _ = await shield.protect_tool(
                "send_email", {"to": "alice@example.com"}, _execute, session=session
            )
            assert blocked is True
            assert shield.last_pending_resolution() is None
            session.end_request()

    asyncio.run(_drive())


def test_resolve_pending_without_latch_or_set_variables_raises(send_email_yaml_path: str) -> None:
    shield = Shield.from_yaml(send_email_yaml_path, auto_bind=False).build()

    async def _drive() -> None:
        with shield.runtime.new_session(session_id="s") as session:
            shield._last_pending_session = session
            shield._last_pending_resolution = None
            with pytest.raises(RuntimeError, match="pending_resolution"):
                await shield.resolve_pending("allow")

    asyncio.run(_drive())
