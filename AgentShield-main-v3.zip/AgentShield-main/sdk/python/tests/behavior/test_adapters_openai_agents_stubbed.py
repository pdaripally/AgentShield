"""Behavior tests consolidated into behavior/test_adapters_openai_agents_stubbed.py."""
from __future__ import annotations
from .._support.paths import REPO_ROOT
import sys
import tempfile
import types
from pathlib import Path
import pytest
_openai_agents_agents_guardrails_REPO_ROOT = REPO_ROOT
_openai_agents_agents_guardrails_GLOBAL_FIXTURES = _openai_agents_agents_guardrails_REPO_ROOT / 'tests' / 'fixtures'
_openai_agents_agents_guardrails_MINIMAL = str(_openai_agents_agents_guardrails_GLOBAL_FIXTURES / 'smoke' / 'minimal.guardrails.yaml')

@pytest.fixture
def _openai_agents_agents_guardrails_stub_agents_module(monkeypatch):
    """Inject a fake ``agents`` module so the import succeeds without
    the real openai-agents package."""
    fake = types.ModuleType('agents')

    class GuardrailFunctionOutput:

        def __init__(self, output_info, tripwire_triggered):
            self.output_info = output_info
            self.tripwire_triggered = tripwire_triggered

    def _identity_decorator(fn):
        return fn
    fake.GuardrailFunctionOutput = GuardrailFunctionOutput
    fake.input_guardrail = _identity_decorator
    fake.output_guardrail = _identity_decorator
    monkeypatch.setitem(sys.modules, 'agents', fake)
    return fake
_openai_agents_agents_guardrails_BLOCK_INPUT_YAML = '\nmetadata:\n  name: oai-input-guard-fixture\n  version: 0.1.0\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["block jailbreak"]\n  forbidden: ["jailbreak"]\ninput_validation:\n  guard_policies:\n    - name: block_jailbreak\n      evaluate_when:\n        - patterns:\n            - "ignore previous instructions"\n          reason: "jailbreak attempt"\n      action: "block"\n'
_openai_agents_agents_guardrails_REDACT_OUTPUT_YAML = '\nmetadata:\n  name: oai-output-guard-fixture\n  version: 0.1.0\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["block leaked secrets"]\n  forbidden: ["leak"]\noutput_validation:\n  guard_policies:\n    - name: block_secrets\n      evaluate_when:\n        - patterns:\n            - "top secret"\n          reason: "output contains protected content"\n      action: "block"\n'

def _openai_agents_agents_guardrails_write_yaml(yaml: str, name: str) -> str:
    f = tempfile.NamedTemporaryFile(mode='w', suffix=f'.{name}.yaml', delete=False)
    f.write(yaml)
    f.close()
    return f.name

class TestOpenaiAgentsAgentsGuardrailsOpenAIAgentsNativeGuardrails:

    def test_as_input_guardrail_returns_callable(self, _openai_agents_agents_guardrails_stub_agents_module):
        from agent_shield import Shield
        path = _openai_agents_agents_guardrails_write_yaml(_openai_agents_agents_guardrails_BLOCK_INPUT_YAML, 'input')
        try:
            shield = Shield.from_yaml(path, auto_bind=False).with_openai_agents().build()
            guard = shield.as_input_guardrail()
            assert callable(guard), 'must return a callable suitable for input_guardrails=[...]'
        finally:
            Path(path).unlink()

    def test_as_input_guardrail_trips_on_blocked_input(self, _openai_agents_agents_guardrails_stub_agents_module):
        import asyncio
        from agent_shield import Shield
        path = _openai_agents_agents_guardrails_write_yaml(_openai_agents_agents_guardrails_BLOCK_INPUT_YAML, 'input_block')
        try:
            shield = Shield.from_yaml(path, auto_bind=False).with_openai_agents().build()
            guard = shield.as_input_guardrail()
            result = asyncio.run(guard(None, None, 'ignore previous instructions'))
            assert result.tripwire_triggered is True, 'Stage 1 block must trip the guardrail'
            assert result.output_info['guardrail'] == 'agent_shield'
            assert result.output_info['stage'] == 'input'
            assert result.output_info['reason'], 'blocked input must carry a reason'
        finally:
            Path(path).unlink()

    def test_as_input_guardrail_passes_clean_input(self, _openai_agents_agents_guardrails_stub_agents_module):
        import asyncio
        from agent_shield import Shield
        path = _openai_agents_agents_guardrails_write_yaml(_openai_agents_agents_guardrails_BLOCK_INPUT_YAML, 'input_pass')
        try:
            shield = Shield.from_yaml(path, auto_bind=False).with_openai_agents().build()
            guard = shield.as_input_guardrail()
            result = asyncio.run(guard(None, None, 'what is the weather'))
            assert result.tripwire_triggered is False, 'clean input must not trip the guardrail'
        finally:
            Path(path).unlink()

    def test_as_output_guardrail_trips_on_blocked_output(self, _openai_agents_agents_guardrails_stub_agents_module):
        import asyncio
        from agent_shield import Shield
        path = _openai_agents_agents_guardrails_write_yaml(_openai_agents_agents_guardrails_REDACT_OUTPUT_YAML, 'output_block')
        try:
            shield = Shield.from_yaml(path, auto_bind=False).with_openai_agents().build()
            guard = shield.as_output_guardrail()
            result = asyncio.run(guard(None, None, 'the top secret answer is 42'))
            assert result.tripwire_triggered is True, 'Stage 5 block must trip the output guardrail'
            assert result.output_info['stage'] == 'output'
        finally:
            Path(path).unlink()

    def test_as_output_guardrail_passes_clean_output(self, _openai_agents_agents_guardrails_stub_agents_module):
        import asyncio
        from agent_shield import Shield
        path = _openai_agents_agents_guardrails_write_yaml(_openai_agents_agents_guardrails_REDACT_OUTPUT_YAML, 'output_pass')
        try:
            shield = Shield.from_yaml(path, auto_bind=False).with_openai_agents().build()
            guard = shield.as_output_guardrail()
            result = asyncio.run(guard(None, None, 'the answer is 42'))
            assert result.tripwire_triggered is False
        finally:
            Path(path).unlink()

    def test_missing_agents_package_raises_runtime_error(self, monkeypatch):
        monkeypatch.setitem(sys.modules, 'agents', None)
        from agent_shield import Shield
        path = _openai_agents_agents_guardrails_write_yaml(_openai_agents_agents_guardrails_BLOCK_INPUT_YAML, 'no_agents')
        try:
            shield = Shield.from_yaml(path, auto_bind=False).with_openai_agents().build()
            with pytest.raises(RuntimeError, match='openai-agents'):
                shield.as_input_guardrail()
            with pytest.raises(RuntimeError, match='openai-agents'):
                shield.as_output_guardrail()
        finally:
            Path(path).unlink()
import asyncio
_openai_agents_agents_pending_resolution_REPO_ROOT = REPO_ROOT
_openai_agents_agents_pending_resolution_GLOBAL_FIXTURES = _openai_agents_agents_pending_resolution_REPO_ROOT / 'tests' / 'fixtures'
_openai_agents_agents_pending_resolution_MINIMAL = str(_openai_agents_agents_pending_resolution_GLOBAL_FIXTURES / 'smoke' / 'minimal.guardrails.yaml')

@pytest.fixture
def _openai_agents_agents_pending_resolution_stub_agents_module(monkeypatch):
    fake = types.ModuleType('agents')

    class FunctionTool:

        def __init__(self, *, name: str, description: str='', params_json_schema=None, on_invoke_tool=None, strict_json_schema: bool=True, failure_error_function=None):
            self.name = name
            self.description = description
            self.params_json_schema = params_json_schema or {}
            self.on_invoke_tool = on_invoke_tool
            self.strict_json_schema = strict_json_schema
            self.failure_error_function = failure_error_function

    class RunContextWrapper:

        def __init__(self, run_config=None):
            self.run_config = run_config

    class GuardrailFunctionOutput:

        def __init__(self, output_info, tripwire_triggered):
            self.output_info = output_info
            self.tripwire_triggered = tripwire_triggered
    fake.FunctionTool = FunctionTool
    fake.RunContextWrapper = RunContextWrapper
    fake.GuardrailFunctionOutput = GuardrailFunctionOutput
    fake.input_guardrail = lambda fn: fn
    fake.output_guardrail = lambda fn: fn
    monkeypatch.setitem(sys.modules, 'agents', fake)
    return fake
_openai_agents_agents_pending_resolution_APPROVAL_YAML = '\nmetadata:\n  name: oai-pending-resolution-fixture\n  version: 0.1.0\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["block until authorized"]\n  forbidden: ["skip"]\nresources:\n  tools:\n    - name: "execute_trade"\n      description: "Execute a trade."\n      permission: "execute"\nvariables:\n  - name: "trade_authorized"\n    type: "boolean"\n    on_demand_by:\n      kind: "human"\n      prompt: "Authorize this trade?"\n    lifetime: "per_session"\nstate_validation:\n  guard_policies:\n    - name: "trade_requires_authorization"\n      applies_to:\n        tools: ["execute_trade"]\n      evaluate_when:\n        - expression: "trade_authorized == true"\n          reason: "Trade was not authorized."\n      action: "block"\n'

def _openai_agents_agents_pending_resolution_write_yaml(yaml: str, name: str) -> str:
    f = tempfile.NamedTemporaryFile(mode='w', suffix=f'.{name}.yaml', delete=False)
    f.write(yaml)
    f.close()
    return f.name

class TestOpenaiAgentsAgentsPendingResolutionPendingResolutionSurfacing:
    """Stage 3 block with an unregistered ``kind: human`` resolver
    fails closed without pending_resolution."""

    def test_protect_tools_block_has_no_pending_resolution(self, _openai_agents_agents_pending_resolution_stub_agents_module):
        from agent_shield import Shield
        path = _openai_agents_agents_pending_resolution_write_yaml(_openai_agents_agents_pending_resolution_APPROVAL_YAML, 'pending')
        try:
            shield = Shield.from_yaml(path, auto_bind=False).with_openai_agents().build()

            async def _execute(ctx, input_json: str) -> str:
                raise AssertionError('underlying tool must not run on Stage 3 block')
            original = _openai_agents_agents_pending_resolution_stub_agents_module.FunctionTool(name='execute_trade', description='Execute a trade', params_json_schema={'type': 'object'}, on_invoke_tool=_execute)
            protected = shield.protect_tools([original])[0]
            ctx = _openai_agents_agents_pending_resolution_stub_agents_module.RunContextWrapper(run_config={})
            runtime = shield.runtime
            sess = runtime.new_session()
            sess.begin_turn()
            try:
                from agent_shield.adapters._orchestration import AgentShieldBlocked, current_session
                token = current_session.set(sess)
                try:
                    with pytest.raises(AgentShieldBlocked) as exc_info:
                        asyncio.run(protected.on_invoke_tool(ctx, '{"account_id":"A-123","ticker":"MSFT","qty":10,"side":"buy"}'))
                finally:
                    current_session.reset(token)
            finally:
                sess.end_turn()
            assert 'GUARDRAIL' in exc_info.value.message or 'blocked' in exc_info.value.message.lower()
            assert shield.last_pending_resolution() is None
        finally:
            Path(path).unlink()

    def test_last_pending_resolution_is_none_when_no_block_seen(self, _openai_agents_agents_pending_resolution_stub_agents_module):
        from agent_shield import Shield
        shield = Shield.from_yaml(_openai_agents_agents_pending_resolution_MINIMAL, auto_bind=False).with_openai_agents().build()
        assert shield.last_pending_resolution() is None
import json
_openai_agents_agents_ctx_forwarding_REPO_ROOT = REPO_ROOT
_openai_agents_agents_ctx_forwarding_GLOBAL_FIXTURES = _openai_agents_agents_ctx_forwarding_REPO_ROOT / 'tests' / 'fixtures'
_openai_agents_agents_ctx_forwarding_MINIMAL = str(_openai_agents_agents_ctx_forwarding_GLOBAL_FIXTURES / 'smoke' / 'minimal.guardrails.yaml')

@pytest.fixture
def _openai_agents_agents_ctx_forwarding_stub_agents_module(monkeypatch):
    fake = types.ModuleType('agents')

    class FunctionTool:

        def __init__(self, *, name: str, description: str='', params_json_schema=None, on_invoke_tool=None, strict_json_schema: bool=True, failure_error_function=None):
            self.name = name
            self.description = description
            self.params_json_schema = params_json_schema or {}
            self.on_invoke_tool = on_invoke_tool
            self.strict_json_schema = strict_json_schema
            self.failure_error_function = failure_error_function

    class RunContextWrapper:

        def __init__(self, run_config=None):
            self.run_config = run_config

    class GuardrailFunctionOutput:

        def __init__(self, output_info, tripwire_triggered):
            self.output_info = output_info
            self.tripwire_triggered = tripwire_triggered
    fake.FunctionTool = FunctionTool
    fake.RunContextWrapper = RunContextWrapper
    fake.GuardrailFunctionOutput = GuardrailFunctionOutput
    fake.input_guardrail = lambda fn: fn
    fake.output_guardrail = lambda fn: fn
    monkeypatch.setitem(sys.modules, 'agents', fake)
    return fake

def _openai_agents_agents_ctx_forwarding_make_ctx_capturing_tool(_openai_agents_agents_ctx_forwarding_stub_agents_module):
    """Build a fake ``FunctionTool`` whose on_invoke_tool reads ``ctx.run_config``.

    The decorated ``@function_tool`` callable expects a ctx-shaped object;
    if the wrapper drops ctx (passes ``None``), this tool raises the
    same ``'NoneType' object has no attribute 'run_config'`` error
    seen in the regression's repro.
    """
    captured: dict = {'ctx': None, 'args': None}

    async def on_invoke(ctx, input_json: str) -> str:
        _ = ctx.run_config
        captured['ctx'] = ctx
        captured['args'] = input_json
        return json.dumps({'ok': True, 'echo': input_json})
    return (_openai_agents_agents_ctx_forwarding_stub_agents_module.FunctionTool(name='lookup_portfolio', description='Look up a portfolio', params_json_schema={'type': 'object'}, on_invoke_tool=on_invoke), captured)

class TestOpenaiAgentsAgentsCtxForwardingCtxForwarding:
    """``shield.protect_tools([fn_tool])[0].on_invoke_tool(ctx, args)``
    must thread ``ctx`` through to the underlying tool."""

    def test_protect_tools_forwards_ctx_to_underlying_tool(self, _openai_agents_agents_ctx_forwarding_stub_agents_module):
        from agent_shield import Shield
        shield = Shield.from_yaml(_openai_agents_agents_ctx_forwarding_MINIMAL, auto_bind=False).with_openai_agents().build()
        original, captured = _openai_agents_agents_ctx_forwarding_make_ctx_capturing_tool(_openai_agents_agents_ctx_forwarding_stub_agents_module)
        protected = shield.protect_tools([original])
        assert len(protected) == 1
        wrapped = protected[0]
        assert wrapped.name == 'lookup_portfolio'
        ctx = _openai_agents_agents_ctx_forwarding_stub_agents_module.RunContextWrapper(run_config={'sandbox': 'trusted'})
        runtime = shield.runtime
        sess = runtime.new_session()
        sess.begin_turn()
        try:
            from agent_shield.adapters._orchestration import current_session
            token = current_session.set(sess)
            try:
                result = asyncio.run(wrapped.on_invoke_tool(ctx, '{"account_id": "A-123"}'))
            finally:
                current_session.reset(token)
        finally:
            sess.end_turn()
        assert captured['ctx'] is ctx, 'wrapped tool dropped ctx; regression not fixed'
        assert captured['args'] == '{"account_id": "A-123"}'
        payload = json.loads(result)
        assert payload['ok'] is True

    def test_protect_tools_preserves_strict_json_schema_flag(self, _openai_agents_agents_ctx_forwarding_stub_agents_module):
        """A tool built with ``strict_json_schema=False`` keeps that flag
        through wrapping so the wrapped tool doesn't accidentally
        re-apply strict-mode transformations to a non-strict schema."""
        from agent_shield import Shield
        shield = Shield.from_yaml(_openai_agents_agents_ctx_forwarding_MINIMAL, auto_bind=False).with_openai_agents().build()

        async def on_invoke(ctx, input_json: str) -> str:
            return 'ok'
        original = _openai_agents_agents_ctx_forwarding_stub_agents_module.FunctionTool(name='loose_tool', description='A loose-schema tool', params_json_schema={'type': 'object'}, on_invoke_tool=on_invoke, strict_json_schema=False)
        wrapped = shield.protect_tools([original])[0]
        assert wrapped.strict_json_schema is False
from typing import Any, List, Optional
from unittest.mock import MagicMock
from agent_shield import RuntimeBuilder
from agent_shield.adapters.openai_agents import make_llm_caller
_openai_agents_agents_llm_caller_model_MULTI_CONFIG_YAML = '\nmetadata:\n  name: oai-llm-caller-model-fixture\n  version: 0.1.0\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["exercise configurations[] routing"]\n  forbidden: ["bypass"]\nconfigurations:\n  - id: stage1-judge\n    type: llm\n    provider: openai.chat\n    model: gpt-4o\n    max_tokens: 256\n  - id: stage3-judge\n    type: llm\n    provider: openai.chat\n    model: gpt-4o-mini-with-context\ninput_validation:\n  guard_policies:\n    - name: trivial_input_guard\n      evaluate_when:\n        - patterns: ["jailbreak"]\n          reason: "jailbreak attempt"\n      action: "block"\n'

class _OpenaiAgentsAgentsLlmCallerModelRecordingChatCompletions:
    """Stand-in for ``client.chat.completions`` that records every call."""

    def __init__(self) -> None:
        self.calls: List[dict] = []

    def create(self, **kwargs: Any) -> Any:
        self.calls.append(kwargs)
        msg = MagicMock()
        msg.content = 'ok'
        choice = MagicMock()
        choice.message = msg
        result = MagicMock()
        result.choices = [choice]
        return result

class _OpenaiAgentsAgentsLlmCallerModelFakeOpenAiClient:
    """Minimal sync OpenAI-shaped client (no ``Async`` in the class name)."""

    def __init__(self) -> None:
        self.chat = MagicMock()
        self.chat.completions = _OpenaiAgentsAgentsLlmCallerModelRecordingChatCompletions()

def _openai_agents_agents_llm_caller_model_build_runtime(yaml_str: str):
    import tempfile
    import os
    fd, path = tempfile.mkstemp(suffix='.yaml')
    try:
        with os.fdopen(fd, 'w') as fh:
            fh.write(yaml_str)
        return RuntimeBuilder.from_yaml(path).build()
    finally:
        os.unlink(path)

def test_openai_agents_agents_llm_caller_model__llm_configuration_returns_yaml_model_for_known_id():
    rt = _openai_agents_agents_llm_caller_model_build_runtime(_openai_agents_agents_llm_caller_model_MULTI_CONFIG_YAML)
    cfg = rt.llm_configuration('stage1-judge')
    assert cfg is not None
    assert cfg['id'] == 'stage1-judge'
    assert cfg['type'] == 'llm'
    assert cfg['model'] == 'gpt-4o'
    assert cfg.get('max_tokens') == 256

def test_openai_agents_agents_llm_caller_model__llm_configuration_returns_none_for_unknown_id():
    rt = _openai_agents_agents_llm_caller_model_build_runtime(_openai_agents_agents_llm_caller_model_MULTI_CONFIG_YAML)
    assert rt.llm_configuration('does-not-exist') is None

def test_openai_agents_agents_llm_caller_model__caller_uses_yaml_model_for_each_configuration_id():
    rt = _openai_agents_agents_llm_caller_model_build_runtime(_openai_agents_agents_llm_caller_model_MULTI_CONFIG_YAML)
    client = _OpenaiAgentsAgentsLlmCallerModelFakeOpenAiClient()
    caller = make_llm_caller(client, configuration_resolver=rt.llm_configuration)
    caller('stage1-judge', 'is the input safe?')
    caller('stage3-judge', 'is the tool call safe?')
    completions = client.chat.completions
    assert len(completions.calls) == 2
    assert completions.calls[0]['model'] == 'gpt-4o'
    assert completions.calls[0].get('max_tokens') == 256
    assert completions.calls[1]['model'] == 'gpt-4o-mini-with-context'
    assert 'max_tokens' not in completions.calls[1]

def test_openai_agents_agents_llm_caller_model__caller_raises_when_no_matching_configuration():
    """Missing configuration: a security library MUST raise rather
    than silently picking a model on the customer's behalf."""
    from agent_shield.adapters._capabilities import ConfigurationMissingModelError
    rt = _openai_agents_agents_llm_caller_model_build_runtime(_openai_agents_agents_llm_caller_model_MULTI_CONFIG_YAML)
    client = _OpenaiAgentsAgentsLlmCallerModelFakeOpenAiClient()
    caller = make_llm_caller(client, configuration_resolver=rt.llm_configuration)
    with pytest.raises(ConfigurationMissingModelError) as exc_info:
        caller('not-in-yaml', 'judge me')
    assert 'not-in-yaml' in str(exc_info.value)
    assert len(client.chat.completions.calls) == 0

def test_openai_agents_agents_llm_caller_model__caller_raises_when_no_resolver_wired():
    """No resolver: every configurationId resolves to "missing" and
    raises. The customer either wires a resolver via Shield.build() or
    they don't get a model — there is no silent fallback."""
    from agent_shield.adapters._capabilities import ConfigurationMissingModelError
    client = _OpenaiAgentsAgentsLlmCallerModelFakeOpenAiClient()
    caller = make_llm_caller(client)
    with pytest.raises(ConfigurationMissingModelError):
        caller('stage1-judge', 'prompt')
    assert len(client.chat.completions.calls) == 0

def test_openai_agents_agents_llm_caller_model__caller_raises_when_configuration_id_is_none():
    from agent_shield.adapters._capabilities import ConfigurationMissingModelError
    rt = _openai_agents_agents_llm_caller_model_build_runtime(_openai_agents_agents_llm_caller_model_MULTI_CONFIG_YAML)
    client = _OpenaiAgentsAgentsLlmCallerModelFakeOpenAiClient()
    caller = make_llm_caller(client, configuration_resolver=rt.llm_configuration)
    with pytest.raises(ConfigurationMissingModelError) as exc_info:
        caller(None, 'prompt')
    assert '<unset>' in str(exc_info.value)

def test_openai_agents_agents_llm_caller_model__caller_raises_when_resolver_raises():
    """Resolver exceptions surface as ConfigurationMissingModelError;
    a broken resolver is treated the same as "no entry"."""
    from agent_shield.adapters._capabilities import ConfigurationMissingModelError
    client = _OpenaiAgentsAgentsLlmCallerModelFakeOpenAiClient()

    def broken_resolver(_cid: Optional[str]) -> Optional[dict]:
        raise RuntimeError('boom')
    caller = make_llm_caller(client, configuration_resolver=broken_resolver)
    with pytest.raises(ConfigurationMissingModelError):
        caller('stage1-judge', 'prompt')
    assert len(client.chat.completions.calls) == 0

def test_openai_agents_agents_llm_caller_model__shield_builder_wires_resolver_through_build(tmp_path):
    """Shield.from_yaml(...).with_client(...).build() => caller honours YAML.

    Reaches into ``ShieldBuilder`` to grab the actually-wired LLM caller
    (the same closure ``RuntimeBuilder.register_llm_caller`` receives,
    which is what the Rust runtime invokes for every stage). Drives the
    closure directly and asserts the model came from the YAML.
    """
    from agent_shield.adapters._shield import ShieldBuilder
    yaml_path = tmp_path / 'guardrails.yaml'
    yaml_path.write_text(_openai_agents_agents_llm_caller_model_MULTI_CONFIG_YAML)
    client = _OpenaiAgentsAgentsLlmCallerModelFakeOpenAiClient()
    builder = ShieldBuilder(str(yaml_path), auto_bind=False).with_openai_agents().with_client(client)
    shield = builder.build()
    bound_caller = builder._llm_caller
    assert bound_caller is not None
    bound_caller('stage1-judge', 'prompt')
    bound_caller('stage3-judge', 'prompt')
    completions = client.chat.completions
    assert completions.calls[-2]['model'] == 'gpt-4o'
    assert completions.calls[-1]['model'] == 'gpt-4o-mini-with-context'
    assert shield.runtime.llm_configuration('stage1-judge')['model'] == 'gpt-4o'
_openai_agents_agents_llm_caller_model_AZURE_YAML = '\nmetadata:\n  name: oai-azure-fixture\n  version: 0.1.0\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["exercise Azure routing"]\n  forbidden: ["bypass"]\nconfigurations:\n  - id: azure-judge\n    type: llm\n    provider: azure_openai\n    model: my-gpt4o-deployment\n  - id: openai-judge\n    type: llm\n    provider: openai.chat\n    model: gpt-4o\ninput_validation:\n  guard_policies:\n    - name: trivial_input_guard\n      evaluate_when:\n        - patterns: ["jailbreak"]\n          reason: "jailbreak attempt"\n      action: "block"\n'

def test_openai_agents_agents_llm_caller_model__runtime_surfaces_model_for_azure_entry():
    rt = _openai_agents_agents_llm_caller_model_build_runtime(_openai_agents_agents_llm_caller_model_AZURE_YAML)
    cfg = rt.llm_configuration('azure-judge')
    assert cfg is not None
    assert cfg['model'] == 'my-gpt4o-deployment'
    assert cfg['provider'] == 'azure_openai'

def test_openai_agents_agents_llm_caller_model__caller_sends_yaml_model_for_azure_entry():
    rt = _openai_agents_agents_llm_caller_model_build_runtime(_openai_agents_agents_llm_caller_model_AZURE_YAML)
    client = _OpenaiAgentsAgentsLlmCallerModelFakeOpenAiClient()
    caller = make_llm_caller(client, configuration_resolver=rt.llm_configuration)
    caller('azure-judge', 'prompt')
    completions = client.chat.completions
    assert len(completions.calls) == 1
    assert completions.calls[0]['model'] == 'my-gpt4o-deployment'

def test_openai_agents_agents_llm_caller_model__caller_sends_yaml_model_for_non_azure_entry():
    rt = _openai_agents_agents_llm_caller_model_build_runtime(_openai_agents_agents_llm_caller_model_AZURE_YAML)
    client = _OpenaiAgentsAgentsLlmCallerModelFakeOpenAiClient()
    caller = make_llm_caller(client, configuration_resolver=rt.llm_configuration)
    caller('openai-judge', 'prompt')
    completions = client.chat.completions
    assert completions.calls[0]['model'] == 'gpt-4o'

def test_openai_agents_agents_llm_caller_model__caller_accepts_reverse_domain_azure_provider():
    yaml = '\nmetadata:\n  name: rd\n  version: 0.1.0\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["x"]\n  forbidden: ["bypass"]\nconfigurations:\n  - id: judge\n    type: llm\n    provider: microsoft.azure.openai\n    model: my-deploy\ninput_validation:\n  guard_policies:\n    - name: trivial\n      evaluate_when:\n        - patterns: ["x"]\n          reason: "x"\n      action: "block"\n'
    rt = _openai_agents_agents_llm_caller_model_build_runtime(yaml)
    client = _OpenaiAgentsAgentsLlmCallerModelFakeOpenAiClient()
    caller = make_llm_caller(client, configuration_resolver=rt.llm_configuration)
    caller('judge', 'prompt')
    assert client.chat.completions.calls[0]['model'] == 'my-deploy'
