"""Behavior tests consolidated into behavior/test_redaction.py."""
from __future__ import annotations
import asyncio
from typing import Any
import pytest
from agent_shield import RuntimeBuilder
from agent_shield.mcp import MCPShield
_mcp_shape_redaction_REDACT_SSN_YAML = '\nmetadata:\n  name: "f63-7-redact"\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["pass"]\n  forbidden: ["leak ssn"]\nresources:\n  tools:\n    - name: "lookup"\n      description: "Lookup helper."\n      permission: "read_only"\npost_tool_validation:\n  guard_policies:\n    - name: "redact_ssn_tool_output"\n      applies_to:\n        tools: ["lookup"]\n      evaluate_when:\n        - pattern: "\\\\d{3}-\\\\d{2}-\\\\d{4}"\n          reason: "SSN detected in tool output."\n      action: "redact"\n      replacement: "[REDACTED]"\n'

def _mcp_shape_redaction_build_shield() -> MCPShield:
    runtime = RuntimeBuilder.from_yaml_strings([_mcp_shape_redaction_REDACT_SSN_YAML]).build()
    return MCPShield(runtime)

class TestMcpShapeRedactionDictShape:

    def test_dict_input_returns_dict_not_json_string(self):
        """A tool returning ``{"name": "Alice", "ssn": "123-45-6789"}``
        must come back as a dict with the SSN field redacted — NOT
        as a JSON-stringified blob."""
        shield = _mcp_shape_redaction_build_shield()

        async def lookup(**_):
            return {'name': 'Alice', 'ssn': '123-45-6789', 'metadata': {'trace': 'abc-123', 'secondary_ssn': '555-66-7777'}, 'count': 42, 'ok': True}
        wrapped = shield.protect_tools([('lookup', lookup)], on_block='raise')[0][1]
        result = asyncio.run(wrapped())
        assert isinstance(result, dict), f'regression: dict input must round-trip as dict; got {type(result).__name__}: {result!r}'
        assert result['name'] == 'Alice'
        assert '123-45-6789' not in str(result['ssn']), f'regression: SSN must be redacted; got {result["ssn"]!r}'
        assert result['ssn'] == '[REDACTED]'
        assert '555-66-7777' not in str(result['metadata']['secondary_ssn'])
        assert result['count'] == 42
        assert result['ok'] is True
        assert result['metadata']['trace'] == 'abc-123'

def _mcp_shape_redaction_mcp_types_available() -> bool:
    try:
        return True
    except Exception:
        return False

@pytest.mark.skipif(not _mcp_shape_redaction_mcp_types_available(), reason='mcp package not installed; CallToolResult shape test skipped')
class TestMcpShapeRedactionCallToolResultShape:

    def test_call_tool_result_preserves_typed_fields(self):
        """Tool returns ``CallToolResult(content=[TextContent,
        ImageContent], structuredContent={"ssn": ..., "ok": True},
        meta={"trace_id": "abc"}, isError=False)``.

        Expected behavior:
        * Returns a ``CallToolResult`` of the same class.
        * ``TextContent.text`` is redacted.
        * ``ImageContent`` is unchanged (binary payload never sees
          Stage 4's regex).
        * ``structuredContent.ssn`` is redacted, ``ok`` preserved.
        * ``meta`` is preserved verbatim.
        * ``isError`` is preserved verbatim.
        """
        from mcp.types import CallToolResult, ImageContent, TextContent
        shield = _mcp_shape_redaction_build_shield()
        image_payload = 'ZmFrZS1pbWFnZS0xMjMtNDUtNjc4OQ=='

        async def lookup(**_):
            return CallToolResult(content=[TextContent(type='text', text='SSN 123-45-6789 leaked'), ImageContent(type='image', data=image_payload, mimeType='image/png')], structuredContent={'ssn': '555-66-7777', 'ok': True, 'trace': 'no-pii-here'}, isError=False)
        wrapped = shield.protect_tools([('lookup', lookup)], on_block='raise')[0][1]
        result = asyncio.run(wrapped())
        assert isinstance(result, CallToolResult), f'regression: CallToolResult must round-trip as CallToolResult; got {type(result).__name__}'
        text_blocks = [b for b in result.content if isinstance(b, TextContent)]
        image_blocks = [b for b in result.content if isinstance(b, ImageContent)]
        assert len(text_blocks) == 1
        assert len(image_blocks) == 1
        assert '123-45-6789' not in text_blocks[0].text
        assert '[REDACTED]' in text_blocks[0].text
        assert image_blocks[0].data == image_payload, "regression: ImageContent.data must NOT be submitted to Stage 4's regex engine — false-positive matches against base64 would silently corrupt binary payloads."
        assert image_blocks[0].mimeType == 'image/png'
        assert result.structuredContent is not None
        assert '555-66-7777' not in str(result.structuredContent.get('ssn'))
        assert result.structuredContent['ok'] is True
        assert result.structuredContent['trace'] == 'no-pii-here'
        assert result.isError is False

def _mcp_shape_redaction_pydantic_v2_available() -> bool:
    try:
        from pydantic import BaseModel
        return hasattr(BaseModel, 'model_validate')
    except Exception:
        return False

@pytest.mark.skipif(not _mcp_shape_redaction_pydantic_v2_available(), reason='pydantic v2 not installed')
class TestMcpShapeRedactionPydanticModelShape:

    def test_pydantic_v2_model_round_trips_with_redaction(self):
        """A custom Pydantic v2 model with a nested string field
        comes back as the SAME model class, redacted in the right
        place, with other fields untouched."""
        from pydantic import BaseModel

        class Address(BaseModel):
            line1: str
            ssn_note: str

        class Person(BaseModel):
            name: str
            age: int
            address: Address
        shield = _mcp_shape_redaction_build_shield()

        async def lookup(**_):
            return Person(name='Alice', age=42, address=Address(line1='100 Main St', ssn_note='SSN 123-45-6789 on file'))
        wrapped = shield.protect_tools([('lookup', lookup)], on_block='raise')[0][1]
        result = asyncio.run(wrapped())
        assert isinstance(result, Person), f'regression: Pydantic model round-trip must return the same model class; got {type(result).__name__}'
        assert result.name == 'Alice'
        assert result.age == 42
        assert isinstance(result.address, Address)
        assert result.address.line1 == '100 Main St'
        assert '123-45-6789' not in result.address.ssn_note
        assert '[REDACTED]' in result.address.ssn_note

class TestMcpShapeRedactionNestedListShape:

    def test_list_of_dicts_preserves_shape(self):
        shield = _mcp_shape_redaction_build_shield()

        async def lookup(**_):
            return [{'name': 'Alice', 'ssn': '123-45-6789'}, {'name': 'Bob', 'ssn': '555-66-7777'}, {'name': 'Carol', 'notes': ['benign', '555-44-3333']}]
        wrapped = shield.protect_tools([('lookup', lookup)], on_block='raise')[0][1]
        result = asyncio.run(wrapped())
        assert isinstance(result, list), f'regression: list input must round-trip as list; got {type(result).__name__}: {result!r}'
        assert len(result) == 3
        for entry in result:
            assert isinstance(entry, dict)
        assert result[0]['name'] == 'Alice'
        assert '123-45-6789' not in str(result[0]['ssn'])
        assert '555-66-7777' not in str(result[1]['ssn'])
        assert isinstance(result[2]['notes'], list)
        assert result[2]['notes'][0] == 'benign'
        assert '555-44-3333' not in result[2]['notes'][1]

class TestMcpShapeRedactionBareProtectToolOutputShape:

    def test_bare_protect_tool_output_returns_dict(self):
        """The module-level :func:`protect_tool_output` helper must
        also preserve shape (was stringifying every non-str input
        previous behavior)."""
        from agent_shield.mcp import protect_tool, protect_tool_output
        runtime = RuntimeBuilder.from_yaml_strings([_mcp_shape_redaction_REDACT_SSN_YAML]).build()

        async def _drive():
            session = runtime.new_session()
            session.begin_turn()
            allowed, _params, _msg = await protect_tool(runtime, 'lookup', {}, 'tc1', session=session)
            assert allowed is True
            allowed, value, _msg = await protect_tool_output(runtime, 'lookup', {'ssn': '123-45-6789', 'ok': True}, 'tc1', session=session)
            return (allowed, value)
        allowed, value = asyncio.run(_drive())
        assert allowed is True
        assert isinstance(value, dict), f'regression: bare protect_tool_output must preserve dict shape; got {type(value).__name__}: {value!r}'
        assert '123-45-6789' not in str(value['ssn'])
        assert value['ok'] is True
_stage4_redaction_YAML_REDACT_DIGIT_RUN = '\nmetadata:\n  name: "f66-4-digit-run"\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["test"]\n  forbidden: []\nresources:\n  tools:\n    - name: "lookup"\n      description: "Lookup helper."\n      permission: "read_only"\npost_tool_validation:\n  guard_policies:\n    - name: "redact_digits"\n      applies_to:\n        tools: ["lookup"]\n      evaluate_when:\n        - pattern: "\\\\d+"\n          reason: "Digit run."\n      action: "redact"\n      replacement: "[D]"\n'
_stage4_redaction_YAML_REDACT_SSN = '\nmetadata:\n  name: "f66-4-ssn"\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["test"]\n  forbidden: []\nresources:\n  tools:\n    - name: "lookup"\n      description: "Lookup helper."\n      permission: "read_only"\npost_tool_validation:\n  guard_policies:\n    - name: "redact_ssn"\n      applies_to:\n        tools: ["lookup"]\n      evaluate_when:\n        - pattern: "\\\\d{3}-\\\\d{2}-\\\\d{4}"\n          reason: "SSN detected."\n      action: "redact"\n      replacement: "[SSN]"\n'

def _stage4_redaction_build_session(yaml: str=_stage4_redaction_YAML_REDACT_DIGIT_RUN):
    runtime = RuntimeBuilder.from_yaml_strings([yaml]).build()
    session = runtime.new_session()
    session.begin_turn()
    return session

def _stage4_redaction_validate_tool_call_then_output(session, tool_name, params, result):
    """Run Stage 2/3 and capture the admission, then drive Stage 4."""
    call_outcome = session.validate_tool_call(tool_name, params)
    assert call_outcome.verdict.allowed, f'Stage 3 unexpectedly blocked: {call_outcome.verdict.reason}'
    return session.validate_tool_output(call_outcome.admission_id, result)

class TestStage4RedactionDictShapePreserved:
    """A dict tool result round-trips as a dict; string leaves get
    redacted; numeric leaves stay untouched."""

    def test_dict_with_mixed_string_and_number_leaves(self):
        session = _stage4_redaction_build_session()
        out = _stage4_redaction_validate_tool_call_then_output(session, 'lookup', {}, {'ssn': '123-45-6789', 'n': 42})
        assert out.verdict.allowed
        recovered = out.result
        assert isinstance(recovered, dict), f'regression: dict input MUST round-trip as dict, got {type(recovered).__name__}: {recovered!r}'
        assert recovered['n'] == 42, f'regression: numeric leaf must not be redacted; got {recovered["n"]!r}'
        assert isinstance(recovered['n'], int), f'regression: numeric leaf must keep `int` type; got {type(recovered["n"]).__name__}'
        assert '123-45-6789' not in str(recovered['ssn']), f'regression: SSN substring leaked: {recovered["ssn"]!r}'
        assert '[D]' in recovered['ssn']

    def test_nested_dict_redacts_only_string_leaves(self):
        session = _stage4_redaction_build_session(_stage4_redaction_YAML_REDACT_SSN)
        out = _stage4_redaction_validate_tool_call_then_output(session, 'lookup', {}, {'patient': {'name': 'Alice', 'ssn': '123-45-6789', 'age': 42, 'active': True}, 'trace_id': 'abc-no-ssn'})
        recovered = out.result
        assert isinstance(recovered, dict)
        assert isinstance(recovered['patient'], dict)
        assert recovered['patient']['name'] == 'Alice'
        assert recovered['patient']['ssn'] == '[SSN]'
        assert recovered['patient']['age'] == 42
        assert recovered['patient']['active'] is True
        assert recovered['trace_id'] == 'abc-no-ssn'

class TestStage4RedactionListShapePreserved:
    """List of strings + numbers round-trips with shape; only strings
    receive redaction."""

    def test_list_with_string_and_number_elements(self):
        session = _stage4_redaction_build_session()
        out = _stage4_redaction_validate_tool_call_then_output(session, 'lookup', {}, ['abc123', 456])
        recovered = out.result
        assert isinstance(recovered, list), f'regression: list input MUST round-trip as list; got {type(recovered).__name__}: {recovered!r}'
        assert len(recovered) == 2
        assert '123' not in recovered[0], f'regression: digit substring leaked in string element: {recovered[0]!r}'
        assert recovered[0].startswith('abc')
        assert recovered[1] == 456
        assert isinstance(recovered[1], int)

    def test_list_of_dicts(self):
        session = _stage4_redaction_build_session(_stage4_redaction_YAML_REDACT_SSN)
        out = _stage4_redaction_validate_tool_call_then_output(session, 'lookup', {}, [{'name': 'Alice', 'ssn': '123-45-6789', 'age': 30}, {'name': 'Bob', 'ssn': '987-65-4321', 'age': 45}])
        recovered = out.result
        assert isinstance(recovered, list)
        assert len(recovered) == 2
        for entry in recovered:
            assert isinstance(entry, dict)
            assert entry['ssn'] == '[SSN]'
            assert isinstance(entry['age'], int)

class TestStage4RedactionStringPassThrough:
    """A plain-string tool result is the existing happy path — must
    keep working exactly as today (no regression from the new walker)."""

    def test_string_input_returns_redacted_string(self):
        session = _stage4_redaction_build_session(_stage4_redaction_YAML_REDACT_SSN)
        out = _stage4_redaction_validate_tool_call_then_output(session, 'lookup', {}, 'SSN 123-45-6789 here')
        assert out.verdict.allowed
        assert isinstance(out.result, str)
        assert '123-45-6789' not in out.result
        assert '[SSN]' in out.result

class TestStage4RedactionNoRedactionPreservesShape:
    """When no redactor fires, the structured input MUST come back
    unchanged (no spurious stringification)."""

    def test_dict_with_no_pii_round_trips(self):
        session = _stage4_redaction_build_session(_stage4_redaction_YAML_REDACT_SSN)
        out = _stage4_redaction_validate_tool_call_then_output(session, 'lookup', {}, {'name': 'Alice', 'age': 30, 'active': True})
        recovered = out.result
        assert isinstance(recovered, dict)
        assert recovered == {'name': 'Alice', 'age': 30, 'active': True}

    def test_list_with_no_pii_round_trips(self):
        session = _stage4_redaction_build_session(_stage4_redaction_YAML_REDACT_SSN)
        out = _stage4_redaction_validate_tool_call_then_output(session, 'lookup', {}, ['abc', 123, True])
        recovered = out.result
        assert isinstance(recovered, list)
        assert recovered == ['abc', 123, True]

class TestStage4RedactionNonStringKeysNotRedacted:
    """Dict KEYS that happen to contain digits MUST NOT be redacted
    (redact only string leaves — values, not keys)."""

    def test_numeric_string_dict_key_is_preserved(self):
        session = _stage4_redaction_build_session()
        out = _stage4_redaction_validate_tool_call_then_output(session, 'lookup', {}, {'key_42': 'no digits here'})
        recovered = out.result
        assert isinstance(recovered, dict)
        assert 'key_42' in recovered
        assert recovered['key_42'] == 'no digits here'

class TestStage4RedactionStructuredContentBlockedStillBlocks:
    """Structured input that triggers a Stage-4 block (e.g. via
    ``allowed_when``) must still surface as a block verdict — shape
    preservation only runs on allow-with-mutation, never as a
    fail-open."""
    BLOCK_YAML = '\nmetadata:\n  name: "f66-4-block"\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["test"]\n  forbidden: []\nresources:\n  tools:\n    - name: "lookup"\n      description: "Lookup helper."\n      permission: "read_only"\npost_tool_validation:\n  guard_policies:\n    - name: "block_ssn_unless_approved"\n      applies_to:\n        tools: ["lookup"]\n      evaluate_when:\n        - pattern: "\\\\d{3}-\\\\d{2}-\\\\d{4}"\n          reason: "SSN detected."\n      action: "block"\n'

    def test_structured_input_block_path(self):
        session = _stage4_redaction_build_session(self.BLOCK_YAML)
        out = _stage4_redaction_validate_tool_call_then_output(session, 'lookup', {}, {'ssn': '123-45-6789', 'ok': True})
        assert not out.verdict.allowed, 'regression: Stage-4 block on structured input must still block'
from agent_shield.adapters._shield import Shield, ShieldMode
_stage3_redact_nested_params_Case_NESTED_REDACT_YAML = '\n\nmetadata:\n  name: f2711-stage3-nested-redact\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["test PII redaction on tool args"]\nresources:\n  tools:\n    - name: save_to_db\n      permission: read_write\ntool_execution_validation:\n  guard_policies:\n    - name: pii_scrub\n      applies_to: { tools: ["save_to_db"] }\n      action: redact\n      replacement: "[PII]"\n      evaluate_when:\n        - patterns:\n            - \'\\b\\d{3}-\\d{2}-\\d{4}\\b\'\n            - \'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}\'\n          reason: "PII detected in tool arguments."\n'

def _stage3_redact_nested_params_build_runtime() -> Any:
    return RuntimeBuilder.from_yaml_strings([_stage3_redact_nested_params_Case_NESTED_REDACT_YAML]).build()

def test_stage3_redact_nested_params__stage3_redact_mutates_effective_params_nested_object() -> None:
    """Top-level field is an object; the SSN lives one level deep.

    Before the regression fix, the verdict reported ``action=redact`` but
    ``effective_params`` still contained the raw SSN because the
    redactor only walked top-level string fields. The tool callable
    must observe the redacted form.
    """
    rt = _stage3_redact_nested_params_build_runtime()
    s = Shield(rt, mode=ShieldMode.ENFORCE)
    captured: dict[str, Any] = {}

    async def _exec(effective_params: Any) -> str:
        captured['params'] = effective_params
        return 'saved'
    blocked, output = asyncio.run(s.protect_tool('save_to_db', {'record': {'note': 'SSN is 123-45-6789', 'email': 'a@b.co'}}, _exec))
    assert blocked is False, 'expected redact (allowed), not block'
    assert output == 'saved'
    serialized = repr(captured['params'])
    assert '123-45-6789' not in serialized, f'Stage 3 verdict reported action=redact but raw SSN survived in the params passed to execute(): {serialized}'
    assert 'a@b.co' not in serialized, f'Stage 3 verdict reported action=redact but raw email survived in the params passed to execute(): {serialized}'
    assert captured['params']['record']['note'] == 'SSN is [PII]'
    assert captured['params']['record']['email'] == '[PII]'

def test_stage3_redact_nested_params__stage3_redact_mutates_effective_params_array_of_objects() -> None:
    """Array-of-records variant — PII buried inside list elements."""
    rt = _stage3_redact_nested_params_build_runtime()
    s = Shield(rt, mode=ShieldMode.ENFORCE)
    captured: dict[str, Any] = {}

    async def _exec(effective_params: Any) -> str:
        captured['params'] = effective_params
        return 'saved'
    blocked, _ = asyncio.run(s.protect_tool('save_to_db', {'rows': [{'note': 'SSN 123-45-6789'}, {'note': 'clean'}]}, _exec))
    assert blocked is False
    serialized = repr(captured['params'])
    assert '123-45-6789' not in serialized, f'raw SSN survived in array element: {serialized}'
    assert captured['params']['rows'][0]['note'] == 'SSN [PII]'
    assert captured['params']['rows'][1]['note'] == 'clean'
_stage5_preserves_structure_REDACT_YAML = '\nmetadata:\n  name: stage5-preserve-structure\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["test"]\nresources:\n  tools:\n    - name: noop\n      permission: read_only\noutput_validation:\n  guard_policies:\n    - name: redact_ssn\n      evaluate_when:\n        - pattern: \'\\d{3}-\\d{2}-\\d{4}\'\n          reason: ssn\n          action: redact\n      replacement: "[REDACTED]"\n'
_stage5_preserves_structure_BLOCK_YAML = '\nmetadata:\n  name: stage5-block-structure\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["test"]\nresources:\n  tools:\n    - name: noop\n      permission: read_only\noutput_validation:\n  guard_policies:\n    - name: block_token\n      evaluate_when:\n        - pattern: "TOPSECRET-[A-Z0-9]+"\n          reason: leaked secret\n          action: block\n'

def _stage5_preserves_structure_shield(yaml: str) -> Shield:
    runtime = RuntimeBuilder.from_yaml_strings([yaml]).build()
    return Shield(runtime)

def test_stage5_preserves_structure__shield_run_preserves_dict_shape_with_redaction() -> None:
    """LangGraph-style State dict survives Stage 5 redaction (regression)."""
    shield = _stage5_preserves_structure_shield(_stage5_preserves_structure_REDACT_YAML)

    async def _thunk() -> dict:
        return {'patient_id': 'P204', 'complaint_text': 'Patient P204 age 45 routine note includes SSN 123-45-6789 and other details.', 'score': 0.91, 'tags': ['urgent', 'phi']}
    out = asyncio.run(shield.run(_thunk))
    assert isinstance(out, dict), f'Stage 5 redaction must preserve dict shape (regression); got {type(out).__name__}'
    assert out['patient_id'] == 'P204'
    assert out['score'] == 0.91
    assert out['tags'] == ['urgent', 'phi']
    assert '[REDACTED]' in out['complaint_text']
    assert '123-45-6789' not in out['complaint_text']

def test_stage5_preserves_structure__shield_run_preserves_list_of_dicts() -> None:
    shield = _stage5_preserves_structure_shield(_stage5_preserves_structure_REDACT_YAML)

    async def _thunk() -> list:
        return [{'id': 1, 'note': 'ssn 111-22-3333 here'}, {'id': 2, 'note': 'no pii'}, {'id': 3, 'note': 'ssn 444-55-6666 there'}]
    out = asyncio.run(shield.run(_thunk))
    assert isinstance(out, list)
    assert len(out) == 3
    assert all((isinstance(item, dict) for item in out))
    assert out[0]['id'] == 1
    assert '[REDACTED]' in out[0]['note']
    assert out[1]['note'] == 'no pii'
    assert '[REDACTED]' in out[2]['note']

def test_stage5_preserves_structure__shield_run_preserves_nested_structure() -> None:
    shield = _stage5_preserves_structure_shield(_stage5_preserves_structure_REDACT_YAML)

    async def _thunk() -> dict:
        return {'patient': {'id': 'P1', 'history': [{'date': '2024-01-01', 'note': 'ssn 111-22-3333'}, {'date': '2024-02-01', 'note': 'fine'}]}, 'score': 0.5, 'flags': (True, False, None)}
    out = asyncio.run(shield.run(_thunk))
    assert isinstance(out, dict)
    assert isinstance(out['patient'], dict)
    assert isinstance(out['patient']['history'], list)
    assert '[REDACTED]' in out['patient']['history'][0]['note']
    assert out['patient']['history'][1]['note'] == 'fine'
    assert out['score'] == 0.5
    assert isinstance(out['flags'], tuple)
    assert out['flags'] == (True, False, None)

def test_stage5_preserves_structure__shield_run_passes_through_scalars_unchanged() -> None:
    shield = _stage5_preserves_structure_shield(_stage5_preserves_structure_REDACT_YAML)
    for value in (None, True, False, 0, 1, -5, 3.14):

        async def _thunk(v: Any=value) -> Any:
            return v
        out = asyncio.run(shield.run(_thunk))
        assert out == value, f'scalar {value!r} mutated → {out!r}'
        if value is not None:
            assert type(out) is type(value), f'scalar {value!r} type changed → {type(out).__name__}'

def test_stage5_preserves_structure__shield_run_preserves_plain_string_legacy_path() -> None:
    """The dominant chat-text case keeps the legacy single-shot
    redaction path: a ``str`` in still returns a ``str`` out."""
    shield = _stage5_preserves_structure_shield(_stage5_preserves_structure_REDACT_YAML)

    async def _thunk() -> str:
        return 'leak ssn 999-88-7777 here'
    out = asyncio.run(shield.run(_thunk))
    assert isinstance(out, str)
    assert '[REDACTED]' in out
    assert '999-88-7777' not in out

def test_stage5_preserves_structure__shield_run_block_in_structure_returns_block_message() -> None:
    """A leaf-level Stage 5 block short-circuits the structure walk
    and returns the canonical block message (a string).

    regression — explicitly opts into ``on_block="return_blocked"`` to keep
    asserting the legacy string-return shape; the new default
    (``"raise"``) is covered in
    :mod:`sdk/python/tests/test_shield_run_default_raise`.
    """
    shield = _stage5_preserves_structure_shield(_stage5_preserves_structure_BLOCK_YAML)

    async def _thunk() -> dict:
        return {'ok_field': 'harmless', 'leaked': 'here is the token: TOPSECRET-ABC123'}
    out = asyncio.run(shield.run(_thunk, on_block='return_blocked'))
    assert isinstance(out, str)
    assert out.startswith('[GUARDRAIL BLOCK]')

def test_stage5_preserves_structure__shield_run_empty_dict_returns_empty_dict() -> None:
    shield = _stage5_preserves_structure_shield(_stage5_preserves_structure_REDACT_YAML)

    async def _thunk() -> dict:
        return {}
    out = asyncio.run(shield.run(_thunk))
    assert out == {}
    assert isinstance(out, dict)

def test_stage5_preserves_structure__shield_run_dict_without_string_leaves_passes_through() -> None:
    """A dict with only numeric / bool / None leaves has nothing to
    redact and must pass through with shape intact."""
    shield = _stage5_preserves_structure_shield(_stage5_preserves_structure_REDACT_YAML)

    async def _thunk() -> dict:
        return {'score': 0.91, 'ok': True, 'count': 7, 'missing': None}
    out = asyncio.run(shield.run(_thunk))
    assert out == {'score': 0.91, 'ok': True, 'count': 7, 'missing': None}
    assert isinstance(out, dict)

@pytest.mark.skipif(pytest.importorskip('pydantic', reason='pydantic not installed') is None, reason='pydantic required')
def test_stage5_preserves_structure__shield_run_pydantic_model_round_trip() -> None:
    """Pydantic v2 ``BaseModel`` returns are redacted via
    ``model_dump`` and re-validated back into the same class."""
    from pydantic import BaseModel

    class PatientNote(BaseModel):
        patient_id: str
        note: str
        score: float
    shield = _stage5_preserves_structure_shield(_stage5_preserves_structure_REDACT_YAML)

    async def _thunk() -> PatientNote:
        return PatientNote(patient_id='P9', note='contains ssn 222-33-4444 in the body', score=0.42)
    out = asyncio.run(shield.run(_thunk))
    assert isinstance(out, PatientNote), f'Pydantic round-trip failed: {type(out).__name__}'
    assert out.patient_id == 'P9'
    assert out.score == 0.42
    assert '[REDACTED]' in out.note
    assert '222-33-4444' not in out.note
import inspect
from agent_shield.hooks import RedactionSpan

def test_redaction_span_docstring__redaction_span_docstring_specifies_codepoint_offsets() -> None:
    doc = inspect.getdoc(RedactionSpan) or ''
    assert 'codepoint' in doc.lower(), 'RedactionSpan docstring must specify codepoint (character) offsets — see regression. Current docstring:\n' + doc

def test_redaction_span_docstring__redaction_span_docstring_canonical_contract_is_codepoint() -> None:
    """The opening of the docstring must establish codepoints as the
    canonical contract — not bytes. Any mention of bytes is allowed
    further down (e.g. cautionary examples) as long as the canonical
    statement leads.
    """
    doc = inspect.getdoc(RedactionSpan) or ''
    head = doc[:200].lower()
    assert 'codepoint' in head, "RedactionSpan docstring's opening paragraph must establish codepoint (character) offsets as the canonical contract (regression). Current opening:\n" + head
    for phrase in ('byte range', 'byte offset', 'byte-range', 'byte-offset'):
        idx = head.find(phrase)
        if idx != -1:
            preamble = head[max(0, idx - 8):idx]
            assert 'not ' in preamble or 'not\n' in preamble, f'RedactionSpan docstring opening uses {phrase!r} as canonical contract — must say codepoint instead (regression). Context: ' + head[max(0, idx - 40):idx + len(phrase) + 20]

def test_redaction_span_docstring__redaction_span_docstring_warns_against_utf8_encode_pitfall() -> None:
    """The docstring should call out the ``str.encode('utf-8').index(...)``
    pitfall — that's the exact mistake that produced the original leak.
    """
    doc = inspect.getdoc(RedactionSpan) or ''
    assert 'encode' in doc.lower(), "RedactionSpan docstring should warn callers against using str.encode('utf-8').index(...) to compute offsets (regression)."
