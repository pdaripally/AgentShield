"""Behavior tests consolidated into behavior/test_pyo3_binding.py."""
from __future__ import annotations
from .._support.paths import REPO_ROOT
from typing import Any, Dict
from agent_shield import RuntimeBuilder
_pyo3_binding_REPO_ROOT = REPO_ROOT
_pyo3_binding_FIXTURES_DIR = _pyo3_binding_REPO_ROOT / 'tests' / 'fixtures'

def _pyo3_binding_fixture_path(*parts: str) -> str:
    path = _pyo3_binding_FIXTURES_DIR.joinpath(*parts)
    if not path.exists():
        raise FileNotFoundError(f'Fixture not found: {path}')
    return str(path)
_pyo3_binding_COMPREHENSIVE = _pyo3_binding_fixture_path('comprehensive', 'comprehensive-spec-test.guardrails.yaml')

def _pyo3_binding_make_session(path: str=_pyo3_binding_COMPREHENSIVE):
    rt = RuntimeBuilder.from_yaml(path).build()
    session = rt.new_session(session_id='test', correlation_id='test-corr')
    session.begin_turn()
    return session

class TestPyo3BindingPyO3TypeRoundTrip:
    """Verify Python types survive the PyO3 → Rust → PyO3 boundary."""

    def test_string_roundtrip(self):
        session = _pyo3_binding_make_session()
        session.set_variable('data_sensitivity', 'internal')
        val = session.read_variable('data_sensitivity').value
        assert isinstance(val, str)
        assert val == 'internal'

    def test_number_roundtrip(self):
        session = _pyo3_binding_make_session()
        session.set_variable('api_cost', 100)
        val = session.read_variable('api_cost').value
        assert isinstance(val, (int, float))
        assert val == 100

    def test_boolean_roundtrip(self):
        session = _pyo3_binding_make_session()
        session.set_variable('is_authenticated', True)
        assert session.read_variable('is_authenticated').value is True
        session.set_variable('is_authenticated', False)
        assert session.read_variable('is_authenticated').value is False

    def test_list_roundtrip(self):
        session = _pyo3_binding_make_session()
        session.set_variable('data_jurisdictions', ['US'])
        val = session.read_variable('data_jurisdictions').value
        assert isinstance(val, list)
        assert val == ['US']

    def test_dict_roundtrip(self):
        session = _pyo3_binding_make_session()
        session.set_variable('account_details', {'id': 'acc-123', 'type': 'savings'})
        val = session.read_variable('account_details').value
        assert isinstance(val, dict)
        assert val.get('id') == 'acc-123'

    def test_none_for_missing(self):
        session = _pyo3_binding_make_session()
        assert session.read_variable('nonexistent_attr') is None
        unset = session.read_variable('data_sensitivity')
        assert unset is not None
        assert unset.status == 'unset'

    def test_read_variable_returns_state(self):
        session = _pyo3_binding_make_session()
        session.set_variable('api_cost', 42)
        state = session.read_variable('api_cost')
        assert state is not None
        assert state.value == 42
        assert state.status in {'resolved', 'set'}

    def test_datetime_string_roundtrip(self):
        session = _pyo3_binding_make_session()
        session.set_variable('session_start', '2026-03-15T14:30:00Z')
        assert session.read_variable('session_start').value is not None

class TestPyo3BindingUpdatePolicyViaPythonAPI:
    """Verify ``update_policy`` behavior through ``set_variable``."""

    def test_set_variable_max_prevents_downgrade(self):
        session = _pyo3_binding_make_session()
        session.set_variable('data_sensitivity', 'restricted')
        session.set_variable('data_sensitivity', 'public')
        assert session.read_variable('data_sensitivity').value == 'restricted'

    def test_set_variable_min_keeps_lower(self):
        session = _pyo3_binding_make_session()
        session.set_variable('min_balance', 1000)
        session.set_variable('min_balance', 2000)
        assert session.read_variable('min_balance').value == 1000

    def test_set_variable_collect_accumulates(self):
        session = _pyo3_binding_make_session()
        session.set_variable('data_jurisdictions', ['US'])
        session.set_variable('data_jurisdictions', ['EU'])
        result = session.read_variable('data_jurisdictions').value
        assert isinstance(result, list)
        assert set(result) == {'US', 'EU'}

    def test_set_variable_collect_deduplicates(self):
        session = _pyo3_binding_make_session()
        session.set_variable('data_jurisdictions', ['US'])
        session.set_variable('data_jurisdictions', ['US'])
        result = session.read_variable('data_jurisdictions').value
        assert isinstance(result, list)
        assert result.count('US') == 1

    def test_set_variable_replace_overwrites(self):
        session = _pyo3_binding_make_session()
        session.set_variable('api_cost', 100)
        session.set_variable('api_cost', 50)
        assert session.read_variable('api_cost').value == 50

    def test_record_tool_success_populates_via_expression(self):
        session = _pyo3_binding_make_session()
        session.record_tool_success('read_document', {'sensitivity': 'restricted'})
        session.record_tool_success('read_document', {'sensitivity': 'public'})
        state = session.read_variable('data_sensitivity')
        val = state.value if state is not None else None
        assert val in (None, 'restricted')

class TestPyo3BindingFromYamlChain:
    """Test the Python-specific ``RuntimeBuilder.from_yaml_chain`` API."""

    @staticmethod
    def _stub_classifier(_configuration_id: str, _subject: str) -> Dict[str, Any]:
        return {'failed': False, 'scores': {}}

    def test_chain_loading(self):
        base = _pyo3_binding_fixture_path('bank-manager', 'bank-base.guardrails.yaml')
        overlay = _pyo3_binding_fixture_path('bank-manager', 'bank-manager-assistant.guardrails.yaml')
        rt = RuntimeBuilder.from_yaml_chain([base, overlay]).register_classifier_caller(self._stub_classifier).build()
        assert rt is not None
        names = set(rt.variable_names)
        assert names, 'chain-loaded runtime must expose variable_names'

    def test_chain_merges_tools(self):
        base = _pyo3_binding_fixture_path('bank-manager', 'bank-base.guardrails.yaml')
        overlay = _pyo3_binding_fixture_path('bank-manager', 'bank-manager-assistant.guardrails.yaml')
        rt = RuntimeBuilder.from_yaml_chain([base, overlay]).register_classifier_caller(self._stub_classifier).build()
        session = rt.new_session()
        session.begin_turn()
        outcome = session.validate_tool_call('freeze_account', {}, tool_call_id='call_1')
        assert outcome.verdict.allowed is False
