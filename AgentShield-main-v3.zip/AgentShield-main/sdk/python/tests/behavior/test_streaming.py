"""Behavior tests consolidated into behavior/test_streaming.py."""
from __future__ import annotations
from typing import Any, Iterable, List
import pytest
from agent_shield import StreamChunkResult, StreamingGuard, StreamingReplaceNotSupportedError
from agent_shield.adapters._capabilities import StreamingPushResult
from agent_shield.adapters._shield import _OrchestratorStreamingValidator

class _StreamingReplaceFakeNativeGuard:
    """Minimal stand-in for the PyO3 ``StreamingGuard``.

    Emits the scripted sequence of result dicts on each ``push`` and
    one tail dict on ``finish``. Mirrors the wire shape that the
    Rust binding ``stream_result_to_py`` produces: ``{action, payload,
    reason}`` with snake_case action strings.
    """

    def __init__(self, push_results: Iterable[dict], finish_result: dict | None=None, mode: str='per_chunk') -> None:
        self._push_results = list(push_results)
        self._finish_result = finish_result or {'action': 'pass', 'payload': '', 'reason': None}
        self._push_idx = 0
        self._chunks: List[str] = []
        self._ended = False
        self._mode = mode

    @property
    def mode(self) -> str:
        return self._mode

    @property
    def is_ended(self) -> bool:
        return self._ended

    @property
    def buffer(self) -> str:
        return ''.join(self._chunks)

    @property
    def chunks_received(self) -> int:
        return len(self._chunks)

    def push(self, chunk: str) -> dict:
        self._chunks.append(chunk)
        if self._push_idx < len(self._push_results):
            r = self._push_results[self._push_idx]
            self._push_idx += 1
            return r
        return {'action': 'pass', 'payload': '', 'reason': None}

    def finish(self) -> dict:
        self._ended = True
        return self._finish_result

class _StreamingReplaceFakeBoundary:
    """Minimal `AgentBoundary` stand-in for the orchestrator validator."""

    def make_blocked(self, message: str) -> Any:
        return {'blocked': message}

    def apply_redaction(self, framework_chunk: Any, text: str) -> Any:
        return {'chunk': framework_chunk, 'text': text}

class TestStreamingReplaceStreamChunkResultActionField:

    def test_action_pass_round_trips(self):
        r = StreamChunkResult.from_dict({'action': 'pass', 'payload': 'hello', 'reason': None})
        assert r.action == 'pass'
        assert r.payload == 'hello'
        assert r.reason is None
        assert r.stopped is False

    def test_action_replace_round_trips(self):
        r = StreamChunkResult.from_dict({'action': 'replace', 'payload': 'SSN [SSN]', 'reason': None})
        assert r.action == 'replace'
        assert r.payload == 'SSN [SSN]'
        assert r.stopped is False

    def test_action_stop_sets_stopped_property(self):
        r = StreamChunkResult.from_dict({'action': 'stop', 'payload': '', 'reason': 'policy'})
        assert r.action == 'stop'
        assert r.stopped is True
        assert r.reason == 'policy'

class TestStreamingReplaceOrchestratorStreamingValidatorPropagatesAction:
    """The fix — `_OrchestratorStreamingValidator` must propagate the
    Rust core's `action` field instead of dropping it."""

    def test_push_pass_propagates_action_pass(self):
        guard = _StreamingReplaceFakeNativeGuard(push_results=[{'action': 'pass', 'payload': 'hi', 'reason': None}])
        v = _OrchestratorStreamingValidator(StreamingGuard(guard), _StreamingReplaceFakeBoundary())
        r = v.push('hi')
        assert isinstance(r, StreamingPushResult)
        assert r.action == 'pass'
        assert r.payload == 'hi'
        assert r.stopped is False

    def test_push_replace_propagates_action_replace_f70_2(self):
        guard = _StreamingReplaceFakeNativeGuard(push_results=[{'action': 'replace', 'payload': 'SSN [SSN]', 'reason': None}])
        v = _OrchestratorStreamingValidator(StreamingGuard(guard), _StreamingReplaceFakeBoundary())
        r = v.push('9')
        assert r.action == 'replace'
        assert r.payload == 'SSN [SSN]'
        assert r.stopped is False

    def test_push_stop_propagates_action_stop(self):
        guard = _StreamingReplaceFakeNativeGuard(push_results=[{'action': 'stop', 'payload': '', 'reason': 'blocked'}])
        v = _OrchestratorStreamingValidator(StreamingGuard(guard), _StreamingReplaceFakeBoundary())
        r = v.push('x')
        assert r.action == 'stop'
        assert r.stopped is True
        assert r.reason == 'blocked'

    def test_finish_propagates_action(self):
        guard = _StreamingReplaceFakeNativeGuard(push_results=[], finish_result={'action': 'replace', 'payload': '[REDACTED]', 'reason': None})
        v = _OrchestratorStreamingValidator(StreamingGuard(guard), _StreamingReplaceFakeBoundary())
        r = v.finish()
        assert r.action == 'replace'
        assert r.payload == '[REDACTED]'

class TestStreamingReplaceStreamingGuardProcessCase:
    """regression canonical reproducer: byte-by-byte chunks over
    `SSN 123-45-6789` with a Stage-5 SSN redactor. The append-only
    iterator surface (`StreamingGuard.process`) MUST raise on the
    first `replace` event so the consumer cannot render the leaked-
    then-redacted blob."""

    def test_replace_action_raises_streaming_replace_not_supported(self):
        chunks = list('SSN 123-45-6789')
        push_results = [{'action': 'pass', 'payload': ch, 'reason': None} for ch in chunks[:-1]] + [{'action': 'replace', 'payload': 'SSN [SSN]', 'reason': 'Output contained an SSN.'}]
        guard = StreamingGuard(_StreamingReplaceFakeNativeGuard(push_results=push_results))
        emitted: list[str] = []
        with pytest.raises(StreamingReplaceNotSupportedError) as excinfo:
            for safe in guard.process(chunks):
                emitted.append(safe)
        msg = str(excinfo.value)
        assert 'replace' in msg.lower()
        assert 'on_complete' in msg
        assert 'SSN' in msg

    def test_replace_action_on_finish_also_raises(self):
        guard = StreamingGuard(_StreamingReplaceFakeNativeGuard(push_results=[{'action': 'pass', 'payload': 'hello ', 'reason': None}], finish_result={'action': 'replace', 'payload': 'hello [REDACTED]', 'reason': 'secret'}))
        emitted: list[str] = []
        with pytest.raises(StreamingReplaceNotSupportedError):
            for safe in guard.process(['hello ', 'secret']):
                emitted.append(safe)
        assert emitted == ['hello ']

    def test_pass_only_stream_yields_concatenation_no_error(self):
        guard = StreamingGuard(_StreamingReplaceFakeNativeGuard(push_results=[{'action': 'pass', 'payload': 'alpha ', 'reason': None}, {'action': 'pass', 'payload': 'beta ', 'reason': None}, {'action': 'pass', 'payload': 'gamma', 'reason': None}], finish_result={'action': 'pass', 'payload': '', 'reason': None}))
        out = list(guard.process(['a', 'b', 'c']))
        assert out == ['alpha ', 'beta ', 'gamma']

    def test_stop_action_terminates_iterator_without_error(self):
        guard = StreamingGuard(_StreamingReplaceFakeNativeGuard(push_results=[{'action': 'pass', 'payload': 'ok ', 'reason': None}, {'action': 'stop', 'payload': '', 'reason': 'policy'}]))
        out = list(guard.process(['a', 'b', 'c']))
        assert out == ['ok ']

    def test_finish_pass_payload_yielded(self):
        guard = StreamingGuard(_StreamingReplaceFakeNativeGuard(push_results=[{'action': 'pass', 'payload': '', 'reason': None}, {'action': 'pass', 'payload': '', 'reason': None}], finish_result={'action': 'pass', 'payload': 'validated body', 'reason': None}))
        out = list(guard.process(['a', 'b']))
        assert out == ['validated body']

class TestStreamingReplaceExceptionExports:

    def test_exception_importable_from_package_root(self):
        from agent_shield import StreamingReplaceNotSupportedError as Exc1
        from agent_shield.errors import StreamingReplaceNotSupportedError as Exc2
        assert Exc1 is Exc2
        assert issubclass(Exc1, RuntimeError)

class TestStreamingReplaceBufferedAdapterResetOnReplace:
    """The langchain / autogen adapters accumulate `safe_parts` and
    yield via `apply_redaction` at the end. On `replace` they MUST
    reset the accumulator instead of appending so the consumer sees
    only the redacted text, not the leaked-then-redacted concatenation.

    The contract is enforced via direct unit drive of the adapter's
    `stream` coroutine with stubbed framework objects.
    """

    @pytest.mark.asyncio
    async def test_langchain_adapter_resets_safe_parts_on_replace(self):
        pytest.importorskip('langchain_core')
        from agent_shield.adapters.langchain import _StreamingAdapter
        from langchain_core.messages import AIMessageChunk
        chunk_texts = list('SSN 123-45-6789')

        class _FakeRunnable:

            async def astream(self, _input, _config, **_kwargs):
                for ch in chunk_texts:
                    yield {'messages': [AIMessageChunk(content=ch)]}
        push_results = [StreamingPushResult(payload=ch, stopped=False, reason=None, action='pass') for ch in chunk_texts[:-1]] + [StreamingPushResult(payload='SSN [SSN]', stopped=False, reason='ssn', action='replace')]
        tail = StreamingPushResult(payload=None, stopped=False, reason=None, action='pass')

        class _FakeValidator:
            mode = 'per_chunk'

            def __init__(self):
                self._idx = 0

            def push(self, _text):
                r = push_results[self._idx]
                self._idx += 1
                return r

            def finish(self):
                return tail

            def make_blocked(self, msg):
                return {'blocked': msg}

            def apply_redaction(self, _chunk, text):
                return {'final': text}
        adapter = _StreamingAdapter()
        emissions = []
        async for em in adapter.stream(_FakeRunnable(), 'ssn', _FakeValidator()):
            emissions.append(em)
        assert emissions == [{'final': 'SSN [SSN]'}]

class TestStreamingReplaceYieldDirectAdapterRaisesOnReplace:
    """The openai_agents / anthropic_agents adapters yield deltas
    directly to the consumer (append-only). On `replace` they MUST
    raise ``StreamingReplaceNotSupportedError`` so the host sees the
    unsafe configuration instead of silently rendering both versions.
    """

    @pytest.mark.asyncio
    async def test_openai_agents_adapter_raises_on_replace(self):
        pytest.importorskip('agents')
        from agent_shield.adapters.openai_agents import _StreamingAdapter

        class _FakeStreamed:

            async def stream_events(self):

                class _Ev:
                    delta = '9'
                yield _Ev()

        class _FakeRunner:

            @staticmethod
            def run_streamed(_agent, _input, **_kw):
                return _FakeStreamed()
        import agents
        agents.Runner = _FakeRunner

        class _FakeValidator:
            mode = 'per_chunk'

            def push(self, _text):
                return StreamingPushResult(payload='SSN [SSN]', stopped=False, reason='ssn', action='replace')

            def finish(self):
                return StreamingPushResult(payload=None, stopped=False, reason=None, action='pass')

            def make_blocked(self, msg):
                return {'blocked': msg}

            def apply_redaction(self, _chunk, text):
                return {'final': text}
        adapter = _StreamingAdapter()
        with pytest.raises(StreamingReplaceNotSupportedError):
            async for _em in adapter.stream(object(), 'ssn', _FakeValidator()):
                pass
import textwrap
from pathlib import Path
from typing import AsyncIterator
from agent_shield import RuntimeBuilder
from agent_shield.adapters._shield import GuardedRunner
_streaming_input_redaction_REDACT_YAML = textwrap.dedent('    metadata:\n      name: "r89-1-input-redact"\n      version: "0.1.0"\n      agent_shield_version: "2.0"\n\n    objective:\n      goal:\n        - "Demonstrate Stage 1 redaction."\n      forbidden:\n        - "Pass raw secret tokens into the agent."\n\n    resources:\n      tools:\n        - name: "echo"\n          description: "Echo helper."\n          permission: "read_only"\n\n    input_validation:\n      guard_policies:\n        - name: "redact_secret_input"\n          evaluate_when:\n            - patterns:\n                - "SECRET-[A-Z0-9]{4,}"\n              reason: "Input contained a secret token."\n          action: "redact"\n          replacement: "[INPUT REDACTED]"\n    ')
_streaming_input_redaction_BLOCK_YAML = textwrap.dedent('    metadata:\n      name: "r89-1-input-block"\n      version: "0.1.0"\n      agent_shield_version: "2.0"\n\n    objective:\n      goal:\n        - "Demonstrate Stage 1 block."\n      forbidden:\n        - "Pass blocked tokens to the agent."\n\n    resources:\n      tools:\n        - name: "echo"\n          description: "Echo helper."\n          permission: "read_only"\n\n    input_validation:\n      guard_policies:\n        - name: "block_forbidden_input"\n          evaluate_when:\n            - patterns:\n                - "FORBIDDEN-[A-Z0-9]+"\n              reason: "Input contained a forbidden token."\n          action: "block"\n    ')
_streaming_input_redaction_NOOP_YAML = textwrap.dedent('    metadata:\n      name: "r89-1-input-noop"\n      version: "0.1.0"\n      agent_shield_version: "2.0"\n\n    objective:\n      goal:\n        - "Pass-through Stage 1 (no policies)."\n      forbidden:\n        - "n/a"\n\n    resources:\n      tools:\n        - name: "echo"\n          description: "Echo helper."\n          permission: "read_only"\n    ')

class _StreamingInputRedactionRecordingBoundary:
    """Capture what the non-streaming path forwarded to the agent."""

    def __init__(self) -> None:
        self.run_inputs: List[Any] = []

    async def run(self, agent: Any, input_text: Any, **_: Any) -> dict:
        self.run_inputs.append(input_text)
        return {'output': f'nonstream saw: {input_text}'}

    def extract_output(self, result: Any) -> str | None:
        if isinstance(result, dict):
            return result.get('output')
        return None

    def apply_redaction(self, result: Any, redacted_text: str) -> Any:
        out = dict(result) if isinstance(result, dict) else {'output': ''}
        out['output'] = redacted_text
        return out

    def make_blocked(self, message: str) -> dict:
        return {'blocked': message}

class _StreamingInputRedactionRecordingStreaming:
    """Streaming adapter that records the ``input_text`` it received
    and re-emits it via the validator, mirroring how a real streaming
    adapter would push the agent's response chunks back through Stage 5.

    The shape matches :class:`agent_shield.adapters._capabilities.StreamingAdapter`.
    """

    def __init__(self) -> None:
        self.stream_inputs: List[Any] = []

    async def stream(self, agent: Any, input_text: Any, validator: Any, **_: Any) -> AsyncIterator[dict]:
        self.stream_inputs.append(input_text)
        text = f'stream saw: {input_text}'
        mid = len(text) // 2
        safe_parts: List[str] = []
        for chunk in (text[:mid], text[mid:]):
            result = validator.push(chunk)
            if result.stopped:
                yield validator.make_blocked(result.reason or 'blocked')
                return
            if result.action == 'replace':
                safe_parts = [result.payload or '']
            elif result.payload:
                safe_parts.append(result.payload)
        tail = validator.finish()
        if tail.stopped:
            yield validator.make_blocked(tail.reason or 'blocked')
            return
        if tail.action == 'replace':
            safe_parts = [tail.payload or '']
        elif tail.payload:
            safe_parts.append(tail.payload)
        yield {'output': ''.join(safe_parts)}

def _streaming_input_redaction_yaml_to_runtime(tmp_path: Path, body: str) -> Any:
    fixture = tmp_path / 'guardrails.yaml'
    fixture.write_text(body, encoding='utf-8')
    return RuntimeBuilder.from_yaml(str(fixture)).build()

@pytest.mark.asyncio
async def test_streaming_input_redaction__streaming_input_redact_propagates_to_agent(tmp_path: Path) -> None:
    runtime = _streaming_input_redaction_yaml_to_runtime(tmp_path, _streaming_input_redaction_REDACT_YAML)
    boundary = _StreamingInputRedactionRecordingBoundary()
    streaming = _StreamingInputRedactionRecordingStreaming()
    runner = GuardedRunner(runtime, agent=object(), boundary=boundary, streaming=streaming)
    emissions = [item async for item in runner.run_streamed('please process SECRET-ABCD1234 now')]
    assert streaming.stream_inputs, 'streaming adapter was never invoked'
    forwarded = streaming.stream_inputs[-1]
    assert 'SECRET-ABCD1234' not in str(forwarded), 'Streaming adapter received the unredacted input; Stage 1 redact did not propagate to the streaming path (behavior contract / the behavior contract).'
    assert '[INPUT REDACTED]' in str(forwarded)
    assert not any(('SECRET-ABCD1234' in str(e) for e in emissions)), 'Stage-1-redacted secret leaked through the streamed emissions.'

@pytest.mark.asyncio
async def test_streaming_input_redaction__streaming_input_block_returns_blocked(tmp_path: Path) -> None:
    runtime = _streaming_input_redaction_yaml_to_runtime(tmp_path, _streaming_input_redaction_BLOCK_YAML)
    boundary = _StreamingInputRedactionRecordingBoundary()
    streaming = _StreamingInputRedactionRecordingStreaming()
    runner = GuardedRunner(runtime, agent=object(), boundary=boundary, streaming=streaming)
    emissions = [item async for item in runner.run_streamed('call FORBIDDEN-XYZ123')]
    assert emissions, 'streaming path produced no emissions'
    assert all((isinstance(e, dict) and 'blocked' in e for e in emissions)), f'Expected only blocked-shape emissions; got: {emissions!r}'
    assert not streaming.stream_inputs, 'Streaming adapter was invoked despite Stage 1 block.'

@pytest.mark.asyncio
async def test_streaming_input_redaction__streaming_no_input_policy_passes_original_text(tmp_path: Path) -> None:
    runtime = _streaming_input_redaction_yaml_to_runtime(tmp_path, _streaming_input_redaction_NOOP_YAML)
    boundary = _StreamingInputRedactionRecordingBoundary()
    streaming = _StreamingInputRedactionRecordingStreaming()
    runner = GuardedRunner(runtime, agent=object(), boundary=boundary, streaming=streaming)
    user_text = 'just a normal message'
    emissions = [item async for item in runner.run_streamed(user_text)]
    assert streaming.stream_inputs == [user_text], f'Streaming adapter received unexpected input(s): {streaming.stream_inputs!r}'
    assert emissions, 'streaming path produced no emissions'

@pytest.mark.asyncio
async def test_streaming_input_redaction__nonstreaming_input_redact_still_works(tmp_path: Path) -> None:
    runtime = _streaming_input_redaction_yaml_to_runtime(tmp_path, _streaming_input_redaction_REDACT_YAML)
    boundary = _StreamingInputRedactionRecordingBoundary()
    streaming = _StreamingInputRedactionRecordingStreaming()
    runner = GuardedRunner(runtime, agent=object(), boundary=boundary, streaming=streaming)
    result = await runner.run('please process SECRET-ABCD1234 now')
    assert boundary.run_inputs, 'non-streaming path never invoked .run()'
    forwarded = boundary.run_inputs[-1]
    assert 'SECRET-ABCD1234' not in str(forwarded)
    assert '[INPUT REDACTED]' in str(forwarded)
    assert 'SECRET-ABCD1234' not in str(result)

def test_streaming_input_redaction__stage1_decision_proceed_with_redact(tmp_path: Path) -> None:
    from agent_shield.adapters._orchestration import check_stage1, Stage1Decision
    runtime = _streaming_input_redaction_yaml_to_runtime(tmp_path, _streaming_input_redaction_REDACT_YAML)
    with runtime.new_session() as sess:
        sess.begin_turn()
        decision = check_stage1(sess, 'process SECRET-ABCD1234')
    assert isinstance(decision, Stage1Decision)
    assert decision.kind == 'proceed'
    assert decision.block_message is None
    assert decision.effective_input is not None
    assert 'SECRET-ABCD1234' not in decision.effective_input
    assert '[INPUT REDACTED]' in decision.effective_input

def test_streaming_input_redaction__stage1_decision_block(tmp_path: Path) -> None:
    from agent_shield.adapters._orchestration import check_stage1, Stage1Decision
    runtime = _streaming_input_redaction_yaml_to_runtime(tmp_path, _streaming_input_redaction_BLOCK_YAML)
    with runtime.new_session() as sess:
        sess.begin_turn()
        decision = check_stage1(sess, 'call FORBIDDEN-XYZ123')
    assert isinstance(decision, Stage1Decision)
    assert decision.kind == 'block'
    assert decision.is_blocked is True
    assert decision.effective_input is None
    assert decision.block_message

def test_streaming_input_redaction__stage1_decision_passthrough(tmp_path: Path) -> None:
    from agent_shield.adapters._orchestration import check_stage1, Stage1Decision
    runtime = _streaming_input_redaction_yaml_to_runtime(tmp_path, _streaming_input_redaction_NOOP_YAML)
    with runtime.new_session() as sess:
        sess.begin_turn()
        decision = check_stage1(sess, 'hello world')
    assert isinstance(decision, Stage1Decision)
    assert decision.kind == 'proceed'
    assert decision.block_message is None
    assert decision.effective_input == 'hello world'
