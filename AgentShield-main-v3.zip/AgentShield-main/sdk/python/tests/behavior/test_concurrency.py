"""Behavior tests consolidated into behavior/test_concurrency.py."""
from __future__ import annotations
import asyncio
import time
from agent_shield import RuntimeBuilder
from agent_shield.adapters._shield import Shield
from agent_shield.observability import CapturingProvider
_protect_tool_concurrency_FIXTURE_YAML = '\nmetadata:\n  name: f72-5-protect-tool-concurrency\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["pin protect_tool same-session concurrency safety"]\n  forbidden: ["nothing"]\nresources:\n  tools:\n    - name: audit_tool\n      description: "Tool used for the concurrency repro (regression)."\n      permission: execute\n'

def _protect_tool_concurrency_build_shield() -> Shield:
    provider = CapturingProvider()
    rt = RuntimeBuilder.from_yaml_strings([_protect_tool_concurrency_FIXTURE_YAML]).register_observability_provider(provider).build()
    return Shield(rt)

def test_protect_tool_concurrency__20_concurrent_protect_tool_same_session_all_succeed() -> None:
    """20 concurrent ``protect_tool`` calls bound to the SAME explicit
    ``session=`` must all succeed. Pre-fix this produced
    ``binding missing (unknown_admission N)`` blocks on most calls
    because overlapping turns raced the Rust admission registry."""
    shield = _protect_tool_concurrency_build_shield()
    sess = shield.create_session(session_id='f72-5-same-session')

    async def tool(eff: dict) -> str:
        await asyncio.sleep(0.001)
        return f'ok {eff["payload"]}'

    async def driver():

        async def one(i: int) -> tuple[bool, object]:
            return await shield.protect_tool('audit_tool', {'payload': f'TOKEN-{i:05d}'}, tool, session=sess, tool_call_id=f'f72-5-call-{i}')
        return await asyncio.gather(*[one(i) for i in range(20)])
    results = asyncio.run(driver())
    assert len(results) == 20
    for i, (blocked, output) in enumerate(results):
        assert blocked is False, f'call {i}: expected success, got blocked={blocked!r} output={output!r}'
        assert isinstance(output, str) and output.startswith('ok TOKEN-'), f"call {i}: expected 'ok TOKEN-…', got {output!r}"
    for blocked, output in results:
        if blocked:
            assert 'binding missing' not in str(output), f'regression: Stage 4 binding-missing block surfaced under concurrent same-session protect_tool calls. output={output!r}'

def test_protect_tool_concurrency__protect_tool_lock_does_not_serialise_across_sessions() -> None:
    """The per-session lock MUST be keyed per session, not global —
    concurrent calls on DIFFERENT sessions must run in parallel."""
    shield = _protect_tool_concurrency_build_shield()
    sessions = [shield.create_session(session_id=f'f72-5-multi-{i}') for i in range(16)]
    calls_per_session = 4
    tool_latency_s = 0.02

    async def tool(eff: dict) -> str:
        await asyncio.sleep(tool_latency_s)
        return f'ok {eff["payload"]}'

    async def driver():

        async def one(session_idx: int, call_idx: int) -> tuple[bool, object]:
            return await shield.protect_tool('audit_tool', {'payload': f'S{session_idx}-{call_idx}'}, tool, session=sessions[session_idx], tool_call_id=f'f72-5-multi-{session_idx}-{call_idx}')
        coros = [one(s, c) for s in range(len(sessions)) for c in range(calls_per_session)]
        return await asyncio.gather(*coros)
    started = time.perf_counter()
    results = asyncio.run(driver())
    elapsed = time.perf_counter() - started
    assert len(results) == len(sessions) * calls_per_session
    for blocked, output in results:
        assert blocked is False, f'unexpected block under cross-session concurrency: {output!r}'
    global_lock_floor = len(sessions) * calls_per_session * tool_latency_s
    assert elapsed < global_lock_floor * 0.5, f'regression lock regression suspected: cross-session calls took {elapsed:.3f}s, which is >= 50% of the global-lock floor {global_lock_floor:.3f}s; the per-session lock may have been replaced by a shield-wide lock.'

def test_protect_tool_concurrency__protect_tool_single_session_throughput_unchanged_when_uncontended() -> None:
    """The lock MUST add negligible overhead when uncontended.

    Compares sequential calls on a single session against the same
    number of calls scattered across distinct sessions. The two
    should be within the same order of magnitude — the lock acquires
    instantly when nobody else holds it."""
    shield = _protect_tool_concurrency_build_shield()
    n = 20

    async def tool(_eff: dict) -> str:
        return 'ok'
    sess_one = shield.create_session(session_id='f72-5-uncontended-one')

    async def sequential():
        for i in range(n):
            blocked, _ = await shield.protect_tool('audit_tool', {'i': i}, tool, session=sess_one, tool_call_id=f'seq-{i}')
            assert blocked is False
    start = time.perf_counter()
    asyncio.run(sequential())
    sequential_elapsed = time.perf_counter() - start
    distinct_sessions = [shield.create_session(session_id=f'f72-5-uncontended-multi-{i}') for i in range(n)]

    async def parallel_distinct():

        async def one(i: int):
            blocked, _ = await shield.protect_tool('audit_tool', {'i': i}, tool, session=distinct_sessions[i], tool_call_id=f'par-{i}')
            assert blocked is False
        await asyncio.gather(*[one(i) for i in range(n)])
    start = time.perf_counter()
    asyncio.run(parallel_distinct())
    parallel_elapsed = time.perf_counter() - start
    assert sequential_elapsed < max(parallel_elapsed, 0.001) * 50 + 0.5, f'regression lock overhead regression: {n} sequential same-session protect_tool calls took {sequential_elapsed:.3f}s vs {parallel_elapsed:.3f}s for {n} distinct-session calls (both should complete in well under a second on any reasonable host).'
from agent_shield.adapters._orchestration import guarded_turn
_turn_lease_YAML = '\nmetadata:\n  name: turn-lease-stress\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["stress per-turn lease isolation"]\nvariables:\n  - name: turn_token\n    type: string\n    lifetime: per_turn\n'

def test_turn_lease__20_concurrent_guarded_turns_same_session_isolate_per_turn_state() -> None:
    runtime = RuntimeBuilder.from_yaml_strings([_turn_lease_YAML]).build()
    session = runtime.new_session(session_id='py-turn-lease-stress')

    async def one(i: int) -> str | None:
        token = f'token-{i}'

        async def execute(_effective: str) -> str | None:
            session.set_variable('turn_token', token)
            await asyncio.sleep(0)
            state = session.read_variable('turn_token')
            return None if state is None else state.value
        return await guarded_turn(session, token, execute=execute, extract_output=lambda result: result, apply_redaction=lambda result, text: text, make_blocked=lambda msg: msg)

    async def driver():
        return await asyncio.gather(*(one(i) for i in range(20)))
    results = asyncio.run(driver())
    assert results == [f'token-{i}' for i in range(20)]
