"""Behavior tests consolidated into behavior/test_adapters_openai_client.py."""
from __future__ import annotations
from typing import Any, Optional
from unittest.mock import MagicMock
import openai
import pytest
from agent_shield.adapters.openai_agents import AzureClientMissingApiVersionError, _LlmCallerFactory, _clone_async_openai_client_as_sync

def test_openai_adapter_azure_clone__azure_async_clone_preserves_api_version_and_azure_endpoint() -> None:
    src = openai.AsyncAzureOpenAI(azure_endpoint='https://r96-1.openai.azure.com', api_key='real-key', api_version='2025-04-01-preview', azure_deployment='gpt-4o', organization='org-r96')
    clone = _clone_async_openai_client_as_sync(src)
    assert isinstance(clone, openai.AzureOpenAI)
    assert not isinstance(clone, openai.AsyncAzureOpenAI)
    assert clone._api_version == '2025-04-01-preview'
    assert str(clone._azure_endpoint) == 'https://r96-1.openai.azure.com'
    assert clone._azure_deployment == 'gpt-4o'
    assert clone.organization == 'org-r96'
    assert clone.api_key == 'real-key'

def test_openai_adapter_azure_clone__azure_async_clone_preserves_azure_ad_token() -> None:
    src = openai.AsyncAzureOpenAI(azure_endpoint='https://r96-1.openai.azure.com', azure_ad_token='aad-bearer-token', api_version='2024-01-01-preview')
    clone = _clone_async_openai_client_as_sync(src)
    assert isinstance(clone, openai.AzureOpenAI)
    assert clone._azure_ad_token == 'aad-bearer-token'
    assert clone._api_version == '2024-01-01-preview'
    assert clone.api_key.startswith('<')

def test_openai_adapter_azure_clone__azure_async_clone_preserves_azure_ad_token_provider() -> None:

    def _provider() -> str:
        return 'fresh-aad-token'
    src = openai.AsyncAzureOpenAI(azure_endpoint='https://r96-1.openai.azure.com', azure_ad_token_provider=_provider, api_version='2024-01-01-preview')
    clone = _clone_async_openai_client_as_sync(src)
    assert clone._azure_ad_token_provider is _provider

class _OpenaiAdapterAzureCloneFakeAsyncAzureMissingApiVersion:
    """Stand-in for ``AsyncAzureOpenAI`` with ``_api_version = None``.

    ``openai.AsyncAzureOpenAI.__init__`` would itself reject a missing
    ``api_version`` at construction time, so we use a duck-typed stub
    to exercise the adapter's clone-time guard. The shape mirrors the
    private attributes the real client exposes.
    """
    api_key = 'k'
    base_url = None
    organization = None
    project = None
    _api_version: Optional[str] = None
    _azure_endpoint = 'https://r96-1.openai.azure.com'
_OpenaiAdapterAzureCloneFakeAsyncAzureMissingApiVersion.__name__ = 'AsyncAzureOpenAI'

def test_openai_adapter_azure_clone__missing_api_version_raises_typed_error() -> None:
    with pytest.raises(AzureClientMissingApiVersionError) as exc:
        _clone_async_openai_client_as_sync(_OpenaiAdapterAzureCloneFakeAsyncAzureMissingApiVersion())
    msg = str(exc.value)
    assert 'api_version' in msg
    assert 'Shield.with_client' in msg

def test_openai_adapter_azure_clone__missing_api_version_does_not_fall_back_to_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """The adapter must NOT silently honour ``OPENAI_API_VERSION``.

    Implicit env fallback would mask configuration drift in CI /
    staging / production — the customer must set ``api_version`` on
    their own client.
    """
    monkeypatch.setenv('OPENAI_API_VERSION', 'should-not-be-used')
    with pytest.raises(AzureClientMissingApiVersionError):
        _clone_async_openai_client_as_sync(_OpenaiAdapterAzureCloneFakeAsyncAzureMissingApiVersion())

def test_openai_adapter_azure_clone__non_azure_async_clone_preserves_organization_and_project() -> None:
    src = openai.AsyncOpenAI(api_key='k', organization='org-r96', project='proj-r96')
    clone = _clone_async_openai_client_as_sync(src)
    assert isinstance(clone, openai.OpenAI)
    assert not isinstance(clone, openai.AsyncOpenAI)
    assert clone.organization == 'org-r96'
    assert clone.project == 'proj-r96'
    assert clone.api_key == 'k'

def test_openai_adapter_azure_clone__llm_caller_factory_uses_cloned_sync_azure_client(monkeypatch: pytest.MonkeyPatch) -> None:
    """The caller produced by ``make_caller`` must dispatch through the
    cloned sync client, not the original async one (which would deadlock
    when invoked from Rust's sync callback)."""
    src = openai.AsyncAzureOpenAI(azure_endpoint='https://r96-1.openai.azure.com', api_key='real-key', api_version='2025-04-01-preview')
    fake_sync_client = MagicMock()
    fake_sync_client.chat.completions.create.return_value = MagicMock(choices=[MagicMock(message=MagicMock(content='LLM-response'))])
    captured: dict[str, Any] = {}

    def _fake_clone(client: Any) -> Any:
        captured['clone_called_with'] = client
        return fake_sync_client
    monkeypatch.setattr('agent_shield.adapters.openai_agents._clone_async_openai_client_as_sync', _fake_clone)
    factory = _LlmCallerFactory()
    caller = factory.make_caller(src, configuration_resolver=lambda _id: {'model': 'gpt-4o'})
    out = caller('stage1-judge', 'hello')
    assert out == 'LLM-response'
    assert captured['clone_called_with'] is src
    fake_sync_client.chat.completions.create.assert_called_once()
    kwargs = fake_sync_client.chat.completions.create.call_args.kwargs
    assert kwargs['model'] == 'gpt-4o'
    assert kwargs['messages'] == [{'role': 'user', 'content': 'hello'}]

def test_openai_adapter_azure_clone__sync_azure_client_passes_through_unchanged() -> None:
    """Customers who already pass a sync ``AzureOpenAI`` shouldn't be
    cloned — the factory only clones ``Async*`` sources."""
    sync_src = openai.AzureOpenAI(azure_endpoint='https://r96-1.openai.azure.com', api_key='real-key', api_version='2025-04-01-preview')
    factory = _LlmCallerFactory()
    caller = factory.make_caller(sync_src, configuration_resolver=lambda _id: {'model': 'gpt-4o'})
    sync_src.chat.completions.create = MagicMock(return_value=MagicMock(choices=[MagicMock(message=MagicMock(content='ok'))]))
    out = caller('stage1-judge', 'hi')
    assert out == 'ok'
    sync_src.chat.completions.create.assert_called_once()
