"""Behavior tests consolidated into behavior/test_tool_protection.py."""
from __future__ import annotations
from .._support.paths import REPO_ROOT
import asyncio
from agent_shield import RuntimeBuilder
from agent_shield.adapters._shield import Shield
from agent_shield.observability import CapturingProvider
_protect_tool_caller_tool_call_id_FIXTURE_YAML = '\nmetadata:\n  name: f50-7-caller-tool-call-id\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["test caller-supplied tool_call_id propagation"]\n  forbidden: ["nothing"]\nresources:\n  tools:\n    - name: echo\n      description: "Echo the supplied message."\n      permission: execute\n'

def _protect_tool_caller_tool_call_id_shield_with_provider() -> tuple[Shield, CapturingProvider]:
    provider = CapturingProvider()
    rt = RuntimeBuilder.from_yaml_strings([_protect_tool_caller_tool_call_id_FIXTURE_YAML]).register_observability_provider(provider).build()
    return (Shield(rt), provider)

def _protect_tool_caller_tool_call_id_find_tool_called_event(provider: CapturingProvider, tool_name: str):
    target_event_id = f'tool.{tool_name}.called'
    for ev in provider.events:
        if ev.attributes.get('agent_shield.event.id') == target_event_id:
            return ev
    return None

def test_protect_tool_caller_tool_call_id__protect_tool_caller_supplied_tool_call_id_propagates_to_observability() -> None:
    """regression: when the customer passes ``tool_call_id="vercel-call-abc123"``
    the Stage 3 ``tool.<name>.called`` observability event carries the
    same id, so cross-system trace correlation works out of the box."""
    shield, provider = _protect_tool_caller_tool_call_id_shield_with_provider()
    supplied = 'vercel-call-abc123'

    async def _exec(params: dict) -> str:
        return 'ok'
    blocked, output = asyncio.run(shield.protect_tool('echo', {'msg': 'hi'}, _exec, tool_call_id=supplied))
    assert blocked is False
    assert output == 'ok'
    ev = _protect_tool_caller_tool_call_id_find_tool_called_event(provider, 'echo')
    assert ev is not None, f'no tool.echo.called event captured; provider saw event_ids: {[e.attributes.get("agent_shield.event.id") for e in provider.events]}'
    observed = ev.attributes.get('agent_shield.invocation.tool_call_id')
    assert observed == supplied, f'regression: caller-supplied tool_call_id {supplied!r} did NOT propagate to Stage 3 event (observed={observed!r})'

def test_protect_tool_caller_tool_call_id__protect_tool_default_mints_tool_call_id() -> None:
    """Backward compat: without ``tool_call_id=`` the SDK mints a UUID
    so concurrent same-name calls don't collide on the the behavior contract binding
    key. The minted id MUST appear in the Stage 3 event."""
    shield, provider = _protect_tool_caller_tool_call_id_shield_with_provider()

    async def _exec(params: dict) -> str:
        return 'ok'
    blocked, _ = asyncio.run(shield.protect_tool('echo', {'msg': 'hi'}, _exec))
    assert blocked is False
    ev = _protect_tool_caller_tool_call_id_find_tool_called_event(provider, 'echo')
    assert ev is not None
    minted = ev.attributes.get('agent_shield.invocation.tool_call_id')
    assert isinstance(minted, str) and len(minted) > 0, f'expected a minted tool_call_id string, got {minted!r}'
import pytest
_protect_tool_singular_shape_NOOP_YAML = '\nmetadata:\n  name: protect-tool-shape\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["test"]\nresources:\n  tools:\n    - name: classify_document\n      permission: read_only\n    - name: list_tool\n      permission: read_only\n    - name: pydantic_tool\n      permission: read_only\n'

def _protect_tool_singular_shape_shield() -> Shield:
    runtime = RuntimeBuilder.from_yaml_strings([_protect_tool_singular_shape_NOOP_YAML]).build()
    return Shield(runtime)

def test_protect_tool_singular_shape__protect_tool_dict_return_is_dict() -> None:
    """regression — dict-returning tool gives the caller a dict, not the
    Python-repr string the pre-fix path produced."""
    shield = _protect_tool_singular_shape_shield()

    async def _classify(params: dict) -> dict:
        return {'score': 0.91, 'category': 'urgent', 'summary': 'ok'}
    blocked, output = asyncio.run(shield.protect_tool('classify_document', {'doc': 'x'}, _classify))
    assert blocked is False
    assert isinstance(output, dict), f'protect_tool stringified the dict (regression): got {type(output).__name__} = {output!r}'
    assert output['score'] == 0.91
    assert output['category'] == 'urgent'
    assert output['summary'] == 'ok'

def test_protect_tool_singular_shape__protect_tool_list_return_is_list() -> None:
    shield = _protect_tool_singular_shape_shield()

    async def _list_tool(params: dict) -> list:
        return [{'a': 1}, {'a': 2}, {'a': 3}]
    blocked, output = asyncio.run(shield.protect_tool('list_tool', {}, _list_tool))
    assert blocked is False
    assert isinstance(output, list)
    assert len(output) == 3
    assert output[0]['a'] == 1

def test_protect_tool_singular_shape__protect_tool_string_return_still_string() -> None:
    """Legacy contract: ``str`` returns stay ``str``."""
    shield = _protect_tool_singular_shape_shield()

    async def _str_tool(params: dict) -> str:
        return 'hello world'
    blocked, output = asyncio.run(shield.protect_tool('classify_document', {}, _str_tool))
    assert blocked is False
    assert isinstance(output, str)
    assert output == 'hello world'

def test_protect_tool_singular_shape__protect_tool_int_return_passes_through() -> None:
    shield = _protect_tool_singular_shape_shield()

    async def _int_tool(params: dict) -> int:
        return 42
    blocked, output = asyncio.run(shield.protect_tool('classify_document', {}, _int_tool))
    assert blocked is False
    assert output == 42

def test_protect_tool_singular_shape__protect_tool_pydantic_return_normalised_to_dict() -> None:
    """Pydantic v2 ``BaseModel`` returns are normalised via
    ``model_dump(mode='json')`` so the same shape Stage 4 extractors
    see is also what flows back to the caller (matches the plural
    :meth:`protect_tools` contract from regression / a2222c5)."""
    pydantic = pytest.importorskip('pydantic')
    BaseModel = pydantic.BaseModel

    class Result(BaseModel):
        score: float
        category: str
    shield = _protect_tool_singular_shape_shield()

    async def _pyd_tool(params: dict) -> Result:
        return Result(score=0.5, category='ok')
    blocked, output = asyncio.run(shield.protect_tool('pydantic_tool', {}, _pyd_tool))
    assert blocked is False
    assert isinstance(output, dict), f'protect_tool did not normalise Pydantic model; got {type(output).__name__}'
    assert output['score'] == 0.5
    assert output['category'] == 'ok'

def test_protect_tool_singular_shape__protect_tool_dict_return_populates_at_result_variable() -> None:
    """End-to-end: a dict-returning protected tool feeds Stage 4
    ``@result.<field>`` extraction (the contract this fix also
    preserves — same one the plural API got at a2222c5)."""
    yaml = '\nmetadata:\n  name: protect-tool-at-result\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["test"]\nresources:\n  tools:\n    - name: classify_document\n      permission: read_only\nvariables:\n  - name: classifier_score\n    type: number\n    populated_by:\n      - kind: tool\n        name: classify_document\n        expression: "@result.score"\n'
    runtime = RuntimeBuilder.from_yaml_strings([yaml]).build()
    shield = Shield(runtime)

    async def _classify(params: dict) -> dict:
        return {'score': 0.91, 'category': 'urgent'}
    sess = shield.runtime.new_session()
    sess.begin_turn()
    try:
        blocked, output = asyncio.run(shield.protect_tool('classify_document', {'doc': 'x'}, _classify, session=sess))
    finally:
        try:
            sess.end_turn()
        except Exception:
            pass
    assert blocked is False
    assert isinstance(output, dict)
    assert output['score'] == 0.91
    score = sess.read_variable('classifier_score')
    assert score.value == 0.91, f'@result.score extraction broken under structured return: got {score!r}'
    assert score.status == 'resolved'
import logging
from typing import Any
from agent_shield import Session, Shield  # noqa: F811
from agent_shield.adapters._orchestration import AgentShieldBlocked, UnguardedToolInvocation, current_session
_protect_tools_session_param_REPO_ROOT = REPO_ROOT
_protect_tools_session_param_Case_YAML = str(_protect_tools_session_param_REPO_ROOT / 'sdk' / 'python' / 'tests' / 'fixtures_smoke' / 'langgraph_session.guardrails.yaml')

def _protect_tools_session_param_build_shield() -> Shield:
    """Build a shield bound to the regression fixture + AutoGen bundle."""
    return Shield.from_yaml(_protect_tools_session_param_Case_YAML, auto_bind=False).with_autogen().build()

def _protect_tools_session_param_build_shield_no_bundle() -> Shield:
    """Bundle-free shield for tests that only exercise
    :meth:`Shield.protect_tool` (singular)."""
    return Shield.from_yaml(_protect_tools_session_param_Case_YAML, auto_bind=False).build()

def _protect_tools_session_param_classify_factory(score: float=0.91):

    async def _classify(params: dict) -> dict[str, Any]:
        return {'classifier_score': score, 'summary': f'summary of {params.get("document", "")}'}
    return _classify

async def _protect_tools_session_param_notify_doctor(params: dict) -> dict[str, Any]:
    return {'paged': True, 'patient_id': params.get('patient_id')}

def _protect_tools_session_param_make_autogen_classify_tool(score: float=0.91):
    from autogen_core.tools import FunctionTool

    async def _classify(document: str) -> dict[str, Any]:
        return {'classifier_score': score, 'summary': f'summary of {document}'}
    return FunctionTool(_classify, name='classify_document', description='Score a clinical document.')

def _protect_tools_session_param_make_autogen_notify_tool():
    from autogen_core.tools import FunctionTool

    async def _notify(patient_id: str) -> dict[str, Any]:
        return {'paged': True, 'patient_id': patient_id}
    return FunctionTool(_notify, name='notify_doctor', description='Page a doctor.')

async def _protect_tools_session_param_run_autogen(protected_tool, params: dict) -> Any:
    """Invoke a protected AutoGen ``FunctionTool``. Returns the
    framework's ``run_json`` result, or re-raises
    :class:`AgentShieldBlocked` when the bundle is configured to
    surface blocks as exceptions."""
    from autogen_core import CancellationToken
    return await protected_tool.run_json(params, CancellationToken())

@pytest.mark.asyncio
async def test_protect_tools_session_param__protect_tools_no_session_no_ambient_raises_unguarded() -> None:
    """A wrapped tool invoked with neither ``session=`` nor an ambient
    ``current_session`` MUST still raise
    :class:`UnguardedToolInvocation` (regression). The regression ``session=``
    path is additive — opting out of fail-closed requires an explicit
    ``session=`` or ``allow_unguarded=True``."""
    shield = _protect_tools_session_param_build_shield()
    [protected_notify] = shield.protect_tools([_protect_tools_session_param_make_autogen_notify_tool()])
    with pytest.raises(Exception) as excinfo:
        await _protect_tools_session_param_run_autogen(protected_notify, {'patient_id': 'p-001'})
    err: BaseException | None = excinfo.value
    saw_unguarded = False
    while err is not None:
        if isinstance(err, UnguardedToolInvocation):
            saw_unguarded = True
            break
        err = err.__cause__ or err.__context__
    assert saw_unguarded, f'Default-path tool call must raise UnguardedToolInvocation; saw {excinfo.value!r} instead.'

@pytest.mark.asyncio
async def test_protect_tools_session_param__protect_tools_with_explicit_session_runs() -> None:
    """Passing ``session=<Session>`` MUST replace the fail-closed
    default: the wrapped tool executes normally, without minting a
    fresh per-call session."""
    shield = _protect_tools_session_param_build_shield()
    sess = shield.create_session(session_id='t2-session')
    try:
        [protected_classify] = shield.protect_tools([_protect_tools_session_param_make_autogen_classify_tool(score=0.93)], session=sess)
        result = await _protect_tools_session_param_run_autogen(protected_classify, {'document': 'doc-1'})
        assert result is not None, 'classify_document MUST run'
    finally:
        sess.close()

@pytest.mark.asyncio
async def test_protect_tools_session_param__protect_tool_same_session_shares_state() -> None:
    """Two ``protect_tool`` calls sharing the same Session MUST
    persist the per_session ``classifier_score`` populated by the
    first call so the second call passes its Stage 2 gate."""
    shield = _protect_tools_session_param_build_shield_no_bundle()
    sess = shield.create_session(session_id='t3-shared')
    try:
        blocked, _ = await shield.protect_tool('classify_document', {'document': 'doc-a'}, _protect_tools_session_param_classify_factory(score=0.93), session=sess)
        assert blocked is False, 'classify_document MUST NOT block'
        blocked, output = await shield.protect_tool('notify_doctor', {'patient_id': 'p-shared'}, _protect_tools_session_param_notify_doctor, session=sess)
        assert blocked is False, f'notify_doctor MUST pass because classifier_score persists on the shared session; got block: {output!r}'
        assert output == {'paged': True, 'patient_id': 'p-shared'}
    finally:
        sess.close()

@pytest.mark.asyncio
async def test_protect_tools_session_param__protect_tool_different_sessions_isolate_state() -> None:
    """A classifier-populated ``classifier_score`` on session A MUST
    NOT leak to session B; notify_doctor on B must block."""
    shield = _protect_tools_session_param_build_shield_no_bundle()
    sess_a = shield.create_session(session_id='t4-A')
    sess_b = shield.create_session(session_id='t4-B')
    try:
        blocked_a, _ = await shield.protect_tool('classify_document', {'document': 'doc-A'}, _protect_tools_session_param_classify_factory(score=0.97), session=sess_a)
        assert blocked_a is False
        blocked_a2, _ = await shield.protect_tool('notify_doctor', {'patient_id': 'p-A'}, _protect_tools_session_param_notify_doctor, session=sess_a)
        assert blocked_a2 is False, 'notify_doctor on session A MUST pass after classify'
        blocked_b, output_b = await shield.protect_tool('notify_doctor', {'patient_id': 'p-B'}, _protect_tools_session_param_notify_doctor, session=sess_b)
        assert blocked_b is True, f'notify_doctor on session B (no classifier_score) MUST block; got: {output_b!r}'
        assert 'classifier_score' in str(output_b)
    finally:
        sess_a.close()
        sess_b.close()

@pytest.mark.asyncio
async def test_protect_tools_session_param__protect_tool_explicit_session_overrides_ambient(caplog: pytest.LogCaptureFixture) -> None:
    """When the ambient ``current_session`` is set AND a different
    explicit ``session=`` is passed, the explicit session wins and a
    debug-level log is emitted naming the tool."""
    shield = _protect_tools_session_param_build_shield_no_bundle()
    ambient_sess = shield.create_session(session_id='t5-ambient')
    explicit_sess = shield.create_session(session_id='t5-explicit')
    blocked_seed, _ = await shield.protect_tool('classify_document', {'document': 'seed'}, _protect_tools_session_param_classify_factory(score=0.95), session=explicit_sess)
    assert blocked_seed is False
    ambient_sess.begin_turn()
    tok = current_session.set(ambient_sess)
    try:
        caplog.set_level(logging.DEBUG, logger='agent_shield.shield')
        blocked, output = await shield.protect_tool('notify_doctor', {'patient_id': 'p-explicit'}, _protect_tools_session_param_notify_doctor, session=explicit_sess)
        assert blocked is False, f'Explicit session= MUST be honored over ambient; notify_doctor unexpectedly blocked: {output!r}'
        override_logs = [rec for rec in caplog.records if 'explicit session=' in rec.getMessage() and 'notify_doctor' in rec.getMessage()]
        assert override_logs, f"Expected a debug log on the agent_shield.shield logger naming 'notify_doctor' when explicit session diverges from ambient. Captured: {[r.getMessage() for r in caplog.records]}"
    finally:
        current_session.reset(tok)
        ambient_sess.end_turn()
        ambient_sess.close()
        explicit_sess.close()

@pytest.mark.asyncio
async def test_protect_tools_session_param__langgraph_3_node_flow_with_shared_session() -> None:
    """End-to-end coverage for the LangGraph customer scenario: one
    Session shared across multiple ``protect_tools`` wrappings (one
    wrapping per node), classifier_score populated by node 1
    persists to gate node 2's notify_doctor call, and a fresh session
    (graph run 2) starts cold."""
    shield = _protect_tools_session_param_build_shield()
    shared = shield.create_session(session_id='graph-run-1')
    try:
        [node1_classify] = shield.protect_tools([_protect_tools_session_param_make_autogen_classify_tool(score=0.92)], session=shared)
        node1_out = await _protect_tools_session_param_run_autogen(node1_classify, {'document': 'doc-001'})
        assert node1_out is not None
        [node2_notify] = shield.protect_tools([_protect_tools_session_param_make_autogen_notify_tool()], session=shared)
        node2_out = await _protect_tools_session_param_run_autogen(node2_notify, {'patient_id': 'p-007'})
        assert 'GUARDRAIL BLOCK' not in str(node2_out), f'notify_doctor unexpectedly blocked despite shared session: {node2_out!r}'
    finally:
        shared.close()
    fresh = shield.create_session(session_id='graph-run-2')
    try:
        [notify_fresh] = shield.protect_tools([_protect_tools_session_param_make_autogen_notify_tool()], session=fresh)
        raise_on_block = getattr(shield._bundle, 'tool_wrapper_raise_on_block', False)
        if raise_on_block:
            with pytest.raises(AgentShieldBlocked) as excinfo:
                await _protect_tools_session_param_run_autogen(notify_fresh, {'patient_id': 'p-008'})
            assert 'classifier_score' in str(excinfo.value)
        else:
            result = await _protect_tools_session_param_run_autogen(notify_fresh, {'patient_id': 'p-008'})
            assert 'classifier_score' in str(result), f'Node 3 on a fresh session MUST surface the classifier_score block; got: {result!r}'
    finally:
        fresh.close()

@pytest.mark.asyncio
async def test_protect_tools_session_param__create_session_returns_usable_session() -> None:
    shield = _protect_tools_session_param_build_shield_no_bundle()
    sess = shield.create_session(session_id='t7-create')
    try:
        assert isinstance(sess, Session)
        blocked, _ = await shield.protect_tool('classify_document', {'document': 'doc-create'}, _protect_tools_session_param_classify_factory(score=0.88), session=sess)
        assert blocked is False
    finally:
        sess.close()

@pytest.mark.asyncio
async def test_protect_tools_session_param__shield_session_context_manager_closes_on_exit() -> None:
    shield = _protect_tools_session_param_build_shield_no_bundle()
    with shield.session(session_id='t8-ctx') as sess:
        assert isinstance(sess, Session)
        blocked, _ = await shield.protect_tool('classify_document', {'document': 'doc-ctx'}, _protect_tools_session_param_classify_factory(score=0.91), session=sess)
        assert blocked is False
    assert getattr(sess, '_closed', False) is True, 'Session.__exit__ MUST close the session.'

@pytest.mark.asyncio
async def test_protect_tools_session_param__run_with_session_uses_provided_session() -> None:
    """``shield.run_with_session(sess, thunk)`` MUST run the thunk
    inside a turn on the provided session — verifiable by observing
    that ``current_session`` inside the thunk is the bound session."""
    shield = _protect_tools_session_param_build_shield_no_bundle()
    sess = shield.create_session(session_id='t9-run-with')
    captured: dict[str, Any] = {}
    try:

        async def _thunk() -> str:
            captured['ambient'] = current_session.get(None)
            return 'ok'
        result = await shield.run_with_session(sess, _thunk)
        assert result == 'ok'
        assert captured['ambient'] is sess, f'Thunk must see the explicit session as ambient current_session; got {captured["ambient"]!r}'
    finally:
        sess.close()

@pytest.mark.asyncio
async def test_protect_tools_session_param__run_with_session_rejects_none_session() -> None:
    shield = _protect_tools_session_param_build_shield_no_bundle()

    async def _thunk() -> None:
        return None
    with pytest.raises(TypeError):
        await shield.run_with_session(None, _thunk)
from agent_shield.adapters._orchestration import guarded_tool_sync
_tool_block_no_silent_bypass_REPO_ROOT = REPO_ROOT
_tool_block_no_silent_bypass_FIXTURE = str(_tool_block_no_silent_bypass_REPO_ROOT / 'sdk' / 'python' / 'tests' / 'fixtures_smoke' / 'crewai_session_isolation.guardrails.yaml')

def _tool_block_no_silent_bypass_build_runtime() -> Any:
    return RuntimeBuilder.from_yaml(_tool_block_no_silent_bypass_FIXTURE).build()
_tool_block_no_silent_bypass_ADAPTER_BUNDLES = [('autogen', 'agent_shield.adapters.autogen'), ('langchain', 'agent_shield.adapters.langchain'), ('openai_agents', 'agent_shield.adapters.openai_agents'), ('anthropic_agents', 'agent_shield.adapters.anthropic_agents'), ('crewai', 'agent_shield.adapters.crewai')]

@pytest.mark.parametrize('name,module_path', _tool_block_no_silent_bypass_ADAPTER_BUNDLES)
def test_tool_block_no_silent_bypass__bundle_has_tool_wrapper_raise_on_block(name: str, module_path: str) -> None:
    """Every Python framework bundle must opt-in to the raise-on-block
    contract — that's the SDK-level signal the orchestrator uses to
    pick the raise path inside
    :func:`_protect_tools_via_wrapper`.

    A regression that flips this flag to ``False`` re-introduces the
    silent-bypass class across all five adapters.
    """
    mod = pytest.importorskip(module_path)
    bundle = mod._BUNDLE
    assert getattr(bundle, 'tool_wrapper_raise_on_block', False) is True, f'adapter {name!r} bundle is missing ``tool_wrapper_raise_on_block=True`` — this re-opens the silent-bypass class fixed by regression probe.{{1,2,3,4}}.'

def test_tool_block_no_silent_bypass__guarded_tool_sync_signals_block_on_stage3() -> None:
    """The shared synchronous orchestrator
    :func:`agent_shield.adapters._orchestration.guarded_tool_sync`
    MUST return ``(blocked=True, block_message)`` on a Stage 3
    block. Every adapter's ``_protect_tools_via_wrapper`` path
    sits on top of this — when ``raise_on_block=True`` the wrapper
    raises :class:`AgentShieldBlocked` (see
    ``test_crewai_adapter.py::Test*`` for the end-to-end
    raise contract through CrewAI's ``_GuardedTool._run``).

    The regression fixture's Stage 3 ``editor_only_publish`` policy blocks
    ``publish_draft`` when ``caller_agent`` is unset. Calling the
    orchestrator without setting the variable leaves it unset →
    fail-closed → ``blocked=True``.

    This pins the SDK-boundary signal each adapter's wrapper
    inspects to decide whether to raise; a regression that flips
    ``blocked`` to ``False`` on a denied call would silently
    re-introduce the bypass class across every framework.
    """
    runtime = _tool_block_no_silent_bypass_build_runtime()
    session = runtime.new_session()
    session.begin_turn()
    try:
        token = current_session.set(session)
        try:
            blocked, output = guarded_tool_sync('publish_draft', {}, lambda **_: 'publish_draft-ran', session=session)
            assert blocked is True, "guarded_tool_sync must report blocked=True on a Stage 3 deny so adapter wrappers can raise / translate to the framework's tool-error channel."
            assert isinstance(output, str) and output, "guarded_tool_sync must surface a non-empty block message string in the tuple's second slot."
        finally:
            current_session.reset(token)
    finally:
        session.end_turn()

def test_tool_block_no_silent_bypass__openai_agents_tool_has_failure_error_function_none() -> None:
    """regression probe — verify the wrapped ``FunctionTool`` is built
    with ``failure_error_function=None`` so a raised
    :class:`AgentShieldBlocked` actually reaches ``Runner.run``
    instead of being formatted back to the LLM as a tool-error
    string by the OpenAI Agents SDK's default error formatter.

    This is a static surface check: instantiate the wrapper, hand
    it a minimal ``FunctionTool``-shaped duck, and verify the
    returned object's ``failure_error_function`` attribute is
    ``None`` (the only value that makes ``Runner.run`` re-raise).
    """
    pytest.importorskip('agents', exc_type=ImportError)
    mod = pytest.importorskip('agent_shield.adapters.openai_agents')
    from agent_shield.adapters._capabilities import ToolMetadata

    class _OAIDuck:
        strict_json_schema = True
    metadata = ToolMetadata(name='publish_draft', description='fake', params_schema={'type': 'object', 'properties': {}, 'additionalProperties': False}, extras={})

    async def _fake_guarded_invoke(params: dict, prefix: str) -> str:
        return 'ok'
    function_tool = mod._BUNDLE.tool_wrapper.wrap(_OAIDuck(), metadata, _fake_guarded_invoke)
    # openai-agents 0.16.x exposed `failure_error_function`; 0.17.x renamed
    # it to private `_failure_error_function` + a `_use_default_failure_error_function`
    # flag. The adapter handles both. Accept either name set to None.
    legacy = getattr(function_tool, 'failure_error_function', 'MISSING')
    modern = getattr(function_tool, '_failure_error_function', 'MISSING')
    assert legacy is None or modern is None, (
        f"expected failure_error_function (or _failure_error_function) to be None; "
        f"got legacy={legacy!r}, modern={modern!r}"
    )

def test_tool_block_no_silent_bypass__langchain_tool_translates_block_to_tool_exception() -> None:
    """regression probe — verify the LangChain wrapper translates
    :class:`AgentShieldBlocked` to
    ``langchain_core.tools.ToolException`` (the contract LangChain
    agent loops use to detect a tool error).

    Static surface check: build the wrapper directly with a fake
    ``guarded_invoke`` that raises ``AgentShieldBlocked``, then call
    the resulting ``StructuredTool.ainvoke({})`` and assert the
    exception type at the boundary is ``ToolException`` (not the
    raw ``AgentShieldBlocked``, and not a normal string return).
    """
    try:
        from langchain_core.tools import StructuredTool, ToolException  # noqa: F401
    except ImportError as e:
        pytest.skip(f'langchain_core.tools not importable: {e}')
    mod = pytest.importorskip('agent_shield.adapters.langchain')
    from agent_shield.adapters._capabilities import ToolMetadata
    from pydantic import BaseModel

    class _Args(BaseModel):
        pass

    metadata = ToolMetadata(name='publish_draft', description='fake', params_schema={}, extras={'args_schema': _Args})

    async def _raises_block(params: dict, prefix: str) -> str:
        raise AgentShieldBlocked('publish_draft', '[GUARDRAIL BLOCK] publish_draft denied by editor_only_publish')
    structured = mod._BUNDLE.tool_wrapper.wrap(object(), metadata, _raises_block)
    with pytest.raises(ToolException) as exc_info:
        asyncio.run(structured.ainvoke({}))
    assert 'publish_draft' in exc_info.value.args[0]
from typing import Callable, List, Optional
from agent_shield.adapters import CapabilityReport, FrameworkBundle, Shield, ShieldMode, UnguardedToolInvocation  # noqa: F811
from agent_shield.adapters._capabilities import AgentBoundary, GuardedInvoke, LlmCallerFactory, ToolMetadata, ToolWrapper
_unguarded_tool_invocation_REPO_ROOT = REPO_ROOT
_unguarded_tool_invocation_MINIMAL = str(_unguarded_tool_invocation_REPO_ROOT / 'tests' / 'fixtures' / 'smoke' / 'minimal.guardrails.yaml')

class _UnguardedToolInvocationFakeFrameworkTool:

    def __init__(self, name: str, return_value: Any='ok') -> None:
        self.name = name
        self.description = f'fake tool {name}'
        self.return_value = return_value
        self.calls: List[dict] = []

    async def __call__(self, **params: Any) -> Any:
        self.calls.append(dict(params))
        return self.return_value

class _UnguardedToolInvocationFakeToolWrapper(ToolWrapper):

    def extract(self, tool: Any) -> ToolMetadata:
        return ToolMetadata(name=tool.name, description=tool.description)

    async def invoke(self, original: Any, params: dict) -> Any:
        return await original(**params)

    def wrap(self, original: Any, metadata: ToolMetadata, guarded_invoke: GuardedInvoke) -> Any:

        async def _wrapped(**kwargs: Any) -> Any:
            return await guarded_invoke(kwargs, '')
        _wrapped.__wrapped__ = original
        _wrapped.name = metadata.name
        return _wrapped

class _UnguardedToolInvocationFakeAgentBoundary(AgentBoundary):

    async def run(self, agent: Any, input_text: str, **kwargs: Any) -> Any:
        return await agent.execute(input_text)

    def extract_output(self, result: Any) -> Optional[str]:
        return getattr(result, 'text', None)

    def apply_redaction(self, result: Any, redacted_text: str) -> Any:
        result.text = redacted_text
        return result

    def make_blocked(self, message: str) -> Any:
        return type('_Blocked', (), {'text': message})()

class _UnguardedToolInvocationFakeLlmCallerFactory(LlmCallerFactory):

    def make_caller(self, client: Any) -> Callable[[Optional[str], str], str]:

        def caller(_cid: Optional[str], _prompt: str) -> str:
            return ''
        return caller

def _unguarded_tool_invocation_make_fake_bundle() -> FrameworkBundle:
    return FrameworkBundle(name='_fake', llm_caller_factory=_UnguardedToolInvocationFakeLlmCallerFactory(), tool_wrapper=_UnguardedToolInvocationFakeToolWrapper(), agent_boundary=_UnguardedToolInvocationFakeAgentBoundary(), streaming_adapter=None, capabilities=CapabilityReport(framework='_fake'))

def _unguarded_tool_invocation_build_shield() -> Shield:
    builder = Shield.from_yaml(_unguarded_tool_invocation_MINIMAL, auto_bind=False)
    builder._bind_to_bundle(_unguarded_tool_invocation_make_fake_bundle())
    return builder.with_mode(ShieldMode.ENFORCE).build()

class TestUnguardedToolInvocationDefaultFailsClosed:
    """`shield.protect_tools([...])` + direct invocation → exception."""

    def test_raises_unguarded_tool_invocation_with_actionable_message(self):
        shield = _unguarded_tool_invocation_build_shield()
        tool = _UnguardedToolInvocationFakeFrameworkTool('issue_refund', return_value='refunded')
        wrapped, = shield.protect_tools([tool])

        async def _drive() -> Any:
            return await wrapped(order_id='1234', amount=50.0)
        with pytest.raises(UnguardedToolInvocation) as excinfo:
            asyncio.run(_drive())
        msg = str(excinfo.value)
        assert 'issue_refund' in msg
        assert 'shield.guard(agent)' in msg
        assert 'allow_unguarded=True' in msg
        assert tool.calls == []

    def test_exception_is_importable_from_top_level_package(self):
        import agent_shield
        assert agent_shield.UnguardedToolInvocation is UnguardedToolInvocation
        assert issubclass(UnguardedToolInvocation, RuntimeError)

class TestUnguardedToolInvocationAllowUnguardedOptIn:
    """`allow_unguarded=True` warns + creates fresh session + succeeds."""

    def test_warns_creates_fresh_session_and_runs_tool(self, caplog):
        shield = _unguarded_tool_invocation_build_shield()
        tool = _UnguardedToolInvocationFakeFrameworkTool('lookup_order', return_value='order#1234')
        wrapped, = shield.protect_tools([tool], allow_unguarded=True)

        async def _drive() -> Any:
            return await wrapped(order_id='1234')
        with caplog.at_level(logging.WARNING, logger='agent_shield'):
            out = asyncio.run(_drive())
        assert tool.calls == [{'order_id': '1234'}]
        assert 'order#1234' in str(out)
        warnings = [r for r in caplog.records if 'without ambient session' in r.getMessage()]
        assert len(warnings) == 1, [r.getMessage() for r in caplog.records]
        assert 'lookup_order' in warnings[0].getMessage()

class TestUnguardedToolInvocationAmbientSessionSucceeds:
    """`shield.run(fn)` sets ambient session; protect_tools call inside it works."""

    def test_inside_shield_run_no_warning_no_raise(self, caplog):
        shield = _unguarded_tool_invocation_build_shield()
        tool = _UnguardedToolInvocationFakeFrameworkTool('lookup_order', return_value='order#1234')
        wrapped, = shield.protect_tools([tool])

        async def _drive() -> Any:

            async def _agent_thunk() -> str:
                return str(await wrapped(order_id='1234'))
            return await shield.run(_agent_thunk)
        with caplog.at_level(logging.WARNING, logger='agent_shield'):
            out = asyncio.run(_drive())
        assert tool.calls == [{'order_id': '1234'}]
        assert 'order#1234' in str(out)
        warnings = [r for r in caplog.records if 'without ambient session' in r.getMessage()]
        assert warnings == [], [r.getMessage() for r in warnings]
