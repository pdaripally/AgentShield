"""Behavior tests consolidated into behavior/test_mcp_integration.py."""
from __future__ import annotations
from .._support.paths import LOCAL_FIXTURES, REPO_ROOT
import asyncio
from typing import Any
import pytest
_mcp_REPO_ROOT = REPO_ROOT
_mcp_GLOBAL_FIXTURES = _mcp_REPO_ROOT / 'tests' / 'fixtures'
_mcp_LOCAL_FIXTURES = LOCAL_FIXTURES
_mcp_MINIMAL = str(_mcp_GLOBAL_FIXTURES / 'smoke' / 'minimal.guardrails.yaml')
_mcp_TOOL_ARGS_REDACT = str(_mcp_LOCAL_FIXTURES / 'tool_args_redact.guardrails.yaml')

class TestMcpMCPModuleSurface:
    """Public API of :mod:`agent_shield.mcp`."""

    def test_imports(self):
        from agent_shield import mcp as mcp_module
        for name in ('MCPGuardrailBlocked', 'MCPShield', 'MCPShieldBuilder', 'protect_tool', 'protect_tool_output', 'shield_server'):
            assert hasattr(mcp_module, name), f'missing {name}'

    def test_capability_report_describes_mcp_profile(self):
        from agent_shield.adapters._capabilities import CoverageLevel
        from agent_shield.mcp import MCPShield
        shield = MCPShield.from_yaml(_mcp_MINIMAL).build()
        rep = shield.capabilities
        assert rep.framework == 'mcp'
        assert rep.input_validation == CoverageLevel.UNSUPPORTED
        assert rep.output_validation == CoverageLevel.UNSUPPORTED
        assert rep.streaming_output == CoverageLevel.UNSUPPORTED
        assert rep.tool_authorization == CoverageLevel.FULL
        assert rep.tool_execution_validation == CoverageLevel.FULL
        assert rep.tool_output_validation == CoverageLevel.FULL

class TestMcpMCPProtectTool:
    """`protect_tool` / `protect_tool_output` Stage 2/3/4 behaviour."""

    def test_protect_tool_blocks_unauthorized(self):
        from agent_shield.mcp import MCPShield, protect_tool
        shield = MCPShield.from_yaml(_mcp_MINIMAL).build()

        async def _drive() -> tuple[bool, dict, str | None]:
            with shield.runtime.new_session() as session:
                session.begin_turn()
                return await protect_tool(shield.runtime, 'echo', {'msg': 'hi'}, 'tc_block', session=session)
        allowed, _params, msg = asyncio.run(_drive())
        assert allowed is False
        assert msg is not None
        assert 'GUARDRAIL' in msg

    def test_protect_tool_allows_authorized(self):
        from agent_shield.mcp import MCPShield, protect_tool
        shield = MCPShield.from_yaml(_mcp_MINIMAL).build()

        async def _drive() -> tuple[bool, dict, str | None]:
            with shield.runtime.new_session() as session:
                session.begin_turn()
                session.set_variable('authorized', True)
                return await protect_tool(shield.runtime, 'echo', {'msg': 'hi'}, 'tc_allow', session=session)
        allowed, params, msg = asyncio.run(_drive())
        assert allowed is True
        assert msg is None
        assert params == {'msg': 'hi'}

    def test_protect_tool_requires_tool_call_id_section_16_0(self):
        """the behavior contract — public MCP surfaces MUST require a non-empty tool_call_id.

        Locks in the Section 16.0 invariant: a regression that loosens
        the runtime guard (e.g. accepts ``None`` or ``""``) would
        re-open the no-id call path the spec forbids.
        """
        from agent_shield.mcp import MCPShield, protect_tool, protect_tool_output
        shield = MCPShield.from_yaml(_mcp_MINIMAL).build()

        async def _drive_empty_call():
            return await protect_tool(shield.runtime, 'echo', {'msg': 'hi'}, '')

        async def _drive_empty_output():
            return await protect_tool_output(shield.runtime, 'echo', 'result', '')
        with pytest.raises(TypeError, match='tool_call_id'):
            asyncio.run(_drive_empty_call())
        with pytest.raises(TypeError, match='tool_call_id'):
            asyncio.run(_drive_empty_output())

    def test_protect_tool_returns_stage3_mutated_params(self):
        from agent_shield.mcp import MCPShield, protect_tool
        shield = MCPShield.from_yaml(_mcp_TOOL_ARGS_REDACT).build()

        async def _drive() -> tuple[bool, dict, str | None]:
            with shield.runtime.new_session() as session:
                session.begin_turn()
                return await protect_tool(shield.runtime, 'echo', {'msg': 'ssn is 123-45-6789'}, 'tc_redact', session=session)
        allowed, params, msg = asyncio.run(_drive())
        assert allowed is True
        assert '123-45-6789' not in params.get('msg', '')
        assert '[REDACTED]' in params.get('msg', '')

    def test_protect_tool_output_records_success_on_allow(self):
        from agent_shield.mcp import MCPShield, protect_tool, protect_tool_output
        shield = MCPShield.from_yaml(_mcp_MINIMAL).build()

        async def _drive() -> tuple[bool, str, str | None]:
            tool_call_id = 'tc_minimal'
            with shield.runtime.new_session() as session:
                session.begin_turn()
                session.set_variable('authorized', True)
                await protect_tool(shield.runtime, 'echo', {}, tool_call_id, session=session)
                return await protect_tool_output(shield.runtime, 'echo', 'result', tool_call_id, session=session, record=True)
        allowed, output, msg = asyncio.run(_drive())
        assert allowed is True
        assert output == 'result'
        assert msg is None

class TestMcpMCPProtectServer:
    """`shield_server` / `protect_server` integration via fakes."""

    def _make_fake_server(self):

        class _FakeTool:

            def __init__(self, name, fn):
                self.name = name
                self.fn = fn

        class _FakeToolManager:

            def __init__(self):
                self._tools = {}

        class _FakeServer:

            def __init__(self):
                self._tool_manager = _FakeToolManager()

            def add(self, name, fn):
                self._tool_manager._tools[name] = _FakeTool(name, fn)
        return _FakeServer()

    def test_shield_server_wraps_tools_in_place(self):
        from agent_shield.mcp import shield_server
        server = self._make_fake_server()
        original_called = []

        async def echo(msg: str='') -> str:
            original_called.append(msg)
            return f'echo: {msg}'
        server.add('echo', echo)
        original_fn = server._tool_manager._tools['echo'].fn
        shield = shield_server(server, _mcp_MINIMAL, on_block='raise')
        wrapped_fn = server._tool_manager._tools['echo'].fn
        assert wrapped_fn is not original_fn
        from agent_shield.adapters._orchestration import current_session

        async def _drive() -> str:
            with shield.runtime.new_session() as session:
                session.begin_turn()
                session.set_variable('authorized', True)
                tok = current_session.set(session)
                try:
                    return await wrapped_fn(msg='hi')
                finally:
                    current_session.reset(tok)
        out = asyncio.run(_drive())
        assert 'echo: hi' in out
        assert original_called == ['hi']

    def test_shield_server_blocks_unauthorized_via_raise(self):
        from agent_shield.mcp import MCPGuardrailBlocked, shield_server
        server = self._make_fake_server()

        async def echo(msg: str='') -> str:
            return f'echo: {msg}'
        server.add('echo', echo)
        shield = shield_server(server, _mcp_MINIMAL, on_block='raise')
        wrapped = server._tool_manager._tools['echo'].fn
        from agent_shield.adapters._orchestration import current_session

        async def _drive() -> Any:
            with shield.runtime.new_session() as session:
                session.begin_turn()
                tok = current_session.set(session)
                try:
                    return await wrapped(msg='hi')
                finally:
                    current_session.reset(tok)
        with pytest.raises(MCPGuardrailBlocked) as exc_info:
            asyncio.run(_drive())
        assert exc_info.value.tool_name == 'echo'

    def test_shield_server_blocks_unauthorized_via_return_message(self):
        from agent_shield.mcp import shield_server
        server = self._make_fake_server()

        async def echo(msg: str='') -> str:
            return f'echo: {msg}'
        server.add('echo', echo)
        shield = shield_server(server, _mcp_MINIMAL, on_block='return_message')
        wrapped = server._tool_manager._tools['echo'].fn
        from agent_shield.adapters._orchestration import current_session

        async def _drive() -> Any:
            with shield.runtime.new_session() as session:
                session.begin_turn()
                tok = current_session.set(session)
                try:
                    return await wrapped(msg='hi')
                finally:
                    current_session.reset(tok)
        out = asyncio.run(_drive())
        assert 'GUARDRAIL' in out

    def test_protect_tools_manual_pair_form(self):
        from agent_shield.mcp import MCPShield
        shield = MCPShield.from_yaml(_mcp_MINIMAL).build()

        async def echo(msg: str='') -> str:
            return f'echo: {msg}'
        wrapped = shield.protect_tools([('echo', echo)], on_block='return_message')
        assert len(wrapped) == 1
        name, fn = wrapped[0]
        assert name == 'echo'
        assert fn is not echo

    def test_unsupported_server_shape_errors(self):
        from agent_shield.mcp import MCPShield
        shield = MCPShield.from_yaml(_mcp_MINIMAL).build()

        class _BadServer:
            pass
        with pytest.raises(TypeError, match='tool registry'):
            shield.protect_server(_BadServer())

class TestMcpMCPBuilder:
    """Builder fluent API."""

    def test_with_observability(self):
        from agent_shield.mcp import MCPShield
        from agent_shield.observability import CapturingProvider
        cap = CapturingProvider()
        shield = MCPShield.from_yaml(_mcp_MINIMAL).with_observability(cap).build()
        with shield.runtime.new_session() as session:
            session.begin_turn()
            session.end_turn()
        assert len(cap.events) > 0

    def test_yaml_chain(self):
        from agent_shield.mcp import MCPShield
        shield = MCPShield.from_yaml([_mcp_MINIMAL]).build()
        assert shield.runtime is not None

class TestMcpMCPSessionScope:
    """Session-scope behaviour — connection (default) vs call."""

    def test_default_scope_is_call(self):
        from agent_shield.mcp import MCPShield
        shield = MCPShield.from_yaml(_mcp_MINIMAL).build()
        assert shield.session_scope == 'call'
        assert shield.session is None

    def test_connection_scope_state_spans_calls(self):
        """A variable set on the held session is visible to later calls."""
        import warnings
        from agent_shield.mcp import MCPShield
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', DeprecationWarning)
            shield = MCPShield.from_yaml(_mcp_MINIMAL).with_session_scope('connection').build()
        sess = shield.session
        assert sess is not None
        sess.begin_turn()
        sess.set_variable('authorized', True)

        async def _drive():
            r1 = await shield.protect_tool('echo', {'msg': 'first'}, 'tc_1')
            r2 = await shield.protect_tool('echo', {'msg': 'second'}, 'tc_2')
            return (r1, r2)
        r1, r2 = asyncio.run(_drive())
        assert r1[0] is True, r1[2]
        assert r2[0] is True, r2[2]

    def test_call_scope_does_not_share_state(self):
        from agent_shield.mcp import MCPShield
        shield = MCPShield.from_yaml(_mcp_MINIMAL).with_session_scope('call').build()
        assert shield.session_scope == 'call'
        assert shield.session is None

        async def _drive():
            return await shield.protect_tool('echo', {'msg': 'hi'}, 'tc_per_call')
        allowed, _, msg = asyncio.run(_drive())
        assert allowed is False
        assert msg is not None and 'GUARDRAIL' in msg

    def test_reset_session_drops_held_session(self):
        import warnings
        from agent_shield.mcp import MCPShield
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', DeprecationWarning)
            shield = MCPShield.from_yaml(_mcp_MINIMAL).with_session_scope('connection').build()
        sess1 = shield.session
        assert sess1 is not None
        shield.reset_session()
        assert shield._session is None
        sess2 = shield.session
        assert sess2 is not sess1

    def test_reset_session_noop_in_call_scope(self):
        from agent_shield.mcp import MCPShield
        shield = MCPShield.from_yaml(_mcp_MINIMAL).with_session_scope('call').build()
        shield.reset_session()
        assert shield.session is None
import json
_mcp_server_REPO_ROOT = REPO_ROOT
_mcp_server_GLOBAL_FIXTURES = _mcp_server_REPO_ROOT / 'tests' / 'fixtures'
_mcp_server_LOCAL_FIXTURES = LOCAL_FIXTURES
_mcp_server_MINIMAL = str(_mcp_server_GLOBAL_FIXTURES / 'smoke' / 'minimal.guardrails.yaml')
_mcp_server_APPROVAL = str(_mcp_server_LOCAL_FIXTURES / 'approval.guardrails.yaml')
_mcp_server_TOOL_ARGS_REDACT = str(_mcp_server_LOCAL_FIXTURES / 'tool_args_redact.guardrails.yaml')
_mcp_server_PENDING_RESOLUTION = str(_mcp_server_GLOBAL_FIXTURES / 'contract' / 'pending_resolution.guardrails.yaml')

def _mcp_server_make_fake_server():

    class _FakeTool:

        def __init__(self, name, fn):
            self.name = name
            self.fn = fn

    class _FakeToolManager:

        def __init__(self):
            self._tools = {}

    class _FakeServer:

        def __init__(self):
            self._tool_manager = _FakeToolManager()

        def add(self, name, fn):
            self._tool_manager._tools[name] = _FakeTool(name, fn)
    return _FakeServer()

class TestMcpServerNoAmbientSessionRequired:
    """``shield_server(...)`` must not require an outer
    ``shield.guard(agent)`` context to dispatch tool calls.

    Before the fix, ``MCPShield._wrap_callable`` delegated to
    ``guarded_tool(...)`` without a ``session=`` arg, so the
    ``_resolve_session`` helper raised
    :class:`UnguardedToolInvocation` whenever ``current_session`` was
    unset — i.e. on EVERY MCP call (MCP servers have no agent loop
    that would set the ambient ContextVar).
    """

    def test_wrapped_tool_runs_without_ambient_session(self):
        from agent_shield.mcp import shield_server
        server = _mcp_server_make_fake_server()
        seen = []

        async def echo(msg: str='') -> str:
            seen.append(msg)
            return f'echo: {msg}'
        server.add('echo', echo)
        import warnings as _warnings
        from agent_shield.mcp import MCPShield as _MCPShield
        with _warnings.catch_warnings():
            _warnings.simplefilter('ignore', DeprecationWarning)
            _shield = _MCPShield.from_yaml(_mcp_server_MINIMAL).with_session_scope('connection').build()
        shield = shield_server(server, _shield, on_block='raise')
        wrapped = server._tool_manager._tools['echo'].fn
        sess = shield.session
        assert sess is not None
        sess.set_variable('authorized', True)

        async def _drive():
            return await wrapped(msg='hi')
        out = asyncio.run(_drive())
        assert 'echo: hi' in out
        assert seen == ['hi']

    def test_per_turn_lifetime_resets_between_calls(self):
        """Each ``tools/call`` opens its own turn so ``per_turn``
        variables (set by Stage 3 / Stage 4) reset correctly.

        Verified by exercising two consecutive calls on the same
        wrapper — both must succeed and the second must observe a
        fresh per-turn slate (no leftover state from the first).
        """
        from agent_shield.mcp import shield_server
        server = _mcp_server_make_fake_server()

        async def echo(msg: str='') -> str:
            return f'echo: {msg}'
        server.add('echo', echo)
        import warnings as _warnings
        from agent_shield.mcp import MCPShield as _MCPShield
        with _warnings.catch_warnings():
            _warnings.simplefilter('ignore', DeprecationWarning)
            _shield = _MCPShield.from_yaml(_mcp_server_MINIMAL).with_session_scope('connection').build()
        shield = shield_server(server, _shield, on_block='raise')
        wrapped = server._tool_manager._tools['echo'].fn
        sess = shield.session
        assert sess is not None
        sess.set_variable('authorized', True)

        async def _drive():
            return [await wrapped(msg='first'), await wrapped(msg='second')]
        outs = asyncio.run(_drive())
        assert outs[0].endswith('first')
        assert outs[1].endswith('second')

    def test_call_scope_opens_fresh_session_per_call(self):
        """``session_scope='call'`` MUST also no longer require an
        ambient session — the wrapper opens its own per-call session
        and manages its turn boundary.
        """
        from agent_shield.mcp import MCPShield
        shield = MCPShield.from_yaml(_mcp_server_TOOL_ARGS_REDACT).with_session_scope('call').build()

        async def echo(msg: str='') -> str:
            return f'echo: {msg}'
        wrapped_pair = shield.protect_tools([('echo', echo)], on_block='raise')
        wrapped = wrapped_pair[0][1]

        async def _drive():
            return await wrapped(msg='ssn is 123-45-6789')
        out = asyncio.run(_drive())
        assert '[REDACTED]' in out
        assert '123-45-6789' not in out

    def test_ambient_session_still_preferred_when_set(self):
        """Back-compat: when an outer ``shield.guard(agent)`` context
        has pushed an ambient session, the wrapper MUST use it (the
        host owns the turn boundary).
        """
        from agent_shield.adapters._orchestration import current_session
        from agent_shield.mcp import shield_server
        server = _mcp_server_make_fake_server()

        async def echo(msg: str='') -> str:
            return f'echo: {msg}'
        server.add('echo', echo)
        shield = shield_server(server, _mcp_server_MINIMAL, on_block='raise')
        wrapped = server._tool_manager._tools['echo'].fn

        async def _drive():
            with shield.runtime.new_session() as ambient:
                ambient.begin_turn()
                ambient.set_variable('authorized', True)
                tok = current_session.set(ambient)
                try:
                    return await wrapped(msg='hi')
                finally:
                    current_session.reset(tok)
        out = asyncio.run(_drive())
        assert 'echo: hi' in out

class TestMcpServerBlockEnvelope:
    """Stage 2/3/4 blocks surface as a structured envelope a client
    can branch on without substring-matching the human-readable
    ``[GUARDRAIL ...]`` block string.

    FastMCP cannot emit a JSON-RPC ``error`` envelope from a tool
    handler — the lowlevel ``call_tool`` decorator catches every
    ``Exception`` and converts it to
    ``CallToolResult(isError=True, content=[TextContent])``. The
    structured-content envelope is therefore the tightest contract we
    can guarantee on the wire.
    """

    def test_default_on_block_is_error_envelope(self):
        from agent_shield.mcp import shield_server
        server = _mcp_server_make_fake_server()

        async def echo(msg: str='') -> str:
            return f'echo: {msg}'
        server.add('echo', echo)
        _ = shield_server(server, _mcp_server_MINIMAL)
        wrapped = server._tool_manager._tools['echo'].fn

        async def _drive():
            return await wrapped(msg='hi')
        result = asyncio.run(_drive())
        from mcp.types import CallToolResult, TextContent
        assert isinstance(result, CallToolResult), f'expected CallToolResult, got {type(result).__name__}'
        assert result.isError is True, 'isError flag MUST be set'
        sc = result.structuredContent
        assert sc is not None, 'structuredContent MUST carry the block payload'
        assert sc['shield'] == 'blocked'
        assert sc['tool'] == 'echo'
        assert sc['stage'] in ('stage_2_3', 'stage_4')
        assert 'message' in sc and 'GUARDRAIL' in sc['message']
        assert 'pending_resolution' in sc
        assert isinstance(result.content[0], TextContent)
        decoded = json.loads(result.content[0].text)
        assert decoded['shield'] == 'blocked'
        assert decoded['tool'] == 'echo'

    def test_error_envelope_serialisable_to_json(self):
        """The envelope must survive a JSON round-trip — MCP transports
        will serialise it onto the wire."""
        from agent_shield.mcp import shield_server
        server = _mcp_server_make_fake_server()

        async def echo(msg: str='') -> str:
            return f'echo: {msg}'
        server.add('echo', echo)
        _ = shield_server(server, _mcp_server_MINIMAL, on_block='error_envelope')
        wrapped = server._tool_manager._tools['echo'].fn

        async def _drive():
            return await wrapped(msg='hi')
        result = asyncio.run(_drive())
        dumped = result.model_dump(mode='json')
        assert dumped['isError'] is True
        assert dumped['structuredContent']['shield'] == 'blocked'
        assert dumped['content'][0]['type'] == 'text'
        json.loads(dumped['content'][0]['text'])

    def test_on_block_raise_preserves_legacy_shape(self):
        """``on_block='raise'`` keeps raising
        :class:`MCPGuardrailBlocked` for back-compat callers."""
        from agent_shield.mcp import MCPGuardrailBlocked, shield_server
        server = _mcp_server_make_fake_server()

        async def echo(msg: str='') -> str:
            return f'echo: {msg}'
        server.add('echo', echo)
        _ = shield_server(server, _mcp_server_MINIMAL, on_block='raise')
        wrapped = server._tool_manager._tools['echo'].fn

        async def _drive():
            return await wrapped(msg='hi')
        with pytest.raises(MCPGuardrailBlocked) as exc_info:
            asyncio.run(_drive())
        assert exc_info.value.tool_name == 'echo'
        assert exc_info.value.stage in ('stage_2_3', 'stage_4')
        assert hasattr(exc_info.value, 'pending_resolution')

class TestMcpServerStructuredOutputPreserved:
    """Direct mirror of regression for the MCP wrapper — structured tool
    returns (``list[dict]``, ``None``, Pydantic ``BaseModel``) survive
    Stage 4 with their Python shape intact (no ``str()`` coercion).
    """

    def _wrap_minimal(self, fn, tool_name='echo'):
        import warnings
        from agent_shield.mcp import MCPShield
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', DeprecationWarning)
            shield = MCPShield.from_yaml(_mcp_server_MINIMAL).with_session_scope('connection').build()
        sess = shield.session
        sess.set_variable('authorized', True)
        wrapped_pair = shield.protect_tools([(tool_name, fn)], on_block='raise')
        return (shield, wrapped_pair[0][1])

    def test_list_of_dicts_preserved(self):

        async def list_things(**_: Any) -> list[dict[str, Any]]:
            return [{'id': 1, 'title': 'first'}, {'id': 2, 'title': 'second'}]
        _shield, wrapped = self._wrap_minimal(list_things)

        async def _drive():
            return await wrapped()
        out = asyncio.run(_drive())
        assert isinstance(out, list), f'expected list, got {type(out).__name__}'
        assert len(out) == 2
        assert isinstance(out[0], dict)
        assert out[0]['id'] == 1
        assert out[0]['title'] == 'first'
        assert out[1]['title'] == 'second'

    def test_none_preserved(self):

        async def returns_none(**_: Any) -> None:
            return None
        _shield, wrapped = self._wrap_minimal(returns_none)

        async def _drive():
            return await wrapped()
        out = asyncio.run(_drive())
        assert out is None, f'expected None, got {out!r}'

    def test_pydantic_basemodel_round_trips(self):
        from pydantic import BaseModel

        class Result(BaseModel):
            id: int
            title: str

        async def make_result(**_: Any) -> Result:
            return Result(id=42, title='ok')
        _shield, wrapped = self._wrap_minimal(make_result)

        async def _drive():
            return await wrapped()
        out = asyncio.run(_drive())
        assert isinstance(out, Result), f'expected Result, got {type(out).__name__}: {out!r}'
        assert out.id == 42
        assert out.title == 'ok'

    def test_plain_string_unchanged(self):
        """Back-compat — plain string returns still flow through."""

        async def echo(msg: str='') -> str:
            return f'echo: {msg}'
        _shield, wrapped = self._wrap_minimal(echo)

        async def _drive():
            return await wrapped(msg='hi')
        out = asyncio.run(_drive())
        assert out == 'echo: hi'

    def test_dict_preserved(self):

        async def make_dict(**_: Any) -> dict[str, Any]:
            return {'status': 'ok', 'items': [1, 2, 3]}
        _shield, wrapped = self._wrap_minimal(make_dict)

        async def _drive():
            return await wrapped()
        out = asyncio.run(_drive())
        assert isinstance(out, dict)
        assert out['status'] == 'ok'
        assert out['items'] == [1, 2, 3]


class TestMcpServerPendingResolutionSurfacing:
    """Runtime-bound `kind: human` blocks fail closed without a
    pending_resolution envelope when no handler is registered."""

    def test_human_resolver_block_has_no_pending_envelope(self):
        from agent_shield.mcp import MCPShield, MCPGuardrailBlocked
        shield = MCPShield.from_yaml(_mcp_server_PENDING_RESOLUTION).build()

        async def send_email(**_: Any) -> str:
            return 'sent'
        wrapped = shield.protect_tools([('send_email', send_email)], on_block='raise')[0][1]

        with pytest.raises(MCPGuardrailBlocked) as exc_info:
            asyncio.run(wrapped(to='x@example.com', body='hi'))
        assert exc_info.value.pending_resolution is None
        assert shield.last_pending_resolution() is None

    def test_pending_resolution_sink_not_called_without_pending(self):
        from agent_shield.mcp import MCPShield, MCPGuardrailBlocked
        shield = MCPShield.from_yaml(_mcp_server_PENDING_RESOLUTION).build()
        sink_calls: list[dict] = []
        shield.pending_resolution_sink = lambda pr: sink_calls.append(pr)

        async def send_email(**_: Any) -> str:
            return 'sent'
        wrapped = shield.protect_tools([('send_email', send_email)], on_block='raise')[0][1]
        with pytest.raises(MCPGuardrailBlocked):
            asyncio.run(wrapped(to='x@example.com', body='hi'))
        assert sink_calls == []
        assert shield.last_pending_resolution() is None

    def test_error_envelope_has_null_pending_resolution(self):
        from agent_shield.mcp import MCPShield
        shield = MCPShield.from_yaml(_mcp_server_PENDING_RESOLUTION).build()

        async def send_email(**_: Any) -> str:
            return 'sent'
        wrapped = shield.protect_tools([('send_email', send_email)], on_block='error_envelope')[0][1]
        result = asyncio.run(wrapped(to='x@example.com', body='hi'))
        sc = result.structuredContent
        assert sc is not None
        assert sc.get('pending_resolution') is None


class TestMcpServerAPI_Surface:
    """Lock in the public API surface."""

    def test_mcp_shield_exposes_last_pending_resolution(self):
        from agent_shield.mcp import MCPShield
        assert hasattr(MCPShield, 'last_pending_resolution')

    def test_mcp_shield_exposes_pending_resolution_sink(self):
        from agent_shield.mcp import MCPShield
        shield = MCPShield.from_yaml(_mcp_server_MINIMAL).build()
        assert shield.pending_resolution_sink is None
        shield.pending_resolution_sink = lambda _pr: None
        assert callable(shield.pending_resolution_sink)
        shield.pending_resolution_sink = None
        assert shield.pending_resolution_sink is None

    def test_mcp_guardrail_blocked_carries_structured_fields(self):
        from agent_shield.mcp import MCPGuardrailBlocked
        exc = MCPGuardrailBlocked('x', '[GUARDRAIL BLOCK]', stage='stage_4', pending_resolution={'kind': 'human'})
        assert exc.tool_name == 'x'
        assert exc.message == '[GUARDRAIL BLOCK]'
        assert exc.stage == 'stage_4'
        assert exc.pending_resolution == {'kind': 'human'}

    def test_on_block_literal_includes_error_envelope(self):
        from agent_shield.mcp import OnBlock
        args = getattr(OnBlock, '__args__', None)
        if args is not None:
            assert 'error_envelope' in args
            assert 'raise' in args
            assert 'return_message' in args


_mcp_pending_resolution_REPO_ROOT = REPO_ROOT
_mcp_pending_resolution_GLOBAL_FIXTURES = _mcp_pending_resolution_REPO_ROOT / 'tests' / 'fixtures'
_mcp_pending_resolution_PENDING_RESOLUTION = str(_mcp_pending_resolution_GLOBAL_FIXTURES / 'contract' / 'pending_resolution.guardrails.yaml')


def _mcp_pending_resolution_build_shield():
    from agent_shield.mcp import MCPShield
    import warnings as _w
    with _w.catch_warnings():
        _w.simplefilter('ignore', DeprecationWarning)
        return MCPShield.from_yaml(_mcp_pending_resolution_PENDING_RESOLUTION).with_session_scope('connection').build()


async def _mcp_pending_resolution_send_email_ok(**_: Any) -> str:
    return 'sent'


class TestMcpPendingResolutionRuntimeBoundHuman:
    def test_repeated_peek_stays_null(self):
        from agent_shield.mcp import MCPGuardrailBlocked
        shield = _mcp_pending_resolution_build_shield()
        wrapped = shield.protect_tools([('send_email', _mcp_pending_resolution_send_email_ok)], on_block='raise')[0][1]
        with pytest.raises(MCPGuardrailBlocked):
            asyncio.run(wrapped(to='x@example.com', body='hi'))
        assert shield.last_pending_resolution() is None
        assert shield.last_pending_resolution() is None
        assert shield.last_pending_resolution() is None

    def test_successful_followup_after_manual_variable_write(self):
        from agent_shield.mcp import MCPGuardrailBlocked
        shield = _mcp_pending_resolution_build_shield()
        wrapped = shield.protect_tools([('send_email', _mcp_pending_resolution_send_email_ok)], on_block='raise')[0][1]

        async def _drive():
            with pytest.raises(MCPGuardrailBlocked):
                await wrapped(to='x@example.com', body='hi')
            assert shield.last_pending_resolution() is None
            shield.session.set_variable('send_email_approved', True)
            result = await wrapped(to='x@example.com', body='hi')
            return (result, shield.last_pending_resolution())
        result, post_peek = asyncio.run(_drive())
        assert result == 'sent'
        assert post_peek is None

    def test_resolve_pending_requires_latch_or_explicit_set_variables(self):
        shield = _mcp_pending_resolution_build_shield()
        with pytest.raises(RuntimeError, match='pending_resolution'):
            asyncio.run(shield.resolve_pending('allow'))

    def test_manual_variable_write_records_approval_value(self):
        shield = _mcp_pending_resolution_build_shield()
        shield.session.set_variable('send_email_approved', True)
        state = shield.session.read_variable('send_email_approved')
        assert state is not None
        assert state.value is True
