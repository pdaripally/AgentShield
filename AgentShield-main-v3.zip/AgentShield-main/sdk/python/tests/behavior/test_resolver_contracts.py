"""Behavior tests consolidated into behavior/test_resolver_contracts.py."""
from __future__ import annotations
from .._support.paths import REPO_ROOT
import os
import tempfile
from typing import Any, Dict, Iterator
import pytest
from agent_shield import AgentShieldResolverEnvelopeError, RuntimeBuilder
from agent_shield.runtime import _coerce_resolver_response

def test_resolver_envelope_validation__coerce_dict_allow_without_value_raises() -> None:
    """Fixture 1: ``allow`` without ``value`` MUST fail-closed."""
    with pytest.raises(AgentShieldResolverEnvelopeError) as excinfo:
        _coerce_resolver_response({'decision': 'allow'})
    msg = str(excinfo.value)
    assert 'value' in msg
    assert 'deny' in msg
    assert 'None' in msg or 'null' in msg

def test_resolver_envelope_validation__coerce_dict_allow_with_explicit_none_value_accepted() -> None:
    """Fixture 2: explicit ``value: None`` is the documented opt-in."""
    out = _coerce_resolver_response({'decision': 'allow', 'value': None})
    assert out == {'decision': 'allow', 'value': None}

def test_resolver_envelope_validation__coerce_dict_allow_with_value_accepted() -> None:
    """Fixture 3: a normal allow with a value is unaffected."""
    out = _coerce_resolver_response({'decision': 'allow', 'value': 42})
    assert out['decision'] == 'allow'
    assert out['value'] == 42

def test_resolver_envelope_validation__coerce_dict_deny_without_value_accepted() -> None:
    """Fixture 4: ``deny`` envelope does not require ``value`` — it does
    not write the variable, so the optionality is preserved."""
    out = _coerce_resolver_response({'decision': 'deny', 'reason': 'nope'})
    assert out['decision'] == 'deny'
    assert out.get('reason') == 'nope'

def test_resolver_envelope_validation__coerce_dict_cancelled_without_value_accepted() -> None:
    """``cancelled`` is the third terminal outcome and, like ``deny``,
    does not write a variable value (the behavior contracta). Don't gate it on the
    value field."""
    out = _coerce_resolver_response({'decision': 'cancelled', 'reason': 'user aborted'})
    assert out['decision'] == 'cancelled'

def test_resolver_envelope_validation__coerce_dataclass_unaffected() -> None:
    """The typed :class:`ResolverResponse` dataclass is the trusted API
    path. ``ResolverResponse(decision='allow')`` defaults ``value=None``
    and that's treated as explicit — the dataclass user has opted into
    the typed surface. regression's check fires only on the loose dict
    surface where the key can be silently dropped."""
    from agent_shield import ResolverResponse
    out = _coerce_resolver_response(ResolverResponse(decision='allow'))
    assert 'value' in out
    assert out['value'] is None
_resolver_envelope_validation_YAML = '\nmetadata:\n  name: "f55-2-resolver-envelope"\n  version: "0.1.0"\n  agent_shield_version: "2.0"\n\nobjective:\n  goal: ["test resolver envelope validation"]\n  forbidden: []\n\nresources:\n  tools:\n    - name: "do_thing"\n      description: "test tool"\n      permission: "execute"\n\nvariables:\n  - name: "authorized"\n    type: "boolean"\n    on_demand_by:\n      kind: "agent"\n      prompt: "Authorize the call?"\n    lifetime: "per_call"\n\nstate_validation:\n  guard_policies:\n    - name: "needs_authz"\n      applies_to:\n        tools: ["do_thing"]\n      evaluate_when:\n        - expression: "authorized == true"\n          reason: "must be authorized"\n      action: "block"\n'

@pytest.fixture
def _resolver_envelope_validation_yaml_path() -> Iterator[str]:
    with tempfile.NamedTemporaryFile('w', suffix='.guardrails.yaml', delete=False) as f:
        f.write(_resolver_envelope_validation_YAML)
        path = f.name
    try:
        yield path
    finally:
        os.unlink(path)

def test_resolver_envelope_validation__agent_resolver_dict_without_value_raises_at_callback_boundary(_resolver_envelope_validation_yaml_path: str) -> None:
    """A resolver callback that returns ``{decision: allow}`` (no value)
    must NOT silently pass the gate. The fail-closed check fires inside
    the SDK's callback wrapper before the bad envelope reaches the
    runtime — the FFI catches the Python exception, logs it at error
    severity, and the runtime converts it to a deny envelope so the
    gate is blocked.

    Previously the SDK silently normalized ``{decision: allow}`` to
    ``VariableState(value=None, status='resolved')`` and the gate
    PASSED. This test locks in the fail-closed contract: the gate MUST
    be blocked.

    Developers debugging a bad resolver see the
    ``AgentShieldResolverEnvelopeError`` either via:

      * unit-testing their callback against
        :func:`_coerce_resolver_response` (the exception bubbles up
        unchanged — see the unit tests above);
      * the SDK's error-level log line ``python agent resolver error:
        AgentShieldResolverEnvelopeError(...)``.
    """

    def bad_resolver(req: Dict[str, Any]) -> Dict[str, Any]:
        return {'decision': 'allow'}
    builder = RuntimeBuilder.from_yaml(_resolver_envelope_validation_yaml_path).register_agent_resolver(bad_resolver)
    runtime = builder.build()
    with runtime.new_session(session_id='s', correlation_id='c') as session:
        session.begin_turn()
        outcome = session.validate_tool_call('do_thing', {}, tool_call_id='c1')
        assert outcome.verdict.allowed is False, 'regression contract: a resolver returning {decision: allow} without a `value` field MUST NOT silently allow the gate. The previous behavior was to normalize to value=None and resolve the variable, letting the gate pass.'

def test_resolver_envelope_validation__agent_resolver_dict_with_value_none_passes_gate(_resolver_envelope_validation_yaml_path: str) -> None:
    """Explicit ``value: None`` is the documented opt-in for resolvers
    that legitimately resolve to null. Here we publish ``True`` via
    ``set_variables`` while keeping the variable's direct value as
    ``null`` — the gate must pass once the variable is resolved."""

    def explicit_null_then_set(req: Dict[str, Any]) -> Dict[str, Any]:
        return {'decision': 'allow', 'value': True, 'set_variables': {}}
    builder = RuntimeBuilder.from_yaml(_resolver_envelope_validation_yaml_path).register_agent_resolver(explicit_null_then_set)
    runtime = builder.build()
    with runtime.new_session(session_id='s', correlation_id='c') as session:
        session.begin_turn()
        outcome = session.validate_tool_call('do_thing', {}, tool_call_id='c1')
        assert outcome.verdict.allowed is True

def test_resolver_envelope_validation__agent_resolver_deny_without_value_blocks_gate(_resolver_envelope_validation_yaml_path: str) -> None:
    """Sanity check: ``deny`` envelopes without ``value`` are NOT
    caught by the regression check — denying is the explicit and correct
    way to reject without supplying a value."""

    def denier(req: Dict[str, Any]) -> Dict[str, Any]:
        return {'decision': 'deny', 'reason': 'policy denies'}
    builder = RuntimeBuilder.from_yaml(_resolver_envelope_validation_yaml_path).register_agent_resolver(denier)
    runtime = builder.build()
    with runtime.new_session(session_id='s', correlation_id='c') as session:
        session.begin_turn()
        outcome = session.validate_tool_call('do_thing', {}, tool_call_id='c1')
        assert outcome.verdict.allowed is False
from typing import List
from agent_shield import CapturingProvider, HumanResolveRequest, ResolverResponse
_register_human_resolver_APPROVAL_YAML = '\nmetadata:\n  name: "f55-5-human-resolver"\n  version: "0.1.0"\n  agent_shield_version: "2.0"\n\nobjective:\n  goal: ["only send email after a registered human callback approves"]\n  forbidden: []\n\nresources:\n  tools:\n    - name: "send_email"\n      description: "send email"\n      permission: "execute"\n\nvariables:\n  - name: "send_email_authorized"\n    type: "boolean"\n    on_demand_by:\n      kind: "human"\n      prompt: "Approve sending email to ${@tool.params.to}?"\n      timeout_ms: 60000\n    lifetime: "per_session"\n\nstate_validation:\n  guard_policies:\n    - name: "send_email_requires_approval"\n      applies_to:\n        tools: ["send_email"]\n      evaluate_when:\n        - expression: "send_email_authorized == true"\n          reason: "Sending email requires explicit user confirmation"\n      action: "block"\n'

@pytest.fixture
def _register_human_resolver_yaml_path() -> Iterator[str]:
    with tempfile.NamedTemporaryFile('w', suffix='.guardrails.yaml', delete=False) as f:
        f.write(_register_human_resolver_APPROVAL_YAML)
        path = f.name
    try:
        yield path
    finally:
        os.unlink(path)

def test_register_human_resolver__callback_approves_first_call_gate_passes(_register_human_resolver_yaml_path: str) -> None:
    """Approver callback returns ``decision: allow`` + ``value: True``;
    the gate MUST allow on the same call (synchronous dispatch — no
    pending-resolution suspension)."""
    observed_requests: List[HumanResolveRequest] = []

    def approver(req: HumanResolveRequest) -> ResolverResponse:
        observed_requests.append(req)
        return ResolverResponse(decision='allow', value=True)
    runtime = RuntimeBuilder.from_yaml(_register_human_resolver_yaml_path).register_human_resolver(approver).build()
    with runtime.new_session(session_id='s', correlation_id='c') as session:
        session.begin_turn()
        outcome = session.validate_tool_call('send_email', {'to': 'alice@example.com'}, tool_call_id='c1')
        assert outcome.verdict.allowed is True, 'synchronous approver returning allow should let the gate pass on the same call'
        assert outcome.verdict.pending_resolution is None
    assert len(observed_requests) == 1
    req = observed_requests[0]
    assert req.variable == 'send_email_authorized'
    assert req.prompt and 'alice@example.com' in req.prompt
    assert req.approval_nonce and len(req.approval_nonce) >= 8

def test_register_human_resolver__callback_denies_gate_blocks_with_reason(_register_human_resolver_yaml_path: str) -> None:
    """Denier callback returns ``decision: deny`` + reason; the gate
    MUST block and the reason MUST surface in the verdict."""

    def denier(req: HumanResolveRequest) -> ResolverResponse:
        return ResolverResponse(decision='deny', reason='user clicked Reject')
    runtime = RuntimeBuilder.from_yaml(_register_human_resolver_yaml_path).register_human_resolver(denier).build()
    with runtime.new_session(session_id='s', correlation_id='c') as session:
        session.begin_turn()
        outcome = session.validate_tool_call('send_email', {'to': 'alice@example.com'}, tool_call_id='c1')
        assert outcome.verdict.allowed is False

def test_register_human_resolver__callback_set_variables_mutations_propagate(_register_human_resolver_yaml_path: str) -> None:
    """A callback that returns ``set_variables`` MUST mutate the
    listed variables alongside the primary one. The mutation must
    survive the resolver dispatch (i.e. be visible on the next gate
    evaluation in the same session)."""
    yaml_with_secondary = _register_human_resolver_APPROVAL_YAML.replace('variables:', 'variables:\n  - name: "audit_recorded"\n    type: "boolean"\n    lifetime: "per_session"', 1)
    with tempfile.NamedTemporaryFile('w', suffix='.guardrails.yaml', delete=False) as f:
        f.write(yaml_with_secondary)
        path = f.name
    try:

        def approver_with_side_effects(req: HumanResolveRequest) -> ResolverResponse:
            return ResolverResponse(decision='allow', value=True, set_variables={'audit_recorded': True})
        runtime = RuntimeBuilder.from_yaml(path).register_human_resolver(approver_with_side_effects).build()
        with runtime.new_session(session_id='s', correlation_id='c') as session:
            session.begin_turn()
            outcome = session.validate_tool_call('send_email', {'to': 'alice@example.com'}, tool_call_id='c1')
            assert outcome.verdict.allowed is True
            state = session.read_variable('audit_recorded')
            assert state is not None
            assert state.value is True
    finally:
        os.unlink(path)

def test_register_human_resolver__callback_returns_dict_envelope_accepted(_register_human_resolver_yaml_path: str) -> None:
    """The callback contract accepts either a typed
    :class:`ResolverResponse` dataclass or a raw the behavior contract-shaped dict.
    Test the dict path to lock the bridge."""

    def dict_approver(req: HumanResolveRequest) -> Dict[str, Any]:
        return {'decision': 'allow', 'value': True}
    runtime = RuntimeBuilder.from_yaml(_register_human_resolver_yaml_path).register_human_resolver(dict_approver).build()
    with runtime.new_session(session_id='s', correlation_id='c') as session:
        session.begin_turn()
        outcome = session.validate_tool_call('send_email', {'to': 'alice@example.com'}, tool_call_id='c1')
        assert outcome.verdict.allowed is True

def test_register_human_resolver__callback_envelope_validation_applies(_register_human_resolver_yaml_path: str) -> None:
    """The regression fail-closed envelope contract applies uniformly across
    resolver kinds. A human resolver returning ``{decision: allow}``
    without ``value`` MUST fail-closed (gate blocked) rather than
    silently resolving the variable to ``null``."""

    def bad_resolver(req: HumanResolveRequest) -> Dict[str, Any]:
        return {'decision': 'allow'}
    runtime = RuntimeBuilder.from_yaml(_register_human_resolver_yaml_path).register_human_resolver(bad_resolver).build()
    with runtime.new_session(session_id='s', correlation_id='c') as session:
        session.begin_turn()
        outcome = session.validate_tool_call('send_email', {'to': 'alice@example.com'}, tool_call_id='c1')
        assert outcome.verdict.allowed is False, 'regression envelope validation must fire on the human resolver path too — a missing `value` on `decision: allow` MUST NOT let the gate pass silently.'

def test_register_human_resolver__missing_handler_fails_closed(_register_human_resolver_yaml_path: str) -> None:
    """If the host does not register a human resolver, the Rust core fail-closes the gate with a structured deny."""
    runtime = RuntimeBuilder.from_yaml(_register_human_resolver_yaml_path).build()
    with runtime.new_session(session_id='s', correlation_id='c') as session:
        session.begin_turn()
        outcome = session.validate_tool_call('send_email', {'to': 'alice@example.com'}, tool_call_id='c1')
        assert outcome.verdict.allowed is False

def test_register_human_resolver__approval_event_fires_on_terminal_outcome(_register_human_resolver_yaml_path: str) -> None:
    """Spec the behavior contract requires the runtime to emit
    ``approval.<variable>.<outcome>`` for the resolver chain's terminal
    outcome. The Python SDK doesn't directly observe this internal
    event (event-bus events drive guard-policy ``active_if`` /
    ``until_event:`` lifetimes and are not part of the public
    observability stream by default); instead, verify the observable
    consequence — the variable's status flips to ``resolved`` and
    ``@source_kind`` records the human channel."""

    def approver(req: HumanResolveRequest) -> ResolverResponse:
        return ResolverResponse(decision='allow', value=True)
    capture = CapturingProvider()
    runtime = RuntimeBuilder.from_yaml(_register_human_resolver_yaml_path).register_human_resolver(approver).register_observability_provider(capture).build()
    with runtime.new_session(session_id='s', correlation_id='c') as session:
        session.begin_turn()
        outcome = session.validate_tool_call('send_email', {'to': 'alice@example.com'}, tool_call_id='c1')
        assert outcome.verdict.allowed is True
        state = session.read_variable('send_email_authorized')
        assert state is not None
        assert state.status == 'resolved'
        assert state.value is True
        assert state.source_kind == 'human', f"variable source_kind should be 'human' after a human resolver fires; got {state.source_kind!r}"

class TestResolverEnvelopeStrictUnknownFieldsRejected:
    """The the behavior contract envelope is closed — unknown keys must fail closed."""

    def test_unknown_field_alongside_otherwise_valid_envelope_raises(self):
        """An otherwise-valid allow envelope
        with one extra ``extra_field_we_made_up`` key.
        Previously allowed silently; now fails closed."""
        with pytest.raises(AgentShieldResolverEnvelopeError) as excinfo:
            _coerce_resolver_response({'decision': 'allow', 'value': True, 'set_variables': {}, 'reason': 'ok', 'extra_field_we_made_up': 42})
        msg = str(excinfo.value)
        assert 'extra_field_we_made_up' in msg
        assert 'decision' in msg
        assert 'value' in msg
        assert 'set_variables' in msg
        assert 'reason' in msg

    def test_typo_close_to_decision_suggests_correction(self):
        """``descision`` (single-letter typo on ``decision``) should
        produce a "did you mean 'decision'?" hint — a common
        resolver typo."""
        with pytest.raises(AgentShieldResolverEnvelopeError) as excinfo:
            _coerce_resolver_response({'descision': 'allow', 'value': True})
        msg = str(excinfo.value)
        assert 'descision' in msg
        assert "did you mean 'decision'" in msg

    def test_multiple_unknown_fields_all_listed(self):
        """An envelope with two unknown keys must list BOTH so the
        author isn't left chasing one error at a time."""
        with pytest.raises(AgentShieldResolverEnvelopeError) as excinfo:
            _coerce_resolver_response({'decision': 'allow', 'value': True, 'foo': 1, 'bar': 2})
        msg = str(excinfo.value)
        assert 'foo' in msg
        assert 'bar' in msg

    def test_deny_envelope_with_unknown_field_also_rejected(self):
        """The strict-mode check applies regardless of decision —
        ``deny`` envelopes are not exempt (silent drop on a ``deny``
        path is just as misleading as on ``allow``)."""
        with pytest.raises(AgentShieldResolverEnvelopeError) as excinfo:
            _coerce_resolver_response({'decision': 'deny', 'reason': 'nope', 'audit_id': 'abc'})
        msg = str(excinfo.value)
        assert 'audit_id' in msg

    def test_cancelled_envelope_with_unknown_field_also_rejected(self):
        """``cancelled`` is the third terminal outcome — same rule."""
        with pytest.raises(AgentShieldResolverEnvelopeError) as excinfo:
            _coerce_resolver_response({'decision': 'cancelled', 'trace_id': 'xyz'})
        msg = str(excinfo.value)
        assert 'trace_id' in msg

class TestResolverEnvelopeStrictCanonicalEnvelopesUnaffected:
    """The four canonical fields — and only those — must continue to
    pass through unchanged. This is the regression check for the
    regression contract (envelope validation) so the strict-mode addition
    doesn't accidentally tighten the canonical surface."""

    def test_allow_with_value_only(self):
        out = _coerce_resolver_response({'decision': 'allow', 'value': 42})
        assert out['decision'] == 'allow'
        assert out['value'] == 42

    def test_allow_with_value_and_set_variables(self):
        out = _coerce_resolver_response({'decision': 'allow', 'value': True, 'set_variables': {'approved_by': 'alice'}})
        assert out['set_variables'] == {'approved_by': 'alice'}

    def test_allow_with_all_four_canonical_fields(self):
        out = _coerce_resolver_response({'decision': 'allow', 'value': 'ok', 'set_variables': {'k': 'v'}, 'reason': 'approved by reviewer'})
        assert out['decision'] == 'allow'
        assert out['value'] == 'ok'
        assert out['set_variables'] == {'k': 'v'}
        assert out['reason'] == 'approved by reviewer'

    def test_deny_canonical(self):
        out = _coerce_resolver_response({'decision': 'deny', 'reason': 'policy says no'})
        assert out['decision'] == 'deny'
        assert out['reason'] == 'policy says no'

    def test_cancelled_canonical(self):
        out = _coerce_resolver_response({'decision': 'cancelled', 'reason': 'user aborted'})
        assert out['decision'] == 'cancelled'

class TestResolverEnvelopeStrictDataclassPathUnaffected:
    """The :class:`ResolverResponse` typed dataclass is the trusted
    entry point — its ``to_dict()`` emits only the canonical fields, so
    the strict check is structurally unreachable. Pin the contract to
    avoid future drift where someone wires an arbitrary-attributes
    dataclass into the same coercer."""

    def test_typed_dataclass_allow_passes(self):
        from agent_shield import ResolverResponse
        out = _coerce_resolver_response(ResolverResponse(decision='allow'))
        assert out['decision'] == 'allow'
        assert out['value'] is None

    def test_typed_dataclass_with_set_variables_passes(self):
        from agent_shield import ResolverResponse
        out = _coerce_resolver_response(ResolverResponse(decision='allow', value=True, set_variables={'approved_by': 'alice'}, reason='ok'))
        assert out['set_variables'] == {'approved_by': 'alice'}
from agent_shield import DelegateDispatcher, DelegateRequest, ResolverRequest

def _resolver_request_fields_yaml_with_resolver(resolver_block: str) -> str:
    return f'\nmetadata:\n  name: "r85-3-resolver-fields"\n  version: "0.1.0"\n  agent_shield_version: "2.0"\n\nobjective:\n  goal: ["test that resolver request envelopes carry requested_key + resource"]\n  forbidden: []\n\nresources:\n  tools:\n    - name: "do_thing"\n      description: "tool gated on per-id authorization"\n      permission: "execute"\n\nvariables:\n  - name: "authorized"\n    type: "boolean"\n    key: "@tool.params.id"\n{resolver_block}\n\nstate_validation:\n  guard_policies:\n    - name: "needs_authz"\n      applies_to:\n        tools: ["do_thing"]\n      evaluate_when:\n        - expression: "authorized == true"\n          reason: "must be authorized"\n      action: "block"\n'

def _resolver_request_fields_write_yaml(text: str) -> str:
    with tempfile.NamedTemporaryFile('w', suffix='.guardrails.yaml', delete=False) as f:
        f.write(text)
        return f.name
_resolver_request_fields_AGENT_RESOLVER_BLOCK = '    on_demand_by:\n      kind: "agent"\n      prompt: "Authorize id=${@tool.params.id}?"\n    lifetime: "per_call"\n'

@pytest.fixture
def _resolver_request_fields_agent_yaml_path() -> Iterator[str]:
    path = _resolver_request_fields_write_yaml(_resolver_request_fields_yaml_with_resolver(_resolver_request_fields_AGENT_RESOLVER_BLOCK))
    try:
        yield path
    finally:
        os.unlink(path)

def test_resolver_request_fields__agent_resolver_request_carries_requested_key_and_resource(_resolver_request_fields_agent_yaml_path: str) -> None:
    """regression agent-resolver bridge: the Python callback MUST receive
    ``requested_key`` (the gating-site value of the variable's ``key:``
    expression) and the nested ``resource: {kind, name, params}``
    envelope with the tool invocation params."""
    captured: List[ResolverRequest] = []

    def approver(req: ResolverRequest) -> ResolverResponse:
        captured.append(req)
        return ResolverResponse(decision='allow', value=True)
    runtime = RuntimeBuilder.from_yaml(_resolver_request_fields_agent_yaml_path).register_agent_resolver(approver).build()
    with runtime.new_session(session_id='s', correlation_id='c') as session:
        session.begin_turn()
        outcome = session.validate_tool_call('do_thing', {'id': 'K42'}, tool_call_id='c1')
        assert outcome.verdict.allowed is True, f'approver returned allow — gate should pass; reason={outcome.verdict.reason!r}'
    assert len(captured) == 1
    req = captured[0]
    assert req.variable == 'authorized'
    assert req.requested_key == 'K42', f"agent resolver MUST receive requested_key='K42' for `key: '@tool.params.id'`; got {req.requested_key!r}"
    assert req.resource is not None, 'agent resolver MUST receive a nested `resource` envelope (behavior contract); got None'
    assert req.resource.get('kind') == 'tool'
    assert req.resource.get('name') == 'do_thing'
    assert req.resource.get('params', {}).get('id') == 'K42', 'nested resource.params MUST carry the tool invocation parameters; previously only the flat resource_kind / resource_name keys were forwarded'
    assert req.resource_kind == 'tool'
    assert req.resource_name == 'do_thing'
_resolver_request_fields_DELEGATE_RESOLVER_BLOCK = '    on_demand_by:\n      kind: "delegate"\n      configuration: "approval-service"\n      prompt: "Authorize id=${@tool.params.id}?"\n      lifetime: "per_turn"\n    lifetime: "per_call"\n'
_resolver_request_fields_DELEGATE_YAML = '\nmetadata:\n  name: "r85-3-delegate-fields"\n  version: "0.1.0"\n  agent_shield_version: "2.0"\n\nobjective:\n  goal: ["test that delegate requests carry requested_key + resource + lifetime"]\n  forbidden: []\n\nconfigurations:\n  - id: "approval-service"\n    type: "http_endpoint"\n    endpoint: "https://example.com/approval"\n    timeout: 5000\n\nresources:\n  tools:\n    - name: "do_thing"\n      description: "tool gated on per-id authorization"\n      permission: "execute"\n\nvariables:\n  - name: "authorized"\n    type: "boolean"\n    key: "@tool.params.id"\n' + _resolver_request_fields_DELEGATE_RESOLVER_BLOCK + '\nstate_validation:\n  guard_policies:\n    - name: "needs_authz"\n      applies_to:\n        tools: ["do_thing"]\n      evaluate_when:\n        - expression: "authorized == true"\n          reason: "must be authorized"\n      action: "block"\n'

@pytest.fixture
def _resolver_request_fields_delegate_yaml_path() -> Iterator[str]:
    path = _resolver_request_fields_write_yaml(_resolver_request_fields_DELEGATE_YAML)
    try:
        yield path
    finally:
        os.unlink(path)

def test_resolver_request_fields__delegate_dispatcher_request_carries_requested_key_resource_lifetime(_resolver_request_fields_delegate_yaml_path: str) -> None:
    """regression delegate-dispatcher bridge: the Python callback MUST
    receive ``requested_key`` (gating-site key), the nested ``resource``
    envelope with ``params``, and the resolver's declared
    ``lifetime:`` hint per behavior contract."""
    captured: List[DelegateRequest] = []

    class CapturingDispatcher(DelegateDispatcher):

        def dispatch(self, request: DelegateRequest) -> ResolverResponse:
            captured.append(request)
            return ResolverResponse(decision='allow', value=True)
    runtime = RuntimeBuilder.from_yaml(_resolver_request_fields_delegate_yaml_path).register_delegate_dispatcher(CapturingDispatcher()).build()
    with runtime.new_session(session_id='s', correlation_id='c') as session:
        session.begin_turn()
        outcome = session.validate_tool_call('do_thing', {'id': 'K42'}, tool_call_id='c1')
        assert outcome.verdict.allowed is True, f'dispatcher returned allow — gate should pass; reason={outcome.verdict.reason!r}'
    assert len(captured) == 1
    req = captured[0]
    assert req.variable == 'authorized'
    assert req.requested_key == 'K42', f"delegate dispatcher MUST receive requested_key='K42'; got {req.requested_key!r}"
    assert req.resource is not None, 'delegate dispatcher MUST receive a nested `resource` envelope'
    assert req.resource.get('kind') == 'tool'
    assert req.resource.get('name') == 'do_thing'
    assert req.resource.get('params', {}).get('id') == 'K42'
    assert req.lifetime == 'per_turn', f"delegate dispatcher MUST receive the resolver's lifetime hint ('per_turn'); got {req.lifetime!r}"
    assert req.configuration.get('id') == 'approval-service'
    assert req.configuration.get('type') == 'http_endpoint'
_resolver_request_fields_HUMAN_RESOLVER_BLOCK = '    on_demand_by:\n      kind: "human"\n      prompt: "Authorize id=${@tool.params.id}?"\n      timeout_ms: 60000\n    lifetime: "per_call"\n'

@pytest.fixture
def _resolver_request_fields_human_yaml_path() -> Iterator[str]:
    path = _resolver_request_fields_write_yaml(_resolver_request_fields_yaml_with_resolver(_resolver_request_fields_HUMAN_RESOLVER_BLOCK))
    try:
        yield path
    finally:
        os.unlink(path)

def test_resolver_request_fields__human_resolver_request_carries_resource_envelope(_resolver_request_fields_human_yaml_path: str) -> None:
    """regression human-resolver bridge: ``requested_key`` was already
    surfaced previously (locked in by the human dataclass since
    regression); this test additionally locks in the nested ``resource``
    envelope so all three resolver kinds expose the same spec shape."""
    captured: List[HumanResolveRequest] = []

    def approver(req: HumanResolveRequest) -> ResolverResponse:
        captured.append(req)
        return ResolverResponse(decision='allow', value=True)
    runtime = RuntimeBuilder.from_yaml(_resolver_request_fields_human_yaml_path).register_human_resolver(approver).build()
    with runtime.new_session(session_id='s', correlation_id='c') as session:
        session.begin_turn()
        outcome = session.validate_tool_call('do_thing', {'id': 'K42'}, tool_call_id='c1')
        assert outcome.verdict.allowed is True, f'approver returned allow — gate should pass; reason={outcome.verdict.reason!r}'
    assert len(captured) == 1
    req = captured[0]
    assert req.variable == 'authorized'
    assert req.requested_key == 'K42'
    assert req.resource is not None, 'human resolver MUST receive a nested `resource` envelope; previously the dataclass only declared the flat keys'
    assert req.resource.get('kind') == 'tool'
    assert req.resource.get('name') == 'do_thing'
    assert req.resource.get('params', {}).get('id') == 'K42'
_source_params_YAML = '\nmetadata:\n  name: r86-3-source-params\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["read account"]\n  forbidden: ["none"]\nresources:\n  tools:\n    - name: read_account\n      description: returns the customer record for a given account id\n      permission: read_only\nvariables:\n  - name: customer\n    type: object\n    populated_by:\n      - kind: tool\n        name: read_account\n        phase: after\n        expression: "@result"\n'

def test_source_params__read_variable_surfaces_source_params() -> None:
    rt = RuntimeBuilder.from_yaml_strings([_source_params_YAML]).build()
    with rt.new_session(session_id='s-r86-3', correlation_id='c-r86-3') as session:
        session.begin_turn()
        params = {'account_id': 'ACC-1001', 'authenticated': True}
        gate = session.validate_tool_call('read_account', params, tool_call_id='call-1')
        assert gate.verdict.allowed, f'Stage 3 must admit read_account; got {gate.verdict!r}'
        assert gate.admission_id is not None, 'Stage 4 requires the Stage-3 admission handle'
        result = {'customer_id': 'ACC-1001'}
        out = session.validate_tool_output(gate.admission_id, result)
        assert out.verdict.allowed, f'Stage 4 must allow the benign tool result; got {out.verdict!r}'
        state = session.read_variable('customer')
    assert state is not None, 'populator must commit `customer`'
    assert state.status == 'resolved', f'populator should leave `customer` resolved; got status={state.status!r}'
    assert state.source_kind == 'populator', f'@source_kind must record the populator writer; got {state.source_kind!r}'
    assert state.source_params is not None, 'regression: read_variable dropped @source_params. The behavior contract requires the resource-bound parameter snapshot to be surfaced alongside source_kind / set_by so hosts can inspect which invocation produced the variable value.'
    assert state.source_params == params, f'@source_params must mirror the invocation params verbatim; got {state.source_params!r}, expected {params!r}'
from agent_shield import AgentShieldConfigError, Shield

def _approval_event_error_friendlier_write_yaml(body: str) -> str:
    with tempfile.NamedTemporaryFile('w', suffix='.guardrails.yaml', delete=False) as f:
        f.write(body)
        return f.name

def _approval_event_error_friendlier_yaml_with_until_event(evt: str) -> str:
    # The canonical-shape variant references `approval.cfo.allow`. The
    # `approval.<name>` event namespace requires `<name>` to be a declared
    # variable (loader rejects with UnknownEventResourceName otherwise — see
    # spec). The malformed-suffix variants (`approval.cfo_approved`,
    # `approval.cfo.approved`) are rejected at an earlier suffix-validation
    # step before the declared-name check fires, so the extra `cfo` declaration
    # is inert for those cases. Declaring `cfo` unconditionally keeps the
    # fixture single-string and lets the canonical-shape case load cleanly.
    return f'metadata:\n  name: t\n  version: 0.1.0\n  agent_shield_version: "2.0"\n\nvariables:\n  - name: v\n    type: boolean\n    lifetime:\n      until_event: {evt}\n  - name: cfo\n    type: string\n\nresources:\n  tools:\n    - name: tt\n      permission: execute\n\nstate_validation:\n  guard_policies:\n    - name: b\n      applies_to:\n        tools: [tt]\n      action: block\n'

def test_approval_event_error_friendlier__malformed_approval_event_suggests_allow_deny_cancelled() -> None:
    """``approval.cfo_approved`` (missing suffix) — error must
    suggest ``approval.cfo_approved.allow|deny|cancelled``."""
    path = _approval_event_error_friendlier_write_yaml(_approval_event_error_friendlier_yaml_with_until_event('approval.cfo_approved'))
    try:
        with pytest.raises(AgentShieldConfigError) as exc_info:
            Shield.from_yaml(path, auto_bind=False).build()
    finally:
        os.unlink(path)
    msg = str(exc_info.value)
    assert 'approval.cfo_approved' in msg
    assert 'allow' in msg
    assert 'deny' in msg
    assert 'cancelled' in msg
    assert 'approval.cfo_approved.allow' in msg

def test_approval_event_error_friendlier__invalid_approval_suffix_suggests_canonical_suffixes() -> None:
    """``approval.cfo.approved`` (typo on the suffix) — error must
    suggest the canonical ``approval.cfo.allow|deny|cancelled``."""
    path = _approval_event_error_friendlier_write_yaml(_approval_event_error_friendlier_yaml_with_until_event('approval.cfo.approved'))
    try:
        with pytest.raises(AgentShieldConfigError) as exc_info:
            Shield.from_yaml(path, auto_bind=False).build()
    finally:
        os.unlink(path)
    msg = str(exc_info.value)
    assert 'approval.cfo.approved' in msg
    assert 'approval.cfo.allow' in msg
    assert 'approval.cfo.deny' in msg
    assert 'approval.cfo.cancelled' in msg

def test_approval_event_error_friendlier__canonical_approval_shape_loads_successfully() -> None:
    """The accepted shape ``approval.<name>.allow`` must continue to
    load without warning or error."""
    path = _approval_event_error_friendlier_write_yaml(_approval_event_error_friendlier_yaml_with_until_event('approval.cfo.allow'))
    try:
        shield = Shield.from_yaml(path, auto_bind=False).build()
    finally:
        os.unlink(path)
    assert shield is not None

def test_approval_event_error_friendlier__non_approval_loader_error_is_unchanged() -> None:
    """Non-``approval.*`` loader errors must NOT be rephrased — the
    enrichment is scoped to the approval namespace."""
    bad_yaml = 'metadata:\n  name: t\n  version: 0.1.0\n  agent_shield_version: "2.0"\n\nvariables:\n  - name: v\n    type: boolean\n    lifetime:\n      until_event: tool.unknown_tool.completed\n\nresources:\n  tools:\n    - name: tt\n      permission: execute\n\nstate_validation:\n  guard_policies:\n    - name: b\n      applies_to:\n        tools: [tt]\n      action: block\n'
    path = _approval_event_error_friendlier_write_yaml(bad_yaml)
    try:
        with pytest.raises(AgentShieldConfigError) as exc_info:
            Shield.from_yaml(path, auto_bind=False).build()
    finally:
        os.unlink(path)
    msg = str(exc_info.value)
    assert 'approval.cfo.allow' not in msg
    assert 'the only valid suffixes are' not in msg

def test_approval_event_error_friendlier__example_autogen_yaml_loads_successfully() -> None:
    """The autogen quickstart example YAML must continue to load —
    regression docs touch-up must not break the example."""
    repo_root = REPO_ROOT
    example = repo_root / 'examples' / 'autogen_team_quickstart_azure.guardrails.yaml'
    if not example.exists():
        pytest.skip(f'example YAML not found at {example}')
    shield = Shield.from_yaml(str(example), auto_bind=False).build()
    assert shield is not None
