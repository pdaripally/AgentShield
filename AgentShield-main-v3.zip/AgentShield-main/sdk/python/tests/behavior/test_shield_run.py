"""Behavior tests consolidated into behavior/test_shield_run.py."""
from __future__ import annotations
from .._support.paths import REPO_ROOT
import asyncio
import pytest
from agent_shield import RuntimeBuilder
from agent_shield.adapters._shield import Shield
_shield_run_REPO_ROOT = REPO_ROOT
_shield_run_HUMAN_FIXTURE = _shield_run_REPO_ROOT / 'tests' / 'fixtures' / 'contract' / 'pending_resolution.guardrails.yaml'
_shield_run_STAGE1_REDACT_YAML = '\nmetadata:\n  name: stage1-redact\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["test"]\ninput_validation:\n  guard_policies:\n    - name: strip_ssn\n      evaluate_when:\n        - patterns:\n            - "SSN \\\\d{3}-\\\\d{2}-\\\\d{4}"\n          reason: "Strip SSNs from user input"\n      action: "redact"\n      replacement: "[REDACTED-SSN]"\n'

def _shield_run_human_shield() -> Shield:
    runtime = RuntimeBuilder.from_yaml(str(_shield_run_HUMAN_FIXTURE)).build()
    return Shield(runtime)

def _shield_run_redact_shield() -> Shield:
    runtime = RuntimeBuilder.from_yaml_strings([_shield_run_STAGE1_REDACT_YAML]).build()
    return Shield(runtime)

def _shield_run_assert_no_pending(pending) -> None:
    assert pending is None

class TestShieldRunProtectToolSingularLatch:
    """The singular ``Shield.protect_tool`` path blocks fail-closed for
    ``kind: human`` when no runtime handler is registered."""

    def test_protect_tool_singular_has_no_pending_resolution(self) -> None:
        shield = _shield_run_human_shield()

        async def _execute(params: dict):
            raise AssertionError('underlying tool MUST NOT execute on a Stage 3 kind: human block')
        blocked, output = asyncio.run(shield.protect_tool('send_email', {'to': 'alice@example.com', 'subject': 'Hi'}, _execute))
        assert blocked is True, 'Stage 3 kind: human gate must block'
        assert isinstance(output, str) and 'GUARDRAIL' in output, 'block message returned to the caller is the canonical [GUARDRAIL ...] string'
        pending = shield.last_pending_resolution()
        _shield_run_assert_no_pending(pending)

    def test_protect_tool_singular_last_pending_stays_null(self) -> None:
        shield = _shield_run_human_shield()

        async def _execute(params: dict):
            raise AssertionError('tool must not run on block')
        asyncio.run(shield.protect_tool('send_email', {'to': 'alice@example.com'}, _execute))
        assert shield.last_pending_resolution() is None
        assert shield.last_pending_resolution() is None


class TestShieldRunProtectToolsBundleLatch:
    """The plural ``Shield.protect_tools`` bundle path also leaves
    ``last_pending_resolution`` null for fail-closed human blocks."""

    def test_protect_tools_bundle_has_no_pending_resolution(self) -> None:
        try:
            from langchain_core.tools import StructuredTool
        except Exception as exc:
            pytest.skip(f'langchain adapter unavailable: {exc}')
        shield = Shield.from_yaml(str(_shield_run_HUMAN_FIXTURE), auto_bind=False).with_langchain().build()

        def _execute(**kwargs):
            raise AssertionError('tool must not run on Stage 3 block')
        original = StructuredTool.from_function(func=_execute, name='send_email', description='Send email')
        protected = shield.protect_tools([original])[0]
        from agent_shield.adapters._orchestration import current_session
        runtime = shield.runtime
        sess = runtime.new_session()
        sess.begin_turn()
        try:
            token = current_session.set(sess)
            try:
                with pytest.raises(Exception):
                    if hasattr(protected, 'ainvoke'):
                        asyncio.run(protected.ainvoke({'to': 'alice@example.com', 'subject': 'Hi'}))
                    elif hasattr(protected, 'invoke'):
                        protected.invoke({'to': 'alice@example.com', 'subject': 'Hi'})
                    else:
                        protected.run({'to': 'alice@example.com', 'subject': 'Hi'})
            finally:
                current_session.reset(token)
        finally:
            sess.end_turn()
        pending = shield.last_pending_resolution()
        _shield_run_assert_no_pending(pending)

class TestShieldRunResetOnNextTurn:
    """Human fail-closed blocks must not leave stale pending state that
    survives into the next ``Shield.run`` turn."""

    def test_no_pending_state_on_next_run_turn(self) -> None:
        shield = _shield_run_human_shield()

        async def _exec_block(params: dict):
            raise AssertionError('must not run')
        asyncio.run(shield.protect_tool('send_email', {'to': 'alice@example.com'}, _exec_block))
        assert shield._last_pending_resolution is None

        async def _thunk():
            return 'ok'
        result = asyncio.run(shield.run(_thunk, user_input='hello'))
        assert result == 'ok'
        assert shield.last_pending_resolution() is None

class TestShieldRunThunkReceivesEffectiveInput:
    """One-arg thunks receive the Stage 1 effective text; zero-arg
    thunks are untouched."""

    def test_one_arg_thunk_receives_redacted_text(self) -> None:
        shield = _shield_run_redact_shield()
        captured: dict = {}

        async def _thunk(effective: str) -> str:
            captured['arg'] = effective
            return effective
        result = asyncio.run(shield.run(_thunk, user_input='SSN 123-45-6789 please look up'))
        assert 'arg' in captured, 'one-arg thunk MUST be called with the input'
        assert '123-45-6789' not in captured['arg'], 'the redacted Stage 1 form MUST be passed to the thunk; the un-redacted prompt would defeat input_validation'
        assert '[REDACTED-SSN]' in captured['arg'], "expected the policy's replacement token in the effective input"
        assert isinstance(result, str)

    def test_zero_arg_thunk_still_works(self) -> None:
        shield = _shield_run_redact_shield()

        async def _thunk() -> str:
            return 'ok'
        result = asyncio.run(shield.run(_thunk, user_input='hello'))
        assert result == 'ok'

    def test_sync_one_arg_thunk(self) -> None:
        """Sync callables are supported too — ``inspect.isawaitable``
        keys the await path."""
        shield = _shield_run_redact_shield()
        captured: dict = {}

        def _thunk(effective: str) -> str:
            captured['arg'] = effective
            return effective
        asyncio.run(shield.run(_thunk, user_input='SSN 999-00-1234 hi'))
        assert '999-00-1234' not in captured['arg']

class TestShieldRunCurrentEffectiveInputAccessor:
    """The public :meth:`Shield.current_effective_input` accessor is
    the documented escape hatch for Pattern-C closures that have
    already captured the original prompt."""

    def test_accessor_inside_thunk_returns_redacted_input(self) -> None:
        shield = _shield_run_redact_shield()
        captured: dict = {}

        async def _thunk() -> str:
            captured['effective'] = shield.current_effective_input()
            return 'ok'
        asyncio.run(shield.run(_thunk, user_input='SSN 111-22-3333 please'))
        assert '111-22-3333' not in captured['effective'], 'current_effective_input MUST return the redacted form'
        assert '[REDACTED-SSN]' in captured['effective']

    def test_accessor_outside_turn_returns_empty_string(self) -> None:
        """Calling the accessor outside any ``Shield.run`` returns
        ``""`` (NOT None) so customer code can call
        ``shield.current_effective_input() or fallback`` without a
        ``TypeError`` on string concat."""
        shield = _shield_run_redact_shield()
        assert shield.current_effective_input() == ''

    def test_accessor_returns_same_value_as_thunk_arg(self) -> None:
        """The accessor and the one-arg thunk parameter MUST agree —
        they are two reads of the same per-turn ContextVar."""
        shield = _shield_run_redact_shield()
        captured: dict = {}

        async def _thunk(effective: str) -> str:
            captured['arg'] = effective
            captured['accessor'] = shield.current_effective_input()
            return effective
        asyncio.run(shield.run(_thunk, user_input='SSN 444-55-6666 oops'))
        assert captured['arg'] == captured['accessor'], 'thunk arg and current_effective_input() MUST agree byte-for-byte'

class TestShieldRunRunWithSessionDelegates:
    """``run_with_session`` is a thin wrapper around ``run`` — both
    regression behaviours (thunk-arg threading + accessor) must hold."""

    def test_run_with_session_threads_effective_input(self) -> None:
        shield = _shield_run_redact_shield()
        sess = shield.create_session()
        captured: dict = {}

        async def _thunk(effective: str) -> str:
            captured['arg'] = effective
            captured['accessor'] = shield.current_effective_input()
            return 'ok'
        asyncio.run(shield.run_with_session(sess, _thunk, user_input='SSN 777-88-9999 thanks'))
        assert '777-88-9999' not in captured['arg']
        assert captured['arg'] == captured['accessor']
from agent_shield.adapters._shield import AgentShieldBlocked
_shield_run_default_block_STAGE1_BLOCK_YAML = '\nmetadata:\n  name: stage1-block\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["test"]\ninput_validation:\n  guard_policies:\n    - name: block_ssn\n      evaluate_when:\n        - patterns:\n            - "SSN \\\\d{3}-\\\\d{2}-\\\\d{4}"\n          reason: "SSNs are blocked at Stage 1 for this test"\n      action: "block"\n'
_shield_run_default_block_STAGE5_BLOCK_YAML = '\nmetadata:\n  name: stage5-block\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["test"]\noutput_validation:\n  guard_policies:\n    - name: block_topsecret\n      evaluate_when:\n        - patterns:\n            - "TOPSECRET-[A-Z0-9]+"\n          reason: "TOPSECRET tokens must not appear in output"\n      action: "block"\n'

def _shield_run_default_block_shield(yaml: str) -> Shield:
    runtime = RuntimeBuilder.from_yaml_strings([yaml]).build()
    return Shield(runtime)

class TestShieldRunDefaultBlockDefaultRaise:
    """The new default flipped from ``return_blocked`` to ``raise``."""

    def test_stage1_block_raises_by_default(self) -> None:
        shield = _shield_run_default_block_shield(_shield_run_default_block_STAGE1_BLOCK_YAML)

        async def _thunk() -> str:
            raise AssertionError('thunk MUST NOT run when Stage 1 blocks the user input')
        with pytest.raises(AgentShieldBlocked) as excinfo:
            asyncio.run(shield.run(_thunk, user_input='SSN 123-45-6789 hi'))
        msg = str(excinfo.value)
        assert '[GUARDRAIL' in msg, f'AgentShieldBlocked message MUST be the canonical block string; got: {msg!r}'

    def test_stage5_block_raises_by_default(self) -> None:
        shield = _shield_run_default_block_shield(_shield_run_default_block_STAGE5_BLOCK_YAML)

        async def _thunk() -> str:
            return 'here is the TOPSECRET-ABCD token'
        with pytest.raises(AgentShieldBlocked) as excinfo:
            asyncio.run(shield.run(_thunk))
        msg = str(excinfo.value)
        assert '[GUARDRAIL' in msg

    def test_stage1_block_raises_via_run_with_session(self) -> None:
        """``run_with_session`` is a thin wrapper around ``run`` — the
        regression default-raise behaviour must hold there too."""
        shield = _shield_run_default_block_shield(_shield_run_default_block_STAGE1_BLOCK_YAML)
        sess = shield.runtime.new_session()

        async def _thunk() -> str:
            raise AssertionError('thunk must not run on Stage 1 block')
        with pytest.raises(AgentShieldBlocked):
            asyncio.run(shield.run_with_session(sess, _thunk, user_input='SSN 999-88-7777 oops'))

class TestShieldRunDefaultBlockLegacyOptIn:
    """``on_block="return_blocked"`` preserves the historic
    string-return shape for customers who explicitly opt in."""

    def test_stage1_block_returns_string_with_legacy_opt_in(self) -> None:
        shield = _shield_run_default_block_shield(_shield_run_default_block_STAGE1_BLOCK_YAML)

        async def _thunk() -> str:
            raise AssertionError('thunk must not run on Stage 1 block')
        result = asyncio.run(shield.run(_thunk, user_input='SSN 555-44-3333 please', on_block='return_blocked'))
        assert isinstance(result, str)
        assert result.startswith('[GUARDRAIL')

    def test_stage5_block_returns_string_with_legacy_opt_in(self) -> None:
        shield = _shield_run_default_block_shield(_shield_run_default_block_STAGE5_BLOCK_YAML)

        async def _thunk() -> str:
            return 'here is TOPSECRET-XYZ token'
        result = asyncio.run(shield.run(_thunk, on_block='return_blocked'))
        assert isinstance(result, str)
        assert result.startswith('[GUARDRAIL')

    def test_legacy_opt_in_via_run_with_session(self) -> None:
        shield = _shield_run_default_block_shield(_shield_run_default_block_STAGE1_BLOCK_YAML)
        sess = shield.runtime.new_session()

        async def _thunk() -> str:
            raise AssertionError('thunk must not run on Stage 1 block')
        result = asyncio.run(shield.run_with_session(sess, _thunk, user_input='SSN 555-44-3333 please', on_block='return_blocked'))
        assert isinstance(result, str)
        assert result.startswith('[GUARDRAIL')

class TestShieldRunDefaultBlockAllowPathUnchanged:
    """When no stage blocks, both the new default and the legacy
    opt-in return the thunk's result untouched."""

    def test_no_block_returns_thunk_result_default(self) -> None:
        shield = _shield_run_default_block_shield(_shield_run_default_block_STAGE5_BLOCK_YAML)

        async def _thunk() -> str:
            return 'totally benign output'
        result = asyncio.run(shield.run(_thunk))
        assert result == 'totally benign output'

    def test_no_block_returns_thunk_result_legacy(self) -> None:
        shield = _shield_run_default_block_shield(_shield_run_default_block_STAGE5_BLOCK_YAML)

        async def _thunk() -> str:
            return 'totally benign output'
        result = asyncio.run(shield.run(_thunk, on_block='return_blocked'))
        assert result == 'totally benign output'
import dataclasses
from agent_shield import AgentShieldUnsupportedOutputType
_shield_run_output_type_STAGE5_REDACT_YAML = '\nmetadata:\n  name: stage5-redact-emails\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["test"]\noutput_validation:\n  guard_policies:\n    - name: redact_emails\n      evaluate_when:\n        - patterns:\n            - "[a-z0-9._-]+@[a-z0-9-]+\\\\.[a-z.]+"\n          reason: "redact emails at Stage 5"\n      action: redact\n      replacement: "[REDACTED]"\n'
_shield_run_output_type_STAGE5_BLOCK_YAML = '\nmetadata:\n  name: stage5-block-topsecret\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["test"]\noutput_validation:\n  guard_policies:\n    - name: block_topsecret\n      evaluate_when:\n        - patterns:\n            - "TOPSECRET-[A-Z0-9]+"\n          reason: "TOPSECRET tokens must not appear in output"\n      action: "block"\n'

def _shield_run_output_type_shield(yaml: str) -> Shield:
    runtime = RuntimeBuilder.from_yaml_strings([yaml]).build()
    return Shield(runtime)

class _FrameworkResult:

    def __init__(self, text: str, tool_results: list | None=None) -> None:
        self.text = text
        self.tool_results = tool_results or []

@dataclasses.dataclass(frozen=True)
class _FrozenResult:
    text: str

class TestShieldRunOutputTypeDefaultRaisesOnArbitraryObject:

    def test_arbitrary_class_raises_unsupported_output_type(self) -> None:
        shield = _shield_run_output_type_shield(_shield_run_output_type_STAGE5_REDACT_YAML)

        async def _thunk() -> _FrameworkResult:
            return _FrameworkResult(text='email: alice@example.com')
        with pytest.raises(AgentShieldUnsupportedOutputType) as excinfo:
            asyncio.run(shield.run(_thunk))
        assert excinfo.value.result_type == '_FrameworkResult'
        assert 'extract_text' in str(excinfo.value)
        assert 'Stage 5' in str(excinfo.value)

    def test_frozen_dataclass_also_raises(self) -> None:
        """Frozen / immutable result types raise the same way —
        the customer must supply both ``extract_text=`` and
        ``set_text=`` for those shapes."""
        shield = _shield_run_output_type_shield(_shield_run_output_type_STAGE5_REDACT_YAML)

        async def _thunk() -> _FrozenResult:
            return _FrozenResult(text='alice@example.com')
        with pytest.raises(AgentShieldUnsupportedOutputType) as excinfo:
            asyncio.run(shield.run(_thunk))
        assert excinfo.value.result_type == '_FrozenResult'

class TestShieldRunOutputTypeExtractTextDefaultMutator:

    def test_extract_text_redacts_into_result_text(self) -> None:
        shield = _shield_run_output_type_shield(_shield_run_output_type_STAGE5_REDACT_YAML)

        async def _thunk() -> _FrameworkResult:
            return _FrameworkResult(text='email: alice@example.com')
        result = asyncio.run(shield.run(_thunk, extract_text=lambda r: r.text, set_text=lambda r, t: setattr(r, 'text', t)))
        assert isinstance(result, _FrameworkResult)
        assert 'alice@example.com' not in result.text
        assert '[REDACTED]' in result.text
        assert result.tool_results == []

    def test_extract_text_empty_string_passes_through(self) -> None:
        shield = _shield_run_output_type_shield(_shield_run_output_type_STAGE5_REDACT_YAML)

        async def _thunk() -> _FrameworkResult:
            return _FrameworkResult(text='')
        result = asyncio.run(shield.run(_thunk, extract_text=lambda r: r.text, set_text=lambda r, t: setattr(r, 'text', t)))
        assert result.text == ''

    def test_extract_text_returning_none_passes_through(self) -> None:
        """When ``extract_text`` returns ``None`` (e.g. a result whose
        text field is itself ``None``), Stage 5 is skipped and the raw
        result is returned unchanged. Matches the regression ``raw is None``
        early-return semantics."""
        shield = _shield_run_output_type_shield(_shield_run_output_type_STAGE5_REDACT_YAML)

        class _NullText:

            def __init__(self) -> None:
                self.text: str | None = None

        async def _thunk() -> _NullText:
            return _NullText()
        result = asyncio.run(shield.run(_thunk, extract_text=lambda r: r.text, set_text=lambda r, t: setattr(r, 'text', t)))
        assert result.text is None

class TestShieldRunOutputTypeCustomSetText:

    def test_custom_set_text_replaces_result_via_dataclass_replace(self) -> None:
        shield = _shield_run_output_type_shield(_shield_run_output_type_STAGE5_REDACT_YAML)

        async def _thunk() -> _FrozenResult:
            return _FrozenResult(text='email: alice@example.com')
        result = asyncio.run(shield.run(_thunk, extract_text=lambda r: r.text, set_text=lambda r, t: dataclasses.replace(r, text=t)))
        assert isinstance(result, _FrozenResult)
        assert 'alice@example.com' not in result.text
        assert '[REDACTED]' in result.text

    def test_custom_set_text_returning_none_mutates_in_place(self) -> None:
        """A ``set_text`` that returns ``None`` signals "I mutated the
        original result in place; reuse it." — same contract as the
        default mutator."""
        shield = _shield_run_output_type_shield(_shield_run_output_type_STAGE5_REDACT_YAML)
        observed_writes: list[tuple[object, str]] = []

        def _set_text(r: _FrameworkResult, t: str) -> None:
            observed_writes.append((r, t))
            r.text = t
            return None

        async def _thunk() -> _FrameworkResult:
            return _FrameworkResult(text='email: alice@example.com')
        result = asyncio.run(shield.run(_thunk, extract_text=lambda r: r.text, set_text=_set_text))
        assert len(observed_writes) == 1
        assert 'alice@example.com' not in result.text

class TestShieldRunOutputTypeExtractTextBlockDispatch:

    def test_extract_text_block_raises_by_default(self) -> None:
        """A Stage 5 block on the extracted string must route through
        the regression ``on_block=`` policy. With the default
        ``on_block="raise"``, the customer sees
        ``AgentShieldBlocked`` rather than a silently swapped result."""
        from agent_shield.adapters._shield import AgentShieldBlocked
        shield = _shield_run_output_type_shield(_shield_run_output_type_STAGE5_BLOCK_YAML)

        async def _thunk() -> _FrameworkResult:
            return _FrameworkResult(text='TOPSECRET-ABCD leaked')
        with pytest.raises(AgentShieldBlocked):
            asyncio.run(shield.run(_thunk, extract_text=lambda r: r.text, set_text=lambda r, t: setattr(r, 'text', t)))

    def test_extract_text_block_returns_string_with_legacy_opt_in(self) -> None:
        shield = _shield_run_output_type_shield(_shield_run_output_type_STAGE5_BLOCK_YAML)

        async def _thunk() -> _FrameworkResult:
            return _FrameworkResult(text='TOPSECRET-XYZ found')
        result = asyncio.run(shield.run(_thunk, extract_text=lambda r: r.text, set_text=lambda r, t: setattr(r, 'text', t), on_block='return_blocked'))
        assert isinstance(result, str)
        assert result.startswith('[GUARDRAIL')

class TestShieldRunOutputTypeNativeShapesUnchanged:

    def test_string_return_redacts(self) -> None:
        shield = _shield_run_output_type_shield(_shield_run_output_type_STAGE5_REDACT_YAML)

        async def _thunk() -> str:
            return 'alice@example.com here'
        result = asyncio.run(shield.run(_thunk))
        assert isinstance(result, str)
        assert '[REDACTED]' in result

    def test_dict_return_redacts_via_walker(self) -> None:
        shield = _shield_run_output_type_shield(_shield_run_output_type_STAGE5_REDACT_YAML)

        async def _thunk() -> dict:
            return {'text': 'alice@example.com here', 'n': 1}
        result = asyncio.run(shield.run(_thunk))
        assert isinstance(result, dict)
        assert '[REDACTED]' in result['text']
        assert result['n'] == 1

    def test_list_return_redacts_via_walker(self) -> None:
        shield = _shield_run_output_type_shield(_shield_run_output_type_STAGE5_REDACT_YAML)

        async def _thunk() -> list:
            return ['alice@example.com', 'ok']
        result = asyncio.run(shield.run(_thunk))
        assert isinstance(result, list)
        assert '[REDACTED]' in result[0]

    def test_none_passes_through(self) -> None:
        shield = _shield_run_output_type_shield(_shield_run_output_type_STAGE5_REDACT_YAML)

        async def _thunk() -> None:
            return None
        result = asyncio.run(shield.run(_thunk))
        assert result is None

class TestShieldRunOutputTypeKwargValidation:

    def test_extract_text_non_callable_raises_type_error(self) -> None:
        shield = _shield_run_output_type_shield(_shield_run_output_type_STAGE5_REDACT_YAML)

        async def _thunk() -> _FrameworkResult:
            return _FrameworkResult(text='hi')
        with pytest.raises(TypeError):
            asyncio.run(shield.run(_thunk, extract_text='not a callable'))

    def test_set_text_non_callable_raises_type_error(self) -> None:
        shield = _shield_run_output_type_shield(_shield_run_output_type_STAGE5_REDACT_YAML)

        async def _thunk() -> _FrameworkResult:
            return _FrameworkResult(text='hi')
        with pytest.raises(TypeError):
            asyncio.run(shield.run(_thunk, extract_text=lambda r: r.text, set_text='not a callable'))

    def test_extract_text_returning_non_str_raises_type_error(self) -> None:
        shield = _shield_run_output_type_shield(_shield_run_output_type_STAGE5_REDACT_YAML)

        async def _thunk() -> _FrameworkResult:
            return _FrameworkResult(text='hi')
        with pytest.raises(TypeError):
            asyncio.run(shield.run(_thunk, extract_text=lambda r: 12345, set_text=lambda r, t: setattr(r, 'text', t)))

class _ShieldRunOutputTypeFakeLitellmMessage:

    def __init__(self, content: str) -> None:
        self.content = content

class _ShieldRunOutputTypeFakeLitellmChoice:

    def __init__(self, content: str) -> None:
        self.message = _ShieldRunOutputTypeFakeLitellmMessage(content)

class _ShieldRunOutputTypeFakeLitellmResponse:

    def __init__(self, content: str) -> None:
        self.choices = [_ShieldRunOutputTypeFakeLitellmChoice(content)]

class TestShieldRunOutputTypeLensIncomplete:
    """regression — ``extract_text`` without ``set_text`` is now a
    configuration error.

    The previous silent-bypass: customer passes
    ``extract_text=lambda r: r.choices[0].message.content`` (a nested
    location) but forgets ``set_text=``. The default mutator did
    ``setattr(result, 'text', redacted)`` — writing to a fresh
    ``result.text`` attribute. Customer-visible
    ``r.choices[0].message.content`` remained unredacted; customer
    sees no exception; downstream code returns unredacted text.
    """

    def test_extract_text_without_set_text_raises_lens_incomplete(self) -> None:
        from agent_shield import AgentShieldLensIncomplete
        shield = _shield_run_output_type_shield(_shield_run_output_type_STAGE5_REDACT_YAML)

        async def _thunk() -> _ShieldRunOutputTypeFakeLitellmResponse:
            return _ShieldRunOutputTypeFakeLitellmResponse('support@example.com SSN 123-45-6789')
        with pytest.raises(AgentShieldLensIncomplete) as excinfo:
            asyncio.run(shield.run(_thunk, extract_text=lambda r: r.choices[0].message.content))
        msg = str(excinfo.value)
        assert 'set_text' in msg
        assert 'set_text=None' in msg
        assert 'extract_text' in msg

    def test_lens_incomplete_raises_eagerly_before_thunk_runs(self) -> None:
        """The fail-closed check fires at ``run()`` entry — *before* the
        thunk executes. A misconfigured customer should never see their
        agent invoked when the lens is half-configured.
        """
        from agent_shield import AgentShieldLensIncomplete
        shield = _shield_run_output_type_shield(_shield_run_output_type_STAGE5_REDACT_YAML)
        thunk_called: list[bool] = []

        async def _thunk() -> _FrameworkResult:
            thunk_called.append(True)
            return _FrameworkResult(text='hi')
        with pytest.raises(AgentShieldLensIncomplete):
            asyncio.run(shield.run(_thunk, extract_text=lambda r: r.text))
        assert thunk_called == []

    def test_set_text_explicit_none_is_advisory_only(self) -> None:
        """The acknowledge-and-override path: ``set_text=None`` opts in
        to advisory-only mode. Stage 5 runs over the extracted text but
        the result object is intentionally NOT mutated. The customer
        explicitly acknowledged that their framework result will not be
        rewritten and downstream code is responsible for handling that.
        """
        shield = _shield_run_output_type_shield(_shield_run_output_type_STAGE5_REDACT_YAML)

        async def _thunk() -> _ShieldRunOutputTypeFakeLitellmResponse:
            return _ShieldRunOutputTypeFakeLitellmResponse('email: alice@example.com')
        result = asyncio.run(shield.run(_thunk, extract_text=lambda r: r.choices[0].message.content, set_text=None))
        assert isinstance(result, _ShieldRunOutputTypeFakeLitellmResponse)
        assert result.choices[0].message.content == 'email: alice@example.com'
        assert not hasattr(result, 'text')

    def test_set_text_explicit_none_still_blocks_on_stage5_block(self) -> None:
        """Advisory mode does not suppress block dispatch — a Stage 5
        block on the extracted text still routes through ``on_block=``.
        Only the write-back is advisory."""
        from agent_shield.adapters._shield import AgentShieldBlocked
        shield = _shield_run_output_type_shield(_shield_run_output_type_STAGE5_BLOCK_YAML)

        async def _thunk() -> _ShieldRunOutputTypeFakeLitellmResponse:
            return _ShieldRunOutputTypeFakeLitellmResponse('TOPSECRET-ABCD leaked')
        with pytest.raises(AgentShieldBlocked):
            asyncio.run(shield.run(_thunk, extract_text=lambda r: r.choices[0].message.content, set_text=None))

    def test_extract_text_with_set_text_redacts_at_extract_location(self) -> None:
        """The canonical opt-in shape: ``extract_text`` + ``set_text``
        targeting the same nested field. Stage 5 redacts and writes
        back to the location the customer pointed at."""
        shield = _shield_run_output_type_shield(_shield_run_output_type_STAGE5_REDACT_YAML)

        async def _thunk() -> _ShieldRunOutputTypeFakeLitellmResponse:
            return _ShieldRunOutputTypeFakeLitellmResponse('email: alice@example.com')

        def _set(r: _ShieldRunOutputTypeFakeLitellmResponse, t: str) -> None:
            r.choices[0].message.content = t
            return None
        result = asyncio.run(shield.run(_thunk, extract_text=lambda r: r.choices[0].message.content, set_text=_set))
        assert isinstance(result, _ShieldRunOutputTypeFakeLitellmResponse)
        assert 'alice@example.com' not in result.choices[0].message.content
        assert '[REDACTED]' in result.choices[0].message.content
        assert not hasattr(result, 'text')

    def test_string_result_unchanged_without_set_text(self) -> None:
        """String results don't need the lens at all — pre-existing
        in-place redaction continues to work regardless of the
        ``extract_text`` / ``set_text`` plumbing."""
        shield = _shield_run_output_type_shield(_shield_run_output_type_STAGE5_REDACT_YAML)

        async def _thunk() -> str:
            return 'alice@example.com here'
        result = asyncio.run(shield.run(_thunk))
        assert isinstance(result, str)
        assert '[REDACTED]' in result

    def test_default_raise_still_fires_without_extract_text(self) -> None:
        """Regression — regression default-raise for non-string results
        without ``extract_text`` is unaffected by the regression plumbing."""
        shield = _shield_run_output_type_shield(_shield_run_output_type_STAGE5_REDACT_YAML)

        async def _thunk() -> _ShieldRunOutputTypeFakeLitellmResponse:
            return _ShieldRunOutputTypeFakeLitellmResponse('email: alice@example.com')
        with pytest.raises(AgentShieldUnsupportedOutputType):
            asyncio.run(shield.run(_thunk))
from agent_shield import Shield  # noqa: F811
from agent_shield.adapters._orchestration import current_user_input
from agent_shield.adapters._shield import GuardedRunner, ShieldMode
_with_fresh_session_REPO_ROOT = REPO_ROOT
_with_fresh_session_MINIMAL = str(_with_fresh_session_REPO_ROOT / 'tests' / 'fixtures' / 'smoke' / 'minimal.guardrails.yaml')
_with_fresh_session_INPUT_REDACT = str(_with_fresh_session_REPO_ROOT / 'tests' / 'fixtures' / 'smoke' / 'input-redact.guardrails.yaml')

def _with_fresh_session_build_shield(**kwargs) -> Shield:
    """Build a minimally-configured Shield for the immutability tests."""
    return Shield.from_yaml(_with_fresh_session_MINIMAL, auto_bind=False).with_langchain().build()

def test_with_fresh_session__shield_with_fresh_session_returns_new_instance() -> None:
    original = _with_fresh_session_build_shield()
    forked = original.with_fresh_session()
    assert forked is not original
    assert forked.runtime is original.runtime

def test_with_fresh_session__shield_with_fresh_session_preserves_config() -> None:
    original = Shield.from_yaml(_with_fresh_session_MINIMAL, auto_bind=False).with_langchain().with_mode(ShieldMode.MONITOR).with_on_block('raise').build()
    forked = original.with_fresh_session()
    assert forked.mode is ShieldMode.MONITOR
    assert forked._on_block == 'raise'
    assert forked._bundle is original._bundle
    assert forked._streaming_config == original._streaming_config

def test_with_fresh_session__shield_with_fresh_session_does_not_mutate_original() -> None:
    original = _with_fresh_session_build_shield()

    class _Marker:
        pass
    sentinel = _Marker()
    original._guarded_runners.add(sentinel)
    forked = original.with_fresh_session()
    assert sentinel in original._guarded_runners
    assert sentinel not in forked._guarded_runners
    assert len(forked._guarded_runners) == 0

def test_with_fresh_session__shield_with_fresh_session_returns_shield_instance() -> None:
    """``with_fresh_session`` returns a :class:`Shield` (no subclassing
    is supported in the unified-resolver model)."""
    original = _with_fresh_session_build_shield()
    forked = original.with_fresh_session()
    assert type(forked) is type(original)

def _with_fresh_session_stub_boundary():

    class _Stub:

        async def run(self, agent, input_text, **kwargs):
            return {}

        def extract_output(self, result):
            return ''

        def apply_redaction(self, result, redacted):
            return result

        def make_blocked(self, message):
            return message
    return _Stub()

def test_with_fresh_session__runner_run_passes_stage1_mutated_input() -> None:
    import asyncio
    shield = Shield.from_yaml(_with_fresh_session_INPUT_REDACT, auto_bind=False).with_langchain().build()
    seen = {}

    class _Boundary:

        async def run(self, agent, input_text, **kwargs):
            seen['input'] = input_text
            return {'ok': True}

        def extract_output(self, result):
            return ''

        def apply_redaction(self, result, redacted):
            return result

        def make_blocked(self, message):
            return message
    runner = GuardedRunner(shield.runtime, agent=object(), boundary=_Boundary())
    asyncio.run(runner.run('hello SECRET-ABCD'))
    assert seen['input'] == 'hello [INPUT REDACTED]'

def test_with_fresh_session__shield_run_sets_ambient_stage1_mutated_input() -> None:
    import asyncio
    shield = Shield.from_yaml(_with_fresh_session_INPUT_REDACT, auto_bind=False).build()
    seen = {}

    async def _execute():
        seen['input'] = current_user_input.get()
        return ''
    asyncio.run(shield.run(_execute, user_input='hello SECRET-ABCD'))
    assert seen['input'] == 'hello [INPUT REDACTED]'

def test_with_fresh_session__runner_with_fresh_session_returns_new_runner() -> None:
    shield = _with_fresh_session_build_shield()
    boundary = _with_fresh_session_stub_boundary()
    original = GuardedRunner(shield.runtime, agent=object(), boundary=boundary)
    original_session = original._session
    forked = original.with_fresh_session()
    assert forked is not original
    assert forked._session is not original._session
    assert forked._runtime is original._runtime
    assert original._session is original_session
