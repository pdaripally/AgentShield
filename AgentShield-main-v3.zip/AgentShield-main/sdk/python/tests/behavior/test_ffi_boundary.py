"""Behavior tests consolidated into behavior/test_ffi_boundary.py."""
from __future__ import annotations
from .._support.paths import REPO_ROOT
import concurrent.futures
import json
import threading
import pytest
try:
    import agent_shield._native as _native
    from agent_shield import RuntimeBuilder
except ImportError:
    RuntimeBuilder = None
    _native = None
pytestmark = pytest.mark.skipif(_native is None, reason='agent_shield._native unavailable; run `maturin develop` in sdk/python')
_ffi_boundary_REPO_ROOT = REPO_ROOT
_ffi_boundary_MINIMAL = str(_ffi_boundary_REPO_ROOT / 'tests' / 'fixtures' / 'smoke' / 'minimal.guardrails.yaml')
_ffi_boundary_STRING_FIXTURE_YAML = '\nmetadata:\n  name: "ffi-string-roundtrip"\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["exercise string FFI round-tripping"]\n  forbidden: ["nothing"]\nresources:\n  tools:\n    - name: "echo"\n      description: "Echoes a message back."\n      permission: "read_only"\nvariables:\n  - name: "status_text"\n    type: "string"\n    default: ""\n'

def _ffi_boundary_build_runtime(path: str=_ffi_boundary_MINIMAL):
    return RuntimeBuilder.from_yaml(path).build()

def _ffi_boundary_build_string_runtime():
    return RuntimeBuilder.from_yaml_strings([_ffi_boundary_STRING_FIXTURE_YAML]).build()

def _ffi_boundary_new_session(runtime, *, session_id: str, correlation_id: str):
    session = runtime.new_session(session_id=session_id, correlation_id=correlation_id)
    session.begin_turn()
    return session

def _ffi_boundary_authorized_session(runtime, *, session_id: str, correlation_id: str):
    session = _ffi_boundary_new_session(runtime, session_id=session_id, correlation_id=correlation_id)
    session.set_variable('authorized', True)
    return session

def _ffi_boundary_deeply_nested_object(depth: int) -> dict[str, object]:
    root: dict[str, object] = {'leaf': 'start'}
    cursor = root
    for level in range(depth):
        child: dict[str, object] = {'level': level}
        cursor['next'] = child
        cursor = child
    return root

def test_ffi_boundary__embedded_nul_byte_in_tool_name_is_catchable():
    session = _ffi_boundary_authorized_session(_ffi_boundary_build_runtime(), session_id='ffi-nul', correlation_id='ffi-nul')
    try:
        outcome = session.validate_tool_call('echo\x00ffi', {'msg': 'hello'}, tool_call_id='ffi-nul')
    except Exception as exc:
        assert isinstance(exc, Exception)
    else:
        assert isinstance(outcome.verdict.allowed, bool)
        assert isinstance(outcome.params, dict)

def test_ffi_boundary__four_byte_emoji_round_trips_through_string_variable():
    runtime = _ffi_boundary_build_string_runtime()
    session = _ffi_boundary_new_session(runtime, session_id='ffi-emoji', correlation_id='ffi-emoji')
    emoji = '🛡️'
    session.set_variable('status_text', emoji)
    state = session.read_variable('status_text')
    assert state is not None
    assert state.value == emoji
    assert isinstance(state.value, str)

def test_ffi_boundary__empty_string_input_is_handled_without_null_coercion():
    session = _ffi_boundary_new_session(_ffi_boundary_build_runtime(), session_id='ffi-empty', correlation_id='ffi-empty')
    verdict = session.validate_input('')
    assert verdict.allowed is True
    assert verdict.reason is None

def test_ffi_boundary__large_string_tool_param_returns_consistent_verdict():
    session = _ffi_boundary_authorized_session(_ffi_boundary_build_runtime(), session_id='ffi-large-str', correlation_id='ffi-large-str')
    large_value = 'x' * (1024 * 1024)
    outcome = session.validate_tool_call('echo', {'msg': large_value}, tool_call_id='ffi-large-str')
    assert outcome.verdict.allowed is True
    assert outcome.params == {'msg': large_value}

def test_ffi_boundary__deeply_nested_tool_params_do_not_abort_the_process():
    session = _ffi_boundary_authorized_session(_ffi_boundary_build_runtime(), session_id='ffi-nested', correlation_id='ffi-nested')
    payload = _ffi_boundary_deeply_nested_object(24)
    try:
        outcome = session.validate_tool_call('echo', payload, tool_call_id='ffi-nested')
    except Exception as exc:
        assert isinstance(exc, Exception)
    else:
        assert outcome.verdict.allowed is True
        assert isinstance(outcome.params, dict)

def test_ffi_boundary__shared_runtime_is_thread_safe_for_tool_validation():
    runtime = _ffi_boundary_build_runtime()
    params = {'msg': 'thread-safe 🛡️'}
    barrier = threading.Barrier(4)

    def worker(worker_id: int) -> tuple[int, bool]:
        with runtime.new_session(session_id=f'ffi-thread-{worker_id}', correlation_id=f'ffi-thread-{worker_id}') as session:
            session.begin_turn()
            session.set_variable('authorized', True)
            barrier.wait()
            for iteration in range(10000):
                outcome = session.validate_tool_call('echo', params, tool_call_id=f'ffi-thread-{worker_id}-{iteration}')
                assert outcome.verdict.allowed is True
                assert outcome.params == params
            return (worker_id, True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        futures = [executor.submit(worker, worker_id) for worker_id in range(4)]
        results = [future.result() for future in futures]
    assert results == [(0, True), (1, True), (2, True), (3, True)]

def test_ffi_boundary__large_json_tool_params_round_trip_without_oom():
    session = _ffi_boundary_authorized_session(_ffi_boundary_build_runtime(), session_id='ffi-large-json', correlation_id='ffi-large-json')
    tool_params = {'payload': 'x' * 1060000, 'metadata': {'source': 'ffi-boundary', 'empty': '', 'emoji': '🛡️', 'flags': [True, False, None]}, 'items': [{'index': idx, 'label': f'item-{idx}'} for idx in range(32)]}
    assert len(json.dumps(tool_params, ensure_ascii=False)) >= 1024 * 1024
    outcome = session.validate_tool_call('echo', tool_params, tool_call_id='ffi-large-json')
    assert outcome.verdict.allowed is True
    assert outcome.params == tool_params
