"""Behavior tests consolidated into behavior/test_adapters_openai_agents_sdk.py."""
from __future__ import annotations
from .._support.paths import REPO_ROOT
import asyncio
import inspect
import pytest
_openai_adapter_functiontool_compat_REPO_ROOT = REPO_ROOT
_openai_adapter_functiontool_compat_GLOBAL_FIXTURES = _openai_adapter_functiontool_compat_REPO_ROOT / 'tests' / 'fixtures'
_openai_adapter_functiontool_compat_MINIMAL = str(_openai_adapter_functiontool_compat_GLOBAL_FIXTURES / 'smoke' / 'minimal.guardrails.yaml')
pytest.importorskip('agents', reason='openai-agents not installed')

def test_openai_adapter_functiontool_compat__function_tool_constructs_on_current_sdk():
    """``_ToolWrapper.wrap`` builds a real ``FunctionTool`` without
    ``TypeError`` on whatever ``openai-agents`` is installed.

    This is the direct regression: against 0.17.4 the old kwarg
    name raised ``TypeError`` here; against 0.16.x the new private name
    would raise the same.
    """
    from agents import FunctionTool
    from agent_shield import Shield
    shield = Shield.from_yaml(_openai_adapter_functiontool_compat_MINIMAL, auto_bind=False).with_openai_agents().build()

    async def on_invoke(ctx, input_json: str) -> str:
        return 'ok'
    original = FunctionTool(name='echo_tool', description='An echo tool', params_json_schema={'type': 'object', 'additionalProperties': False}, on_invoke_tool=on_invoke, strict_json_schema=False)
    wrapped = shield.protect_tools([original])[0]
    assert isinstance(wrapped, FunctionTool)
    assert wrapped.name == 'echo_tool'

def test_openai_adapter_functiontool_compat__function_tool_reraise_on_block():
    """A ``FunctionTool`` built by ``_ToolWrapper.wrap`` MUST be
    configured so a Stage-2/3/4 guardrail block (which surfaces as
    :class:`AgentShieldBlocked` raised by ``guarded_invoke``)
    propagates out of ``on_invoke_tool`` rather than being rendered
    by the SDK's default tool-error formatter into a string the LLM
    consumes as an ordinary tool result.

    The check has two halves:

    1. Calling the wrapped ``on_invoke_tool`` re-raises
       :class:`AgentShieldBlocked` when ``guarded_invoke`` raises it
       (simulating a guardrail-decision block, not an underlying-tool
       exception — the orchestrator routes underlying-tool exceptions
       through Stage 4 instead). The runner's outer ``except Exception``
       in ``run_internal/tool_execution.py`` then halts the agent loop.

    2. ``maybe_invoke_function_tool_failure_error_function``, which
       the runner consults on certain error paths (notably
       cancellation), returns ``None`` for this tool — so even if
       ``AgentShieldBlocked`` reached that path, no formatter would
       render it as a tool-result string. This is the silent-bypass
       guard.
    """
    from agents import FunctionTool
    from agents.tool import maybe_invoke_function_tool_failure_error_function, resolve_function_tool_failure_error_function
    from agent_shield.adapters._capabilities import ToolMetadata
    from agent_shield.adapters._orchestration import AgentShieldBlocked
    from agent_shield.adapters.openai_agents import _ToolWrapper
    wrapper = _ToolWrapper()

    async def on_invoke_original(ctx, input_json: str) -> str:
        return 'original-not-reached'
    original = FunctionTool(name='blocking_tool', description='A tool whose guardrail always blocks', params_json_schema={'type': 'object', 'additionalProperties': False}, on_invoke_tool=on_invoke_original, strict_json_schema=False)
    metadata = ToolMetadata(name='blocking_tool', description='A tool whose guardrail always blocks', params_schema={'type': 'object', 'additionalProperties': False}, extras={'original': original})

    async def stub_guarded_invoke(params, user_input):
        raise AgentShieldBlocked('simulated stage-3 block')
    wrapped = wrapper.wrap(original, metadata, stub_guarded_invoke)
    assert isinstance(wrapped, FunctionTool)
    with pytest.raises(AgentShieldBlocked):
        asyncio.run(wrapped.on_invoke_tool(None, '{}'))
    assert resolve_function_tool_failure_error_function(wrapped) is None

    class _DummyCtx:
        pass
    result = asyncio.run(maybe_invoke_function_tool_failure_error_function(function_tool=wrapped, context=_DummyCtx(), error=AgentShieldBlocked('simulated stage-3 block')))
    assert result is None, 'regression probe regression: SDK would render AgentShieldBlocked as a tool-error string, enabling the silent-bypass class'

def test_openai_adapter_functiontool_compat__kwarg_detection_caches():
    """``_function_tool_failure_kwargs`` inspects ``FunctionTool.__init__``
    once and caches the resolved kwargs dict. Subsequent wraps must not
    re-walk the signature.

    Strategy: prime the cache, then swap ``inspect.signature`` with a
    sentinel that records calls — a cached lookup must NOT touch it.
    """
    from agent_shield.adapters.openai_agents import _function_tool_failure_kwargs, _reset_function_tool_failure_kwargs_cache
    from agents import FunctionTool
    _reset_function_tool_failure_kwargs_cache()
    first = _function_tool_failure_kwargs(FunctionTool)
    assert isinstance(first, dict)
    assert first == {'_failure_error_function': None, '_use_default_failure_error_function': False} or first == {'failure_error_function': None}
    sentinel = {'calls': 0}
    original_signature = inspect.signature

    def counting_signature(*args, **kwargs):
        sentinel['calls'] += 1
        return original_signature(*args, **kwargs)
    inspect.signature = counting_signature
    try:
        second = _function_tool_failure_kwargs(FunctionTool)
        third = _function_tool_failure_kwargs(FunctionTool)
    finally:
        inspect.signature = original_signature
    assert second is first, 'cache returned a new object'
    assert third is first, 'cache returned a new object on second hit'
    assert sentinel['calls'] == 0, f'signature was inspected {sentinel["calls"]} extra times; _function_tool_failure_kwargs is not caching'
_openai_runner_run_guard_agents = pytest.importorskip('agents')
from agent_shield import Shield
from agent_shield.adapters._orchestration import current_session
from agent_shield.adapters._shield import GuardedRunner
_openai_runner_run_guard_REPO_ROOT = REPO_ROOT
_openai_runner_run_guard_GLOBAL_FIXTURES = _openai_runner_run_guard_REPO_ROOT / 'tests' / 'fixtures'
_openai_runner_run_guard_MINIMAL = str(_openai_runner_run_guard_GLOBAL_FIXTURES / 'smoke' / 'minimal.guardrails.yaml')

@pytest.fixture
def _openai_runner_run_guard_shield():
    """Build a Shield bound to the openai_agents bundle.

    No LLM client is needed; the tests stub ``boundary.run`` so the
    framework's LLM caller is never invoked.
    """
    return Shield.from_yaml(_openai_runner_run_guard_MINIMAL, auto_bind=False).with_openai_agents().build()

@pytest.fixture
def _openai_runner_run_guard_plain_agent():
    """A bare ``agents.Agent`` with no tools or model."""
    return _openai_runner_run_guard_agents.Agent(name='test', instructions='hello')

def _openai_runner_run_guard_make_boundary_recorder(monkeypatch, guarded):
    """Replace ``guarded._boundary.run`` with a recorder that captures
    whether the ambient ``current_session`` ContextVar was set when the
    boundary fired. Returns the captured-state dict and a stub result.

    The recorder returns a minimal object that satisfies
    ``boundary.extract_output`` (a ``final_output`` attribute) so the
    Stage 5 path runs cleanly.
    """
    captured: dict = {'called': False, 'session_at_call': None, 'input_at_call': None}

    class _StubResult:

        def __init__(self, text: str) -> None:
            self.final_output = text
    original_run = guarded._boundary.run

    async def _recording_run(agent, input_text, **kwargs):
        captured['called'] = True
        captured['session_at_call'] = current_session.get()
        captured['input_at_call'] = input_text
        return _StubResult('ok')
    monkeypatch.setattr(guarded._boundary, 'run', _recording_run)
    return (captured, original_run)

class TestOpenaiRunnerRunGuardRunnerRunShim:
    """``Runner.run(guarded, input)`` must dispatch through ``guarded.run``."""

    def test_shim_installed_at_import_time(self):
        """The shim sets a sentinel attribute on the patched classmethod
        so callers (and the shim itself) can detect prior installation
        and avoid double-patching."""
        assert getattr(_openai_runner_run_guard_agents.Runner.run, '__agent_shield_shimmed__', False) is True, 'Runner.run should be shimmed at adapter import time'
        assert getattr(_openai_runner_run_guard_agents.Runner.run_sync, '__agent_shield_shimmed__', False) is True, 'Runner.run_sync should also be shimmed'

    def test_runner_run_with_guarded_agent_propagates_session(self, _openai_runner_run_guard_shield, _openai_runner_run_guard_plain_agent, monkeypatch):
        """The regression acceptance test: ``Runner.run(guarded, input)`` must
        open a guarded session and set the ``current_session`` ContextVar
        before executing the agent, so wrapped tools see an ambient
        session and don't fail-closed with ``UnguardedToolInvocation``."""
        guarded = _openai_runner_run_guard_shield.guard(_openai_runner_run_guard_plain_agent)
        captured, _ = _openai_runner_run_guard_make_boundary_recorder(monkeypatch, guarded)
        result = asyncio.run(_openai_runner_run_guard_agents.Runner.run(guarded, 'hello world'))
        assert captured['called'] is True, 'boundary.run should fire when Runner.run dispatches through the shim'
        assert captured['session_at_call'] is not None, 'current_session ContextVar must be set when the agent executes — otherwise wrapped tools fail-closed with UnguardedToolInvocation. This is the regression check.'
        assert captured['input_at_call'] == 'hello world'
        assert getattr(result, 'final_output', None) == 'ok'

    def test_runner_run_without_guarded_agent_unchanged(self, monkeypatch):
        """Plain ``Agent`` instances must NOT be intercepted — they
        flow through to the original ``Runner.run``."""
        plain = _openai_runner_run_guard_agents.Agent(name='plain', instructions='hi')
        sentinel = object()
        called: dict = {'orig_called': False, 'first_arg': None}
        original_func = _openai_runner_run_guard_agents.Runner.run.__func__.__wrapped__

        async def _stub_original(cls, starting_agent, input, **kwargs):
            called['orig_called'] = True
            called['first_arg'] = starting_agent
            return sentinel

        async def _shim(cls, starting_agent, input, **kwargs):
            if isinstance(starting_agent, GuardedRunner):
                return await starting_agent.run(input, **kwargs)
            return await _stub_original(cls, starting_agent, input, **kwargs)
        _shim.__agent_shield_shimmed__ = True
        _shim.__wrapped__ = _stub_original
        monkeypatch.setattr(_openai_runner_run_guard_agents.Runner, 'run', classmethod(_shim))
        result = asyncio.run(_openai_runner_run_guard_agents.Runner.run(plain, 'hi'))
        assert called['orig_called'] is True, 'non-Guarded first-arg must delegate to original Runner.run'
        assert called['first_arg'] is plain
        assert result is sentinel
        assert callable(original_func)

    def test_guarded_run_still_works(self, _openai_runner_run_guard_shield, _openai_runner_run_guard_plain_agent, monkeypatch):
        """The existing ``guarded.run(input)`` path must continue to
        work (no regression from the shim's installation)."""
        guarded = _openai_runner_run_guard_shield.guard(_openai_runner_run_guard_plain_agent)
        captured, _ = _openai_runner_run_guard_make_boundary_recorder(monkeypatch, guarded)
        result = asyncio.run(guarded.run('direct call'))
        assert captured['called'] is True
        assert captured['session_at_call'] is not None
        assert captured['input_at_call'] == 'direct call'
        assert getattr(result, 'final_output', None) == 'ok'

    def test_runner_run_forwards_kwargs_to_underlying_runner(self, _openai_runner_run_guard_shield, _openai_runner_run_guard_plain_agent, monkeypatch):
        """Customer-supplied Runner.run kwargs (e.g. ``max_turns``,
        ``context``) must reach the framework's ``Runner.run`` via
        ``boundary.run`` — not be silently dropped by the shim."""
        guarded = _openai_runner_run_guard_shield.guard(_openai_runner_run_guard_plain_agent)
        forwarded: dict = {'kwargs': None}

        class _StubResult:

            def __init__(self) -> None:
                self.final_output = 'ok'

        async def _recording_run(agent, input_text, **kwargs):
            forwarded['kwargs'] = kwargs
            return _StubResult()
        monkeypatch.setattr(guarded._boundary, 'run', _recording_run)
        asyncio.run(_openai_runner_run_guard_agents.Runner.run(guarded, 'hi', max_turns=7, context={'role': 'user'}))
        assert forwarded['kwargs'] is not None
        assert forwarded['kwargs'].get('max_turns') == 7
        assert forwarded['kwargs'].get('context') == {'role': 'user'}

    def test_runner_run_with_wrapped_tool_invocation_succeeds(self, _openai_runner_run_guard_shield, monkeypatch):
        """End-to-end: ``Runner.run(guarded, input)`` where the agent's
        execute path drives a callable that reads
        ``current_session`` (the same ContextVar wrapped tools read)
        must observe the ambient session and not fail-closed.

        We don't drive the real LLM, and we don't go through
        ``shield.protect_tools(...)`` here (that path constructs
        ``FunctionTool`` with kwargs whose names vary across
        openai-agents minor versions — a separate regression finding). The
        observable contract this test guards is the only one regression
        cares about: ``current_session.get()`` is non-None inside
        ``boundary.run``, which is exactly when wrapped tools read it.
        """
        agent = _openai_runner_run_guard_agents.Agent(name='t', instructions='x')
        guarded = _openai_runner_run_guard_shield.guard(agent)
        tool_observed: dict = {'session_at_tool': None, 'tool_ran': False}

        async def _execute_via_boundary(agent_, input_text, **kwargs):
            tool_observed['session_at_tool'] = current_session.get()
            tool_observed['tool_ran'] = True

            class _Result:
                final_output = 'done'
            return _Result()
        monkeypatch.setattr(guarded._boundary, 'run', _execute_via_boundary)
        result = asyncio.run(_openai_runner_run_guard_agents.Runner.run(guarded, 'trigger echo'))
        assert tool_observed['tool_ran'] is True
        assert tool_observed['session_at_tool'] is not None, 'Wrapped tool invoked from inside Runner.run(guarded, ...) must see ambient current_session ContextVar'
        assert getattr(result, 'final_output', None) == 'done'

class TestOpenaiRunnerRunGuardImprovedErrorMessage:
    """Option D — the unguarded error message must explicitly mention
    ``Runner.run(guarded, ...)`` and the adapter import contract so
    customers who somehow bypass the shim aren't left guessing."""

    def test_error_message_mentions_runner_run_and_adapter_import(self):
        from agent_shield.adapters._orchestration import _unguarded_message
        msg = _unguarded_message('execute_trade')
        assert 'execute_trade' in msg
        assert 'shield.guard' in msg
        assert 'allow_unguarded' in msg
        assert 'Runner.run(guarded' in msg
        assert 'agent_shield.adapters.openai_agents' in msg
        assert 'guarded.run' in msg
