"""Behavior tests consolidated into behavior/test_adapters_crewai.py."""
from __future__ import annotations
from .._support.paths import REPO_ROOT, TESTS_ROOT
from typing import Any, Optional
import pytest
_crewai_adapter_crewai = pytest.importorskip('crewai')
from agent_shield import RuntimeBuilder
from agent_shield.adapters._orchestration import AgentShieldBlocked, UnguardedToolInvocation, current_session
from agent_shield.adapters.crewai import GuardedCrew, _bind_caller_agent_if_present, _current_crewai_agent_role, protect_tools
_crewai_adapter_REPO_ROOT = REPO_ROOT
_crewai_adapter_FIXTURE = str(_crewai_adapter_REPO_ROOT / 'sdk' / 'python' / 'tests' / 'fixtures_smoke' / 'crewai_session_isolation.guardrails.yaml')

class _CrewaiAdapterFakeTool:
    """Minimal duck-type that mirrors CrewAI's ``BaseTool`` surface.

    The adapter's ``_ToolWrapper.extract`` reads ``.name``,
    ``.description``, and ``.args_schema``. Its ``_run`` is the
    underlying implementation the guarded wrapper delegates to.
    """

    def __init__(self, name: str='publish_draft') -> None:
        self.name = name
        self.description = f'Fake CrewAI tool {name}'
        self.args_schema = None
        self.calls: list[dict] = []

    def _run(self, **kwargs: Any) -> Any:
        self.calls.append(kwargs)
        return f'{self.name}-ran'

class _CrewaiAdapterFakeCrewAgent:
    """Stand-in for ``crewai.Agent`` — only ``.role`` is read."""

    def __init__(self, role: str) -> None:
        self.role = role

class _CrewaiAdapterFakeToolUsage:
    """Stand-in for ``crewai.tools.tool_usage.ToolUsage``.

    The adapter's stack walker matches the frame's ``self`` by class
    NAME (``"ToolUsage"``), so this class is named accordingly. It
    only needs to carry the executing agent on ``.agent``.
    """

    def __init__(self, agent: Any) -> None:
        self.agent = agent

    def dispatch(self, fn, **kwargs):
        """Run ``fn`` so its call stack includes this ``ToolUsage`` frame.

        Mirrors what real CrewAI does inside
        ``ToolUsage._use`` → ``tool.invoke(...)`` → ``BaseTool._run``.
        """
        return fn(**kwargs)

class ToolUsage(_CrewaiAdapterFakeToolUsage):  # noqa: N801 — class name MUST be "ToolUsage" because the adapter's stack walker matches frames by ``type(self).__name__ == "ToolUsage"``.
    pass

class _CrewaiAdapterFakeCrew:
    """Stand-in for ``crewai.Crew`` — only ``.kickoff(inputs=...)`` is used."""

    def __init__(self, output: str='OK', side_effect=None) -> None:
        self._output = output
        self._side_effect = side_effect
        self.kickoff_calls: list[dict | None] = []

    def kickoff(self, inputs: Optional[dict]=None) -> Any:
        self.kickoff_calls.append(inputs)
        if self._side_effect is not None:
            self._side_effect()
        return self._output

def _crewai_adapter_build_runtime() -> Any:
    return RuntimeBuilder.from_yaml(_crewai_adapter_FIXTURE).build()

class TestCrewaiAdapterStackWalker:
    """Whitebox tests for ``_current_crewai_agent_role``."""

    def test_no_toolusage_frame_returns_none(self) -> None:
        assert _current_crewai_agent_role() is None

    def test_finds_editor_role_from_toolusage_frame(self) -> None:
        agent = _CrewaiAdapterFakeCrewAgent(role='Editor')
        usage = ToolUsage(agent)

        def _inner() -> Optional[str]:
            return _current_crewai_agent_role()
        role = usage.dispatch(_inner)
        assert role == 'Editor'

    def test_finds_writer_role_from_toolusage_frame(self) -> None:
        agent = _CrewaiAdapterFakeCrewAgent(role='Writer')
        usage = ToolUsage(agent)
        role = usage.dispatch(_current_crewai_agent_role)
        assert role == 'Writer'

    def test_toolusage_with_no_agent_returns_none(self) -> None:
        usage = ToolUsage(agent=None)
        role = usage.dispatch(_current_crewai_agent_role)
        assert role is None

    def test_toolusage_with_blank_role_returns_none(self) -> None:
        """Empty / non-string roles fall through to fail-closed unset."""
        usage = ToolUsage(_CrewaiAdapterFakeCrewAgent(role=''))
        assert usage.dispatch(_current_crewai_agent_role) is None

class TestCrewaiAdapterBindCallerAgent:
    """``_bind_caller_agent_if_present`` writes the role to the session."""

    def test_binds_role_to_session(self) -> None:
        runtime = _crewai_adapter_build_runtime()
        session = runtime.new_session()
        session.begin_turn()
        try:
            agent = _CrewaiAdapterFakeCrewAgent(role='Editor')
            usage = ToolUsage(agent)

            def _call() -> Optional[str]:
                return _bind_caller_agent_if_present(session)
            role = usage.dispatch(_call)
            assert role == 'Editor'
            state = session.read_variable('caller_agent')
            assert state is not None
            assert state.value == 'Editor'
        finally:
            session.end_turn()

    def test_leaves_variable_unset_when_no_agent_on_stack(self) -> None:
        runtime = _crewai_adapter_build_runtime()
        session = runtime.new_session()
        session.begin_turn()
        try:
            role = _bind_caller_agent_if_present(session)
            assert role is None
            state = session.read_variable('caller_agent')
            if state is not None:
                assert state.status == 'unset' or state.value is None
        finally:
            session.end_turn()

class TestCrewaiAdapterKickoffBindsUserInput:
    """regression — ``kickoff()`` populates ``@context.user_input``."""

    def test_kickoff_blocks_competitor_brief_via_context_user_input(self) -> None:
        """Stage 1 policy reading ``@context.user_input`` now fires."""
        runtime = _crewai_adapter_build_runtime()
        crew = _CrewaiAdapterFakeCrew(output='ignored')
        guarded = GuardedCrew(runtime, crew)
        result = guarded.kickoff(inputs={'topic': 'Here is a competitor brief about Acme Corp.'})
        assert isinstance(result, str)
        assert 'Competitor brief detected' in result
        assert crew.kickoff_calls == [], 'Stage 1 must short-circuit BEFORE crew.kickoff runs.'

    def test_kickoff_allows_benign_input(self) -> None:
        runtime = _crewai_adapter_build_runtime()
        crew = _CrewaiAdapterFakeCrew(output='OK')
        guarded = GuardedCrew(runtime, crew)
        result = guarded.kickoff(inputs={'topic': 'Discuss the weather.'})
        assert result == 'OK'
        assert len(crew.kickoff_calls) == 1

    def test_session_request_context_carries_user_input(self) -> None:
        """The fresh per-kickoff session sees the input as @context.user_input."""
        runtime = _crewai_adapter_build_runtime()
        captured: dict[str, Any] = {}

        def _capture() -> None:
            sess = current_session.get(None)
            assert sess is not None
            captured['session'] = sess
        crew = _CrewaiAdapterFakeCrew(output='OK', side_effect=_capture)
        guarded = GuardedCrew(runtime, crew)
        guarded.kickoff(inputs={'topic': 'Tell me a joke.'})
        assert 'session' in captured

class TestCrewaiAdapterProtectToolsBindsCallerAgent:
    """regression — protected tools bind ``caller_agent`` before Stage 2/3."""

    def _run_protected_tool_as(self, role: str, runtime: Any, tool: _CrewaiAdapterFakeTool) -> Any:
        """Invoke a guarded tool inside a synthetic ToolUsage frame."""
        guarded_tools = protect_tools(runtime, [tool])
        assert len(guarded_tools) == 1
        guarded = guarded_tools[0]
        session = runtime.new_session()
        session.begin_turn()
        try:
            token = current_session.set(session)
            try:
                agent = _CrewaiAdapterFakeCrewAgent(role=role)
                usage = ToolUsage(agent)
                return usage.dispatch(lambda: guarded._run())
            finally:
                current_session.reset(token)
        finally:
            session.end_turn()

    def test_editor_call_passes_editor_only_gate(self) -> None:
        runtime = _crewai_adapter_build_runtime()
        tool = _CrewaiAdapterFakeTool(name='publish_draft')
        result = self._run_protected_tool_as('Editor', runtime, tool)
        assert result == 'publish_draft-ran'
        assert tool.calls == [{}]

    def test_writer_call_is_blocked_by_editor_only_gate(self) -> None:
        runtime = _crewai_adapter_build_runtime()
        tool = _CrewaiAdapterFakeTool(name='publish_draft')
        with pytest.raises(AgentShieldBlocked) as exc_info:
            self._run_protected_tool_as('Writer', runtime, tool)
        assert exc_info.value.tool_name == 'publish_draft'
        assert 'Only the Editor agent may call publish_draft.' in exc_info.value.message
        assert tool.calls == [], 'Stage 3 must short-circuit BEFORE the underlying tool runs.'

    def test_unrecognised_role_is_blocked_by_editor_only_gate(self) -> None:
        runtime = _crewai_adapter_build_runtime()
        tool = _CrewaiAdapterFakeTool(name='publish_draft')
        with pytest.raises(AgentShieldBlocked) as exc_info:
            self._run_protected_tool_as('Reviewer', runtime, tool)
        assert 'Only the Editor agent may call publish_draft.' in exc_info.value.message
        assert tool.calls == []

class TestCrewaiAdapterFailClosedWhenCallerAgentUnset:
    """When no CrewAI agent is on the stack, the gate fail-closes."""

    def test_protected_tool_blocked_when_no_agent_frame(self) -> None:
        """A guarded tool called outside any CrewAI ToolUsage fails closed.

        The stack walker returns ``None`` so ``caller_agent`` is left
        unset; ``caller_agent == 'Editor'`` resolves to ``false`` per
        the behavior contract null semantics; Stage 3 raises ``AgentShieldBlocked``
        (regression).
        """
        runtime = _crewai_adapter_build_runtime()
        tool = _CrewaiAdapterFakeTool(name='publish_draft')
        guarded_tools = protect_tools(runtime, [tool])
        guarded = guarded_tools[0]
        session = runtime.new_session()
        session.begin_turn()
        try:
            token = current_session.set(session)
            try:
                with pytest.raises(AgentShieldBlocked) as exc_info:
                    guarded._run()
            finally:
                current_session.reset(token)
        finally:
            session.end_turn()
        assert 'Only the Editor agent may call publish_draft.' in exc_info.value.message
        assert tool.calls == []

    def test_protected_tool_outside_session_raises_unguarded(self) -> None:
        """Independent of regression, regression fail-closed still applies."""
        runtime = _crewai_adapter_build_runtime()
        tool = _CrewaiAdapterFakeTool(name='publish_draft')
        guarded_tools = protect_tools(runtime, [tool])
        guarded = guarded_tools[0]
        with pytest.raises(UnguardedToolInvocation):
            guarded._run()
_crewai_adapter_Case_FIXTURE = str(_crewai_adapter_REPO_ROOT / 'sdk' / 'python' / 'tests' / 'fixtures_smoke' / 'crewai_kyc_raw_result.guardrails.yaml')

def _crewai_adapter_build_f42_runtime() -> Any:
    return RuntimeBuilder.from_yaml(_crewai_adapter_Case_FIXTURE).build()

class _CrewaiAdapterDictReturningTool:
    """Tool whose ``_run`` returns a plain Python dict.

    Mirrors the regression scenario: ``verify_identity`` returns a dict
    with ``kyc_token``; the adapter must hand that raw dict to
    Stage 4 so the populator can extract ``@result.kyc_token``.
    """

    def __init__(self, name: str='verify_identity', payload: dict | None=None) -> None:
        self.name = name
        self.description = f'dict-returning tool {name}'
        self.args_schema = None
        self.calls: list[dict] = []
        self._payload = payload or {'kyc_token': 'tok-abc', 'score': 12}

    def _run(self, **kwargs: Any) -> Any:
        self.calls.append(kwargs)
        return dict(self._payload)

class _CrewaiAdapterPydanticReturningTool:
    """Tool whose ``_run`` returns a Pydantic ``BaseModel`` instance.

    Mirrors AutoGen's regression path: the adapter must normalise the
    model via ``model_dump(mode="json")`` before handing it to
    Stage 4, so populators like ``@result.kyc_token`` resolve.
    """

    def __init__(self, name: str='verify_identity') -> None:
        self.name = name
        self.description = f'pydantic-returning tool {name}'
        self.args_schema = None
        from pydantic import BaseModel

        class _KycResult(BaseModel):
            kyc_token: str
            score: int
        self._cls = _KycResult
        self.calls: list[dict] = []

    def _run(self, **kwargs: Any) -> Any:
        self.calls.append(kwargs)
        return self._cls(kyc_token='tok-xyz', score=7)

class TestCrewaiAdapterCreateCrewaiAgentReturnsNativeAgent:
    """regression — ``Shield.create_crewai_agent`` returns a native Agent.

    Before the fix the helper returned a custom ``GuardedAgent``
    wrapper. CrewAI's ``Task`` / ``Crew`` constructors validate
    inputs through Pydantic and reject non-Agent objects with
    ``AttributeError: 'Agent' object has no attribute 'get'``.
    """

    def _shield(self) -> Any:
        from agent_shield import Shield
        return Shield.from_yaml(_crewai_adapter_Case_FIXTURE, auto_bind=False).with_crewai().build()

    def test_returns_native_crewai_agent_instance(self) -> None:
        from crewai import Agent
        shield = self._shield()
        tool = _CrewaiAdapterFakeTool(name='verify_identity')
        agent = shield.create_crewai_agent([tool], role='KycAgent', goal='Verify identity', backstory='A KYC specialist', llm='gpt-4o')
        assert isinstance(agent, Agent), 'regression — create_crewai_agent MUST return a native crewai.Agent so Task/Crew Pydantic constructors accept it.'
        assert agent.role == 'KycAgent'
        assert len(agent.tools) == 1
        assert agent.tools[0] is not tool

    def test_task_accepts_native_agent(self) -> None:
        """``Task(agent=<agent>)`` MUST validate without AttributeError."""
        from crewai import Task
        shield = self._shield()
        tool = _CrewaiAdapterFakeTool(name='verify_identity')
        agent = shield.create_crewai_agent([tool], role='KycAgent', goal='Verify identity', backstory='A KYC specialist', llm='gpt-4o')
        task = Task(description="Verify the user's identity", expected_output='A KYC token', agent=agent)
        assert task.agent is agent

    def test_crew_accepts_native_agent(self) -> None:
        """``Crew(agents=[<agent>], ...)`` MUST validate without error."""
        from crewai import Crew, Task
        shield = self._shield()
        tool = _CrewaiAdapterFakeTool(name='verify_identity')
        agent = shield.create_crewai_agent([tool], role='KycAgent', goal='Verify identity', backstory='A KYC specialist', llm='gpt-4o')
        task = Task(description="Verify the user's identity", expected_output='A KYC token', agent=agent)
        crew = Crew(agents=[agent], tasks=[task])
        assert agent in crew.agents

class TestCrewaiAdapterBlockedToolRaisesAndEmitsIncident:
    """regression — Stage 3 block raises and emits ``incident.tool_blocked``.

    The pre-fix shape returned the block message as the tool's
    normal observation string. CrewAI fed that to the LLM, which
    confidently produced a final answer that contradicted the
    block — a SILENT BYPASS. The fix raises
    :class:`AgentShieldBlocked` AND emits
    ``incident.tool_blocked`` on the session so YAML Stage 5
    policies can gate the final answer on whether any guarded
    tool was blocked this turn.
    """

    def test_blocked_tool_raises_agent_shield_blocked(self) -> None:
        runtime = _crewai_adapter_build_runtime()
        tool = _CrewaiAdapterFakeTool(name='publish_draft')
        guarded_tools = protect_tools(runtime, [tool])
        guarded = guarded_tools[0]
        session = runtime.new_session()
        session.begin_turn()
        try:
            token = current_session.set(session)
            try:
                with pytest.raises(AgentShieldBlocked) as exc_info:
                    guarded._run()
            finally:
                current_session.reset(token)
        finally:
            session.end_turn()
        assert exc_info.value.tool_name == 'publish_draft'
        assert '[GUARDRAIL BLOCK]' in exc_info.value.message
        assert tool.calls == [], 'regression — Stage 3 MUST short-circuit BEFORE the underlying tool runs.'

    def test_blocked_tool_emits_incident_event(self) -> None:
        """``incident.tool_blocked`` is emitted with structured payload.

        Verified end-to-end by latching the event on the session
        and asserting a follow-up Stage 5 policy that reads
        ``event.fired("incident.tool_blocked")`` observes it.
        """
        import textwrap
        yaml_src = textwrap.dedent('            metadata:\n              name: "f42-5-incident-event"\n              version: "0.1.0"\n              agent_shield_version: "2.0"\n            objective:\n              goal: ["Test"]\n              forbidden: ["nothing"]\n            resources:\n              tools:\n                - name: "publish_draft"\n                  description: "publish"\n                  permission: "destructive"\n            variables:\n              - name: "caller_agent"\n                type: "string"\n            tool_execution_validation:\n              guard_policies:\n                - name: "editor_only_publish"\n                  applies_to:\n                    tools: ["publish_draft"]\n                  allowed_when: \'caller_agent == "Editor"\'\n                  action: "block"\n                  evaluate_when:\n                    - expression: "false"\n                      reason: "Only the Editor agent may call publish_draft."\n            output_validation:\n              guard_policies:\n                - name: "block_on_tool_blocked_incident"\n                  description: >\n                    Stage 5 fail-closed when any tool was blocked\n                    this turn — gates the final answer on the\n                    incident.tool_blocked event the CrewAI adapter\n                    emits in _GuardedTool._run after regression.\n                  action: "block"\n                  evaluate_when:\n                    - expression: \'not @event.fired("incident.tool_blocked")\'\n                      reason: "A guarded tool was blocked this turn."\n            ')
        scratch = TESTS_ROOT / '.agent_shield_scratch'
        scratch.mkdir(exist_ok=True)
        fixture_path = scratch / 'f42_5_incident.guardrails.yaml'
        fixture_path.write_text(yaml_src)
        try:
            runtime = RuntimeBuilder.from_yaml(str(fixture_path)).build()
            tool = _CrewaiAdapterFakeTool(name='publish_draft')
            guarded_tools = protect_tools(runtime, [tool])
            guarded = guarded_tools[0]
            session = runtime.new_session()
            session.begin_turn()
            try:
                token = current_session.set(session)
                try:
                    with pytest.raises(AgentShieldBlocked):
                        guarded._run()
                finally:
                    current_session.reset(token)
                outcome = session.validate_output('Approved.')
                assert outcome.verdict.action == 'block', "regression — Stage 5 referencing event.fired('incident.tool_blocked') MUST observe the event the adapter emitted on block."
            finally:
                session.end_turn()
        finally:
            try:
                fixture_path.unlink()
                scratch.rmdir()
            except OSError:
                pass

class TestCrewaiAdapterDictAndPydanticReturnSurvivesStage4:
    """regression — tool returns survive Stage 4 as raw Python values.

    The post-tool variable engine extracts ``@result.X`` against
    the tool return. CrewAI's ``BaseTool._run`` historically
    stringified the return (Python repr; ``True`` not ``true``;
    single-quoted) so populators couldn't extract anything from
    a dict-returning tool. The fix:

    * ``_ToolWrapper.invoke`` returns the raw value (or
      ``model_dump(mode="json")`` for Pydantic models).
    * ``guarded_tool`` (with ``preserve_raw_result=True``)
      forwards the raw shape to ``validate_tool_output``.
    * ``_run`` (with ``tool_wrapper_preserve_raw_result=True``)
      returns the raw shape to the customer pipeline.
    """

    def test_dict_return_populates_at_result_variable(self) -> None:
        runtime = _crewai_adapter_build_f42_runtime()
        tool = _CrewaiAdapterDictReturningTool(name='verify_identity', payload={'kyc_token': 'tok-abc', 'score': 12})
        guarded_tools = protect_tools(runtime, [tool])
        guarded = guarded_tools[0]
        session = runtime.new_session()
        session.begin_turn()
        try:
            token = current_session.set(session)
            try:
                result = guarded._run()
            finally:
                current_session.reset(token)
            assert isinstance(result, dict), f'regression — _run MUST return the raw dict; got {type(result).__name__}: {result!r}'
            assert result == {'kyc_token': 'tok-abc', 'score': 12}
            kyc = session.read_variable('kyc_token')
            assert kyc.value == 'tok-abc', 'regression — @result.kyc_token populator MUST extract from the raw dict; pre-fix the variable stayed unset because the dict was stringified to Python repr.'
        finally:
            session.end_turn()

    def test_pydantic_return_populates_at_result_variable(self) -> None:
        pytest.importorskip('pydantic')
        runtime = _crewai_adapter_build_f42_runtime()
        tool = _CrewaiAdapterPydanticReturningTool(name='verify_identity')
        guarded_tools = protect_tools(runtime, [tool])
        guarded = guarded_tools[0]
        session = runtime.new_session()
        session.begin_turn()
        try:
            token = current_session.set(session)
            try:
                result = guarded._run()
            finally:
                current_session.reset(token)
            assert isinstance(result, dict), f'regression — Pydantic return MUST be dumped to dict; got {type(result).__name__}: {result!r}'
            assert result['kyc_token'] == 'tok-xyz'
            assert result['score'] == 7
            kyc = session.read_variable('kyc_token')
            assert kyc.value == 'tok-xyz', "regression — populator extraction against a Pydantic return MUST resolve through model_dump(mode='json')."
        finally:
            session.end_turn()

    def test_dict_return_unlocks_state_validation_gate(self) -> None:
        """End-to-end: dict-returning tool unlocks downstream Stage 3."""
        runtime = _crewai_adapter_build_f42_runtime()
        verify = _CrewaiAdapterDictReturningTool(name='verify_identity', payload={'kyc_token': 'tok-end-to-end', 'score': 5})
        approve = _CrewaiAdapterFakeTool(name='approve_payment')
        guarded_verify, guarded_approve = protect_tools(runtime, [verify, approve])
        session = runtime.new_session()
        session.begin_turn()
        try:
            token = current_session.set(session)
            try:
                pre_outcome = session.validate_tool_call('approve_payment', {})
                assert pre_outcome.verdict.action == 'block', 'Sanity: approve_payment MUST block before verify_identity populates kyc_token.'
                guarded_verify._run()
                post_outcome = session.validate_tool_call('approve_payment', {})
                assert post_outcome.verdict.action != 'block', "regression end-to-end — after verify_identity's dict return populates kyc_token, Stage 3 MUST allow approve_payment. Pre-fix the dict was stringified to Python repr, @result.kyc_token couldn't extract, kyc_token stayed unset, and the bypass failed."
            finally:
                current_session.reset(token)
        finally:
            session.end_turn()
