"""Behavior tests consolidated into behavior/test_adapters_anthropic.py."""
from __future__ import annotations
from .._support.paths import REPO_ROOT
from typing import Any, List, Optional
from unittest.mock import MagicMock
import pytest
from agent_shield import RuntimeBuilder
from agent_shield.adapters._capabilities import ConfigurationMissingModelError
from agent_shield.adapters.anthropic_agents import _LlmCallerFactory, make_llm_caller
_anthropic_agents_llm_caller_model_MULTI_CONFIG_YAML = '\nmetadata:\n  name: anthropic-llm-caller-model-fixture\n  version: 0.1.0\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["exercise configurations[] routing"]\n  forbidden: ["bypass"]\nconfigurations:\n  - id: stage1-judge\n    type: llm\n    provider: anthropic.messages\n    model: claude-3-5-sonnet-latest\n    max_tokens: 256\n  - id: stage3-judge\n    type: llm\n    provider: anthropic.messages\n    model: claude-3-haiku-20240307\ninput_validation:\n  guard_policies:\n    - name: trivial_input_guard\n      evaluate_when:\n        - patterns: ["jailbreak"]\n          reason: "jailbreak attempt"\n      action: "block"\n'

class _AnthropicAgentsLlmCallerModelRecordingMessages:
    """Stand-in for ``client.messages`` that records every ``create`` call."""

    def __init__(self) -> None:
        self.calls: List[dict] = []

    def create(self, **kwargs: Any) -> Any:
        self.calls.append(kwargs)
        block = MagicMock()
        block.text = 'ok'
        result = MagicMock()
        result.content = [block]
        return result

class _AnthropicAgentsLlmCallerModelFakeAnthropicClient:
    """Minimal sync Anthropic-shaped client (no ``Async`` in the class name)."""

    def __init__(self) -> None:
        self.messages = _AnthropicAgentsLlmCallerModelRecordingMessages()

def _anthropic_agents_llm_caller_model_build_runtime(yaml_str: str):
    import tempfile
    fd, path = tempfile.mkstemp(suffix='.yaml')
    try:
        with os.fdopen(fd, 'w') as fh:
            fh.write(yaml_str)
        return RuntimeBuilder.from_yaml(path).build()
    finally:
        os.unlink(path)

def test_anthropic_agents_llm_caller_model__llm_configuration_returns_yaml_model_for_known_id():
    rt = _anthropic_agents_llm_caller_model_build_runtime(_anthropic_agents_llm_caller_model_MULTI_CONFIG_YAML)
    cfg = rt.llm_configuration('stage1-judge')
    assert cfg is not None
    assert cfg['id'] == 'stage1-judge'
    assert cfg['type'] == 'llm'
    assert cfg['model'] == 'claude-3-5-sonnet-latest'
    assert cfg.get('max_tokens') == 256

def test_anthropic_agents_llm_caller_model__llm_configuration_returns_none_for_unknown_id():
    rt = _anthropic_agents_llm_caller_model_build_runtime(_anthropic_agents_llm_caller_model_MULTI_CONFIG_YAML)
    assert rt.llm_configuration('does-not-exist') is None

def test_anthropic_agents_llm_caller_model__caller_uses_yaml_model_for_each_configuration_id():
    rt = _anthropic_agents_llm_caller_model_build_runtime(_anthropic_agents_llm_caller_model_MULTI_CONFIG_YAML)
    client = _AnthropicAgentsLlmCallerModelFakeAnthropicClient()
    caller = make_llm_caller(client, configuration_resolver=rt.llm_configuration)
    caller('stage1-judge', 'is the input safe?')
    caller('stage3-judge', 'is the tool call safe?')
    messages = client.messages
    assert len(messages.calls) == 2
    assert messages.calls[0]['model'] == 'claude-3-5-sonnet-latest'
    assert messages.calls[0]['max_tokens'] == 256
    assert messages.calls[1]['model'] == 'claude-3-haiku-20240307'
    assert messages.calls[1]['max_tokens'] == _LlmCallerFactory.DEFAULT_FALLBACK_MAX_TOKENS

def test_anthropic_agents_llm_caller_model__caller_raises_when_no_matching_configuration():
    """Missing configuration: a security library MUST raise rather
    than silently picking a model on the customer's behalf."""
    rt = _anthropic_agents_llm_caller_model_build_runtime(_anthropic_agents_llm_caller_model_MULTI_CONFIG_YAML)
    client = _AnthropicAgentsLlmCallerModelFakeAnthropicClient()
    caller = make_llm_caller(client, configuration_resolver=rt.llm_configuration)
    with pytest.raises(ConfigurationMissingModelError) as exc_info:
        caller('not-in-yaml', 'judge me')
    assert 'not-in-yaml' in str(exc_info.value)
    assert len(client.messages.calls) == 0

def test_anthropic_agents_llm_caller_model__caller_raises_when_no_resolver_wired():
    client = _AnthropicAgentsLlmCallerModelFakeAnthropicClient()
    caller = make_llm_caller(client)
    with pytest.raises(ConfigurationMissingModelError):
        caller('stage1-judge', 'prompt')
    assert len(client.messages.calls) == 0

def test_anthropic_agents_llm_caller_model__caller_raises_when_configuration_id_is_none():
    rt = _anthropic_agents_llm_caller_model_build_runtime(_anthropic_agents_llm_caller_model_MULTI_CONFIG_YAML)
    client = _AnthropicAgentsLlmCallerModelFakeAnthropicClient()
    caller = make_llm_caller(client, configuration_resolver=rt.llm_configuration)
    with pytest.raises(ConfigurationMissingModelError) as exc_info:
        caller(None, 'prompt')
    assert '<unset>' in str(exc_info.value)

def test_anthropic_agents_llm_caller_model__caller_raises_when_resolver_raises():
    """Resolver exceptions surface as ConfigurationMissingModelError;
    a broken resolver is treated the same as "no entry"."""
    client = _AnthropicAgentsLlmCallerModelFakeAnthropicClient()

    def broken_resolver(_cid: Optional[str]) -> Optional[dict]:
        raise RuntimeError('boom')
    caller = make_llm_caller(client, configuration_resolver=broken_resolver)
    with pytest.raises(ConfigurationMissingModelError):
        caller('stage1-judge', 'prompt')
    assert len(client.messages.calls) == 0

def test_anthropic_agents_llm_caller_model__shield_builder_wires_resolver_through_build(tmp_path):
    """Shield.from_yaml(...).with_client(...).build() => caller honours YAML.

    Reaches into ``ShieldBuilder`` to grab the actually-wired LLM caller
    (the same closure ``RuntimeBuilder.register_llm_caller`` receives,
    which is what the Rust runtime invokes for every stage). Drives the
    closure directly and asserts the model came from the YAML.
    """
    from agent_shield.adapters._shield import ShieldBuilder
    yaml_path = tmp_path / 'guardrails.yaml'
    yaml_path.write_text(_anthropic_agents_llm_caller_model_MULTI_CONFIG_YAML)
    client = _AnthropicAgentsLlmCallerModelFakeAnthropicClient()
    builder = ShieldBuilder(str(yaml_path), auto_bind=False).with_anthropic_agents().with_client(client)
    shield = builder.build()
    bound_caller = builder._llm_caller
    assert bound_caller is not None
    bound_caller('stage1-judge', 'prompt')
    bound_caller('stage3-judge', 'prompt')
    messages = client.messages
    assert messages.calls[-2]['model'] == 'claude-3-5-sonnet-latest'
    assert messages.calls[-2]['max_tokens'] == 256
    assert messages.calls[-1]['model'] == 'claude-3-haiku-20240307'
    assert shield.runtime.llm_configuration('stage1-judge')['model'] == 'claude-3-5-sonnet-latest'
import os
import tempfile
_anthropic_agents_runner_construction_MIN_YAML = '\nmetadata:\n  name: anthropic-agents-runner-construction-fixture\n  version: 0.1.0\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["exercise BetaAsyncToolRunner construction"]\n  forbidden: ["bypass"]\n'

@pytest.fixture()
def _anthropic_agents_runner_construction_guardrails_path(tmp_path):
    p = tmp_path / 'guardrails.yaml'
    p.write_text(_anthropic_agents_runner_construction_MIN_YAML)
    return p

class _AnthropicAgentsRunnerConstructionFakeFinalMessage:
    """A stand-in for ``ParsedBetaMessage`` returned by ``get_final_message``."""

    def __init__(self) -> None:
        block = MagicMock()
        block.text = 'ok'
        self.content = [block]

class _AnthropicAgentsRunnerConstructionRecordingRunner:
    """Records ``BetaAsyncToolRunner.__init__`` kwargs for assertion.

    Mirrors only the surface the orchestrator touches:
    ``get_final_message``. The class is monkeypatched onto
    ``anthropic.lib.tools.BetaAsyncToolRunner`` so the adapter's
    ``from anthropic.lib.tools import BetaAsyncToolRunner`` picks it
    up.
    """
    calls: list[dict] = []

    def __init__(self, **kwargs: Any) -> None:
        _AnthropicAgentsRunnerConstructionRecordingRunner.calls.append(kwargs)

    async def get_final_message(self) -> Any:
        return _AnthropicAgentsRunnerConstructionFakeFinalMessage()

@pytest.fixture()
def _anthropic_agents_runner_construction_fake_runner(monkeypatch):
    _AnthropicAgentsRunnerConstructionRecordingRunner.calls = []
    import anthropic.lib.tools as _antools
    monkeypatch.setattr(_antools, 'BetaAsyncToolRunner', _AnthropicAgentsRunnerConstructionRecordingRunner)
    return _AnthropicAgentsRunnerConstructionRecordingRunner

@pytest.fixture()
def _anthropic_agents_runner_construction_shield_factory(_anthropic_agents_runner_construction_guardrails_path):
    from anthropic import AsyncAnthropic

    def _build():
        client = AsyncAnthropic(api_key='sk-placeholder')
        from agent_shield.adapters._shield import ShieldBuilder
        return ShieldBuilder(str(_anthropic_agents_runner_construction_guardrails_path), auto_bind=False).with_anthropic_agents().with_client(client).build()
    return _build

@pytest.mark.asyncio
async def test_anthropic_agents_runner_construction__run_constructs_runner_with_params_envelope(_anthropic_agents_runner_construction_shield_factory, _anthropic_agents_runner_construction_fake_runner):
    """``shield.create_anthropic_agents_agent(...).run(...)`` must call
    ``BetaAsyncToolRunner`` with ``params={"model": ..., "messages": ...,
    "max_tokens": ...}`` and ``options={}`` — not ``model=`` /
    ``messages=`` as top-level kwargs (which is the regression bug).
    """
    shield = _anthropic_agents_runner_construction_shield_factory()
    runner = shield.create_anthropic_agents_agent([], model='claude-sonnet-4-20250514', system_prompt='you are helpful')
    await runner.run('hello')
    assert len(_anthropic_agents_runner_construction_fake_runner.calls) == 1
    kw = _anthropic_agents_runner_construction_fake_runner.calls[0]
    assert set(kw) >= {'client', 'tools', 'params', 'options'}, f'missing required envelope keys; got {sorted(kw)}'
    for forbidden in ('model', 'messages', 'system', 'max_tokens'):
        assert forbidden not in kw, f'{forbidden!r} must live inside params=, not as a top-level runner kwarg (regression)'
    params = kw['params']
    assert isinstance(params, dict)
    assert params['model'] == 'claude-sonnet-4-20250514'
    assert params['messages'] == [{'role': 'user', 'content': 'hello'}]
    assert params['system'] == 'you are helpful'
    assert 'max_tokens' in params
    assert isinstance(params['max_tokens'], int)
    assert params['max_tokens'] > 0
    assert isinstance(kw['options'], dict)

@pytest.mark.asyncio
async def test_anthropic_agents_runner_construction__run_promotes_passthrough_kwargs_into_params(_anthropic_agents_runner_construction_shield_factory, _anthropic_agents_runner_construction_fake_runner):
    """Caller-supplied message-create kwargs (``temperature``,
    ``tool_choice``) ride inside ``params=``, not as top-level runner
    kwargs."""
    shield = _anthropic_agents_runner_construction_shield_factory()
    runner = shield.create_anthropic_agents_agent([], model='claude-sonnet-4-20250514')
    await runner.run('hi', temperature=0.2, tool_choice={'type': 'auto'})
    kw = _anthropic_agents_runner_construction_fake_runner.calls[-1]
    params = kw['params']
    assert params['temperature'] == 0.2
    assert params['tool_choice'] == {'type': 'auto'}
    assert 'temperature' not in kw
    assert 'tool_choice' not in kw

@pytest.mark.asyncio
async def test_anthropic_agents_runner_construction__run_routes_max_iterations_to_top_level(_anthropic_agents_runner_construction_shield_factory, _anthropic_agents_runner_construction_fake_runner):
    """``max_iterations`` is a *runner* knob (not a message-create
    field) and must stay at the top level."""
    shield = _anthropic_agents_runner_construction_shield_factory()
    runner = shield.create_anthropic_agents_agent([], model='claude-sonnet-4-20250514')
    await runner.run('hi', max_iterations=3)
    kw = _anthropic_agents_runner_construction_fake_runner.calls[-1]
    assert kw['max_iterations'] == 3
    assert 'max_iterations' not in kw['params']

@pytest.mark.asyncio
async def test_anthropic_agents_runner_construction__run_streamed_constructs_runner_with_params_envelope(_anthropic_agents_runner_construction_shield_factory, _anthropic_agents_runner_construction_fake_runner):
    """Streaming path goes through the same translation."""
    shield = _anthropic_agents_runner_construction_shield_factory()
    agent = shield.create_anthropic_agents_agent([], model='claude-sonnet-4-20250514', system_prompt='streaming hello')
    async for _ in agent.run_streamed('stream-me'):
        pass
    assert len(_anthropic_agents_runner_construction_fake_runner.calls) == 1
    kw = _anthropic_agents_runner_construction_fake_runner.calls[0]
    assert 'model' not in kw and 'messages' not in kw
    assert kw['params']['model'] == 'claude-sonnet-4-20250514'
    assert kw['params']['messages'] == [{'role': 'user', 'content': 'stream-me'}]
    assert kw['params']['system'] == 'streaming hello'

@pytest.mark.asyncio
async def test_anthropic_agents_runner_construction__no_typeerror_on_construction(_anthropic_agents_runner_construction_shield_factory, _anthropic_agents_runner_construction_fake_runner):
    """Direct repro of regression's TypeError:
    ``BaseAsyncToolRunner.__init__() got an unexpected keyword
    argument 'model'``. Must not raise."""
    shield = _anthropic_agents_runner_construction_shield_factory()
    runner = shield.create_anthropic_agents_agent([], model='claude-sonnet-4-20250514')
    result = await runner.run('hi')
    assert result is not None
import asyncio
from pathlib import Path
_anthropic_dict_tools_PASSTHROUGH_YAML = '\nmetadata:\n  name: anthropic-dict-tools-passthrough\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["dispatch dict tools with no guardrail gates firing"]\nresources:\n  tools:\n    - name: lookup_customer\n      permission: read_only\n'
_anthropic_dict_tools_REDACT_YAML = '\nmetadata:\n  name: anthropic-dict-tools-redact\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["redact PII passed to lookup_customer"]\nresources:\n  tools:\n    - name: lookup_customer\n      permission: read_only\ntool_execution_validation:\n  guard_policies:\n    - name: pii_scrub\n      applies_to: { tools: ["lookup_customer"] }\n      action: redact\n      replacement: "[PII]"\n      evaluate_when:\n        - patterns:\n            - \'\\b\\d{3}-\\d{2}-\\d{4}\\b\'\n          reason: "SSN-shaped value in tool args."\n'
_anthropic_dict_tools_HUMAN_APPROVAL_YAML = '\nmetadata:\n  name: anthropic-dict-tools-human-approval\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["require human approval before executing trades"]\n  forbidden: ["skip approval"]\nresources:\n  tools:\n    - name: execute_trade\n      description: "Place a trade."\n      permission: execute\nvariables:\n  - name: trade_authorized\n    type: boolean\n    on_demand_by:\n      kind: human\n      prompt: "Authorize this trade?"\n    lifetime: per_session\nstate_validation:\n  guard_policies:\n    - name: trade_requires_authorization\n      applies_to:\n        tools: ["execute_trade"]\n      evaluate_when:\n        - expression: "trade_authorized == true"\n          reason: "Trade was not authorized."\n      action: block\n'

def _anthropic_dict_tools_write_yaml(yaml: str) -> str:
    f = tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False)
    f.write(yaml)
    f.close()
    return f.name

def _anthropic_dict_tools_build_shield(yaml: str):
    from agent_shield import Shield
    path = _anthropic_dict_tools_write_yaml(yaml)
    shield = Shield.from_yaml(path, auto_bind=False).with_anthropic_agents().build()
    return (shield, path)
_anthropic_dict_tools_LOOKUP_TOOL_DICT = {'name': 'lookup_customer', 'description': 'Look up customer details by ID.', 'input_schema': {'type': 'object', 'properties': {'customer_id': {'type': 'string'}}, 'required': ['customer_id']}}
_anthropic_dict_tools_TRADE_TOOL_DICT = {'name': 'execute_trade', 'description': 'Place a trade for the given account.', 'input_schema': {'type': 'object', 'properties': {'account_id': {'type': 'string'}, 'ticker': {'type': 'string'}, 'qty': {'type': 'integer'}, 'side': {'type': 'string'}}, 'required': ['account_id', 'ticker', 'qty', 'side']}}

class TestAnthropicDictToolsOriginalBugMessage:

    def test_protect_tools_dict_raises_actionable_typeerror(self):
        shield, path = _anthropic_dict_tools_build_shield(_anthropic_dict_tools_PASSTHROUGH_YAML)
        try:
            with pytest.raises(TypeError) as excinfo:
                shield.protect_tools([_anthropic_dict_tools_LOOKUP_TOOL_DICT])
            msg = str(excinfo.value)
            assert 'protect_anthropic_tools' in msg
            assert 'dispatch' in msg
            assert "object has no attribute 'name'" not in msg
        finally:
            Path(path).unlink()

class TestAnthropicDictToolsProtectAnthropicTools:

    def test_allow_passes_dispatch_result_through(self):
        shield, path = _anthropic_dict_tools_build_shield(_anthropic_dict_tools_PASSTHROUGH_YAML)
        try:
            calls: list[tuple[str, dict]] = []

            def dispatch(name: str, params: dict) -> dict:
                calls.append((name, dict(params)))
                return {'name': 'Acme Inc', 'id': params['customer_id']}
            guarded_dispatch = shield.protect_anthropic_tools([_anthropic_dict_tools_LOOKUP_TOOL_DICT], dispatch)
            from agent_shield.adapters._orchestration import current_session
            sess = shield.runtime.new_session()
            sess.begin_turn()
            token = current_session.set(sess)
            try:
                result = asyncio.run(guarded_dispatch('lookup_customer', {'customer_id': 'c-1'}))
            finally:
                current_session.reset(token)
                sess.end_turn()
            assert calls == [('lookup_customer', {'customer_id': 'c-1'})]
            assert 'Acme Inc' in result and 'c-1' in result
            assert shield.last_pending_resolution() is None
        finally:
            Path(path).unlink()

    def test_async_dispatch_callable_is_awaited(self):
        shield, path = _anthropic_dict_tools_build_shield(_anthropic_dict_tools_PASSTHROUGH_YAML)
        try:

            async def dispatch(name: str, params: dict) -> dict:
                await asyncio.sleep(0)
                return {'name': 'Async Inc', 'id': params['customer_id']}
            guarded_dispatch = shield.protect_anthropic_tools([_anthropic_dict_tools_LOOKUP_TOOL_DICT], dispatch)
            from agent_shield.adapters._orchestration import current_session
            sess = shield.runtime.new_session()
            sess.begin_turn()
            token = current_session.set(sess)
            try:
                result = asyncio.run(guarded_dispatch('lookup_customer', {'customer_id': 'c-2'}))
            finally:
                current_session.reset(token)
                sess.end_turn()
            assert result == "{'name': 'Async Inc', 'id': 'c-2'}" or ('Async Inc' in result and 'c-2' in result)
        finally:
            Path(path).unlink()

    def test_missing_dispatch_raises(self):
        shield, path = _anthropic_dict_tools_build_shield(_anthropic_dict_tools_PASSTHROUGH_YAML)
        try:
            with pytest.raises(ValueError) as excinfo:
                shield.protect_anthropic_tools([_anthropic_dict_tools_LOOKUP_TOOL_DICT], None)
            assert 'dispatch' in str(excinfo.value)
        finally:
            Path(path).unlink()

    def test_unknown_tool_raises_keyerror(self):
        shield, path = _anthropic_dict_tools_build_shield(_anthropic_dict_tools_PASSTHROUGH_YAML)
        try:

            def dispatch(name: str, params: dict) -> dict:
                return {}
            guarded_dispatch = shield.protect_anthropic_tools([_anthropic_dict_tools_LOOKUP_TOOL_DICT], dispatch)
            from agent_shield.adapters._orchestration import current_session
            sess = shield.runtime.new_session()
            sess.begin_turn()
            token = current_session.set(sess)
            try:
                with pytest.raises(KeyError):
                    asyncio.run(guarded_dispatch('unknown_tool', {}))
            finally:
                current_session.reset(token)
                sess.end_turn()
        finally:
            Path(path).unlink()

class TestAnthropicDictToolsStage3RedactMutates:

    def test_redact_mutates_params_passed_to_dispatch(self):
        shield, path = _anthropic_dict_tools_build_shield(_anthropic_dict_tools_REDACT_YAML)
        try:
            captured: dict[str, Any] = {}

            def dispatch(name: str, params: dict) -> str:
                captured['params'] = dict(params)
                return 'ok'
            guarded_dispatch = shield.protect_anthropic_tools([_anthropic_dict_tools_LOOKUP_TOOL_DICT], dispatch)
            from agent_shield.adapters._orchestration import current_session
            sess = shield.runtime.new_session()
            sess.begin_turn()
            token = current_session.set(sess)
            try:
                result = asyncio.run(guarded_dispatch('lookup_customer', {'customer_id': 'SSN 123-45-6789 in id'}))
            finally:
                current_session.reset(token)
                sess.end_turn()
            assert 'params' in captured, 'dispatch must have been called'
            serialized = repr(captured['params'])
            assert '123-45-6789' not in serialized, f'Stage 3 verdict reported action=redact but the raw SSN survived in the params passed to dispatch: {serialized}'
            assert '[PII]' in serialized
            assert result == 'ok'
        finally:
            Path(path).unlink()

class TestAnthropicDictToolsPendingResolutionSurfaced:

    def test_human_approval_block_exposes_pending_resolution(self):
        shield, path = _anthropic_dict_tools_build_shield(_anthropic_dict_tools_HUMAN_APPROVAL_YAML)
        try:

            def dispatch(name: str, params: dict) -> str:
                raise AssertionError('underlying dispatch must not run on Stage 3 block')
            guarded_dispatch = shield.protect_anthropic_tools([_anthropic_dict_tools_TRADE_TOOL_DICT], dispatch)
            from agent_shield.adapters._orchestration import current_session
            sess = shield.runtime.new_session()
            sess.begin_turn()
            token = current_session.set(sess)
            try:
                result = asyncio.run(guarded_dispatch('execute_trade', {'account_id': 'A-123', 'ticker': 'MSFT', 'qty': 10, 'side': 'buy'}))
            finally:
                current_session.reset(token)
                sess.end_turn()
            assert isinstance(result, str)
            assert 'GUARDRAIL' in result or 'blocked' in result.lower()
            assert shield.last_pending_resolution() is None
        finally:
            Path(path).unlink()

class _AnthropicDictToolsFakeBuiltinTool:
    """Stand-in for BetaAsyncBuiltinFunctionTool with the duck-typed
    surface ``_ToolWrapper`` reads: ``.name``, ``.description``,
    ``.to_dict()``, async ``.call(input=...)``."""

    def __init__(self, name: str, fn):
        self.name = name
        self.description = f'{name} tool'
        self._fn = fn

    def to_dict(self) -> dict:
        return {'name': self.name, 'description': self.description}

    async def call(self, *, input):
        return self._fn(**input or {})

class TestAnthropicDictToolsBackwardCompat:

    def test_object_shape_still_wraps_via_protect_tools(self):
        shield, path = _anthropic_dict_tools_build_shield(_anthropic_dict_tools_PASSTHROUGH_YAML)
        try:
            calls: list[dict] = []

            def lookup(customer_id: str) -> dict:
                calls.append({'customer_id': customer_id})
                return {'name': 'Object Inc', 'id': customer_id}
            obj = _AnthropicDictToolsFakeBuiltinTool('lookup_customer', lookup)
            wrapped = shield.protect_tools([obj])
            assert len(wrapped) == 1
            assert wrapped[0].name == 'lookup_customer'
            from agent_shield.adapters._orchestration import current_session
            sess = shield.runtime.new_session()
            sess.begin_turn()
            token = current_session.set(sess)
            try:
                result = asyncio.run(wrapped[0].call(input={'customer_id': 'c-9'}))
            finally:
                current_session.reset(token)
                sess.end_turn()
            assert calls == [{'customer_id': 'c-9'}]
            assert result == "{'name': 'Object Inc', 'id': 'c-9'}" or ('Object Inc' in result and 'c-9' in result)
        finally:
            Path(path).unlink()

class _AnthropicDictToolsFakeToolUseBlock:
    type = 'tool_use'

    def __init__(self, id: str, name: str, input: dict):
        self.id = id
        self.name = name
        self.input = input

class _AnthropicDictToolsFakeTextBlock:
    type = 'text'

    def __init__(self, text: str):
        self.text = text

class _AnthropicDictToolsFakeMessage:

    def __init__(self, *, content: list, stop_reason: str):
        self.content = content
        self.stop_reason = stop_reason

class _AnthropicDictToolsFakeMessages:

    def __init__(self, scripted: list):
        self._scripted = list(scripted)
        self.calls: list[dict] = []

    def create(self, **kwargs):
        self.calls.append(kwargs)
        if not self._scripted:
            raise AssertionError('FakeMessages: ran out of scripted responses')
        content, stop_reason = self._scripted.pop(0)
        return _AnthropicDictToolsFakeMessage(content=content, stop_reason=stop_reason)

class _AnthropicDictToolsFakeAnthropic:

    def __init__(self, scripted: list):
        self.messages = _AnthropicDictToolsFakeMessages(scripted)

class TestAnthropicDictToolsRunAnthropicAgent:

    def test_full_loop_dispatches_and_returns_final_message(self):
        shield, path = _anthropic_dict_tools_build_shield(_anthropic_dict_tools_PASSTHROUGH_YAML)
        try:
            calls: list[tuple[str, dict]] = []

            def dispatch(name: str, params: dict) -> dict:
                calls.append((name, dict(params)))
                return {'name': 'Acme Inc', 'id': params['customer_id']}
            client = _AnthropicDictToolsFakeAnthropic([([_AnthropicDictToolsFakeToolUseBlock('tu_1', 'lookup_customer', {'customer_id': 'c-42'})], 'tool_use'), ([_AnthropicDictToolsFakeTextBlock('Customer is Acme Inc.')], 'end_turn')])
            result = asyncio.run(shield.run_anthropic_agent(client=client, model='claude-sonnet-4-20250514', tools=[_anthropic_dict_tools_LOOKUP_TOOL_DICT], dispatch=dispatch, messages=[{'role': 'user', 'content': 'Who is c-42?'}], max_tokens=512))
            assert calls == [('lookup_customer', {'customer_id': 'c-42'})]
            assert 'tools' in client.messages.calls[0]
            assert client.messages.calls[0]['tools'] == [_anthropic_dict_tools_LOOKUP_TOOL_DICT]
            second = client.messages.calls[1]
            roles = [m['role'] for m in second['messages']]
            assert roles == ['user', 'assistant', 'user']
            tool_results = second['messages'][2]['content']
            assert tool_results[0]['type'] == 'tool_result'
            assert tool_results[0]['tool_use_id'] == 'tu_1'
            assert getattr(result, 'stop_reason', None) == 'end_turn'
            assert shield.last_pending_resolution() is None
        finally:
            Path(path).unlink()

    def test_run_anthropic_agent_human_block_surfaces_pending_resolution(self):
        shield, path = _anthropic_dict_tools_build_shield(_anthropic_dict_tools_HUMAN_APPROVAL_YAML)
        try:

            def dispatch(name: str, params: dict) -> str:
                raise AssertionError('underlying dispatch must not run on Stage 3 block')
            client = _AnthropicDictToolsFakeAnthropic([([_AnthropicDictToolsFakeToolUseBlock('tu_1', 'execute_trade', {'account_id': 'A-1', 'ticker': 'MSFT', 'qty': 10, 'side': 'buy'})], 'tool_use'), ([_AnthropicDictToolsFakeTextBlock('Trade blocked.')], 'end_turn')])
            asyncio.run(shield.run_anthropic_agent(client=client, model='claude-sonnet-4-20250514', tools=[_anthropic_dict_tools_TRADE_TOOL_DICT], dispatch=dispatch, messages=[{'role': 'user', 'content': 'Place a trade for MSFT'}], max_tokens=512))
            assert shield.last_pending_resolution() is None
        finally:
            Path(path).unlink()
from unittest import mock
from agent_shield import Shield, ShieldBuilder
_with_anthropic_alias_REPO_ROOT = REPO_ROOT
_with_anthropic_alias_MINIMAL = str(_with_anthropic_alias_REPO_ROOT / 'tests' / 'fixtures' / 'smoke' / 'minimal.guardrails.yaml')

def test_with_anthropic_alias__with_anthropic_alias_exists_on_builder() -> None:
    """The alias is a real attribute on ShieldBuilder — the customer
    error message in `Shield.capabilities` references it by name, so
    looking it up must NOT AttributeError."""
    assert hasattr(ShieldBuilder, 'with_anthropic'), 'ShieldBuilder.with_anthropic is the spelling the error message in Shield.capabilities suggests; both must agree (regression).'
    method = ShieldBuilder.with_anthropic
    assert callable(method)

def test_with_anthropic_alias__with_anthropic_alias_delegates_to_with_anthropic_agents() -> None:
    """Calling `.with_anthropic()` must route through the same
    machinery as `.with_anthropic_agents()` — we patch the canonical
    method and assert the alias invokes it exactly once. This proves
    the alias isn't a copy-pasted reimplementation that could drift."""
    builder = Shield.from_yaml(_with_anthropic_alias_MINIMAL, auto_bind=False)
    sentinel = object()
    with mock.patch.object(ShieldBuilder, 'with_anthropic_agents', return_value=sentinel) as canonical:
        result = builder.with_anthropic()
    assert canonical.call_count == 1
    assert result is sentinel

def test_with_anthropic_alias__capabilities_error_message_names_with_anthropic() -> None:
    """The error message in ``Shield.capabilities`` advertises
    ``.with_anthropic()`` — if anyone deletes the alias, that error
    becomes a lie. Lock the contract from both directions: the alias
    exists, and the error continues to name it."""
    builder = Shield.from_yaml(_with_anthropic_alias_MINIMAL, auto_bind=False)
    shield = builder.build()
    with pytest.raises(RuntimeError) as excinfo:
        _ = shield.capabilities
    msg = str(excinfo.value)
    assert 'with_anthropic' in msg, 'Shield.capabilities error message must continue to mention with_anthropic — the alias relies on that being the public spelling customers see (regression).'
