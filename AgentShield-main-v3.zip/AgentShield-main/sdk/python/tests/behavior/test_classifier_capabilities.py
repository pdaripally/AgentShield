"""Behavior tests consolidated into behavior/test_classifier_capabilities.py."""
from __future__ import annotations
from .._support.paths import LOCAL_FIXTURES, REPO_ROOT
import os
from typing import Any, Dict, List, Optional, Tuple
from unittest.mock import patch
import pytest
from agent_shield import RuntimeBuilder
from agent_shield.adapters._shield import ShieldBuilder
from agent_shield.runtime import _classifier_positional_arity, _wrap_classifier
_classifier_registration_CLASSIFIER_YAML = 'metadata:\n  name: "r96-4-classifier-test"\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["test classifier callback"]\n  forbidden: []\nconfigurations:\n  - id: "aacs_main"\n    type: classifier\n    endpoint: "https://example.cognitiveservices.azure.com/contentsafety/text:analyze"\n    threshold: 0.6\n    headers:\n      Ocp-Apim-Subscription-Key: "test-key-not-real"\n      X-Test-Header: "marker-r96-4"\n    provider_config:\n      categories: ["Hate", "Violence"]\n      output_type: "FourSeverityLevels"\noutput_validation:\n  guard_policies:\n    - name: "aacs_output_check"\n      evaluate_when:\n        - classifier:\n            configuration: "aacs_main"\n          reason: "classifier flagged output"\n'

def _classifier_registration_build_runtime_with_classifier(callback: Any) -> Any:
    """Build a runtime from `_CLASSIFIER_YAML` with `callback` registered."""
    return RuntimeBuilder.from_yaml_strings([_classifier_registration_CLASSIFIER_YAML]).register_classifier_caller(callback).build()

class TestClassifierRegistrationClassifierArityInspection:
    """The arity-detection helper picks between the legacy 2-arg shape
    and the new 3-arg shape, matching the pattern already used for
    Pattern-C thunks (`_call_thunk_with_optional_input`).
    """

    def test_two_arg_plain_function(self) -> None:

        def fn(configuration_id: str, subject: str) -> Dict[str, Any]:
            return {'classification': 'allow'}
        assert _classifier_positional_arity(fn) == 2

    def test_three_arg_plain_function(self) -> None:

        def fn(configuration_id: str, subject: str, configuration: Dict[str, Any]) -> Dict[str, Any]:
            return {'classification': 'allow'}
        assert _classifier_positional_arity(fn) == 3

    def test_lambda_two_arg(self) -> None:
        fn = lambda a, b: {'classification': 'allow'}
        assert _classifier_positional_arity(fn) == 2

    def test_lambda_three_arg(self) -> None:
        fn = lambda a, b, c: {'classification': 'allow'}
        assert _classifier_positional_arity(fn) == 3

    def test_var_positional_treated_as_three_arg(self) -> None:
        """A callable with ``*args`` claims it can absorb any arity; the
        helper opts it into the richer 3-arg shape so the configuration
        is not silently withheld."""

        def fn(*args: Any, **_kwargs: Any) -> Dict[str, Any]:
            return {'classification': 'allow'}
        assert _classifier_positional_arity(fn) == 3

    def test_bound_method_two_arg(self) -> None:

        class Cls:

            def classify(self, configuration_id: str, subject: str) -> Dict[str, Any]:
                return {'classification': 'allow'}
        assert _classifier_positional_arity(Cls().classify) == 2

    def test_bound_method_three_arg(self) -> None:

        class Cls:

            def classify(self, configuration_id: str, subject: str, configuration: Dict[str, Any]) -> Dict[str, Any]:
                return {'classification': 'allow'}
        assert _classifier_positional_arity(Cls().classify) == 3

    def test_uninspectable_falls_back_to_two_arg(self) -> None:
        """Built-ins / C-implemented callables that defeat
        ``inspect.signature`` MUST fall back to the back-compat
        2-arg shape — never to the new 3-arg shape — or hosts that
        registered legacy callables would suddenly receive an extra
        positional argument."""
        assert _classifier_positional_arity(str.upper) == 2

class TestClassifierRegistrationWrapClassifierDispatch:
    """The runtime wrapper dispatches to the 2-arg or 3-arg shape based
    on the cached arity inspected once at registration time. The 3-arg
    form receives the resolved configuration dict; the 2-arg form is
    unchanged (back-compat)."""

    def test_two_arg_form_works(self) -> None:
        seen: List[Tuple[str, str]] = []

        def caller(configuration_id: str, subject: str) -> Dict[str, Any]:
            seen.append((configuration_id, subject))
            return {'classification': 'allow'}
        wrapped = _wrap_classifier(caller)
        out = wrapped('aacs_main', 'hello')
        assert out == {'classification': 'allow'}
        assert seen == [('aacs_main', 'hello')]

    def test_three_arg_form_receives_configuration(self) -> None:
        seen: List[Tuple[str, str, Dict[str, Any]]] = []

        def caller(configuration_id: str, subject: str, configuration: Dict[str, Any]) -> Dict[str, Any]:
            seen.append((configuration_id, subject, configuration))
            return {'classification': 'allow'}
        resolved = {'id': 'aacs_main', 'endpoint': 'https://example.com/cs', 'headers': {'Ocp-Apim-Subscription-Key': 'test-key'}, 'threshold': 0.7}
        wrapped = _wrap_classifier(caller, configuration_resolver=lambda cid: resolved if cid == 'aacs_main' else None)
        out = wrapped('aacs_main', 'hello')
        assert out == {'classification': 'allow'}
        assert len(seen) == 1
        assert seen[0][0] == 'aacs_main'
        assert seen[0][1] == 'hello'
        assert seen[0][2] == resolved

    def test_three_arg_form_without_resolver_receives_empty_dict(self) -> None:
        """When no resolver is supplied, the 3-arg form must still be
        called with a dict (never ``None``) so hosts can write
        ``configuration.get("endpoint")`` without a guard."""
        seen: List[Any] = []

        def caller(configuration_id: str, subject: str, configuration: Dict[str, Any]) -> Dict[str, Any]:
            seen.append(configuration)
            return {'classification': 'allow'}
        wrapped = _wrap_classifier(caller, configuration_resolver=None)
        wrapped('aacs_main', 'hello')
        assert seen == [{}]

    def test_three_arg_form_resolver_returning_none_yields_empty_dict(self) -> None:
        seen: List[Any] = []

        def caller(configuration_id: str, subject: str, configuration: Dict[str, Any]) -> Dict[str, Any]:
            seen.append(configuration)
            return {'classification': 'allow'}
        wrapped = _wrap_classifier(caller, configuration_resolver=lambda _cid: None)
        wrapped('unknown_cfg', 'hello')
        assert seen == [{}]

    def test_three_arg_form_resolver_raising_is_swallowed(self) -> None:
        """If the resolver throws, the wrapper must hand the host an
        empty dict (and NOT propagate the exception into the
        classifier dispatch path). A broken resolver should never
        translate into a runtime block."""
        seen: List[Any] = []

        def caller(configuration_id: str, subject: str, configuration: Dict[str, Any]) -> Dict[str, Any]:
            seen.append(configuration)
            return {'classification': 'allow'}

        def broken(_cid: str) -> Optional[Dict[str, Any]]:
            raise RuntimeError('upstream config lookup failed')
        wrapped = _wrap_classifier(caller, configuration_resolver=broken)
        wrapped('aacs_main', 'hello')
        assert seen == [{}]

    def test_protocol_object_with_classify_two_arg(self) -> None:

        class HostCaller:

            def __init__(self) -> None:
                self.calls: List[Tuple[str, str]] = []

            def classify(self, configuration_id: str, subject: str) -> Dict[str, Any]:
                self.calls.append((configuration_id, subject))
                return {'classification': 'allow'}
        target = HostCaller()
        wrapped = _wrap_classifier(target)
        wrapped('aacs_main', 'hi')
        assert target.calls == [('aacs_main', 'hi')]

    def test_protocol_object_with_classify_three_arg(self) -> None:

        class HostCaller:

            def __init__(self) -> None:
                self.calls: List[Tuple[str, str, Dict[str, Any]]] = []

            def classify(self, configuration_id: str, subject: str, configuration: Dict[str, Any]) -> Dict[str, Any]:
                self.calls.append((configuration_id, subject, configuration))
                return {'classification': 'allow'}
        target = HostCaller()
        wrapped = _wrap_classifier(target, configuration_resolver=lambda _cid: {'endpoint': 'https://x'})
        wrapped('aacs_main', 'hi')
        assert target.calls == [('aacs_main', 'hi', {'endpoint': 'https://x'})]

    def test_arity_inspected_once_at_wrap_time(self) -> None:
        """Arity inspection must be cached on the closure — invoking the
        wrapped form repeatedly must NOT call ``inspect.signature``
        again per dispatch."""

        def caller(configuration_id: str, subject: str, configuration: Dict[str, Any]) -> Dict[str, Any]:
            return {'classification': 'allow'}
        with patch('agent_shield.runtime.inspect.signature', wraps=__import__('inspect').signature) as spy:
            wrapped = _wrap_classifier(caller, configuration_resolver=lambda _c: {})
            calls_after_wrap = spy.call_count
            for _ in range(10):
                wrapped('aacs_main', 'hello')
            assert spy.call_count == calls_after_wrap, f'inspect.signature was called {spy.call_count - calls_after_wrap} additional times after wrap — arity inspection is NOT cached'

class TestClassifierRegistrationRuntimeBuilderRegisterClassifierCaller:
    """Smoke-tests the full pipeline: YAML → ``RuntimeBuilder`` →
    ``register_classifier_caller`` → native dispatch → Python callback
    sees the resolved configuration dict (endpoint, headers, threshold,
    provider_config) carried straight from YAML."""

    def test_three_arg_callback_receives_resolved_yaml_configuration(self) -> None:
        captured: List[Dict[str, Any]] = []

        def caller(configuration_id: str, subject: str, configuration: Dict[str, Any]) -> Dict[str, Any]:
            captured.append({'id': configuration_id, 'cfg': configuration})
            return {'classification': 'allow'}
        runtime = _classifier_registration_build_runtime_with_classifier(caller)
        with runtime.new_session() as session:
            session.begin_turn()
            session.validate_output('hello world')
        assert len(captured) == 1, f'expected exactly one classifier dispatch, got {len(captured)}: {captured}'
        cid = captured[0]['id']
        cfg = captured[0]['cfg']
        assert cid == 'aacs_main'
        assert cfg.get('type') == 'classifier'
        assert cfg.get('endpoint', '').startswith('https://example.cognitiveservices.azure.com')
        headers = cfg.get('headers') or {}
        assert headers.get('Ocp-Apim-Subscription-Key') == 'test-key-not-real'
        assert headers.get('X-Test-Header') == 'marker-r96-4'
        assert cfg.get('threshold') == pytest.approx(0.6)
        pc = cfg.get('provider_config') or {}
        assert pc.get('output_type') == 'FourSeverityLevels'

    def test_two_arg_callback_still_works(self) -> None:
        """Back-compat: the legacy 2-arg callback shape MUST keep
        working without code changes — the runtime must not break
        hosts that haven't migrated."""
        captured: List[Tuple[str, str]] = []

        def caller(configuration_id: str, subject: str) -> Dict[str, Any]:
            captured.append((configuration_id, subject))
            return {'classification': 'allow'}
        runtime = _classifier_registration_build_runtime_with_classifier(caller)
        with runtime.new_session() as session:
            session.begin_turn()
            session.validate_output('hello world')
        assert len(captured) == 1
        assert captured[0][0] == 'aacs_main'
        assert isinstance(captured[0][1], str)
        assert captured[0][1]

class TestClassifierRegistrationShieldBuilderClassifierHelpers:
    """The ``ShieldBuilder`` surface MUST expose
    ``with_classifier_caller`` / ``with_aacs_caller`` so the three-line
    drop-in extends cleanly to classifier registration without falling
    through to the advanced ``with_extension(lambda rb: ...)`` path."""

    def test_with_classifier_caller_present(self) -> None:
        assert hasattr(ShieldBuilder, 'with_classifier_caller')
        assert callable(ShieldBuilder.with_classifier_caller)

    def test_with_aacs_caller_present(self) -> None:
        assert hasattr(ShieldBuilder, 'with_aacs_caller')
        assert callable(ShieldBuilder.with_aacs_caller)

    def test_with_classifier_caller_returns_builder_for_chaining(self, tmp_path: Any) -> None:
        yaml_path = tmp_path / 'guardrails.yaml'
        yaml_path.write_text(_classifier_registration_CLASSIFIER_YAML)

        def caller(_cid: str, _subject: str, _cfg: Dict[str, Any]) -> Dict[str, Any]:
            return {'classification': 'allow'}
        builder = ShieldBuilder(str(yaml_path), auto_bind=False)
        chained = builder.with_classifier_caller(caller)
        assert chained is builder

    def test_with_aacs_caller_registers_via_extension_hook(self, tmp_path: Any) -> None:
        """The helper installs a registration hook on the underlying
        ``RuntimeBuilder`` — visible via ``ShieldBuilder._extra_register``,
        the public extension lane every adapter-installed helper uses."""
        yaml_path = tmp_path / 'guardrails.yaml'
        yaml_path.write_text(_classifier_registration_CLASSIFIER_YAML)

        def caller(_cid: str, _subject: str, _cfg: Dict[str, Any]) -> Dict[str, Any]:
            return {'classification': 'allow'}
        builder = ShieldBuilder(str(yaml_path), auto_bind=False)
        n_before = len(builder._extra_register)
        builder.with_aacs_caller(caller)
        assert len(builder._extra_register) == n_before + 1

    def test_with_aacs_caller_end_to_end_drives_dispatch(self, tmp_path: Any) -> None:
        """Build a Shield through the new helper and confirm the
        callback actually fires when a stage dispatches the
        classifier — proves the helper is fully wired, not just a
        method that records intent."""
        yaml_path = tmp_path / 'guardrails.yaml'
        yaml_path.write_text(_classifier_registration_CLASSIFIER_YAML)
        captured: List[Dict[str, Any]] = []

        def caller(configuration_id: str, subject: str, configuration: Dict[str, Any]) -> Dict[str, Any]:
            captured.append({'id': configuration_id, 'cfg': configuration})
            return {'classification': 'allow'}
        shield = ShieldBuilder(str(yaml_path), auto_bind=False).with_aacs_caller(caller).build()
        with shield.runtime.new_session() as session:
            session.begin_turn()
            session.validate_output('hello')
        assert len(captured) == 1
        assert captured[0]['id'] == 'aacs_main'
        assert captured[0]['cfg'].get('endpoint', '').startswith('https://example.cognitiveservices.azure.com')
_classifier_wiring_UNSET = 'AGENT_SHIELD_Case_PY_TEST_UNSET_VAR_XYZ123'
_classifier_wiring_SET = 'AGENT_SHIELD_Case_PY_TEST_AACS_KEY_OK'

def _classifier_wiring_yaml_with_aacs(api_key_env: str | None) -> str:
    api_key_line = f'    api_key_env: "{api_key_env}"\n' if api_key_env else ''
    return f'metadata:\n  name: "test"\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["pass"]\n  forbidden: ["fail"]\nconfigurations:\n  - id: "aacs_default"\n    type: classifier\n    provider: "azure_content_safety"\n    endpoint: "https://example.cognitiveservices.azure.com"\n    threshold: 0.5\n{api_key_line}post_tool_validation:\n  guard_policies:\n    - name: "aacs_check"\n      evaluate_when:\n        - classifier:\n            configuration: "aacs_default"\n          reason: "classifier flagged"\n'

@pytest.fixture(autouse=True)
def _classifier_wiring_clean_env() -> None:
    for v in (_classifier_wiring_UNSET, _classifier_wiring_SET):
        os.environ.pop(v, None)
    yield
    for v in (_classifier_wiring_UNSET, _classifier_wiring_SET):
        os.environ.pop(v, None)

class TestClassifierWiringClassifierWiringLoadCheck:

    def test_build_raises_with_actionable_text_when_env_var_unset(self) -> None:
        os.environ.pop(_classifier_wiring_UNSET, None)
        yaml = _classifier_wiring_yaml_with_aacs(_classifier_wiring_UNSET)
        with pytest.raises((RuntimeError, ValueError)) as excinfo:
            RuntimeBuilder.from_yaml_strings([yaml]).build()
        msg = str(excinfo.value)
        assert 'aacs_default' in msg, msg
        assert _classifier_wiring_UNSET in msg, msg
        assert 'aacs_check' in msg, msg
        assert 'classifier_wiring_missing' in msg, msg

    def test_build_succeeds_when_env_var_set(self) -> None:
        os.environ[_classifier_wiring_SET] = 'sk-test-credential-not-real'
        yaml = _classifier_wiring_yaml_with_aacs(_classifier_wiring_SET)
        runtime = RuntimeBuilder.from_yaml_strings([yaml]).build()
        assert runtime is not None

    def test_build_raises_when_configurations_entry_missing(self) -> None:
        yaml = 'metadata:\n  name: "test"\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["pass"]\n  forbidden: ["fail"]\npost_tool_validation:\n  guard_policies:\n    - name: "ghost_check"\n      evaluate_when:\n        - classifier:\n            configuration: "not_defined_anywhere"\n          reason: "classifier flagged"\n'
        with pytest.raises((RuntimeError, ValueError)) as excinfo:
            RuntimeBuilder.from_yaml_strings([yaml]).build()
        msg = str(excinfo.value)
        assert 'not_defined_anywhere' in msg, msg
        assert 'ghost_check' in msg, msg
        assert 'classifier_wiring_missing' in msg, msg
import asyncio
from typing import AsyncIterator, Callable
from agent_shield.adapters._capabilities import AgentBoundary, CapabilityReport, CoverageLevel, FrameworkBundle, GuardedInvoke, LlmCallerFactory, StreamingAdapter, StreamingValidator, ToolMetadata, ToolWrapper
from agent_shield.adapters._shield import AgentShieldBlocked, Shield, ShieldMode
_capability_conformance_REPO_ROOT = REPO_ROOT
_capability_conformance_GLOBAL_FIXTURES = _capability_conformance_REPO_ROOT / 'tests' / 'fixtures'
_capability_conformance_LOCAL_FIXTURES = LOCAL_FIXTURES
_capability_conformance_MINIMAL = str(_capability_conformance_GLOBAL_FIXTURES / 'smoke' / 'minimal.guardrails.yaml')
_capability_conformance_TOOL_ARGS_REDACT = str(_capability_conformance_LOCAL_FIXTURES / 'tool_args_redact.guardrails.yaml')

class _CapabilityConformanceFakeFrameworkAgent:
    """Minimal stand-in for a framework agent.

    The orchestrator sees an opaque ``agent`` object; the bundle's
    boundary is what knows how to invoke it. By using a hand-rolled
    fake we keep the orchestrator contract tests independent of any
    third-party framework.
    """

    def __init__(self, response_text: str='') -> None:
        self.response_text = response_text
        self.invoked_with: List[str] = []

    async def execute(self, input_text: str) -> '_CapabilityConformanceFakeAgentResult':
        self.invoked_with.append(input_text)
        return _CapabilityConformanceFakeAgentResult(text=self.response_text)

class _CapabilityConformanceFakeAgentResult:
    """Mutable result object so ``apply_redaction`` can edit it in place."""

    def __init__(self, text: str='') -> None:
        self.text = text

    def __repr__(self) -> str:
        return f'_CapabilityConformanceFakeAgentResult({self.text!r})'

class _CapabilityConformanceFakeFrameworkTool:
    """Stand-in for a framework tool. Tracks calls + raised exceptions."""

    def __init__(self, name: str, return_value: Any='ok', raises: Optional[Exception]=None) -> None:
        self.name = name
        self.description = f'fake tool {name}'
        self.return_value = return_value
        self.raises = raises
        self.calls: List[Dict[str, Any]] = []

    async def __call__(self, **params: Any) -> Any:
        self.calls.append(dict(params))
        if self.raises:
            raise self.raises
        return self.return_value

class _CapabilityConformanceFakeToolWrapper(ToolWrapper):

    def extract(self, tool: Any) -> ToolMetadata:
        return ToolMetadata(name=tool.name, description=tool.description)

    async def invoke(self, original: Any, params: dict) -> Any:
        return await original(**params)

    def wrap(self, original: Any, metadata: ToolMetadata, guarded_invoke: GuardedInvoke) -> Any:

        async def _wrapped(**kwargs: Any) -> Any:
            return await guarded_invoke(kwargs, '')
        _wrapped.__wrapped__ = original
        _wrapped.name = metadata.name
        return _wrapped

class _CapabilityConformanceFakeAgentBoundary(AgentBoundary):
    """Drives ``agent.execute(input_text)`` and reshapes the result."""

    def __init__(self) -> None:
        self.runs = 0
        self.redactions: List[str] = []
        self.blocked: List[str] = []

    async def run(self, agent: Any, input_text: str, **kwargs: Any) -> Any:
        self.runs += 1
        return await agent.execute(input_text)

    def extract_output(self, result: Any) -> Optional[str]:
        return getattr(result, 'text', None)

    def apply_redaction(self, result: Any, redacted_text: str) -> Any:
        self.redactions.append(redacted_text)
        result.text = redacted_text
        return result

    def make_blocked(self, message: str) -> Any:
        self.blocked.append(message)
        return _CapabilityConformanceFakeAgentResult(text=message)

class _CapabilityConformanceFakeStreamingAdapter(StreamingAdapter):
    """Yields per-chunk text payloads from a list of pre-canned chunks."""

    def __init__(self, chunks: Optional[List[str]]=None) -> None:
        self.chunks = chunks or []

    async def stream(self, agent: Any, input_text: str, validator: StreamingValidator, **kwargs: Any) -> AsyncIterator[Any]:
        for chunk in self.chunks:
            result = validator.push(chunk)
            if result.payload:
                yield result.payload
            if result.stopped:
                yield validator.make_blocked(result.reason or 'streaming guard stopped')
                return
        tail = validator.finish()
        if tail.stopped:
            yield validator.make_blocked(tail.reason or 'streaming guard stopped')
            return
        if tail.payload:
            yield tail.payload

class _CapabilityConformanceFakeLlmCallerFactory(LlmCallerFactory):

    def make_caller(self, client: Any) -> Callable[[Optional[str], str], str]:

        def caller(_cid: Optional[str], _prompt: str) -> str:
            return ''
        return caller

def _capability_conformance_make_fake_bundle() -> FrameworkBundle:
    return FrameworkBundle(name='_fake', llm_caller_factory=_CapabilityConformanceFakeLlmCallerFactory(), tool_wrapper=_CapabilityConformanceFakeToolWrapper(), agent_boundary=_CapabilityConformanceFakeAgentBoundary(), streaming_adapter=_CapabilityConformanceFakeStreamingAdapter(), capabilities=CapabilityReport(framework='_fake'))

class TestCapabilityConformanceOrchestratorContract:
    """Contract that every adapter inherits via the Shield orchestrator."""

    def _build(self, path: str=_capability_conformance_MINIMAL, *, mode: ShieldMode=ShieldMode.ENFORCE, on_block: Any='return_blocked', observability: Optional[List[Any]]=None) -> Shield:
        bundle = _capability_conformance_make_fake_bundle()
        builder = Shield.from_yaml(path, auto_bind=False)
        builder._bind_to_bundle(bundle)
        builder = builder.with_mode(mode).with_on_block(on_block)
        if observability:
            for provider in observability:
                builder = builder.with_observability(provider)
        return builder.build()

    def test_capability_report_exposed(self):
        shield = self._build()
        rep = shield.capabilities
        assert isinstance(rep, CapabilityReport)
        assert rep.is_full_coverage()

    def test_mode_attribute_round_trips(self):
        shield = self._build(mode=ShieldMode.MONITOR)
        assert shield.mode is ShieldMode.MONITOR

    def test_input_allowed_proceeds_to_run(self):
        shield = self._build()
        agent = _CapabilityConformanceFakeFrameworkAgent(response_text='ok')
        runner = shield.guard(agent)
        result = asyncio.run(runner.run('hello'))
        assert result.text == 'ok'
        assert agent.invoked_with == ['hello']

    def test_output_allowed_unchanged(self):
        shield = self._build()
        agent = _CapabilityConformanceFakeFrameworkAgent(response_text='benign')
        runner = shield.guard(agent)
        result = asyncio.run(runner.run('hello'))
        assert result.text == 'benign'

    def test_begin_end_turn_fires_exactly_once_per_run(self):
        from agent_shield.observability import CapturingProvider
        capture = CapturingProvider()
        shield = self._build(observability=[capture])
        agent = _CapabilityConformanceFakeFrameworkAgent(response_text='ok')
        runner = shield.guard(agent)
        asyncio.run(runner.run('hello'))
        starts = [e for e in capture.events if dict(getattr(e, 'attributes', {})).get('agent_shield.event.id') == 'turn.start']
        ends = [e for e in capture.events if dict(getattr(e, 'attributes', {})).get('agent_shield.event.id') == 'turn.end']
        assert len(starts) == 1, f'expected 1 turn.start, got {len(starts)}'
        assert len(ends) == 1, f'expected 1 turn.end, got {len(ends)}'

    def test_tool_wrapper_invocation_routes_through_orchestrator(self):
        shield = self._build()
        tool = _CapabilityConformanceFakeFrameworkTool('echo', return_value='echoed')
        wrapped_list = shield.protect_tools([tool])
        assert len(wrapped_list) == 1
        wrapped = wrapped_list[0]
        from agent_shield.adapters._orchestration import current_session, current_user_input

        async def _drive() -> Any:
            with shield.runtime.new_session() as session:
                session.begin_turn()
                tok = current_session.set(session)
                inp = current_user_input.set('test')
                try:
                    session.set_variable('authorized', True)
                    return await wrapped(msg='hi')
                finally:
                    current_user_input.reset(inp)
                    current_session.reset(tok)
        out = asyncio.run(_drive())
        assert tool.calls == [{'msg': 'hi'}], tool.calls
        assert 'echoed' in str(out)

    def test_stage3_mutated_params_reach_framework_tool(self):
        from agent_shield.adapters._orchestration import current_session
        rt = RuntimeBuilder.from_yaml(_capability_conformance_TOOL_ARGS_REDACT).build()
        bundle = _capability_conformance_make_fake_bundle()

        class _CaptureTool:
            name = 'echo'
            description = 'fake echo tool'

            def __init__(self) -> None:
                self.seen: Dict[str, Any] = {}

            async def __call__(self, **params: Any) -> Any:
                self.seen.update(params)
                return f'saw: {params.get("msg", "")}'
        tool = _CaptureTool()
        from agent_shield.adapters._shield import _protect_tools_via_wrapper
        wrapped = _protect_tools_via_wrapper(rt, [tool], bundle.tool_wrapper)[0]

        async def _drive() -> Any:
            with rt.new_session(session_id='s1', correlation_id='c1') as session:
                session.begin_turn()
                tok = current_session.set(session)
                try:
                    return await wrapped(msg='ssn is 123-45-6789')
                finally:
                    current_session.reset(tok)
        asyncio.run(_drive())
        assert '123-45-6789' not in tool.seen.get('msg', ''), tool.seen
        assert '[REDACTED]' in tool.seen.get('msg', ''), tool.seen

    def test_monitor_mode_does_not_block(self):
        shield = self._build(mode=ShieldMode.MONITOR)
        agent = _CapabilityConformanceFakeFrameworkAgent(response_text='ok')
        runner = shield.guard(agent)
        result = asyncio.run(runner.run('hello'))
        assert result.text == 'ok'
        assert agent.invoked_with == ['hello']

    def test_on_block_callable_invoked(self):
        captured: List[Any] = []

        def policy(verdict_or_message: Any) -> str:
            captured.append(verdict_or_message)
            return 'custom blocked text'
        shield = self._build(on_block=policy)
        assert shield._on_block is policy
        runner = shield.guard(_CapabilityConformanceFakeFrameworkAgent(response_text='ok'))
        assert runner._on_block is policy

    def test_on_block_raise_class_present(self):
        exc = AgentShieldBlocked(verdict=None, message='msg')
        assert exc.message == 'msg'
        assert isinstance(exc, Exception)

def _capability_conformance_runtime_event_id(event: Any) -> Optional[str]:
    """Return the ``agent_shield.event.id`` attribute of a captured event."""
    attrs = dict(getattr(event, 'attributes', {}) or {})
    return attrs.get('agent_shield.event.id')
_capability_conformance_REAL_ADAPTERS = ['openai_agents', 'langchain', 'anthropic_agents', 'autogen', 'crewai', 'semantic_kernel']

@pytest.mark.parametrize('adapter_name', _capability_conformance_REAL_ADAPTERS)
class TestCapabilityConformanceBundleConformance:
    """Every real adapter satisfies the capability Protocol contract."""

    def _bundle(self, adapter_name: str) -> FrameworkBundle:
        mod = __import__(f'agent_shield.adapters.{adapter_name}', fromlist=['_BUNDLE'])
        return mod._BUNDLE

    def test_bundle_name_matches_module(self, adapter_name: str):
        bundle = self._bundle(adapter_name)
        assert bundle.name == adapter_name

    def test_capability_report_framework_matches(self, adapter_name: str):
        bundle = self._bundle(adapter_name)
        assert bundle.capabilities.framework == adapter_name

    def test_llm_caller_factory_protocol(self, adapter_name: str):
        bundle = self._bundle(adapter_name)
        assert callable(getattr(bundle.llm_caller_factory, 'make_caller', None))

    def test_tool_wrapper_protocol(self, adapter_name: str):
        bundle = self._bundle(adapter_name)
        if bundle.tool_wrapper is None:
            return
        for method in ('extract', 'invoke', 'wrap'):
            assert callable(getattr(bundle.tool_wrapper, method, None)), f'{adapter_name} tool_wrapper missing {method}'

    def test_agent_boundary_protocol(self, adapter_name: str):
        bundle = self._bundle(adapter_name)
        if bundle.agent_boundary is None:
            return
        for method in ('run', 'extract_output', 'apply_redaction', 'make_blocked'):
            assert callable(getattr(bundle.agent_boundary, method, None)), f'{adapter_name} agent_boundary missing {method}'

    def test_streaming_adapter_protocol_or_unsupported(self, adapter_name: str):
        bundle = self._bundle(adapter_name)
        rep = bundle.capabilities
        if bundle.streaming_adapter is None:
            assert rep.streaming_output == CoverageLevel.UNSUPPORTED, f'{adapter_name} streaming_adapter is None but report says {rep.streaming_output}'
        else:
            assert callable(getattr(bundle.streaming_adapter, 'stream', None))

    def test_capability_coverage_levels_valid(self, adapter_name: str):
        bundle = self._bundle(adapter_name)
        rep = bundle.capabilities
        for stage in ('input_validation', 'state_validation', 'tool_authorization', 'tool_execution_validation', 'tool_output_validation', 'output_validation', 'streaming_output'):
            level = getattr(rep, stage)
            assert isinstance(level, CoverageLevel), f'{adapter_name}.{stage} is not a CoverageLevel'

    def test_shield_constructs_via_composition(self, adapter_name: str):
        __import__(f'agent_shield.adapters.{adapter_name}')
        method = f'with_{adapter_name}'
        builder = Shield.from_yaml(_capability_conformance_MINIMAL, auto_bind=False)
        shield = getattr(builder, method)().build()
        assert shield.runtime is not None
        assert isinstance(shield.capabilities, CapabilityReport)
        assert shield.capabilities.framework == adapter_name

class TestCapabilityConformanceCrossAdapterParity:
    """Parity smoke: every adapter reports the same fundamental shape.

    Heavyweight cross-framework behavioural parity belongs in a future
    cross-language conformance harness; what we lock down here is the
    minimum every adapter must agree on so the architectural guarantee
    survives future changes.
    """

    def test_every_adapter_exposes_composition_hook(self):
        for name in _capability_conformance_REAL_ADAPTERS:
            __import__(f'agent_shield.adapters.{name}')
            method = f'with_{name}'
            assert hasattr(ShieldBuilder, method), f'ShieldBuilder.{method} not installed by adapter import'

    def test_every_adapter_supports_monitor_mode_via_builder(self):
        for name in _capability_conformance_REAL_ADAPTERS:
            __import__(f'agent_shield.adapters.{name}')
            method = f'with_{name}'
            builder = Shield.from_yaml(_capability_conformance_MINIMAL, auto_bind=False)
            shield = getattr(builder, method)().with_mode('monitor').build()
            assert shield.mode is ShieldMode.MONITOR

    def test_every_adapter_supports_on_block_policy_via_builder(self):
        for name in _capability_conformance_REAL_ADAPTERS:
            __import__(f'agent_shield.adapters.{name}')
            method = f'with_{name}'
            builder = Shield.from_yaml(_capability_conformance_MINIMAL, auto_bind=False)
            shield = getattr(builder, method)().with_on_block('raise').build()
            assert shield._on_block == 'raise'
