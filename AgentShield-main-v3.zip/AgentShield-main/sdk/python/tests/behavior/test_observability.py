"""Behavior tests consolidated into behavior/test_observability.py."""
from __future__ import annotations
from .._support.paths import REPO_ROOT
from pathlib import Path
_observability_call_allowed_REPO_ROOT = REPO_ROOT
_observability_call_allowed_MINIMAL = str(_observability_call_allowed_REPO_ROOT / 'tests' / 'fixtures' / 'smoke' / 'minimal.guardrails.yaml')

def test_observability_call_allowed__allowed_tool_call_emits_call_allowed_not_call_blocked() -> None:
    """The regression repro: an allowed ``validate_tool_call`` must NOT
    produce a ``call_blocked`` event."""
    from agent_shield import RuntimeBuilder
    from agent_shield.observability import CapturingProvider
    provider = CapturingProvider()
    rt = RuntimeBuilder.from_yaml(_observability_call_allowed_MINIMAL).register_observability_provider(provider).build()
    with rt.new_session(session_id='f20-9', correlation_id='c-f20-9') as session:
        session.begin_turn()
        session.set_variable('authorized', True)
        session.validate_tool_call('echo', {'msg': 'hi'}, tool_call_id='call_1')
        session.end_turn()
    gating_events = [ev for ev in provider.events if ev.event_type in {'call_blocked', 'call_allowed'}]
    assert gating_events, 'no gating-verdict events captured — the test scenario must fire at least one stage gate'
    misclassified = [ev for ev in gating_events if ev.action == 'allow' and ev.event_type == 'call_blocked']
    assert not misclassified, f'regression: allowed gating verdicts must NOT emit event_type=`call_blocked`; got {[(ev.stage, ev.message) for ev in misclassified]}'
    allowed_tool_exec = [ev for ev in gating_events if ev.event_type == 'call_allowed' and ev.action == 'allow' and (ev.stage == 'tool_execution')]
    assert allowed_tool_exec, f'expected at least one tool_execution gating verdict with event_type=`call_allowed` and action=`allow`; saw {[(ev.event_type, ev.action, ev.stage) for ev in gating_events]}'

def test_observability_call_allowed__allowed_verdict_message_and_event_type_agree() -> None:
    """Belt-and-suspenders: the human-readable message and the
    machine-readable event_type must not disagree about whether the
    call was allowed or blocked. This is the underlying invariant the
    regression test exercises."""
    from agent_shield import RuntimeBuilder
    from agent_shield.observability import CapturingProvider
    provider = CapturingProvider()
    rt = RuntimeBuilder.from_yaml(_observability_call_allowed_MINIMAL).register_observability_provider(provider).build()
    with rt.new_session(session_id='f20-9b', correlation_id='c-f20-9b') as session:
        session.begin_turn()
        session.set_variable('authorized', True)
        session.validate_tool_call('echo', {'msg': 'hi'}, tool_call_id='call_2')
        session.end_turn()
    for ev in provider.events:
        if ev.event_type == 'call_allowed':
            assert 'allowed' in ev.message, f'call_allowed event has incongruent message: {ev.message!r}'
            assert ev.action == 'allow', f"call_allowed event has action != 'allow': {ev.action!r}"
        elif ev.event_type == 'call_blocked':
            assert 'blocked' in ev.message, f'call_blocked event has incongruent message: {ev.message!r}'
            assert ev.action == 'block', f"call_blocked event has action != 'block': {ev.action!r}"
import pytest
from agent_shield import PerfTelemetry, RuntimeBuilder, ShieldLogEvent
_pertelemetry_PERF_EVENT_TYPES = {'stage_evaluated', 'policy_evaluated', 'llm_called', 'classifier_called'}
_pertelemetry_POLICY_YAML = '\nmetadata:\n  name: perf-test\n  version: "1.0.0"\ninput_validation:\n  guard_policies:\n    - name: pii_regex\n      evaluate_when:\n        - pattern: \'\\d{3}-\\d{2}-\\d{4}\'\n          reason: \'SSN detected\'\n          action: block\noutput_validation:\n  guard_policies:\n    - name: secret_in_output\n      evaluate_when:\n        - pattern: \'sk_live_[A-Za-z0-9]+\'\n          reason: \'API key leaked\'\n          action: block\n'

@pytest.fixture()
def _pertelemetry_policy_path(tmp_path: Path) -> Path:
    p = tmp_path / 'perf.guardrails.yaml'
    p.write_text(_pertelemetry_POLICY_YAML, encoding='utf-8')
    return p

def _pertelemetry_build_with_capture(_pertelemetry_policy_path: Path, mode):
    """Return (runtime, captured_events_list) for the given mode."""
    captured: list[ShieldLogEvent] = []

    def emit(event: ShieldLogEvent) -> None:
        captured.append(event)
    builder = RuntimeBuilder.from_yaml(str(_pertelemetry_policy_path))
    builder = builder.register_observability_provider(emit)
    if mode is not None:
        builder = builder.with_perf_telemetry(mode)
    runtime = builder.build()
    return (runtime, captured)

def _pertelemetry_count_perf(events) -> int:
    return sum((1 for e in events if e.event_type in _pertelemetry_PERF_EVENT_TYPES))

def test_pertelemetry__perf_telemetry_enum_values_match_wire_strings():
    assert PerfTelemetry.OFF.value == 'off'
    assert PerfTelemetry.EXTERNAL.value == 'external'
    assert PerfTelemetry.FULL.value == 'full'
    assert isinstance(PerfTelemetry.OFF, str)

def test_pertelemetry__with_perf_telemetry_default_off_emits_no_perf_events(_pertelemetry_policy_path: Path):
    runtime, captured = _pertelemetry_build_with_capture(_pertelemetry_policy_path, None)
    session = runtime.new_session()
    session.validate_input('hello, world')
    session.validate_output('just a response')
    runtime.flush_observability()
    assert _pertelemetry_count_perf(captured) == 0, f'Off (default) must emit zero perf events; saw {[e.event_type for e in captured if e.event_type in _pertelemetry_PERF_EVENT_TYPES]}'

def test_pertelemetry__with_perf_telemetry_full_emits_perf_events(_pertelemetry_policy_path: Path):
    runtime, captured = _pertelemetry_build_with_capture(_pertelemetry_policy_path, PerfTelemetry.FULL)
    session = runtime.new_session()
    session.validate_input('hello, world')
    session.validate_output('just a response')
    runtime.flush_observability()
    assert _pertelemetry_count_perf(captured) >= 2, f'Full must emit at least one StageEvaluated and one PolicyEvaluated; saw {[e.event_type for e in captured]}'
    types = {e.event_type for e in captured}
    assert 'stage_evaluated' in types
    assert 'policy_evaluated' in types

def test_pertelemetry__with_perf_telemetry_external_emits_no_stage_or_policy_events(_pertelemetry_policy_path: Path):
    runtime, captured = _pertelemetry_build_with_capture(_pertelemetry_policy_path, PerfTelemetry.EXTERNAL)
    session = runtime.new_session()
    session.validate_input('hello, world')
    session.validate_output('just a response')
    runtime.flush_observability()
    types = {e.event_type for e in captured}
    assert 'stage_evaluated' not in types
    assert 'policy_evaluated' not in types

def test_pertelemetry__with_perf_telemetry_round_trips_all_three(_pertelemetry_policy_path: Path):
    for mode in [PerfTelemetry.OFF, PerfTelemetry.EXTERNAL, PerfTelemetry.FULL, 'off', 'external', 'full', 'OFF', 'Full']:
        builder = RuntimeBuilder.from_yaml(str(_pertelemetry_policy_path))
        builder = builder.with_perf_telemetry(mode)
        runtime = builder.build()
        session = runtime.new_session()
        _ = session.validate_input('hi')

def test_pertelemetry__with_perf_telemetry_rejects_unknown_mode(_pertelemetry_policy_path: Path):
    builder = RuntimeBuilder.from_yaml(str(_pertelemetry_policy_path))
    with pytest.raises(Exception) as excinfo:
        builder.with_perf_telemetry('loud')
    assert 'perf_telemetry' in str(excinfo.value).lower() or 'loud' in str(excinfo.value).lower()
import logging
from typing import Iterator, List
_no_pii_sentinel_SENTINEL_USER_INPUT = 'SENTINEL_PII_USER_INPUT_xZk2'
_no_pii_sentinel_SENTINEL_TOOL_ARGS = 'SENTINEL_PII_TOOL_ARGS_8mNQ'
_no_pii_sentinel_SENTINEL_TOOL_RESULT = 'SENTINEL_PII_TOOL_RESULT_v3pL'
_no_pii_sentinel_SENTINEL_VAR_VALUE = 'SENTINEL_PII_VAR_VALUE_CasetF'
_no_pii_sentinel_ALL_SENTINELS = (_no_pii_sentinel_SENTINEL_USER_INPUT, _no_pii_sentinel_SENTINEL_TOOL_ARGS, _no_pii_sentinel_SENTINEL_TOOL_RESULT, _no_pii_sentinel_SENTINEL_VAR_VALUE)
_no_pii_sentinel_MINIMAL_YAML = '\nmetadata:\n  name: "no-pii-sentinel-py"\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["sentinel test"]\n  forbidden: ["nothing"]\nresources:\n  tools:\n    - name: "echo"\n      description: "Echo tool for the no-PII sentinel test."\n      permission: "read_only"\n'

class _NoPiiSentinelCapturingHandler(logging.Handler):
    """Buffer every record at DEBUG or above into a list.

    Capture starts at DEBUG so the swallow-path test can assert both
    halves of the logging change demotion contract:
      - the type-only warning line stays at WARNING (no PII at info+),
      - the full exception text + traceback remain visible at DEBUG.

    Callers that only care about the info+ half use the
    ``_assert_no_sentinel`` helper, which filters ``[DEBUG]`` lines
    out before asserting absence.
    """

    def __init__(self) -> None:
        super().__init__(level=logging.DEBUG)
        self.records: List[str] = []

    def emit(self, record: logging.LogRecord) -> None:
        try:
            self.records.append(self.format(record))
        except Exception:
            self.records.append(record.getMessage())

@pytest.fixture
def _no_pii_sentinel_captured_logs() -> Iterator[List[str]]:
    """Attach a capturing handler at DEBUG to the ``agent_shield`` logger tree."""
    handler = _NoPiiSentinelCapturingHandler()
    handler.setFormatter(logging.Formatter('[%(levelname)s] %(name)s: %(message)s'))
    root = logging.getLogger('agent_shield')
    prev_level = root.level
    root.setLevel(logging.DEBUG)
    root.addHandler(handler)
    try:
        yield handler.records
    finally:
        root.removeHandler(handler)
        root.setLevel(prev_level)

def _no_pii_sentinel_assert_no_sentinel(captured: List[str]) -> None:
    """logging change contract's INFO+ half: sentinel never appears at info+/warn/error/critical.

    The capturing handler runs at DEBUG so the swallow-path test can
    separately prove the sentinel IS visible at DEBUG (the
    demoted-not-deleted half of the contract). This helper skips
    ``[DEBUG]`` lines so the info+ assertion stays scoped to its
    intended level.
    """
    for line in captured:
        if line.startswith('[DEBUG]'):
            continue
        for sentinel in _no_pii_sentinel_ALL_SENTINELS:
            assert sentinel not in line, f'sentinel {sentinel!r} leaked at INFO+ level: {line}'

def test_no_pii_sentinel__no_pii_in_info_logs_during_full_turn(_no_pii_sentinel_captured_logs: List[str]) -> None:
    """End-to-end: drive a full turn, assert no sentinel in INFO+ logs."""
    from agent_shield import RuntimeBuilder
    runtime = RuntimeBuilder.from_yaml_strings([_no_pii_sentinel_MINIMAL_YAML]).build()
    with runtime.new_session(session_id='sess-sentinel', correlation_id='corr-sentinel') as session:
        session.begin_turn()
        session.validate_input(_no_pii_sentinel_SENTINEL_USER_INPUT)
        session.validate_tool_call('echo', {'msg': _no_pii_sentinel_SENTINEL_TOOL_ARGS}, tool_call_id='tc-sentinel')
        session.record_tool_failure('echo', _no_pii_sentinel_SENTINEL_TOOL_RESULT)
        try:
            session.set_variable('authorized', _no_pii_sentinel_SENTINEL_VAR_VALUE)
        except Exception:
            pass
        session.validate_output(f'agent said: {_no_pii_sentinel_SENTINEL_TOOL_RESULT}')
        session.end_turn()
    _no_pii_sentinel_assert_no_sentinel(_no_pii_sentinel_captured_logs)

@pytest.mark.asyncio
async def test_no_pii_sentinel__no_pii_in_info_logs_during_orchestrator_swallow_paths(_no_pii_sentinel_captured_logs: List[str]) -> None:
    """The async-orchestration ``_orchestration.py`` swallow paths log
    exception text at warning level. Verify the exception message we
    feed in does NOT escape into the captured log.

    logging change demoted the leaky ``logger.warning("Tool '%s' raised: %s",
    tool_name, exc)`` sites at ``_orchestration.py:401`` / ``:494`` to
    a type-only template at warn + full message at debug. This test
    locks down that contract.

    Drives both ``guarded_tool`` and ``guarded_tool_sync`` with an
    ``execute`` body that raises ``ValueError`` containing every
    sentinel. The warning-level line must stay type-only while the full
    exception text remains debug-only.
    """
    from agent_shield import RuntimeBuilder
    from agent_shield.adapters._orchestration import guarded_tool, guarded_tool_sync
    runtime = RuntimeBuilder.from_yaml_strings([_no_pii_sentinel_MINIMAL_YAML]).build()
    with runtime.new_session(session_id='sess-sentinel-2', correlation_id='corr-sentinel-2') as session:
        session.begin_turn()
        error_message = ' :: '.join(_no_pii_sentinel_ALL_SENTINELS)

        async def _execute_async(_: dict) -> str:
            raise ValueError(error_message)

        def _execute_sync(_: dict) -> str:
            raise ValueError(error_message)
        blocked_async, output_async = await guarded_tool('echo', {'msg': _no_pii_sentinel_SENTINEL_TOOL_ARGS}, _execute_async, session=session)
        blocked_sync, output_sync = guarded_tool_sync('echo', {'msg': _no_pii_sentinel_SENTINEL_TOOL_ARGS}, _execute_sync, session=session)
        session.end_turn()
    assert blocked_async is False
    assert blocked_sync is False
    expected_error_text = f'[tool error] echo: {error_message}'
    assert output_async == expected_error_text
    assert output_sync == expected_error_text
    warning_lines = [line for line in _no_pii_sentinel_captured_logs if line.startswith('[WARNING]') and "Tool 'echo' raised" in line]
    assert warning_lines == ["[WARNING] agent_shield: Tool 'echo' raised ValueError", "[WARNING] agent_shield: Tool 'echo' raised ValueError"]
    _no_pii_sentinel_assert_no_sentinel(_no_pii_sentinel_captured_logs)
    debug_lines = [line for line in _no_pii_sentinel_captured_logs if line.startswith('[DEBUG]')]
    assert any((_no_pii_sentinel_SENTINEL_TOOL_RESULT in line for line in debug_lines)), f'logging change contract violation: the full exception text must remain visible at DEBUG. Either the debug call site at _orchestration.py:401/494 was removed, or the captured logger never received it. Debug lines seen: {debug_lines!r}'
import io
import os
import tempfile
from contextlib import redirect_stderr, redirect_stdout
from agent_shield import Shield
_no_stdout_block_messages_YAML = 'metadata:\n  name: "r48-4-no-stdout-block"\n  version: "0.1.0"\n  agent_shield_version: "2.0"\n\nobjective:\n  goal: ["execute a wire transfer only after manager approval"]\n  forbidden: ["execute without approval"]\n\nresources:\n  tools:\n    - name: "execute_wire_transfer"\n      description: "Execute a previously prepared wire transfer."\n      permission: "execute"\n\nvariables:\n  - name: "manager_approved"\n    type: "boolean"\n    description: "Manager-confirmed authorization."\n    on_demand_by:\n      kind: "human"\n      prompt: "Approve wire transfer?"\n    lifetime: "per_session"\n\nstate_validation:\n  guard_policies:\n    - name: "require_manager_approval"\n      applies_to:\n        tools: ["execute_wire_transfer"]\n      evaluate_when:\n        - expression: "defined(manager_approved) and manager_approved == true"\n          reason: "Manager approval is required before executing a wire transfer."\n      action: "block"\n'

@pytest.fixture
def _no_stdout_block_messages_yaml_path() -> str:
    with tempfile.NamedTemporaryFile(mode='w', suffix='.guardrails.yaml', delete=False) as f:
        f.write(_no_stdout_block_messages_YAML)
        path = f.name
    try:
        yield path
    finally:
        os.unlink(path)

def _no_stdout_block_messages_drive_block(shield: Shield) -> None:
    """Trigger a Stage-2/3 block via :meth:`Shield.protect_tool`.

    Mirrors the regression reproducer shape: a ``protect_tool`` call against a
    tool guarded by an ``on_demand_by: kind: human`` variable, where
    the variable is unset and no runtime handler is registered. We only
    need the fail-closed block to fire.
    """
    import asyncio

    async def _run() -> None:
        with shield.session(session_id='r48-4') as session:
            session.begin_request()
            try:
                blocked, _out = await shield.protect_tool('execute_wire_transfer', {'transfer_id': 'wire-1'}, lambda params: asyncio.sleep(0, result={'ok': True}), session=session)
                assert blocked is True
            finally:
                session.end_request()
    asyncio.run(_run())

def test_no_stdout_block_messages__no_unstructured_guardrail_block_lines_on_stderr(_no_stdout_block_messages_yaml_path: str) -> None:
    """A tool-block must NOT print ``[GUARDRAIL BLOCK] ...`` to stderr.

    Captures stderr (where Python's ``lastResort`` handler writes
    ``WARNING+`` records when no host handler is installed) and the
    root logger; asserts neither carries the unstructured line.
    """
    al = logging.getLogger('agent_shield')
    saved_handlers = list(al.handlers)
    saved_propagate = al.propagate
    saved_level = al.level
    al.handlers = []
    al.propagate = True
    al.setLevel(logging.NOTSET)
    try:
        shield = Shield.from_yaml(_no_stdout_block_messages_yaml_path, auto_bind=False).build()
        err = io.StringIO()
        out = io.StringIO()
        with redirect_stderr(err), redirect_stdout(out):
            _no_stdout_block_messages_drive_block(shield)
        stderr_text = err.getvalue()
        stdout_text = out.getvalue()
    finally:
        al.handlers = saved_handlers
        al.propagate = saved_propagate
        al.setLevel(saved_level)
    assert '[GUARDRAIL' not in stderr_text, f"Tool-block leaked an unstructured '[GUARDRAIL ...]' line to stderr (regression):\n{stderr_text!r}"
    assert '[GUARDRAIL' not in stdout_text, f"Tool-block leaked an unstructured '[GUARDRAIL ...]' line to stdout (regression):\n{stdout_text!r}"
    for needle in ('[Stage 1] Input blocked', '[Stage 5] Output blocked'):
        assert needle not in stderr_text, f'Block notification leaked to stderr: {needle!r}\nstderr: {stderr_text!r}'

def test_no_stdout_block_messages__block_message_routes_through_debug_logger(_no_stdout_block_messages_yaml_path: str) -> None:
    """When a host opts in to DEBUG logging, the diagnostic IS emitted.

    This is the inverse of the no-stdout assertion: the diagnostic
    line is still useful for operators that want it — it just must
    not appear on the default ``lastResort`` path.
    """
    al = logging.getLogger('agent_shield')
    handler = logging.Handler()
    captured: list[logging.LogRecord] = []
    handler.emit = captured.append
    handler.setLevel(logging.DEBUG)
    saved_handlers = list(al.handlers)
    saved_level = al.level
    al.handlers = [handler]
    al.setLevel(logging.DEBUG)
    try:
        shield = Shield.from_yaml(_no_stdout_block_messages_yaml_path, auto_bind=False).build()
        _no_stdout_block_messages_drive_block(shield)
    finally:
        al.handlers = saved_handlers
        al.setLevel(saved_level)
    debug_msgs = [r.getMessage() for r in captured if r.levelno == logging.DEBUG]
    assert any(('[GUARDRAIL' in m for m in debug_msgs)), f'Expected the tool-block diagnostic to be emitted at DEBUG when the host opts in. Captured DEBUG records: {debug_msgs!r}'
import shutil
import subprocess
_cross_lang_digest_REPO_ROOT = REPO_ROOT
_cross_lang_digest_NODE_DIR = _cross_lang_digest_REPO_ROOT / 'sdk' / 'node'
_cross_lang_digest_RUST_DIR = _cross_lang_digest_REPO_ROOT / 'sdk' / 'rust' / 'agent_shield_core'
_cross_lang_digest_DOTNET = Path.home() / '.dotnet' / 'dotnet'
_cross_lang_digest_FIXTURE = _cross_lang_digest_REPO_ROOT / 'tests' / 'fixtures' / 'smoke' / 'minimal.guardrails.yaml'

def _cross_lang_digest_compute_python_digest(path: Path) -> str:
    from agent_shield import GuardrailsConfig
    return GuardrailsConfig.load(str(path)).compile().digest

def _cross_lang_digest_node_digest(path: Path) -> str:
    node = shutil.which('node')
    if node is None:
        pytest.skip('node not installed')
    if not (_cross_lang_digest_NODE_DIR / 'agent-shield.linux-x64-gnu.node').exists():
        pytest.skip('Node native binding not built — run `npm run build`')
    if not (_cross_lang_digest_NODE_DIR / 'dist' / 'config.js').exists():
        pytest.skip('Node TS wrapper not built — run `npm run build:wrapper` in sdk/node')
    code = f"const {{GuardrailsConfig}} = require('./dist/config.js');console.log(GuardrailsConfig.load({str(path)!r}).compile().digest);"
    out = subprocess.run([node, '-e', code], cwd=_cross_lang_digest_NODE_DIR, capture_output=True, text=True, check=True)
    return out.stdout.strip()

def _cross_lang_digest_rust_digest(path: Path) -> str:
    if shutil.which('cargo') is None:
        pytest.skip('cargo not installed')
    so_path = _cross_lang_digest_RUST_DIR / 'target' / 'release' / 'libagent_shield_core.so'
    if not so_path.exists():
        pytest.skip('Rust core release cdylib not built — run `cargo build --release --lib`')
    import ctypes
    lib = ctypes.CDLL(str(so_path))
    lib.shield_config_load.restype = ctypes.c_void_p
    lib.shield_config_load.argtypes = [ctypes.c_char_p, ctypes.POINTER(ctypes.c_char_p)]
    lib.shield_config_compile.restype = ctypes.c_void_p
    lib.shield_config_compile.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_char_p)]
    lib.shield_compiled_digest.restype = ctypes.c_char_p
    lib.shield_compiled_digest.argtypes = [ctypes.c_void_p]
    lib.shield_config_free.argtypes = [ctypes.c_void_p]
    lib.shield_compiled_free.argtypes = [ctypes.c_void_p]
    err = ctypes.c_char_p()
    cfg = lib.shield_config_load(str(path).encode(), ctypes.byref(err))
    assert cfg, f'shield_config_load failed: {err.value}'
    try:
        compiled = lib.shield_config_compile(cfg, ctypes.byref(err))
        assert compiled, f'shield_config_compile failed: {err.value}'
        try:
            digest = lib.shield_compiled_digest(compiled)
            return digest.decode()
        finally:
            lib.shield_compiled_free(compiled)
    finally:
        lib.shield_config_free(cfg)

@pytest.fixture(scope='module')
def _cross_lang_digest_python_digest() -> str:
    return _cross_lang_digest_compute_python_digest(_cross_lang_digest_FIXTURE)

class TestCrossLangDigestCrossLanguageDigest:
    """Same fixture → same digest in every SDK."""

    def test_python_node_digest_match(self, _cross_lang_digest_python_digest):
        node = _cross_lang_digest_node_digest(_cross_lang_digest_FIXTURE)
        assert _cross_lang_digest_python_digest == node, f'digest drift: python={_cross_lang_digest_python_digest!r} node={node!r}'

    def test_python_rust_digest_match(self, _cross_lang_digest_python_digest):
        rust = _cross_lang_digest_rust_digest(_cross_lang_digest_FIXTURE)
        assert _cross_lang_digest_python_digest == rust, f'digest drift: python={_cross_lang_digest_python_digest!r} rust={rust!r}'

    def test_digest_is_deterministic_across_invocations(self, _cross_lang_digest_python_digest):
        for _ in range(3):
            assert _cross_lang_digest_compute_python_digest(_cross_lang_digest_FIXTURE) == _cross_lang_digest_python_digest

class TestCrossLangDigestDigestStabilityProperties:
    """Properties the digest contract MUST hold."""

    def test_digest_is_64_char_hex(self, _cross_lang_digest_python_digest):
        import re
        assert re.fullmatch('[0-9a-f]{64}', _cross_lang_digest_python_digest), f'digest is not lowercase 64-char hex: {_cross_lang_digest_python_digest!r}'

    def test_digest_changes_with_content(self):
        from agent_shield import GuardrailsConfig
        a = GuardrailsConfig.load(str(_cross_lang_digest_FIXTURE)).compile().digest
        b = GuardrailsConfig.load(str(_cross_lang_digest_FIXTURE)).with_overrides({'metadata': {'description': 'different'}}).compile().digest
        assert a != b
