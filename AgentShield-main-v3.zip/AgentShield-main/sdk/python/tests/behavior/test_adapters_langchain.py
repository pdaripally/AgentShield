"""Behavior tests consolidated into behavior/test_adapters_langchain.py."""
from __future__ import annotations
from .._support.paths import REPO_ROOT
import importlib
import pytest
_bundle_auto_bind_REPO_ROOT = REPO_ROOT
_bundle_auto_bind_MINIMAL = str(_bundle_auto_bind_REPO_ROOT / 'tests' / 'fixtures' / 'smoke' / 'minimal.guardrails.yaml')

@pytest.fixture
def _bundle_auto_bind_clean_registry():
    """Snapshot and reset the bundle registry around each test so the
    parametrised state stays under test control."""
    from agent_shield.adapters import _bundle_registry
    snapshot = dict(_bundle_registry._REGISTERED)
    _bundle_registry.reset()
    try:
        yield _bundle_registry
    finally:
        _bundle_registry._REGISTERED.clear()
        _bundle_registry._REGISTERED.update(snapshot)

def _bundle_auto_bind_import_adapter(name: str):
    """Import an adapter module and re-register its bundle.

    The module-level ``_registry.register(_BUNDLE)`` runs only on the
    *first* import of an adapter module within a process. Re-importing
    after a registry reset is a no-op against the bundle dict, so this
    helper explicitly re-registers the bundle so each test sees the
    expected registration state.
    """
    from agent_shield.adapters import _bundle_registry
    module = importlib.import_module(f'agent_shield.adapters.{name}')
    _bundle_registry.register(module._BUNDLE)
    return module

class TestBundleAutoBindAutoBindOneAdapter:

    def test_single_import_auto_binds(self, _bundle_auto_bind_clean_registry):
        from agent_shield import Shield
        _bundle_auto_bind_import_adapter('openai_agents')
        builder = Shield.from_yaml(_bundle_auto_bind_MINIMAL)
        assert builder._bundle is not None
        assert builder._bundle.name == 'openai_agents'
        shield = builder.build()
        assert shield.capabilities.framework == 'openai_agents'

class TestBundleAutoBindAutoBindZeroAdapters:

    def test_no_adapter_imported_builder_constructs(self, _bundle_auto_bind_clean_registry):
        """No adapter imported: builder constructs (auto-bind is a no-op),
        ``build()`` itself succeeds (null-bundle path is allowed), and
        the bundle-requiring accessors raise at call time."""
        from agent_shield import Shield
        assert _bundle_auto_bind_clean_registry.active_bundle() is None
        builder = Shield.from_yaml(_bundle_auto_bind_MINIMAL)
        assert builder._bundle is None
        shield = builder.build()
        with pytest.raises(RuntimeError, match='with_<framework>'):
            _ = shield.capabilities

class TestBundleAutoBindAutoBindAmbiguous:

    def test_two_imports_raise_ambiguity_error(self, _bundle_auto_bind_clean_registry):
        from agent_shield import AmbientBundleAmbiguityError, Shield
        _bundle_auto_bind_import_adapter('openai_agents')
        _bundle_auto_bind_import_adapter('anthropic_agents')
        with pytest.raises(AmbientBundleAmbiguityError) as info:
            Shield.from_yaml(_bundle_auto_bind_MINIMAL)
        assert info.value.registered == ['anthropic_agents', 'openai_agents']
        msg = str(info.value)
        assert "'openai_agents'" in msg
        assert "'anthropic_agents'" in msg
        assert 'auto_bind=False' in msg

    def test_explicit_with_framework_resolves_after_ambiguity(self, _bundle_auto_bind_clean_registry):
        """With ``auto_bind=False`` the ambient lookup is bypassed; the
        explicit ``.with_<framework>()`` call pins a specific bundle
        and ``build()`` succeeds."""
        from agent_shield import Shield
        _bundle_auto_bind_import_adapter('openai_agents')
        _bundle_auto_bind_import_adapter('anthropic_agents')
        shield = Shield.from_yaml(_bundle_auto_bind_MINIMAL, auto_bind=False).with_anthropic_agents().build()
        assert shield.capabilities.framework == 'anthropic_agents'

class TestBundleAutoBindAmbientBundleAmbiguityErrorShape:

    def test_error_carries_sorted_registered_names(self, _bundle_auto_bind_clean_registry):
        from agent_shield import AmbientBundleAmbiguityError
        _bundle_auto_bind_import_adapter('langchain')
        _bundle_auto_bind_import_adapter('openai_agents')
        _bundle_auto_bind_import_adapter('anthropic_agents')
        with pytest.raises(AmbientBundleAmbiguityError) as info:
            _bundle_auto_bind_clean_registry.active_bundle()
        assert info.value.registered == ['anthropic_agents', 'langchain', 'openai_agents']
import sys
_with_langchain_no_side_effect_REPO_ROOT = REPO_ROOT
_with_langchain_no_side_effect_MINIMAL = str(_with_langchain_no_side_effect_REPO_ROOT / 'tests' / 'fixtures' / 'smoke' / 'minimal.guardrails.yaml')

@pytest.fixture
def _with_langchain_no_side_effect_fresh_langchain_state():
    """Simulate "first call in a brand-new interpreter".

    Subsequent runs of the test suite would otherwise inherit the
    ``with_langchain`` method that earlier tests' ``import
    agent_shield.adapters.langchain`` already monkey-patched onto
    ``ShieldBuilder``. To exercise the lazy-import code path we:

    1. Snapshot the current ``ShieldBuilder.with_langchain`` (the
       adapter-installed function, if it exists, otherwise the
       lazy-import stub).
    2. Force-restore the lazy-import stub from the source module so
       this test's call actually goes through it.
    3. Remove the adapter from ``sys.modules`` so the lazy import
       re-runs ``_install()``.
    4. Clear the bundle registry so the auto-bind path matches a
       fresh interpreter's empty state.

    Restore everything after the test so we don't poison sibling
    tests.
    """
    from agent_shield import ShieldBuilder
    from agent_shield.adapters import _bundle_registry
    saved_method = ShieldBuilder.__dict__.get('with_langchain')
    saved_modules = {name: sys.modules[name] for name in list(sys.modules) if name == 'agent_shield.adapters.langchain' or name.startswith('agent_shield.adapters.langchain.')}
    saved_registry = dict(_bundle_registry._REGISTERED)
    import agent_shield

    def _lazy_with_langchain(self):
        return self._lazy_install_adapter('langchain', 'with_langchain')
    ShieldBuilder.with_langchain = _lazy_with_langchain
    for name in list(saved_modules):
        sys.modules.pop(name, None)
    _bundle_registry._REGISTERED.clear()
    assert 'with_langchain' in agent_shield.ShieldBuilder.__dict__, 'lazy stub was not preserved by the test fixture'
    try:
        yield agent_shield
    finally:
        for module_name in list(sys.modules):
            if module_name == 'agent_shield.adapters.langchain' or module_name.startswith('agent_shield.adapters.langchain.'):
                sys.modules.pop(module_name, None)
        if saved_method is not None:
            agent_shield.ShieldBuilder.with_langchain = saved_method
        elif hasattr(agent_shield.ShieldBuilder, 'with_langchain'):
            delattr(agent_shield.ShieldBuilder, 'with_langchain')
        _bundle_registry._REGISTERED.clear()
        _bundle_registry._REGISTERED.update(saved_registry)

def test_with_langchain_no_side_effect__with_langchain_works_without_side_effect_import(_with_langchain_no_side_effect_fresh_langchain_state):
    """The headline regression case.

    From a baseline where the adapter has NOT been imported, the
    three-line drop-in must succeed.
    """
    Shield = _with_langchain_no_side_effect_fresh_langchain_state.Shield
    builder = Shield.from_yaml(_with_langchain_no_side_effect_MINIMAL)
    bound = builder.with_langchain()
    assert bound is builder
    assert 'agent_shield.adapters.langchain' in sys.modules, 'with_langchain() must lazy-import the adapter on first call'
    assert builder._bundle is not None
    assert builder._bundle.name == 'langchain'
    shield = bound.build()
    assert shield.capabilities.framework == 'langchain'

def test_with_langchain_no_side_effect__subsequent_calls_hit_the_installed_method_directly(_with_langchain_no_side_effect_fresh_langchain_state):
    """After the first lazy-import, the class attribute is the
    adapter's real method — the stub is no longer in the resolution
    path. This guards against the stub leaking double-import latency
    into hot paths."""
    Shield = _with_langchain_no_side_effect_fresh_langchain_state.Shield
    ShieldBuilder = _with_langchain_no_side_effect_fresh_langchain_state.ShieldBuilder
    stub = ShieldBuilder.__dict__['with_langchain']
    Shield.from_yaml(_with_langchain_no_side_effect_MINIMAL).with_langchain()
    installed = ShieldBuilder.__dict__['with_langchain']
    assert installed is not stub, "first call must replace the stub with the adapter's real method"

def test_with_langchain_no_side_effect__with_other_framework_methods_have_stubs(_with_langchain_no_side_effect_fresh_langchain_state):
    """The same lazy-import treatment applies to every shipped
    adapter shortcut, not just LangChain — so the friction can't
    recur on the next framework someone integrates."""
    ShieldBuilder = _with_langchain_no_side_effect_fresh_langchain_state.ShieldBuilder
    for name in ('with_langchain', 'with_openai_agents', 'with_anthropic_agents', 'with_autogen', 'with_crewai', 'with_semantic_kernel'):
        assert hasattr(ShieldBuilder, name), f'ShieldBuilder.{name} stub is missing; regression fix is incomplete'
        assert callable(getattr(ShieldBuilder, name))
