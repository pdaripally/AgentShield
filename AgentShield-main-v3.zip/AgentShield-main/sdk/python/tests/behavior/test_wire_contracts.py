"""Behavior tests consolidated into behavior/test_wire_contracts.py."""
from __future__ import annotations
from .._support.paths import REPO_ROOT
import json
from pathlib import Path
from typing import Iterator
import pytest
_wire_fixtures_REPO_ROOT = REPO_ROOT
_wire_fixtures_SCHEMAS_DIR = _wire_fixtures_REPO_ROOT / 'spec' / 'schemas' / 'wire'
_wire_fixtures_FIXTURES_DIR = _wire_fixtures_REPO_ROOT / 'tests' / 'fixtures' / 'wire'

def _wire_fixtures_shape_dirs() -> list[Path]:
    return sorted((p for p in _wire_fixtures_FIXTURES_DIR.iterdir() if p.is_dir()))

def _wire_fixtures_fixture_paths() -> Iterator[tuple[str, Path, Path]]:
    for shape_dir in _wire_fixtures_shape_dirs():
        schema_path = _wire_fixtures_SCHEMAS_DIR / f'{shape_dir.name}.schema.json'
        if not schema_path.exists():
            raise FileNotFoundError(f'No schema for fixture shape {shape_dir.name!r}: {schema_path}')
        for fixture in sorted(shape_dir.glob('*.json')):
            yield (shape_dir.name, fixture, schema_path)
_wire_fixtures_FIXTURE_IDS = [f'{shape}/{fixture.stem}' for shape, fixture, _ in _wire_fixtures_fixture_paths()]
_wire_fixtures_FIXTURE_PARAMS = list(_wire_fixtures_fixture_paths())

@pytest.mark.parametrize('shape,fixture_path,schema_path', _wire_fixtures_FIXTURE_PARAMS, ids=_wire_fixtures_FIXTURE_IDS)
class TestWireFixturesWireFixtures:
    """Every fixture validates against its schema and round-trips."""

    def test_fixture_is_valid_json(self, shape, fixture_path, schema_path):
        with open(fixture_path) as f:
            data = json.load(f)
        assert isinstance(data, dict), f'{fixture_path} is not a JSON object'

    def test_fixture_validates_against_schema(self, shape, fixture_path, schema_path):
        import jsonschema
        with open(schema_path) as f:
            schema = json.load(f)
        with open(fixture_path) as f:
            data = json.load(f)
        jsonschema.validate(data, schema)

    def test_fixture_round_trips(self, shape, fixture_path, schema_path):
        """Serialise → deserialise → re-validate. Stability check."""
        import jsonschema
        with open(schema_path) as f:
            schema = json.load(f)
        with open(fixture_path) as f:
            data = json.load(f)
        serialised = json.dumps(data, sort_keys=True)
        reparsed = json.loads(serialised)
        jsonschema.validate(reparsed, schema)

    def test_fixture_uses_snake_case(self, shape, fixture_path, schema_path):
        """The canonical wire format is snake_case. Catches accidental
        camelCase / PascalCase leakage from SDKs into golden fixtures."""
        with open(fixture_path) as f:
            data = json.load(f)
        for key in _wire_fixtures_all_keys(data):
            assert key.islower() or '_' in key or key.isalpha(), f'Key {key!r} in {fixture_path} is not snake_case'
            assert not any((c.isupper() for c in key)), f'Key {key!r} in {fixture_path} has uppercase characters (canonical wire format is snake_case)'

def _wire_fixtures_all_keys(obj) -> Iterator[str]:
    """Recursively yield every dict key in a JSON document."""
    if isinstance(obj, dict):
        for key, value in obj.items():
            yield key
            yield from _wire_fixtures_all_keys(value)
    elif isinstance(obj, list):
        for item in obj:
            yield from _wire_fixtures_all_keys(item)

class TestWireFixturesFixtureCoverage:
    """Every wire shape has at least one fixture."""

    def test_every_schema_has_fixtures(self):
        for schema_path in sorted(_wire_fixtures_SCHEMAS_DIR.glob('*.schema.json')):
            shape = schema_path.stem.replace('.schema', '')
            shape_dir = _wire_fixtures_FIXTURES_DIR / shape
            assert shape_dir.is_dir(), f'Schema {schema_path.name} has no fixtures directory under {_wire_fixtures_FIXTURES_DIR}'
            fixtures = list(shape_dir.glob('*.json'))
            assert fixtures, f'Schema {schema_path.name} has no fixtures in {shape_dir}'

    def test_no_orphan_fixture_dirs(self):
        for shape_dir in _wire_fixtures_shape_dirs():
            schema_path = _wire_fixtures_SCHEMAS_DIR / f'{shape_dir.name}.schema.json'
            assert schema_path.exists(), f'Fixture directory {shape_dir.name} has no matching schema at {schema_path}'
import dataclasses
from typing import Any, Dict
_wire_schemas_REPO_ROOT = REPO_ROOT
_wire_schemas_SCHEMAS_DIR = _wire_schemas_REPO_ROOT / 'spec' / 'schemas' / 'wire'
_wire_schemas_GLOBAL_FIXTURES = _wire_schemas_REPO_ROOT / 'tests' / 'fixtures'
_wire_schemas_MINIMAL = str(_wire_schemas_GLOBAL_FIXTURES / 'smoke' / 'minimal.guardrails.yaml')

def _wire_schemas_load_schema(name: str) -> Dict[str, Any]:
    path = _wire_schemas_SCHEMAS_DIR / f'{name}.schema.json'
    with open(path) as f:
        return json.load(f)

def _wire_schemas_validator(schema: Dict[str, Any]):
    import jsonschema
    return jsonschema.Draft7Validator(schema)

@pytest.mark.parametrize('name', ['stage_verdict', 'variable_state', 'resolver_request', 'resolver_response', 'delegate_request', 'llm_response', 'classifier_verdict', 'shield_log_event', 'capability_report'])
def test_wire_schemas__schema_is_valid_json_schema(name: str):
    schema = _wire_schemas_load_schema(name)
    import jsonschema
    jsonschema.Draft7Validator.check_schema(schema)
    assert schema['$schema'] == 'http://json-schema.org/draft-07/schema#'
    assert schema['$id'].startswith('https://github.com/microsoft/AgentShield/spec/schemas/wire/')

def _wire_schemas_verdict_to_dict(v: Any) -> Dict[str, Any]:
    """Convert a StageVerdict into the canonical wire dict.

    The Python ``StageVerdict`` is a dataclass; ``dataclasses.asdict``
    produces a shape compatible with the wire schema (modulo Python's
    None ↔ JSON null mapping which the validator accepts).
    """
    return dataclasses.asdict(v)

class TestWireSchemasStageVerdictAgainstRuntime:
    """Real verdicts from Session.validate_* validate against the schema."""

    def test_validate_input_verdict(self):
        from agent_shield import RuntimeBuilder
        rt = RuntimeBuilder.from_yaml(_wire_schemas_MINIMAL).build()
        with rt.new_session() as session:
            session.begin_turn()
            verdict = session.validate_input('hello')
        d = _wire_schemas_verdict_to_dict(verdict)
        _wire_schemas_validator(_wire_schemas_load_schema('stage_verdict')).validate(d)

    def test_validate_tool_call_verdict(self):
        from agent_shield import RuntimeBuilder
        rt = RuntimeBuilder.from_yaml(_wire_schemas_MINIMAL).build()
        with rt.new_session() as session:
            session.begin_turn()
            outcome = session.validate_tool_call('echo', {'msg': 'hi'}, tool_call_id='call_1')
        d = _wire_schemas_verdict_to_dict(outcome.verdict)
        _wire_schemas_validator(_wire_schemas_load_schema('stage_verdict')).validate(d)

    def test_validate_output_verdict(self):
        from agent_shield import RuntimeBuilder
        rt = RuntimeBuilder.from_yaml(_wire_schemas_MINIMAL).build()
        with rt.new_session() as session:
            session.begin_turn()
            outcome = session.validate_output('hello world')
        d = _wire_schemas_verdict_to_dict(outcome.verdict)
        _wire_schemas_validator(_wire_schemas_load_schema('stage_verdict')).validate(d)

class TestWireSchemasStageVerdictCounterexamples:
    """The schema rejects malformed StageVerdicts."""

    def test_missing_allowed_field_rejected(self):
        from jsonschema import ValidationError
        v = _wire_schemas_validator(_wire_schemas_load_schema('stage_verdict'))
        with pytest.raises(ValidationError):
            v.validate({'reason': 'blocked'})

    def test_invalid_action_rejected(self):
        from jsonschema import ValidationError
        v = _wire_schemas_validator(_wire_schemas_load_schema('stage_verdict'))
        with pytest.raises(ValidationError):
            v.validate({'allowed': True, 'action': 'explode'})

    def test_extra_fields_rejected(self):
        from jsonschema import ValidationError
        v = _wire_schemas_validator(_wire_schemas_load_schema('stage_verdict'))
        with pytest.raises(ValidationError):
            v.validate({'allowed': True, 'spurious_field': 'nope'})

class TestWireSchemasVariableStateAgainstRuntime:
    """Real variable states validate against the schema."""

    def test_unset_state(self):
        v = _wire_schemas_validator(_wire_schemas_load_schema('variable_state'))
        v.validate({'status': 'unset'})

    def test_resolved_state(self):
        v = _wire_schemas_validator(_wire_schemas_load_schema('variable_state'))
        v.validate({'status': 'resolved', 'value': True, 'set_at': '2026-05-06T20:00:00Z', 'set_by': 'host', 'source_kind': 'host'})

    def test_denied_state(self):
        v = _wire_schemas_validator(_wire_schemas_load_schema('variable_state'))
        v.validate({'status': 'denied', 'deny_reason': 'user denied'})

    def test_invalid_status_rejected(self):
        from jsonschema import ValidationError
        v = _wire_schemas_validator(_wire_schemas_load_schema('variable_state'))
        with pytest.raises(ValidationError):
            v.validate({'status': 'frozen'})

class TestWireSchemasResolverRequestResponseShapes:
    """Resolver request / response shapes validate."""

    def test_request_minimum(self):
        v = _wire_schemas_validator(_wire_schemas_load_schema('resolver_request'))
        v.validate({'request_id': 'req-1'})

    def test_request_full(self):
        v = _wire_schemas_validator(_wire_schemas_load_schema('resolver_request'))
        v.validate({'request_id': 'req-2', 'variable': 'send_authorized', 'resource_kind': 'tool', 'resource_name': 'send_message', 'prompt': 'Approve send?', 'reason': 'user policy', 'context': {'foo': 'bar'}, 'requested_key': 'channel-42'})

    def test_response_allow(self):
        v = _wire_schemas_validator(_wire_schemas_load_schema('resolver_response'))
        v.validate({'decision': 'allow', 'value': True})

    def test_response_deny(self):
        v = _wire_schemas_validator(_wire_schemas_load_schema('resolver_response'))
        v.validate({'decision': 'deny', 'reason': 'user denied'})

    def test_response_invalid_decision_rejected(self):
        from jsonschema import ValidationError
        v = _wire_schemas_validator(_wire_schemas_load_schema('resolver_response'))
        with pytest.raises(ValidationError):
            v.validate({'decision': 'maybe'})

class TestWireSchemasDelegateRequestShape:
    """Delegate request envelope."""

    def test_delegate_minimum(self):
        v = _wire_schemas_validator(_wire_schemas_load_schema('delegate_request'))
        v.validate({'request_id': 'del-1', 'configuration': {'endpoint': 'https://approve.example'}, 'effective_timeout_ms': 5000})

    def test_delegate_full(self):
        v = _wire_schemas_validator(_wire_schemas_load_schema('delegate_request'))
        v.validate({'request_id': 'del-2', 'variable': 'kyc', 'configuration': {'endpoint': 'https://kyc.example'}, 'effective_timeout_ms': 10000, 'resource_kind': 'tool', 'resource_name': 'request_kyc', 'prompt': 'Run KYC for user', 'context': {'user_id': 'u1'}, 'requested_key': 'u1'})

class TestWireSchemasLlmResponseShape:

    def test_allow(self):
        v = _wire_schemas_validator(_wire_schemas_load_schema('llm_response'))
        v.validate({'decision': 'allow', 'reason': 'ok'})

    def test_deny_with_redactions(self):
        v = _wire_schemas_validator(_wire_schemas_load_schema('llm_response'))
        v.validate({'decision': 'deny', 'reason': 'PII detected', 'redactions': [{'start': 0, 'end': 5, 'replacement': '[REDACTED]'}]})

class TestWireSchemasClassifierVerdictShape:

    def test_score_below_threshold(self):
        v = _wire_schemas_validator(_wire_schemas_load_schema('classifier_verdict'))
        v.validate({'score': 0.1, 'threshold': 0.5, 'flagged': False})

    def test_score_above_threshold(self):
        v = _wire_schemas_validator(_wire_schemas_load_schema('classifier_verdict'))
        v.validate({'score': 0.95, 'threshold': 0.5, 'flagged': True, 'categories': ['pii', 'secrets']})

class TestWireSchemasCapabilityReportShape:
    """Real capability reports from the adapters validate."""

    def test_openai_agents_report(self):
        from agent_shield.adapters.openai_agents import _BUNDLE
        rep = _BUNDLE.capabilities
        d = {'framework': rep.framework, 'input_validation': rep.input_validation.value, 'state_validation': rep.state_validation.value, 'tool_authorization': rep.tool_authorization.value, 'tool_execution_validation': rep.tool_execution_validation.value, 'tool_output_validation': rep.tool_output_validation.value, 'output_validation': rep.output_validation.value, 'streaming_output': rep.streaming_output.value, 'notes': list(rep.notes)}
        _wire_schemas_validator(_wire_schemas_load_schema('capability_report')).validate(d)

    def test_crewai_report_with_unsupported_streaming(self):
        from agent_shield.adapters.crewai import _BUNDLE
        rep = _BUNDLE.capabilities
        d = {'framework': rep.framework, 'input_validation': rep.input_validation.value, 'state_validation': rep.state_validation.value, 'tool_authorization': rep.tool_authorization.value, 'tool_execution_validation': rep.tool_execution_validation.value, 'tool_output_validation': rep.tool_output_validation.value, 'output_validation': rep.output_validation.value, 'streaming_output': rep.streaming_output.value, 'notes': list(rep.notes)}
        _wire_schemas_validator(_wire_schemas_load_schema('capability_report')).validate(d)
        assert d['streaming_output'] == 'unsupported'

    def test_mcp_report(self):
        from agent_shield.mcp import MCPShield
        shield = MCPShield.from_yaml(_wire_schemas_MINIMAL).build()
        rep = shield.capabilities
        d = {'framework': rep.framework, 'input_validation': rep.input_validation.value, 'state_validation': rep.state_validation.value, 'tool_authorization': rep.tool_authorization.value, 'tool_execution_validation': rep.tool_execution_validation.value, 'tool_output_validation': rep.tool_output_validation.value, 'output_validation': rep.output_validation.value, 'streaming_output': rep.streaming_output.value, 'notes': list(rep.notes)}
        _wire_schemas_validator(_wire_schemas_load_schema('capability_report')).validate(d)

class TestWireSchemasShieldLogEventShape:
    """Real observability events validate."""

    def test_real_runtime_event(self):
        from agent_shield import RuntimeBuilder
        from agent_shield.observability import CapturingProvider
        cap = CapturingProvider()
        rt = RuntimeBuilder.from_yaml(_wire_schemas_MINIMAL).register_observability_provider(cap).build()
        with rt.new_session() as session:
            session.begin_turn()
            session.validate_input('hi')
            session.end_turn()
        assert len(cap.events) > 0
        v = _wire_schemas_validator(_wire_schemas_load_schema('shield_log_event'))
        for event in cap.events:
            d = {'event_type': event.event_type, 'event_name': getattr(event, 'event_name', None), 'timestamp': event.timestamp, 'session_id': getattr(event, 'session_id', None), 'correlation_id': getattr(event, 'correlation_id', None), 'stage': getattr(event, 'stage', None), 'attributes': dict(event.attributes)}
            v.validate(d)
