"""Behavior tests consolidated into behavior/test_runtime_core.py."""
from __future__ import annotations
from .._support.paths import LOCAL_FIXTURES, REPO_ROOT
from typing import List
import pytest
_runtime_REPO_ROOT = REPO_ROOT
_runtime_GLOBAL_FIXTURES = _runtime_REPO_ROOT / 'tests' / 'fixtures'
_runtime_LOCAL_FIXTURES = LOCAL_FIXTURES
_runtime_MINIMAL = str(_runtime_GLOBAL_FIXTURES / 'smoke' / 'minimal.guardrails.yaml')
_runtime_VARS_AND_EVENTS = str(_runtime_GLOBAL_FIXTURES / 'smoke' / 'variables-and-events.guardrails.yaml')
_runtime_GUARD_POLICY_MERGE = str(_runtime_GLOBAL_FIXTURES / 'smoke' / 'guard-policy-merge.guardrails.yaml')
_runtime_APPROVAL = str(_runtime_LOCAL_FIXTURES / 'approval.guardrails.yaml')
_runtime_REDACT = str(_runtime_GLOBAL_FIXTURES / 'smoke' / 'redact.guardrails.yaml')

class TestRuntimePackageImports:
    """The public namespace is published cleanly."""

    def test_import_namespace(self):
        import agent_shield as sdk
        assert hasattr(sdk, 'RuntimeBuilder')
        assert hasattr(sdk, 'Runtime')
        assert hasattr(sdk, 'Session')
        assert hasattr(sdk, 'StageVerdict')
        assert hasattr(sdk, 'Lifetime')

    def test_canonical_module_importable(self):
        import agent_shield
        assert hasattr(agent_shield, 'RuntimeBuilder')
        assert hasattr(agent_shield, 'Runtime')
        assert hasattr(agent_shield, 'Session')

    def test_native_submodule_present(self):
        import agent_shield._native as native
        assert hasattr(native, 'RuntimeBuilder')
        assert hasattr(native, 'GuardrailsRuntime')
        assert hasattr(native, 'GuardrailsSession')
        assert hasattr(native, 'StreamingGuard')

    def test_hook_protocols_exposed(self):
        from agent_shield import AgentResolver, DelegateDispatcher, LlmCaller, ClassifierCaller, ObservabilityProvider
        assert AgentResolver is not None
        assert DelegateDispatcher is not None
        assert LlmCaller is not None
        assert ClassifierCaller is not None
        assert ObservabilityProvider is not None

class TestRuntimeRuntimeBuilder:
    """Builder loads YAML and produces an immutable runtime."""

    def test_from_yaml_minimal(self):
        from agent_shield import RuntimeBuilder
        rt = RuntimeBuilder.from_yaml(_runtime_MINIMAL).build()
        assert rt.metadata_name == 'smoke-minimal'

    def test_from_yaml_variables_and_events(self):
        from agent_shield import RuntimeBuilder
        rt = RuntimeBuilder.from_yaml(_runtime_VARS_AND_EVENTS).build()
        names = set(rt.variable_names)
        assert 'send_authorized' in names
        assert 'messages_sent' in names

    def test_from_yaml_guard_policy_merge(self):
        from agent_shield import RuntimeBuilder
        rt = RuntimeBuilder.from_yaml(_runtime_GUARD_POLICY_MERGE).build()
        assert 'leaf' in rt.metadata_name

    def test_from_yaml_chain(self):
        from agent_shield import RuntimeBuilder
        rt = RuntimeBuilder.from_yaml_chain([_runtime_MINIMAL]).build()
        assert rt.metadata_name == 'smoke-minimal'

    def test_builder_is_consumed_by_build(self):
        from agent_shield import RuntimeBuilder
        builder = RuntimeBuilder.from_yaml(_runtime_MINIMAL)
        builder.build()
        with pytest.raises(Exception):
            builder.build()

    def test_register_extractor(self):
        from agent_shield import RuntimeBuilder
        rt = RuntimeBuilder.from_yaml(_runtime_MINIMAL).register_extractor('test.identity', lambda v: v).build()
        assert rt.metadata_name == 'smoke-minimal'

class TestRuntimeSessionLifecycle:

    def _runtime(self, path: str=_runtime_MINIMAL):
        from agent_shield import RuntimeBuilder
        return RuntimeBuilder.from_yaml(path).build()

    def test_default_request_context(self):
        rt = self._runtime()
        session = rt.new_session()
        assert session.current_turn_id == 0

    def test_explicit_request_context(self):
        rt = self._runtime()
        session = rt.new_session(session_id='sess-42', correlation_id='corr-42', user_id='alice', tenant_id='acme', extensions={'region': 'EU'})
        assert session.current_turn_id == 0

    def test_begin_end_turn(self):
        rt = self._runtime()
        session = rt.new_session(session_id='s1', correlation_id='c1')
        assert session.begin_turn() == 1
        assert session.current_turn_id == 1
        session.end_turn()

    def test_multiple_turns(self):
        rt = self._runtime()
        session = rt.new_session(session_id='s1', correlation_id='c1')
        assert session.begin_turn() == 1
        session.end_turn()
        assert session.begin_turn() == 2

    def test_begin_end_request(self):
        rt = self._runtime()
        session = rt.new_session(session_id='s1', correlation_id='c1')
        assert session.begin_request() == 1
        session.end_request()

    def test_session_context_manager(self):
        rt = self._runtime()
        with rt.new_session(session_id='s1', correlation_id='c1') as session:
            session.begin_turn()
            session.begin_request()
            assert session.current_turn_id == 1

class TestRuntimeVariableOps:

    def _session(self):
        from agent_shield import RuntimeBuilder
        rt = RuntimeBuilder.from_yaml(_runtime_MINIMAL).build()
        s = rt.new_session(session_id='s1', correlation_id='c1')
        s.begin_turn()
        return s

    def test_unknown_variable_raises(self):
        s = self._session()
        with pytest.raises(Exception):
            s.set_variable('nonexistent_var', True)

    def test_read_unknown_variable_returns_none(self):
        s = self._session()
        assert s.read_variable('nonexistent_var') is None

    def test_large_unsigned_int_roundtrip(self):
        from agent_shield import RuntimeBuilder
        rt = RuntimeBuilder.from_yaml(_runtime_VARS_AND_EVENTS).build()
        s = rt.new_session(session_id='s1', correlation_id='c1')
        s.begin_turn()
        big = 2 ** 63 + 7
        s.set_variable('recipient_profile', {'id': big})
        state = s.read_variable('recipient_profile')
        assert state is not None
        assert state.value == {'id': big}
        assert isinstance(state.value['id'], int)

class TestRuntimeStageValidation:

    def _session(self, path: str=_runtime_MINIMAL):
        from agent_shield import RuntimeBuilder
        rt = RuntimeBuilder.from_yaml(path).build()
        s = rt.new_session(session_id='s1', correlation_id='c1')
        s.begin_turn()
        return s

    def test_stage_verdict_truthiness(self):
        s = self._session()
        v = s.validate_input('hello')
        assert bool(v) == v.allowed

class TestRuntimeEventOps:

    def test_invalid_event_id_raises(self):
        from agent_shield import RuntimeBuilder
        rt = RuntimeBuilder.from_yaml(_runtime_MINIMAL).build()
        with rt.new_session(session_id='s1', correlation_id='c1') as session:
            with pytest.raises(Exception):
                session.emit_event('not a real event id 🚫')

class TestRuntimeHumanResolverRuntimeBound:
    """`kind: human` dispatches through the host-registered runtime
    handler. Missing handlers fail closed; YAML provider/name selection
    is rejected at load time."""

    _yaml = '\nmetadata:\n  name: "py-test-human-runtime"\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["block until authorized"]\n  forbidden: ["skip"]\nresources:\n  tools:\n    - name: "send_message"\n      description: "Send a message."\n      permission: "execute"\nvariables:\n  - name: "send_authorized"\n    type: "boolean"\n    on_demand_by:\n      kind: "human"\n      prompt: "Authorize sending message?"\n    lifetime: "per_session"\nstate_validation:\n  guard_policies:\n    - name: "send_requires_authorization"\n      applies_to:\n        tools: ["send_message"]\n      evaluate_when:\n        - expression: "send_authorized == true"\n          reason: "Send was not authorized for this call."\n      action: "block"\n'

    def _write(self, yaml: str):
        import tempfile
        f = tempfile.NamedTemporaryFile('w', suffix='.guardrails.yaml', delete=False)
        f.write(yaml)
        f.close()
        return f.name

    def test_kind_human_without_registered_handler_denies_fail_closed(self):
        from agent_shield import RuntimeBuilder
        import os
        path = self._write(self._yaml)
        try:
            rt = RuntimeBuilder.from_yaml(path).build()
            with rt.new_session(session_id='s1', correlation_id='c1') as session:
                session.begin_turn()
                blocked = session.validate_tool_call('send_message', {'msg': 'hi'}, tool_call_id='call_1')
                assert blocked.verdict.allowed is False
                assert blocked.verdict.pending_resolution is None
        finally:
            os.unlink(path)

    def test_kind_human_resolve_variable_returns_none_when_unregistered(self):
        from agent_shield import RuntimeBuilder
        rt = RuntimeBuilder.from_yaml(_runtime_APPROVAL).build()
        with rt.new_session(session_id='s1', correlation_id='c1') as session:
            session.begin_turn()
            value = session.resolve_variable('send_authorized')
            assert value is None

    def test_provider_field_is_rejected_at_load_time(self):
        from agent_shield import RuntimeBuilder
        import os
        yaml = self._yaml.replace('      prompt:', '      provider: auto_reject\n      prompt:')
        path = self._write(yaml)
        try:
            with pytest.raises(Exception) as excinfo:
                RuntimeBuilder.from_yaml(path)
            msg = str(excinfo.value)
            assert 'provider' in msg and 'not allowed' in msg
        finally:
            os.unlink(path)

    def test_name_field_is_rejected_at_load_time(self):
        from agent_shield import RuntimeBuilder
        import os
        yaml = self._yaml.replace('      prompt:', '      name: user_approval\n      prompt:')
        path = self._write(yaml)
        try:
            with pytest.raises(Exception) as excinfo:
                RuntimeBuilder.from_yaml(path)
            msg = str(excinfo.value)
            assert 'name' in msg and 'not allowed' in msg
        finally:
            os.unlink(path)

class TestRuntimeObservability:

    def test_capturing_provider_receives_events(self):
        from agent_shield import RuntimeBuilder
        from agent_shield.observability import CapturingProvider
        provider = CapturingProvider()
        rt = RuntimeBuilder.from_yaml(_runtime_MINIMAL).register_observability_provider(provider).build()
        with rt.new_session(session_id='s1', correlation_id='c1') as session:
            session.begin_turn()
            session.validate_input('hello')
            session.set_variable('authorized', True)
            session.validate_tool_call('echo', {'msg': 'hi'}, tool_call_id='call_1')
            session.end_turn()
        assert len(provider.events) > 0
        sample = provider.events[0]
        assert sample.severity in {'info', 'low', 'medium', 'high', 'critical'}
        assert sample.event_type

    def test_otel_genai_attributes_emitted_on_every_event(self):
        from agent_shield import RuntimeBuilder
        from agent_shield.observability import CapturingProvider
        cap = CapturingProvider()
        rt = RuntimeBuilder.from_yaml(_runtime_MINIMAL).register_observability_provider(cap).build()
        with rt.new_session(session_id='s1', correlation_id='c1') as session:
            session.begin_turn()
            session.validate_tool_call('echo', {'msg': 'hi'}, tool_call_id='call_1')
            session.end_turn()
        assert len(cap.events) > 0
        for ev in cap.events:
            attrs = ev.attributes
            assert attrs.get('gen_ai.system') == 'agent_shield', f'event {ev.event_type} missing gen_ai.system'
            assert 'gen_ai.operation.name' in attrs, f'event {ev.event_type} missing gen_ai.operation.name'
        block_events = [ev for ev in cap.events if ev.attributes.get('gen_ai.response.finish_reason') == 'content_filter']
        assert len(block_events) > 0, 'block events must carry gen_ai.response.finish_reason=content_filter'

    def test_callable_provider_accepted(self):
        from agent_shield import RuntimeBuilder
        from agent_shield.observability import ShieldLogEvent
        sink: List[ShieldLogEvent] = []
        rt = RuntimeBuilder.from_yaml(_runtime_MINIMAL).register_observability_provider(sink.append).build()
        with rt.new_session(session_id='s1', correlation_id='c1') as session:
            session.begin_turn()
            session.set_variable('authorized', True)
        assert len(sink) > 0
        for ev in sink:
            assert isinstance(ev, ShieldLogEvent)

class TestRuntimeStreaming:

    def test_streaming_redacts_secret(self):
        from agent_shield import RuntimeBuilder
        rt = RuntimeBuilder.from_yaml(_runtime_REDACT).build()
        with rt.new_session(session_id='s1', correlation_id='c1') as session:
            session.begin_turn()
            with session.streaming_session(stage=5) as guard:
                guard.push('Here is ')
                guard.push('the token SECRET-AB12CD34, careful.')
                final = guard.finish()
            assert 'SECRET-AB12CD34' not in final.payload

    def test_streaming_session_str_alias(self):
        from agent_shield import RuntimeBuilder
        rt = RuntimeBuilder.from_yaml(_runtime_REDACT).build()
        with rt.new_session(session_id='s1', correlation_id='c1') as session:
            session.begin_turn()
            with session.streaming_session(stage='output') as guard:
                guard.push('All clean text here.')
                final = guard.finish()
            assert 'All clean text here.' in final.payload

    def test_streaming_process_iterator(self):
        from agent_shield import RuntimeBuilder
        rt = RuntimeBuilder.from_yaml(_runtime_REDACT).build()
        with rt.new_session(session_id='s1', correlation_id='c1') as session:
            session.begin_turn()
            chunks = ['part one ', 'part two ', 'part three']
            with session.streaming_session(stage=5) as guard:
                output = ''.join(guard.process(chunks))
            assert 'part one' in output
            assert 'part three' in output

    def test_streaming_buffer_property(self):
        from agent_shield import RuntimeBuilder
        rt = RuntimeBuilder.from_yaml(_runtime_REDACT).build()
        with rt.new_session(session_id='s1', correlation_id='c1') as session:
            session.begin_turn()
            guard = session.streaming_session(stage=5)
            guard.push('abc')
            guard.push('def')
            assert 'abcdef' in guard.buffer
            assert guard.chunks_received == 2
            guard.finish()
            assert guard.is_ended

    def test_streaming_mode_defaults_to_on_complete(self):
        from agent_shield import RuntimeBuilder
        rt = RuntimeBuilder.from_yaml(_runtime_REDACT).build()
        with rt.new_session(session_id='s1', correlation_id='c1') as session:
            session.begin_turn()
            with session.streaming_session(stage=5) as guard:
                assert guard.mode == 'on_complete'

    def test_streaming_on_complete_buffers_until_finish(self):
        from agent_shield import RuntimeBuilder
        rt = RuntimeBuilder.from_yaml(_runtime_REDACT).build()
        with rt.new_session(session_id='s1', correlation_id='c1') as session:
            session.begin_turn()
            with session.streaming_session(stage=5) as guard:
                assert guard.mode == 'on_complete'
                r1 = guard.push('Here is ')
                r2 = guard.push('the token SECRET-AB12CD34, careful.')
                assert r1.action == 'pass'
                assert r1.payload == ''
                assert r2.action == 'pass'
                assert r2.payload == ''
                final = guard.finish()
            assert 'SECRET-AB12CD34' not in final.payload
            assert len(final.payload) > 0

class TestRuntimeResourceRecordHooks:

    def _session(self):
        from agent_shield import RuntimeBuilder
        rt = RuntimeBuilder.from_yaml(_runtime_MINIMAL).build()
        s = rt.new_session(session_id='s1', correlation_id='c1')
        s.begin_turn()
        return s

    def test_record_tool_success(self):
        s = self._session()
        s.record_tool_success('echo', {'out': 'ok'})

    def test_record_tool_failure(self):
        s = self._session()
        s.record_tool_failure('echo', 'boom')

    def test_record_endpoint_helpers(self):
        s = self._session()
        s.record_endpoint_success('GET', '/api/x', {'ok': True})
        s.record_endpoint_failure('GET', '/api/x', 'boom')

    def test_record_agent_helpers(self):
        s = self._session()
        s.record_agent_success('subagent', {'ok': True})
        s.record_agent_failure('subagent', 'boom')

class TestRuntimeLifetimeHelper:

    def test_per_call(self):
        from agent_shield import Lifetime
        assert Lifetime.per_call().to_native() == 'per_call'

    def test_per_session(self):
        from agent_shield import Lifetime
        assert Lifetime.per_session().to_native() == 'per_session'

    def test_for_duration(self):
        from agent_shield import Lifetime
        assert Lifetime.for_duration('PT5M').to_native() == {'for': 'PT5M'}

    def test_until_event_single(self):
        from agent_shield import Lifetime
        assert Lifetime.until_event('session.end').to_native() == {'until_event': 'session.end'}

    def test_until_event_multi(self):
        from agent_shield import Lifetime
        v = Lifetime.until_event('session.end', 'turn.end').to_native()
        assert v == {'until_event': ['session.end', 'turn.end']}

    def test_until_event_rejects_empty(self):
        import pytest
        from agent_shield import Lifetime
        with pytest.raises(ValueError, match='at least one event id'):
            Lifetime.until_event()

    def test_map_form(self):
        from agent_shield import Lifetime
        v = Lifetime.map(allow='per_call', deny='per_session').to_native()
        assert v == {'allow': 'per_call', 'deny': 'per_session'}

class TestRuntimeEnvelopes:

    def test_resolver_response_to_dict(self):
        from agent_shield.hooks import ResolverResponse
        r = ResolverResponse(decision='allow', value=42, reason='ok')
        d = r.to_dict()
        assert d['decision'] == 'allow'
        assert d['value'] == 42
        assert d['reason'] == 'ok'

    def test_resolver_response_set_variables(self):
        from agent_shield.hooks import ResolverResponse
        r = ResolverResponse(decision='allow', set_variables={'x': 1, 'y': 'two'})
        d = r.to_dict()
        assert d['set_variables'] == {'x': 1, 'y': 'two'}

    def test_resolver_request_from_dict(self):
        from agent_shield.hooks import ResolverRequest
        req = ResolverRequest.from_dict({'request_id': 'abc', 'variable': 'v', 'context': {'a': 1}})
        assert req.request_id == 'abc'
        assert req.variable == 'v'
        assert req.context == {'a': 1}
from agent_shield import Shield, ShieldBuilder
_builder_consume_REPO_ROOT = REPO_ROOT
_builder_consume_MINIMAL = str(_builder_consume_REPO_ROOT / 'tests' / 'fixtures' / 'smoke' / 'minimal.guardrails.yaml')
_builder_consume_EXPECTED_MESSAGE = 'ShieldBuilder.build() can only be called once. Call Shield.from_yaml(...) again to create a new builder.'

def _builder_consume_fresh_builder() -> ShieldBuilder:
    """Return a freshly-bound ShieldBuilder ready to be built."""
    return Shield.from_yaml(_builder_consume_MINIMAL, auto_bind=False).with_langchain()

class TestBuilderConsumeConsumeOnBuild:

    def test_first_build_returns_working_shield(self) -> None:
        shield = _builder_consume_fresh_builder().build()
        assert isinstance(shield, Shield)

    def test_second_build_raises_runtime_error(self) -> None:
        builder = _builder_consume_fresh_builder()
        builder.build()
        with pytest.raises(RuntimeError) as excinfo:
            builder.build()
        assert str(excinfo.value) == _builder_consume_EXPECTED_MESSAGE

    def test_with_mode_after_build_raises(self) -> None:
        builder = _builder_consume_fresh_builder()
        builder.build()
        with pytest.raises(RuntimeError) as excinfo:
            builder.with_mode('monitor')
        assert str(excinfo.value) == _builder_consume_EXPECTED_MESSAGE

    def test_with_on_block_after_build_raises(self) -> None:
        builder = _builder_consume_fresh_builder()
        builder.build()
        with pytest.raises(RuntimeError) as excinfo:
            builder.with_on_block('throw')
        assert str(excinfo.value) == _builder_consume_EXPECTED_MESSAGE

    def test_with_extension_after_build_raises(self) -> None:
        builder = _builder_consume_fresh_builder()
        builder.build()
        with pytest.raises(RuntimeError) as excinfo:
            builder.with_extension(lambda _b: None)
        assert str(excinfo.value) == _builder_consume_EXPECTED_MESSAGE

    def test_bind_to_bundle_after_build_raises(self) -> None:
        """Adapter-installed ``with_<framework>()`` methods route through
        ``_bind_to_bundle`` so they too must reject post-build calls."""
        builder = _builder_consume_fresh_builder()
        builder.build()
        with pytest.raises(RuntimeError) as excinfo:
            builder.with_langchain()
        assert str(excinfo.value) == _builder_consume_EXPECTED_MESSAGE

    def test_fresh_from_yaml_produces_independent_builder(self) -> None:
        """A fresh ``Shield.from_yaml`` call always yields a usable builder.

        The consume flag is per-instance — the customer-facing escape hatch
        for "I built once and need a second Shield" is to call
        ``Shield.from_yaml(...)`` again.
        """
        first = _builder_consume_fresh_builder().build()
        assert isinstance(first, Shield)
        second = _builder_consume_fresh_builder().with_mode('monitor').build()
        assert isinstance(second, Shield)

    def test_error_message_names_the_type(self) -> None:
        builder = _builder_consume_fresh_builder()
        builder.build()
        with pytest.raises(RuntimeError) as excinfo:
            builder.build()
        msg = str(excinfo.value)
        assert 'ShieldBuilder.build()' in msg
        assert 'Shield.from_yaml(...)' in msg
import asyncio
from typing import Any
from agent_shield import RuntimeBuilder
from agent_shield.adapters._shield import Shield, ShieldMode  # noqa: F811
_shadow_runtime_sdk_SHADOW_INPUT_BLOCK_YAML = '\n\nmetadata:\n  name: shadow-sdk-input-block\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["test"]\nresources:\n  tools:\n    - name: echo\n      permission: read_only\ninput_validation:\n  guard_policies:\n    - name: block_secret\n      evaluate_when:\n        - pattern: "(?i)secret"\n          reason: "input contained secret"\n          action: block\n'
_shadow_runtime_sdk_SHADOW_TOOL_REDACT_YAML = '\n\nmetadata:\n  name: shadow-sdk-tool-redact\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["test"]\nresources:\n  tools:\n    - name: echo\n      permission: read_only\ntool_execution_validation:\n  guard_policies:\n    - name: redact_ssn\n      applies_to: { tools: ["echo"] }\n      evaluate_when:\n        - pattern: \'\\d{3}-\\d{2}-\\d{4}\'\n          reason: ssn\n          action: redact\n      replacement: "[X]"\n'

def _shadow_runtime_sdk_build_runtime(yaml: str):
    return RuntimeBuilder.from_yaml_strings([yaml]).with_mode('shadow').build()

def test_shadow_runtime_sdk__shadow_runtime_auto_folds_shield_to_monitor() -> None:
    rt = _shadow_runtime_sdk_build_runtime(_shadow_runtime_sdk_SHADOW_INPUT_BLOCK_YAML)
    s = Shield(rt, mode=ShieldMode.ENFORCE)
    assert s.mode is ShieldMode.MONITOR

def test_shadow_runtime_sdk__shadow_runtime_run_does_not_block_on_stage1_deny() -> None:
    rt = _shadow_runtime_sdk_build_runtime(_shadow_runtime_sdk_SHADOW_INPUT_BLOCK_YAML)
    s = Shield(rt, mode=ShieldMode.ENFORCE)

    async def _execute() -> str:
        return 'ok'
    result = asyncio.run(s.run(_execute, user_input='this contains secret stuff'))
    assert result == 'ok', f'shadow Shield.run must proceed to execute() even when Stage 1 would have blocked; got {result!r}'

def test_shadow_runtime_sdk__shadow_runtime_before_invoke_returns_none_on_block() -> None:
    rt = _shadow_runtime_sdk_build_runtime(_shadow_runtime_sdk_SHADOW_INPUT_BLOCK_YAML)
    s = Shield(rt, mode=ShieldMode.ENFORCE)
    out = asyncio.run(s.before_invoke('this is a secret'))
    assert out is None, f'shadow Shield.before_invoke must return None so the caller proceeds, even when Stage 1 would have blocked; got {out!r}'

def test_shadow_runtime_sdk__shadow_runtime_protect_tool_does_not_mutate_params() -> None:
    rt = _shadow_runtime_sdk_build_runtime(_shadow_runtime_sdk_SHADOW_TOOL_REDACT_YAML)
    s = Shield(rt, mode=ShieldMode.ENFORCE)
    captured: dict[str, Any] = {}

    async def _exec(effective_params: Any) -> str:
        captured['params'] = effective_params
        return 'tool ran'
    blocked, output = asyncio.run(s.protect_tool('echo', {'msg': 'id 123-45-6789'}, _exec))
    assert blocked is False
    assert output == 'tool ran'
    assert '123-45-6789' in captured['params']['msg'], f'shadow Shield.protect_tool must pass the ORIGINAL params to the tool, never the redacted ones; got {captured["params"]!r}'
