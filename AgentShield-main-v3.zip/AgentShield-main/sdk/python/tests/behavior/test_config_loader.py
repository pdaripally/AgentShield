"""Behavior tests consolidated into behavior/test_config_loader.py."""
from __future__ import annotations
from .._support.paths import LOCAL_FIXTURES, REPO_ROOT
from pathlib import Path
import pytest
_config_REPO_ROOT = REPO_ROOT
_config_GLOBAL_FIXTURES = _config_REPO_ROOT / 'tests' / 'fixtures'
_config_LOCAL_FIXTURES = LOCAL_FIXTURES
_config_MINIMAL = str(_config_GLOBAL_FIXTURES / 'smoke' / 'minimal.guardrails.yaml')

class TestConfigGuardrailsConfigConstructors:
    """Constructors produce correct initial chains."""

    def test_load_single_path(self):
        from agent_shield import GuardrailsConfig
        cfg = GuardrailsConfig.load(_config_MINIMAL)
        assert len(cfg) == 1
        assert cfg.layers[0].kind == 'path'

    def test_from_string(self):
        from agent_shield import GuardrailsConfig
        with open(_config_MINIMAL) as f:
            text = f.read()
        cfg = GuardrailsConfig.from_string(text)
        assert len(cfg) == 1
        assert cfg.layers[0].kind == 'string'
        assert cfg.layers[0].source == text

    def test_from_dict(self):
        from agent_shield import GuardrailsConfig
        data = {'metadata': {'name': 'x', 'version': '0.1.0'}}
        cfg = GuardrailsConfig.from_dict(data)
        assert len(cfg) == 1
        assert cfg.layers[0].kind == 'dict'
        assert cfg.layers[0].source == data

    def test_compose_chains_multiple_sources(self):
        from agent_shield import GuardrailsConfig
        cfg = GuardrailsConfig.compose(_config_MINIMAL, {'agent_metadata': {'mode': 'monitor'}})
        assert len(cfg) == 2
        assert cfg.layers[0].kind == 'path'
        assert cfg.layers[1].kind == 'dict'

    def test_compose_empty_raises(self):
        from agent_shield import GuardrailsConfig
        with pytest.raises(ValueError, match='at least one'):
            GuardrailsConfig.compose()

class TestConfigGuardrailsConfigExtension:
    """Fluent extend / overrides return new instances."""

    def test_extend_returns_new_instance(self):
        from agent_shield import GuardrailsConfig
        cfg = GuardrailsConfig.load(_config_MINIMAL)
        cfg2 = cfg.extend({'agent_metadata': {'mode': 'monitor'}})
        assert cfg is not cfg2
        assert len(cfg) == 1
        assert len(cfg2) == 2

    def test_extend_with_path(self):
        from agent_shield import GuardrailsConfig
        cfg = GuardrailsConfig.load(_config_MINIMAL).extend(_config_MINIMAL)
        assert len(cfg) == 2
        assert all((layer.kind == 'path' for layer in cfg.layers))

    def test_extend_with_dict(self):
        from agent_shield import GuardrailsConfig
        cfg = GuardrailsConfig.load(_config_MINIMAL).extend({'metadata': {'name': 'leaf'}})
        assert cfg.layers[-1].kind == 'dict'

    def test_extend_with_yaml_string(self):
        from agent_shield import GuardrailsConfig
        with open(_config_MINIMAL) as f:
            text = f.read()
        cfg = GuardrailsConfig.load(_config_MINIMAL).extend(text)
        assert cfg.layers[-1].kind == 'string'

    def test_extend_with_other_config(self):
        from agent_shield import GuardrailsConfig
        a = GuardrailsConfig.load(_config_MINIMAL)
        b = GuardrailsConfig.load(_config_MINIMAL).extend(_config_MINIMAL)
        merged = a.extend(b)
        assert len(merged) == 3

    def test_with_overrides(self):
        from agent_shield import GuardrailsConfig
        cfg = GuardrailsConfig.load(_config_MINIMAL).with_overrides({'metadata': {'description': 'monitoring mode'}})
        assert len(cfg) == 2
        assert cfg.layers[-1].kind == 'dict'

    def test_with_policy_pack_path(self):
        from agent_shield import GuardrailsConfig
        cfg = GuardrailsConfig.load(_config_MINIMAL).with_policy_pack(_config_MINIMAL)
        assert cfg.layers[-1].kind == 'path'

    def test_with_policy_pack_dict(self):
        from agent_shield import GuardrailsConfig
        cfg = GuardrailsConfig.load(_config_MINIMAL).with_policy_pack({'metadata': {'description': 'tenant pack'}})
        assert cfg.layers[-1].kind == 'dict'

class TestConfigCompiledPolicy:
    """compile() produces a hashable, content-keyed CompiledPolicy."""

    def test_compile_yields_yaml_strings(self):
        from agent_shield import GuardrailsConfig
        cfg = GuardrailsConfig.load(_config_MINIMAL)
        compiled = cfg.compile()
        assert len(compiled.yaml_strings) == 1
        assert 'smoke-minimal' in compiled.yaml_strings[0]
        assert len(compiled.digest) == 64

    def test_compile_chain_yields_n_strings(self):
        from agent_shield import GuardrailsConfig
        cfg = GuardrailsConfig.load(_config_MINIMAL).extend({'metadata': {'description': 'overlay'}})
        compiled = cfg.compile()
        assert len(compiled.yaml_strings) == 2
        assert 'overlay' in compiled.yaml_strings[1]

    def test_compile_is_deterministic(self):
        from agent_shield import GuardrailsConfig
        a = GuardrailsConfig.load(_config_MINIMAL).compile()
        b = GuardrailsConfig.load(_config_MINIMAL).compile()
        assert a == b
        assert a.digest == b.digest
        assert hash(a) == hash(b)

    def test_compile_changes_with_layer_change(self):
        from agent_shield import GuardrailsConfig
        a = GuardrailsConfig.load(_config_MINIMAL).compile()
        b = GuardrailsConfig.load(_config_MINIMAL).with_overrides({'metadata': {'description': 'different'}}).compile()
        assert a != b
        assert a.digest != b.digest

    def test_empty_chain_compile_raises(self):
        from agent_shield import GuardrailsConfig
        with pytest.raises(ValueError, match='no layers'):
            GuardrailsConfig().compile()

    def test_compiled_policy_is_hashable(self):
        from agent_shield import GuardrailsConfig
        compiled = GuardrailsConfig.load(_config_MINIMAL).compile()
        d: dict = {compiled: 'cached_runtime'}
        assert d[compiled] == 'cached_runtime'

class TestConfigRuntimeBuilderFromConfig:
    """RuntimeBuilder.from_config accepts every supported shape."""

    def test_from_config_with_path(self):
        from agent_shield import RuntimeBuilder
        rt = RuntimeBuilder.from_config(_config_MINIMAL).build()
        assert rt.metadata_name == 'smoke-minimal'

    def test_from_config_with_path_list(self):
        from agent_shield import RuntimeBuilder
        rt = RuntimeBuilder.from_config([_config_MINIMAL]).build()
        assert rt.metadata_name == 'smoke-minimal'

    def test_from_config_with_guardrails_config(self):
        from agent_shield import GuardrailsConfig, RuntimeBuilder
        cfg = GuardrailsConfig.load(_config_MINIMAL)
        rt = RuntimeBuilder.from_config(cfg).build()
        assert rt.metadata_name == 'smoke-minimal'

    def test_from_config_with_compiled_policy(self):
        from agent_shield import GuardrailsConfig, RuntimeBuilder
        compiled = GuardrailsConfig.load(_config_MINIMAL).compile()
        rt = RuntimeBuilder.from_config(compiled).build()
        assert rt.metadata_name == 'smoke-minimal'

    def test_from_yaml_strings_chain_via_runtime_builder(self):
        from agent_shield import RuntimeBuilder
        with open(_config_MINIMAL) as f:
            text = f.read()
        rt = RuntimeBuilder.from_yaml_strings([text]).build()
        assert rt.metadata_name == 'smoke-minimal'

class TestConfigComposedRuntime:
    """End-to-end: composed config produces a runtime with leaf-wins values."""

    def test_overlay_overrides_metadata_name(self):
        from agent_shield import GuardrailsConfig, RuntimeBuilder
        base_overlay = {'metadata': {'name': 'leaf-name', 'version': '0.1.0', 'agent_shield_version': '2.0'}, 'objective': {'goal': ['overlay goal']}, 'resources': {'tools': []}}
        cfg = GuardrailsConfig.load(_config_MINIMAL).with_overrides(base_overlay)
        rt = RuntimeBuilder.from_config(cfg).build()
        assert rt.metadata_name == 'leaf-name'

    def test_compiled_policy_caches_by_digest(self):
        from agent_shield import GuardrailsConfig
        compiled_a = GuardrailsConfig.load(_config_MINIMAL).compile()
        compiled_b = GuardrailsConfig.load(_config_MINIMAL).compile()
        cache: dict = {}
        cache[compiled_a.digest] = 'runtime-A'
        assert cache.get(compiled_b.digest) == 'runtime-A'
_composition_REPO_ROOT = REPO_ROOT
_composition_GLOBAL_FIXTURES = _composition_REPO_ROOT / 'tests' / 'fixtures'
_composition_MINIMAL = str(_composition_GLOBAL_FIXTURES / 'smoke' / 'minimal.guardrails.yaml')
_composition_ADAPTERS = [('agent_shield.adapters.langchain', 'with_langchain', 'langchain'), ('agent_shield.adapters.openai_agents', 'with_openai_agents', 'openai_agents'), ('agent_shield.adapters.anthropic_agents', 'with_anthropic_agents', 'anthropic_agents'), ('agent_shield.adapters.autogen', 'with_autogen', 'autogen'), ('agent_shield.adapters.crewai', 'with_crewai', 'crewai'), ('agent_shield.adapters.semantic_kernel', 'with_semantic_kernel', 'semantic_kernel')]

@pytest.fixture(scope='module', params=_composition_ADAPTERS, ids=[a[2] for a in _composition_ADAPTERS])
def _composition_adapter(request):
    """Import the adapter module (side-effect installs methods)."""
    import importlib
    module_path, method_name, framework = request.param
    module = importlib.import_module(module_path)
    return (module, method_name, framework)

class TestCompositionSideEffectInstall:

    def test_with_method_installed_on_shieldbuilder(self, _composition_adapter):
        """``with_<framework>`` is present on ShieldBuilder after import."""
        from agent_shield import ShieldBuilder
        _module, method_name, _framework = _composition_adapter
        assert hasattr(ShieldBuilder, method_name), f'ShieldBuilder.{method_name} not installed by adapter import'
        assert callable(getattr(ShieldBuilder, method_name))

    def test_create_agent_factory_installed_on_shield(self, _composition_adapter):
        """``create_<framework>_agent`` is present on Shield after import."""
        from agent_shield import Shield
        _module, _method, framework = _composition_adapter
        factory = f'create_{framework}_agent'
        assert hasattr(Shield, factory), f'Shield.{factory} not installed by adapter import'
        assert callable(getattr(Shield, factory))

    def test_shield_exported_from_top_level_package(self):
        """``from agent_shield import Shield`` works."""
        from agent_shield import Shield, ShieldBuilder
        assert Shield is not None
        assert ShieldBuilder is not None

class TestCompositionComposition:

    def test_from_yaml_with_framework_build(self, _composition_adapter):
        """``Shield.from_yaml(path).with_<framework>().build()`` works."""
        from agent_shield import Shield
        _module, method_name, framework = _composition_adapter
        builder = Shield.from_yaml(_composition_MINIMAL, auto_bind=False)
        builder = getattr(builder, method_name)()
        shield = builder.build()
        assert shield is not None
        assert isinstance(shield, Shield)
        assert shield.capabilities.framework == framework

    def test_capability_report_matches_bundle(self, _composition_adapter):
        """Capability report of composed Shield matches the bundle's."""
        from agent_shield import Shield
        module, method_name, _framework = _composition_adapter
        shield = getattr(Shield.from_yaml(_composition_MINIMAL, auto_bind=False), method_name)().build()
        assert shield.capabilities is module._BUNDLE.capabilities

    def test_build_without_framework_succeeds_with_no_bundle_methods_unavailable(self):
        """``build()`` without a bundle now succeeds — the framework-agnostic
        methods (``run`` / ``protect_tool`` / ``before_invoke``) work on the
        resulting shield. Methods that need a bundle (``guard`` / ``protect_tools``
        / ``capabilities``) raise a clear error at call time, NOT at build time.

        Mirrors the Node SDK's behaviour where a null bundle is allowed.
        """
        from agent_shield import Shield
        from agent_shield.adapters import _bundle_registry
        previous = dict(_bundle_registry._REGISTERED)
        _bundle_registry.reset()
        try:
            shield = Shield.from_yaml(_composition_MINIMAL).build()
            with pytest.raises(RuntimeError, match='with_<framework>'):
                _ = shield.capabilities
            with pytest.raises(RuntimeError, match='with_<framework>'):
                shield.protect_tools([])
            with pytest.raises(RuntimeError, match='with_<framework>'):
                shield.guard(object())
        finally:
            _bundle_registry._REGISTERED.update(previous)

    def test_protect_tools_works_on_composed_shield(self, _composition_adapter):
        """``protect_tools([])`` returns an empty list on a composed shield.

        Smoke test that the bundle's tool wrapper is wired up correctly.
        """
        from agent_shield import Shield
        _module, method_name, _framework = _composition_adapter
        shield = getattr(Shield.from_yaml(_composition_MINIMAL, auto_bind=False), method_name)().build()
        assert shield.protect_tools([]) == []

class TestCompositionClientRebinding:
    """Use openai_agents because its make_caller closure doesn't trigger
    the framework import on a sentinel client (langchain's does)."""

    def test_client_set_before_bundle_is_rebound(self):
        """Matches Node behaviour: client set first → re-bound on bundle."""
        from agent_shield import Shield
        from agent_shield.adapters import _bundle_registry
        previous = dict(_bundle_registry._REGISTERED)
        _bundle_registry.reset()
        try:
            builder = Shield.from_yaml(_composition_MINIMAL)
            sentinel = object()
            builder.with_client(sentinel)
            assert builder._client is sentinel
            assert builder._llm_caller is None
            builder.with_openai_agents()
            assert builder._llm_caller is not None
        finally:
            _bundle_registry._REGISTERED.update(previous)

    def test_client_set_after_bundle_is_bound(self):
        """Bundle first then client also wires the caller."""
        from agent_shield import Shield
        from agent_shield.adapters import _bundle_registry
        previous = dict(_bundle_registry._REGISTERED)
        _bundle_registry.reset()
        try:
            builder = Shield.from_yaml(_composition_MINIMAL).with_openai_agents()
            assert builder._llm_caller is None
            builder.with_client(object())
            assert builder._llm_caller is not None
        finally:
            _bundle_registry._REGISTERED.update(previous)

class TestCompositionBundleAutoBinding:
    """A single imported adapter module registers its bundle on the
    module-level registry; new ``ShieldBuilder`` instances pick it up
    automatically. Multiple imported adapters make auto-bind ambiguous
    and raise; customers disambiguate via ``auto_bind=False`` plus
    ``with_<framework>()``."""

    def test_auto_binding_happens_when_adapter_imported(self):
        from agent_shield import Shield
        from agent_shield.adapters import _bundle_registry
        previous = dict(_bundle_registry._REGISTERED)
        _bundle_registry.reset()
        try:
            import agent_shield.adapters.openai_agents as oai_mod
            _bundle_registry.register(oai_mod._BUNDLE)
            assert _bundle_registry.active_bundle() is not None
            builder = Shield.from_yaml(_composition_MINIMAL)
            assert builder._bundle is not None
            shield = builder.build()
            assert shield.capabilities is not None
        finally:
            _bundle_registry._REGISTERED.clear()
            _bundle_registry._REGISTERED.update(previous)

    def test_explicit_with_framework_overrides_auto_bound_bundle(self):
        from agent_shield import Shield
        from agent_shield.adapters import _bundle_registry
        previous = dict(_bundle_registry._REGISTERED)
        _bundle_registry.reset()
        try:
            import agent_shield.adapters.openai_agents as oai_mod
            _bundle_registry.register(oai_mod._BUNDLE)
            builder = Shield.from_yaml(_composition_MINIMAL)
            assert builder._bundle is not None
            assert builder._bundle.name == 'openai_agents'
            import agent_shield.adapters.anthropic_agents as anthr_mod
            _bundle_registry.register(anthr_mod._BUNDLE)
            builder.with_anthropic_agents()
            assert builder._bundle.name == 'anthropic_agents'
        finally:
            _bundle_registry._REGISTERED.clear()
            _bundle_registry._REGISTERED.update(previous)
from agent_shield import make_configuration_caller

def _configuration_dispatcher_recording_caller(label: str):
    calls: list[str] = []

    def caller(prompt: str) -> str:
        calls.append(prompt)
        return f'{label}:{prompt}'
    caller.calls = calls
    return caller

class TestConfigurationDispatcherExactMatchDispatch:

    def test_exact_match_routes_to_registered_caller(self):
        input_caller = _configuration_dispatcher_recording_caller('input')
        tool_caller = _configuration_dispatcher_recording_caller('tool')
        dispatcher = make_configuration_caller({'input_llm': input_caller, 'tool_execution_llm': tool_caller})
        assert dispatcher('input_llm', 'hello') == 'input:hello'
        assert dispatcher('tool_execution_llm', 'calc') == 'tool:calc'
        assert input_caller.calls == ['hello']
        assert tool_caller.calls == ['calc']

    def test_substring_match_does_NOT_route(self):
        """Substring hints (``"my_input_check"`` containing ``"input"``)
        must NOT route to the ``"input_llm"`` caller — exact match only.
        """
        input_caller = _configuration_dispatcher_recording_caller('input')
        fallback = _configuration_dispatcher_recording_caller('default')
        dispatcher = make_configuration_caller({'input_llm': input_caller}, default=fallback)
        result = dispatcher('my_input_check', 'hello')
        assert result == 'default:hello'
        assert input_caller.calls == []
        assert fallback.calls == ['hello']

class TestConfigurationDispatcherDefaultFallback:

    def test_default_used_for_unknown_id(self):
        fallback = _configuration_dispatcher_recording_caller('default')
        dispatcher = make_configuration_caller({}, default=fallback)
        assert dispatcher('never_registered', 'x') == 'default:x'

    def test_default_used_when_configuration_id_is_none(self):
        fallback = _configuration_dispatcher_recording_caller('default')
        dispatcher = make_configuration_caller({'input_llm': _configuration_dispatcher_recording_caller('input')}, default=fallback)
        assert dispatcher(None, 'x') == 'default:x'

    def test_no_default_unknown_id_raises(self):
        dispatcher = make_configuration_caller({'input_llm': _configuration_dispatcher_recording_caller('input')})
        with pytest.raises(RuntimeError) as info:
            dispatcher('unknown_id', 'x')
        msg = str(info.value)
        assert 'no LLM caller registered' in msg
        assert "'input_llm'" in msg
        assert "'unknown_id'" in msg
        assert 'no default provided' in msg

    def test_error_lists_known_ids(self):
        dispatcher = make_configuration_caller({'a': _configuration_dispatcher_recording_caller('a'), 'b': _configuration_dispatcher_recording_caller('b')})
        with pytest.raises(RuntimeError) as info:
            dispatcher('c', 'x')
        assert "'a'" in str(info.value)
        assert "'b'" in str(info.value)

    def test_error_renders_null_for_none_id(self):
        """Cross-SDK parity: a missing ``configuration_id`` must render as
        the literal ``null`` in the error message, not Python's native
        ``None``. Rust/.NET/Node all use ``null``; Python matches them
        here to keep the helper's error shape consistent across SDKs.
        """
        dispatcher = make_configuration_caller({})
        with pytest.raises(RuntimeError) as info:
            dispatcher(None, 'x')
        assert 'configuration_id=null' in str(info.value)

class TestConfigurationDispatcherDispatcherIsolation:

    def test_callers_mapping_is_copied(self):
        """Mutating the source mapping must not affect an already-built
        dispatcher."""
        caller = _configuration_dispatcher_recording_caller('a')
        callers = {'a': caller}
        dispatcher = make_configuration_caller(callers)
        callers.clear()
        assert dispatcher('a', 'x') == 'a:x'
from agent_shield import AgentShieldConfigError, RuntimeBuilder

def _loader_typed_errors_write(tmp_root: Path, name: str, body: str) -> str:
    """Write ``body`` to ``tmp_root/name`` and return the path string."""
    p = tmp_root / name
    p.write_text(body, encoding='utf-8')
    return str(p)
_loader_typed_errors_MINIMAL_VALID = "metadata:\n  name: t\n  version: '0.1.0'\n  agent_shield_version: '2.0'\nobjective:\n  goal: ['demo']\n  forbidden: ['x']\n"

def test_loader_typed_errors__importable_from_package_root() -> None:
    """The five-finding cluster requires the typed exception to be
    catchable via ``from agent_shield import AgentShieldConfigError``."""
    from agent_shield import AgentShieldConfigError as Reimported
    assert Reimported is AgentShieldConfigError
    assert issubclass(AgentShieldConfigError, Exception)
    assert issubclass(AgentShieldConfigError, RuntimeError)

def test_loader_typed_errors__unparseable_yaml_raises_typed_exception(tmp_path: Path) -> None:
    """An unparseable YAML scalar surfaces ``code='unparseable_yaml'``
    with the failing path populated."""
    bad = _loader_typed_errors_write(tmp_path, 'bad.yaml', 'metadata:\n  name: [unterminated\n')
    with pytest.raises(AgentShieldConfigError) as info:
        RuntimeBuilder.from_yaml(bad)
    exc = info.value
    assert exc.code == 'unparseable_yaml'
    assert exc.path is not None and exc.path.endswith('bad.yaml')
    assert 'loader: YAML parse error' in str(exc)
    assert exc.line is not None
    assert exc.column is not None

def test_loader_typed_errors__schema_violation_carries_path_and_field(tmp_path: Path) -> None:
    """A schema violation (unknown top-level field) surfaces
    ``code='unknown_top_level_field'`` with ``path`` and ``field``
    populated."""
    bad = _loader_typed_errors_write(tmp_path, 'schema.yaml', _loader_typed_errors_MINIMAL_VALID + 'totally_unknown_top_level_key: true\n')
    with pytest.raises(AgentShieldConfigError) as info:
        RuntimeBuilder.from_yaml(bad)
    exc = info.value
    assert exc.code == 'unknown_top_level_field'
    assert exc.path is not None and exc.path.endswith('schema.yaml')
    assert exc.field == 'totally_unknown_top_level_key'
    assert 'unknown_top_level_field' in str(exc)

def test_loader_typed_errors__unknown_resolver_kind_typed_exception(tmp_path: Path) -> None:
    """An unknown ``kind:`` on a resolver surfaces as a typed exception
    with the offending kind embedded in the canonical message."""
    bad = _loader_typed_errors_write(tmp_path, 'resolver.yaml', _loader_typed_errors_MINIMAL_VALID + 'variables:\n  - name: x\n    type: string\n    on_demand_by:\n      kind: totally_bogus_kind\n      name: x_resolver\n')
    with pytest.raises(AgentShieldConfigError) as info:
        RuntimeBuilder.from_yaml(bad)
    exc = info.value
    assert exc.code in {'schema_violation', 'unparseable_yaml', 'loader_error'}, exc.code
    assert 'totally_bogus_kind' in str(exc)
    assert exc.path is not None

def test_loader_typed_errors__extends_cycle_typed_exception(tmp_path: Path) -> None:
    """A cycle in the ``extends:`` chain surfaces
    ``code='cycle_detected'``."""
    a = _loader_typed_errors_write(tmp_path, 'a.yaml', "extends: ['./b.yaml']\n" + _loader_typed_errors_MINIMAL_VALID)
    _loader_typed_errors_write(tmp_path, 'b.yaml', "extends: ['./a.yaml']\n" + _loader_typed_errors_MINIMAL_VALID)
    with pytest.raises(AgentShieldConfigError) as info:
        RuntimeBuilder.from_yaml(a)
    exc = info.value
    assert exc.code == 'cycle_detected'
    assert 'cycle' in str(exc).lower()

def test_loader_typed_errors__message_preserves_substring_grep_contract(tmp_path: Path) -> None:
    """The five-finding cluster explicitly requires the typed
    exception's ``message`` to remain identical to the legacy bare
    exception, so substring-grep tests still pass.

    Pin the contract: ``str(exc)`` and ``exc.message`` are the same
    canonical text, with the same recognizable ``loader: ...`` prefix
    Rust core emits.
    """
    bad = _loader_typed_errors_write(tmp_path, 'x.yaml', 'metadata:\n  name: [unterminated\n')
    with pytest.raises(AgentShieldConfigError) as info:
        RuntimeBuilder.from_yaml(bad)
    exc = info.value
    assert exc.message == str(exc)
    assert str(exc).startswith('loader:')

def test_loader_typed_errors__typed_exception_has_repr_of_all_five_fields(tmp_path: Path) -> None:
    """A debug-friendly ``repr()`` MUST include all of
    ``{path, field, code, message, remediation}`` so logs and
    tracebacks expose the structured shape, not just the message."""
    bad = _loader_typed_errors_write(tmp_path, 'schema.yaml', _loader_typed_errors_MINIMAL_VALID + 'totally_unknown_top_level_key: true\n')
    with pytest.raises(AgentShieldConfigError) as info:
        RuntimeBuilder.from_yaml(bad)
    exc = info.value
    assert hasattr(exc, 'path')
    assert hasattr(exc, 'field')
    assert hasattr(exc, 'code')
    assert hasattr(exc, 'message')
    assert hasattr(exc, 'remediation')
    assert exc.remediation is None or isinstance(exc.remediation, str)

def test_loader_typed_errors__from_yaml_chain_raises_typed_exception(tmp_path: Path) -> None:
    bad = _loader_typed_errors_write(tmp_path, 'bad.yaml', 'metadata:\n  name: [unterminated\n')
    with pytest.raises(AgentShieldConfigError) as info:
        RuntimeBuilder.from_yaml_chain([bad])
    assert info.value.code == 'unparseable_yaml'

def test_loader_typed_errors__from_yaml_strings_raises_typed_exception() -> None:
    """String-input loads have no filesystem path; ``exc.path`` is
    ``None`` but every other structured field is still populated."""
    yaml = 'metadata:\n  name: [unterminated\n'
    with pytest.raises(AgentShieldConfigError) as info:
        RuntimeBuilder.from_yaml_strings([yaml])
    exc = info.value
    assert exc.code == 'unparseable_yaml'
    assert exc.path is None
    assert exc.line is not None

def test_loader_typed_errors__non_loader_errors_keep_legacy_runtime_error_shape(tmp_path: Path) -> None:
    """The cluster fix scopes the typed exception to *loader / build*
    paths. Runtime-time errors (unknown variable, missing host hook,
    builder already consumed) intentionally continue to raise
    ``RuntimeError`` so existing customer try/except blocks keep
    working."""
    minimal = _loader_typed_errors_write(tmp_path, 'ok.yaml', _loader_typed_errors_MINIMAL_VALID)
    builder = RuntimeBuilder.from_yaml(minimal)
    builder.build()
    with pytest.raises(RuntimeError) as info:
        builder.build()
    assert not isinstance(info.value, AgentShieldConfigError)
from agent_shield import ShieldLogEvent

def test_attributes_passthrough__from_dict_survives_new_variants_and_unknown_attributes():
    for wire in ['stage_evaluated', 'policy_evaluated', 'llm_called', 'classifier_called', 'future_variant_we_havent_invented_yet']:
        ev = ShieldLogEvent.from_dict({'timestamp': '2026-05-21T18:00:00Z', 'severity': 'info', 'event_type': wire, 'category': 'perf.test', 'session_id': 'sess-1', 'correlation_id': 'corr-1', 'attributes': {}})
        assert ev.event_type == wire, f'event_type {wire!r} must round-trip verbatim'
    payload = {'timestamp': '2026-05-21T18:00:00Z', 'severity': 'info', 'event_type': 'llm_called', 'category': 'perf.llm', 'session_id': 'sess-2', 'correlation_id': 'corr-2', 'attributes': {'agent_shield.duration_ms': 42, 'agent_shield.stage': 'input', 'agent_shield.guard_policy': 'wire_transfer_safety', 'agent_shield.evaluate_when_index': 0, 'agent_shield.llm.configuration_id': 'fast-haiku', 'agent_shield.llm.decision': 'block', 'agent_shield.llm.confidence': 0.95, 'agent_shield.future.cost_usd_micros': 12345, 'my_company.tenant_id': 'acme', 'my_company.cost_center': 'ai-platform'}}
    ev = ShieldLogEvent.from_dict(payload)
    for key, value in payload['attributes'].items():
        assert ev.attributes.get(key) == value, f'attribute {key!r} did not round-trip: got {ev.attributes.get(key)!r}, expected {value!r}'
    assert ev.event_type == 'llm_called'
    assert ev.session_id == 'sess-2'
    assert ev.correlation_id == 'corr-2'
_binding_hash_FIXTURE_YAML = '\nmetadata:\n  name: "section-16-binding-parity"\n  version: "0.1.0"\n  agent_shield_version: "2.0"\nobjective:\n  goal: ["test the behavior contract invocation binding"]\n  forbidden: ["nothing"]\nresources:\n  tools:\n    - name: "send_email"\n      description: "Send an email."\n      permission: "execute"\npost_tool_validation:\n  guard_policies:\n    - name: "result_recipient_must_match_call_recipient"\n      applies_to:\n        tools: ["send_email"]\n      evaluate_when:\n        - expression: \'endswith(@tool.params.recipient, "@example.com")\'\n          reason: "the behavior contract: Stage 4 bound to the wrong invocation."\n'

def _binding_hash_build_session():
    rt = RuntimeBuilder.from_yaml_strings([_binding_hash_FIXTURE_YAML]).build()
    sess = rt.new_session()
    sess.begin_turn()
    return sess

def test_binding_hash__section_16_stage3_then_stage4_with_id_binds():
    sess = _binding_hash_build_session()
    call = sess.validate_tool_call('send_email', {'recipient': 'alice@example.com', 'body': 'hi'}, tool_call_id='call_alice_1')
    assert call.verdict.allowed, 'Stage 3 should pass — no Stage-3 policies'
    out = sess.validate_tool_output(call.admission_id, {'matched_recipient': 'alice@example.com', 'sent': True})
    assert out.verdict.allowed, f'the behavior contract: Stage 4 must bind to the recorded Stage-3 invocation; verdict was: {out.verdict!r}'
    assert out.verdict.invocation_hash, 'the behavior contract: Stage 4 must surface invocation_hash when bound to a Stage-3-admitted invocation'
    assert out.verdict.post_validation_invocation_hash, 'the behavior contract: Stage 4 must surface post_validation_invocation_hash'

def test_binding_hash__section_16_parallel_same_name_distinct_ids_bind_independently():
    sess = _binding_hash_build_session()
    call_a = sess.validate_tool_call('send_email', {'recipient': 'alice@example.com', 'body': 'hi alice'}, tool_call_id='call_alice_1')
    assert call_a.verdict.allowed
    call_b = sess.validate_tool_call('send_email', {'recipient': 'bob@example.com', 'body': 'hi bob'}, tool_call_id='call_bob_2')
    assert call_b.verdict.allowed
    out_b = sess.validate_tool_output(call_b.admission_id, {'matched_recipient': 'bob@example.com', 'sent': True})
    assert out_b.verdict.allowed, f'the behavior contract: bob Stage 4 must bind to call_bob_2 invocation; verdict was: {out_b.verdict!r}'
    out_a = sess.validate_tool_output(call_a.admission_id, {'matched_recipient': 'alice@example.com', 'sent': True})
    assert out_a.verdict.allowed, f'the behavior contract: alice Stage 4 must bind to call_alice_1 invocation; verdict was: {out_a.verdict!r}'
    hash_a = out_a.verdict.invocation_hash
    hash_b = out_b.verdict.invocation_hash
    assert hash_a and hash_b
    assert hash_a != hash_b, f'the behavior contract: distinct same-name invocations must hash to distinct digests (got alice={hash_a!r}, bob={hash_b!r})'

def test_binding_hash__section_16_stage4_with_unknown_id_fails_closed():
    sess = _binding_hash_build_session()
    stale = sess.validate_tool_call('send_email', {'recipient': 'alice@example.com'}, tool_call_id='stale')
    sess.evict_admission(stale.admission_id)
    out = sess.validate_tool_output(stale.admission_id, {'matched_recipient': 'alice@example.com', 'sent': True})
    assert not out.verdict.allowed, f'the behavior contract: Stage 4 with unknown tool_call_id must fail closed; verdict was: {out.verdict!r}'
    assert out.verdict.policy == '<binding>', f"the behavior contract: deny verdict policy should be '<binding>'; got {out.verdict.policy!r}"
    assert out.verdict.invocation_hash is None, 'the behavior contract: fail-closed binding verdict must not advertise an invocation_hash'

def test_binding_hash__section_16_stage4_with_mismatched_explicit_id_fails_closed():
    sess = _binding_hash_build_session()
    stale = sess.validate_tool_call('send_email', {'recipient': 'alice@example.com', 'body': 'hi'}, tool_call_id='call_alice_1')
    sess.evict_admission(stale.admission_id)
    out = sess.validate_tool_output(stale.admission_id, {'matched_recipient': 'alice@example.com', 'sent': True})
    assert not out.verdict.allowed, f'the behavior contract: Stage 4 with mismatched tool_call_id must fail closed; verdict was: {out.verdict!r}'
    assert out.verdict.policy == '<binding>'
    assert out.verdict.invocation_hash is None
    assert out.verdict.post_validation_invocation_hash is None
