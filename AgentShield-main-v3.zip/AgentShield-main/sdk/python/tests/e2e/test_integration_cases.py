"""Behavior tests consolidated into e2e/test_integration_cases.py."""
from __future__ import annotations
from .._support.paths import REPO_ROOT
import inspect
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
import pytest
import yaml
_integration_cases_REPO_ROOT = REPO_ROOT
_integration_cases_CASES_DIR = _integration_cases_REPO_ROOT / 'tests' / 'cases'
_integration_cases_FIXTURES_DIR = _integration_cases_REPO_ROOT / 'tests' / 'fixtures'

def _integration_cases_find_fixture(name: str) -> Path:
    """Search ``tests/fixtures/`` for a file by name or relative path."""
    direct = _integration_cases_FIXTURES_DIR / name
    if direct.is_file():
        return direct
    leaf = Path(name).name
    for child in _integration_cases_FIXTURES_DIR.iterdir():
        if child.is_dir():
            candidate = child / leaf
            if candidate.is_file():
                return candidate
    raise FileNotFoundError(f'Fixture not found: {name}')

def _integration_cases_resolve_fixture_paths(given: Dict[str, Any]) -> List[str]:
    return [str(_integration_cases_find_fixture(f)) for f in given.get('fixtures', [])]

class _IntegrationCasesCallCounter:
    """Track which resolver hooks were invoked and per-variable counts."""

    def __init__(self) -> None:
        self.calls: List[Tuple[str, str, Dict[str, Any]]] = []

    def record(self, kind: str, variable: Optional[str], request_dict: Dict[str, Any]) -> None:
        self.calls.append((kind, variable or '', dict(request_dict)))

    def was_called(self, variable: str, kind: Optional[str]=None) -> bool:
        for k, v, _ in self.calls:
            if v == variable and (kind is None or k == kind):
                return True
        return False

class _IntegrationCasesCannedResolver:
    """Stub resolver that consults a pre-canned `given.resolvers` map.

    Looks up the response by ``request.variable``. If the runtime didn't
    populate the variable name in the request envelope (some resolver
    request envelopes omit it for non-human kinds), falls back to matching
    by ``prompt`` text or — when there's only one canned entry — uses that
    entry as the response. Final fallback is a fail-closed deny.
    """

    def __init__(self, kind: str, canned: Dict[str, Dict[str, Any]], counter: _IntegrationCasesCallCounter) -> None:
        self._kind = kind
        self._canned = canned
        self._counter = counter

    def __call__(self, request: Any) -> Any:
        var = getattr(request, 'variable', None)
        if var is None and isinstance(request, dict):
            var = request.get('variable')
        prompt = getattr(request, 'prompt', None)
        if prompt is None and isinstance(request, dict):
            prompt = request.get('prompt')
        self._counter.record(self._kind, var, _integration_cases_request_to_dict(request))
        canned = None
        if var is not None:
            canned = self._canned.get(var)
        if canned is None and prompt:
            for _k, v in self._canned.items():
                if isinstance(v, dict) and v.get('prompt') == prompt:
                    canned = v
                    break
        if canned is None and len(self._canned) == 1:
            canned = next(iter(self._canned.values()))
        if canned is None:
            return {'decision': 'deny', 'reason': f'{self._kind} resolver: no canned response (variable={var!r})'}
        out: Dict[str, Any] = {'decision': canned.get('decision', 'deny')}
        if 'value' in canned:
            out['value'] = canned['value']
        if canned.get('set_variables'):
            out['set_variables'] = dict(canned['set_variables'])
        if 'reason' in canned:
            out['reason'] = canned['reason']
        return out

def _integration_cases_request_to_dict(request: Any) -> Dict[str, Any]:
    if isinstance(request, dict):
        return request
    out: Dict[str, Any] = {}
    for attr in ('request_id', 'variable', 'resource_kind', 'resource_name', 'prompt', 'reason', 'context'):
        if hasattr(request, attr):
            out[attr] = getattr(request, attr)
    return out

def _integration_cases_load_all_cases() -> List[Tuple[str, Dict[str, Any]]]:
    cases: List[Tuple[str, Dict[str, Any]]] = []
    for yaml_file in sorted(_integration_cases_CASES_DIR.rglob('*.cases.yaml')):
        with open(yaml_file) as f:
            data = yaml.safe_load(f)
        suite_name = data.get('suite', yaml_file.stem)
        for case in data.get('cases', []):
            case_id = f'{suite_name}::{case.get("name", "unnamed")}'
            case['_suite_name'] = suite_name
            case['_suite_fixture'] = data.get('fixture')
            case['_suite_fixtures'] = data.get('fixtures')
            cases.append((case_id, case))
    return cases
_integration_cases_ALL_CASES = _integration_cases_load_all_cases()

def _integration_cases_get_given(case: Dict[str, Any]) -> Dict[str, Any]:
    given = dict(case.get('given', {}) or {})
    if 'fixtures' not in given:
        if case.get('_suite_fixtures'):
            given['fixtures'] = case['_suite_fixtures']
        elif case.get('_suite_fixture'):
            scenario_dir = _integration_cases_FIXTURES_DIR / case['_suite_fixture']
            if scenario_dir.is_dir():
                given['fixtures'] = [f.name for f in sorted(scenario_dir.glob('*.guardrails.yaml'))]
    return given

def _integration_cases_expected_load_error(case: Dict[str, Any]) -> Any:
    then = case.get('then')
    if isinstance(then, dict) and 'expect_load_error' in then:
        return then.get('expect_load_error')
    for step in case.get('steps') or []:
        expected = step.get('then') or step.get('expected')
        if isinstance(expected, dict) and 'expect_load_error' in expected:
            return expected.get('expect_load_error')
    return None

def _integration_cases_build_runtime(paths: List[str], given: Dict[str, Any]):
    """Build a Runtime + capturing observability + canned resolvers."""
    from agent_shield import RuntimeBuilder, CapturingProvider
    canned = given.get('resolvers') or {}
    counter = _IntegrationCasesCallCounter()
    capture = CapturingProvider()
    if len(paths) == 1:
        builder = RuntimeBuilder.from_yaml(paths[0])
    else:
        builder = RuntimeBuilder.from_yaml_chain(paths)
    builder = builder.register_observability_provider(capture)
    builder = builder.register_agent_resolver(_IntegrationCasesCannedResolver('agent', canned, counter))
    builder = builder.register_delegate_dispatcher(_IntegrationCasesCannedResolver('delegate', canned, counter))

    def _allow_llm(_cfg_id, _prompt):
        return {'decision': 'allow'}

    def _allow_classifier(_cfg_id, _subject):
        return {'score': 0.0, 'threshold': 0.5, 'flagged': False}
    try:
        builder = builder.register_llm_caller(_allow_llm)
    except Exception:
        pass
    try:
        builder = builder.register_classifier_caller(_allow_classifier)
    except Exception:
        pass
    runtime = builder.build()
    return (runtime, capture, counter)

def _integration_cases_open_session(runtime):
    session = runtime.new_session(session_id='harness-session', correlation_id='harness-correlation')
    try:
        session.begin_request()
    except Exception:
        pass
    try:
        session.begin_turn()
    except Exception:
        pass
    return session

class _IntegrationCasesUnknownActionError(Exception):
    """Raised when a shared YAML action verb is not implemented by the harness."""

def _integration_cases_params(action: Dict[str, Any]) -> Dict[str, Any]:
    return dict(action.get('params') or {})

def _integration_cases_supports_kwarg(fn: Any, name: str) -> bool:
    try:
        return name in inspect.signature(fn).parameters
    except (TypeError, ValueError):
        return False

def _integration_cases_execute_action(session: Any, action: Dict[str, Any]) -> Any:
    """Run one action against the session and return its result."""
    verb = action.get('action') or action.get('type')
    p = _integration_cases_params(action)
    if verb == 'validate_input':
        text = p.get('input') or action.get('input') or ''
        return session.validate_input(text)
    if verb == 'validate_tool_call':
        tool = p.get('tool_name') or action.get('tool_name') or ''
        params = p.get('tool_params') or action.get('tool_params') or {}
        tool_call_id = p.get('tool_call_id') or action.get('tool_call_id') or 'case_invocation'
        if _integration_cases_supports_kwarg(session.validate_tool_call, 'tool_call_id'):
            return session.validate_tool_call(tool, params, tool_call_id=tool_call_id)
        return session.validate_tool_call(tool, params)
    if verb == 'validate_tool_output':
        tool = p.get('tool_name') or action.get('tool_name') or 'unknown_tool'
        result = p.get('output') if 'output' in p else p.get('result')
        if result is None:
            result = action.get('output') if 'output' in action else action.get('result')
        tool_call_id = p.get('tool_call_id') or action.get('tool_call_id') or 'case_invocation'
        prebind_params = p.get('tool_params') or action.get('tool_params') or {}
        call = session.validate_tool_call(tool, prebind_params, tool_call_id=tool_call_id)
        outcome = session.validate_tool_output(call.admission_id, result)
        return outcome
    if verb == 'validate_endpoint_call':
        method = p.get('method') or action.get('method') or 'GET'
        uri = p.get('path') or p.get('uri') or p.get('url') or action.get('path') or action.get('url') or ''
        body = p.get('body') if 'body' in p else p.get('query_params')
        tool_call_id = p.get('tool_call_id') or action.get('tool_call_id') or 'case_invocation'
        if _integration_cases_supports_kwarg(session.validate_endpoint_call, 'tool_call_id'):
            return session.validate_endpoint_call(method, uri, body or {}, tool_call_id=tool_call_id)
        return session.validate_endpoint_call(method, uri, body or {})
    if verb == 'validate_agent_call':
        agent = p.get('agent_name') or action.get('agent_name') or ''
        params = p.get('agent_params') or action.get('agent_params') or {}
        tool_call_id = p.get('tool_call_id') or action.get('tool_call_id') or 'case_invocation'
        if _integration_cases_supports_kwarg(session.validate_agent_call, 'tool_call_id'):
            return session.validate_agent_call(agent, params, tool_call_id=tool_call_id)
        return session.validate_agent_call(agent, params)
    if verb == 'validate_output':
        text = p.get('output') or action.get('output') or ''
        return session.validate_output(text)
    if verb == 'set_variable':
        name = p.get('name') or action.get('name')
        value = p.get('value') if 'value' in p else action.get('value')
        session.set_variable(name, value)
        return None
    if verb == 'reset_variable':
        name = p.get('name') or action.get('name')
        session.reset_variable(name)
        return None
    if verb == 'resolve_variable':
        name = p.get('name') or action.get('name')
        return session.resolve_variable(name)
    if verb == 'emit_event':
        event_id = p.get('id') or action.get('id')
        session.emit_event(event_id, lifetime=p.get('lifetime'), payload=p.get('payload'))
        return None
    if verb == 'clear_event':
        event_id = p.get('id') or action.get('id')
        session.clear_event(event_id)
        return None
    if verb == 'emit_incident':
        name = p.get('name') or action.get('name')
        session.emit_incident(name, p.get('payload'))
        return None
    if verb == 'begin_turn':
        return session.begin_turn()
    if verb == 'end_turn':
        session.end_turn()
        return None
    if verb == 'begin_request':
        return session.begin_request()
    if verb == 'end_request':
        session.end_request()
        return None
    if verb == 'close_session':
        session.close()
        return None
    if verb == 'record_tool_success':
        tool = p.get('tool_name') or action.get('tool_name')
        result = p.get('result') if 'result' in p else action.get('result')
        session.record_tool_success(tool, result)
        return None
    if verb == 'record_tool_failure':
        tool = p.get('tool_name') or action.get('tool_name')
        error = p.get('error') or action.get('error') or ''
        session.record_tool_failure(tool, error)
        return None
    if verb == 'record_endpoint_success':
        pattern = p.get('pattern') or p.get('uri') or p.get('path') or action.get('pattern', '')
        result = p.get('result')
        session.record_endpoint_success(pattern, result)
        return None
    if verb == 'record_endpoint_failure':
        pattern = p.get('pattern') or p.get('uri') or p.get('path') or action.get('pattern', '')
        error = p.get('error') or ''
        session.record_endpoint_failure(pattern, error)
        return None
    if verb == 'record_agent_success':
        agent = p.get('agent_name') or action.get('agent_name')
        result = p.get('result')
        session.record_agent_success(agent, result)
        return None
    if verb == 'record_agent_failure':
        agent = p.get('agent_name') or action.get('agent_name')
        error = p.get('error') or ''
        session.record_agent_failure(agent, error)
        return None
    if verb == 'load_config':
        return None
    raise _IntegrationCasesUnknownActionError(f'Unknown action verb: {verb}')

def _integration_cases_verdict_view(result: Any) -> Tuple[Optional[Any], Optional[str]]:
    """Extract a (verdict, transformed_text) pair from any outcome."""
    if result is None:
        return (None, None)
    if hasattr(result, 'allowed') and (not hasattr(result, 'verdict')):
        return (result, None)
    if hasattr(result, 'verdict'):
        verdict = result.verdict
        text = None
        for attr in ('response', 'result', 'params', 'body'):
            if hasattr(result, attr):
                v = getattr(result, attr)
                if isinstance(v, str):
                    text = v
                    break
        return (verdict, text)
    return (None, None)

def _integration_cases_check_assertions(result: Any, expected: Dict[str, Any], case_name: str, capture: Any, counter: _IntegrationCasesCallCounter) -> None:
    if not expected:
        return
    verdict, text = _integration_cases_verdict_view(result)
    if 'allowed' in expected:
        assert verdict is not None, f'[{case_name}] expected verdict but got {result!r}'
        assert verdict.allowed == expected['allowed'], f'[{case_name}] expected allowed={expected["allowed"]}, got {verdict.allowed} (action={verdict.action}, reason={verdict.reason})'
    if 'expect_verdict_action' in expected:
        assert verdict is not None
        assert verdict.action == expected['expect_verdict_action'], f'[{case_name}] expected action={expected["expect_verdict_action"]}, got {verdict.action}'
    if 'expect_verdict_reason' in expected:
        assert verdict is not None
        actual = verdict.reason or ''
        assert expected['expect_verdict_reason'] in actual, f'[{case_name}] expected reason to contain {expected["expect_verdict_reason"]!r}, got {actual!r}'
    if 'expect_verdict_policy' in expected:
        assert verdict is not None
        assert verdict.policy == expected['expect_verdict_policy'], f'[{case_name}] expected policy={expected["expect_verdict_policy"]}, got {verdict.policy}'
    if 'text_contains' in expected:
        body = text if text is not None else getattr(result, 'output', None) or (getattr(result, 'response', None) if hasattr(result, 'response') else None) or ''
        assert expected['text_contains'] in (body or ''), f'[{case_name}] expected output to contain {expected["text_contains"]!r}; got {body!r}'
    if 'text_not_contains' in expected:
        body = text if text is not None else getattr(result, 'output', None) or (getattr(result, 'response', None) if hasattr(result, 'response') else None) or ''
        items = expected['text_not_contains']
        if isinstance(items, str):
            items = [items]
        for item in items:
            assert item not in (body or ''), f'[{case_name}] expected output to NOT contain {item!r}; got {body!r}'
    if 'expect_variable_status' in expected:
        cfg = expected['expect_variable_status']
        name = cfg['name']
        want_status = cfg['status']
        sess = getattr(_integration_cases_check_assertions, '_session', None)
        assert sess is not None, 'harness did not provide session for variable assertions'
        state = sess.read_variable(name)
        actual_status = state.status if state is not None else 'unset'
        assert actual_status == want_status, f'[{case_name}] expected variable {name!r} status={want_status}, got {actual_status}'
    if 'expect_variable_value' in expected:
        cfg = expected['expect_variable_value']
        name = cfg['name']
        sess = getattr(_integration_cases_check_assertions, '_session', None)
        assert sess is not None, 'harness did not provide session for variable assertions'
        state = sess.read_variable(name)
        actual = state.value if state is not None else None
        if 'value' in cfg:
            assert actual == cfg['value'], f'[{case_name}] expected variable {name!r} value={cfg["value"]!r}, got {actual!r}'
    if 'expect_event_fired' in expected:
        _integration_cases_flush_capture(capture)
        eid = expected['expect_event_fired']
        fired = any((_integration_cases_event_id_matches(ev, eid) for ev in capture.events))
        assert fired, f'[{case_name}] expected event {eid!r} to be fired'
    if 'expect_event_not_fired' in expected:
        _integration_cases_flush_capture(capture)
        eid = expected['expect_event_not_fired']
        fired = any((_integration_cases_event_id_matches(ev, eid) for ev in capture.events))
        assert not fired, f'[{case_name}] expected event {eid!r} NOT to be fired'
    if 'expect_resolver_called' in expected:
        cfg = expected['expect_resolver_called']
        var = cfg['variable']
        kind = cfg.get('kind')
        assert counter.was_called(var, kind), f'[{case_name}] expected resolver call for variable {var!r} (kind={kind}); got calls={counter.calls!r}'
    if 'expect_log_event' in expected:
        _integration_cases_flush_capture(capture)
        match = expected['expect_log_event']
        ok = False
        for ev in capture.events:
            if not _integration_cases_log_event_matches(ev, match):
                continue
            ok = True
            break
        assert ok, f'[{case_name}] expected log event matching {match!r}; saw {[_integration_cases_event_summary(e) for e in capture.events]}'

def _integration_cases_flush_capture(capture: Any) -> None:
    """Drain the runtime's async observability queue so `capture.events`
    reflects everything emitted up to this point.

    The per-provider worker model delivers events asynchronously,
    so synchronous reads of `capture.events` must first wait for the
    dispatcher to flush. The harness exposes the active session via
    ``_check_assertions._session`` (set in ``test_shared_case``);
    flushing through the session keeps this helper independent of
    the runtime variable.
    """
    sess = getattr(_integration_cases_check_assertions, '_session', None)
    if sess is None:
        return
    flush = getattr(sess, 'flush_observability', None)
    if flush is None:
        return
    try:
        flush()
    except Exception:
        pass

def _integration_cases_event_id_matches(event: Any, expected_id: str) -> bool:
    eid = getattr(event, 'event_id', None)
    if eid == expected_id:
        return True
    attrs = getattr(event, 'attributes', {}) or {}
    return attrs.get('agent_shield.event.id') == expected_id

def _integration_cases_log_event_matches(event: Any, match: Dict[str, Any]) -> bool:
    for key, want in match.items():
        if key == 'message_contains':
            actual = getattr(event, 'message', '') or ''
            if want not in actual:
                return False
            continue
        if key == 'attributes':
            actual_attrs = getattr(event, 'attributes', {}) or {}
            for ak, av in (want or {}).items():
                if actual_attrs.get(ak) != av:
                    return False
            continue
        actual = getattr(event, key, None)
        if actual != want:
            return False
    return True

def _integration_cases_event_summary(event: Any) -> Dict[str, Any]:
    return {'event_type': getattr(event, 'event_type', None), 'stage': getattr(event, 'stage', None), 'guard_policy': getattr(event, 'guard_policy', None), 'category': getattr(event, 'category', None), 'event_id': getattr(event, 'event_id', None)}

def _integration_cases_seed_session(session: Any, given: Dict[str, Any]) -> None:
    for name, value in (given.get('variables') or {}).items():
        session.set_variable(name, value)
    for entry in given.get('events') or []:
        if isinstance(entry, str):
            session.emit_event(entry)
        else:
            session.emit_event(entry['id'], lifetime=entry.get('lifetime'), payload=entry.get('payload'))

@pytest.mark.parametrize('case_id,case', _integration_cases_ALL_CASES, ids=[c[0] for c in _integration_cases_ALL_CASES])
def test_integration_cases__shared_case(case_id: str, case: Dict[str, Any]) -> None:
    xfail_info = (case.get('xfail') or {}).get('python')
    is_xfail = bool(xfail_info)
    given = _integration_cases_get_given(case)
    paths = _integration_cases_resolve_fixture_paths(given)
    if not paths:
        pytest.skip(f'No fixtures defined for case: {case_id}')
    expected_load_error = _integration_cases_expected_load_error(case)
    load_only = (case.get('when') or {}).get('action') == 'load_config'
    try:
        runtime, capture, counter = _integration_cases_build_runtime(paths, given)
    except Exception as exc:
        if expected_load_error is True:
            if is_xfail:
                pytest.xfail(f'xfail (python): {xfail_info.get("reason", "known failure")}')
            return
        if isinstance(expected_load_error, str):
            actual = str(exc)
            assert expected_load_error in actual, f'[{case_id}] expected load error containing {expected_load_error!r}, got {actual!r}'
            if is_xfail:
                pytest.xfail(f'xfail (python): {xfail_info.get("reason", "known failure")}')
            return
        if is_xfail:
            pytest.xfail(f'xfail (python): {xfail_info.get("reason", "known failure")}')
        raise
    if expected_load_error is True:
        if is_xfail:
            pytest.xfail('xfail (python): expected load error but loaded successfully')
        pytest.fail(f'[{case_id}] expected load error, but runtime loaded successfully', pytrace=False)
    if isinstance(expected_load_error, str):
        if is_xfail:
            pytest.xfail(f'xfail (python): expected load error containing {expected_load_error!r} but loaded successfully')
        pytest.fail(f'[{case_id}] expected load error containing {expected_load_error!r}, but runtime loaded successfully', pytrace=False)
    if load_only:
        return
    session = _integration_cases_open_session(runtime)
    _integration_cases_check_assertions._session = session
    try:
        _integration_cases_seed_session(session, given)
        if 'when' in case and 'then' in case:
            result = _integration_cases_execute_action(session, case['when'])
            _integration_cases_check_assertions(result, case['then'], case_id, capture, counter)
            return
        for i, step in enumerate(case.get('steps') or []):
            step_name = f'{case_id}[step {i}]'
            action_data = step.get('when') or step
            result = _integration_cases_execute_action(session, action_data)
            expected = step.get('then') or step.get('expected')
            if expected:
                _integration_cases_check_assertions(result, expected, step_name, capture, counter)
    except (pytest.skip.Exception, KeyboardInterrupt, SystemExit):
        raise
    except Exception:
        if is_xfail:
            pytest.xfail(f'xfail (python): {xfail_info.get("reason", "known failure")}')
        raise
    finally:
        try:
            session.end_turn()
        except Exception:
            pass
        try:
            session.end_request()
        except Exception:
            pass
        _integration_cases_check_assertions._session = None
