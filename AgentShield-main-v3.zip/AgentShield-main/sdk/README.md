# 🔌 Custom Attribute Extractors

When a tool executes, Agent Shield extracts runtime attributes (like `data_sensitivity`) from the tool's JSON response. By default, the SDK uses **exact key matching** — the JSON key must match the attribute name declared in `after_execute` (list form) exactly.

For example, if your guardrails YAML declares:

```yaml
resources:
  tools:
    - name: "read_document"
      after_execute:
        - data_sensitivity
        - data_jurisdictions

  endpoints:
    - pattern: "/api/v1/documents/{doc_id}"
      methods: ["GET"]
      description: "Fetch a document by ID"
      action: "allow"
      after_execute:
        - data_sensitivity
        - data_jurisdictions
```

Then the MCP server (or tool/endpoint) must return JSON with those exact keys:

```json
{
  "data_sensitivity": "confidential",
  "data_jurisdictions": ["US", "EU"],
  "content": "..."
}
```

## When You Need a Custom Extractor

If your MCP server returns differently-named keys (e.g., `classification` instead of `data_sensitivity`), or if the attributes are nested, you need a custom extractor. Pass it when constructing the runtime:

```python
from agent_shield import GuardrailsRuntime
import json

def my_attribute_extractor(tool_name: str, tool_result: str, expected_attributes: list[str]) -> dict:
    """Custom extractor that maps vendor-specific keys to guardrails attributes."""
    try:
        data = json.loads(tool_result)
    except (json.JSONDecodeError, TypeError):
        return {}

    if not isinstance(data, dict):
        return {}

    # Map MCP server field names → guardrails attribute names
    key_mapping = {
        "data_sensitivity": data.get("classification"),
        "data_jurisdictions": data.get("regions", []),
    }

    return {
        attr: key_mapping[attr]
        for attr in expected_attributes
        if attr in key_mapping and key_mapping[attr] is not None
    }

runtime = (
    GuardrailsRuntime.from_yaml("my-agent.guardrails.yaml")
    .with_attribute_extractor(my_attribute_extractor)
    .build()
)
```

## Extractor Function Signature

```python
def attribute_extractor(
    tool_name: str,           # Name of the tool that produced the result
    tool_result: str,         # Raw JSON string from the tool
    expected_attributes: list[str],  # Attribute names from after_execute (list form)
) -> dict[str, Any]:          # Mapping of attribute name → extracted value
```

The `tool_name` parameter lets you branch logic per tool if different MCP servers use different response schemas.

## Best Practices

- **Keep MCP responses aligned with guardrails YAML** — the simplest approach is to have your MCP server return keys that exactly match the `after_execute` names. This avoids needing a custom extractor entirely.
- **Use custom extractors for third-party MCP servers** — when you don't control the server's response format, the custom extractor bridges the gap.
- **Return only recognized attributes** — the extractor should only return keys that are in `expected_attributes`. Unknown keys are ignored by the runtime.
