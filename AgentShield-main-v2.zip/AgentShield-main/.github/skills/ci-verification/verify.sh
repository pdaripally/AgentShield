#!/usr/bin/env bash
#
# CI verification driver — single source of truth for local CI.
#
# Runs the full suite the way the GitHub Actions workflows run it,
# enumerates every test target dynamically (so a new test file added
# anywhere in the workspace is automatically picked up), and asserts
# every expected binary actually executed.
#
# Usage:
#   .github/skills/ci-verification/verify.sh             # full suite
#   .github/skills/ci-verification/verify.sh rust        # rust only
#   .github/skills/ci-verification/verify.sh python      # python only
#   .github/skills/ci-verification/verify.sh node        # node only
#   .github/skills/ci-verification/verify.sh dotnet      # .NET only
#   .github/skills/ci-verification/verify.sh demo-syntax # demo syntax only
#
# Exit code is non-zero if any step fails OR if any expected test
# binary did not appear in the cargo output. The expected-binary check
# is the load-bearing part: it catches scope-narrowing that "all tests
# passed" summaries hide.

set -uo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
cd "$REPO_ROOT"

# Standard toolchain paths.
export PATH="$REPO_ROOT/.dotnet:$REPO_ROOT/.dotnet-tools:$HOME/.dotnet:$HOME/.cargo/bin:$PATH"

# ANSI for the human reading.
RED=$'\033[0;31m'
GREEN=$'\033[0;32m'
YELLOW=$'\033[0;33m'
BOLD=$'\033[1m'
NC=$'\033[0m'

SCOPE="${1:-all}"
FAILED_STEPS=()
MANIFEST=()
PYTHON_BIN="${PYTHON_BIN:-}"
SCRATCH_DIR="$REPO_ROOT/.git/ci-verify"
mkdir -p "$SCRATCH_DIR"

note() { printf "%s==>%s %s\n" "$BOLD" "$NC" "$*"; }
ok()   { printf "%s ok %s %s\n" "$GREEN" "$NC" "$*"; }
err()  { printf "%sFAIL%s %s\n" "$RED" "$NC" "$*" >&2; }
warn() { printf "%swarn%s %s\n" "$YELLOW" "$NC" "$*"; }

log_path() {
  local name="$1"
  local path="$SCRATCH_DIR/$name"
  : > "$path"
  printf '%s' "$path"
}

# ── Step 0: toolchains ────────────────────────────────────────────────

verify_toolchains() {
  local missing=()
  for tool in cargo rustfmt node npm dotnet; do
    if ! command -v "$tool" >/dev/null 2>&1; then
      missing+=("$tool")
    fi
  done
  if [ -z "$PYTHON_BIN" ]; then
    for candidate in python3 python py; do
      if command -v "$candidate" >/dev/null 2>&1 && "$candidate" --version 2>&1 | grep -q '^Python '; then
        PYTHON_BIN="$candidate"
        break
      fi
    done
  fi
  if [ -z "$PYTHON_BIN" ]; then
    missing+=("python3/python")
  fi
  if [ ${#missing[@]} -ne 0 ]; then
    err "missing toolchains: ${missing[*]}"
    err "fix PATH (try: export PATH=\"\$HOME/.dotnet:\$HOME/.cargo/bin:\$PATH\") then re-run"
    return 1
  fi
  for tool in cargo rustfmt node npm dotnet; do
    printf "  %-8s %s\n" "$tool:" "$("$tool" --version 2>&1 | head -1)"
  done
  printf "  %-8s %s\n" "python:" "$("$PYTHON_BIN" --version 2>&1 | head -1)"
}

# ── Step 0.5: rebase check ────────────────────────────────────────────
#
# Catches the "pre-existing issue" failure mode where the local branch
# sits on an unmerged base that doesn't reflect what CI will see. If
# `origin/main` is ahead of the local merge-base, warn loudly.

check_rebase_state() {
  if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    warn "not in a git repo, skipping rebase check"
    return 0
  fi
  git fetch --quiet origin main 2>/dev/null || {
    if [ "${SKIP_REBASE_CHECK:-0}" = "1" ]; then
      warn "could not fetch origin/main; skipping rebase check (SKIP_REBASE_CHECK=1)"
      return 0
    fi
    err "could not fetch origin/main; rebase check requires network access"
    err "set SKIP_REBASE_CHECK=1 to bypass in offline environments"
    return 1
  }
  local base
  base="$(git merge-base HEAD origin/main 2>/dev/null || echo "")"
  if [ -z "$base" ]; then
    warn "no merge-base with origin/main, skipping"
    return 0
  fi
  local origin_main
  origin_main="$(git rev-parse origin/main)"
  if [ "$base" != "$origin_main" ]; then
    local behind
    behind="$(git rev-list --count "$base..$origin_main")"
    err "branch is $behind commits behind origin/main"
    err "CI runs against the merge result, not your branch in isolation"
    err "rebase onto origin/main first:  git rebase origin/main"
    err "then re-run this script"
    return 1
  fi
  ok "branch is up to date with origin/main"
}

# ── Rust: enumerate expected test binaries dynamically ────────────────
#
# Every `tests/*.rs` file becomes a separately-compiled integration test
# binary. We list them so we can later assert each one ran.

rust_expected_test_binaries() {
  find sdk/rust -mindepth 3 -maxdepth 4 -path '*/tests/*.rs' \
    -not -path '*/target/*' -not -path '*/src/*' | \
    while IFS= read -r f; do
      basename "$f" .rs
    done | sort
}

# ── Rust: full suite ──────────────────────────────────────────────────

rust_suite() {
  local rust_log; rust_log="$(log_path rust-verify.log)"

  note "cargo fmt --all -- --check"
  cargo fmt --all -- --check || { FAILED_STEPS+=("rust fmt"); return 1; }
  ok "fmt"

  note "cargo clippy --workspace --all-features -- -D warnings"
  cargo clippy --workspace --all-features -- -D warnings || { FAILED_STEPS+=("rust clippy"); return 1; }
  ok "clippy"

  note "cargo check -p agent_shield_core --no-default-features"
  cargo check -p agent_shield_core --no-default-features || { FAILED_STEPS+=("rust check no-default"); return 1; }

  note "cargo check --workspace --all-features"
  cargo check --workspace --all-features || { FAILED_STEPS+=("rust check workspace"); return 1; }

  note "cargo test --workspace --all-features  (tees to $rust_log)"
  if ! cargo test --workspace --all-features 2>&1 | tee "$rust_log"; then
    FAILED_STEPS+=("rust test workspace")
    err "cargo test workspace failed; check $rust_log"
    return 1
  fi

  # Manifest check: every tests/*.rs we expected must appear in the cargo
  # output at least as many times as it exists across crates. `sort | uniq -c`
  # gives us the expected count for each name so duplicate-named integration
  # tests (e.g. two crates both owning tests/smoke.rs) are counted separately.
  local expected; expected="$(rust_expected_test_binaries)"
  local missing=()
  local total_expected=0
  while IFS=' ' read -r exp_count bin; do
    [ -z "$bin" ] && continue
    total_expected=$((total_expected + exp_count))
    actual_count="$(grep -cE "Running .*tests[/\\]${bin}\\.rs" "$rust_log" 2>/dev/null || true)"
    actual_count="${actual_count:-0}"
    if [ "$actual_count" -lt "$exp_count" ]; then
      missing+=("$bin (expected $exp_count occurrence(s), found $actual_count)")
    fi
  done < <(echo "$expected" | sort | uniq -c)
  if [ ${#missing[@]} -ne 0 ]; then
    err "the following Rust integration test binaries did NOT execute:"
    for b in "${missing[@]}"; do err "  - $b"; done
    err "this means cargo test --workspace skipped them; investigate before claiming a green run"
    FAILED_STEPS+=("rust manifest")
    return 1
  fi
  ok "all $total_expected expected Rust integration test binaries executed"

  MANIFEST+=("rust: fmt + clippy + check (no-default, workspace --all-features) + test --workspace --all-features")
}

# ── Python ────────────────────────────────────────────────────────────

python_suite() {
  if [ ! -d sdk/python ]; then
    warn "sdk/python not found, skipping"
    return 0
  fi

  # Install / build strategy. Three paths, picked in priority order:
  #
  #   1. uv-managed venv at sdk/python/.venv: `uv sync` rebuilds the
  #      maturin extension and installs project deps; then a
  #      separate `uv pip install` adds pytest + ancillary tools that
  #      aren't in the project's runtime deps. All pytest invocations
  #      below run through `uv run --no-sync` so they hit the venv.
  #
  #   2. Active VIRTUAL_ENV: install via `$PYTHON_BIN -m pip` into it.
  #
  #   3. System python with no venv: try `pip install`; fall back to
  #      `--user --break-system-packages` for PEP 668 hosts
  #      (Debian 12+, Ubuntu 24.04+, etc.).
  #
  # CI's setup-python action puts python on PATH in a non-externally-
  # managed location, so path 3's bare `pip install` works there.
  local py_install_log; py_install_log="$(log_path py-install.log)"
  local pytest_cmd
  if [ -d sdk/python/.venv ] && command -v uv >/dev/null 2>&1; then
    note "Python: uv sync (rebuild maturin extension + project deps)"
    ( cd sdk/python && uv sync --quiet ) 2>&1 | tee -a "$py_install_log" \
      || { err "uv sync failed; check $py_install_log"; FAILED_STEPS+=("python install"); return 1; }
    note "Python: uv pip install (test deps)"
    ( cd sdk/python && uv pip install --quiet pytest pytest-asyncio jsonschema ) 2>&1 | tee -a "$py_install_log" \
      || { err "uv pip install test deps failed; check $py_install_log"; FAILED_STEPS+=("python install-test-deps"); return 1; }
    pytest_cmd="uv run --no-sync python -m pytest"
  else
    local suite_venv="$REPO_ROOT/.venv-python-suite"
    rm -rf "$suite_venv"
    note "Python: install SDK (repo venv $suite_venv)"
    "$PYTHON_BIN" -m venv "$suite_venv" 2>&1 | tee -a "$py_install_log" \
      || { err "python venv creation failed; check $py_install_log"; FAILED_STEPS+=("python venv"); return 1; }
    local suite_python="$suite_venv/bin/python"
    "$suite_python" -m pip install --quiet --upgrade pip pyyaml pytest pytest-asyncio jsonschema httpx maturin 2>&1 | tee -a "$py_install_log" \
      || { err "$suite_python -m pip install deps failed; check $py_install_log"; FAILED_STEPS+=("python install-deps"); return 1; }
    ( cd sdk/python && "$suite_python" -m maturin develop --quiet --release ) 2>&1 | tee -a "$py_install_log" \
      || { err "maturin develop failed; check $py_install_log"; FAILED_STEPS+=("python install-sdk"); return 1; }
    pytest_cmd="$suite_python -m pytest"
  fi
  ok "python install"

  note "Python: pytest sdk/python/tests"
  ( cd sdk/python && $pytest_cmd tests/ -q ) || { FAILED_STEPS+=("python unit"); return 1; }
  ok "python unit"

  if [ -d tests/e2e ]; then
    note "Python: pytest tests/e2e"
    ( cd sdk/python && $pytest_cmd ../../tests/e2e -q ) || { FAILED_STEPS+=("python e2e"); return 1; }
    ok "python e2e"
  fi

  if [ -f sdk/python/tests/test_integration_cases.py ]; then
    note "Python: cross-language integration_cases harness"
    ( cd sdk/python && $pytest_cmd tests/test_integration_cases.py -q ) \
      || { FAILED_STEPS+=("python integration_cases"); return 1; }
    ok "python integration_cases"
  fi
  MANIFEST+=("python: unit + e2e + integration_cases")
}

# ── Node ──────────────────────────────────────────────────────────────

node_suite() {
  if [ ! -d sdk/node ]; then
    warn "sdk/node not found, skipping"
    return 0
  fi
  local node_log; node_log="$(log_path node-verify.log)"
  ( cd sdk/node && {
    note "Node: npm install"
    npm install --silent 2>&1 | tee -a "$node_log" || exit 1
    note "Node: napi build"
    npm run build 2>&1 | tee -a "$node_log" || exit 1
    note "Node: TS wrapper build"
    npm run build:wrapper 2>&1 | tee -a "$node_log" || exit 1
    note "Node: tsc --noEmit (sources)"
    npx tsc -p tsconfig.json --noEmit 2>&1 | tee -a "$node_log" || exit 1
    note "Node: tsc --noEmit (tests)"
    npx tsc -p tsconfig.tests.json --noEmit 2>&1 | tee -a "$node_log" || exit 1
    note "Node: vitest"
    npm test 2>&1 | tee -a "$node_log" || exit 1
    note "Node: parity tests"
    node --test ../../tests/parity/test_shield_api_node.mjs \
                ../../tests/parity/test_capability_node.mjs 2>&1 | tee -a "$node_log" || exit 1
    if [ -f __tests__/integration_cases.test.mjs ]; then
      note "Node: integration_cases harness"
      node --test __tests__/integration_cases.test.mjs 2>&1 | tee -a "$node_log" || exit 1
    fi
  } ) || { FAILED_STEPS+=("node"); err "node suite failed; check $node_log"; return 1; }
  ok "node: build + tsc strict (sources + tests) + vitest + parity + integration_cases"
  MANIFEST+=("node: build + tsc strict (sources + tests) + vitest + parity + integration_cases")
}

# ── .NET ──────────────────────────────────────────────────────────────

# Detect OS-specific native library name and dynamic-linker env var.
# On Windows the DLL is already copied next to the test binary, so no
# library-path override is needed. On Linux/macOS we prepend (not replace)
# target/release to the existing search-path env var.
case "$(uname -s 2>/dev/null)" in
  Darwin)
    _NATIVE_LIB="libagent_shield_core.dylib"
    _NATIVE_LIB_ENV="DYLD_LIBRARY_PATH"
    ;;
  MINGW*|MSYS*|CYGWIN*|Windows_NT)
    _NATIVE_LIB="agent_shield_core.dll"
    _NATIVE_LIB_ENV=""   # DLL copied next to binary; PATH override not needed
    ;;
  *)
    _NATIVE_LIB="libagent_shield_core.so"
    _NATIVE_LIB_ENV="LD_LIBRARY_PATH"
    ;;
esac

dotnet_suite() {
  if [ ! -d sdk/dotnet ]; then
    warn "sdk/dotnet not found, skipping"
    return 0
  fi
  note ".NET: build native lib ($_NATIVE_LIB)"
  cargo build --release -p agent_shield_core >/dev/null || { FAILED_STEPS+=("dotnet native"); return 1; }

  # Build all .NET test projects, then copy the native lib next to each
  # test binary, then run them. The lib copy is required because the
  # P/Invoke load path doesn't include target/release by default.
  local projects=()
  while IFS= read -r p; do projects+=("$p"); done < <(find sdk/dotnet/tests -name '*.csproj')
  if [ ${#projects[@]} -eq 0 ]; then
    warn "no .NET test projects, skipping"
    return 0
  fi

  for proj in "${projects[@]}"; do
    note ".NET: build $proj"
    dotnet build "$proj" --nologo >/dev/null || { FAILED_STEPS+=("dotnet build $proj"); return 1; }
    local bindir; bindir="$(dirname "$proj")/bin/Debug/net8.0"
    if [ -d "$bindir" ]; then
      if ! cp "target/release/$_NATIVE_LIB" "$bindir/" 2>/dev/null; then
        if [ -z "$_NATIVE_LIB_ENV" ]; then
          # Windows: the DLL must be next to the test binary for P/Invoke.
          err "failed to copy target/release/$_NATIVE_LIB into $bindir"
          err "make sure 'cargo build --release -p agent_shield_core' completed successfully"
          FAILED_STEPS+=("dotnet copy-native $proj"); return 1
        fi
        # Linux/macOS: LD/DYLD_LIBRARY_PATH covers the load path; copy is
        # best-effort only, so a copy failure is non-fatal here.
        warn "could not copy $_NATIVE_LIB into $bindir (will rely on $_NATIVE_LIB_ENV)"
      fi
    fi
  done

  for proj in "${projects[@]}"; do
    note ".NET: test $proj"
    if [ -n "$_NATIVE_LIB_ENV" ]; then
      # Prepend target/release to the existing search path (not replace it).
      local existing; existing="${!_NATIVE_LIB_ENV:-}"
      env "$_NATIVE_LIB_ENV=target/release${existing:+:$existing}" \
        dotnet test "$proj" --no-build --nologo >/dev/null \
        || { FAILED_STEPS+=("dotnet test $proj"); return 1; }
    else
      # Windows: DLL already copied next to the test binary.
      dotnet test "$proj" --no-build --nologo >/dev/null \
        || { FAILED_STEPS+=("dotnet test $proj"); return 1; }
    fi
  done
  ok ".NET: built and tested ${#projects[@]} projects"
  MANIFEST+=("dotnet: ${#projects[@]} test projects (all built, all passed)")
}

# ── Demo syntax ───────────────────────────────────────────────────────

demo_syntax() {
  "$PYTHON_BIN" -c "
import ast, glob, sys
errors = []
# After the examples/ restructure, agent demos live at
# examples/agents/<name>/*.py + mcp_servers/, and the cross-example
# plumbing lives at examples/_shared/. Tool reference impls live at
# examples/tools/<name>/. Walk them all.
patterns = [
    'examples/_shared/**/*.py',
    'examples/agents/**/*.py',
    'examples/tools/**/*.py',
]
files = sorted({f for p in patterns for f in glob.glob(p, recursive=True)})
for f in files:
    try: ast.parse(open(f, encoding='utf-8').read())
    except SyntaxError as e: errors.append(f'{f}: {e}')
if errors:
    print('FAILED:'); [print(f'  {e}') for e in errors]; sys.exit(1)
print(f'All {len(files)} demo files parse OK')
" || { FAILED_STEPS+=("demo syntax"); return 1; }
  MANIFEST+=("demo syntax: all examples/{_shared,agents,tools}/**/*.py parse")
}

build_python_requirement_file() {
  local output_path="$1"
  "$PYTHON_BIN" - <<'PY' > "$output_path"
import tomllib
from pathlib import Path

data = tomllib.loads(Path('sdk/python/pyproject.toml').read_text())
project = data['project']
deps = list(project.get('dependencies', []))
seen = set()
for dep in deps:
    lowered = dep.lower()
    if lowered.startswith('agent-shield['):
        continue
    if dep not in seen:
        seen.add(dep)
        print(dep)
PY
}

conformance_suite() {
  local conf_log; conf_log="$(log_path conformance.log)"
  (
    set -e
  local req_file="$SCRATCH_DIR/python-deps.txt"
  build_python_requirement_file "$req_file"
    note "Conformance: prepare Python environment"
    rm -rf .venv-conformance
    "$PYTHON_BIN" -m venv .venv-conformance
    . .venv-conformance/bin/activate
    python -m pip install --quiet --upgrade pip
    python -m pip install --quiet pyyaml jsonschema maturin httpx pytest pip-audit pip-licenses
    python -m pip install --quiet sdk/python --no-build-isolation

    note "Conformance: build Node wrapper"
    ( cd sdk/node && npm install --silent && npm run build >/dev/null && npm run build:wrapper >/dev/null )

    note "Conformance: run Python runner"
    . .venv-conformance/bin/activate
    python tests/conformance/run_python.py

    note "Conformance: run Rust runner"
    bash tests/conformance/run_rust.sh

    note "Conformance: run Node runner"
    node tests/conformance/run_node.mjs

    note "Conformance: run .NET runner"
    bash tests/conformance/run_dotnet.sh

    note "Conformance: generate coverage + verify claims"
    python tests/conformance/generate_coverage.py
    git diff --exit-code -- tests/conformance/coverage.md
    python tests/conformance/verify_release_claims.py
    python3 scripts/check_package_metadata.py
  ) 2>&1 | tee "$conf_log" || { FAILED_STEPS+=("conformance"); err "conformance suite failed; check $conf_log"; return 1; }
  ok "conformance: 4 SDK runners + coverage freshness + claim verification + metadata"
  MANIFEST+=("conformance: rust/python/node/dotnet runners + coverage freshness + release claims + metadata")
}

workflow_sanity() {
  note "Workflow sanity"
  local required=(
    .github/workflows/release-claim-gate.yml
    .github/workflows/sca.yml
    .github/workflows/secret-scan.yml
    .github/workflows/codeql.yml
    .github/workflows/license-scan.yml
  )
  for file in "${required[@]}"; do
    [ -f "$file" ] || { FAILED_STEPS+=("workflow sanity"); err "missing workflow: $file"; return 1; }
  done
  grep -q 'actions/attest-build-provenance' .github/workflows/publish.yml \
    || { FAILED_STEPS+=("workflow sanity"); err "publish.yml is missing artifact attestation steps"; return 1; }
  grep -q 'verify_release_claims.py' .github/workflows/release-claim-gate.yml \
    || { FAILED_STEPS+=("workflow sanity"); err "release-claim-gate.yml is missing claim verification"; return 1; }
  if git diff --name-only origin/main -- spec/ | grep . >/dev/null 2>&1; then
    FAILED_STEPS+=("workflow sanity")
    err "spec/ changes detected; this PR must not modify spec/"
    return 1
  fi
  MANIFEST+=("workflow sanity: required workflows present + publish attestations + no spec drift")
}

security_suite() {
  local security_log; security_log="$(log_path security.log)"
  local req_file="$SCRATCH_DIR/python-deps.txt"
  build_python_requirement_file "$req_file"
  (
    set -e
    note "Security: install audit and license tools"
    cargo install cargo-audit --locked >/dev/null 2>&1 || cargo install cargo-audit --locked
    cargo install cargo-license --locked >/dev/null 2>&1 || cargo install cargo-license --locked
    DOTNET_ROOT="$REPO_ROOT/.dotnet" PATH="$REPO_ROOT/.dotnet:$PATH" dotnet tool install --tool-path ./.dotnet-tools dotnet-project-licenses >/dev/null 2>&1 || true

    note "Security: cargo audit"
    cargo audit

    note "Security: python dependency audit"
    rm -rf .venv-security
    "$PYTHON_BIN" -m venv .venv-security
    . .venv-security/bin/activate
    python -m pip install --quiet --upgrade pip
    python -m pip install --quiet pip-audit pip-licenses
    python -m pip install --quiet -r "$req_file"
    pip-audit -r "$req_file"
    pip-licenses --format=json --with-authors --with-urls > "$SCRATCH_DIR/pip-licenses.json"

    note "Security: npm audit + licenses"
    ( cd sdk/node && npm install --silent && npm audit --audit-level=high )
    ( cd sdk/node && npx --yes license-checker-rseidelsohn --json > "$SCRATCH_DIR/node-licenses.json" )

    note "Security: cargo licenses"
    cargo license --json > "$SCRATCH_DIR/cargo-licenses.json"

    note "Security: .NET vulnerable package scan"
    while IFS= read -r project; do
      PATH="$REPO_ROOT/.dotnet:$PATH" dotnet restore "$project" >/dev/null
      PATH="$REPO_ROOT/.dotnet:$PATH" dotnet list "$project" package --vulnerable --include-transitive --format json > "$SCRATCH_DIR/dotnet-vuln.json"
      "$PYTHON_BIN" - <<'PY'
import json
from pathlib import Path

data = json.loads(Path('.git/ci-verify/dotnet-vuln.json').read_text())
advisories = []
for project in data.get('projects', []):
    for framework in project.get('frameworks', []):
        for bucket in ('topLevelPackages', 'transitivePackages'):
            for package in framework.get(bucket, []):
                if package.get('advisories'):
                    advisories.append((project.get('path'), package.get('id'), package.get('advisories')))
if advisories:
    raise SystemExit(f'.NET vulnerabilities detected: {advisories}')
PY
    done < <(find sdk/dotnet/src -name '*.csproj' | sort)

    note "Security: .NET licenses"
    mkdir -p "$SCRATCH_DIR/dotnet-license-reports"
    while IFS= read -r project; do
      safe_name=$(echo "$project" | tr '/.' '__')
      PATH="$REPO_ROOT/.dotnet:$PATH" DOTNET_ROOT="$REPO_ROOT/.dotnet" dotnet restore "$project" >/dev/null
      PATH="$REPO_ROOT/.dotnet:$PATH" DOTNET_ROOT="$REPO_ROOT/.dotnet" ./.dotnet-tools/dotnet-project-licenses \
        --input "$project" \
        --include-transitive \
        --use-project-assets-json \
        --json \
        --outfile "$SCRATCH_DIR/dotnet-license-reports/${safe_name}.json"
    done < <(find sdk/dotnet/src -name '*.csproj' | sort)
    "$PYTHON_BIN" - <<'PY'
import json
from pathlib import Path
reports = []
for path in sorted(Path('.git/ci-verify/dotnet-license-reports').glob('*.json')):
    reports.append(json.loads(path.read_text()))
Path('.git/ci-verify/dotnet-licenses.json').write_text(json.dumps(reports, indent=2))
PY

    note "Security: GPL-family deny list"
    python3 scripts/check_licenses.py \
      "$SCRATCH_DIR/cargo-licenses.json" \
      "$SCRATCH_DIR/pip-licenses.json" \
      "$SCRATCH_DIR/node-licenses.json" \
      "$SCRATCH_DIR/dotnet-licenses.json"

    note "Security: secret scan"
    if command -v gitleaks >/dev/null 2>&1; then
      gitleaks detect --source . --config .gitleaks.toml --no-banner --redact --verbose --exit-code 1
    else
      warn "gitleaks not installed; using regex fallback"
      PATTERNS='(AKIA[0-9A-Z]{16}|sk-[a-zA-Z0-9]{48}|ghp_[a-zA-Z0-9]{36}|-----BEGIN (RSA |EC )?PRIVATE KEY-----)'
      if grep -rPn "$PATTERNS" --include='*.py' --include='*.yaml' --include='*.yml' --include='*.json' --include='*.ts' --exclude-dir=.git --exclude-dir=__pycache__ --exclude-dir=node_modules --exclude-dir=.venv-conformance --exclude-dir=.venv-security --exclude-dir=.venv-release --exclude-dir=.dotnet --exclude-dir=.dotnet-tools --exclude-dir=.tools --exclude-dir=target --exclude-dir=dist . 2>/dev/null; then
        exit 1
      fi
    fi
  ) 2>&1 | tee "$security_log" || { FAILED_STEPS+=("security"); err "security suite failed; check $security_log"; return 1; }
  ok "security: sca + licenses + secret scan"
  MANIFEST+=("security: cargo audit + pip-audit + npm audit + dotnet vuln scan + GPL deny list + secret scan")
}

release_dry_run_suite() {
  local release_log; release_log="$(log_path release-dry-run.log)"
  (
    set -e
    local backup_dir="$SCRATCH_DIR/release-backup"
    rm -rf "$backup_dir"
    mkdir -p "$backup_dir/sdk/node" "$backup_dir/sdk/python" "$backup_dir/sdk/dotnet/src"
    cp Cargo.toml "$backup_dir/Cargo.toml"
    cp Cargo.lock "$backup_dir/Cargo.lock"
    cp sdk/node/package.json "$backup_dir/sdk/node/package.json"
    cp sdk/python/pyproject.toml "$backup_dir/sdk/python/pyproject.toml"
    cp sdk/dotnet/src/Directory.Build.props "$backup_dir/sdk/dotnet/src/Directory.Build.props"
    trap 'cp "$backup_dir/Cargo.toml" Cargo.toml >/dev/null 2>&1 || true; cp "$backup_dir/Cargo.lock" Cargo.lock >/dev/null 2>&1 || true; cp "$backup_dir/sdk/node/package.json" sdk/node/package.json >/dev/null 2>&1 || true; cp "$backup_dir/sdk/python/pyproject.toml" sdk/python/pyproject.toml >/dev/null 2>&1 || true; cp "$backup_dir/sdk/dotnet/src/Directory.Build.props" sdk/dotnet/src/Directory.Build.props >/dev/null 2>&1 || true; rm -rf "$backup_dir" sdk/python/dist sdk/dotnet/packages .venv-release; rm -f sdk/node/*.tgz dist/agent-shield-rust-sdk-*' EXIT
    local version="99.99.99-rc.99"

    note "Release dry-run: patch manifests"
    bash .github/scripts/patch-version.sh "$version"
    python3 scripts/check_package_metadata.py

    note "Release dry-run: rust bundle"
    cargo check --workspace --all-features
    mkdir -p dist
    tar -czf "dist/agent-shield-rust-sdk-${version}.tar.gz" Cargo.toml Cargo.lock LICENSE README.md sdk/rust
    tar -xOf "dist/agent-shield-rust-sdk-${version}.tar.gz" Cargo.toml | grep -q "version = \"${version}\""
    test -f "dist/agent-shield-rust-sdk-${version}.tar.gz"

    note "Release dry-run: python packages"
    rm -rf .venv-release
    "$PYTHON_BIN" -m venv .venv-release
    . .venv-release/bin/activate
    python -m pip install --quiet --upgrade pip 'maturin>=1.7,<2.0'
    ( cd sdk/python && maturin build --release --out dist && maturin sdist --out ../../dist )

    note "Release dry-run: node tarball"
    ( cd sdk/node && npm pack >/dev/null )

    note "Release dry-run: dotnet packages"
    PATH="$REPO_ROOT/.dotnet:$PATH" dotnet pack sdk/dotnet/src/AgentShield/AgentShield.csproj -c Release -o sdk/dotnet/packages >/dev/null
  ) 2>&1 | tee "$release_log" || { FAILED_STEPS+=("release dry-run"); err "release dry-run failed; check $release_log"; return 1; }
  ok "release dry-run: patched manifests + package artifacts + source bundle"
  MANIFEST+=("release dry-run: patch-version + rust bundle + python/node/dotnet package build")
}

# ── Driver ────────────────────────────────────────────────────────────

main() {
  note "CI verification — scope: $SCOPE"

  verify_toolchains || exit 1
  check_rebase_state || exit 1

  case "$SCOPE" in
    rust)        rust_suite ;;
    python)      python_suite ;;
    node)        node_suite ;;
    dotnet)      dotnet_suite ;;
    demo-syntax) demo_syntax ;;
    conformance) conformance_suite ;;
    security)    security_suite ;;
    release)     release_dry_run_suite ;;
    workflows)   workflow_sanity ;;
    all)
      rust_suite
      python_suite
      node_suite
      dotnet_suite
      demo_syntax
      conformance_suite
      security_suite
      release_dry_run_suite
      workflow_sanity
      ;;
    *) err "unknown scope: $SCOPE"; exit 2 ;;
  esac

  echo
  echo "${BOLD}=== Manifest ===${NC}"
  for line in "${MANIFEST[@]}"; do echo "  ✓ $line"; done

  if [ ${#FAILED_STEPS[@]} -ne 0 ]; then
    echo
    err "${#FAILED_STEPS[@]} step(s) failed:"
    for s in "${FAILED_STEPS[@]}"; do err "  - $s"; done
    exit 1
  fi

  echo
  ok "all CI verification steps green"
}

main
