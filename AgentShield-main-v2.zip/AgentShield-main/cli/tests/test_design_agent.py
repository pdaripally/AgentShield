"""Design-agent turn-loop tests using a mocked LLM caller.

The mock returns a pre-scripted sequence of assistant turns. Each
test verifies the dispatcher dispatches correctly, the validator
gate works, the self-correct loop kicks in on validation failure,
and the user-fallback path triggers after the retry budget is spent.
"""
from __future__ import annotations

from collections import deque
from typing import Deque, List

import yaml

from agent_shield_cli.init._design_agent import run_design_loop
from .conftest import MockLlmCaller, make_action


_MINIMAL_VALID_YAML = yaml.safe_dump(
    {
        "metadata": {"name": "p", "version": "0.1.0", "agent_shield_version": "2.0"},
        "objective": {"goal": ["test"]},
        "input_validation": {
            "guard_policies": [
                {
                    "name": "j",
                    "evaluate_when": [
                        {"pattern": "ignore.*instructions", "reason": "jb"}
                    ],
                }
            ]
        },
    }
)


_INVALID_YAML = yaml.safe_dump(
    {
        "metadata": {"name": "p", "version": "0.1.0", "agent_shield_version": "2.0"},
        "objective": {"goal": ["t"]},
        # missing applies_to — Rust loader rejects
        "state_validation": {
            "guard_policies": [{"name": "bad", "reason": "no applies_to"}]
        },
    }
)


def _io_pair(inputs: List[str]) -> tuple:
    """Return ``(input_fn, output_fn)`` driving the design loop.

    Inputs are returned in order; outputs are appended to a captured
    list the test can assert against.
    """
    q: Deque[str] = deque(inputs)
    captured: List[str] = []

    def in_fn(prompt: str) -> str:
        if not q:
            return ""
        return q.popleft()

    def out_fn(text: str) -> None:
        captured.append(text)

    return in_fn, out_fn, captured


def test_happy_path_non_interactive() -> None:
    """Non-interactive: model goes straight to `done`."""
    caller = MockLlmCaller(
        script=[make_action("done", yaml=_MINIMAL_VALID_YAML, summary="ok")]
    )
    in_fn, out_fn, _ = _io_pair([])
    result = run_design_loop(
        caller=caller,
        system_prompt="<system>",
        non_interactive=True,
        input_fn=in_fn,
        output_fn=out_fn,
    )
    assert result.final_yaml is not None
    assert not result.aborted
    assert result.final_data["metadata"]["name"] == "p"


def test_happy_path_with_ask_propose_done() -> None:
    """Interactive: ask → user replies → propose → user accepts → done."""
    caller = MockLlmCaller(
        script=[
            make_action("ask", question="What domain?"),
            make_action(
                "propose",
                yaml=_MINIMAL_VALID_YAML,
                explanation="Initial draft.",
            ),
            make_action("done", yaml=_MINIMAL_VALID_YAML, summary="shipped"),
        ]
    )
    in_fn, out_fn, captured = _io_pair(
        [
            "banking support",  # answer to ask
            "a",                # accept the propose
        ]
    )
    result = run_design_loop(
        caller=caller,
        system_prompt="<system>",
        input_fn=in_fn,
        output_fn=out_fn,
    )
    assert result.final_yaml is not None
    assert result.turns == 3
    # The validated YAML was shown to the user.
    assert any("```yaml" in c for c in captured)
    # The user's answer was appended to the conversation; verify by
    # checking the next chat call saw a user-role message named "banking
    # support" (the conftest mock records only response text, so we
    # verify on a coarse signal: the agent reached 3 turns and exited.)
    assert caller.cursor == 3


def test_self_correct_recovers_after_one_validation_failure() -> None:
    """Bad propose → orchestrator feeds error back → next propose passes."""
    caller = MockLlmCaller(
        script=[
            make_action("propose", yaml=_INVALID_YAML, explanation="bad first"),
            make_action(
                "propose", yaml=_MINIMAL_VALID_YAML, explanation="fixed"
            ),
            make_action("done", yaml=_MINIMAL_VALID_YAML, summary="ok"),
        ]
    )
    in_fn, out_fn, captured = _io_pair(["a"])  # accept the fixed proposal
    result = run_design_loop(
        caller=caller,
        system_prompt="<system>",
        input_fn=in_fn,
        output_fn=out_fn,
    )
    assert result.final_yaml is not None
    # validation attempt 1 failed before recovery
    assert any("validation attempt 1" in c for c in captured)


def test_three_strikes_falls_to_user_fallback() -> None:
    """N=3 failed self-corrects → user prompted; user aborts."""
    caller = MockLlmCaller(
        script=[
            make_action("propose", yaml=_INVALID_YAML, explanation="bad"),
            make_action("propose", yaml=_INVALID_YAML, explanation="still bad"),
            make_action("propose", yaml=_INVALID_YAML, explanation="still bad"),
            # next turn the LLM should emit `done` after the user fed
            # "user_feedback: …" / abort marker. If we abort, the loop
            # asks the LLM to emit a final done; we let it emit `done`
            # with the same invalid YAML, then the post-done validation
            # also rejects → aborted result.
            make_action("done", yaml=_INVALID_YAML, summary="giving up"),
        ]
    )
    in_fn, out_fn, captured = _io_pair(["abort"])
    result = run_design_loop(
        caller=caller,
        system_prompt="<system>",
        input_fn=in_fn,
        output_fn=out_fn,
    )
    assert result.aborted
    # Either the 3-strikes path or the final-done validation rejection
    # surfaces; both flow through `abort_reason`.
    assert "invalid" in result.abort_reason or "abort" in result.abort_reason.lower()


def test_skip_proposal_moves_on() -> None:
    caller = MockLlmCaller(
        script=[
            make_action("propose", yaml=_MINIMAL_VALID_YAML, explanation="A"),
            make_action("done", yaml=_MINIMAL_VALID_YAML, summary="ok"),
        ]
    )
    in_fn, out_fn, _ = _io_pair(["s"])  # skip the first proposal
    result = run_design_loop(
        caller=caller,
        system_prompt="<system>",
        input_fn=in_fn,
        output_fn=out_fn,
    )
    assert result.final_yaml is not None


def test_refine_passes_user_feedback_to_model() -> None:
    caller = MockLlmCaller(
        script=[
            make_action("propose", yaml=_MINIMAL_VALID_YAML, explanation="A"),
            make_action("done", yaml=_MINIMAL_VALID_YAML, summary="ok"),
        ]
    )
    feedback_text = "add a Stage 4 PII redaction policy"
    in_fn, out_fn, _ = _io_pair(
        [
            "r",            # refine choice
            feedback_text,  # actual feedback
        ]
    )
    result = run_design_loop(
        caller=caller,
        system_prompt="<system>",
        input_fn=in_fn,
        output_fn=out_fn,
    )
    assert result.final_yaml is not None
    assert not result.aborted
    # The model received the user's free-text feedback as the last user
    # message before emitting `done`. The mock records last_user_content
    # per call so we can verify the feedback reached the LLM.
    feedback_seen = any(
        entry.get("last_user_content") and feedback_text in entry["last_user_content"]
        for entry in caller.transcript
    )
    assert feedback_seen, (
        f"User feedback {feedback_text!r} was not found in any LLM call; "
        f"transcript: {caller.transcript}"
    )


def test_invalid_json_is_recovered_by_retry_prompt() -> None:
    """If the LLM emits non-JSON, the loop asks it to fix and retries."""
    caller = MockLlmCaller(
        script=[
            "this is just text, not JSON",
            make_action("done", yaml=_MINIMAL_VALID_YAML, summary="ok"),
        ]
    )
    in_fn, out_fn, _ = _io_pair([])
    result = run_design_loop(
        caller=caller,
        system_prompt="<system>",
        non_interactive=True,
        input_fn=in_fn,
        output_fn=out_fn,
    )
    assert result.final_yaml is not None


def test_max_turns_caps_runaway() -> None:
    """If the LLM keeps asking forever, the loop terminates with abort."""
    script = [make_action("ask", question=f"q{i}?") for i in range(10)]
    caller = MockLlmCaller(script=script)
    in_fn, out_fn, _ = _io_pair(["answer"] * 10)
    result = run_design_loop(
        caller=caller,
        system_prompt="<system>",
        max_turns=5,
        input_fn=in_fn,
        output_fn=out_fn,
    )
    assert result.aborted
    assert "max_turns" in result.abort_reason


def test_non_interactive_rejects_ask() -> None:
    """In non-interactive mode, an `ask` is rejected; LLM must proceed."""
    caller = MockLlmCaller(
        script=[
            make_action("ask", question="what?"),
            make_action("done", yaml=_MINIMAL_VALID_YAML, summary="ok"),
        ]
    )
    in_fn, out_fn, _ = _io_pair([])
    result = run_design_loop(
        caller=caller,
        system_prompt="<system>",
        non_interactive=True,
        input_fn=in_fn,
        output_fn=out_fn,
    )
    assert result.final_yaml is not None
    # The agent saw a user turn telling it no human is available.
    # Just check the loop made it through both scripted responses.
    assert caller.cursor == 2
