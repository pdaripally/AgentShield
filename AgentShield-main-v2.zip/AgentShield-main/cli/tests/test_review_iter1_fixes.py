"""Regression tests for the four bugs caught in iteration 1 of the
agent-review loop.

1. ``--force`` plus a post-write validation failure must not nuke the
   user's prior config — we now write to a staging file and atomic
   replace.
2. Tool parameter schemas must reach the system prompt so the LLM
   can write ``@tool.params.X`` references with grounding.
3. Content-filter sanitization must cover user-supplied text too
   (``--describe``, tool descriptions, source notes, server names).
4. ``parent_tool_names`` must walk the full ``extends:`` chain, not
   just the directly-loaded file.
"""
from __future__ import annotations

from pathlib import Path
from unittest import mock

import yaml

from agent_shield_cli import main
from agent_shield_cli.init._context import (
    DesignContext,
    _summarize_schema,
    build_system_prompt,
)
from agent_shield_cli.init._sources import LoadedSources, ToolEntry
from agent_shield_cli.init._validate import parent_tool_names
from .conftest import MockLlmCaller, make_action


# ─────────────────────── Fix #1 ────────────────────────────────────


_VALID_YAML = yaml.safe_dump(
    {
        "metadata": {"name": "v", "version": "0.1.0", "agent_shield_version": "2.0"},
        "objective": {"goal": ["h"]},
    }
)


def test_force_overwrite_preserves_prior_on_post_write_failure(
    tmp_path: Path,
    openai_tools_json: Path,
) -> None:
    """The user's existing file must survive an LLM-produced YAML that
    fails the post-write smoke check (e.g. extends-chain mismatch)."""
    out = tmp_path / ".guardrails.yaml"
    prior_bytes = b"# user's hand-written config\nmetadata: {name: existing}\n"
    out.write_bytes(prior_bytes)

    # Patch validate_on_disk to fail on the staging file. The CLI
    # should keep the prior file intact and clean up staging.
    from agent_shield_cli.init import _command as cmd

    fake = mock.Mock(side_effect=cmd.ValidationError("simulated post-write failure"))
    with mock.patch.object(cmd, "validate_on_disk", fake), \
         mock.patch.object(
            cmd,
            "build_caller",
            return_value=MockLlmCaller(
                script=[make_action("done", yaml=_VALID_YAML, summary="ok")]
            ),
        ):
        rc = main(
            [
                "init",
                "--provider", "openai",
                "--model", "gpt-5",
                "--api-key", "test",
                "--describe", "x",
                "--openai-tools", str(openai_tools_json),
                "--output", str(out),
                "--non-interactive",
                "--force",
            ]
        )
    assert rc != 0
    # Prior config is byte-identical to before.
    assert out.read_bytes() == prior_bytes
    # No staging files left lingering (mkstemp + finally-unlink).
    leftovers = list(tmp_path.glob(".*.agent-shield-init.tmp"))
    assert leftovers == [], f"unexpected staging leftovers: {leftovers}"


def test_force_overwrite_preserves_prior_when_sibling_tmp_exists(
    tmp_path: Path,
    openai_tools_json: Path,
) -> None:
    """A pre-existing file matching the *old* fixed staging suffix
    must NOT be clobbered. The new code uses unique mkstemp names."""
    out = tmp_path / ".guardrails.yaml"
    out.write_bytes(b"# prior\n")
    # Simulate a stale tmp file from a different tool run.
    legacy_staging = tmp_path / ".guardrails.yaml.agent-shield-init.tmp"
    legacy_staging.write_bytes(b"unrelated content the user wants to keep")

    from agent_shield_cli.init import _command as cmd

    with mock.patch.object(
        cmd,
        "build_caller",
        return_value=MockLlmCaller(
            script=[make_action("done", yaml=_VALID_YAML, summary="ok")]
        ),
    ):
        rc = main(
            [
                "init",
                "--provider", "openai",
                "--model", "gpt-5",
                "--api-key", "test",
                "--describe", "x",
                "--openai-tools", str(openai_tools_json),
                "--output", str(out),
                "--non-interactive",
                "--force",
            ]
        )
    assert rc == 0
    # The legacy file the user had was untouched by the staging logic.
    assert legacy_staging.read_bytes() == b"unrelated content the user wants to keep"


def test_written_file_uses_0644_for_new_files(
    tmp_path: Path,
    openai_tools_json: Path,
) -> None:
    """tempfile.mkstemp defaults to 0o600. After os.replace into the
    final destination, the file MUST carry ordinary readable
    permissions (0o644) so deploy / CI processes that previously
    could read .guardrails.yaml still can. We hardcode 0o644 rather
    than read process umask to stay thread-safe under embedded use.
    """
    import stat

    out = tmp_path / ".guardrails.yaml"
    from agent_shield_cli.init import _command as cmd

    with mock.patch.object(
        cmd,
        "build_caller",
        return_value=MockLlmCaller(
            script=[make_action("done", yaml=_VALID_YAML, summary="ok")]
        ),
    ):
        rc = main(
            [
                "init",
                "--provider", "openai",
                "--model", "gpt-5",
                "--api-key", "test",
                "--describe", "x",
                "--openai-tools", str(openai_tools_json),
                "--output", str(out),
                "--non-interactive",
            ]
        )

    assert rc == 0
    mode = stat.S_IMODE(out.stat().st_mode)
    # Catches the regression where mkstemp-default 0o600 leaked through.
    assert mode == 0o644, f"expected 0o644 for new files, got {oct(mode)}"


def test_init_refuses_overwrite_if_file_appears_during_design(
    tmp_path: Path,
    openai_tools_json: Path,
) -> None:
    """The initial no-overwrite check is minutes-old by the time the
    LLM conversation finishes. If the destination materialises during
    that window (concurrent process, manual creation, etc.) we must
    not silently clobber it just because --force was not specified."""
    out = tmp_path / ".guardrails.yaml"

    from agent_shield_cli.init import _command as cmd

    class _CreateFileMidLoop:
        """A scripted caller that creates the destination file as a
        side effect on its first call, simulating another process
        writing to the output between the initial check and the final
        swap."""

        name = "mock"
        model = "mock"

        def __init__(self) -> None:
            self.calls = 0

        def chat(self, messages):
            self.calls += 1
            if self.calls == 1:
                out.write_bytes(b"# someone else got here first\n")
            return make_action("done", yaml=_VALID_YAML, summary="ok")

    with mock.patch.object(cmd, "build_caller", return_value=_CreateFileMidLoop()):
        rc = main(
            [
                "init",
                "--provider", "openai",
                "--model", "gpt-5",
                "--api-key", "test",
                "--describe", "x",
                "--openai-tools", str(openai_tools_json),
                "--output", str(out),
                "--non-interactive",
                # NOTE: no --force
            ]
        )
    assert rc != 0
    # The race-loser's bytes are preserved.
    assert out.read_bytes() == b"# someone else got here first\n"


def test_init_preflights_invalid_output_parent(
    tmp_path: Path,
    openai_tools_json: Path,
) -> None:
    """If --output's parent cannot be created (e.g. the path goes
    through an existing file), fail before any LLM tokens are spent."""
    # A file masquerading as a directory: trying to write `<file>/foo`
    # is illegal on POSIX.
    block = tmp_path / "blocker"
    block.write_bytes(b"not a directory")
    bad_output = block / "subdir" / "child.yaml"

    from agent_shield_cli.init import _command as cmd

    fake_caller = mock.Mock()
    with mock.patch.object(cmd, "build_caller", return_value=fake_caller):
        rc = main(
            [
                "init",
                "--provider", "openai",
                "--model", "gpt-5",
                "--api-key", "test",
                "--describe", "x",
                "--openai-tools", str(openai_tools_json),
                "--output", str(bad_output),
                "--non-interactive",
            ]
        )
    assert rc != 0
    # The LLM was never called — the preflight short-circuited
    # before build_caller's return value would have been used.
    fake_caller.chat.assert_not_called()


def test_init_refuses_clobber_of_dangling_symlink(
    tmp_path: Path,
    openai_tools_json: Path,
) -> None:
    """`Path.exists()` returns False for a dangling symlink but
    os.replace will still replace it. The CLI must treat any directory
    entry (resolved or not) as occupied unless --force was set."""
    import os as _os

    out = tmp_path / ".guardrails.yaml"
    out.symlink_to(tmp_path / "does-not-exist")

    assert not out.exists()  # Path.exists() returns False
    assert _os.path.lexists(out)  # but the directory entry is real

    from agent_shield_cli.init import _command as cmd

    with mock.patch.object(
        cmd,
        "build_caller",
        return_value=MockLlmCaller(
            script=[make_action("done", yaml=_VALID_YAML, summary="ok")]
        ),
    ):
        rc = main(
            [
                "init",
                "--provider", "openai",
                "--model", "gpt-5",
                "--api-key", "test",
                "--describe", "x",
                "--openai-tools", str(openai_tools_json),
                "--output", str(out),
                "--non-interactive",
                # NOTE: no --force
            ]
        )
    assert rc != 0
    # The dangling symlink is still there, pointing where it pointed.
    assert out.is_symlink()


def test_overwrite_preserves_existing_target_mode(
    tmp_path: Path,
    openai_tools_json: Path,
) -> None:
    """Overwriting an existing target file must inherit the target's
    prior mode, not the mkstemp default."""
    import os
    import stat

    out = tmp_path / ".guardrails.yaml"
    out.write_bytes(b"# prior\n")
    os.chmod(out, 0o640)  # group-readable, no other access

    from agent_shield_cli.init import _command as cmd

    with mock.patch.object(
        cmd,
        "build_caller",
        return_value=MockLlmCaller(
            script=[make_action("done", yaml=_VALID_YAML, summary="ok")]
        ),
    ):
        rc = main(
            [
                "init",
                "--provider", "openai",
                "--model", "gpt-5",
                "--api-key", "test",
                "--describe", "x",
                "--openai-tools", str(openai_tools_json),
                "--output", str(out),
                "--non-interactive",
                "--force",
            ]
        )
    assert rc == 0
    mode = stat.S_IMODE(out.stat().st_mode)
    assert mode == 0o640, f"expected 0o640 (inherited from prior file), got {oct(mode)}"


# ─────────────────────── Fix #2 ────────────────────────────────────


def test_summarize_schema_renders_params() -> None:
    schema = {
        "type": "object",
        "properties": {
            "amount": {"type": "number"},
            "currency": {"type": "string"},
            "reason": {"type": ["string", "null"]},
        },
        "required": ["amount"],
    }
    summary = _summarize_schema(schema)
    assert "amount*: number" in summary
    assert "currency: string" in summary
    # Union types render with `|`
    assert "reason: string|null" in summary


def test_summarize_schema_empty_inputs() -> None:
    assert _summarize_schema(None) == ""
    assert _summarize_schema({}) == ""
    assert _summarize_schema({"type": "object"}) == ""
    assert _summarize_schema({"type": "object", "properties": {}}) == ""


def test_system_prompt_includes_tool_params() -> None:
    """When tools carry input_schema, the prompt MUST surface the
    parameter names — otherwise the LLM cannot write
    ``@tool.params.X`` expressions with grounding."""
    ctx = DesignContext.from_inputs(
        sources=LoadedSources(
            tools=[
                ToolEntry(
                    name="refund_order",
                    description="Refund.",
                    source_label="openai_function",
                    input_schema={
                        "type": "object",
                        "properties": {"amount": {"type": "number"}},
                        "required": ["amount"],
                    },
                )
            ]
        ),
        description="bank bot",
        parent_path=None,
        parent_tool_names=[],
    )
    prompt = build_system_prompt(ctx)
    assert "params: {amount*: number}" in prompt


# ─────────────────────── Fix #3 ────────────────────────────────────


def test_sanitization_applies_to_user_describe() -> None:
    """A user typing 'detect prompt injection' must not survive into
    the system prompt with the literal trigger phrase."""
    ctx = DesignContext.from_inputs(
        sources=LoadedSources(tools=[ToolEntry(name="x")]),
        description="Stop prompt injection attacks and jailbreak attempts.",
        parent_path=None,
        parent_tool_names=[],
    )
    prompt = build_system_prompt(ctx)
    # Substitutions performed
    assert "prompt injection" not in prompt
    assert "jailbreak" not in prompt
    # Replacement text is present in the description section
    assert "untrusted-input attack" in prompt
    assert "input-attack" in prompt


def test_sanitization_applies_to_tool_descriptions() -> None:
    ctx = DesignContext.from_inputs(
        sources=LoadedSources(
            tools=[
                ToolEntry(
                    name="t1",
                    description="Detects jailbreak attempts in user input.",
                    source_label="openai_function",
                )
            ]
        ),
        description="bot",
        parent_path=None,
        parent_tool_names=[],
    )
    prompt = build_system_prompt(ctx)
    assert "jailbreak" not in prompt


def test_tool_names_are_NOT_sanitized(tmp_path: Path) -> None:
    """Tool name identifiers must round-trip byte-for-byte: rewriting
    them would create a mismatch between the prompt and the real
    runtime tool registry (the LLM would emit YAML referencing the
    rewritten name)."""
    parent = tmp_path / "p.yaml"
    parent.write_text(
        yaml.safe_dump(
            {
                "metadata": {"name": "p", "version": "0.1.0", "agent_shield_version": "2.0"},
                "objective": {"goal": ["g"]},
                "resources": {"tools": [{"name": "legacy_jailbreak_log"}]},
            }
        ),
        encoding="utf-8",
    )
    ctx = DesignContext.from_inputs(
        sources=LoadedSources(
            tools=[
                ToolEntry(
                    name="jailbreak_detector",
                    description="(description goes through sanitizer)",
                    source_label="openai_function",
                )
            ]
        ),
        description="bot",
        parent_path=parent,
        parent_tool_names=["legacy_jailbreak_log"],
    )
    prompt = build_system_prompt(ctx)
    # Identifiers preserved verbatim.
    assert "jailbreak_detector" in prompt
    assert "legacy_jailbreak_log" in prompt


def test_tool_param_names_are_NOT_sanitized() -> None:
    """Parameter names render verbatim so the LLM can write correct
    \\u0040tool.params.X references."""
    ctx = DesignContext.from_inputs(
        sources=LoadedSources(
            tools=[
                ToolEntry(
                    name="t",
                    description="",
                    source_label="openai_function",
                    input_schema={
                        "type": "object",
                        "properties": {"jailbreak_score": {"type": "number"}},
                    },
                )
            ]
        ),
        description="bot",
        parent_path=None,
        parent_tool_names=[],
    )
    prompt = build_system_prompt(ctx)
    assert "jailbreak_score: number" in prompt


def test_sanitization_applies_to_source_notes() -> None:
    ctx = DesignContext.from_inputs(
        sources=LoadedSources(
            tools=[ToolEntry(name="x")],
            notes=["Stripped a jailbreak filter from input."],
        ),
        description="bot",
        parent_path=None,
        parent_tool_names=[],
    )
    prompt = build_system_prompt(ctx)
    assert "jailbreak" not in prompt


# ─────────────────────── Fix #4 ────────────────────────────────────


def _write(p: Path, data: dict) -> None:
    p.write_text(yaml.safe_dump(data), encoding="utf-8")


def test_parent_tool_names_walks_extends_chain(tmp_path: Path) -> None:
    """A 3-deep extends chain must surface tools from all layers."""
    gp = tmp_path / "gp.yaml"
    _write(
        gp,
        {
            "metadata": {"name": "gp", "version": "0.1.0", "agent_shield_version": "2.0"},
            "objective": {"goal": ["g"]},
            "resources": {"tools": [{"name": "gp_tool"}]},
        },
    )
    p = tmp_path / "p.yaml"
    _write(
        p,
        {
            "extends": ["gp.yaml"],
            "metadata": {"name": "p", "version": "0.1.0", "agent_shield_version": "2.0"},
            "objective": {"goal": ["g"]},
            "resources": {"tools": [{"name": "p_tool"}]},
        },
    )
    names = parent_tool_names(p)
    assert "p_tool" in names
    assert "gp_tool" in names


def test_parent_tool_names_handles_cyclic_extends(tmp_path: Path) -> None:
    """A cyclic chain must terminate (visited-set guard), even if the
    Rust loader would reject the cycle at compile-time."""
    a = tmp_path / "a.yaml"
    b = tmp_path / "b.yaml"
    _write(
        a,
        {
            "extends": ["b.yaml"],
            "metadata": {"name": "a", "version": "0.1.0", "agent_shield_version": "2.0"},
            "objective": {"goal": ["g"]},
            "resources": {"tools": [{"name": "a_tool"}]},
        },
    )
    _write(
        b,
        {
            "extends": ["a.yaml"],
            "metadata": {"name": "b", "version": "0.1.0", "agent_shield_version": "2.0"},
            "objective": {"goal": ["g"]},
            "resources": {"tools": [{"name": "b_tool"}]},
        },
    )
    # The Rust compile will reject the cycle; the eager-trigger raises.
    # We just need to confirm we don't hang or stack-overflow getting
    # to that error.
    try:
        parent_tool_names(a)
    except Exception:
        pass
