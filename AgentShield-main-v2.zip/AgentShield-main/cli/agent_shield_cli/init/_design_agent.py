"""The design-agent turn loop.

Drives a conversation between the LLM and the user. The LLM emits
exactly one JSON action per turn (``ask`` / ``propose`` / ``done``);
the orchestrator dispatches:

- ``ask``     → print the question, read a user reply, append to the
                conversation as a user message.
- ``propose`` → validate the YAML via the Rust loader.
                * success → ask the user `[a]ccept / [r]efine / [s]kip`.
                * failure → feed the loader error back as a user
                  message. Retry budget = N_SELF_CORRECT (3) per
                  propose. After that, surface the error to the user
                  for direction (refine / abort).
- ``done``    → validate the final YAML; write it; exit.

The interactive prompts are stdin/stdout-based; ``--non-interactive``
short-circuits all user prompts: the loop refuses any ``ask`` (forces
a one-shot ``done`` path) and auto-accepts every ``propose``.
"""
from __future__ import annotations

import json
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, List, Optional

import yaml

from ._llm import LlmCaller, LlmError
from ._validate import (
    ValidationError,
    validate_standalone,
    validate_with_parent,
)


N_SELF_CORRECT = 3


@dataclass
class DesignResult:
    """Outcome of a design session.

    ``final_yaml`` is set when the session reached ``done`` with a
    validated payload; the orchestrator writes it. ``final_data`` is
    the parsed dict (same content as ``final_yaml``) for callers that
    want to inspect / re-emit.
    """

    final_yaml: Optional[str] = None
    final_data: Optional[dict] = None
    aborted: bool = False
    abort_reason: str = ""
    turns: int = 0


@dataclass
class _Session:
    caller: LlmCaller
    system_prompt: str
    parent_path: Optional[Path]
    non_interactive: bool
    in_stream: Callable[[str], str]
    out_stream: Callable[[str], None]
    max_turns: int = 30
    messages: List[Dict[str, str]] = field(default_factory=list)
    turn: int = 0

    def chat(self) -> str:
        """All LLM calls flow through here so ``max_turns`` actually caps cost.

        Each call counts as one turn regardless of which handler made
        it (top-level dispatch, self-correct, or `done`-retry). The
        budget is enforced before the call, so an exhausted session
        raises rather than running up the bill.
        """
        if self.turn >= self.max_turns:
            raise _BudgetExhausted(
                f"hit max_turns={self.max_turns} (every LLM call counts, "
                f"including self-correct and done retries)"
            )
        self.turn += 1
        return self.caller.chat(self.messages)


class _BudgetExhausted(RuntimeError):
    """Raised when ``_Session.chat`` is called past the turn budget."""


def run_design_loop(
    *,
    caller: LlmCaller,
    system_prompt: str,
    parent_path: Optional[Path] = None,
    non_interactive: bool = False,
    max_turns: int = 30,
    input_fn: Optional[Callable[[str], str]] = None,
    output_fn: Optional[Callable[[str], None]] = None,
) -> DesignResult:
    """Drive the conversation until the LLM emits ``done`` or we abort."""
    session = _Session(
        caller=caller,
        system_prompt=system_prompt,
        parent_path=parent_path,
        non_interactive=non_interactive,
        in_stream=input_fn or _default_input,
        out_stream=output_fn or _default_output,
        max_turns=max_turns,
    )
    session.messages.append({"role": "system", "content": system_prompt})

    # Kick the agent off — the first user turn names what we want.
    # Phrasing matters: imperative "do not emit X" instructions read as
    # prompt-injection attempts to Azure's content shield. Cooperative,
    # task-framing language passes filters without losing meaning.
    kick = (
        "Please get started. Begin by drafting a starter `metadata`, "
        "`objective`, and `resources.tools` block based on what you "
        "already know from the description and tool list, then propose "
        "it. After that, ask whatever clarifying questions you need "
        "(sensitivity tiers, approval thresholds, what data classes the "
        "tools handle) so we can design the variables, predicates, and "
        "Stage-2 gates together."
        if not non_interactive
        else (
            "Please design the complete `.guardrails.yaml` in this "
            "session based on the agent description and tool list. "
            "There is no follow-up human in this run, so make reasonable "
            "assumptions for anything not specified and call them out "
            "in the final `summary`. Emit `done` once the config "
            "validates."
        )
    )
    session.messages.append({"role": "user", "content": kick})

    while True:
        try:
            raw = session.chat()
        except _BudgetExhausted as exc:
            return DesignResult(
                aborted=True,
                abort_reason=str(exc),
                turns=session.turn,
            )
        except LlmError as exc:
            return DesignResult(
                aborted=True,
                abort_reason=f"LLM call failed on turn {session.turn}: {exc}",
                turns=session.turn,
            )

        action = _parse_action(raw)
        if action is None:
            session.messages.append({"role": "assistant", "content": raw})
            session.messages.append(
                {
                    "role": "user",
                    "content": (
                        "Your last message was not valid JSON for the action "
                        "protocol. Emit ONE JSON object with `action: ask | "
                        "propose | done`. Try again."
                    ),
                }
            )
            continue

        kind = action.get("action")
        # Record the assistant turn (verbatim, before dispatch) so the
        # next call sees the full history.
        session.messages.append({"role": "assistant", "content": raw})

        if kind == "ask":
            outcome = _handle_ask(session, action)
            if outcome == "abort":
                return DesignResult(
                    aborted=True,
                    abort_reason="user aborted",
                    turns=session.turn,
                )
            continue

        if kind == "propose":
            outcome = _handle_propose(session, action)
            if outcome == "abort":
                return DesignResult(
                    aborted=True,
                    abort_reason="user aborted after repeated validation failures",
                    turns=session.turn,
                )
            continue

        if kind == "done":
            return _handle_done(session, action)

        session.messages.append(
            {
                "role": "user",
                "content": (
                    f"Unknown `action` value: {kind!r}. Use `ask`, "
                    f"`propose`, or `done`."
                ),
            }
        )

    # Unreachable — `session.chat()` raises when the budget is spent;
    # the loop only exits via `return` above.


# ─────────────────────── Action dispatchers ───────────────────────


def _handle_ask(session: _Session, action: dict) -> str:
    question = (action.get("question") or "").strip()
    if not question:
        session.messages.append(
            {
                "role": "user",
                "content": "Your `ask` had no `question`. Try again.",
            }
        )
        return "retry"

    if session.non_interactive:
        session.messages.append(
            {
                "role": "user",
                "content": (
                    "The CLI is running in --non-interactive mode. No human "
                    "is available to answer. Make a best-effort assumption, "
                    "note it in your next propose's `explanation`, and "
                    "proceed."
                ),
            }
        )
        return "ok"

    session.out_stream(f"\n? {question}\n")
    answer = session.in_stream("> ").strip()
    if answer.lower() in {"abort", "quit", "exit"}:
        return "abort"
    session.messages.append({"role": "user", "content": answer or "(skipped)"})
    return "ok"


def _handle_propose(session: _Session, action: dict) -> str:
    yaml_text = action.get("yaml") or ""
    explanation = (action.get("explanation") or "").strip()

    if explanation:
        session.out_stream(f"\n— {explanation}\n")

    for attempt in range(1, N_SELF_CORRECT + 1):
        try:
            data = _parse_and_validate(yaml_text, session.parent_path)
        except _ProposeError as err:
            session.out_stream(
                f"  ✗ validation attempt {attempt}/{N_SELF_CORRECT}: {err}\n"
            )
            if attempt == N_SELF_CORRECT:
                # Fall through to user-fallback (ii).
                resolution = _user_fallback_after_validation_failure(session, err)
                if resolution == "abort":
                    return "abort"
                # User asked the agent to retry with feedback they typed.
                session.messages.append(
                    {
                        "role": "user",
                        "content": (
                            f"validation_error: {err}\n"
                            f"user_feedback: {resolution}"
                        ),
                    }
                )
                return "continue"

            # Self-correct: feed the loader error back, get a retry.
            session.messages.append(
                {
                    "role": "user",
                    "content": (
                        f"validation_error: {err}\n"
                        "Emit a new `propose` that fixes this exact issue. "
                        "Do not change anything else."
                    ),
                }
            )
            try:
                retry_raw = session.chat()
            except (LlmError, _BudgetExhausted) as exc:
                session.out_stream(f"  ✗ LLM error during self-correct: {exc}\n")
                return "continue"
            session.messages.append({"role": "assistant", "content": retry_raw})
            retry_action = _parse_action(retry_raw)
            if retry_action is None or retry_action.get("action") != "propose":
                session.out_stream(
                    "  ✗ retry was not a propose; bailing out of self-correct loop\n"
                )
                return "continue"
            yaml_text = retry_action.get("yaml") or ""
            continue

        # validation succeeded
        choice = _accept_refine_skip(session, data, yaml_text)
        if choice == "accept":
            session.messages.append(
                {
                    "role": "user",
                    "content": (
                        "User accepted the proposal. Continue with the next "
                        "increment (ask the next question if you need more "
                        "input, propose more policies, or emit `done` if the "
                        "config is complete)."
                    ),
                }
            )
        elif choice == "skip":
            session.messages.append(
                {
                    "role": "user",
                    "content": (
                        "User skipped this proposal. Try a different "
                        "approach or move on."
                    ),
                }
            )
        else:
            session.messages.append(
                {
                    "role": "user",
                    "content": f"User feedback on the proposal: {choice}",
                }
            )
        return "continue"
    return "continue"


def _handle_done(session: _Session, action: dict) -> DesignResult:
    yaml_text = action.get("yaml") or ""
    try:
        data = _parse_and_validate(yaml_text, session.parent_path)
    except _ProposeError as err:
        # Final payload is invalid — last-chance self-correct.
        session.out_stream(f"\n✗ final config did not validate: {err}\n")
        session.messages.append(
            {
                "role": "user",
                "content": (
                    f"validation_error on `done`: {err}\nEmit a corrected "
                    "`done` action with valid YAML."
                ),
            }
        )
        try:
            retry_raw = session.chat()
        except (LlmError, _BudgetExhausted) as exc:
            return DesignResult(
                aborted=True, abort_reason=f"LLM error on done retry: {exc}",
                turns=session.turn,
            )
        session.messages.append({"role": "assistant", "content": retry_raw})
        retry_action = _parse_action(retry_raw)
        if retry_action is None or retry_action.get("action") != "done":
            return DesignResult(
                aborted=True,
                abort_reason="retried done was not a done action",
                turns=session.turn,
            )
        yaml_text = retry_action.get("yaml") or ""
        try:
            data = _parse_and_validate(yaml_text, session.parent_path)
        except _ProposeError as err2:
            return DesignResult(
                aborted=True,
                abort_reason=f"final config invalid after retry: {err2}",
                turns=session.turn,
            )

    # When --from was supplied, the LLM is instructed to emit
    # `extends:` pointing at the parent. The model can forget — and
    # `_parse_and_validate` happily strips and validates regardless,
    # because the parent is supplied to the loader directly. Inject
    # the canonical `extends:` here so the on-disk file actually
    # references the parent. Re-validate after injection.
    if session.parent_path is not None:
        data = _inject_canonical_extends(data, session.parent_path)
        try:
            # Re-validate the post-injection shape via the standard
            # path-based parent + dict child route.
            _parse_and_validate(
                yaml.safe_dump(data, sort_keys=False),
                session.parent_path,
            )
        except _ProposeError as err:
            return DesignResult(
                aborted=True,
                abort_reason=f"post-injection validation failed: {err}",
                turns=session.turn,
            )

    summary = (action.get("summary") or "").strip()
    if summary:
        session.out_stream(f"\nsummary: {summary}\n")

    # When extends was injected, re-serialise data so final_yaml
    # reflects the post-injection shape and stays consistent with
    # final_data (avoids callers writing a file that is missing extends).
    if session.parent_path is not None:
        yaml_text = yaml.safe_dump(data, sort_keys=False, allow_unicode=True)

    return DesignResult(
        final_yaml=yaml_text,
        final_data=data,
        turns=session.turn,
    )


def _inject_canonical_extends(
    data: Dict[str, object], parent_path: Path
) -> Dict[str, object]:
    """Force ``extends: [<absolute parent path>]`` into ``data``.

    Replaces whatever the LLM emitted (or didn't) with a single-entry
    list pointing at the parent. The path is left absolute here so
    validation works regardless of cwd; the CLI orchestrator rewrites
    it to a path relative to the on-disk output dir before emitting.
    """
    new_data: Dict[str, object] = {}
    new_data["extends"] = [str(parent_path.resolve())]
    for key, value in data.items():
        if key == "extends":
            continue
        new_data[key] = value
    return new_data


# ─────────────────────── Helpers ──────────────────────────────────


class _ProposeError(Exception):
    """Raised when a propose YAML fails parse or validation."""


def _parse_and_validate(yaml_text: str, parent_path: Optional[Path]) -> dict:
    if not yaml_text.strip():
        raise _ProposeError("empty `yaml` field")
    try:
        data = yaml.safe_load(yaml_text)
    except yaml.YAMLError as exc:
        raise _ProposeError(f"YAML parse error: {exc}") from exc
    if not isinstance(data, dict):
        raise _ProposeError(
            f"top-level YAML must be an object (got {type(data).__name__})"
        )
    try:
        if parent_path is None:
            validate_standalone(data)
        else:
            # The model is told to emit `extends:` on the final `done`
            # YAML when a parent is present; strip it for the in-memory
            # validator (parent path is the source of truth there).
            tmp = {k: v for k, v in data.items() if k != "extends"}
            validate_with_parent(parent_path, tmp)
    except ValidationError as exc:
        raise _ProposeError(str(exc)) from exc
    return data


def _parse_action(raw: str) -> Optional[dict]:
    raw = raw.strip()
    # Some providers wrap JSON in ```json fences even with response_format.
    if raw.startswith("```"):
        lines = raw.splitlines()
        if lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        raw = "\n".join(lines)
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        return None
    if not isinstance(parsed, dict):
        return None
    return parsed


def _accept_refine_skip(session: _Session, data: dict, yaml_text: str) -> str:
    """Show the validated proposal and read the user's decision.

    Returns ``"accept"``, ``"skip"``, or a free-text feedback string.
    Non-interactive mode auto-accepts every proposal.
    """
    session.out_stream("\n```yaml\n" + yaml_text.rstrip() + "\n```\n")
    if session.non_interactive:
        return "accept"
    raw = session.in_stream("[a]ccept / [r]efine / [s]kip > ").strip().lower()
    if raw in {"a", "accept", ""}:
        return "accept"
    if raw in {"s", "skip"}:
        return "skip"
    # 'r' or any other text → request refinement
    if raw in {"r", "refine"}:
        feedback = session.in_stream("what should change? > ").strip()
        return feedback or "Refine further."
    return raw


def _user_fallback_after_validation_failure(
    session: _Session, err: _ProposeError
) -> str:
    """After N_SELF_CORRECT failures, hand the wheel to the user."""
    if session.non_interactive:
        return "abort"
    session.out_stream(
        f"\nThe model couldn't produce a valid proposal after "
        f"{N_SELF_CORRECT} attempts. Last error:\n  {err}\n"
        "[r]etry with your feedback / [a]bort > "
    )
    raw = session.in_stream("").strip().lower()
    if raw in {"a", "abort", "quit", "exit"}:
        return "abort"
    return session.in_stream("feedback for the model > ").strip() or "Retry."


# ─────────────────────── stdio defaults ───────────────────────────


def _default_input(prompt: str) -> str:
    try:
        return input(prompt)
    except EOFError:
        return ""


def _default_output(text: str) -> None:
    sys.stdout.write(text)
    sys.stdout.flush()


__all__ = ["DesignResult", "run_design_loop"]
