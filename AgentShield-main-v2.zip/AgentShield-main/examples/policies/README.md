# Reference policies

## DEMO ONLY

These policy examples are starting points, not complete production-ready deployments or control attestations.


Reference `.guardrails.yaml` files demonstrating specific Agent Shield
patterns. No demo code — these are pure policy artifacts you can lift
into your own project, paired with explanations of what each pattern
teaches and how to wire it into a runtime.

For runnable end-to-end agent demos, see [`../agents/`](../agents/).

## Validate any of these locally

```bash
# JSON Schema validation (catches misspellings, shape errors)
python -m jsonschema -i examples/policies/<file>.yaml \
    spec/schema/guardrails.schema.json

# Full loader validation (resolves references, expressions, prompt_path:)
cargo run -p agent_shield_core --example validate -- examples/policies/<file>.yaml
```

## Catalog

| Pattern | File | What it teaches |
|---|---|---|
| **Information-flow control** | [`ifc-email-assistant.yaml`](ifc-email-assistant.yaml) | The full §13 IFC story — tag-set lattice, exposure tracking, declassification at named boundaries. Companion docs: [`docs/information-flow-control.md`](../../docs/information-flow-control.md), [`docs/information-flow-control-proof.md`](../../docs/information-flow-control-proof.md). |
| **HTTP endpoint governance** | [`endpoint-governance.yaml`](endpoint-governance.yaml) | URL-pattern allow/deny — exact match, parameterised (`/users/{id}`), glob (`/internal/**`), catch-all, rate limiting, state-based escalation. |
| **Channel governance** | [`channel-governance/`](channel-governance/) | Per-channel governance for Slack, Discord, WhatsApp, Signal, Telegram, iMessage, Google Chat, plus a `popular-channels.yaml` composing the common subset. |
| **External classifiers** | several | Wiring an external classifier as a `configurations[]` entry with `type: classifier`. Bundled provider modules are gated by Cargo feature flags. See per-classifier sections below. |

### IFC email assistant (`ifc-email-assistant.yaml`)

Demonstrates Agent Shield's **information-flow control** on a
realistic agent loop. The agent reads customer data from internal
sources and writes responses through external channels; the lattice
prevents the secret-to-public flow systematically without per-policy
rules.

```
                                    ┌─── send_email_external (μ = ∅, ν = ∅)
read_customer_balance                                         (PUBLIC SINK)
  λ = {pii, financial}              │
        │                           │
        ▼                           │
  exposure ⊆ μ?  ─── NO ────────────┘  ✗ DENIED
                                       (proof: Eₙ ⊄ μ(send_email_external))
```

The agent has read PII and financial data, raising the running
exposure to `{pii, financial}`. The external email sink advertises
`μ = ∅` (no privileges), so the IFC engine refuses the call before
a per-tool guard policy is even consulted.

See `docs/information-flow-control-proof.md` for the formal
compliance proof.

### Endpoint governance (`endpoint-governance.yaml`)

URL-pattern resolution order (most specific wins):

1. **Exact match** — `/api/v1/health`
2. **Parameterised** — `/api/v1/users/{user_id}` (one path segment)
3. **Glob** — `/internal/**` (zero or more path segments)
4. **Catch-all** — `**`

Patterns covered: read-allowed but mutating-methods gated by approval;
internal `**` allowed with logging while admin `**` is hard-blocked;
catch-all denies unlisted endpoints; payment endpoint capped at
50 calls/hour; rate-limit warning escalates payments to approval.

### Channel governance (`channel-governance/`)

Per-channel content-and-send governance for chat platforms. Each YAML
is independently loadable. `popular-channels.yaml` composes the
common subset for an organisation that needs the same baseline
across Slack, Teams, and WhatsApp.

### External classifiers

Wiring an external classifier into Agent Shield is one
`configurations[]` entry plus a Cargo feature flag. The bundled
provider modules under
[`sdk/rust/agent_shield_core/src/classifiers/`](../../sdk/rust/agent_shield_core/src/classifiers/)
take care of the HTTP wire shape, retries, and category mapping.

| Classifier | File | Cargo feature | Required env |
|---|---|---|---|
| Azure AI Content Safety | [`azure-content-safety.yaml`](azure-content-safety.yaml) | `azure-content-safety` (alias `aacs`) | `AZURE_CONTENT_SAFETY_KEY` |
| Lakera Guard | [`lakera-guard.yaml`](lakera-guard.yaml) | `lakera-guard` | `LAKERA_GUARD_API_KEY` |
| Llama Guard | [`llama-guard.yaml`](llama-guard.yaml) | `llama-guard` | (self-hosted endpoint) |
| OpenAI Moderation | [`openai-moderation.yaml`](openai-moderation.yaml) | `openai-moderation` | `OPENAI_API_KEY` |
| Perspective API | [`perspective-api.yaml`](perspective-api.yaml) | `perspective` | `PERSPECTIVE_API_KEY` |

Each YAML is an end-to-end working configuration — the bank-manager or
document-dlp demos can `extends: <classifier>.yaml` to pull in the
bundled provider.

#### Azure AI Content Safety setup

1. An Azure AI Content Safety resource ([create one](https://portal.azure.com/#create/Microsoft.CognitiveServicesContentSafety)).
2. The resource endpoint and an API key (or an Entra ID credential).

```yaml
configurations:
  - id: aacs
    type: classifier
    provider: azure_content_safety
    endpoint: https://myresource.cognitiveservices.azure.com
    api_key_env: AZURE_CONTENT_SAFETY_KEY
    category_thresholds:
      Hate: 2
```

`category_thresholds` gates the verdict per category — only listed
categories are monitored.
