# Agent Shield

**An open specification and reference implementation for securing agentic AI systems**

[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Spec](https://img.shields.io/badge/spec-v2.0.0--alpha-blue)](spec/SPECIFICATION.md)
[![Status](https://img.shields.io/badge/status-alpha-orange)](#)

---

## 🛡️ What is Agent Shield?

Agent Shield is an open specification and reference SDK and runtime for **security controls on AI agents**. It defines guardrails as a portable, declarative YAML contract that gates every tool call, endpoint call, and sub-agent invocation an agent attempts, **enforced outside the model**. Agent Shield is a mediation layer, not a sandbox; see [`docs/security-model.md`](docs/security-model.md) for trust boundaries and integration requirements.

The same `.guardrails.yaml` file works across LangChain, AutoGen, OpenAI Agents SDK, CrewAI, Anthropic Agents SDK, and [LiteLLM Proxy](docs/integrations/litellm-proxy.md). Security teams can review one contract; developers integrate with a short framework wrapper around an `.guardrails.yaml` file; the runtime enforces everything automatically. See [QUICKSTART.md](QUICKSTART.md) for installation and integration walkthroughs.

> **The model picks the action, and Agent Shield controls it. That decision is based on deterministic and probabilistic rules the model can't talk its way around.**

### The problem

AI agents read untrusted content (emails, documents, MCP tool outputs) and take real actions (send messages, move money, change configurations) and traditional governance systems are not well equiped to solve this because they assume a fixed actor and a fixed scope. IAM, network policies, and allow/deny rules that answer the same question: "is this credential allowed to access this resource?". That model breaks for agents because the same credential that is appropriate in one turn of the loop is dangerous in the next. A Slack token that's fine for posting a meeting summary is dangerous the moment after the agent has read a document tagged confidential. The credential didn't change, but the state did. 

Customer ends up using 3 approaches that break in different ways:

- **System prompts**: The first line of defense is a system prompt like "you MUST NOT...". System-prompt instructions live in the same text stream as everything else and the model has no structural way to distinguish operator policy from untrusted data. 
- **Custom code in the agent SDK**: For tighter controls, developers can add rules directly inside their Agent code. This works for the deterministic cases, but the rules end up locked inside code: hard to audit, hard to modify on the fly, hard to replicate across deployments, and invisible to the security team that has to sign off. Even more problematic, nothing prevents an Agent from crafting custom python code and call the end point directly.  
- **Input and output classifiers**: They catch useful classes of bad problems like  jailbreak detectors, PII scrubbers, and indirect-prompt-injection classifiers when probabilistic checks are needed. But they can't see what matters most: the tool call itself, its parameters, or the tool result about to be read into session memory. They also score text in isolation, so they can't tell that transfer $50,000 is fine for one user and forbidden for another, or that the same query is acceptable in read-only mode and forbidden after the agent has touched restricted data. That's a job for a deterministic state machine, not a classifier. 


| Approach | What it does | Why it fails |
|---|---|---|
| **System prompt** | "Please don't send sensitive data" | Advisory. The model decides whether to comply. |
| **Input classifiers** | Scan input for known jailbreak patterns | Probabilistic, narrow scope. |
| **Output classifiers** | Scan response for PII / toxicity | Too late — the tool already executed. |
| **Per-framework hooks** | LangChain `on_tool_start`, code filters | Custom code, locked to one framework, no portability. |

### The solution

![Agent Shield](/docs/assets/images/Agent%20shield.png)

A single `.guardrails.yaml` declares the agent's objective, forbidden behaviors, configured providers, **variables** (typed runtime state with metadata), **predicates** (named expressions), **events and lifetimes**, **resolvers** (the unified gate), **guard policies** (the unified enforcement primitive), and the resource catalog. The runtime enforces it deterministically across five validation stages. The same file is reviewed by security, version-controlled, and reused across frameworks and deployments.

---

## The model in one paragraph

Every gating decision runs through one of five **validation stages** — Input, State, Tool execution, Post-tool, Output — using the same `guard_policies[]` schema. The runtime evaluates a Rego-inspired predicate language over typed **variables**, emits **events**, and dispatches **resolvers** (`expression`, `human`, `tool`, `delegate`, `agent`) to produce allow/deny verdicts. The same contract gates MCP tools, HTTP endpoints, and sub-agents.

![Agent Shield](/docs/assets/images/5%20stages.jpg)

> For the full model — stage semantics, core building blocks, runtime intercepts, and the resolver / guard-policy contract — see [`spec/SPECIFICATION.md` §2](spec/SPECIFICATION.md#2-the-agent-shield-model).

---


## What does a policy looks like. 

Here is shortened version of an example YAML file. This policy gates outbound email based on the sensitivity of of a document. A `data_sensitivity` variable starts at public and is ratcheted up — never down — each time Get_Document_Content runs for the rest of the session. Two guards watch every sendMail call: if an internal document is in scope, the runtime pauses and asks the human to `allow_once`, `allow_always`, or `decline`; the answer's lifetime is derived from the choice. If a protected document is in scope, no prompt is shown but the rule must satisfy that at most ten recipients across To/Cc/Bcc combined, and every To recipient must be a @microsoft.com address. Anything that fails either gate is blocked and logged.

```yaml

variables:
  - name: "data_sensitivity"
    type: enum
    members: ["public", "internal", "protected"]
    default: "public"
    update: "max(@current, @incoming)"
    populated_by:
      - kind: tool
        name: "Get_Document_Content"

  # The human resolver fires on the first read while @status == 'unset'.
  - name: "internal_send_decision"
    type: enum
    members: ["allow_once", "allow_always"]
    on_demand_by:
      kind: human
      prompt: >-
        The agent wants to email an INTERNAL document via sendMail.
        Subject: ${@tool.params.subject}
        Reply with one of:
          allow_once   — permit this single send,
          allow_always — permit every internal-document send for the
                         rest of this session,
          decline      — block this send and stop asking for the rest
                         of this session.
      context:
        sensitivity: "data_sensitivity"
      on_error: block
    lifetime:
      allow: "@incoming == 'allow_always' ? 'per_session' : 'per_call'"
      deny:
        until_event:
          - session.end

state_validation:
  guard_policies:
    # ── Internal document → sendMail needs human approval. ─────────
    # The first read of `internal_send_decision` while @status ==
    # 'unset' triggers auto-resolution (§11.5) and fires the human
    # resolver. 
    - name: "internal_doc_send_gate"
      applies_to:
        tools: ["mcp_MailTools_graph_mail_sendMail"]
      active_if: "is_internal"
      evaluate_when:
        - expression: "internal_send_decision in ['allow_once', 'allow_always']"
          reason: >-
            Sending an internal document requires human approval. The
            user either declined or has not yet approved this send.
    # ── Protected document → strict recipient allowlist + count. ──
    # Recipients live in the sendMail call's parameters (§Work IQ
    # Mail MCP). 
    - name: "protected_doc_send_gate"
      applies_to:
        tools: ["mcp_MailTools_graph_mail_sendMail"]
      active_if: "is_protected"
      evaluate_when:
        - expression: >-
            count(coalesce(@tool.params.toRecipients,  []))
            + count(coalesce(@tool.params.ccRecipients,  []))
            + count(coalesce(@tool.params.bccRecipients, []))
            <= 10;
            all(coalesce(@tool.params.toRecipients,  []), r -> endswith(r.emailAddress.address, '@microsoft.com'))
      reason: >-
            Protected documents may be emailed to at most 10
            recipients in total (toRecipients + ccRecipients + bccRecipients)
            and may only be emailed to @microsoft.com
            recipients.
      log:
        severity: high|medium|low
        category: "..."
        message: "..."
```


---

## Composability

A `.guardrails.yaml` can `extends:` other files. The merger is additive and intended to never weaken a policy. A common pattern is a three-tier chain would be:

```
organization.guardrails.yaml      # CISO baseline
   └─ extends: tools.guardrails.yaml      # platform tool catalog
         └─ extends: developer.guardrails.yaml  # app-specific overrides
```

Arbitrary chains are supported. The runtime resolves the chain at load time and validates compatibility against `metadata.agent_shield_version`.

---

##  Integrating Agent Shield

Agent Shield meets your agent where it already lives. There are three ways to wire it in. Full installation, code samples, and end-to-end walkthroughs are in [QUICKSTART.md](QUICKSTART.md).

### 1. Framework adapters

If your agent is built on a supported framework, the adapter is the shortest path: a two- or three-line wrapper turns any agent into a guarded agent, with all five stages active and the same `.guardrails.yaml` enforced identically across backends. This is best for client-side agents and development/test.

| Framework | Adapter |
|---|---|
| LangChain | [Python](sdk/python/agent_shield/adapters/) |
| OpenAI Agents SDK | [Python](sdk/python/agent_shield/adapters/) |
| Anthropic Agents SDK | [Python](sdk/python/agent_shield/adapters/) |
| AutoGen | [Python](sdk/python/agent_shield/adapters/) · [.NET](sdk/dotnet/) |
| CrewAI | [Python](sdk/python/agent_shield/adapters/) |
| Semantic Kernel | [Python](sdk/python/agent_shield/adapters/) · [.NET](sdk/dotnet/) |

Three lines turn an existing LangChain agent into a guarded one:

```python
from agent_shield import Shield
import agent_shield.adapters.langchain  # side-effect import: installs .with_langchain() and .create_langchain_agent()

shield = Shield.from_yaml(".guardrails.yaml").with_langchain().with_client(my_llm).build()
guarded = shield.guard(my_agent)              # all 5 stages now active
result  = await guarded.ainvoke(user_input)
```

→ See [QUICKSTART §4 — Integrate with your framework](QUICKSTART.md#4-integrate-with-your-framework) for every supported framework and the manual-compose / function-level variants.

### 2. Gateway / proxy deployment

If you run agents behind a centralised LLM gateway, the same `.guardrails.yaml` can be enforced at the proxy boundary. Zero changes to client agents, and one chokepoint for every agent in the fleet. Recommended for cloud deployments

- **[LiteLLM Proxy](docs/integrations/litellm-proxy.md)** — drop-in guardrail plugin for the OpenAI-compatible gateway many teams already run for centralised LLM access. Stage map, threat model, and streaming behaviour documented.
- **[Istio + SDK reference](deploy/kubernetes/istio-sdk-reference/)** — production-grade Kubernetes deployment pairing the SDK with Istio for mesh-level mTLS, identity, and OTel telemetry. See [docs/istio-sdk-reference-architecture.md](docs/istio-sdk-reference-architecture.md).

→ See [QUICKSTART §5 — Gateway / proxy deployment](QUICKSTART.md#5-gateway--proxy-deployment).

### 3. Direct SDK integration

If you've built your agent loop yourself, or you're on a framework Agent Shield doesn't yet have an adapter for, you can call the runtime API directly. You manage sessions, `begin_turn` / `end_turn`, and the per-stage `validate_*` calls; the runtime handles the rest.

| Language | SDK | Native primitives shipped alongside |
|---|---|---|
| Python | [`agent_shield`](sdk/python/) | MCP server guard |
| Node.js / TypeScript | [`@microsoft/agent-shield`](sdk/node/) | MCP server guard |
| .NET | [`AgentShield`](sdk/dotnet/) | `GuardedChatClient` for Microsoft.Extensions.AI (`UseAgentShield()`) |
| Rust | [`agent_shield_core`](sdk/rust/) | `agent_shield_rig` (`GuardedRigTool`), `agent_shield_mcp` |

→ See [QUICKSTART §6 — Direct SDK integration](QUICKSTART.md#6-direct-sdk-integration).

Adapter-specific mediation boundaries live in per-adapter `MEDIATION.md` files plus the shared docs below:

- [`docs/adapter-mediated-paths.md`](docs/adapter-mediated-paths.md)
- [`docs/SDK_PARITY.md`](docs/SDK_PARITY.md)
- [`docs/FRAMEWORK_COMPAT.md`](docs/FRAMEWORK_COMPAT.md)
- [`docs/THIRD_PARTY_ADAPTER_CONFORMANCE.md`](docs/THIRD_PARTY_ADAPTER_CONFORMANCE.md)

---

## Demos

End-to-end runnable demos with mock MCP servers ship in [`examples/agents/`](examples/agents/). Each demo's `demo.py` is one script with a `--framework {langchain,anthropic}` flag — same `guardrails.yaml`, same scenarios, same verdicts across both backends. Use `--scenarios all` for a scripted side-by-side guarded ↔ unguarded run.

| Demo | What it shows | README |
|---|---|---|
| **Bank Manager** | All 5 stages — VIP transfer approvals, social engineering, prompt injection in tool memos, account enumeration, composable YAML tiers | [README](examples/agents/bank-manager/README.md) |
| **Document DLP** | Sensitivity ratchets, jurisdiction tracking, graduated email policy, output PII redaction | [README](examples/agents/document-dlp/README.md) |

Reference YAML configurations (no demo code) — IFC, endpoint governance, channel governance, classifier wirings — live in [`examples/policies/`](examples/policies/). The full `examples/` map is in [`examples/README.md`](examples/README.md).

---

## Documentation

- **[QUICKSTART.md](QUICKSTART.md)** — install, integrate, run a demo in 5 minutes.
- **[docs/getting-started/init.md](docs/getting-started/init.md)** — `agent-shield init`: LLM-driven `.guardrails.yaml` designer.
- **[docs/architecture.md](docs/architecture.md)** — runtime architecture: stages, sessions, event bus, resolver runtime.
- **[docs/security-model.md](docs/security-model.md)** — security model: trust boundaries, fail-closed semantics, threat model.
- **[docs/adapter-mediated-paths.md](docs/adapter-mediated-paths.md)** — adapter coverage: mediated paths, unsupported paths, bypass assumptions, and per-adapter mediation references.
- **[docs/SDK_PARITY.md](docs/SDK_PARITY.md)** — public Shield / ShieldBuilder parity across Rust, Python, Node, and .NET.
- **[docs/FRAMEWORK_COMPAT.md](docs/FRAMEWORK_COMPAT.md)** — supported framework/package ranges and the CI-backed compatibility matrix.
- **[docs/THIRD_PARTY_ADAPTER_CONFORMANCE.md](docs/THIRD_PARTY_ADAPTER_CONFORMANCE.md)** — the minimum evidence a third-party adapter must publish before Agent Shield links to it.
- **[docs/DESIGN_CONSIDERATIONS.md](docs/DESIGN_CONSIDERATIONS.md)** — design guidance index for mediation boundaries, portability, and operational trade-offs.
- **[docs/POST_TOOL_LIMITS.md](docs/POST_TOOL_LIMITS.md)** — why Stage 4/5 do not roll back irreversible side effects and what compensating controls hosts still need.
- **[docs/pluggable-moderation.md](docs/pluggable-moderation.md)** — bundled moderation classifier providers (AACS, Lakera, Llama Guard, OpenAI Moderation, Perspective).
- **[docs/istio-sdk-reference-architecture.md](docs/istio-sdk-reference-architecture.md)** — deploy SDK-integrated agents in Istio with ConfigMaps, mTLS, and OTel wiring.
- **[docs/integrations/litellm-proxy.md](docs/integrations/litellm-proxy.md)** — enforce a `.guardrails.yaml` at a LiteLLM Proxy boundary (stage map, threat model, streaming behaviour).
- **[spec/SPECIFICATION.md](spec/SPECIFICATION.md)** — the canonical, normative spec (v2.0.0-alpha).
- **[spec/expressions/LANGUAGE.md](spec/expressions/LANGUAGE.md)** — the Agent Shield expression language.
- **[spec/schema/guardrails.schema.json](spec/schema/guardrails.schema.json)** — JSON Schema for `.guardrails.yaml` files.
- **[CHANGELOG.md](CHANGELOG.md)** — release notes.

---




## ❓ FAQ

### How is this different from framework guardrail hooks?

Framework hooks (LangChain `on_tool_start`, SK filters, OpenAI Agents SDK guardrails) tell you *where* to put security logic. Agent Shield is a specification for *what* that logic should be. They're complementary: Agent Shield integrates through framework hooks, but the value is in a standardized, auditable, portable security model that sits above any single framework.

### How is this different from putting safety rules in the system prompt?

System prompts are advisory. Stage 2 state validation is deterministic (predicate evaluation over typed variables), and Stage 3 tool-execution validation runs in a separate context that the agent can't manipulate. No amount of prompt manipulation bypasses a `guard_policy: { action: block }`.

### What's the relationship to MCP?

MCP defines how agents talk to tools. Agent Shield defines what agents are allowed to do with those tools. The two are complementary; the `mcp_server` configuration type and the wildcard `name: "*"` resource entry make MCP-tool governance a first-class case.

---

## 📄 License

MIT — see [LICENSE](LICENSE).

## 🤝 Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). This project has adopted the [Microsoft Open Source Code of Conduct](https://opensource.microsoft.com/codeofconduct/).

## 🔒 Security

To report a security vulnerability, please see [SECURITY.md](SECURITY.md).

Operational security references:

- [docs/security-model.md](docs/security-model.md)
- [docs/POST_TOOL_LIMITS.md](docs/POST_TOOL_LIMITS.md)
- [docs/adapter-mediated-paths.md](docs/adapter-mediated-paths.md)

Additional operator-facing security references:

- [Production deployment checklist](docs/PRODUCTION_DEPLOYMENT.md)
- Runbooks:
  - [Incident deny storm](docs/runbooks/incident-deny-storm.md)
  - [Incident resolver down](docs/runbooks/incident-resolver-down.md)
  - [Incident streaming leak](docs/runbooks/incident-streaming-leak.md)
  - [Incident limit exceeded](docs/runbooks/incident-limit-exceeded.md)
  - [Incident resolver trust failure](docs/runbooks/incident-resolver-trust.md)
  - [Release rollback](docs/runbooks/release-rollback.md)
- [External risk-framework mappings](docs/RISK_MAPPINGS.md)

---

## 🙏 Acknowledgments

Inspired by:
- [Model Context Protocol (MCP)](https://modelcontextprotocol.io) — standardizing agent-tool communication.
- [Apache Iceberg](https://iceberg.apache.org) — open table-format specification as a precedent for portable, declarative contracts.
- OpenClaw security research — real-world agent vulnerabilities.

---

Built with ❤️ for safer AI agents.
