# Agent Shield — Quickstart

Get up and running with Agent Shield in five minutes. This guide walks the three integration paths in order of decreasing convenience: **framework adapter** (shortest path, recommended), **gateway / proxy** (one chokepoint for an agent fleet), and **direct SDK** (full control for custom agent loops).

---

## 1. Prerequisites

- One of: Python 3.11+, Node.js 18+, .NET 8+, or Rust 1.78+.
- For Stage 1 / Stage 3 / Stage 4 LLM-based validators: an LLM API key (OpenAI, Azure OpenAI, or Anthropic). Pure expression / pattern guards do not need a key.

---

## 2. Install the SDK

> **Latest released version.** The version literals on this page are placeholders shown as `<version>` — substitute the version of the artifact you actually have (e.g., `0.13.0-alpha.1`). Filenames produced by the publish workflow embed the version automatically; nothing below is meant to be copy-pasted with the literal `<version>` left in place.

### From a locally downloaded wheel / package

If you have a wheel, tarball, or NuGet package from a GitHub Actions build (or a pinned release artifact) and want to install it directly — no PyPI / npm / NuGet.org needed:

```bash
# Python — abi3 wheel works on every CPython ≥ 3.11
pip install ./agent_shield-<version>-cp311-abi3-manylinux_2_34_x86_64.whl
# Or with extras (resolves the wheel for the core package, then PyPI for the extra):
pip install "./agent_shield-<version>-cp311-abi3-manylinux_2_34_x86_64.whl[langchain]"

# Node — local tarball
npm install ./microsoft-agent-shield-<version>.tgz

# .NET — local NuGet folder source
dotnet nuget add source ./packages --name local
dotnet add package AgentShield --version <version> --source local
```

> **Python wheels are abi3.** A single `cp311-abi3-<platform>.whl` works on every CPython ≥ 3.11 (3.11, 3.12, 3.13, …). Do **not** rename the wheel filename to coerce pip on a different Python version — the install will succeed but the import will fail (`ModuleNotFoundError: No module named 'agent_shield._native'`) because the actual native module is `_native.abi3.so` / `_native.pyd` regardless of filename tag.

> **The snippets below assume Agent Shield is on a public package registry.** Today, Agent Shield is not on PyPI / npm / NuGet.org / crates.io — releases are private GitHub Actions artifacts (see [`RELEASING.md`](RELEASING.md)). Use the local-package install above. The public-registry snippets are kept here so the consumer-facing shape is clear for when the project decides to publish externally.

### Python

```bash
pip install agent-shield                    # core (surface under agent_shield)

# With a framework adapter
pip install agent-shield[langchain]
pip install agent-shield[openai-agents]
pip install agent-shield[all]               # all frameworks
```

### Node.js

```bash
npm install @microsoft/agent-shield
```

### .NET

```bash
dotnet add package AgentShield
```

### Rust

```toml
# Cargo.toml — pin to the latest 0.x.y release in the AgentShield repo.
# Crates are not published to crates.io; consume via git or a local path.
[dependencies]
agent_shield_core = { git = "https://github.com/microsoft/AgentShield", tag = "v<version>" }
# Optional framework adapters (same pattern):
# agent_shield           = { git = "https://github.com/microsoft/AgentShield", tag = "v<version>" }
# agent_shield_anthropic = { git = "https://github.com/microsoft/AgentShield", tag = "v<version>" }
# agent_shield_openai    = { git = "https://github.com/microsoft/AgentShield", tag = "v<version>" }
# agent_shield_langchain = { git = "https://github.com/microsoft/AgentShield", tag = "v<version>" }
# agent_shield_rig       = { git = "https://github.com/microsoft/AgentShield", tag = "v<version>" }
# agent_shield_mcp       = { git = "https://github.com/microsoft/AgentShield", tag = "v<version>" }
```

### From source

```bash
git clone https://github.com/microsoft/AgentShield.git
cd AgentShield

pip install -e sdk/python[all]
# or build from sdk/node, sdk/dotnet, sdk/rust as needed
```

---

## 3. Set up LLM credentials (optional)

Stages 1, 3, and 4 can use an LLM via a registered `LlmCaller` / `ClassifierCaller`. Demos auto-load `.env` from `examples/<demo>/demo/.env`:

```bash
cp examples/agents/bank-manager/.env.example .env
# Then edit with your API keys.
```

Or set the environment directly:

```bash
export OPENAI_API_KEY="sk-..."
# or
export ANTHROPIC_API_KEY="sk-ant-..."
# or Azure OpenAI
export LLM_PROVIDER=azure
export AZURE_OPENAI_ENDPOINT="https://<your-resource>.openai.azure.com"
export AZURE_OPENAI_API_KEY="<your-key>"
export AZURE_OPENAI_DEPLOYMENT="gpt-4o-mini"
export AZURE_OPENAI_API_VERSION="2024-12-01-preview"
```

---

## 4. Integrate with your framework

If your agent is built on a supported framework, the adapter is the shortest path to a guarded agent. The Python adapters compose a framework-agnostic `Shield` orchestrator with one capability bundle per framework. The entry point lives on the `Shield` class (imported from `agent_shield`, not from the adapter module); each adapter module is **side-effect imported** so it can install its `with_<framework>()` builder hook and `create_<framework>_agent()` factory onto `Shield`.

Every adapter exposes three integration levels:

- **Level 1 — functions** (`make_llm_caller`, `protect_tools` exported from the adapter module) operate directly on a `RuntimeBuilder` from `agent_shield`. Full control, more glue.
- **Level 2 — `Shield` helper** (recommended). Build the shield, then manually compose `shield.protect_tools(...)` + `shield.guard(framework_agent)`.
- **Level 3 — two-liner**. The adapter installs `shield.create_<framework>_agent(...)` which does protect-tools + guard-agent in one call.

### Supported frameworks

| Framework | Side-effect import | Builder hook | One-shot factory |
|---|---|---|---|
| **LangChain** | `import agent_shield.adapters.langchain` | `.with_langchain()` | `shield.create_langchain_agent(llm, tools, system_prompt=...)` |
| **OpenAI Agents SDK** | `import agent_shield.adapters.openai_agents` | `.with_openai_agents()` | `shield.create_openai_agents_agent(tools, system_prompt=...)` |
| **Anthropic Agents SDK** | `import agent_shield.adapters.anthropic_agents` | `.with_anthropic_agents()` | `shield.create_anthropic_agents_agent(tools, system_prompt=...)` |
| **AutoGen** | `import agent_shield.adapters.autogen` | `.with_autogen()` | `shield.create_autogen_agent(model_client, tools, system_message=...)` |
| **CrewAI** | `import agent_shield.adapters.crewai` | `.with_crewai()` | `shield.create_crewai_agent(...)` |
| **Semantic Kernel** | `import agent_shield.adapters.semantic_kernel` | `.with_semantic_kernel()` | `shield.create_semantic_kernel_agent(...)` |

### Example: LangChain (Level 3, the two-liner)

```python
from agent_shield import Shield
import agent_shield.adapters.langchain  # side-effect import: installs .with_langchain() and .create_langchain_agent()

shield = (
    Shield.from_yaml("my-agent.guardrails.yaml")
    .with_langchain()
    .with_client(my_llm)
    .build()
)
agent = shield.create_langchain_agent(
    my_llm,
    tools,
    system_prompt="You are a helpful assistant.",
)
# All five stages active; the runtime applies the YAML contract automatically.
```

### Example: LangChain (Level 2, manual compose)

```python
from agent_shield import Shield
import agent_shield.adapters.langchain  # side-effect import
from langchain.agents import create_agent  # this is LangChain's factory, not Shield's

shield = (
    Shield.from_yaml("my-agent.guardrails.yaml")
    .with_langchain()
    .with_client(my_llm)
    .build()
)
protected_tools = shield.protect_tools(raw_tools)         # Stages 2 + 3 + 4
guarded_agent   = shield.guard(create_agent(my_llm, protected_tools))  # Stages 1 + 5
```

### Example: LangChain (Level 1, no `Shield`)

```python
from agent_shield import RuntimeBuilder
from agent_shield.adapters.langchain import make_llm_caller, protect_tools

runtime = (
    RuntimeBuilder.from_yaml("my-agent.guardrails.yaml")
    .register_llm_caller(make_llm_caller(my_llm))
    .build()
)
protected = protect_tools(runtime, raw_tools)
# You manage sessions, begin_turn / end_turn, validate_input, validate_output yourself.
```

The `ShieldBuilder` surface is small: `with_<framework>()`, `with_client(llm)`, `with_agent_resolver(...)`, `with_observability(provider)`, `with_on_block(policy)`, `with_mode(monitor|enforce)`, `with_streaming(**kwargs)`, `with_extension(name, value)`, `build()`. There is no `.with_llm()` — the framework-aware LLM is passed via `.with_client(...)`.

---

## 5. Gateway / proxy deployment

If you run agents behind a centralised LLM gateway, the same `.guardrails.yaml` can be enforced at the proxy boundary — zero changes to client agents, and one chokepoint for every agent in the fleet.

### LiteLLM Proxy

Agent Shield ships a drop-in guardrail plugin for [LiteLLM Proxy](https://docs.litellm.ai/docs/simple_proxy), the OpenAI-compatible gateway many teams already run for centralised LLM access.

```bash
pip install agent-shield[litellm-proxy]
```

Register the guardrail in `litellm_config.yaml`:

```yaml
guardrails:
  - guardrail_name: agent_shield
    litellm_params:
      guardrail: agent_shield_guardrail.AgentShieldLiteLLMGuardrail
      mode: ["pre_call", "post_call"]
      guardrails_path: /etc/agent-shield/guardrails.yaml
      default_on: true
```

Full setup — shim file, stage map, threat model, session correlation, streaming behaviour — is documented in [docs/integrations/litellm-proxy.md](docs/integrations/litellm-proxy.md).

### Istio + SDK reference

For Kubernetes deployments, the [Istio + SDK reference architecture](docs/istio-sdk-reference-architecture.md) pairs the in-process SDK with Istio for mesh-level mTLS, identity propagation, and OTel telemetry. Sample manifests and ConfigMap layouts live in [`deploy/kubernetes/istio-sdk-reference/`](deploy/kubernetes/istio-sdk-reference/).

---

## 6. Direct SDK integration

If you've built your agent loop yourself, or you're on a framework Agent Shield doesn't yet have an adapter for, you can call the runtime API directly. You manage sessions, `begin_turn` / `end_turn`, and the per-stage `validate_*` calls; the runtime handles the rest.

Every snippet below loads the **smoke fixture** [`tests/fixtures/smoke/minimal.guardrails.yaml`](tests/fixtures/smoke/minimal.guardrails.yaml):

```yaml
metadata:
  name: "smoke-minimal"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal:
    - "Demonstrate the smallest valid guardrails file."
resources:
  tools:
    - { name: "echo", description: "Echoes a message back.", permission: "read_only" }
variables:
  - { name: "authorized", type: "boolean", default: false }
state_validation:
  guard_policies:
    - name: "echo_only_when_authorized"
      applies_to: { tools: ["echo"] }
      evaluate_when:
        - expression: "authorized == true"
          reason: "Echo requires prior authorization."
      action: "block"
```

The `echo` tool is blocked at Stage 2 unless the `authorized` variable is `true`. Each snippet flips it through the host API; in production a `HumanResolver` (or a tool/event hook) would do the same.

### 6.1 Python

```python
# Quickstart Python example.
from agent_shield import RuntimeBuilder

runtime = (
    RuntimeBuilder
    .from_yaml("tests/fixtures/smoke/minimal.guardrails.yaml")
    .build()
)

with runtime.new_session(session_id="s-1", correlation_id="c-1") as session:
    session.begin_turn()

    input_v = session.validate_input("hello, please echo me")
    print("Stage 1 allowed =", bool(input_v))

    # Without the variable set, Stage 2 should block.
    blocked = session.validate_tool_call("echo", {"msg": "hi"})
    print("Stage 2 (unauthorized) allowed =", bool(blocked),
          "reason:", blocked.verdict.reason)

    # Authorize and re-try.
    session.set_variable("authorized", True)
    allowed = session.validate_tool_call("echo", {"msg": "hi"})
    print("Stage 2 (authorized) allowed =", bool(allowed))

    out = session.validate_output("echoed: hi")
    print("Stage 5 allowed =", bool(out), "response =", out.response)
```

### 6.2 Node.js / TypeScript

```ts
// Quickstart TypeScript example.
import { RuntimeBuilder } from "@microsoft/agent-shield";

async function main(): Promise<void> {
  const runtime = RuntimeBuilder
    .fromYaml("tests/fixtures/smoke/minimal.guardrails.yaml")
    .build();

  const session = runtime.newSession({
    sessionId: "s-1",
    correlationId: "c-1",
  });
  session.beginTurn();

  const inputV = await session.validateInput("hello, please echo me");
  console.log("Stage 1 allowed =", inputV.allowed);

  // Without the variable set, Stage 2 should block.
  const blocked = await session.validateToolCall("echo", { msg: "hi" });
  console.log(
    "Stage 2 (unauthorized) allowed =", blocked.verdict.allowed,
    "reason:", blocked.verdict.reason,
  );

  // Authorize and re-try.
  session.setVariable("authorized", true);
  const allowed = await session.validateToolCall("echo", { msg: "hi" });
  console.log("Stage 2 (authorized) allowed =", allowed.verdict.allowed);

  const out = await session.validateOutput("echoed: hi");
  console.log(
    "Stage 5 allowed =", out.verdict.allowed,
    "response =", out.response,
  );

  session.endTurn();
}

main().catch((err) => { console.error(err); process.exit(1); });
```

### 6.3 .NET

```csharp
// Quickstart .NET example.
using System.Text.Json;
using AgentShield;

using var runtime = RuntimeBuilder
    .FromYaml("tests/fixtures/smoke/minimal.guardrails.yaml")
    .Build();

// RequestContext is a record with field order
//   (UserId, TenantId, SessionId, CorrelationId, Extensions)
// — use named arguments so SessionId / CorrelationId aren't silently
// assigned to UserId / TenantId.
using var session = runtime.NewSession(
    new RequestContext(SessionId: "session-1", CorrelationId: "corr-1"));
session.BeginTurn();

var inputV = session.ValidateInput("hello, please echo me");
Console.WriteLine($"Stage 1 allowed = {inputV.Allowed}");

// Without the variable set, Stage 2 should block.
var paramsJson = JsonDocument.Parse("""{"msg":"hi"}""").RootElement;
var (blocked, _) = session.ValidateToolCall("echo", paramsJson);
Console.WriteLine($"Stage 2 (unauthorized) allowed = {blocked.Allowed} reason: {blocked.Reason}");

// Authorize and re-try.
session.SetVariable("authorized", JsonDocument.Parse("true").RootElement);
var (allowed, _) = session.ValidateToolCall("echo", paramsJson);
Console.WriteLine($"Stage 2 (authorized) allowed = {allowed.Allowed}");

var (outV, response) = session.ValidateOutput("echoed: hi");
Console.WriteLine($"Stage 5 allowed = {outV.Allowed}, response = {response}");
session.EndTurn();
```

### 6.4 Rust

> Add `agent_shield_core` (via a `git = "..." , tag = "v<version>"` dependency — see §2) and `serde_json = "1"` to your `Cargo.toml`. The validate / set_variable / begin_turn / end_turn methods are synchronous — no async runtime required.

```rust
// Quickstart Rust example.
use std::error::Error;

use agent_shield_core::{RequestContext, RuntimeBuilder};

fn main() -> Result<(), Box<dyn Error>> {
    let runtime = RuntimeBuilder::from_yaml(
        "tests/fixtures/smoke/minimal.guardrails.yaml",
    )?
    .build()?;

    let ctx = RequestContext::new("session-1", "corr-1");
    let session = runtime.new_session(ctx);

    session.begin_turn()?;

    let v1 = session.validate_input("hello, please echo me");
    println!("Stage 1 allowed = {}", v1.allowed);

    // Without the variable set, Stage 2 should block the tool call.
    let mut params = serde_json::json!({ "msg": "hi" });
    let v_tool = session.validate_tool_call("echo", &mut params);
    println!("Stage 2 (unauthorized) allowed = {}", v_tool.allowed);

    // Authorize, then re-validate.
    session.set_variable("authorized", serde_json::json!(true))?;
    let v3 = session.validate_tool_call("echo", &mut params);
    println!("Stage 2 (authorized) allowed = {}", v3.allowed);

    let mut response = String::from("echoed: hi");
    let v4 = session.validate_output(&mut response);
    println!("Stage 5 allowed = {}", v4.allowed);

    session.end_turn()?;
    Ok(())
}
```

---

## 7. Write your first `.guardrails.yaml`

> **Shortcut:** run `agent-shield init` to have an LLM design a
> working policy for your specific agent from your existing tool
> definitions — see
> [docs/getting-started/init.md](docs/getting-started/init.md).

A realistic example for a document agent:

```yaml
metadata:
  name: "my-first-agent"
  version: "1.0.0"
  agent_shield_version: "2.0"

objective:
  goal:
    - "Help users find documents while enforcing DLP policies."
  forbidden:
    - "Email confidential data externally."
    - "Bypass sensitivity controls."

variables:
  - name: data_sensitivity
    type: string
    update_policy: max
    ordering: ["public", "internal", "confidential", "restricted"]
    default: "public"
    populated_by:
      - kind: tool
        name: read_document
        phase: after_execute

  - name: send_email_authorized
    type: boolean
    update_policy: replace
    on_demand_by:
      kind: human
      message: "Approve outbound email."
    lifetime: per_call

resources:
  tools:
    - { name: read_document, description: "Read a document from store" }
    - { name: send_email,    description: "Send an email" }

state_validation:
  guard_policies:
    - name: block_outbound_when_restricted
      applies_to:
        tools: [send_email]
      active_if: "data_sensitivity == 'restricted'"
      action: block
      reason: "Restricted data may not be emailed."

    - name: send_email_requires_approval
      applies_to:
        tools: [send_email]
      evaluate_when:
        - expression: "send_email_authorized == true"
          reason: "Outbound email requires manager approval."
      action: block

input_validation:
  guard_policies:
    - name: jailbreak_pattern
      detect:
        kind: pattern
        patterns:
          - "ignore.*(?:previous|all).*(?:instructions|rules)"
      action: block
      reason: "Likely prompt injection."

output_validation:
  guard_policies:
    - name: ssn_redact
      detect:
        kind: pattern
        patterns: ["\\b\\d{3}-\\d{2}-\\d{4}\\b"]
      action: redact
      replacement: "[SSN REDACTED]"
```

What this gives you:
- **Ratcheted sensitivity** — once the agent reads a `restricted` document, `data_sensitivity` ratchets up via `update_policy: max` and stays there for the session.
- **State-stage block** — `block_outbound_when_restricted` fires before the tool runs.
- **Human-resolver approval** — `send_email_authorized` is `unset` by default; the gate triggers the `HumanResolver` you registered with the runtime, which returns `{decision: "allow", value: true}` if approved.
- **Stage-1 jailbreak screen** — pattern guards run on every input.
- **Stage-5 SSN redaction** — output is rewritten before reaching the user.

---

## 8. Run the demos

```bash
# From the repo root
pip install -r examples/agents/bank-manager/requirements.txt

# 1. Create your .env from the template
cp examples/agents/bank-manager/.env.example .env
# Edit with at least one LLM provider key.

# 2. Run the headline demo
python examples/agents/bank-manager/demo.py --scenarios all

# Same demo, different framework
python examples/agents/bank-manager/demo.py --framework anthropic --scenarios all
```

Set `AGENT_SHIELD_LOG_LEVEL=INFO` in `.env` to see which stages fire on each request. Detailed scenario tables and talking points live in each demo's README.

| Demo | What it shows | README |
|---|---|---|
| **Bank Manager** | All 5 stages — VIP transfer approvals, social engineering, prompt injection in tool memos, account enumeration, composable YAML tiers | [README](examples/agents/bank-manager/README.md) |
| **Document DLP** | Sensitivity ratchets, jurisdiction tracking, graduated email policy, output PII redaction | [README](examples/agents/document-dlp/README.md) |

---

## Next steps

- **Read the [Specification](spec/SPECIFICATION.md)** — normative reference for every YAML field and runtime behavior.
- **Read the [Expression Language reference](spec/expressions/LANGUAGE.md)** — the predicate language used in `evaluate_when:`, `allowed_when:`, `active_if:`.
- **Validate against the [JSON Schema](spec/schema/guardrails.schema.json)** — catches misspellings.
- **Browse [shared LLM prompts](examples/prompts/)** — reusable detector templates for jailbreak, PII, social-engineering, and task-adherence checks.
- **Browse [reference policies](examples/policies/)** — IFC, endpoint governance, channel governance, classifier wirings.
