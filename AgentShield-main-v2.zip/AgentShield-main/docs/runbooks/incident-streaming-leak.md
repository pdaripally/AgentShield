# Incident runbook: streaming leak or mid-stream abort

## Trigger

Use this runbook when streamed content appears to leak sensitive material, or when `incident.stream_aborted` / `incident.stream_limit_exceeded` events spike.

## Immediate actions

1. Stop or drain streaming traffic for the affected route.
2. Preserve request IDs, session IDs, and event samples.
3. Determine whether any partial output already reached end users.
4. Page the on-call owner for the affected adapter/framework path.

## Evidence to collect

- The exact streaming route, adapter, and framework version.
- Whether the incident emitted `incident.stream_aborted` or `incident.stream_limit_exceeded`.
- The policy name or limit name associated with the denial.
- Whether the host buffered chunks or released them directly to clients.

## Containment

- Temporarily force buffered/non-streaming responses if the product can tolerate it.
- Disable the affected streaming feature flag or endpoint until the boundary is understood.
- If only one adapter path is implicated, route traffic to a known-mediated path documented in `docs/adapter-mediated-paths.md`.

## Root-cause checklist

- Did a chunk escape before Stage 5 denied the stream?
- Did the host release chunks before the guarded boundary completed validation?
- Did a new upstream truncation or gateway cap change the stream length behavior?
- Did the deployment move onto a runtime that lacks the expected §18.4 safeguards?

## Remediation

- Fix the adapter/buffering path before re-enabling streaming.
- Add or update the relevant conformance case for the observed failure mode.
- Review whether user-visible content must be deleted or customers notified under local policy.

## Exit criteria

- The affected streaming path is either disabled or demonstrably mediated.
- New events confirm the incident is no longer recurring.
- A follow-up item exists for any missing conformance or adapter coverage.
