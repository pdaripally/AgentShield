# IFC Design Rationale

**Audience.** Principal architects and security researchers evaluating the
information-flow-control (IFC) primitives in `spec/SPECIFICATION.md`
(§7, §9, §10, §11, §12) and `spec/expressions/LANGUAGE.md`.

**Premise.** Every option we considered had tradeoffs. This document does
not claim the chosen design is optimal in the abstract; it claims it is the
right cut given the constraints of the project — _security product, no
runtime-discoverable footguns, expression language is the only semantics,
existing `variables[]` / `guard_policies[]` machinery is the asset to reuse_.

Read this top-down. Each design choice is presented with: the alternative
considered, the tradeoff, the principle that decided it, and a small
example that makes the consequence concrete. The progressive examples at
the end show what the spec now expresses end-to-end.

---

## Contents

1. [TL;DR — the path we took](#1-tldr--the-path-we-took)
2. [Invariants (the things we will not give up)](#2-invariants-the-things-we-will-not-give-up)
3. [Why variables, not a dedicated `ifc:` block](#3-why-variables-not-a-dedicated-ifc-block)
4. [Why labels are not a `labels:` top-level — they are a variable subtype](#4-why-labels-are-not-a-labels-top-level--they-are-a-variable-subtype)
5. [Why `type: level` and `type: compartment` exist as distinct types](#5-why-type-level-and-type-compartment-exist-as-distinct-types)
6. [Why we rejected putting IFC labels on tool resources](#6-why-we-rejected-putting-ifc-labels-on-tool-resources)
7. [Static `value:` vs dynamic `expression:` vs delegated classification](#7-static-value-vs-dynamic-expression-vs-delegated-classification)
8. [Why resolvers are banned from label variables](#8-why-resolvers-are-banned-from-label-variables)
9. [Why monotonicity is enforced by the type, not by an `update:` expression](#9-why-monotonicity-is-enforced-by-the-type-not-by-an-update-expression)
10. [Sugar decisions, principle-by-principle](#10-sugar-decisions-principle-by-principle)
11. [Null-as-top, vocabulary enforcement, and the fail-closed chain](#11-null-as-top-vocabulary-enforcement-and-the-fail-closed-chain)
12. [Declassification — `reset_by:` + `variable.<name>.declassified`](#12-declassification--reset_by--variablenamedeclassified)
13. [Cross-tier composability — Option A (strict no-redefinition)](#13-cross-tier-composability--option-a-strict-no-redefinition)
14. [Selector grammar — the cleanup of `*` and "fallback-only" wildcards](#14-selector-grammar--the-cleanup-of--and-fallback-only-wildcards)
15. [Stage ordering — what we kept honest about](#15-stage-ordering--what-we-kept-honest-about)
16. [Risks that remain (and why they remain)](#16-risks-that-remain-and-why-they-remain)
17. [Progressive examples](#17-progressive-examples)
18. [Deferred / open work](#18-deferred--open-work)
19. [Appendix — restriction matrix](#19-appendix--restriction-matrix)

---

## 1. TL;DR — the path we took

We started with a question: _can the existing spec primitives express IFC,
or do we need a dedicated `ifc:` block?_ The spec had `type: enum`,
`update: max(...)`, `populated_by[]`, `guard_policies[]`, and an expression
language with `<=` / `in` / `all(...)`. The technical answer was **yes,
but operationally fragile** — every silent fail-open in IFC came from
authors forgetting to write `update: "max(...)"`, forgetting to add a
populator for a new tool, or accidentally putting `reset_by:` on a label.

We considered three paths to fix it:

1. **Dedicated `ifc:` block.** Make IFC its own surface, hide the
   variable machinery underneath. Smallest expressive cost; biggest
   conceptual cost (parallel mental model; new merge rules; new audit
   wiring; bifurcation between IFC variables and non-IFC variables).
2. **Tool-level annotations (`produces:` / `requires:` on resources).**
   Locality wins; the IFC graph moves to where the author already looks
   when adding a tool. But: every richer case (cross-tool reuse,
   `allowed_when:` bypasses, argument-conditional sinks, dynamic
   classification, declassification) forces the author to drop back to
   `guard_policies[]` — and now the IFC story for one tool lives in two
   places.
3. **Two new variable types (`level`, `compartment`) that lock the
   safety invariants into the schema itself, plus a unified selector
   grammar across `populated_by[]` / `reset_by[]` / `applies_to[]`.** No
   new top-level construct, no parallel surface, no bifurcation.
   Every existing audit event, every existing expression rule, every
   existing composition rule continues to apply.

We picked path 3. Path 1 is what the spec started with; we removed the
`ifc:` block entirely and the proof was reframed against the variable
surface. Path 2 was rejected because it scattered the IFC contract and
re-introduced the very bifurcation we were trying to eliminate.

The minimum surface that this required is:

- `type: level` and `type: compartment` — two new entries in the `type:`
  enum, with the schema enforcing the safety invariants by what fields
  it **does not** admit on those types.
- The `<=` operator overloaded on arrays as subset (LANGUAGE.md §3.7),
  plus named `subset(a, b)` / `superset(a, b)` built-ins (§5.3).
- `value:` shorthand on populator / resetter entries (literal-only,
  type-checked at load time).
- `reason:` field on `reset_by[]` entries (carried into the audit event).
- Four new closed-namespace events: `variable.<name>.declassified`,
  `variable.<name>.populator_null`, `variable.<name>.vocabulary_violation`,
  and `guard_policy.<name>.redacted`.
- A unified `name:` selector grammar at the three call sites that take
  resource lists.

That is the whole surface. Everything else IFC needs is already in the
spec.

---

## 2. Invariants (the things we will not give up)

These are the principles that decided every other question. They are
listed in priority order. When a tradeoff was unclear, the higher-numbered
invariant lost.

1. **The expression language is the only semantics carrier.** YAML keys
   are at most _literal-only_ shortcuts for fixed expression forms.
   `value: confidential` is sugar for `expression: "'confidential'"`.
   `requires_max:` / `admits:` / `produces:` are not sugar for anything
   — they would hide a comparison and a join behind a key name, which
   means a reader cannot determine the policy by reading the file.
2. **Fail-closed by construction, not by discipline.** The shape of the
   YAML must make the wrong configuration unrepresentable. Anything that
   requires the author to "remember to" write something safe is wrong by
   default. Concretely: missing populator returns `null` ⇒ lattice top;
   missing tool from the selector ⇒ the wildcard fallback assigns the
   most restrictive label; missing `update:` ⇒ type-locked join (not a
   permissive default).
3. **One mental model.** A label variable is just a variable. The
   loader, audit pipeline, lifetime engine, event bus, and expression
   evaluator already know how to handle variables. We do not introduce
   a parallel system that duplicates any of these.
4. **Single source of truth for any decision.** The lattice lives on the
   variable. The sink admittance lives in `guard_policies[]`. The
   resource list is just a list — no rules. If a reviewer wants to know
   what `data_sensitivity` admits at `send_external_email`, they read
   exactly one guard policy.
5. **Composability is additive-only.** Child `extends:` tiers can add
   protections; they cannot weaken them. This applies to every list-
   typed field in the spec, including selectors.
6. **Cross-tool patterns must be expressible without enumeration.**
   "Every PII-tagged tool" should not require typing every PII-tagged
   tool's name into every guard policy. The selector grammar (§14)
   discharges this.
7. **No prematurely-clever defaults.** When a default behavior could
   reasonably be "do nothing" or "do the safest thing," pick the safest
   thing. The cost is verbosity for the deliberately-permissive case;
   the benefit is no silent fail-open.

---

## 3. Why variables, not a dedicated `ifc:` block

The spec inherited an `ifc:` block with tag-set semantics and a formal
noninterference proof. Walking through it surfaced three problems:

1. **Bifurcation.** Authors had two label-shaped things: the `ifc:`
   block's tags (with their own composability rules, their own audit
   events, their own merge story) and the existing `variables[]`
   primitives. A policy that mixed IFC concerns with non-IFC state (an
   admin bypass on egress, a delegated approval for declassification)
   had to be expressed across both surfaces.
2. **Composability cost.** `extends:` was harder for IFC because the
   `ifc:` block needed its own merge rule. The proof's TC-1 (the
   trusted base never re-binds the labeling function) was carried by
   "single-declaration" rules specific to `ifc:`. Variables already
   have a strict no-redefinition rule (§10.9); reusing it discharges
   TC-1 for free.
3. **Authoring surface cost.** Two ways to express "this variable
   represents accumulated session sensitivity" with subtly different
   semantics for resolvers, lifetimes, and audit. Code review has to
   keep both surfaces in their heads.

**The move.** We deleted the `ifc:` block. We added two variable
subtypes (`level`, `compartment`). We re-derived every IFC property
the proof required against those subtypes. The math is unchanged; the
realisation surface is one, not two.

**What this gives up.** The dedicated block had a tight, IFC-specific
audit shape (every event was clearly an IFC event). The variable
surface gives you `variable.<name>.declassified` /
`variable.<name>.populator_null` /
`variable.<name>.vocabulary_violation` — distinguishable from generic
`variable.<name>.changed` and `.set`, but you have to know that a given
variable is the IFC carrier to interpret the event. We accept this; it
is paid back many times over by not having to maintain a parallel
audit pipeline.

**Small example.** The same policy expresses both IFC and a non-IFC
admin bypass, in one block, with one mental model:

```yaml
variables:
  - name: data_sensitivity
    type: level
    members: [public, internal, confidential, restricted]
    default: public
    populated_by:
      - { kind: tool, name: read_user_diary, value: confidential }

  - name: operator_override
    type: boolean
    default: false
    on_demand_by:
      kind: human
      prompt: "Allow egress despite elevated sensitivity?"

state_validation:
  guard_policies:
    - name: external_egress
      applies_to: { tools: { include: ["send_external_*"] } }
      evaluate_when:
        - expression: "data_sensitivity <= 'internal' or operator_override"
          reason: "External egress requires <= internal sensitivity or operator override."
```

No special-case handling for the IFC variable in the gating logic. The
same expression language reads from both.

---

## 4. Why labels are not a `labels:` top-level — they are a variable subtype

We considered a parallel top-level `labels:` block. The arguments for
it were "labels are a different concept" and "you can lock the schema
more tightly when it's not a variable." Both arguments collapsed on
inspection.

| Property | `labels:` top-level | `type: level` / `compartment` variable subtype |
|---|---|---|
| Where to look up "what is this name" | Two places (`variables:`, `labels:`) | One (`variables:`) |
| Reuses populator / lifetime / envelope machinery | Yes, but must restate scope | Native — no spec text needed |
| Reads via bare identifier in expressions | Same | Same |
| `extends:` composability story | Needs its own merge rule | Inherits §10.9 |
| Conceptual cost | A new top-level construct | One new value in `type:` |

The deciding principle is **invariant 3 (one mental model)**. A separate
top-level is two lookup sites for the same kind of name binding. The
subtype is one. Authors who already know variables know labels.

---

## 5. Why `type: level` and `type: compartment` exist as distinct types

The honest forcing question from review was: _why not just `type: enum` +
`update: "max(@current, @incoming)"`?_ That works. The answer is that
the new type bundles four properties — only the first of which is the
join.

1. **Type-locked join (the forcing function).** `update:` is forbidden
   on `level` / `compartment`. The schema does not admit the field at
   all. An author cannot write `update: "min(...)"`, cannot write
   `update: "@incoming"`, cannot regress in a typo. The join is the
   spec.
2. **Resolver writes forbidden.** `on_demand_by:` is forbidden; resolver
   `set_variables:` writes to a label-typed variable are a load-time
   error (§11.5). This is not a soundness requirement (the proof's TC-1
   holds either way because resolvers are themselves config-merge-bound)
   — it is a defense-in-depth choice. The footgun is real and worth
   eliminating; see §8 for the reasoning.
3. **Null-as-top.** A populator whose `expression:` evaluates to `null`
   on a label-typed variable escalates to the lattice top, with a
   `variable.<name>.populator_null` (warn) audit event. On a regular
   variable, null is a no-op. This is the only point in the spec where
   the same primitive (`populated_by[].expression:`) has different
   semantics based on the receiving variable's type. It is the difference
   between fail-open and fail-closed.
4. **Label-specific audit events.** `variable.<name>.declassified`
   (critical) fires when a label is reset; ordinary variables get
   `.changed` / `.set`. SOC pipelines want the IFC-specific event;
   muxing them through the generic `.changed` would either drown the
   pipeline or hide the signal.

You cannot retrofit any of these onto `type: enum` without a discriminator.
At which point you've reinvented the type — and made it a flag, not a
schema property. **Invariant 2 (fail-closed by construction)** rules
out the flag-shaped version because the type-locked join no longer
falls out of the schema; the loader has to remember to enforce it on
the flagged subset.

**Small example — the regression a type-locked join prevents.**

```yaml
# What the author meant to write.
- name: data_sensitivity
  type: enum
  members: [public, internal, confidential, restricted]
  default: public
  update: "max(@current, @incoming)"

# What a code-review-grade typo can produce.
- name: data_sensitivity
  type: enum
  members: [public, internal, confidential, restricted]
  default: public
  update: "@incoming"          # last-write-wins; any 'public' write downgrades the label
```

Both load. Both run. The second silently rolls back IFC accumulation.
With `type: level`, `update:` is not in the schema. The second YAML is a
load-time error.

---

## 6. Why we rejected putting IFC labels on tool resources

The alternative was to put `ifc.produces:` / `ifc.requires:` on every
tool resource:

```yaml
resources:
  tools:
    - name: read_user_diary
      ifc:
        data_sensitivity: { produces: confidential }
    - name: send_external_email
      ifc:
        data_sensitivity: { requires_max: public }
```

The locality argument is real: a reviewer adding `get_credit_report`
reads one tool entry and sees its IFC role. We rejected this for three
overlapping reasons.

**a. It encodes semantics in a YAML key (violates invariant 1).** The
key `requires_max: public` means "synthesize a guard policy with
`evaluate_when: [{ expression: \"data_sensitivity <= 'public'\" }]`."
That comparison and synthesis is invisible from the file. The
expression language is the carrier of semantics; if a key has a
comparison in it, the comparison should be the expression.

**b. The simple case ends fast.** Cross-tool reuse (`applies_to:
[a, b, c]`), `allowed_when:` admin bypasses, argument-conditional sinks
(`@tool.params.recipient.is_external`), action customization
(`action: { kind: redact_response, ... }`), `active_if:` predicates,
and non-default stages — all of these force the author to drop back to
`guard_policies[]`. Now the IFC story for one tool lives in two places.
The reviewer cannot read the tool entry and know the policy; the
reviewer cannot read the guard policy and know the tool's IFC role.
Splitting is worse than centralizing.

**c. The composability gap.** `produces:` / `requires:` on a tool would
be additive across `extends:` because resources are additive. That
sounds nice. But a child tier can then silently raise (or lower!) the
label of a tool the parent tier classified. The "lattice owner is the
top tier" property (§13) breaks because every tier owns its own tool
entries.

**Honest framing on author burden.** The decorator design and the
variable surface impose comparable per-catalog author obligations.
Neither is zero-burden: any IFC scheme that gates per-resource has to
know which resources are gated, and that knowledge has to be authored
somewhere. The decorator design distributes the obligation across
resource entries (one `ifc:` block per relevant tool); the variable
surface plus the §12 coverage check centralizes the obligation in
`guard_policies[]` (any policy whose `applies_to:` union covers the
catalog satisfies it — one `tools: "*"` policy is enough for the
universal case, N per-sink policies for per-sink clearance).
Per-resource decoration is not lighter author work — it is
differently-shaped author work. The decorator design was rejected
on the three structural grounds above (semantics-in-keys, two-places
for non-trivial tools, lattice-ownership break under `extends:`) plus
a fourth point that surfaces only when the defaults question is
forced: the decorator design has no clean answer for "what does a
missing `ifc:` block mean." Silent-permissive (`produces: ⊥`,
`requires_max: ⊤`) reintroduces TC-7 at a different YAML site;
silent-restrictive (`produces: ⊤`, `requires_max: ⊥`) makes the agent
unable to do anything until every tool is decorated; rejecting load
on any undecorated tool is the same kind of enforcement check as the
variable-surface coverage check, just expressed per-tool rather than
per-coverage. The variable surface plus a single coverage check has
one structural answer to the defaults question (uncovered resource
⇒ load error) and lets one policy discharge the obligation for the
whole catalog in the simple case.

**The compromise we kept open.** A one-line `labels: [data_sensitivity]`
on the tool resource is on the table (deferred per the conversation).
It is _not_ a rule site; it is a cross-reference, useful only for the
load-time check that catches "this tool is wired into a label variable's
populators / resetters / guards" out-of-sync with "this tool is marked
as participating in this label." This stays orthogonal to the IFC
semantics and does not violate invariant 1.

---

## 7. Static `value:` vs dynamic `expression:` vs delegated classification

The conversation repeatedly returned to: _can authors mix static
assignments, dynamic `@result`-based labels, and delegated
classification (call MCP1; have MCP2 classify; populate from MCP2)?_

Yes. All three are populator entries; they only differ in how the value
is computed.

### Static `value:` — literal, type-checked at load

```yaml
populated_by:
  - kind: tool
    name: read_customer_balance
    value: [pii, financial]              # equivalent to expression: "['pii', 'financial']"
```

`value:` is mutually exclusive with `expression:`. Every element of an
array `value:` is checked against the variable's `vocabulary:` at load
time — typos there are a load-time error.

### Dynamic `expression:` — value flows from `@result`

```yaml
populated_by:
  - kind: tool
    name: read_document
    expression: "@result.sensitivity_tags"
```

The post-tool envelope is the only place `@result.*` is bound. Stage
4 redaction does _not_ flow back into the label (this is the residual
limitation — see §15). When the expression returns `null`, the lattice
top is written. That single rule absorbs every "the field was missing
from the result" footgun.

### Delegated classification — MCP1 reads, MCP2 classifies

This is the case that confused the conversation most. The answer is:
**there is no special "delegation" mechanism**. The agent's workflow
calls MCP2; MCP2 has its own populator entry; that populator extracts
the classification from MCP2's `@result`. Every call to MCP2 raises
the running label monotonically.

```yaml
populated_by:
  - kind: tool
    name: mcp1.read_document
    value: [internal]                    # conservative pre-classification
  - kind: tool
    name: mcp2.classify_document
    expression: "@result.tags"           # MCP2's classification
```

If the workflow only sometimes calls MCP2, the type-locked union join
keeps MCP1's `[internal]` write monotone — the running label is still
at least `[internal]`. Fail-closed by construction (invariant 2).

### Conditional from `@result`

The ternary is part of the expression language (LANGUAGE.md §2.5).

```yaml
expression: "@result.is_personal ? ['pii'] : []"
```

If `@result.is_personal` is missing, the whole expression returns `null`,
and the null-escalation rule writes the lattice top. Fail-closed.

### Why we did not collapse these into one

The temptation was to provide a shorthand like `from_result:` that
unwraps the expression. We rejected it: invariant 1. There is exactly
one shorthand for `expression:` and it is `value:`, restricted to
literals. Every other dynamic decision is a real expression, parsed by
the real parser, audited as the real expression.

---

## 8. Why resolvers are banned from label variables

This was the most-debated decision in the second conversation. The
honest framing took two passes to get right.

### First framing (rejected on review)

"Resolvers let the agent influence labeling, which violates TC-1 of the
proof."

This is **wrong**. A resolver definition is itself bound at config-merge
time. The labeling function `λ` is still bound at config-merge whether
the variable is populated by a populator or by a resolver. The agent's
"choice of which tools to invoke" already exists under the populator
surface; it is not a new attack the resolver surface introduces.

### Second framing (correct)

Resolvers and populators answer different questions:

| | `populated_by:` | `on_demand_by:` (resolver) |
|---|---|---|
| Question answered | _What flowed?_ | _Is this allowed?_ |
| Cardinality | Fires on every matching tool call; accumulates | Fires once on `unset → resolved`; one-shot |
| Write semantic on label types | Type-locked join (monotone) | `set_variables:` — last-write-wins |
| Re-firing on later calls | Yes — every call composes | No — cached for the lifetime |
| Null result | Lattice top (§10.5.4) | Regular null value |
| Default lifetime | Variable's `lifetime:` | Resolver's `lifetime.allow:` |
| Audit event | `variable.<name>.set` | `variable.<name>.resolved` |

A label is the **monotone accumulation** of exposure. A resolver is a
**one-shot authorization decision**. The two are conceptually distinct.
Allowing both surfaces on the same variable means an author can write
something that _looks_ like IFC and is actually authorization, or vice
versa.

The footgun the prohibition closes:

```yaml
# What an author writes — and what they think it means.
variables:
  - name: data_sensitivity
    type: level
    members: [public, internal, confidential, restricted]
    default: public
    on_demand_by:
      kind: human
      prompt: "What sensitivity does this document contain?"
```

This _reads_ as "ask the user to classify the document." It actually
means: the running session label is set to whatever the user says, once,
the first time a guard reads `data_sensitivity`. The user can lower the
exposure label by clicking the wrong option in a UI — the IFC system
now records their belief, not what flowed. Worse: with `default: public`
the variable is already `resolved` at session start, so the resolver
**never fires**. The author thinks IFC is wired; nothing is wired.

`§11.5` therefore makes this combination a load-time error. The author
who wants user-mediated declassification writes a separate non-label
variable (`type: boolean`, `kind: human` resolver) and consumes it in a
`reset_by[]` on the label. The two concerns stay separate; the audit
trail records both decisions distinctly.

**Why this is defense-in-depth, not a soundness requirement.** A
hypothetical relaxation that allowed resolver writes through the
type-locked join would also be sound (TC-1 still holds). We chose the
strict prohibition because the relaxation has high footgun surface
(authors who think `decision: deny` means anything on a label; authors
who write `default: public` and silently get dead code; authors who
forget that resolver lifetime semantics differ from variable lifetime
semantics). The spec note in §11.5 documents this trade explicitly so
the decision is reviewable.

---

## 9. Why monotonicity is enforced by the type, not by an `update:` expression

Once you grant that label variables need monotone joins, the question
is _where the constraint lives_. Three placements:

1. **As a flag (`monotone: true`).** Author writes both the flag and
   `update: "max(@current, @incoming)"`; the loader checks they agree.
   This is an if-then validation: if A is declared, B must also be true.
2. **As a property of the type.** The type does not admit the `update:`
   field at all. The join function is the spec.
3. **As convention.** Document that authors should write
   `update: "max(...)"`. Hope code review catches mistakes.

Option 1 violates a stronger principle: **invalid configurations should
be unrepresentable, not validated**. An if-then check exists only
because the schema allows both branches; eliminating one branch
eliminates the check. Option 2 is the form of "make wrong configs
unrepresentable" that requires the least machinery.

Option 3 is what most IFC systems ship. Most IFC systems also rot.

We picked option 2. The cost is the new types (§5). The benefit is
that the safety property is structural, not procedural.

---

## 10. Sugar decisions, principle-by-principle

The conversation explicitly enumerated three pieces of sugar. Each is
principle-based, not convenience-based.

### `value:` shorthand (kept)

**Principle.** `value: confidential` is sugar for
`expression: "'confidential'"`. It is _literal-only_: no `@` references,
no operators, no function calls. The author who wants any computation
writes `expression:`.

**Why.** Authors typing `expression: "'public'"` is a documented
foot-gun — `"public"` (one quote layer) resolves to a session variable
named `public` which does not exist, returns `null`, and silently
no-ops on a regular variable. The literal shortcut removes the trap.
Limiting it to literals keeps invariant 1 alive: anything dynamic is
in the expression language.

### `reason:` on `reset_by[]` (kept)

**Principle.** Audit events should carry the author's intent.

**Why.** `variable.<name>.declassified` is the most security-sensitive
audit event in the IFC story. Today the audit log shows _that_ a
declassification occurred and _which_ resetter triggered it. The
optional `reason:` carries the _why_ — "session boundary," "PII removed
at Stage 4," "operator-approved export" — into the event payload.
Required would be too noisy for trivial resetters; optional is enough.

### Vocabulary enforcement — drop-with-warning (kept)

**Principle.** Authors should hear about typos at load time; agents
should not bypass IFC because a tool's API drift introduced a new
classification string the policy file does not know about.

**Why.** Two separate enforcement paths:

- `value:` literals are statically known. A `value: [pii, finncial]`
  (typo) is a **load-time error** referencing the file and the
  vocabulary.
- `expression:` evaluations are runtime values. A populator that
  returns `["pii", "novel_classification"]` against a `vocabulary:
  [pii, financial, phi]` drops `novel_classification`, joins the
  surviving subset, and emits `variable.<name>.vocabulary_violation`
  (warn).

The expression path cannot be load-time-checked because the value is
dynamic. The runtime warning is the only available defense. We keep
the strict load-time check on the static path because we can.

### Subset / superset on arrays (added to LANGUAGE.md)

**Principle.** Existing operators should overload onto arrays where
the semantics is unambiguous. New built-ins should be named, not
symbolic, when the use is rare.

**Why.** Compartments need a partial order. The author writes
`data_compartments <= clearance_set` to mean "every compartment in
the running exposure is admitted by the sink." The natural reading of
`<=` on sets is subset. The alternative — `all(data_compartments, c ->
c in clearance_set)` — works today but is verbose.

LANGUAGE.md §3.7 adds the array overload for `<=` / `<` / `>=` / `>`
(subset / strict subset / superset / strict superset). LANGUAGE.md
§5.3 adds named `subset(a, b)` / `superset(a, b)` for readability in
predicate definitions.

**Why not also `<=` on objects?** No clear semantics: subset of keys?
Subset of values? Skipped.

---

## 11. Null-as-top, vocabulary enforcement, and the fail-closed chain

This is the chain of small rules that compose into "fail-closed by
construction." Each rule is small; the chain is the contract.

| Rule | Where | Behavior |
|---|---|---|
| Missing variable reads `null` | LANGUAGE.md §3.6 | Boolean coercion of `null` → `false`; gates fail closed |
| Cross-type comparison returns `false` | LANGUAGE.md §3.5 | `'restricted' <= 5` is `false`, not an error; gates fail closed |
| Populator returning null on a label | Spec §10.5.4 | Escalates to lattice top; gates against high label fail closed |
| Populator wildcard fallback | Spec §10.5.1 (selector grammar) | Catches unenumerated tools; explicit `exclude:` makes coverage reviewable |
| Vocabulary mismatch on `value:` literal | Spec §10.5.5 | Load-time error |
| Vocabulary mismatch on `expression:` result | Spec §10.5.5 | Drop + warn event; partial subset joined |
| `update:` forbidden on label types | Spec §10.2 | Type-locked join cannot be overridden |
| `on_demand_by:` forbidden on label types | Spec §11.5 | Resolver writes blocked; exposure ≠ authorization |
| `reset_by[]` on label types | Spec §10.6 | Emits `.declassified` (critical) — clearing is loud |
| `lifetime:` expiry on label types | Spec §9 | Same `.declassified` emission as `reset_by[]` |
| Variable redefinition across tiers | Spec §10.9 | Load-time error — parent owns the lattice |

Each row is a single mechanism. The composition is what closes the
fail-open path. The chain is verifiable end-to-end by reading these
sections — there is no implicit global behavior to remember.

### Worked trace — why a forgotten populator does not fail open

```yaml
# Author declared the lattice and three populators.
variables:
  - name: data_sensitivity
    type: level
    members: [public, internal, confidential, restricted]
    default: public
    populated_by:
      - { kind: tool, name: read_user_diary, value: confidential }
      - { kind: tool, name: get_account_balance, value: restricted }
      - { kind: tool, name: { include: ["*"], exclude: ["get_current_time", "ping"] }, value: restricted }

# Six months later, someone adds:
resources:
  tools:
    - name: get_credit_report
```

`get_credit_report` is not in `exclude:`. It matches the wildcard
include. Every call to it writes `restricted`. The next call to
`send_external_email` fails closed. The author who forgot to
explicitly classify the new tool has shipped the safest posture, not
the most permissive.

If the author wanted `get_credit_report` to be considered "public,"
they had to add it to `exclude:` and add an explicit `value: public`
populator — a deliberate, reviewable choice in the diff.

---

## 12. Declassification — `reset_by:` + `variable.<name>.declassified`

Declassification is the most security-sensitive operation in the IFC
story. We considered three placements:

1. **A new `action: declassify` on guard policies.** Too much new
   surface; needs its own approval-shape rules; needs to refuse to
   raise labels; needs its own audit shape.
2. **A first-class `declassify:` field on label variables.** Mirrors the
   "the type carries the semantics" principle. Concrete enough to make
   the audit shape obvious.
3. **`reset_by[]` (existing primitive) + a label-specific event.** Reuses
   the existing reset machinery; no new primitive.

We picked option 3. **Invariant 3 (one mental model).** A reset is a
reset; on a label, it is also a declassification, and the type-level
audit event makes that visible.

```yaml
variables:
  - name: data_sensitivity
    type: level
    members: [public, internal, confidential, restricted]
    default: public
    populated_by:
      - { kind: tool, name: read_kyc_record, value: restricted }
    reset_by:
      - kind: tool
        name: declassify_to_public
        phase: after
        reason: "Operator-approved declassification."
```

When `declassify_to_public` succeeds, `data_sensitivity` clears, and
`variable.data_sensitivity.declassified` fires at severity `critical`
with `{ reset_by_kind: tool, reset_by_name: declassify_to_public,
reason: "Operator-approved declassification.", prior_value: restricted,
prior_key: null }`. SOC pipelines alert on this event class.

The "approval"-shaped declassification is composed, not built-in:

```yaml
variables:
  - name: operator_approval_for_declassify
    type: boolean
    default: false
    on_demand_by:
      kind: human
      prompt: "Approve declassifying the current session?"
      lifetime: { allow: per_call, deny: per_session }

state_validation:
  guard_policies:
    - name: gate_declassify
      applies_to: { tools: { include: ["declassify_*"] } }
      evaluate_when:
        - expression: "operator_approval_for_declassify"
          reason: "Declassification requires operator approval."
```

The label has no resolver. The approval is a separate variable. The
two compose. **Invariant 4 (single source of truth)** — the label's
audit event tells you the label cleared; the approval's audit event
tells you who approved; the guard policy's audit event tells you the
gate passed.

---

## 13. Cross-tier composability — Option A (strict no-redefinition)

The conversation considered three composability stories:

- **Option A.** Strict no-redefinition. Top tier owns the lattice; child
  tiers cannot add populators / resetters / sinks to a parent's label
  variable. Trade: lattice flexibility for security floor.
- **Option B.** A separate top-level `label_overlays:` block where
  children additively add populators. Trade: a new top-level construct.
- **Option C.** Resource-level `classifies:` annotations that desugar
  to populators. Trade: scatter the IFC graph.

We picked Option A. **Invariant 5 (composability is additive-only)**
is satisfied — child tiers add their own variables, their own guard
policies, their own resources; they just cannot weaken the parent's
lattice. **Invariant 4 (single source of truth)** is preserved — the
lattice lives in exactly one file.

The cost is real: a developer tier that adds `read_partner_marketing_doc`
cannot mark it `[marketing]` if the org tier declared
`data_compartments` with a `*` populator at the full vocabulary.
Workaround patterns:

- Org tier publishes a name-pattern populator (e.g., a wildcard with
  `exclude:` for known-low-sensitivity prefixes).
- Developer tier adds an explicit `reset_by[]` entry that fires after
  the partner doc read with a justified `reason:` — visible
  declassification.

If demand for flexible cross-tier composability becomes overwhelming,
Option B is the unlock — and it is additive, not breaking, so we have
optionality.

---

## 14. Selector grammar — the cleanup of `*` and "fallback-only" wildcards

The earlier spec had a "fallback-only" rule on `populated_by[]`
wildcards: an exact `name:` entry shadowed a `name: "*"` entry. This
violated invariant 6 (cross-tool patterns must be expressible without
enumeration) and created an asymmetry with `applies_to.tools: ["*"]`
(additive). The migration note in §10.5.1 documented a previous
breaking change.

We replaced the wildcard rule with a unified selector grammar
applicable at three call sites:

- `populated_by[].name`
- `reset_by[].name`
- `guard_policies[].applies_to.tools` / `.agents`

A selector is one of four shapes (§10.5.1):

| Shape | Form | Use |
|---|---|---|
| 1 | `"<pattern>"` | Single exact name or single glob |
| 2 | `["<pattern>", ...]` | Multiple includes |
| 3 | `{ include: [...], exclude: [...] }` | Canonical form with exclusions |
| 4 | `{ unlisted: true }` | Catch-all for resources not declared by literal name |

`<pattern>` is a snake_case identifier with optional `*` wildcards.
No regex, no `?`, no `**` — kept deliberately minimal so authors do
not write clever patterns that pass review but fail in production.

**Per-site match rule:**

- `applies_to`: set-union (guard fires once if any selector entry
  matches).
- `populated_by[]`: all matching entries fire in declaration order;
  the variable's type-locked join (or `update:` expression for non-label
  variables) composes the writes.
- `reset_by[]`: all matching entries fire in declaration order; reset is
  idempotent so this collapses to "at least one matched ⇒ reset."

The "fallback-only" rule and the migration note are gone. The
authoring pattern for "narrow case, then default" is explicit:

```yaml
populated_by:
  - kind: tool
    name: { include: ["read_user_*"], exclude: ["read_user_preferences"] }
    value: confidential
  - kind: tool
    name: { include: ["fetch_credit_*", "get_account_*"] }
    value: restricted
  - kind: tool
    name:
      include: ["*"]
      exclude: ["read_user_*", "fetch_credit_*", "get_account_*", "get_current_time", "ping"]
    value: internal
```

The verbosity of `exclude:` is the **point**. A reviewer can answer
"what's the default classification?" by reading the last entry and
"is this tool covered by something narrower?" by reading the prior
entries. Compare to the prior wildcard rule, where the same review
required mental simulation of the spec's matching algorithm.

Shape 4 (`{ unlisted: true }`) is the spec's first-class spelling of
the catch-all for resources not declared by literal name. It is
deliberately separate from Shape 3 `"*"` because the two intents
differ: "applies to every tool, declared or not" vs "applies only to
the unenumerated tools." Mixing them on one selector is a load-time
error.

**Composability for selectors (§12.12).** Across `extends:` chains,
`include:` lists concatenate. The `exclude:` field is owned by the
declaring tier — children cannot relax a parent's exclusion. Selector
merge maintains the additive-only invariant.

---

## 15. Stage ordering — what we kept honest about

Two ordering decisions worth surfacing for review.

### 15.1 Populators fire on the raw result, before Stage 4 redaction

`populated_by[]` runs at the same logical point as
`tool.<name>.success`, against the **raw** tool result. Stage 4
redaction (`action: redact_response`) runs after. The consequence:

```yaml
# Stage 4 redacts emails from read_user_profile's output.
output_validation:
  guard_policies:
    - name: redact_emails_from_profile
      applies_to: { tools: { include: ["read_user_profile"] } }
      action: { kind: redact_response, spans: "regex.pii_email" }

# Label populator marks the session restricted on diary reads.
variables:
  - name: data_sensitivity
    type: level
    members: [public, internal, confidential, restricted]
    default: public
    populated_by:
      - { kind: tool, name: read_user_profile, value: restricted }
```

After a `read_user_profile` call: the label is `restricted`. The redaction
ran successfully. The egress gates still see `restricted` and block —
even though the only PII the agent actually saw was the redacted
residue. The label is more pessimistic than necessary; the system is
fail-closed but ergonomically surprising.

We addressed this by adding `guard_policy.<name>.redacted` (info-level
audit) and documenting the `reset_by[]`-based mitigation:

```yaml
reset_by:
  - event: guard_policy.redact_emails_from_profile.redacted
    reason: "PII redacted at Stage 4 — context declassified."
```

The declassification is reviewable, audit-visible, and explicit. We
deliberately did not add a `phase: post_redaction` populator phase —
the audit trail of "reset on redaction" is more reviewable than a
silent "re-classify on the residue" populator phase.

### 15.2 `active_if:` on compartments and the empty-set trap

`active_if: "'hipaa' in data_compartments"` evaluates `false` against
both `unset` and `[]`. Without the wildcard fallback, a HIPAA-boundary
guard policy would stay inactive when no source has run — fail-open.

The wildcard fallback (full vocabulary on unknown) makes the empty-set
case correspond exclusively to "no source has run, no exposure" —
which is the correct fail-open path (there is no data to protect yet).
This is the only place the spec's IFC contract relies on a
load-time-checked invariant in the populator list.

### 15.3 Lifetime expiry vs default re-application

Variable lifetime expiry transitions to `@status == 'unset'`, not back
to `default:`. On a label, `unset` reads as `null`, which fails closed
at every sink. This is correct but easy to be surprised by. Documented
in §10.1 and the IFC design doc.

---

## 16. Risks that remain (and why they remain)

We are not claiming the design is exhaustively safe. These are the
residual risks we accepted, with reasoning.

| Risk | Why it remains | Mitigation in current spec |
|---|---|---|
| Session-state IFC, not value-state | Per-message taint requires tracking labels on individual values within the agent's working memory. The runtime is boundary-mediated; the LLM is opaque. | Documented in the proof (§5 — out of scope) |
| Post-redaction residue keeps elevated label | Forward-flowing redaction-aware re-labeling needs a new phase or a new primitive | `guard_policy.<name>.redacted` + `reset_by:` |
| Cross-tier lattice ownership | Option A locks the lattice to the top tier; downstream tiers cannot extend | Documented; Option B is unlocked if needed |
| Author writes `default: data_sensitivity` to `restricted` | Defeats the lattice — every session starts at top, no gating fires | Linter / load-time check not in spec yet; flagged for follow-up |
| Tools that mutate their own result post-populator | A tool that returns sanitized data but populates from a hash of the raw data is conceivable | Out of scope; populators only see the result envelope |
| Concurrent populator writes | Multiple `populated_by[]` entries fire on the same call; ordering is by declaration | Type-locked join is commutative; non-label variables get last-write-wins per declaration order, which is reproducible |
| Resolver-driven declassification approval | Lifetime semantics on the approval variable must be authored; `lifetime: per_session` is the silent footgun | Documented; spec note in §11.5 |

The bigger principle: **invariant 7 (no prematurely-clever defaults)**.
Where the spec has a residual risk that cannot be fixed structurally,
the audit event is the answer. Every declassification, vocabulary
violation, null-escalation, and redaction emits a distinct event class.
The SOC pipeline is the safety net the spec does not pretend to be.

---

## 17. Progressive examples

These examples are intended to be readable in order. Each adds one
capability to the previous.

### 17.1 Minimal level lattice

Three reads, two sinks, one level variable.

```yaml
metadata:
  name: "ifc-level"
  version: "0.1.0"
  agent_shield_version: "2.0"

variables:
  - name: data_sensitivity
    type: level
    members: [public, internal, confidential, restricted]
    default: public
    populated_by:
      - { kind: tool, name: read_public_doc,       value: public }
      - { kind: tool, name: read_internal_doc,     value: internal }
      - { kind: tool, name: read_confidential_doc, value: confidential }
      - { kind: tool, name: { include: ["*"], exclude: ["read_public_doc", "read_internal_doc", "read_confidential_doc", "send_internal_email", "send_external_email"] }, value: restricted }

state_validation:
  guard_policies:
    - name: external_egress
      applies_to: { tools: { include: ["send_external_email"] } }
      evaluate_when:
        - expression: "data_sensitivity <= 'public'"
          reason: "External egress requires public-only context."
    - name: internal_egress
      applies_to: { tools: { include: ["send_internal_email"] } }
      evaluate_when:
        - expression: "data_sensitivity <= 'internal'"
          reason: "Internal egress requires <= internal."
```

A new tool added to the catalog is automatically tainted to `restricted`
by the catch-all populator. The author's only path to public is an
explicit populator entry and an explicit `exclude:` in the wildcard.

### 17.2 Level + compartment (regulated data)

Adds an unordered categorical dimension.

```yaml
variables:
  - name: data_sensitivity
    type: level
    members: [public, internal, confidential, restricted]
    default: public
    populated_by:
      - { kind: tool, name: read_kyc_record,      value: restricted }
      - { kind: tool, name: read_clinical_record, value: restricted }
      - { kind: tool, name: read_marketing_brief, value: internal }
      - { kind: tool, name: { include: ["*"], exclude: ["read_kyc_record", "read_clinical_record", "read_marketing_brief", "send_external_email", "post_hipaa_audit"] }, value: restricted }

  - name: data_compartments
    type: compartment
    vocabulary: [pii, phi, hipaa, financial, marketing, public_facts]
    default: []
    populated_by:
      - { kind: tool, name: read_kyc_record,      value: [pii, financial] }
      - { kind: tool, name: read_clinical_record, value: [phi, hipaa] }
      - { kind: tool, name: read_marketing_brief, value: [marketing] }

state_validation:
  guard_policies:
    - name: external_egress
      applies_to: { tools: { include: ["send_external_email"] } }
      evaluate_when:
        - expression: "data_sensitivity <= 'internal'"
          reason: "External egress: level too high."
        - expression: "data_compartments <= ['marketing', 'public_facts']"
          reason: "External egress: forbidden compartment present."

    - name: phi_audit_only
      applies_to: { tools: { include: ["post_hipaa_audit"] } }
      evaluate_when:
        - expression: "'phi' in data_compartments"
          reason: "PHI audit requires phi in context."
```

The subset operator on arrays (`data_compartments <= [...]`) is the
cleanest way to express "every compartment must be in the admitted
set." The level guard and compartment guard compose as AND of two
`evaluate_when[]` entries on the same guard policy.

### 17.3 Dynamic classification from `@result`

A document-reading tool whose classification flows from the result
itself.

```yaml
variables:
  - name: data_sensitivity
    type: level
    members: [public, internal, confidential, restricted]
    default: public
    populated_by:
      - kind: tool
        name: read_document
        expression: "@result.sensitivity"   # tool returns 'public' | 'internal' | 'confidential' | 'restricted'

      # If the tool ever returns null (missing field), the population escalates to 'restricted'.
      # No additional configuration needed — fail-closed by spec rule §10.5.4.
```

The conversation's "what if MCP1 reads and MCP2 classifies?" pattern is
two populator entries:

```yaml
populated_by:
  - kind: tool
    name: mcp1.read_document
    value: internal                       # conservative pre-classification
  - kind: tool
    name: mcp2.classify_document
    expression: "@result.tags"
```

### 17.4 Conditional from `@result`

```yaml
populated_by:
  - kind: tool
    name: read_record
    expression: "@result.is_personal ? ['pii'] : []"
```

If `is_personal` is missing, the whole expression returns `null`, and the
spec's null-escalation rule writes the lattice top.

### 17.5 Declassification — operator-gated

```yaml
variables:
  - name: data_sensitivity
    type: level
    members: [public, internal, confidential, restricted]
    default: public
    populated_by:
      - { kind: tool, name: read_kyc_record, value: restricted }
    reset_by:
      - kind: tool
        name: declassify_session
        phase: after
        reason: "Operator-approved declassification."

  - name: operator_approval_for_declassify
    type: boolean
    default: false
    on_demand_by:
      kind: human
      prompt: "Approve declassifying this session for export?"
      lifetime: { allow: per_call, deny: per_session }

state_validation:
  guard_policies:
    - name: gate_declassify
      applies_to: { tools: { include: ["declassify_*"] } }
      evaluate_when:
        - expression: "operator_approval_for_declassify"
          reason: "Declassification requires operator approval."
```

The label has no resolver. The approval is a separate variable with
its own resolver. The two compose; the audit trail is rich (the
approval emits `variable.operator_approval_for_declassify.resolved`,
the reset emits `variable.data_sensitivity.declassified` at critical).

### 17.6 Cross-tier inheritance — org owns the lattice

```yaml
# org-baseline.yaml
metadata: { name: "org-baseline", version: "1.0.0", agent_shield_version: "2.0" }

variables:
  - name: data_sensitivity
    type: level
    members: [public, internal, confidential, restricted]
    default: public
    populated_by:
      - { kind: tool, name: { include: ["*"], exclude: ["public_*"] }, value: restricted }
      - { kind: tool, name: { include: ["public_*"] }, value: public }

state_validation:
  guard_policies:
    - name: external_egress_floor
      applies_to: { tools: { include: ["send_external_*", "post_external_*"] } }
      evaluate_when:
        - expression: "data_sensitivity <= 'public'"
          reason: "Org-baseline: external egress is public-only."
```

```yaml
# product.yaml
metadata: { name: "product", version: "0.1.0", agent_shield_version: "2.0" }
extends: ["org-baseline.yaml"]

# Cannot redefine data_sensitivity (Option A).
# Cannot extend org-baseline's populators directly.

# Product can add its own variables and guards, working WITHIN the lattice.
variables:
  - name: customer_segment
    type: enum
    members: [free, pro, enterprise]
    on_demand_by: { kind: tool, name: get_customer_segment }

state_validation:
  guard_policies:
    - name: enterprise_data_export_extra_gate
      applies_to: { tools: { include: ["export_to_*"] } }
      evaluate_when:
        - expression: "customer_segment == 'enterprise'"
          reason: "Export tools restricted to enterprise customers."
        # The org-baseline external_egress_floor still applies — AND-composed with this gate.
```

Child tiers cannot weaken the lattice; they can stack additional
gates. The audit trail shows both guard policies' verdicts.

### 17.7 Multi-tenant compartments with subset operator

```yaml
variables:
  - name: data_compartments
    type: compartment
    vocabulary: [tenant_a, tenant_b, tenant_c, public_communications]
    default: []
    populated_by:
      - { kind: tool, name: read_tenant_a_data, value: [tenant_a] }
      - { kind: tool, name: read_tenant_b_data, value: [tenant_b] }
      - { kind: tool, name: read_tenant_c_data, value: [tenant_c] }

state_validation:
  guard_policies:
    - name: tenant_a_egress
      applies_to: { tools: { include: ["write_to_tenant_a"] } }
      evaluate_when:
        - expression: "data_compartments <= ['tenant_a', 'public_communications']"
          reason: "Tenant A sink admits only its tenant + public_communications."

    - name: tenant_b_egress
      applies_to: { tools: { include: ["write_to_tenant_b"] } }
      evaluate_when:
        - expression: "data_compartments <= ['tenant_b', 'public_communications']"
          reason: "Tenant B sink admits only its tenant + public_communications."
```

Compare to the variable-only design we considered: this requires no
per-tenant `_clearance` variable, no per-sink populator enumeration.
The subset operator is the entire sink check. N tenants ⇒ N guard
policies, each one line.

### 17.8 Mixed static + dynamic + redaction-aware

The hardest case in the conversation.

```yaml
variables:
  - name: data_sensitivity
    type: level
    members: [public, internal, confidential, restricted]
    default: public
    populated_by:
      # Static — a known-restricted source.
      - { kind: tool, name: read_kyc_record, value: restricted }
      # Dynamic — classification from result.
      - { kind: tool, name: read_document, expression: "@result.sensitivity" }
      # Delegated — MCP2's classifier service.
      - { kind: tool, name: mcp2.classify_document, expression: "@result.tags" }
      # Catch-all — restricted floor on unknown tools.
      - kind: tool
        name:
          include: ["*"]
          exclude: ["read_kyc_record", "read_document", "mcp2.classify_document", "send_external_email", "log_to_warehouse", "redact_pii_from_response"]
        value: restricted

    reset_by:
      # After Stage 4 redaction, declassify (audit-loud, reviewable).
      - event: guard_policy.redact_pii_from_response.redacted
        reason: "PII redacted at Stage 4."

output_validation:
  guard_policies:
    - name: redact_pii_from_response
      applies_to: { tools: { include: ["read_document", "read_kyc_record"] } }
      action: { kind: redact_response, spans: "regex.pii_email" }

state_validation:
  guard_policies:
    - name: external_egress
      applies_to: { tools: { include: ["send_external_email"] } }
      evaluate_when:
        - expression: "data_sensitivity <= 'internal'"
          reason: "External egress requires <= internal."
```

Trace through a session:

1. `read_kyc_record` → label rises to `restricted` (static populator).
2. Stage 4 redaction (`redact_pii_from_response`) runs → emits
   `guard_policy.redact_pii_from_response.redacted`.
3. `reset_by[]` matches that event → label clears, emits
   `variable.data_sensitivity.declassified` (critical) with reason
   "PII redacted at Stage 4."
4. `send_external_email` is called → guard re-evaluates →
   `data_sensitivity <= 'internal'` is now `true` (label is `unset` →
   `null`, but `null <= 'internal'` is `false`).

Wait — that fails closed. Did we want it to pass?

This is the residual risk from §15. The redaction-driven reset clears
the label to `unset`; the gate then fails closed on the next egress
attempt unless a second populator (or a `default:`) re-establishes a
working level. The honest authoring pattern is:

```yaml
# After redaction, declassify and re-establish a public floor.
reset_by:
  - event: guard_policy.redact_pii_from_response.redacted
    reason: "PII redacted at Stage 4."

populated_by:
  # ... previous entries ...

  # Re-establish the floor after a declassification.
  - event: variable.data_sensitivity.declassified
    value: public
```

Now the trace works: reset clears, the post-declassification populator
writes `public`, and the egress passes. Every step is audit-visible
and reviewable. The author had to make every decision deliberately.

---

## 18. Deferred / open work

Captured here so they do not get lost.

- **`phase: post_redaction` populator phase.** Considered, deferred —
  the `reset_by: [{ event: guard_policy.X.redacted }]` pattern is
  more reviewable. Revisit if real cases surface.
- **Endpoint selectors.** The unified selector grammar is tool / agent
  only; endpoints still use the §13.4 pattern matcher. Worth unifying
  in a follow-up.
- **Vocabulary inheritance.** Today `vocabulary:` is locked at the top
  tier. Child tiers cannot add new tags. Same design tradeoff as the
  lattice; revisit if needed.

---

## 19. Appendix — restriction matrix

Quick reference: what a label-typed variable allows, vs a plain variable.

| Feature | Plain variable | `type: level` / `type: compartment` |
|---|---|---|
| `value:` on `populated_by[]` | yes | yes |
| `expression:` on `populated_by[]` | yes | yes |
| `update:` (merge expression) | yes | **no — type-locked join** |
| `on_demand_by:` (inline resolver) | yes | **no — load-time error** |
| Resolver `set_variables:` writes | yes | **no — load-time error** |
| `reset_by[]` | yes | yes (emits `.declassified` critical) |
| `lifetime:` | any form | any form (expiry emits `.declassified`) |
| Null populator result | no-op | **escalates to lattice top** |
| Out-of-vocabulary literal | n/a | **load-time error** |
| Out-of-vocabulary expression result | n/a | **drop + warn event** |
| Same-name redefinition across tiers | error (§10.9) | error (same rule) |
| Default `update:` semantics | replace (`@incoming`) | **`max(...)` / `union(...)`** |

The columns are the spec's structural promises. Reviewers who care
about IFC-soundness can use this as a checklist when reading any
guardrails YAML that declares label-typed variables.

---

_End of document._
