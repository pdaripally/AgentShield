# Agent Shield — Rust Runtime Concurrency Contract

This document is the authoritative thread-safety contract for Agent Shield's Rust core runtime. It describes what may be shared across threads, which ordering guarantees exist today, and which behaviors hosts and SDKs MUST treat as part of the runtime contract.

## 1. Overview

Agent Shield uses a **shared-immutable runtime, session-local mutable state** model.

- One `Arc<GuardrailsRuntime>` may be shared across many concurrent sessions.
- `GuardrailsRuntime` holds immutable configuration plus shared services:
  - `EventBus`
  - `Arc<LifetimeTracker>`
  - `Arc<ResolverDispatcher>`
  - `Arc<GuardPolicyEngine>`
  - `Arc<ObservabilityDispatcher>`
- Each `GuardrailsSession` owns its own mutable conversation state and scopes all cross-cutting runtime state with its `SessionId`.

The intended concurrency model is therefore:

```text
shared-nothing sessions
        on top of
shared immutable runtime services
```

Sessions may run concurrently. Cross-session interference is prohibited except through explicitly shared immutable runtime configuration and services that are themselves session-keyed.

## 2. Type Safety

### Send + Sync types

The following types are part of the shareable runtime surface and MUST remain safe to use from multiple threads:

- `GuardrailsRuntime`
- `Arc<GuardrailsRuntime>`
- `GuardrailsSession`
- `EventBus`
- `Arc<LifetimeTracker>` / `LifetimeTracker`
- `Arc<ResolverDispatcher>`
- `Arc<GuardPolicyEngine>`
- `Arc<ObservabilityDispatcher>`
- registered resolver / delegate / observability callback traits, which MUST be `Send + Sync`

These types achieve thread-safety through immutability, `Arc`, atomics, and `std::sync::Mutex`.

### Not part of the shared-thread contract

The following are **not** shared-runtime synchronization primitives and MUST be treated as per-operation or single-owner values:

- `StreamingGuard` — mutable per-stream state, not for concurrent multi-thread access
- `ToolAdmission<'_>` — ephemeral RAII admission handle; do not treat it as a long-lived cross-thread coordination object
- `MutexGuard`s from any session sub-lock — never send or hold across callback boundaries

## 3. Lock-Order DAG

Agent Shield relies on a strict acyclic locking policy.

| Level | Lock / resource | Allowed while holding | Forbidden while holding |
|---|---|---|---|
| 0 | `Arc` clones, immutable config reads, atomics | anything | none |
| 1 | `EventBus.inner` mutex | internal bus mutation only | any session sub-lock, `LifetimeTracker.inner` |
| 1 | `LifetimeTracker.inner` mutex | internal tracker mutation only | any session sub-lock, `EventBus.inner` |
| 1 | one session sub-lock (`cached_user_input`, `tool_results_this_turn`, one binding-cache shard, or `exposure`) | local mutation only | `EventBus`, `LifetimeTracker`, any other session sub-lock |
| 2 | subscriber callback mutex | only after `EventBus.inner` has been released | reacquiring `EventBus.inner` through lock inheritance assumptions |

### Rules

1. **Never hold a session lock while calling into the bus or tracker.**
2. **Never call the bus while holding the tracker lock.**
3. **Never call the tracker while holding the bus lock.**
4. `EventBus` subscriber dispatch happens only after the bus mutex is released.
5. Session code should acquire a lock, mutate local state, and release it before any runtime callback or cross-component call.

The important invariant is that there is **no lock cycle** between session-local mutexes and runtime-global mutexes.

## 4. Sibling-Lock Rule

Within `GuardrailsSession`, **no two session sub-locks may be held simultaneously**.

This applies to:

- `cached_user_input`
- `tool_results_this_turn`
- each element of `validated_invocations`
- `exposure`

Implications:

- No nested acquisition of session mutexes.
- No "lock one shard, then lock another shard" behavior in normal code.
- If future work ever requires multi-shard operations, it MUST be implemented as a special-case ordered protocol; the current contract is one-session-lock-at-a-time.

## 5. Atomics Ordering

Current atomic ordering is **`Relaxed`**.

The runtime currently uses relaxed atomics for:

- `turn_id.fetch_add(1, Relaxed)`
- `request_id.fetch_add(1, Relaxed)`
- `turn_active.store/swap/load(..., Relaxed)`
- `request_active.store/swap/load(..., Relaxed)`
- `closed` state checks

### Meaning of the current contract

- These atomics provide atomicity of the individual flag/counter updates.
- They do **not** provide publication ordering for adjacent non-atomic state.
- Visibility of mutex-protected state comes from the mutex, not from the relaxed atomics.

### Known issue: `begin_turn()` race window

`begin_turn()` currently performs:

```rust
emit turn.start
turn_id.fetch_add(1, Relaxed)
turn_active.store(true, Relaxed)
tool_results_this_turn.lock().clear()
```

This creates a known race window:

- `turn_active` becomes `true`
- **before** `tool_results_this_turn` is cleared
- so a concurrent Stage 3 reader can observe stale tool results from the previous turn

This race window is part of the currently documented implementation constraints and MUST be treated as a known issue until fixed.

### Boundary idempotence

`end_turn()` uses:

```rust
turn_active.swap(false, Relaxed)
```

and is therefore idempotent with respect to duplicate end calls. `end_request()` follows the same pattern for `request_active`.

## 6. Session Isolation

`SessionId` is the runtime's isolation key.

- `EventBus` stores latched state keyed by `(SessionId, EventId)`.
- `LifetimeTracker` stores per-session state in maps keyed by `SessionId`.
- Bus subscriber payloads include `session_id`; subscribers MUST scope all mutations to that session only.
- `GuardrailsSession` also stores session-local mutable state directly in the session object, so its local caches are not shared across sessions.

The contract is: **all mutable runtime state is either session-local by ownership or session-scoped by `SessionId` keying**.

## 7. EventBus Dispatch Pattern

`EventBus` uses a single mutex for its inner state, but subscriber callbacks are dispatched **after mutex release**.

This is required behavior:

1. mutate latched state under the bus mutex
2. snapshot deferred notifications / subscribers
3. release the bus mutex
4. invoke subscribers

Consequences:

- subscriber callbacks must never assume the bus lock is still held
- callbacks may safely call back into public bus methods without self-deadlocking on the outer bus mutex
- session scoping is carried explicitly through `BusEvent.session_id`, not through thread-local state

## 8. LifetimeTracker

`LifetimeTracker` uses `Arc<Mutex<Inner>>` and stores per-session maps keyed by `SessionId`.

### Expiry model

Expiry is **reactive**.

- `for: <duration>` state is checked on read
- expiry is not proactively swept in the background
- the first reader that observes expiry performs the remove-on-read transition

**✅ FIXED (this PR):** The original implementation used THREE separate lock acquisitions for check/remove/read, creating two race windows:
1. **Data loss:** A fresh write between Lock#1 (check-expired) and Lock#2 (remove) was silently destroyed.
2. **Stale read:** A reader that checked `expired=false` under Lock#1 could return stale `Resolved` at Lock#3 after time advanced past expiry.

The same pattern existed in `read_predicate_in`. **Fix:** both `read_variable_keyed_in` and `read_predicate_in` now perform the entire check-expiry/remove/read sequence under a single lock acquisition.

### Single-fire semantics

Expired state transitions at most once logically:

- before expiry: readers may observe the stored value
- first reader to detect expiry removes it
- subsequent readers observe the post-expiry state (`unset` / absent)

The same session scoping applies to event-driven invalidation (`until_event:` and approval revocation): only the matching session's state is mutated.

## 9. ToolAdmission State Machine

`ToolAdmission` is the Stage-3 RAII handle for a tentatively admitted tool invocation.

```text
Tentative --commit_to_stage4()--> Committed
Tentative --abandon()-----------> Revoked
Tentative --Drop----------------> Revoked
Committed --Drop----------------> no cleanup
```

### States

- **Tentative**
  - Stage 3 inserted a binding-cache entry
  - `cleanup_on_drop = true`
- **Committed**
  - `commit_to_stage4()` sets `cleanup_on_drop = false`
  - Stage 4 is now responsible for consuming the binding
- **Revoked**
  - `abandon()` or `Drop` removes the tentative binding from the cache

This is the contract that prevents abandoned Stage-3 admissions from leaving stale binding-cache entries behind.

## 10. Binding Cache Sharding

The validated-invocation cache is sharded as:

- `validated_invocations: [Mutex<HashMap<...>>; 16]`
- shard index = `DefaultHasher(full_binding_key) % 16`
- full binding key = `(turn_id, resource_kind, name, tool_call_id)`

### Sharding rules

1. Shard selection MUST use the full binding key.
2. The shard count is fixed at **16** for this contract.
3. Normal operations take **one shard lock only**.
4. If a future change ever needs multiple shard locks, they MUST be acquired in ascending shard-index order.
5. Shard locks remain subject to the sibling-lock rule and MUST NOT be held while calling `EventBus` or `LifetimeTracker`.

## 11. Resolver Callback Contract

Host-supplied resolver callbacks are part of the thread-safety boundary.

### Required properties

- callbacks MUST be `Send + Sync`
- callbacks MUST tolerate invocation from arbitrary runtime threads
- callbacks MUST return a pure `ResolverResponse` payload; they are not the place where runtime state is mutated directly
- callbacks MUST NOT synchronously reenter the same `GuardrailsSession`

### Post-return application rule

`set_variables` and `on_allow` side effects are applied by the runtime **after** the callback returns. The callback contract is therefore:

```text
callback computes response -> returns -> runtime applies set_variables/on_allow -> runtime emits approval events
```

Callbacks must not assume their own returned side effects are visible until control has returned to the runtime.

## 12. StreamingGuard

`StreamingGuard` is **per-stream mutable state**.

It owns:

- a mutable text buffer
- counters for emitted/validated lengths
- end-of-stream state
- validation cadence configuration

It is not a shared session/global synchronization primitive. The contract is:

- create one `StreamingGuard` per protected stream
- mutate it from one execution context at a time
- do not concurrently call `add_chunk()` / `end_stream()` from multiple threads

## 13. Mutex Poisoning Policy

Session mutex poisoning is treated as **session-local failure**, not runtime-wide failure.

Policy:

- a poisoned session sub-lock does **not** invalidate `GuardrailsRuntime`
- it does **not** invalidate other sessions sharing the same runtime
- the affected session may fail closed, skip cache cleanup, or require disposal
- hosts should discard the poisoned session rather than attempt to recover semantic correctness from partially-mutated session-local cache state

In short: **session corruption is contained to the session; the shared runtime survives**.

## 14. Known Issues and Constraints

### Fixed bugs (confirmed by 3-model source-level review, fixed in this PR)

1. **~~BUG 1: Session resurrection via `session_state_mut`~~ — FIXED**
   - `Inner::session_state_mut()` used `entry().or_default()` unconditionally
   - 10+ callers could resurrect a closed session (writes, reads, bus events)
   - **Fix applied:** replaced with `session_state_existing() -> Option<&mut SessionState>` + explicit `ensure_session()` lifecycle registration. Late writes after `cleanup_session` are now no-ops.

2. **~~BUG 2: Three-lock TOCTOU in `read_variable_keyed_in` AND `read_predicate_in`~~ — FIXED**
   - Three separate `inner.lock()` calls created data-loss and stale-read windows
   - Fresh writes could be silently destroyed by stale expiry decisions
   - **Fix applied:** collapsed into single lock acquisition for the entire check-expiry/remove/read sequence.

### Open bugs (documented, to be addressed in follow-up PRs)

3. **BUG 3: Resolver vs host write ordering**
   - No epoch/generation mechanism — resolver's stale write can overwrite host's explicit denial
   - Fix: monotonic write-epoch per variable slot, strict equality check

### Known design issues

4. **`begin_turn()` stale-tool-results race window**
   - `turn_active = true` is published before `tool_results_this_turn` is cleared.
5. **`begin_turn()` / `end_turn()` are not reentrant protocols**
   - duplicate `end_turn()` is tolerated as a no-op
   - overlapping or recursively nested turn lifecycles are not supported
6. **`begin_request()` / `end_request()` follow the same non-reentrant model**

### Host constraints

1. **`tool_call_id` uniqueness is a host contract**
   - uniqueness is required per invocation
   - re-use within a turn is a host bug
   - collisions poison the binding slot and force later Stage-4 lookup to fail closed
2. **Session scoping must be threaded explicitly**
   - do not rely on ambient thread-local state inside Rust core
3. **Streaming guards are single-owner objects**
4. **Resolver callbacks are external code and must uphold the callback contract above**

## 15. Guidance for SDK Authors

### Ambient session propagation

Ambient session propagation belongs in the host SDK, not in Rust core.

- Python: `contextvars`
- Node: `AsyncLocalStorage`
- .NET: `AsyncLocal<T>`

SDKs MUST ensure the correct `GuardrailsSession` handle is associated with the host's async flow, especially across `await` boundaries.

### FFI thread safety

When exposing the runtime through FFI:

- only share handles whose underlying Rust values satisfy the runtime's `Send + Sync` expectations
- treat callback `user_data` as host-owned shared state that must be synchronized by the host
- do not assume callbacks run on one dedicated thread
- do not reenter a session from inside a resolver callback
- ensure host-generated `tool_call_id`s are unique per invocation

## Practical SDK rule of thumb

Use the Rust core for deterministic policy decisions and state transitions. Use the SDK for:

- host async orchestration
- ambient session propagation
- framework-specific tool / result shape translation
- FFI-safe callback adaptation

That boundary preserves both correctness and thread-safety.
