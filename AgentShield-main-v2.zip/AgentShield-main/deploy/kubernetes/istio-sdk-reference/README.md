# Istio SDK-First Reference Bundle

## PRODUCTION REFERENCE

This bundle is the production-oriented reference deployment in this repository and is intended to be adapted, not copied blindly.


This bundle deploys an agent service that already uses Agent Shield SDK adapters.

It does not deploy an Agent Shield reverse proxy.

## Files

- `namespace.yaml`:
  - Namespace with Istio sidecar injection enabled.
- `guardrails-configmap.yaml`:
  - `.guardrails.yaml` mounted into the app container.
- `deployment.yaml`:
  - Agent app deployment (replace image with your SDK-integrated app).
- `service.yaml`:
  - ClusterIP service for the app.
- `peer-authentication.yaml`:
  - STRICT mTLS for namespace.
- `destination-rule.yaml`:
  - ISTIO_MUTUAL service-to-service TLS policy.
- `kustomization.yaml`:
  - Apply all resources.
- `test.sh`:
  - Real-stack checks (sidecar, mTLS, allow/deny probes, stage 2-4 checklist).

## Deploy

```bash
kubectl apply -k deploy/kubernetes/istio-sdk-reference
```

## Test

```bash
bash deploy/kubernetes/istio-sdk-reference/test.sh
```

Optional overrides:

```bash
NAMESPACE=agents SERVICE=agent-app PORT=8080 CHAT_PATH=/chat bash deploy/kubernetes/istio-sdk-reference/test.sh
```

Additional useful overrides:

```bash
# If deployment name differs from service name
DEPLOYMENT=agent-app-v2 \
APP_LABEL_SELECTOR='app.kubernetes.io/name=agent-app-v2' \
bash deploy/kubernetes/istio-sdk-reference/test.sh

# Tune expected status assertions
HEALTH_EXPECTED_REGEX='^2[0-9][0-9]$' \
ALLOW_EXPECTED_REGEX='^2[0-9][0-9]$' \
DENY_EXPECTED_REGEX='^(401|403)$' \
bash deploy/kubernetes/istio-sdk-reference/test.sh
```
## Notes

- Replace `ghcr.io/your-org/agent-app:latest` in `deployment.yaml` with your app image.
- Your app should expose a health route (`/health`) and a request route (`/chat` by default in `test.sh`).
- For stronger validation, include one route in your app that deterministically triggers a guarded tool call so Stage 2-4 behavior can be asserted in CI.
