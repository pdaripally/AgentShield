using System;
using System.Collections.Generic;
using System.Text.Json;
using Xunit;

using AgentShield;

namespace AgentShield.Anthropic.Tests;

/// <summary>
/// Bypass-path tests for the Anthropic adapter.
/// Covers guarded calls, missing bindings, unguarded dispatch incidents,
/// parameter normalization, and streaming blocks.
/// </summary>
public class BypassPathTests
{
    private const string FixtureYaml = """
metadata:
  name: "anthropic-dotnet-bypass"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Guard Anthropic adapter tool calls."]
  forbidden: ["Leak secrets."]
resources:
  tools:
    - name: "calculator"
      description: "Performs arithmetic."
      permission: "read_only"
""";

    private const string BlockOutputYaml = """
metadata:
  name: "anthropic-dotnet-block"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Block confidential output."]
  forbidden: ["Leak secrets."]
output_validation:
  guard_policies:
    - name: "block-confidential"
      evaluate_when:
        - pattern: "CONFIDENTIAL"
          reason: "Output contains confidential marker."
      action: block
""";

    private sealed class CapturingProvider : IObservabilityProvider
    {
        public List<JsonElement> Events { get; } = new();
        public void OnLogEvent(JsonElement e) => Events.Add(e.Clone());
    }

    private static JsonElement Json(string raw) =>
        JsonDocument.Parse(raw).RootElement.Clone();

    private static GuardrailsRuntime Build(out CapturingProvider p, string yaml = FixtureYaml)
    {
        p = new CapturingProvider();
        using var b = RuntimeBuilder.FromYamlStrings(new[] { yaml });
        b.RegisterObservabilityProvider(p);
        return b.Build();
    }

    private static GuardrailsSession NewSession(GuardrailsRuntime rt)
    {
        var s = rt.NewSession();
        s.BeginTurn();
        return s;
    }

    [Fact]
    public void GuardedCallProducesInvocationHash()
    {
        using var rt = Build(out _);
        using var s = NewSession(rt);

        var (cv, _) = s.ValidateToolCall("calculator",
            Json("""{"op":"add","a":1,"b":2}"""), "ant_dn_001");
        Assert.True(cv.Allowed);
        Assert.False(string.IsNullOrEmpty(cv.InvocationHash));

        var (ov, _) = s.ValidateToolOutput("calculator",
            Json("""{"result":3}"""), "ant_dn_001");
        Assert.True(ov.Allowed);
        Assert.False(string.IsNullOrEmpty(ov.InvocationHash));
    }

    [Fact]
    public void RawCallWithoutStage3FailsClosedNoHash()
    {
        using var rt = Build(out _);
        using var s = NewSession(rt);
        var (ov, _) = s.ValidateToolOutput("calculator",
            Json("""{"result":42}"""), "never_admitted");
        Assert.False(ov.Allowed);
        Assert.Equal("<binding>", ov.Policy);
        Assert.True(string.IsNullOrEmpty(ov.InvocationHash));
    }

    [Fact]
    public void RawDispatchEmitsUnguardedToolDispatchIncident()
    {
        using var rt = Build(out var p);
        using var s = NewSession(rt);
        s.ValidateToolOutput("calculator", Json("""{"result":0}"""), "raw_ant_dn");
        bool found = p.Events.Exists(e =>
            e.TryGetProperty("event_type", out var et) &&
            et.GetString() == "incident_emitted" &&
            e.TryGetProperty("event_id", out var ei) &&
            ei.GetString() == "incident.unguarded_tool_dispatch");
        Assert.True(found, "Expected incident.unguarded_tool_dispatch");
    }

    [Fact]
    public void NullParamsNormalizeToEmptyParamsAndReturnHash()
    {
        using var rt = Build(out _);
        using var s = NewSession(rt);
        var (cv, _) = s.ValidateToolCall("calculator", Json("null"), "ant_dn_malformed");
        Assert.True(cv.Allowed, "null params MUST still allow the call");
        Assert.False(string.IsNullOrEmpty(cv.InvocationHash), "null params MUST still produce InvocationHash");
    }

    [Fact]
    public void StreamingStage5DenyEmitsStreamAbortedIncident()
    {
        using var rt = Build(out var p, BlockOutputYaml);
        using var s = NewSession(rt);
        using var g = s.StreamingSession(StreamingStage.Output);
        g.Push("The secret is: ");
        g.Push("CONFIDENTIAL-TOKEN-XYZ.");
        var r = g.Finish();
        Assert.Equal(StreamAction.Stop, r.Action);
        bool found = p.Events.Exists(e =>
            e.TryGetProperty("event_type", out var et) &&
            et.GetString() == "incident_emitted" &&
            e.TryGetProperty("event_id", out var ei) &&
            ei.GetString() == "incident.stream_aborted");
        Assert.True(found, "Expected incident.stream_aborted");
    }
}
