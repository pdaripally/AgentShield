using System;
using System.Collections.Generic;
using System.Text.Json;
using Xunit;

using AgentShield;

namespace AgentShield.Tests;

/// <summary>
/// Bypass-path tests for the core .NET session API used by the adapters.
/// Covers guarded calls, missing bindings, unguarded dispatch incidents,
/// parameter normalization, and streaming blocks.
/// </summary>
public class BypassPathTests
{
    private const string FixtureYaml = """
metadata:
  name: "dotnet-bypass-paths"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Guard .NET adapter tool calls."]
  forbidden: ["Leak secrets."]
resources:
  tools:
    - name: "search"
      description: "Web search."
      permission: "read_only"
""";

    private const string BlockOutputYaml = """
metadata:
  name: "dotnet-block-output"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Block confidential output."]
  forbidden: ["Leak secrets."]
output_validation:
  guard_policies:
    - name: "block-confidential"
      evaluate_when:
        - pattern: "CONFIDENTIAL"
          reason: "Output contains confidential marker."
      action: block
""";

    private sealed class CapturingProvider : IObservabilityProvider
    {
        public List<JsonElement> Events { get; } = new();
        public void OnLogEvent(JsonElement e) => Events.Add(e.Clone());
    }

    private static JsonElement Json(string raw) =>
        JsonDocument.Parse(raw).RootElement.Clone();

    private static GuardrailsRuntime BuildRuntime(
        out CapturingProvider provider,
        string yaml = FixtureYaml)
    {
        provider = new CapturingProvider();
        using var b = RuntimeBuilder.FromYamlStrings(new[] { yaml });
        b.RegisterObservabilityProvider(provider);
        return b.Build();
    }

    private static GuardrailsSession NewSession(GuardrailsRuntime rt)
    {
        var s = rt.NewSession();
        s.BeginTurn();
        return s;
    }

    // ─── 1. Guarded path: Stage-3 + Stage-4 invocation_hash ──────────

    [Fact]
    public void GuardedToolCallProducesInvocationHash()
    {
        using var rt = BuildRuntime(out _);
        using var s = NewSession(rt);

        var (callVerdict, _) = s.ValidateToolCall(
            "search",
            Json("""{"query":"hello"}"""),
            "dn_call_001");
        Assert.True(callVerdict.Allowed, "Stage 3 MUST allow the call");
        Assert.False(
            string.IsNullOrEmpty(callVerdict.InvocationHash),
            "Guarded Stage 3 MUST produce InvocationHash");

        var (outVerdict, _) = s.ValidateToolOutput(
            "search",
            Json("""{"results":["r1"]}"""),
            "dn_call_001");
        Assert.True(outVerdict.Allowed, "Stage 4 MUST allow the output");
        Assert.False(
            string.IsNullOrEmpty(outVerdict.InvocationHash),
            "Guarded Stage 4 MUST preserve InvocationHash from Stage 3");
    }

    // ─── 2. Direct Stage-4 without Stage 3: fails closed ─────────────

    [Fact]
    public void RawCallWithoutStage3FailsClosedAndHasNoHash()
    {
        using var rt = BuildRuntime(out _);
        using var s = NewSession(rt);

        var (outVerdict, _) = s.ValidateToolOutput(
            "search",
            Json("""{"results":[]}"""),
            "never_validated_id");

        Assert.False(
            outVerdict.Allowed,
            "Direct Stage 4 without Stage 3 MUST fail closed");
        Assert.Equal("<binding>", outVerdict.Policy);
        Assert.True(
            string.IsNullOrEmpty(outVerdict.InvocationHash),
            "Binding-miss deny MUST NOT carry an InvocationHash");
    }

    // ─── 3. Raw dispatch emits incident.unguarded_tool_dispatch ────────

    [Fact]
    public void RawDispatchWithoutStage3EmitsUnguardedToolDispatchIncident()
    {
        using var rt = BuildRuntime(out var provider);
        using var s = NewSession(rt);

        s.ValidateToolOutput(
            "search",
            Json("""{"results":[]}"""),
            "bypass_dn_001");

        bool found = provider.Events.Exists(e =>
            e.TryGetProperty("event_type", out var et) &&
            et.GetString() == "incident_emitted" &&
            e.TryGetProperty("event_id", out var ei) &&
            ei.GetString() == "incident.unguarded_tool_dispatch");

        Assert.True(
            found,
            "Unguarded dispatch MUST emit 'incident.unguarded_tool_dispatch'; " +
            $"events: [{string.Join(", ", provider.Events.ConvertAll(e => e.GetRawText()[..Math.Min(80, e.GetRawText().Length)]))}]");
    }

    // ─── 4. Malformed params normalize safely ─────────────────────────

    [Fact]
    public void NullParamsNormalizeToEmptyParamsAndReturnHash()
    {
        using var rt = BuildRuntime(out _);
        using var s = NewSession(rt);

        var (callVerdict, _) = s.ValidateToolCall(
            "search",
            Json("null"),
            "dn_malformed_001");

        Assert.True(callVerdict.Allowed, "null params MUST still allow the call");
        Assert.False(
            string.IsNullOrEmpty(callVerdict.InvocationHash),
            "null params MUST still produce InvocationHash");
    }

    // ─── 5. Streaming Stage-5 deny: incident.stream_aborted ───────────

    [Fact]
    public void StreamingStage5BlockEmitsStreamAbortedIncident()
    {
        using var rt = BuildRuntime(out var provider, BlockOutputYaml);
        using var s = NewSession(rt);
        using var guard = s.StreamingSession(StreamingStage.Output);

        guard.Push("This output is ");
        guard.Push("marked CONFIDENTIAL and should be blocked.");
        var result = guard.Finish();

        Assert.Equal(StreamAction.Stop, result.Action);

        bool found = provider.Events.Exists(e =>
            e.TryGetProperty("event_type", out var et) &&
            et.GetString() == "incident_emitted" &&
            e.TryGetProperty("event_id", out var ei) &&
            ei.GetString() == "incident.stream_aborted");

        Assert.True(
            found,
            "Streaming Stage-5 deny MUST emit 'incident.stream_aborted'");
    }
}
