using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using Xunit;

namespace AgentShield.Tests;

/// <summary>
/// Cross-SDK verdict-dispatch parity test.
/// Reads <c>tests/parity/verdict_dispatch_canonical.json</c> and checks
/// that .NET matches the shared dispatch fixture used by the other SDKs.
/// </summary>
public class VerdictDispatchParityTests
{
    private static readonly string RepoRoot = FindRepoRoot();
    private static readonly string CanonicalPath =
        Path.Combine(RepoRoot, "tests", "parity", "verdict_dispatch_canonical.json");

    private static string FindRepoRoot()
    {
        var dir = AppContext.BaseDirectory;
        while (dir is not null && !Directory.Exists(Path.Combine(dir, ".git")))
            dir = Path.GetDirectoryName(dir);
        return dir ?? throw new InvalidOperationException("repo root not found");
    }

    public static IEnumerable<object[]> StageCases()
    {
        if (!File.Exists(CanonicalPath)) yield break;
        using var doc = JsonDocument.Parse(File.ReadAllText(CanonicalPath));
        foreach (var c in doc.RootElement.GetProperty("stage_cases").EnumerateArray())
        {
            yield return new object[] { c.GetRawText() };
        }
    }

    public static IEnumerable<object[]> ToolCases()
    {
        if (!File.Exists(CanonicalPath)) yield break;
        using var doc = JsonDocument.Parse(File.ReadAllText(CanonicalPath));
        foreach (var c in doc.RootElement.GetProperty("tool_cases").EnumerateArray())
        {
            yield return new object[] { c.GetRawText() };
        }
    }

    private static StageVerdict ParseVerdict(JsonElement v)
    {
        return StageVerdict.FromJson(v.GetRawText());
    }

    private static OnBlockPolicy ParsePolicy(string s) => s switch
    {
        "return_blocked" => OnBlockPolicy.ReturnBlocked,
        "return_verdict" => OnBlockPolicy.ReturnVerdict,
        "raise" => OnBlockPolicy.Raise,
        // The .NET enum doesn't expose a Custom variant; we represent
        // it as the int code 3 by passing through the raw FFI shape.
        // For test cases that use "custom", we treat it as ReturnBlocked
        // upstream and override the policy here.
        "custom" => (OnBlockPolicy)3,
        _ => throw new ArgumentException($"unknown policy: {s}"),
    };

    private static ShieldMode ParseMode(string s) => s switch
    {
        "enforce" => ShieldMode.Enforce,
        "monitor" => ShieldMode.Monitor,
        _ => throw new ArgumentException($"unknown mode: {s}"),
    };

    private static ToolStage ParseStage(string s) => s switch
    {
        "call" => ToolStage.Call,
        "output" => ToolStage.Output,
        _ => throw new ArgumentException($"unknown stage: {s}"),
    };

    [Theory]
    [MemberData(nameof(StageCases))]
    public void Stage_Dispatch_Matches_Canonical(string caseJson)
    {
        using var doc = JsonDocument.Parse(caseJson);
        var c = doc.RootElement;
        var verdict = ParseVerdict(c.GetProperty("verdict"));
        var policy = ParsePolicy(c.GetProperty("policy").GetString()!);
        var mode = ParseMode(c.GetProperty("mode").GetString()!);
        var name = c.GetProperty("name").GetString();

        var actual = VerdictDispatcher.DispatchStage(verdict, policy, mode);
        var expected = c.GetProperty("expected");

        var expectedAction = expected.GetProperty("action");
        Assert.Equal(expectedAction.GetProperty("kind").GetString(), actual.Action.Kind);
        if (expectedAction.TryGetProperty("message", out var msg))
        {
            Assert.Equal(msg.GetString(), actual.Action.Message);
        }
        if (expectedAction.TryGetProperty("value", out var val))
        {
            Assert.Equal(val.GetString(), actual.Action.Value);
        }
        Assert.Equal(expected.GetProperty("record_block").GetBoolean(), actual.RecordBlock);
        Assert.Equal(
            expected.GetProperty("override_to_proceed").GetBoolean(),
            actual.OverrideToProceed);
    }

    [Theory]
    [MemberData(nameof(ToolCases))]
    public void Tool_Dispatch_Matches_Canonical(string caseJson)
    {
        using var doc = JsonDocument.Parse(caseJson);
        var c = doc.RootElement;
        var verdict = ParseVerdict(c.GetProperty("verdict"));
        var toolName = c.GetProperty("tool_name").GetString()!;
        var stage = ParseStage(c.GetProperty("stage").GetString()!);
        var policy = ParsePolicy(c.GetProperty("policy").GetString()!);
        var mode = ParseMode(c.GetProperty("mode").GetString()!);

        var actual = VerdictDispatcher.DispatchTool(verdict, toolName, stage, policy, mode);
        var expected = c.GetProperty("expected");

        var expectedAction = expected.GetProperty("action");
        Assert.Equal(expectedAction.GetProperty("kind").GetString(), actual.Action.Kind);
        if (expectedAction.TryGetProperty("message", out var msg))
        {
            Assert.Equal(msg.GetString(), actual.Action.Message);
        }
        if (expectedAction.TryGetProperty("value", out var val))
        {
            Assert.Equal(val.GetString(), actual.Action.Value);
        }
        Assert.Equal(expected.GetProperty("record_failure").GetBoolean(), actual.RecordFailure);
        Assert.Equal(expected.GetProperty("record_success").GetBoolean(), actual.RecordSuccess);
        Assert.Equal(
            expected.GetProperty("override_to_proceed").GetBoolean(),
            actual.OverrideToProceed);
    }
}
