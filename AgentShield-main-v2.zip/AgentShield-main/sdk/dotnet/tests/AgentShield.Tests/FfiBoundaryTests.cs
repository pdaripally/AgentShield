using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Xunit;

using AgentShield;
using AgentShield.Interop;

namespace AgentShield.Tests;

/// <summary>
/// FFI boundary tests: validates correctness at the .NET↔Rust P/Invoke layer.
/// Covers: UTF-8 edge cases, concurrency, large payloads, error propagation.
/// </summary>
[Trait("Category", "FFI")]
public class FfiBoundaryTests
{
    private const int OneMegabyte = 1024 * 1024;

    private const string FixtureYaml = """
metadata:
  name: "ffi-boundary"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["exercise ffi boundary"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "ffi_echo"
      description: "ffi boundary echo tool"
      permission: "read_only"
variables:
  - name: "ffi_value"
    type: "string"
    default: ""
""";

    private static readonly bool NativeAvailable = CheckNativeAvailable();
    private static readonly string? NativeSkipReason = NativeAvailable ? null : "Native library not available";

    private static bool CheckNativeAvailable()
    {
        try
        {
            using var builder = RuntimeBuilder.FromConfigText(FixtureYaml);
            using var runtime = builder.Build();
            return true;
        }
        catch (DllNotFoundException) { return false; }
        catch (TypeInitializationException) { return false; }
    }

    private static GuardrailsRuntime BuildRuntime()
    {
        Assert.True(NativeAvailable, NativeSkipReason ?? "Native library check failed");
        using var builder = RuntimeBuilder.FromConfigText(FixtureYaml);
        return builder.Build();
    }

    private static JsonElement Json(string json) =>
        JsonDocument.Parse(json).RootElement.Clone();

    private static JsonElement JsonValue<T>(T value) =>
        JsonSerializer.SerializeToElement(value);

    private static string BuildDeeplyNestedInvalidInvocationJson()
    {
        var sb = new StringBuilder(300_000);
        sb.Append("{\"kind\":\"tool\",\"name\":\"ffi_echo\",\"params\":");
        for (var i = 0; i < 512; i++)
            sb.Append("{\"nested\":");

        sb.Append('"');
        sb.Append(new string('x', 256 * 1024));
        return sb.ToString();
    }

    private static string BuildVeryLongInvalidInvocationJson() =>
        "{\"kind\":\"tool\",\"name\":\"ffi_echo\",\"params\":{\"payload\":\"" +
        new string('y', OneMegabyte) +
        "\"";

    public static IEnumerable<object[]> PathologicalInvocationPayloads()
    {
        yield return new object[] { "deep-nesting", BuildDeeplyNestedInvalidInvocationJson() };
        yield return new object[] { "very-long-string", BuildVeryLongInvalidInvocationJson() };
    }

    private static JsonElement BuildLargeJsonObject()
    {
        var payload = Enumerable.Range(0, 2048)
            .ToDictionary(i => $"key_{i:D4}", _ => new string('x', 512));

        var bytes = JsonSerializer.SerializeToUtf8Bytes(payload);
        Assert.True(bytes.Length >= OneMegabyte, $"expected at least 1 MiB, got {bytes.Length} bytes");
        using var doc = JsonDocument.Parse(bytes);
        return doc.RootElement.Clone();
    }

    [Fact]
    public void ValidateToolCall_EmbeddedNulInToolName_HandlesGracefully()
    {
        using var runtime = BuildRuntime();
        using var session = runtime.NewSession();

        var (verdict, mutated) = session.ValidateToolCall(
            "ffi_echo\0suffix",
            JsonValue(new Dictionary<string, string> { ["payload"] = "ok" }),
            "ffi-nul-tool");

        Assert.True(verdict.Allowed);
        Assert.Equal("ok", mutated.GetProperty("payload").GetString());
    }

    [Fact]
    public void SetVariable_FourByteEmoji_RoundTripsCorrectly()
    {
        using var runtime = BuildRuntime();
        using var session = runtime.NewSession();

        const string emoji = "🛡️";
        session.SetVariable("ffi_value", JsonValue(emoji));

        var state = session.ReadVariable("ffi_value");
        Assert.NotNull(state);
        Assert.Equal(emoji, state!.Value.GetString());
    }

    [Fact]
    public void ValidateInput_EmptyString_IsHandledWithoutNull()
    {
        using var runtime = BuildRuntime();
        using var session = runtime.NewSession();

        var verdict = session.ValidateInput(string.Empty);

        Assert.NotNull(verdict);
        Assert.True(verdict.Allowed);
    }

    [Fact]
    public void ValidateToolCall_OneMegabyteStringValue_ReturnsCorrectVerdict()
    {
        using var runtime = BuildRuntime();
        using var session = runtime.NewSession();

        var payload = new string('a', OneMegabyte);
        var (verdict, mutated) = session.ValidateToolCall(
            "ffi_echo",
            JsonValue(new Dictionary<string, string> { ["payload"] = payload }),
            "ffi-1mb-string");

        Assert.True(verdict.Allowed);
        Assert.Equal(payload.Length, mutated.GetProperty("payload").GetString()!.Length);
    }

    [Theory]
    [MemberData(nameof(PathologicalInvocationPayloads))]
    public void PathologicalNativeInput_ThrowsManagedException_InsteadOfCrashing(string scenario, string payload)
    {
        using var runtime = BuildRuntime();
        using var session = runtime.NewSession();

        var ex = Assert.Throws<ShieldNativeException>(() =>
            session.ValidateState(payload));

        Assert.False(string.IsNullOrWhiteSpace(ex.Message));

        var (verdict, _) = session.ValidateToolCall(
            "ffi_echo",
            Json("{\"payload\":\"still-alive\"}"),
            $"ffi-after-native-error-{scenario}");

        Assert.True(verdict.Allowed);
    }

    [Fact]
    public async Task ValidateToolCall_TaskWhenAllAcrossSessions_RemainsConsistent()
    {
        using var runtime = BuildRuntime();

        var tasks = Enumerable.Range(0, 4).Select(taskIndex => Task.Run(() =>
        {
            using var session = runtime.NewSession();
            var expected = $"task-{taskIndex}";
            var parameters = JsonValue(new Dictionary<string, string> { ["payload"] = expected });

            for (var iteration = 0; iteration < 10_000; iteration++)
            {
                var (verdict, mutated) = session.ValidateToolCall(
                    "ffi_echo",
                    parameters,
                    $"ffi-concurrency-{taskIndex}-{iteration}");

                Assert.True(verdict.Allowed);
                Assert.Equal(expected, mutated.GetProperty("payload").GetString());
            }
        }));

        await Task.WhenAll(tasks);
    }

    [Fact]
    public void ValidateToolCall_OneMegabyteJsonObject_ReturnsCorrectVerdict()
    {
        using var runtime = BuildRuntime();
        using var session = runtime.NewSession();

        var parameters = BuildLargeJsonObject();
        var (verdict, mutated) = session.ValidateToolCall("ffi_echo", parameters, "ffi-1mb-object");

        Assert.True(verdict.Allowed);
        Assert.Equal(new string('x', 512), mutated.GetProperty("key_0000").GetString());
        Assert.True(Encoding.UTF8.GetByteCount(mutated.GetRawText()) >= OneMegabyte);
    }
}
