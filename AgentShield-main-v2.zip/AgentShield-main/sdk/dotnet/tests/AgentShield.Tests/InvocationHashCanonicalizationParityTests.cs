using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using Xunit;

using AgentShield;

namespace AgentShield.Tests;

public class InvocationHashCanonicalizationParityTests
{
    private static readonly string RepoRoot = FindRepoRoot();
    private static readonly string FixturePath =
        Path.Combine(RepoRoot, "tests", "parity", "invocation_hash_canonicalization.json");

    private static string FindRepoRoot()
    {
        var dir = AppContext.BaseDirectory;
        while (dir is not null && !Directory.Exists(Path.Combine(dir, ".git")))
            dir = Path.GetDirectoryName(dir);
        return dir ?? throw new InvalidOperationException("repo root not found");
    }

    public static IEnumerable<object[]> Cases()
    {
        if (!File.Exists(FixturePath))
            throw new FileNotFoundException($"Missing parity fixture: {FixturePath}");

        var fixtureJson = File.ReadAllText(FixturePath);
        if (string.IsNullOrWhiteSpace(fixtureJson))
            throw new InvalidOperationException($"Parity fixture is empty: {FixturePath}");

        using var doc = JsonDocument.Parse(fixtureJson);
        var cases = new List<object[]>();
        foreach (var c in doc.RootElement.GetProperty("cases").EnumerateArray())
            cases.Add(new object[] { c.GetRawText() });

        if (cases.Count == 0)
            throw new InvalidOperationException($"No cases found in parity fixture: {FixturePath}");

        return cases;
    }

    private static JsonElement Json(string raw) => JsonDocument.Parse(raw).RootElement.Clone();

    [Theory]
    [MemberData(nameof(Cases))]
    public void ValidateToolCall_MatchesCanonicalHashes(string caseJson)
    {
        using var doc = JsonDocument.Parse(caseJson);
        var c = doc.RootElement;
        var path = Path.Combine(RepoRoot, c.GetProperty("fixture").GetString()!);
        using var runtime = GuardrailsRuntime.FromYaml(path);
        using var session = runtime.NewSession();
        session.BeginTurn();

        var (verdict, mutated) = session.ValidateToolCall(
            c.GetProperty("tool_name").GetString()!,
            Json(c.GetProperty("params").GetRawText()),
            c.GetProperty("tool_call_id").GetString()!);
        var expected = c.GetProperty("expected");

        Assert.True(verdict.Allowed);
        Assert.Equal(expected.GetProperty("invocation_hash").GetString(), verdict.InvocationHash);
        Assert.Equal(
            expected.GetProperty("post_validation_invocation_hash").GetString(),
            verdict.PostValidationInvocationHash);
        if (expected.TryGetProperty("effective_params", out var effective))
            Assert.Equal(
                JsonSerializer.Serialize(effective),
                JsonSerializer.Serialize(mutated));
    }
}
