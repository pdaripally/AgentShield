// Agent Shield — .NET no-PII sentinel test (PR1 SKELETON).
//
// ## Status: SKELETON — `[Fact(Skip = "...")]`-marked.
//
// Per docs/logging-style-guide.md Rule 7, the .NET SDK has zero
// `_logger.Log*` call sites in production code as of v0.13.0-alpha.1 —
// operational state goes through `IObservabilityProvider` callbacks.
// This skeleton therefore has TWO purposes that diverge slightly from
// the Rust + Python sentinels:
//
//   1. Forward-looking: assert that no `_logger.Log*` info+ calls leak
//      sentinels in the SDK's production source. Today this is
//      vacuously true; if a future contributor adds a `_logger.Log*`
//      call, this test catches the leak.
//
//   2. Provider-side: a `IObservabilityProvider` registered by the
//      adopter is the OFFICIAL surface for SDK telemetry. We assert
//      that none of the canonical event types ever carry a sentinel
//      value in attributes — this is the contract that PR4's
//      logging-parity test will tighten further.
//
// ## Deviation from v3 brief PR1
//
// v3 brief PR1 said: *"Skeletons committed RED is INTENTIONAL — DO
// NOT skip/xfail them."* That is wrong; landing RED tests violates
// the green-CI invariant. This skeleton lands `[Fact(Skip = "...")]`;
// PR3 removes the Skip in the same commit that ships the .NET-side
// PII work. Documented per /memories/repo/stacked-pr-workflow.md.

using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace AgentShield.Tests;

public class NoPiiSentinelTests
{
    // Distinctive low-collision sentinels — same constants as
    // sdk/rust/agent_shield_core/tests/no_pii_sentinel.rs and
    // sdk/python/tests/test_no_pii_sentinel.py.
    private const string SentinelUserInput  = "SENTINEL_PII_USER_INPUT_xZk2";
    private const string SentinelToolArgs   = "SENTINEL_PII_TOOL_ARGS_8mNQ";
    private const string SentinelToolResult = "SENTINEL_PII_TOOL_RESULT_v3pL";
    private const string SentinelVarValue   = "SENTINEL_PII_VAR_VALUE_R7tF";

    private static readonly string[] AllSentinels =
    {
        SentinelUserInput, SentinelToolArgs, SentinelToolResult, SentinelVarValue,
    };

    /// <summary>
    /// Forward-looking sentinel: assert no `_logger.Log*` info+ call
    /// in `sdk/dotnet/src/AgentShield/` includes a sensitive identifier.
    /// As of v0.13.0-alpha.1 there are zero such calls; this is a
    /// guard against a future contributor adding one with a leak.
    ///
    /// Today this test is asserting "the lint pass agrees with the
    /// runtime test that there's nothing here." When PR3 lands real
    /// .NET PII work, the Skip is removed and the assertion meaningfully
    /// runs against actual code.
    /// </summary>
    [Fact(Skip = "PR1 skeleton — unblocks when PR3 (fix/pii-python-dotnet) lands; documents the contract")]
    public void NoPiiInInfoLogsDuringFullTurn()
    {
        // Smoke-shape only; the runtime drive logic lives in PR3.
        // PR3 will fill this in mirroring the Rust + Python sentinels:
        //   1. Build runtime from minimal_yaml().
        //   2. Open session, begin_turn.
        //   3. Drive validate_input / validate_tool_call /
        //      record_tool_failure / validate_output with sentinel
        //      strings.
        //   4. Capture every event emitted via IObservabilityProvider.
        //   5. Assert no captured event's serialized form contains
        //      any sentinel.
        var captured = new List<string>(); // populated in PR3
        AssertNoSentinel(captured);
    }

    /// <summary>
    /// Provider-side sentinel: assert that the canonical event surface
    /// (IObservabilityProvider.Emit) never receives an event whose
    /// serialized payload contains a sentinel value.
    /// </summary>
    [Fact(Skip = "PR1 skeleton — unblocks when PR3 (fix/pii-python-dotnet) lands; documents the contract")]
    public void NoPiiInProviderEmissionsDuringSwallowPaths()
    {
        var captured = new List<string>(); // populated in PR3
        AssertNoSentinel(captured);
    }

    private static void AssertNoSentinel(IEnumerable<string> captured)
    {
        foreach (var line in captured)
        {
            foreach (var sentinel in AllSentinels)
            {
                Assert.False(
                    line.Contains(sentinel, StringComparison.Ordinal),
                    $"sentinel '{sentinel}' leaked: {line}"
                );
            }
        }
    }
}
