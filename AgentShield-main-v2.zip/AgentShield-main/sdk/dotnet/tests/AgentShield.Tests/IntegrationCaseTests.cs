/// <summary>
/// Cross-language integration test runner for Agent Shield (.NET).
///
/// Loads shared YAML test cases from tests/cases/ and shared fixtures from
/// tests/fixtures/, then runs each test case against the .NET runtime
/// surface (RuntimeBuilder / GuardrailsRuntime / GuardrailsSession).
///
/// Mirrors the Python runner (sdk/python/tests/test_integration_cases.py) and the Rust runner
/// (sdk/rust/agent_shield_core/tests/integration_cases.rs) to verify cross-language
/// behavioral parity.
/// </summary>

using System.Collections.Concurrent;
using System.Diagnostics;
using System.Text.Json;
using System.Text.Json.Serialization;
using AgentShield;
using Xunit;
using Xunit.Abstractions;
using Xunit.Sdk;
using YamlDotNet.RepresentationModel;

namespace AgentShield.Tests;

public class IntegrationCaseTests : IClassFixture<IntegrationCaseReportFixture>
{
    private readonly ITestOutputHelper _output;

    public IntegrationCaseTests(ITestOutputHelper output, IntegrationCaseReportFixture _)
    {
        _output = output;
    }

    // ── Path resolution ────────────────────────────────────────────

    private static string RepoRoot
    {
        get
        {
            // Walk up from bin/Debug/net8.0 → tests → dotnet → sdk → repo root
            var dir = AppContext.BaseDirectory;
            while (dir != null && !Directory.Exists(Path.Combine(dir, "tests", "cases")))
                dir = Directory.GetParent(dir)?.FullName;
            return dir ?? throw new DirectoryNotFoundException(
                "Could not find repo root (expected tests/cases/ directory)");
        }
    }

    private static string CasesDir => Path.Combine(RepoRoot, "tests", "cases");
    private static string FixturesDir => Path.Combine(RepoRoot, "tests", "fixtures");

    private static string? FindFixture(string name)
    {
        // Try direct relative path first
        var direct = Path.Combine(FixturesDir, name);
        if (File.Exists(direct)) return direct;

        // Fallback: search subdirectories by leaf filename
        var leaf = Path.GetFileName(name);
        if (Directory.Exists(FixturesDir))
        {
            foreach (var subdir in Directory.GetDirectories(FixturesDir))
            {
                var candidate = Path.Combine(subdir, leaf);
                if (File.Exists(candidate)) return candidate;
            }
        }

        // Fixture not present in the working tree — return null so the test
        // skips cleanly. This keeps the runner robust to the cross-language
        // harness rewrites that periodically reorganize tests/fixtures.
        return null;
    }

    // ── YAML loading ───────────────────────────────────────────────

    public static IEnumerable<object[]> LoadAllCases()
    {
        foreach (var yamlFile in Directory.GetFiles(CasesDir, "*.cases.yaml", SearchOption.AllDirectories).OrderBy(f => f))
        {
            using var reader = new StreamReader(yamlFile);
            var yaml = new YamlStream();
            yaml.Load(reader);

            var root = (YamlMappingNode)yaml.Documents[0].RootNode;
            var suiteName = GetScalar(root, "suite") ?? Path.GetFileNameWithoutExtension(yamlFile);

            var casesNode = root.Children.ContainsKey("cases")
                ? (YamlSequenceNode)root["cases"]
                : null;
            if (casesNode == null) continue;

            // Suite-level fixture defaults
            var suiteFixture = GetScalar(root, "fixture");
            var suiteFixtures = GetStringList(root, "fixtures");

            foreach (YamlMappingNode caseNode in casesNode)
            {
                var caseName = GetScalar(caseNode, "name") ?? "unnamed";
                var caseId = $"{suiteName}::{caseName}";
                yield return new object[] { suiteName, caseName, caseId, caseNode, suiteFixture!, suiteFixtures! };
            }
        }
    }

    // ── The parametrized test ──────────────────────────────────────

    [Theory]
    [MemberData(nameof(LoadAllCases))]
    public void SharedCase(string suiteName, string caseName, string caseId, YamlMappingNode caseNode,
        string? suiteFixture, List<string>? suiteFixtures)
    {
        _output.WriteLine($"Running: {caseId}");

        var stopwatch = Stopwatch.StartNew();
        var status = "pass";
        string? errorDetail = null;
        var isXfail = TryGetDotnetXfail(caseNode, out var xfailDetail);

        try
        {
            if (IsOptionalForDotnet(caseNode))
            {
                status = "skip";
                errorDetail = "sdk_support.dotnet is optional";
                _output.WriteLine($"SKIP: Optional for dotnet: {caseId}");
                return;
            }

            var fixtures = ResolveFixtures(caseNode, suiteFixture, suiteFixtures);
            if (fixtures.Count == 0)
            {
                status = "skip";
                errorDetail = $"No fixtures for {caseId}";
                _output.WriteLine($"SKIP: No fixtures for {caseId}");
                return;
            }

            var expectedLoadErrorNode = GetExpectedLoadErrorNode(caseNode);
            var expectsAnyLoadError = string.Equals((expectedLoadErrorNode as YamlScalarNode)?.Value, "true", StringComparison.OrdinalIgnoreCase);
            var expectedLoadError = expectsAnyLoadError ? null : (expectedLoadErrorNode as YamlScalarNode)?.Value;
            var loadOnly = string.Equals(GetScalar(GetMapping(caseNode, "when") ?? new YamlMappingNode(), "action"), "load_config", StringComparison.Ordinal);

            GuardrailsRuntime? rt = null;
            try
            {
                rt = CreateRuntime(fixtures);
            }
            catch (Exception ex)
            {
                if (expectsAnyLoadError)
                    return;
                if (!string.IsNullOrEmpty(expectedLoadError))
                {
                    Assert.Contains(expectedLoadError, ex.ToString(), StringComparison.OrdinalIgnoreCase);
                    return;
                }

                throw;
            }

            if (expectsAnyLoadError)
            {
                if (!isXfail)
                    throw new XunitException($"[{caseId}] expected load error, but runtime loaded successfully");
                status = "xfail";
                return;
            }
            if (!string.IsNullOrEmpty(expectedLoadError))
            {
                if (!isXfail)
                    throw new XunitException($"[{caseId}] expected load error containing '{expectedLoadError}', but runtime loaded successfully");
                status = "xfail";
                return;
            }

            using var runtime = rt!;
            if (loadOnly)
                return;
            using var session = runtime.NewSession();

            try { session.BeginRequest(); } catch { }
            try { session.BeginTurn(); } catch { }

            var given = GetMapping(caseNode, "given");
            if (given != null)
            {
                var vars = GetMapping(given, "variables") ?? GetMapping(given, "attributes");
                if (vars != null)
                {
                    foreach (var kv in vars.Children)
                    {
                        var name = ((YamlScalarNode)kv.Key).Value!;
                        var value = YamlToObject(kv.Value);
                        session.SetVariable(name, ToJsonElement(value));
                    }
                }
            }

            if (caseNode.Children.ContainsKey("when") && caseNode.Children.ContainsKey("then"))
            {
                var when = (YamlMappingNode)caseNode["when"];
                var singleThen = (YamlMappingNode)caseNode["then"];
                var result = ExecuteAction(session, when);
                CheckAssertions(result, singleThen, caseId);
                return;
            }

            if (caseNode.Children.ContainsKey("steps"))
            {
                var steps = (YamlSequenceNode)caseNode["steps"];
                for (var i = 0; i < steps.Children.Count; i++)
                {
                    var step = (YamlMappingNode)steps[i];
                    var stepName = $"{caseId}[step {i}]";
                    var when = (YamlMappingNode)step["when"];
                    var result = ExecuteAction(session, when);

                    if (step.Children.ContainsKey("then"))
                    {
                        var stepThen = (YamlMappingNode)step["then"];
                        CheckAssertions(result, stepThen, stepName);
                    }
                }
            }
        }
        catch (UnknownActionException ex)
        {
            status = "unknown_action";
            errorDetail = ex.Message;
            _output.WriteLine($"UNKNOWN_ACTION: {ex.Message}");
        }
        catch (XunitException ex)
        {
            status = isXfail ? "xfail" : "fail";
            errorDetail = isXfail && !string.IsNullOrWhiteSpace(xfailDetail)
                ? $"{xfailDetail}{Environment.NewLine}{ex}"
                : ex.ToString();
            if (!isXfail) throw;
        }
        catch (Exception ex)
        {
            status = isXfail ? "xfail" : "error";
            errorDetail = isXfail && !string.IsNullOrWhiteSpace(xfailDetail)
                ? $"{xfailDetail}{Environment.NewLine}{ex}"
                : ex.ToString();
            if (!isXfail) throw;
        }
        finally
        {
            stopwatch.Stop();
            IntegrationCaseJsonReporter.Record(new IntegrationCaseResult(
                suiteName,
                caseName,
                status,
                stopwatch.Elapsed.TotalMilliseconds,
                errorDetail));
        }
    }

    // ── Fixture resolution ─────────────────────────────────────────

    private static List<string> ResolveFixtures(YamlMappingNode caseNode,
        string? suiteFixture, List<string>? suiteFixtures)
    {
        var given = GetMapping(caseNode, "given");

        // Case-level fixtures override suite-level
        var fixtureNames = given != null ? GetStringList(given, "fixtures") : null;

        if (fixtureNames == null || fixtureNames.Count == 0)
        {
            if (suiteFixtures != null && suiteFixtures.Count > 0)
            {
                fixtureNames = suiteFixtures;
            }
            else if (suiteFixture != null)
            {
                // Auto-discover *.guardrails.yaml in the suite fixture directory
                var scenarioDir = Path.Combine(FixturesDir, suiteFixture);
                if (Directory.Exists(scenarioDir))
                {
                    fixtureNames = Directory.GetFiles(scenarioDir, "*.guardrails.yaml")
                        .OrderBy(f => f)
                        .Select(Path.GetFileName)
                        .ToList()!;
                }
            }
        }

        if (fixtureNames == null) return new List<string>();
        var resolved = new List<string>();
        foreach (var name in fixtureNames)
        {
            var path = FindFixture(name);
            if (path == null) return new List<string>(); // any missing fixture → skip whole case
            resolved.Add(path);
        }
        return resolved;
    }

    private static YamlNode? GetExpectedLoadErrorNode(YamlMappingNode caseNode)
    {
        var then = GetMapping(caseNode, "then");
        if (then != null && then.Children.ContainsKey("expect_load_error"))
            return then["expect_load_error"];

        if (!caseNode.Children.ContainsKey("steps") || caseNode["steps"] is not YamlSequenceNode steps)
            return null;

        foreach (var child in steps.Children.OfType<YamlMappingNode>())
        {
            var expected = GetMapping(child, "then") ?? GetMapping(child, "expected");
            if (expected != null && expected.Children.ContainsKey("expect_load_error"))
                return expected["expect_load_error"];
        }

        return null;
    }

    private static bool IsOptionalForDotnet(YamlMappingNode caseNode)
    {
        var support = GetMapping(caseNode, "sdk_support");
        var dotnetSupport = support != null ? GetScalar(support, "dotnet") : null;
        return string.Equals(dotnetSupport, "optional", StringComparison.OrdinalIgnoreCase);
    }

    private static bool TryGetDotnetXfail(YamlMappingNode caseNode, out string? detail)
    {
        detail = null;
        var xfail = GetMapping(caseNode, "xfail");
        var dotnet = xfail != null ? GetMapping(xfail, "dotnet") : null;
        if (dotnet == null)
            return false;

        var issue = GetScalar(dotnet, "issue");
        var reason = GetScalar(dotnet, "reason");
        detail = string.Join("; ", new[]
        {
            !string.IsNullOrWhiteSpace(issue) ? $"issue={issue}" : null,
            !string.IsNullOrWhiteSpace(reason) ? $"reason={reason}" : null,
        }.Where(value => value != null)!);
        return true;
    }

    private static GuardrailsRuntime CreateRuntime(List<string> paths)
    {
        var builder = paths.Count == 1
            ? RuntimeBuilder.FromYaml(paths[0])
            : RuntimeBuilder.FromYamlChain(paths);
        try
        {
            // Default-allow LLM and classifier callers so guard policies
            // that use `llm:` or `classifier:` detection don't fail-closed
            // for lack of a registered caller. Mirrors the Python harness.
            builder.RegisterLlmCaller(new AllowLlmCaller());
            builder.RegisterClassifierCaller(new AllowClassifierCaller());
            return builder.Build();
        }
        catch
        {
            builder.Dispose();
            throw;
        }
    }

    private sealed class AllowLlmCaller : ILlmCaller
    {
        public LlmResponse Call(LlmRequest request) => LlmResponse.Allow();
    }

    private sealed class AllowClassifierCaller : IClassifierCaller
    {
        public ClassifierVerdict Call(LlmRequest request) =>
            new(Score: 0.0, Threshold: 0.5, Flagged: false);
    }

    // ── Action execution ───────────────────────────────────────────

    private object? ExecuteAction(GuardrailsSession session, YamlMappingNode when)
    {
        var actionType = GetScalar(when, "action") ?? GetScalar(when, "type")
            ?? throw new InvalidOperationException("No action type in 'when' block");
        var paramsNode = GetMapping(when, "params");

        switch (actionType)
        {
            case "validate_input":
            {
                var text = GetScalar(when, "input") ?? GetScalarFromParams(paramsNode, "input") ?? "";
                return session.ValidateInput(text);
            }
            case "validate_tool_call":
            {
                var toolName = GetScalar(when, "tool_name") ?? GetScalarFromParams(paramsNode, "tool_name") ?? "";
                var toolParams = GetDictFromParams(paramsNode, "tool_params")
                    ?? YamlToDict(GetMapping(when, "tool_params"));
                var toolCallId = GetScalar(when, "tool_call_id")
                    ?? GetScalarFromParams(paramsNode, "tool_call_id")
                    ?? "case_invocation";
                var (verdict, _) = session.ValidateToolCall(toolName, ToJsonElement(toolParams), toolCallId);
                return verdict;
            }
            case "validate_endpoint_call":
            {
                var url = GetScalar(when, "url") ?? GetScalar(when, "path")
                    ?? GetScalarFromParams(paramsNode, "path")
                    ?? GetScalarFromParams(paramsNode, "url") ?? "";
                var method = GetScalar(when, "method") ?? GetScalarFromParams(paramsNode, "method") ?? "GET";
                var queryParams = GetDictFromParams(paramsNode, "query_params");
                var toolCallId = GetScalar(when, "tool_call_id")
                    ?? GetScalarFromParams(paramsNode, "tool_call_id")
                    ?? "case_invocation";
                var (verdict, _) = session.ValidateEndpointCall(method, url, ToJsonElement(queryParams), toolCallId);
                return verdict;
            }
            case "validate_output":
            {
                var text = GetScalar(when, "output") ?? GetScalarFromParams(paramsNode, "output") ?? "";
                var (verdict, response) = session.ValidateOutput(text);
                return new OutputCarrier(verdict, response);
            }
            case "validate_tool_output":
            {
                var toolName = GetScalar(when, "tool_name") ?? GetScalarFromParams(paramsNode, "tool_name") ?? "unknown_tool";
                var text = GetScalar(when, "output") ?? GetScalarFromParams(paramsNode, "output") ?? "";
                var toolCallId = GetScalar(when, "tool_call_id")
                    ?? GetScalarFromParams(paramsNode, "tool_call_id")
                    ?? "case_invocation";
                // §16.0 fallback: attempt Stage 4 directly first. If a
                // paired Stage 3 step already bound the invocation, that
                // is the expected path. Otherwise transparently emit a
                // Stage 3 admit so the cross-language case continues to
                // exercise Stage 4 policy logic rather than the
                // binding-missing fail-closed path.
                var (verdict, mutated) = session.ValidateToolOutput(toolName, ToJsonElement(text), toolCallId);
                if (!verdict.Allowed && verdict.Policy == "<binding>")
                {
                    var prebindParams = GetDictFromParams(paramsNode, "tool_params")
                        ?? YamlToDict(GetMapping(when, "tool_params"))
                        ?? new Dictionary<string, object?>();
                    session.ValidateToolCall(toolName, ToJsonElement(prebindParams), toolCallId);
                    (verdict, mutated) = session.ValidateToolOutput(toolName, ToJsonElement(text), toolCallId);
                }
                // Tool output may be either a JSON string element or a primitive — surface
                // the textual representation for redaction-style assertions.
                var textOut = mutated.ValueKind == JsonValueKind.String
                    ? mutated.GetString() ?? ""
                    : mutated.GetRawText();
                return new OutputCarrier(verdict, textOut);
            }
            case "set_attribute":
            case "set_variable":
            {
                var name = GetScalar(when, "name") ?? GetScalarFromParams(paramsNode, "name") ?? "";
                var value = GetValueFromParams(paramsNode, "value") ?? YamlToObject(when.Children.ContainsKey("value") ? when["value"] : new YamlScalarNode(""));
                session.SetVariable(name, ToJsonElement(value));
                return null;
            }
            case "reset_variable":
            {
                var name = GetScalar(when, "name") ?? GetScalarFromParams(paramsNode, "name") ?? "";
                session.ResetVariable(name);
                return null;
            }
            case "emit_event":
            {
                var eventId = GetScalar(when, "event") ?? GetScalar(when, "event_id") ?? GetScalar(when, "id")
                    ?? GetScalarFromParams(paramsNode, "event")
                    ?? GetScalarFromParams(paramsNode, "event_id")
                    ?? GetScalarFromParams(paramsNode, "id") ?? "";
                Lifetime? lifetime = null;
                if (paramsNode != null && paramsNode.Children.ContainsKey("lifetime"))
                {
                    var ltObj = YamlToObject(paramsNode["lifetime"]);
                    if (ltObj is string ltStr)
                    {
                        lifetime = Lifetime.FromJson(JsonSerializer.Serialize(ltStr));
                    }
                    else if (ltObj != null)
                    {
                        lifetime = Lifetime.FromJson(JsonSerializer.Serialize(ltObj));
                    }
                }
                session.EmitEvent(eventId, lifetime);
                return null;
            }
            case "clear_event":
            {
                var eventId = GetScalar(when, "event") ?? GetScalar(when, "event_id") ?? GetScalar(when, "id")
                    ?? GetScalarFromParams(paramsNode, "event")
                    ?? GetScalarFromParams(paramsNode, "event_id")
                    ?? GetScalarFromParams(paramsNode, "id") ?? "";
                session.ClearEvent(eventId);
                return null;
            }
            case "emit_incident":
            {
                var name = GetScalar(when, "name") ?? GetScalarFromParams(paramsNode, "name") ?? "";
                session.EmitIncident(name);
                return null;
            }
            case "begin_turn":
            {
                session.BeginTurn();
                return null;
            }
            case "end_turn":
            {
                session.EndTurn();
                return null;
            }
            case "begin_request":
            {
                session.BeginRequest();
                return null;
            }
            case "end_request":
            {
                session.EndRequest();
                return null;
            }
            case "get_active_states":
            {
                // Active states are not exposed on the .NET surface;
                // skip silently so the case is a no-op rather than a
                // failure.
                _output.WriteLine($"SKIP: get_active_states (not on .NET surface)");
                return null;
            }
            case "load_config":
                return null;
            case "resolve_variable":
            {
                var name = GetScalar(when, "name") ?? GetScalarFromParams(paramsNode, "name") ?? "";
                var result = session.ResolveVariable(name);
                return result;
            }
            case "record_tool_success":
            {
                var toolName = GetScalar(when, "tool_name") ?? GetScalarFromParams(paramsNode, "tool_name") ?? "";
                var resultVal = GetValueFromParams(paramsNode, "result") ?? YamlToObject(
                    when.Children.ContainsKey("result") ? when["result"] : new YamlScalarNode(""));
                session.RecordToolSuccess(toolName, ToJsonElement(resultVal));
                return null;
            }
            case "record_tool_failure":
            {
                var toolName = GetScalar(when, "tool_name") ?? GetScalarFromParams(paramsNode, "tool_name") ?? "";
                var error = GetScalar(when, "error") ?? GetScalarFromParams(paramsNode, "error") ?? "";
                session.RecordToolFailure(toolName, error);
                return null;
            }
            case "validate_agent_call":
            {
                var agentName = GetScalar(when, "agent_name") ?? GetScalarFromParams(paramsNode, "agent_name") ?? "";
                var agentParams = GetDictFromParams(paramsNode, "agent_params")
                    ?? YamlToDict(GetMapping(when, "agent_params"));
                var toolCallId = GetScalar(when, "tool_call_id")
                    ?? GetScalarFromParams(paramsNode, "tool_call_id")
                    ?? "case_invocation";
                var (verdict, _) = session.ValidateAgentCall(agentName, ToJsonElement(agentParams), toolCallId);
                return verdict;
            }
            default:
                throw new UnknownActionException(actionType);
        }
    }

    /// <summary>Internal carrier with the verdict plus the post-redaction
    /// text, so the assertion helper can branch on text/verdict for
    /// redaction cases (Stage 4 / Stage 5).</summary>
    private sealed record OutputCarrier(StageVerdict Verdict, string Text);

    // ── Assertion checking ─────────────────────────────────────────

    private void CheckAssertions(object? result, YamlMappingNode expected, string caseId)
    {
        if (result == null) return; // set_variable / skipped actions return null

        // Normalize OutputCarrier → extract inner StageVerdict
        string? outputText = null;
        if (result is OutputCarrier carrier)
        {
            outputText = carrier.Text;
            if (expected.Children.ContainsKey("passed"))
            {
                var expectedPassed = bool.Parse(GetScalar(expected, "passed")!);
                Assert.True(carrier.Verdict.Allowed == expectedPassed,
                    $"[{caseId}] expected passed={expectedPassed}, got {carrier.Verdict.Allowed}");
            }
            result = carrier.Verdict;
        }

        if (result is StageVerdict vr)
        {
            if (expected.Children.ContainsKey("allowed"))
            {
                var expectedAllowed = bool.Parse(GetScalar(expected, "allowed")!);
                Assert.True(vr.Allowed == expectedAllowed,
                    $"[{caseId}] expected allowed={expectedAllowed}, got {vr.Allowed}");
            }

            if (expected.Children.ContainsKey("action"))
            {
                var expAction = GetScalar(expected, "action")!;
                // Accept "block" for legacy "require_approval" cases —
                // the unified resolver collapses approvals into
                // block-on-deny semantics.
                var matches = vr.Action == expAction ||
                    ((vr.Action == "block" || vr.Action == "block_once") && (expAction == "require_approval" || expAction == "require_approval_always"));
                Assert.True(matches,
                    $"[{caseId}] expected action={expAction}, got {vr.Action}");
            }

            if (expected.Children.ContainsKey("reason_contains"))
            {
                var expectedReason = GetScalar(expected, "reason_contains")!;
                Assert.Contains(expectedReason, vr.Reason ?? "",
                    StringComparison.OrdinalIgnoreCase);
            }

            // StageVerdict has no Stage field; "stage" assertions in
            // legacy cases are skipped silently.

            // Output text assertions (for redaction checks)
            if (expected.Children.ContainsKey("text_contains"))
            {
                var text = outputText ?? vr.Redaction ?? vr.Reason ?? "";
                var expectedContains = GetScalar(expected, "text_contains")!;
                Assert.Contains(expectedContains, text);
            }

            if (expected.Children.ContainsKey("text_not_contains"))
            {
                var text = outputText ?? vr.Redaction ?? vr.Reason ?? "";
                var items = GetStringListOrScalar(expected, "text_not_contains");
                foreach (var item in items)
                {
                    Assert.DoesNotContain(item, text);
                }
            }
        }

        // State assertions (for get_active_states) — the .NET surface
        // does not expose active state names, so result will not be a
        // list. Skip silently.
        if (result is IReadOnlyList<string> states)
        {
            // Nested format: active_states.includes/excludes
            var statesCfg = GetMapping(expected, "active_states");
            if (statesCfg != null)
            {
                foreach (var s in GetStringList(statesCfg, "includes") ?? new List<string>())
                    Assert.Contains(s, states);
                foreach (var s in GetStringList(statesCfg, "excludes") ?? new List<string>())
                    Assert.DoesNotContain(s, states);
            }

            // Flat format: active_states_includes/active_states_excludes
            foreach (var s in GetStringListOrScalar(expected, "active_states_includes"))
                Assert.Contains(s, states);
            foreach (var s in GetStringListOrScalar(expected, "active_states_excludes"))
                Assert.DoesNotContain(s, states);
        }
    }

    // ── YAML helper methods ────────────────────────────────────────

    private static string? GetScalar(YamlMappingNode node, string key)
    {
        if (node.Children.ContainsKey(key) && node[key] is YamlScalarNode scalar)
            return scalar.Value;
        return null;
    }

    private static string? GetScalarFromParams(YamlMappingNode? paramsNode, string key)
    {
        if (paramsNode == null) return null;
        return GetScalar(paramsNode, key);
    }

    private static object? GetValueFromParams(YamlMappingNode? paramsNode, string key)
    {
        if (paramsNode == null || !paramsNode.Children.ContainsKey(key)) return null;
        return YamlToObject(paramsNode[key]);
    }

    private static YamlMappingNode? GetMapping(YamlMappingNode node, string key)
    {
        if (node.Children.ContainsKey(key) && node[key] is YamlMappingNode mapping)
            return mapping;
        return null;
    }

    private static List<string>? GetStringList(YamlMappingNode node, string key)
    {
        if (!node.Children.ContainsKey(key)) return null;
        if (node[key] is YamlSequenceNode seq)
            return seq.Children.Select(c => ((YamlScalarNode)c).Value!).ToList();
        return null;
    }

    private static List<string> GetStringListOrScalar(YamlMappingNode node, string key)
    {
        if (!node.Children.ContainsKey(key)) return new List<string>();
        if (node[key] is YamlSequenceNode seq)
            return seq.Children.Select(c => ((YamlScalarNode)c).Value!).ToList();
        if (node[key] is YamlScalarNode scalar && scalar.Value != null)
            return new List<string> { scalar.Value };
        return new List<string>();
    }

    private static Dictionary<string, object?>? GetDictFromParams(YamlMappingNode? paramsNode, string key)
    {
        if (paramsNode == null || !paramsNode.Children.ContainsKey(key)) return null;
        if (paramsNode[key] is YamlMappingNode map)
            return YamlToDict(map);
        return null;
    }

    private static Dictionary<string, object?>? YamlToDict(YamlMappingNode? node)
    {
        if (node == null) return null;
        var dict = new Dictionary<string, object?>();
        foreach (var kv in node.Children)
        {
            var k = ((YamlScalarNode)kv.Key).Value!;
            dict[k] = YamlToObject(kv.Value);
        }
        return dict;
    }

    private static object? YamlToObject(YamlNode node)
    {
        switch (node)
        {
            case YamlScalarNode scalar:
                if (scalar.Value == null || scalar.Value == "null" || scalar.Value == "~")
                    return null;
                if (bool.TryParse(scalar.Value, out var b)) return b;
                if (long.TryParse(scalar.Value, out var l)) return l;
                if (double.TryParse(scalar.Value, out var d) && scalar.Value.Contains('.'))
                    return d;
                return scalar.Value;

            case YamlSequenceNode seq:
                return seq.Children.Select(YamlToObject).ToList();

            case YamlMappingNode map:
                return YamlToDict(map);

            default:
                return node.ToString();
        }
    }

    // ── JsonElement adapters ───────────────────────────────────────

    /// <summary>Convert a CLR object (string/long/double/bool/null/list/dict)
    /// into a <see cref="JsonElement"/> suitable for the session API.</summary>
    private static JsonElement ToJsonElement(object? value)
    {
        var json = value == null
            ? "null"
            : JsonSerializer.Serialize(value);
        return JsonDocument.Parse(json).RootElement.Clone();
    }
}

public sealed class IntegrationCaseReportFixture : IDisposable
{
    public void Dispose()
    {
        IntegrationCaseJsonReporter.WriteIfConfigured();
    }
}

internal static class IntegrationCaseJsonReporter
{
    private static readonly string DotnetSdkVersion = typeof(IntegrationCaseJsonReporter).Assembly.GetName().Version?.ToString(3) ?? "0.0.0";
    private static readonly string CoreVersion = Environment.GetEnvironmentVariable("AGENT_SHIELD_CORE_VERSION") ?? DotnetSdkVersion;
    private static readonly ConcurrentBag<IntegrationCaseResult> Results = new();
    private static int _written;

    public static void Record(IntegrationCaseResult result)
    {
        Results.Add(result);
    }

    public static void WriteIfConfigured()
    {
        if (Interlocked.Exchange(ref _written, 1) != 0)
            return;

        var reportPath = Environment.GetEnvironmentVariable("AGENT_SHIELD_REPORT_JSON");
        if (string.IsNullOrWhiteSpace(reportPath))
            return;

        var directory = Path.GetDirectoryName(reportPath);
        if (!string.IsNullOrWhiteSpace(directory))
            Directory.CreateDirectory(directory);

        var payload = new IntegrationCaseReport(
            "dotnet",
            DotnetSdkVersion,
            CoreVersion,
            DateTime.UtcNow,
            Results.OrderBy(result => result.Suite, StringComparer.Ordinal)
                .ThenBy(result => result.Case, StringComparer.Ordinal)
                .ToArray());

        var json = JsonSerializer.Serialize(payload, new JsonSerializerOptions
        {
            WriteIndented = true,
        });

        File.WriteAllText(reportPath, json);
    }
}

internal sealed class UnknownActionException : Exception
{
    public UnknownActionException(string actionType)
        : base($"Unrecognized action: {actionType}")
    {
    }
}

internal sealed record IntegrationCaseReport(
    [property: JsonPropertyName("sdk")] string Sdk,
    [property: JsonPropertyName("sdk_version")] string SdkVersion,
    [property: JsonPropertyName("core_version")] string CoreVersion,
    [property: JsonPropertyName("timestamp")] DateTime Timestamp,
    [property: JsonPropertyName("results")] IReadOnlyList<IntegrationCaseResult> Results);

internal sealed record IntegrationCaseResult(
    [property: JsonPropertyName("suite")] string Suite,
    [property: JsonPropertyName("case")] string Case,
    [property: JsonPropertyName("status")] string Status,
    [property: JsonPropertyName("duration_ms")] double DurationMs,
    [property: JsonPropertyName("error_detail")] string? ErrorDetail);
