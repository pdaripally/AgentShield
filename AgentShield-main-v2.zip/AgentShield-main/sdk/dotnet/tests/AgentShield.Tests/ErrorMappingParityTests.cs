using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Xunit;

using AgentShield;
using AgentShield.MCP;

namespace AgentShield.Tests;

public class ErrorMappingParityTests
{
    private static readonly string RepoRoot = FindRepoRoot();
    private static readonly string FixturePath =
        Path.Combine(RepoRoot, "tests", "parity", "error_mapping_parity.json");

    private static string FindRepoRoot()
    {
        var dir = AppContext.BaseDirectory;
        while (dir is not null && !Directory.Exists(Path.Combine(dir, ".git")))
            dir = Path.GetDirectoryName(dir);
        return dir ?? throw new InvalidOperationException("repo root not found");
    }

    private static JsonElement Case(string name)
    {
        using var doc = JsonDocument.Parse(File.ReadAllText(FixturePath));
        return doc.RootElement
            .GetProperty("cases")
            .EnumerateArray()
            .First(c => c.GetProperty("name").GetString() == name)
            .Clone();
    }

    [Fact]
    public async Task ShieldBlockedRaise_MapsToExpectedException()
    {
        var c = Case("shield_blocked_raise");
        using var shield = Shield.FromYaml(Path.Combine(RepoRoot, c.GetProperty("fixture").GetString()!))
            .WithOnBlock(OnBlockPolicy.Raise)
            .Build();

        var ex = await Assert.ThrowsAsync<AgentShieldBlockedException>(async () =>
            await shield.RunAsync<string>(
                userInput: "DENY_ME please",
                execute: () => Task.FromResult("never runs")));
        Assert.Equal(c.GetProperty("expected").GetProperty("dotnet").GetString(), ex.GetType().Name);
    }

    [Fact]
    public void McpBlockedRaise_MapsToExpectedExceptionType()
    {
        var c = Case("mcp_blocked_raise");
        var ex = new MCPGuardrailBlockedException("echo", "blocked");
        Assert.Equal(c.GetProperty("expected").GetProperty("dotnet").GetString(), ex.GetType().Name);
    }
}
