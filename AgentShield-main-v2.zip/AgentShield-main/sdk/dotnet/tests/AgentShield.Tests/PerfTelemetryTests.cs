// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

using System;
using System.Collections.Concurrent;
using System.IO;
using System.Linq;
using System.Text.Json;

using Xunit;

namespace AgentShield.Tests;

/// <summary>
/// v8 perf-logging PR6 — .NET SDK surface tests.
///
/// Verifies that <see cref="RuntimeBuilder.WithPerfTelemetry"/> and
/// <see cref="ShieldBuilder.WithPerfTelemetry"/> round-trip the
/// gating knob into the underlying Rust runtime for all three modes,
/// and that <see cref="PerfTelemetry.Off"/> (the default) emits zero
/// perf events when a stage runs. The full event catalogue (per-stage,
/// per-policy, AC10-Corr correlation) is covered by
/// <c>sdk/rust/agent_shield_core/tests/perf_telemetry.rs</c>; this
/// suite pins the .NET wrapper's delegation.
/// </summary>
public class PerfTelemetryTests
{
    private static readonly string[] PerfEventTypes =
    {
        "stage_evaluated",
        "policy_evaluated",
        "llm_called",
        "classifier_called",
    };

    private static string FixturePath()
    {
        var dir = AppContext.BaseDirectory;
        while (dir != null && !File.Exists(Path.Combine(dir, "tests", "fixtures", "test-guardrails.yaml")))
            dir = Directory.GetParent(dir)?.FullName;
        if (dir == null)
            throw new FileNotFoundException("Could not locate tests/fixtures/test-guardrails.yaml");
        return Path.Combine(dir, "tests", "fixtures", "test-guardrails.yaml");
    }

    private sealed class CaptureProvider : IObservabilityProvider
    {
        public ConcurrentBag<JsonElement> Events { get; } = new();

        public void OnLogEvent(JsonElement eventJson)
        {
            // Clone — the framework reuses the underlying JsonDocument buffer.
            Events.Add(eventJson.Clone());
        }

        public int CountPerf()
        {
            return Events.Count(e =>
                e.TryGetProperty("event_type", out var t)
                && t.ValueKind == JsonValueKind.String
                && PerfEventTypes.Contains(t.GetString()));
        }
    }

    [Fact]
    public void PerfTelemetryEnumValuesMatchWireBytes()
    {
        Assert.Equal((byte)0, (byte)PerfTelemetry.Off);
        Assert.Equal((byte)1, (byte)PerfTelemetry.External);
        Assert.Equal((byte)2, (byte)PerfTelemetry.Full);
    }

    [Fact]
    public void RuntimeBuilderWithPerfTelemetryAllModesBuildSuccessfully()
    {
        // All three values must be accepted by the FFI. The release
        // build of agent_shield_core's `from_u8` rejects everything
        // else; we exercise the happy path here and let the unit
        // test in `perf_telemetry::tests` cover the rejection path.
        foreach (var mode in new[] { PerfTelemetry.Off, PerfTelemetry.External, PerfTelemetry.Full })
        {
            using var rb = RuntimeBuilder.FromYaml(FixturePath());
            rb.WithPerfTelemetry(mode);
            // Smoke: build succeeds.
            using var runtime = rb.Build();
            Assert.NotNull(runtime);
        }
    }

    [Fact]
    public void ShieldBuilderDefaultPerfTelemetryEmitsNoPerfEvents()
    {
        var provider = new CaptureProvider();
        using var shield = Shield.FromYaml(FixturePath())
            .WithObservability(provider)
            .Build();

        // Drive Stage 1 (input validation) so at least one stage runs.
        shield.Session.ValidateInput("hello");

        Assert.Equal(0, provider.CountPerf());
    }

    [Fact]
    public void ShieldBuilderWithPerfTelemetryFullEmitsStageAndPolicyEvents()
    {
        var provider = new CaptureProvider();
        using var shield = Shield.FromYaml(FixturePath())
            .WithObservability(provider)
            .WithPerfTelemetry(PerfTelemetry.Full)
            .Build();

        shield.Session.ValidateInput("hello");

        var emittedTypes = provider.Events
            .Select(e => e.GetProperty("event_type").GetString())
            .Where(t => t != null)
            .ToHashSet();
        Assert.Contains("stage_evaluated", emittedTypes);
        // The test fixture's Stage 1 has at least one guard policy,
        // so a policy_evaluated event must also fire.
        Assert.Contains("policy_evaluated", emittedTypes);
    }

    [Fact]
    public void ShieldBuilderWithPerfTelemetryExternalEmitsNoStageOrPolicyEvents()
    {
        var provider = new CaptureProvider();
        using var shield = Shield.FromYaml(FixturePath())
            .WithObservability(provider)
            .WithPerfTelemetry(PerfTelemetry.External)
            .Build();

        shield.Session.ValidateInput("hello");

        // External must NOT emit stage / policy events. The fixture's
        // policies use regex (not LLM / classifier), so the perf
        // count is zero overall.
        Assert.Equal(0, provider.CountPerf());
    }
}
