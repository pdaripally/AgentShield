# Agent Shield — .NET SDK

.NET SDK for [Agent Shield](https://github.com/microsoft/AgentShield), an open specification and reference implementation for runtime security controls on AI agents. Loads a [`.guardrails.yaml`](https://github.com/microsoft/AgentShield/blob/main/spec/SPECIFICATION.md) contract and enforces it across **5 validation stages** (Input → State → Tool execution → Post-tool → Output).

The .NET SDK is a P/Invoke layer over the Rust `agent_shield_core` plus an idiomatic C# facade. All validation logic lives in Rust; the .NET side translates shapes and exposes per-framework integrations through each ecosystem's native middleware contract.

## Packages

| Package | Description |
|---------|-------------|
| `AgentShield` | Core runtime + P/Invoke bindings + `Shield` builder |
| `AgentShield.AI` | [Microsoft.Extensions.AI](https://learn.microsoft.com/en-us/dotnet/ai/microsoft-extensions-ai) integration via `DelegatingChatClient` (`UseAgentShield()`) |
| `AgentShield.SemanticKernel` | [Semantic Kernel](https://learn.microsoft.com/en-us/semantic-kernel/) integration via `IAutoFunctionInvocationFilter` |
| `AgentShield.AutoGen` | [AutoGen .NET](https://microsoft.github.io/autogen-for-net/) integration via `IMiddleware` |
| `AgentShield.OpenAI` | [OpenAI .NET SDK](https://github.com/openai/openai-dotnet) integration |
| `AgentShield.Anthropic` | [Anthropic.SDK](https://github.com/tghamm/Anthropic.SDK) integration |

All packages target .NET 8.0+ and require the native `agent_shield_core` library at runtime (shipped in the package's `runtimes/<RID>/native/` folder).

## Install

```bash
dotnet add package AgentShield
dotnet add package AgentShield.AI               # Microsoft.Extensions.AI
dotnet add package AgentShield.SemanticKernel   # Semantic Kernel
# … etc.
```

## Quick start

```csharp
using AgentShield;

await using var shield = await Shield.FromYamlAsync(".guardrails.yaml").BuildAsync();

// Pattern C — Stage 1 + Stage 5 around an opaque agent thunk:
var answer = await shield.RunAsync("user input", async effectiveInput =>
{
    // effectiveInput is the value after Stage 1 mutations.
    return await callMyOpaqueAgentAsync(effectiveInput);
});
```

**Before shipping:** read [Post-tool limits and dangerous patterns](../../docs/POST_TOOL_LIMITS.md) — it covers what AgentShield does and does not guarantee.

## Three integration patterns

The same conceptual model — **Patterns A / B / C** — applies across all four AgentShield SDKs (Python, Node, Rust, .NET); the *implementation shape* matches each ecosystem's idiomatic middleware surface. .NET has the most sophisticated middleware story of any ecosystem, so each framework adapter uses that framework's *native* contract:

### Pattern A — Guard the agent loop (full coverage)

The integration shape depends on which .NET framework you're using:

#### Microsoft.Extensions.AI — `DelegatingChatClient` decorator chain

```csharp
using AgentShield;
using AgentShield.AI;
using Microsoft.Extensions.AI;

await using var shield = await Shield.FromYamlAsync(".guardrails.yaml").BuildAsync();

var chatClient = new ChatClientBuilder(rawClient)
    .UseLogging()
    .UseOpenTelemetry()
    .UseFunctionInvocation()
    .UseAgentShield(shield)         // ← AgentShield as a DelegatingChatClient
    .Build();

var response = await chatClient.GetResponseAsync("user input");
```

#### Semantic Kernel — `IAutoFunctionInvocationFilter`

```csharp
using AgentShield;
using AgentShield.SemanticKernel;
using Microsoft.SemanticKernel;

await using var shield = await Shield.FromYamlAsync(".guardrails.yaml").BuildAsync();

var kernel = Kernel.CreateBuilder()
    .AddOpenAIChatCompletion(...)
    .Build();
kernel.AttachAgentShieldFilter(shield);     // ← guards every auto-function-invocation

var result = await kernel.InvokePromptAsync("user input");
```

#### AutoGen .NET — `IMiddleware`

```csharp
using AgentShield;
using AgentShield.AutoGen;
using AutoGen.Core;

await using var shield = await Shield.FromYamlAsync(".guardrails.yaml").BuildAsync();

var agent = new MyAgent(...)
    .RegisterMiddleware(new AgentShieldMiddleware(shield));   // ← guards every reply

var reply = await agent.GenerateReplyAsync(messages);
```

### Pattern B — Protect individual tools

For frameworks where you want only the tool boundary guarded:

```csharp
await using var shield = await Shield.FromYamlAsync(".guardrails.yaml").BuildAsync();

var protectedTools = await shield.ProtectAnthropicToolsAsync(myTools);
// ... pass protectedTools to your Anthropic client
```

### Pattern C — Stage 1 + 5 boundary (opaque loops)

For black-box agent loops you don't control:

```csharp
await using var shield = await Shield.FromYamlAsync(".guardrails.yaml").BuildAsync();

var result = await shield.RunAsync("user input", async effectiveInput =>
{
    // your model call + custom loop here
    return await runMyOpaqueAgentAsync(effectiveInput);
});
```

## YAML auto-wiring

YAML configurations drive everything; no host code needed for the common case:

- **Bundled `kind: human` providers** — `provider: auto_reject` / `provider: deny` / `provider: console` work out of the box.
- **LLM clients** — `configurations: - {id, type: llm, provider, model, api_key_env}` auto-wire HTTP-based callers.
- **Classifiers** — `configurations: - {id, type: classifier, provider: ...}` auto-wire HTTP-based callers.

```yaml
# .guardrails.yaml
configurations:
  - id: "gpt4o"
    type: llm
    provider: openai
    model: gpt-4o
    api_key_env: OPENAI_API_KEY

tool_execution_validation:
  configuration: "gpt4o"
  prompts:
    task_adherence: "Is this tool call consistent with the user's request?"
```

`Shield.FromYamlAsync` reads `configurations` and auto-resolves `OPENAI_API_KEY` from the environment — no manual wiring required.

## Observability

```csharp
using AgentShield;
using AgentShield.Observability;

await using var shield = await Shield.FromYamlAsync(".guardrails.yaml")
    .WithObservability(new OtelProvider())   // or AzureMonitorProvider / CloudWatchProvider
    .BuildAsync();
```

Every emitted event carries [OpenTelemetry GenAI semantic-convention](https://opentelemetry.io/docs/specs/semconv/gen-ai/) attributes (`gen_ai.system="agent_shield"`, `gen_ai.operation.name="guard.<stage>"`, `gen_ai.response.finish_reason="content_filter"` on blocks), so any OTel exporter sees AgentShield events with the same shape it sees other GenAI telemetry.

## Lower-level API

For framework-agnostic code, drop down to `GuardrailsRuntime` directly:

```csharp
using AgentShield;

await using var runtime = await GuardrailsRuntime.FromYamlAsync(".guardrails.yaml");

var input = await runtime.ValidateInputAsync("user prompt");
if (!input.Allowed) throw new InvalidOperationException(input.Reason);

var tool = await runtime.ValidateToolCallAsync("send_email", toolParams);
if (!tool.Allowed) throw new InvalidOperationException(tool.Reason);
```

## Building from source

```bash
# Build the native engine
cargo build --release --manifest-path sdk/rust/agent_shield_core/Cargo.toml

# Build + test the .NET projects
dotnet build sdk/dotnet/tests/AgentShield.Tests/AgentShield.Tests.csproj
LD_LIBRARY_PATH=sdk/rust/agent_shield_core/target/release \
  dotnet test sdk/dotnet/tests/AgentShield.Tests/AgentShield.Tests.csproj
```

## More

- [Specification](https://github.com/microsoft/AgentShield/blob/main/spec/SPECIFICATION.md) — the source of truth for `.guardrails.yaml` semantics.
- [SDK guarded-turn semantics](../../docs/sdk-guarded-turn-semantics.md) — effective Stage 1 input, Stage 3 parameters, and `RecordToolSuccess`.
- [Expression-language reference](https://github.com/microsoft/AgentShield/blob/main/spec/expressions/LANGUAGE.md).
- [Examples](https://github.com/microsoft/AgentShield/tree/main/examples) — bank-manager, sensitive-documents, IFC, ask-human MCP server.
