using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace AgentShield;

/// <summary>
/// Internal helpers that drive the stage-validation pipelines used by
/// <see cref="Shield"/>. These are deliberately split from the
/// <c>Shield</c> class so they can be unit-tested independently and so
/// per-framework extension methods can compose them differently.
///
/// <para>
/// Three pipelines live here:
/// </para>
/// <list type="bullet">
///   <item>
///     <c>RunGuardedTurnAsync</c> — Stage 1 → execute → Stage 5,
///     bracketed by <see cref="GuardrailsSession.BeginTurn"/> /
///     <see cref="GuardrailsSession.EndTurn"/>.
///   </item>
///   <item>
///     <c>RunStreamedAsync</c> — Stage 1, ambient session push, then a
///     per-chunk Stage 5 streaming guard.
///   </item>
///   <item>
///     <c>RunGuardedToolAsync</c> — Stage 2 + 3, execute, Stage 4,
///     plus <c>record_tool_success</c> / <c>record_tool_failure</c>
///     bookkeeping.
///   </item>
/// </list>
/// </summary>
internal static class GuardedRunner
{
    // ── Stage 1 + 5 (full agent turn) ───────────────────────────────

    internal static async Task<TResult> RunGuardedTurnAsync<TResult>(
        GuardrailsSession session,
        string userInput,
        Func<Task<TResult>> execute,
        ShieldMode mode,
        Func<StageVerdict, string, TResult> dispatchBlocked,
        AsyncLocal<GuardrailsSession?> ambient,
        AsyncLocal<string?> ambientInput,
        CancellationToken ct = default)
    {
        ct.ThrowIfCancellationRequested();
        session.BeginTurn();
        try
        {
            // Shadow / Monitor (#14): observability-only branch. Run
            // every stage validator for audit events (core stamps them
            // with `mode: shadow` + `enforced: false` and routes them
            // through the registered ObservabilityProvider), never
            // block, never apply redactions / appends / prepends.
            // Mirrors Python `_execute_with_monitor` and Node
            // `_runMonitorMode`.
            if (mode == ShieldMode.Monitor)
            {
                _ = session.ValidateInput(userInput ?? string.Empty);

                ct.ThrowIfCancellationRequested();

                var prevSessionMon = ambient.Value;
                var prevInputMon = ambientInput.Value;
                ambient.Value = session;
                ambientInput.Value = userInput ?? string.Empty;
                TResult monResult;
                try
                {
                    monResult = await execute().ConfigureAwait(false);
                }
                finally
                {
                    ambient.Value = prevSessionMon;
                    ambientInput.Value = prevInputMon;
                }

                if (monResult is string monText && !string.IsNullOrEmpty(monText))
                {
                    _ = session.ValidateOutput(monText);
                }

                return monResult;
            }

            // Stage 1 — canonical dispatch.
            var inputVerdict = session.ValidateInput(userInput ?? string.Empty);
            var inputDecision = VerdictDispatcher.DispatchStage(
                inputVerdict, OnBlockPolicy.ReturnBlocked, mode);
            if (inputDecision.Action.Kind == "return_blocked"
                && !inputDecision.OverrideToProceed)
            {
                return dispatchBlocked(
                    inputVerdict, inputDecision.Action.Message ?? string.Empty);
            }
            // override_to_proceed only fires when `mode == Monitor`, but
            // the dedicated Monitor branch above already handles that
            // case; in any other mode this is unreachable.
            var effectiveInput = inputDecision.Action.Kind == "proceed_with_mutation"
                ? inputDecision.Action.Value ?? userInput ?? string.Empty
                : userInput ?? string.Empty;

            ct.ThrowIfCancellationRequested();

            var prevSession = ambient.Value;
            var prevInput = ambientInput.Value;
            ambient.Value = session;
            ambientInput.Value = effectiveInput;
            TResult result;
            try
            {
                result = await execute().ConfigureAwait(false);
            }
            finally
            {
                ambient.Value = prevSession;
                ambientInput.Value = prevInput;
            }

            // Stage 5 — best-effort. Validate when the result has a
            // string projection; non-string TResults pass through.
            if (result is string text && !string.IsNullOrEmpty(text))
            {
                var (verdict, redacted) = session.ValidateOutput(text);
                var stage5 = VerdictDispatcher.DispatchStage(
                    verdict, OnBlockPolicy.ReturnBlocked, mode);
                switch (stage5.Action.Kind)
                {
                    case "return_blocked" when !stage5.OverrideToProceed:
                        return dispatchBlocked(
                            verdict, stage5.Action.Message ?? string.Empty);
                    case "proceed_with_mutation":
                        if (redacted is TResult casted) return casted;
                        break;
                }
            }

            return result;
        }
        finally
        {
            try { session.EndTurn(); }
            catch { /* best-effort */ }
        }
    }

    // ── Streaming Stage 1 + Stage 5 chunk-validated ────────────────
    //
    // Emission scheduling respects the guard's configured mode:
    //
    // * OnComplete — buffer every text-bearing chunk through the engine
    //   but emit nothing to the consumer until Finish() returns. The
    //   final validated text is yielded as a single chunk, or a single
    //   `[GUARDRAIL BLOCK]` chunk if the engine blocked the buffer.
    // * PerChunk / Windowed — emit the engine's `pushed.Payload` (the
    //   authoritative, overlap-respecting safe-to-emit slice) when
    //   non-empty; skip when empty (engine is still holding back
    //   overlap bytes). Stop verdicts emit a `[GUARDRAIL BLOCK]`
    //   chunk and abort. SDKs forwarding the raw chunk on Pass
    //   verdicts would silently bypass windowed validators that
    //   produce payload-altered Pass actions — see
    //   `streaming-windowed-payload-respect` for context.

    internal static async IAsyncEnumerable<string> RunStreamedAsync(
        GuardrailsSession session,
        string userInput,
        Func<IAsyncEnumerable<string>> execute,
        ShieldMode mode,
        AsyncLocal<GuardrailsSession?> ambient,
        AsyncLocal<string?> ambientInput,
        [EnumeratorCancellation] CancellationToken ct = default)
    {
        ct.ThrowIfCancellationRequested();
        session.BeginTurn();
        try
        {
            // Shadow / Monitor (#14): run Stage 1 for observability,
            // push every chunk through the Stage-5 guard for audit
            // events, but always emit the ORIGINAL chunk and never
            // honour the guard's buffer / stop / replace decisions.
            // Core stamps every emitted event with `mode: shadow` +
            // `enforced: false` and routes them through the registered
            // ObservabilityProvider. Mirrors the Python / Node
            // `_MonitorStreamingValidator` contract.
            if (mode == ShieldMode.Monitor)
            {
                _ = session.ValidateInput(userInput ?? string.Empty);

                var prevSessionMon = ambient.Value;
                var prevInputMon = ambientInput.Value;
                ambient.Value = session;
                ambientInput.Value = userInput ?? string.Empty;
                try
                {
                    StreamingGuard? auditGuard = null;
                    try { auditGuard = session.StreamingSession(StreamingStage.Output); }
                    catch { /* fall back to no-guard observability */ }
                    try
                    {
                        await foreach (var chunk in execute().WithCancellation(ct).ConfigureAwait(false))
                        {
                            if (chunk is null) continue;
                            if (chunk.Length == 0)
                            {
                                yield return chunk;
                                continue;
                            }
                            if (auditGuard != null)
                            {
                                try { _ = auditGuard.Push(chunk); }
                                catch { /* observability best-effort */ }
                            }
                            // Always emit the original chunk in shadow.
                            yield return chunk;
                        }
                        if (auditGuard != null)
                        {
                            try { _ = auditGuard.Finish(); }
                            catch { /* observability best-effort */ }
                        }
                    }
                    finally
                    {
                        auditGuard?.Dispose();
                    }
                }
                finally
                {
                    ambient.Value = prevSessionMon;
                    ambientInput.Value = prevInputMon;
                }
                yield break;
            }

            var inputVerdict = session.ValidateInput(userInput ?? string.Empty);
            if (!inputVerdict.Allowed)
            {
                yield return BlockMessageFormatter.Format(inputVerdict);
                yield break;
            }
            var inputDecision = VerdictDispatcher.DispatchStage(
                inputVerdict, OnBlockPolicy.ReturnBlocked, mode);
            var effectiveInput = inputDecision.Action.Kind == "proceed_with_mutation"
                ? inputDecision.Action.Value ?? userInput ?? string.Empty
                : userInput ?? string.Empty;

            var prevSession = ambient.Value;
            var prevInput = ambientInput.Value;
            ambient.Value = session;
            ambientInput.Value = effectiveInput;
            try
            {
                using var guard = session.StreamingSession(StreamingStage.Output);
                var bufferMode = guard.Mode == StreamingMode.OnComplete;
                var stopped = false;
                await foreach (var chunk in execute().WithCancellation(ct).ConfigureAwait(false))
                {
                    if (chunk is null) continue;
                    if (chunk.Length == 0)
                    {
                        // Empty string is the framework-agnostic
                        // analogue of a metadata-only chunk — surface
                        // it so consumers that key on chunk arrival
                        // still see progress, but skip the validator.
                        yield return chunk;
                        continue;
                    }

                    var pushed = guard.Push(chunk);
                    if (pushed.Action == StreamAction.Stop)
                    {
                        yield return string.IsNullOrEmpty(pushed.Payload)
                            ? $"[GUARDRAIL BLOCK] {pushed.Reason ?? "blocked by policy"}"
                            : pushed.Payload;
                        stopped = true;
                        break;
                    }
                    else if (bufferMode)
                    {
                        // OnComplete: hold back text-bearing chunks until
                        // Finish() emits the validated payload.
                        continue;
                    }
                    else if (!string.IsNullOrEmpty(pushed.Payload))
                    {
                        // per_chunk / windowed: emit pushed.Payload (the
                        // engine's safe-to-emit slice) when non-empty.
                        // Empty payload means "buffered for overlap —
                        // emit nothing yet". This mirrors the OnComplete
                        // payload-respect fix; both Pass (overlap-window
                        // suffix) and Replace (redacted) flow through
                        // the same path now.
                        yield return pushed.Payload;
                    }
                }
                if (!stopped)
                {
                    var tail = guard.Finish();
                    if (tail.Action == StreamAction.Stop)
                    {
                        yield return string.IsNullOrEmpty(tail.Payload)
                            ? $"[GUARDRAIL BLOCK] {tail.Reason ?? "blocked by policy"}"
                            : tail.Payload;
                    }
                    else if (bufferMode)
                    {
                        // OnComplete: emit the validated payload as the
                        // single terminal chunk. Empty payload (no
                        // text-bearing chunks received) yields nothing.
                        if (!string.IsNullOrEmpty(tail.Payload))
                        {
                            yield return tail.Payload;
                        }
                    }
                    else if (!string.IsNullOrEmpty(tail.Payload))
                    {
                        // per_chunk / windowed tail: the engine flushes
                        // the held-back overlap (Pass) OR the final
                        // redacted text (Replace) here — both must
                        // reach the consumer.
                        yield return tail.Payload;
                    }
                }
            }
            finally
            {
                ambient.Value = prevSession;
                ambientInput.Value = prevInput;
            }
        }
        finally
        {
            try { session.EndTurn(); }
            catch { /* best-effort */ }
        }
    }

    // ── Stage 2 + 3 + execute + Stage 4 + record ───────────────────

    internal static async Task<(bool Blocked, string Output)> RunGuardedToolAsync(
        GuardrailsSession session,
        string toolName,
        JsonElement parameters,
        Func<JsonElement, Task<string>> execute,
        ShieldMode mode,
        CancellationToken ct = default,
        string? toolCallId = null)
    {
        ct.ThrowIfCancellationRequested();

        // §16.0 binding — if the caller didn't supply an upstream
        // id, mint a per-call id so concurrent same-name calls bind
        // correctly through Stage 3 → Stage 4 instead of colliding
        // with another same-name call.
        var boundId = toolCallId ?? Guid.NewGuid().ToString("N");

        // Shadow / Monitor (#14): observability-only branch. Run Stage
        // 3 and Stage 4 validators for audit events (core stamps them
        // with `mode: shadow` + `enforced: false`), never block, never
        // apply mutated params or redacted output. Mirrors Python
        // `Shield.protect_tool` MONITOR branch and Node equivalent.
        if (mode == ShieldMode.Monitor)
        {
            _ = session.ValidateToolCall(toolName, parameters, boundId);

            string monOutput;
            try
            {
                ct.ThrowIfCancellationRequested();
                monOutput = await execute(parameters).ConfigureAwait(false) ?? string.Empty;
            }
            catch (Exception ex)
            {
                var monErrorText = $"[tool error] {toolName}: {ex.Message}";
                try
                {
                    JsonElement monErrEl = JsonDocument.Parse(JsonSerializer.Serialize(monErrorText)).RootElement.Clone();
                    _ = session.ValidateToolOutput(toolName, monErrEl, boundId);
                }
                catch { /* best-effort observability */ }
                try { session.RecordToolFailure(toolName, ex.Message); } catch { }
                return (false, monErrorText);
            }

            try
            {
                JsonElement monOutEl;
                try
                {
                    monOutEl = JsonDocument.Parse(JsonSerializer.Serialize(monOutput)).RootElement.Clone();
                }
                catch
                {
                    monOutEl = JsonDocument.Parse("\"\"").RootElement.Clone();
                }
                _ = session.ValidateToolOutput(toolName, monOutEl, boundId);
                try { session.RecordToolSuccess(toolName, JsonDocument.Parse(JsonSerializer.Serialize(monOutput)).RootElement); } catch { }
            }
            catch { /* best-effort observability */ }

            return (false, monOutput);
        }

        // Stage 2 + 3 — canonical tool dispatch.
        var (callVerdict, mutatedParams) = session.ValidateToolCall(toolName, parameters, boundId);
        var callDispatch = VerdictDispatcher.DispatchTool(
            callVerdict, toolName, ToolStage.Call,
            OnBlockPolicy.ReturnBlocked, mode);
        if (callDispatch.Action.Kind == "blocked")
        {
            if (callDispatch.OverrideToProceed)
            {
                mutatedParams = parameters;
            }
            else
            {
                return (true, callDispatch.Action.Message ?? string.Empty);
            }
        }

        // Execute the underlying tool, passing Stage-3 mutated params.
        string rawOutput;
        try
        {
            ct.ThrowIfCancellationRequested();
            rawOutput = await execute(mutatedParams).ConfigureAwait(false) ?? string.Empty;
        }
        catch (Exception ex)
        {
            try { session.RecordToolFailure(toolName, ex.Message); } catch { }
            var errorText = $"[tool error] {toolName}: {ex.Message}";
            // Run Stage 4 over the error text so policies can still
            // flag it; if Stage 4 blocks we surface the block, else
            // return the error text untouched.
            JsonElement errEl = JsonDocument.Parse(JsonSerializer.Serialize(errorText)).RootElement.Clone();
            var (errVerdict, errRedacted) = session.ValidateToolOutput(toolName, errEl, boundId);
            // Use the bare-stage dispatcher (no tool-name suffix) here
            // because the error text already names the tool inline.
            var errDispatch = VerdictDispatcher.DispatchStage(
                errVerdict, OnBlockPolicy.ReturnBlocked, mode);
            if (errDispatch.Action.Kind == "return_blocked"
                && !errDispatch.OverrideToProceed)
            {
                return (true, errDispatch.Action.Message ?? string.Empty);
            }
            return (false, JsonElementToText(errRedacted) ?? errorText);
        }

        // Stage 4
        JsonElement outEl;
        try
        {
            outEl = JsonDocument.Parse(JsonSerializer.Serialize(rawOutput)).RootElement.Clone();
        }
        catch
        {
            outEl = JsonDocument.Parse("\"\"").RootElement.Clone();
        }
        var (outVerdict, outRedacted) = session.ValidateToolOutput(toolName, outEl, boundId);
        var outDispatch = VerdictDispatcher.DispatchTool(
            outVerdict, toolName, ToolStage.Output,
            OnBlockPolicy.ReturnBlocked, mode);
        if (outDispatch.Action.Kind == "blocked")
        {
            if (!outDispatch.OverrideToProceed)
            {
                if (outDispatch.RecordFailure)
                {
                    try { session.RecordToolFailure(toolName, outVerdict.Reason ?? "blocked"); } catch { }
                }
                return (true, outDispatch.Action.Message ?? string.Empty);
            }
        }

        var finalText = JsonElementToText(outRedacted) ?? rawOutput;
        if (outDispatch.RecordSuccess && outDispatch.Action.Kind != "blocked")
        {
            try { session.RecordToolSuccess(toolName, JsonDocument.Parse(JsonSerializer.Serialize(finalText)).RootElement); }
            catch { /* best-effort */ }
        }
        return (false, finalText);
    }

    private static string? JsonElementToText(JsonElement el)
    {
        return el.ValueKind switch
        {
            JsonValueKind.String => el.GetString(),
            JsonValueKind.Null => null,
            JsonValueKind.Undefined => null,
            _ => el.GetRawText(),
        };
    }
}
