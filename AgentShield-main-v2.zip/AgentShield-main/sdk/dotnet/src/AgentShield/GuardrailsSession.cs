using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text.Json;

using AgentShield.Interop;

namespace AgentShield;

/// <summary>
/// Per-request guardrails session. Sessions are NOT thread-safe — the
/// host should use one session per logical request / turn. Disposing a
/// session frees the underlying native handle.
///
/// <para>
/// All stage-validation methods return a <see cref="StageVerdict"/>;
/// validators that mutate parameters (Stage 3 transforms / Stage 5
/// redactions) additionally return the post-mutation value via the
/// tuple shape documented per method.
/// </para>
/// </summary>
public sealed class GuardrailsSession : IDisposable
{
    private IntPtr _handle;
    private bool _disposed;

    internal GuardrailsSession(IntPtr handle)
    {
        _handle = handle;
    }

    ~GuardrailsSession()
    {
        DisposeCore();
    }

    // ── Variable ops ───────────────────────────────────────────────

    /// <summary>Set a variable's value. Marks status = resolved.</summary>
    public void SetVariable(string name, JsonElement value)
    {
        ThrowIfDisposed();
        var json = value.GetRawText();
        NativeMethods.shield_session_set_variable(_handle, name, json, out var err);
        NativeMethods.ThrowIfErr(err);
    }

    /// <summary>Reset a variable back to its declared default.</summary>
    public void ResetVariable(string name)
    {
        ThrowIfDisposed();
        NativeMethods.shield_session_reset_variable(_handle, name, out var err);
        NativeMethods.ThrowIfErr(err);
    }

    /// <summary>
    /// Trigger the variable's <c>on_demand_by:</c> resolver. Returns the
    /// resolved value (or null when the resolver denied / cancelled / no
    /// resolver is configured).
    /// </summary>
    public JsonElement? ResolveVariable(string name)
    {
        ThrowIfDisposed();
        var ptr = NativeMethods.shield_session_resolve_variable(_handle, name, out var err);
        NativeMethods.ThrowIfErr(err);
        var json = NativeMethods.ReadAndFreeString(ptr);
        if (string.IsNullOrEmpty(json) || json == "null") return null;
        return JsonDocument.Parse(json).RootElement.Clone();
    }

    /// <summary>Read the cached variable state. Null when the variable is not declared.</summary>
    public VariableState? ReadVariable(string name)
    {
        ThrowIfDisposed();
        var ptr = NativeMethods.shield_session_read_variable(_handle, name, out var err);
        NativeMethods.ThrowIfErr(err);
        var json = NativeMethods.ReadAndFreeString(ptr);
        return VariableState.FromJson(json);
    }

    // ── Event ops ──────────────────────────────────────────────────

    /// <summary>Emit an event with optional lifetime + payload (spec §9).</summary>
    public void EmitEvent(string eventId, Lifetime? lifetime = null, JsonElement? payload = null)
    {
        ThrowIfDisposed();
        var ltJson = lifetime?.ToWireJson();
        var payloadJson = payload?.GetRawText();
        NativeMethods.shield_session_emit_event(
            _handle, eventId, ltJson, payloadJson, out var err);
        NativeMethods.ThrowIfErr(err);
    }

    /// <summary>Clear a previously fired event by id.</summary>
    public void ClearEvent(string eventId)
    {
        ThrowIfDisposed();
        NativeMethods.shield_session_clear_event(_handle, eventId, out var err);
        NativeMethods.ThrowIfErr(err);
    }

    /// <summary>Emit a host-originated incident (spec §9.5).</summary>
    public void EmitIncident(string name, JsonElement? payload = null)
    {
        ThrowIfDisposed();
        var payloadJson = payload?.GetRawText();
        NativeMethods.shield_session_emit_incident(_handle, name, payloadJson, out var err);
        NativeMethods.ThrowIfErr(err);
    }

    // ── Boundary ops ───────────────────────────────────────────────

    /// <summary>Open a turn boundary. Returns the opaque turn id.</summary>
    public ulong BeginTurn()
    {
        ThrowIfDisposed();
        var id = NativeMethods.shield_session_begin_turn(_handle, out var err);
        NativeMethods.ThrowIfErr(err);
        return id;
    }

    /// <summary>Close the active turn boundary.</summary>
    public void EndTurn()
    {
        ThrowIfDisposed();
        NativeMethods.shield_session_end_turn(_handle, out var err);
        NativeMethods.ThrowIfErr(err);
    }

    /// <summary>Open a request boundary. Returns the opaque request id.</summary>
    public ulong BeginRequest()
    {
        ThrowIfDisposed();
        var id = NativeMethods.shield_session_begin_request(_handle, out var err);
        NativeMethods.ThrowIfErr(err);
        return id;
    }

    /// <summary>Close the active request boundary.</summary>
    public void EndRequest()
    {
        ThrowIfDisposed();
        NativeMethods.shield_session_end_request(_handle, out var err);
        NativeMethods.ThrowIfErr(err);
    }

    // ── IFC ops (proof: docs/information-flow-control-proof.md) ─────

    /// <summary>
    /// The session's running IFC exposure as a sorted list of
    /// declared tag names. Empty when IFC is disabled (no
    /// <c>ifc:</c> block in the merged config) or when exposure
    /// is ⊥.
    /// </summary>
    public IReadOnlyList<string> CurrentExposure
    {
        get
        {
            ThrowIfDisposed();
            var raw = NativeMethods.shield_session_ifc_current_exposure(_handle, out var err);
            NativeMethods.ThrowIfErr(err);
            var jsonPtr = NativeMethods.shield_session_ifc_tag_names(_handle, raw, out var err2);
            NativeMethods.ThrowIfErr(err2);
            var json = NativeMethods.ReadAndFreeString(jsonPtr);
            return System.Text.Json.JsonSerializer.Deserialize<List<string>>(json ?? "[]")
                   ?? new List<string>();
        }
    }

    // ── Stage validation ───────────────────────────────────────────

    /// <summary>Stage 1 — validate user input.</summary>
    public StageVerdict ValidateInput(string input)
    {
        ThrowIfDisposed();
        var ptr = NativeMethods.shield_session_validate_input(_handle, input, out var err);
        NativeMethods.ThrowIfErr(err);
        return ParseVerdict(ptr);
    }

    /// <summary>
    /// Stage 2 — validate state for an arbitrary invocation. Pass the
    /// invocation envelope as JSON of the form
    /// <c>{"kind": "tool|agent|endpoint", "name": ..., "params": ...}</c>.
    /// </summary>
    public StageVerdict ValidateState(string invocationJson)
    {
        ThrowIfDisposed();
        var ptr = NativeMethods.shield_session_validate_state(
            _handle, invocationJson, out var err);
        NativeMethods.ThrowIfErr(err);
        return ParseVerdict(ptr);
    }

    /// <summary>
    /// Stage 3 — validate a tool call. Pair the call with a stable
    /// <paramref name="toolCallId"/> so the matching Stage 4
    /// <see cref="ValidateToolOutput"/> binds back to the canonical
    /// invocation (§16.0). Hosts with parallel/repeated same-name tool
    /// calls MUST pass a distinct id per call to avoid binding-cache
    /// collisions. When the host framework does not supply a native id,
    /// adapters synthesize one via <c>Guid.NewGuid().ToString("N")</c>.
    /// </summary>
    public (StageVerdict Verdict, JsonElement Params) ValidateToolCall(
        string tool,
        JsonElement parameters,
        string toolCallId)
    {
        ThrowIfDisposed();
        ArgumentNullException.ThrowIfNull(toolCallId);
        var paramsJson = parameters.GetRawText();
        var ptr = NativeMethods.shield_session_validate_tool_call(
            _handle, tool, paramsJson, toolCallId, out var mutatedPtr, out var err);
        NativeMethods.ThrowIfErr(err);
        var verdict = ParseVerdict(ptr);
        var mutated = ReadJsonOrFallback(mutatedPtr, parameters);
        return (verdict, mutated);
    }

    /// <summary>
    /// Stage 4 — validate a tool result. Returns the verdict and the
    /// (possibly redacted) result. Pass the same
    /// <paramref name="toolCallId"/> that was passed to
    /// <see cref="ValidateToolCall"/> (§16.0). When no Stage 3 entry
    /// matches the id, this method fails closed with a fixed
    /// <c>&lt;binding&gt;</c> policy.
    /// </summary>
    public (StageVerdict Verdict, JsonElement Result) ValidateToolOutput(
        string tool,
        JsonElement result,
        string toolCallId)
    {
        ThrowIfDisposed();
        ArgumentNullException.ThrowIfNull(toolCallId);
        var resultJson = result.GetRawText();
        var ptr = NativeMethods.shield_session_validate_tool_output(
            _handle, tool, resultJson, toolCallId, out var mutatedPtr, out var err);
        NativeMethods.ThrowIfErr(err);
        var verdict = ParseVerdict(ptr);
        var mutated = ReadJsonOrFallback(mutatedPtr, result);
        return (verdict, mutated);
    }

    /// <summary>Validate an HTTP endpoint call. Returns verdict + (possibly transformed) body.</summary>
    public (StageVerdict Verdict, JsonElement Body) ValidateEndpointCall(
        string method,
        string uri,
        JsonElement body,
        string toolCallId)
    {
        ThrowIfDisposed();
        ArgumentNullException.ThrowIfNull(toolCallId);
        var bodyJson = body.GetRawText();
        var ptr = NativeMethods.shield_session_validate_endpoint_call(
            _handle, method, uri, bodyJson, toolCallId, out var mutatedPtr, out var err);
        NativeMethods.ThrowIfErr(err);
        var verdict = ParseVerdict(ptr);
        var mutated = ReadJsonOrFallback(mutatedPtr, body);
        return (verdict, mutated);
    }

    /// <summary>Validate an A2A agent call. Returns verdict + (possibly transformed) parameters.</summary>
    public (StageVerdict Verdict, JsonElement Params) ValidateAgentCall(
        string agent,
        JsonElement parameters,
        string toolCallId)
    {
        ThrowIfDisposed();
        ArgumentNullException.ThrowIfNull(toolCallId);
        var paramsJson = parameters.GetRawText();
        var ptr = NativeMethods.shield_session_validate_agent_call(
            _handle, agent, paramsJson, toolCallId, out var mutatedPtr, out var err);
        NativeMethods.ThrowIfErr(err);
        var verdict = ParseVerdict(ptr);
        var mutated = ReadJsonOrFallback(mutatedPtr, parameters);
        return (verdict, mutated);
    }

    /// <summary>Stage 5 — validate the final agent response. Returns the verdict and the (possibly redacted) text.</summary>
    public (StageVerdict Verdict, string Response) ValidateOutput(string response)
    {
        ThrowIfDisposed();
        var ptr = NativeMethods.shield_session_validate_output(
            _handle, response, out var mutatedPtr, out var err);
        NativeMethods.ThrowIfErr(err);
        var verdict = ParseVerdict(ptr);
        var mutated = NativeMethods.ReadAndFreeString(mutatedPtr) ?? response;
        return (verdict, mutated);
    }

    // ── Resource cycle helpers ─────────────────────────────────────

    public void RecordToolSuccess(string tool, JsonElement result)
    {
        ThrowIfDisposed();
        NativeMethods.shield_session_record_tool_success(
            _handle, tool, result.GetRawText(), out var err);
        NativeMethods.ThrowIfErr(err);
    }

    public void RecordToolFailure(string tool, string error)
    {
        ThrowIfDisposed();
        NativeMethods.shield_session_record_tool_failure(_handle, tool, error, out var err);
        NativeMethods.ThrowIfErr(err);
    }

    public void RecordEndpointSuccess(string method, string uri, JsonElement result)
    {
        ThrowIfDisposed();
        NativeMethods.shield_session_record_endpoint_success(
            _handle, method, uri, result.GetRawText(), out var err);
        NativeMethods.ThrowIfErr(err);
    }

    public void RecordEndpointFailure(string method, string uri, string error)
    {
        ThrowIfDisposed();
        NativeMethods.shield_session_record_endpoint_failure(
            _handle, method, uri, error, out var err);
        NativeMethods.ThrowIfErr(err);
    }

    public void RecordAgentSuccess(string agent, JsonElement result)
    {
        ThrowIfDisposed();
        NativeMethods.shield_session_record_agent_success(
            _handle, agent, result.GetRawText(), out var err);
        NativeMethods.ThrowIfErr(err);
    }

    public void RecordAgentFailure(string agent, string error)
    {
        ThrowIfDisposed();
        NativeMethods.shield_session_record_agent_failure(_handle, agent, error, out var err);
        NativeMethods.ThrowIfErr(err);
    }

    // ── Streaming ──────────────────────────────────────────────────

    /// <summary>Open a streaming guard for the given stage (Stage 4 or 5).</summary>
    public StreamingGuard StreamingSession(StreamingStage stage)
    {
        ThrowIfDisposed();
        var ptr = NativeMethods.shield_session_streaming_session(
            _handle, (int)stage, out var err);
        NativeMethods.ThrowIfErr(err);
        if (ptr == IntPtr.Zero)
            throw new GuardrailsException("shield_session_streaming_session returned null");
        // Stream incidents are emitted by the native dispatcher; the
        // managed wrapper does not need a session back-reference.
        return new StreamingGuard(ptr);
    }

    // ── IDisposable ────────────────────────────────────────────────

    public void Dispose()
    {
        DisposeCore();
        GC.SuppressFinalize(this);
    }

    private void DisposeCore()
    {
        if (_disposed) return;
        _disposed = true;
        if (_handle != IntPtr.Zero)
        {
            NativeMethods.shield_session_free(_handle);
            _handle = IntPtr.Zero;
        }
    }

    private void ThrowIfDisposed()
    {
        if (_disposed) throw new GuardrailsDisposedException(nameof(GuardrailsSession));
    }

    // ── Helpers ────────────────────────────────────────────────────

    private static StageVerdict ParseVerdict(IntPtr ptr)
    {
        var json = NativeMethods.ReadAndFreeString(ptr)
            ?? throw new GuardrailsException("Validation returned null verdict");
        return StageVerdict.FromJson(json);
    }

    private static JsonElement ReadJsonOrFallback(IntPtr ptr, JsonElement fallback)
    {
        var json = NativeMethods.ReadAndFreeString(ptr);
        if (string.IsNullOrEmpty(json)) return fallback;
        try
        {
            return JsonDocument.Parse(json).RootElement.Clone();
        }
        catch
        {
            return fallback;
        }
    }
}
