using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace AgentShield;

/// <summary>
/// Framework-agnostic orchestrator for guarded agent runs. Bridges
/// the <see cref="GuardrailsRuntime"/> / <see cref="GuardrailsSession"/>
/// API to ergonomic <c>RunAsync</c> / <c>RunStreamedAsync</c> /
/// <c>ProtectToolAsync</c> entry points. Mirrors the Python
/// <c>Shield</c> orchestrator and the Node <c>Shield</c> class so the
/// customer-visible drop-in story is identical across all SDKs.
///
/// <example>
/// <code>
/// using var shield = Shield.FromYaml("guardrails.yaml")
///     .WithLlm(myLlm)
///     .Build();
/// var answer = await shield.RunAsync(async () =&gt; await agent.AskAsync(input));
/// </code>
/// </example>
///
/// <para>
/// This class is intentionally additive — it does not replace any of
/// the existing per-framework integrations
/// (<c>AgentShieldMiddleware</c>, <c>AgentShieldFilter</c>,
/// <c>GuardedChatClient</c>); customers can opt in to whichever
/// integration shape suits their codebase.
/// </para>
/// </summary>
public sealed class Shield : IDisposable
{
    private readonly GuardrailsRuntime _runtime;
    private readonly bool _ownsRuntime;
    private GuardrailsSession _session;
    private bool _ownsSession;
    private readonly CapabilityReport _capabilities;
    private readonly ShieldMode _mode;
    private readonly OnBlockPolicy _onBlock;
    private readonly Func<StageVerdict?, string, object?>? _onBlockCallback;
    private readonly FrameworkBundle? _bundle;
    private bool _disposed;

    private static readonly AsyncLocal<GuardrailsSession?> _ambientSession = new();
    private static readonly AsyncLocal<string?> _ambientInput = new();

    /// <summary>
    /// Ambient session for the current async flow, or <c>null</c> if
    /// no <c>RunAsync</c> / <c>RunStreamedAsync</c> turn is active in
    /// this flow. Mirrors <c>Activity.Current</c> / <c>HttpContext.Current</c>.
    /// </summary>
    public static GuardrailsSession? CurrentSession => _ambientSession.Value;

    /// <summary>
    /// Ambient user input for the current guarded turn after Stage 1
    /// mutations have been applied. Empty when no guarded turn is
    /// active in this async flow.
    /// </summary>
    public static string CurrentUserInput => _ambientInput.Value ?? string.Empty;

    internal Shield(
        GuardrailsRuntime runtime,
        bool ownsRuntime,
        GuardrailsSession session,
        bool ownsSession,
        CapabilityReport capabilities,
        ShieldMode mode,
        OnBlockPolicy onBlock,
        Func<StageVerdict?, string, object?>? onBlockCallback,
        FrameworkBundle? bundle)
    {
        _runtime = runtime ?? throw new ArgumentNullException(nameof(runtime));
        _ownsRuntime = ownsRuntime;
        _session = session ?? throw new ArgumentNullException(nameof(session));
        _ownsSession = ownsSession;
        _capabilities = capabilities ?? throw new ArgumentNullException(nameof(capabilities));
        // Shadow mode (#14) forces Monitor.
        _mode = runtime.Mode == "shadow" ? ShieldMode.Monitor : mode;
        _onBlock = onBlock;
        _onBlockCallback = onBlockCallback;
        _bundle = bundle;
    }

    // ── Construction ──────────────────────────────────────────────

    /// <summary>Build a Shield from a single guardrails YAML file.</summary>
    public static ShieldBuilder FromYaml(string path) =>
        new(RuntimeBuilder.FromYaml(path));

    /// <summary>Build a Shield from a chain of guardrails YAML files
    /// (merged left → right with leaf-wins semantics).</summary>
    public static ShieldBuilder FromYaml(IReadOnlyList<string> paths) =>
        new(RuntimeBuilder.FromYamlChain(paths));

    /// <summary>Build a Shield from an existing <see cref="GuardrailsRuntime"/>.
    /// The Shield does not take ownership; the caller is still responsible
    /// for disposing the runtime.</summary>
    public static ShieldBuilder FromRuntime(GuardrailsRuntime runtime) =>
        new(runtime, ownsRuntime: false);

    // ── Surface ───────────────────────────────────────────────────

    /// <summary>The active per-shield session.</summary>
    public GuardrailsSession Session => _session;

    /// <summary>The underlying guardrails runtime.</summary>
    public GuardrailsRuntime Runtime => _runtime;

    /// <summary>The capability profile of this Shield (set by the
    /// adapter extension method).</summary>
    public CapabilityReport Capabilities => _capabilities;

    /// <summary>Behavioural mode (Enforce / Monitor).</summary>
    public ShieldMode Mode => _mode;

    /// <summary>The optional framework bundle attached at build time.</summary>
    public FrameworkBundle? Bundle => _bundle;

    /// <summary>
    /// Replace the active session. Disposes the previous session iff
    /// this Shield owned it. Returns <c>this</c> for fluent chaining.
    /// </summary>
    public Shield WithSession(GuardrailsSession session)
    {
        if (session == null) throw new ArgumentNullException(nameof(session));
        if (_ownsSession) _session.Dispose();
        _session = session;
        _ownsSession = false;
        return this;
    }

    /// <summary>
    /// Functional sibling of <see cref="WithSession"/>: returns a NEW
    /// <see cref="Shield"/> bound to a brand-new <see cref="GuardrailsSession"/>
    /// spawned from the same runtime. The original Shield (and its
    /// session) is not mutated, satisfying the post-build immutability
    /// contract documented in <c>spec/SPECIFICATION.md</c>.
    /// </summary>
    /// <remarks>
    /// The returned Shield does not own the underlying runtime — only
    /// the original Shield (or whichever instance was created via
    /// <see cref="ShieldBuilder.Build"/>) owns the runtime and is
    /// responsible for disposing it. The returned Shield does own its
    /// fresh session and will dispose it when the Shield is disposed.
    /// Mirrors the Rust <c>Shield::with_fresh_session</c>, the Node
    /// <c>shield.withFreshSession()</c>, and the Python
    /// <c>shield.with_fresh_session()</c> APIs.
    /// </remarks>
    public Shield WithFreshSession()
    {
        ThrowIfDisposed();
        var fresh = _runtime.NewSession();
        return new Shield(
            _runtime,
            ownsRuntime: false,
            fresh,
            ownsSession: true,
            _capabilities,
            _mode,
            _onBlock,
            _onBlockCallback,
            _bundle);
    }

    // ── BeforeInvokeAsync ─────────────────────────────────────────

    /// <summary>
    /// Pre-flight Stage 1 check. Returns <c>null</c> when the input
    /// is allowed, or the canonical block message when Stage 1
    /// denies. Useful for "is this user input safe to even start
    /// processing?" guards at API entry points before any expensive
    /// agent work.
    ///
    /// Mirrors the Python / Node <c>before_invoke()</c> ergonomic
    /// helper. The block / proceed decision is delegated to
    /// <see cref="VerdictDispatcher.DispatchStage"/> so the message
    /// format is byte-equivalent across SDKs.
    /// </summary>
    public Task<string?> BeforeInvokeAsync(string input, CancellationToken ct = default)
    {
        ThrowIfDisposed();
        if (input == null) throw new ArgumentNullException(nameof(input));
        ct.ThrowIfCancellationRequested();
        return Task.FromResult(BeforeInvoke(input));
    }

    private string? BeforeInvoke(string input)
    {
        try
        {
            _session.BeginTurn();
        }
        catch
        {
            if (_mode == ShieldMode.Enforce) throw;
        }

        var verdict = _session.ValidateInput(input);
        var dispatch = VerdictDispatcher.DispatchStage(
            verdict,
            OnBlockPolicy.ReturnBlocked,
            _mode);

        try
        {
            _session.EndTurn();
        }
        catch
        {
            // Logged but not surfaced; turn-end errors mustn't mask
            // the block decision.
        }

        if (dispatch.OverrideToProceed)
        {
            return null;
        }

        return dispatch.Action.Kind switch
        {
            "return_blocked" => dispatch.Action.Message,
            "raise" => throw new AgentShieldBlockedException(
                verdict,
                dispatch.Action.Message ?? VerdictDispatcher.FormatBlockMessage(verdict)),
            "return_verdict" or "invoke_custom" => VerdictDispatcher.FormatBlockMessage(verdict),
            _ => null,
        };
    }

    // ── RunAsync ──────────────────────────────────────────────────

    /// <summary>
    /// Run an arbitrary async callback under Stage 1 + Stage 5
    /// enforcement. The callback's first user message should be
    /// supplied via <c>userInput</c>; if the callback's input is
    /// implicit (e.g. the underlying agent reads its own state) an
    /// empty string is acceptable and Stage 1 will validate "".
    /// </summary>
    public Task<TResult> RunAsync<TResult>(Func<Task<TResult>> execute, CancellationToken ct = default) =>
        RunAsync(string.Empty, execute, ct);

    /// <summary>
    /// Run an arbitrary async callback under Stage 1 + Stage 5
    /// enforcement, validating <paramref name="userInput"/> at Stage 1.
    /// </summary>
    public Task<TResult> RunAsync<TResult>(string userInput, Func<Task<TResult>> execute, CancellationToken ct = default)
    {
        ThrowIfDisposed();
        if (execute == null) throw new ArgumentNullException(nameof(execute));
        return GuardedRunner.RunGuardedTurnAsync(
            _session,
            userInput,
            execute,
            _mode,
            DispatchBlocked<TResult>,
            _ambientSession,
            _ambientInput,
            ct);
    }

    /// <summary>
    /// Run an arbitrary async callback under Stage 1 + Stage 5
    /// enforcement, passing the post-Stage-1 input value into the
    /// callback. This overload is the preferred shape when Stage 1
    /// policies may redact or otherwise transform input.
    /// </summary>
    public Task<TResult> RunAsync<TResult>(string userInput, Func<string, Task<TResult>> execute, CancellationToken ct = default)
    {
        ThrowIfDisposed();
        if (execute == null) throw new ArgumentNullException(nameof(execute));
        return RunAsync(userInput, () => execute(CurrentUserInput), ct);
    }

    // ── RunStreamedAsync ──────────────────────────────────────────

    /// <summary>
    /// Stream a sequence of output text chunks under Stage 1 + Stage 5
    /// enforcement (per-chunk Stage 5 validation via the streaming guard).
    /// </summary>
    public IAsyncEnumerable<string> RunStreamedAsync(Func<IAsyncEnumerable<string>> execute, CancellationToken ct = default) =>
        RunStreamedAsync(string.Empty, execute, ct);

    /// <summary>
    /// Stream a sequence of output text chunks under Stage 1 + Stage 5
    /// enforcement, validating <paramref name="userInput"/> at Stage 1.
    /// </summary>
    public IAsyncEnumerable<string> RunStreamedAsync(string userInput, Func<IAsyncEnumerable<string>> execute, CancellationToken ct = default)
    {
        ThrowIfDisposed();
        if (execute == null) throw new ArgumentNullException(nameof(execute));
        return GuardedRunner.RunStreamedAsync(
            _session,
            userInput,
            execute,
            _mode,
            _ambientSession,
            _ambientInput,
            ct);
    }

    // ── ProtectToolAsync ──────────────────────────────────────────

    /// <summary>
    /// Run a tool invocation under Stage 2 + Stage 3 + Stage 4
    /// enforcement (with <c>record_tool_*</c> bookkeeping). Returns
    /// <c>(Blocked, Output)</c>; when <c>Blocked</c> is true the
    /// <c>Output</c> is the canonical <c>[GUARDRAIL ACTION] reason</c>
    /// message and the underlying tool was either short-circuited or
    /// its result was rejected by Stage 4.
    ///
    /// Pass <paramref name="toolCallId"/> (the upstream model's
    /// tool-call handle, e.g. OpenAI <c>tool_call.id</c> or Anthropic
    /// <c>tool_use.id</c>) so §16.0 binding can match Stage 4 back to
    /// the canonical Stage 3 invocation under concurrent same-name
    /// calls. When omitted, a stable per-call id is minted internally.
    /// </summary>
    public Task<(bool Blocked, string Output)> ProtectToolAsync(
        string toolName,
        JsonElement parameters,
        Func<JsonElement, Task<string>> execute,
        CancellationToken ct = default,
        string? toolCallId = null)
    {
        ThrowIfDisposed();
        if (string.IsNullOrEmpty(toolName)) throw new ArgumentException("toolName is required", nameof(toolName));
        if (execute == null) throw new ArgumentNullException(nameof(execute));
        return GuardedRunner.RunGuardedToolAsync(_session, toolName, parameters, execute, _mode, ct, toolCallId);
    }

    // ── ProtectTools<TIn, TOut> ───────────────────────────────────

    /// <summary>
    /// Wrap a list of framework tools with Stage 2 + 3 + 4 enforcement
    /// using the supplied <see cref="IToolWrapper{TIn,TOut}"/>. The
    /// returned list contains framework-shaped tools whose body
    /// delegates to <see cref="ProtectToolAsync"/>.
    /// </summary>
    public IReadOnlyList<TOut> ProtectTools<TIn, TOut>(
        IReadOnlyList<TIn> tools,
        IToolWrapper<TIn, TOut> wrapper)
    {
        ThrowIfDisposed();
        if (tools == null) throw new ArgumentNullException(nameof(tools));
        if (wrapper == null) throw new ArgumentNullException(nameof(wrapper));

        var results = new List<TOut>(tools.Count);
        foreach (var tool in tools)
        {
            var capturedTool = tool;
            var capturedName = wrapper.GetName(tool);
            Func<JsonElement, Task<string>> guarded = async args =>
            {
                var (_, output) = await ProtectToolAsync(
                    capturedName, args,
                    mutatedArgs => wrapper.InvokeAsync(capturedTool, mutatedArgs),
                    default).ConfigureAwait(false);
                return output;
            };
            results.Add(wrapper.Wrap(capturedTool, guarded));
        }
        return results;
    }

    // ── Block dispatch ────────────────────────────────────────────

    private TResult DispatchBlocked<TResult>(StageVerdict verdict, string message)
    {
        // Custom callback short-circuits the canonical dispatcher: the
        // host owns the decision tree once they've registered one.
        if (_onBlockCallback != null)
        {
            var result = _onBlockCallback(verdict, message);
            return CoerceToResult<TResult>(result, verdict, message);
        }

        // Otherwise route through the canonical core dispatcher so the
        // .NET decision tree is byte-equivalent to the Python / Node /
        // Rust SDKs. We re-derive `message` from the dispatcher's
        // action payload to guarantee the canonical string surfaces
        // verbatim.
        var dispatch = VerdictDispatcher.DispatchStage(verdict, _onBlock, _mode);
        var action = dispatch.Action;
        switch (action.Kind)
        {
            case "raise":
                throw new AgentShieldBlockedException(verdict, action.Message ?? message);

            case "return_verdict":
                if (verdict is TResult v) return v;
                throw new AgentShieldBlockedException(verdict,
                    $"OnBlockPolicy.ReturnVerdict requires TResult assignable from StageVerdict; got {typeof(TResult).Name}.");

            case "return_blocked":
            default:
                var msg = action.Message ?? message;
                if (typeof(TResult) == typeof(string))
                    return (TResult)(object)msg;
                if (typeof(TResult) == typeof(object))
                    return (TResult)(object)msg;
                // Default for non-string TResult: throw so the caller
                // knows to either supply a callback or use string.
                throw new AgentShieldBlockedException(verdict, msg);
        }
    }

    private static TResult CoerceToResult<TResult>(object? value, StageVerdict verdict, string message)
    {
        if (value is null)
        {
            if (default(TResult) is null) return default!;
            throw new AgentShieldBlockedException(verdict,
                $"on-block callback returned null but {typeof(TResult).Name} is non-nullable.");
        }
        if (value is TResult cast) return cast;
        if (typeof(TResult) == typeof(string))
            return (TResult)(object)(value.ToString() ?? message);
        throw new AgentShieldBlockedException(verdict,
            $"on-block callback returned {value.GetType().Name}, cannot coerce to {typeof(TResult).Name}.");
    }

    // ── IDisposable ───────────────────────────────────────────────

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        if (_ownsSession)
        {
            try { _session.Dispose(); } catch { }
        }
        if (_ownsRuntime)
        {
            try { _runtime.Dispose(); } catch { }
        }
        GC.SuppressFinalize(this);
    }

    private void ThrowIfDisposed()
    {
        if (_disposed) throw new GuardrailsDisposedException(nameof(Shield));
    }
}

