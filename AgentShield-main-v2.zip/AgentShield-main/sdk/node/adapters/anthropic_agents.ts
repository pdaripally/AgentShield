// Anthropic Agents adapter for the Agent Shield Node SDK.
//
// Integrates with the Anthropic Node SDK (`@anthropic-ai/sdk`) and its
// native `BetaToolRunner` agent loop. The runner owns the conversation
// (model → tool_use → tool_result → model → … → end_turn); we wrap each
// tool's `run` callback to enforce Stages 2 + 3 + 4. Stage 1 fires
// before `client.beta.messages.toolRunner(...)`. Stage 5 fires against
// the runner's final assistant text.
//
// This brings Node to parity with the Python reference adapter at
// `sdk/python/agent_shield/adapters/anthropic_agents.py`, which uses
// `BetaAsyncToolRunner`. Previously the Node adapter reimplemented the
// Messages-API tool loop on top of raw `client.messages.create`; that
// duplicated bookkeeping (assistant-message pushing, JSON-parsing of
// tool args, iteration counting) the SDK already does correctly.
//
// Three integration patterns:
//
//   Pattern A — adapter owns the agent loop (`BetaToolRunner`):
//       const text = await shield.runAnthropicAgent({
//         client, model, tools, messages,
//         dispatchTool: (name, args) => ...,
//       })
//
//   Pattern A streaming — chunk-level Stage 5 over text deltas:
//       for await (const ev of shield.runAnthropicAgentStreamed(...)) {
//         if (ev.type === 'text_delta') process.stdout.write(ev.text)
//       }
//
//   Pattern B — protect a customer-owned dispatcher:
//       const { dispatchTool } = shield.protectAnthropicTools({
//         tools, dispatchTool: (name, args) => ...,
//       })
//
//   Pattern C — Stage 1 + Stage 5 only (drop-in around an opaque agent):
//       await shield.run(() => userAgentLoop(), { userInput })
//
// `runAnthropicAgent` / `runAnthropicAgentStreamed` require
// `@anthropic-ai/sdk` to be installed. It is declared as an **optional
// peer dependency** so customers using only `protectAnthropicTools` or
// `shield.run` need not pull it in. The dynamic `import()` emits a
// clear install hint when the dep is missing.
//
// Side-effect installation: `import`-ing this module monkey-patches
//
//   - `ShieldBuilder.prototype.withAnthropic(opts?)`         — selects
//     the Anthropic capability bundle for the build.
//   - `Shield.prototype.runAnthropicAgent(opts)`             — Pattern A.
//   - `Shield.prototype.protectAnthropicTools(opts)`         — Pattern B.
//   - `Shield.prototype.runAnthropicAgentStreamed(opts)`     — streaming.
//
// What this module deliberately does NOT touch (anti
// prototype-pollution guarantees):
//
//   - `Shield.BUNDLE`. Customers explicitly select the bundle via
//     `.withAnthropic()` on the builder.
//   - `Shield.prototype.run`. The base class owns the canonical
//     Stage 1 + Stage 5 wrapper (`shield.run(fn)`).
//   - `Shield.prototype.protectTool`. The base class owns the
//     canonical Stage 2/3/4 wrapper.

import {
  CapabilityReport,
  ConfigurationMissingModelError,
  CoverageLevel,
  Shield,
  ShieldBuilder,
  type AdapterContext,
  type SessionLike,
  type StageVerdictLike,
  type CapabilityBundle,
  type LlmCallerFactory,
} from '../shield.js'
import { randomUUID } from 'node:crypto'

// ─── Module augmentation: install adapter methods on Shield/ShieldBuilder

declare module '../shield.js' {
  interface ShieldBuilder {
    /** Bind this builder to the Anthropic Agents capability bundle. */
    withAnthropic(opts?: AnthropicWithOpts): this
  }
  interface Shield {
    /** Pattern A — adapter owns the Anthropic agent loop. */
    runAnthropicAgent(opts: AnthropicRunAgentOpts): Promise<string>
    /** Pattern B — wrap a customer-owned tool dispatcher. */
    protectAnthropicTools(
      opts: AnthropicProtectToolsOpts,
    ): AnthropicProtectToolsResult
    /** Pattern A — streaming variant of `runAnthropicAgent`. */
    runAnthropicAgentStreamed(
      opts: AnthropicRunStreamedOpts,
    ): AsyncGenerator<AnthropicStreamEmission, void, void>
  }
}

// ─── Public opts / result types ───────────────────────────────────

/** Minimal structural shape of the Anthropic SDK client we depend on.
 *
 *  The runner-based loop drives `client.beta.messages.toolRunner(...)`.
 *  The legacy `messages.create` slot is retained because the LLM-caller
 *  factory (used by Stage-3 / Stage-5 LLM judges declared in YAML) still
 *  calls it directly — it is not part of the customer-visible agent
 *  loop. */
export interface AnthropicClient {
  messages: {
    create(args: Record<string, unknown>): Promise<AnthropicMessageResponse>
  }
  beta?: {
    messages?: {
      toolRunner?: (
        body: Record<string, unknown>,
        options?: Record<string, unknown>,
      ) => AnthropicBetaToolRunnerLike
    }
  }
}

/** Structural slice of `BetaToolRunner` we depend on. Kept minimal so
 *  tests can stand up a fake client without bringing in the full
 *  `@anthropic-ai/sdk` dependency. */
export interface AnthropicBetaToolRunnerLike {
  /** Makes the runner directly awaitable; resolves to the final
   *  assistant `BetaMessage`. Equivalent to `runUntilDone()`. */
  then?: (
    onfulfilled?: (value: AnthropicMessageResponse) => unknown,
    onrejected?: (reason: unknown) => unknown,
  ) => Promise<unknown>
  /** Streaming mode: yields one `BetaMessageStream` per assistant
   *  iteration. Only present when `stream: true` was passed. */
  [Symbol.asyncIterator]?: () => AsyncIterator<AnthropicBetaMessageStreamLike>
  runUntilDone?: () => Promise<AnthropicMessageResponse>
}

/** Structural slice of `BetaMessageStream` — the per-iteration stream
 *  object yielded by the runner's async iterator in streaming mode. */
export interface AnthropicBetaMessageStreamLike {
  /** `on('text', (delta, snapshot) => ...)` is the canonical text-delta
   *  hook. Other events (`message`, `contentBlock`, `finalMessage`,
   *  `streamEvent`) exist but are not required for chunk-level Stage 5. */
  on?: (event: string, listener: (...args: unknown[]) => void) => unknown
  finalMessage?: () => Promise<AnthropicMessageResponse>
}

export interface AnthropicMessageResponse {
  content?: AnthropicContentBlock[]
  stop_reason?: string
}

export type AnthropicContentBlock =
  | { type: 'text'; text: string }
  | { type: 'tool_use'; id: string; name: string; input: Record<string, unknown> }
  | { type: string; [key: string]: unknown }

export interface AnthropicMessage {
  role: 'user' | 'assistant'
  content: string | AnthropicContentBlock[]
}

export interface AnthropicLlmRequest {
  prompt?: string
  configurationId?: string | null
}

export type AnthropicToolDispatch = (
  name: string,
  input: Record<string, unknown>,
) => Promise<unknown> | unknown

/** Emissions yielded by `runAnthropicAgentStreamed`. The
 *  BetaToolRunner owns the tool_use → tool_result handshake
 *  internally, so emitted events are only text deltas, the terminal
 *  final-text event, and (on block) a `blocked` event. */
export type AnthropicStreamEmission =
  | { type: 'text_delta'; text: string }
  | { type: 'final'; text: string }
  | { type: 'blocked'; message: string }

export interface AnthropicWithOpts {
  /** Reserved for future per-bundle options. */
  [key: string]: unknown
}

export interface AnthropicRunAgentOpts {
  client: AnthropicClient
  /** Required: the Claude SKU that drives the BetaToolRunner loop.
   *  A security library MUST NOT pick a model on the customer's
   *  behalf — this field has no default. */
  model: string
  /** Raw Anthropic tool definitions `{name, description, input_schema}`.
   *  Each is wrapped with a guarded `run` callback that flows tool
   *  invocations through Stages 2 + 3 + 4 before reaching the
   *  customer-supplied `dispatchTool`. */
  tools?: ReadonlyArray<unknown>
  messages: AnthropicMessage[]
  dispatchTool: AnthropicToolDispatch
  system?: string
  /** Forwarded to the runner as `max_iterations`. */
  maxIters?: number
  maxTokens?: number
  requestExtras?: Record<string, unknown>
  /** Test seam — inject a fake `@anthropic-ai/sdk` module to bypass
   *  the optional peer-dep import. Not part of the supported public
   *  API; the underscore prefix marks it internal. */
  _anthropicModule?: AnthropicSdkLikeModule
}

export interface AnthropicProtectToolsOpts {
  tools?: ReadonlyArray<unknown>
  dispatchTool: AnthropicToolDispatch
  session?: SessionLike
}

export interface AnthropicProtectToolsResult {
  tools: ReadonlyArray<unknown>
  dispatchTool: (
    name: string,
    input: Record<string, unknown>,
  ) => Promise<string | { blocked: true; blockMessage: string }>
}

export interface AnthropicRunStreamedOpts {
  client: AnthropicClient
  /** Required: the Claude SKU. A security library MUST NOT pick a
   *  model on the customer's behalf. */
  model: string
  tools?: ReadonlyArray<unknown>
  messages: AnthropicMessage[]
  dispatchTool: AnthropicToolDispatch
  system?: string
  maxIters?: number
  maxTokens?: number
  requestExtras?: Record<string, unknown>
  _anthropicModule?: AnthropicSdkLikeModule
}

// ─── Capability bundle ────────────────────────────────────────────

const _CAPABILITIES = new CapabilityReport({
  framework: 'anthropic_agents',
  inputValidation: CoverageLevel.FULL,
  stateValidation: CoverageLevel.FULL,
  toolAuthorization: CoverageLevel.FULL,
  toolExecutionValidation: CoverageLevel.FULL,
  toolOutputValidation: CoverageLevel.FULL,
  outputValidation: CoverageLevel.FULL,
  streamingOutput: CoverageLevel.PARTIAL,
  notes: [
    'streaming chunk-level Stage-5 covers text deltas only; tool dispatch is gated by Stage 2/3/4 inside the BetaToolRunner',
  ],
})

// ─── LLM caller factory ───────────────────────────────────────────
//
// `withClient(client)` on `ShieldBuilder` invokes
// `bundle.llmCallerFactory.makeCaller(client, ctx)`. The runtime
// expects an async caller signature `(req) -> string`. We call the
// Anthropic Messages API directly here — this caller is for
// runtime-internal LLM judges declared in YAML `configurations:`,
// not the customer's agent loop, so it is independent of the
// BetaToolRunner rewrite.
//
// Model is sourced strictly from the YAML's `configurations[]` entry
// via `ctx.configurationResolver` (so a `configurations: [{id:
// stage3-judge, type: llm, model: claude-3-7-sonnet}]` actually
// drives that value). A security library MUST NOT pick a model on
// the customer's behalf — when the resolver cannot find a matching
// entry, or the entry omits `model:`, the caller raises
// {@link ConfigurationMissingModelError}. `max_tokens` is treated
// differently: the Anthropic Messages API requires it but the
// numeric budget is not security-sensitive, so missing values fall
// back to {@link DEFAULT_FALLBACK_MAX_TOKENS}.

/**
 * Default `max_tokens` used by the Anthropic LLM-judge caller when
 * the resolved configuration omits `max_tokens:`. 1024 is the
 * historical Node default; the numeric budget is not
 * security-sensitive (unlike model selection), so defaulting it is
 * acceptable.
 */
export const DEFAULT_FALLBACK_MAX_TOKENS = 1024

export interface AnthropicLlmCallerOpts {
  /**
   * Fallback `max_tokens` used when the resolved configuration has
   * none. Defaults to {@link DEFAULT_FALLBACK_MAX_TOKENS}.
   */
  maxTokens?: number
  /**
   * Optional resolver that maps a `configurationId` to its
   * camelCased `configurations[]` entry — typically
   * `runtime.llmConfiguration` bound by `ShieldBuilder`. When the
   * resolver returns `null` or a configuration without `model:`, the
   * caller throws {@link ConfigurationMissingModelError}.
   * Resolver exceptions are routed through `recordAdapterError`
   * before being surfaced as the missing-model error.
   */
  configurationResolver?: (
    configurationId: string | null | undefined,
  ) => import('../index.js').LlmConfiguration | null
  /** Same shape as {@link AdapterContext.recordAdapterError}; used
   *  to surface resolver exceptions through observability. */
  recordAdapterError?: (error: unknown) => void
}

/**
 * Build an LLM caller from an Anthropic client. The runtime invokes
 * `caller({ configurationId, prompt }) -> string` from the napi
 * boundary; we use `messages.create` and extract the final text.
 *
 * When `opts.configurationResolver` is supplied (the production
 * path — `ShieldBuilder` wires it through `AdapterContext`), the
 * produced caller looks up the YAML's `configurations[]` entry by
 * `configurationId` at call time and uses its `model:` /
 * `max_tokens:` fields. `model:` is required (missing raises
 * {@link ConfigurationMissingModelError}); missing `max_tokens:`
 * falls back to {@link DEFAULT_FALLBACK_MAX_TOKENS} since the token
 * budget is not security-sensitive.
 */
export function makeLlmCaller(
  client: AnthropicClient,
  opts: AnthropicLlmCallerOpts = {},
): (req: AnthropicLlmRequest) => Promise<string> {
  const fallbackMaxTokens = opts.maxTokens ?? DEFAULT_FALLBACK_MAX_TOKENS
  const resolver = opts.configurationResolver
  const recordAdapterError = opts.recordAdapterError
  return async (req: AnthropicLlmRequest): Promise<string> => {
    let cfg: import('../index.js').LlmConfiguration | null = null
    if (resolver && req.configurationId) {
      try {
        cfg = resolver(req.configurationId)
      } catch (err) {
        // Resolver lookup must never break the LLM caller with an
        // internal error — emit an adapter-error event so SREs see a
        // distinct signal, then surface the load-time-shaped
        // ConfigurationMissingModelError below.
        recordAdapterError?.(
          new Error(
            `anthropic_agents llm caller: configurationResolver raised ` +
              `for configurationId=${JSON.stringify(req.configurationId)}: ` +
              `${err instanceof Error ? err.message : String(err)}`,
          ),
        )
        cfg = null
      }
    }

    if (!cfg || typeof cfg.model !== 'string' || !cfg.model) {
      // A security library MUST NOT pick a model on the customer's
      // behalf. Raise so the YAML is the only place where the model
      // is declared.
      throw new ConfigurationMissingModelError(req.configurationId)
    }
    const model = cfg.model

    const maxTokens =
      typeof cfg.maxTokens === 'number' ? cfg.maxTokens : fallbackMaxTokens

    const kwargs: Record<string, unknown> = {
      model,
      max_tokens: maxTokens,
      messages: [{ role: 'user', content: req.prompt ?? '' }],
    }
    // Forward any other Messages-API-supported scalar fields the
    // resolved configuration declared. Currently `temperature` is
    // the only one camel-cased on `LlmConfiguration`'s open index
    // signature; we pick it up generically so future spec additions
    // ride through without an adapter change.
    const temp = (cfg as Record<string, unknown>).temperature
    if (typeof temp === 'number') kwargs.temperature = temp
    const topP = (cfg as Record<string, unknown>).topP
    if (typeof topP === 'number') kwargs.top_p = topP
    const stopSeq = (cfg as Record<string, unknown>).stopSequences
    if (Array.isArray(stopSeq)) kwargs.stop_sequences = stopSeq

    try {
      const res = await client.messages.create(kwargs)
      return _extractFinalText(res)
    } catch (err) {
      // Surface the original provider error through observability
      // BEFORE returning the fail-closed block string, so SREs see
      // a real "Anthropic API errored" signal instead of inferring
      // a policy block.
      try {
        recordAdapterError?.(err)
      } catch {
        // recordAdapterError swallows provider errors itself, but
        // belt-and-braces: never propagate out of the catch path.
      }
      const msg = err instanceof Error ? err.message : String(err)
      return JSON.stringify({
        decision: 'block',
        reason: `anthropic llm caller error: ${msg}`,
      })
    }
  }
}

const _llmCallerFactory: LlmCallerFactory<AnthropicClient, (req: AnthropicLlmRequest) => Promise<string>> = {
  makeCaller(client: AnthropicClient, ctx?: AdapterContext) {
    return makeLlmCaller(client, {
      configurationResolver: ctx?.configurationResolver,
      recordAdapterError: (err) => {
        try {
          ctx?.recordAdapterError(err)
        } catch {
          /* recordAdapterError swallows internally; belt-and-braces */
        }
      },
    })
  },
}

// ─── Bundle ───────────────────────────────────────────────────────

const _BUNDLE: CapabilityBundle = Object.freeze({
  name: 'anthropic_agents',
  llmCallerFactory: _llmCallerFactory as unknown as LlmCallerFactory,
  // Anthropic's tool definitions are passive ({name, description,
  // input_schema}); the dispatcher is customer-owned. The
  // adapter-owned loop in `runAnthropicAgent` does the wrapping; the
  // generic Shield.protectTools (which expects a ToolWrapper) is not
  // applicable. `protectAnthropicTools` provides the wrapped
  // dispatcher path instead.
  capabilities: _CAPABILITIES,
})

// ─── Helpers ──────────────────────────────────────────────────────

function _formatBlock(verdict: StageVerdictLike | null | undefined): string {
  const action = (verdict?.action ?? 'block').toUpperCase()
  const reason = verdict?.reason ?? 'blocked by policy'
  return `[GUARDRAIL ${action}] ${reason}`
}

function _extractFinalText(message: AnthropicMessageResponse | null | undefined): string {
  if (!message || typeof message !== 'object') return ''
  const blocks: AnthropicContentBlock[] = Array.isArray(message.content) ? message.content : []
  const parts: string[] = []
  for (const b of blocks) {
    if (b && b.type === 'text' && typeof (b as { text?: unknown }).text === 'string') {
      parts.push((b as { text: string }).text)
    }
  }
  return parts.join('')
}

function _extractUserInputFromMessages(messages: AnthropicMessage[] | undefined): string {
  if (!Array.isArray(messages) || messages.length === 0) return ''
  // Take the most recent user-role text content. Tool_result blocks
  // are excluded — they are framework-internal, not user input.
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i]
    if (!m || m.role !== 'user') continue
    if (typeof m.content === 'string') return m.content
    if (Array.isArray(m.content)) {
      const parts: string[] = []
      for (const block of m.content) {
        if (typeof block === 'string') {
          parts.push(block)
        } else if (block && block.type === 'text' && typeof (block as { text?: unknown }).text === 'string') {
          parts.push((block as { text: string }).text)
        }
      }
      if (parts.length > 0) return parts.join('\n')
    }
  }
  return ''
}

function _cleanArgs(args: Record<string, unknown> | null | undefined): Record<string, unknown> {
  const cleaned: Record<string, unknown> = { ...(args ?? {}) }
  for (const k of Object.keys(cleaned)) {
    if (cleaned[k] === undefined || cleaned[k] === null) delete cleaned[k]
  }
  return cleaned
}

function _stringifyToolResult(raw: unknown): string {
  if (raw === null || raw === undefined) return ''
  if (typeof raw === 'string') return raw
  try {
    return JSON.stringify(raw)
  } catch {
    return String(raw)
  }
}

// ─── @anthropic-ai/sdk loader (lazy, with a test seam) ────────────

/** Structural slice of `@anthropic-ai/sdk` we depend on. We only need
 *  `ToolError`: the `BetaToolRunner` instance is obtained through the
 *  customer's client (`client.beta.messages.toolRunner(...)`), so the
 *  SDK module itself is only loaded to access `ToolError` — thrown
 *  inside a guarded `run` callback to signal the runner that the
 *  resulting tool_result block should carry `is_error: true` with our
 *  pre-formatted content (instead of being wrapped in the runner's
 *  default `Error: ...` prefix). */
export interface AnthropicSdkLikeModule {
  ToolError: new (content: string | unknown[]) => Error
}

let _anthropicModuleOverride: AnthropicSdkLikeModule | null = null

/** Test seam — install / clear a fake `@anthropic-ai/sdk` module.
 *  Used exclusively by the adapter test suite; not exported from the
 *  package's public entry point. */
export function _setAnthropicModuleForTesting(
  mod: AnthropicSdkLikeModule | null,
): void {
  _anthropicModuleOverride = mod
}

async function _loadAnthropicModule(
  override?: AnthropicSdkLikeModule,
): Promise<AnthropicSdkLikeModule> {
  if (override) return override
  if (_anthropicModuleOverride) return _anthropicModuleOverride
  try {
    // Dynamic import keeps `@anthropic-ai/sdk` an optional peer dep —
    // customers using only `protectAnthropicTools` or `shield.run`
    // need not install it. The `@ts-expect-error` is needed because
    // the peer dep is optional and not necessarily resolvable at
    // `tsc` time.
    // @ts-expect-error -- optional peer dep
    const mod = (await import('@anthropic-ai/sdk')) as Record<string, unknown>
    const ToolError = (mod.ToolError ?? (mod.default as Record<string, unknown> | undefined)?.ToolError) as
      | (new (content: string | unknown[]) => Error)
      | undefined
    if (!ToolError) {
      throw new Error(
        '`@anthropic-ai/sdk` is installed but does not export `ToolError`. ' +
          'This adapter requires v0.40 or newer (the version that introduced `BetaToolRunner`).',
      )
    }
    return { ToolError }
  } catch (err) {
    throw new Error(
      'runAnthropicAgent: `@anthropic-ai/sdk` is not installed. Install ' +
        'with `npm i @anthropic-ai/sdk` (v0.40+). Underlying error: ' +
        String(err),
    )
  }
}

// ─── Tool wrapping ────────────────────────────────────────────────

interface AnthropicRunnableToolDef {
  name: string
  description?: string
  input_schema?: Record<string, unknown>
  [key: string]: unknown
}

/** Stage 2 + 3 + 4 enforcement around a single tool dispatch. Returns
 *  a string (the guarded tool output) for the runner to embed in the
 *  next tool_result block, or throws a `ToolError(...)` so the runner
 *  emits `is_error: true` with our formatted block message verbatim. */
async function _guardedToolDispatch(
  session: SessionLike,
  toolName: string,
  args: Record<string, unknown>,
  dispatch: AnthropicToolDispatch,
  ToolError: new (content: string | unknown[]) => Error,
): Promise<string> {
  const cleaned = _cleanArgs(args)

  // §16.0 binding: Pattern B helper does not receive the model's
  // tool_use.id (it's invoked directly by callers without a
  // tool_use context). Generate a stable per-call id so concurrent
  // same-name calls on the same session bind to distinct Stage 3
  // invocations.
  const callId = randomUUID()

  // Stage 2 (state) + Stage 3 (tool execution).
  const callOutcome = await session.validateToolCall(toolName, cleaned, callId)
  if (!callOutcome.verdict.allowed) {
    throw new ToolError(
      `${_formatBlock(callOutcome.verdict)} (tool: ${toolName})`,
    )
  }
  const effective = (callOutcome.params as Record<string, unknown> | undefined) ?? cleaned

  // Execute.
  let raw: unknown
  try {
    raw = await dispatch(toolName, effective)
  } catch (err) {
    try {
      session.recordToolFailure(toolName, String(err))
    } catch {
      /* swallow */
    }
    const errText = `[tool error] ${toolName}: ${err}`
    const errOutcome = await session.validateToolOutput(toolName, errText, callId)
    if (!errOutcome.verdict.allowed) {
      throw new ToolError(_formatBlock(errOutcome.verdict))
    }
    // The runner will still mark this as `is_error: true` because we
    // throw — but the customer (and the model) see the tool error
    // text as the content.
    throw new ToolError(String(errOutcome.result ?? errText))
  }

  // Stage 4 (post-tool).
  const outputStr = _stringifyToolResult(raw)
  const outOutcome = await session.validateToolOutput(toolName, outputStr, callId)
  if (!outOutcome.verdict.allowed) {
    try {
      session.recordToolFailure(toolName, outOutcome.verdict.reason ?? 'blocked')
    } catch {
      /* swallow */
    }
    throw new ToolError(_formatBlock(outOutcome.verdict))
  }

  const final = outOutcome.result ?? outputStr
  const finalStr = typeof final === 'string' ? final : String(final)
  try {
    session.recordToolSuccess(toolName, finalStr)
  } catch {
    /* swallow */
  }
  return finalStr
}

/** Wrap a raw Anthropic tool definition `{name, description,
 *  input_schema, ...}` into a `BetaRunnableTool` — i.e. the same
 *  shape plus a `run(args, ctx)` callback that flows through the
 *  guarded dispatcher. */
function _wrapAnthropicTool(
  raw: unknown,
  session: SessionLike,
  dispatch: AnthropicToolDispatch,
  ToolError: new (content: string | unknown[]) => Error,
): AnthropicRunnableToolDef {
  const def = (raw ?? {}) as AnthropicRunnableToolDef
  const name = def.name
  if (!name || typeof name !== 'string') {
    throw new TypeError(
      'runAnthropicAgent: tool definition missing required `name` field',
    )
  }
  // Spread to preserve description / input_schema / type / etc.
  const wrapped: AnthropicRunnableToolDef = { ...def }
  ;(wrapped as Record<string, unknown>).run = async (
    input: unknown,
    _ctx?: unknown,
  ): Promise<string> => {
    void _ctx
    const args: Record<string, unknown> =
      input && typeof input === 'object' ? (input as Record<string, unknown>) : {}
    return await _guardedToolDispatch(session, name, args, dispatch, ToolError)
  }
  return wrapped
}

function _resolveToolRunner(
  client: AnthropicClient,
): NonNullable<NonNullable<NonNullable<AnthropicClient['beta']>['messages']>['toolRunner']> {
  const tr = client.beta?.messages?.toolRunner
  if (typeof tr !== 'function') {
    throw new TypeError(
      'runAnthropicAgent: the supplied Anthropic client does not expose ' +
        '`client.beta.messages.toolRunner`. This adapter requires ' +
        '`@anthropic-ai/sdk` v0.40+ which introduced the BetaToolRunner.',
    )
  }
  return tr
}

// ─── Pattern A: runAnthropicAgent (runner-driven) ─────────────────

/**
 * Pattern A — drive a full `BetaToolRunner` loop with all five
 * validation stages enforced. Returns the final (possibly redacted)
 * assistant text, or a `[GUARDRAIL …]` block message.
 *
 * The body is a thin shim around `client.beta.messages.toolRunner`:
 *
 *   1. Stage 1 input validation against the last user message.
 *   2. Wrap each raw tool definition with a `run` callback that flows
 *      Stages 2 + 3 + 4 via {@link _guardedToolDispatch}.
 *   3. `client.beta.messages.toolRunner({...})` → `await runner`
 *      drives the model ↔ tool loop. Conversation bookkeeping, JSON
 *      parsing of tool args, and iteration counting all live inside
 *      the SDK.
 *   4. Stage 5 fires on the final assistant text.
 *
 * Required: `client` (with `beta.messages.toolRunner`) and
 * `dispatchTool`. `@anthropic-ai/sdk` v0.40+ must be installed at
 * runtime for `ToolError` (used to surface guardrail blocks as
 * `is_error: true` tool_result blocks).
 */
async function runAnthropicAgent(this: Shield, opts: AnthropicRunAgentOpts): Promise<string> {
  if (!opts || typeof opts !== 'object') {
    throw new TypeError('runAnthropicAgent requires an opts object')
  }
  const {
    client,
    model,
    tools,
    messages,
    dispatchTool,
    system,
    maxIters = 10,
    maxTokens = 4096,
    requestExtras = {},
    _anthropicModule,
  } = opts

  if (!client) {
    throw new TypeError('runAnthropicAgent requires a client')
  }
  if (typeof model !== 'string' || model.length === 0) {
    throw new TypeError('runAnthropicAgent: { model } is required')
  }
  if (typeof dispatchTool !== 'function') {
    throw new TypeError('runAnthropicAgent requires a dispatchTool function')
  }
  if (!Array.isArray(messages)) {
    throw new TypeError('runAnthropicAgent requires a messages array')
  }

  const toolRunner = _resolveToolRunner(client)
  const { ToolError } = await _loadAnthropicModule(_anthropicModule)

  const session = this.runtime.newSession()
  session.beginTurn()

  try {
    // Stage 1 — input validation.
    const userInput = _extractUserInputFromMessages(messages)
    if (userInput) {
      const inV = await session.validateInput(userInput)
      if (!inV.allowed) return _formatBlock(inV)
    }

    // Wrap tools.
    const wrappedTools = Array.isArray(tools)
      ? tools.map((t) => _wrapAnthropicTool(t, session, dispatchTool, ToolError))
      : []

    const body: Record<string, unknown> = {
      model,
      max_tokens: maxTokens,
      messages,
      tools: wrappedTools,
      max_iterations: maxIters,
      ...(system ? { system } : {}),
      ...requestExtras,
    }

    const runner = toolRunner(body)
    // Prefer the explicit `runUntilDone()` method over `await runner`.
    // The runner is also thenable, but its `then` return type does
    // not satisfy TS's strict Promise-shape inference.
    const runUntilDone = runner.runUntilDone
    if (typeof runUntilDone !== 'function') {
      throw new TypeError(
        'runAnthropicAgent: the runner returned from `client.beta.messages.toolRunner(...)` does not expose `runUntilDone()`',
      )
    }
    const finalMessage = (await runUntilDone.call(runner)) as AnthropicMessageResponse

    // Stage 5 — output validation.
    const finalText = _extractFinalText(finalMessage)
    if (!finalText) return ''
    const outOutcome = await session.validateOutput(finalText)
    if (!outOutcome.verdict.allowed) return _formatBlock(outOutcome.verdict)
    return outOutcome.response ?? finalText
  } finally {
    try {
      session.endTurn()
    } catch {
      /* swallow */
    }
  }
}

// ─── Pattern B: wrap a customer dispatcher ────────────────────────

function protectAnthropicTools(
  this: Shield,
  opts: AnthropicProtectToolsOpts,
): AnthropicProtectToolsResult {
  if (!opts || typeof opts !== 'object') {
    throw new TypeError('protectAnthropicTools requires an opts object')
  }
  const { tools, dispatchTool, session: providedSession } = opts
  if (typeof dispatchTool !== 'function') {
    throw new TypeError('protectAnthropicTools requires a dispatchTool function')
  }

  const runtime = this.runtime
  // A Pattern B caller still owns the agent loop, so they own session
  // lifecycle. We allocate a per-shield session lazily if none given.
  let session: SessionLike | null = providedSession ?? null

  const wrappedDispatch = async (
    name: string,
    input: Record<string, unknown>,
  ): Promise<string | { blocked: true; blockMessage: string }> => {
    if (!session) {
      session = runtime.newSession()
      try {
        session.beginTurn()
      } catch {
        /* swallow */
      }
    }
    const cleaned = _cleanArgs(input)
    // §16.0 binding: Pattern B does not receive the model's
    // tool_use.id (the customer's `dispatchTool(name, input)`
    // signature predates the binding model). Generate a stable
    // per-call id so concurrent same-name calls on the same
    // session bind to distinct Stage 3 invocations.
    const callId = randomUUID()
    const callOutcome = await session.validateToolCall(name, cleaned, callId)
    if (!callOutcome.verdict.allowed) {
      return {
        blocked: true,
        blockMessage: `${_formatBlock(callOutcome.verdict)} (tool: ${name})`,
      }
    }
    const effective = (callOutcome.params as Record<string, unknown> | undefined) ?? cleaned

    let raw: unknown
    try {
      raw = await dispatchTool(name, effective)
    } catch (err) {
      try {
        session.recordToolFailure(name, String(err))
      } catch {
        /* swallow */
      }
      const errText = `[tool error] ${name}: ${err}`
      const errOutcome = await session.validateToolOutput(name, errText, callId)
      if (!errOutcome.verdict.allowed) {
        return { blocked: true, blockMessage: _formatBlock(errOutcome.verdict) }
      }
      return String(errOutcome.result ?? errText)
    }

    const outputStr = _stringifyToolResult(raw)
    const outOutcome = await session.validateToolOutput(name, outputStr, callId)
    if (!outOutcome.verdict.allowed) {
      try {
        session.recordToolFailure(name, outOutcome.verdict.reason ?? 'blocked')
      } catch {
        /* swallow */
      }
      return { blocked: true, blockMessage: _formatBlock(outOutcome.verdict) }
    }

    const finalOut =
      typeof outOutcome.result === 'string'
        ? outOutcome.result
        : outOutcome.result != null
          ? String(outOutcome.result)
          : outputStr
    try {
      session.recordToolSuccess(name, finalOut)
    } catch {
      /* swallow */
    }
    return finalOut
  }

  return {
    tools: Array.isArray(tools) ? tools : [],
    dispatchTool: wrappedDispatch,
  }
}

// ─── Pattern A — streaming variant ────────────────────────────────
//
// The Anthropic SDK exposes a streaming mode of `BetaToolRunner` via
// `client.beta.messages.toolRunner({..., stream: true})`. The returned
// runner is an async iterable whose values are `BetaMessageStream`
// objects (one per assistant iteration). For each stream we hook the
// `text` event to push deltas through the shield's StreamingGuard
// (chunk-level Stage 5). Tool dispatch is gated by the same per-tool
// `run` wrapper as the non-streaming path.

async function* runAnthropicAgentStreamed(
  this: Shield,
  opts: AnthropicRunStreamedOpts,
): AsyncGenerator<AnthropicStreamEmission, void, void> {
  if (!opts || typeof opts !== 'object') {
    throw new TypeError('runAnthropicAgentStreamed requires an opts object')
  }
  const {
    client,
    model,
    tools,
    messages,
    dispatchTool,
    system,
    maxIters = 10,
    maxTokens = 4096,
    requestExtras = {},
    _anthropicModule,
  } = opts
  if (!client) {
    throw new TypeError('runAnthropicAgentStreamed requires a client')
  }
  if (typeof model !== 'string' || model.length === 0) {
    throw new TypeError('runAnthropicAgentStreamed: { model } is required')
  }
  if (typeof dispatchTool !== 'function') {
    throw new TypeError('runAnthropicAgentStreamed requires a dispatchTool function')
  }
  if (!Array.isArray(messages)) {
    throw new TypeError('runAnthropicAgentStreamed requires a messages array')
  }

  const toolRunner = _resolveToolRunner(client)
  const { ToolError } = await _loadAnthropicModule(_anthropicModule)

  const runtime = this.runtime
  const session = runtime.newSession()
  session.beginTurn()

  try {
    // Stage 1.
    const userInput = _extractUserInputFromMessages(messages)
    if (userInput) {
      const inV = await session.validateInput(userInput)
      if (!inV.allowed) {
        yield { type: 'blocked', message: _formatBlock(inV) }
        return
      }
    }

    const guard = session.streamingSession(5)
    const wrappedTools = Array.isArray(tools)
      ? tools.map((t) => _wrapAnthropicTool(t, session, dispatchTool, ToolError))
      : []

    const body: Record<string, unknown> = {
      model,
      max_tokens: maxTokens,
      messages,
      tools: wrappedTools,
      max_iterations: maxIters,
      stream: true,
      ...(system ? { system } : {}),
      ...requestExtras,
    }

    const runner = toolRunner(body)
    const asyncIter = runner[Symbol.asyncIterator]
    if (typeof asyncIter !== 'function') {
      throw new TypeError(
        'runAnthropicAgentStreamed: the runner returned from `client.beta.messages.toolRunner({stream: true})` is not async-iterable',
      )
    }

    let finalText = ''
    // Validator cadence governs both `text_delta` scheduling AND what
    // ends up in the terminal `final` emission. In `on_complete` mode
    // the guard returns empty payloads per push and ships the
    // validated full text via `finish()` — only then is it safe to
    // surface to the consumer. In `per_chunk` / `windowed` the
    // per-push payload IS the validated emission.
    const bufferMode = guard.mode === 'on_complete'
    for await (const messageStream of runner as AsyncIterable<AnthropicBetaMessageStreamLike>) {
      // Collect text deltas from this iteration. We accumulate them
      // into a buffer using the `text` event, then drain through the
      // streaming guard once the stream's final message resolves. This
      // is simpler than racing against the underlying async iteration
      // and keeps the buffer ordering deterministic — fine because
      // chunk-level Stage 5 already buffers internally.
      const deltas: string[] = []
      if (typeof messageStream.on === 'function') {
        messageStream.on('text', (delta: unknown) => {
          if (typeof delta === 'string') deltas.push(delta)
        })
      }
      let perIterFinal: AnthropicMessageResponse | undefined
      if (typeof messageStream.finalMessage === 'function') {
        perIterFinal = await messageStream.finalMessage()
      }

      // Push collected deltas through Stage 5.
      for (const d of deltas) {
        const r = await guard.addChunk(d)
        if (r.action === 'stop') {
          yield { type: 'blocked', message: r.reason ?? 'output blocked' }
          return
        }
        if (r.payload && r.payload.length > 0) {
          // Engine emitted a validated payload — surface it. In
          // `on_complete` this branch never fires (engine buffers
          // until finish); in `per_chunk`/`windowed` it is the safe
          // mid-stream emission, so it doubles as the building block
          // for `finalText`.
          yield { type: 'text_delta', text: r.payload }
          if (!bufferMode) {
            finalText += r.payload
          }
        }
      }

      // If the iteration's stop_reason is end_turn there are no more
      // iterations — but the runner's async iterator handles that
      // for us (it will simply not yield another stream).
      void perIterFinal
    }

    const tail = await guard.finish()
    if (tail.action === 'stop') {
      yield { type: 'blocked', message: tail.reason ?? 'output blocked' }
      return
    }
    if (tail.payload && tail.payload.length > 0) {
      yield { type: 'text_delta', text: tail.payload }
      finalText += tail.payload
    }
    yield { type: 'final', text: finalText }
  } finally {
    try {
      session.endTurn()
    } catch {
      /* swallow */
    }
  }
}

// ─── Side-effect installation ─────────────────────────────────────

interface ShieldBuilderInternal {
  _bundle: CapabilityBundle | null
  _rebindPendingLlmClient?: () => void
}

function _installPatches(): void {
  // (1) ShieldBuilder.withAnthropic — explicitly choose the Anthropic
  //     bundle. Idempotent: re-installing returns the same function.
  const builderProto = ShieldBuilder.prototype as ShieldBuilder & {
    withAnthropic?: (opts?: AnthropicWithOpts) => ShieldBuilder
  }
  if (typeof builderProto.withAnthropic !== 'function') {
    builderProto.withAnthropic = function withAnthropic(
      this: ShieldBuilder,
      _opts: AnthropicWithOpts = {},
    ): ShieldBuilder {
      void _opts
      const self = this as unknown as ShieldBuilderInternal
      self._bundle = _BUNDLE
      // If `.withClient(c)` ran BEFORE this adapter was chosen, the
      // client was stashed (no factory yet). Rebind through the base
      // helper so call order is irrelevant.
      self._rebindPendingLlmClient?.()
      return this
    }
  }

  // (2) Shield methods — framework-specific only. We deliberately do
  //     NOT install `Shield.prototype.run`, `Shield.prototype.protectTool`,
  //     or a default `Shield.BUNDLE` here: those belong to the base
  //     `Shield` class so adapter load order can never reshape the
  //     generic API surface (prototype-pollution guarantee). See
  //     `../shield.js`.
  const shieldProto = Shield.prototype as Shield & {
    runAnthropicAgent?: typeof runAnthropicAgent
    protectAnthropicTools?: typeof protectAnthropicTools
    runAnthropicAgentStreamed?: typeof runAnthropicAgentStreamed
  }
  if (typeof shieldProto.runAnthropicAgent !== 'function') {
    shieldProto.runAnthropicAgent = runAnthropicAgent
  }
  if (typeof shieldProto.protectAnthropicTools !== 'function') {
    shieldProto.protectAnthropicTools = protectAnthropicTools
  }
  if (typeof shieldProto.runAnthropicAgentStreamed !== 'function') {
    shieldProto.runAnthropicAgentStreamed = runAnthropicAgentStreamed
  }
}

_installPatches()

export {
  _BUNDLE as ANTHROPIC_AGENTS_BUNDLE,
  _CAPABILITIES as ANTHROPIC_AGENTS_CAPABILITIES,
  runAnthropicAgent,
  protectAnthropicTools,
  runAnthropicAgentStreamed,
}

/** Re-exported installer for tests that need to exercise the install
 *  path explicitly (mirrors the OpenAI adapter's `install` export). */
export { _installPatches as install }
