// Agent Shield adapter for the OpenAI Agents Node SDK
// (`@openai/agents`).
//
// This is the framework-level integration that brings Node to parity
// with the Python `agent_shield.adapters.openai_agents` adapter: the
// `@openai/agents` SDK owns the agent loop (model → tool call → model
// → … → final output), and we wrap each tool's `execute` to enforce
// Stages 2 + 3 + 4. Stage 1 fires before `Runner.run`; Stage 5 fires
// against the run's `finalOutput`.
//
// Three integration patterns:
//
//   Pattern A — adapter owns the agent loop (Runner-based):
//       const text = await shield.runOpenaiAgent({
//         client,
//         model,
//         tools,
//         messages,
//         dispatchToolCall: (name, args) => ...,
//       });
//
//   Pattern B — protect tool dispatcher, customer runs the loop:
//       const guardedDispatch = shield.protectOpenaiTools({
//         tools, dispatchToolCall: (name, args) => ...,
//       });
//
//   Pattern C — Stage 1 + Stage 5 only (drop-in around an opaque agent):
//       await shield.run(() => userAgentLoop(), { userInput });
//       // `shield.run` is the canonical base method on Shield —
//       // see `../shield.js`.
//
// `runOpenaiAgent` requires `@openai/agents` (and, when the customer's
// `client` is an `openai` SDK instance, `@openai/agents-openai`) to be
// installed. Both are declared as **optional peer dependencies** so
// customers using only `protectOpenaiTools` or `shield.run` need not
// pull them in. The dynamic `import()` inside the loop body emits a
// clear install hint when either is missing.

import {
  Shield,
  ShieldBuilder,
  CapabilityReport,
  ConfigurationMissingModelError,
  CoverageLevel,
  currentSession,
  type SessionLike,
  type StageVerdictLike,
  type CapabilityBundle,
  type LlmCallerFactory,
  type AdapterContext,
} from '../shield.js'
import type { LlmConfiguration } from '../index.js'
import { randomUUID } from 'node:crypto'

// ─── Module augmentation: install adapter methods on Shield/ShieldBuilder

declare module '../shield.js' {
  interface ShieldBuilder {
    /** Bind this builder to the OpenAI Agents capability bundle. */
    withOpenaiAgents(): this
  }
  interface Shield {
    /** Pattern A — adapter owns the OpenAI Agents SDK Runner loop. */
    runOpenaiAgent(opts: OpenaiRunAgentOpts): Promise<string>
    /** Pattern A (streaming) — adapter owns the Runner streamed loop
     *  and yields {@link OpenaiStreamEmission} chunks. */
    runOpenaiAgentStreamed(
      opts: OpenaiRunStreamedOpts,
    ): AsyncGenerator<OpenaiStreamEmission, void, void>
    /** Pattern B — guarded tool dispatcher. */
    protectOpenaiTools(opts: OpenaiProtectToolsOpts): OpenaiGuardedDispatch
  }
}

// ─── Public opts / result types ───────────────────────────────────

/** Minimal structural shape of the OpenAI Node SDK client. Used by
 *  `makeLlmCaller` (the LLM-judge caller, still a raw chat-completions
 *  call) and forwarded to `@openai/agents-openai`'s
 *  `setDefaultOpenAIClient` so the Runner-driven loop reuses the same
 *  client / API key / base URL. */
export interface OpenaiClient {
  chat: {
    completions: {
      create(args: Record<string, unknown>): Promise<OpenaiChatCompletion>
    }
  }
}

export interface OpenaiChatCompletion {
  choices?: Array<{ message?: OpenaiChatMessage }>
}

export interface OpenaiChatMessage {
  role?: string
  content?: string | null
  tool_calls?: OpenaiToolCall[]
  tool_call_id?: string
}

export interface OpenaiToolCall {
  id?: string
  function?: { name?: string; arguments?: string }
}

export type OpenaiToolDispatch = (
  name: string,
  args: Record<string, unknown>,
) => Promise<unknown> | unknown

/**
 * Loose structural type for `@openai/agents`'s `AgentConfiguration`
 * (the object passed to `new Agent({...})`). We don't take a hard
 * dep on `@openai/agents` types — that package is an optional peer
 * dep — so `agentConfig` is typed as a free-form record. Customers
 * pass keys like `tool_choice`, `outputType`, `handoffs`,
 * `model_settings`, `reset_tool_choice`, etc., and the adapter
 * forwards them verbatim to the Agent constructor.
 *
 * One field is special-cased: `tools` is stripped before the merge
 * (with a one-shot `console.warn`) because the adapter must own
 * tool wrapping — letting `agentConfig.tools` win would silently
 * bypass Stages 2/3/4 on whatever tools the customer supplied.
 */
export type OpenaiAgentConfig = Record<string, unknown>

export interface OpenaiRunAgentOpts {
  client: OpenaiClient
  /** Required: the *customer agent's* model that drives the OpenAI
   *  Agents Runner loop. A security library MUST NOT pick a model on
   *  the customer's behalf — this field has no default. The
   *  AgentShield validation stages are driven separately by the
   *  `configurations[]` block in `.guardrails.yaml`. */
  model: string
  /** Tool definitions. Accepts either raw OpenAI chat-tool defs
   *  (`{ type: 'function', function: { name, description, parameters } }`)
   *  or already-built `@openai/agents` `FunctionTool` objects. In
   *  either case each tool's execution is gated by the shield via
   *  the supplied `dispatchToolCall` (when the source shape is a raw
   *  chat-tool def) or by re-wrapping `.invoke` (when the source is a
   *  pre-built `FunctionTool`). */
  tools?: ReadonlyArray<unknown>
  messages?: OpenaiChatMessage[]
  /** Required when `tools` is a raw chat-tool def array. Ignored for
   *  pre-built `FunctionTool` arrays (they carry their own executor). */
  dispatchToolCall?: OpenaiToolDispatch
  /** Forwarded to `Runner.run` as `maxTurns`. */
  maxIters?: number
  userInput?: string
  /** Optional system instructions for the synthetic Agent built by
   *  `runOpenaiAgent`. When unset and `messages` contains a system
   *  message, that message's content is used. */
  instructions?: string
  /**
   * Extra fields to pass through to the synthetic `@openai/agents`
   * `Agent` constructor. Useful for `tool_choice`, `outputType`
   * (structured outputs via zod / JSON Schema), `handoffs`,
   * `model_settings`, etc. — anything `AgentConfiguration` supports.
   *
   * Merge order: adapter defaults first (`name`, `instructions`,
   * `model`, `tools: wrappedTools`), then `agentConfig` spread on
   * top — so customer fields override defaults *except* `tools`,
   * which is always taken from the shield-wrapped array. Attempting
   * to set `tools` via `agentConfig` triggers a one-shot
   * `console.warn` and the field is dropped: letting the customer
   * win there would silently bypass Stages 2/3/4 on those tools.
   */
  agentConfig?: OpenaiAgentConfig
  /** Test seam — inject a fake `@openai/agents` module to bypass the
   *  optional peer-dep import. Not part of the supported public API;
   *  the underscore prefix marks it internal. */
  _agentsModule?: AgentsLikeModule
  /** Test seam — inject a fake `@openai/agents-openai` module to
   *  bypass `setDefaultOpenAIClient` plumbing. */
  _agentsOpenaiModule?: AgentsOpenaiLikeModule
}

export interface OpenaiProtectToolsOpts {
  dispatchToolCall: OpenaiToolDispatch
  tools?: ReadonlyArray<unknown>
}

/** Emissions yielded by `runOpenaiAgentStreamed`. The streamed
 *  `@openai/agents` Runner owns tool dispatch internally (and our
 *  wrapped tools gate Stages 2 / 3 / 4 underneath it), so the only
 *  events surfaced to the caller are text deltas, the terminal
 *  `final` event, and a single `blocked` event on Stage-1 / Stage-5
 *  block.
 *
 *  Mirrors {@link AnthropicStreamEmission} in `anthropic_agents.ts`
 *  so consumer code switching between providers can share a shape. */
export type OpenaiStreamEmission =
  | { type: 'text_delta'; text: string }
  | { type: 'final'; text: string }
  | { type: 'blocked'; message: string }

export interface OpenaiRunStreamedOpts {
  client: OpenaiClient
  /** Required: the *customer agent's* model that drives the OpenAI
   *  Agents Runner streamed loop. A security library MUST NOT pick a
   *  model on the customer's behalf — this field has no default. */
  model: string
  tools?: ReadonlyArray<unknown>
  messages?: OpenaiChatMessage[]
  dispatchToolCall?: OpenaiToolDispatch
  /** Forwarded to `run` as `maxTurns`. */
  maxIters?: number
  userInput?: string
  /** Optional system instructions for the synthetic Agent built by
   *  the streamed runner. When unset and `messages` contains a system
   *  message, that message's content is used. */
  instructions?: string
  /** Same merge / `tools`-strip semantics as
   *  {@link OpenaiRunAgentOpts.agentConfig}. */
  agentConfig?: OpenaiAgentConfig
  /** Test seam — inject a fake `@openai/agents` module. */
  _agentsModule?: AgentsLikeModule
  /** Test seam — inject a fake `@openai/agents-openai` module. */
  _agentsOpenaiModule?: AgentsOpenaiLikeModule
}

export type OpenaiGuardedDispatch = (
  name: string,
  args: Record<string, unknown>,
) => Promise<string>

export interface OpenaiLlmCallerOpts {
  /**
   * Optional resolver that maps a `configurationId` to its
   * camelCased `configurations[]` entry — typically
   * `runtime.llmConfiguration` bound by `ShieldBuilder`. When
   * supplied, the caller honours the YAML's per-stage `model:` /
   * `max_tokens:` selection. When the resolver returns a
   * configuration without `model:` (or `deployment:` on Azure) — or
   * returns `null` — the caller throws
   * {@link ConfigurationMissingModelError} rather than silently
   * picking a model on the customer's behalf. Resolver exceptions are
   * caught and routed through the optional `recordAdapterError`
   * callback before being surfaced as `ConfigurationMissingModelError`.
   */
  configurationResolver?: (
    configurationId: string | null | undefined,
  ) => LlmConfiguration | null
  /** Same shape as {@link AdapterContext.recordAdapterError}; used
   *  to surface resolver exceptions through observability. Optional —
   *  level-1 callers (`makeLlmCaller(client)`) can ignore this.
   */
  recordAdapterError?: (error: unknown) => void
}

// ─── Capability report ───────────────────────────────────────────

export const OPENAI_CAPABILITIES = new CapabilityReport({
  framework: 'openai_agents',
  inputValidation: CoverageLevel.FULL,
  stateValidation: CoverageLevel.FULL,
  toolAuthorization: CoverageLevel.FULL,
  toolExecutionValidation: CoverageLevel.FULL,
  toolOutputValidation: CoverageLevel.FULL,
  outputValidation: CoverageLevel.FULL,
  // PARTIAL — same value as the Anthropic adapter. `runOpenaiAgentStreamed`
  // wires Stage 5 through the streaming guard for text deltas; tool
  // dispatch is gated by Stage 2/3/4 inside the wrapped `tool.execute`
  // / `tool.invoke` underneath the `@openai/agents` Runner's streamed
  // loop. Non-streaming Pattern A (`runOpenaiAgent`) and Pattern B
  // (`protectOpenaiTools`) remain FULL across all stages.
  streamingOutput: CoverageLevel.PARTIAL,
  notes: [
    'Pattern A = full coverage; Pattern C drop-in covers Stage 1+5 only',
    'streaming chunk-level Stage-5 covers text deltas only; tool dispatch is gated by Stage 2/3/4 inside the @openai/agents Runner',
  ],
})

// ─── Helpers ─────────────────────────────────────────────────────

function _formatBlock(verdict: StageVerdictLike | null | undefined): string {
  const action = (verdict?.action ?? 'block').toUpperCase()
  const reason = verdict?.reason ?? 'blocked by policy'
  return `[GUARDRAIL ${action}] ${reason}`
}

function _stringifyToolResult(raw: unknown): string {
  if (raw === null || raw === undefined) return ''
  if (typeof raw === 'string') return raw
  try {
    return JSON.stringify(raw)
  } catch {
    return String(raw)
  }
}

function _extractUserInput(messages: OpenaiChatMessage[] | undefined): string {
  // Last user message wins. Concatenate string content; ignore
  // structured (image / tool) parts. Returns '' when none found.
  if (!Array.isArray(messages)) return ''
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i]
    if (!m || m.role !== 'user') continue
    if (typeof m.content === 'string') return m.content
    if (Array.isArray(m.content)) {
      const parts = (m.content as Array<unknown>)
        .map((p) =>
          typeof p === 'string'
            ? p
            : ((p as { text?: string } | null)?.text ?? ''),
        )
        .filter((s): s is string => typeof s === 'string' && s.length > 0)
      if (parts.length) return parts.join('\n')
    }
  }
  return ''
}

function _extractSystemInstructions(
  messages: OpenaiChatMessage[] | undefined,
): string {
  if (!Array.isArray(messages)) return ''
  const parts: string[] = []
  for (const m of messages) {
    if (!m || m.role !== 'system') continue
    if (typeof m.content === 'string' && m.content.length > 0) {
      parts.push(m.content)
    }
  }
  return parts.join('\n')
}

function _cleanArgs(args: Record<string, unknown> | null | undefined): Record<string, unknown> {
  const cleaned: Record<string, unknown> = { ...(args ?? {}) }
  for (const k of Object.keys(cleaned)) {
    if (cleaned[k] === undefined) delete cleaned[k]
  }
  return cleaned
}

// ─── Stage 2 + 3 + 4 dispatcher around a user `(name, args) => result`
//     function. Drives the same sequencing as the Python / Rust /
//     .NET adapters: validate the call, run the dispatcher with the
//     possibly-mutated effective args, validate the result, redact /
//     block / record success or failure.

async function _guardedToolDispatch(
  session: SessionLike,
  toolName: string,
  args: Record<string, unknown>,
  dispatch: OpenaiToolDispatch,
  toolCallId?: string | null,
): Promise<string> {
  const cleaned = _cleanArgs(args)

  // §16.0 binding: when the caller doesn't supply a tool_call_id —
  // e.g. the OpenAI Agents SDK's `tool()` execute callback doesn't
  // expose the model's tool_call_id — mint a stable per-invocation
  // id so concurrent same-name calls on the same session bind to
  // distinct Stage 3 invocations.
  const callId = toolCallId ?? randomUUID()

  // Stage 2 (state) + Stage 3 (tool execution).
  const callOutcome = await session.validateToolCall(toolName, cleaned, callId)
  if (!callOutcome.verdict.allowed) {
    return _formatBlock(callOutcome.verdict)
  }
  const effective = (callOutcome.params as Record<string, unknown> | undefined) ?? cleaned

  // Execute (Stage-3-mutated args reach the dispatcher).
  let raw: unknown
  try {
    raw = await dispatch(toolName, effective)
  } catch (err) {
    try {
      session.recordToolFailure(toolName, String(err))
    } catch {
      /* swallow */
    }
    const errText = `[tool error] ${toolName}: ${err}`
    const errOutcome = await session.validateToolOutput(toolName, errText, callId)
    if (!errOutcome.verdict.allowed) return _formatBlock(errOutcome.verdict)
    return String(errOutcome.result ?? errText)
  }

  // Stage 4 (post-tool).
  const outputStr = _stringifyToolResult(raw)
  const outOutcome = await session.validateToolOutput(toolName, outputStr, callId)
  if (!outOutcome.verdict.allowed) {
    try {
      session.recordToolFailure(toolName, outOutcome.verdict.reason ?? 'blocked')
    } catch {
      /* swallow */
    }
    return _formatBlock(outOutcome.verdict)
  }
  const final = outOutcome.result ?? outputStr
  const finalStr = typeof final === 'string' ? final : String(final)
  try {
    session.recordToolSuccess(toolName, finalStr)
  } catch {
    /* swallow */
  }
  return finalStr
}

// ─── @openai/agents loader (lazy, with a test seam) ──────────────

/** Process-wide latch for the one-shot `agentConfig.tools` warning.
 *  Keyed by the warning identifier so we can extend later without
 *  resetting the whole Set. */
const _ONE_SHOT_WARNINGS = new Set<string>()

function _warnOnce(key: string, message: string): void {
  if (_ONE_SHOT_WARNINGS.has(key)) return
  _ONE_SHOT_WARNINGS.add(key)
  try {
    // eslint-disable-next-line no-console
    console.warn(message)
  } catch {
    /* swallow — best-effort observability, must never crash the loop */
  }
}

/** Structural slice of `@openai/agents` we depend on. Kept minimal so
 *  tests can stand up a fake module without bringing in the full
 *  Agents SDK (which transitively requires zod 4 + openai 6).
 *
 *  `run` is overloaded by the upstream SDK: with `{ stream: true }` it
 *  returns a `StreamedRunResult` (an `AsyncIterable<RunStreamEvent>`)
 *  rather than a plain result. We type the return as the union here
 *  so the streamed runner can iterate raw model events. */
export interface AgentsLikeModule {
  Agent: new (opts: Record<string, unknown>) => unknown
  tool: (opts: Record<string, unknown>) => unknown
  run: (
    agent: unknown,
    input: string,
    opts?: Record<string, unknown>,
  ) => Promise<AgentsRunReturn>
}

/** Either a non-streaming run result (`{ finalOutput }`) or a streaming
 *  `StreamedRunResult` (`AsyncIterable<RunStreamEvent>` with helpers).
 *  The streaming branch is engaged by passing `{ stream: true }` to
 *  `run`. */
export type AgentsRunReturn = AgentsRunResult | AgentsStreamedRunResult

export interface AgentsRunResult {
  finalOutput?: unknown
}

/** Structural slice of the upstream `StreamedRunResult`. We rely on the
 *  `AsyncIterable<RunStreamEvent>` surface; `completed` and
 *  `finalOutput` are useful but optional. */
export interface AgentsStreamedRunResult {
  [Symbol.asyncIterator](): AsyncIterator<AgentsRunStreamEvent>
  readonly completed?: Promise<void>
  readonly finalOutput?: unknown
}

/** Loose structural slice of `RunStreamEvent`. The runner emits three
 *  top-level event types; the streamed runner only acts on
 *  `raw_model_stream_event` items whose data carries an
 *  `output_text_delta`. Other events (run-item updates, agent
 *  switches) are ignored — `@openai/agents` handles tool dispatch and
 *  agent handoffs internally; our wrapped tools already gate Stages
 *  2 / 3 / 4 underneath that loop. */
export interface AgentsRunStreamEvent {
  type?: string
  data?: {
    type?: string
    delta?: unknown
    [k: string]: unknown
  }
  [k: string]: unknown
}

/** Structural slice of `@openai/agents-openai` we depend on. */
export interface AgentsOpenaiLikeModule {
  setDefaultOpenAIClient?: (client: unknown) => void
  setOpenAIAPI?: (api: 'chat_completions' | 'responses') => void
}

let _agentsModuleOverride: AgentsLikeModule | null = null
let _agentsOpenaiModuleOverride: AgentsOpenaiLikeModule | null = null

/** Test seam — install / clear a fake `@openai/agents` module. Used
 *  exclusively by the adapter test suite; not exported from the
 *  package's public entry point. */
export function _setAgentsModuleForTesting(
  mod: AgentsLikeModule | null,
): void {
  _agentsModuleOverride = mod
}

/** Test seam — install / clear a fake `@openai/agents-openai`. */
export function _setAgentsOpenaiModuleForTesting(
  mod: AgentsOpenaiLikeModule | null,
): void {
  _agentsOpenaiModuleOverride = mod
}

async function _loadAgentsModule(
  override?: AgentsLikeModule,
): Promise<AgentsLikeModule> {
  if (override) return override
  if (_agentsModuleOverride) return _agentsModuleOverride
  try {
    // Dynamic import keeps `@openai/agents` an optional peer dep —
    // customers using only `protectOpenaiTools` or `shield.run` need
    // not install it. The `@ts-expect-error` is needed because the
    // peer dep is optional and not necessarily resolvable at
    // `tsc` time.
    // @ts-expect-error -- optional peer dep
    const mod = (await import('@openai/agents')) as unknown as AgentsLikeModule
    return mod
  } catch (err) {
    throw new Error(
      'runOpenaiAgent: `@openai/agents` is not installed. Install with ' +
        '`npm i @openai/agents` (and `@openai/agents-openai` if you are ' +
        'passing a raw `openai` SDK client). Underlying error: ' +
        String(err),
    )
  }
}

async function _loadAgentsOpenaiModule(
  override?: AgentsOpenaiLikeModule,
): Promise<AgentsOpenaiLikeModule | null> {
  if (override) return override
  if (_agentsOpenaiModuleOverride) return _agentsOpenaiModuleOverride
  try {
    // @ts-expect-error -- optional peer dep
    const mod = (await import('@openai/agents-openai')) as unknown as AgentsOpenaiLikeModule
    return mod
  } catch {
    // Optional. The customer may be using `@openai/agents` with a
    // non-OpenAI model provider, in which case no client wiring is
    // needed at this layer.
    return null
  }
}

// ─── Tool shape normalisation ────────────────────────────────────

interface ChatToolDef {
  type?: string
  name?: string
  description?: string
  parameters?: Record<string, unknown>
  function?: {
    name?: string
    description?: string
    parameters?: Record<string, unknown>
  }
}

interface FunctionToolLike {
  type?: string
  name?: string
  invoke?: (...args: unknown[]) => Promise<string | unknown>
  execute?: (...args: unknown[]) => Promise<unknown> | unknown
}

function _isAgentsFunctionTool(raw: unknown): raw is FunctionToolLike {
  if (!raw || typeof raw !== 'object') return false
  const t = raw as FunctionToolLike
  // `@openai/agents` FunctionTool: `{ type: 'function', name, invoke,
  // ... }`. The presence of a callable `invoke` is the discriminator
  // — raw chat-tool defs don't carry one.
  return t.type === 'function' && typeof t.invoke === 'function'
}

function _wrapChatToolDef(
  raw: unknown,
  session: SessionLike,
  dispatch: OpenaiToolDispatch,
  agentsMod: AgentsLikeModule,
): unknown {
  const t = (raw ?? {}) as ChatToolDef
  const fnDef = t.function ?? t
  const name = fnDef.name ?? ''
  if (!name) {
    throw new TypeError(
      'runOpenaiAgent: tool definition missing `function.name` (or `name`).',
    )
  }
  const description = fnDef.description ?? name
  const parameters: Record<string, unknown> =
    fnDef.parameters ?? {
      type: 'object',
      properties: {},
      required: [],
      additionalProperties: false,
    }
  return agentsMod.tool({
    name,
    description,
    parameters,
    strict: false,
    execute: async (input: unknown) => {
      let args: Record<string, unknown> = {}
      if (typeof input === 'string') {
        try {
          args = JSON.parse(input) as Record<string, unknown>
        } catch {
          args = {}
        }
      } else if (input && typeof input === 'object') {
        args = input as Record<string, unknown>
      }
      return await _guardedToolDispatch(session, name, args, dispatch)
    },
  })
}

function _wrapFunctionTool(
  raw: FunctionToolLike,
  session: SessionLike,
): FunctionToolLike {
  // Pre-built `@openai/agents` FunctionTool. The framework calls
  // `tool.invoke(runContext, inputJson, details)`; we splice the
  // shield around that call. `tool.invoke` returns a string by
  // contract (see `@openai/agents-core/dist/tool.d.ts`).
  const name = raw.name ?? ''
  if (!name) {
    throw new TypeError(
      'runOpenaiAgent: pre-built FunctionTool is missing `name`.',
    )
  }
  const originalInvoke = raw.invoke!.bind(raw)
  const wrapped: FunctionToolLike = Object.create(raw as object)
  ;(wrapped as { invoke: FunctionToolLike['invoke'] }).invoke = async (
    ...callArgs: unknown[]
  ) => {
    const inputJson = callArgs[1]
    let args: Record<string, unknown> = {}
    if (typeof inputJson === 'string') {
      try {
        args = JSON.parse(inputJson) as Record<string, unknown>
      } catch {
        args = {}
      }
    } else if (inputJson && typeof inputJson === 'object') {
      args = inputJson as Record<string, unknown>
    }
    // The dispatcher for a pre-built FunctionTool is the tool's own
    // original `invoke` — Stage 3 may mutate args, and the (mutated)
    // args reach the customer-defined `execute` underneath the
    // framework's invoke envelope.
    return await _guardedToolDispatch(
      session,
      name,
      args,
      async (_n: string, effective: Record<string, unknown>) => {
        return await originalInvoke(
          callArgs[0],
          JSON.stringify(effective),
          callArgs[2],
        )
      },
    )
  }
  return wrapped
}

// ─── LLM caller factory ──────────────────────────────────────────

/**
 * Build an LLM caller from an OpenAI client. The runtime invokes
 * `caller({ configurationId, prompt }) -> string` synchronously from
 * the napi boundary; we use `chat.completions.create` (the broadly
 * supported envelope) and extract the assistant content.
 *
 * When `opts.configurationResolver` is supplied, the produced caller
 * looks up the YAML's `configurations[]` entry by `configurationId`
 * at call time and uses its `model:` / `max_tokens:` fields — so a
 * `.guardrails.yaml` like
 * `configurations: [{id: stage3-judge, type: llm, model: gpt-4o}]`
 * actually drives `gpt-4o`.
 *
 * Model selection is **strict**: when the resolved configuration has
 * neither `model:` nor `deployment:` (or no entry matches the
 * configurationId), the caller throws
 * {@link ConfigurationMissingModelError} rather than silently picking
 * a hard-coded SKU. The schema enforces this at load time.
 */
export function makeLlmCaller(
  client: OpenaiClient,
  opts: OpenaiLlmCallerOpts = {},
): (req: { configurationId: string | null; prompt: string }) => Promise<string> {
  const resolver = opts.configurationResolver
  const recordAdapterError = opts.recordAdapterError
  return async ({ configurationId, prompt }) => {
    let cfg: LlmConfiguration | null = null
    if (resolver && configurationId) {
      try {
        cfg = resolver(configurationId)
      } catch (err) {
        // Resolver lookup must never break the LLM caller with an
        // internal error — emit an adapter-error event so SREs see a
        // distinct signal, then surface the load-time-shaped
        // ConfigurationMissingModelError below.
        recordAdapterError?.(
          new Error(
            `openai_agents llm caller: configurationResolver raised ` +
              `for configurationId=${JSON.stringify(configurationId)}: ` +
              `${err instanceof Error ? err.message : String(err)}`,
          ),
        )
        cfg = null
      }
    }

    if (!cfg || typeof cfg.model !== 'string' || !cfg.model) {
      // A security library MUST NOT pick a model on the customer's
      // behalf. When the resolved configuration is missing `model:`
      // (or no entry matched the configurationId), raise a typed
      // error so the customer's `.guardrails.yaml` is the only place
      // where the model is declared.
      //
      // §6.2 — `model:` is the identifier passed verbatim to the
      // provider SDK. For direct OpenAI it's a model name; for Azure
      // OpenAI it's a deployment name (Azure's OpenAI SDK takes the
      // deployment in the `model=` kwarg). The runtime treats it as
      // opaque.
      throw new ConfigurationMissingModelError(configurationId)
    }
    const model = cfg.model

    const kwargs: Record<string, unknown> = {
      model,
      messages: [{ role: 'user', content: String(prompt ?? '') }],
    }
    if (typeof cfg.maxTokens === 'number') {
      kwargs.max_tokens = cfg.maxTokens
    }
    const response = await client.chat.completions.create(kwargs)
    const choice = response?.choices?.[0]
    return choice?.message?.content ?? ''
  }
}

const _LLM_CALLER_FACTORY: LlmCallerFactory<
  OpenaiClient,
  (req: { configurationId: string | null; prompt: string }) => Promise<string>
> = Object.freeze({
  makeCaller: (client: OpenaiClient, ctx?: AdapterContext) =>
    makeLlmCaller(client, {
      configurationResolver: ctx?.configurationResolver,
      recordAdapterError: ctx?.recordAdapterError,
    }),
})

// ─── Bundle ──────────────────────────────────────────────────────

export const OPENAI_BUNDLE: CapabilityBundle = Object.freeze({
  name: 'openai_agents',
  llmCallerFactory: _LLM_CALLER_FACTORY as unknown as LlmCallerFactory,
  // The OpenAI Node SDK does not expose a unified Agent abstraction
  // or construction-time tool wrapper at the bundle level; Pattern A
  // is driven by `runOpenaiAgent` (which uses `@openai/agents`'s
  // `Runner.run` directly), Pattern B by `protectOpenaiTools`.
  // `Shield.guard()` is intentionally unsupported here — use the
  // adapter helpers instead.
  capabilities: OPENAI_CAPABILITIES,
})

// ─── Shield methods (monkey-patched onto Shield.prototype) ───────

/**
 * Pattern A — drive a full `@openai/agents` `Runner.run` loop with
 * all five validation stages enforced. Returns the final (possibly
 * redacted) assistant text or a `[GUARDRAIL …]` block message.
 *
 * The body is a thin shim around `@openai/agents`:
 *   1. Stage 1 input validation against the last user message
 *      (or the explicit `userInput`).
 *   2. Build a synthetic `Agent` whose tools each have their
 *      `execute` (or `invoke`) re-wrapped to fire Stages 2 + 3 + 4
 *      via {@link _guardedToolDispatch}.
 *   3. `Runner.run(agent, input, { maxTurns: maxIters })` drives the
 *      model → tool-call → model loop. Tool args, conversation
 *      bookkeeping, and JSON parsing all live inside the Runner.
 *   4. Stage 5 fires on `result.finalOutput`.
 *
 * Required: `client` (an OpenAI SDK instance) and `@openai/agents`
 * installed. When `tools` contains raw chat-tool definitions,
 * `dispatchToolCall` is also required.
 */
async function runOpenaiAgent(this: Shield, opts: OpenaiRunAgentOpts): Promise<string> {
  const {
    client,
    model,
    tools,
    messages = [],
    dispatchToolCall,
    maxIters = 10,
    userInput,
    instructions,
    agentConfig,
    _agentsModule,
    _agentsOpenaiModule,
  } = opts

  if (!client) {
    throw new TypeError('runOpenaiAgent: { client } is required')
  }
  if (typeof model !== 'string' || model.length === 0) {
    throw new TypeError('runOpenaiAgent: { model } is required')
  }

  const hasTools = Array.isArray(tools) && tools.length > 0
  const usesRawChatTools = hasTools && !_isAgentsFunctionTool(tools![0])
  if (usesRawChatTools && typeof dispatchToolCall !== 'function') {
    throw new TypeError(
      'runOpenaiAgent: { dispatchToolCall } is required when tools are raw chat-tool defs',
    )
  }

  const agentsMod = await _loadAgentsModule(_agentsModule)
  const agentsOpenaiMod = await _loadAgentsOpenaiModule(_agentsOpenaiModule)

  const session = this.runtime.newSession()
  session.beginTurn()
  try {
    // ── Stage 1 ── input validation ─────────────────────────────
    const inputText = userInput ?? _extractUserInput(messages)
    if (inputText) {
      const verdict = await session.validateInput(inputText)
      if (!verdict.allowed) return _formatBlock(verdict)
    }

    // ── Build wrapped tools ────────────────────────────────────
    const wrappedTools = hasTools
      ? tools!.map((raw) => {
          if (_isAgentsFunctionTool(raw)) {
            return _wrapFunctionTool(raw, session)
          }
          return _wrapChatToolDef(
            raw,
            session,
            dispatchToolCall as OpenaiToolDispatch,
            agentsMod,
          )
        })
      : []

    // ── Wire the customer's OpenAI client into the Runner ──────
    // `setDefaultOpenAIClient` lets the Runner reuse the customer's
    // API key / base URL / org without us threading them through.
    // When `@openai/agents-openai` isn't installed (e.g. the customer
    // configured a non-OpenAI model provider directly), we skip this
    // step silently.
    if (agentsOpenaiMod?.setDefaultOpenAIClient) {
      try {
        agentsOpenaiMod.setDefaultOpenAIClient(client)
      } catch {
        /* swallow — non-fatal */
      }
    }
    if (agentsOpenaiMod?.setOpenAIAPI) {
      try {
        agentsOpenaiMod.setOpenAIAPI('chat_completions')
      } catch {
        /* swallow */
      }
    }

    const computedInstructions =
      typeof instructions === 'string' && instructions.length > 0
        ? instructions
        : _extractSystemInstructions(messages)

    // ── Filter agentConfig: customer-supplied `tools` is dropped
    //    (with a one-shot warning) so the shield-wrapped tools always
    //    win — otherwise Stage 2/3/4 would silently be bypassed on
    //    whatever the customer passed. Everything else passes through
    //    verbatim: `tool_choice`, `outputType` (structured outputs),
    //    `handoffs`, `model_settings`, etc.
    let filteredAgentConfig: Record<string, unknown> | undefined
    if (agentConfig && typeof agentConfig === 'object') {
      const ownTools = Object.prototype.hasOwnProperty.call(agentConfig, 'tools')
      if (ownTools) {
        _warnOnce(
          'runOpenaiAgent.agentConfig.tools',
          'runOpenaiAgent: `agentConfig.tools` was ignored. The adapter ' +
            'owns tool wrapping (Stages 2 + 3 + 4); passing `tools` ' +
            'through `agentConfig` would silently bypass them. Pass ' +
            'tool definitions via `opts.tools` instead.',
        )
        const { tools: _drop, ...rest } = agentConfig as {
          tools?: unknown
          [k: string]: unknown
        }
        void _drop
        filteredAgentConfig = rest
      } else {
        filteredAgentConfig = { ...agentConfig }
      }
    }

    const agent = new agentsMod.Agent({
      name: 'agent-shield-managed',
      instructions: computedInstructions,
      model,
      tools: wrappedTools,
      ...(filteredAgentConfig ?? {}),
    })

    const result = (await agentsMod.run(agent, inputText, {
      maxTurns: maxIters,
    })) as AgentsRunResult

    // ── Stage 5 ── final assistant message ─────────────────────
    const rawFinal = result?.finalOutput
    const finalText =
      typeof rawFinal === 'string'
        ? rawFinal
        : rawFinal == null
          ? ''
          : String(rawFinal)
    if (finalText.length === 0) {
      return ''
    }
    const outcome = await session.validateOutput(finalText)
    if (!outcome.verdict.allowed) return _formatBlock(outcome.verdict)
    return outcome.response ?? finalText
  } finally {
    try {
      session.endTurn()
    } catch {
      /* swallow */
    }
  }
}

/**
 * Pattern A (streaming) — drive a streaming `@openai/agents` Runner
 * loop with all five validation stages enforced. Yields a sequence
 * of {@link OpenaiStreamEmission} discriminated-union events
 * compatible with the Anthropic streamed runner.
 *
 * Stage choreography (mirrors `runAnthropicAgentStreamed`):
 *   1. **Stage 1** input validation runs *before* `run(..., { stream: true })`.
 *      A block emits a single `{ type: 'blocked', ... }` event and stops.
 *   2. The synthetic `Agent` is built exactly as in {@link runOpenaiAgent},
 *      with each tool's `execute` / `invoke` re-wrapped to fire
 *      Stages 2 + 3 + 4 underneath the Runner's tool loop.
 *   3. `run(agent, input, { stream: true, maxTurns })` returns a
 *      `StreamedRunResult` — an `AsyncIterable<RunStreamEvent>`. We
 *      filter for `raw_model_stream_event` with `output_text_delta`
 *      data and push each delta through a Stage-5 `StreamingGuard`.
 *   4. Validator cadence (`guard.mode`) governs emission scheduling:
 *      `on_complete` buffers every text-bearing delta and emits the
 *      validated full text once at `guard.finish()`; `per_chunk` /
 *      `windowed` emit `r.payload` mid-stream (NOT the raw delta —
 *      see the streaming engine's overlap-respecting hold-back
 *      logic in `guard_policy_runtime/streaming.rs`).
 *   5. A terminal `{ type: 'final', text }` event carries the
 *      concatenation of all validated text emissions so callers that
 *      only care about the assembled output don't have to track it
 *      themselves.
 *
 * Required: `client` (an OpenAI SDK instance) and `@openai/agents`
 * installed. When `tools` contains raw chat-tool defs,
 * `dispatchToolCall` is also required.
 */
async function* runOpenaiAgentStreamed(
  this: Shield,
  opts: OpenaiRunStreamedOpts,
): AsyncGenerator<OpenaiStreamEmission, void, void> {
  if (!opts || typeof opts !== 'object') {
    throw new TypeError('runOpenaiAgentStreamed requires an opts object')
  }
  const {
    client,
    model,
    tools,
    messages = [],
    dispatchToolCall,
    maxIters = 10,
    userInput,
    instructions,
    agentConfig,
    _agentsModule,
    _agentsOpenaiModule,
  } = opts

  if (!client) {
    throw new TypeError('runOpenaiAgentStreamed: { client } is required')
  }
  if (typeof model !== 'string' || model.length === 0) {
    throw new TypeError('runOpenaiAgentStreamed: { model } is required')
  }

  const hasTools = Array.isArray(tools) && tools.length > 0
  const usesRawChatTools = hasTools && !_isAgentsFunctionTool(tools![0])
  if (usesRawChatTools && typeof dispatchToolCall !== 'function') {
    throw new TypeError(
      'runOpenaiAgentStreamed: { dispatchToolCall } is required when tools are raw chat-tool defs',
    )
  }

  const agentsMod = await _loadAgentsModule(_agentsModule)
  const agentsOpenaiMod = await _loadAgentsOpenaiModule(_agentsOpenaiModule)

  const session = this.runtime.newSession()
  session.beginTurn()
  try {
    // ── Stage 1 ── input validation ─────────────────────────────
    const inputText = userInput ?? _extractUserInput(messages)
    if (inputText) {
      const verdict = await session.validateInput(inputText)
      if (!verdict.allowed) {
        yield { type: 'blocked', message: _formatBlock(verdict) }
        return
      }
    }

    // ── Build wrapped tools ────────────────────────────────────
    const wrappedTools = hasTools
      ? tools!.map((raw) => {
          if (_isAgentsFunctionTool(raw)) {
            return _wrapFunctionTool(raw, session)
          }
          return _wrapChatToolDef(
            raw,
            session,
            dispatchToolCall as OpenaiToolDispatch,
            agentsMod,
          )
        })
      : []

    // ── Wire the customer's OpenAI client into the Runner ──────
    if (agentsOpenaiMod?.setDefaultOpenAIClient) {
      try {
        agentsOpenaiMod.setDefaultOpenAIClient(client)
      } catch {
        /* swallow */
      }
    }
    if (agentsOpenaiMod?.setOpenAIAPI) {
      try {
        agentsOpenaiMod.setOpenAIAPI('chat_completions')
      } catch {
        /* swallow */
      }
    }

    const computedInstructions =
      typeof instructions === 'string' && instructions.length > 0
        ? instructions
        : _extractSystemInstructions(messages)

    // ── Filter agentConfig: customer-supplied `tools` is dropped
    //    (with a one-shot warning) so the shield-wrapped tools always
    //    win — mirrors `runOpenaiAgent`.
    let filteredAgentConfig: Record<string, unknown> | undefined
    if (agentConfig && typeof agentConfig === 'object') {
      const ownTools = Object.prototype.hasOwnProperty.call(agentConfig, 'tools')
      if (ownTools) {
        _warnOnce(
          'runOpenaiAgentStreamed.agentConfig.tools',
          'runOpenaiAgentStreamed: `agentConfig.tools` was ignored. The ' +
            'adapter owns tool wrapping (Stages 2 + 3 + 4); passing ' +
            '`tools` through `agentConfig` would silently bypass them. ' +
            'Pass tool definitions via `opts.tools` instead.',
        )
        const { tools: _drop, ...rest } = agentConfig as {
          tools?: unknown
          [k: string]: unknown
        }
        void _drop
        filteredAgentConfig = rest
      } else {
        filteredAgentConfig = { ...agentConfig }
      }
    }

    const agent = new agentsMod.Agent({
      name: 'agent-shield-managed',
      instructions: computedInstructions,
      model,
      tools: wrappedTools,
      ...(filteredAgentConfig ?? {}),
    })

    const streamed = (await agentsMod.run(agent, inputText, {
      maxTurns: maxIters,
      stream: true,
    })) as AgentsStreamedRunResult

    const asyncIter = (streamed as { [Symbol.asyncIterator]?: unknown })[
      Symbol.asyncIterator
    ]
    if (typeof asyncIter !== 'function') {
      throw new TypeError(
        'runOpenaiAgentStreamed: `run(agent, input, { stream: true })` did not return an async-iterable; ' +
          'is the installed `@openai/agents` package recent enough to support streaming?',
      )
    }

    // ── Stage 5 streaming ──────────────────────────────────────
    const guard = session.streamingSession(5)
    const bufferMode = guard.mode === 'on_complete'
    let finalText = ''

    for await (const event of streamed as AsyncIterable<AgentsRunStreamEvent>) {
      // Only Responses / Chat-Completions output_text_delta events
      // carry assistant text. Everything else (run-item updates,
      // tool-call announcements, agent-switch events, raw OpenAI
      // `response.created` envelopes) is metadata that the Runner
      // already handles internally — we skip it.
      if (event?.type !== 'raw_model_stream_event') continue
      if (event?.data?.type !== 'output_text_delta') continue
      const delta =
        typeof event.data.delta === 'string' ? event.data.delta : ''
      if (!delta) continue

      const r = await guard.addChunk(delta)
      if (r.action === 'stop') {
        yield { type: 'blocked', message: r.reason ?? 'output blocked' }
        return
      }
      // In every cadence the engine's `r.payload` is the authoritative
      // safe-to-emit slice — NOT the raw upstream delta. Windowed and
      // per_chunk modes hold back `overlap` bytes, so most pushes
      // return `payload: ""` (buffered); on_complete returns empty
      // for every push and the validated full text lands at
      // `guard.finish()` below. Either way: emit `r.payload` if
      // non-empty, skip otherwise. Bypass: in on_complete bufferMode
      // we never surface text-bearing emissions mid-stream so the
      // consumer sees exactly one terminal `text_delta`.
      if (!bufferMode && r.payload && r.payload.length > 0) {
        yield { type: 'text_delta', text: r.payload }
        finalText += r.payload
      }
    }

    // Drain the Runner's tail callbacks (history compaction, etc.)
    // when the optional `completed` promise is exposed. Errors are
    // swallowed — the streamed run is already over from our POV.
    if (streamed && typeof streamed.completed?.then === 'function') {
      try {
        await streamed.completed
      } catch {
        /* swallow — already past the consumer-visible boundary */
      }
    }

    const tail = await guard.finish()
    if (tail.action === 'stop') {
      yield { type: 'blocked', message: tail.reason ?? 'output blocked' }
      return
    }
    if (tail.payload && tail.payload.length > 0) {
      yield { type: 'text_delta', text: tail.payload }
      finalText += tail.payload
    }
    yield { type: 'final', text: finalText }
  } finally {
    try {
      session.endTurn()
    } catch {
      /* swallow */
    }
  }
}

/**
 * Pattern B — return a guarded `(name, args) => result` dispatcher
 * the customer can plug into their own agent loop. Stages 2 + 3 + 4
 * fire around the user-supplied `dispatchToolCall`.
 */
function protectOpenaiTools(this: Shield, opts: OpenaiProtectToolsOpts): OpenaiGuardedDispatch {
  const { dispatchToolCall } = opts
  if (typeof dispatchToolCall !== 'function') {
    throw new TypeError('protectOpenaiTools: { dispatchToolCall } is required')
  }
  return async (name, args): Promise<string> => {
    const ambient = currentSession()
    let session: SessionLike
    let ownTurn = false
    if (ambient) {
      session = ambient
    } else {
      session = this.runtime.newSession()
      session.beginTurn()
      ownTurn = true
    }
    try {
      // §16.0 binding: Pattern B is a wrapper-owned dispatch boundary
      // where the upstream OpenAI tool_call.id isn't surfaced through
      // the (name, args) → output dispatcher signature. Mint a stable
      // per-call UUID so Stage 3 and Stage 4 find the same canonical
      // invocation, symmetric with the Anthropic Pattern B path at
      // `anthropic_agents.ts` and the Python `protect_tools_via_wrapper`.
      const callId = randomUUID()
      return await _guardedToolDispatch(session, name, args, dispatchToolCall, callId)
    } finally {
      if (ownTurn) {
        try {
          session.endTurn()
        } catch {
          /* swallow */
        }
      }
    }
  }
}

// ─── Side-effect installation ────────────────────────────────────

interface ShieldBuilderInternal {
  _bundle: CapabilityBundle | null
}

function _install(): void {
  // ShieldBuilder.withOpenaiAgents — sets the OpenAI bundle on the
  // builder so `.build()` produces an OpenAI-flavoured Shield.
  const builderProto = ShieldBuilder.prototype as ShieldBuilder & {
    withOpenaiAgents?: () => ShieldBuilder
  }
  if (typeof builderProto.withOpenaiAgents !== 'function') {
    builderProto.withOpenaiAgents = function withOpenaiAgents(this: ShieldBuilder): ShieldBuilder {
      const self = this as unknown as ShieldBuilderInternal & {
        _rebindPendingLlmClient?: () => void
      }
      self._bundle = OPENAI_BUNDLE
      // If `.withClient(c)` ran BEFORE this adapter was chosen, the
      // client was stashed (no factory yet). Rebind through the base
      // helper so call order is irrelevant — parity with the
      // LangChain and Anthropic adapters.
      self._rebindPendingLlmClient?.()
      return this
    }
  }

  // Shield.prototype methods — framework-specific only. The generic
  // `run` and `protectTool` are owned by the BASE Shield class
  // (see `../shield.js`); installing them here would resurrect the
  // load-order prototype-pollution bug across adapters. Likewise
  // we do NOT install a default `Shield.BUNDLE`: the customer
  // selects the bundle explicitly via `.withOpenaiAgents()`.
  const shieldProto = Shield.prototype as Shield & {
    runOpenaiAgent?: typeof runOpenaiAgent
    runOpenaiAgentStreamed?: typeof runOpenaiAgentStreamed
    protectOpenaiTools?: typeof protectOpenaiTools
  }
  if (typeof shieldProto.runOpenaiAgent !== 'function') {
    shieldProto.runOpenaiAgent = runOpenaiAgent
  }
  if (typeof shieldProto.runOpenaiAgentStreamed !== 'function') {
    shieldProto.runOpenaiAgentStreamed = runOpenaiAgentStreamed
  }
  if (typeof shieldProto.protectOpenaiTools !== 'function') {
    shieldProto.protectOpenaiTools = protectOpenaiTools
  }
}

_install()

// ─── Exports ─────────────────────────────────────────────────────

export { _install as install }
