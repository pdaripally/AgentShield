// Agent Shield for MCP (Model Context Protocol) servers — Node SDK.
//
// MCP servers are tool providers, not agent loops, so this module is
// a sibling integration rather than a framework adapter. Mirrors the
// Python `agent_shield.mcp` and the .NET `AgentShield.MCP` modules.
//
// Session scope
// -------------
// By default an MCPShield instance holds a single long-lived session
// for the lifetime of the connection so state predicates span tool
// calls. Pass `{ sessionScope: 'call' }` to opt out (per-call sessions,
// stateless).

import {
  CoverageLevel,
  CapabilityReport,
  currentSession,
  currentUserInput,
  type SessionLike,
  type RuntimeLike,
  type StageVerdictLike,
} from './shield.js'
// Namespace import breaks the mcp ↔ index module cycle.
// `_index.RuntimeBuilder` is referenced only inside method bodies, so
// the cycle resolves before any access.
import * as _index from './index.js'
import { randomUUID } from 'node:crypto'

let _MCP_CAPABILITIES_CACHE: CapabilityReport | null = null
function _mcpCapabilities(): CapabilityReport {
  if (_MCP_CAPABILITIES_CACHE === null) {
    _MCP_CAPABILITIES_CACHE = new CapabilityReport({
      framework: 'mcp',
      inputValidation: CoverageLevel.UNSUPPORTED,
      stateValidation: CoverageLevel.FULL,
      toolAuthorization: CoverageLevel.FULL,
      toolExecutionValidation: CoverageLevel.FULL,
      toolOutputValidation: CoverageLevel.FULL,
      outputValidation: CoverageLevel.UNSUPPORTED,
      streamingOutput: CoverageLevel.UNSUPPORTED,
      notes: [
        'MCP is a tool-provider integration; no user-facing input or assistant-output boundary exists for Stage 1 / Stage 5 / streaming',
      ],
    })
  }
  return _MCP_CAPABILITIES_CACHE
}

export class MCPGuardrailBlocked extends Error {
  override readonly name = 'MCPGuardrailBlocked'
  readonly toolName: string
  override readonly message: string

  constructor(toolName: string, message: string) {
    super(message)
    this.toolName = toolName
    this.message = message
  }
}

function _formatBlock(verdict: StageVerdictLike | null | undefined): string {
  const action = (verdict?.action ?? 'block').toUpperCase()
  const reason = verdict?.reason ?? 'blocked by policy'
  return `[GUARDRAIL ${action}] ${reason}`
}

function _cleanArgs(
  args: Record<string, unknown> | null | undefined,
): Record<string, unknown> {
  const cleaned: Record<string, unknown> = { ...(args ?? {}) }
  for (const k of Object.keys(cleaned)) {
    // eslint-disable-next-line security/detect-object-injection -- k is enumerated from the local cleaned-args object.
    if (cleaned[k] === undefined || cleaned[k] === null) delete cleaned[k]
  }
  return cleaned
}

export interface ProtectToolResult {
  allowed: boolean
  effectiveArgs: Record<string, unknown>
  blockMessage: string | null
}

export interface ProtectToolOutputResult {
  allowed: boolean
  effectiveOutput: string
  blockMessage: string | null
}

async function _doProtectTool(
  session: SessionLike,
  toolName: string,
  args: Record<string, unknown> | null | undefined,
  toolCallId: string,
): Promise<ProtectToolResult> {
  if (!toolCallId) {
    throw new TypeError('toolCallId is required and must be non-empty')
  }
  const cleaned = _cleanArgs(args)
  const outcome = await session.validateToolCall(toolName, cleaned, toolCallId)
  if (!outcome.verdict.allowed) {
    return {
      allowed: false,
      effectiveArgs: cleaned,
      blockMessage: _formatBlock(outcome.verdict),
    }
  }
  return {
    allowed: true,
    effectiveArgs: (outcome.params as Record<string, unknown> | undefined) ?? cleaned,
    blockMessage: null,
  }
}

async function _doProtectToolOutput(
  session: SessionLike,
  toolName: string,
  output: unknown,
  toolCallId: string,
  record: boolean,
): Promise<ProtectToolOutputResult> {
  if (!toolCallId) {
    throw new TypeError('toolCallId is required and must be non-empty')
  }
  const text = typeof output === 'string' ? output : String(output)
  const outcome = await session.validateToolOutput(toolName, text, toolCallId)
  if (!outcome.verdict.allowed) {
    if (record) {
      try {
        session.recordToolFailure(toolName, outcome.verdict.reason ?? 'blocked')
      } catch {
        /* swallow */
      }
    }
    return {
      allowed: false,
      effectiveOutput: text,
      blockMessage: _formatBlock(outcome.verdict),
    }
  }
  const final = outcome.result ?? text
  const finalStr = typeof final === 'string' ? final : String(final)
  if (record) {
    try {
      session.recordToolSuccess(toolName, finalStr)
    } catch {
      /* swallow */
    }
  }
  return { allowed: true, effectiveOutput: finalStr, blockMessage: null }
}

/**
 * Stage 2 + 3 — guard an inbound MCP tool call.
 *
 * `toolCallId` is REQUIRED (Section 16.0 mandatory binding). Reuse
 * the same id on the paired {@link protectToolOutput} call so Stage 4
 * binds against the canonical invocation Stage 3 admitted. When the
 * host framework does not surface a native id (e.g. raw MCP without
 * a request id), mint one with `randomUUID()` per call.
 */
export async function protectTool(
  runtime: RuntimeLike,
  toolName: string,
  args: Record<string, unknown> | null | undefined,
  toolCallId: string,
  opts: { session?: SessionLike } = {},
): Promise<ProtectToolResult> {
  const session = opts.session ?? runtime.newSession()
  return _doProtectTool(session, toolName, args, toolCallId)
}

/**
 * Stage 4 — guard an outbound MCP tool result.
 *
 * `toolCallId` is REQUIRED and MUST match the id passed to the
 * paired {@link protectTool} call (Section 16.0).
 */
export async function protectToolOutput(
  runtime: RuntimeLike,
  toolName: string,
  output: unknown,
  toolCallId: string,
  opts: { session?: SessionLike; record?: boolean } = {},
): Promise<ProtectToolOutputResult> {
  const session = opts.session ?? runtime.newSession()
  const record = opts.record ?? true
  return _doProtectToolOutput(session, toolName, output, toolCallId, record)
}

export type SessionScope = 'connection' | 'call'

export interface MCPShieldOpts {
  capabilities?: CapabilityReport
  sessionScope?: SessionScope
}

export type MCPOnBlock = 'raise' | 'returnMessage'

export interface ProtectToolsOpts {
  onBlock?: MCPOnBlock
}

export type MCPToolFn = (params?: Record<string, unknown>) => Promise<unknown> | unknown

export class MCPShieldBuilder {
  protected _path: string
  _yamlChain: readonly string[] | null = null
  protected readonly _observabilityProviders: Array<(event: unknown) => void> = []
  protected _llmCaller: ((req: unknown) => unknown) | null = null
  protected readonly _extra: Array<(builder: unknown) => void> = []
  protected _sessionScope: SessionScope = 'connection'

  constructor(path: string) {
    this._path = path
  }

  withObservability(provider: (event: unknown) => void): this {
    this._observabilityProviders.push(provider)
    return this
  }

  withLlmCaller(caller: (req: unknown) => unknown): this {
    this._llmCaller = caller
    return this
  }

  withExtension(hook: (builder: unknown) => void): this {
    this._extra.push(hook)
    return this
  }

  withSessionScope(scope: SessionScope): this {
    this._sessionScope = scope
    return this
  }

  build(): MCPShield {
    let builder: import('./index.js').RuntimeBuilder
    if (this._yamlChain) {
      builder = _index.RuntimeBuilder.fromYamlChain(this._yamlChain.slice())
    } else {
      builder = _index.RuntimeBuilder.fromYaml(this._path)
    }
    if (this._llmCaller) builder.registerLlmCaller(this._llmCaller as never)
    for (const p of this._observabilityProviders) builder.registerProvider(p as never)
    for (const hook of this._extra) hook(builder)
    return new MCPShield(builder.build() as unknown as RuntimeLike, {
      sessionScope: this._sessionScope,
    })
  }
}

export class MCPShield {
  readonly runtime: RuntimeLike
  protected readonly _capabilities: CapabilityReport
  protected readonly _sessionScope: SessionScope
  protected _session: SessionLike | null = null

  constructor(runtime: RuntimeLike, opts: MCPShieldOpts = {}) {
    this.runtime = runtime
    this._capabilities = opts.capabilities ?? _mcpCapabilities()
    const scope = opts.sessionScope ?? 'connection'
    if (scope !== 'connection' && scope !== 'call') {
      throw new Error(
        `sessionScope must be 'connection' or 'call', got ${JSON.stringify(scope)}`,
      )
    }
    this._sessionScope = scope
  }

  /** Start a builder from a single YAML file or a chain of YAML files. */
  static fromYaml(pathOrPaths: string | readonly string[]): MCPShieldBuilder {
    if (Array.isArray(pathOrPaths)) {
      const b = new MCPShieldBuilder('')
      b._yamlChain = pathOrPaths.slice()
      return b
    }
    return new MCPShieldBuilder(pathOrPaths as string)
  }

  get capabilities(): CapabilityReport {
    return this._capabilities
  }

  get sessionScope(): SessionScope {
    return this._sessionScope
  }

  /**
   * The held connection session, or `null` when scope is `'call'`.
   * Lazily created on first access in connection mode.
   */
  get session(): SessionLike | null {
    if (this._sessionScope !== 'connection') return null
    if (this._session === null) this._session = this.runtime.newSession()
    return this._session
  }

  /**
   * Drop the held connection session. The next call lazily creates a
   * fresh one. No-op when scope is `'call'`.
   */
  resetSession(): void {
    this._session = null
  }

  protected _resolveSession(explicit: SessionLike | null | undefined): SessionLike {
    if (explicit) return explicit
    if (this._sessionScope === 'connection') {
      const sess = this.session
      if (sess) return sess
    }
    return this.runtime.newSession()
  }

  async protectTool(
    toolName: string,
    args: Record<string, unknown> | null | undefined,
    toolCallId: string,
    opts: { session?: SessionLike } = {},
  ): Promise<ProtectToolResult> {
    return _doProtectTool(
      this._resolveSession(opts.session),
      toolName,
      args,
      toolCallId,
    )
  }

  async protectToolOutput(
    toolName: string,
    output: unknown,
    toolCallId: string,
    opts: { session?: SessionLike; record?: boolean } = {},
  ): Promise<ProtectToolOutputResult> {
    const record = opts.record ?? true
    return _doProtectToolOutput(
      this._resolveSession(opts.session),
      toolName,
      output,
      toolCallId,
      record,
    )
  }

  /**
   * Wrap a list of `(name, fn)` tool pairs with Stage 2/3/4 enforcement.
   * Returns a list of `(name, wrappedFn)` pairs the MCP server can
   * register. `onBlock` is `"raise"` (throws MCPGuardrailBlocked) or
   * `"returnMessage"` (returns the formatted block string).
   */
  protectTools(
    tools: ReadonlyArray<[string, MCPToolFn]>,
    opts: ProtectToolsOpts = {},
  ): Array<[string, MCPToolFn]> {
    const onBlock = opts.onBlock ?? 'raise'
    return tools.map(([name, fn]) => [name, this._wrapCallable(name, fn, onBlock)])
  }

  protected _wrapCallable(
    toolName: string,
    fn: MCPToolFn,
    onBlock: MCPOnBlock,
  ): MCPToolFn {
    return async (params: Record<string, unknown> = {}): Promise<unknown> => {
      const session = currentSession() ?? this._resolveSession(null)
      // Pre-fetch the ambient user input so a custom resolver context can
      // optionally include it in its prompts. Currently unused at this
      // call site but kept symmetric with the Python adapter.
      void currentUserInput()
      // §16.0 binding: MCP servers do not surface the upstream client's
      // request id at the tool boundary, so we mint a stable per-call
      // id here. Stage 3 + Stage 4 share one id even when the server
      // sees concurrent same-name calls on the held connection session.
      const callId = randomUUID()
      const inboundCheck = await _doProtectTool(session, toolName, params, callId)
      if (!inboundCheck.allowed) {
        if (onBlock === 'raise') {
          throw new MCPGuardrailBlocked(toolName, inboundCheck.blockMessage ?? '')
        }
        return inboundCheck.blockMessage
      }
      const result = await fn(inboundCheck.effectiveArgs)
      const out = await _doProtectToolOutput(session, toolName, result, callId, true)
      if (!out.allowed) {
        if (onBlock === 'raise') {
          throw new MCPGuardrailBlocked(toolName, out.blockMessage ?? '')
        }
        return out.blockMessage
      }
      return out.effectiveOutput
    }
  }
}
