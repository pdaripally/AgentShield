# Agent Shield — Node.js SDK

Node.js bindings for [Agent Shield](https://github.com/microsoft/AgentShield), an open specification and reference implementation for runtime security controls on AI agents. Loads a [`.guardrails.yaml`](../../spec/SPECIFICATION.md) contract and enforces it across **5 validation stages** (Input → State → Tool execution → Post-tool → Output).

The Node SDK is a thin [`napi-rs`](https://napi.rs) layer over the Rust `agent_shield_core` plus a small camelCase TypeScript facade. All validation logic lives in Rust; the Node side translates shapes and exposes idiomatic JS / TS APIs.

## Install

```bash
npm install @microsoft/agent-shield
```

Requires Node.js >= 18.

## Quick start

```typescript
import { Shield, currentUserInput } from '@microsoft/agent-shield'
import '@microsoft/agent-shield/adapters/langchain'  // side-effect import: registers bundle

const shield = await Shield.fromYaml('.guardrails.yaml')
  .withClient(myLangChainModel)
  .build()

const guarded = shield.guard(myAgent)
const result  = await guarded.invoke('user input')
```

**Before shipping:** read [Post-tool limits and dangerous patterns](../../docs/POST_TOOL_LIMITS.md) — it covers what AgentShield does and does not guarantee.

## Three integration patterns

The same conceptual model — **Patterns A / B / C** — applies across all four AgentShield SDKs (Python, Node, Rust, .NET); the *implementation shape* matches each ecosystem's idiomatic middleware surface. In Node, that means agent-object wrapping for frameworks that have one, and `shield.run(thunk)` boundaries for opaque loops.

### Pattern A — Guard the agent loop (full coverage)

For LangChain.js / OpenAI Agents JS / Anthropic Agents JS — frameworks that expose an agent object you can wrap. AgentShield runs all 5 validation stages around the loop:

```typescript
import { Shield } from '@microsoft/agent-shield'
import '@microsoft/agent-shield/adapters/langchain'

const shield = await Shield.fromYaml('.guardrails.yaml')
  .withClient(model)
  .build()

const guarded = shield.guard(agent)
const result  = await guarded.invoke('user input')   // runs Stages 1 + 5; tools run Stages 2/3/4
```

The adapter is selected by the side-effect import. To pin one explicitly (multi-framework apps), call `.withLangchain()` / `.withAnthropic()` / `.withOpenaiAgents()` on the builder.

### Pattern B — Protect individual tools

When the framework owns the loop tightly and only the tool boundary is wrappable:

```typescript
import { Shield } from '@microsoft/agent-shield'
import '@microsoft/agent-shield/adapters/openai_agents'

const shield = await Shield.fromYaml('.guardrails.yaml').withClient(model).build()
const protectedTools = shield.protectTools(myTools)
// ... pass protectedTools to your agent constructor
```

### Pattern C — Stage 1 + 5 boundary (opaque loops)

For black-box agent loops you don't control. AgentShield runs Stage 1 (input) and Stage 5 (output) around the call, plus Stage 2/3/4 around individual tool calls if you wrap them with `shield.protectTool`:

```typescript
const shield = await Shield.fromYaml('.guardrails.yaml').withClient(model).build()

const result = await shield.run(async () => {
  // `currentUserInput()` is the effective value after Stage 1 mutations.
  return await runMyOpaqueAgent(currentUserInput())
}, { userInput: 'user input' })

// And for individual tool calls inside the loop:
const safe = await shield.protectTool('send_email', params, async (effective) => {
  return await actuallySend(effective)
})
```

## YAML auto-wiring

YAML configurations drive everything; no host code needed for the common case:

- **Bundled `kind: human` providers** — `provider: auto_reject` / `provider: deny` / `provider: console` work out of the box.
- **LLM clients** — `configurations: - {id, type: llm, provider, model, api_key_env}` auto-wire HTTP-based callers.
- **Classifiers** — `configurations: - {id, type: classifier, provider: ...}` auto-wire HTTP-based callers (the supported set lives in the Rust core under `agent_shield_core::classifiers`).

## Observability

```typescript
import { Shield, ConsoleObservabilityProvider } from '@microsoft/agent-shield'

const shield = await Shield.fromYaml('.guardrails.yaml')
  .withClient(model)
  .withObservability(new ConsoleObservabilityProvider())
  .build()
```

Every emitted event carries [OpenTelemetry GenAI semantic-convention](https://opentelemetry.io/docs/specs/semconv/gen-ai/) attributes (`gen_ai.system="agent_shield"`, `gen_ai.operation.name="guard.<stage>"`, `gen_ai.response.finish_reason="content_filter"` on blocks), so any OTel exporter (LangSmith, Phoenix, Honeycomb) sees AgentShield events with the same shape it sees other GenAI telemetry.

For a custom provider, register any object with an `emit(event)` method.

## Lower-level API

For framework-agnostic code, drop down to `RuntimeBuilder` directly:

```typescript
import { RuntimeBuilder } from '@microsoft/agent-shield'

const runtime = RuntimeBuilder.fromYaml('.guardrails.yaml').build()
const session = runtime.newSession({ userId: 'u1', correlationId: 'c1' })

const v1 = await session.validateInput('user prompt')
if (!v1.allowed) throw new Error(v1.reason)

const { verdict: v2, params } = await session.validateToolCall('send_email', toolParams)
if (!v2.allowed) throw new Error(v2.reason)
```

## Building from source

```bash
cd sdk/node
npm install
npm run build           # napi-rs build
npm run build:wrapper   # TypeScript compile
npx vitest run          # tests
```

## More

- [Specification](../../spec/SPECIFICATION.md) — the source of truth for `.guardrails.yaml` semantics.
- [SDK guarded-turn semantics](../../docs/sdk-guarded-turn-semantics.md) — effective Stage 1 input, Stage 3 parameters, and `recordToolSuccess`.
- [Expression-language reference](../../spec/expressions/LANGUAGE.md).
- [Examples](../../examples/) — bank-manager, sensitive-documents, IFC, ask-human MCP server.
