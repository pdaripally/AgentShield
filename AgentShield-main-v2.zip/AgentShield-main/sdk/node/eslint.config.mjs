import js from "@eslint/js";
import tseslint from "typescript-eslint";
import security from "eslint-plugin-security";

export default [
  js.configs.recommended,
  ...tseslint.configs.recommended,
  security.configs.recommended,
  {
    files: ["**/*.ts", "**/*.js"],
    ignores: ["__tests__/**", "node_modules/**", "dist/**"],
    rules: {
      "security/detect-eval-with-expression": "error",
      "security/detect-non-literal-regexp": "warn",
      "security/detect-possible-timing-attacks": "warn",
      "preserve-caught-error": "off",
    }
  },
  {
    ignores: ["node_modules/", "dist/", "*.d.ts", "__tests__/", "eslint-rules/"]
  }
];
