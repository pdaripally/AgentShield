// Capability-based shield orchestrator (mirrors Python
// `agent_shield.adapters._shield`).
//
// What lives here (framework-agnostic):
//
//   - Stage sequencing and beginTurn / endTurn invariants
//   - Shield orchestrator class with monitor mode, on-block policy,
//     capability report, decision hooks
//   - GuardedRunner with run / runStreamed and ContextVar-equivalent
//     ambient session via AsyncLocalStorage
//   - Tool wrapping helper that routes through the orchestrator
//
// What does NOT live here:
//
//   - Framework-specific shape translation (LLM client → caller, tool
//     extraction, agent invocation, streaming chunk format) — those
//     live in framework-adapter modules and implement the capability
//     interfaces declared below.

import { AsyncLocalStorage } from 'node:async_hooks'
import { randomUUID } from 'node:crypto'
import {
  dispatchStageVerdict,
  dispatchToolVerdict,
  formatBlockMessage,
} from './native.js'
// Namespace import (lazy property access) breaks the shield ↔ index
// module cycle: when this module is loaded as a side-effect of
// index.ts loading, the partial `_index` object is empty, but by the
// time `ShieldBuilder.build()` is called the cycle has resolved and
// `_index.RuntimeBuilder` is fully defined.
import * as _index from './index.js'
// Type-only import — TS erases this at compile time, so it doesn't
// reintroduce the value-level cycle with `_index`.
import type { LlmConfiguration } from './index.js'

// ─── Types from index.ts referenced here ─────────────────────────
// We avoid importing them directly to prevent the cycle. The shapes
// below are structural and match the canonical types.

export interface StageVerdictLike {
  allowed: boolean
  action?: string | null
  reason?: string | null
  policy?: string | null
  evaluateWhenIndex?: number | null
  evaluate_when_index?: number | null
  bypassedByAllowedWhen?: boolean
  bypassed_by_allowed_when?: boolean
  redaction?: string | null
  appended?: string | null
  prepended?: string | null
  invocationHash?: string | null
  invocation_hash?: string | null
  postValidationInvocationHash?: string | null
  post_validation_invocation_hash?: string | null
}

export interface ToolCallOutcomeLike {
  verdict: StageVerdictLike
  params?: unknown
}

export interface ToolOutputOutcomeLike {
  verdict: StageVerdictLike
  result?: unknown
}

export interface OutputOutcomeLike {
  verdict: StageVerdictLike
  response?: string
}

export interface StreamChunkResultLike {
  action?: string | null
  payload?: string | null
  reason?: string | null
}

/**
 * Validation cadence configured on a {@link StreamingGuardLike}.
 * Mirrors `StreamingTrigger` in the Rust core.
 *
 * - `on_complete` — buffer every chunk through the engine and emit
 *   only the final validated payload at `finish()`. Streaming adapters
 *   MUST NOT yield text-bearing chunks to the consumer until
 *   `finish()` resolves.
 * - `windowed` — re-validate every `window_size` bytes (`overlap`
 *   bytes held back).
 * - `per_chunk` — validate after every chunk, in real time.
 */
export type StreamingMode = 'on_complete' | 'windowed' | 'per_chunk'

export interface SessionLike {
  beginTurn(): unknown
  endTurn(): unknown
  validateInput(input: string): Promise<StageVerdictLike>
  validateToolCall(
    tool: string,
    params: unknown,
    toolCallId: string,
  ): Promise<ToolCallOutcomeLike>
  validateToolOutput(
    tool: string,
    result: unknown,
    toolCallId: string,
  ): Promise<ToolOutputOutcomeLike>
  validateOutput(response: string): Promise<OutputOutcomeLike>
  recordToolSuccess(tool: string, result?: unknown): void
  recordToolFailure(tool: string, error: string): void
  streamingSession(stage: number | string): StreamingGuardLike
}

export interface StreamingGuardLike {
  addChunk(chunk: string): Promise<StreamChunkResultLike>
  finish(): Promise<StreamChunkResultLike>
  readonly mode: StreamingMode
}

export interface RuntimeLike {
  newSession(): SessionLike
  /**
   * Effective runtime mode (#14): `"active"` or `"shadow"`. Optional
   * so mock runtimes still satisfy the type. Shadow forces the
   * Shield to {@link ShieldMode.MONITOR}.
   */
  mode?(): string
}

// ─── Coverage levels ─────────────────────────────────────────────

export const CoverageLevel = Object.freeze({
  FULL: 'full',
  PARTIAL: 'partial',
  UNSUPPORTED: 'unsupported',
} as const)
export type CoverageLevelValue = typeof CoverageLevel[keyof typeof CoverageLevel]

export interface CapabilityReportInit {
  framework: string
  inputValidation?: CoverageLevelValue
  stateValidation?: CoverageLevelValue
  toolAuthorization?: CoverageLevelValue
  toolExecutionValidation?: CoverageLevelValue
  toolOutputValidation?: CoverageLevelValue
  outputValidation?: CoverageLevelValue
  streamingOutput?: CoverageLevelValue
  notes?: readonly string[]
}

export class CapabilityReport {
  readonly framework: string
  readonly inputValidation: CoverageLevelValue
  readonly stateValidation: CoverageLevelValue
  readonly toolAuthorization: CoverageLevelValue
  readonly toolExecutionValidation: CoverageLevelValue
  readonly toolOutputValidation: CoverageLevelValue
  readonly outputValidation: CoverageLevelValue
  readonly streamingOutput: CoverageLevelValue
  readonly notes: readonly string[]

  constructor(opts: CapabilityReportInit) {
    this.framework = opts.framework
    this.inputValidation = opts.inputValidation ?? CoverageLevel.FULL
    this.stateValidation = opts.stateValidation ?? CoverageLevel.FULL
    this.toolAuthorization = opts.toolAuthorization ?? CoverageLevel.FULL
    this.toolExecutionValidation = opts.toolExecutionValidation ?? CoverageLevel.FULL
    this.toolOutputValidation = opts.toolOutputValidation ?? CoverageLevel.FULL
    this.outputValidation = opts.outputValidation ?? CoverageLevel.FULL
    this.streamingOutput = opts.streamingOutput ?? CoverageLevel.FULL
    this.notes = (opts.notes ?? []).slice()
  }

  isFullCoverage(): boolean {
    return [
      this.inputValidation,
      this.stateValidation,
      this.toolAuthorization,
      this.toolExecutionValidation,
      this.toolOutputValidation,
      this.outputValidation,
      this.streamingOutput,
    ].every((l) => l === CoverageLevel.FULL)
  }
}

// ─── Capability bundle interfaces ────────────────────────────────

export interface ToolMeta {
  name: string
  description?: string
}

export interface ToolWrapper<TTool = unknown, TGuarded = unknown> {
  extract(tool: TTool): ToolMeta
  invoke(tool: TTool, params: Record<string, unknown>): Promise<unknown> | unknown
  wrap(
    tool: TTool,
    meta: ToolMeta,
    guardedInvoke: (params: Record<string, unknown>, userInput?: string) => Promise<unknown>,
  ): TGuarded
}

export interface AgentBoundary<TAgent = unknown, TResult = unknown> {
  run(agent: TAgent, inputText: string | undefined, opts: Record<string, unknown>): Promise<TResult>
  extractOutput(result: TResult): string | null | undefined
  applyRedaction(result: TResult, redactedText: string | null | undefined): TResult
  makeBlocked(message: string): TResult
}

export interface StreamingValidatorLike {
  push(text: string): Promise<{ payload: string | null; stopped: boolean; reason: string | null }>
  finish(): Promise<{ payload: string | null; stopped: boolean; reason: string | null }>
  makeBlocked(message: string): unknown
  applyRedaction(chunk: unknown, text: string): unknown
  /**
   * The underlying guard's configured validation cadence (see
   * {@link StreamingMode}). Adapters use this to decide whether to
   * forward upstream chunks to the consumer in real time
   * (`per_chunk` / `windowed`) or to buffer every chunk and emit the
   * validated payload only at `finish()` (`on_complete`).
   */
  readonly mode: StreamingMode
}

export interface StreamingAdapter<TAgent = unknown, TEmission = unknown> {
  stream(
    agent: TAgent,
    inputText: string | undefined,
    validator: StreamingValidatorLike,
    opts: Record<string, unknown>,
  ): AsyncIterable<TEmission>
}

export interface LlmCallerFactory<TClient = unknown, TCaller = unknown> {
  makeCaller(client: TClient, ctx?: AdapterContext): TCaller
}

/**
 * Context passed to {@link LlmCallerFactory.makeCaller} so framework
 * adapters can surface their own (non-stage) errors through the same
 * observability stream as Stage 1–5 verdicts.
 *
 * Used by adapters that fail-CLOSED on a provider outage (e.g. the
 * Anthropic agent loop turns an Anthropic API 503 into a synthesized
 * block string). The fail-closed return is the right policy choice,
 * but conflating "the provider went down" with "the policy blocked" is
 * a SRE foot-gun — `recordAdapterError` routes the original error
 * through observability as a distinct signal so root-cause analysis
 * works.
 */
export interface AdapterContext {
  /** Emit a free-form `adapter.llm_caller_error` log event. */
  recordAdapterError(error: unknown): void

  /**
   * Look up a `configurations[]` entry from the merged YAML at LLM-caller
   * call time. Returns the camelCased configuration snapshot when the
   * runtime has a matching `type: llm` entry, or `null` when nothing
   * matches (unknown id, wrong `type`, or `configurationId` is empty).
   *
   * Adapter LLM-caller factories MUST use this to honour the YAML's
   * per-stage `model:` / `max_tokens:` selections; falling back to a
   * hard-coded model is a bug — the canonical adapters raise
   * {@link ConfigurationMissingModelError} when the resolved
   * configuration has neither `model:` nor `deployment:`. `null` is
   * returned (not thrown) on any lookup failure so caller closures
   * never need a try/catch around the resolver call; the underlying
   * `Runtime.llmConfiguration` errors are routed through observability
   * via {@link recordAdapterError}.
   *
   * Optional — third-party `LlmCallerFactory` implementations that
   * pre-date this field continue to work; they simply can't drive
   * per-stage model selection from YAML.
   */
  configurationResolver?: (
    configurationId: string | null | undefined,
  ) => LlmConfiguration | null
}

export interface CapabilityBundle {
  name: string
  capabilities: CapabilityReport
  toolWrapper?: ToolWrapper
  agentBoundary?: AgentBoundary
  streamingAdapter?: StreamingAdapter
  llmCallerFactory?: LlmCallerFactory
}

// ─── Shield mode + on-block policy ──────────────────────────────

export const ShieldMode = Object.freeze({
  ENFORCE: 'enforce',
  MONITOR: 'monitor',
} as const)
export type ShieldModeValue = typeof ShieldMode[keyof typeof ShieldMode]

export type OnBlockPolicy =
  | 'returnBlocked'
  | 'return_blocked'
  | 'returnVerdict'
  | 'return_verdict'
  | 'raise'
  | ((verdict: unknown) => unknown)

export class AgentShieldBlocked extends Error {
  override readonly name = 'AgentShieldBlocked'
  readonly verdict: unknown
  override readonly message: string

  constructor(verdict: unknown, message: string) {
    super(message)
    this.verdict = verdict
    this.message = message
  }
}

/**
 * Raised when an LLM-caller adapter is asked to invoke a
 * `configurations[]` entry that does not declare `model:`.
 *
 * A security library MUST NOT pick a model on the customer's behalf.
 * When the runtime resolves the configuration referenced by a guard
 * policy's stage and finds an entry with no `model:` — or no matching
 * entry at all — the LLM caller surfaces this typed exception instead
 * of silently falling back to a hard-coded SKU (`gpt-4o-mini` /
 * `claude-sonnet-4-20250514` historically). The schema in
 * `spec/schema/guardrails.schema.json` rejects entries missing
 * `model:` at load time, so in normal operation this exception fires
 * only when an out-of-band configuration source bypasses schema
 * validation or when the runtime asks for a `configurationId` that
 * doesn't exist.
 *
 * Recovery: declare `model: <name>` on the offending
 * `configurations[]` entry in `.guardrails.yaml`. `model:` is the
 * identifier passed verbatim to the provider SDK — a model name for
 * direct OpenAI, a deployment name for Azure OpenAI, the
 * provider-native identifier for Anthropic / Amazon Bedrock /
 * Google Gemini / Vertex AI / Ollama / etc.
 */
export class ConfigurationMissingModelError extends Error {
  override readonly name = 'ConfigurationMissingModelError'
  readonly configurationId: string | null

  constructor(configurationId: string | null | undefined) {
    const idRepr =
      configurationId == null || configurationId === ''
        ? '<unset>'
        : configurationId
    super(
      `LLM configuration '${idRepr}' is missing 'model'. Add ` +
        `'model: <name>' to the configurations[] entry in your ` +
        `.guardrails.yaml. 'model:' is passed verbatim to the ` +
        `provider SDK — a model name for direct OpenAI, a deployment ` +
        `name for Azure OpenAI.`,
    )
    this.configurationId = configurationId ?? null
  }
}

// ─── Ambient session (AsyncLocalStorage equivalent of
//     Python's contextvars) ─────────────────────────────────────

interface AmbientStore {
  session: SessionLike
  userInput: string
}

const _ambient: AsyncLocalStorage<AmbientStore> = new AsyncLocalStorage()

export function currentSession(): SessionLike | null {
  return _ambient.getStore()?.session ?? null
}

export function currentUserInput(): string {
  return _ambient.getStore()?.userInput ?? ''
}

// ─── Shared orchestration helpers ───────────────────────────────

interface VerdictWire {
  allowed: boolean
  action: string | null
  reason: string | null
  policy: string | null
  evaluate_when_index: number | null
  bypassed_by_allowed_when: boolean
  redaction: string | null
  appended: string | null
  prepended: string | null
}

interface DispatchAction {
  kind: string
  message?: string
  value?: unknown
}

interface DispatchDecision {
  action: DispatchAction
  record_failure?: boolean
  record_success?: boolean
}

// Convert a JS verdict object (the camelCase shape every native
// `validate*` returns post-camelize) to the canonical wire shape
// consumed by the dispatch FFI. We defensively coerce undefined fields
// to null so the wire-shape parser accepts the payload.
function _verdictToWire(v: StageVerdictLike | null | undefined): VerdictWire {
  return {
    allowed: !!(v && v.allowed),
    action: (v && v.action) ?? null,
    reason: (v && v.reason) ?? null,
    policy: (v && v.policy) ?? null,
    evaluate_when_index:
      (v && (v.evaluateWhenIndex ?? v.evaluate_when_index)) ?? null,
    bypassed_by_allowed_when: !!(
      v && (v.bypassedByAllowedWhen ?? v.bypassed_by_allowed_when)
    ),
    redaction: (v && v.redaction) ?? null,
    appended: (v && v.appended) ?? null,
    prepended: (v && v.prepended) ?? null,
  }
}

export function _formatBlock(verdict: StageVerdictLike): string {
  // Single source of truth: route through the core formatter so the
  // canonical `[GUARDRAIL ACTION] reason` string is byte-equivalent
  // across every SDK.
  return formatBlockMessage(_verdictToWire(verdict))
}

interface DispatchOpts {
  policy?: string
  mode?: string
}

function _dispatchStage(
  verdict: StageVerdictLike,
  opts: DispatchOpts = {},
): DispatchDecision {
  return dispatchStageVerdict(_verdictToWire(verdict), {
    policy: opts.policy ?? 'return_blocked',
    mode: opts.mode ?? 'enforce',
  }) as DispatchDecision
}

interface DispatchToolOpts extends DispatchOpts {
  stage?: string
}

function _dispatchTool(
  verdict: StageVerdictLike,
  toolName: string,
  opts: DispatchToolOpts = {},
): DispatchDecision {
  return dispatchToolVerdict(_verdictToWire(verdict), toolName, {
    stage: opts.stage ?? 'output',
    policy: opts.policy ?? 'return_blocked',
    mode: opts.mode ?? 'enforce',
  }) as DispatchDecision
}

export interface GuardedToolResult {
  blocked: boolean
  output: string
}

async function _guardedTool(
  session: SessionLike,
  toolName: string,
  params: Record<string, unknown> | null | undefined,
  execute: (effective: Record<string, unknown>) => Promise<unknown>,
  _opts: { userInput?: string } = {},
): Promise<GuardedToolResult> {
  void _opts
  const cleaned: Record<string, unknown> = { ...(params ?? {}) }
  for (const k of Object.keys(cleaned)) {
    // eslint-disable-next-line security/detect-object-injection -- k is enumerated from the local cleaned tool params object.
    if (cleaned[k] === undefined || cleaned[k] === null) delete cleaned[k]
  }
  // §16.0 binding: this is a wrapper-owned Pattern-B dispatch boundary.
  // Mint a stable per-call UUID so Stage 3 and Stage 4 can find the
  // same canonical invocation. Without this, concurrent same-name
  // tool calls inside the same ambient session would collide on the
  // same binding key and both outputs would fail closed.
  const callId = randomUUID()
  const callOutcome = await session.validateToolCall(toolName, cleaned, callId)
  const callDecision = _dispatchTool(callOutcome.verdict, toolName, { stage: 'call' })
  if (callDecision.action.kind === 'blocked') {
    return { blocked: true, output: callDecision.action.message ?? '' }
  }
  const effective =
    (callOutcome.params as Record<string, unknown> | undefined) ?? cleaned

  let raw: unknown
  try {
    raw = await execute(effective)
  } catch (err) {
    try {
      session.recordToolFailure(toolName, String(err))
    } catch {
      /* swallow */
    }
    const errText = `[tool error] ${toolName}: ${err}`
    const errOutcome = await session.validateToolOutput(toolName, errText, callId)
    const errDecision = _dispatchStage(errOutcome.verdict)
    if (errDecision.action.kind === 'return_blocked') {
      return { blocked: true, output: errDecision.action.message ?? '' }
    }
    return { blocked: false, output: String(errOutcome.result ?? errText) }
  }

  const outputStr = typeof raw === 'string' ? raw : String(raw)
  const outOutcome = await session.validateToolOutput(toolName, outputStr, callId)
  const outDecision = _dispatchTool(outOutcome.verdict, toolName, { stage: 'output' })
  if (outDecision.action.kind === 'blocked') {
    if (outDecision.record_failure) {
      try {
        session.recordToolFailure(toolName, outOutcome.verdict.reason ?? 'blocked')
      } catch {
        /* swallow */
      }
    }
    return { blocked: true, output: outDecision.action.message ?? '' }
  }

  const final = outOutcome.result ?? outputStr
  const finalStr = typeof final === 'string' ? final : String(final)
  if (outDecision.record_success) {
    try {
      session.recordToolSuccess(toolName, finalStr)
    } catch {
      /* swallow */
    }
  }
  return { blocked: false, output: finalStr }
}

async function _checkStage1(
  session: SessionLike,
  userInput: string | undefined,
): Promise<string | null> {
  if (!userInput) return null
  const verdict = await session.validateInput(userInput)
  const decision = _dispatchStage(verdict)
  if (decision.action.kind === 'return_blocked') {
    return decision.action.message ?? ''
  }
  return null
}

// ─── GuardedRunner ──────────────────────────────────────────────

export interface GuardedRunnerOpts {
  mode?: ShieldModeValue
  onBlock?: OnBlockPolicy
  streamingConfig?: Record<string, unknown>
}

export interface RunOpts extends Record<string, unknown> {
  session?: SessionLike
}

export class GuardedRunner<TAgent = unknown, TResult = unknown> {
  protected readonly _runtime: RuntimeLike
  protected readonly _agent: TAgent
  protected readonly _boundary: AgentBoundary<TAgent, TResult>
  protected readonly _streaming: StreamingAdapter<TAgent, unknown> | undefined
  protected readonly _mode: ShieldModeValue
  protected readonly _onBlock: OnBlockPolicy
  protected readonly _streamingConfig: Record<string, unknown> | undefined
  protected readonly _session: SessionLike

  constructor(
    runtime: RuntimeLike,
    agent: TAgent,
    boundary: AgentBoundary<TAgent, TResult>,
    streaming?: StreamingAdapter<TAgent, unknown>,
    opts: GuardedRunnerOpts = {},
  ) {
    if (!boundary) {
      throw new TypeError(
        'GuardedRunner requires an AgentBoundary; framework adapter does not support agent run wrapping',
      )
    }
    this._runtime = runtime
    this._agent = agent
    this._boundary = boundary
    this._streaming = streaming
    // Shadow mode (#14) forces MONITOR.
    const runtimeMode = typeof runtime.mode === 'function'
      ? runtime.mode()
      : 'active'
    this._mode = runtimeMode === 'shadow'
      ? ShieldMode.MONITOR
      : (opts.mode ?? ShieldMode.ENFORCE)
    this._onBlock = opts.onBlock ?? 'returnBlocked'
    this._streamingConfig = opts.streamingConfig
    this._session = runtime.newSession()
  }

  get agent(): TAgent {
    return this._agent
  }

  /**
   * Returns a NEW `GuardedRunner` bound to a fresh session spawned
   * from the same runtime. The original runner — and any in-flight
   * conversation it owns — is not mutated. This is the canonical,
   * post-build-immutable way to "start a new conversation" for an
   * agent.
   *
   * Mirrors the Rust `Shield::with_fresh_session`, the .NET
   * `Shield.WithFreshSession`, and the Python
   * `GuardedRunner.with_fresh_session` APIs.
   */
  withFreshSession(): GuardedRunner<TAgent, TResult> {
    return new GuardedRunner<TAgent, TResult>(
      this._runtime,
      this._agent,
      this._boundary,
      this._streaming,
      {
        mode: this._mode,
        onBlock: this._onBlock,
        streamingConfig: this._streamingConfig,
      },
    )
  }

  async run(inputText: string | undefined, opts: RunOpts = {}): Promise<TResult> {
    const session = opts.session ?? this._session
    const boundary = this._boundary
    const onBlock = this._onBlock
    const mode = this._mode

    const ambientStore = { session, userInput: inputText ?? '' }
    return await _ambient.run(
      ambientStore,
      async (): Promise<TResult> => {
        session.beginTurn()
        try {
          let effectiveInput = inputText ?? ''
          if (mode === ShieldMode.MONITOR) {
            return await this._runMonitorMode(session, inputText, opts)
          }

          // Stage 1 — canonical dispatch.
          if (inputText) {
            const verdict = await session.validateInput(inputText)
            const decision = _dispatchStage(verdict)
            if (decision.action.kind === 'return_blocked') {
              return _resolveBlock(
                onBlock,
                boundary,
                verdict,
                decision.action.message ?? '',
              ) as TResult
            }
            if (decision.action.kind === 'proceed_with_mutation') {
              effectiveInput = String(decision.action.value ?? effectiveInput)
            }
          }
          ambientStore.userInput = effectiveInput

          const result = await boundary.run(this._agent, effectiveInput, opts)

          const outputText = boundary.extractOutput(result)
          if (typeof outputText === 'string' && outputText.length > 0) {
            const outcome = await session.validateOutput(outputText)
            const stage5 = _dispatchStage(outcome.verdict)
            if (stage5.action.kind === 'return_blocked') {
              return _resolveBlock(
                onBlock,
                boundary,
                outcome.verdict,
                stage5.action.message ?? '',
              ) as TResult
            }
            if (stage5.action.kind === 'proceed_with_mutation') {
              return boundary.applyRedaction(result, outcome.response)
            }
          }
          return result
        } finally {
          try {
            session.endTurn()
          } catch {
            /* swallow */
          }
        }
      },
    )
  }

  protected async _runMonitorMode(
    session: SessionLike,
    inputText: string | undefined,
    opts: RunOpts,
  ): Promise<TResult> {
    // Run validation for observability; never block. Core stamps every
    // emitted event with `mode: shadow` + `enforced: false` and routes
    // through the registered ObservabilityProvider.
    try {
      await session.validateInput(inputText ?? '')
    } catch {
      /* swallow */
    }
    const result = await this._boundary.run(this._agent, inputText, opts)
    const outputText = this._boundary.extractOutput(result)
    if (typeof outputText === 'string' && outputText.length > 0) {
      try {
        await session.validateOutput(outputText)
      } catch {
        /* swallow */
      }
    }
    return result
  }

  /**
   * Run the agent with streaming Stage 5 enforcement.
   *
   * Emission scheduling honours the streaming guard's configured mode
   * (see {@link StreamingMode}). When the mode is `on_complete` the
   * orchestrator pushes every text-bearing chunk through the engine
   * for accumulation but emits NOTHING to the consumer until
   * `validator.finish()` resolves — that final call yields a single
   * terminal chunk carrying the validated/redacted text (or a block
   * message if Stage 5 stopped the buffer). When the mode is
   * `per_chunk` or `windowed` the framework adapter forwards
   * validated chunks in real time.
   *
   * Metadata-only chunks (no text content) are always passed through
   * promptly because they are not security-relevant.
   */
  async *runStreamed(
    inputText: string | undefined,
    opts: RunOpts = {},
  ): AsyncGenerator<unknown, void, void> {
    if (!this._streaming) {
      throw new Error(
        'streaming is unsupported for this framework (no StreamingAdapter in bundle)',
      )
    }
    const session = opts.session ?? this._session
    const boundary = this._boundary
    const streaming = this._streaming

    session.beginTurn()
    try {
      // Shadow / Monitor (#14): run Stage 1 for observability but
      // never short-circuit; stream through a monitor validator that
      // pushes chunks to the real Stage-5 streaming guard for audit
      // events but always emits the original chunks. Core stamps
      // every emitted event with `mode: shadow` + `enforced: false`.
      if (this._mode === ShieldMode.MONITOR) {
        await session.validateInput(inputText ?? '')
        let guard: StreamingGuardLike | null = null
        try {
          guard = session.streamingSession(5)
        } catch {
          /* fall back to no-guard observability */
        }
        const passthrough = new _MonitorStreamingValidator(boundary, guard)
        const inner = streaming.stream(this._agent, inputText, passthrough, opts)
        for await (const emission of inner) {
          yield emission
        }
        // Drain the guard's finish() so any tail Stage-5 evaluation
        // fires for observability.
        if (guard) {
          try {
            await passthrough.finish()
          } catch {
            /* swallow */
          }
        }
        return
      }

      const stage1Block = await _checkStage1(session, inputText)
      if (stage1Block) {
        yield boundary.makeBlocked(stage1Block)
        return
      }
      const guard = session.streamingSession(5)
      const validator = new _OrchestratorStreamingValidator(guard, boundary)
      const inner = streaming.stream(this._agent, inputText, validator, opts)
      for await (const emission of inner) {
        yield emission
      }
    } finally {
      try {
        session.endTurn()
      } catch {
        /* swallow */
      }
    }
  }
}

class _OrchestratorStreamingValidator implements StreamingValidatorLike {
  private readonly _guard: StreamingGuardLike
  private readonly _boundary: AgentBoundary

  constructor(guard: StreamingGuardLike, boundary: AgentBoundary) {
    this._guard = guard
    this._boundary = boundary
  }

  get mode(): StreamingMode {
    return this._guard.mode
  }

  async push(text: string) {
    const r = await this._guard.addChunk(text)
    return {
      payload: r.payload ?? null,
      stopped: r.action === 'stop' || !!(r as { stopped?: boolean }).stopped,
      reason: r.reason ?? null,
    }
  }

  async finish() {
    const r = await this._guard.finish()
    return {
      payload: r.payload ?? null,
      stopped: r.action === 'stop' || !!(r as { stopped?: boolean }).stopped,
      reason: r.reason ?? null,
    }
  }

  makeBlocked(message: string): unknown {
    return this._boundary.makeBlocked(message)
  }

  applyRedaction(chunk: unknown, text: string): unknown {
    return this._boundary.applyRedaction(chunk, text)
  }
}

/**
 * Monitor-mode streaming validator (#14). Pushes chunks through the
 * real Stage-5 streaming guard for observability, logs a warning
 * when the guard would have blocked or redacted, but always emits
 * the ORIGINAL chunk text and never reports `stopped`. `finish()` is
 * idempotent: the adapter typically calls it at the end of `stream()`
 * and the orchestrator may call it again for tail drain; the second
 * call is a no-op so we don't emit a spurious "stream already ended"
 * warning.
 */
class _MonitorStreamingValidator implements StreamingValidatorLike {
  private readonly _guard: StreamingGuardLike | null
  private readonly _boundary: AgentBoundary
  private _finished = false

  constructor(boundary: AgentBoundary, guard: StreamingGuardLike | null) {
    this._boundary = boundary
    this._guard = guard
  }

  get mode(): StreamingMode {
    // Per-chunk so the adapter forwards chunks promptly; in shadow
    // we never want to buffer the customer's output.
    return 'per_chunk' as StreamingMode
  }

  async push(text: string) {
    if (this._guard) {
      try {
        await this._guard.addChunk(text)
      } catch {
        /* swallow — observability is best-effort */
      }
    }
    return { payload: text, stopped: false, reason: null }
  }

  async finish() {
    if (this._finished) {
      return { payload: null, stopped: false, reason: null }
    }
    this._finished = true
    if (this._guard) {
      try {
        await this._guard.finish()
      } catch {
        /* swallow */
      }
    }
    return { payload: null, stopped: false, reason: null }
  }

  makeBlocked(message: string): unknown {
    return this._boundary.makeBlocked(message)
  }

  applyRedaction(chunk: unknown, text: string): unknown {
    return this._boundary.applyRedaction(chunk, text)
  }
}

function _resolveBlock(
  onBlock: OnBlockPolicy,
  boundary: AgentBoundary,
  verdict: StageVerdictLike | null | undefined,
  message: string,
): unknown {
  // Function form is the host's custom callback — core never owns it.
  if (typeof onBlock === 'function') {
    return onBlock(verdict ?? message)
  }
  // For everything else, route through the canonical dispatcher so
  // the action tag is identical to what every other SDK computes.
  // We synthesise a deny verdict when the caller passed only a
  // message (the Stage-1 path); otherwise the real verdict drives.
  const v: StageVerdictLike =
    verdict ?? {
      allowed: false,
      action: 'block',
      reason: message?.replace(/^\[GUARDRAIL [A-Z]+\]\s*/, '') ?? null,
    }
  const policy =
    typeof onBlock === 'string'
      ? onBlock === 'raise'
        ? 'raise'
        : onBlock === 'returnVerdict' || onBlock === 'return_verdict'
          ? 'return_verdict'
          : 'return_blocked'
      : 'return_blocked'
  const decision = _dispatchStage(v, { policy })
  const action = decision.action
  switch (action.kind) {
    case 'raise':
      throw new AgentShieldBlocked(verdict, action.message ?? '')
    case 'return_verdict':
      return verdict
    case 'return_blocked':
    default:
      return boundary.makeBlocked(action.message ?? '')
  }
}

// ─── Tool registry: wrap a list of framework tools ──────────────

export async function protectToolsViaWrapper<TTool, TGuarded>(
  runtime: RuntimeLike,
  tools: readonly TTool[],
  wrapper: ToolWrapper<TTool, TGuarded>,
  opts: Record<string, unknown> = {},
): Promise<TGuarded[]> {
  // Shadow / Monitor (#14): when called via `Shield.protectTools` with
  // shadow runtime, the caller passes `mode: 'monitor'` here. In that
  // mode we still run Stage 3 / Stage 4 for observability but always
  // execute the underlying tool with the caller's original params.
  const monitor = opts.mode === ShieldMode.MONITOR || opts.mode === 'monitor'
  const out: TGuarded[] = []
  for (const tool of tools) {
    const meta = wrapper.extract(tool)
    const guardedInvoke = async (
      params: Record<string, unknown>,
      userInput?: string,
    ): Promise<string> => {
      const session = currentSession() ?? runtime.newSession()
      const inp = userInput ?? currentUserInput()
      const ambient = _ambient.getStore()
      const exec = async (effective: Record<string, unknown>) =>
        wrapper.invoke(tool, effective)
      if (monitor) {
        const ambientStore = _ambient.getStore()
        const ownTurn = !ambientStore
        if (ownTurn) {
          session.beginTurn()
        }
        const runMonitor = async (): Promise<string> => {
          const effective: Record<string, unknown> = { ...(params ?? {}) }
          // §16.0: mint a per-call id so concurrent same-name MONITOR
          // calls bind correctly through Stage 3 → Stage 4.
          const _monCallId = randomUUID()
          await session.validateToolCall(meta.name, effective, _monCallId)
          let raw: unknown
          try {
            raw = await exec(params ?? {})
          } catch (err) {
            const errText = `[tool error] ${meta.name}: ${String(err)}`
            await session.validateToolOutput(meta.name, errText, _monCallId)
            try {
              session.recordToolFailure(meta.name, String(err))
            } catch {
              /* swallow */
            }
            return errText
          }
          await session.validateToolOutput(meta.name, raw, _monCallId)
          try {
            session.recordToolSuccess(meta.name, raw)
          } catch {
            /* swallow */
          }
          return typeof raw === 'string' ? raw : raw == null ? '' : String(raw)
        }
        try {
          if (ambientStore) {
            return await runMonitor()
          }
          return await _ambient.run({ session, userInput: inp }, runMonitor)
        } finally {
          if (ownTurn) {
            try {
              session.endTurn()
            } catch {
              /* swallow */
            }
          }
        }
      }
      let result: GuardedToolResult
      if (ambient) {
        result = await _guardedTool(session, meta.name, params, exec, { userInput: inp })
      } else {
        result = await _ambient.run(
          { session, userInput: inp },
          () => _guardedTool(session, meta.name, params, exec, { userInput: inp }),
        )
      }
      return result.output
    }
    out.push(wrapper.wrap(tool, meta, guardedInvoke))
  }
  return out
}

// ─── Adapter observability emitter ──────────────────────────────
//
// Builds a `ShieldLogEvent`-shaped event (snake_case → camelCase
// already applied because we never round-trip through napi for these)
// and feeds it to every registered provider. Errors thrown by
// providers are swallowed — observability is fire-and-forget.

export function _emitAdapterErrorEvent(
  providers: ReadonlyArray<(event: unknown) => void>,
  adapterName: string,
  error: unknown,
): void {
  if (!providers || providers.length === 0) return
  const message = error instanceof Error ? error.message : String(error)
  const errorName = error instanceof Error ? error.name : 'Error'
  const event = {
    timestamp: new Date().toISOString(),
    severity: 'warn',
    eventType: 'adapter.llm_caller_error',
    category: 'adapter',
    stage: null,
    action: null,
    guardPolicy: null,
    evaluateWhenIndex: null,
    resource: null,
    variable: null,
    eventId: null,
    correlationId: '',
    sessionId: '',
    userId: null,
    tenantId: null,
    message: `${adapterName} llm caller error: ${message}`,
    attributes: {
      'agent_shield.adapter.name': adapterName,
      'agent_shield.adapter.error_name': errorName,
      'agent_shield.adapter.error_message': message,
    },
  }
  for (const p of providers) {
    try {
      p(event)
    } catch {
      // Providers must never break the caller — fire and forget.
    }
  }
}

// ─── Shield orchestrator ────────────────────────────────────────

export interface ShieldOpts {
  bundle?: CapabilityBundle | null
  mode?: ShieldModeValue
  onBlock?: OnBlockPolicy
  streamingConfig?: Record<string, unknown>
  observabilityProviders?: ReadonlyArray<(event: unknown) => void>
}

export interface ProtectToolsOpts {
  // Reserved for future per-call overrides.
  [key: string]: unknown
}

export class Shield {
  // Subclasses MAY override `BUNDLE` (via `static get BUNDLE() {...}`)
  // to seed a default capability bundle. The base class deliberately
  // returns `undefined` rather than throwing so:
  //   - `new Shield(runtime)` works without any adapter loaded.
  //   - Adapter `import`s do NOT race to install a default
  //     `Shield.BUNDLE`; the bundle is selected explicitly via
  //     `ShieldBuilder.with<Framework>()`.
  static get BUNDLE(): CapabilityBundle | undefined {
    return undefined
  }

  static get BUILDER_CLASS(): typeof ShieldBuilder | undefined {
    return undefined
  }

  readonly runtime: RuntimeLike
  // `_bundle` is set in the constructor but adapter `with<Framework>()`
  // patches re-bind it (non-readonly) so the late-binding flow works.
  protected _bundle: CapabilityBundle | null
  protected readonly _mode: ShieldModeValue
  protected readonly _onBlock: OnBlockPolicy
  protected readonly _streamingConfig: Record<string, unknown> | undefined
  protected readonly _guardedRunners: Set<GuardedRunner<unknown, unknown>>
  // Observability providers used for `recordAdapterError` and other
  // SDK-side, non-stage signals. Populated by `ShieldBuilder.build()`;
  // bare `new Shield(runtime)` constructors leave it empty.
  protected readonly _observabilityProviders: ReadonlyArray<(event: unknown) => void>

  constructor(runtime: RuntimeLike, opts: ShieldOpts = {}) {
    this.runtime = runtime
    const ctor = this.constructor as typeof Shield
    this._bundle = opts.bundle ?? ctor.BUNDLE ?? null
    // Shadow mode (#14) forces MONITOR.
    const runtimeMode = typeof runtime.mode === 'function'
      ? runtime.mode()
      : 'active'
    this._mode = runtimeMode === 'shadow'
      ? ShieldMode.MONITOR
      : (opts.mode ?? ShieldMode.ENFORCE)
    this._onBlock = opts.onBlock ?? 'returnBlocked'
    this._streamingConfig = opts.streamingConfig
    this._guardedRunners = new Set()
    this._observabilityProviders = opts.observabilityProviders ?? []
  }

  /**
   * Emit an `adapter.llm_caller_error` log event to every registered
   * observability provider. Used by framework adapters to surface
   * provider-side errors (e.g. an Anthropic API 503) that they choose
   * to fail-CLOSED on, so the original error is auditable as a
   * distinct signal rather than being conflated with a policy block.
   *
   * Free-form by design: the runtime's own log channel is shaped by
   * the Rust core and reserved for stage / guard-policy events. This
   * helper writes to the *same* provider callbacks but with an event
   * shape that lives entirely on the SDK side.
   */
  recordAdapterError(adapterName: string, error: unknown): void {
    _emitAdapterErrorEvent(this._observabilityProviders, adapterName, error)
  }

  static fromYaml(this: typeof Shield, path: string): ShieldBuilder {
    const BuilderCls = this.BUILDER_CLASS ?? ShieldBuilder
    return new BuilderCls(this, this.BUNDLE ?? null, path)
  }

  static fromYamlChain(this: typeof Shield, paths: readonly string[]): ShieldBuilder {
    const BuilderCls = this.BUILDER_CLASS ?? ShieldBuilder
    const b = new BuilderCls(this, this.BUNDLE ?? null, paths[0] ?? '')
    b._yamlChain = paths.slice()
    return b
  }

  get capabilities(): CapabilityReport {
    if (!this._bundle) {
      throw new Error(
        'Shield has no capability bundle: call `.with<Framework>()` on the ' +
          'builder (e.g. `.withLangchain()`, `.withOpenaiAgents()`, ' +
          '`.withAnthropic()`) before `.build()`, or supply ' +
          '`{ bundle }` to the constructor.',
      )
    }
    return this._bundle.capabilities
  }

  get mode(): ShieldModeValue {
    return this._mode
  }

  async protectTools<TTool, TGuarded = unknown>(
    tools: readonly TTool[],
    opts: ProtectToolsOpts = {},
  ): Promise<TGuarded[]> {
    const wrapper = this._bundle?.toolWrapper as ToolWrapper<TTool, TGuarded> | undefined
    if (!wrapper) {
      const name = this._bundle ? this._bundle.name : '<no bundle>'
      throw new Error(`${name} does not support tool wrapping`)
    }
    return protectToolsViaWrapper<TTool, TGuarded>(this.runtime, tools, wrapper, {
      ...opts,
      mode: this._mode,
    })
  }

  guard<TAgent = unknown, TResult = unknown>(agent: TAgent): GuardedRunner<TAgent, TResult> {
    if (!this._bundle || !this._bundle.agentBoundary) {
      const name = this._bundle ? this._bundle.name : '<no bundle>'
      throw new Error(
        `${name} does not support full agent run wrapping (no AgentBoundary). ` +
          `Use a framework-specific helper (e.g. \`runOpenaiAgent\`, ` +
          `\`runAnthropicAgent\`) or the generic \`shield.run(fn)\` Stage 1+5 wrapper instead.`,
      )
    }
    const runner = new GuardedRunner<TAgent, TResult>(
      this.runtime,
      agent,
      this._bundle.agentBoundary as AgentBoundary<TAgent, TResult>,
      this._bundle.streamingAdapter as StreamingAdapter<TAgent, unknown> | undefined,
      {
        mode: this._mode,
        onBlock: this._onBlock,
        streamingConfig: this._streamingConfig,
      },
    )
    this._guardedRunners.add(runner as GuardedRunner<unknown, unknown>)
    return runner
  }

  async beforeInvoke(
    userInput: string | undefined,
    opts: { session?: SessionLike } = {},
  ): Promise<string | null> {
    const ownSession = !opts.session
    const session = opts.session ?? this.runtime.newSession()
    if (ownSession) {
      session.beginTurn()
    }
    try {
      // Shadow / Monitor (#14): run Stage 1 for observability but
      // never return a block message so the caller proceeds. Core
      // emits the audit event via the observability dispatcher.
      if (this._mode === ShieldMode.MONITOR) {
        await session.validateInput(userInput ?? '')
        return null
      }
      return await _checkStage1(session, userInput)
    } finally {
      if (ownSession) {
        try {
          session.endTurn()
        } catch {
          /* swallow */
        }
      }
    }
  }

  // ─── Canonical Pattern C: Stage 1 + Stage 5 around an opaque
  //     user-supplied agent thunk ─────────────────────────────────
  //
  // Framework-agnostic `run` on the BASE `Shield` class to avoid
  // prototype-pollution races between adapter modules. Each adapter
  // installs its own `run<Framework>Agent(...)` for full-coverage
  // Pattern A; this method covers the drop-in case where the customer
  // hands us an opaque thunk and just wants Stage 1 + Stage 5.
  //
  // Mirrors the Python `_orchestration.guarded_turn` flow:
  //   begin_turn → Stage 1 → execute → Stage 5 → end_turn
  async run<T>(
    executeFn: () => T | Promise<T>,
    opts: { userInput?: string; session?: SessionLike } = {},
  ): Promise<T | string> {
    if (typeof executeFn !== 'function') {
      throw new TypeError('shield.run(fn): fn must be a function')
    }
    const userInput = opts.userInput ?? ''
    const session = opts.session ?? this.runtime.newSession()
    const ambientStore = { session, userInput }
    return await _ambient.run(
      ambientStore,
      async (): Promise<T | string> => {
        session.beginTurn()
        try {
          // Shadow / Monitor (#14): run stages for observability but
          // never short-circuit the caller's flow.
          if (this._mode === ShieldMode.MONITOR) {
            if (userInput) {
              await session.validateInput(userInput)
            }
            const raw = (await executeFn()) as T
            const text =
              typeof raw === 'string'
                ? raw
                : raw == null
                  ? ''
                  : String(raw)
            if (text.length > 0) {
              await session.validateOutput(text)
            }
            return raw
          }

          let effectiveInput = userInput
          if (userInput) {
            const verdict = await session.validateInput(userInput)
            const decision = _dispatchStage(verdict)
            if (decision.action.kind === 'return_blocked') {
              return decision.action.message ?? ''
            }
            if (decision.action.kind === 'proceed_with_mutation') {
              effectiveInput = String(decision.action.value ?? effectiveInput)
            }
          }
          ambientStore.userInput = effectiveInput

          const raw = (await executeFn()) as T

          const text =
            typeof raw === 'string'
              ? raw
              : raw == null
                ? ''
                : String(raw)
          if (text.length > 0) {
            const outcome = await session.validateOutput(text)
            const stage5 = _dispatchStage(outcome.verdict)
            if (stage5.action.kind === 'return_blocked') {
              return stage5.action.message ?? ''
            }
            if (stage5.action.kind === 'proceed_with_mutation') {
              return outcome.response ?? text
            }
          }
          return raw
        } finally {
          try {
            session.endTurn()
          } catch {
            /* swallow */
          }
        }
      },
    )
  }

  // ─── Canonical Pattern B helper: Stage 2 + 3 + 4 around a single
  //     tool function ──────────────────────────────────────────────
  async protectTool(
    name: string,
    params: Record<string, unknown> | null | undefined,
    executeFn: (effective: Record<string, unknown>) => Promise<unknown> | unknown,
  ): Promise<GuardedToolResult> {
    if (typeof executeFn !== 'function') {
      throw new TypeError(
        'shield.protectTool(name, params, fn): fn must be a function',
      )
    }
    const ambient = currentSession()
    let session: SessionLike
    let ownTurn = false
    if (ambient) {
      session = ambient
    } else {
      session = this.runtime.newSession()
      session.beginTurn()
      ownTurn = true
    }
    try {
      // Shadow / Monitor (#14): run Stage 3 / Stage 4 for observability
      // but never block; the tool sees the caller's original params.
      if (this._mode === ShieldMode.MONITOR) {
        const effective: Record<string, unknown> = { ...(params ?? {}) }
        // §16.0: mint a per-call id so concurrent same-name MONITOR
        // calls bind correctly through Stage 3 → Stage 4.
        const _monCallId = randomUUID()
        await session.validateToolCall(name, effective, _monCallId)
        let raw: unknown
        try {
          raw = await executeFn(params ?? {})
        } catch (err) {
          const errText = `[tool error] ${name}: ${String(err)}`
          await session.validateToolOutput(name, errText, _monCallId)
          try {
            session.recordToolFailure(name, String(err))
          } catch {
            /* swallow */
          }
          return { blocked: false, output: errText }
        }
        await session.validateToolOutput(name, raw, _monCallId)
        try {
          session.recordToolSuccess(name, raw)
        } catch {
          /* swallow */
        }
        const out = typeof raw === 'string' ? raw : raw == null ? '' : String(raw)
        return { blocked: false, output: out }
      }
      return await _guardedTool(
        session,
        name,
        params ?? null,
        async (effective) => executeFn(effective),
      )
    } finally {
      if (ownTurn) {
        try {
          session.endTurn()
        } catch {
          /* swallow */
        }
      }
    }
  }

  /**
   * Returns a NEW `Shield` instance backed by the same runtime,
   * bundle, mode, on-block policy, and streaming config — but with
   * an empty set of guarded runners. The original Shield (and the
   * runners spawned from it) are untouched. Mirrors the Rust
   * `Shield::with_fresh_session`, the .NET `Shield.WithFreshSession`,
   * and the Python `Shield.with_fresh_session` APIs.
   */
  withFreshSession(): this {
    const Ctor = this.constructor as new (rt: RuntimeLike, opts: ShieldOpts) => this
    return new Ctor(this.runtime, {
      bundle: this._bundle,
      mode: this._mode,
      onBlock: this._onBlock,
      streamingConfig: this._streamingConfig,
    })
  }
}

export class ShieldBuilder {
  protected readonly _shieldClass: typeof Shield
  // `_bundle` is set in the constructor but adapter `with<Framework>()`
  // patches re-bind it (non-readonly) so the late-binding flow works.
  protected _bundle: CapabilityBundle | null
  protected _path: string
  _yamlChain: readonly string[] | null = null
  protected readonly _observabilityProviders: Array<(event: unknown) => void> = []
  protected _llmCaller: ((req: unknown) => unknown) | null = null
  protected readonly _extra: Array<(builder: unknown) => void> = []
  protected _mode: ShieldModeValue = ShieldMode.ENFORCE
  protected _onBlock: OnBlockPolicy = 'returnBlocked'
  protected _consumed = false
  // Holds a client registered via `withClient(...)` when no bundle
  // with an `llmCallerFactory` is installed yet. Consumed by
  // `_rebindPendingLlmClient()` once an adapter installer (e.g.
  // `withLangchain()`, `withOpenaiAgents()`, `withAnthropic()`) sets
  // `_bundle`. Ensures `.withClient(c).with<Framework>()` and
  // `.with<Framework>().withClient(c)` produce equivalent Shields.
  _pendingLlmClient: unknown = null
  // Mutable indirection between an LLM-caller closure and the
  // runtime: adapter LLM-caller factories build their closure in
  // `_buildLlmCaller`, which fires the moment a client is wired —
  // typically BEFORE `build()` produces the runtime. The closure
  // therefore can't capture `Runtime.llmConfiguration` directly.
  // This holder is registered with the factory via
  // `AdapterContext.configurationResolver` at make-caller time and
  // populated in `build()` once the runtime exists, so calls to
  // `configurationResolver(configurationId)` start returning the
  // real `configurations[]` entry as soon as the first stage runs.
  // Mirrors the Python `_ConfigurationResolverHolder` in
  // `agent_shield.adapters._shield`.
  protected _configurationResolverLookup:
    | ((configurationId: string) => LlmConfiguration | null)
    | null = null

  constructor(shieldClass: typeof Shield, bundle: CapabilityBundle | null, path: string) {
    this._shieldClass = shieldClass
    this._bundle = bundle
    this._path = path
  }

  protected _checkConsumed(): void {
    if (this._consumed) {
      throw new Error(
        'ShieldBuilder.build() can only be called once. ' +
          'Call Shield.fromYaml(...) again to create a new builder.',
      )
    }
  }

  // Stable resolver closure handed to adapter `LlmCallerFactory`
  // implementations via `AdapterContext.configurationResolver`. The
  // identity is stable across the builder's lifetime — adapters
  // capture this once at `makeCaller` time and the lookup it
  // dispatches to is populated by `build()` when the runtime exists.
  // Lookup failures (unknown id, post-build runtime errors) are
  // routed through observability so SREs see them as a distinct
  // signal rather than collapsing into "the policy blocked".
  protected _resolveConfiguration(
    configurationId: string | null | undefined,
  ): LlmConfiguration | null {
    if (!configurationId) return null
    const lookup = this._configurationResolverLookup
    if (!lookup) return null
    try {
      return lookup(configurationId)
    } catch (err) {
      const bundleName = this._bundle?.name ?? 'shield_builder'
      _emitAdapterErrorEvent(this._observabilityProviders, bundleName, err)
      return null
    }
  }

  withClient(client: unknown): this {
    this._checkConsumed()
    if (this._bundle?.llmCallerFactory && client) {
      this._llmCaller = this._buildLlmCaller(client, this._bundle)
      this._pendingLlmClient = null
    } else if (client) {
      // No bundle (or no factory) installed yet — stash the client so
      // a subsequent `.with<Framework>()` call can bind it through that
      // bundle's factory. Without this, `.withClient(c).withOpenaiAgents()`
      // and similar orderings would silently drop the client.
      this._pendingLlmClient = client
    }
    return this
  }

  // Builds an LLM caller from a client + bundle, wiring up the adapter
  // context so factory-side errors flow through observability. Shared
  // between `withClient` (immediate bind) and `_rebindPendingLlmClient`
  // (deferred bind after an adapter installer sets `_bundle`).
  protected _buildLlmCaller(
    client: unknown,
    bundle: CapabilityBundle,
  ): ((req: unknown) => unknown) | null {
    if (!bundle.llmCallerFactory) return null
    // The adapter context lets adapters fail-CLOSED on provider
    // outages without conflating the original error with a policy
    // block. Captures the providers array BY REFERENCE so callers
    // that register providers AFTER `.withClient(...)` still see
    // their handlers fire when the LLM caller errors.
    const bundleName = bundle.name
    const providersRef = this._observabilityProviders
    // Bound to `this` so the resolver dispatches through the holder
    // populated by `build()`. Stable identity across the closure's
    // lifetime, so factories can safely cache it.
    const configurationResolver = (
      configurationId: string | null | undefined,
    ): LlmConfiguration | null => this._resolveConfiguration(configurationId)
    const ctx: AdapterContext = {
      recordAdapterError: (error: unknown): void => {
        _emitAdapterErrorEvent(providersRef, bundleName, error)
      },
      configurationResolver,
    }
    return bundle.llmCallerFactory.makeCaller(client, ctx) as (req: unknown) => unknown
  }

  // Called by adapter installers (`withLangchain`, `withOpenaiAgents`,
  // `withAnthropic`) after they set `_bundle`. If a client was stashed
  // via `.withClient(c)` BEFORE the adapter was chosen, this binds it
  // through the freshly-installed bundle's factory so call order is
  // not significant.
  _rebindPendingLlmClient(): void {
    if (!this._pendingLlmClient) return
    if (!this._bundle?.llmCallerFactory) return
    this._llmCaller = this._buildLlmCaller(this._pendingLlmClient, this._bundle)
    this._pendingLlmClient = null
  }

  withObservability(provider: (event: unknown) => void): this {
    this._checkConsumed()
    this._observabilityProviders.push(provider)
    return this
  }

  withMode(mode: ShieldModeValue): this {
    this._checkConsumed()
    this._mode = mode
    return this
  }

  withOnBlock(policy: OnBlockPolicy): this {
    this._checkConsumed()
    this._onBlock = policy
    return this
  }

  withExtension(hook: (builder: unknown) => void): this {
    this._checkConsumed()
    this._extra.push(hook)
    return this
  }

  /**
   * Register a host implementation for `kind: agent` resolvers
   * declared in YAML. The resolver receives a `ResolverRequest` and
   * returns a `ResolverResponse`. Mirrors `Shield::with_agent_resolver`
   * in Rust and `ShieldBuilder.WithAgentResolver` in .NET.
   */
  withAgentResolver(resolver: (req: unknown) => unknown): this {
    this._checkConsumed()
    this._extra.push((rb: unknown) => {
      const builder = rb as { registerAgentResolver(fn: (req: unknown) => unknown): unknown }
      builder.registerAgentResolver(resolver)
    })
    return this
  }

  build(): Shield {
    this._checkConsumed()
    let builder: import('./index.js').RuntimeBuilder
    if (this._yamlChain) {
      builder = _index.RuntimeBuilder.fromYamlChain(this._yamlChain.slice())
    } else {
      builder = _index.RuntimeBuilder.fromYaml(this._path)
    }
    if (this._llmCaller) builder.registerLlmCaller(this._llmCaller as never)
    for (const p of this._observabilityProviders) builder.registerProvider(p as never)
    for (const hook of this._extra) hook(builder)
    const runtime = builder.build()
    // Now that the runtime exists, fill in the LLM configuration
    // resolver so adapter caller closures can look up
    // `configurations[]` entries at call time. MUST happen BEFORE
    // any stage runs, so adapter closures captured during
    // `_buildLlmCaller` (which fires inside `withClient` /
    // `_rebindPendingLlmClient`, both before `build()`) see the live
    // runtime on their first invocation. Mirrors the Python
    // `_ConfigurationResolverHolder.bind` call.
    const runtimeWrapper = runtime as unknown as {
      llmConfiguration?: (id: string) => LlmConfiguration | null
    }
    if (typeof runtimeWrapper.llmConfiguration === 'function') {
      const bound = runtimeWrapper.llmConfiguration.bind(runtime)
      this._configurationResolverLookup = (id: string) => bound(id)
    }
    const shield = new this._shieldClass(runtime as unknown as RuntimeLike, {
      bundle: this._bundle,
      mode: this._mode,
      onBlock: this._onBlock,
      observabilityProviders: this._observabilityProviders.slice(),
    })
    this._consumed = true
    return shield
  }
}
