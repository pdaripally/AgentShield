//! Node.js bindings for the unified-resolver runtime.
//!
//! Every exported class / function is a thin shim over
//! `agent_shield_core::*` — the napi layer only handles JSON
//! marshaling and TSFN bridging for host hooks (`AgentResolver`,
//! `AgentResolver`, `DelegateDispatcher`, `LlmCaller`,
//! `ClassifierCaller`, `ObservabilityProvider`, populator
//! `Extractor`).
//!
//! ## Threading model
//!
//! - The session methods on [`agent_shield_core::GuardrailsSession`]
//!   take `&self` and use interior mutability, so the napi class holds
//!   an `Arc<CoreGuardrailsSession>` with no outer lock.
//! - Async stage methods are declared `pub async fn` so napi-rs returns
//!   Promises naturally and the call runs on a tokio worker. That gives
//!   sync host hooks (which must `block_in_place(block_on(...))` on a
//!   TSFN call) a tokio runtime to land on.
//! - Pure boundary / variable / event ops are `pub fn` (sync) — they
//!   never invoke a host hook.

// agent_shield_core::RuntimeError is intentionally large; the core
// silences this lint at its own crate level, but the size propagates
// into every Result<T, RuntimeError> we surface across napi.
#![allow(clippy::result_large_err)]

use std::collections::HashMap;
use std::pin::Pin;
use std::sync::{Arc, OnceLock};

use napi::bindgen_prelude::*;
use napi::threadsafe_function::{ErrorStrategy, ThreadsafeFunction, ThreadsafeFunctionCallMode};
use napi_derive::napi;
use serde_json::{Map, Value};
use std::sync::Mutex as StdMutex;

use agent_shield_core::guard_policy_runtime::streaming::StreamingTrigger;
use agent_shield_core::{
    AgentResolveRequest, AgentResolver, ClassifierCaller, ClassifierVerdict,
    CompiledPolicy as CoreCompiledPolicy, DelegateDispatcher, DelegateRequest, Extractor,
    GuardrailsConfig as CoreGuardrailsConfig, GuardrailsRuntime as CoreGuardrailsRuntime,
    GuardrailsSession as CoreGuardrailsSession, Layer, LlmCaller, LlmResponse, ObsStage,
    ObservabilityProvider, RequestContext, ResolverDecision, ResolverResponse,
    ResolverRuntimeError, RuntimeBuilder, ShieldLogEvent, StageVerdict, StreamChunkAction,
    StreamChunkResult, StreamingGuard as CoreStreamingGuard, StreamingOptions,
};

/// Shared tokio runtime used to drive TSFN calls from Rust contexts that
/// are NOT already on a tokio worker (e.g. host calls into a sync session
/// method whose internals end up triggering a host hook). One worker is
/// enough — TSFN call_async only needs a runtime to await the host's
/// returned Promise.
fn sync_bridge_runtime() -> &'static tokio::runtime::Runtime {
    static RT: OnceLock<tokio::runtime::Runtime> = OnceLock::new();
    RT.get_or_init(|| {
        tokio::runtime::Builder::new_multi_thread()
            .worker_threads(1)
            .enable_all()
            .thread_name("agent-shield-sync-bridge")
            .build()
            .expect("failed to build agent-shield sync bridge runtime")
    })
}

// ─── JSON helpers ──────────────────────────────────────────────────

fn stage_verdict_to_json(v: &StageVerdict) -> Value {
    let mut m = Map::new();
    m.insert("allowed".into(), Value::Bool(v.allowed));
    m.insert(
        "action".into(),
        v.action.as_ref().map(action_to_json).unwrap_or(Value::Null),
    );
    m.insert(
        "reason".into(),
        v.reason
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    m.insert(
        "policy".into(),
        v.policy
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    m.insert(
        "evaluate_when_index".into(),
        v.evaluate_when_index
            .map(|i| Value::Number(serde_json::Number::from(i as u64)))
            .unwrap_or(Value::Null),
    );
    m.insert(
        "bypassed_by_allowed_when".into(),
        Value::Bool(v.bypassed_by_allowed_when),
    );
    m.insert(
        "redaction".into(),
        v.redaction
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    m.insert(
        "appended".into(),
        v.appended
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    m.insert(
        "prepended".into(),
        v.prepended
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    m.insert(
        "pending_resolution".into(),
        v.pending_resolution
            .as_ref()
            .map(|p| {
                let mut pm = Map::new();
                pm.insert("tool".into(), Value::String(p.tool.clone()));
                pm.insert("variable".into(), Value::String(p.variable.clone()));
                pm.insert(
                    "prompt".into(),
                    p.prompt
                        .as_ref()
                        .map(|s| Value::String(s.clone()))
                        .unwrap_or(Value::Null),
                );
                pm.insert("request_id".into(), Value::String(p.request_id.clone()));
                pm.insert("kind".into(), Value::String(p.kind.into()));
                Value::Object(pm)
            })
            .unwrap_or(Value::Null),
    );
    // §16.0 binding hashes — _camelize at the TS boundary turns these
    // into `invocationHash` / `postValidationInvocationHash`. They are
    // `null` whenever the verdict was not bound to a Stage-3-admitted
    // canonical invocation (synthetic Stage-4 fallback, fail-closed
    // binding deny, etc.).
    m.insert(
        "invocation_hash".into(),
        v.invocation_hash
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    m.insert(
        "post_validation_invocation_hash".into(),
        v.post_validation_invocation_hash
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    Value::Object(m)
}

fn action_to_json(a: &agent_shield_core::Action) -> Value {
    use agent_shield_core::Action::*;
    Value::String(
        match a {
            Block => "block",
            Warn => "warn",
            Redact => "redact",
            Append => "append",
            Prepend => "prepend",
            DeclassifyTo => "declassify_to",
        }
        .to_string(),
    )
}

fn stage_verdict_with_params(verdict: &StageVerdict, params: &Value) -> Value {
    let mut m = Map::new();
    m.insert("verdict".into(), stage_verdict_to_json(verdict));
    m.insert("params".into(), params.clone());
    Value::Object(m)
}

fn stage_verdict_with_response(verdict: &StageVerdict, response: &str) -> Value {
    let mut m = Map::new();
    m.insert("verdict".into(), stage_verdict_to_json(verdict));
    m.insert("response".into(), Value::String(response.to_string()));
    Value::Object(m)
}

fn parse_request_context(raw: Option<Value>) -> RequestContext {
    let v = match raw {
        Some(v) => v,
        None => return RequestContext::default(),
    };
    let obj = match v.as_object() {
        Some(o) => o,
        None => return RequestContext::default(),
    };
    let session_id = obj
        .get("session_id")
        .and_then(|v| v.as_str())
        .map(|s| s.to_string());
    let correlation_id = obj
        .get("correlation_id")
        .and_then(|v| v.as_str())
        .map(|s| s.to_string());
    let mut ctx = match (session_id, correlation_id) {
        (Some(s), Some(c)) => RequestContext::new(s, c),
        (Some(s), None) => {
            let default = RequestContext::default();
            RequestContext::new(s, default.correlation_id)
        }
        (None, Some(c)) => {
            let default = RequestContext::default();
            RequestContext::new(default.session_id, c)
        }
        (None, None) => RequestContext::default(),
    };
    if let Some(u) = obj.get("user_id").and_then(|v| v.as_str()) {
        ctx = ctx.with_user_id(u);
    }
    if let Some(t) = obj.get("tenant_id").and_then(|v| v.as_str()) {
        ctx = ctx.with_tenant_id(t);
    }
    if let Some(ext) = obj.get("extensions").cloned() {
        ctx = ctx.with_extensions(ext);
    }
    ctx
}

#[allow(dead_code)]
fn resolver_decision_str(d: &ResolverDecision) -> &'static str {
    match d {
        ResolverDecision::Allow => "allow",
        ResolverDecision::Deny => "deny",
        ResolverDecision::Cancelled => "cancelled",
    }
}

#[allow(dead_code)]
fn parse_resolver_decision(s: &str) -> Option<ResolverDecision> {
    match s {
        "allow" => Some(ResolverDecision::Allow),
        "deny" => Some(ResolverDecision::Deny),
        "cancelled" | "canceled" => Some(ResolverDecision::Cancelled),
        _ => None,
    }
}

// ─── Wire-shape parsers ───────────────────────────────────────────
//
// Every parser below routes through the canonical
// `agent_shield_core::wire_shapes` API. The Node-side wrappers exist
// only to convert ResolverDecision / Verdict types into the
// engine-internal shapes the rest of this module expects, and to
// preserve the historical `Result<...>` signatures for inline use in
// the `LlmCaller` / `ClassifierCaller` traits below. Hosts MUST NOT
// reimplement the JSON shape grammars — see `wire_shapes.rs` for the
// single source of truth.

fn parse_resolver_response(json: &str) -> ResolverResponse {
    agent_shield_core::parse_resolver_response_json(json)
}

fn parse_llm_response(s: &str) -> std::result::Result<LlmResponse, String> {
    if s.trim().is_empty() {
        return Err("empty llm response".into());
    }
    Ok(agent_shield_core::parse_llm_response_json(s))
}

fn parse_classifier_verdict(s: &str) -> std::result::Result<ClassifierVerdict, String> {
    if s.trim().is_empty() {
        return Err("empty classifier response".into());
    }
    Ok(agent_shield_core::parse_classifier_verdict_json(s))
}

// Resource kind / envelope helpers — the canonical builders live in
// `agent_shield_core::wire_shapes`, but Node has a few internal call
// sites (e.g. observability events) that still want the bare envelope,
// so the local helpers stay as thin shims.
fn resource_kind_str(k: agent_shield_core::ResourceKind) -> &'static str {
    use agent_shield_core::ResourceKind::*;
    match k {
        Tool => "tool",
        Endpoint => "endpoint",
        Agent => "agent",
    }
}

/// Build the `resource: {kind, name, params?}` envelope per spec §11.10.
/// Returns `Value::Null` when the resolver context has no resource
/// attached (e.g. a top-level `validate_input` resolution).
#[allow(dead_code)]
fn resource_envelope(
    kind: Option<agent_shield_core::ResourceKind>,
    name: Option<&String>,
    params: Option<&Value>,
) -> Value {
    let (kind, name) = match (kind, name) {
        (Some(k), Some(n)) => (k, n.clone()),
        _ => return Value::Null,
    };
    let mut m = Map::new();
    m.insert(
        "kind".into(),
        Value::String(resource_kind_str(kind).to_string()),
    );
    m.insert("name".into(), Value::String(name));
    if let Some(p) = params {
        m.insert("params".into(), p.clone());
    }
    Value::Object(m)
}

fn agent_request_to_json(req: &AgentResolveRequest) -> Value {
    agent_shield_core::serialize_agent_request_json(req)
}

fn delegate_request_to_json(req: &DelegateRequest) -> Value {
    agent_shield_core::serialize_delegate_request_json(req)
}

fn variable_state_to_json(st: &agent_shield_core::VariableState) -> Value {
    use agent_shield_core::VarStatus::*;
    let mut m = Map::new();
    m.insert("value".into(), st.value.clone());
    m.insert(
        "status".into(),
        Value::String(
            match st.status {
                Unset => "unset",
                Resolved => "resolved",
                Denied => "denied",
            }
            .to_string(),
        ),
    );
    m.insert("set_at".into(), Value::String(st.set_at.to_rfc3339()));
    m.insert(
        "expires_at".into(),
        st.expires_at
            .map(|t| Value::String(t.to_rfc3339()))
            .unwrap_or(Value::Null),
    );
    m.insert(
        "deny_reason".into(),
        st.deny_reason
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    m.insert(
        "source_kind".into(),
        st.source_kind
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    m.insert(
        "set_by".into(),
        st.set_by
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    Value::Object(m)
}

// ─── TSFN bridge helper ─────────────────────────────────────────────

/// Call a TSFN with a String input and await a JS Promise<String> reply.
///
/// Behaves correctly whether or not the caller is already on a tokio
/// runtime worker:
///   - If a tokio runtime is current, uses `block_in_place(block_on(...))`
///     so we don't deadlock the worker.
///   - Otherwise routes the await through the dedicated
///     [`sync_bridge_runtime`].
fn call_tsfn_blocking(
    tsfn: &ThreadsafeFunction<String, ErrorStrategy::CalleeHandled>,
    arg: String,
) -> std::result::Result<String, String> {
    let fut = async {
        let promise: std::result::Result<Promise<String>, napi::Error> =
            tsfn.call_async::<Promise<String>>(Ok(arg)).await;
        match promise {
            Ok(p) => p.await.map_err(|e| format!("{e}")),
            Err(e) => Err(format!("{e}")),
        }
    };
    if let Ok(handle) = tokio::runtime::Handle::try_current() {
        tokio::task::block_in_place(|| handle.block_on(fut))
    } else {
        sync_bridge_runtime().block_on(fut)
    }
}

// ─── Host-hook trait shims ─────────────────────────────────────────

struct JsAgentResolver(ThreadsafeFunction<String, ErrorStrategy::CalleeHandled>);

impl AgentResolver for JsAgentResolver {
    fn resolve(&self, req: AgentResolveRequest) -> ResolverResponse {
        let json = serde_json::to_string(&agent_request_to_json(&req)).unwrap_or_default();
        match call_tsfn_blocking(&self.0, json) {
            Ok(s) => parse_resolver_response(&s),
            Err(e) => ResolverResponse {
                decision: ResolverDecision::Deny,
                value: None,
                set_variables: HashMap::new(),
                reason: Some(format!("agent resolver error: {e}")),
            },
        }
    }
}

struct JsDelegateDispatcher(ThreadsafeFunction<String, ErrorStrategy::CalleeHandled>);

impl DelegateDispatcher for JsDelegateDispatcher {
    fn dispatch(
        &self,
        req: DelegateRequest,
    ) -> std::result::Result<ResolverResponse, ResolverRuntimeError> {
        let json = serde_json::to_string(&delegate_request_to_json(&req)).unwrap_or_default();
        match call_tsfn_blocking(&self.0, json) {
            Ok(s) => Ok(parse_resolver_response(&s)),
            Err(e) => Ok(ResolverResponse {
                decision: ResolverDecision::Deny,
                value: None,
                set_variables: HashMap::new(),
                reason: Some(format!("delegate dispatcher error: {e}")),
            }),
        }
    }
}

struct JsLlmCaller(ThreadsafeFunction<String, ErrorStrategy::CalleeHandled>);

impl LlmCaller for JsLlmCaller {
    fn call(
        &self,
        configuration_id: Option<&str>,
        prompt: &str,
    ) -> std::result::Result<LlmResponse, String> {
        let payload = serde_json::json!({
            "configuration_id": configuration_id,
            "prompt": prompt,
        });
        let json = serde_json::to_string(&payload).unwrap_or_default();
        let response =
            call_tsfn_blocking(&self.0, json).map_err(|e| format!("llm caller error: {e}"))?;
        parse_llm_response(&response)
    }
}

struct JsClassifierCaller(ThreadsafeFunction<String, ErrorStrategy::CalleeHandled>);

impl ClassifierCaller for JsClassifierCaller {
    fn classify(
        &self,
        configuration_id: &str,
        subject: &str,
    ) -> std::result::Result<ClassifierVerdict, String> {
        let payload = serde_json::json!({
            "configuration_id": configuration_id,
            "subject": subject,
        });
        let json = serde_json::to_string(&payload).unwrap_or_default();
        let response =
            call_tsfn_blocking(&self.0, json).map_err(|e| format!("classifier error: {e}"))?;
        parse_classifier_verdict(&response)
    }
}

/// Bounded queue size for the observability TSFN. Observability is
/// fire-and-forget per spec §17 — when the consumer can't drain events
/// fast enough, the queue caps at this length and further events are
/// dropped (with a one-shot warning to stderr) rather than letting
/// native memory grow unbounded.
const OBSERVABILITY_QUEUE_SIZE: usize = 4096;

struct JsObservabilityProvider {
    tsfn: ThreadsafeFunction<String, ErrorStrategy::CalleeHandled>,
    /// Number of events dropped because the bounded TSFN queue was full.
    /// Incremented atomically so we can emit a single warning the first
    /// time it happens without spamming.
    dropped: std::sync::atomic::AtomicU64,
}

impl ObservabilityProvider for JsObservabilityProvider {
    fn emit(&self, event: ShieldLogEvent) {
        let json = match serde_json::to_string(&event) {
            Ok(s) => s,
            Err(_) => return,
        };
        // Fire-and-forget — observability MUST NOT block the engine.
        // With a bounded queue + NonBlocking, `call` returns
        // `Status::QueueFull` when we'd grow native memory; we drop the
        // event in that case.
        let status = self
            .tsfn
            .call(Ok(json), ThreadsafeFunctionCallMode::NonBlocking);
        if status != napi::Status::Ok {
            let prev = self
                .dropped
                .fetch_add(1, std::sync::atomic::Ordering::Relaxed);
            // Warn once when the first drop happens; subsequent drops
            // are silent so a slow consumer can't generate log spam.
            if prev == 0 {
                eprintln!(
                    "agent-shield: observability TSFN queue full ({} events queued), dropping events — slow JS consumer?",
                    OBSERVABILITY_QUEUE_SIZE
                );
            }
        }
    }
}

struct JsExtractor(ThreadsafeFunction<String, ErrorStrategy::CalleeHandled>);

impl Extractor for JsExtractor {
    fn extract(&self, raw: &Value) -> Option<Value> {
        let json = serde_json::to_string(raw).unwrap_or_else(|_| "null".into());
        match call_tsfn_blocking(&self.0, json) {
            Ok(s) => agent_shield_core::parse_extractor_output_json(&s),
            Err(_) => None,
        }
    }
}

// ─── Builder ────────────────────────────────────────────────────────

/// runtime builder. `from_yaml` / `from_yaml_chain` produce a builder
/// that is mutated through `register_*` methods and finalized via
/// [`Self::build`]. Every register method consumes the inner builder
/// (because the underlying [`agent_shield_core::RuntimeBuilder`]
/// uses move-style chaining) and stashes the new value back in the
/// `Option<...>` slot.
#[napi(js_name = "RuntimeBuilder")]
pub struct JsRuntimeBuilder {
    inner: StdMutex<Option<RuntimeBuilder>>,
}

impl JsRuntimeBuilder {
    fn take(&self) -> Result<RuntimeBuilder> {
        self.inner
            .lock()
            .unwrap()
            .take()
            .ok_or_else(|| Error::from_reason("already consumed"))
    }
    fn put(&self, b: RuntimeBuilder) {
        *self.inner.lock().unwrap() = Some(b);
    }
    fn with<F: FnOnce(RuntimeBuilder) -> RuntimeBuilder>(&self, f: F) -> Result<()> {
        let b = self.take()?;
        self.put(f(b));
        Ok(())
    }
}

fn make_string_tsfn(
    env: &Env,
    callback: JsFunction,
) -> Result<ThreadsafeFunction<String, ErrorStrategy::CalleeHandled>> {
    let mut tsfn = callback.create_threadsafe_function(0, |ctx| Ok(vec![ctx.value]))?;
    tsfn.unref(env)?;
    Ok(tsfn)
}

/// Build a TSFN with a bounded queue, used exclusively for the
/// observability provider . Other request/response hooks need
/// synchronous responses so they keep `max_queue_size = 0` (unbounded);
/// observability is fire-and-forget so it tolerates drops.
fn make_observability_tsfn(
    env: &Env,
    callback: JsFunction,
) -> Result<ThreadsafeFunction<String, ErrorStrategy::CalleeHandled>> {
    let mut tsfn =
        callback.create_threadsafe_function(OBSERVABILITY_QUEUE_SIZE, |ctx| Ok(vec![ctx.value]))?;
    tsfn.unref(env)?;
    Ok(tsfn)
}

#[napi]
impl JsRuntimeBuilder {
    /// Load a single guardrails YAML file (resolves `extends:` per §3.2 / §4.2).
    #[napi(factory)]
    pub fn from_yaml(path: String) -> Result<Self> {
        let inner = RuntimeBuilder::from_yaml(std::path::Path::new(&path))
            .map_err(|e| Error::from_reason(format!("{e}")))?;
        Ok(Self {
            inner: StdMutex::new(Some(inner)),
        })
    }

    /// Load a prepared chain of YAML files (leaf-wins).
    #[napi(factory)]
    pub fn from_yaml_chain(paths: Vec<String>) -> Result<Self> {
        let path_refs: Vec<&std::path::Path> = paths
            .iter()
            .map(|p| std::path::Path::new(p.as_str()))
            .collect();
        let inner = RuntimeBuilder::from_yaml_chain(&path_refs)
            .map_err(|e| Error::from_reason(format!("{e}")))?;
        Ok(Self {
            inner: StdMutex::new(Some(inner)),
        })
    }

    /// Build from a [`CompiledPolicy`] produced by
    /// `GuardrailsConfig.compile()`. Lets the host cache compiled
    /// runtimes by content digest in multi-tenant SaaS deployments.
    #[napi(factory)]
    pub fn from_compiled_policy(compiled: &CompiledPolicy) -> Result<Self> {
        let inner = RuntimeBuilder::from_compiled_policy(compiled.inner.as_ref());
        Ok(Self {
            inner: StdMutex::new(Some(inner)),
        })
    }

    /// Register a `kind: agent` resolver.
    #[napi(ts_args_type = "callback: (err: Error | null, requestJson: string) => Promise<string>")]
    pub fn register_agent_resolver(&self, env: Env, callback: JsFunction) -> Result<()> {
        let tsfn = make_string_tsfn(&env, callback)?;
        let resolver: Arc<dyn AgentResolver> = Arc::new(JsAgentResolver(tsfn));
        self.with(|b| b.register_agent_resolver(resolver))
    }

    /// Register the delegate dispatcher used by `kind: delegate` resolvers.
    #[napi(ts_args_type = "callback: (err: Error | null, requestJson: string) => Promise<string>")]
    pub fn register_delegate_dispatcher(&self, env: Env, callback: JsFunction) -> Result<()> {
        let tsfn = make_string_tsfn(&env, callback)?;
        let dispatcher: Arc<dyn DelegateDispatcher> = Arc::new(JsDelegateDispatcher(tsfn));
        self.with(|b| b.register_delegate_dispatcher(dispatcher))
    }

    /// Register the LLM caller used by `evaluate_when[].llm` detection.
    #[napi(ts_args_type = "callback: (err: Error | null, requestJson: string) => Promise<string>")]
    pub fn register_llm_caller(&self, env: Env, callback: JsFunction) -> Result<()> {
        let tsfn = make_string_tsfn(&env, callback)?;
        let caller: Arc<dyn LlmCaller> = Arc::new(JsLlmCaller(tsfn));
        self.with(|b| b.register_llm_caller(caller))
    }

    /// Register the classifier caller used by `evaluate_when[].classifier`.
    #[napi(ts_args_type = "callback: (err: Error | null, requestJson: string) => Promise<string>")]
    pub fn register_classifier_caller(&self, env: Env, callback: JsFunction) -> Result<()> {
        let tsfn = make_string_tsfn(&env, callback)?;
        let caller: Arc<dyn ClassifierCaller> = Arc::new(JsClassifierCaller(tsfn));
        self.with(|b| b.register_classifier_caller(caller))
    }

    /// Register an observability provider. Multiple providers fan-out;
    /// each call adds another. The callback is fire-and-forget — it
    /// receives a JSON-encoded `ShieldLogEvent` and any return value
    /// is ignored.
    #[napi(ts_args_type = "callback: (err: Error | null, eventJson: string) => void")]
    pub fn register_provider(&self, env: Env, callback: JsFunction) -> Result<()> {
        let tsfn = make_observability_tsfn(&env, callback)?;
        let provider: Arc<dyn ObservabilityProvider> = Arc::new(JsObservabilityProvider {
            tsfn,
            dropped: std::sync::atomic::AtomicU64::new(0),
        });
        self.with(|b| b.register_provider(provider))
    }

    /// Register a populator extractor (matched by reverse-domain name).
    #[napi(
        ts_args_type = "name: string, callback: (err: Error | null, rawJson: string) => Promise<string>"
    )]
    pub fn register_extractor(&self, env: Env, name: String, callback: JsFunction) -> Result<()> {
        let tsfn = make_string_tsfn(&env, callback)?;
        let extractor: Box<dyn Extractor> = Box::new(JsExtractor(tsfn));
        self.with(|b| b.register_extractor(&name, extractor))
    }

    /// Override the per-(turn, variable, tool) retry limit (§11.10.2).
    #[napi]
    pub fn tool_retry_limit(&self, n: u32) -> Result<()> {
        self.with(|b| b.tool_retry_limit(n as usize))
    }

    /// Set the runtime's effective enforcement mode (#14). Accepts
    /// `"active"` or `"shadow"`. The `AGENT_SHIELD_MODE` env var,
    /// when set, takes precedence over this call.
    #[napi]
    pub fn with_mode(&self, mode: String) -> Result<()> {
        let m = agent_shield_core::shield_primitives::RuntimeMode::from_wire_str(&mode)
            .ok_or_else(|| {
                Error::from_reason(format!(
                    "withMode: unknown mode {mode:?} (expected `active` or `shadow`)"
                ))
            })?;
        self.with(|b| b.with_mode(m))
    }

    /// Declare host capability for sub-session IFC scope reset
    /// (proof TC-3 in `docs/information-flow-control-proof.md`).
    /// Required when the merged config declares `ifc.scope:
    /// per_turn` or `per_request`. Hosts that retain LLM context
    /// across these boundaries MUST NOT call this with `true`.
    #[napi]
    pub fn supports_context_reset(&self, supports: bool) -> Result<()> {
        self.with(|b| b.supports_context_reset(supports))
    }

    /// Pin streaming defaults. `trigger`: `0=on_complete`, `1=windowed`,
    /// `2=per_chunk`.
    #[napi]
    pub fn streaming_window(&self, trigger: u8, window_size: u32, overlap: u32) -> Result<()> {
        let trig = match trigger {
            1 => StreamingTrigger::Windowed,
            2 => StreamingTrigger::PerChunk,
            _ => StreamingTrigger::OnComplete,
        };
        let opts = StreamingOptions {
            trigger: trig,
            window_size: window_size as usize,
            overlap: overlap as usize,
        };
        self.with(|b| b.streaming_window(opts))
    }

    /// Consume the builder and produce a runtime.
    #[napi]
    pub fn build(&self) -> Result<GuardrailsRuntime> {
        let inner = self.take()?;
        let runtime = inner
            .build()
            .map_err(|e| Error::from_reason(format!("builder build: {e}")))?;
        Ok(GuardrailsRuntime { inner: runtime })
    }
}

// ─── Runtime ────────────────────────────────────────────────────────

#[napi]
pub struct GuardrailsRuntime {
    inner: Arc<CoreGuardrailsRuntime>,
}

#[napi]
impl GuardrailsRuntime {
    /// Spawn a new per-conversation session bound to the given request
    /// context (§6.3). `requestContext` may be omitted / null — the
    /// runtime auto-generates session/correlation ids.
    #[napi]
    pub fn new_session(&self, request_context: Option<Value>) -> Result<GuardrailsSession> {
        let ctx = parse_request_context(request_context);
        let session = self.inner.new_session(ctx);
        Ok(GuardrailsSession {
            inner: Arc::new(session),
        })
    }

    /// Borrow the merged config metadata name. Full config introspection
    /// is not exposed through napi yet — hosts that need it should use
    /// the YAML they loaded.
    #[napi]
    pub fn metadata_name(&self) -> String {
        self.inner.config().metadata.name.clone()
    }

    /// Look up a `configurations[]` entry by id (§6).
    ///
    /// Returns an object mirroring the `ShieldConfiguration` fields
    /// for the resolved entry (snake_case keys — the JS facade
    /// camelCases them at the `Runtime.llmConfiguration` boundary),
    /// or `null` when no entry matches. Used by adapter LLM-caller
    /// closures to honour the YAML's per-stage `model:` / `provider:`
    /// / `max_tokens:` selection rather than hard-coding a model name.
    /// Mirrors `PyGuardrailsRuntime.llm_configuration` in the Python
    /// SDK so the two surfaces stay byte-equivalent.
    #[napi]
    pub fn llm_configuration(&self, configuration_id: String) -> Value {
        for c in &self.inner.config().configurations {
            if c.id == configuration_id {
                let mut map = Map::new();
                map.insert("id".into(), Value::String(c.id.clone()));
                map.insert(
                    "type".into(),
                    Value::String(c.config_type.as_str().to_string()),
                );
                if let Some(ref m) = c.model {
                    map.insert("model".into(), Value::String(m.clone()));
                }
                if let Some(ref p) = c.provider {
                    map.insert("provider".into(), Value::String(p.clone()));
                }
                if let Some(ref pc) = c.provider_config {
                    map.insert("provider_config".into(), pc.clone());
                }
                if let Some(ref e) = c.endpoint {
                    map.insert("endpoint".into(), Value::String(e.clone()));
                }
                if let Some(t) = c.timeout {
                    map.insert("timeout".into(), Value::Number(t.into()));
                }
                if let Some(mt) = c.max_tokens {
                    map.insert("max_tokens".into(), Value::Number(mt.into()));
                }
                if let Some(ref env) = c.api_key_env {
                    map.insert("api_key_env".into(), Value::String(env.clone()));
                }
                if let Some(ref meta) = c.metadata {
                    map.insert("metadata".into(), meta.clone());
                }
                if let Some(def) = c.default {
                    map.insert("default".into(), Value::Bool(def));
                }
                return Value::Object(map);
            }
        }
        Value::Null
    }
}

// ─── Session ────────────────────────────────────────────────────────

#[napi]
pub struct GuardrailsSession {
    inner: Arc<CoreGuardrailsSession>,
}

#[napi]
impl GuardrailsSession {
    // ── Variable ops ────────────────────────────────────────────────

    /// Set a declared variable. `value` is any JSON value.
    #[napi]
    pub fn set_variable(&self, name: String, value: Value) -> Result<()> {
        self.inner
            .set_variable(&name, value)
            .map_err(|e| Error::from_reason(format!("set_variable: {e}")))
    }

    /// Reset a declared variable to `unset`.
    #[napi]
    pub fn reset_variable(&self, name: String) -> Result<()> {
        self.inner
            .reset_variable(&name)
            .map_err(|e| Error::from_reason(format!("reset_variable: {e}")))
    }

    /// Synchronously invoke the variable's `on_demand_by:` resolver.
    /// Returns the resolved value, or `null` for `Deny` / `Cancelled`
    /// / no resolver. Async because resolver hooks may dispatch
    /// through TSFN.
    #[napi]
    pub async fn resolve_variable(&self, name: String) -> Result<Value> {
        let inner = self.inner.clone();
        let result = tokio::task::spawn_blocking(move || inner.resolve_variable(&name))
            .await
            .map_err(|e| Error::from_reason(format!("resolve_variable: join: {e}")))?
            .map_err(|e| Error::from_reason(format!("resolve_variable: {e}")))?;
        Ok(result.unwrap_or(Value::Null))
    }

    /// Read the cached state envelope for a variable.
    /// Returns `null` if the variable is not declared.
    #[napi]
    pub fn read_variable(&self, name: String) -> Result<Value> {
        match self.inner.read_variable(&name) {
            Some(state) => Ok(variable_state_to_json(&state)),
            None => Ok(Value::Null),
        }
    }

    // ── Event ops ───────────────────────────────────────────────────

    /// Emit a closed-namespace event. `lifetime` is an optional YAML
    /// scalar/map already parsed into JSON shape; `payload` is any JSON.
    #[napi]
    pub fn emit_event(
        &self,
        event_id: String,
        lifetime: Option<Value>,
        payload: Option<Value>,
    ) -> Result<()> {
        let lt = match lifetime {
            None | Some(Value::Null) => None,
            Some(v) => {
                let lt: agent_shield_core::Lifetime = serde_json::from_value(v)
                    .map_err(|e| Error::from_reason(format!("invalid lifetime: {e}")))?;
                Some(lt)
            }
        };
        self.inner
            .emit_event(&event_id, lt, payload)
            .map_err(|e| Error::from_reason(format!("emit_event: {e}")))
    }

    #[napi]
    pub fn clear_event(&self, event_id: String) -> Result<()> {
        self.inner
            .clear_event(&event_id)
            .map_err(|e| Error::from_reason(format!("clear_event: {e}")))
    }

    #[napi]
    pub fn emit_incident(&self, name: String, payload: Option<Value>) -> Result<()> {
        self.inner
            .emit_incident(&name, payload)
            .map_err(|e| Error::from_reason(format!("emit_incident: {e}")))
    }

    // ── Boundary ops ────────────────────────────────────────────────

    #[napi]
    pub fn begin_turn(&self) -> Result<u32> {
        self.inner
            .begin_turn()
            .map(|n| n as u32)
            .map_err(|e| Error::from_reason(format!("begin_turn: {e}")))
    }

    #[napi]
    pub fn end_turn(&self) -> Result<()> {
        self.inner
            .end_turn()
            .map_err(|e| Error::from_reason(format!("end_turn: {e}")))
    }

    #[napi]
    pub fn begin_request(&self) -> Result<u32> {
        self.inner
            .begin_request()
            .map(|n| n as u32)
            .map_err(|e| Error::from_reason(format!("begin_request: {e}")))
    }

    #[napi]
    pub fn end_request(&self) -> Result<()> {
        self.inner
            .end_request()
            .map_err(|e| Error::from_reason(format!("end_request: {e}")))
    }

    /// Latest turn id (or 0 before the first `begin_turn`).
    #[napi(getter)]
    pub fn current_turn_id(&self) -> u32 {
        self.inner.current_turn_id() as u32
    }

    /// Latest request id (or 0 before the first `begin_request`).
    #[napi(getter)]
    pub fn current_request_id(&self) -> u32 {
        self.inner.current_request_id() as u32
    }

    // ── IFC ops (proof: docs/information-flow-control-proof.md) ─────

    /// The session's running IFC exposure as a sorted array of
    /// declared tag names. Empty when IFC is disabled (no `ifc:`
    /// block in the merged config) or when exposure is ⊥.
    #[napi(getter)]
    pub fn current_exposure(&self) -> Vec<String> {
        let exposure = self.inner.current_exposure();
        self.inner
            .runtime()
            .config()
            .ifc
            .universe
            .names_of(exposure)
    }

    // ── Stage validation ────────────────────────────────────────────

    /// Stage 1 — input validation. Returns the StageVerdict.
    #[napi]
    pub async fn validate_input(&self, input: String) -> Result<Value> {
        let inner = self.inner.clone();
        let verdict = tokio::task::spawn_blocking(move || inner.validate_input(&input))
            .await
            .map_err(|e| Error::from_reason(format!("validate_input: join: {e}")))?;
        Ok(stage_verdict_to_json(&verdict))
    }

    /// Stage 3 — tool execution validation (§16). `toolCallId` is
    /// REQUIRED per spec §16.0 and MUST be paired with the same id
    /// passed to the matching Stage 4 `validateToolOutput`. Hosts with
    /// parallel/repeated same-name tool calls MUST pass a distinct id
    /// per call. Returns `{ verdict, params }` where `params` is the
    /// (possibly mutated) parameter shape after Stage 3 transforms.
    #[napi]
    pub async fn validate_tool_call(
        &self,
        tool: String,
        params: Value,
        tool_call_id: String,
    ) -> Result<Value> {
        let inner = self.inner.clone();
        let (verdict, params): (agent_shield_core::StageVerdict, Value) =
            tokio::task::spawn_blocking(move || {
                let mut p = params;
                let v = inner.validate_tool_call(&tool, &mut p, tool_call_id.as_str());
                (v, p)
            })
            .await
            .map_err(|e| Error::from_reason(format!("validate_tool_call: join: {e}")))?;
        Ok(stage_verdict_with_params(&verdict, &params))
    }

    /// Stage 3 — endpoint variant. `toolCallId` is REQUIRED for API
    /// symmetry but currently unused (no Stage 4 for endpoint).
    /// Returns `{ verdict, body }`.
    #[napi]
    pub async fn validate_endpoint_call(
        &self,
        method: String,
        uri: String,
        body: Value,
        tool_call_id: String,
    ) -> Result<Value> {
        let inner = self.inner.clone();
        let (verdict, body): (agent_shield_core::StageVerdict, Value) =
            tokio::task::spawn_blocking(move || {
                let mut b = body;
                let v = inner.validate_endpoint_call(&method, &uri, &mut b, tool_call_id.as_str());
                (v, b)
            })
            .await
            .map_err(|e| Error::from_reason(format!("validate_endpoint_call: join: {e}")))?;
        let mut m = Map::new();
        m.insert("verdict".into(), stage_verdict_to_json(&verdict));
        m.insert("body".into(), body);
        Ok(Value::Object(m))
    }

    /// Stage 3 — agent variant. `toolCallId` is REQUIRED for API
    /// symmetry but currently unused (no Stage 4 for agent). Returns
    /// `{ verdict, params }`.
    #[napi]
    pub async fn validate_agent_call(
        &self,
        agent: String,
        params: Value,
        tool_call_id: String,
    ) -> Result<Value> {
        let inner = self.inner.clone();
        let (verdict, params): (agent_shield_core::StageVerdict, Value) =
            tokio::task::spawn_blocking(move || {
                let mut p = params;
                let v = inner.validate_agent_call(&agent, &mut p, tool_call_id.as_str());
                (v, p)
            })
            .await
            .map_err(|e| Error::from_reason(format!("validate_agent_call: join: {e}")))?;
        Ok(stage_verdict_with_params(&verdict, &params))
    }

    /// Stage 4 — post-tool validation (§17). `toolCallId` MUST match
    /// the id passed to the paired Stage 3 `validateToolCall`. A
    /// non-matching or missing entry fails closed with a `<binding>`
    /// policy verdict. Returns `{ verdict, result }`.
    #[napi]
    pub async fn validate_tool_output(
        &self,
        tool: String,
        result: Value,
        tool_call_id: String,
    ) -> Result<Value> {
        let inner = self.inner.clone();
        let (verdict, result): (agent_shield_core::StageVerdict, Value) =
            tokio::task::spawn_blocking(move || {
                let mut r = result;
                let v = inner.validate_tool_output(&tool, &mut r, tool_call_id.as_str());
                (v, r)
            })
            .await
            .map_err(|e| Error::from_reason(format!("validate_tool_output: join: {e}")))?;
        let mut m = Map::new();
        m.insert("verdict".into(), stage_verdict_to_json(&verdict));
        m.insert("result".into(), result);
        Ok(Value::Object(m))
    }

    /// Stage 5 — output validation. Returns `{ verdict, response }`.
    #[napi]
    pub async fn validate_output(&self, response: String) -> Result<Value> {
        let inner = self.inner.clone();
        let (verdict, response) = tokio::task::spawn_blocking(move || {
            let mut r = response;
            let v = inner.validate_output(&mut r);
            (v, r)
        })
        .await
        .map_err(|e| Error::from_reason(format!("validate_output: join: {e}")))?;
        Ok(stage_verdict_with_response(&verdict, &response))
    }

    // ── Resource cycle helpers ──────────────────────────────────────

    #[napi]
    pub fn record_tool_success(&self, tool: String, result: Value) -> Result<()> {
        self.inner
            .record_tool_success(&tool, &result)
            .map_err(|e| Error::from_reason(format!("record_tool_success: {e}")))
    }

    #[napi]
    pub fn record_tool_failure(&self, tool: String, error: String) -> Result<()> {
        self.inner
            .record_tool_failure(&tool, &error)
            .map_err(|e| Error::from_reason(format!("record_tool_failure: {e}")))
    }

    #[napi]
    pub fn record_endpoint_success(
        &self,
        method: String,
        pattern: String,
        result: Value,
    ) -> Result<()> {
        self.inner
            .record_endpoint_success(&method, &pattern, &result)
            .map_err(|e| Error::from_reason(format!("record_endpoint_success: {e}")))
    }

    #[napi]
    pub fn record_endpoint_failure(
        &self,
        method: String,
        pattern: String,
        error: String,
    ) -> Result<()> {
        self.inner
            .record_endpoint_failure(&method, &pattern, &error)
            .map_err(|e| Error::from_reason(format!("record_endpoint_failure: {e}")))
    }

    #[napi]
    pub fn record_agent_success(&self, agent: String, result: Value) -> Result<()> {
        self.inner
            .record_agent_success(&agent, &result)
            .map_err(|e| Error::from_reason(format!("record_agent_success: {e}")))
    }

    #[napi]
    pub fn record_agent_failure(&self, agent: String, error: String) -> Result<()> {
        self.inner
            .record_agent_failure(&agent, &error)
            .map_err(|e| Error::from_reason(format!("record_agent_failure: {e}")))
    }

    // ── Streaming ───────────────────────────────────────────────────

    /// Construct a streaming guard for Stage 4 (`stage == 4`) or Stage 5
    /// (`stage == 5`).
    #[napi]
    pub fn streaming_session(&self, stage: u8) -> Result<StreamingGuard> {
        let stage = match stage {
            4 => ObsStage::PostTool,
            5 => ObsStage::Output,
            other => {
                return Err(Error::from_reason(format!(
                    "streaming_session: stage must be 4 or 5, got {other}"
                )))
            }
        };
        let guard = self.inner.streaming_session(stage);
        Ok(StreamingGuard {
            inner: Arc::new(StdMutex::new(Some(guard))),
        })
    }
}

// ─── Streaming guard ────────────────────────────────────────────────
//
// The Rust struct name matches the desired JavaScript class name on
// purpose: napi-rs registers wrapper classes under their Rust name
// (the `js_name` attribute is honoured by the codegen for `native.js`
// /`native.d.ts` but the compiled binding registers the Rust ident).
// Keeping the names in sync avoids the `Js*` artefacts leaking into
// the public JS surface.

#[napi]
pub struct StreamingGuard {
    inner: Arc<StdMutex<Option<CoreStreamingGuard>>>,
}

fn stream_chunk_to_json(r: &StreamChunkResult) -> Value {
    let action = match r.action {
        StreamChunkAction::Pass => "pass",
        StreamChunkAction::Replace => "replace",
        StreamChunkAction::Stop => "stop",
    };
    let mut m = Map::new();
    m.insert("action".into(), Value::String(action.to_string()));
    m.insert("payload".into(), Value::String(r.payload.clone()));
    m.insert(
        "reason".into(),
        r.reason
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    Value::Object(m)
}

#[napi]
impl StreamingGuard {
    /// Submit a chunk. Returns `{ action, payload, reason }`.
    #[napi]
    pub async fn add_chunk(&self, chunk: String) -> Result<Value> {
        let guard = self.inner.clone();
        let result = tokio::task::spawn_blocking(move || {
            let mut g = guard.lock().unwrap();
            let inner = g
                .as_mut()
                .ok_or_else(|| "stream already finished".to_string())?;
            Ok::<StreamChunkResult, String>(inner.add_chunk(&chunk))
        })
        .await
        .map_err(|e| Error::from_reason(format!("add_chunk: join: {e}")))?
        .map_err(|e| Error::from_reason(format!("add_chunk: {e}")))?;
        Ok(stream_chunk_to_json(&result))
    }

    /// End the stream. Returns the final `StreamChunkResult`.
    ///
    /// Atomicity: the guard slot is cleared inside the same critical
    /// section as `end_stream()` so concurrent `add_chunk`/`finish`
    /// calls observe an "already finished" error instead of racing
    /// against a half-ended stream.
    #[napi]
    pub async fn finish(&self) -> Result<Value> {
        let guard = self.inner.clone();
        let result = tokio::task::spawn_blocking(move || {
            let mut g = guard.lock().unwrap();
            let inner = g
                .as_mut()
                .ok_or_else(|| "stream already finished".to_string())?;
            let res = inner.end_stream();
            *g = None;
            Ok::<StreamChunkResult, String>(res)
        })
        .await
        .map_err(|e| Error::from_reason(format!("finish: join: {e}")))?
        .map_err(|e| Error::from_reason(format!("finish: {e}")))?;
        Ok(stream_chunk_to_json(&result))
    }

    /// The streaming guard's configured validation cadence:
    /// `'on_complete'` / `'windowed'` / `'per_chunk'`.
    ///
    /// SDK adapters use this to decide whether to forward upstream
    /// chunks to the customer in real time (`per_chunk` / `windowed`)
    /// or to buffer every chunk and emit only the final validated
    /// payload at `finish()` (`on_complete`). Pure read accessor; safe
    /// to call after `finish()` (returns the trigger at construction
    /// time).
    #[napi(getter)]
    pub fn mode(&self) -> String {
        let g = self.inner.lock().unwrap();
        let trig = g
            .as_ref()
            .map(|g| g.mode())
            .unwrap_or(StreamingTrigger::OnComplete);
        match trig {
            StreamingTrigger::OnComplete => "on_complete".into(),
            StreamingTrigger::Windowed => "windowed".into(),
            StreamingTrigger::PerChunk => "per_chunk".into(),
        }
    }
}

// ─── GuardrailsConfig / CompiledPolicy ──────────────────────────────
//
// Thin napi-rs wrappers around `GuardrailsConfig` and `CompiledPolicy`
// from `agent_shield_core::config`. The Node facade in
// `sdk/node/config.js` collapses to a thin handle wrapper around
// these. `GuardrailsConfig` is immutable-by-convention: every fluent
// method clones the inner builder and returns a new instance, so
// napi-rs `&self` callers compose without aliasing or surprise
// mutation.
//
// The Rust struct names match the desired JavaScript class names on
// purpose (`StreamingGuard` / `CompiledPolicy` / `GuardrailsConfig`)
// so napi-rs registers them under the right ident even when other
// `#[napi]` factories reference them via `&Type` parameters.

#[napi]
pub struct GuardrailsConfig {
    inner: CoreGuardrailsConfig,
}

#[napi]
impl GuardrailsConfig {
    /// Start a chain from a single YAML file on disk.
    #[napi(factory)]
    pub fn load(path: String) -> Result<Self> {
        Ok(Self {
            inner: CoreGuardrailsConfig::load(path),
        })
    }

    /// Start a chain from a raw YAML string.
    #[napi(factory, js_name = "fromString")]
    pub fn from_string(yaml: String) -> Result<Self> {
        Ok(Self {
            inner: CoreGuardrailsConfig::from_string(yaml),
        })
    }

    /// Start a chain from a typed value (serialised to YAML at compile
    /// time).
    #[napi(factory, js_name = "fromValue")]
    pub fn from_value(value: Value) -> Result<Self> {
        Ok(Self {
            inner: CoreGuardrailsConfig::from_value(value),
        })
    }

    /// Append another configuration's layers to this chain. Leaf-wins.
    #[napi]
    pub fn extend(&self, other: &GuardrailsConfig) -> Result<GuardrailsConfig> {
        Ok(GuardrailsConfig {
            inner: self.inner.clone().extend(other.inner.clone()),
        })
    }

    /// Append a single path layer.
    #[napi(js_name = "extendPath")]
    pub fn extend_path(&self, path: String) -> Result<GuardrailsConfig> {
        Ok(GuardrailsConfig {
            inner: self.inner.clone().extend_path(path),
        })
    }

    /// Append a single YAML-string layer.
    #[napi(js_name = "extendString")]
    pub fn extend_string(&self, yaml: String) -> Result<GuardrailsConfig> {
        Ok(GuardrailsConfig {
            inner: self.inner.clone().extend_string(yaml),
        })
    }

    /// Append a final value-shaped layer that overrides earlier values.
    #[napi(js_name = "withOverrides")]
    pub fn with_overrides(&self, overrides: Value) -> Result<GuardrailsConfig> {
        Ok(GuardrailsConfig {
            inner: self.inner.clone().with_overrides(overrides),
        })
    }

    /// Append a "policy pack" layer. `pack` may be a string (path to a
    /// YAML file) or an object (typed value layer).
    #[napi(js_name = "withPolicyPack")]
    pub fn with_policy_pack(&self, pack: Value) -> Result<GuardrailsConfig> {
        let layer = match pack {
            Value::String(s) => Layer::Path(std::path::PathBuf::from(s)),
            other => Layer::Object(other),
        };
        Ok(GuardrailsConfig {
            inner: self.inner.clone().with_policy_pack(layer),
        })
    }

    /// Materialise the chain into a [`CompiledPolicy`].
    #[napi]
    pub fn compile(&self) -> Result<CompiledPolicy> {
        let compiled = self
            .inner
            .compile()
            .map_err(|e| Error::from_reason(format!("{e}")))?;
        Ok(CompiledPolicy {
            inner: Arc::new(compiled),
        })
    }

    /// Compute the canonical SHA-256 digest of the chain *without*
    /// validating it. This is the introspection-only twin of
    /// [`compile`](Self::compile): callers can fingerprint a chain
    /// (cache key, log line) without paying the full validation cost
    /// or rejecting partial overlays. The digest is byte-stable with
    /// the digest produced by [`compile`](Self::compile) for the same
    /// content.
    #[napi(getter)]
    pub fn digest(&self) -> Result<String> {
        self.inner
            .digest()
            .map_err(|e| Error::from_reason(format!("{e}")))
    }

    /// Number of layers in the chain.
    #[napi]
    pub fn len(&self) -> u32 {
        self.inner.len() as u32
    }

    /// Whether the chain has no layers.
    #[napi(js_name = "isEmpty")]
    pub fn is_empty(&self) -> bool {
        self.inner.is_empty()
    }
}

#[napi]
pub struct CompiledPolicy {
    inner: Arc<CoreCompiledPolicy>,
}

#[napi]
impl CompiledPolicy {
    /// SHA-256 (lowercase hex) of the canonical JSON encoding of the
    /// merged configuration. Byte-stable across SDKs for the same
    /// content.
    #[napi(getter)]
    pub fn digest(&self) -> String {
        self.inner.digest().to_string()
    }
}

// ─── Module-level helpers (versioning) ──────────────────────────────

#[napi(js_name = "version")]
pub fn version() -> String {
    agent_shield_core::RUNTIME_SPEC_VERSION.to_string()
}

/// Effective runtime mode (#14) as a wire string.
///
/// Exposed as a module-level function so the JS `Runtime.mode()`
/// wrapper can read the underlying core's effective mode without
/// expanding the napi class surface.
#[napi(js_name = "runtimeMode")]
pub fn runtime_mode(runtime: &GuardrailsRuntime) -> String {
    runtime.inner.mode().as_wire_str().to_string()
}

/// Parse a lifetime value (string for the bare keyword form, object
/// for the map / `for:` / `until_event:` forms) and return the
/// canonical representation as a JS value (string or object).
///
/// Routes through `agent_shield_core::lifetime::parse_lifetime`, the
/// single canonical lifetime parser shared by every language SDK.
#[napi(js_name = "parseLifetime")]
pub fn parse_lifetime(value: Value) -> napi::Result<Value> {
    let lt = agent_shield_core::lifetime::parse_lifetime(value)
        .map_err(|e| napi::Error::from_reason(format!("invalid lifetime: {e}")))?;
    serde_json::to_value(&lt)
        .map_err(|e| napi::Error::from_reason(format!("serialize lifetime: {e}")))
}

// ─── Canonical verdict-handling decision (Stage 1/5 + tools) ────────

fn parse_policy_str(s: &str) -> napi::Result<agent_shield_core::OnBlockPolicy> {
    agent_shield_core::OnBlockPolicy::from_wire_str(s)
        .ok_or_else(|| napi::Error::from_reason(format!("unknown on_block policy: {s:?}")))
}

fn parse_mode_str(s: &str) -> napi::Result<agent_shield_core::ShieldMode> {
    agent_shield_core::ShieldMode::from_wire_str(s)
        .ok_or_else(|| napi::Error::from_reason(format!("unknown shield mode: {s:?}")))
}

fn verdict_value_to_core(value: &Value) -> napi::Result<agent_shield_core::StageVerdict> {
    agent_shield_core::stage_verdict_from_wire(value)
        .ok_or_else(|| napi::Error::from_reason("malformed StageVerdict wire shape"))
}

/// Canonical Stage 1 / Stage 5 verdict-handling decision.
///
/// Returns an object: `{action: {kind, value?, message?}, recordBlock,
/// overrideToProceed}`. Note the camelCased keys at the JS boundary —
/// the underlying core uses snake_case but napi auto-camelCases for
/// the JS surface.
///
/// `opts` is `{policy?, mode?}` — both strings, both optional.
#[napi(js_name = "dispatchStageVerdict")]
pub fn napi_dispatch_stage_verdict(verdict: Value, opts: Option<Value>) -> napi::Result<Value> {
    let opts_map = opts
        .as_ref()
        .and_then(|v| v.as_object())
        .cloned()
        .unwrap_or_default();
    let policy = opts_map
        .get("policy")
        .and_then(|v| v.as_str())
        .unwrap_or("return_blocked");
    let mode = opts_map
        .get("mode")
        .and_then(|v| v.as_str())
        .unwrap_or("enforce");
    let v = verdict_value_to_core(&verdict)?;
    let p = parse_policy_str(policy)?;
    let m = parse_mode_str(mode)?;
    let outcome = agent_shield_core::dispatch_stage_verdict(&v, p, m);
    Ok(agent_shield_core::dispatch_outcome_to_wire(&outcome))
}

/// Canonical Stage 2/3/4 (tool-call) verdict-handling decision.
///
/// `stage` is `'call'` (Stage 2/3, pre-execute) or `'output'` (Stage 4,
/// post-execute). Returns `{action, recordFailure, recordSuccess,
/// overrideToProceed}`.
///
/// `opts` is an options object: `{stage?, policy?, mode?}` — all
/// strings, all optional.
#[napi(js_name = "dispatchToolVerdict")]
pub fn napi_dispatch_tool_verdict(
    verdict: Value,
    tool_name: String,
    opts: Option<Value>,
) -> napi::Result<Value> {
    let opts_map = opts
        .as_ref()
        .and_then(|v| v.as_object())
        .cloned()
        .unwrap_or_default();
    let stage = opts_map
        .get("stage")
        .and_then(|v| v.as_str())
        .unwrap_or("output");
    let policy = opts_map
        .get("policy")
        .and_then(|v| v.as_str())
        .unwrap_or("return_blocked");
    let mode = opts_map
        .get("mode")
        .and_then(|v| v.as_str())
        .unwrap_or("enforce");
    let v = verdict_value_to_core(&verdict)?;
    let p = parse_policy_str(policy)?;
    let m = parse_mode_str(mode)?;
    let s = match stage {
        "call" | "Call" | "stage23" | "stage_23" => agent_shield_core::ToolStage::Call,
        "output" | "Output" | "stage4" | "stage_4" => agent_shield_core::ToolStage::Output,
        other => {
            return Err(napi::Error::from_reason(format!(
                "unknown tool stage: {other:?}; expected 'call' or 'output'"
            )))
        }
    };
    let outcome = agent_shield_core::dispatch_tool_verdict(&v, &tool_name, s, p, m);
    Ok(agent_shield_core::tool_dispatch_outcome_to_wire(&outcome))
}

/// Format a verdict as the canonical `[GUARDRAIL ACTION] reason`
/// string. Hands off to `agent_shield_core::format_block_message` so
/// every SDK produces byte-equivalent strings.
#[napi(js_name = "formatBlockMessage")]
pub fn napi_format_block_message(verdict: Value) -> napi::Result<String> {
    let v = verdict_value_to_core(&verdict)?;
    Ok(agent_shield_core::format_block_message(&v))
}

// ─── Hook integration runtime ──────────────────────────────────────
//
// napi-rs surface over `agent_shield_core::integrations::hooks`:
// `HookSessionRegistry`, `HookSession`, `StageDispatcher`. Async
// serialisation of concurrent callbacks for the same session id is
// the integration's responsibility; Node's single-threaded event
// loop is sufficient for most hosts. Wire shapes match the pyo3
// surface so cross-language consumers see identical JSON.

use agent_shield_core::integrations::hooks::{
    ConcurrencyError as CoreConcurrencyError, RegistryOptions as CoreRegistryOptions,
    RequestStateError as CoreRequestStateError, RequestToken as CoreRequestToken,
    SessionLease as CoreSessionLease, SessionRegistry as CoreSessionRegistry,
    StageDispatcher as CoreStageDispatcher,
};
use agent_shield_core::shield_primitives::{
    dispatch_outcome_to_wire as core_dispatch_outcome_to_wire, tool_dispatch_outcome_to_wire,
    OnBlockPolicy as CoreOnBlockPolicy, ShieldMode as CoreShieldMode,
};

fn parse_mode(s: &str) -> napi::Result<CoreShieldMode> {
    CoreShieldMode::from_wire_str(s).ok_or_else(|| {
        napi::Error::from_reason(format!(
            "unknown ShieldMode: {s:?} (expected \"enforce\" or \"monitor\")"
        ))
    })
}

fn parse_policy(s: &str) -> napi::Result<CoreOnBlockPolicy> {
    CoreOnBlockPolicy::from_wire_str(s).ok_or_else(|| {
        napi::Error::from_reason(format!(
            "unknown OnBlockPolicy: {s:?} (expected \"return_blocked\", \"return_verdict\", \"raise\", or \"custom\")"
        ))
    })
}

#[napi(js_name = "HookSessionRegistry")]
pub struct HookSessionRegistry {
    inner: CoreSessionRegistry,
    in_flight_timeout: std::time::Duration,
}

#[napi]
impl HookSessionRegistry {
    /// Construct a registry around an existing `GuardrailsRuntime`.
    /// Options are object-shaped: `{ maxSize?, ttlSeconds?,
    /// inFlightTimeoutSeconds? }`. All optional with the same
    /// defaults as the pyo3 surface (512, 1800, 300).
    #[napi(constructor)]
    pub fn new(runtime: &GuardrailsRuntime, options: Option<Value>) -> napi::Result<Self> {
        let mut max_size = 512usize;
        let mut ttl_seconds = 1800u64;
        let mut in_flight_seconds = 300u64;
        if let Some(Value::Object(obj)) = options {
            if let Some(v) = obj.get("maxSize").and_then(|v| v.as_u64()) {
                max_size = v as usize;
            }
            if let Some(v) = obj.get("ttlSeconds").and_then(|v| v.as_u64()) {
                ttl_seconds = v;
            }
            if let Some(v) = obj.get("inFlightTimeoutSeconds").and_then(|v| v.as_u64()) {
                in_flight_seconds = v;
            }
        }
        let in_flight_timeout = std::time::Duration::from_secs(in_flight_seconds);
        let opts = CoreRegistryOptions {
            max_size,
            ttl: std::time::Duration::from_secs(ttl_seconds),
            in_flight_timeout,
        };
        Ok(Self {
            inner: CoreSessionRegistry::new(runtime.inner.clone(), opts),
            in_flight_timeout,
        })
    }

    /// Acquire a lease on the session keyed by `sessionId`. Returns a
    /// `HookSession` instance that decrements the lease counter on
    /// `release()`. Integrations MUST call `release()` (typically in
    /// a `try / finally`) so eviction can reclaim the entry.
    #[napi]
    pub fn acquire(
        &self,
        session_id: String,
        request_context: Option<Value>,
    ) -> napi::Result<HookSession> {
        let ctx = parse_request_context(request_context);
        let lease = self
            .inner
            .acquire(&session_id, ctx)
            .map_err(|e| napi::Error::from_reason(e.to_string()))?;
        Ok(HookSession {
            inner: StdMutex::new(Some(lease)),
            in_flight_timeout: self.in_flight_timeout,
        })
    }

    #[napi(js_name = "len")]
    pub fn js_len(&self) -> u32 {
        self.inner.len() as u32
    }
}

#[napi(js_name = "HookSession")]
pub struct HookSession {
    inner: StdMutex<Option<CoreSessionLease>>,
    in_flight_timeout: std::time::Duration,
}

impl HookSession {
    fn with_lease<F, R>(&self, f: F) -> napi::Result<R>
    where
        F: FnOnce(&CoreSessionLease) -> napi::Result<R>,
    {
        let guard = self
            .inner
            .lock()
            .map_err(|_| napi::Error::from_reason("HookSession mutex poisoned".to_string()))?;
        match guard.as_ref() {
            Some(lease) => f(lease),
            None => Err(napi::Error::from_reason(
                "HookSession has been released; acquire a fresh lease".to_string(),
            )),
        }
    }
}

#[napi]
impl HookSession {
    #[napi]
    pub fn begin_turn(&self) -> napi::Result<()> {
        self.with_lease(|l| {
            l.begin_turn()
                .map_err(|e| napi::Error::from_reason(e.to_string()))
        })
    }

    #[napi]
    pub fn restart_turn(&self) -> napi::Result<()> {
        self.with_lease(|l| {
            l.restart_turn()
                .map_err(|e| napi::Error::from_reason(e.to_string()))
        })
    }

    #[napi]
    pub fn end_turn(&self) -> napi::Result<()> {
        self.with_lease(|l| {
            l.end_turn()
                .map_err(|e| napi::Error::from_reason(e.to_string()))
        })
    }

    #[napi]
    pub fn turn_is_open(&self) -> napi::Result<bool> {
        self.with_lease(|l| Ok(l.turn_is_open()))
    }

    /// Begin a request scope. Returns a numeric token the caller
    /// MUST present to `endRequest` when the logical request
    /// completes. JS `number` is precise up to 2^53; the underlying
    /// counter is u64 but per-session lifetime makes overflow
    /// practically unreachable.
    #[napi]
    pub fn begin_request(&self) -> napi::Result<f64> {
        self.with_lease(|l| {
            l.begin_request(Some(self.in_flight_timeout))
                .map(|t| t.0 as f64)
                .map_err(|e| match e {
                    CoreConcurrencyError::AlreadyInFlight { age } => {
                        napi::Error::from_reason(format!(
                            "another request is in flight for this session (age={:?})",
                            age
                        ))
                    }
                    CoreConcurrencyError::SessionError(msg) => napi::Error::from_reason(msg),
                })
        })
    }

    /// Retire a request token. Returns "ok" | "mismatch" |
    /// "no_request_open" rather than throwing — the failure-hook
    /// double-call path relies on no_request_open being safe.
    #[napi]
    pub fn end_request(&self, token: f64) -> napi::Result<String> {
        let tok = CoreRequestToken(token as u64);
        self.with_lease(|l| {
            Ok(match l.end_request(tok) {
                Ok(()) => "ok".to_string(),
                Err(CoreRequestStateError::Mismatch) => "mismatch".to_string(),
                Err(CoreRequestStateError::NoRequestOpen) => "no_request_open".to_string(),
            })
        })
    }

    /// Retire whatever request is currently open without needing the
    /// token. Convenience for hosts that don't want to plumb the
    /// token across hook callbacks.
    #[napi]
    pub fn end_current_request(&self) -> napi::Result<String> {
        self.with_lease(|l| {
            Ok(match l.end_current_request() {
                Ok(()) => "ok".to_string(),
                Err(CoreRequestStateError::NoRequestOpen) => "no_request_open".to_string(),
                Err(CoreRequestStateError::Mismatch) => "mismatch".to_string(),
            })
        })
    }

    #[napi]
    pub fn request_is_open(&self) -> napi::Result<bool> {
        self.with_lease(|l| Ok(l.request_is_open()))
    }

    #[napi]
    pub fn turn_kv_set(&self, key: String, value: Value) -> napi::Result<Value> {
        self.with_lease(|l| Ok(l.turn_kv_set(&key, value).unwrap_or(Value::Null)))
    }

    #[napi]
    pub fn turn_kv_get(&self, key: String) -> napi::Result<Value> {
        self.with_lease(|l| Ok(l.turn_kv_get(&key).unwrap_or(Value::Null)))
    }

    #[napi]
    pub fn turn_kv_remove(&self, key: String) -> napi::Result<Value> {
        self.with_lease(|l| Ok(l.turn_kv_remove(&key).unwrap_or(Value::Null)))
    }

    #[napi]
    pub fn turn_kv_keys(&self) -> napi::Result<Vec<String>> {
        self.with_lease(|l| Ok(l.turn_kv_keys()))
    }

    #[napi]
    pub fn record_tool_success(&self, tool_name: String, result: Value) -> napi::Result<()> {
        self.with_lease(|l| {
            l.record_tool_success(&tool_name, &result)
                .map_err(|e| napi::Error::from_reason(e.to_string()))
        })
    }

    #[napi]
    pub fn record_tool_failure(&self, tool_name: String, error: String) -> napi::Result<()> {
        self.with_lease(|l| {
            l.record_tool_failure(&tool_name, &error)
                .map_err(|e| napi::Error::from_reason(e.to_string()))
        })
    }

    /// Drop the lease. Idempotent — safe to call multiple times.
    #[napi]
    pub fn release(&self) {
        if let Ok(mut g) = self.inner.lock() {
            let _ = g.take();
        }
    }
}

#[napi(js_name = "StageDispatcher")]
pub struct StageDispatcher {
    inner: CoreStageDispatcher,
}

#[napi]
impl StageDispatcher {
    #[napi(constructor)]
    #[allow(clippy::new_without_default)]
    pub fn new() -> Self {
        Self {
            inner: CoreStageDispatcher,
        }
    }

    /// Stage 1.
    #[napi]
    pub fn validate_input(
        &self,
        session: &HookSession,
        user_input: String,
        mode: Option<String>,
        policy: Option<String>,
    ) -> napi::Result<Value> {
        let m = parse_mode(mode.as_deref().unwrap_or("enforce"))?;
        let p = parse_policy(policy.as_deref().unwrap_or("return_blocked"))?;
        let result = session.with_lease(|lease| {
            Ok(self
                .inner
                .validate_input(lease.session(), &user_input, m, p))
        })?;
        let mut out = Map::new();
        out.insert(
            "dispatch".into(),
            core_dispatch_outcome_to_wire(&result.dispatch),
        );
        Ok(Value::Object(out))
    }

    /// Stages 2 + 3.
    #[napi]
    pub fn validate_tool_call(
        &self,
        session: &HookSession,
        tool_name: String,
        params: Value,
        tool_call_id: String,
        mode: Option<String>,
        policy: Option<String>,
    ) -> napi::Result<Value> {
        let m = parse_mode(mode.as_deref().unwrap_or("enforce"))?;
        let p = parse_policy(policy.as_deref().unwrap_or("return_blocked"))?;
        let result = session.with_lease(|lease| {
            Ok(self.inner.validate_tool_call(
                lease.session(),
                &tool_name,
                params,
                &tool_call_id,
                m,
                p,
            ))
        })?;
        let mut out = Map::new();
        out.insert(
            "dispatch".into(),
            tool_dispatch_outcome_to_wire(&result.dispatch),
        );
        out.insert("effective_params".into(), result.effective_params);
        Ok(Value::Object(out))
    }

    /// Stage 4.
    #[napi]
    pub fn validate_tool_output(
        &self,
        session: &HookSession,
        tool_name: String,
        output: Value,
        tool_call_id: String,
        mode: Option<String>,
        policy: Option<String>,
    ) -> napi::Result<Value> {
        let m = parse_mode(mode.as_deref().unwrap_or("enforce"))?;
        let p = parse_policy(policy.as_deref().unwrap_or("return_blocked"))?;
        let result = session.with_lease(|lease| {
            Ok(self.inner.validate_tool_output(
                lease.session(),
                &tool_name,
                output,
                &tool_call_id,
                m,
                p,
            ))
        })?;
        let mut out = Map::new();
        out.insert(
            "dispatch".into(),
            tool_dispatch_outcome_to_wire(&result.dispatch),
        );
        out.insert("effective_output".into(), result.effective_output);
        Ok(Value::Object(out))
    }

    /// Stage 5.
    #[napi]
    pub fn validate_output(
        &self,
        session: &HookSession,
        content: String,
        mode: Option<String>,
        policy: Option<String>,
    ) -> napi::Result<Value> {
        let m = parse_mode(mode.as_deref().unwrap_or("enforce"))?;
        let p = parse_policy(policy.as_deref().unwrap_or("return_blocked"))?;
        let mut buf = content;
        let result = session
            .with_lease(|lease| Ok(self.inner.validate_output(lease.session(), &mut buf, m, p)))?;
        let mut out = Map::new();
        out.insert(
            "dispatch".into(),
            core_dispatch_outcome_to_wire(&result.dispatch),
        );
        Ok(Value::Object(out))
    }
}

// Mark types we import-but-don't-use-publicly so dead-code lints stay clean.
#[allow(dead_code, clippy::let_underscore_future)]
fn _silence_unused() -> impl Sized {
    let _: Pin<Box<dyn std::future::Future<Output = ()> + Send>> = Box::pin(async {});
}
