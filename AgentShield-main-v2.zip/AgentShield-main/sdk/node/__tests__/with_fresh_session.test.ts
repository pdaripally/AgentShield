// Tests for `Shield#withFreshSession` and `GuardedRunner#withFreshSession`.
//
// Verifies the post-build immutability contract documented in
// `spec/SPECIFICATION.md`:
//
//   1. `withFreshSession()` returns a NEW instance (different object
//      identity from the original).
//   2. The original Shield's runner state is unchanged (runners
//      previously spawned from it are preserved).
//   3. The new Shield has a clean slate (no inherited runners, fresh
//      session for runners).
//   4. Both Shields point to the same `runtime` reference.
//   5. `reset()` still works in-place but emits a one-shot
//      deprecation warning, mirroring the pre-1.0 behaviour for
//      back-compat.
//
// Mirrors the Rust `with_fresh_session.rs`, .NET `WithFreshSessionTests.cs`,
// and Python `test_with_fresh_session.py` suites so the four SDKs
// stay in lockstep.

import { describe, it, expect, beforeEach } from 'vitest'
import * as path from 'path'

import { Shield, GuardedRunner, ShieldMode, RuntimeBuilder } from '../index.js'

const FIXTURES = path.resolve(__dirname, '../../../tests/fixtures/smoke')
const MINIMAL = path.join(FIXTURES, 'minimal.guardrails.yaml')
const INPUT_REDACT = path.join(FIXTURES, 'input-redact.guardrails.yaml')

describe('Shield.withFreshSession', () => {
  beforeEach(() => {
    // The legacy `reset()` deprecation flags lived on the shield
    // module itself; with the TS port the legacy flag is no longer
    // exposed, but this hook is preserved as a no-op so that the
    // tests below still exercise the canonical `withFreshSession()`
    // path the way they always did.
  })

  it('returns a NEW Shield instance', () => {
    const runtime = RuntimeBuilder.fromYaml(MINIMAL).build()
    const original = new Shield(runtime)

    const forked = original.withFreshSession()

    expect(forked).not.toBe(original) // (1)
    expect(forked.runtime).toBe(original.runtime) // (4)
  })

  it('preserves config (mode, on-block, bundle) on the fork', () => {
    const runtime = RuntimeBuilder.fromYaml(MINIMAL).build()
    const original = new Shield(runtime, {
      mode: ShieldMode.MONITOR,
      onBlock: 'raise',
    })

    const forked = original.withFreshSession()

    expect(forked.mode).toBe(ShieldMode.MONITOR)
    expect(forked._onBlock).toBe('raise')
    expect(forked._bundle).toBe(original._bundle)
  })

  it('does NOT mutate the original Shield', () => {
    const runtime = RuntimeBuilder.fromYaml(MINIMAL).build()
    const original = new Shield(runtime)
    const originalRunners = original._guardedRunners
    const originalRuntimeRef = original.runtime

    original.withFreshSession()

    expect(original._guardedRunners).toBe(originalRunners) // (2)
    expect(original.runtime).toBe(originalRuntimeRef)
  })

  it('starts the fork with an EMPTY runner set', () => {
    const runtime = RuntimeBuilder.fromYaml(MINIMAL).build()
    const original = new Shield(runtime)
    // Mutate the original's runner set directly — we don't have a
    // bundle to call `guard()` against in this minimal smoke test.
    original._guardedRunners.add({ fake: 'runner' })

    const forked = original.withFreshSession()

    expect(forked._guardedRunners.size).toBe(0) // (3)
    expect(original._guardedRunners.size).toBe(1) // original untouched
  })

  it('GuardedRunner.withFreshSession returns a NEW runner with a fresh session', () => {
    const runtime = RuntimeBuilder.fromYaml(MINIMAL).build()
    const stubBoundary = {
      run: async () => ({}),
      extractOutput: () => '',
      applyRedaction: (r: unknown) => r,
      makeBlocked: (m: string) => m,
    }
    const original = new GuardedRunner(runtime, {}, stubBoundary, null)
    const originalSession = original._session

    const forked = original.withFreshSession()

    expect(forked).not.toBe(original) // (1)
    expect(forked._session).not.toBe(original._session) // (3)
    expect(forked._runtime).toBe(original._runtime) // (4)
    // (2) Original's session reference is unchanged.
    expect(original._session).toBe(originalSession)
  })

  it('GuardedRunner.run passes Stage 1 mutated input to the boundary', async () => {
    const runtime = RuntimeBuilder.fromYaml(INPUT_REDACT).build()
    let seenInput = ''
    const stubBoundary = {
      run: async (_agent: unknown, input: string | undefined) => {
        seenInput = input ?? ''
        return {}
      },
      extractOutput: () => '',
      applyRedaction: (r: unknown) => r,
      makeBlocked: (m: string) => m,
    }
    const runner = new GuardedRunner(runtime, {}, stubBoundary, null)

    await runner.run('hello SECRET-ABCD')

    expect(seenInput).toBe('hello [INPUT REDACTED]')
  })
})
