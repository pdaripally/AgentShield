import { describe, expect, it } from 'vitest'

import { RuntimeBuilder } from '../../../index.js'
import type { ShieldLogEvent } from '../../../index.js'

const FIXTURE_YAML = `
metadata:
  name: "node-mcp-bypass-paths"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Guard MCP tool calls."]
  forbidden: ["Leak secrets."]
resources:
  tools:
    - name: "mcp_lookup"
      description: "Lookup data."
      permission: "read_only"
`

async function makeSession() {
  const captured: ShieldLogEvent[] = []
  const rt = RuntimeBuilder.fromYamlStrings([FIXTURE_YAML])
    .registerProvider((ev) => captured.push(ev as ShieldLogEvent))
    .build()
  const sess = rt.newSession()
  await sess.beginTurn()
  return { sess, captured }
}

describe('MCP adapter bypass paths', () => {
  it('guarded tool call produces invocationHash', async () => {
    const { sess } = await makeSession()

    const call = await sess.validateToolCall('mcp_lookup', { query: 'hello' }, 'mcp_call_001')
    expect(call.verdict.allowed).toBe(true)
    expect(call.verdict.invocationHash).toBeTruthy()

    const out = await sess.validateToolOutput('mcp_lookup', { result: 'ok' }, 'mcp_call_001')
    expect(out.verdict.allowed).toBe(true)
    expect(out.verdict.invocationHash).toBeTruthy()
  })

  it('direct Stage-4 without Stage 3 fails closed with no invocationHash', async () => {
    const { sess } = await makeSession()
    const out = await sess.validateToolOutput('mcp_lookup', { result: 'ok' }, 'mcp_unbound_001')
    expect(out.verdict.allowed).toBe(false)
    expect(out.verdict.policy).toBe('<binding>')
    expect(out.verdict.invocationHash).toBeFalsy()
  })

  it('raw dispatch without Stage 3 emits incident.unguarded_tool_dispatch', async () => {
    const { sess, captured } = await makeSession()
    await sess.validateToolOutput('mcp_lookup', { result: 'ok' }, 'mcp_raw_dispatch')
    await new Promise((r) => setTimeout(r, 50))

    const incidents = captured.filter(
      (e) => e.eventType === 'incident_emitted' && e.eventId === 'incident.unguarded_tool_dispatch',
    )
    expect(incidents.length).toBeGreaterThan(0)
  })

  it('null params normalize to {} and produce invocationHash', async () => {
    const { sess } = await makeSession()
    const outcome = await sess.validateToolCall('mcp_lookup', null as any, 'mcp_malformed_001')
    expect(outcome.verdict.allowed).toBe(true)
    expect(outcome.verdict.invocationHash).toBeTruthy()
  })

  it('non-string toolCallId is rejected at the API boundary', async () => {
    const { sess } = await makeSession()
    await expect(sess.validateToolCall('mcp_lookup', {}, null as any)).rejects.toThrow()
  })
})
