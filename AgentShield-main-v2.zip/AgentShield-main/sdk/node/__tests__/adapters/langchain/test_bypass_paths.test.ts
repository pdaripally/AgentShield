/**
 * Bypass-path tests for the LangChain adapter.
 *
 * Mirrors the Python adapter coverage for guarded calls, missing
 * bindings, unguarded dispatch incidents, parameter normalization, and
 * streaming blocks.
 */
import { describe, it, expect } from 'vitest'
import { RuntimeBuilder } from '../../../index.js'
import type { ShieldLogEvent } from '../../../index.js'

const FIXTURE_YAML = `
metadata:
  name: "langchain-node-bypass-paths"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Guard LangChain tool calls."]
  forbidden: ["Leak secrets."]
resources:
  tools:
    - name: "search"
      description: "Web search."
      permission: "read_only"
`

const BLOCK_OUTPUT_YAML = `
metadata:
  name: "langchain-node-block-output"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Block confidential output."]
  forbidden: ["Leak secrets."]
output_validation:
  guard_policies:
    - name: "block-confidential"
      evaluate_when:
        - pattern: "CONFIDENTIAL"
          reason: "Output contains confidential marker."
      action: block
`

async function makeSession(yaml = FIXTURE_YAML) {
  const captured: ShieldLogEvent[] = []
  const rt = RuntimeBuilder.fromYamlStrings([yaml])
    .registerProvider((ev) => captured.push(ev as ShieldLogEvent))
    .build()
  const sess = rt.newSession()
  await sess.beginTurn()
  return { sess, captured }
}

// ─── 1. Guarded path: Stage-3 + Stage-4 invocationHash ────────────

describe('LangChain adapter bypass paths', () => {
  it('guarded tool call produces invocationHash', async () => {
    const { sess } = await makeSession()

    const call = await sess.validateToolCall('search', { query: 'hello' }, 'lc_call_001')
    expect(call.verdict.allowed).toBe(true)
    expect(call.verdict.invocationHash).toBeTruthy()

    const out = await sess.validateToolOutput('search', { results: ['r1'] }, 'lc_call_001')
    expect(out.verdict.allowed).toBe(true)
    expect(out.verdict.invocationHash).toBeTruthy()
  })

  // ─── 2. Direct Stage-4 without Stage 3: fails closed ─────────────

  it('direct Stage-4 without Stage 3 fails closed with no invocationHash', async () => {
    const { sess } = await makeSession()

    const out = await sess.validateToolOutput(
      'search',
      { results: [] },
      'never_validated_id',
    )
    expect(out.verdict.allowed).toBe(false)
    expect(out.verdict.policy).toBe('<binding>')
    expect(out.verdict.invocationHash).toBeFalsy()
  })

  // ─── 3. Raw tool dispatch: incident.unguarded_tool_dispatch ────────

  it('raw dispatch without Stage 3 emits incident.unguarded_tool_dispatch', async () => {
    const { sess, captured } = await makeSession()

    await sess.validateToolOutput('search', { results: [] }, 'bypass_lc_001')

    // Give the TSFN callback a tick to flush.
    await new Promise((r) => setTimeout(r, 50))

    const incidents = captured.filter(
      (e) =>
        e.eventType === 'incident_emitted' && e.eventId === 'incident.unguarded_tool_dispatch',
    )
    expect(incidents.length).toBeGreaterThan(0)
  })

  // ─── 4. Malformed params normalize safely ─────────────────────────

  it('null params normalize to {} and produce invocationHash', async () => {
    const { sess } = await makeSession()
    // Pass null — the SDK coerces to {} per the wire-shape contract.
    const outcome = await sess.validateToolCall('search', null as any, 'lc_malformed_001')
    expect(outcome.verdict.allowed).toBe(true)
    expect(outcome.verdict.invocationHash).toBeTruthy()
  })

  it('non-string toolCallId is rejected at the API boundary', async () => {
    const { sess } = await makeSession()
    await expect(
      sess.validateToolCall('search', {}, 42 as any),
    ).rejects.toThrow()
  })

  // ─── 5. Streaming Stage-5 deny: incident.stream_aborted ───────────

  it('streaming Stage-5 deny emits incident.stream_aborted', async () => {
    const { sess, captured } = await makeSession(BLOCK_OUTPUT_YAML)

    const guard = sess.streamingSession('output')
    await guard.push('This output is ')
    const result = await guard.finish()
    // The policy fires at finish() because on_complete mode buffers all chunks.

    // Wait for TSFN callback.
    await new Promise((r) => setTimeout(r, 50))

    // finish() with action='stop' OR we check after push with pattern match
    // Both push() and finish() can emit; collect all incidents.
    const incidents = captured.filter(
      (e) => e.eventType === 'incident_emitted' && e.eventId === 'incident.stream_aborted',
    )

    // If the block fires, the incident MUST have been emitted.
    if (result.action === 'stop') {
      expect(incidents.length).toBeGreaterThan(0)
    } else {
      // Try with a chunk that contains the pattern directly.
      const guard2 = sess.streamingSession('output')
      await guard2.push('Marked CONFIDENTIAL stop here.')
      const r2 = await guard2.finish()
      await new Promise((r) => setTimeout(r, 50))
      const incidents2 = captured.filter(
        (e) => e.eventType === 'incident_emitted' && e.eventId === 'incident.stream_aborted',
      )
      expect(r2.action).toBe('stop')
      expect(incidents2.length).toBeGreaterThan(0)
    }
  })
})
