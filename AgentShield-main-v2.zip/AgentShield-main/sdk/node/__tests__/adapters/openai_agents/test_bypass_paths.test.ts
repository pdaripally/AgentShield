/**
 * Bypass-path tests for the OpenAI Agents SDK adapter.
 *
 * Covers guarded calls, missing bindings, unguarded dispatch incidents,
 * parameter normalization, and streaming blocks.
 */
import { describe, it, expect } from 'vitest'
import { RuntimeBuilder } from '../../../index.js'
import type { ShieldLogEvent } from '../../../index.js'

const FIXTURE_YAML = `
metadata:
  name: "openai-agents-node-bypass"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Guard OpenAI Agents SDK tool calls."]
  forbidden: ["Leak secrets."]
resources:
  tools:
    - name: "web_search"
      description: "Search the web."
      permission: "read_only"
`

const BLOCK_OUTPUT_YAML = `
metadata:
  name: "openai-agents-node-block"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Block confidential output."]
  forbidden: ["Leak secrets."]
output_validation:
  guard_policies:
    - name: "block-confidential"
      evaluate_when:
        - pattern: "CONFIDENTIAL"
          reason: "Output contains confidential marker."
      action: block
`

async function makeSession(yaml = FIXTURE_YAML) {
  const captured: ShieldLogEvent[] = []
  const rt = RuntimeBuilder.fromYamlStrings([yaml])
    .registerProvider((ev) => captured.push(ev as ShieldLogEvent))
    .build()
  const sess = rt.newSession()
  await sess.beginTurn()
  return { sess, captured }
}

async function waitForIncident(
  captured: ShieldLogEvent[],
  eventId: string,
  timeoutMs = 2000,
  pollMs = 10,
): Promise<ShieldLogEvent> {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    const incident = captured.find(
      (e) => e.eventType === 'incident_emitted' && e.eventId === eventId,
    )
    if (incident) return incident
    await new Promise((resolve) => setTimeout(resolve, pollMs))
  }
  throw new Error(`timed out after ${timeoutMs}ms waiting for ${eventId}`)
}

describe('OpenAI Agents adapter bypass paths', () => {
  it('guarded tool call produces invocationHash', async () => {
    const { sess } = await makeSession()
    const call = await sess.validateToolCall('web_search', { query: 'test' }, 'oai_call_001')
    expect(call.verdict.allowed).toBe(true)
    expect(call.verdict.invocationHash).toBeTruthy()

    const out = await sess.validateToolOutput('web_search', { results: ['r1'] }, 'oai_call_001')
    expect(out.verdict.allowed).toBe(true)
    expect(out.verdict.invocationHash).toBeTruthy()
  })

  it('direct Stage-4 without Stage 3 fails closed with no invocationHash', async () => {
    const { sess } = await makeSession()
    const out = await sess.validateToolOutput(
      'web_search',
      { results: [] },
      'unregistered_oai_call',
    )
    expect(out.verdict.allowed).toBe(false)
    expect(out.verdict.policy).toBe('<binding>')
    expect(out.verdict.invocationHash).toBeFalsy()
  })

  it('raw dispatch without Stage 3 emits incident.unguarded_tool_dispatch', async () => {
    const { sess, captured } = await makeSession()
    await sess.validateToolOutput('web_search', { results: [] }, 'bypass_oai_001')
    const incident = await waitForIncident(captured, 'incident.unguarded_tool_dispatch')
    expect(incident).toBeTruthy()
  })

  it('null params normalize to {} and produce invocationHash', async () => {
    const { sess } = await makeSession()
    const outcome = await sess.validateToolCall('web_search', null as any, 'oai_malformed_001')
    expect(outcome.verdict.allowed).toBe(true)
    expect(outcome.verdict.invocationHash).toBeTruthy()
  })

  it('streaming Stage-5 deny emits incident.stream_aborted', async () => {
    const { sess, captured } = await makeSession(BLOCK_OUTPUT_YAML)
    const guard = sess.streamingSession('output')
    await guard.push('Partial text then CONFIDENTIAL marker.')
    const result = await guard.finish()
    expect(result.action).toBe('stop')
    const incident = await waitForIncident(captured, 'incident.stream_aborted')
    expect(incident).toBeTruthy()
  })
})
