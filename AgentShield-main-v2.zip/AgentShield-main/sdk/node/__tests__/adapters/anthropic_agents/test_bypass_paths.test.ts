/**
 * Bypass-path tests for the Anthropic Agents SDK adapter.
 *
 * Covers guarded calls, missing bindings, unguarded dispatch incidents,
 * parameter normalization, and streaming blocks.
 */
import { describe, it, expect } from 'vitest'
import { RuntimeBuilder } from '../../../index.js'
import type { ShieldLogEvent } from '../../../index.js'

const FIXTURE_YAML = `
metadata:
  name: "anthropic-node-bypass"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Guard Anthropic Agents SDK tool calls."]
  forbidden: ["Leak secrets."]
resources:
  tools:
    - name: "calculator"
      description: "Performs arithmetic."
      permission: "read_only"
`

const BLOCK_OUTPUT_YAML = `
metadata:
  name: "anthropic-node-block"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Block confidential output."]
  forbidden: ["Leak secrets."]
output_validation:
  guard_policies:
    - name: "block-confidential"
      evaluate_when:
        - pattern: "CONFIDENTIAL"
          reason: "Output contains confidential marker."
      action: block
`

async function makeSession(yaml = FIXTURE_YAML) {
  const captured: ShieldLogEvent[] = []
  const rt = RuntimeBuilder.fromYamlStrings([yaml])
    .registerProvider((ev) => captured.push(ev as ShieldLogEvent))
    .build()
  const sess = rt.newSession()
  await sess.beginTurn()
  return { sess, captured }
}

describe('Anthropic Agents adapter bypass paths', () => {
  it('guarded tool call produces invocationHash', async () => {
    const { sess } = await makeSession()
    const call = await sess.validateToolCall(
      'calculator',
      { op: 'add', a: 1, b: 2 },
      'ant_call_001',
    )
    expect(call.verdict.allowed).toBe(true)
    expect(call.verdict.invocationHash).toBeTruthy()

    const out = await sess.validateToolOutput('calculator', { result: 3 }, 'ant_call_001')
    expect(out.verdict.allowed).toBe(true)
    expect(out.verdict.invocationHash).toBeTruthy()
  })

  it('direct Stage-4 without Stage 3 fails closed with no invocationHash', async () => {
    const { sess } = await makeSession()
    const out = await sess.validateToolOutput(
      'calculator',
      { result: 42 },
      'never_admitted_call',
    )
    expect(out.verdict.allowed).toBe(false)
    expect(out.verdict.policy).toBe('<binding>')
    expect(out.verdict.invocationHash).toBeFalsy()
  })

  it('raw dispatch without Stage 3 emits incident.unguarded_tool_dispatch', async () => {
    const { sess, captured } = await makeSession()
    await sess.validateToolOutput('calculator', { result: 0 }, 'raw_ant_dispatch')
    await new Promise((r) => setTimeout(r, 50))
    const incidents = captured.filter(
      (e) =>
        e.eventType === 'incident_emitted' && e.eventId === 'incident.unguarded_tool_dispatch',
    )
    expect(incidents.length).toBeGreaterThan(0)
  })

  it('null params normalize to {} and produce invocationHash', async () => {
    const { sess } = await makeSession()
    const outcome = await sess.validateToolCall('calculator', null as any, 'ant_malformed_001')
    expect(outcome.verdict.allowed).toBe(true)
    expect(outcome.verdict.invocationHash).toBeTruthy()
  })

  it('streaming Stage-5 deny emits incident.stream_aborted', async () => {
    const { sess, captured } = await makeSession(BLOCK_OUTPUT_YAML)
    const guard = sess.streamingSession('output')
    await guard.push('The secret is: ')
    await guard.push('CONFIDENTIAL-TOKEN-XYZ here.')
    const result = await guard.finish()
    await new Promise((r) => setTimeout(r, 50))
    // The policy fires at finish() in on_complete mode; result.action='stop'.
    expect(result.action).toBe('stop')
    const incidents = captured.filter(
      (e) => e.eventType === 'incident_emitted' && e.eventId === 'incident.stream_aborted',
    )
    expect(incidents.length).toBeGreaterThan(0)
  })
})
