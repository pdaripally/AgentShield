import { describe, it, expect } from 'vitest'
import * as fs from 'fs'
import * as path from 'path'
import {
  dispatchStageVerdict,
  dispatchToolVerdict,
} from '../native.js'

/**
 * Cross-SDK verdict-dispatch parity test.
 *
 * Reads `tests/parity/verdict_dispatch_canonical.json` and checks that
 * Node matches the shared dispatch fixture used by the other SDKs.
 */

const fixturePath = path.resolve(
  __dirname,
  '../../../tests/parity/verdict_dispatch_canonical.json',
)

const canonical = fs.existsSync(fixturePath)
  ? JSON.parse(fs.readFileSync(fixturePath, 'utf8'))
  : { stage_cases: [], tool_cases: [] }

describe('verdict-dispatch cross-SDK parity', () => {
  for (const c of canonical.stage_cases) {
    it(`stage: ${c.name}`, () => {
      const out = dispatchStageVerdict(c.verdict, {
        policy: c.policy,
        mode: c.mode,
      })
      expect(out.action).toEqual(c.expected.action)
      expect(out.record_block).toBe(c.expected.record_block)
      expect(out.override_to_proceed).toBe(c.expected.override_to_proceed)
    })
  }

  for (const c of canonical.tool_cases) {
    it(`tool: ${c.name}`, () => {
      const out = dispatchToolVerdict(c.verdict, c.tool_name, {
        stage: c.stage,
        policy: c.policy,
        mode: c.mode,
      })
      expect(out.action).toEqual(c.expected.action)
      expect(out.record_failure).toBe(c.expected.record_failure)
      expect(out.record_success).toBe(c.expected.record_success)
      expect(out.override_to_proceed).toBe(c.expected.override_to_proceed)
    })
  }
})
