//! Cross-SDK logging-parity test (Rust side).
//!
//! Reads the canonical fixture in `tests/parity/logging_canonical.json`
//! and asserts every Info+ `ShieldLogEvent` emitted during a
//! representative end-to-end interaction carries the canonical 7
//! fields. Equivalent runners under
//! `sdk/python/tests/parity/test_logging_canonical.py` and
//! `sdk/dotnet/tests/AgentShield.Tests/Parity/LoggingCanonicalTests.cs`
//! load the same fixture.
//!
//! Why this test exists (PR4 per v8 plan §6 AC2):
//!
//! - PR1's audit found no Bucket-C duplicates today, so PR4 ships no
//!   deprecation shims. But the parity contract is still load-bearing:
//!   it prevents one SDK silently dropping a required top-level field
//!   when adding new event emissions in Phase 1 (PR5–PR7 + onwards).
//!
//! - The fixture documents WHICH 7 fields are required and WHY (per
//!   spec §19.2). All three SDK runners assert against the same JSON,
//!   so the contract is byte-aligned across languages.

use std::fs;
use std::path::PathBuf;
use std::sync::{Arc, Mutex};

use agent_shield_core::{
    load_from_str, GuardrailsRuntime, ObsSeverity, ObservabilityProvider, RequestContext,
    RuntimeBuilder, ShieldLogEvent,
};
use serde_json::{json, Value};

const MINIMAL_YAML: &str = r#"
metadata:
  name: "parity-logging-canonical"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["parity test"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "echo"
      description: "Echo tool for the logging-canonical parity test."
      permission: "read_only"
"#;

fn fixture_path() -> Option<PathBuf> {
    let mut dir = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    while !dir.join(".git").exists() {
        if !dir.pop() {
            return None;
        }
    }
    let p = dir
        .join("tests")
        .join("parity")
        .join("logging_canonical.json");
    if p.exists() {
        Some(p)
    } else {
        None
    }
}

#[derive(Default)]
struct CapturingProvider {
    events: Mutex<Vec<ShieldLogEvent>>,
}

impl ObservabilityProvider for CapturingProvider {
    fn emit(&self, event: ShieldLogEvent) {
        self.events.lock().unwrap().push(event);
    }
}

fn build_runtime(provider: Arc<CapturingProvider>) -> Arc<GuardrailsRuntime> {
    let cfg = load_from_str(MINIMAL_YAML).expect("valid yaml");
    RuntimeBuilder::from_config(cfg)
        .register_provider(provider)
        .build()
        .expect("runtime build")
}

/// Severity ranking for the "Info+" filter. Mirrors the host-side
/// ordering (debug/trace come before info; everything from info up is
/// part of the canonical contract).
fn is_info_plus(severity: ObsSeverity) -> bool {
    matches!(
        severity,
        ObsSeverity::Info
            | ObsSeverity::Low
            | ObsSeverity::Medium
            | ObsSeverity::High
            | ObsSeverity::Critical
    )
}

/// Drive the runtime through a representative end-to-end interaction
/// so the capturing provider sees a varied event stream (input
/// validation, tool call, tool output, output validation, lifecycle
/// boundaries).
fn drive_representative_interaction(provider: Arc<CapturingProvider>) {
    let runtime = build_runtime(provider);
    let session = runtime.new_session(RequestContext::new("sess-parity", "corr-parity"));
    session.begin_turn().expect("begin_turn");
    let _ = session.validate_input("hello");
    let mut params = json!({ "msg": "ping" });
    let _ = session.validate_tool_call("echo", &mut params, "tc-parity");
    let _ = session.record_tool_success("echo", &json!({ "out": "pong" }));
    let mut response = String::from("agent said: pong");
    let _ = session.validate_output(&mut response);
    session.end_turn().expect("end_turn");
}

fn assert_wire_value_matches_contract(
    event_type: &str,
    field_name: &str,
    value: &Value,
    spec: &Value,
) {
    let expected_type = spec["type"].as_str().expect("required_fields[].type");

    match expected_type {
        "string" | "string-enum" => {
            let as_str = value.as_str().unwrap_or_else(|| {
                panic!(
                    "Info+ event `{}`: field `{}` must serialize as string, got {}",
                    event_type, field_name, value
                )
            });

            if expected_type == "string-enum" {
                if let Some(allowed_values) = spec["values"].as_array() {
                    let allowed = allowed_values
                        .iter()
                        .map(|v| v.as_str().expect("enum value string"))
                        .collect::<Vec<_>>();
                    assert!(
                        allowed.contains(&as_str),
                        "Info+ event `{}`: field `{}` had value `{}` outside {:?}",
                        event_type,
                        field_name,
                        as_str,
                        allowed
                    );
                }
            }
        }
        other => panic!("unsupported contract field type `{}`", other),
    }
}

#[test]
fn every_info_plus_event_carries_the_canonical_seven_fields() {
    let path = match fixture_path() {
        Some(p) => p,
        None => {
            eprintln!("logging_canonical.json not found; skipping");
            return;
        }
    };
    let raw = fs::read_to_string(&path).expect("read fixture");
    let doc: Value = serde_json::from_str(&raw).expect("parse fixture");
    let required_fields = doc["required_fields"]
        .as_array()
        .expect("required_fields array");

    // Sanity: the contract must list exactly the seven field names
    // we care about. Drift here would mean the fixture is out of
    // sync with the test contract.
    let expected_names: Vec<&str> = vec![
        "session_id",
        "correlation_id",
        "stage",
        "action",
        "event_type",
        "severity",
        "agent_id",
    ];
    let actual_names: Vec<&str> = required_fields
        .iter()
        .map(|f| f["name"].as_str().expect("field name string"))
        .collect();
    assert_eq!(
        actual_names, expected_names,
        "logging_canonical.json field list drift; update the fixture and ALL three SDK runners together"
    );

    let provider = Arc::new(CapturingProvider::default());
    drive_representative_interaction(provider.clone());
    let captured = provider.events.lock().unwrap();
    assert!(
        !captured.is_empty(),
        "expected at least one event from a representative interaction"
    );

    // Walk every Info+ event and verify the seven fields are
    // present per the fixture's nullable / required rules. We
    // serialize each event to JSON and check field presence on the
    // wire — this is what downstream pipelines see.
    let mut info_plus_seen = 0usize;
    for event in captured.iter() {
        if !is_info_plus(event.severity) {
            continue;
        }
        info_plus_seen += 1;
        let wire = serde_json::to_value(event).expect("serialize event");
        let obj = wire.as_object().expect("event serialises to JSON object");

        for spec in required_fields {
            let field_name = spec["rust_field"]
                .as_str()
                .expect("required_fields[].rust_field");
            let nullable = spec["nullable"].as_bool().unwrap_or(false);
            let maybe_value = obj.get(field_name);

            if !nullable {
                let v = maybe_value.unwrap_or_else(|| {
                    panic!(
                        "Info+ event `{}` is missing required field `{}` on the wire",
                        event.event_type.as_str(),
                        field_name
                    )
                });
                assert!(
                    !v.is_null(),
                    "Info+ event `{}`: required field `{}` is null but contract says non-nullable",
                    event.event_type.as_str(),
                    field_name
                );
                if let Some(s) = v.as_str() {
                    assert!(
                        !s.is_empty(),
                        "Info+ event `{}`: required field `{}` is empty string but contract says non-nullable",
                        event.event_type.as_str(),
                        field_name
                    );
                }
                assert_wire_value_matches_contract(event.event_type.as_str(), field_name, v, spec);
                continue;
            }

            if let Some(v) = maybe_value {
                assert!(
                    !v.is_null(),
                    "Info+ event `{}`: nullable field `{}` must be omitted or typed on the wire, got null",
                    event.event_type.as_str(),
                    field_name
                );
                assert_wire_value_matches_contract(event.event_type.as_str(), field_name, v, spec);
            }
        }
    }
    assert!(
        info_plus_seen > 0,
        "expected at least one Info+ event in the captured stream"
    );
}
