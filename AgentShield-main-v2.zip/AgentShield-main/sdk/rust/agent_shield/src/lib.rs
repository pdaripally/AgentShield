#![forbid(unsafe_code)]
//! # Agent Shield SDK
//!
//! Ergonomic Rust SDK for [Agent Shield](https://github.com/microsoft/AgentShield) —
//! runtime security controls for AI agents.
//!
//! Wraps [`agent_shield_core`] with a builder facade ([`Shield`] /
//! [`ShieldBuilder`]) that auto-wires the default delegate dispatcher,
//! exposes turn / tool brackets, and surfaces every adapter's
//! [`CapabilityReport`].
//!
//! # Quick Start
//!
//! ```no_run
//! use agent_shield::{Shield, ConsoleObservabilityProvider};
//! # async fn try_main() -> Result<(), Box<dyn std::error::Error>> {
//! let shield = Shield::from_yaml("guardrails.yaml")
//!     .with_observability(ConsoleObservabilityProvider::new())
//!     .build()?;
//!
//! let answer = shield.guarded_run("hello", |input| async move {
//!     Ok(format!("you said {input}"))
//! }).await?;
//! # let _ = answer;
//! # Ok(())
//! # }
//! ```
//!
//! # Auto-wiring
//!
//! - The `DefaultDelegateDispatcher` is wired automatically when no
//!   explicit dispatcher is registered.
//! - No default `LlmCaller` is wired — the core falls back to
//!   [`agent_shield_core::FailClosedLlmCaller`] when an
//!   `evaluate_when[].llm` entry fires without a registered caller.
//!   Hosts that need an LLM caller register one with
//!   [`ShieldBuilder::with_llm`].
//! - Observability providers are registered through
//!   [`ShieldBuilder::with_observability`]; multiple providers
//!   fan out per the dispatcher contract.
//! - `kind: human` resolvers do not need a host trait callback. The
//!   runtime synthesises a canonical `agent_shield.ask_human` MCP tool
//!   call (see `examples/tools/ask-human-mcp-server/`); the host registers
//!   an MCP tool under that name and the agent's LLM calls it when a
//!   guard policy denies with a `pending_resolution`.
//!
pub mod approval;
pub mod capabilities;
pub mod constants;
pub mod errors;
pub mod facade;
pub mod observability;
pub mod shield;

pub use capabilities::{CapabilityReport, CoverageLevel};
pub use errors::ShieldError;
pub use facade::GuardedTurn;
pub use observability::ConsoleObservabilityProvider;
pub use shield::{Shield, ShieldBuilder, ShieldMode, ToolWrapper};

// Re-export the core surface so users don't depend on agent_shield_core directly.
pub use agent_shield_core::{
    format_block_message, format_tool_block_message, make_configuration_caller, resolve_on_block,
    Action, AgentResolveRequest, AgentResolver, ClassifierCaller, ClassifierVerdict,
    CompiledPolicy, ConfigurationCaller, DelegateDispatcher, DelegateRequest, EventId,
    FailClosedLlmCaller, GuardrailsConfig, GuardrailsRuntime, GuardrailsSession, Invocation, Layer,
    LlmCaller, LlmDecision, LlmResponse, ObsStage, ObservabilityProvider, OnBlockOutcome,
    OnBlockPolicy, PendingResolution, PerfTelemetry, RequestContext, Resolver, ResolverDecision,
    ResolverResponse, RuntimeBuilder, ShieldLogEvent, StageVerdict, StreamingGuard,
    StreamingOptions, ASK_HUMAN_TOOL_NAME,
};
