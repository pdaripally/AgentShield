use std::collections::HashMap;
use std::fs;
use std::path::PathBuf;
use std::sync::Arc;
use std::time::Instant;

use agent_shield_core::{
    GuardrailsRuntime, GuardrailsSession, RequestContext, RuntimeBuilder, StageVerdict,
};
use serde::Deserialize;
use serde_json::{json, Value};

#[derive(Debug, Deserialize)]
struct Case {
    id: String,
    #[allow(dead_code)]
    spec_anchor: String,
    #[allow(dead_code)]
    title: String,
    pending: Option<bool>,
    deferred_reason: Option<String>,
    fixture_paths: Option<Vec<String>>,
    scenario: Option<Scenario>,
}

#[derive(Debug, Deserialize)]
#[serde(tag = "type")]
enum Scenario {
    #[serde(rename = "build_error")]
    BuildError { error_contains: Vec<String> },
    #[serde(rename = "session_flow")]
    SessionFlow {
        sessions: Option<Vec<String>>,
        steps: Vec<Step>,
    },
}

#[derive(Debug, Deserialize)]
struct Step {
    name: Option<String>,
    session: Option<String>,
    action: String,
    tool_name: Option<String>,
    tool_call_id: Option<String>,
    method: Option<String>,
    uri: Option<String>,
    variable_name: Option<String>,
    tool_params: Option<Value>,
    result: Option<Value>,
    body: Option<Value>,
    value: Option<Value>,
    assert: Option<Assertions>,
}

#[derive(Debug, Deserialize, Default)]
struct Assertions {
    allowed: Option<bool>,
    policy: Option<String>,
    reason_contains: Option<String>,
    mutated_text_contains: Option<String>,
    mutated_text_not_contains: Option<OneOrMany>,
    events_fired: Option<OneOrMany>,
    events_not_fired: Option<OneOrMany>,
    invocation_hash: Option<HashAssertion>,
    post_validation_invocation_hash: Option<HashAssertion>,
}

#[derive(Debug, Deserialize)]
#[serde(untagged)]
enum OneOrMany {
    One(String),
    Many(Vec<String>),
}

impl OneOrMany {
    fn values(&self) -> Vec<String> {
        match self {
            Self::One(value) => vec![value.clone()],
            Self::Many(values) => values.clone(),
        }
    }
}

#[derive(Debug, Deserialize)]
struct HashAssertion {
    state: Option<String>,
    equals_step: Option<String>,
    equals_step_field: Option<String>,
    differs_step: Option<String>,
    differs_step_field: Option<String>,
    differs_from: Option<String>,
}

struct CaseResult {
    case_id: String,
    status: &'static str,
    message: String,
    duration_s: f64,
}

struct ActionOutcome {
    verdict: Option<StageVerdict>,
    text: Option<String>,
}

#[derive(Clone)]
struct StepRef {
    invocation_hash: Option<String>,
    post_validation_invocation_hash: Option<String>,
}

fn repo_root() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("..")
        .join("..")
        .join("..")
        .canonicalize()
        .expect("repo root")
}

fn conformance_dir() -> PathBuf {
    repo_root().join("tests").join("conformance")
}

fn cases_dir() -> PathBuf {
    conformance_dir().join("cases")
}

fn results_path() -> PathBuf {
    conformance_dir().join("results").join("rust.xml")
}

fn absolute_fixture_paths(case: &Case) -> Vec<PathBuf> {
    case.fixture_paths
        .clone()
        .unwrap_or_default()
        .into_iter()
        .map(|rel| repo_root().join(rel))
        .collect()
}

fn load_cases() -> Vec<Case> {
    let mut out = Vec::new();
    let mut entries: Vec<_> = fs::read_dir(cases_dir())
        .expect("cases dir")
        .flatten()
        .filter(|entry| entry.path().extension().and_then(|ext| ext.to_str()) == Some("json"))
        .collect();
    entries.sort_by_key(|entry| entry.file_name());
    for entry in entries {
        let text = fs::read_to_string(entry.path()).expect("case json");
        out.push(serde_json::from_str(&text).expect("valid case json"));
    }
    out
}

fn build_runtime(case: &Case) -> Result<Arc<GuardrailsRuntime>, String> {
    let paths = absolute_fixture_paths(case);
    let builder = if paths.len() == 1 {
        RuntimeBuilder::from_yaml(&paths[0]).map_err(|e| format!("from_yaml: {e:?}"))?
    } else {
        RuntimeBuilder::from_yaml_chain(&paths).map_err(|e| format!("from_yaml_chain: {e:?}"))?
    };
    builder.build().map_err(|e| format!("build: {e:?}"))
}

fn open_session(rt: &Arc<GuardrailsRuntime>, name: &str) -> GuardrailsSession {
    let session = rt.new_session(RequestContext::new(name, format!("{name}-corr")));
    let _ = session.begin_request();
    let _ = session.begin_turn();
    session
}

fn run_build_error(case: &Case, needles: &[String]) -> Result<(), String> {
    match build_runtime(case) {
        Ok(_) => Err("expected build failure but runtime built successfully".into()),
        Err(error) => {
            for needle in needles {
                if !error.contains(needle) {
                    return Err(format!(
                        "expected build error containing {needle:?}, got {error:?}"
                    ));
                }
            }
            Ok(())
        }
    }
}

fn run_step(session: &GuardrailsSession, step: &Step) -> Result<ActionOutcome, String> {
    match step.action.as_str() {
        "begin_request" => {
            session
                .begin_request()
                .map_err(|e| format!("begin_request: {e:?}"))?;
            Ok(ActionOutcome {
                verdict: None,
                text: None,
            })
        }
        "begin_turn" => {
            session
                .begin_turn()
                .map_err(|e| format!("begin_turn: {e:?}"))?;
            Ok(ActionOutcome {
                verdict: None,
                text: None,
            })
        }
        "set_variable" => {
            let name = step
                .variable_name
                .as_deref()
                .ok_or_else(|| "set_variable missing variable_name".to_string())?;
            session
                .set_variable(name, step.value.clone().unwrap_or(Value::Null))
                .map_err(|e| format!("set_variable({name}): {e:?}"))?;
            Ok(ActionOutcome {
                verdict: None,
                text: None,
            })
        }
        "validate_tool_call" => {
            let tool = step
                .tool_name
                .as_deref()
                .ok_or_else(|| "validate_tool_call missing tool_name".to_string())?;
            let mut params = step.tool_params.clone().unwrap_or_else(|| json!({}));
            let verdict = session.validate_tool_call(
                tool,
                &mut params,
                step.tool_call_id.as_deref().unwrap_or("case"),
            );
            Ok(ActionOutcome {
                verdict: Some(verdict),
                text: Some(params.to_string()),
            })
        }
        "validate_tool_output" => {
            let tool = step
                .tool_name
                .as_deref()
                .ok_or_else(|| "validate_tool_output missing tool_name".to_string())?;
            let mut result = step.result.clone().unwrap_or(Value::Null);
            let verdict = session.validate_tool_output(
                tool,
                &mut result,
                step.tool_call_id.as_deref().unwrap_or("case"),
            );
            Ok(ActionOutcome {
                verdict: Some(verdict),
                text: Some(result.to_string()),
            })
        }
        "validate_endpoint_call" => {
            let mut body = step.body.clone().unwrap_or_else(|| json!({}));
            let verdict = session.validate_endpoint_call(
                step.method.as_deref().unwrap_or("GET"),
                step.uri.as_deref().unwrap_or(""),
                &mut body,
                step.tool_call_id.as_deref().unwrap_or("case"),
            );
            Ok(ActionOutcome {
                verdict: Some(verdict),
                text: Some(body.to_string()),
            })
        }
        other => Err(format!("unsupported action {other:?}")),
    }
}

fn read_step_field(
    step_refs: &HashMap<String, StepRef>,
    step: &str,
    field: &str,
) -> Option<String> {
    step_refs.get(step).and_then(|step_ref| match field {
        "post_validation_invocation_hash" => step_ref.post_validation_invocation_hash.clone(),
        _ => step_ref.invocation_hash.clone(),
    })
}

fn assert_hash(
    actual: Option<String>,
    verdict: &StageVerdict,
    spec: &HashAssertion,
    field: &str,
    step_refs: &HashMap<String, StepRef>,
    tag: &str,
) -> Result<(), String> {
    if let Some(state) = spec.state.as_deref() {
        match state {
            "present" if actual.is_none() => {
                return Err(format!("[{tag}] expected {field} to be present"));
            }
            "absent" if actual.is_some() => {
                return Err(format!(
                    "[{tag}] expected {field} to be absent, got {actual:?}"
                ));
            }
            _ => {}
        }
    }
    if let Some(step) = spec.equals_step.as_deref() {
        let other = read_step_field(
            step_refs,
            step,
            spec.equals_step_field.as_deref().unwrap_or(field),
        );
        if actual != other {
            return Err(format!(
                "[{tag}] expected {field}={actual:?} to equal {step}:{}={other:?}",
                spec.equals_step_field.as_deref().unwrap_or(field)
            ));
        }
    }
    if let Some(step) = spec.differs_step.as_deref() {
        let other = read_step_field(
            step_refs,
            step,
            spec.differs_step_field.as_deref().unwrap_or(field),
        );
        if actual == other {
            return Err(format!(
                "[{tag}] expected {field}={actual:?} to differ from {step}:{}",
                spec.differs_step_field.as_deref().unwrap_or(field)
            ));
        }
    }
    if let Some(other_field) = spec.differs_from.as_deref() {
        let other = match other_field {
            "post_validation_invocation_hash" => verdict.post_validation_invocation_hash.clone(),
            _ => verdict.invocation_hash.clone(),
        };
        if actual == other {
            return Err(format!(
                "[{tag}] expected {field}={actual:?} to differ from {other_field}={other:?}"
            ));
        }
    }
    Ok(())
}

fn check_assertions(
    case_id: &str,
    step_name: &str,
    outcome: &ActionOutcome,
    expected: &Assertions,
    step_refs: &HashMap<String, StepRef>,
) -> Result<(), String> {
    let tag = format!("{case_id}:{step_name}");
    let verdict = outcome.verdict.as_ref();

    if let Some(allowed) = expected.allowed {
        let verdict = verdict.ok_or_else(|| format!("[{tag}] expected verdict"))?;
        if verdict.allowed != allowed {
            return Err(format!(
                "[{tag}] expected allowed={allowed}, got {} (policy={:?}, reason={:?})",
                verdict.allowed, verdict.policy, verdict.reason
            ));
        }
    }
    if let Some(policy) = expected.policy.as_deref() {
        let verdict = verdict.ok_or_else(|| format!("[{tag}] expected verdict"))?;
        if verdict.policy.as_deref() != Some(policy) {
            return Err(format!(
                "[{tag}] expected policy={policy:?}, got {:?}",
                verdict.policy
            ));
        }
    }
    if let Some(reason_contains) = expected.reason_contains.as_deref() {
        let verdict = verdict.ok_or_else(|| format!("[{tag}] expected verdict"))?;
        let reason = verdict.reason.clone().unwrap_or_default();
        if !reason.contains(reason_contains) {
            return Err(format!(
                "[{tag}] expected reason containing {reason_contains:?}, got {reason:?}"
            ));
        }
    }
    if let Some(needle) = expected.mutated_text_contains.as_deref() {
        let actual = outcome.text.clone().unwrap_or_default();
        if !actual.contains(needle) {
            return Err(format!(
                "[{tag}] expected transformed text containing {needle:?}, got {actual:?}"
            ));
        }
    }
    if let Some(values) = &expected.mutated_text_not_contains {
        let actual = outcome.text.clone().unwrap_or_default();
        for value in values.values() {
            if actual.contains(&value) {
                return Err(format!(
                    "[{tag}] expected transformed text to exclude {value:?}, got {actual:?}"
                ));
            }
        }
    }
    if expected
        .events_fired
        .as_ref()
        .map(|values| !values.values().is_empty())
        .unwrap_or(false)
        || expected
            .events_not_fired
            .as_ref()
            .map(|values| !values.values().is_empty())
            .unwrap_or(false)
    {
        return Err(format!(
            "[{tag}] event assertions are not yet implemented in the Rust conformance runner"
        ));
    }
    if let Some(hash_assertion) = &expected.invocation_hash {
        let verdict = verdict.ok_or_else(|| format!("[{tag}] expected verdict"))?;
        assert_hash(
            verdict.invocation_hash.clone(),
            verdict,
            hash_assertion,
            "invocation_hash",
            step_refs,
            &tag,
        )?;
    }
    if let Some(hash_assertion) = &expected.post_validation_invocation_hash {
        let verdict = verdict.ok_or_else(|| format!("[{tag}] expected verdict"))?;
        assert_hash(
            verdict.post_validation_invocation_hash.clone(),
            verdict,
            hash_assertion,
            "post_validation_invocation_hash",
            step_refs,
            &tag,
        )?;
    }
    Ok(())
}

fn run_session_flow(
    case: &Case,
    sessions: &Option<Vec<String>>,
    steps: &[Step],
) -> Result<(), String> {
    let runtime = build_runtime(case)?;
    let session_names = sessions
        .clone()
        .unwrap_or_else(|| vec!["default".to_string()]);
    let mut all_sessions = HashMap::new();
    for name in &session_names {
        all_sessions.insert(name.clone(), open_session(&runtime, name));
    }
    let mut step_refs: HashMap<String, StepRef> = HashMap::new();
    for (index, step) in steps.iter().enumerate() {
        let name = step
            .name
            .clone()
            .unwrap_or_else(|| format!("step_{}", index + 1));
        let session_name = step
            .session
            .clone()
            .unwrap_or_else(|| session_names[0].clone());
        let session = all_sessions
            .get(&session_name)
            .ok_or_else(|| format!("unknown session {session_name:?}"))?;
        let outcome = run_step(session, step)?;
        if let Some(verdict) = &outcome.verdict {
            step_refs.insert(
                name.clone(),
                StepRef {
                    invocation_hash: verdict.invocation_hash.clone(),
                    post_validation_invocation_hash: verdict
                        .post_validation_invocation_hash
                        .clone(),
                },
            );
        }
        if let Some(assertions) = &step.assert {
            check_assertions(&case.id, &name, &outcome, assertions, &step_refs)?;
        }
    }
    Ok(())
}

fn xml_escape(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
        .replace('\'', "&apos;")
}

fn write_junit(results: &[CaseResult]) {
    let path = results_path();
    fs::create_dir_all(path.parent().expect("results dir")).expect("create results dir");
    let failures = results
        .iter()
        .filter(|result| result.status == "failed")
        .count();
    let skipped = results
        .iter()
        .filter(|result| result.status == "skipped")
        .count();
    let total_time: f64 = results.iter().map(|result| result.duration_s).sum();
    let mut xml = format!(
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<testsuite name=\"conformance-rust\" tests=\"{}\" failures=\"{}\" skipped=\"{}\" time=\"{:.3}\">\n",
        results.len(), failures, skipped, total_time
    );
    for result in results {
        xml.push_str(&format!(
            "  <testcase classname=\"tests.conformance.rust\" name=\"{}\" time=\"{:.3}\">\n",
            xml_escape(&result.case_id),
            result.duration_s
        ));
        match result.status {
            "failed" => xml.push_str(&format!(
                "    <failure message=\"{}\">{}</failure>\n",
                xml_escape(&result.message),
                xml_escape(&result.message)
            )),
            "skipped" => xml.push_str(&format!(
                "    <skipped message=\"{}\"/>\n",
                xml_escape(&result.message)
            )),
            _ => {}
        }
        xml.push_str("  </testcase>\n");
    }
    xml.push_str("</testsuite>\n");
    fs::write(path, xml).expect("write rust junit");
}

fn main() {
    let cases = load_cases();
    let mut results = Vec::new();
    let mut failures = 0usize;

    for case in cases {
        let started = Instant::now();
        let outcome = if case.pending.unwrap_or(false) {
            Ok((
                "skipped",
                case.deferred_reason
                    .clone()
                    .unwrap_or_else(|| "pending".into()),
            ))
        } else {
            match case.scenario.as_ref() {
                Some(Scenario::BuildError { error_contains }) => {
                    run_build_error(&case, error_contains).map(|_| ("passed", String::new()))
                }
                Some(Scenario::SessionFlow { sessions, steps }) => {
                    run_session_flow(&case, sessions, steps).map(|_| ("passed", String::new()))
                }
                None => Err("non-pending case missing scenario".into()),
            }
        };

        match outcome {
            Ok((status, message)) => {
                if status == "passed" {
                    println!("PASS {}", case.id);
                }
                results.push(CaseResult {
                    case_id: case.id,
                    status,
                    message,
                    duration_s: started.elapsed().as_secs_f64(),
                });
            }
            Err(message) => {
                eprintln!("FAIL {}: {}", case.id, message);
                failures += 1;
                results.push(CaseResult {
                    case_id: case.id,
                    status: "failed",
                    message,
                    duration_s: started.elapsed().as_secs_f64(),
                });
            }
        }
    }

    write_junit(&results);
    println!(
        "Wrote {}",
        results_path().strip_prefix(repo_root()).unwrap().display()
    );
    if failures > 0 {
        std::process::exit(1);
    }
}
