//! Integration test binary: AgentShield concurrency validation suite.
//!
//! This file is the Cargo entry point for the concurrency tests.
//! Each submodule exercises a different concurrency concern:
//!   - race_windows: TOCTOU and begin/end turn races
//!   - tool_admission: ToolAdmission RAII commit/drop races
//!   - session_isolation: Cross-session state leakage
//!   - lock_order: Lock-ordering and deadlock detection
//!   - resolver: Resolver callback safety
//!   - parallel_validation: Concurrent Stage 3 evaluations
//!   - streaming: Overlapping streaming chunks
//!   - stress: Multi-agent fan-out and soak tests
//!   - failure: Panic recovery and poisoning

mod concurrency {
    pub mod failure;
    pub mod helpers;
    pub mod lock_order;
    pub mod parallel_validation;
    pub mod race_windows;
    pub mod resolver;
    pub mod session_isolation;
    pub mod streaming;
    pub mod stress;
    pub mod tool_admission;
}
