#![cfg(not(loom))]

use std::panic::{self, AssertUnwindSafe};
use std::sync::{mpsc, Arc, Barrier};
use std::thread;
use std::time::{Duration, Instant};

use agent_shield_core::{
    GuardrailsRuntime, GuardrailsSession, RequestContext, RuntimeBuilder, StageVerdict,
};
use serde_json::json;

const TEST_TIMEOUT: Duration = Duration::from_secs(60);
const PARALLEL_CALLS: usize = 20;
const INTERLEAVING_CALLS: usize = 10;
const CONCURRENT_SESSIONS: usize = 32;
const REENTRANCY_ITERS: usize = 5_000;
const DEADLOCK_ITERS: usize = 5_000;

const ALWAYS_ALLOW_YAML: &str = r#"
metadata:
  name: "concurrency-parallel"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Test parallel validation."]
  forbidden: ["None."]
resources:
  tools:
    - name: "tool_a"
      description: "Tool A."
      permission: "execute"
    - name: "tool_b"
      description: "Tool B."
      permission: "execute"
variables:
  - name: "counter"
    type: "number"
    default: 0
  - name: "flag"
    type: "boolean"
    default: false
state_validation:
  guard_policies:
    - name: "allow_all"
      applies_to:
        tools: ["tool_a", "tool_b"]
      evaluate_when:
        - expression: "true"
          reason: "Unreachable."
      action: "block"
"#;

const INPUT_EVAL_YAML: &str = r#"
metadata:
  name: "concurrency-input-eval"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Test parallel validation."]
  forbidden: ["None."]
resources:
  tools:
    - name: "tool_a"
      description: "Tool A."
      permission: "execute"
variables:
  - name: "counter"
    type: "number"
    default: 0
  - name: "flag"
    type: "boolean"
    default: false
input_validation:
  guard_policies:
    - name: "input_eval_isolation"
      evaluate_when:
        - expression: "counter >= 0 and flag == false"
          reason: "Unexpected cross-session evaluator state."
      action: "block"
"#;

const FLAG_GUARD_YAML: &str = r#"
metadata:
  name: "concurrency-flag-guard"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Test parallel validation."]
  forbidden: ["None."]
resources:
  tools:
    - name: "tool_a"
      description: "Tool A."
      permission: "execute"
variables:
  - name: "counter"
    type: "number"
    default: 0
  - name: "flag"
    type: "boolean"
    default: false
state_validation:
  guard_policies:
    - name: "allow_all"
      applies_to:
        tools: ["tool_a"]
      evaluate_when:
        - expression: "true"
          reason: "Unreachable."
      action: "block"
tool_execution_validation:
  guard_policies:
    - name: "check_flag_on_exec"
      applies_to:
        tools: ["tool_a"]
      evaluate_when:
        - expression: "flag == true"
          reason: "Flag not set."
      action: "block"
"#;

const EVENT_GUARD_YAML: &str = r#"
metadata:
  name: "concurrency-event-eval"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Test parallel validation."]
  forbidden: ["None."]
resources:
  tools:
    - name: "tool_b"
      description: "Tool B."
      permission: "execute"
variables:
  - name: "counter"
    type: "number"
    default: 0
  - name: "flag"
    type: "boolean"
    default: false
state_validation:
  guard_policies:
    - name: "allow_all"
      applies_to:
        tools: ["tool_b"]
      evaluate_when:
        - expression: "true"
          reason: "Unreachable."
      action: "block"
tool_execution_validation:
  guard_policies:
    - name: "incident_gate"
      applies_to:
        tools: ["tool_b"]
      evaluate_when:
        - expression: "@event.fired('incident.foo')"
          reason: "incident.foo not fired yet"
      action: "block"
"#;

fn build_runtime(yaml: &str) -> Arc<GuardrailsRuntime> {
    RuntimeBuilder::from_yaml_strings(&[yaml])
        .expect("yaml parses")
        .build()
        .expect("runtime builds")
}

fn open_session(runtime: &Arc<GuardrailsRuntime>, name: &str) -> Arc<GuardrailsSession> {
    let session = Arc::new(runtime.new_session(RequestContext::new(
        format!("session-{name}"),
        format!("corr-{name}"),
    )));
    // Seed declared variable defaults so guard-policy expressions that
    // reference them evaluate correctly (unset variables are null in
    // the expression evaluator, which causes false blocks).
    let _ = session.set_variable("counter", json!(0));
    let _ = session.set_variable("flag", json!(false));
    session
}

fn run_with_timeout<F>(name: &'static str, f: F)
where
    F: FnOnce() + Send + 'static,
{
    let (tx, rx) = mpsc::sync_channel(1);
    let handle = thread::spawn(move || {
        let result = panic::catch_unwind(AssertUnwindSafe(f));
        let _ = tx.send(result);
    });

    match rx.recv_timeout(TEST_TIMEOUT) {
        Ok(Ok(())) => {
            handle
                .join()
                .expect("timeout worker thread should join cleanly");
        }
        Ok(Err(payload)) => {
            handle
                .join()
                .expect("panic worker thread should join cleanly");
            panic::resume_unwind(payload);
        }
        Err(mpsc::RecvTimeoutError::Timeout) => {
            panic!("{name} timed out after {TEST_TIMEOUT:?}");
        }
        Err(err) => {
            panic!("{name} failed to report completion: {err}");
        }
    }
}

fn assert_allowed(verdict: &StageVerdict, label: &str) {
    assert!(verdict.allowed, "{label} should allow, got {verdict:?}");
}

fn assert_flag_verdict_is_consistent(verdict: &StageVerdict) {
    if verdict.allowed {
        return;
    }

    assert_eq!(verdict.policy.as_deref(), Some("check_flag_on_exec"));
    assert_eq!(verdict.reason.as_deref(), Some("Flag not set."));
}

fn assert_event_verdict_is_consistent(verdict: &StageVerdict) {
    if verdict.allowed {
        return;
    }

    assert_eq!(verdict.policy.as_deref(), Some("incident_gate"));
    assert_eq!(
        verdict.reason.as_deref(),
        Some("incident.foo not fired yet")
    );
}

#[test]
fn parallel_stage3_distinct_ids() {
    run_with_timeout("parallel_stage3_distinct_ids", move || {
        let runtime = build_runtime(ALWAYS_ALLOW_YAML);
        let session = open_session(&runtime, "parallel-stage3-distinct-ids");
        let turn_id = session.begin_turn().expect("begin turn");
        let barrier = Arc::new(Barrier::new(PARALLEL_CALLS + 1));

        let handles: Vec<_> = (0..PARALLEL_CALLS)
            .map(|index| {
                let session = Arc::clone(&session);
                let barrier = Arc::clone(&barrier);
                thread::spawn(move || {
                    let call_id = format!("call_{index}");
                    let mut params = json!({});
                    barrier.wait();
                    let verdict = session.validate_tool_call("tool_a", &mut params, &call_id);
                    (call_id, verdict)
                })
            })
            .collect();

        barrier.wait();

        let mut call_ids = Vec::with_capacity(PARALLEL_CALLS);
        for handle in handles {
            let (call_id, verdict) = handle.join().expect("stage3 thread should not panic");
            assert_allowed(&verdict, "parallel Stage 3 verdict");
            call_ids.push(call_id);
        }

        for call_id in call_ids {
            let mut result = json!({"ok": true});
            let verdict =
                session.validate_tool_output_for_turn("tool_a", &mut result, &call_id, turn_id);
            assert_allowed(&verdict, "paired Stage 4 verdict");
        }

        session.end_turn().expect("end turn");
    });
}

#[test]
fn same_shard_contention() {
    run_with_timeout("same_shard_contention", move || {
        let runtime = build_runtime(ALWAYS_ALLOW_YAML);
        let session = open_session(&runtime, "same-shard-contention");
        let turn_id = session.begin_turn().expect("begin turn");
        let barrier = Arc::new(Barrier::new(PARALLEL_CALLS + 1));

        let handles: Vec<_> = (0..PARALLEL_CALLS)
            .map(|index| {
                let session = Arc::clone(&session);
                let barrier = Arc::clone(&barrier);
                thread::spawn(move || {
                    let call_id = format!("call_{index}");
                    let mut params = json!({});
                    barrier.wait();
                    let verdict = session.validate_tool_call("tool_a", &mut params, &call_id);
                    (call_id, verdict)
                })
            })
            .collect();

        let started = Instant::now();
        barrier.wait();

        let mut call_ids = Vec::with_capacity(PARALLEL_CALLS);
        for handle in handles {
            let (call_id, verdict) = handle.join().expect("contention thread should not panic");
            assert_allowed(&verdict, "contention Stage 3 verdict");
            call_ids.push(call_id);
        }

        let elapsed = started.elapsed();
        assert!(
            elapsed < Duration::from_secs(10),
            "20 concurrent validations serialized unexpectedly: {elapsed:?}"
        );

        for call_id in call_ids {
            let mut result = json!({"ok": true});
            let verdict =
                session.validate_tool_output_for_turn("tool_a", &mut result, &call_id, turn_id);
            assert_allowed(&verdict, "contention Stage 4 verdict");
        }

        session.end_turn().expect("end turn");
    });
}

#[test]
fn stage3_stage4_interleaving() {
    run_with_timeout("stage3_stage4_interleaving", move || {
        let runtime = build_runtime(ALWAYS_ALLOW_YAML);
        let session = open_session(&runtime, "stage3-stage4-interleaving");
        let turn_id = session.begin_turn().expect("begin turn");

        let call_ids: Vec<_> = (0..INTERLEAVING_CALLS)
            .map(|index| {
                let call_id = format!("call_{index}");
                let mut params = json!({"index": index});
                let verdict = session.validate_tool_call("tool_a", &mut params, &call_id);
                assert_allowed(&verdict, "sequential Stage 3 verdict");
                call_id
            })
            .collect();

        let barrier = Arc::new(Barrier::new(INTERLEAVING_CALLS + 1));
        let handles: Vec<_> = call_ids
            .iter()
            .rev()
            .cloned()
            .map(|call_id| {
                let session = Arc::clone(&session);
                let barrier = Arc::clone(&barrier);
                thread::spawn(move || {
                    let mut result = json!({"ok": true, "call_id": call_id.clone()});
                    barrier.wait();
                    session.validate_tool_output_for_turn("tool_a", &mut result, &call_id, turn_id)
                })
            })
            .collect();

        barrier.wait();

        for handle in handles {
            let verdict = handle.join().expect("stage4 thread should not panic");
            assert_allowed(&verdict, "parallel Stage 4 verdict");
        }

        session.end_turn().expect("end turn");
    });
}

#[test]
fn guard_policy_concurrent_evaluation() {
    run_with_timeout("guard_policy_concurrent_evaluation", move || {
        let runtime = build_runtime(INPUT_EVAL_YAML);
        let barrier = Arc::new(Barrier::new(CONCURRENT_SESSIONS + 1));

        let handles: Vec<_> = (0..CONCURRENT_SESSIONS)
            .map(|index| {
                let runtime = Arc::clone(&runtime);
                let barrier = Arc::clone(&barrier);
                thread::spawn(move || {
                    let session = open_session(&runtime, &format!("input-{index}"));
                    let input = format!("parallel input {index}");
                    barrier.wait();
                    let verdict = session.validate_input(&input);
                    assert_allowed(&verdict, "concurrent input verdict");
                })
            })
            .collect();

        barrier.wait();

        for handle in handles {
            handle.join().expect("input thread should not panic");
        }
    });
}

#[test]
fn expression_evaluator_reentrancy() {
    run_with_timeout("expression_evaluator_reentrancy", move || {
        let runtime = build_runtime(FLAG_GUARD_YAML);
        let session = open_session(&runtime, "expression-evaluator-reentrancy");
        session.begin_turn().expect("begin turn");

        for iter in 0..REENTRANCY_ITERS {
            session
                .set_variable("flag", json!(false))
                .expect("reset flag to false");

            let barrier = Arc::new(Barrier::new(3));

            let writer_session = Arc::clone(&session);
            let writer_barrier = Arc::clone(&barrier);
            let writer = thread::spawn(move || {
                writer_barrier.wait();
                writer_session
                    .set_variable("flag", json!(true))
                    .expect("set flag to true");
            });

            let reader_session = Arc::clone(&session);
            let reader_barrier = Arc::clone(&barrier);
            let reader = thread::spawn(move || {
                let call_id = format!("call_{iter}");
                let mut params = json!({});
                reader_barrier.wait();
                let admission =
                    reader_session.validate_tool_admission("tool_a", &mut params, &call_id);
                let verdict = admission.verdict().clone();
                drop(admission);
                verdict
            });

            barrier.wait();
            writer.join().expect("writer thread should not panic");
            let verdict = reader.join().expect("reader thread should not panic");
            assert_flag_verdict_is_consistent(&verdict);

            let flag_state = session.read_variable("flag").expect("flag declared");
            assert_eq!(
                flag_state.value,
                json!(true),
                "iteration {iter} lost the write"
            );
        }

        session.end_turn().expect("end turn");
    });
}

#[test]
fn nested_evaluation_no_deadlock() {
    run_with_timeout("nested_evaluation_no_deadlock", move || {
        let runtime = build_runtime(EVENT_GUARD_YAML);
        let session = open_session(&runtime, "nested-evaluation-no-deadlock");
        session.begin_turn().expect("begin turn");

        for iter in 0..DEADLOCK_ITERS {
            session
                .clear_event("incident.foo")
                .expect("clear incident.foo before iteration");

            let barrier = Arc::new(Barrier::new(3));

            let evaluator_session = Arc::clone(&session);
            let evaluator_barrier = Arc::clone(&barrier);
            let evaluator = thread::spawn(move || {
                let call_id = format!("call_{iter}");
                let mut params = json!({});
                evaluator_barrier.wait();
                let admission =
                    evaluator_session.validate_tool_admission("tool_b", &mut params, &call_id);
                let verdict = admission.verdict().clone();
                drop(admission);
                verdict
            });

            let emitter_session = Arc::clone(&session);
            let emitter_barrier = Arc::clone(&barrier);
            let emitter = thread::spawn(move || {
                emitter_barrier.wait();
                emitter_session
                    .emit_event("incident.foo", None, None)
                    .expect("emit incident.foo");
            });

            barrier.wait();
            emitter.join().expect("emitter thread should not panic");
            let verdict = evaluator.join().expect("evaluator thread should not panic");
            assert_event_verdict_is_consistent(&verdict);
            assert!(
                session.event_fired("incident.foo"),
                "iteration {iter} should leave the event latched"
            );
        }

        session.end_turn().expect("end turn");
    });
}
