#![allow(dead_code)]

use std::any::Any;
use std::collections::HashMap;
use std::panic::{self, AssertUnwindSafe};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{mpsc, Arc, Mutex};
use std::thread;
use std::time::Duration;

use agent_shield_core::guard_policy_runtime::streaming::StreamingTrigger;
use agent_shield_core::observability::Stage;
use agent_shield_core::resolver_runtime::{HumanResolveRequest, HumanResolver};
use agent_shield_core::{
    GuardrailsRuntime, ObservabilityProvider, RequestContext, ResolverDecision, ResolverResponse,
    RuntimeBuilder, ShieldLogEvent, StreamChunkAction, StreamingOptions, VarStatus,
};
use serde_json::json;

const TEST_TIMEOUT: Duration = Duration::from_secs(30);

const FAILURE_YAML: &str = r#"
metadata:
  name: "concurrency-failure"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Test failure injection."]
  forbidden: ["None."]
resources:
  tools:
    - name: "tool_a"
      description: "Tool A."
      permission: "execute"
variables:
  - name: "counter"
    type: "number"
    default: 0
  - name: "flag"
    type: "boolean"
    default: false
state_validation:
  guard_policies:
    - name: "check_flag"
      applies_to:
        tools: ["tool_a"]
      evaluate_when:
        - expression: "flag == true"
          reason: "Flag not set."
      action: "block"
"#;

const RESOLVER_PANIC_YAML: &str = r#"
metadata:
  name: "concurrency-failure-resolver"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Test failure injection."]
  forbidden: ["None."]
resources:
  tools:
    - name: "tool_a"
      description: "Tool A."
      permission: "execute"
variables:
  - name: "approval"
    type: "boolean"
    on_demand_by:
      kind: human
      provider: panic_once
      prompt: "Approve this operation?"
"#;

const OUTPUT_FAILURE_YAML: &str = r#"
metadata:
  name: "concurrency-failure-output"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Test failure injection."]
  forbidden: ["None."]
resources:
  tools:
    - name: "tool_a"
      description: "Tool A."
      permission: "execute"
output_validation:
  guard_policies:
    - name: "scrub_secret"
      evaluate_when:
        - pattern: "\\d{3}-\\d{2}-\\d{4}"
          reason: "Secret detected."
      action: "redact"
      replacement: "[REDACTED]"
"#;

fn ctx(session_id: &str) -> RequestContext {
    RequestContext::new(session_id, format!("{session_id}-corr"))
}

fn build_runtime(yaml: &str) -> Arc<GuardrailsRuntime> {
    RuntimeBuilder::from_yaml_strings(&[yaml])
        .expect("yaml loads")
        .build()
        .expect("runtime builds")
}

fn run_with_timeout<F>(name: &'static str, f: F)
where
    F: FnOnce() + Send + 'static,
{
    let (tx, rx) = mpsc::sync_channel(1);
    let handle = thread::spawn(move || {
        let result = panic::catch_unwind(AssertUnwindSafe(f));
        let _ = tx.send(result);
    });

    match rx.recv_timeout(TEST_TIMEOUT) {
        Ok(Ok(())) => {
            handle
                .join()
                .expect("timeout worker thread should join cleanly");
        }
        Ok(Err(panic_payload)) => {
            handle
                .join()
                .expect("panic worker thread should join cleanly");
            panic::resume_unwind(panic_payload);
        }
        Err(mpsc::RecvTimeoutError::Timeout) => {
            panic!("{name} exceeded {:?}", TEST_TIMEOUT);
        }
        Err(err) => {
            panic!("{name} did not report completion: {err}");
        }
    }
}

fn panic_message(payload: Box<dyn Any + Send>) -> String {
    match payload.downcast::<String>() {
        Ok(msg) => *msg,
        Err(payload) => match payload.downcast::<&'static str>() {
            Ok(msg) => (*msg).to_string(),
            Err(_) => "<non-string panic payload>".to_string(),
        },
    }
}

fn assert_poison_text(text: &str, context: &str) {
    assert!(
        text.to_ascii_lowercase().contains("poison"),
        "{context} should either recover or fail due to mutex poisoning; got {text}"
    );
}

fn assert_result_recovers_or_poison<T, E: std::fmt::Debug>(
    result: Result<T, E>,
    context: &str,
) -> Option<T> {
    match result {
        Ok(value) => Some(value),
        Err(err) => {
            assert_poison_text(&format!("{err:?}"), context);
            None
        }
    }
}

fn assert_caught_recovers_or_poison<T, E: std::fmt::Debug>(
    result: Result<Result<T, E>, Box<dyn Any + Send>>,
    context: &str,
) -> Option<T> {
    match result {
        Ok(inner) => assert_result_recovers_or_poison(inner, context),
        Err(payload) => {
            assert_poison_text(&panic_message(payload), context);
            None
        }
    }
}

#[derive(Default)]
struct SessionEventCounter {
    counts: Mutex<HashMap<String, usize>>,
}

impl SessionEventCounter {
    fn count_for(&self, session_id: &str) -> usize {
        self.counts
            .lock()
            .expect("counter mutex should not poison")
            .get(session_id)
            .copied()
            .unwrap_or(0)
    }
}

impl ObservabilityProvider for SessionEventCounter {
    fn emit(&self, event: ShieldLogEvent) {
        let mut counts = self.counts.lock().expect("counter mutex should not poison");
        *counts.entry(event.session_id).or_insert(0) += 1;
    }
}

struct PanicOnceHumanResolver {
    session_id: String,
    fired: AtomicBool,
}

impl PanicOnceHumanResolver {
    fn new(session_id: &str) -> Self {
        Self {
            session_id: session_id.to_string(),
            fired: AtomicBool::new(false),
        }
    }
}

impl HumanResolver for PanicOnceHumanResolver {
    fn resolve(&self, req: HumanResolveRequest) -> ResolverResponse {
        let matches_session = req
            .session_id
            .as_ref()
            .map(|id| id.as_str() == self.session_id)
            .unwrap_or(false);

        if matches_session && !self.fired.swap(true, Ordering::SeqCst) {
            panic!("intentional resolver panic for session {}", self.session_id);
        }

        ResolverResponse {
            decision: ResolverDecision::Allow,
            value: Some(json!(true)),
            set_variables: HashMap::new(),
            reason: None,
        }
    }
}

#[test]
fn mutex_poison_propagation() {
    run_with_timeout("mutex_poison_propagation", move || {
        let counter = Arc::new(SessionEventCounter::default());
        let runtime = RuntimeBuilder::from_yaml_strings(&[FAILURE_YAML])
            .expect("yaml loads")
            .register_provider(counter.clone())
            .build()
            .expect("runtime builds");

        let session_a = Arc::new(runtime.new_session(ctx("failure-a")));
        let session_b = runtime.new_session(ctx("failure-b"));

        let panicking_thread = {
            let session_a = session_a.clone();
            thread::spawn(move || {
                let unwind = panic::catch_unwind(AssertUnwindSafe(|| {
                    session_a.begin_turn().expect("session A begins its turn");
                    let verdict = session_a.validate_input("panic after begin_turn");
                    assert!(
                        verdict.allowed,
                        "session A input validation should complete before panic"
                    );
                    panic!("intentional failure after session A completed an operation");
                }));
                let payload = unwind.expect_err("catch_unwind must observe the injected panic");
                panic::resume_unwind(payload);
            })
        };

        assert!(
            panicking_thread.join().is_err(),
            "the worker thread must report a panic through JoinHandle::join"
        );

        if assert_result_recovers_or_poison(
            session_a.set_variable("counter", json!(62)),
            "session A write after injected panic",
        )
        .is_some()
        {
            let counter_state = session_a
                .read_variable("counter")
                .expect("counter is declared for session A");
            assert_eq!(counter_state.status, VarStatus::Resolved);
            assert_eq!(counter_state.value, json!(62));
            session_a
                .end_turn()
                .expect("observed behavior: the panicked session remains usable after the unwind");
        }

        session_b.begin_turn().expect("session B begins normally");
        let verdict_b = session_b.validate_input("healthy session should continue");
        assert!(verdict_b.allowed, "session B must remain unaffected");
        session_b
            .set_variable("flag", json!(true))
            .expect("session B variable writes must still work");
        assert_eq!(
            session_b
                .read_variable("flag")
                .expect("flag declared")
                .value,
            json!(true)
        );
        session_b.end_turn().expect("session B ends normally");

        let session_c = runtime.new_session(ctx("failure-c"));
        session_c
            .begin_turn()
            .expect("runtime can still create session C");
        let verdict_c = session_c.validate_input("fresh session still works");
        assert!(verdict_c.allowed, "new sessions must still validate input");
        session_c
            .set_variable("counter", json!(3))
            .expect("session C variable writes must succeed");
        assert_eq!(
            session_c
                .read_variable("counter")
                .expect("counter declared")
                .value,
            json!(3)
        );
        session_c.end_turn().expect("session C ends normally");

        assert!(
            counter.count_for("failure-b") > 0,
            "healthy session B should keep emitting observability events"
        );
        assert!(
            counter.count_for("failure-c") > 0,
            "new session C should emit observability events after session A panics"
        );
    });
}

#[test]
fn resolver_panic_recovery() {
    run_with_timeout("resolver_panic_recovery", move || {
        let resolver = Arc::new(PanicOnceHumanResolver::new("resolver-a"));
        let runtime = RuntimeBuilder::from_yaml_strings(&[RESOLVER_PANIC_YAML])
            .expect("yaml loads")
            .register_human_provider("panic_once", resolver)
            .build()
            .expect("runtime builds");

        let session_a = Arc::new(runtime.new_session(ctx("resolver-a")));
        let session_b = runtime.new_session(ctx("resolver-b"));
        let session_c = runtime.new_session(ctx("resolver-c"));

        let resolver_thread = {
            let session_a = session_a.clone();
            thread::spawn(move || {
                let unwind = panic::catch_unwind(AssertUnwindSafe(|| {
                    let _ = session_a.resolve_variable("approval");
                }));
                let payload = unwind.expect_err("resolver path should panic once");
                panic::resume_unwind(payload);
            })
        };

        assert!(
            resolver_thread.join().is_err(),
            "resolver panic must stay isolated to the spawned thread"
        );

        if let Some(value) = assert_caught_recovers_or_poison(
            panic::catch_unwind(AssertUnwindSafe(|| session_a.resolve_variable("approval"))),
            "session A resolver retry after panic",
        ) {
            assert_eq!(
                value,
                Some(json!(true)),
                "once the one-shot panic is exhausted, the resolver path should allow"
            );
            let approval_state = session_a
                .read_variable("approval")
                .expect("approval variable is declared");
            assert_eq!(approval_state.status, VarStatus::Resolved);
            assert_eq!(approval_state.value, json!(true));
        }

        assert_eq!(
            session_b
                .resolve_variable("approval")
                .expect("session B resolve succeeds"),
            Some(json!(true)),
            "other sessions must be unaffected by session A's resolver panic"
        );
        assert_eq!(
            session_c
                .resolve_variable("approval")
                .expect("session C resolve succeeds"),
            Some(json!(true)),
            "the runtime must keep serving brand new sessions after a resolver panic"
        );
    });
}

#[test]
fn observer_panic_isolation() {
    run_with_timeout("observer_panic_isolation", move || {
        let counter = Arc::new(SessionEventCounter::default());
        let runtime = RuntimeBuilder::from_yaml_strings(&[OUTPUT_FAILURE_YAML])
            .expect("yaml loads")
            .register_provider(counter.clone())
            .build()
            .expect("runtime builds");

        let session_a = runtime.new_session(ctx("observer-a"));
        let session_b = runtime.new_session(ctx("observer-b"));
        let session_c = runtime.new_session(ctx("observer-c"));

        let panic_result = panic::catch_unwind(AssertUnwindSafe(|| {
            let mut output = String::from("session A leaked 111-22-3333");
            let _ = session_a.validate_output(&mut output);
            panic!("intentional panic after session A validation completed");
        }));
        assert!(
            panic_result.is_err(),
            "catch_unwind must observe the injected panic"
        );

        let before_b = counter.count_for("observer-b");
        let before_c = counter.count_for("observer-c");

        let mut output_b = String::from("session B leaked 222-33-4444");
        let _ = session_b.validate_output(&mut output_b);
        assert!(
            !output_b.contains("222-33-4444"),
            "session B output should still be sanitized"
        );

        let mut output_c = String::from("session C leaked 333-44-5555");
        let _ = session_c.validate_output(&mut output_c);
        assert!(
            !output_c.contains("333-44-5555"),
            "session C output should still be sanitized"
        );

        let delta_b = counter.count_for("observer-b") - before_b;
        let delta_c = counter.count_for("observer-c") - before_c;
        assert!(
            delta_b > 0 && delta_c > 0,
            "healthy sessions must keep reaching the shared observability system"
        );
        assert_eq!(
            delta_b, delta_c,
            "equivalent healthy validations should emit the same number of observable events"
        );
    });
}

#[test]
fn streaming_processor_panic() {
    run_with_timeout("streaming_processor_panic", move || {
        let counter = Arc::new(SessionEventCounter::default());
        let runtime = RuntimeBuilder::from_yaml_strings(&[OUTPUT_FAILURE_YAML])
            .expect("yaml loads")
            .register_provider(counter.clone())
            .streaming_window(StreamingOptions {
                trigger: StreamingTrigger::PerChunk,
                window_size: 1,
                overlap: 0,
            })
            .build()
            .expect("runtime builds");

        let session_a = runtime.new_session(ctx("stream-a"));
        let session_b = runtime.new_session(ctx("stream-b"));
        session_a
            .begin_turn()
            .expect("session A begins a streaming turn");
        session_b
            .begin_turn()
            .expect("session B begins a streaming turn");

        let mut stream_a = session_a.streaming_session(Stage::Output);
        let first_chunk = panic::catch_unwind(AssertUnwindSafe(|| {
            let _ = stream_a.add_chunk("session A leaked 444-55-6666");
            panic!("intentional panic after the first chunk was processed");
        }));
        assert!(
            first_chunk.is_err(),
            "catch_unwind must observe the injected streaming panic"
        );
        assert_eq!(stream_a.chunks_received(), 1);
        assert!(
            !stream_a.is_ended(),
            "after the unwind the caller still owns a not-yet-ended guard"
        );
        assert!(
            !stream_a.buffer().is_empty(),
            "the buffered chunk should remain inspectable after the panic"
        );

        let finish_a = stream_a.end_stream();
        assert!(matches!(
            finish_a.action,
            StreamChunkAction::Pass | StreamChunkAction::Replace
        ));
        assert!(
            !finish_a.payload.contains("444-55-6666"),
            "finishing the recovered stream should still sanitize buffered content"
        );

        let mut stream_b = session_b.streaming_session(Stage::Output);
        let mid_b = stream_b.add_chunk("session B leaked 555-66-7777");
        assert!(matches!(
            mid_b.action,
            StreamChunkAction::Pass | StreamChunkAction::Replace
        ));
        let finish_b = stream_b.end_stream();
        assert!(matches!(
            finish_b.action,
            StreamChunkAction::Pass | StreamChunkAction::Replace
        ));
        assert!(
            !finish_b.payload.contains("555-66-7777"),
            "other sessions' streams must remain unaffected"
        );

        session_a
            .end_turn()
            .expect("session A can still close the streaming turn");
        session_b.end_turn().expect("session B ends normally");
        assert!(
            counter.count_for("stream-b") > 0,
            "healthy streaming sessions must keep emitting observable events"
        );
    });
}

#[test]
fn poison_clears_across_turns() {
    run_with_timeout("poison_clears_across_turns", move || {
        let runtime = build_runtime(FAILURE_YAML);

        let session_a = runtime.new_session(ctx("turn-poison-a"));
        let session_b = runtime.new_session(ctx("turn-poison-b"));
        session_a.begin_turn().expect("session A begins turn 1");

        let panic_result = panic::catch_unwind(AssertUnwindSafe(|| {
            let verdict = session_a.validate_input("panic before next turn");
            assert!(
                verdict.allowed,
                "input validation should complete before the injected panic"
            );
            panic!("intentional panic before ending turn 1");
        }));
        assert!(
            panic_result.is_err(),
            "catch_unwind must observe the injected panic before the next turn"
        );

        let _ = assert_caught_recovers_or_poison(
            panic::catch_unwind(AssertUnwindSafe(|| session_a.end_turn())),
            "end_turn on a panicked session",
        );

        if let Some(turn_id) = assert_caught_recovers_or_poison(
            panic::catch_unwind(AssertUnwindSafe(|| session_a.begin_turn())),
            "begin_turn after a prior panic",
        ) {
            assert!(
                turn_id >= 2,
                "recovered sessions should advance to a fresh turn"
            );
            let verdict = session_a.validate_input("retry turn after panic");
            assert!(
                verdict.allowed,
                "observed behavior: this runtime lets the session recover across turns"
            );
            session_a
                .end_turn()
                .expect("recovered session should end the retry turn");
        }

        session_b
            .begin_turn()
            .expect("healthy session B begins normally");
        let verdict_b = session_b.validate_input("healthy peer turn");
        assert!(
            verdict_b.allowed,
            "healthy peer sessions must remain unaffected"
        );
        session_b
            .end_turn()
            .expect("healthy session B ends normally");
    });
}
