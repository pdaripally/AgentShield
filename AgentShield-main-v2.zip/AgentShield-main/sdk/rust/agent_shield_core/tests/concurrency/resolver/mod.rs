#![allow(dead_code)]

use std::collections::{HashMap, HashSet};
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::sync::{mpsc, Arc, Barrier};
use std::thread;
use std::time::Duration;

use agent_shield_core::{
    AgentResolveRequest, AgentResolver, GuardrailsRuntime, GuardrailsSession, RequestContext,
    ResolverDecision, ResolverResponse, RuntimeBuilder, VarStatus,
};
use serde_json::{json, Value};

const TEST_TIMEOUT: Duration = Duration::from_secs(60);
const REENTRANCY_ITERS: usize = 5_000;
const RESOLVE_READ_THREADS: usize = 10;
const RESOLVE_READ_ITERS: usize = 1_000;
const RESOLVER_LAST_WRITER_ITERS: usize = 10_000;
const IDENTICAL_RESOLVER_SESSIONS: usize = 10;
const LATE_RESOLVER_ITERS: usize = 2_000;
const CONFLICTING_SET_ITERS: usize = 5_000;
const CYCLE_THREADS: usize = 8;
const CYCLE_ITERS: usize = 100;

const FLAG_VALIDATION_YAML: &str = r#"
metadata:
  name: "concurrency-resolver-flag"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Test resolver safety."]
  forbidden: ["None."]
resources:
  tools:
    - name: "tool_a"
      description: "Test tool."
      permission: "execute"
variables:
  - name: "counter"
    type: "number"
    default: 0
  - name: "flag"
    type: "boolean"
    on_demand_by:
      kind: agent
      prompt: "Resolve flag"
  - name: "data"
    type: "string"
    default: ""
state_validation:
  guard_policies:
    - name: "check_flag"
      applies_to:
        tools: ["tool_a"]
      evaluate_when:
        - expression: "flag == true"
          reason: "Flag not set."
      action: "block"
"#;

const COUNTER_RESOLVER_YAML: &str = r#"
metadata:
  name: "concurrency-resolver-counter"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Test resolver safety."]
  forbidden: ["None."]
resources:
  tools:
    - name: "tool_a"
      description: "Test tool."
      permission: "execute"
variables:
  - name: "counter"
    type: "number"
    on_demand_by:
      kind: agent
      prompt: "Resolve counter"
  - name: "flag"
    type: "boolean"
    default: false
  - name: "data"
    type: "string"
    default: ""
state_validation:
  guard_policies:
    - name: "check_flag"
      applies_to:
        tools: ["tool_a"]
      evaluate_when:
        - expression: "flag == true"
          reason: "Flag not set."
      action: "block"
"#;

const DATA_RESOLVER_YAML: &str = r#"
metadata:
  name: "concurrency-resolver-data"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Test resolver safety."]
  forbidden: ["None."]
resources:
  tools:
    - name: "tool_a"
      description: "Test tool."
      permission: "execute"
variables:
  - name: "counter"
    type: "number"
    default: 0
  - name: "flag"
    type: "boolean"
    default: false
  - name: "data"
    type: "string"
    on_demand_by:
      kind: agent
      prompt: "Resolve data"
state_validation:
  guard_policies:
    - name: "check_flag"
      applies_to:
        tools: ["tool_a"]
      evaluate_when:
        - expression: "flag == true"
          reason: "Flag not set."
      action: "block"
"#;

const CYCLIC_RESOLVER_YAML: &str = r#"
metadata:
  name: "concurrency-resolver-cycle"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Test resolver safety."]
  forbidden: ["None."]
variables:
  - name: "a"
    type: "boolean"
    on_demand_by:
      kind: expression
      expression: "b"
  - name: "b"
    type: "boolean"
    on_demand_by:
      kind: expression
      expression: "a"
"#;

fn build_runtime(yaml: &str) -> Arc<GuardrailsRuntime> {
    RuntimeBuilder::from_yaml_strings(&[yaml])
        .expect("yaml loads")
        .supports_context_reset(true)
        .build()
        .expect("runtime builds")
}

fn build_runtime_with_agent_resolver<R>(yaml: &str, resolver: Arc<R>) -> Arc<GuardrailsRuntime>
where
    R: AgentResolver + 'static,
{
    RuntimeBuilder::from_yaml_strings(&[yaml])
        .expect("yaml loads")
        .supports_context_reset(true)
        .register_agent_resolver(resolver)
        .build()
        .expect("runtime builds")
}

fn new_session(runtime: &Arc<GuardrailsRuntime>, label: &str) -> Arc<GuardrailsSession> {
    Arc::new(runtime.new_session(RequestContext::new(
        format!("resolver-session-{label}"),
        format!("resolver-corr-{label}"),
    )))
}

fn run_with_timeout<F>(name: &'static str, f: F)
where
    F: FnOnce() + Send + 'static,
{
    let (tx, rx) = mpsc::sync_channel(1);
    let handle = thread::spawn(move || {
        let result = catch_unwind(AssertUnwindSafe(f));
        let _ = tx.send(result);
    });

    match rx.recv_timeout(TEST_TIMEOUT) {
        Ok(Ok(())) => {
            handle
                .join()
                .expect("timeout worker thread should join cleanly");
        }
        Ok(Err(payload)) => {
            handle
                .join()
                .expect("panic worker thread should join cleanly");
            std::panic::resume_unwind(payload);
        }
        Err(mpsc::RecvTimeoutError::Timeout) => {
            panic!("{name} exceeded {:?}", TEST_TIMEOUT);
        }
        Err(err) => {
            panic!("{name} did not report completion: {err}");
        }
    }
}

fn allow_value(value: Value) -> ResolverResponse {
    ResolverResponse {
        decision: ResolverDecision::Allow,
        value: Some(value),
        set_variables: HashMap::new(),
        reason: None,
    }
}

struct FixedResolver {
    value: Value,
}

impl FixedResolver {
    fn new(value: Value) -> Self {
        Self { value }
    }
}

impl AgentResolver for FixedResolver {
    fn resolve(&self, _req: AgentResolveRequest) -> ResolverResponse {
        allow_value(self.value.clone())
    }
}

struct GateResolver {
    value: Value,
    entered: AtomicUsize,
    block: AtomicBool,
}

impl GateResolver {
    fn new(value: Value) -> Self {
        Self {
            value,
            entered: AtomicUsize::new(0),
            block: AtomicBool::new(false),
        }
    }

    fn entered(&self) -> usize {
        self.entered.load(Ordering::SeqCst)
    }

    fn block_next(&self) {
        self.block.store(true, Ordering::SeqCst);
    }

    fn release(&self) {
        self.block.store(false, Ordering::SeqCst);
    }
}

impl AgentResolver for GateResolver {
    fn resolve(&self, _req: AgentResolveRequest) -> ResolverResponse {
        self.entered.fetch_add(1, Ordering::SeqCst);
        while self.block.load(Ordering::SeqCst) {
            thread::yield_now();
        }
        allow_value(self.value.clone())
    }
}

struct PanickingResolver;

impl AgentResolver for PanickingResolver {
    fn resolve(&self, _req: AgentResolveRequest) -> ResolverResponse {
        panic!("intentional resolver panic")
    }
}

struct RequestIdResolver;

impl AgentResolver for RequestIdResolver {
    fn resolve(&self, req: AgentResolveRequest) -> ResolverResponse {
        allow_value(json!(req.request_id))
    }
}

fn assert_runtime_and_session_send_sync() {
    fn assert_send_sync<T: Send + Sync>() {}
    assert_send_sync::<GuardrailsRuntime>();
    assert_send_sync::<GuardrailsSession>();
}

#[test]
fn resolver_set_variable_reentrancy() {
    run_with_timeout("resolver_set_variable_reentrancy", move || {
        let resolver = Arc::new(GateResolver::new(json!(true)));
        let runtime = build_runtime_with_agent_resolver(FLAG_VALIDATION_YAML, resolver.clone());

        for iter in 0..REENTRANCY_ITERS {
            let session = new_session(&runtime, &format!("reentrancy-{iter}"));
            let entered_before = resolver.entered();
            resolver.block_next();

            let validate_session = session.clone();
            let validate = thread::spawn(move || {
                let mut params = json!({"iteration": iter as i64});
                validate_session.validate_tool_call("tool_a", &mut params, &format!("call-{iter}"))
            });

            while resolver.entered() == entered_before {
                thread::yield_now();
            }

            let write_session = session.clone();
            let writer = thread::spawn(move || {
                write_session
                    .set_variable("flag", json!(true))
                    .expect("concurrent flag write succeeds");
            });

            writer.join().expect("writer thread should not panic");
            resolver.release();

            let verdict = validate.join().expect("validation thread should not panic");
            assert!(
                verdict.allowed,
                "validation should admit once flag resolves"
            );

            let state = session.read_variable("flag").expect("flag declared");
            assert_eq!(state.status, VarStatus::Resolved);
            assert_eq!(state.value, json!(true));
        }
    });
}

#[test]
fn resolver_read_variable_concurrent() {
    run_with_timeout("resolver_read_variable_concurrent", move || {
        let runtime = build_runtime_with_agent_resolver(
            COUNTER_RESOLVER_YAML,
            Arc::new(FixedResolver::new(json!(7))),
        );
        let session = new_session(&runtime, "resolve-read");
        let start = Arc::new(Barrier::new(RESOLVE_READ_THREADS));

        let handles: Vec<_> = (0..RESOLVE_READ_THREADS)
            .map(|thread_index| {
                let session = session.clone();
                let start = start.clone();
                thread::spawn(move || {
                    start.wait();
                    for iter in 0..RESOLVE_READ_ITERS {
                        let value = session
                            .resolve_variable("counter")
                            .expect("resolve_variable should succeed");
                        assert_eq!(
                            value,
                            Some(json!(7)),
                            "thread {thread_index} iteration {iter} observed an inconsistent value"
                        );
                    }
                })
            })
            .collect();

        for handle in handles {
            handle
                .join()
                .expect("resolver read thread should not panic");
        }

        let state = session.read_variable("counter").expect("counter declared");
        assert_eq!(state.status, VarStatus::Resolved);
        assert_eq!(state.value, json!(7));
    });
}

#[test]
fn resolver_spawns_thread() {
    run_with_timeout("resolver_spawns_thread", move || {
        let resolver = Arc::new(GateResolver::new(json!("resolver")));
        let runtime = build_runtime_with_agent_resolver(DATA_RESOLVER_YAML, resolver.clone());

        for iter in 0..RESOLVER_LAST_WRITER_ITERS {
            let session = new_session(&runtime, &format!("spawn-{iter}"));
            let entered_before = resolver.entered();
            resolver.block_next();

            let resolve_session = session.clone();
            let resolve_thread = thread::spawn(move || {
                resolve_session
                    .resolve_variable("data")
                    .expect("resolve_variable should succeed")
            });

            while resolver.entered() == entered_before {
                thread::yield_now();
            }

            session
                .set_variable("data", json!("writer"))
                .expect("writer update should succeed");
            resolver.release();

            let resolved = resolve_thread
                .join()
                .expect("resolver thread should not panic");
            assert_eq!(resolved, Some(json!("resolver")));

            let state = session.read_variable("data").expect("data declared");
            assert_eq!(state.status, VarStatus::Resolved);
            assert_eq!(
                state.value,
                json!("resolver"),
                "resolver completion should win when it is released after the host write"
            );
        }
    });
}

#[test]
fn panicking_resolver_recovery() {
    run_with_timeout("panicking_resolver_recovery", move || {
        let runtime =
            build_runtime_with_agent_resolver(COUNTER_RESOLVER_YAML, Arc::new(PanickingResolver));
        let session = new_session(&runtime, "panic-recovery");

        let unwind = catch_unwind(AssertUnwindSafe(|| {
            let _ = session.resolve_variable("counter");
        }));
        assert!(
            unwind.is_err(),
            "resolver panic should unwind into the caller"
        );

        session
            .set_variable("data", json!("still-usable"))
            .expect("session should remain writable after resolver panic");
        let data = session.read_variable("data").expect("data declared");
        assert_eq!(data.status, VarStatus::Resolved);
        assert_eq!(data.value, json!("still-usable"));

        session
            .set_variable("flag", json!(true))
            .expect("session should remain usable for subsequent writes");
        let flag = session.read_variable("flag").expect("flag declared");
        assert_eq!(flag.value, json!(true));
    });
}

#[test]
fn send_sync_bounds_compile_test() {
    assert_runtime_and_session_send_sync();
}

#[test]
fn concurrent_identical_resolver() {
    run_with_timeout("concurrent_identical_resolver", move || {
        let runtime =
            build_runtime_with_agent_resolver(DATA_RESOLVER_YAML, Arc::new(RequestIdResolver));
        let start = Arc::new(Barrier::new(IDENTICAL_RESOLVER_SESSIONS));

        let handles: Vec<_> = (0..IDENTICAL_RESOLVER_SESSIONS)
            .map(|index| {
                let runtime = runtime.clone();
                let start = start.clone();
                thread::spawn(move || {
                    let label = format!("shared-runtime-{index}");
                    let expected = json!(format!("resolver-corr-{label}-0"));
                    let session = new_session(&runtime, &label);
                    start.wait();
                    let value = session
                        .resolve_variable("data")
                        .expect("resolve_variable should succeed");
                    assert_eq!(value, Some(expected.clone()));
                    let state = session.read_variable("data").expect("data declared");
                    assert_eq!(state.status, VarStatus::Resolved);
                    assert_eq!(state.value, expected.clone());
                    state.value
                })
            })
            .collect();

        let values: Vec<Value> = handles
            .into_iter()
            .map(|handle| handle.join().expect("session thread should not panic"))
            .collect();

        let unique: HashSet<_> = values.iter().cloned().collect();
        assert_eq!(unique.len(), IDENTICAL_RESOLVER_SESSIONS);
    });
}

#[test]
fn late_resolver_vs_variable_set() {
    run_with_timeout("late_resolver_vs_variable_set", move || {
        let resolver = Arc::new(GateResolver::new(json!("resolver")));
        let runtime = build_runtime_with_agent_resolver(DATA_RESOLVER_YAML, resolver.clone());
        let mut saw_resolver = false;
        let mut saw_writer = false;

        for iter in 0..LATE_RESOLVER_ITERS {
            let session = new_session(&runtime, &format!("late-{iter}"));
            let entered_before = resolver.entered();
            let expect_resolver = iter % 2 == 0;
            if expect_resolver {
                resolver.block_next();
            } else {
                resolver.release();
            }

            let resolve_session = session.clone();
            let resolver_thread = thread::spawn(move || {
                resolve_session
                    .resolve_variable("data")
                    .expect("resolve_variable should succeed")
            });

            while resolver.entered() == entered_before {
                thread::yield_now();
            }

            let write_session = session.clone();
            let expect_resolver_w = expect_resolver;
            let writer_thread = thread::spawn(move || {
                if !expect_resolver_w {
                    // Give the unblocked resolver enough time to complete under CI load.
                    thread::sleep(Duration::from_millis(5));
                }
                write_session
                    .set_variable("data", json!("writer"))
                    .expect("writer update should succeed");
            });

            writer_thread
                .join()
                .expect("writer thread should not panic");
            if expect_resolver {
                resolver.release();
            }

            let _ = resolver_thread
                .join()
                .expect("resolver thread should not panic");

            let state = session.read_variable("data").expect("data declared");
            assert_eq!(state.status, VarStatus::Resolved);
            if expect_resolver {
                assert_eq!(state.value, json!("resolver"));
                saw_resolver = true;
            } else {
                assert_eq!(state.value, json!("writer"));
                saw_writer = true;
            }
        }

        assert!(saw_resolver, "resolver should win at least one late race");
        assert!(saw_writer, "host write should win at least one late race");
    });
}

#[test]
fn conflicting_set_variables_concurrent() {
    run_with_timeout("conflicting_set_variables_concurrent", move || {
        let runtime = build_runtime(DATA_RESOLVER_YAML);

        for iter in 0..CONFLICTING_SET_ITERS {
            let session = new_session(&runtime, &format!("conflicting-set-{iter}"));
            let start = Arc::new(Barrier::new(2));

            let left_session = session.clone();
            let left_start = start.clone();
            let left = thread::spawn(move || {
                left_start.wait();
                left_session
                    .set_variable("data", json!("left"))
                    .expect("left write should succeed");
            });

            let right_session = session.clone();
            let right_start = start.clone();
            let right = thread::spawn(move || {
                right_start.wait();
                right_session
                    .set_variable("data", json!("right"))
                    .expect("right write should succeed");
            });

            left.join().expect("left writer should not panic");
            right.join().expect("right writer should not panic");

            let state = session.read_variable("data").expect("data declared");
            assert_eq!(state.status, VarStatus::Resolved);
            assert!(
                state.value == json!("left") || state.value == json!("right"),
                "final value must be one of the two writes, got {:?}",
                state.value
            );
        }
    });
}

#[test]
fn cycle_detection_concurrent() {
    run_with_timeout("cycle_detection_concurrent", move || {
        // Public API rejects resolver cycles at load/build time, so the concurrency
        // coverage here stress-tests that detector under simultaneous builders.
        let start = Arc::new(Barrier::new(CYCLE_THREADS));
        let handles: Vec<_> = (0..CYCLE_THREADS)
            .map(|thread_index| {
                let start = start.clone();
                thread::spawn(move || {
                    start.wait();
                    for iter in 0..CYCLE_ITERS {
                        let err = RuntimeBuilder::from_yaml_strings(&[CYCLIC_RESOLVER_YAML])
                            .expect_err("cyclic resolver graph should be rejected");
                        let message = err.to_string();
                        assert!(
                            message.contains("cycle") || message.contains("ResolverCycle"),
                            "thread {thread_index} iteration {iter} expected a cycle error, got {message}"
                        );
                    }
                })
            })
            .collect();

        for handle in handles {
            handle.join().expect("cycle worker should not panic");
        }
    });
}
