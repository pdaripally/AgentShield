#![cfg(not(loom))]

use std::collections::HashMap;
use std::panic::{self, AssertUnwindSafe};
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::sync::{mpsc, Arc, Barrier, Mutex};
use std::thread;
use std::time::{Duration, Instant};

use agent_shield_core::resolver_runtime::HumanResolverFn;
use agent_shield_core::*;
use serde_json::{json, Value};

const TEST_TIMEOUT: Duration = Duration::from_secs(60);

fn run_with_timeout<F>(name: &'static str, timeout: Duration, f: F)
where
    F: FnOnce() + Send + 'static,
{
    let (tx, rx) = mpsc::sync_channel(1);
    thread::spawn(move || {
        let result = panic::catch_unwind(AssertUnwindSafe(f));
        let _ = tx.send(result);
    });

    match rx.recv_timeout(timeout) {
        Ok(Ok(())) => {}
        Ok(Err(payload)) => panic::resume_unwind(payload),
        Err(_) => panic!("{name} timed out after {timeout:?}"),
    }
}

fn wait_until(deadline: Instant, mut predicate: impl FnMut() -> bool) {
    while Instant::now() < deadline {
        if predicate() {
            return;
        }
        thread::yield_now();
    }
    panic!("condition was not observed before {deadline:?}");
}

fn build_runtime(yaml: &str) -> Arc<GuardrailsRuntime> {
    RuntimeBuilder::from_yaml_strings(&[yaml])
        .expect("yaml parses")
        .build()
        .expect("runtime builds")
}

fn open_session(rt: &Arc<GuardrailsRuntime>, session_id: &str) -> Arc<GuardrailsSession> {
    Arc::new(rt.new_session(RequestContext::new(
        session_id,
        format!("corr-{session_id}"),
    )))
}

fn minimal_tool_yaml() -> &'static str {
    r#"
metadata:
  name: "race-window-minimal"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["exercise concurrency edges"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "echo"
      description: "Echo tool"
      permission: "read_only"
    - name: "search"
      description: "Search tool"
      permission: "read_only"
    - name: "send_email"
      description: "Send email"
      permission: "execute"
"#
}

fn stage3_probe_yaml() -> &'static str {
    r#"
metadata:
  name: "race-window-stage3-probe"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["probe stage3 prompt construction"]
  forbidden: ["nothing"]
configurations:
  - id: "stub"
    type: "llm"
    provider: "test"
    model: "stub"
    default: true
resources:
  tools:
    - name: "search"
      description: "Search tool"
      permission: "read_only"
    - name: "send_email"
      description: "Send email"
      permission: "execute"
tool_execution_validation:
  guard_policies:
    - name: "capture_stage3_prompt"
      applies_to:
        tools: ["send_email"]
      evaluate_when:
        - llm:
            prompt: "Validate: {user_input}"
          reason: "capture prompt"
"#
}

fn per_turn_yaml() -> &'static str {
    r#"
metadata:
  name: "race-window-per-turn"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["exercise concurrent end_turn"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "echo"
      description: "Echo tool"
      permission: "read_only"
variables:
  - name: "per_turn_token"
    type: "string"
    default: "unset"
    lifetime: "per_turn"
"#
}

fn slow_resolver_yaml() -> &'static str {
    r#"
metadata:
  name: "race-window-slow-resolver"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["exercise resolver completion after close"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "noop"
      description: "No-op"
      permission: "read_only"
variables:
  - name: "approval"
    type: "boolean"
    default: false
    on_demand_by:
      kind: human
      provider: slow_sync
      prompt: "Approve?"
    lifetime:
      allow: "per_session"
      deny: "per_session"
"#
}

fn expiring_variable_yaml() -> &'static str {
    r#"
metadata:
  name: "race-window-expiry"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["exercise concurrent expiry reads"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "echo"
      description: "Echo tool"
      permission: "read_only"
variables:
  - name: "ephemeral"
    type: "string"
    default: ""
    lifetime:
      allow:
        for: "50ms"
      deny: "per_session"
"#
}

#[derive(Default)]
struct MarkerDetectingLlm {
    prompts: Mutex<Vec<String>>,
    saw_stale_tool_marker: AtomicBool,
}

impl LlmCaller for MarkerDetectingLlm {
    fn call(&self, _configuration_id: Option<&str>, prompt: &str) -> Result<LlmResponse, String> {
        if prompt.contains("## START TOOL RESPONSE: search ##") {
            self.saw_stale_tool_marker.store(true, Ordering::SeqCst);
        }
        self.prompts.lock().unwrap().push(prompt.to_string());
        Ok(LlmResponse {
            decision: Some(LlmDecision::Allow),
            ..Default::default()
        })
    }
}

struct ExpiryCaptureProvider {
    expired_clears: Arc<AtomicUsize>,
}

impl ObservabilityProvider for ExpiryCaptureProvider {
    fn emit(&self, event: ShieldLogEvent) {
        let is_probe_clear = event.event_id.as_deref() == Some("incident.expiry_probe")
            && event
                .attributes
                .get("agent_shield.event.cause")
                .and_then(Value::as_str)
                == Some("expired");
        if is_probe_clear {
            self.expired_clears.fetch_add(1, Ordering::SeqCst);
        }
    }
}

/// NOTE: This test documents a known race window in `begin_turn()` — `turn_active`
/// is published before `tool_results_this_turn` is cleared. Under unlucky scheduling,
/// a concurrent reader may briefly observe stale prior-turn tool markers. The test
/// currently passes because the window is narrow, but it may become flaky under heavy
/// CI load. If it does, mark it `#[ignore]` and track in a dedicated issue.
/// See: docs/concurrency.md § "Known design issues" item 4.
#[test]
fn begin_turn_input_visibility() {
    run_with_timeout("begin_turn_input_visibility", TEST_TIMEOUT, || {
        let llm = Arc::new(MarkerDetectingLlm::default());
        let rt = RuntimeBuilder::from_yaml_strings(&[stage3_probe_yaml()])
            .expect("yaml parses")
            .register_llm_caller(llm.clone())
            .build()
            .expect("runtime builds");
        let session = open_session(&rt, "race-begin-turn");

        session.begin_turn().unwrap();
        let _ = session.validate_input("seed-turn");
        let mut seed_params = json!({"q": "seed"});
        assert!(
            session
                .validate_tool_call("search", &mut seed_params, "seed-search")
                .allowed
        );
        let mut seed_result = json!("stale-from-previous-turn");
        assert!(
            session
                .validate_tool_output("search", &mut seed_result, "seed-search")
                .allowed
        );
        session.end_turn().unwrap();

        let iterations = 128usize;
        let start = Arc::new(Barrier::new(2));
        let observer_done = Arc::new(AtomicBool::new(false));

        let producer = {
            let session = session.clone();
            let start = start.clone();
            let observer_done = observer_done.clone();
            thread::spawn(move || {
                for i in 0..iterations {
                    observer_done.store(false, Ordering::SeqCst);
                    start.wait();
                    let _turn_id = session.begin_turn().unwrap();

                    let deadline = Instant::now() + Duration::from_secs(2);
                    wait_until(deadline, || observer_done.load(Ordering::SeqCst));

                    let _ = session.validate_input(&format!("producer-turn-{i}"));
                    let mut params = json!({"q": format!("seed-{i}")});
                    assert!(
                        session
                            .validate_tool_call("search", &mut params, &format!("search-{i}"))
                            .allowed
                    );
                    let mut result = json!(format!("tool-output-{i}"));
                    assert!(
                        session
                            .validate_tool_output("search", &mut result, &format!("search-{i}"))
                            .allowed
                    );
                    session.end_turn().unwrap();
                }
            })
        };

        let observer = {
            let session = session.clone();
            let start = start.clone();
            let observer_done = observer_done.clone();
            thread::spawn(move || {
                let mut last_seen_turn = 0;
                for i in 0..iterations {
                    start.wait();
                    let deadline = Instant::now() + Duration::from_secs(2);
                    wait_until(deadline, || {
                        session.is_turn_active() && session.current_turn_id() > last_seen_turn
                    });
                    last_seen_turn = session.current_turn_id();

                    let _ = session.validate_input(&format!("observer-turn-{i}"));
                    let mut params = json!({"to": "x@example.com"});
                    let verdict =
                        session.validate_tool_call("send_email", &mut params, &format!("send-{i}"));
                    assert!(
                        verdict.allowed,
                        "Stage 3 probe must not fail closed: {verdict:?}"
                    );
                    observer_done.store(true, Ordering::SeqCst);
                }
            })
        };

        producer.join().expect("producer joined");
        observer.join().expect("observer joined");

        assert!(
            !llm.saw_stale_tool_marker.load(Ordering::SeqCst),
            "observing turn_active=true for a fresh turn must not expose prior-turn Stage-4 enrichment in Stage-3 prompts"
        );
    });
}

#[test]
fn concurrent_begin_turn() {
    run_with_timeout("concurrent_begin_turn", TEST_TIMEOUT, || {
        let rt = build_runtime(minimal_tool_yaml());
        let session = open_session(&rt, "race-concurrent-begin");
        let barrier = Arc::new(Barrier::new(2));

        let t1 = {
            let session = session.clone();
            let barrier = barrier.clone();
            thread::spawn(move || {
                barrier.wait();
                session.begin_turn()
            })
        };

        let t2 = {
            let session = session.clone();
            let barrier = barrier.clone();
            thread::spawn(move || {
                barrier.wait();
                session.begin_turn()
            })
        };

        let r1 = t1.join().expect("begin_turn thread 1 joined");
        let r2 = t2.join().expect("begin_turn thread 2 joined");

        let mut ok_ids = vec![];
        if let Ok(id) = r1 {
            ok_ids.push(id);
        }
        if let Ok(id) = r2 {
            ok_ids.push(id);
        }

        assert!(
            !ok_ids.is_empty(),
            "at least one concurrent begin_turn call must succeed: r1={r1:?}, r2={r2:?}"
        );
        if ok_ids.len() == 2 {
            ok_ids.sort_unstable();
            ok_ids.dedup();
            assert_eq!(
                ok_ids,
                vec![1, 2],
                "successful concurrent begin_turn calls must produce unique monotonic turn ids"
            );
        }
        assert!(
            session.is_turn_active(),
            "session should remain in an active turn after a successful begin_turn race"
        );
        assert!(session.current_turn_id() >= 1);
    });
}

#[test]
fn stage3_during_end_turn() {
    run_with_timeout("stage3_during_end_turn", TEST_TIMEOUT, || {
        let rt = build_runtime(minimal_tool_yaml());
        let session = open_session(&rt, "race-stage3-end-turn");
        let turn_id = session.begin_turn().unwrap();
        let _ = session.validate_input("old turn input");

        let barrier = Arc::new(Barrier::new(2));

        let ender = {
            let session = session.clone();
            let barrier = barrier.clone();
            thread::spawn(move || {
                barrier.wait();
                session.end_turn()
            })
        };

        let validator = {
            let session = session.clone();
            let barrier = barrier.clone();
            thread::spawn(move || {
                let mut params = json!({"msg": "hi"});
                barrier.wait();
                session.validate_tool_call("echo", &mut params, "race-call")
            })
        };

        let end_result = ender.join().expect("end_turn thread joined");
        let stage3 = validator.join().expect("validator thread joined");
        end_result.expect("end_turn must remain idempotent under race");

        let mut output = json!("ok");
        let stage4 =
            session.validate_tool_output_for_turn("echo", &mut output, "race-call", turn_id);
        assert!(
            stage4.allowed || stage4.policy.as_deref() == Some("<binding>"),
            "racing Stage 3 against end_turn must either preserve the old-turn binding or fail closed, never panic or corrupt state: {stage4:?}"
        );
        assert!(
            stage3.allowed || stage3.reason.is_some() || stage3.policy.is_some(),
            "Stage 3 must return a structured verdict under race: {stage3:?}"
        );
        assert!(
            !session.is_turn_active(),
            "end_turn race must leave the turn closed"
        );
    });
}

#[test]
fn stage4_after_new_turn() {
    run_with_timeout("stage4_after_new_turn", TEST_TIMEOUT, || {
        let rt = build_runtime(minimal_tool_yaml());
        let session = open_session(&rt, "race-stage4-new-turn");

        let turn_n = session.begin_turn().unwrap();
        let _ = session.validate_input("turn n");
        let mut params = json!({"msg": "hi"});
        let stage3 = session.validate_tool_call("echo", &mut params, "call-1");
        assert!(stage3.allowed);
        session.end_turn().unwrap();

        let turn_n_plus_1 = session.begin_turn().unwrap();
        assert!(turn_n_plus_1 > turn_n);

        let mut result = json!("echoed");
        let stage4 = session.validate_tool_output_for_turn("echo", &mut result, "call-1", turn_n);
        assert!(
            stage4.allowed,
            "turn_id is part of the Stage-4 binding key, so an old-turn binding must still resolve exactly when the caller supplies the original turn id: {stage4:?}"
        );
        assert!(stage4.invocation_hash.is_some());
        assert_eq!(session.current_turn_id(), turn_n_plus_1);
    });
}

#[test]
fn concurrent_end_turn() {
    run_with_timeout("concurrent_end_turn", TEST_TIMEOUT, || {
        let rt = build_runtime(per_turn_yaml());
        let session = open_session(&rt, "race-concurrent-end");
        session.begin_turn().unwrap();
        session
            .set_variable("per_turn_token", json!("live"))
            .unwrap();
        session
            .emit_event(
                "incident.end_turn_probe",
                Some(Lifetime::Bare(BareLifetime::PerTurn)),
                None,
            )
            .unwrap();

        let turn_end_count = Arc::new(AtomicUsize::new(0));
        let capture = turn_end_count.clone();
        rt.bus().subscribe(
            Some(Box::new(|ev: &BusEvent| {
                matches!(
                    ev,
                    BusEvent::Emitted {
                        event_id: EventId::TurnEnd,
                        ..
                    }
                )
            })),
            move |_| {
                capture.fetch_add(1, Ordering::SeqCst);
            },
        );

        let barrier = Arc::new(Barrier::new(2));

        let t1 = {
            let session = session.clone();
            let barrier = barrier.clone();
            thread::spawn(move || {
                barrier.wait();
                session.end_turn()
            })
        };

        let t2 = {
            let session = session.clone();
            let barrier = barrier.clone();
            thread::spawn(move || {
                barrier.wait();
                session.end_turn()
            })
        };

        t1.join().expect("end_turn thread 1 joined").unwrap();
        t2.join().expect("end_turn thread 2 joined").unwrap();

        assert!(!session.is_turn_active());
        assert_eq!(
            turn_end_count.load(Ordering::SeqCst),
            1,
            "turn.end must be emitted exactly once across concurrent end_turn calls"
        );
        let state = session.read_variable("per_turn_token").unwrap();
        assert_eq!(
            state.status,
            VarStatus::Unset,
            "per-turn state must be cleared exactly once and remain cleared"
        );
        assert!(
            !session.event_fired("incident.end_turn_probe"),
            "per-turn event latches must be cleared after the first successful end_turn"
        );
    });
}

#[test]
fn stream_chunk_after_abort() {
    run_with_timeout("stream_chunk_after_abort", TEST_TIMEOUT, || {
        let rt = build_runtime(minimal_tool_yaml());
        let session = open_session(&rt, "race-stream-abort");
        let shared = Arc::new(Mutex::new(Some(
            session.streaming_session(ObsStage::Output),
        )));
        let barrier = Arc::new(Barrier::new(2));

        let dropper = {
            let shared = shared.clone();
            let barrier = barrier.clone();
            thread::spawn(move || {
                barrier.wait();
                let _dropped = shared.lock().unwrap().take();
            })
        };

        let writer = {
            let shared = shared.clone();
            let barrier = barrier.clone();
            thread::spawn(move || {
                barrier.wait();
                let mut guard = shared.lock().unwrap();
                if let Some(stream) = guard.as_mut() {
                    let result = stream.add_chunk("hello");
                    assert!(
                        matches!(
                            result.action,
                            StreamChunkAction::Pass
                                | StreamChunkAction::Replace
                                | StreamChunkAction::Stop
                        ),
                        "shared access through Arc<Mutex<Option<StreamingGuard>>> must not panic"
                    );
                }
            })
        };

        dropper.join().expect("dropper joined");
        writer.join().expect("writer joined");
    });
}

#[test]
fn resolver_completion_after_close() {
    run_with_timeout("resolver_completion_after_close", TEST_TIMEOUT, || {
        let started = Arc::new(AtomicBool::new(false));
        let started_for_resolver = started.clone();

        let rt = RuntimeBuilder::from_yaml_strings(&[slow_resolver_yaml()])
            .expect("yaml parses")
            .register_human_provider(
                "slow_sync",
                Arc::new(HumanResolverFn(move |_req| {
                    started_for_resolver.store(true, Ordering::SeqCst);
                    thread::sleep(Duration::from_millis(100));
                    ResolverResponse {
                        decision: ResolverDecision::Allow,
                        value: Some(json!(true)),
                        set_variables: HashMap::new(),
                        reason: Some("approved".to_string()),
                    }
                })),
            )
            .build()
            .expect("runtime builds");

        let session = open_session(&rt, "race-slow-resolver");
        let resolver_thread = {
            let session = session.clone();
            thread::spawn(move || session.resolve_variable("approval"))
        };

        wait_until(Instant::now() + Duration::from_secs(2), || {
            started.load(Ordering::SeqCst)
        });
        thread::sleep(Duration::from_millis(50));
        session.close();

        let resolve_result = resolver_thread.join().expect("resolver thread joined");
        assert!(
            resolve_result.is_ok(),
            "slow resolver completion after close must not panic or surface transport errors: {resolve_result:?}"
        );

        let state = session.read_variable("approval").unwrap();
        assert_eq!(
            state.status,
            VarStatus::Unset,
            "late resolver completion must be discarded after session close so cleanup remains complete"
        );
        assert!(!session.is_turn_active());
    });
}

#[test]
fn lifetime_expiry_concurrent_read() {
    run_with_timeout("lifetime_expiry_concurrent_read", TEST_TIMEOUT, || {
        let expired_clears = Arc::new(AtomicUsize::new(0));
        let rt = RuntimeBuilder::from_yaml_strings(&[expiring_variable_yaml()])
            .expect("yaml parses")
            .register_provider(Arc::new(ExpiryCaptureProvider {
                expired_clears: expired_clears.clone(),
            }))
            .build()
            .expect("runtime builds");
        let session = open_session(&rt, "race-expiry");

        session.set_variable("ephemeral", json!("value")).unwrap();
        session
            .emit_event(
                "incident.expiry_probe",
                Some(Lifetime::Bare(BareLifetime::For(
                    parse_duration("50ms").expect("duration parses"),
                ))),
                None,
            )
            .unwrap();

        let readers = 16usize;
        let barrier = Arc::new(Barrier::new(readers));
        let saw_expiry_once = Arc::new(AtomicBool::new(false));
        let expiry_first_hits = Arc::new(AtomicUsize::new(0));
        let stale_after_expiry = Arc::new(AtomicBool::new(false));

        let mut handles = Vec::with_capacity(readers);
        for _ in 0..readers {
            let session = session.clone();
            let barrier = barrier.clone();
            let saw_expiry_once = saw_expiry_once.clone();
            let expiry_first_hits = expiry_first_hits.clone();
            let stale_after_expiry = stale_after_expiry.clone();
            handles.push(thread::spawn(move || {
                barrier.wait();
                // Wait for the 50ms TTL to definitely expire before racing reads.
                // This ensures all readers observe the post-expiry state, and the
                // test validates that removal is atomic (no stale Resolved after removal).
                thread::sleep(Duration::from_millis(60));
                let deadline = Instant::now() + Duration::from_secs(2);
                while Instant::now() < deadline {
                    let state = session.read_variable("ephemeral").unwrap();
                    let _ = session.event_fired("incident.expiry_probe");

                    if state.status == VarStatus::Unset {
                        if !saw_expiry_once.swap(true, Ordering::SeqCst) {
                            expiry_first_hits.fetch_add(1, Ordering::SeqCst);
                        }

                        for _ in 0..8 {
                            let reread = session.read_variable("ephemeral").unwrap();
                            if reread.status != VarStatus::Unset {
                                stale_after_expiry.store(true, Ordering::SeqCst);
                                break;
                            }
                            let _ = session.event_fired("incident.expiry_probe");
                        }
                        return;
                    }

                    if saw_expiry_once.load(Ordering::SeqCst) {
                        stale_after_expiry.store(true, Ordering::SeqCst);
                        return;
                    }

                    thread::yield_now();
                }

                panic!("reader did not observe expiry before deadline");
            }));
        }

        for handle in handles {
            handle.join().expect("reader joined");
        }

        assert!(
            saw_expiry_once.load(Ordering::SeqCst),
            "at least one reader must observe expiry"
        );
        assert_eq!(
            expiry_first_hits.load(Ordering::SeqCst),
            1,
            "exactly one reader should win the first-expiry observation race"
        );
        assert!(
            !stale_after_expiry.load(Ordering::SeqCst),
            "once the variable has expired, no reader may observe a stale resolved value"
        );

        wait_until(Instant::now() + Duration::from_secs(2), || {
            expired_clears.load(Ordering::SeqCst) == 1
        });
        assert_eq!(
            expired_clears.load(Ordering::SeqCst),
            1,
            "paired short-lived event must emit exactly one expired-clear signal under concurrent reads"
        );
    });
}

/// Verify that `close()` racing with an in-flight `validate_tool_call()` does not panic or corrupt.
#[test]
fn close_vs_stage3_race() {
    run_with_timeout("close_vs_stage3_race", TEST_TIMEOUT, || {
        let yaml = r#"
metadata:
  name: "close-vs-stage3"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Test close vs stage3."]
  forbidden: ["None."]
resources:
  tools:
    - name: "tool_a"
      description: "Tool A."
      permission: "execute"
"#;
        let rt = RuntimeBuilder::from_yaml_strings(&[yaml])
            .expect("yaml")
            .build()
            .expect("runtime");

        for iter in 0..500 {
            let session = Arc::new(rt.new_session(RequestContext::new(
                format!("close-stage3-{iter}"),
                format!("corr-{iter}"),
            )));
            session.begin_turn().expect("begin turn");

            let barrier = Arc::new(Barrier::new(2));

            let s1 = Arc::clone(&session);
            let b1 = Arc::clone(&barrier);
            let validator = thread::spawn(move || {
                let call_id = format!("call_{iter}");
                let mut params = json!({});
                b1.wait();
                // May return an error or verdict — either is acceptable
                let _verdict = s1.validate_tool_call("tool_a", &mut params, &call_id);
            });

            barrier.wait();
            session.close();

            validator
                .join()
                .expect("validate_tool_call must not panic when session closes concurrently");
        }
    });
}

/// Verify that `close()` racing with `emit_event()` does not panic or corrupt.
#[test]
fn close_vs_event_emission_race() {
    run_with_timeout("close_vs_event_emission_race", TEST_TIMEOUT, || {
        let yaml = r#"
metadata:
  name: "close-vs-event"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Test close vs event emission."]
  forbidden: ["None."]
resources:
  tools:
    - name: "tool_a"
      description: "Tool A."
      permission: "execute"
"#;
        let rt = RuntimeBuilder::from_yaml_strings(&[yaml])
            .expect("yaml")
            .build()
            .expect("runtime");

        for iter in 0..500 {
            let session = Arc::new(rt.new_session(RequestContext::new(
                format!("close-event-{iter}"),
                format!("corr-{iter}"),
            )));
            session.begin_turn().expect("begin turn");

            let barrier = Arc::new(Barrier::new(2));

            let s1 = Arc::clone(&session);
            let b1 = Arc::clone(&barrier);
            let emitter = thread::spawn(move || {
                b1.wait();
                // May fail if session is already closed — that's fine
                let _ = s1.emit_event("test.event", None, None);
            });

            barrier.wait();
            session.close();

            emitter
                .join()
                .expect("emit_event must not panic when session closes concurrently");
        }
    });
}

/// Compile-time assertions that key types are Send + Sync.
#[test]
fn send_sync_compile_assertions() {
    fn assert_send_sync<T: Send + Sync>() {}

    assert_send_sync::<GuardrailsRuntime>();
    assert_send_sync::<Arc<GuardrailsRuntime>>();
    assert_send_sync::<GuardrailsSession>();
    assert_send_sync::<Arc<GuardrailsSession>>();
    assert_send_sync::<EventBus>();
}
