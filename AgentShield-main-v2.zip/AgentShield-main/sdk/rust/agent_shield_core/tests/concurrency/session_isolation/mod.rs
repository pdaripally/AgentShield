#![allow(dead_code)]

use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{mpsc, Arc, Barrier};
use std::thread;
use std::time::Duration;

use agent_shield_core::{GuardrailsRuntime, Invocation, RequestContext, RuntimeBuilder, VarStatus};
use serde_json::{json, Value};

const TEST_TIMEOUT: Duration = Duration::from_secs(30);

const MULTI_TOOL_YAML: &str = r#"
metadata:
  name: "concurrency-test"
  version: "0.1.0"
  agent_shield_version: "2.0"

objective:
  goal: ["Test concurrency safety."]
  forbidden: ["Access tools not listed."]

resources:
  tools:
    - name: "tool_a"
      description: "Test tool A."
      permission: "execute"
    - name: "tool_b"
      description: "Test tool B."
      permission: "execute"

variables:
  - name: "counter"
    type: "number"
    default: 0
  - name: "authorized"
    type: "boolean"
    default: false

state_validation:
  guard_policies:
    - name: "require_auth"
      applies_to:
        tools: ["tool_a"]
      evaluate_when:
        - expression: "authorized == true"
          reason: "Not authorized."
      action: "block"
"#;

const PER_TURN_COUNTER_YAML: &str = r#"
metadata:
  name: "concurrency-per-turn"
  version: "0.1.0"
  agent_shield_version: "2.0"

objective:
  goal: ["Test concurrency safety."]
  forbidden: ["Access tools not listed."]

resources:
  tools:
    - name: "tool_a"
      description: "Test tool A."
      permission: "execute"

variables:
  - name: "counter"
    type: "number"
    default: 0
    lifetime: "per_turn"
  - name: "authorized"
    type: "boolean"
    default: false
"#;

const IFC_YAML: &str = r#"
metadata:
  name: "concurrency-ifc"
  version: "0.1.0"
  agent_shield_version: "2.0"

objective:
  goal: ["Test concurrency safety."]
  forbidden: ["Access tools not listed."]

ifc:
  tags: [sensitive]
  strict: false
  default_audience: ["*"]
  default_clearance: ["*"]
  unsafe_default_clearance_top: true
  user_output_clearance: ["*"]

resources:
  tools:
    - name: "tool_a"
      description: "Sensitive read tool."
      permission: "execute"
      tags: [sensitive]
      audience: ["*"]
      clearance: ["*"]
    - name: "tool_b"
      description: "Unclassified tool."
      permission: "execute"
      tags: []
      audience: ["*"]
      clearance: ["*"]

variables:
  - name: "counter"
    type: "number"
    default: 0
  - name: "authorized"
    type: "boolean"
    default: false
"#;

const PREDICATE_MEMO_YAML: &str = r#"
metadata:
  name: "concurrency-predicate"
  version: "0.1.0"
  agent_shield_version: "2.0"

objective:
  goal: ["Test concurrency safety."]
  forbidden: ["Access tools not listed."]

resources:
  tools:
    - name: "tool_a"
      description: "Test tool A."
      permission: "execute"

variables:
  - name: "counter"
    type: "number"
    default: 0
  - name: "authorized"
    type: "boolean"
    default: false

predicates:
  require_auth: "authorized == true"

state_validation:
  guard_policies:
    - name: "require_auth_policy"
      applies_to:
        tools: ["tool_a"]
      evaluate_when:
        - expression: "require_auth"
          reason: "Not authorized."
      action: "block"
"#;

fn build_runtime(yaml: &str) -> Arc<GuardrailsRuntime> {
    RuntimeBuilder::from_yaml_strings(&[yaml])
        .expect("yaml loads")
        .build()
        .expect("runtime builds")
}

fn build_runtime_with_context_reset(yaml: &str) -> Arc<GuardrailsRuntime> {
    RuntimeBuilder::from_yaml_strings(&[yaml])
        .expect("yaml loads")
        .supports_context_reset(true)
        .build()
        .expect("runtime builds")
}

fn ctx(session_id: &str) -> RequestContext {
    RequestContext::new(session_id, format!("{session_id}-corr"))
}

fn run_with_timeout<F>(name: &'static str, f: F)
where
    F: FnOnce() + Send + 'static,
{
    let (tx, rx) = mpsc::sync_channel(1);
    let handle = thread::spawn(move || {
        let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(f));
        let _ = tx.send(result);
    });

    match rx.recv_timeout(TEST_TIMEOUT) {
        Ok(Ok(())) => {
            handle
                .join()
                .expect("timeout worker thread should join cleanly");
        }
        Ok(Err(panic_payload)) => {
            handle
                .join()
                .expect("panic worker thread should join cleanly");
            std::panic::resume_unwind(panic_payload);
        }
        Err(mpsc::RecvTimeoutError::Timeout) => {
            panic!("{name} exceeded {:?}", TEST_TIMEOUT);
        }
        Err(err) => {
            panic!("{name} did not report completion: {err}");
        }
    }
}

fn expected_authorized(index: usize) -> bool {
    index % 2 == 0
}

#[test]
fn variable_isolation_50_sessions() {
    run_with_timeout("variable_isolation_50_sessions", move || {
        let runtime = build_runtime(MULTI_TOOL_YAML);
        let start = Arc::new(Barrier::new(50));
        let after_write = Arc::new(Barrier::new(50));

        let handles: Vec<_> = (1..=50)
            .map(|index| {
                let runtime = runtime.clone();
                let start = start.clone();
                let after_write = after_write.clone();
                thread::spawn(move || {
                    let session_id = format!("session-{index}");
                    let session = runtime.new_session(ctx(&session_id));
                    let authorized = expected_authorized(index);

                    start.wait();
                    session
                        .set_variable("counter", json!(index))
                        .expect("counter write succeeds");
                    // `authorized` is boolean, so we use a deterministic per-session
                    // pattern instead of unique numeric values.
                    session
                        .set_variable("authorized", json!(authorized))
                        .expect("authorized write succeeds");
                    after_write.wait();

                    let counter_state = session.read_variable("counter").expect("counter declared");
                    assert_eq!(
                        counter_state.status,
                        VarStatus::Resolved,
                        "{session_id} counter should be resolved"
                    );
                    assert_eq!(
                        counter_state.value,
                        json!(index),
                        "{session_id} read wrong counter value"
                    );

                    let authorized_state = session
                        .read_variable("authorized")
                        .expect("authorized declared");
                    assert_eq!(
                        authorized_state.status,
                        VarStatus::Resolved,
                        "{session_id} authorized should be resolved"
                    );
                    assert_eq!(
                        authorized_state.value,
                        json!(authorized),
                        "{session_id} read wrong authorized value"
                    );

                    session.close();
                })
            })
            .collect();

        for (index, handle) in handles.into_iter().enumerate() {
            handle
                .join()
                .unwrap_or_else(|_| panic!("worker session-{} panicked", index + 1));
        }
    });
}

#[test]
fn concurrent_session_creation_destruction() {
    run_with_timeout("concurrent_session_creation_destruction", move || {
        let runtime = build_runtime(MULTI_TOOL_YAML);
        let stop = Arc::new(AtomicBool::new(false));

        let long_lived_handles: Vec<_> = (1..=10)
            .map(|index| {
                let runtime = runtime.clone();
                let stop = stop.clone();
                thread::spawn(move || -> usize {
                    let session_id = format!("long-lived-session-{index}");
                    let session = runtime.new_session(ctx(&session_id));
                    let invocation = Invocation::tool("tool_a", json!({ "session": session_id }));
                    let mut completed_validations = 0usize;

                    session
                        .set_variable("authorized", json!(true))
                        .expect("long-lived session can set authorized");

                    while !stop.load(Ordering::SeqCst) {
                        session.begin_turn().expect("begin_turn succeeds");
                        session
                            .set_variable("counter", json!(completed_validations as i64))
                            .expect("counter write succeeds");
                        let verdict = session.validate_state(&invocation);
                        assert!(
                            verdict.allowed,
                            "{index}: long-lived validation should stay admitted, got {:?}",
                            verdict
                        );
                        session.end_turn().expect("end_turn succeeds");
                        completed_validations += 1;
                        thread::yield_now();
                    }

                    let authorized_state = session
                        .read_variable("authorized")
                        .expect("authorized declared");
                    assert_eq!(authorized_state.value, json!(true));
                    session.close();
                    completed_validations
                })
            })
            .collect();

        let start = Arc::new(Barrier::new(100));
        let ephemeral_handles: Vec<_> = (1..=100)
            .map(|index| {
                let runtime = runtime.clone();
                let start = start.clone();
                thread::spawn(move || {
                    let session_id = format!("ephemeral-session-{index}");
                    let session = runtime.new_session(ctx(&session_id));

                    start.wait();
                    session.begin_turn().expect("begin_turn succeeds");
                    session
                        .set_variable("counter", json!(index as i64))
                        .expect("counter write succeeds");
                    session
                        .set_variable("authorized", json!(expected_authorized(index)))
                        .expect("authorized write succeeds");
                    let counter_state = session.read_variable("counter").expect("counter declared");
                    assert_eq!(counter_state.value, json!(index as i64));
                    session.end_turn().expect("end_turn succeeds");
                    session.close();
                })
            })
            .collect();

        for (index, handle) in ephemeral_handles.into_iter().enumerate() {
            handle.join().unwrap_or_else(|_| {
                panic!(
                    "ephemeral-session-{} panicked during create/destroy",
                    index + 1
                )
            });
        }

        thread::sleep(Duration::from_millis(250));
        stop.store(true, Ordering::SeqCst);

        let mut total_validations = 0usize;
        for (index, handle) in long_lived_handles.into_iter().enumerate() {
            let completed = handle
                .join()
                .unwrap_or_else(|_| panic!("long-lived-session-{} panicked", index + 1));
            assert!(
                completed > 0,
                "long-lived-session-{} never completed a validation loop",
                index + 1
            );
            total_validations += completed;
        }

        assert!(
            total_validations >= 10,
            "expected long-lived sessions to validate repeatedly; got {total_validations} loops"
        );
    });
}

#[test]
fn event_bus_session_isolation() {
    run_with_timeout("event_bus_session_isolation", move || {
        let runtime = build_runtime(MULTI_TOOL_YAML);

        let session_a = runtime.new_session(ctx("session-a"));
        let session_b = runtime.new_session(ctx("session-b"));
        let session_c = runtime.new_session(ctx("session-c"));
        let session_d = runtime.new_session(ctx("session-d"));

        session_a
            .emit_event("incident.foo", None, None)
            .expect("session A emits incident.foo");
        assert!(
            session_a.event_fired("incident.foo"),
            "session A should see its own incident.foo latch"
        );
        assert!(
            !session_b.event_fired("incident.foo"),
            "session B must not see session A's incident.foo latch"
        );
        assert!(
            !session_c.event_fired("incident.foo"),
            "session C must not see session A's incident.foo latch"
        );
        assert!(
            !session_d.event_fired("incident.foo"),
            "session D must not see session A's incident.foo latch"
        );

        session_a.close();
        session_b.close();
        session_c.close();
        session_d.close();

        let event_ids = Arc::new(
            (1..=20)
                .map(|index| format!("incident.session_{index}"))
                .collect::<Vec<_>>(),
        );
        let start = Arc::new(Barrier::new(20));
        let after_emit = Arc::new(Barrier::new(20));

        let handles: Vec<_> = (1..=20)
            .map(|index| {
                let runtime = runtime.clone();
                let event_ids = event_ids.clone();
                let start = start.clone();
                let after_emit = after_emit.clone();
                thread::spawn(move || {
                    let session_id = format!("session-{index}");
                    let session = runtime.new_session(ctx(&session_id));
                    let own_event = format!("incident.session_{index}");

                    start.wait();
                    session
                        .emit_event(&own_event, None, None)
                        .expect("event emit succeeds");
                    after_emit.wait();

                    for event_id in event_ids.iter() {
                        let fired = session.event_fired(event_id);
                        if event_id == &own_event {
                            assert!(fired, "{session_id} should see {own_event}");
                        } else {
                            assert!(
                                !fired,
                                "{session_id} must not see another session's event {event_id}"
                            );
                        }
                    }

                    session.close();
                })
            })
            .collect();

        for (index, handle) in handles.into_iter().enumerate() {
            handle
                .join()
                .unwrap_or_else(|_| panic!("event worker session-{} panicked", index + 1));
        }
    });
}

#[test]
fn lifetime_tracker_cross_session() {
    run_with_timeout("lifetime_tracker_cross_session", move || {
        let runtime = build_runtime_with_context_reset(PER_TURN_COUNTER_YAML);
        let session_a = runtime.new_session(ctx("session-a"));
        let session_b = runtime.new_session(ctx("session-b"));
        let start = Arc::new(Barrier::new(2));
        const B_SENTINEL: i64 = 777;

        session_b.begin_turn().expect("session B begins a turn");
        session_b
            .set_variable("counter", json!(B_SENTINEL))
            .expect("session B sets counter");

        let a_start = start.clone();
        let handle_a = thread::spawn(move || {
            a_start.wait();
            for value in 0..500i64 {
                session_a
                    .begin_turn()
                    .expect("session A begin_turn succeeds");
                session_a
                    .set_variable("counter", json!(value))
                    .expect("session A sets counter");

                let during_turn = session_a
                    .read_variable("counter")
                    .expect("counter declared");
                assert_eq!(during_turn.status, VarStatus::Resolved);
                assert_eq!(during_turn.value, json!(value));

                session_a.end_turn().expect("session A end_turn succeeds");
                let after_turn = session_a
                    .read_variable("counter")
                    .expect("counter declared");
                assert_eq!(
                    after_turn.status,
                    VarStatus::Unset,
                    "session A counter should clear at end of each turn"
                );
            }
            session_a.close();
        });

        let b_start = start.clone();
        let handle_b = thread::spawn(move || {
            b_start.wait();
            for _ in 0..5_000 {
                let current = session_b
                    .read_variable("counter")
                    .expect("counter declared");
                assert_eq!(
                    current.status,
                    VarStatus::Resolved,
                    "session B counter must stay resolved while session A clears its own state"
                );
                assert_eq!(
                    current.value,
                    json!(B_SENTINEL),
                    "session B must never observe session A's per-turn clear"
                );
                thread::yield_now();
            }
            session_b.end_turn().expect("session B end_turn succeeds");
            session_b.close();
        });

        handle_a.join().expect("session A worker panicked");
        handle_b.join().expect("session B worker panicked");
    });
}

#[test]
fn ifc_exposure_isolation() {
    run_with_timeout("ifc_exposure_isolation", move || {
        let runtime = build_runtime(IFC_YAML);
        let session_a = runtime.new_session(ctx("session-a"));
        let session_b = runtime.new_session(ctx("session-b"));

        assert!(
            session_a.current_exposure().is_empty(),
            "session A should start with empty IFC exposure"
        );
        assert!(
            session_b.current_exposure().is_empty(),
            "session B should start with empty IFC exposure"
        );

        session_a
            .record_tool_success("tool_a", &Value::Null)
            .expect("tool_a success records IFC exposure");

        assert!(
            !session_a.current_exposure().is_empty(),
            "session A exposure should rise after reading tool_a"
        );
        assert!(
            session_b.current_exposure().is_empty(),
            "session B exposure must stay empty after session A's IFC read"
        );

        let mut params = Value::Null;
        let verdict_b = session_b.validate_tool_call("tool_b", &mut params, "call-b");
        assert!(
            verdict_b.allowed,
            "session B should remain unaffected by session A's IFC exposure; got {:?}",
            verdict_b
        );

        session_a.close();
        session_b.close();
    });
}

#[test]
fn predicate_memoization_isolation() {
    run_with_timeout("predicate_memoization_isolation", move || {
        let runtime = build_runtime(PREDICATE_MEMO_YAML);
        let session_a = runtime.new_session(ctx("session-a"));
        let session_b = runtime.new_session(ctx("session-b"));
        let invocation = Invocation::tool("tool_a", json!({ "request": "test" }));

        session_a
            .set_variable("authorized", json!(true))
            .expect("session A sets authorized=true");
        session_b
            .set_variable("authorized", json!(false))
            .expect("session B sets authorized=false");

        let verdict_a = session_a.validate_state(&invocation);
        assert!(
            verdict_a.allowed,
            "session A should pass require_auth with authorized=true; got {:?}",
            verdict_a
        );

        let verdict_b = session_b.validate_state(&invocation);
        assert!(
            !verdict_b.allowed,
            "session B must block with authorized=false even after session A memoizes true; got {:?}",
            verdict_b
        );

        let verdict_b_again = session_b.validate_state(&invocation);
        assert!(
            !verdict_b_again.allowed,
            "session B must continue to use its own predicate state on repeat evaluation; got {:?}",
            verdict_b_again
        );

        session_a.close();
        session_b.close();
    });
}

#[test]
fn runtime_shutdown_with_active_sessions() {
    run_with_timeout("runtime_shutdown_with_active_sessions", move || {
        let runtime = build_runtime(MULTI_TOOL_YAML);
        let weak_runtime = Arc::downgrade(&runtime);
        let mut sessions = Vec::new();

        for index in 1..=10 {
            let session_id = format!("session-{index}");
            let session = runtime.new_session(ctx(&session_id));
            session
                .set_variable("authorized", json!(true))
                .expect("authorized write succeeds");

            if index <= 5 {
                session
                    .begin_turn()
                    .expect("active session begin_turn succeeds");
                session
                    .set_variable("counter", json!(index as i64))
                    .expect("active session counter write succeeds");
                assert!(
                    session.is_turn_active(),
                    "{session_id} should still report an active turn"
                );
            }

            sessions.push(session);
        }

        drop(runtime);
        assert!(
            weak_runtime.upgrade().is_some(),
            "sessions should keep the runtime alive after the primary Arc is dropped"
        );

        for (index, session) in sessions.iter().enumerate() {
            let expected_counter = (index as i64) + 100;
            session
                .set_variable("counter", json!(expected_counter))
                .expect("session should keep working after runtime Arc drop");

            let counter_state = session.read_variable("counter").expect("counter declared");
            assert_eq!(
                counter_state.value,
                json!(expected_counter),
                "session-{} read the wrong counter after runtime Arc drop",
                index + 1
            );

            let verdict = session
                .validate_state(&Invocation::tool("tool_a", json!({ "session": index + 1 })));
            assert!(
                verdict.allowed,
                "session-{} should still validate state after runtime Arc drop; got {:?}",
                index + 1,
                verdict
            );

            if index < 5 {
                assert!(
                    session.is_turn_active(),
                    "session-{} should still have its pre-drop active turn",
                    index + 1
                );
                session
                    .end_turn()
                    .expect("end_turn succeeds after runtime Arc drop");
                assert!(
                    !session.is_turn_active(),
                    "session-{} should have ended its turn cleanly",
                    index + 1
                );
            }
        }

        for session in &sessions {
            session.close();
        }
        drop(sessions);

        assert!(
            weak_runtime.upgrade().is_none(),
            "runtime should be released once all sessions are dropped"
        );
    });
}
