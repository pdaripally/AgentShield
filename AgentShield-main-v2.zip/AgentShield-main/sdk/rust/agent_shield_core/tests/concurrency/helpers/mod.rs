#![allow(dead_code)]

//! Shared test helpers for the concurrency test suite.
//!
//! Provides:
//! - `BarrierHarness` — synchronize N threads at a rendezvous point
//! - `Watchdog` — wall-clock timeout that aborts on deadlock
//! - `build_test_runtime` — construct a runtime from inline YAML
//! - `spawn_session` — create a session with a unique ID
//! - `assert_no_deadlock` — run a closure with a timeout
//! - `CountingObserver` — observability provider that counts events
//! - `PanickingResolver` / `SlowResolver` / `ReentrantResolver` — test doubles

use std::collections::HashMap;
use std::panic::{self, AssertUnwindSafe};
use std::sync::{
    atomic::{AtomicBool, AtomicUsize, Ordering},
    mpsc, Arc, Barrier,
};
use std::thread::{self, JoinHandle};
use std::time::{Duration, Instant};

use agent_shield_core::resolver_runtime::{HumanResolveRequest, HumanResolver};
use agent_shield_core::{
    AgentResolveRequest, AgentResolver, DelegateDispatcher, DelegateRequest, GuardrailsRuntime,
    GuardrailsSession, Lifetime, ObservabilityProvider, RequestContext, ResolverDecision,
    ResolverResponse, ResolverRuntimeError, RuntimeBuilder, ShieldLogEvent,
};
use serde_json::{json, Value};

static SESSION_COUNTER: AtomicUsize = AtomicUsize::new(1);

pub const MULTI_TOOL_POLICY_YAML: &str = r#"
metadata:
  name: "concurrency-test"
  version: "0.1.0"
  agent_shield_version: "2.0"

objective:
  goal: ["Test concurrency safety."]
  forbidden: ["Access tools not listed."]

resources:
  tools:
    - name: "tool_a"
      description: "Test tool A."
      permission: "execute"
    - name: "tool_b"
      description: "Test tool B."
      permission: "execute"
    - name: "tool_c"
      description: "Test tool C."
      permission: "execute"
    - name: "tool_d"
      description: "Test tool D."
      permission: "execute"
    - name: "tool_e"
      description: "Test tool E."
      permission: "read_only"

variables:
  - name: "counter"
    type: "number"
    default: 0
  - name: "authorized"
    type: "boolean"
    default: false
  - name: "sensitivity"
    type: "enum"
    members: ["public", "internal", "protected"]
    default: "public"
    update: "max(@current, @incoming)"

state_validation:
  guard_policies:
    - name: "require_auth"
      applies_to:
        tools: ["tool_a", "tool_b"]
      evaluate_when:
        - expression: "authorized == true"
          reason: "Not authorized."
      action: "block"

tool_execution_validation:
  guard_policies:
    - name: "block_tool_c_when_protected"
      applies_to:
        tools: ["tool_c"]
      evaluate_when:
        - expression: 'sensitivity != "protected"'
          reason: "Cannot use tool_c with protected data."
      action: "block"
"#;

pub fn build_test_runtime(yaml: &str) -> Arc<GuardrailsRuntime> {
    RuntimeBuilder::from_yaml_strings(&[yaml])
        .expect("inline test YAML should parse")
        .supports_context_reset(true)
        .build()
        .expect("test runtime should build")
}

pub fn spawn_session(runtime: &Arc<GuardrailsRuntime>) -> GuardrailsSession {
    let id = SESSION_COUNTER.fetch_add(1, Ordering::SeqCst);
    let ctx = RequestContext::new(
        format!("test-session-{id}"),
        format!("test-correlation-{id}"),
    )
    .with_user_id(format!("test-user-{id}"))
    .with_tenant_id(format!("test-tenant-{id}"));

    runtime.new_session(ctx)
}

#[derive(Clone)]
pub struct BarrierHarness {
    barrier: Arc<Barrier>,
}

impl BarrierHarness {
    pub fn new(parties: usize) -> Self {
        assert!(parties > 0, "BarrierHarness requires at least one party");
        Self {
            barrier: Arc::new(Barrier::new(parties)),
        }
    }

    pub fn wait(&self) {
        self.barrier.wait();
    }

    pub fn spawn<F, T>(&self, f: F) -> JoinHandle<T>
    where
        F: FnOnce(BarrierHarness) -> T + Send + 'static,
        T: Send + 'static,
    {
        let harness = self.clone();
        thread::spawn(move || f(harness))
    }

    pub fn spawn_rendezvous<F, T>(&self, f: F) -> JoinHandle<T>
    where
        F: FnOnce() -> T + Send + 'static,
        T: Send + 'static,
    {
        let harness = self.clone();
        thread::spawn(move || {
            harness.wait();
            f()
        })
    }
}

pub struct Watchdog {
    label: String,
    started_at: Instant,
    disarmed: AtomicBool,
    cancel_tx: Option<mpsc::Sender<()>>,
    handle: Option<JoinHandle<()>>,
}

impl Watchdog {
    pub fn start(timeout: Duration, label: impl Into<String>) -> Self {
        let label = label.into();
        let thread_label = label.clone();
        let (tx, rx) = mpsc::channel();
        let started_at = Instant::now();

        let handle = thread::spawn(move || match rx.recv_timeout(timeout) {
            Ok(()) | Err(mpsc::RecvTimeoutError::Disconnected) => {}
            Err(mpsc::RecvTimeoutError::Timeout) => {
                eprintln!("watchdog timeout after {:?}: {}", timeout, thread_label);
                std::process::abort();
            }
        });

        Self {
            label,
            started_at,
            disarmed: AtomicBool::new(false),
            cancel_tx: Some(tx),
            handle: Some(handle),
        }
    }

    pub fn disarm(&mut self) {
        if self.disarmed.swap(true, Ordering::SeqCst) {
            return;
        }

        if let Some(tx) = self.cancel_tx.take() {
            let _ = tx.send(());
        }
        if let Some(handle) = self.handle.take() {
            let _ = handle.join();
        }
    }

    pub fn elapsed(&self) -> Duration {
        self.started_at.elapsed()
    }

    pub fn label(&self) -> &str {
        &self.label
    }
}

impl Drop for Watchdog {
    fn drop(&mut self) {
        self.disarm();
    }
}

pub fn assert_no_deadlock<F, T>(timeout: Duration, f: F) -> T
where
    F: FnOnce() -> T + Send + 'static,
    T: Send + 'static,
{
    let started_at = Instant::now();
    let (tx, rx) = mpsc::channel();

    let handle = thread::spawn(move || {
        let result = panic::catch_unwind(AssertUnwindSafe(f));
        let _ = tx.send(result);
    });

    match rx.recv_timeout(timeout) {
        Ok(Ok(value)) => {
            handle.join().expect("worker thread should join cleanly");
            value
        }
        Ok(Err(payload)) => {
            let _ = handle.join();
            panic::resume_unwind(payload);
        }
        Err(mpsc::RecvTimeoutError::Timeout) => {
            panic!(
                "operation exceeded {:?} (elapsed {:?}); possible deadlock",
                timeout,
                started_at.elapsed()
            );
        }
        Err(mpsc::RecvTimeoutError::Disconnected) => match handle.join() {
            Ok(()) => panic!("worker thread exited without returning a result"),
            Err(payload) => panic::resume_unwind(payload),
        },
    }
}

#[derive(Clone, Default)]
pub struct CountingObserver {
    calls: Arc<AtomicUsize>,
}

impl CountingObserver {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn total(&self) -> usize {
        self.calls.load(Ordering::SeqCst)
    }

    pub fn counter(&self) -> Arc<AtomicUsize> {
        self.calls.clone()
    }
}

impl ObservabilityProvider for CountingObserver {
    fn emit(&self, _event: ShieldLogEvent) {
        self.calls.fetch_add(1, Ordering::SeqCst);
    }
}

#[derive(Clone)]
pub struct PanickingResolver {
    message: Arc<String>,
    calls: Arc<AtomicUsize>,
}

impl PanickingResolver {
    pub fn new(message: impl Into<String>) -> Self {
        Self {
            message: Arc::new(message.into()),
            calls: Arc::new(AtomicUsize::new(0)),
        }
    }

    pub fn calls(&self) -> usize {
        self.calls.load(Ordering::SeqCst)
    }

    fn panic_now(&self) -> ! {
        self.calls.fetch_add(1, Ordering::SeqCst);
        panic!("{}", self.message.as_str());
    }
}

impl HumanResolver for PanickingResolver {
    fn resolve(&self, _req: HumanResolveRequest) -> ResolverResponse {
        self.panic_now()
    }
}

impl AgentResolver for PanickingResolver {
    fn resolve(&self, _req: AgentResolveRequest) -> ResolverResponse {
        self.panic_now()
    }
}

impl DelegateDispatcher for PanickingResolver {
    fn dispatch(&self, _req: DelegateRequest) -> Result<ResolverResponse, ResolverRuntimeError> {
        self.panic_now()
    }
}

#[derive(Clone)]
pub struct SlowResolver {
    delay: Duration,
    response: ResolverResponse,
    calls: Arc<AtomicUsize>,
    started: Arc<AtomicBool>,
    finished: Arc<AtomicBool>,
}

impl SlowResolver {
    pub fn new(delay: Duration, response: ResolverResponse) -> Self {
        Self {
            delay,
            response,
            calls: Arc::new(AtomicUsize::new(0)),
            started: Arc::new(AtomicBool::new(false)),
            finished: Arc::new(AtomicBool::new(false)),
        }
    }

    pub fn allow_after(delay: Duration) -> Self {
        Self::new(delay, allow_response())
    }

    pub fn calls(&self) -> usize {
        self.calls.load(Ordering::SeqCst)
    }

    pub fn started(&self) -> bool {
        self.started.load(Ordering::SeqCst)
    }

    pub fn finished(&self) -> bool {
        self.finished.load(Ordering::SeqCst)
    }

    fn resolve_slowly(&self) -> ResolverResponse {
        self.calls.fetch_add(1, Ordering::SeqCst);
        self.started.store(true, Ordering::SeqCst);
        thread::sleep(self.delay);
        self.finished.store(true, Ordering::SeqCst);
        self.response.clone()
    }
}

impl HumanResolver for SlowResolver {
    fn resolve(&self, _req: HumanResolveRequest) -> ResolverResponse {
        self.resolve_slowly()
    }
}

impl AgentResolver for SlowResolver {
    fn resolve(&self, _req: AgentResolveRequest) -> ResolverResponse {
        self.resolve_slowly()
    }
}

impl DelegateDispatcher for SlowResolver {
    fn dispatch(&self, _req: DelegateRequest) -> Result<ResolverResponse, ResolverRuntimeError> {
        Ok(self.resolve_slowly())
    }
}

#[derive(Clone)]
pub struct ReentrantResolver {
    session: Arc<GuardrailsSession>,
    action: Arc<dyn Fn(&GuardrailsSession) + Send + Sync>,
    response: ResolverResponse,
    calls: Arc<AtomicUsize>,
}

impl ReentrantResolver {
    pub fn new<F>(session: Arc<GuardrailsSession>, action: F) -> Self
    where
        F: Fn(&GuardrailsSession) + Send + Sync + 'static,
    {
        Self::with_response(session, allow_response(), action)
    }

    pub fn with_response<F>(
        session: Arc<GuardrailsSession>,
        response: ResolverResponse,
        action: F,
    ) -> Self
    where
        F: Fn(&GuardrailsSession) + Send + Sync + 'static,
    {
        Self {
            session,
            action: Arc::new(action),
            response,
            calls: Arc::new(AtomicUsize::new(0)),
        }
    }

    pub fn calls(&self) -> usize {
        self.calls.load(Ordering::SeqCst)
    }

    fn resolve_reentrantly(&self) -> ResolverResponse {
        self.calls.fetch_add(1, Ordering::SeqCst);
        (self.action)(self.session.as_ref());
        self.response.clone()
    }
}

impl HumanResolver for ReentrantResolver {
    fn resolve(&self, _req: HumanResolveRequest) -> ResolverResponse {
        self.resolve_reentrantly()
    }
}

impl AgentResolver for ReentrantResolver {
    fn resolve(&self, _req: AgentResolveRequest) -> ResolverResponse {
        self.resolve_reentrantly()
    }
}

impl DelegateDispatcher for ReentrantResolver {
    fn dispatch(&self, _req: DelegateRequest) -> Result<ResolverResponse, ResolverRuntimeError> {
        Ok(self.resolve_reentrantly())
    }
}

pub fn allow_response() -> ResolverResponse {
    ResolverResponse {
        decision: ResolverDecision::Allow,
        value: Some(json!(true)),
        set_variables: HashMap::new(),
        reason: None,
    }
}

pub fn deny_response(reason: impl Into<String>) -> ResolverResponse {
    ResolverResponse {
        decision: ResolverDecision::Deny,
        value: None,
        set_variables: HashMap::new(),
        reason: Some(reason.into()),
    }
}

pub fn cancelled_response(reason: impl Into<String>) -> ResolverResponse {
    ResolverResponse {
        decision: ResolverDecision::Cancelled,
        value: None,
        set_variables: HashMap::new(),
        reason: Some(reason.into()),
    }
}

pub fn emit_test_event(session: &GuardrailsSession, id: &str, payload: Value) {
    session
        .emit_event(
            id,
            Some(Lifetime::Bare(agent_shield_core::BareLifetime::PerSession)),
            Some(payload),
        )
        .expect("test event should emit");
}
