#![allow(dead_code)]
#![cfg(not(loom))]

use std::any::Any;
use std::panic::{self, catch_unwind, AssertUnwindSafe};
use std::sync::{
    atomic::{AtomicBool, AtomicUsize, Ordering},
    mpsc, Arc, Barrier,
};
use std::thread;
use std::time::{Duration, Instant};

use agent_shield_core::{
    BareLifetime, EventId, GuardrailsRuntime, GuardrailsSession, Lifetime, ObservabilityProvider,
    RequestContext, RuntimeBuilder, ShieldLogEvent,
};
use serde_json::json;

const DEADLOCK_TIMEOUT: Duration = Duration::from_secs(10);
const LOAD_WINDOW: Duration = Duration::from_secs(5);
const OBSERVABILITY_WINDOW: Duration = Duration::from_secs(3);
const SUBSCRIBER_TRACKER_ITERS: usize = 1_000;
const SESSION_LOCK_ITERS: usize = 10_000;
const RESOLVER_CALLBACK_ITERS: usize = 5_000;
const OBSERVABILITY_SESSIONS: usize = 10;

static SESSION_COUNTER: AtomicUsize = AtomicUsize::new(1);

const LOCK_ORDER_YAML: &str = r#"
metadata:
  name: "concurrency-lock-order"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Test lock ordering."]
  forbidden: ["None."]
resources:
  tools:
    - name: "tool_a"
      description: "Test tool."
      permission: "execute"
variables:
  - name: "counter"
    type: "number"
    default: 0
  - name: "flag"
    type: "boolean"
    default: false
state_validation:
  guard_policies:
    - name: "check_flag"
      applies_to:
        tools: ["tool_a"]
      evaluate_when:
        - expression: "flag == true"
          reason: "Flag not set."
      action: "block"
"#;

#[derive(Clone, Default)]
struct CountingObserver {
    calls: Arc<AtomicUsize>,
}

impl CountingObserver {
    fn new() -> Self {
        Self::default()
    }

    fn total(&self) -> usize {
        self.calls.load(Ordering::SeqCst)
    }
}

impl ObservabilityProvider for CountingObserver {
    fn emit(&self, _event: ShieldLogEvent) {
        self.calls.fetch_add(1, Ordering::SeqCst);
    }
}

fn build_runtime() -> Arc<GuardrailsRuntime> {
    RuntimeBuilder::from_yaml_strings(&[LOCK_ORDER_YAML])
        .expect("inline lock-order YAML should parse")
        .supports_context_reset(true)
        .build()
        .expect("lock-order runtime should build")
}

fn build_runtime_with_observer(observer: Arc<CountingObserver>) -> Arc<GuardrailsRuntime> {
    RuntimeBuilder::from_yaml_strings(&[LOCK_ORDER_YAML])
        .expect("inline lock-order YAML should parse")
        .supports_context_reset(true)
        .register_provider(observer)
        .build()
        .expect("lock-order runtime should build")
}

fn open_session(runtime: &Arc<GuardrailsRuntime>) -> Arc<GuardrailsSession> {
    let id = SESSION_COUNTER.fetch_add(1, Ordering::SeqCst);
    Arc::new(runtime.new_session(RequestContext::new(
        format!("lock-order-session-{id}"),
        format!("lock-order-correlation-{id}"),
    )))
}

fn assert_no_deadlock<F, T>(timeout: Duration, f: F) -> T
where
    F: FnOnce() -> T + Send + 'static,
    T: Send + 'static,
{
    let started_at = Instant::now();
    let (tx, rx) = mpsc::channel();

    let handle = thread::spawn(move || {
        let result = panic::catch_unwind(AssertUnwindSafe(f));
        let _ = tx.send(result);
    });

    match rx.recv_timeout(timeout) {
        Ok(Ok(value)) => {
            handle.join().expect("worker thread should join cleanly");
            value
        }
        Ok(Err(payload)) => {
            let _ = handle.join();
            panic::resume_unwind(payload);
        }
        Err(mpsc::RecvTimeoutError::Timeout) => {
            panic!(
                "operation exceeded {:?} (elapsed {:?}); possible deadlock",
                timeout,
                started_at.elapsed()
            );
        }
        Err(mpsc::RecvTimeoutError::Disconnected) => match handle.join() {
            Ok(()) => panic!("worker thread exited without returning a result"),
            Err(payload) => panic::resume_unwind(payload),
        },
    }
}

fn spin_until(deadline: Instant) {
    while Instant::now() < deadline {
        thread::yield_now();
    }
}

fn panic_message(payload: &(dyn Any + Send)) -> String {
    if let Some(message) = payload.downcast_ref::<String>() {
        return message.clone();
    }
    if let Some(message) = payload.downcast_ref::<&'static str>() {
        return (*message).to_string();
    }
    "non-string panic payload".to_string()
}

#[test]
fn subscriber_calls_tracker() {
    assert_no_deadlock(DEADLOCK_TIMEOUT, move || {
        let runtime = build_runtime();
        let session = open_session(&runtime);
        let start = Arc::new(Barrier::new(2));
        let finish = Arc::new(Barrier::new(2));
        let progress = Arc::new(AtomicUsize::new(0));

        let writer_session = session.clone();
        let writer_start = start.clone();
        let writer_finish = finish.clone();
        let writer_progress = progress.clone();
        let writer = thread::spawn(move || {
            for iteration in 0..SUBSCRIBER_TRACKER_ITERS {
                writer_start.wait();
                writer_session
                    .set_variable("counter", json!(iteration as i64))
                    .expect("counter writes should succeed");
                writer_progress.fetch_add(1, Ordering::SeqCst);
                writer_finish.wait();
            }
        });

        let reader_session = session.clone();
        let reader_start = start.clone();
        let reader_finish = finish.clone();
        let reader_progress = progress.clone();
        let reader = thread::spawn(move || {
            for iteration in 0..SUBSCRIBER_TRACKER_ITERS {
                reader_start.wait();
                reader_session
                    .emit_event(
                        "incident.tracker_probe",
                        Some(Lifetime::Bare(BareLifetime::PerSession)),
                        Some(json!({"iteration": iteration})),
                    )
                    .expect("probe event should emit");
                let state = reader_session
                    .read_variable("counter")
                    .expect("counter should be declared");
                assert!(
                    matches!(
                        state.value,
                        serde_json::Value::Null | serde_json::Value::Number(_)
                    ),
                    "counter should stay readable while events emit: {:?}",
                    state
                );
                reader_progress.fetch_add(1, Ordering::SeqCst);
                reader_finish.wait();
            }
        });

        writer.join().expect("writer thread should finish");
        reader.join().expect("reader thread should finish");

        assert_eq!(
            progress.load(Ordering::SeqCst),
            SUBSCRIBER_TRACKER_ITERS * 2,
            "both threads should complete every synchronized iteration"
        );
        assert!(
            session.event_fired("incident.tracker_probe"),
            "the shared event bus should have observed the emitted probe event"
        );
    });
}

#[test]
fn reentrant_event_emission() {
    assert_no_deadlock(DEADLOCK_TIMEOUT, move || {
        let runtime = build_runtime();
        let session = open_session(&runtime);
        let running = Arc::new(AtomicBool::new(true));
        let progress = Arc::new(AtomicUsize::new(0));
        let start = Arc::new(Barrier::new(4));
        let until_bar = Lifetime::Bare(BareLifetime::UntilEvent(vec![EventId::parse(
            "incident.bar",
        )
        .expect("event id should parse")]));

        let handles: Vec<_> = (0..4)
            .map(|worker| {
                let session = session.clone();
                let running = running.clone();
                let progress = progress.clone();
                let start = start.clone();
                let until_bar = until_bar.clone();
                thread::spawn(move || {
                    start.wait();
                    while running.load(Ordering::SeqCst) {
                        if worker % 2 == 0 {
                            session
                                .emit_event(
                                    "incident.foo",
                                    Some(until_bar.clone()),
                                    Some(json!({"worker": worker})),
                                )
                                .expect("incident.foo should emit");
                            session
                                .set_variable("flag", json!(true))
                                .expect("flag write should succeed");
                        } else {
                            session
                                .emit_event(
                                    "incident.bar",
                                    Some(Lifetime::Bare(BareLifetime::PerTurn)),
                                    Some(json!({"worker": worker})),
                                )
                                .expect("incident.bar should emit");
                            session
                                .set_variable("flag", json!(false))
                                .expect("flag write should succeed");
                        }
                        let _ = session.event_fired("incident.foo");
                        progress.fetch_add(1, Ordering::SeqCst);
                        thread::yield_now();
                    }
                })
            })
            .collect();

        spin_until(Instant::now() + LOAD_WINDOW);
        running.store(false, Ordering::SeqCst);

        for handle in handles {
            handle.join().expect("reentrant event worker should finish");
        }

        assert!(
            progress.load(Ordering::SeqCst) > 0,
            "workers should make progress during the reentrant event emission window"
        );
    });
}

#[test]
fn subscriber_takes_session_lock() {
    assert_no_deadlock(DEADLOCK_TIMEOUT, move || {
        let runtime = build_runtime();
        let session = open_session(&runtime);
        let start = Arc::new(Barrier::new(2));
        let finish = Arc::new(Barrier::new(2));
        let progress = Arc::new(AtomicUsize::new(0));

        let setter_session = session.clone();
        let setter_start = start.clone();
        let setter_finish = finish.clone();
        let setter_progress = progress.clone();
        let setter = thread::spawn(move || {
            for iteration in 0..SESSION_LOCK_ITERS {
                setter_start.wait();
                setter_session
                    .set_variable("flag", json!(iteration % 2 == 0))
                    .expect("flag write should succeed");
                setter_progress.fetch_add(1, Ordering::SeqCst);
                setter_finish.wait();
            }
        });

        let boundary_session = session.clone();
        let boundary_start = start.clone();
        let boundary_finish = finish.clone();
        let boundary_progress = progress.clone();
        let boundary = thread::spawn(move || {
            for _ in 0..SESSION_LOCK_ITERS {
                boundary_start.wait();
                boundary_session
                    .begin_turn()
                    .expect("begin_turn should succeed");
                boundary_session
                    .end_turn()
                    .expect("end_turn should succeed");
                boundary_progress.fetch_add(1, Ordering::SeqCst);
                boundary_finish.wait();
            }
        });

        setter.join().expect("variable setter should finish");
        boundary.join().expect("turn boundary thread should finish");

        assert_eq!(
            progress.load(Ordering::SeqCst),
            SESSION_LOCK_ITERS * 2,
            "both lock-order participants should finish all iterations"
        );
    });
}

#[test]
fn resolver_callback_event_emission() {
    assert_no_deadlock(DEADLOCK_TIMEOUT, move || {
        let runtime = build_runtime();
        let session = open_session(&runtime);
        let start = Arc::new(Barrier::new(2));
        let finish = Arc::new(Barrier::new(2));
        let progress = Arc::new(AtomicUsize::new(0));

        session.begin_turn().expect("seed turn should start");

        let validator_session = session.clone();
        let validator_start = start.clone();
        let validator_finish = finish.clone();
        let validator_progress = progress.clone();
        let validator = thread::spawn(move || {
            for iteration in 0..RESOLVER_CALLBACK_ITERS {
                validator_start.wait();
                let _ = validator_session.validate_input(&format!("input-{iteration}"));
                let mut params = json!({"iteration": iteration});
                let admission = validator_session.validate_tool_admission(
                    "tool_a",
                    &mut params,
                    &format!("tool-call-{iteration}"),
                );
                drop(admission);
                validator_progress.fetch_add(1, Ordering::SeqCst);
                validator_finish.wait();
            }
        });

        let mutator_session = session.clone();
        let mutator_start = start.clone();
        let mutator_finish = finish.clone();
        let mutator_progress = progress.clone();
        let mutator = thread::spawn(move || {
            for iteration in 0..RESOLVER_CALLBACK_ITERS {
                mutator_start.wait();
                mutator_session
                    .set_variable("flag", json!(iteration % 2 == 0))
                    .expect("flag write should succeed");
                mutator_session
                    .emit_event(
                        "incident.resolver_probe",
                        Some(Lifetime::Bare(BareLifetime::PerSession)),
                        Some(json!({"iteration": iteration})),
                    )
                    .expect("resolver probe should emit");
                mutator_progress.fetch_add(1, Ordering::SeqCst);
                mutator_finish.wait();
            }
        });

        validator.join().expect("validator thread should finish");
        mutator.join().expect("mutator thread should finish");
        session.end_turn().expect("seed turn should end cleanly");

        assert_eq!(
            progress.load(Ordering::SeqCst),
            RESOLVER_CALLBACK_ITERS * 2,
            "validation and mutation threads should both complete all iterations"
        );
    });
}

#[test]
fn observability_reentry() {
    assert_no_deadlock(DEADLOCK_TIMEOUT, move || {
        let observer = Arc::new(CountingObserver::new());
        let runtime = build_runtime_with_observer(observer.clone());
        let running = Arc::new(AtomicBool::new(true));
        let progress = Arc::new(AtomicUsize::new(0));
        let start = Arc::new(Barrier::new(OBSERVABILITY_SESSIONS));

        let handles: Vec<_> = (0..OBSERVABILITY_SESSIONS)
            .map(|worker| {
                let session = open_session(&runtime);
                let running = running.clone();
                let progress = progress.clone();
                let start = start.clone();
                thread::spawn(move || {
                    start.wait();
                    while running.load(Ordering::SeqCst) {
                        session.begin_turn().expect("begin_turn should succeed");
                        let _ = session.validate_input("lock-order observability probe");
                        session
                            .set_variable("counter", json!(worker as i64))
                            .expect("counter write should succeed");
                        session
                            .emit_event(
                                "incident.observability_probe",
                                Some(Lifetime::Bare(BareLifetime::PerSession)),
                                Some(json!({"worker": worker})),
                            )
                            .expect("observability probe should emit");
                        session.end_turn().expect("end_turn should succeed");
                        progress.fetch_add(1, Ordering::SeqCst);
                        thread::yield_now();
                    }
                })
            })
            .collect();

        spin_until(Instant::now() + OBSERVABILITY_WINDOW);
        running.store(false, Ordering::SeqCst);

        for handle in handles {
            handle.join().expect("observability worker should finish");
        }

        assert!(
            progress.load(Ordering::SeqCst) > 0,
            "sessions should make progress while observability callbacks fan out"
        );
        assert!(
            observer.total() > 0,
            "the shared observability provider should observe concurrent emissions"
        );
    });
}

#[test]
fn watchdog_infrastructure_test() {
    let panic = catch_unwind(AssertUnwindSafe(|| {
        assert_no_deadlock(Duration::from_secs(1), move || {
            thread::park();
        });
    }));

    assert!(
        panic.is_err(),
        "the watchdog helper should time out and panic"
    );
    let message = panic_message(&**panic.as_ref().err().expect("panic payload should exist"));
    assert!(
        message.contains("operation exceeded") || message.contains("possible deadlock"),
        "unexpected watchdog panic message: {message}"
    );
}
