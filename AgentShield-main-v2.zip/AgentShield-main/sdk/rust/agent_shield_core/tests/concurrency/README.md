# Concurrency Validation Test Suite

## Running

```bash
# All concurrency tests (parallel, default)
cargo test -p agent_shield_core --test concurrency

# Serial mode (exposes BUG 3 more reliably)
cargo test -p agent_shield_core --test concurrency -- --test-threads=1

# Soak test (60s, ignored by default)
cargo test -p agent_shield_core --test concurrency soak_test -- --ignored

# Single module
cargo test -p agent_shield_core --test concurrency race_windows
```

## Expected Results

| Status | Count | Details |
|--------|-------|---------|
| Pass | 59 | Core concurrency guarantees confirmed (including Bug 1 & 2 fixes) |
| Fail | 0 | All known bugs fixed or test ignored |
| Ignored | 1 | Soak test (nightly-only) |

## Fixed Bugs (verified by this test suite)

| Test | Bug | Status |
|------|-----|--------|
| `race_windows::resolver_completion_after_close` | BUG 1: Session resurrection via `or_default()` | ✅ Fixed |
| `race_windows::lifetime_expiry_concurrent_read` | BUG 2: Three-lock TOCTOU in expiry path | ✅ Fixed |

## Remaining Known Issues

| Test | Bug | Status |
|------|-----|--------|
| `resolver::late_resolver_vs_variable_set` | BUG 3: No write-ordering for resolver vs host | Passes (race window documented, fix deferred) |

The Bug 1 & 2 tests previously failed to document production bugs. Those bugs
are now fixed and the tests serve as regression guards.

## Module Structure

| Module | Focus |
|--------|-------|
| `helpers` | Shared infrastructure (resolvers, watchdog, runtime builders) |
| `race_windows` | Targeted race condition reproduction |
| `tool_admission` | ToolAdmission state machine under contention |
| `session_isolation` | Cross-session data isolation |
| `lock_order` | Lock ordering / deadlock freedom |
| `resolver` | Resolver lifecycle races |
| `parallel_validation` | Guard policy evaluation under load |
| `streaming` | StreamingGuard concurrent chunks |
| `stress` | Fan-out, mixed workloads, soak |
| `failure` | Panic propagation, error recovery |

## Limitations

- **Probabilistic, not proof:** Barrier-based stress tests increase race probability but cannot guarantee hitting every interleaving. Loom would provide mechanical verification.
- **x86-only:** Tests run under x86-TSO memory model. ARM/weak-memory architectures may expose additional ordering issues with `Relaxed` atomics.
- **No FFI boundary:** Python/Node/.NET call through C FFI (`unsafe`). That boundary is untested here.
- **No `read_predicate_in` coverage:** May share BUG 2's three-lock pattern.
