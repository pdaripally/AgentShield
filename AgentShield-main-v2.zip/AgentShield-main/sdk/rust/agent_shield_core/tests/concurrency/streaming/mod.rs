#![allow(dead_code)]

use std::sync::{mpsc, Arc, Barrier};
use std::thread;
use std::time::Duration;

use agent_shield_core::guard_policy_runtime::streaming::StreamingTrigger;
use agent_shield_core::observability::Stage;
use agent_shield_core::{
    BareLifetime, GuardrailsRuntime, Lifetime, RequestContext, RuntimeBuilder, StreamChunkAction,
    StreamChunkResult, StreamingOptions,
};
use serde_json::json;

const TEST_TIMEOUT: Duration = Duration::from_secs(30);
const HIGH_LOAD_CHUNKS: usize = 1_000;
const CONCURRENT_STREAMS: usize = 10;
const ON_COMPLETE_STREAMS: usize = 5;
const WINDOW_SIZE: usize = 96;
const OVERLAP: usize = 12;

const STREAMING_YAML: &str = r#"
metadata:
  name: "concurrency-streaming"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Test streaming concurrency."]
  forbidden: ["None."]
resources:
  tools:
    - name: "tool_a"
      description: "Tool A."
      permission: "execute"
variables:
  - name: "flag"
    type: "boolean"
    default: false
output_validation:
  guard_policies:
    - name: "block_secret"
      evaluate_when:
        - pattern: "SECRET"
          reason: "Output contains SECRET."
          action: "block"
"#;

fn build_runtime() -> Arc<GuardrailsRuntime> {
    RuntimeBuilder::from_yaml_strings(&[STREAMING_YAML])
        .expect("yaml loads")
        .build()
        .expect("runtime builds")
}

fn build_windowed_runtime() -> Arc<GuardrailsRuntime> {
    RuntimeBuilder::from_yaml_strings(&[STREAMING_YAML])
        .expect("yaml loads")
        .streaming_window(StreamingOptions {
            trigger: StreamingTrigger::Windowed,
            window_size: WINDOW_SIZE,
            overlap: OVERLAP,
        })
        .build()
        .expect("runtime builds")
}

fn ctx(session_id: &str) -> RequestContext {
    RequestContext::new(session_id, format!("{session_id}-corr"))
}

fn run_with_timeout<T, F>(name: &'static str, f: F) -> T
where
    T: Send + 'static,
    F: FnOnce() -> T + Send + 'static,
{
    let (tx, rx) = mpsc::sync_channel(1);
    let handle = thread::spawn(move || {
        let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(f));
        let _ = tx.send(result);
    });

    match rx.recv_timeout(TEST_TIMEOUT) {
        Ok(Ok(value)) => {
            handle
                .join()
                .expect("timeout worker thread should join cleanly");
            value
        }
        Ok(Err(panic_payload)) => {
            handle
                .join()
                .expect("panic worker thread should join cleanly");
            std::panic::resume_unwind(panic_payload);
        }
        Err(mpsc::RecvTimeoutError::Timeout) => {
            panic!("{name} exceeded {:?}", TEST_TIMEOUT);
        }
        Err(err) => {
            panic!("{name} did not report completion: {err}");
        }
    }
}

fn apply_stream_result(rendered: &mut String, result: StreamChunkResult) {
    match result.action {
        StreamChunkAction::Pass => rendered.push_str(&result.payload),
        StreamChunkAction::Replace => {
            rendered.clear();
            rendered.push_str(&result.payload);
        }
        StreamChunkAction::Stop => {
            panic!("stream unexpectedly stopped: {:?}", result.reason);
        }
    }
}

fn chunk_text(prefix: &str, index: usize) -> String {
    format!("{prefix}chunk_{index}_")
}

fn stream_body(prefix: &str, chunks: usize) -> String {
    (0..chunks)
        .map(|index| chunk_text(prefix, index))
        .collect::<String>()
}

fn assert_ok<T, E: std::fmt::Debug>(result: Result<T, E>, message: &str) -> T {
    result.unwrap_or_else(|err| panic!("{message}: {err:?}"))
}

#[test]
fn windowed_streaming_under_load() {
    run_with_timeout("windowed_streaming_under_load", move || {
        let runtime = build_windowed_runtime();
        let session = Arc::new(runtime.new_session(ctx("windowed-under-load")));
        session.begin_turn().expect("begin turn");

        let start = Arc::new(Barrier::new(2));
        let feed_session = session.clone();
        let feed_start = start.clone();
        let feed = thread::spawn(move || {
            let mut guard = feed_session.streaming_session(Stage::Output);
            assert_eq!(guard.mode(), StreamingTrigger::Windowed);

            let mut rendered = String::new();
            let mut source_so_far = String::new();
            let mut emitted_so_far = 0usize;
            let mut non_empty_emissions = 0usize;

            feed_start.wait();
            for index in 0..HIGH_LOAD_CHUNKS {
                let chunk = chunk_text("load_", index);
                source_so_far.push_str(&chunk);
                let result = guard.add_chunk(&chunk);
                match result.action {
                    StreamChunkAction::Pass => {
                        if !result.payload.is_empty() {
                            non_empty_emissions += 1;
                            emitted_so_far += result.payload.len();
                            assert!(
                                emitted_so_far + OVERLAP <= source_so_far.len(),
                                "windowed guard emitted past the held-back overlap boundary"
                            );
                        }
                        rendered.push_str(&result.payload);
                    }
                    StreamChunkAction::Replace => {
                        panic!("windowed allow-only fixture should not rewrite chunks");
                    }
                    StreamChunkAction::Stop => {
                        panic!("windowed stream stopped unexpectedly: {:?}", result.reason);
                    }
                }
            }

            let final_result = guard.end_stream();
            apply_stream_result(&mut rendered, final_result);
            assert_eq!(guard.chunks_received(), HIGH_LOAD_CHUNKS);
            assert!(
                non_empty_emissions > 0,
                "windowed mode should emit before end_stream"
            );

            (rendered, stream_body("load_", HIGH_LOAD_CHUNKS))
        });

        let mutate_session = session.clone();
        let mutate_start = start.clone();
        let mutate = thread::spawn(move || {
            mutate_start.wait();
            for index in 0..HIGH_LOAD_CHUNKS {
                assert_ok(
                    mutate_session.set_variable("flag", json!(index % 2 == 0)),
                    "set_variable should succeed",
                );
                assert_ok(
                    mutate_session.emit_event(
                        "incident.stream_tick",
                        Some(Lifetime::Bare(BareLifetime::PerSession)),
                        Some(json!({ "tick": index })),
                    ),
                    "emit_event should succeed",
                );
            }
        });

        let (rendered, expected) = feed.join().expect("feed thread should not panic");
        mutate.join().expect("mutation thread should not panic");

        assert_eq!(
            rendered, expected,
            "windowed stream reconstructed the wrong output"
        );
        session.end_turn().expect("end turn");
        session.close();
    });
}

#[test]
fn multiple_concurrent_streaming_sessions() {
    run_with_timeout("multiple_concurrent_streaming_sessions", move || {
        let runtime = build_runtime();
        let start = Arc::new(Barrier::new(CONCURRENT_STREAMS));

        let handles: Vec<_> = (0..CONCURRENT_STREAMS)
            .map(|stream_id| {
                let runtime = runtime.clone();
                let start = start.clone();
                thread::spawn(move || {
                    let session_id = format!("stream-session-{stream_id}");
                    let session = runtime.new_session(ctx(&session_id));
                    session.begin_turn().expect("begin turn");

                    let mut guard = session
                        .streaming_session(Stage::Output)
                        .with_trigger(StreamingTrigger::PerChunk);
                    let prefix = format!("stream_{stream_id}_");
                    let expected = stream_body(&prefix, 80);
                    let mut rendered = String::new();

                    start.wait();
                    for index in 0..80 {
                        apply_stream_result(
                            &mut rendered,
                            guard.add_chunk(&chunk_text(&prefix, index)),
                        );
                    }
                    apply_stream_result(&mut rendered, guard.end_stream());

                    session.end_turn().expect("end turn");
                    session.close();
                    (stream_id, rendered, expected)
                })
            })
            .collect();

        let results: Vec<_> = handles
            .into_iter()
            .map(|handle| handle.join().expect("stream thread should not panic"))
            .collect();

        for (stream_id, rendered, expected) in &results {
            assert_eq!(
                rendered, expected,
                "stream {stream_id} rendered the wrong output"
            );
            for other_id in 0..CONCURRENT_STREAMS {
                if other_id != *stream_id {
                    assert!(
                        !rendered.contains(&format!("stream_{other_id}_")),
                        "stream {stream_id} leaked data from stream {other_id}"
                    );
                }
            }
        }
    });
}

#[test]
fn on_complete_mode_correctness() {
    run_with_timeout("on_complete_mode_correctness", move || {
        let runtime = build_runtime();
        let finalize = Arc::new(Barrier::new(ON_COMPLETE_STREAMS));

        let handles: Vec<_> = (0..ON_COMPLETE_STREAMS)
            .map(|stream_id| {
                let runtime = runtime.clone();
                let finalize = finalize.clone();
                thread::spawn(move || {
                    let session_id = format!("on-complete-{stream_id}");
                    let session = runtime.new_session(ctx(&session_id));
                    session.begin_turn().expect("begin turn");

                    let prefix = format!("complete_{stream_id}_");
                    let expected = stream_body(&prefix, 40);
                    let mut guard = session.streaming_session(Stage::Output);
                    assert_eq!(guard.mode(), StreamingTrigger::OnComplete);

                    for index in 0..40 {
                        let chunk_result = guard.add_chunk(&chunk_text(&prefix, index));
                        assert_eq!(chunk_result.action, StreamChunkAction::Pass);
                        assert!(
                            chunk_result.payload.is_empty(),
                            "on_complete should not emit payload before end_stream"
                        );
                    }

                    finalize.wait();
                    let final_result = guard.end_stream();
                    assert_eq!(final_result.action, StreamChunkAction::Pass);
                    assert_eq!(final_result.payload, expected);

                    session.end_turn().expect("end turn");
                    session.close();
                    (stream_id, final_result.payload, expected)
                })
            })
            .collect();

        for handle in handles {
            let (stream_id, rendered, expected) =
                handle.join().expect("stream thread should not panic");
            assert_eq!(
                rendered, expected,
                "stream {stream_id} received the wrong final text"
            );
        }
    });
}

#[test]
fn stream_mixed_with_non_streaming() {
    run_with_timeout("stream_mixed_with_non_streaming", move || {
        let runtime = build_runtime();
        let start = Arc::new(Barrier::new(CONCURRENT_STREAMS));

        let handles: Vec<_> = (0..CONCURRENT_STREAMS)
            .map(|index| {
                let runtime = runtime.clone();
                let start = start.clone();
                thread::spawn(move || {
                    let session_id = format!("mixed-session-{index}");
                    let session = runtime.new_session(ctx(&session_id));
                    session.begin_turn().expect("begin turn");
                    start.wait();

                    let rendered = if index < CONCURRENT_STREAMS / 2 {
                        let prefix = format!("mixed_stream_{index}_");
                        let expected = stream_body(&prefix, 30);
                        let mut guard = session
                            .streaming_session(Stage::Output)
                            .with_trigger(StreamingTrigger::PerChunk);
                        let mut rendered = String::new();
                        for chunk_index in 0..30 {
                            apply_stream_result(
                                &mut rendered,
                                guard.add_chunk(&chunk_text(&prefix, chunk_index)),
                            );
                        }
                        apply_stream_result(&mut rendered, guard.end_stream());
                        assert_eq!(rendered, expected, "streaming path returned the wrong text");
                        rendered
                    } else {
                        let mut output = format!("regular_output_session_{index}");
                        let original = output.clone();
                        let verdict = session.validate_output(&mut output);
                        assert!(verdict.allowed, "non-streaming output should be allowed");
                        assert_eq!(
                            output, original,
                            "non-streaming output should remain unchanged"
                        );
                        output
                    };

                    session.end_turn().expect("end turn");
                    session.close();
                    (index, rendered)
                })
            })
            .collect();

        let mut results = handles
            .into_iter()
            .map(|handle| handle.join().expect("mixed thread should not panic"))
            .collect::<Vec<_>>();
        results.sort_by_key(|(index, _)| *index);

        for (index, rendered) in results {
            if index < CONCURRENT_STREAMS / 2 {
                assert_eq!(rendered, stream_body(&format!("mixed_stream_{index}_"), 30));
                for other_index in CONCURRENT_STREAMS / 2..CONCURRENT_STREAMS {
                    assert!(
                        !rendered.contains(&format!("regular_output_session_{other_index}")),
                        "streaming session {index} was contaminated by non-streaming output {other_index}"
                    );
                }
            } else {
                assert_eq!(rendered, format!("regular_output_session_{index}"));
                for other_index in 0..CONCURRENT_STREAMS / 2 {
                    assert!(
                        !rendered.contains(&format!("mixed_stream_{other_index}_")),
                        "non-streaming session {index} was contaminated by streaming output {other_index}"
                    );
                }
            }
        }
    });
}
