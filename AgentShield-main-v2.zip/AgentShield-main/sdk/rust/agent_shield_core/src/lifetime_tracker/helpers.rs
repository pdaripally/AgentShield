//! Low-risk helper types and pure functions extracted from
//! [`super`](`super`)'s monolithic implementation. None of these mutate
//! session state directly; they are the variants, parsers, value
//! constructors, and canonicalisers used by the central
//! [`super::LifetimeTracker`].
//!
//! Behavior is byte-identical to the previous inline implementation —
//! this module is a pure mechanical relocation to keep the
//! locked-state-mutation path in [`super`](`super`) focused.

use chrono::{DateTime, Utc};
use serde_json::Value;

use crate::events::{ApprovalEventKind, EventId};
use crate::lifetime::{BareLifetime, Lifetime, LifetimeBranch, LifetimeMap};
use crate::update_policy::UpdateError;
use crate::variables::{Variable, VariableType};

// ── Variable status (§9.3) ───────────────────────────────────────────

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum VarStatus {
    Unset,
    Resolved,
    Denied,
}

/// Outcome of a resolver / approval, used to select a branch from a
/// [`LifetimeMap`].
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ResolverOutcome {
    Allow,
    Deny,
    Cancelled,
}

impl ResolverOutcome {
    pub(super) fn from_approval_kind(k: ApprovalEventKind) -> Self {
        match k {
            ApprovalEventKind::Allow => ResolverOutcome::Allow,
            ApprovalEventKind::Deny => ResolverOutcome::Deny,
            ApprovalEventKind::Cancelled => ResolverOutcome::Cancelled,
        }
    }
}

/// Select the appropriate bare lifetime branch from a [`Lifetime`] given the
/// resolver outcome.  Bare forms ignore `outcome`; the map form selects
/// `allow`, `deny`, or `cancelled` (with `cancelled` falling back to `deny`
/// per §9.1.2). Returns the branch's literal [`BareLifetime`] when the
/// branch is in literal form. For the §9.1.2.1 `expression:` form,
/// callers MUST use [`select_branch_full`] which evaluates the
/// expression at write time. This non-evaluating helper falls back to
/// `PerSession` when it encounters an expression branch — the
/// conservative default if no evaluation context is available.
pub fn select_branch(lifetime: &Lifetime, outcome: ResolverOutcome) -> BareLifetime {
    match select_branch_raw(lifetime, outcome) {
        LifetimeBranch::Bare(b) => b,
        // Conservative fallback for non-evaluating callers (tests,
        // legacy code paths). The evaluated form lands at write time
        // inside `LifetimeTracker::set_variable_keyed_full`.
        LifetimeBranch::Expression(_) => BareLifetime::PerSession,
    }
}

/// Pick the branch as-is (literal or expression), without evaluating
/// expressions. Used internally by the write path to decide whether to
/// fire the §9.1.2.1 expression evaluator.
pub(crate) fn select_branch_raw(lifetime: &Lifetime, outcome: ResolverOutcome) -> LifetimeBranch {
    match lifetime {
        Lifetime::Bare(b) => LifetimeBranch::Bare(b.clone()),
        Lifetime::Map(LifetimeMap {
            allow,
            deny,
            cancelled,
        }) => match outcome {
            ResolverOutcome::Allow => allow.clone(),
            ResolverOutcome::Deny => deny.clone(),
            ResolverOutcome::Cancelled => cancelled.clone().unwrap_or_else(|| deny.clone()),
        },
    }
}

// ── Variable cache entry ─────────────────────────────────────────────

#[derive(Debug, Clone)]
pub struct VariableState {
    pub value: Value,
    pub status: VarStatus,
    pub set_at: DateTime<Utc>,
    pub expires_at: Option<DateTime<Utc>>,
    pub lifetime_branch: Option<BareLifetime>,
    pub deny_reason: Option<String>,
    /// Trigger ids for `until_event:` invalidation.
    pub until_events: Vec<EventId>,
    /// Approval-event provenance (§10.5). Each successful auto-flip pushes
    /// the originating event id; clearing one of these events removes it
    /// from the list. The variable remains in its current state as long as
    /// the list is non-empty; clearing the LAST id reverts to `unset`.
    pub auto_flipped_by: Vec<EventId>,
    /// Resolver `kind:` (or "tool" / "populator" / "host" / etc.) that
    /// last produced this value. `None` for runtime-API writes that
    /// don't surface a source — see §9.3.2 `@source_kind`.
    pub source_kind: Option<String>,
    /// Identifier of the resolver / populator / tool that last set the
    /// variable. `None` for host-API writes — see §9.3.2 `@set_by`.
    pub set_by: Option<String>,
    /// §9.3.2 `@source_params`: snapshot of the writer's resource-bound
    /// namespace (`@tool.params`, `@endpoint.{path_params,query_params,
    /// params}`, or `@agent.params`) captured at the moment this entry
    /// last transitioned to `resolved` via a populator or resolver.
    /// `None` for host-runtime-API writes and while `@status != 'resolved'`.
    /// Read-only; never triggers auto-resolution. Spec wording:
    /// "For `endpoint` writers, `@source_params` is the merged object
    /// `{ path: <path_params>, query: <query_params>, body: <params> }`."
    pub source_params: Option<Value>,
}

impl VariableState {
    pub(super) fn unset(now: DateTime<Utc>) -> Self {
        Self {
            value: Value::Null,
            status: VarStatus::Unset,
            set_at: now,
            expires_at: None,
            lifetime_branch: None,
            deny_reason: None,
            until_events: Vec::new(),
            auto_flipped_by: Vec::new(),
            source_kind: None,
            set_by: None,
            source_params: None,
        }
    }
}

// ── Predicate cache entry ────────────────────────────────────────────

#[derive(Debug, Clone)]
pub struct PredicateState {
    pub value: bool,
    pub set_at: DateTime<Utc>,
    pub expires_at: Option<DateTime<Utc>>,
    pub lifetime: Option<BareLifetime>,
    pub until_events: Vec<EventId>,
}

// ── Tracker error ────────────────────────────────────────────────────

#[derive(Debug, thiserror::Error)]
pub enum TrackerError {
    #[error("unknown variable `{0}` (not in registry)")]
    UnknownVariable(String),

    #[error("update policy rejected the write: {0}")]
    UpdatePolicy(#[from] UpdateError),
}

impl TrackerError {
    /// PII-safe discriminator used at info+ log levels. The full
    /// `Display` / `Debug` of [`TrackerError`] chains through
    /// [`UpdateError`], whose `EnumNotInMembers` and
    /// `UpdateExpressionFailed` variants carry user-derived value /
    /// detail strings (populators feed tool-result data into update
    /// pipelines). Logging sites at `info+` MUST use this discriminator
    /// instead of `{}` / `{:?}`; the full chain is fine at `debug`.
    pub fn kind_safe(&self) -> &'static str {
        match self {
            TrackerError::UnknownVariable(_) => "unknown_variable",
            TrackerError::UpdatePolicy(e) => match e {
                UpdateError::TypeMismatch { .. } => "update_policy.type_mismatch",
                UpdateError::EnumNotInMembers { .. } => "update_policy.enum_not_in_members",
                UpdateError::UpdateProducedNull { .. } => "update_policy.produced_null",
                UpdateError::UpdateExpressionFailed { .. } => "update_policy.expression_failed",
                UpdateError::NestingExceeded { .. } => "update_policy.nesting_exceeded",
            },
        }
    }
}

// ── Pure helpers ─────────────────────────────────────────────────────

pub(super) fn approval_value(decl: &Variable, payload: Option<&Value>) -> Value {
    if let Some(p) = payload {
        if let Some(v) = p.get("value") {
            return v.clone();
        }
    }
    if let Some(d) = &decl.default {
        return d.clone();
    }
    if matches!(decl.var_type, VariableType::Boolean) {
        return Value::Bool(true);
    }
    Value::Null
}

pub(super) fn default_deny_reason(kind: ApprovalEventKind) -> &'static str {
    match kind {
        ApprovalEventKind::Allow => "",
        ApprovalEventKind::Deny => "denied",
        ApprovalEventKind::Cancelled => "cancelled",
    }
}

/// §9.1.2.1: evaluate a lifetime branch's expression form at write time.
/// Per spec the expression evaluates against `@incoming` (the just-
/// stored value) and `@current` (the prior value); the result MUST be:
///
///   - a string matching a §9.1.1 keyword (`per_call` / `per_turn` /
///     `per_session` / `per_request`)
///   - a string in the §9.3 closed event namespace ⇒ `until_event:`
///   - a `duration` value (currently surfaced as an ISO-8601 string)
///     ⇒ `for:`
///
/// Anything else falls back to `PerSession` with a structured warning —
/// the conservative default for unrecognized expression results.
pub(super) fn evaluate_lifetime_expression(
    expr: &str,
    incoming: &Value,
    current: Option<&Value>,
) -> BareLifetime {
    use crate::expressions::eval::{evaluate_to_value, EvalContext};
    use std::collections::HashMap;

    let mut attrs: HashMap<String, Value> = HashMap::new();
    attrs.insert("@incoming".into(), incoming.clone());
    attrs.insert("@current".into(), current.cloned().unwrap_or(Value::Null));
    let mut ctx = EvalContext::from_attrs(&attrs);
    ctx.is_gating_site = false;
    let v = evaluate_to_value(expr, &ctx);

    match v {
        Some(Value::String(s)) => match s.as_str() {
            "per_call" => BareLifetime::PerCall,
            "per_turn" => BareLifetime::PerTurn,
            "per_session" => BareLifetime::PerSession,
            "per_request" => BareLifetime::PerRequest,
            other => {
                // Try as a §9.3 event id.
                if let Ok(id) = crate::events::EventId::parse(other) {
                    BareLifetime::UntilEvent(vec![id])
                } else if let Ok(d) = crate::lifetime::parse_duration(other) {
                    BareLifetime::For(d)
                } else {
                    // Defensive PR2: lifetime expressions can evaluate against
                    // `@incoming` (populator-fed value), so the returned string
                    // may carry user-derived data. Warn carries only metadata
                    // (length); the full content is debug-only.
                    log::warn!(
                        target: "agent_shield::lifetime_tracker",
                        "lifetime expression returned unrecognized string (len={}) — falling back to per_session (§9.1.2.1)",
                        other.len()
                    );
                    log::debug!(
                        target: "agent_shield::lifetime_tracker",
                        "lifetime expression returned unrecognized string `{}` — falling back to per_session (§9.1.2.1)",
                        other
                    );
                    BareLifetime::PerSession
                }
            }
        },
        Some(other) => {
            // Defensive PR2: the returned `Value` originates from the
            // lifetime expression which evaluates against `@incoming`, so
            // any populator-fed user data could surface here. Warn carries
            // only the JSON kind discriminator; full Debug at debug level.
            log::warn!(
                target: "agent_shield::lifetime_tracker",
                "lifetime expression returned non-string value (kind={}) — falling back to per_session (§9.1.2.1)",
                value_kind(&other)
            );
            log::debug!(
                target: "agent_shield::lifetime_tracker",
                "lifetime expression returned non-string {:?} — falling back to per_session (§9.1.2.1)",
                other
            );
            BareLifetime::PerSession
        }
        None => {
            log::warn!(
                target: "agent_shield::lifetime_tracker",
                "lifetime expression failed to evaluate — falling back to per_session (§9.1.2.1)"
            );
            BareLifetime::PerSession
        }
    }
}

/// Stable JSON-kind discriminator used by [`evaluate_lifetime_expression`]'s
/// warn-level fallback log so we never echo populator-fed payload data at
/// info+. Returns one of `null`, `bool`, `number`, `string`, `array`,
/// `object` per the JSON value taxonomy.
fn value_kind(v: &Value) -> &'static str {
    match v {
        Value::Null => "null",
        Value::Bool(_) => "bool",
        Value::Number(_) => "number",
        Value::String(_) => "string",
        Value::Array(_) => "array",
        Value::Object(_) => "object",
    }
}

/// §9.4: canonical JSON serialization of a binding-key value. Used as
/// the second tuple element in `Inner::vars`'s map key so per-key
/// entries route to independent storage slots.
///
/// `None` ⇒ `None` (non-keyed slot).
/// `Some(v)` ⇒ `Some(canonical_json(v))` — keys are deep-equality compared
/// via canonical key form: object keys sorted, no whitespace.
pub(crate) fn canonical_key(key: Option<&Value>) -> Option<String> {
    key.map(canonicalize_value)
}

fn canonicalize_value(v: &Value) -> String {
    let mut out = String::new();
    write_canonical(v, &mut out);
    out
}

fn write_canonical(v: &Value, out: &mut String) {
    match v {
        Value::Null => out.push_str("null"),
        Value::Bool(b) => out.push_str(if *b { "true" } else { "false" }),
        Value::Number(n) => out.push_str(&n.to_string()),
        Value::String(s) => {
            // serde_json::to_string handles escaping correctly.
            out.push_str(&serde_json::to_string(s).unwrap_or_default());
        }
        Value::Array(arr) => {
            out.push('[');
            for (i, item) in arr.iter().enumerate() {
                if i > 0 {
                    out.push(',');
                }
                write_canonical(item, out);
            }
            out.push(']');
        }
        Value::Object(obj) => {
            // Sort keys lexicographically for deterministic equality.
            let mut keys: Vec<&String> = obj.keys().collect();
            keys.sort();
            out.push('{');
            for (i, k) in keys.iter().enumerate() {
                if i > 0 {
                    out.push(',');
                }
                out.push_str(&serde_json::to_string(k).unwrap_or_default());
                out.push(':');
                if let Some(val) = obj.get(*k) {
                    write_canonical(val, out);
                }
            }
            out.push('}');
        }
    }
}
