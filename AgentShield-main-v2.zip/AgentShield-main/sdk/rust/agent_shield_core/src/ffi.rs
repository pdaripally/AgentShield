//! C FFI surface for the unified-resolver runtime.
//!
//! This module exposes [`crate::runtime`]'s `RuntimeBuilder`,
//! `GuardrailsRuntime`, and `GuardrailsSession` through a flat,
//! opaque-handle C ABI. Every exported symbol is prefixed `shield_`.
//!
//! ## Conventions
//!
//! - Opaque handles are returned by `*_new` / `from_*` / `build` and
//!   freed by the matching `*_free` symbol. Passing `null` to any
//!   `*_free` is a no-op.
//! - Strings crossing the boundary are UTF-8 `*const c_char` (input)
//!   and `*mut c_char` (output). Output strings are owned by Rust and
//!   must be freed with [`shield_free_string`].
//! - JSON-typed inputs (`*_json` parameters) are parsed with
//!   `serde_json`; null pointers are rejected with a populated `err`
//!   string. Output JSON is always serialized through `serde_json`.
//! - Fallible operations take a `char** err` out-parameter; on failure
//!   `*err` is set to a freshly-allocated UTF-8 string describing the
//!   error and the function returns `null` / `-1` / a sentinel.
//!   Callers MUST free `*err` with [`shield_free_string`] when it is
//!   non-null.
//! - Callbacks are paired with a `ShieldFreeResultCallback` so the
//!   host owns the lifetime of strings it allocates and passes back to
//!   Rust.
//! - Every `extern "C"` function is null-defensive: passing a null
//!   handle / string returns an error, never UB.
//!
//! ## Resolver-envelope callback shape
//!
//! All five resolver-host callbacks return a JSON-serialized
//! `ResolverResponse` (§11.3):
//!
//! ```json
//! { "decision": "allow"|"deny"|"cancelled",
//!   "value": <any>|null,
//!   "set_variables": { "name": <any>, ... },
//!   "reason": "..." }
//! ```
//!
//! Hosts allocate the response string themselves and pass a
//! `ShieldFreeResultCallback` so Rust can release it after parsing.
//!
//! ## Threading
//!
//! `GuardrailsRuntime` is `Sync` and `Send`. Sessions are similarly
//! `Sync`/`Send` (interior-mutability via atomics + mutexes). The host
//! is responsible for ensuring registered C callbacks are themselves
//! thread-safe — the wrappers here mark their `user_data` pointers
//! `Send + Sync`.

#![allow(clippy::missing_safety_doc)]

use std::collections::HashMap;
use std::ffi::{c_void, CStr, CString};
use std::os::raw::c_char;
use std::path::PathBuf;
use std::sync::Arc;

use serde_json::{Map, Value};

use crate::guard_policy::Action;
use crate::guard_policy_runtime::streaming::StreamingTrigger;
use crate::guard_policy_runtime::{
    ClassifierCaller, ClassifierVerdict, LlmCaller, LlmResponse, Span, StageVerdict,
    StreamChunkAction, StreamingGuard,
};
use crate::lifetime_tracker::{VarStatus, VariableState};
use crate::observability::{ObservabilityProvider, ShieldLogEvent, Stage as ObsStage};
use crate::populator::{Extractor, Invocation};
use crate::resolver::{ResolverDecision, ResolverResponse};
use crate::resolver_runtime::{
    AgentResolveRequest, AgentResolver, DelegateDispatcher, DelegateRequest, ResolverRuntimeError,
};
use crate::runtime::{
    GuardrailsRuntime, GuardrailsSession, RequestContext, RuntimeBuilder, StreamingOptions,
};

// ────────────────────────────────────────────────────────────────────
// Panic safety across the C ABI
// ────────────────────────────────────────────────────────────────────
//
// Every `pub unsafe extern "C" fn` below wraps its body in
// `ffi_guard!`, which itself uses `std::panic::catch_unwind` with
// `AssertUnwindSafe`. This is mandatory: a panic that unwinds across
// the C ABI boundary into the host language (PyO3, napi-rs, .NET
// P/Invoke) is undefined behavior. We accept the `AssertUnwindSafe`
// obligation here — many of the captured values (mutex guards,
// builders, callback holders) are not `RefUnwindSafe`, but the
// alternative (UB across the FFI boundary) is strictly worse.
//
// On panic, the wrapper returns a structured failure value:
//   * `ptr`  → null pointer
//   * `code` → caller-supplied sentinel (e.g. `-1`, `0`, `false`)
//   * `void` → swallowed, fn returns normally
//
// The host language sees a normal failure return rather than a
// foreign-language stack unwind, and the panic is logged to stderr by
// the Rust default panic hook so the underlying bug remains visible.
//
// The canonical ABI surface for agent_shield_core IS this file
// (ffi.rs). Language bindings consume it directly via pyo3, napi-rs,
// and P/Invoke. No hand-maintained C header is shipped; external
// C/C++ embedders should generate one via cbindgen against this
// crate.

macro_rules! ffi_guard {
    (ptr, $body:block) => {{
        match std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| $body)) {
            Ok(v) => v,
            Err(_) => std::ptr::null_mut(),
        }
    }};
    (code, $err_value:expr, $body:block) => {{
        match std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| $body)) {
            Ok(v) => v,
            Err(_) => $err_value,
        }
    }};
    (void, $body:block) => {{
        let _ = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| $body));
    }};
}

// ────────────────────────────────────────────────────────────────────
// Helpers — string / JSON / error plumbing
// ────────────────────────────────────────────────────────────────────

/// Convert `*const c_char` → `&str`. `None` on null / non-UTF-8.
unsafe fn cstr_to_str<'a>(ptr: *const c_char) -> Option<&'a str> {
    if ptr.is_null() {
        return None;
    }
    CStr::from_ptr(ptr).to_str().ok()
}

/// Allocate a C string from a Rust `&str`. Null on internal NUL byte.
fn string_to_c(s: &str) -> *mut c_char {
    match CString::new(s) {
        Ok(c) => c.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

/// Serialize a `serde::Serialize` value to a JSON C string.
fn json_to_c<T: serde::Serialize>(val: &T) -> *mut c_char {
    match serde_json::to_string(val) {
        Ok(s) => string_to_c(&s),
        Err(_) => string_to_c(r#"{"error":"serialization failed"}"#),
    }
}

/// Write an error string into a `char** err` slot. The previous value
/// (if any) is leaked — callers are expected to start with `NULL`.
unsafe fn write_err(err: *mut *mut c_char, msg: &str) {
    if err.is_null() {
        return;
    }
    *err = string_to_c(msg);
}

/// Parse a `*const c_char` JSON value into `serde_json::Value`. `None`
/// pointer → `Ok(Value::Null)`. Invalid JSON → `Err(reason)`.
unsafe fn parse_json_value(ptr: *const c_char) -> Result<Value, String> {
    match cstr_to_str(ptr) {
        None => Ok(Value::Null),
        Some(s) => serde_json::from_str(s).map_err(|e| format!("invalid JSON: {e}")),
    }
}

/// Same as [`parse_json_value`] but null pointers are kept as `None`
/// instead of being mapped to `Value::Null`. Used for optional payload
/// arguments where the caller's intent ("not provided") differs from
/// "explicit null".
unsafe fn parse_json_value_opt(ptr: *const c_char) -> Result<Option<Value>, String> {
    match cstr_to_str(ptr) {
        None => Ok(None),
        Some("") => Ok(None),
        Some(s) => serde_json::from_str(s)
            .map(Some)
            .map_err(|e| format!("invalid JSON: {e}")),
    }
}

// ────────────────────────────────────────────────────────────────────
// Manual JSON shapes for non-Serialize types
// ────────────────────────────────────────────────────────────────────
//
// Several runtime types do not derive `Serialize` because they hold
// references to engine internals or carry transient handles. The FFI
// boundary needs a stable JSON wire form regardless. The helpers below
// turn each into a hand-written `serde_json::Value`.

fn action_to_json(a: &Action) -> Value {
    Value::String(
        match a {
            Action::Block => "block",
            Action::Warn => "warn",
            Action::Redact => "redact",
            Action::Append => "append",
            Action::Prepend => "prepend",
            Action::DeclassifyTo => "declassify_to",
        }
        .to_string(),
    )
}

fn stage_verdict_to_json(v: &StageVerdict) -> Value {
    let mut m = Map::new();
    m.insert("allowed".into(), Value::Bool(v.allowed));
    m.insert(
        "action".into(),
        v.action.as_ref().map(action_to_json).unwrap_or(Value::Null),
    );
    m.insert(
        "reason".into(),
        v.reason
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    m.insert(
        "policy".into(),
        v.policy
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    m.insert(
        "evaluate_when_index".into(),
        v.evaluate_when_index
            .map(|i| Value::Number(serde_json::Number::from(i as u64)))
            .unwrap_or(Value::Null),
    );
    m.insert(
        "bypassed_by_allowed_when".into(),
        Value::Bool(v.bypassed_by_allowed_when),
    );
    m.insert(
        "redaction".into(),
        v.redaction
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    m.insert(
        "appended".into(),
        v.appended
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    m.insert(
        "prepended".into(),
        v.prepended
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    m.insert(
        "pending_resolution".into(),
        v.pending_resolution
            .as_ref()
            .map(pending_resolution_to_json)
            .unwrap_or(Value::Null),
    );
    m.insert(
        "invocation_hash".into(),
        v.invocation_hash
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    m.insert(
        "post_validation_invocation_hash".into(),
        v.post_validation_invocation_hash
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    Value::Object(m)
}

fn pending_resolution_to_json(p: &crate::resolver_runtime::PendingResolution) -> Value {
    let mut m = Map::new();
    m.insert("tool".into(), Value::String(p.tool.clone()));
    m.insert("variable".into(), Value::String(p.variable.clone()));
    m.insert(
        "prompt".into(),
        p.prompt
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    m.insert("request_id".into(), Value::String(p.request_id.clone()));
    m.insert("kind".into(), Value::String(p.kind.into()));
    Value::Object(m)
}

fn var_status_str(s: &VarStatus) -> &'static str {
    match s {
        VarStatus::Unset => "unset",
        VarStatus::Resolved => "resolved",
        VarStatus::Denied => "denied",
    }
}

fn variable_state_to_json(st: &VariableState) -> Value {
    let mut m = Map::new();
    m.insert("value".into(), st.value.clone());
    m.insert(
        "status".into(),
        Value::String(var_status_str(&st.status).to_string()),
    );
    m.insert("set_at".into(), Value::String(st.set_at.to_rfc3339()));
    m.insert(
        "expires_at".into(),
        st.expires_at
            .map(|t| Value::String(t.to_rfc3339()))
            .unwrap_or(Value::Null),
    );
    m.insert(
        "deny_reason".into(),
        st.deny_reason
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    m.insert(
        "source_kind".into(),
        st.source_kind
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    m.insert(
        "set_by".into(),
        st.set_by
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    Value::Object(m)
}

fn resolver_decision_str(d: &ResolverDecision) -> &'static str {
    match d {
        ResolverDecision::Allow => "allow",
        ResolverDecision::Deny => "deny",
        ResolverDecision::Cancelled => "cancelled",
    }
}

#[allow(dead_code)]
fn parse_resolver_decision(s: &str) -> Option<ResolverDecision> {
    // Retained as a thin shim for the few internal sites that bypass
    // wire_shapes and do their own decoding. The canonical entry point
    // is `wire_shapes::parse_resolver_response_json`.
    match s {
        "allow" => Some(ResolverDecision::Allow),
        "deny" => Some(ResolverDecision::Deny),
        "cancelled" | "canceled" => Some(ResolverDecision::Cancelled),
        _ => None,
    }
}

/// Parse a `ResolverResponse` from the host's JSON envelope. On any
/// shape error returns a fail-closed `Deny` with the parse reason.
///
/// This is a thin wrapper around the canonical
/// [`crate::wire_shapes::parse_resolver_response_json`] — kept here for
/// symmetry with the other in-module helpers, but every binding MUST
/// route through the canonical entry point.
fn parse_resolver_response_json(s: &str) -> ResolverResponse {
    crate::wire_shapes::parse_resolver_response_json(s)
}

fn resolver_response_to_json(r: &ResolverResponse) -> Value {
    let mut m = Map::new();
    m.insert(
        "decision".into(),
        Value::String(resolver_decision_str(&r.decision).to_string()),
    );
    m.insert("value".into(), r.value.clone().unwrap_or(Value::Null));
    let mut sv = Map::new();
    for (k, vv) in &r.set_variables {
        sv.insert(k.clone(), vv.clone());
    }
    m.insert("set_variables".into(), Value::Object(sv));
    m.insert(
        "reason".into(),
        r.reason
            .as_ref()
            .map(|s| Value::String(s.clone()))
            .unwrap_or(Value::Null),
    );
    Value::Object(m)
}

// ────────────────────────────────────────────────────────────────────
// Opaque handles
// ────────────────────────────────────────────────────────────────────

/// Opaque builder handle. The inner [`RuntimeBuilder`] is held in an
/// `Option` so the chainable consume-`self` register methods can move
/// the value out, mutate, and put it back behind the same pointer.
pub struct ShieldBuilder {
    inner: Option<RuntimeBuilder>,
}

/// Opaque runtime handle. Wraps an `Arc<GuardrailsRuntime>` so
/// sessions share the immutable engine state cheaply.
pub struct ShieldRuntime {
    inner: Arc<GuardrailsRuntime>,
}

/// Opaque session handle. Owns one [`GuardrailsSession`].
pub struct ShieldSession {
    inner: GuardrailsSession,
    /// Hold a strong ref to the runtime so the session outlives any
    /// caller that frees the runtime first. The session already
    /// internally holds an `Arc<GuardrailsRuntime>` — this is purely
    /// belt-and-suspenders.
    _runtime: Arc<GuardrailsRuntime>,
}

/// Opaque streaming-session handle. Wraps a [`StreamingGuard`].
pub struct ShieldStream {
    inner: StreamingGuard,
}

// ────────────────────────────────────────────────────────────────────
// Callback type aliases
// ────────────────────────────────────────────────────────────────────

/// Free callback paired with every host-allocated string callback. Rust
/// invokes this exactly once per allocated buffer, after parsing.
pub type ShieldFreeResultCallback = unsafe extern "C" fn(ptr: *mut c_char, user_data: *mut c_void);

/// Resolver request envelope handed to the agent host hook (and used by
/// the canonical-tool-call signal that synthesises `kind: human`).
/// String fields are valid only for the duration of the callback.
///
/// `resource_params_json` carries the §11.10 `resource.params` map as a
/// UTF-8 JSON string (`null` when no invocation context is bound). The
/// host SHOULD parse it lazily — null/empty means "no params"; any
/// other value is a JSON-encoded object.
#[repr(C)]
pub struct ShieldResolverRequest {
    pub request_id: *const c_char,
    pub variable: *const c_char,
    pub resource_kind: *const c_char,
    pub resource_name: *const c_char,
    pub resource_params_json: *const c_char,
    pub prompt: *const c_char,
    pub reason: *const c_char,
    pub context_json: *const c_char,
}

/// Delegate request envelope. Includes the resolver context plus the
/// configurations[] entry that determined the routing.
///
/// `lifetime_json` carries the resolver's `lifetime:` declaration
/// (§11.12.1) as a UTF-8 JSON string so the dispatcher can mint
/// per-call lifetime envelopes verbatim. `null` when the resolver
/// did not declare a lifetime.
#[repr(C)]
pub struct ShieldDelegateRequest {
    pub configuration_id: *const c_char,
    pub configuration_type: *const c_char,
    pub configuration_json: *const c_char,
    pub lifetime_json: *const c_char,
    pub base: ShieldResolverRequest,
}

/// Returns a host-allocated UTF-8 JSON string encoding the
/// [`ResolverResponse`] envelope. The host MUST also register a
/// matching `free_result` callback so Rust can release the buffer.
pub type ShieldAgentResolverCallback =
    unsafe extern "C" fn(req: *const ShieldResolverRequest, user_data: *mut c_void) -> *mut c_char;

pub type ShieldDelegateDispatcherCallback =
    unsafe extern "C" fn(req: *const ShieldDelegateRequest, user_data: *mut c_void) -> *mut c_char;

/// LLM / classifier request envelope.
#[repr(C)]
pub struct ShieldLlmRequest {
    pub configuration_id: *const c_char,
    pub prompt: *const c_char,
    pub input: *const c_char,
    pub context_json: *const c_char,
}

/// Returns a JSON string `{decision, reason, ...}` (LlmResponse) or
/// `null` to fail closed.
pub type ShieldLlmCallback =
    unsafe extern "C" fn(req: *const ShieldLlmRequest, user_data: *mut c_void) -> *mut c_char;

/// Returns a JSON string `{score, threshold, flagged, label?, reason?}`
/// or `null` to fail closed.
pub type ShieldClassifierCallback =
    unsafe extern "C" fn(req: *const ShieldLlmRequest, user_data: *mut c_void) -> *mut c_char;

/// Observability log callback. The `event_json` buffer is owned by Rust
/// and is valid only for the duration of the callback.
pub type ShieldLogCallback =
    unsafe extern "C" fn(event_json: *const c_char, user_data: *mut c_void);

/// Extractor callback. Receives the raw tool result as JSON and returns
/// a host-allocated JSON string with the extracted shape (or `null` to
/// signal "skip this populator").
pub type ShieldExtractorCallback =
    unsafe extern "C" fn(result_json: *const c_char, user_data: *mut c_void) -> *mut c_char;

// ────────────────────────────────────────────────────────────────────
// Callback holder — shared shim for paired callback + free + user_data
// ────────────────────────────────────────────────────────────────────

struct CallbackHolder<F> {
    cb: F,
    free: ShieldFreeResultCallback,
    user_data: *mut c_void,
}

// SAFETY: The C contract requires that every callback the host
// registers is safe to invoke from any thread, and that `user_data`
// points either to thread-safe state or `null`. The holders are
// stored inside `Arc<dyn ... + Send + Sync>` traits, so we mark the
// raw pointer fields `Send` here and rely on the host to honor the
// contract.
unsafe impl<F> Send for CallbackHolder<F> {}
// SAFETY: Same contract as the `Send` impl above — the host guarantees
// the callback and `user_data` can be shared across threads for the
// lifetime of the runtime.
unsafe impl<F> Sync for CallbackHolder<F> {}

impl<F> CallbackHolder<F> {
    /// Read a host-allocated UTF-8 string and free it via the paired
    /// release callback.
    unsafe fn read_and_free(&self, ptr: *mut c_char) -> Result<String, &'static str> {
        if ptr.is_null() {
            return Err("callback returned null");
        }
        let result = CStr::from_ptr(ptr).to_str().map(|s| s.to_owned());
        (self.free)(ptr, self.user_data);
        result.map_err(|_| "callback returned non-UTF8 string")
    }
}

/// Build a CString that is safe to hand to a callback. NUL bytes in the
/// source are stripped (replaced with `' '`).
fn cstring_lossy(s: &str) -> CString {
    let cleaned: String = s.chars().map(|c| if c == '\0' { ' ' } else { c }).collect();
    CString::new(cleaned).unwrap_or_else(|_| CString::new("").unwrap())
}

// ────────────────────────────────────────────────────────────────────
// Resolver / dispatcher / LLM / classifier wrappers
// ────────────────────────────────────────────────────────────────────

struct CAgentResolver {
    holder: Arc<CallbackHolder<ShieldAgentResolverCallback>>,
}

impl AgentResolver for CAgentResolver {
    fn resolve(&self, req: AgentResolveRequest) -> ResolverResponse {
        let h = self.holder.clone();
        let ctx_json = serde_json::to_string(&Value::Object(req.context.clone()))
            .unwrap_or_else(|_| "{}".into());
        let resource_kind_str = req.resource_kind.map(|k| match k {
            crate::variables::ResourceKind::Tool => "tool",
            crate::variables::ResourceKind::Endpoint => "endpoint",
            crate::variables::ResourceKind::Agent => "agent",
        });
        let reason_str = req.reason.clone().unwrap_or_default();
        let variable_str = req.variable.clone().unwrap_or_default();
        let resource_name_str = req.resource_name.clone().unwrap_or_default();
        let resource_params_json_str = req
            .resource_params
            .as_ref()
            .and_then(|p| serde_json::to_string(p).ok());

        let request_id_c = cstring_lossy(&req.request_id);
        let variable_c = cstring_lossy(&variable_str);
        let kind_c = resource_kind_str.map(cstring_lossy);
        let resource_name_c = cstring_lossy(&resource_name_str);
        let resource_params_c = resource_params_json_str.as_deref().map(cstring_lossy);
        let prompt_c = cstring_lossy(&req.prompt);
        let reason_c = cstring_lossy(&reason_str);
        let ctx_c = cstring_lossy(&ctx_json);

        let envelope = ShieldResolverRequest {
            request_id: request_id_c.as_ptr(),
            variable: if variable_str.is_empty() {
                std::ptr::null()
            } else {
                variable_c.as_ptr()
            },
            resource_kind: kind_c
                .as_ref()
                .map(|c| c.as_ptr())
                .unwrap_or(std::ptr::null()),
            resource_name: if resource_name_str.is_empty() {
                std::ptr::null()
            } else {
                resource_name_c.as_ptr()
            },
            resource_params_json: resource_params_c
                .as_ref()
                .map(|c| c.as_ptr())
                .unwrap_or(std::ptr::null()),
            prompt: if req.prompt.is_empty() {
                std::ptr::null()
            } else {
                prompt_c.as_ptr()
            },
            reason: if reason_str.is_empty() {
                std::ptr::null()
            } else {
                reason_c.as_ptr()
            },
            context_json: ctx_c.as_ptr(),
        };

        // SAFETY: `h.cb` is the host-registered agent-resolver callback;
        // the FFI contract requires the host to keep it valid and
        // thread-safe for the lifetime of the runtime. `envelope`
        // borrows from `*_c` CStrings owned by this stack frame and is
        // dropped before they go out of scope. The returned pointer is
        // immediately handed to `read_and_free`, which validates it is
        // non-null before copying and then invokes the paired free
        // callback.
        unsafe {
            let ptr = (h.cb)(&envelope as *const _, h.user_data);
            match h.read_and_free(ptr) {
                Ok(s) => parse_resolver_response_json(&s),
                Err(reason) => ResolverResponse {
                    decision: ResolverDecision::Deny,
                    value: None,
                    set_variables: HashMap::new(),
                    reason: Some(format!(
                        "ffi: agent resolver returned no response: {reason}"
                    )),
                },
            }
        }
    }
}

struct CDelegateDispatcher {
    holder: Arc<CallbackHolder<ShieldDelegateDispatcherCallback>>,
}

impl DelegateDispatcher for CDelegateDispatcher {
    fn dispatch(&self, req: DelegateRequest) -> Result<ResolverResponse, ResolverRuntimeError> {
        let h = self.holder.clone();
        let ctx_json = serde_json::to_string(&Value::Object(req.context.clone()))
            .unwrap_or_else(|_| "{}".into());
        let prompt = req.prompt.clone().unwrap_or_default();
        let resource_kind_str = req.resource_kind.map(|k| match k {
            crate::variables::ResourceKind::Tool => "tool",
            crate::variables::ResourceKind::Endpoint => "endpoint",
            crate::variables::ResourceKind::Agent => "agent",
        });
        let reason_str = req.reason.clone().unwrap_or_default();
        let variable_str = req.variable.clone().unwrap_or_default();
        let resource_name_str = req.resource_name.clone().unwrap_or_default();
        let resource_params_json_str = req
            .invocation_params
            .as_ref()
            .and_then(|p| serde_json::to_string(p).ok());
        let lifetime_json_str = req
            .lifetime_hint
            .as_ref()
            .and_then(|lh| serde_json::to_string(lh).ok());
        let configuration_id = req.configuration.id.clone();
        let configuration_type = req.configuration.config_type.as_str().to_string();
        let configuration_json =
            serde_json::to_string(&req.configuration).unwrap_or_else(|_| "{}".into());

        let request_id_c = cstring_lossy(&req.request_id);
        let variable_c = cstring_lossy(&variable_str);
        let kind_c = resource_kind_str.map(cstring_lossy);
        let resource_name_c = cstring_lossy(&resource_name_str);
        let resource_params_c = resource_params_json_str.as_deref().map(cstring_lossy);
        let lifetime_c = lifetime_json_str.as_deref().map(cstring_lossy);
        let prompt_c = cstring_lossy(&prompt);
        let reason_c = cstring_lossy(&reason_str);
        let ctx_c = cstring_lossy(&ctx_json);
        let cfg_id_c = cstring_lossy(&configuration_id);
        let cfg_type_c = cstring_lossy(&configuration_type);
        let cfg_json_c = cstring_lossy(&configuration_json);

        let base = ShieldResolverRequest {
            request_id: request_id_c.as_ptr(),
            variable: if variable_str.is_empty() {
                std::ptr::null()
            } else {
                variable_c.as_ptr()
            },
            resource_kind: kind_c
                .as_ref()
                .map(|c| c.as_ptr())
                .unwrap_or(std::ptr::null()),
            resource_name: if resource_name_str.is_empty() {
                std::ptr::null()
            } else {
                resource_name_c.as_ptr()
            },
            resource_params_json: resource_params_c
                .as_ref()
                .map(|c| c.as_ptr())
                .unwrap_or(std::ptr::null()),
            prompt: if prompt.is_empty() {
                std::ptr::null()
            } else {
                prompt_c.as_ptr()
            },
            reason: if reason_str.is_empty() {
                std::ptr::null()
            } else {
                reason_c.as_ptr()
            },
            context_json: ctx_c.as_ptr(),
        };

        let envelope = ShieldDelegateRequest {
            configuration_id: cfg_id_c.as_ptr(),
            configuration_type: cfg_type_c.as_ptr(),
            configuration_json: cfg_json_c.as_ptr(),
            lifetime_json: lifetime_c
                .as_ref()
                .map(|c| c.as_ptr())
                .unwrap_or(std::ptr::null()),
            base,
        };

        // SAFETY: `h.cb` is the host-registered delegate-dispatcher
        // callback; the FFI contract requires it to remain valid and
        // thread-safe for the runtime's lifetime. `envelope` borrows
        // from CStrings owned by this stack frame and is consumed
        // before they are dropped. The returned pointer is validated
        // and freed via `read_and_free`.
        unsafe {
            let ptr = (h.cb)(&envelope as *const _, h.user_data);
            match h.read_and_free(ptr) {
                Ok(s) => Ok(parse_resolver_response_json(&s)),
                Err(reason) => Ok(ResolverResponse {
                    decision: ResolverDecision::Deny,
                    value: None,
                    set_variables: HashMap::new(),
                    reason: Some(format!(
                        "ffi: delegate dispatcher returned no response: {reason}"
                    )),
                }),
            }
        }
    }
}

struct CLlmCaller {
    holder: Arc<CallbackHolder<ShieldLlmCallback>>,
}

impl LlmCaller for CLlmCaller {
    fn call(&self, configuration_id: Option<&str>, prompt: &str) -> Result<LlmResponse, String> {
        let h = self.holder.clone();
        let cfg_c = cstring_lossy(configuration_id.unwrap_or(""));
        let prompt_c = cstring_lossy(prompt);
        // No subject for plain LLM calls — set `input` and `context_json`
        // to empty / "{}" for parity with the classifier shape.
        let input_c = cstring_lossy("");
        let ctx_c = cstring_lossy("{}");
        let req = ShieldLlmRequest {
            configuration_id: if configuration_id.is_some() {
                cfg_c.as_ptr()
            } else {
                std::ptr::null()
            },
            prompt: prompt_c.as_ptr(),
            input: input_c.as_ptr(),
            context_json: ctx_c.as_ptr(),
        };
        // SAFETY: `h.cb` is the host-registered LLM callback; the FFI
        // contract requires it to remain valid and thread-safe.
        // `req` borrows pointers from `cfg_c`, `prompt_c`, `input_c`,
        // and `ctx_c`, all owned by this stack frame and live until
        // after the callback returns. The result pointer is validated
        // and released via `read_and_free`.
        unsafe {
            let ptr = (h.cb)(&req as *const _, h.user_data);
            let s = h
                .read_and_free(ptr)
                .map_err(|e| format!("ffi: llm callback failed: {e}"))?;
            parse_llm_response_json(&s)
        }
    }
}

struct CClassifierCaller {
    holder: Arc<CallbackHolder<ShieldClassifierCallback>>,
}

impl ClassifierCaller for CClassifierCaller {
    fn classify(&self, configuration_id: &str, subject: &str) -> Result<ClassifierVerdict, String> {
        let h = self.holder.clone();
        let cfg_c = cstring_lossy(configuration_id);
        let prompt_c = cstring_lossy("");
        let input_c = cstring_lossy(subject);
        let ctx_c = cstring_lossy("{}");
        let req = ShieldLlmRequest {
            configuration_id: cfg_c.as_ptr(),
            prompt: prompt_c.as_ptr(),
            input: input_c.as_ptr(),
            context_json: ctx_c.as_ptr(),
        };
        // SAFETY: `h.cb` is the host-registered classifier callback;
        // the FFI contract requires it to remain valid and
        // thread-safe. `req` borrows pointers from `cfg_c`,
        // `prompt_c`, `input_c`, and `ctx_c`, all owned by this stack
        // frame and live until after the callback returns. The result
        // pointer is validated and released via `read_and_free`.
        unsafe {
            let ptr = (h.cb)(&req as *const _, h.user_data);
            let s = h
                .read_and_free(ptr)
                .map_err(|e| format!("ffi: classifier callback failed: {e}"))?;
            parse_classifier_verdict_json(&s)
        }
    }
}

#[allow(dead_code)]
fn parse_spans_array(_v: &Value) -> Vec<Span> {
    // Retained as a no-op shim for any internal callers; the canonical
    // span parser lives in wire_shapes and is invoked through the
    // shared LLM/classifier parsers below. Not currently called.
    Vec::new()
}

fn parse_llm_response_json(s: &str) -> Result<LlmResponse, String> {
    // Route through the canonical wire_shapes parser. The wire_shapes
    // version is total (never errors); we keep the `Result` shape here
    // because the trait's downstream callers do their own error
    // mapping. An empty input is the only "callback returned nothing"
    // signal we still surface as `Err` — every other malformed shape
    // collapses into an `LlmResponse::default()` (folded → Block).
    if s.trim().is_empty() {
        return Err("empty llm response".into());
    }
    Ok(crate::wire_shapes::parse_llm_response_json(s))
}

fn parse_classifier_verdict_json(s: &str) -> Result<ClassifierVerdict, String> {
    if s.trim().is_empty() {
        return Err("empty classifier response".into());
    }
    Ok(crate::wire_shapes::parse_classifier_verdict_json(s))
}

// ────────────────────────────────────────────────────────────────────
// Observability provider wrapper
// ────────────────────────────────────────────────────────────────────

/// FFI wrapper bridging a host-registered C log callback to the Rust
/// [`ObservabilityProvider`] trait.
///
/// # Concurrency contract (host responsibility)
///
/// The host MUST be prepared for the registered log callback to be
/// invoked concurrently from multiple threads. The runtime fans out
/// every log event through a single [`ObservabilityDispatcher`] shared
/// by all sessions opened on a given [`GuardrailsRuntime`], so a single
/// `CLogProvider` instance will receive interleaved emissions from
/// every concurrent session — including emissions that originate on
/// different OS threads.
///
/// The host has three options for handling this safely:
///
///   (a) Wrap the callback's mutable state in a `Mutex` / `RwLock` (or
///       the host-language equivalent — Python's `threading.Lock`, .NET's
///       `lock`, etc.) and accept the contention.
///   (b) Have the callback push events onto a thread-safe queue /
///       channel and process them serially on a dedicated thread.
///   (c) Make the callback genuinely thread-safe by construction (e.g.
///       atomic counters, idempotent forwarding to a thread-safe
///       logger such as `log::info!`, or stateless serialization to
///       stdout).
///
/// The `unsafe impl Send + Sync` below is the SDK's promise that the
/// *handle* — the `*mut c_void` user data and the function-pointer
/// callback — can cross threads. It is **not** a promise about the
/// callback body itself; that remains the host's responsibility.
///
/// Regression coverage for this contract lives in
/// `tests/observability_concurrent.rs`.
struct CLogProvider {
    callback: ShieldLogCallback,
    user_data: *mut c_void,
}

// SAFETY: `callback` is a C function pointer; the FFI contract
// (documented at the top of this module and on `CLogProvider`) requires
// the host to register only thread-safe callbacks. `user_data` is
// opaque to the Rust runtime — the host owns its lifetime and
// concurrency policy. We therefore propagate `Send` to the wrapper so
// the observability provider can be stored inside
// `Arc<dyn ... + Send>`.
unsafe impl Send for CLogProvider {}
// SAFETY: same contract as the `Send` impl above — the host
// guarantees the callback is safe to invoke concurrently and the
// `user_data` pointer is treated as opaque shared state. Concurrent
// sessions on the same runtime share one `ObservabilityProvider`
// dispatcher; a single `CLogProvider` instance will therefore receive
// interleaved emissions from different sessions and threads.
unsafe impl Sync for CLogProvider {}

impl ObservabilityProvider for CLogProvider {
    fn emit(&self, event: ShieldLogEvent) {
        if let Ok(json) = serde_json::to_string(&event) {
            let c = cstring_lossy(&json);
            // SAFETY: `self.callback` is the host-registered log
            // callback; the FFI contract requires it to be valid and
            // thread-safe. `c` is a `CString` owned by this scope, so
            // the `*const c_char` it yields stays valid for the
            // duration of the call.
            unsafe {
                (self.callback)(c.as_ptr(), self.user_data);
            }
        }
    }
}

// ────────────────────────────────────────────────────────────────────
// Extractor wrapper
// ────────────────────────────────────────────────────────────────────

struct CExtractor {
    holder: Arc<CallbackHolder<ShieldExtractorCallback>>,
}

impl Extractor for CExtractor {
    fn extract(&self, raw: &Value) -> Option<Value> {
        let h = self.holder.clone();
        let raw_json = serde_json::to_string(raw).unwrap_or_else(|_| "null".into());
        let raw_c = cstring_lossy(&raw_json);
        // SAFETY: `h.cb` is the host-registered extractor callback;
        // the FFI contract requires it to remain valid and
        // thread-safe. `raw_c` is a `CString` owned by this scope, so
        // the `*const c_char` it yields stays valid for the duration
        // of the call. The returned pointer is validated and freed by
        // `read_and_free`.
        unsafe {
            let ptr = (h.cb)(raw_c.as_ptr(), h.user_data);
            match h.read_and_free(ptr) {
                Ok(s) => crate::wire_shapes::parse_extractor_output_json(&s),
                Err(_) => None,
            }
        }
    }
}

// ────────────────────────────────────────────────────────────────────
// Builder lifecycle
// ────────────────────────────────────────────────────────────────────

/// Construct a builder from a single YAML guardrails file (with
/// `extends:` resolution). Returns `null` and populates `*err` on
/// failure.
#[no_mangle]
pub unsafe extern "C" fn shield_builder_from_yaml(
    path: *const c_char,
    err: *mut *mut c_char,
) -> *mut ShieldBuilder {
    ffi_guard!(ptr, {
        let path = match cstr_to_str(path) {
            Some(p) => p,
            None => {
                write_err(err, "null path");
                return std::ptr::null_mut();
            }
        };
        match RuntimeBuilder::from_yaml(path) {
            Ok(b) => Box::into_raw(Box::new(ShieldBuilder { inner: Some(b) })),
            Err(e) => {
                write_err(err, &format!("from_yaml failed: {e}"));
                std::ptr::null_mut()
            }
        }
    })
}

/// Construct a builder from an explicit chain of YAML paths. `paths` is
/// a `*const *const c_char` of length `n`.
#[no_mangle]
pub unsafe extern "C" fn shield_builder_from_yaml_chain(
    paths: *const *const c_char,
    n: usize,
    err: *mut *mut c_char,
) -> *mut ShieldBuilder {
    ffi_guard!(ptr, {
        if paths.is_null() {
            write_err(err, "null paths array");
            return std::ptr::null_mut();
        }
        if n == 0 {
            write_err(err, "empty paths array");
            return std::ptr::null_mut();
        }
        let mut owned: Vec<PathBuf> = Vec::with_capacity(n);
        for i in 0..n {
            let entry = *paths.add(i);
            let s = match cstr_to_str(entry) {
                Some(s) => s,
                None => {
                    write_err(err, &format!("paths[{i}] is null or non-utf8"));
                    return std::ptr::null_mut();
                }
            };
            owned.push(PathBuf::from(s));
        }
        match RuntimeBuilder::from_yaml_chain(&owned) {
            Ok(b) => Box::into_raw(Box::new(ShieldBuilder { inner: Some(b) })),
            Err(e) => {
                write_err(err, &format!("from_yaml_chain failed: {e}"));
                std::ptr::null_mut()
            }
        }
    })
}

/// Construct a builder from a YAML/JSON string (the merged config wire
/// form). Useful for hosts that synthesize configurations in code.
#[no_mangle]
pub unsafe extern "C" fn shield_builder_from_config_json(
    config_yaml: *const c_char,
    err: *mut *mut c_char,
) -> *mut ShieldBuilder {
    ffi_guard!(ptr, {
        let s = match cstr_to_str(config_yaml) {
            Some(s) => s,
            None => {
                write_err(err, "null config string");
                return std::ptr::null_mut();
            }
        };
        match crate::loader::load_from_str(s) {
            Ok(cfg) => {
                let b = RuntimeBuilder::from_config(cfg);
                Box::into_raw(Box::new(ShieldBuilder { inner: Some(b) }))
            }
            Err(e) => {
                write_err(err, &format!("load_from_str failed: {e}"));
                std::ptr::null_mut()
            }
        }
    })
}

/// Free a builder created by any `shield_builder_from_*` function
/// that was not consumed via [`shield_builder_build`]. No-op on
/// `null`.
#[no_mangle]
pub unsafe extern "C" fn shield_builder_free(b: *mut ShieldBuilder) {
    ffi_guard!(void, {
        if !b.is_null() {
            drop(Box::from_raw(b));
        }
    })
}

/// Helper: take the inner builder out for a chainable register call.
/// Returns `false` (and no-op on the input) when the builder was
/// already consumed.
unsafe fn with_builder<F: FnOnce(RuntimeBuilder) -> RuntimeBuilder>(
    b: *mut ShieldBuilder,
    f: F,
) -> bool {
    let bh = match b.as_mut() {
        Some(b) => b,
        None => return false,
    };
    let inner = match bh.inner.take() {
        Some(i) => i,
        None => return false,
    };
    bh.inner = Some(f(inner));
    true
}

/// Validates a host-supplied function pointer for a required callback
/// slot. Returns `Some(fn)` when non-null, `None` when null. Callers MUST
/// reject `None` for required slots — passing a null function pointer
/// through a bare `unsafe extern "C" fn` parameter is undefined behavior,
/// so every FFI registration site below accepts `Option<...>` and writes
/// a clear error to `err_out` rather than UB-ing on the first invocation.
fn require_callback<F>(cb: Option<F>, err_out: *mut *mut c_char, slot: &str) -> Option<F> {
    match cb {
        Some(f) => Some(f),
        None => {
            // SAFETY: `err_out` is forwarded directly from a public FFI
            // entry point; `write_err` itself null-checks the pointer
            // before dereferencing, so passing through any value the
            // host supplied — including `null` — is sound.
            unsafe { write_err(err_out, &format!("required callback `{slot}` is null")) };
            None
        }
    }
}

/// Register an agent resolver callback (§11.5). The host returns a
/// JSON-serialized `ResolverResponse` describing the resolution; Rust
/// frees the response via `free_result`.
///
/// Panic-safety contract: the host's callback MUST NOT leave
/// `user_data` (the registered context pointer) in a torn or
/// inconsistent state if it panics or unwinds. `ffi_guard!` catches
/// panics at the C ABI boundary and reports a structured failure to
/// the caller (`-1` here), but the captured `user_data` pointer is
/// wrapped in `AssertUnwindSafe` — its invariants are the host's
/// responsibility. Hosts that mutate captured state from the callback
/// should either (a) use interior mutability with poison-safe
/// primitives (e.g. `parking_lot::Mutex`), or (b) push events to a
/// lock-free channel and process them serially elsewhere.
#[no_mangle]
pub unsafe extern "C" fn shield_builder_register_agent_resolver(
    b: *mut ShieldBuilder,
    cb: Option<ShieldAgentResolverCallback>,
    free_result: Option<ShieldFreeResultCallback>,
    user_data: *mut c_void,
    err: *mut *mut c_char,
) -> i32 {
    ffi_guard!(code, -1, {
        let cb = match require_callback(cb, err, "agent_resolver") {
            Some(c) => c,
            None => return -1,
        };
        let free_result = match require_callback(free_result, err, "free_result") {
            Some(f) => f,
            None => return -1,
        };
        let holder = Arc::new(CallbackHolder {
            cb,
            free: free_result,
            user_data,
        });
        let resolver: Arc<dyn AgentResolver> = Arc::new(CAgentResolver { holder });
        with_builder(b, |bldr| bldr.register_agent_resolver(resolver));
        0
    })
}

/// Register a delegate dispatcher callback (§11.4). The host returns a
/// JSON-serialized `ResolverResponse` describing the delegate's
/// resolution; Rust frees the response via `free_result`.
///
/// Panic-safety contract: the host's callback MUST NOT leave
/// `user_data` (the registered context pointer) in a torn or
/// inconsistent state if it panics or unwinds. `ffi_guard!` catches
/// panics at the C ABI boundary and reports a structured failure to
/// the caller (`-1` here), but the captured `user_data` pointer is
/// wrapped in `AssertUnwindSafe` — its invariants are the host's
/// responsibility. Hosts that mutate captured state from the callback
/// should either (a) use interior mutability with poison-safe
/// primitives (e.g. `parking_lot::Mutex`), or (b) push events to a
/// lock-free channel and process them serially elsewhere.
#[no_mangle]
pub unsafe extern "C" fn shield_builder_register_delegate_dispatcher(
    b: *mut ShieldBuilder,
    cb: Option<ShieldDelegateDispatcherCallback>,
    free_result: Option<ShieldFreeResultCallback>,
    user_data: *mut c_void,
    err: *mut *mut c_char,
) -> i32 {
    ffi_guard!(code, -1, {
        let cb = match require_callback(cb, err, "delegate_dispatcher") {
            Some(c) => c,
            None => return -1,
        };
        let free_result = match require_callback(free_result, err, "free_result") {
            Some(f) => f,
            None => return -1,
        };
        let holder = Arc::new(CallbackHolder {
            cb,
            free: free_result,
            user_data,
        });
        let dispatcher: Arc<dyn DelegateDispatcher> = Arc::new(CDelegateDispatcher { holder });
        with_builder(b, |bldr| bldr.register_delegate_dispatcher(dispatcher));
        0
    })
}

/// Register an LLM caller callback (§14). The host returns a
/// JSON-serialized `LlmResponse`; Rust frees the response via
/// `free_result`.
///
/// Panic-safety contract: the host's callback MUST NOT leave
/// `user_data` (the registered context pointer) in a torn or
/// inconsistent state if it panics or unwinds. `ffi_guard!` catches
/// panics at the C ABI boundary and reports a structured failure to
/// the caller (`-1` here), but the captured `user_data` pointer is
/// wrapped in `AssertUnwindSafe` — its invariants are the host's
/// responsibility. Hosts that mutate captured state from the callback
/// should either (a) use interior mutability with poison-safe
/// primitives (e.g. `parking_lot::Mutex`), or (b) push events to a
/// lock-free channel and process them serially elsewhere.
#[no_mangle]
pub unsafe extern "C" fn shield_builder_register_llm_caller(
    b: *mut ShieldBuilder,
    cb: Option<ShieldLlmCallback>,
    free_result: Option<ShieldFreeResultCallback>,
    user_data: *mut c_void,
    err: *mut *mut c_char,
) -> i32 {
    ffi_guard!(code, -1, {
        let cb = match require_callback(cb, err, "llm_caller") {
            Some(c) => c,
            None => return -1,
        };
        let free_result = match require_callback(free_result, err, "free_result") {
            Some(f) => f,
            None => return -1,
        };
        let holder = Arc::new(CallbackHolder {
            cb,
            free: free_result,
            user_data,
        });
        let caller: Arc<dyn LlmCaller> = Arc::new(CLlmCaller { holder });
        with_builder(b, |bldr| bldr.register_llm_caller(caller));
        0
    })
}

/// Register a classifier caller callback (§14). The host returns a
/// JSON-serialized `ClassifierVerdict`; Rust frees the response via
/// `free_result`.
///
/// Panic-safety contract: the host's callback MUST NOT leave
/// `user_data` (the registered context pointer) in a torn or
/// inconsistent state if it panics or unwinds. `ffi_guard!` catches
/// panics at the C ABI boundary and reports a structured failure to
/// the caller (`-1` here), but the captured `user_data` pointer is
/// wrapped in `AssertUnwindSafe` — its invariants are the host's
/// responsibility. Hosts that mutate captured state from the callback
/// should either (a) use interior mutability with poison-safe
/// primitives (e.g. `parking_lot::Mutex`), or (b) push events to a
/// lock-free channel and process them serially elsewhere.
#[no_mangle]
pub unsafe extern "C" fn shield_builder_register_classifier_caller(
    b: *mut ShieldBuilder,
    cb: Option<ShieldClassifierCallback>,
    free_result: Option<ShieldFreeResultCallback>,
    user_data: *mut c_void,
    err: *mut *mut c_char,
) -> i32 {
    ffi_guard!(code, -1, {
        let cb = match require_callback(cb, err, "classifier_caller") {
            Some(c) => c,
            None => return -1,
        };
        let free_result = match require_callback(free_result, err, "free_result") {
            Some(f) => f,
            None => return -1,
        };
        let holder = Arc::new(CallbackHolder {
            cb,
            free: free_result,
            user_data,
        });
        let caller: Arc<dyn ClassifierCaller> = Arc::new(CClassifierCaller { holder });
        with_builder(b, |bldr| bldr.register_classifier_caller(caller));
        0
    })
}

/// Register an observability provider callback (§19). Each emitted
/// [`ShieldLogEvent`] is serialized to JSON and passed to the host
/// callback. The host retains no ownership of the buffer — Rust
/// reclaims it after the call returns.
///
/// Panic-safety contract: the host's callback MUST NOT leave
/// `user_data` (the registered context pointer) in a torn or
/// inconsistent state if it panics or unwinds. `ffi_guard!` catches
/// panics at the C ABI boundary and reports a structured failure to
/// the caller (`-1` here), but the captured `user_data` pointer is
/// wrapped in `AssertUnwindSafe` — its invariants are the host's
/// responsibility. Hosts that mutate captured state from the callback
/// (e.g. an exporter queue) should either (a) use interior mutability
/// with poison-safe primitives (e.g. `parking_lot::Mutex`), or (b)
/// push events to a lock-free channel and process them serially
/// elsewhere. The dispatcher invokes registered providers concurrently
/// from any thread driving a session, so this concern is in addition
/// to ordinary `Send + Sync` thread-safety.
#[no_mangle]
pub unsafe extern "C" fn shield_builder_register_observability_provider(
    b: *mut ShieldBuilder,
    cb: Option<ShieldLogCallback>,
    user_data: *mut c_void,
    err: *mut *mut c_char,
) -> i32 {
    ffi_guard!(code, -1, {
        let cb = match require_callback(cb, err, "observability_provider") {
            Some(c) => c,
            None => return -1,
        };
        let provider: Arc<dyn ObservabilityProvider> = Arc::new(CLogProvider {
            callback: cb,
            user_data,
        });
        with_builder(b, |bldr| bldr.register_provider(provider));
        0
    })
}

/// Register a named extractor callback used by populator pipelines
/// (§16). The host returns a JSON-serialized extraction result; Rust
/// frees the response via `free_result`.
///
/// Panic-safety contract: the host's callback MUST NOT leave
/// `user_data` (the registered context pointer) in a torn or
/// inconsistent state if it panics or unwinds. `ffi_guard!` catches
/// panics at the C ABI boundary and reports a structured failure to
/// the caller (`-1` here), but the captured `user_data` pointer is
/// wrapped in `AssertUnwindSafe` — its invariants are the host's
/// responsibility. Hosts that mutate captured state from the callback
/// should either (a) use interior mutability with poison-safe
/// primitives (e.g. `parking_lot::Mutex`), or (b) push events to a
/// lock-free channel and process them serially elsewhere.
#[no_mangle]
pub unsafe extern "C" fn shield_builder_register_extractor(
    b: *mut ShieldBuilder,
    name: *const c_char,
    cb: Option<ShieldExtractorCallback>,
    free_result: Option<ShieldFreeResultCallback>,
    user_data: *mut c_void,
    err: *mut *mut c_char,
) -> i32 {
    ffi_guard!(code, -1, {
        let name = match cstr_to_str(name) {
            Some(s) => s.to_string(),
            None => {
                write_err(err, "null extractor name");
                return -1;
            }
        };
        let cb = match require_callback(cb, err, "extractor") {
            Some(c) => c,
            None => return -1,
        };
        let free_result = match require_callback(free_result, err, "free_result") {
            Some(f) => f,
            None => return -1,
        };
        let holder = Arc::new(CallbackHolder {
            cb,
            free: free_result,
            user_data,
        });
        let extractor: Box<dyn Extractor> = Box::new(CExtractor { holder });
        with_builder(b, |bldr| bldr.register_extractor(&name, extractor));
        0
    })
}

#[no_mangle]
pub unsafe extern "C" fn shield_builder_tool_retry_limit(b: *mut ShieldBuilder, n: usize) {
    ffi_guard!(void, {
        with_builder(b, |bldr| bldr.tool_retry_limit(n));
    })
}

/// Set the runtime's effective `RuntimeMode` (#14). `mode_c` MUST be
/// a NUL-terminated C string holding `"active"` or `"shadow"`
/// (case-insensitive). Returns 0 on success, -1 on unknown value or
/// null pointer.
#[no_mangle]
pub unsafe extern "C" fn shield_builder_with_mode(
    b: *mut ShieldBuilder,
    mode_c: *const c_char,
) -> i32 {
    ffi_guard!(code, -1, {
        if mode_c.is_null() {
            return -1;
        }
        let cs = std::ffi::CStr::from_ptr(mode_c);
        let s = match cs.to_str() {
            Ok(s) => s,
            Err(_) => return -1,
        };
        let m = match crate::shield_primitives::RuntimeMode::from_wire_str(s) {
            Some(m) => m,
            None => return -1,
        };
        with_builder(b, |bldr| bldr.with_mode(m));
        0
    })
}

/// Set the runtime's perf-telemetry gating level (v8 perf-logging
/// Phase 1, PR5/PR6). `mode` MUST be one of `0 = Off`, `1 = External`,
/// `2 = Full`. Unknown values return -1 without mutating the builder.
/// Returns 0 on success, -1 on null builder or out-of-range mode.
///
/// Mirrors `RuntimeBuilder::with_perf_telemetry(PerfTelemetry)` in
/// the Rust core; the Python / .NET wrappers route their typed
/// `PerfTelemetry` enum through this entry point.
#[no_mangle]
pub unsafe extern "C" fn shield_builder_set_perf_telemetry(b: *mut ShieldBuilder, mode: u8) -> i32 {
    ffi_guard!(code, -1, {
        let perf = match crate::perf_telemetry::PerfTelemetry::from_u8(mode) {
            Some(p) => p,
            None => return -1,
        };
        if !with_builder(b, |bldr| bldr.with_perf_telemetry(perf)) {
            return -1;
        }
        0
    })
}

/// Configure streaming defaults. `trigger` is one of
/// `0 = OnComplete`, `1 = Windowed`, `2 = PerChunk`. Unknown values
/// fall back to OnComplete.
#[no_mangle]
pub unsafe extern "C" fn shield_builder_streaming_window(
    b: *mut ShieldBuilder,
    trigger: i32,
    window_size: usize,
    overlap: usize,
) {
    ffi_guard!(void, {
        let trig = match trigger {
            1 => StreamingTrigger::Windowed,
            2 => StreamingTrigger::PerChunk,
            _ => StreamingTrigger::OnComplete,
        };
        let opts = StreamingOptions {
            trigger: trig,
            window_size,
            overlap,
        };
        with_builder(b, |bldr| bldr.streaming_window(opts));
    })
}

/// Consume the builder and produce a runtime handle. After this call
/// the builder pointer is exhausted; call [`shield_builder_free`] to
/// release the empty wrapper.
#[no_mangle]
pub unsafe extern "C" fn shield_builder_build(
    b: *mut ShieldBuilder,
    err: *mut *mut c_char,
) -> *mut ShieldRuntime {
    ffi_guard!(ptr, {
        let bh = match b.as_mut() {
            Some(b) => b,
            None => {
                write_err(err, "null builder");
                return std::ptr::null_mut();
            }
        };
        let inner = match bh.inner.take() {
            Some(i) => i,
            None => {
                write_err(err, "builder already consumed");
                return std::ptr::null_mut();
            }
        };
        match inner.build() {
            Ok(rt) => Box::into_raw(Box::new(ShieldRuntime { inner: rt })),
            Err(e) => {
                write_err(err, &format!("build failed: {e}"));
                std::ptr::null_mut()
            }
        }
    })
}

/// Free a runtime handle. Sessions spawned from it remain valid until
/// they are individually freed (each holds an `Arc`).
#[no_mangle]
pub unsafe extern "C" fn shield_runtime_free(r: *mut ShieldRuntime) {
    ffi_guard!(void, {
        if !r.is_null() {
            drop(Box::from_raw(r));
        }
    })
}

/// Effective `RuntimeMode` (#14) as a static C string. Null
/// runtime returns `"active"`. Pointer is static; do not free.
#[no_mangle]
pub unsafe extern "C" fn shield_runtime_mode(r: *const ShieldRuntime) -> *const c_char {
    let mode = match r.as_ref() {
        Some(rh) => rh.inner.mode(),
        None => crate::shield_primitives::RuntimeMode::Active,
    };
    let s: &'static std::ffi::CStr = match mode {
        crate::shield_primitives::RuntimeMode::Active => c"active",
        crate::shield_primitives::RuntimeMode::Shadow => c"shadow",
    };
    s.as_ptr()
}

// ────────────────────────────────────────────────────────────────────
// Session lifecycle
// ────────────────────────────────────────────────────────────────────

/// Construct a session. `request_context_json` is an optional JSON
/// envelope `{"user_id":..., "tenant_id":..., "session_id":...,
/// "correlation_id":..., "extensions":{}}`. A `null` argument falls
/// back to a default-generated context.
#[no_mangle]
pub unsafe extern "C" fn shield_runtime_new_session(
    r: *mut ShieldRuntime,
    request_context_json: *const c_char,
    err: *mut *mut c_char,
) -> *mut ShieldSession {
    ffi_guard!(ptr, {
        let rh = match r.as_ref() {
            Some(r) => r,
            None => {
                write_err(err, "null runtime");
                return std::ptr::null_mut();
            }
        };
        let ctx = match build_request_context(request_context_json) {
            Ok(c) => c,
            Err(e) => {
                write_err(err, &e);
                return std::ptr::null_mut();
            }
        };
        let runtime = rh.inner.clone();
        let session = runtime.new_session(ctx);
        Box::into_raw(Box::new(ShieldSession {
            inner: session,
            _runtime: runtime,
        }))
    })
}

unsafe fn build_request_context(json: *const c_char) -> Result<RequestContext, String> {
    let s = match cstr_to_str(json) {
        None => return Ok(RequestContext::default()),
        Some("") => return Ok(RequestContext::default()),
        Some(s) => s,
    };
    let v: Value = serde_json::from_str(s).map_err(|e| format!("invalid request_context: {e}"))?;
    let obj = v
        .as_object()
        .ok_or_else(|| "request_context must be a JSON object".to_string())?;
    let session_id = obj
        .get("session_id")
        .and_then(|v| v.as_str())
        .map(|s| s.to_string())
        .unwrap_or_else(|| format!("sess-{}", uuid::Uuid::new_v4()));
    let correlation_id = obj
        .get("correlation_id")
        .and_then(|v| v.as_str())
        .map(|s| s.to_string())
        .unwrap_or_else(|| format!("corr-{}", uuid::Uuid::new_v4()));
    let mut ctx = RequestContext::new(session_id, correlation_id);
    if let Some(u) = obj.get("user_id").and_then(|v| v.as_str()) {
        ctx = ctx.with_user_id(u);
    }
    if let Some(t) = obj.get("tenant_id").and_then(|v| v.as_str()) {
        ctx = ctx.with_tenant_id(t);
    }
    if let Some(ext) = obj.get("extensions").cloned() {
        ctx = ctx.with_extensions(ext);
    }
    Ok(ctx)
}

#[no_mangle]
pub unsafe extern "C" fn shield_session_free(s: *mut ShieldSession) {
    ffi_guard!(void, {
        if !s.is_null() {
            drop(Box::from_raw(s));
        }
    })
}

// ────────────────────────────────────────────────────────────────────
// Variable ops
// ────────────────────────────────────────────────────────────────────

#[no_mangle]
pub unsafe extern "C" fn shield_session_set_variable(
    s: *mut ShieldSession,
    name: *const c_char,
    value_json: *const c_char,
    err: *mut *mut c_char,
) -> i32 {
    ffi_guard!(code, -1, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return -1;
            }
        };
        let name = match cstr_to_str(name) {
            Some(n) => n,
            None => {
                write_err(err, "null name");
                return -1;
            }
        };
        let value = match parse_json_value(value_json) {
            Ok(v) => v,
            Err(e) => {
                write_err(err, &e);
                return -1;
            }
        };
        match sh.inner.set_variable(name, value) {
            Ok(_) => 0,
            Err(e) => {
                write_err(err, &format!("set_variable failed: {e}"));
                -1
            }
        }
    })
}

#[no_mangle]
pub unsafe extern "C" fn shield_session_reset_variable(
    s: *mut ShieldSession,
    name: *const c_char,
    err: *mut *mut c_char,
) -> i32 {
    ffi_guard!(code, -1, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return -1;
            }
        };
        let name = match cstr_to_str(name) {
            Some(n) => n,
            None => {
                write_err(err, "null name");
                return -1;
            }
        };
        match sh.inner.reset_variable(name) {
            Ok(_) => 0,
            Err(e) => {
                write_err(err, &format!("reset_variable failed: {e}"));
                -1
            }
        }
    })
}

/// Resolve a variable's `on_demand_by:` resolver, returning the
/// resolved value as JSON. Returns the literal string `"null"` (not a
/// null pointer) when the resolver returns `Deny`, `Cancelled`, or no
/// resolver is configured.
#[no_mangle]
pub unsafe extern "C" fn shield_session_resolve_variable(
    s: *mut ShieldSession,
    name: *const c_char,
    err: *mut *mut c_char,
) -> *mut c_char {
    ffi_guard!(ptr, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return std::ptr::null_mut();
            }
        };
        let name = match cstr_to_str(name) {
            Some(n) => n,
            None => {
                write_err(err, "null name");
                return std::ptr::null_mut();
            }
        };
        match sh.inner.resolve_variable(name) {
            Ok(Some(v)) => json_to_c(&v),
            Ok(None) => string_to_c("null"),
            Err(e) => {
                write_err(err, &format!("resolve_variable failed: {e}"));
                std::ptr::null_mut()
            }
        }
    })
}

/// Read the cached variable state. Returns `null` when the variable is
/// not declared.
#[no_mangle]
pub unsafe extern "C" fn shield_session_read_variable(
    s: *mut ShieldSession,
    name: *const c_char,
    err: *mut *mut c_char,
) -> *mut c_char {
    ffi_guard!(ptr, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return std::ptr::null_mut();
            }
        };
        let name = match cstr_to_str(name) {
            Some(n) => n,
            None => {
                write_err(err, "null name");
                return std::ptr::null_mut();
            }
        };
        match sh.inner.read_variable(name) {
            Some(state) => json_to_c(&variable_state_to_json(&state)),
            None => std::ptr::null_mut(),
        }
    })
}

// ────────────────────────────────────────────────────────────────────
// IFC ops (proof: docs/information-flow-control-proof.md)
// ────────────────────────────────────────────────────────────────────

/// Builder-side: declare host capability for sub-session scope reset.
/// Required before calling `shield_builder_build` if the merged
/// configuration declares `ifc.scope: per_turn` or `per_request` —
/// without this capability the build call rejects with a TC-3 error.
/// Hosts that retain LLM context across these boundaries (LangChain
/// memory, AutoGen group chats, persistent conversation IDs) MUST
/// NOT call this.
#[no_mangle]
pub unsafe extern "C" fn shield_builder_supports_context_reset(
    b: *mut ShieldBuilder,
    supports: i32,
) {
    ffi_guard!(void, {
        with_builder(b, |bldr| bldr.supports_context_reset(supports != 0));
    })
}

/// Read the session's running IFC exposure. Returns the raw u64
/// bitset (TagSet representation). When IFC is disabled (no `ifc:`
/// block in the merged config) this is always 0. Use
/// `shield_session_ifc_tag_names` to render a u64 bitset back to
/// declared tag names.
#[no_mangle]
pub unsafe extern "C" fn shield_session_ifc_current_exposure(
    s: *mut ShieldSession,
    err: *mut *mut c_char,
) -> u64 {
    ffi_guard!(code, 0u64, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return 0u64;
            }
        };
        sh.inner.current_exposure().raw()
    })
}

/// Render a TagSet (u64 bitset) back to a JSON array of tag names
/// declared in `ifc.tags`, sorted in declaration order. Returned
/// pointer is heap-allocated and MUST be freed with
/// `shield_string_free`.
#[no_mangle]
pub unsafe extern "C" fn shield_session_ifc_tag_names(
    s: *mut ShieldSession,
    raw: u64,
    err: *mut *mut c_char,
) -> *mut c_char {
    ffi_guard!(ptr, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return std::ptr::null_mut();
            }
        };
        let names = sh
            .inner
            .runtime()
            .config()
            .ifc
            .universe
            .names_of(crate::ifc::TagSet::from_raw(raw));
        json_to_c(&serde_json::Value::Array(
            names.into_iter().map(serde_json::Value::String).collect(),
        ))
    })
}

// ────────────────────────────────────────────────────────────────────
// Event ops
// ────────────────────────────────────────────────────────────────────

#[no_mangle]
pub unsafe extern "C" fn shield_session_emit_event(
    s: *mut ShieldSession,
    event_id: *const c_char,
    lifetime_json: *const c_char,
    payload_json: *const c_char,
    err: *mut *mut c_char,
) -> i32 {
    ffi_guard!(code, -1, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return -1;
            }
        };
        let id = match cstr_to_str(event_id) {
            Some(n) => n,
            None => {
                write_err(err, "null event_id");
                return -1;
            }
        };
        let lifetime = match cstr_to_str(lifetime_json) {
            None => None,
            Some("") => None,
            Some(s) => match serde_yaml::from_str::<crate::lifetime::Lifetime>(s) {
                Ok(lt) => Some(lt),
                Err(e) => {
                    write_err(err, &format!("invalid lifetime: {e}"));
                    return -1;
                }
            },
        };
        let payload = match parse_json_value_opt(payload_json) {
            Ok(p) => p,
            Err(e) => {
                write_err(err, &e);
                return -1;
            }
        };
        match sh.inner.emit_event(id, lifetime, payload) {
            Ok(_) => 0,
            Err(e) => {
                write_err(err, &format!("emit_event failed: {e}"));
                -1
            }
        }
    })
}

#[no_mangle]
pub unsafe extern "C" fn shield_session_clear_event(
    s: *mut ShieldSession,
    event_id: *const c_char,
    err: *mut *mut c_char,
) -> i32 {
    ffi_guard!(code, -1, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return -1;
            }
        };
        let id = match cstr_to_str(event_id) {
            Some(n) => n,
            None => {
                write_err(err, "null event_id");
                return -1;
            }
        };
        match sh.inner.clear_event(id) {
            Ok(_) => 0,
            Err(e) => {
                write_err(err, &format!("clear_event failed: {e}"));
                -1
            }
        }
    })
}

#[no_mangle]
pub unsafe extern "C" fn shield_session_emit_incident(
    s: *mut ShieldSession,
    name: *const c_char,
    payload_json: *const c_char,
    err: *mut *mut c_char,
) -> i32 {
    ffi_guard!(code, -1, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return -1;
            }
        };
        let n = match cstr_to_str(name) {
            Some(n) => n,
            None => {
                write_err(err, "null name");
                return -1;
            }
        };
        let payload = match parse_json_value_opt(payload_json) {
            Ok(p) => p,
            Err(e) => {
                write_err(err, &e);
                return -1;
            }
        };
        match sh.inner.emit_incident(n, payload) {
            Ok(_) => 0,
            Err(e) => {
                write_err(err, &format!("emit_incident failed: {e}"));
                -1
            }
        }
    })
}

// ────────────────────────────────────────────────────────────────────
// Boundary ops
// ────────────────────────────────────────────────────────────────────

#[no_mangle]
pub unsafe extern "C" fn shield_session_begin_turn(
    s: *mut ShieldSession,
    err: *mut *mut c_char,
) -> u64 {
    ffi_guard!(code, 0, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return 0;
            }
        };
        match sh.inner.begin_turn() {
            Ok(id) => id,
            Err(e) => {
                write_err(err, &format!("begin_turn failed: {e}"));
                0
            }
        }
    })
}

#[no_mangle]
pub unsafe extern "C" fn shield_session_end_turn(
    s: *mut ShieldSession,
    err: *mut *mut c_char,
) -> i32 {
    ffi_guard!(code, -1, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return -1;
            }
        };
        match sh.inner.end_turn() {
            Ok(_) => 0,
            Err(e) => {
                write_err(err, &format!("end_turn failed: {e}"));
                -1
            }
        }
    })
}

#[no_mangle]
pub unsafe extern "C" fn shield_session_begin_request(
    s: *mut ShieldSession,
    err: *mut *mut c_char,
) -> u64 {
    ffi_guard!(code, 0, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return 0;
            }
        };
        match sh.inner.begin_request() {
            Ok(id) => id,
            Err(e) => {
                write_err(err, &format!("begin_request failed: {e}"));
                0
            }
        }
    })
}

#[no_mangle]
pub unsafe extern "C" fn shield_session_end_request(
    s: *mut ShieldSession,
    err: *mut *mut c_char,
) -> i32 {
    ffi_guard!(code, -1, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return -1;
            }
        };
        match sh.inner.end_request() {
            Ok(_) => 0,
            Err(e) => {
                write_err(err, &format!("end_request failed: {e}"));
                -1
            }
        }
    })
}

// ────────────────────────────────────────────────────────────────────
// Stage validation
// ────────────────────────────────────────────────────────────────────

#[no_mangle]
pub unsafe extern "C" fn shield_session_validate_input(
    s: *mut ShieldSession,
    input: *const c_char,
    err: *mut *mut c_char,
) -> *mut c_char {
    ffi_guard!(ptr, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return std::ptr::null_mut();
            }
        };
        let i = match cstr_to_str(input) {
            Some(n) => n,
            None => {
                write_err(err, "null input");
                return std::ptr::null_mut();
            }
        };
        let v = sh.inner.validate_input(i);
        json_to_c(&stage_verdict_to_json(&v))
    })
}

/// Stage 3 — tool validation (§16). `tool_call_id` is REQUIRED per
/// spec §16.0 and MUST be non-null; pass an adapter-synthesized
/// UUIDv4 if the host framework does not natively expose one. Pairs
/// with `shield_session_validate_tool_output` carrying the same id.
#[no_mangle]
pub unsafe extern "C" fn shield_session_validate_tool_call(
    s: *mut ShieldSession,
    tool: *const c_char,
    params_json: *const c_char,
    tool_call_id: *const c_char,
    mutated_params_json: *mut *mut c_char,
    err: *mut *mut c_char,
) -> *mut c_char {
    ffi_guard!(ptr, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return std::ptr::null_mut();
            }
        };
        let tool = match cstr_to_str(tool) {
            Some(n) => n,
            None => {
                write_err(err, "null tool");
                return std::ptr::null_mut();
            }
        };
        let id = match cstr_to_str(tool_call_id) {
            Some(n) => n,
            None => {
                write_err(err, "null tool_call_id");
                return std::ptr::null_mut();
            }
        };
        let mut params = match parse_json_value(params_json) {
            Ok(v) => v,
            Err(e) => {
                write_err(err, &e);
                return std::ptr::null_mut();
            }
        };
        let v = sh.inner.validate_tool_call(tool, &mut params, id);
        if !mutated_params_json.is_null() {
            *mutated_params_json = json_to_c(&params);
        }
        json_to_c(&stage_verdict_to_json(&v))
    })
}

/// Stage 4 — tool output validation (§17). `tool_call_id` is REQUIRED
/// per spec §16.0 and MUST match the id passed to the paired
/// `shield_session_validate_tool_call`. A non-matching or missing id
/// fails closed with a `<binding>` policy verdict.
#[no_mangle]
pub unsafe extern "C" fn shield_session_validate_tool_output(
    s: *mut ShieldSession,
    tool: *const c_char,
    result_json: *const c_char,
    tool_call_id: *const c_char,
    mutated_result_json: *mut *mut c_char,
    err: *mut *mut c_char,
) -> *mut c_char {
    ffi_guard!(ptr, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return std::ptr::null_mut();
            }
        };
        let tool = match cstr_to_str(tool) {
            Some(n) => n,
            None => {
                write_err(err, "null tool");
                return std::ptr::null_mut();
            }
        };
        let id = match cstr_to_str(tool_call_id) {
            Some(n) => n,
            None => {
                write_err(err, "null tool_call_id");
                return std::ptr::null_mut();
            }
        };
        let mut result = match parse_json_value(result_json) {
            Ok(v) => v,
            Err(e) => {
                write_err(err, &e);
                return std::ptr::null_mut();
            }
        };
        let v = sh.inner.validate_tool_output(tool, &mut result, id);
        if !mutated_result_json.is_null() {
            *mutated_result_json = json_to_c(&result);
        }
        json_to_c(&stage_verdict_to_json(&v))
    })
}

/// Stage 3 — endpoint variant. `tool_call_id` is REQUIRED for API
/// symmetry but currently unused (no Stage 4 for endpoint).
#[no_mangle]
pub unsafe extern "C" fn shield_session_validate_endpoint_call(
    s: *mut ShieldSession,
    method: *const c_char,
    uri: *const c_char,
    body_json: *const c_char,
    tool_call_id: *const c_char,
    mutated_body_json: *mut *mut c_char,
    err: *mut *mut c_char,
) -> *mut c_char {
    ffi_guard!(ptr, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return std::ptr::null_mut();
            }
        };
        let m = match cstr_to_str(method) {
            Some(n) => n,
            None => {
                write_err(err, "null method");
                return std::ptr::null_mut();
            }
        };
        let u = match cstr_to_str(uri) {
            Some(n) => n,
            None => {
                write_err(err, "null uri");
                return std::ptr::null_mut();
            }
        };
        let id = match cstr_to_str(tool_call_id) {
            Some(n) => n,
            None => {
                write_err(err, "null tool_call_id");
                return std::ptr::null_mut();
            }
        };
        let mut body = match parse_json_value(body_json) {
            Ok(v) => v,
            Err(e) => {
                write_err(err, &e);
                return std::ptr::null_mut();
            }
        };
        let v = sh.inner.validate_endpoint_call(m, u, &mut body, id);
        if !mutated_body_json.is_null() {
            *mutated_body_json = json_to_c(&body);
        }
        json_to_c(&stage_verdict_to_json(&v))
    })
}

/// Stage 3 — agent variant. `tool_call_id` is REQUIRED for API
/// symmetry but currently unused (no Stage 4 for agent).
#[no_mangle]
pub unsafe extern "C" fn shield_session_validate_agent_call(
    s: *mut ShieldSession,
    agent: *const c_char,
    params_json: *const c_char,
    tool_call_id: *const c_char,
    mutated_params_json: *mut *mut c_char,
    err: *mut *mut c_char,
) -> *mut c_char {
    ffi_guard!(ptr, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return std::ptr::null_mut();
            }
        };
        let agent = match cstr_to_str(agent) {
            Some(n) => n,
            None => {
                write_err(err, "null agent");
                return std::ptr::null_mut();
            }
        };
        let id = match cstr_to_str(tool_call_id) {
            Some(n) => n,
            None => {
                write_err(err, "null tool_call_id");
                return std::ptr::null_mut();
            }
        };
        let mut params = match parse_json_value(params_json) {
            Ok(v) => v,
            Err(e) => {
                write_err(err, &e);
                return std::ptr::null_mut();
            }
        };
        let v = sh.inner.validate_agent_call(agent, &mut params, id);
        if !mutated_params_json.is_null() {
            *mutated_params_json = json_to_c(&params);
        }
        json_to_c(&stage_verdict_to_json(&v))
    })
}

#[no_mangle]
pub unsafe extern "C" fn shield_session_validate_output(
    s: *mut ShieldSession,
    response: *const c_char,
    mutated_response: *mut *mut c_char,
    err: *mut *mut c_char,
) -> *mut c_char {
    ffi_guard!(ptr, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return std::ptr::null_mut();
            }
        };
        let r = match cstr_to_str(response) {
            Some(n) => n,
            None => {
                write_err(err, "null response");
                return std::ptr::null_mut();
            }
        };
        let mut owned = r.to_string();
        let v = sh.inner.validate_output(&mut owned);
        if !mutated_response.is_null() {
            *mutated_response = string_to_c(&owned);
        }
        json_to_c(&stage_verdict_to_json(&v))
    })
}

/// Stage 2 — state validation. The caller supplies an invocation
/// envelope as JSON of the form
/// `{"kind":"tool|agent|endpoint","name":..,"params":..,"method":..,"uri":..}`.
/// Returns a StageVerdict JSON.
#[no_mangle]
pub unsafe extern "C" fn shield_session_validate_state(
    s: *mut ShieldSession,
    invocation_json: *const c_char,
    err: *mut *mut c_char,
) -> *mut c_char {
    ffi_guard!(ptr, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return std::ptr::null_mut();
            }
        };
        let v = match parse_json_value(invocation_json) {
            Ok(v) => v,
            Err(e) => {
                write_err(err, &e);
                return std::ptr::null_mut();
            }
        };
        let inv = match invocation_from_json(&v) {
            Ok(i) => i,
            Err(e) => {
                write_err(err, &e);
                return std::ptr::null_mut();
            }
        };
        let verdict = sh.inner.validate_state(&inv);
        json_to_c(&stage_verdict_to_json(&verdict))
    })
}

fn invocation_from_json(v: &Value) -> Result<Invocation, String> {
    let obj = v
        .as_object()
        .ok_or_else(|| "invocation must be a JSON object".to_string())?;
    let kind = obj
        .get("kind")
        .and_then(|x| x.as_str())
        .ok_or_else(|| "invocation missing 'kind'".to_string())?;
    let params = obj.get("params").cloned().unwrap_or(Value::Null);
    match kind {
        "tool" => {
            let name = obj
                .get("name")
                .and_then(|x| x.as_str())
                .ok_or_else(|| "tool invocation missing 'name'".to_string())?;
            Ok(Invocation::tool(name, params))
        }
        "agent" => {
            let name = obj
                .get("name")
                .and_then(|x| x.as_str())
                .ok_or_else(|| "agent invocation missing 'name'".to_string())?;
            Ok(Invocation::agent(name, params))
        }
        "endpoint" => {
            let method = obj.get("method").and_then(|x| x.as_str()).unwrap_or("GET");
            let uri = obj
                .get("uri")
                .and_then(|x| x.as_str())
                .ok_or_else(|| "endpoint invocation missing 'uri'".to_string())?;
            Ok(Invocation::endpoint(method, uri, params))
        }
        other => Err(format!("unknown invocation kind: {other}")),
    }
}

// ────────────────────────────────────────────────────────────────────
// Resource cycle helpers
// ────────────────────────────────────────────────────────────────────

#[no_mangle]
pub unsafe extern "C" fn shield_session_record_tool_success(
    s: *mut ShieldSession,
    tool: *const c_char,
    result_json: *const c_char,
    err: *mut *mut c_char,
) -> i32 {
    ffi_guard!(code, -1, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return -1;
            }
        };
        let tool = match cstr_to_str(tool) {
            Some(n) => n,
            None => {
                write_err(err, "null tool");
                return -1;
            }
        };
        let result = match parse_json_value(result_json) {
            Ok(v) => v,
            Err(e) => {
                write_err(err, &e);
                return -1;
            }
        };
        match sh.inner.record_tool_success(tool, &result) {
            Ok(_) => 0,
            Err(e) => {
                write_err(err, &format!("record_tool_success failed: {e}"));
                -1
            }
        }
    })
}

#[no_mangle]
pub unsafe extern "C" fn shield_session_record_tool_failure(
    s: *mut ShieldSession,
    tool: *const c_char,
    error_message: *const c_char,
    err: *mut *mut c_char,
) -> i32 {
    ffi_guard!(code, -1, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return -1;
            }
        };
        let tool = match cstr_to_str(tool) {
            Some(n) => n,
            None => {
                write_err(err, "null tool");
                return -1;
            }
        };
        let msg = cstr_to_str(error_message).unwrap_or("");
        match sh.inner.record_tool_failure(tool, msg) {
            Ok(_) => 0,
            Err(e) => {
                write_err(err, &format!("record_tool_failure failed: {e}"));
                -1
            }
        }
    })
}

#[no_mangle]
pub unsafe extern "C" fn shield_session_record_endpoint_success(
    s: *mut ShieldSession,
    method: *const c_char,
    uri: *const c_char,
    result_json: *const c_char,
    err: *mut *mut c_char,
) -> i32 {
    ffi_guard!(code, -1, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return -1;
            }
        };
        let m = cstr_to_str(method).unwrap_or("");
        let uri = match cstr_to_str(uri) {
            Some(n) => n,
            None => {
                write_err(err, "null uri");
                return -1;
            }
        };
        let result = match parse_json_value(result_json) {
            Ok(v) => v,
            Err(e) => {
                write_err(err, &e);
                return -1;
            }
        };
        match sh.inner.record_endpoint_success(m, uri, &result) {
            Ok(_) => 0,
            Err(e) => {
                write_err(err, &format!("record_endpoint_success failed: {e}"));
                -1
            }
        }
    })
}

#[no_mangle]
pub unsafe extern "C" fn shield_session_record_endpoint_failure(
    s: *mut ShieldSession,
    method: *const c_char,
    uri: *const c_char,
    error_message: *const c_char,
    err: *mut *mut c_char,
) -> i32 {
    ffi_guard!(code, -1, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return -1;
            }
        };
        let m = cstr_to_str(method).unwrap_or("");
        let uri = match cstr_to_str(uri) {
            Some(n) => n,
            None => {
                write_err(err, "null uri");
                return -1;
            }
        };
        let msg = cstr_to_str(error_message).unwrap_or("");
        match sh.inner.record_endpoint_failure(m, uri, msg) {
            Ok(_) => 0,
            Err(e) => {
                write_err(err, &format!("record_endpoint_failure failed: {e}"));
                -1
            }
        }
    })
}

#[no_mangle]
pub unsafe extern "C" fn shield_session_record_agent_success(
    s: *mut ShieldSession,
    agent: *const c_char,
    result_json: *const c_char,
    err: *mut *mut c_char,
) -> i32 {
    ffi_guard!(code, -1, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return -1;
            }
        };
        let agent = match cstr_to_str(agent) {
            Some(n) => n,
            None => {
                write_err(err, "null agent");
                return -1;
            }
        };
        let result = match parse_json_value(result_json) {
            Ok(v) => v,
            Err(e) => {
                write_err(err, &e);
                return -1;
            }
        };
        match sh.inner.record_agent_success(agent, &result) {
            Ok(_) => 0,
            Err(e) => {
                write_err(err, &format!("record_agent_success failed: {e}"));
                -1
            }
        }
    })
}

#[no_mangle]
pub unsafe extern "C" fn shield_session_record_agent_failure(
    s: *mut ShieldSession,
    agent: *const c_char,
    error_message: *const c_char,
    err: *mut *mut c_char,
) -> i32 {
    ffi_guard!(code, -1, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return -1;
            }
        };
        let agent = match cstr_to_str(agent) {
            Some(n) => n,
            None => {
                write_err(err, "null agent");
                return -1;
            }
        };
        let msg = cstr_to_str(error_message).unwrap_or("");
        match sh.inner.record_agent_failure(agent, msg) {
            Ok(_) => 0,
            Err(e) => {
                write_err(err, &format!("record_agent_failure failed: {e}"));
                -1
            }
        }
    })
}

// ────────────────────────────────────────────────────────────────────
// Streaming
// ────────────────────────────────────────────────────────────────────

/// Construct a streaming-session handle for the given stage.
/// `stage == 4` → post-tool (Stage 4); `stage == 5` → output (Stage 5).
#[no_mangle]
pub unsafe extern "C" fn shield_session_streaming_session(
    s: *mut ShieldSession,
    stage: i32,
    err: *mut *mut c_char,
) -> *mut ShieldStream {
    ffi_guard!(ptr, {
        let sh = match s.as_ref() {
            Some(s) => s,
            None => {
                write_err(err, "null session");
                return std::ptr::null_mut();
            }
        };
        let stage = match stage {
            4 => ObsStage::PostTool,
            5 => ObsStage::Output,
            _ => {
                write_err(err, "stage must be 4 (post_tool) or 5 (output)");
                return std::ptr::null_mut();
            }
        };
        let guard = sh.inner.streaming_session(stage);
        Box::into_raw(Box::new(ShieldStream { inner: guard }))
    })
}

fn stream_action_to_str(a: &StreamChunkAction) -> &'static str {
    match a {
        StreamChunkAction::Pass => "pass",
        StreamChunkAction::Replace => "replace",
        StreamChunkAction::Stop => "stop",
    }
}

#[no_mangle]
pub unsafe extern "C" fn shield_stream_push(
    st: *mut ShieldStream,
    chunk: *const c_char,
    err: *mut *mut c_char,
) -> *mut c_char {
    ffi_guard!(ptr, {
        let sh = match st.as_mut() {
            Some(s) => s,
            None => {
                write_err(err, "null stream");
                return std::ptr::null_mut();
            }
        };
        let chunk = match cstr_to_str(chunk) {
            Some(n) => n,
            None => {
                write_err(err, "null chunk");
                return std::ptr::null_mut();
            }
        };
        let res = sh.inner.add_chunk(chunk);
        let v = serde_json::json!({
            "action": stream_action_to_str(&res.action),
            "payload": res.payload,
            "reason": res.reason,
        });
        json_to_c(&v)
    })
}

#[no_mangle]
pub unsafe extern "C" fn shield_stream_finish(
    st: *mut ShieldStream,
    err: *mut *mut c_char,
) -> *mut c_char {
    ffi_guard!(ptr, {
        let sh = match st.as_mut() {
            Some(s) => s,
            None => {
                write_err(err, "null stream");
                return std::ptr::null_mut();
            }
        };
        let res = sh.inner.end_stream();
        let v = serde_json::json!({
            "action": stream_action_to_str(&res.action),
            "payload": res.payload,
            "reason": res.reason,
        });
        json_to_c(&v)
    })
}

/// Return the streaming guard's configured validation cadence.
///
/// Mapping (matches [`StreamingTrigger`]):
///
/// - `0` → `on_complete` (buffer everything, validate once at finish)
/// - `1` → `windowed` (re-validate every `window_size` bytes)
/// - `2` → `per_chunk` (validate after every chunk)
///
/// Returns `-1` when `st` is null. The host SDK uses the mode to
/// decide whether to forward upstream chunks to the customer in real
/// time (`windowed` / `per_chunk`) or to buffer every chunk and emit
/// only the final validated payload at `shield_stream_finish`
/// (`on_complete`). Pure read accessor — never allocates and never
/// fails for a non-null handle.
#[no_mangle]
pub unsafe extern "C" fn shield_stream_mode(st: *const ShieldStream) -> i32 {
    ffi_guard!(code, -1, {
        if st.is_null() {
            return -1;
        }
        let sh = &*st;
        match sh.inner.mode() {
            StreamingTrigger::OnComplete => 0,
            StreamingTrigger::Windowed => 1,
            StreamingTrigger::PerChunk => 2,
        }
    })
}

#[no_mangle]
pub unsafe extern "C" fn shield_stream_free(st: *mut ShieldStream) {
    ffi_guard!(void, {
        if !st.is_null() {
            drop(Box::from_raw(st));
        }
    })
}

// ────────────────────────────────────────────────────────────────────
// GuardrailsConfig / CompiledPolicy
// ────────────────────────────────────────────────────────────────────
//
// Composable configuration surface (see `crate::config`). Hosts assemble
// a chain of YAML / string / value layers through the fluent
// `shield_config_*` API, compile it once into a `ShieldCompiledPolicy`,
// and feed the compiled handle into a runtime via
// `shield_builder_from_compiled_policy`.
//
// Every fluent extension function returns a NEW handle — the input
// handle is left untouched, mirroring the Rust `GuardrailsConfig`
// `extend / extend_path / extend_string / with_overrides` semantics
// (each clones internally). The caller MUST free both the input and
// returned handles.

/// Opaque [`crate::config::GuardrailsConfig`] handle.
pub struct ShieldGuardrailsConfig {
    inner: crate::config::GuardrailsConfig,
}

/// Opaque [`crate::config::CompiledPolicy`] handle.
pub struct ShieldCompiledPolicy {
    inner: crate::config::CompiledPolicy,
}

#[inline]
unsafe fn cfg_ref<'a>(handle: *const c_void) -> Option<&'a ShieldGuardrailsConfig> {
    if handle.is_null() {
        None
    } else {
        Some(&*(handle as *const ShieldGuardrailsConfig))
    }
}

#[inline]
unsafe fn compiled_ref<'a>(handle: *const c_void) -> Option<&'a ShieldCompiledPolicy> {
    if handle.is_null() {
        None
    } else {
        Some(&*(handle as *const ShieldCompiledPolicy))
    }
}

#[inline]
fn cfg_into_handle(inner: crate::config::GuardrailsConfig) -> *mut c_void {
    Box::into_raw(Box::new(ShieldGuardrailsConfig { inner })) as *mut c_void
}

#[inline]
fn compiled_into_handle(inner: crate::config::CompiledPolicy) -> *mut c_void {
    Box::into_raw(Box::new(ShieldCompiledPolicy { inner })) as *mut c_void
}

/// Construct a config chain seeded with a single YAML file path.
/// Returns `null` and populates `*err` on null/non-UTF-8 input.
#[no_mangle]
pub unsafe extern "C" fn shield_config_load(
    path: *const c_char,
    err: *mut *mut c_char,
) -> *mut c_void {
    ffi_guard!(ptr, {
        let p = match cstr_to_str(path) {
            Some(s) => s,
            None => {
                write_err(err, "shield_config_load: null or non-utf8 path");
                return std::ptr::null_mut();
            }
        };
        cfg_into_handle(crate::config::GuardrailsConfig::load(p))
    })
}

/// Construct a config chain seeded with a single YAML string.
#[no_mangle]
pub unsafe extern "C" fn shield_config_from_string(
    yaml: *const c_char,
    err: *mut *mut c_char,
) -> *mut c_void {
    ffi_guard!(ptr, {
        let s = match cstr_to_str(yaml) {
            Some(s) => s,
            None => {
                write_err(err, "shield_config_from_string: null or non-utf8 yaml");
                return std::ptr::null_mut();
            }
        };
        cfg_into_handle(crate::config::GuardrailsConfig::from_string(s))
    })
}

/// Construct a config chain seeded with a JSON-encoded value layer.
/// The input is parsed with `serde_json` and wrapped as
/// `Layer::Object`, matching `GuardrailsConfig::from_value` in Rust.
#[no_mangle]
pub unsafe extern "C" fn shield_config_from_json(
    json: *const c_char,
    err: *mut *mut c_char,
) -> *mut c_void {
    ffi_guard!(ptr, {
        let v = match parse_json_value(json) {
            Ok(v) => v,
            Err(e) => {
                write_err(err, &format!("shield_config_from_json: {e}"));
                return std::ptr::null_mut();
            }
        };
        cfg_into_handle(crate::config::GuardrailsConfig::from_value(v))
    })
}

/// Append `other`'s layers to `handle`'s and return a NEW handle.
/// Neither input handle is consumed — both must be freed separately
/// by the caller.
#[no_mangle]
pub unsafe extern "C" fn shield_config_extend(
    handle: *const c_void,
    other: *const c_void,
    err: *mut *mut c_char,
) -> *mut c_void {
    ffi_guard!(ptr, {
        let base = match cfg_ref(handle) {
            Some(b) => b,
            None => {
                write_err(err, "shield_config_extend: null base handle");
                return std::ptr::null_mut();
            }
        };
        let extra = match cfg_ref(other) {
            Some(o) => o,
            None => {
                write_err(err, "shield_config_extend: null other handle");
                return std::ptr::null_mut();
            }
        };
        let merged = base.inner.clone().extend(extra.inner.clone());
        cfg_into_handle(merged)
    })
}

/// Append a single path layer and return a NEW handle.
#[no_mangle]
pub unsafe extern "C" fn shield_config_extend_path(
    handle: *const c_void,
    path: *const c_char,
    err: *mut *mut c_char,
) -> *mut c_void {
    ffi_guard!(ptr, {
        let base = match cfg_ref(handle) {
            Some(b) => b,
            None => {
                write_err(err, "shield_config_extend_path: null handle");
                return std::ptr::null_mut();
            }
        };
        let p = match cstr_to_str(path) {
            Some(s) => s,
            None => {
                write_err(err, "shield_config_extend_path: null or non-utf8 path");
                return std::ptr::null_mut();
            }
        };
        cfg_into_handle(base.inner.clone().extend_path(p))
    })
}

/// Append a single YAML-string layer and return a NEW handle.
#[no_mangle]
pub unsafe extern "C" fn shield_config_extend_string(
    handle: *const c_void,
    yaml: *const c_char,
    err: *mut *mut c_char,
) -> *mut c_void {
    ffi_guard!(ptr, {
        let base = match cfg_ref(handle) {
            Some(b) => b,
            None => {
                write_err(err, "shield_config_extend_string: null handle");
                return std::ptr::null_mut();
            }
        };
        let s = match cstr_to_str(yaml) {
            Some(s) => s,
            None => {
                write_err(err, "shield_config_extend_string: null or non-utf8 yaml");
                return std::ptr::null_mut();
            }
        };
        cfg_into_handle(base.inner.clone().extend_string(s))
    })
}

/// Append a final value-shaped override layer (parsed from JSON) and
/// return a NEW handle.
#[no_mangle]
pub unsafe extern "C" fn shield_config_with_overrides_json(
    handle: *const c_void,
    json: *const c_char,
    err: *mut *mut c_char,
) -> *mut c_void {
    ffi_guard!(ptr, {
        let base = match cfg_ref(handle) {
            Some(b) => b,
            None => {
                write_err(err, "shield_config_with_overrides_json: null handle");
                return std::ptr::null_mut();
            }
        };
        let v = match parse_json_value(json) {
            Ok(v) => v,
            Err(e) => {
                write_err(err, &format!("shield_config_with_overrides_json: {e}"));
                return std::ptr::null_mut();
            }
        };
        cfg_into_handle(base.inner.clone().with_overrides(v))
    })
}

/// Number of layers in the chain. `0` for null handles.
#[no_mangle]
pub unsafe extern "C" fn shield_config_len(handle: *const c_void) -> usize {
    ffi_guard!(code, 0, {
        match cfg_ref(handle) {
            Some(c) => c.inner.len(),
            None => 0,
        }
    })
}

/// `true` for null handles or empty chains.
#[no_mangle]
pub unsafe extern "C" fn shield_config_is_empty(handle: *const c_void) -> bool {
    ffi_guard!(code, true, {
        match cfg_ref(handle) {
            Some(c) => c.inner.is_empty(),
            None => true,
        }
    })
}

/// Compile the chain into a [`ShieldCompiledPolicy`] handle. Returns
/// `null` and populates `*err` on failure.
#[no_mangle]
pub unsafe extern "C" fn shield_config_compile(
    handle: *const c_void,
    err: *mut *mut c_char,
) -> *mut c_void {
    ffi_guard!(ptr, {
        let cfg = match cfg_ref(handle) {
            Some(c) => c,
            None => {
                write_err(err, "shield_config_compile: null handle");
                return std::ptr::null_mut();
            }
        };
        match cfg.inner.compile() {
            Ok(compiled) => compiled_into_handle(compiled),
            Err(e) => {
                write_err(err, &format!("shield_config_compile: {e}"));
                std::ptr::null_mut()
            }
        }
    })
}

/// Free a [`ShieldGuardrailsConfig`]. No-op on null.
#[no_mangle]
pub unsafe extern "C" fn shield_config_free(handle: *mut c_void) {
    ffi_guard!(void, {
        if !handle.is_null() {
            drop(Box::from_raw(handle as *mut ShieldGuardrailsConfig));
        }
    })
}

/// Return the SHA-256 (lowercase hex) digest of the chain WITHOUT
/// running merge / validation. Used by hosts that need a stable
/// content-keyed identity for partial overlays (where `compile()`
/// would reject incomplete data). The digest is byte-stable with the
/// digest produced by [`shield_config_compile`] for the same content.
///
/// Caller MUST free with [`shield_free_string`]. Returns `null` and
/// writes `*err` on failure.
#[no_mangle]
pub unsafe extern "C" fn shield_config_digest(
    handle: *const c_void,
    err: *mut *mut c_char,
) -> *mut c_char {
    ffi_guard!(ptr, {
        let cfg = match cfg_ref(handle) {
            Some(c) => c,
            None => {
                write_err(err, "shield_config_digest: null handle");
                return std::ptr::null_mut();
            }
        };
        match cfg.inner.digest() {
            Ok(d) => string_to_c(&d),
            Err(e) => {
                write_err(err, &format!("shield_config_digest: {e}"));
                std::ptr::null_mut()
            }
        }
    })
}

/// Return the SHA-256 (lowercase hex) digest of the compiled chain.
/// Caller MUST free with [`shield_free_string`]. Returns `null` on
/// null input.
#[no_mangle]
pub unsafe extern "C" fn shield_compiled_digest(handle: *const c_void) -> *mut c_char {
    ffi_guard!(ptr, {
        match compiled_ref(handle) {
            Some(c) => string_to_c(c.inner.digest()),
            None => std::ptr::null_mut(),
        }
    })
}

/// Free a [`ShieldCompiledPolicy`]. No-op on null.
#[no_mangle]
pub unsafe extern "C" fn shield_compiled_free(handle: *mut c_void) {
    ffi_guard!(void, {
        if !handle.is_null() {
            drop(Box::from_raw(handle as *mut ShieldCompiledPolicy));
        }
    })
}

/// Construct a builder seeded from a precompiled policy. The compiled
/// handle is borrowed (not consumed) — the caller still owns it and
/// MUST free it with [`shield_compiled_free`] when done.
#[no_mangle]
pub unsafe extern "C" fn shield_builder_from_compiled_policy(
    compiled: *const c_void,
    err: *mut *mut c_char,
) -> *mut ShieldBuilder {
    ffi_guard!(ptr, {
        let c = match compiled_ref(compiled) {
            Some(c) => c,
            None => {
                write_err(err, "shield_builder_from_compiled_policy: null handle");
                return std::ptr::null_mut();
            }
        };
        let b = RuntimeBuilder::from_compiled_policy(&c.inner);
        Box::into_raw(Box::new(ShieldBuilder { inner: Some(b) }))
    })
}

// ────────────────────────────────────────────────────────────────────
// Misc
// ────────────────────────────────────────────────────────────────────

/// Parse a JSON-encoded lifetime value (string for the bare keyword
/// form, object for the map / `for:` / `until_event:` forms) into a
/// canonical `Lifetime` and return its JSON encoding.
///
/// This is the single canonical entry point used by every language SDK
/// for lifetime parsing. SDK shells MUST route through this function
/// rather than implementing their own grammar.
///
/// Returns `null` and writes `*err` on parse failure. Caller MUST free
/// the returned string with [`shield_free_string`].
#[no_mangle]
pub unsafe extern "C" fn shield_parse_lifetime(
    json_in: *const c_char,
    err: *mut *mut c_char,
) -> *mut c_char {
    ffi_guard!(ptr, {
        let value = match parse_json_value(json_in) {
            Ok(v) => v,
            Err(e) => {
                write_err(err, &format!("shield_parse_lifetime: {e}"));
                return std::ptr::null_mut();
            }
        };
        match crate::lifetime::parse_lifetime(value) {
            Ok(lt) => json_to_c(&lt),
            Err(e) => {
                write_err(err, &format!("shield_parse_lifetime: {e}"));
                std::ptr::null_mut()
            }
        }
    })
}

// ────────────────────────────────────────────────────────────────────
// Canonical wire-shape parsers — language bindings MUST route every
// host callback's return value through these. See
// [`crate::wire_shapes`] for the canonical Rust API.
//
// Each parser is total: it never returns an error to the caller. On
// any malformed input it returns the fail-closed shape encoded as
// JSON, so a buggy host callback CANNOT silently leak as an `allow`.
// Caller MUST free the returned string with [`shield_free_string`].
// ────────────────────────────────────────────────────────────────────

/// Parse a host LLM caller's return value into the canonical
/// [`crate::guard_policy_runtime::LlmResponse`] JSON shape (§12.9.3).
///
/// Accepts bare-word strings (`"allow"`, `"BLOCK"`, …) and JSON
/// envelopes alike. The output is a serialized `LlmResponse` object
/// with fields `decision` (string|null), `confidence` (number|null),
/// `reason` (string|null), `categories` (array), `spans` (array),
/// `bool_flags` (object), and `folded_decision` (`"allow"` | `"block"`)
/// computed per the spec's §12.9.3 ¶2 truthy-bool override rule.
///
/// Returns `null` only when the input pointer is null. All other inputs
/// — including malformed JSON — produce a populated fail-closed
/// envelope (decision missing, folded_decision = "block").
#[no_mangle]
pub unsafe extern "C" fn shield_parse_llm_response(json_in: *const c_char) -> *mut c_char {
    ffi_guard!(ptr, {
        let s = match cstr_to_str(json_in) {
            Some(s) => s,
            None => return std::ptr::null_mut(),
        };
        let resp = crate::wire_shapes::parse_llm_response_json(s);
        let folded = match resp.folded_decision() {
            crate::guard_policy_runtime::LlmDecision::Allow => "allow",
            crate::guard_policy_runtime::LlmDecision::Block => "block",
        };
        let mut m = Map::new();
        m.insert(
            "decision".into(),
            match resp.decision {
                Some(crate::guard_policy_runtime::LlmDecision::Allow) => {
                    Value::String("allow".into())
                }
                Some(crate::guard_policy_runtime::LlmDecision::Block) => {
                    Value::String("block".into())
                }
                None => Value::Null,
            },
        );
        m.insert(
            "confidence".into(),
            resp.confidence
                .and_then(|c| serde_json::Number::from_f64(c).map(Value::Number))
                .unwrap_or(Value::Null),
        );
        m.insert(
            "reason".into(),
            resp.reason.map(Value::String).unwrap_or(Value::Null),
        );
        m.insert(
            "categories".into(),
            Value::Array(resp.categories.into_iter().map(Value::String).collect()),
        );
        let spans: Vec<Value> = resp
            .spans
            .into_iter()
            .map(|s| {
                let mut sm = Map::new();
                sm.insert(
                    "start".into(),
                    Value::Number(serde_json::Number::from(s.start as u64)),
                );
                sm.insert(
                    "end".into(),
                    Value::Number(serde_json::Number::from(s.end as u64)),
                );
                sm.insert(
                    "replacement".into(),
                    s.replacement.map(Value::String).unwrap_or(Value::Null),
                );
                Value::Object(sm)
            })
            .collect();
        m.insert("spans".into(), Value::Array(spans));
        let mut flags = Map::new();
        for (k, v) in resp.bool_flags {
            flags.insert(k, Value::Bool(v));
        }
        m.insert("bool_flags".into(), Value::Object(flags));
        m.insert("folded_decision".into(), Value::String(folded.into()));
        json_to_c(&Value::Object(m))
    })
}

/// Parse a host classifier callback's return value into the canonical
/// [`crate::guard_policy_runtime::ClassifierVerdict`] JSON shape
/// (§12.5.1). Output fields: `score`, `threshold`, `flagged`,
/// `label` (string|null), `reason` (string|null), `spans` (array),
/// and the derived `is_failure` (`flagged || score >= threshold`).
#[no_mangle]
pub unsafe extern "C" fn shield_parse_classifier_verdict(json_in: *const c_char) -> *mut c_char {
    ffi_guard!(ptr, {
        let s = match cstr_to_str(json_in) {
            Some(s) => s,
            None => return std::ptr::null_mut(),
        };
        let v = crate::wire_shapes::parse_classifier_verdict_json(s);
        let mut m = Map::new();
        m.insert(
            "score".into(),
            serde_json::Number::from_f64(v.score)
                .map(Value::Number)
                .unwrap_or(Value::Null),
        );
        m.insert(
            "threshold".into(),
            serde_json::Number::from_f64(v.threshold)
                .map(Value::Number)
                .unwrap_or(Value::Null),
        );
        m.insert("flagged".into(), Value::Bool(v.flagged));
        m.insert(
            "label".into(),
            v.label.map(Value::String).unwrap_or(Value::Null),
        );
        m.insert(
            "reason".into(),
            v.reason.map(Value::String).unwrap_or(Value::Null),
        );
        let spans: Vec<Value> = v
            .spans
            .into_iter()
            .map(|s| {
                let mut sm = Map::new();
                sm.insert(
                    "start".into(),
                    Value::Number(serde_json::Number::from(s.start as u64)),
                );
                sm.insert(
                    "end".into(),
                    Value::Number(serde_json::Number::from(s.end as u64)),
                );
                sm.insert(
                    "replacement".into(),
                    s.replacement.map(Value::String).unwrap_or(Value::Null),
                );
                Value::Object(sm)
            })
            .collect();
        m.insert("spans".into(), Value::Array(spans));
        m.insert(
            "is_failure".into(),
            Value::Bool(v.flagged || v.score >= v.threshold),
        );
        json_to_c(&Value::Object(m))
    })
}

/// Parse a host resolver / dispatcher callback's return value into the
/// canonical [`crate::resolver::ResolverResponse`] JSON shape (§11.3).
/// Always returns a populated envelope; on malformed input the
/// envelope's `decision` is `"deny"` with a populated `reason`.
#[no_mangle]
pub unsafe extern "C" fn shield_parse_resolver_response(json_in: *const c_char) -> *mut c_char {
    ffi_guard!(ptr, {
        let s = match cstr_to_str(json_in) {
            Some(s) => s,
            None => return std::ptr::null_mut(),
        };
        let r = crate::wire_shapes::parse_resolver_response_json(s);
        json_to_c(&resolver_response_to_json(&r))
    })
}

/// Parse a populator extractor's return JSON. Returns `null` when the
/// extractor signaled "skip this populator" (empty / `null` / malformed
/// input). Any other input is normalized into the canonical JSON shape
/// and returned as a fresh string.
#[no_mangle]
pub unsafe extern "C" fn shield_parse_extractor_output(json_in: *const c_char) -> *mut c_char {
    ffi_guard!(ptr, {
        let s = match cstr_to_str(json_in) {
            Some(s) => s,
            None => return std::ptr::null_mut(),
        };
        match crate::wire_shapes::parse_extractor_output_json(s) {
            Some(v) => json_to_c(&v),
            None => std::ptr::null_mut(),
        }
    })
}

/// Free a string allocated by Rust. No-op on null.
#[no_mangle]
pub unsafe extern "C" fn shield_free_string(s: *mut c_char) {
    ffi_guard!(void, {
        if !s.is_null() {
            drop(CString::from_raw(s));
        }
    })
}

// ────────────────────────────────────────────────────────────────────
// Canonical verdict dispatch (Stage 1/5 + Stage 2/3/4)
// ────────────────────────────────────────────────────────────────────
//
// Pure deterministic decisions that every SDK previously re-implemented
// inline. The SDK ships a JSON wire-shape `StageVerdict` (the same one
// every `shield_session_validate_*` call already returns), the
// `OnBlockPolicy`, and the `ShieldMode`; core hands back a
// `VerdictDispatch` JSON describing the action the orchestrator should
// take. Async wiring (begin_turn / execute / end_turn / record_tool_*)
// stays per-SDK.

unsafe fn dispatch_inputs(
    verdict_json: *const c_char,
    policy: u32,
    mode: u32,
    err: *mut *mut c_char,
) -> Option<(StageVerdict, crate::OnBlockPolicy, crate::ShieldMode)> {
    let v_str = match cstr_to_str(verdict_json) {
        Some(s) => s,
        None => {
            write_err(err, "shield_dispatch: null or non-utf8 verdict_json");
            return None;
        }
    };
    let v_value: Value = match serde_json::from_str(v_str) {
        Ok(v) => v,
        Err(e) => {
            write_err(err, &format!("shield_dispatch: invalid verdict JSON: {e}"));
            return None;
        }
    };
    let verdict = match crate::stage_verdict_from_wire(&v_value) {
        Some(v) => v,
        None => {
            write_err(err, "shield_dispatch: malformed StageVerdict wire shape");
            return None;
        }
    };
    let p = match policy {
        0 => crate::OnBlockPolicy::ReturnBlocked,
        1 => crate::OnBlockPolicy::ReturnVerdict,
        2 => crate::OnBlockPolicy::Raise,
        3 => crate::OnBlockPolicy::Custom,
        other => {
            write_err(
                err,
                &format!("shield_dispatch: unknown policy code {other}"),
            );
            return None;
        }
    };
    let m = match mode {
        0 => crate::ShieldMode::Enforce,
        1 => crate::ShieldMode::Monitor,
        other => {
            write_err(err, &format!("shield_dispatch: unknown mode code {other}"));
            return None;
        }
    };
    Some((verdict, p, m))
}

/// Decide what an SDK orchestrator should do with a Stage 1 / Stage 5
/// verdict.
///
/// `verdict_json` is the canonical [`StageVerdict`] wire shape every
/// `shield_session_validate_*` export already returns. `policy` is an
/// [`OnBlockPolicy`] integer (`0=ReturnBlocked, 1=ReturnVerdict,
/// 2=Raise, 3=Custom`). `mode` is a [`ShieldMode`] integer
/// (`0=Enforce, 1=Monitor`).
///
/// Returns a JSON-encoded [`VerdictDispatch`]:
///
/// ```text
/// {
///   "action": {
///     "kind": "proceed" | "proceed_with_mutation" | "return_blocked"
///           | "return_verdict" | "raise" | "invoke_custom",
///     "value":   "<mutated content>",   // only for proceed_with_mutation
///     "message": "<canonical block string>" // only for return_blocked / raise / invoke_custom
///   },
///   "record_block": bool,
///   "override_to_proceed": bool
/// }
/// ```
///
/// On error, returns `null` and writes the reason into `*err`. Caller
/// MUST free the returned string and any error string via
/// [`shield_free_string`].
#[no_mangle]
pub unsafe extern "C" fn shield_dispatch_stage_verdict(
    verdict_json: *const c_char,
    policy: u32,
    mode: u32,
    err: *mut *mut c_char,
) -> *mut c_char {
    ffi_guard!(ptr, {
        let (verdict, p, m) = match dispatch_inputs(verdict_json, policy, mode, err) {
            Some(t) => t,
            None => return std::ptr::null_mut(),
        };
        let outcome = crate::dispatch_stage_verdict(&verdict, p, m);
        json_to_c(&crate::dispatch_outcome_to_wire(&outcome))
    })
}

/// Decide what an SDK orchestrator should do with a Stage 2/3/4 verdict
/// on a tool call.
///
/// Same `verdict_json` / `policy` / `mode` semantics as
/// [`shield_dispatch_stage_verdict`]. `tool_name` is required and
/// surfaces as the `(tool: <name>)` suffix on canonical block messages.
/// `stage` is `0=Call (Stage 2/3, pre-execute)` or `1=Output (Stage 4,
/// post-execute)`.
///
/// Returns a JSON-encoded [`ToolVerdictDispatch`]:
///
/// ```text
/// {
///   "action": {
///     "kind": "proceed" | "proceed_with_mutation" | "blocked",
///     "value":   "<mutated output>",        // only for proceed_with_mutation
///     "message": "<canonical block string>" // only for blocked
///   },
///   "record_failure": bool,
///   "record_success": bool,
///   "override_to_proceed": bool
/// }
/// ```
#[no_mangle]
pub unsafe extern "C" fn shield_dispatch_tool_verdict(
    verdict_json: *const c_char,
    tool_name: *const c_char,
    stage: u32,
    policy: u32,
    mode: u32,
    err: *mut *mut c_char,
) -> *mut c_char {
    ffi_guard!(ptr, {
        let (verdict, p, m) = match dispatch_inputs(verdict_json, policy, mode, err) {
            Some(t) => t,
            None => return std::ptr::null_mut(),
        };
        let name = match cstr_to_str(tool_name) {
            Some(s) => s,
            None => {
                write_err(
                    err,
                    "shield_dispatch_tool_verdict: null or non-utf8 tool_name",
                );
                return std::ptr::null_mut();
            }
        };
        let s = match stage {
            0 => crate::ToolStage::Call,
            1 => crate::ToolStage::Output,
            other => {
                write_err(
                    err,
                    &format!("shield_dispatch_tool_verdict: unknown stage code {other}"),
                );
                return std::ptr::null_mut();
            }
        };
        let outcome = crate::dispatch_tool_verdict(&verdict, name, s, p, m);
        json_to_c(&crate::tool_dispatch_outcome_to_wire(&outcome))
    })
}

/// Format a verdict as the canonical `[GUARDRAIL ACTION] reason`
/// string. Pure helper exposed so language SDKs that hold a verdict
/// can produce the canonical string without a second native call.
///
/// Returns `null` and writes the reason into `*err` on malformed
/// input. Caller MUST free the returned string via
/// [`shield_free_string`].
#[no_mangle]
pub unsafe extern "C" fn shield_format_block_message(
    verdict_json: *const c_char,
    err: *mut *mut c_char,
) -> *mut c_char {
    ffi_guard!(ptr, {
        let v_str = match cstr_to_str(verdict_json) {
            Some(s) => s,
            None => {
                write_err(
                    err,
                    "shield_format_block_message: null or non-utf8 verdict_json",
                );
                return std::ptr::null_mut();
            }
        };
        let v_value: Value = match serde_json::from_str(v_str) {
            Ok(v) => v,
            Err(e) => {
                write_err(
                    err,
                    &format!("shield_format_block_message: invalid verdict JSON: {e}"),
                );
                return std::ptr::null_mut();
            }
        };
        let verdict = match crate::stage_verdict_from_wire(&v_value) {
            Some(v) => v,
            None => {
                write_err(
                    err,
                    "shield_format_block_message: malformed StageVerdict wire shape",
                );
                return std::ptr::null_mut();
            }
        };
        string_to_c(&crate::format_block_message(&verdict))
    })
}

/// Return the ABI version. The pointer is `'static` and MUST NOT be
/// freed by the caller.
#[no_mangle]
pub extern "C" fn shield_version() -> *const c_char {
    const V: &[u8] = b"0.13.0\0";
    V.as_ptr() as *const c_char
}

/// Look up a `configurations[]` entry by id (§6).
///
/// Mirrors `PyGuardrailsRuntime.llm_configuration` (pyo3) and
/// `JsGuardrailsRuntime::llm_configuration` (napi-rs); exposes the
/// same lookup over the C ABI for the .NET binding (and any future
/// host without a native binding generator).
///
/// Returns:
/// - a heap-allocated JSON object string (caller MUST free with
///   [`shield_free_string`]) when a matching configuration exists.
///   The object mirrors the `ShieldConfiguration` fields surfaced by
///   the Python/Node accessors — `id`, `type`, optional `model`,
///   `provider`, `provider_config`, `endpoint`, `timeout`,
///   `max_tokens`, `api_key_env`, `metadata`, `default`;
/// - `null` with `*err == null` when no configuration matches the id;
/// - `null` with `*err` populated on hard errors (null runtime,
///   invalid UTF-8 in `configuration_id`).
///
/// SDK adapters use this from their LLM-caller closures so the YAML's
/// `model:` / `max_tokens:` actually drive which model the Stage
/// 1/3/5 LLM judge calls, rather than a hard-coded fallback. `model:`
/// is the identifier passed to the provider SDK (`gpt-4o` for direct
/// OpenAI, a deployment name for Azure OpenAI, etc.).
#[no_mangle]
pub unsafe extern "C" fn shield_runtime_llm_configuration(
    runtime: *const ShieldRuntime,
    configuration_id: *const c_char,
    err: *mut *mut c_char,
) -> *mut c_char {
    ffi_guard!(ptr, {
        let rh = match runtime.as_ref() {
            Some(r) => r,
            None => {
                write_err(err, "shield_runtime_llm_configuration: null runtime");
                return std::ptr::null_mut();
            }
        };
        let id = match cstr_to_str(configuration_id) {
            Some(s) => s,
            None => {
                write_err(
                    err,
                    "shield_runtime_llm_configuration: null or non-UTF-8 configuration_id",
                );
                return std::ptr::null_mut();
            }
        };
        for c in &rh.inner.config().configurations {
            if c.id == id {
                let mut map = serde_json::Map::new();
                map.insert("id".into(), Value::String(c.id.clone()));
                map.insert(
                    "type".into(),
                    Value::String(c.config_type.as_str().to_string()),
                );
                if let Some(ref m) = c.model {
                    map.insert("model".into(), Value::String(m.clone()));
                }
                if let Some(ref p) = c.provider {
                    map.insert("provider".into(), Value::String(p.clone()));
                }
                if let Some(ref pc) = c.provider_config {
                    map.insert("provider_config".into(), pc.clone());
                }
                if let Some(ref e) = c.endpoint {
                    map.insert("endpoint".into(), Value::String(e.clone()));
                }
                if let Some(t) = c.timeout {
                    map.insert("timeout".into(), Value::Number(t.into()));
                }
                if let Some(mt) = c.max_tokens {
                    map.insert("max_tokens".into(), Value::Number(mt.into()));
                }
                if let Some(ref env) = c.api_key_env {
                    map.insert("api_key_env".into(), Value::String(env.clone()));
                }
                if let Some(ref meta) = c.metadata {
                    map.insert("metadata".into(), meta.clone());
                }
                if let Some(def) = c.default {
                    map.insert("default".into(), Value::Bool(def));
                }
                return json_to_c(&Value::Object(map));
            }
        }
        // Not found — clear `*err` to disambiguate from the hard-error
        // paths above and return null.
        if !err.is_null() {
            *err = std::ptr::null_mut();
        }
        std::ptr::null_mut()
    })
}

// ────────────────────────────────────────────────────────────────────
// Tests — internal helper coverage. End-to-end FFI tests live in
// `tests/ffi.rs`.
// ────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use crate::guard_policy_runtime::LlmDecision;

    #[test]
    fn parse_resolver_response_handles_allow() {
        let s = r#"{"decision":"allow","value":42,"reason":"ok"}"#;
        let r = parse_resolver_response_json(s);
        assert_eq!(r.decision, ResolverDecision::Allow);
        assert_eq!(r.value, Some(Value::from(42)));
    }

    #[test]
    fn parse_resolver_response_handles_invalid_json() {
        let r = parse_resolver_response_json("not json");
        assert_eq!(r.decision, ResolverDecision::Deny);
        assert!(r.reason.unwrap().contains("invalid"));
    }

    #[test]
    fn parse_resolver_response_handles_missing_decision() {
        let r = parse_resolver_response_json(r#"{"value":42}"#);
        assert_eq!(r.decision, ResolverDecision::Deny);
    }

    #[test]
    fn stage_verdict_round_trip_allow() {
        let v = StageVerdict::allow();
        let j = stage_verdict_to_json(&v);
        assert_eq!(j["allowed"], Value::Bool(true));
        assert_eq!(j["action"], Value::Null);
    }

    #[test]
    fn stage_verdict_round_trip_block() {
        let v = StageVerdict::block("p", "r", Some(0));
        let j = stage_verdict_to_json(&v);
        assert_eq!(j["allowed"], Value::Bool(false));
        assert_eq!(j["action"], Value::String("block".into()));
        assert_eq!(j["policy"], Value::String("p".into()));
        assert_eq!(j["evaluate_when_index"], Value::from(0));
    }

    #[test]
    fn parse_llm_response_block_via_top_level_bool() {
        let s = r#"{"decision":"allow","contains_pii":true}"#;
        let r = parse_llm_response_json(s).unwrap();
        assert!(r.bool_flags.get("contains_pii").copied().unwrap_or(false));
        // The folded decision should now be Block per §12.9.3.
        assert_eq!(r.folded_decision(), LlmDecision::Block);
    }

    #[test]
    fn parse_classifier_verdict_failure_when_score_above_threshold() {
        let s = r#"{"score":0.9,"threshold":0.5,"flagged":false}"#;
        let v = parse_classifier_verdict_json(s).unwrap();
        assert!(v.is_failure());
    }

    /// P10.1 — spans from LLM callback JSON drive Stage-1 redaction.
    #[test]
    fn parse_llm_response_picks_up_spans_array() {
        let s = r#"{
            "decision": "allow",
            "spans": [
                {"start": 0, "end": 5, "replacement": "[REDACTED]"},
                {"start": 10, "end": 15}
            ]
        }"#;
        let r = parse_llm_response_json(s).unwrap();
        assert_eq!(r.spans.len(), 2);
        assert_eq!(r.spans[0].start, 0);
        assert_eq!(r.spans[0].end, 5);
        assert_eq!(r.spans[0].replacement.as_deref(), Some("[REDACTED]"));
        assert_eq!(r.spans[1].start, 10);
        assert_eq!(r.spans[1].end, 15);
        assert!(r.spans[1].replacement.is_none());
    }

    /// P10.1 — classifier callback `spans[]` flow through identically.
    #[test]
    fn parse_classifier_verdict_picks_up_spans_array() {
        let s = r#"{
            "score": 0.9,
            "threshold": 0.5,
            "flagged": true,
            "spans": [{"start": 3, "end": 7, "replacement": "***"}]
        }"#;
        let v = parse_classifier_verdict_json(s).unwrap();
        assert_eq!(v.spans.len(), 1);
        assert_eq!(v.spans[0].start, 3);
        assert_eq!(v.spans[0].end, 7);
        assert_eq!(v.spans[0].replacement.as_deref(), Some("***"));
    }

    /// P10.1 — malformed span entries are dropped silently.
    #[test]
    fn parse_llm_response_drops_malformed_spans_silently() {
        let s = r#"{
            "decision": "allow",
            "spans": [
                {"start": 0, "end": 5},
                {"start": "bad"},
                {"end": 5},
                {"start": 10, "end": 5}
            ]
        }"#;
        let r = parse_llm_response_json(s).unwrap();
        assert_eq!(r.spans.len(), 1);
        assert_eq!(r.spans[0].start, 0);
        assert_eq!(r.spans[0].end, 5);
    }

    /// P10.2 — null callback returns -1 with clear error.
    #[test]
    fn register_callback_with_null_returns_clear_error() {
        let yaml = std::ffi::CString::new(
            "metadata: { name: \"p10\", version: \"0.1.0\", agent_shield_version: \"2.0\" }\n\
             objective: { goal: [\"x\"], forbidden: [\"y\"] }\n\
             resources: { tools: [{ name: \"t\", description: \"t\", permission: \"read_only\" }] }",
        )
        .unwrap();
        // SAFETY: This test passes pointers derived from local CStrings and stack
        // locals into the FFI under test, then reads and frees only pointers that the
        // same FFI contract returns.
        unsafe {
            let mut err: *mut c_char = std::ptr::null_mut();
            let b = shield_builder_from_config_json(yaml.as_ptr(), &mut err);
            assert!(!b.is_null());

            let rc = shield_builder_register_agent_resolver(
                b,
                None,
                None,
                std::ptr::null_mut(),
                &mut err,
            );
            assert_eq!(rc, -1);
            assert!(!err.is_null());
            let msg = CStr::from_ptr(err).to_str().unwrap();
            assert!(
                msg.contains("agent_resolver") || msg.contains("null"),
                "got: {msg}"
            );
            shield_free_string(err);
            shield_builder_free(b);
        }
    }

    // ── shield_dispatch_* — FFI smoke tests ──────────────────────────

    #[test]
    fn ffi_dispatch_stage_verdict_allowed_proceed() {
        let verdict = std::ffi::CString::new(
            r#"{"allowed":true,"action":null,"reason":null,"policy":null,
                "evaluate_when_index":null,"bypassed_by_allowed_when":false,
                "redaction":null,"appended":null,"prepended":null,
                "pending_resolution":null}"#,
        )
        .unwrap();
        // SAFETY: The input pointer comes from a local CString, `err` is a valid local
        // out-parameter, and any returned allocation is released with `shield_free_string`.
        unsafe {
            let mut err: *mut c_char = std::ptr::null_mut();
            let out = shield_dispatch_stage_verdict(verdict.as_ptr(), 0, 0, &mut err);
            assert!(!out.is_null());
            assert!(err.is_null());
            let s = CStr::from_ptr(out).to_str().unwrap();
            let v: Value = serde_json::from_str(s).unwrap();
            assert_eq!(v["action"]["kind"], "proceed");
            assert_eq!(v["record_block"], false);
            assert_eq!(v["override_to_proceed"], false);
            shield_free_string(out);
        }
    }

    #[test]
    fn ffi_dispatch_stage_verdict_denied_return_blocked_in_monitor() {
        let verdict = std::ffi::CString::new(
            r#"{"allowed":false,"action":"block","reason":"PII detected",
                "policy":"p1","evaluate_when_index":0,
                "bypassed_by_allowed_when":false,"redaction":null,
                "appended":null,"prepended":null,"pending_resolution":null}"#,
        )
        .unwrap();
        // SAFETY: The input pointer comes from a local CString, `err` is a valid local
        // out-parameter, and any returned allocation is released with `shield_free_string`.
        unsafe {
            let mut err: *mut c_char = std::ptr::null_mut();
            // policy=ReturnBlocked(0), mode=Monitor(1)
            let out = shield_dispatch_stage_verdict(verdict.as_ptr(), 0, 1, &mut err);
            assert!(!out.is_null());
            let s = CStr::from_ptr(out).to_str().unwrap();
            let v: Value = serde_json::from_str(s).unwrap();
            assert_eq!(v["action"]["kind"], "return_blocked");
            assert_eq!(v["action"]["message"], "[GUARDRAIL BLOCK] PII detected");
            assert_eq!(v["record_block"], true);
            assert_eq!(v["override_to_proceed"], true);
            shield_free_string(out);
        }
    }

    #[test]
    fn ffi_dispatch_stage_verdict_redaction_proceeds_with_mutation() {
        let verdict = std::ffi::CString::new(
            r#"{"allowed":true,"action":"redact","reason":null,
                "policy":null,"evaluate_when_index":null,
                "bypassed_by_allowed_when":false,"redaction":"[REDACTED]",
                "appended":null,"prepended":null,"pending_resolution":null}"#,
        )
        .unwrap();
        // SAFETY: The input pointer comes from a local CString, `err` is a valid local
        // out-parameter, and any returned allocation is released with `shield_free_string`.
        unsafe {
            let mut err: *mut c_char = std::ptr::null_mut();
            let out = shield_dispatch_stage_verdict(verdict.as_ptr(), 0, 0, &mut err);
            assert!(!out.is_null());
            let s = CStr::from_ptr(out).to_str().unwrap();
            let v: Value = serde_json::from_str(s).unwrap();
            assert_eq!(v["action"]["kind"], "proceed_with_mutation");
            assert_eq!(v["action"]["value"], "[REDACTED]");
            shield_free_string(out);
        }
    }

    #[test]
    fn ffi_dispatch_tool_verdict_blocked_includes_tool_name() {
        let verdict = std::ffi::CString::new(
            r#"{"allowed":false,"action":"block","reason":"denied",
                "policy":null,"evaluate_when_index":null,
                "bypassed_by_allowed_when":false,"redaction":null,
                "appended":null,"prepended":null,"pending_resolution":null}"#,
        )
        .unwrap();
        let tool = std::ffi::CString::new("send_email").unwrap();
        // SAFETY: The input pointers come from local CStrings, `err` is a valid local
        // out-parameter, and any returned allocation is released with `shield_free_string`.
        unsafe {
            let mut err: *mut c_char = std::ptr::null_mut();
            // stage=Call(0), policy=ReturnBlocked(0), mode=Enforce(0)
            let out =
                shield_dispatch_tool_verdict(verdict.as_ptr(), tool.as_ptr(), 0, 0, 0, &mut err);
            assert!(!out.is_null());
            let s = CStr::from_ptr(out).to_str().unwrap();
            let v: Value = serde_json::from_str(s).unwrap();
            assert_eq!(v["action"]["kind"], "blocked");
            assert_eq!(
                v["action"]["message"],
                "[GUARDRAIL BLOCK] denied (tool: send_email)"
            );
            assert_eq!(v["record_failure"], false); // Stage 2/3 deny
            assert_eq!(v["record_success"], false);
            shield_free_string(out);
        }
    }

    #[test]
    fn ffi_dispatch_tool_verdict_stage4_blocked_records_failure() {
        let verdict = std::ffi::CString::new(
            r#"{"allowed":false,"action":"block","reason":"output denied",
                "policy":null,"evaluate_when_index":null,
                "bypassed_by_allowed_when":false,"redaction":null,
                "appended":null,"prepended":null,"pending_resolution":null}"#,
        )
        .unwrap();
        let tool = std::ffi::CString::new("lookup").unwrap();
        // SAFETY: The input pointers come from local CStrings, `err` is a valid local
        // out-parameter, and any returned allocation is released with `shield_free_string`.
        unsafe {
            let mut err: *mut c_char = std::ptr::null_mut();
            // stage=Output(1)
            let out =
                shield_dispatch_tool_verdict(verdict.as_ptr(), tool.as_ptr(), 1, 0, 0, &mut err);
            let s = CStr::from_ptr(out).to_str().unwrap();
            let v: Value = serde_json::from_str(s).unwrap();
            assert_eq!(v["record_failure"], true);
            assert_eq!(v["record_success"], false);
            shield_free_string(out);
        }
    }

    #[test]
    fn ffi_dispatch_rejects_invalid_policy_code() {
        let verdict = std::ffi::CString::new(
            r#"{"allowed":true,"action":null,"reason":null,"policy":null,
                "evaluate_when_index":null,"bypassed_by_allowed_when":false,
                "redaction":null,"appended":null,"prepended":null,
                "pending_resolution":null}"#,
        )
        .unwrap();
        // SAFETY: The input pointer comes from a local CString and `err` is a valid
        // local out-parameter owned by this test for the duration of the FFI call.
        unsafe {
            let mut err: *mut c_char = std::ptr::null_mut();
            let out = shield_dispatch_stage_verdict(verdict.as_ptr(), 99, 0, &mut err);
            assert!(out.is_null());
            assert!(!err.is_null());
            let msg = CStr::from_ptr(err).to_str().unwrap();
            assert!(msg.contains("policy"), "got: {msg}");
            shield_free_string(err);
        }
    }

    #[test]
    fn ffi_format_block_message_round_trip() {
        let verdict = std::ffi::CString::new(
            r#"{"allowed":false,"action":"redact","reason":"phone number",
                "policy":null,"evaluate_when_index":null,
                "bypassed_by_allowed_when":false,"redaction":null,
                "appended":null,"prepended":null,"pending_resolution":null}"#,
        )
        .unwrap();
        // SAFETY: The input pointer comes from a local CString, `err` is a valid local
        // out-parameter, and any returned allocation is released with `shield_free_string`.
        unsafe {
            let mut err: *mut c_char = std::ptr::null_mut();
            let out = shield_format_block_message(verdict.as_ptr(), &mut err);
            assert!(!out.is_null());
            let s = CStr::from_ptr(out).to_str().unwrap();
            assert_eq!(s, "[GUARDRAIL REDACT] phone number");
            shield_free_string(out);
        }
    }
}
