//! [`RuntimeBuilder`].
//!
//! The builder is the only public entry point for constructing a
//! [`GuardrailsRuntime`]. It collects:
//!
//! 1. The merged configuration (loaded via
//!    [`load_chain`](crate::load_chain) or supplied directly).
//! 2. Optional host hooks: `AgentResolver`, `DelegateDispatcher`,
//!    `LlmCaller`, `ClassifierCaller`, plus `ObservabilityProvider`
//!    instances.
//! 3. Tunable knobs: `tool_retry_limit`, streaming options, custom
//!    populator extractors.
//!
//! On [`Self::build`] the builder constructs the entire runtime stack
//! (event bus → tracker → resolver dispatcher → guard-policy engine →
//! observability dispatcher) and produces an `Arc<GuardrailsRuntime>`.
//!
//! ## Defaults
//!
//! - If no [`DelegateDispatcher`] was registered, the
//!   [`crate::runtime::delegate_default::DefaultDelegateDispatcher`]
//!   is wired in. This dispatcher fails closed for `mcp_server` and
//!   `a2a_agent` configurations and provides HTTP+classifier transport
//!   for the other types.
//! - If no [`LlmCaller`] is registered, the
//!   [`crate::runtime::llm_default::FailClosedLlmCaller`] is used —
//!   any `evaluate_when[].llm` entry will block.
//! - No default [`ClassifierCaller`] — `classifier:` evaluate_when
//!   entries fall back to the GuardPolicyEngine's built-in fail-closed
//!   path.
//! - No default [`AgentResolver`] — `kind: agent` resolvers fail
//!   closed unless registered. `kind: human` resolvers do not need a
//!   trait callback at all: they are dispatched through the canonical
//!   `agent_shield.ask_human` MCP tool path. The host registers an MCP
//!   tool under that name (see `examples/tools/ask-human-mcp-server/`).
//!
//! ## Streaming
//!
//! [`Self::streaming_window`] threads window/overlap/trigger options
//! into every [`crate::runtime::session::GuardrailsSession::streaming_session`]
//! call. Hosts that need per-call overrides should configure the
//! returned [`crate::guard_policy_runtime::StreamingGuard`]
//! directly via its builder methods.

use std::collections::HashMap;
use std::path::Path;
use std::sync::Arc;

use crate::clock::{Clock, SystemClock};
use crate::event_bus::EventBus;
use crate::guard_policy_runtime::{
    streaming::StreamingTrigger, ClassifierCaller, GuardPolicyDeps, GuardPolicyEngine, LlmCaller,
};
use crate::lifetime_tracker::LifetimeTracker;
use crate::loader::load_chain;
use crate::merge::MergedConfig;
use crate::observability::{ObservabilityDispatcher, ObservabilityProvider};
use crate::perf_telemetry::PerfTelemetry;
use crate::populator::{Extractor, ExtractorRegistry};
use crate::resolver_runtime::{
    AgentResolver, DelegateDispatcher, ResolverDeps, ResolverDispatcher, DEFAULT_TOOL_RETRY_LIMIT,
};
use crate::variables::Variable;

use super::delegate_default::DefaultDelegateDispatcher;
use super::errors::RuntimeError;
use super::runtime::GuardrailsRuntime;

/// Streaming options surfaced through the builder. Mirrors the
/// `StreamingGuard`'s builder methods so hosts can pin a default
/// cadence at runtime construction time and override per call only
/// when needed.
#[derive(Debug, Clone, Copy)]
pub struct StreamingOptions {
    pub trigger: StreamingTrigger,
    pub window_size: usize,
    pub overlap: usize,
}

impl Default for StreamingOptions {
    fn default() -> Self {
        Self {
            trigger: StreamingTrigger::OnComplete,
            window_size: crate::guard_policy_runtime::streaming::DEFAULT_WINDOW_SIZE,
            overlap: crate::guard_policy_runtime::streaming::DEFAULT_OVERLAP,
        }
    }
}

/// Builder for [`GuardrailsRuntime`].
pub struct RuntimeBuilder {
    config: MergedConfig,
    agent_resolver: Option<Arc<dyn AgentResolver>>,
    delegate_dispatcher: Option<Arc<dyn DelegateDispatcher>>,
    llm_caller: Option<Arc<dyn LlmCaller>>,
    classifier_caller: Option<Arc<dyn ClassifierCaller>>,
    providers: Vec<Arc<dyn ObservabilityProvider>>,
    extractors: ExtractorRegistry,
    human_registry: crate::resolver_runtime::HumanRegistry,
    tool_retry_limit: u32,
    streaming: StreamingOptions,
    /// Whether the host explicitly registered a delegate dispatcher.
    /// When `false`, [`Self::build`] installs the default dispatcher.
    delegate_explicit: bool,
    /// Host capability declaration: when `true`, the host genuinely
    /// tears down the LLM context at scope-reset boundaries (turn /
    /// request end). Required by proof TC-3 for `ifc.scope:
    /// per_turn` or `per_request`. Hosts that retain LLM context
    /// across these boundaries (LangChain memory, AutoGen group
    /// chats, persistent conversation IDs) MUST NOT set this.
    supports_context_reset: bool,
    /// Perf-telemetry gating knob (v8 perf-logging Phase 1, PR5).
    /// Default [`PerfTelemetry::Off`] — zero perf events emit
    /// unless the host opts in. See [`crate::perf_telemetry`] for the
    /// gating table.
    perf_telemetry: PerfTelemetry,
    /// Clock used by the perf-telemetry instrumentation (v8 plan
    /// PR6). Defaults to [`SystemClock`]; tests override via
    /// [`Self::with_clock`] using [`crate::clock::MockClock`] to make
    /// `KEY_DURATION_MS` assertions deterministic.
    clock: Arc<dyn Clock>,
}

impl std::fmt::Debug for RuntimeBuilder {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("RuntimeBuilder")
            .field("metadata.name", &self.config.metadata.name)
            .field("has_agent_resolver", &self.agent_resolver.is_some())
            .field(
                "has_delegate_dispatcher",
                &self.delegate_dispatcher.is_some(),
            )
            .field("has_llm_caller", &self.llm_caller.is_some())
            .field("has_classifier_caller", &self.classifier_caller.is_some())
            .field("providers", &self.providers.len())
            .field("tool_retry_limit", &self.tool_retry_limit)
            .field("streaming", &self.streaming)
            .field("perf_telemetry", &self.perf_telemetry)
            .finish_non_exhaustive()
    }
}

impl RuntimeBuilder {
    // ── Constructors ─────────────────────────────────────────────────

    /// Load a single guardrails YAML file (with `extends:` resolution
    /// per §3.2 / §4.2) and seed the builder with the resulting merged
    /// configuration.
    pub fn from_yaml(path: impl AsRef<Path>) -> Result<Self, RuntimeError> {
        let path: &Path = path.as_ref();
        let config = load_chain(path)?;
        Ok(Self::from_config(config))
    }

    /// Load and merge an explicit ordered list of YAML files. The
    /// rightmost path is the leaf; each earlier file is processed as
    /// `extends:`-style ancestor with leaf-wins semantics. This is a
    /// convenience over [`Self::from_yaml`] for hosts that don't put
    /// `extends:` in their YAML and instead curate the chain in code.
    ///
    /// ## Implementation note
    ///
    /// [`load_chain`] resolves `extends:` declared inside the YAML. To
    /// support an in-code chain without `extends:`, we load each file
    /// independently and re-merge via [`crate::merge::merge_chain`].
    /// Most hosts use [`Self::from_yaml`] (single leaf file with an
    /// `extends:` chain) — this method is provided for hosts that
    /// curate the chain in code.
    pub fn from_yaml_chain<P: AsRef<Path>>(paths: &[P]) -> Result<Self, RuntimeError> {
        if paths.is_empty() {
            return Err(RuntimeError::Config(crate::errors::ConfigError::Schema {
                loc: crate::errors::SourceLoc::default(),
                message: "from_yaml_chain: paths slice is empty".into(),
            }));
        }
        // Single-path optimisation — defer to from_yaml.
        if paths.len() == 1 {
            return Self::from_yaml(paths[0].as_ref());
        }
        // Multi-path: each path's `extends:` chain is resolved independently
        // via `load_from_paths`, then their parents-then-leaf ordered lists
        // are concatenated and merge_chain'd together. Parents shared
        // between paths (diamond loads) are deduped on canonical path so
        // each file contributes its content exactly once.
        let merged = crate::loader::load_from_paths(paths).map_err(RuntimeError::Config)?;
        Ok(Self::from_config(merged))
    }

    /// Load and merge a list of YAML *strings* into the builder. No
    /// filesystem access; the rightmost string is the leaf. Used by
    /// hosts that compose configuration in memory
    /// (`GuardrailsConfig.extend(...)`, `with_overrides`,
    /// policy-pack assembly) instead of curating a chain on disk.
    pub fn from_yaml_strings(yamls: &[&str]) -> Result<Self, RuntimeError> {
        let merged = crate::loader::load_from_strings(yamls).map_err(RuntimeError::Config)?;
        Ok(Self::from_config(merged))
    }

    /// Seed the builder with an already-merged configuration. The
    /// in-memory path used by tests and hosts that build configs in
    /// code.
    pub fn from_config(config: MergedConfig) -> Self {
        Self {
            config,
            agent_resolver: None,
            delegate_dispatcher: None,
            llm_caller: None,
            classifier_caller: None,
            providers: Vec::new(),
            extractors: ExtractorRegistry::new(),
            human_registry: crate::resolver_runtime::HumanRegistry::new(),
            tool_retry_limit: DEFAULT_TOOL_RETRY_LIMIT,
            streaming: StreamingOptions::default(),
            delegate_explicit: false,
            supports_context_reset: false,
            perf_telemetry: PerfTelemetry::Off,
            clock: Arc::new(SystemClock::new()),
        }
    }

    /// Seed the builder from a [`CompiledPolicy`](crate::config::CompiledPolicy).
    /// Multi-tenant SaaS callers cache compiled policies by digest and
    /// reuse the resulting runtime to avoid repeated parsing.
    pub fn from_compiled_policy(compiled: &crate::config::CompiledPolicy) -> Self {
        Self::from_config(compiled.merged().as_ref().clone())
    }

    // ── Hook registration ────────────────────────────────────────────

    /// Register the agent-resolver hook (§11.4).
    pub fn register_agent_resolver(mut self, resolver: Arc<dyn AgentResolver>) -> Self {
        self.agent_resolver = Some(resolver);
        self
    }

    /// Declare that the host genuinely tears down the LLM context at
    /// scope-reset boundaries (turn end, request end). Required by
    /// proof TC-3 for `ifc.scope: per_turn` or `per_request`.
    ///
    /// Hosts that retain LLM context across these boundaries —
    /// LangChain memory, AutoGen group chats, persistent
    /// conversation IDs that survive the SDK boundary, anything that
    /// keeps prior-turn data in the LLM's effective context — MUST
    /// NOT set this. The default is `false` (does not support
    /// context reset), and configurations that require non-`per_session`
    /// scope will be rejected at [`Self::build`] time.
    pub fn supports_context_reset(mut self, supports: bool) -> Self {
        self.supports_context_reset = supports;
        self
    }

    /// Register the delegate dispatcher (§11.10.3 / §11.12). When this
    /// is called, the default dispatcher is NOT installed.
    pub fn register_delegate_dispatcher(mut self, dispatcher: Arc<dyn DelegateDispatcher>) -> Self {
        self.delegate_dispatcher = Some(dispatcher);
        self.delegate_explicit = true;
        self
    }

    /// Register the LLM caller used by `evaluate_when[].llm` detection
    /// (§12.5.1 / §12.9).
    pub fn register_llm_caller(mut self, caller: Arc<dyn LlmCaller>) -> Self {
        self.llm_caller = Some(caller);
        self
    }

    /// Register the classifier caller used by
    /// `evaluate_when[].classifier` detection (§12.5.1 / §12.9).
    pub fn register_classifier_caller(mut self, caller: Arc<dyn ClassifierCaller>) -> Self {
        self.classifier_caller = Some(caller);
        self
    }

    /// Register a named [`crate::resolver_runtime::HumanResolver`].
    /// Resolvers in YAML reference the registered name via
    /// `kind: human, provider: <name>` (bundled, conventional names)
    /// or `kind: human, name: <name>` (closure-based, host-supplied
    /// names). Both fields hit the same registry.
    ///
    /// Calling this method does not change the default
    /// `agent_shield.ask_human` MCP signal path — that's still active
    /// for any `kind: human` resolver that omits `provider:` / `name:`.
    pub fn register_human_provider(
        self,
        name: impl Into<String>,
        handler: Arc<dyn crate::resolver_runtime::HumanResolver>,
    ) -> Self {
        self.human_registry.register(name, handler);
        self
    }

    /// Register an observability provider (§19). Multiple providers
    /// fan-out — each call adds one. We use `register_provider` rather
    /// than the §6.5 `register_provider`-on-configurations naming to
    /// avoid collision with the `configurations[].provider` concept.
    pub fn register_provider(mut self, provider: Arc<dyn ObservabilityProvider>) -> Self {
        self.providers.push(provider);
        self
    }

    /// Register a populator extractor (§10.5.1's `extractor:` field).
    pub fn register_extractor(mut self, name: &str, extractor: Box<dyn Extractor>) -> Self {
        self.extractors.register(name, extractor);
        self
    }

    // ── Knobs ───────────────────────────────────────────────────────

    /// Override the per-(turn, variable, tool) retry limit for
    /// `kind: tool` resolvers (§11.10.2). Default is
    /// [`DEFAULT_TOOL_RETRY_LIMIT`] (3).
    pub fn tool_retry_limit(mut self, n: usize) -> Self {
        self.tool_retry_limit = n.try_into().unwrap_or(u32::MAX);
        self
    }

    /// Pin streaming options (window size / overlap / trigger) used by
    /// every [`crate::guard_policy_runtime::StreamingGuard`]
    /// produced by the runtime.
    pub fn streaming_window(mut self, opts: StreamingOptions) -> Self {
        self.streaming = opts;
        self
    }

    /// Override the runtime's effective enforcement mode (#14).
    ///
    /// The `mode:` knob is **not** part of the YAML / JSON-Schema
    /// contract — it is a runtime concern, set programmatically here
    /// or via the `AGENT_SHIELD_MODE` env var. Calling this is the
    /// supported way for hosts to flip a policy bundle into shadow
    /// for safe-adoption rollouts. The env var, when set, takes
    /// precedence over this call (consistency with operator override).
    pub fn with_mode(mut self, mode: crate::shield_primitives::RuntimeMode) -> Self {
        self.config.mode = mode;
        self
    }

    /// Opt into the perf-instrumentation events introduced in v8
    /// perf-logging Phase 1 (PR6). Default is [`PerfTelemetry::Off`]
    /// — no perf events emit. Pick [`PerfTelemetry::External`] for
    /// LLM + classifier cost signals only, or [`PerfTelemetry::Full`]
    /// for the full stage / policy / detection / LLM / classifier
    /// event stream.
    ///
    /// See [`crate::perf_telemetry`] for the gating table.
    pub fn with_perf_telemetry(mut self, mode: PerfTelemetry) -> Self {
        self.perf_telemetry = mode;
        self
    }

    /// Override the [`Clock`] used by the perf-telemetry instrumentation
    /// (v8 plan PR6). Default is [`SystemClock`]; tests pass
    /// [`crate::clock::MockClock`] to make `KEY_DURATION_MS` deterministic.
    /// Hosts should not need to call this in production.
    pub fn with_clock(mut self, clock: Arc<dyn Clock>) -> Self {
        self.clock = clock;
        self
    }

    /// Borrow the merged configuration before build. Useful for tests.
    pub fn config(&self) -> &MergedConfig {
        &self.config
    }

    // ── Build ───────────────────────────────────────────────────────

    /// Construct the runtime. The order matters:
    ///
    /// 1. Build the [`EventBus`].
    /// 2. Build the [`LifetimeTracker`] subscribed to the bus.
    /// 3. Build the [`ResolverDispatcher`] with hooks + tracker.
    /// 4. Build the [`ObservabilityDispatcher`] subscribed to the bus.
    /// 5. Build the [`GuardPolicyEngine`] with the resolver + tracker
    ///    + observability + caller hooks.
    /// 6. Wrap everything in an `Arc<GuardrailsRuntime>` and return.
    pub fn build(mut self) -> Result<Arc<GuardrailsRuntime>, RuntimeError> {
        // §12.9.2 — defense-in-depth: a hand-constructed `MergedConfig`
        // passed via `from_config` could carry an unresolved
        // `prompt_path:` if the caller bypassed the loader's inlining
        // pass. The loader itself never leaves one populated; this is
        // a foot-gun guard, not a security boundary.
        for pol in self
            .config
            .input_validation
            .guard_policies
            .iter()
            .chain(self.config.tool_execution_validation.guard_policies.iter())
            .chain(self.config.post_tool_validation.guard_policies.iter())
            .chain(self.config.output_validation.guard_policies.iter())
        {
            for ew in &pol.evaluate_when {
                let crate::guard_policy::DetectionKind::Llm(llm) = &ew.detection else {
                    continue;
                };
                if llm.prompt_path.is_some() {
                    return Err(RuntimeError::Config(
                        crate::errors::ConfigError::PromptFile {
                            loc: crate::errors::SourceLoc::default(),
                            path: std::path::PathBuf::from(
                                llm.prompt_path.as_deref().unwrap_or(""),
                            ),
                            kind: crate::errors::PromptFileErrorKind::UnresolvedPromptPath,
                        },
                    ));
                }
            }
        }

        // TC-3 enforcement: non-`per_session` IFC scope requires the
        // host to advertise `supports_context_reset` capability.
        // Without it, the runtime would clear exposure while the LLM
        // context still retains the prior scope's secrets (the
        // proof's invariant `I` would break).
        if !self.config.ifc.is_disabled()
            && !matches!(self.config.ifc.scope, crate::ifc::ScopePolicy::PerSession)
            && !self.supports_context_reset
        {
            return Err(RuntimeError::Config(crate::errors::ConfigError::Schema {
                loc: crate::errors::SourceLoc::default(),
                message: format!(
                    "ifc.scope: `{:?}` requires the host to declare \
                        `RuntimeBuilder::supports_context_reset(true)`. \
                        See proof TC-3 in docs/information-flow-control-proof.md.",
                    self.config.ifc.scope
                ),
            }));
        }

        // Default delegate dispatcher when the host didn't register
        // one explicitly.
        if !self.delegate_explicit {
            self.delegate_dispatcher = Some(Arc::new(DefaultDelegateDispatcher::default()));
        }

        // Auto-wire an LLM caller from `configurations[]` if the host
        // didn't register one explicitly. Engaged only when the `http`
        // feature is on AND at least one `type: llm` configuration
        // resolves (provider + model + api_key_env all present and the
        // env var is set). Otherwise leave `llm_caller` as None and the
        // engine's fail-closed path handles it.
        #[cfg(feature = "http")]
        if self.llm_caller.is_none() {
            let auto = crate::runtime::llm_auto::AutoWiredLlmCaller::from_configurations(
                &self.config.configurations,
            );
            if auto.has_any() {
                self.llm_caller = Some(Arc::new(auto));
            }
        }

        // Same auto-wire path for `type: classifier` configurations.
        // The bundled providers under `crate::classifiers::*` are gated
        // by per-provider Cargo features; entries whose feature is
        // disabled are skipped silently and fall through to the
        // engine's fail-closed path.
        #[cfg(feature = "http")]
        if self.classifier_caller.is_none() {
            let auto = crate::classifiers::AutoWiredClassifierCaller::from_configurations(
                &self.config.configurations,
            );
            if auto.has_any() {
                self.classifier_caller = Some(Arc::new(auto));
            }
        }

        // Auto-register bundled `kind: human` providers referenced from
        // YAML when the host has not already registered a handler under
        // the same name. Walk every variable's `on_demand_by` resolver
        // looking for `kind: human` entries with `provider:` /
        // `name:` pointing at a known bundled name (auto_reject /
        // deny / console). Host registrations always win.
        for v in &self.config.variables {
            if let Some(crate::resolver::Resolver::Human { provider, name, .. }) = &v.on_demand_by {
                if let Some(handler_name) = provider.as_deref().or(name.as_deref()) {
                    if self.human_registry.lookup(handler_name).is_none() {
                        if let Some(bundled) = crate::approval::bundled_handler(handler_name) {
                            self.human_registry.register(handler_name, bundled);
                        }
                    }
                }
            }
        }

        let bus = EventBus::new();

        // Variable registry from the merged config.
        let mut registry: HashMap<String, Variable> =
            HashMap::with_capacity(self.config.variables.len());
        for v in &self.config.variables {
            registry.insert(v.name.clone(), v.clone());
        }
        let variables_arc = Arc::new(registry.clone());

        let tracker = LifetimeTracker::new(bus.clone(), registry);

        // Configurations indexed by id for delegate routing.
        let mut configurations_map: HashMap<String, _> =
            HashMap::with_capacity(self.config.configurations.len());
        for cfg in &self.config.configurations {
            configurations_map.insert(cfg.id.clone(), cfg.clone());
        }

        // Observability dispatcher (§19.5). Built before the resolver
        // dispatcher so the resolver runtime can emit shadow-mode
        // audit events through it (#14) and §11.9 / §19.5 resolver-audit
        // events for every resolver dispatch.
        let observability = ObservabilityDispatcher::with_agent_id_and_mode(
            bus.clone(),
            self.config.metadata.name.clone(),
            self.config.mode,
        );
        for provider in &self.providers {
            observability.register_provider(provider.clone());
        }

        let resolver_deps = {
            let mut deps = ResolverDeps::new(
                bus.clone(),
                tracker.clone(),
                variables_arc.clone(),
                Arc::new(configurations_map),
                self.human_registry.clone(),
                self.tool_retry_limit,
                observability.clone(),
            )
            .with_mode(self.config.mode);
            if let Some(hook) = self.agent_resolver.clone() {
                deps = deps.with_agent_resolver(hook);
            }
            if let Some(hook) = self.delegate_dispatcher.clone() {
                deps = deps.with_delegate_dispatcher(hook);
            }
            deps
        };
        let resolver = Arc::new(ResolverDispatcher::new(resolver_deps));
        // Subscribe to turn.start so the tool-retry tracker advances
        // automatically when the host calls begin_turn().
        let _sub = resolver.wire_turn_boundary_subscription();

        // Guard-policy engine.
        let config_arc = Arc::new(self.config.clone());
        let engine_deps = GuardPolicyDeps {
            config: config_arc.clone(),
            event_bus: bus.clone(),
            tracker: tracker.clone(),
            resolver: resolver.clone(),
            observability: observability.clone(),
            llm_caller: self.llm_caller.clone(),
            classifier_caller: self.classifier_caller.clone(),
            clock: self.clock.clone(),
            perf_telemetry: self.perf_telemetry,
        };
        let engine = GuardPolicyEngine::new(engine_deps);

        let runtime = Arc::new(GuardrailsRuntime {
            config: config_arc,
            bus,
            tracker,
            resolver,
            engine,
            observability,
            extractors: Arc::new(self.extractors),
            variables: variables_arc,
            streaming: self.streaming,
            perf_telemetry: self.perf_telemetry,
        });
        Ok(runtime)
    }

    // ── Streaming knobs accessor (used by sessions) ─────────────────

    /// Cloned streaming options. Used by
    /// [`crate::runtime::session::GuardrailsSession`] when
    /// constructing per-stage streaming guards.
    #[allow(dead_code)]
    pub(crate) fn streaming_options(&self) -> StreamingOptions {
        self.streaming
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn empty_config() -> MergedConfig {
        let mut m = MergedConfig::default();
        m.metadata.name = "test".into();
        m.metadata.version = "0.1.0".into();
        m
    }

    #[test]
    fn build_runtime_from_empty_config_succeeds() {
        let rt = RuntimeBuilder::from_config(empty_config()).build().unwrap();
        assert_eq!(rt.config().metadata.name, "test");
    }

    #[test]
    fn default_delegate_dispatcher_installed_when_unspecified() {
        let rt = RuntimeBuilder::from_config(empty_config()).build().unwrap();
        // The dispatcher is held inside the resolver — we can't
        // observe it directly, but we can verify the resolver was
        // built without error.
        let _ = rt.resolver();
    }

    #[test]
    fn explicit_delegate_dispatcher_overrides_default() {
        struct Stub;
        impl DelegateDispatcher for Stub {
            fn dispatch(
                &self,
                _: crate::resolver_runtime::DelegateRequest,
            ) -> Result<
                crate::resolver::ResolverResponse,
                crate::resolver_runtime::ResolverRuntimeError,
            > {
                unreachable!()
            }
        }
        let _rt = RuntimeBuilder::from_config(empty_config())
            .register_delegate_dispatcher(Arc::new(Stub))
            .build()
            .unwrap();
    }

    #[test]
    fn tool_retry_limit_can_be_overridden() {
        let _rt = RuntimeBuilder::from_config(empty_config())
            .tool_retry_limit(7)
            .build()
            .unwrap();
    }

    #[test]
    fn streaming_window_can_be_set() {
        let opts = StreamingOptions {
            trigger: StreamingTrigger::Windowed,
            window_size: 100,
            overlap: 20,
        };
        let _rt = RuntimeBuilder::from_config(empty_config())
            .streaming_window(opts)
            .build()
            .unwrap();
    }

    #[test]
    fn perf_telemetry_default_off() {
        let rt = RuntimeBuilder::from_config(empty_config()).build().unwrap();
        assert_eq!(rt.perf_telemetry(), PerfTelemetry::Off);
    }

    #[test]
    fn with_perf_telemetry_roundtrips_external() {
        let rt = RuntimeBuilder::from_config(empty_config())
            .with_perf_telemetry(PerfTelemetry::External)
            .build()
            .unwrap();
        assert_eq!(rt.perf_telemetry(), PerfTelemetry::External);
    }

    #[test]
    fn with_perf_telemetry_roundtrips_full() {
        let rt = RuntimeBuilder::from_config(empty_config())
            .with_perf_telemetry(PerfTelemetry::Full)
            .build()
            .unwrap();
        assert_eq!(rt.perf_telemetry(), PerfTelemetry::Full);
    }
}
