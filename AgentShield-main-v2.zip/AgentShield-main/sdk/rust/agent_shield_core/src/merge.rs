//! Merge semantics for the `extends:` chain.
//!
//! Implemented per §3.2 / §4.2 / §5.1 / §6.7 / §8.4 / §12.12. Highlights:
//!
//! - **metadata**: leaf-wins for `name`/`version`/`description`; most-restrictive
//!   for `agent_shield_version` (handled in `metadata.rs::most_restrictive`).
//! - **objective**: concat-by-tier with attribution preserved.
//! - **configurations**: same-`id` last-wins per field; `type:` must match.
//! - **predicates**: concat across files; same-name redefinition is a
//!   load-time error.
//! - **variables**: additive concat; later same-name entries replace earlier
//!   per leaf-wins semantics.
//! - **resources**: additive concat with description last-wins for same-
//!   identity entries.
//! - **guard policies (per stage)**: same-name additive merge:
//!   - `applies_to.tools/agents/endpoints[]` concat + dedup,
//!   - `active_if` parent-immutable (child redefinition is a load-time error),
//!   - `evaluate_when[]` concat,
//!   - `allowed_when` AND-merge,
//!   - `action`/`description`/`replacement` last-wins,
//!   - `log` last-wins per leaf field.

use std::collections::BTreeMap;
use std::path::PathBuf;

use crate::configurations::ShieldConfiguration;
use crate::errors::{ConfigError, SourceLoc};
use crate::guard_policy::GuardPolicy;
use crate::metadata::{most_restrictive, AgentShieldVersion, Metadata};
use crate::objective::{Objective, ObjectiveTier};
use crate::populator::{methods_match, pattern_matches_uri};
use crate::predicates::{PredicateBody, PredicateMap};
use crate::resources::{AgentResource, EndpointResource, LogBlock, ResourcesBlock, ToolResource};
use crate::shield_primitives::RuntimeMode;
use crate::variables::Variable;

/// One file as it has been parsed but before merging. Used as the input to
/// `merge_chain`.
#[derive(Debug, Clone)]
pub struct ParsedFile {
    pub path: PathBuf,
    pub metadata: Metadata,
    pub objective_tier: Option<ObjectiveTier>,
    pub configurations: Vec<ShieldConfiguration>,
    pub predicates: BTreeMap<String, PredicateBody>,
    pub variables: Vec<Variable>,
    pub resources: ResourcesBlock,
    pub input_validation: Vec<GuardPolicy>,
    pub state_validation: Vec<GuardPolicy>,
    pub tool_execution_validation: Vec<GuardPolicy>,
    pub post_tool_validation: Vec<GuardPolicy>,
    pub output_validation: Vec<GuardPolicy>,
    pub agent_shield_version: Option<AgentShieldVersion>,
    /// IFC spec on this file, when present. Composability semantics:
    /// only the leaf file may declare an `ifc:` block; parents that
    /// also declare one cause a load-time error so the lattice can't
    /// silently change underneath an extending file.
    pub ifc: Option<crate::ifc::IfcSpec>,
}

/// Stage-level configuration block on `input_validation` / `output_validation`
/// / `tool_execution_validation` / `post_tool_validation`. Holds the list of
/// guard policies plus the optional `configuration:` reference.
#[derive(Debug, Clone, Default)]
pub struct StageBlock {
    pub configuration: Option<String>,
    pub guard_policies: Vec<GuardPolicy>,
}

/// Final, merged guardrails configuration produced by the loader.
#[derive(Debug, Clone, Default)]
pub struct MergedConfig {
    pub metadata: Metadata,
    pub objective: Objective,
    pub configurations: Vec<ShieldConfiguration>,
    pub predicates: PredicateMap,
    pub variables: Vec<Variable>,
    pub resources: ResourcesBlock,
    pub input_validation: StageBlock,
    pub state_validation: StageBlock,
    pub tool_execution_validation: StageBlock,
    pub post_tool_validation: StageBlock,
    pub output_validation: StageBlock,
    pub effective_agent_shield_version: Option<AgentShieldVersion>,
    /// Compiled IFC config. `CompiledIfc::default()` (trivial /
    /// disabled) when no `ifc:` block was declared in any of the
    /// merged files; IFC checks at runtime then no-op.
    pub ifc: crate::ifc::CompiledIfc,
    /// Effective runtime mode (#14). Default `Active`; overridden by
    /// `RuntimeBuilder::with_mode` or the `AGENT_SHIELD_MODE` env var.
    /// Not sourced from YAML — `mode:` is a runtime concern, not a
    /// policy-bundle concern.
    pub mode: RuntimeMode,
}

impl MergedConfig {
    /// Look up the IFC `λ` (source tags) for a tool by name. Falls
    /// back to the `*` wildcard tool entry, then to `∅`. When no
    /// `ifc:` block is configured the universe is empty and this
    /// returns [`TagSet::EMPTY`], so downstream `raise_exposure` is
    /// a no-op.
    pub fn ifc_tags_for_tool(&self, tool: &str) -> crate::ifc::TagSet {
        self.resolve_resource_field(
            self.resources
                .tools
                .iter()
                .find(|t| t.name == tool)
                .and_then(|t| t.tags.as_deref()),
            self.resources
                .tools
                .iter()
                .find(|t| t.name == "*")
                .and_then(|t| t.tags.as_deref()),
            crate::ifc::TagSet::EMPTY,
        )
    }

    /// Look up the IFC `μ` (sink clearance) for a tool by name. Same
    /// wildcard / default fallback as [`Self::ifc_tags_for_tool`] but
    /// resolving against `ifc.default_clearance`.
    pub fn ifc_clearance_for_tool(&self, tool: &str) -> crate::ifc::TagSet {
        self.resolve_resource_field(
            self.resources
                .tools
                .iter()
                .find(|t| t.name == tool)
                .and_then(|t| t.clearance.as_deref()),
            self.resources
                .tools
                .iter()
                .find(|t| t.name == "*")
                .and_then(|t| t.clearance.as_deref()),
            self.ifc.default_clearance,
        )
    }

    /// Look up the IFC `ν` (audience) for a tool by name.
    pub fn ifc_audience_for_tool(&self, tool: &str) -> crate::ifc::TagSet {
        self.resolve_resource_field(
            self.resources
                .tools
                .iter()
                .find(|t| t.name == tool)
                .and_then(|t| t.audience.as_deref()),
            self.resources
                .tools
                .iter()
                .find(|t| t.name == "*")
                .and_then(|t| t.audience.as_deref()),
            self.ifc.default_audience,
        )
    }

    pub fn ifc_has_tool_resource(&self, tool: &str) -> bool {
        self.ifc.is_disabled()
            || self
                .resources
                .tools
                .iter()
                .any(|t| t.name == tool || t.name == "*")
    }

    /// Look up the IFC `λ` for an endpoint using the same §13.4
    /// method/pattern matching rules as `applies_to.endpoints`.
    pub fn ifc_tags_for_endpoint(&self, method: &str, uri: &str) -> crate::ifc::TagSet {
        let matched = self.best_ifc_endpoint_resource(method, uri);
        self.resolve_resource_field(
            matched.and_then(|e| e.tags.as_deref()),
            None,
            crate::ifc::TagSet::EMPTY,
        )
    }

    pub fn ifc_clearance_for_endpoint(&self, method: &str, uri: &str) -> crate::ifc::TagSet {
        let matched = self.best_ifc_endpoint_resource(method, uri);
        self.resolve_resource_field(
            matched.and_then(|e| e.clearance.as_deref()),
            None,
            self.ifc.default_clearance,
        )
    }

    pub fn ifc_audience_for_endpoint(&self, method: &str, uri: &str) -> crate::ifc::TagSet {
        let matched = self.best_ifc_endpoint_resource(method, uri);
        self.resolve_resource_field(
            matched.and_then(|e| e.audience.as_deref()),
            None,
            self.ifc.default_audience,
        )
    }

    pub fn ifc_has_endpoint_resource(&self, method: &str, uri: &str) -> bool {
        self.ifc.is_disabled() || self.best_ifc_endpoint_resource(method, uri).is_some()
    }

    pub fn ifc_tags_for_agent(&self, agent: &str) -> crate::ifc::TagSet {
        self.resolve_resource_field(
            self.resources
                .agents
                .iter()
                .find(|a| a.name == agent)
                .and_then(|a| a.tags.as_deref()),
            self.resources
                .agents
                .iter()
                .find(|a| a.name == "*")
                .and_then(|a| a.tags.as_deref()),
            crate::ifc::TagSet::EMPTY,
        )
    }

    pub fn ifc_clearance_for_agent(&self, agent: &str) -> crate::ifc::TagSet {
        self.resolve_resource_field(
            self.resources
                .agents
                .iter()
                .find(|a| a.name == agent)
                .and_then(|a| a.clearance.as_deref()),
            self.resources
                .agents
                .iter()
                .find(|a| a.name == "*")
                .and_then(|a| a.clearance.as_deref()),
            self.ifc.default_clearance,
        )
    }

    pub fn ifc_audience_for_agent(&self, agent: &str) -> crate::ifc::TagSet {
        self.resolve_resource_field(
            self.resources
                .agents
                .iter()
                .find(|a| a.name == agent)
                .and_then(|a| a.audience.as_deref()),
            self.resources
                .agents
                .iter()
                .find(|a| a.name == "*")
                .and_then(|a| a.audience.as_deref()),
            self.ifc.default_audience,
        )
    }

    pub fn ifc_has_agent_resource(&self, agent: &str) -> bool {
        self.ifc.is_disabled()
            || self
                .resources
                .agents
                .iter()
                .any(|a| a.name == agent || a.name == "*")
    }

    fn best_ifc_endpoint_resource(&self, method: &str, uri: &str) -> Option<&EndpointResource> {
        self.resources
            .endpoints
            .iter()
            .enumerate()
            .filter(|(_, e)| endpoint_resource_matches(e, method, uri))
            .max_by_key(|(idx, e)| {
                (
                    endpoint_pattern_mode(&e.pattern),
                    endpoint_specificity(&e.pattern),
                    endpoint_method_specificity(&e.methods),
                    -(*idx as i64),
                )
            })
            .map(|(_, e)| e)
    }

    /// Resolve a resource's tag-list field with wildcard fallback and
    /// global default. The field has already been validated against
    /// the universe at load time (see `merge_chain`), so this never
    /// fails — unknown tags would have been rejected already.
    fn resolve_resource_field(
        &self,
        named: Option<&[String]>,
        wildcard: Option<&[String]>,
        default: crate::ifc::TagSet,
    ) -> crate::ifc::TagSet {
        let names = named.or(wildcard);
        match names {
            None => default,
            Some(n) => self
                .ifc
                .universe
                .resolve(n, SourceLoc::default(), "<runtime>")
                .unwrap_or(default),
        }
    }
}

fn endpoint_resource_matches(e: &EndpointResource, method: &str, uri: &str) -> bool {
    methods_match(&e.methods, method) && pattern_matches_uri(&e.pattern, uri)
}

/// §13.4 pattern mode (exact > parameterized > glob).
fn endpoint_pattern_mode(pattern: &str) -> u8 {
    if pattern.contains("**") {
        0
    } else if pattern.contains('{') && pattern.contains('}') {
        1
    } else {
        2
    }
}

/// §13.4 specificity = literal segments - parameter segments.
fn endpoint_specificity(pattern: &str) -> i32 {
    let mut literals = 0i32;
    let mut params = 0i32;
    for seg in pattern.trim_start_matches('/').split('/') {
        if seg == "**" {
            // glob is handled by the mode bucket
        } else if seg.starts_with('{') && seg.ends_with('}') {
            params += 1;
        } else if !seg.is_empty() {
            literals += 1;
        }
    }
    literals - params
}

/// §13.4 method-exact wins over a pure `["*"]` matcher.
fn endpoint_method_specificity(methods: &[String]) -> u8 {
    if methods.iter().any(|m| m == "*") && methods.len() == 1 {
        0
    } else {
        1
    }
}

/// Merge an ordered list of parsed files (parents first, leaf last) into a
/// `MergedConfig` using merge-and-flatten semantics.
pub fn merge_chain(files: Vec<ParsedFile>) -> std::result::Result<MergedConfig, ConfigError> {
    if files.is_empty() {
        return Err(ConfigError::Schema {
            loc: SourceLoc::default(),
            message: "merge_chain: at least one file required".into(),
        });
    }

    // ── agent_shield_version (§4.2) ────────────────────────────────────
    let declared: Vec<(AgentShieldVersion, SourceLoc)> = files
        .iter()
        .filter_map(|f| {
            f.agent_shield_version
                .clone()
                .map(|v| (v, SourceLoc::from_path(f.path.clone())))
        })
        .collect();
    let effective = most_restrictive(&declared)?;

    let mut merged = MergedConfig {
        effective_agent_shield_version: effective.map(|(v, _)| v),
        ..MergedConfig::default()
    };

    // ── metadata: leaf-wins for identity fields. ──────────────────────
    let leaf = files.last().unwrap();
    merged.metadata = Metadata {
        name: leaf.metadata.name.clone(),
        version: leaf.metadata.version.clone(),
        description: leaf.metadata.description.clone(),
        agent_shield_version: merged.effective_agent_shield_version.clone(),
    };

    // ── objective: concat-by-tier with attribution. ───────────────────
    for f in &files {
        if let Some(tier) = &f.objective_tier {
            merged.objective.tiers.push(tier.clone());
        }
    }

    // ── configurations: same-`id` last-wins per field; type must match.
    let mut cfg_idx: std::collections::HashMap<String, usize> = std::collections::HashMap::new();
    for f in &files {
        for c in &f.configurations {
            if let Some(&existing_idx) = cfg_idx.get(&c.id) {
                let existing = &merged.configurations[existing_idx];
                if existing.config_type != c.config_type {
                    return Err(ConfigError::InvalidConfiguration {
                        loc: SourceLoc::from_path(f.path.clone()),
                        id: c.id.clone(),
                        message: format!(
                            "type changed across files: {} → {} (§6.7)",
                            existing.config_type.as_str(),
                            c.config_type.as_str()
                        ),
                    });
                }
                merged.configurations[existing_idx] =
                    merge_configuration(existing.clone(), c.clone());
            } else {
                let idx = merged.configurations.len();
                cfg_idx.insert(c.id.clone(), idx);
                merged.configurations.push(c.clone());
            }
        }
    }

    // §6.2: at most one default per type (llm + classifier only).
    enforce_default_uniqueness(&merged.configurations)?;

    // ── predicates: concat; same-name redefinition is a load-time error.
    for f in &files {
        for (name, body) in &f.predicates {
            if let Some(existing) = merged.predicates.entries.get(name) {
                return Err(ConfigError::PredicateRedefinition {
                    name: name.clone(),
                    origin: existing.origin.clone(),
                    leaf: f.path.clone(),
                });
            }
            merged.predicates.entries.insert(
                name.clone(),
                crate::predicates::PredicateEntry {
                    body: body.clone(),
                    origin: f.path.clone(),
                },
            );
        }
    }

    // ── variables: additive concat; same-name redefinition is a load-time error
    // (§10.9/§11.13 — variables are unique by name; merge follows the predicate model).
    let mut var_origin: std::collections::HashMap<String, PathBuf> =
        std::collections::HashMap::new();
    for f in &files {
        for v in &f.variables {
            if let Some(first) = var_origin.get(&v.name) {
                return Err(ConfigError::DuplicateVariable {
                    name: v.name.clone(),
                    first_file: first.clone(),
                    second_file: f.path.clone(),
                });
            }
            var_origin.insert(v.name.clone(), f.path.clone());
            merged.variables.push(v.clone());
        }
    }

    // ── resources: additive concat; description last-wins on same identity.
    for f in &files {
        merge_resources(&mut merged.resources, &f.resources);
    }

    // ── stages ───────────────────────────────────────────────────────
    merged.input_validation.guard_policies = merge_stage_policies(
        &files,
        |f| &f.input_validation,
        &files.iter().map(|f| f.path.clone()).collect::<Vec<_>>(),
    )?;
    merged.state_validation.guard_policies = merge_stage_policies(
        &files,
        |f| &f.state_validation,
        &files.iter().map(|f| f.path.clone()).collect::<Vec<_>>(),
    )?;
    merged.tool_execution_validation.guard_policies = merge_stage_policies(
        &files,
        |f| &f.tool_execution_validation,
        &files.iter().map(|f| f.path.clone()).collect::<Vec<_>>(),
    )?;
    merged.post_tool_validation.guard_policies = merge_stage_policies(
        &files,
        |f| &f.post_tool_validation,
        &files.iter().map(|f| f.path.clone()).collect::<Vec<_>>(),
    )?;
    merged.output_validation.guard_policies = merge_stage_policies(
        &files,
        |f| &f.output_validation,
        &files.iter().map(|f| f.path.clone()).collect::<Vec<_>>(),
    )?;

    // ── ifc: compile the leaf-only spec. Only one file in the
    // extends-chain may declare an `ifc:` block. If multiple files
    // do, we reject at load time so the lattice can't silently
    // change underneath an extending file (would break the trusted
    // base for `λ`).
    let ifc_specs: Vec<(crate::ifc::IfcSpec, SourceLoc)> = files
        .iter()
        .filter_map(|f| {
            f.ifc
                .clone()
                .map(|s| (s, SourceLoc::from_path(f.path.clone())))
        })
        .collect();
    if ifc_specs.len() > 1 {
        let paths: Vec<String> = ifc_specs
            .iter()
            .map(|(_, loc)| {
                loc.path
                    .clone()
                    .map(|p| p.display().to_string())
                    .unwrap_or_else(|| "<unknown>".into())
            })
            .collect();
        return Err(ConfigError::Schema {
            loc: ifc_specs[0].1.clone(),
            message: format!(
                "ifc: only one file in the extends-chain may declare an `ifc:` block; \
                 found in {paths:?}"
            ),
        });
    }
    if let Some((spec, loc)) = ifc_specs.into_iter().next() {
        merged.ifc = crate::ifc::CompiledIfc::from_spec(spec, loc.clone())?;

        // Validate every resource's tags / clearance / audience
        // against the tag universe and enforce TC-8 (μ ⊆ ν) and
        // TC-9 (λ ⊆ ν) at load time.
        for tool in &merged.resources.tools {
            let path = format!("resources.tools[name={}]", tool.name);
            let tags = merged.ifc.resolve_resource_tags(
                tool.tags.as_deref(),
                loc.clone(),
                &format!("{path}.tags"),
            )?;
            let clearance = merged.ifc.resolve_resource_clearance(
                tool.clearance.as_deref(),
                loc.clone(),
                &format!("{path}.clearance"),
            )?;
            let audience = merged.ifc.resolve_resource_audience(
                tool.audience.as_deref(),
                loc.clone(),
                &format!("{path}.audience"),
            )?;
            enforce_audience_compat(&path, tags, clearance, audience, &merged.ifc, loc.clone())?;
        }
        for ep in &merged.resources.endpoints {
            let path = format!("resources.endpoints[pattern={}]", ep.pattern);
            let tags = merged.ifc.resolve_resource_tags(
                ep.tags.as_deref(),
                loc.clone(),
                &format!("{path}.tags"),
            )?;
            let clearance = merged.ifc.resolve_resource_clearance(
                ep.clearance.as_deref(),
                loc.clone(),
                &format!("{path}.clearance"),
            )?;
            let audience = merged.ifc.resolve_resource_audience(
                ep.audience.as_deref(),
                loc.clone(),
                &format!("{path}.audience"),
            )?;
            enforce_audience_compat(&path, tags, clearance, audience, &merged.ifc, loc.clone())?;
        }
        for ag in &merged.resources.agents {
            let path = format!("resources.agents[name={}]", ag.name);
            let tags = merged.ifc.resolve_resource_tags(
                ag.tags.as_deref(),
                loc.clone(),
                &format!("{path}.tags"),
            )?;
            let clearance = merged.ifc.resolve_resource_clearance(
                ag.clearance.as_deref(),
                loc.clone(),
                &format!("{path}.clearance"),
            )?;
            let audience = merged.ifc.resolve_resource_audience(
                ag.audience.as_deref(),
                loc.clone(),
                &format!("{path}.audience"),
            )?;
            enforce_audience_compat(&path, tags, clearance, audience, &merged.ifc, loc.clone())?;
        }
    } else {
        // No `ifc:` block declared. Reject any resource that carries
        // `tags:` / `clearance:` / `audience:` so authors don't
        // silently get disabled IFC enforcement.
        for tool in &merged.resources.tools {
            if tool.tags.is_some() || tool.clearance.is_some() || tool.audience.is_some() {
                return Err(ConfigError::Schema {
                    loc: SourceLoc::default(),
                    message: format!(
                        "resources.tools[name={}]: `tags:`/`clearance:`/`audience:` declared \
                         but no top-level `ifc:` block — declare an `ifc.tags` universe first",
                        tool.name
                    ),
                });
            }
        }
        for ep in &merged.resources.endpoints {
            if ep.tags.is_some() || ep.clearance.is_some() || ep.audience.is_some() {
                return Err(ConfigError::Schema {
                    loc: SourceLoc::default(),
                    message: format!(
                        "resources.endpoints[pattern={}]: `tags:`/`clearance:`/`audience:` \
                         declared but no top-level `ifc:` block",
                        ep.pattern
                    ),
                });
            }
        }
        for ag in &merged.resources.agents {
            if ag.tags.is_some() || ag.clearance.is_some() || ag.audience.is_some() {
                return Err(ConfigError::Schema {
                    loc: SourceLoc::default(),
                    message: format!(
                        "resources.agents[name={}]: `tags:`/`clearance:`/`audience:` declared \
                         but no top-level `ifc:` block",
                        ag.name
                    ),
                });
            }
        }
    }

    Ok(merged)
}

/// Enforce TC-8 (μ ⊆ ν, sink cannot accept data its audience can't
/// see) and TC-9 (λ ⊆ ν, source cannot return / side-effect data its
/// audience can't see). See `docs/information-flow-control-proof.md`
/// §3.6 for the formal statement.
fn enforce_audience_compat(
    path: &str,
    tags: crate::ifc::TagSet,
    clearance: crate::ifc::TagSet,
    audience: crate::ifc::TagSet,
    ifc: &crate::ifc::CompiledIfc,
    loc: SourceLoc,
) -> std::result::Result<(), ConfigError> {
    if !clearance.is_subset(audience) {
        return Err(ConfigError::Schema {
            loc: loc.clone(),
            message: format!(
                "{path}: TC-8 violation: clearance {:?} ⊄ audience {:?}. A sink cannot \
                 accept data tagged at a level its audience is not cleared to see.",
                ifc.universe.names_of(clearance),
                ifc.universe.names_of(audience),
            ),
        });
    }
    if !tags.is_subset(audience) {
        return Err(ConfigError::Schema {
            loc,
            message: format!(
                "{path}: TC-9 violation: tags {:?} ⊄ audience {:?}. A source cannot \
                 return data (or have side-effects) tagged at a level its audience is \
                 not cleared to see.",
                ifc.universe.names_of(tags),
                ifc.universe.names_of(audience),
            ),
        });
    }
    Ok(())
}

fn merge_configuration(
    parent: ShieldConfiguration,
    child: ShieldConfiguration,
) -> ShieldConfiguration {
    macro_rules! pick {
        ($field:ident) => {
            child.$field.or(parent.$field)
        };
    }
    ShieldConfiguration {
        id: parent.id,
        config_type: parent.config_type,
        default: pick!(default),
        provider: pick!(provider),
        provider_config: pick!(provider_config),
        endpoint: pick!(endpoint),
        timeout: pick!(timeout),
        on_error: pick!(on_error),
        on_error_log: pick!(on_error_log),
        headers: {
            let mut merged = parent.headers;
            for (k, v) in child.headers {
                merged.insert(k, v);
            }
            merged
        },
        model: pick!(model),
        max_tokens: pick!(max_tokens),
        api_key_env: pick!(api_key_env),
        metadata: pick!(metadata),
        threshold: pick!(threshold),
        method: pick!(method),
        category_thresholds: {
            let mut merged = parent.category_thresholds;
            for (k, v) in child.category_thresholds {
                merged.insert(k, v);
            }
            merged
        },
        agent_id: pick!(agent_id),
        tool: pick!(tool),
    }
}

fn enforce_default_uniqueness(
    configs: &[ShieldConfiguration],
) -> std::result::Result<(), ConfigError> {
    let mut seen = std::collections::HashMap::<&str, &str>::new();
    for c in configs {
        if c.default == Some(true) {
            let kind = c.config_type.as_str();
            if let Some(prev) = seen.insert(kind, c.id.as_str()) {
                return Err(ConfigError::InvalidConfiguration {
                    loc: SourceLoc::default(),
                    id: c.id.clone(),
                    message: format!(
                        "two `default: true` entries of type `{}`: `{}` and `{}` (§6.2)",
                        kind, prev, c.id
                    ),
                });
            }
        }
    }
    Ok(())
}

fn merge_resources(into: &mut ResourcesBlock, from: &ResourcesBlock) {
    for t in &from.tools {
        if let Some(existing) = into.tools.iter_mut().find(|e| e.name == t.name) {
            merge_tool_resource(existing, t);
        } else {
            into.tools.push(t.clone());
        }
    }
    for e in &from.endpoints {
        if let Some(existing) = into
            .endpoints
            .iter_mut()
            .find(|x| x.pattern == e.pattern && x.methods == e.methods)
        {
            if e.description.is_some() {
                existing.description = e.description.clone();
            }
            if e.on_error.is_some() {
                existing.on_error = e.on_error;
            }
            if e.on_error_log.is_some() {
                existing.on_error_log = e.on_error_log.clone();
            }
        } else {
            into.endpoints.push(e.clone());
        }
    }
    for a in &from.agents {
        if let Some(existing) = into.agents.iter_mut().find(|e| e.name == a.name) {
            merge_agent_resource(existing, a);
        } else {
            into.agents.push(a.clone());
        }
    }
}

fn merge_tool_resource(into: &mut ToolResource, from: &ToolResource) {
    if from.description.is_some() {
        into.description = from.description.clone();
    }
    if from.permission.is_some() {
        into.permission = from.permission;
    }
    if from.protocol.is_some() {
        into.protocol = from.protocol.clone();
    }
    if from.on_error.is_some() {
        into.on_error = from.on_error;
    }
    if from.on_error_log.is_some() {
        into.on_error_log = from.on_error_log.clone();
    }
}

fn merge_agent_resource(into: &mut AgentResource, from: &AgentResource) {
    if from.description.is_some() {
        into.description = from.description.clone();
    }
    if from.on_error.is_some() {
        into.on_error = from.on_error;
    }
    if from.on_error_log.is_some() {
        into.on_error_log = from.on_error_log.clone();
    }
}

fn merge_stage_policies<F>(
    files: &[ParsedFile],
    pick: F,
    paths: &[PathBuf],
) -> std::result::Result<Vec<GuardPolicy>, ConfigError>
where
    F: Fn(&ParsedFile) -> &Vec<GuardPolicy>,
{
    let mut merged: Vec<GuardPolicy> = Vec::new();
    let mut name_idx: std::collections::HashMap<String, usize> = std::collections::HashMap::new();
    let mut origin: std::collections::HashMap<String, PathBuf> = std::collections::HashMap::new();

    for (file_idx, f) in files.iter().enumerate() {
        for gp in pick(f) {
            if let Some(&i) = name_idx.get(&gp.name) {
                let parent = &mut merged[i];
                merge_guard_policy(parent, gp).map_err(|msg| ConfigError::Schema {
                    loc: SourceLoc::from_path(paths[file_idx].clone()),
                    message: msg,
                })?;
                if parent_set_active_if_then_child_redefines(parent, gp) {
                    return Err(ConfigError::GuardPolicyActiveIfImmutable {
                        name: gp.name.clone(),
                        origin: origin
                            .get(&gp.name)
                            .cloned()
                            .unwrap_or_else(|| paths[file_idx].clone()),
                        leaf: paths[file_idx].clone(),
                    });
                }
            } else {
                let i = merged.len();
                name_idx.insert(gp.name.clone(), i);
                origin.insert(gp.name.clone(), paths[file_idx].clone());
                merged.push(gp.clone());
            }
        }
    }
    Ok(merged)
}

fn parent_set_active_if_then_child_redefines(parent: &GuardPolicy, child: &GuardPolicy) -> bool {
    matches!((parent.active_if.as_deref(), child.active_if.as_deref()),
        (Some(p), Some(c)) if p != c)
}

fn merge_guard_policy(
    parent: &mut GuardPolicy,
    child: &GuardPolicy,
) -> std::result::Result<(), String> {
    if parent.active_if.is_none() {
        if let Some(c) = &child.active_if {
            parent.active_if = Some(c.clone());
        }
    } else if let Some(c) = &child.active_if {
        if Some(c) != parent.active_if.as_ref() {
            return Err(format!(
                "guard policy `{}`: child redefines parent's `active_if` (§12.12 — parent-immutable)",
                parent.name
            ));
        }
    }

    if child.description.is_some() {
        parent.description = child.description.clone();
    }

    // applies_to: concat + dedup on each list.
    match (&mut parent.applies_to, &child.applies_to) {
        (Some(p), Some(c)) => {
            extend_dedup(&mut p.tools, &c.tools);
            extend_dedup(&mut p.agents, &c.agents);
            for ep in &c.endpoints {
                if !p
                    .endpoints
                    .iter()
                    .any(|e| e.pattern == ep.pattern && e.methods == ep.methods)
                {
                    p.endpoints.push(ep.clone());
                }
            }
        }
        (None, Some(c)) => parent.applies_to = Some(c.clone()),
        _ => {}
    }

    // evaluate_when: concat in declaration order.
    parent
        .evaluate_when
        .extend(child.evaluate_when.iter().cloned());

    // allowed_when: AND-merge. Most-restrictive.
    parent.allowed_when = match (&parent.allowed_when, &child.allowed_when) {
        (Some(p), Some(c)) => Some(format!("({}) and ({})", p, c)),
        (Some(p), None) => Some(p.clone()),
        (None, Some(c)) => Some(c.clone()),
        (None, None) => None,
    };

    if child.action.is_some() {
        parent.action = child.action;
    }
    if child.reason.is_some() {
        parent.reason = child.reason.clone();
    }
    if child.replacement.is_some() {
        parent.replacement = child.replacement.clone();
    }

    parent.log = match (&parent.log, &child.log) {
        (Some(p), Some(c)) => Some(LogBlock {
            severity: c.severity.clone().or_else(|| p.severity.clone()),
            category: c.category.clone().or_else(|| p.category.clone()),
            message: c.message.clone().or_else(|| p.message.clone()),
        }),
        (None, Some(c)) => Some(c.clone()),
        (p, None) => p.clone(),
    };

    Ok(())
}

fn extend_dedup(into: &mut Vec<String>, from: &[String]) {
    for x in from {
        if !into.iter().any(|y| y == x) {
            into.push(x.clone());
        }
    }
}

/// Env-var name read by [`apply_env_mode_override`] (#14).
pub const ENV_MODE_VAR: &str = "AGENT_SHIELD_MODE";

/// Apply the `AGENT_SHIELD_MODE` env-var override to `merged.mode`
/// (#14). Env > YAML > `Active` default. Unknown values are a
/// load-time error. Called from every loader entry point.
pub fn apply_env_mode_override(merged: &mut MergedConfig) -> std::result::Result<(), ConfigError> {
    apply_env_mode_override_from(merged, |k| std::env::var(k).ok())
}

/// Test-friendly variant: reads via a caller-supplied function.
pub fn apply_env_mode_override_from<F>(
    merged: &mut MergedConfig,
    read_env: F,
) -> std::result::Result<(), ConfigError>
where
    F: Fn(&str) -> Option<String>,
{
    let Some(raw) = read_env(ENV_MODE_VAR) else {
        return Ok(());
    };
    let trimmed = raw.trim();
    if trimmed.is_empty() {
        return Ok(());
    }
    match RuntimeMode::from_wire_str(trimmed) {
        Some(m) => {
            merged.mode = m;
            Ok(())
        }
        None => Err(ConfigError::Schema {
            loc: SourceLoc::default(),
            message: format!(
                "{ENV_MODE_VAR}={raw:?}: unknown runtime mode (expected `active` or `shadow`)"
            ),
        }),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::guard_policy::{DetectionKind, EvaluateWhenEntry};

    fn mk_meta(name: &str) -> Metadata {
        Metadata {
            name: name.into(),
            version: "0.1.0".into(),
            description: None,
            agent_shield_version: None,
        }
    }

    fn mk_file(path: &str, metadata: Metadata) -> ParsedFile {
        ParsedFile {
            path: PathBuf::from(path),
            metadata,
            objective_tier: None,
            configurations: vec![],
            predicates: BTreeMap::new(),
            variables: vec![],
            resources: ResourcesBlock::default(),
            input_validation: vec![],
            state_validation: vec![],
            tool_execution_validation: vec![],
            post_tool_validation: vec![],
            output_validation: vec![],
            agent_shield_version: None,
            ifc: None,
        }
    }

    #[test]
    fn allowed_when_and_merges() {
        let mut parent = GuardPolicy {
            name: "g".into(),
            description: None,
            applies_to: None,
            active_if: None,
            evaluate_when: vec![],
            allowed_when: Some("a == 1".into()),
            action: None,
            reason: None,
            replacement: None,
            log: None,
        };
        let child = GuardPolicy {
            name: "g".into(),
            description: None,
            applies_to: None,
            active_if: None,
            evaluate_when: vec![],
            allowed_when: Some("b == 2".into()),
            action: None,
            reason: None,
            replacement: None,
            log: None,
        };
        merge_guard_policy(&mut parent, &child).unwrap();
        assert_eq!(parent.allowed_when.unwrap(), "(a == 1) and (b == 2)");
    }

    #[test]
    fn child_cannot_redefine_active_if() {
        let mut parent = GuardPolicy {
            name: "g".into(),
            description: None,
            applies_to: None,
            active_if: Some("x".into()),
            evaluate_when: vec![],
            allowed_when: None,
            action: None,
            reason: None,
            replacement: None,
            log: None,
        };
        let child = GuardPolicy {
            name: "g".into(),
            description: None,
            applies_to: None,
            active_if: Some("y".into()),
            evaluate_when: vec![],
            allowed_when: None,
            action: None,
            reason: None,
            replacement: None,
            log: None,
        };
        let err = merge_guard_policy(&mut parent, &child).unwrap_err();
        assert!(err.contains("active_if"));
    }

    #[test]
    fn evaluate_when_concat_in_order() {
        let mut parent = GuardPolicy {
            name: "g".into(),
            description: None,
            applies_to: None,
            active_if: None,
            evaluate_when: vec![EvaluateWhenEntry {
                detection: DetectionKind::Expression("a".into()),
                reason: "p".into(),
                action: None,
                replacement: None,
                text: None,
                paths: vec![],
                log: None,
            }],
            allowed_when: None,
            action: None,
            reason: None,
            replacement: None,
            log: None,
        };
        let child = GuardPolicy {
            name: "g".into(),
            description: None,
            applies_to: None,
            active_if: None,
            evaluate_when: vec![EvaluateWhenEntry {
                detection: DetectionKind::Expression("b".into()),
                reason: "c".into(),
                action: None,
                replacement: None,
                text: None,
                paths: vec![],
                log: None,
            }],
            allowed_when: None,
            action: None,
            reason: None,
            replacement: None,
            log: None,
        };
        merge_guard_policy(&mut parent, &child).unwrap();
        assert_eq!(parent.evaluate_when.len(), 2);
    }

    #[test]
    fn merge_chain_preserves_objective_attribution() {
        let mut p = mk_file("parent.yaml", mk_meta("parent"));
        p.objective_tier = Some(ObjectiveTier {
            source: "parent".into(),
            goal: vec!["a".into()],
            forbidden: vec![],
        });
        let mut l = mk_file("leaf.yaml", mk_meta("leaf"));
        l.objective_tier = Some(ObjectiveTier {
            source: "leaf".into(),
            goal: vec!["b".into()],
            forbidden: vec!["x".into()],
        });
        let merged = merge_chain(vec![p, l]).unwrap();
        assert_eq!(merged.objective.tiers.len(), 2);
        assert_eq!(merged.objective.tiers[0].source, "parent");
        assert_eq!(merged.objective.tiers[1].source, "leaf");
        assert_eq!(merged.metadata.name, "leaf");
    }

    // ── Runtime mode (#14) ────────────────────────────────────────────

    fn meta(name: &str) -> Metadata {
        Metadata {
            name: name.into(),
            version: "0.1.0".into(),
            description: None,
            agent_shield_version: None,
        }
    }

    fn mk_default_merged() -> MergedConfig {
        merge_chain(vec![mk_file("leaf", meta("leaf"))]).unwrap()
    }

    #[test]
    fn mode_defaults_to_active_when_nothing_overrides() {
        // No YAML mode field anymore; default is Active. Hosts override
        // via `RuntimeBuilder::with_mode` or `AGENT_SHIELD_MODE` env.
        let merged = mk_default_merged();
        assert_eq!(merged.mode, RuntimeMode::Active);
    }

    #[test]
    fn env_override_sets_shadow_when_var_present() {
        let mut merged = mk_default_merged();
        apply_env_mode_override_from(&mut merged, |k| {
            if k == ENV_MODE_VAR {
                Some("shadow".to_string())
            } else {
                None
            }
        })
        .unwrap();
        assert_eq!(merged.mode, RuntimeMode::Shadow);
    }

    #[test]
    fn env_override_is_no_op_when_unset() {
        let mut merged = mk_default_merged();
        merged.mode = RuntimeMode::Shadow;
        apply_env_mode_override_from(&mut merged, |_| None).unwrap();
        assert_eq!(merged.mode, RuntimeMode::Shadow);
    }

    #[test]
    fn env_override_rejects_unknown_value() {
        let mut merged = mk_default_merged();
        let err = apply_env_mode_override_from(&mut merged, |k| {
            if k == ENV_MODE_VAR {
                Some("disabled".to_string())
            } else {
                None
            }
        })
        .unwrap_err();
        let msg = format!("{err}");
        assert!(msg.contains("AGENT_SHIELD_MODE"), "msg was {msg}");
        assert!(msg.contains("disabled"), "msg was {msg}");
    }

    #[test]
    fn env_override_accepts_case_insensitive_values() {
        for raw in [
            "shadow", "SHADOW", "Shadow", "sHaDoW", " shadow ", "active", "aCtIvE",
        ] {
            let mut merged = mk_default_merged();
            apply_env_mode_override_from(&mut merged, |k| {
                if k == ENV_MODE_VAR {
                    Some(raw.to_string())
                } else {
                    None
                }
            })
            .unwrap_or_else(|e| panic!("rejected {raw:?}: {e}"));
        }
    }

    #[test]
    fn env_empty_string_is_no_op() {
        let mut merged = mk_default_merged();
        merged.mode = RuntimeMode::Shadow;
        apply_env_mode_override_from(&mut merged, |k| {
            if k == ENV_MODE_VAR {
                Some("".to_string())
            } else {
                None
            }
        })
        .unwrap();
        assert_eq!(merged.mode, RuntimeMode::Shadow);
    }
}
