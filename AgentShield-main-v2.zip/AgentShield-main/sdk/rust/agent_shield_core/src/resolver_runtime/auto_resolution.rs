//! Auto-resolution bridge from [`crate::expressions::eval::ResolverHook`]
//! to the [`super::ResolverDispatcher`] (§11.5).
//!
//! The expression evaluator calls `ResolverHook::resolve(var)` exactly once
//! per gating-site read of an unset variable. The adapter built here:
//!
//! 1. Looks up the variable's `on_demand_by:` resolver in the registry
//!    snapshot.
//! 2. Runs the chain through the dispatcher.
//! 3. Returns `Some(value)` on `Allow`, `None` on `Deny` / `Cancelled` /
//!    `Suspended`.
//!
//! ## Same-evaluation determinism (§11.5)
//!
//! The adapter caches per-`(adapter instance)` resolver outcomes by
//! variable name so repeated reads inside one expression evaluation see
//! the same value. The cache lives only as long as the adapter — callers
//! build a fresh adapter for each top-level evaluation of a gating
//! expression.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

use serde_json::Value;

use crate::expressions::eval::ResolverHook;
use crate::populator::Invocation;
use crate::session_id::SessionId;

use super::context::{GatedResourceRef, ResolverContext};
use super::{PendingResolution, ResolverDispatcher};

/// Outcome of [`ResolverDispatcher::auto_resolve_with_pending`]. Carries
/// the resolved value (when the chain succeeded) and an optional
/// [`PendingResolution`] (when a `kind: tool` / `kind: human` resolver
/// suspended waiting on the agent).
#[derive(Debug, Default, Clone)]
pub struct AutoResolveOutcome {
    pub value: Option<Value>,
    pub pending: Option<PendingResolution>,
}

/// Trace callback for [`AutoResolveAdapter`] — invoked after each
/// per-variable dispatch with the variable name and the resolved value.
type TraceFn = dyn Fn(&str, &Option<Value>) + Send + Sync;

/// Adapter that satisfies [`ResolverHook`] by routing into the dispatcher.
///
/// The adapter is single-use (one per top-level expression evaluation).
/// Building a new adapter per evaluation is cheap because all the
/// expensive state (registry, configurations, hooks) lives on the
/// dispatcher itself, which the adapter only borrows.
///
/// Per §11.5 / §11.4a, host resolvers fired from an expression's
/// auto-resolution path observe the SAME [`ResolverContext`] as the
/// gating expression — so `request_id`, `reason`, `resource`,
/// `request_context`, and any active `invocation` propagate. The
/// adapter stores an owned snapshot of these fields and rebuilds a fresh
/// `ResolverContext` on each `resolve` call.
pub struct AutoResolveAdapter<'a> {
    dispatcher: &'a ResolverDispatcher,
    base_attrs: HashMap<String, Value>,
    request_context: serde_json::Map<String, Value>,
    reason: Option<String>,
    resource: Option<GatedResourceRef>,
    request_id: Option<String>,
    /// Session that owns the gating evaluation. Threaded into
    /// [`ResolverContext::session_id`] on every rebuild so dispatcher
    /// writes back to tracker/bus state in the correct session.
    session_id: Option<SessionId>,
    /// Owned clone of the active invocation, when the gate is invocation-
    /// bound. We borrow this back into the rebuilt `ResolverContext` on
    /// each `resolve` call.
    invocation: Option<Invocation>,
    cache: Mutex<HashMap<String, Option<Value>>>,
    /// Captured pending resolution. Populated from the dispatcher when a
    /// `kind: tool` / `kind: human` resolver suspended waiting on the
    /// agent. Per-stage runners read this after `block_verdict` to
    /// attach it to [`crate::guard_policy_runtime::StageVerdict::pending_resolution`].
    pending: Mutex<Option<PendingResolution>>,
    on_resolve: Option<Arc<TraceFn>>,
}

impl<'a> AutoResolveAdapter<'a> {
    /// Attribute-only constructor. Prefer [`Self::from_context`] when a
    /// real [`ResolverContext`] is available — passing only `base_attrs`
    /// drops `request_id`, `reason`, `resource`, `request_context`, and
    /// any active `invocation`, which means host resolvers cannot
    /// interpolate `${tool.*}` / `${context.*}` in their prompts.
    pub fn new(dispatcher: &'a ResolverDispatcher, base_attrs: HashMap<String, Value>) -> Self {
        Self {
            dispatcher,
            base_attrs,
            request_context: serde_json::Map::new(),
            reason: None,
            resource: None,
            request_id: None,
            session_id: None,
            invocation: None,
            cache: Mutex::new(HashMap::new()),
            pending: Mutex::new(None),
            on_resolve: None,
        }
    }

    /// Session-scoped variant of [`Self::new`]. Threads the originating
    /// session id into auto-resolved [`ResolverContext`]s so the
    /// dispatcher's writebacks land on the correct session's
    /// [`crate::lifetime_tracker::LifetimeTracker`] /
    /// [`crate::event_bus::EventBus`] state.
    pub fn new_in(
        dispatcher: &'a ResolverDispatcher,
        base_attrs: HashMap<String, Value>,
        session_id: SessionId,
    ) -> Self {
        Self {
            dispatcher,
            base_attrs,
            request_context: serde_json::Map::new(),
            reason: None,
            resource: None,
            request_id: None,
            session_id: Some(session_id),
            invocation: None,
            cache: Mutex::new(HashMap::new()),
            pending: Mutex::new(None),
            on_resolve: None,
        }
    }

    /// Snapshot the full [`ResolverContext`] so host resolvers fired via
    /// auto-resolution see the same `request_id`, `reason`, `resource`,
    /// `request_context`, and `invocation` as the originating gate.
    pub fn from_context(dispatcher: &'a ResolverDispatcher, ctx: &ResolverContext<'_>) -> Self {
        Self {
            dispatcher,
            base_attrs: ctx.attrs.clone(),
            request_context: ctx.request_context.clone(),
            reason: ctx.reason.clone(),
            resource: ctx.resource.clone(),
            request_id: ctx.request_id.clone(),
            session_id: ctx.session_id.clone(),
            invocation: ctx.invocation.cloned(),
            cache: Mutex::new(HashMap::new()),
            pending: Mutex::new(None),
            on_resolve: None,
        }
    }

    pub fn with_trace<F>(mut self, f: F) -> Self
    where
        F: Fn(&str, &Option<Value>) + Send + Sync + 'static,
    {
        self.on_resolve = Some(Arc::new(f));
        self
    }

    /// Threads an active gating invocation into auto-resolution context.
    /// Stage runners call this so the dispatcher's `kind: human/agent/
    /// delegate` resolvers can populate `request.resource_name` and
    /// `request.resource_params` with the tool/agent/endpoint that
    /// triggered the variable read.
    pub fn with_invocation(mut self, inv: Invocation) -> Self {
        self.resource = Some(GatedResourceRef::new(
            inv.kind,
            inv.name.clone().unwrap_or_default(),
            inv.params.clone(),
        ));
        self.invocation = Some(inv);
        self
    }

    /// Take the most recently captured [`PendingResolution`], if any. The
    /// adapter only retains the **first** pending resolution per
    /// evaluation — subsequent suspended resolvers in the same stage are
    /// dropped because the host can only react to one tool-call hint at a
    /// time. Per-stage runners call this after a block verdict.
    pub fn take_pending(&self) -> Option<PendingResolution> {
        self.pending.lock().unwrap().take()
    }

    fn rebuild_context(&self) -> ResolverContext<'_> {
        let mut ctx = ResolverContext::default()
            .with_attrs(self.base_attrs.clone())
            .with_request_context(self.request_context.clone());
        if let Some(reason) = &self.reason {
            ctx = ctx.with_reason(reason.clone());
        }
        if let Some(resource) = &self.resource {
            ctx = ctx.with_resource(resource.clone());
        }
        if let Some(req_id) = &self.request_id {
            ctx = ctx.with_request_id(req_id.clone());
        }
        if let Some(sid) = &self.session_id {
            ctx = ctx.with_session_id(sid.clone());
        }
        if let Some(inv) = &self.invocation {
            ctx = ctx.with_invocation(inv);
        }
        ctx
    }
}

impl<'a> ResolverHook for AutoResolveAdapter<'a> {
    fn resolve(&self, var: &str) -> Option<Value> {
        if let Some(cached) = self.cache.lock().unwrap().get(var).cloned() {
            return cached;
        }
        let ctx = self.rebuild_context();
        let outcome = self.dispatcher.auto_resolve_with_pending(var, &ctx);
        if let Some(trace) = &self.on_resolve {
            trace(var, &outcome.value);
        }
        if let Some(pr) = outcome.pending {
            // Only retain the first pending; subsequent suspends in the
            // same evaluation are surfaced via the bus event.
            let mut slot = self.pending.lock().unwrap();
            if slot.is_none() {
                *slot = Some(pr);
            }
        }
        self.cache
            .lock()
            .unwrap()
            .insert(var.to_string(), outcome.value.clone());
        outcome.value
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::event_bus::EventBus;
    use crate::expressions::eval::{evaluate_with, EvalContext};
    use crate::lifetime_tracker::LifetimeTracker;
    use crate::observability::ObservabilityDispatcher;
    use crate::resolver_runtime::{ResolverDeps, ResolverDispatcher};
    use crate::variables::Variable;
    use serde_json::json;

    fn var_with_resolver(yaml: &str) -> Variable {
        let v: Variable = serde_yaml::from_str(yaml).unwrap();
        v
    }

    #[test]
    fn caches_per_evaluation() {
        let yaml = r#"
name: x
type: number
on_demand_by:
  kind: expression
  expression: "5 + 3"
"#;
        let v = var_with_resolver(yaml);

        let bus = EventBus::new();
        let mut registry = HashMap::new();
        registry.insert("x".to_string(), v);
        let tracker = LifetimeTracker::new(bus.clone(), registry.clone());
        let deps = ResolverDeps::new(
            bus.clone(),
            tracker,
            Arc::new(registry),
            Arc::new(HashMap::new()),
            crate::resolver_runtime::HumanRegistry::new(),
            super::super::tool_kind::DEFAULT_TOOL_RETRY_LIMIT,
            ObservabilityDispatcher::new(bus.clone()),
        );
        let dispatcher = ResolverDispatcher::new(deps);
        let adapter = AutoResolveAdapter::new(&dispatcher, HashMap::new());

        // First read.
        let v1 = adapter.resolve("x");
        assert_eq!(v1, Some(json!(8)));
        // Second read is cached.
        let v2 = adapter.resolve("x");
        assert_eq!(v2, v1);
    }

    #[test]
    fn deny_returns_none() {
        let yaml = r#"
name: x
type: boolean
on_demand_by:
  kind: expression
  expression: "false"
"#;
        let v = var_with_resolver(yaml);

        let bus = EventBus::new();
        let mut registry = HashMap::new();
        registry.insert("x".to_string(), v);
        let tracker = LifetimeTracker::new(bus.clone(), registry.clone());
        let deps = ResolverDeps::new(
            bus.clone(),
            tracker,
            Arc::new(registry),
            Arc::new(HashMap::new()),
            crate::resolver_runtime::HumanRegistry::new(),
            super::super::tool_kind::DEFAULT_TOOL_RETRY_LIMIT,
            ObservabilityDispatcher::new(bus.clone()),
        );
        let dispatcher = ResolverDispatcher::new(deps);
        let adapter = AutoResolveAdapter::new(&dispatcher, HashMap::new());
        assert_eq!(adapter.resolve("x"), None);
    }

    #[test]
    fn integrates_with_evaluator_at_gating_site() {
        // Variable y has an expression resolver that produces 12.
        // We evaluate `y > 10` at a gating site.
        let yaml = r#"
name: y
type: number
on_demand_by:
  kind: expression
  expression: "12"
"#;
        let v = var_with_resolver(yaml);

        let bus = EventBus::new();
        let mut registry = HashMap::new();
        registry.insert("y".to_string(), v);
        let tracker = LifetimeTracker::new(bus.clone(), registry.clone());
        let deps = ResolverDeps::new(
            bus.clone(),
            tracker,
            Arc::new(registry),
            Arc::new(HashMap::new()),
            crate::resolver_runtime::HumanRegistry::new(),
            super::super::tool_kind::DEFAULT_TOOL_RETRY_LIMIT,
            ObservabilityDispatcher::new(bus.clone()),
        );
        let dispatcher = ResolverDispatcher::new(deps);
        let attrs = HashMap::new(); // y is unset
        let adapter = AutoResolveAdapter::new(&dispatcher, attrs.clone());

        let mut ctx = EvalContext::from_attrs(&attrs);
        ctx.is_gating_site = true;
        ctx.resolver_hook = Some(&adapter);
        assert!(evaluate_with("y > 10", &ctx));
    }

    #[test]
    fn not_a_gating_site_does_not_auto_resolve() {
        let yaml = r#"
name: y
type: number
on_demand_by:
  kind: expression
  expression: "12"
"#;
        let v = var_with_resolver(yaml);

        let bus = EventBus::new();
        let mut registry = HashMap::new();
        registry.insert("y".to_string(), v);
        let tracker = LifetimeTracker::new(bus.clone(), registry.clone());
        let deps = ResolverDeps::new(
            bus.clone(),
            tracker,
            Arc::new(registry),
            Arc::new(HashMap::new()),
            crate::resolver_runtime::HumanRegistry::new(),
            super::super::tool_kind::DEFAULT_TOOL_RETRY_LIMIT,
            ObservabilityDispatcher::new(bus.clone()),
        );
        let dispatcher = ResolverDispatcher::new(deps);
        let attrs = HashMap::new();
        let adapter = AutoResolveAdapter::new(&dispatcher, attrs.clone());

        let mut ctx = EvalContext::from_attrs(&attrs);
        ctx.is_gating_site = false; // not a gating site
        ctx.resolver_hook = Some(&adapter);
        // y is unset and not auto-resolvable here; the comparison folds to false.
        assert!(!evaluate_with("y > 10", &ctx));
    }

    // P5.2: ResolverContext (request_id, reason, resource, request_context,
    // invocation) propagates through auto-resolution and is rendered into
    // the canonical `agent_shield.ask_human` tool-call signal.
    #[test]
    fn from_context_renders_canonical_pending_resolution() {
        use crate::populator::Invocation as PopInvocation;
        use crate::resolver_runtime::context::GatedResourceRef;
        use crate::resolver_runtime::tool_kind::ASK_HUMAN_TOOL_NAME;
        use crate::variables::ResourceKind;

        let yaml = r#"
name: send_authorized
type: boolean
on_demand_by:
  kind: human
  prompt: "Approve ${tool.name}?"
"#;
        let v = var_with_resolver(yaml);

        let bus = EventBus::new();
        let mut registry = HashMap::new();
        registry.insert("send_authorized".to_string(), v);
        let tracker = LifetimeTracker::new(bus.clone(), registry.clone());

        let deps = ResolverDeps::new(
            bus.clone(),
            tracker,
            Arc::new(registry),
            Arc::new(HashMap::new()),
            crate::resolver_runtime::HumanRegistry::new(),
            super::super::tool_kind::DEFAULT_TOOL_RETRY_LIMIT,
            ObservabilityDispatcher::new(bus.clone()),
        );
        let dispatcher = ResolverDispatcher::new(deps);

        let inv = PopInvocation {
            kind: ResourceKind::Tool,
            name: Some("send_email".into()),
            matched_resource_name: None,
            method: None,
            uri: None,
            path_params: HashMap::new(),
            query_params: HashMap::new(),
            params: json!({}),
        };

        let resource = GatedResourceRef::new(ResourceKind::Tool, "send_email", json!({}));

        let ctx = ResolverContext::default()
            .with_attrs(HashMap::new())
            .with_invocation(&inv)
            .with_resource(resource)
            .with_request_id("req-42")
            .with_reason("guard policy mail-protect");

        let adapter = AutoResolveAdapter::from_context(&dispatcher, &ctx);
        // Auto-resolution returns None because the resolver suspended;
        // the gate fails closed for this evaluation.
        assert_eq!(adapter.resolve("send_authorized"), None);

        let pending = adapter
            .take_pending()
            .expect("pending resolution should be captured for kind: human");
        assert_eq!(pending.tool, ASK_HUMAN_TOOL_NAME);
        assert_eq!(pending.variable, "send_authorized");
        assert_eq!(
            pending.prompt.as_deref(),
            Some("Approve send_email?"),
            "tool.name must interpolate from the propagated invocation"
        );
        assert_eq!(pending.request_id, "req-42");
        assert_eq!(pending.kind, "human");
    }
}
