//! Resolver runtime — dispatcher tree.
//!
//! The public entry point is [`ResolverDispatcher`]. Its responsibilities:
//!
//! 1. Accept a `ResolveRequest` describing one resolver invocation
//!    (variable-bound or inline).
//! 2. Walk the resolver chain via [`fallback::run_with_fallback`].
//! 3. Per-link, switch on `Resolver::*` and dispatch to the appropriate
//!    [`expression_kind`], [`human_kind`], [`delegate_kind`],
//!    [`agent_kind`], or [`tool_kind`] module.
//! 4. On a final `Allow`, write the resolver's `value:` to the target
//!    variable, then apply `set_variables:` and `on_allow:` (§11.3 +
//!    §11.4 ordering — see [`on_allow`]).
//! 5. Emit the `approval.<variable>.<outcome>` event for the chain's
//!    final non-`Allow` outcome too (§10.5 / §11.5 step 3).
//!
//! ## Auto-resolution bridge
//!
//! [`auto_resolution::AutoResolveAdapter`] wraps a `&ResolverDispatcher`
//! into an [`crate::expressions::eval::ResolverHook`]. The dispatcher's
//! [`ResolverDispatcher::auto_resolve`] does the per-variable lookup and
//! returns the resolver value on `Allow` or `None` on
//! `Deny`/`Cancelled`/`Suspended`.

use std::collections::HashMap;
use std::sync::Arc;

use serde_json::Value;

use super::configurations::ShieldConfiguration;
use super::event_bus::EventBus;
use super::events::ApprovalEventKind;
use super::lifetime_tracker::{LifetimeTracker, ResolverOutcome};
use super::observability::{emitter, ObservabilityDispatcher};
use super::resolver::{Resolver, ResolverDecision, ResolverResponse};
use super::variables::Variable;

pub mod agent_kind;
pub mod auto_resolution;
pub mod context;
pub mod delegate_kind;
pub mod errors;
pub mod expression_kind;
pub mod fallback;
pub mod human_kind;
pub mod invocation_manager;
pub mod on_allow;
pub mod tool_kind;

pub use agent_kind::{AgentResolveRequest, AgentResolver, AgentResolverFn};
pub use auto_resolution::{AutoResolveAdapter, AutoResolveOutcome};
pub use context::{interpolate_prompt, GatedResourceRef, InterpolationError, ResolverContext};
pub use delegate_kind::{
    classifier_bool_to_envelope, classifier_score_to_envelope, DelegateDispatcher,
    DelegateDispatcherFn, DelegateRequest,
};
pub use errors::ResolverRuntimeError;
pub use human_kind::{HumanRegistry, HumanResolveRequest, HumanResolver, HumanResolverFn};
pub use invocation_manager::{
    CancelReason, HostResolverBridge, InvocationCompletion, InvocationId, InvocationState,
    InvocationStats, InvocationTerminal, ResolverInvocationManager, ShutdownReason,
};
pub use tool_kind::{
    DispatchOutcome, ToolLoopTracker, ASK_HUMAN_TOOL_NAME, DEFAULT_TOOL_RETRY_LIMIT,
};

/// Side-channel description of a deny that was caused by a resolver
/// suspending while waiting for the agent to call a tool.
///
/// Surfaced on [`crate::guard_policy_runtime::StageVerdict::pending_resolution`]
/// so the host can read the deny verdict and tell the agent which tool
/// to call next, with which prompt, against which variable.
///
/// `kind: human` and `kind: tool` resolvers both produce this — they are
/// unified internally; the distinction lives in [`Self::kind`] for the
/// host's information only.
#[derive(Debug, Clone)]
pub struct PendingResolution {
    /// The MCP / agent-channel tool the agent is expected to call. For
    /// `kind: human` this is always [`ASK_HUMAN_TOOL_NAME`]; for
    /// `kind: tool` it is the resolver's `name:`.
    pub tool: String,
    /// Variable the resolver was bound to.
    pub variable: String,
    /// Interpolated prompt rendered from the resolver's `prompt:` (the
    /// `${...}` references already resolved against the gating-site
    /// context). `None` only for `kind: tool` resolvers that omitted
    /// `prompt:` entirely.
    pub prompt: Option<String>,
    /// Stable id matching the `incident.resolution_needed` event's
    /// `request_id` payload. Hosts can use this to correlate a deny
    /// verdict with a previously-observed bus event.
    pub request_id: String,
    /// Originating resolver kind: `"human"` or `"tool"`.
    pub kind: &'static str,
}

/// Outcome from [`ResolverDispatcher::resolve_with_pending`]. Carries
/// the wire envelope plus an optional [`PendingResolution`] when the
/// chain terminated because a resolver suspended.
#[derive(Debug, Clone)]
pub struct ResolveOutcome {
    pub response: ResolverResponse,
    pub pending: Option<PendingResolution>,
}

/// Dependencies threaded into the dispatcher. Built once at runtime
/// startup and held inside an Arc for cheap cloning across worker tasks.
///
/// `#[non_exhaustive]` reserves the right to add fields without breaking
/// downstream construction. New code SHOULD prefer [`Self::new`] +
/// `with_*` builder methods over struct-literal construction; the public
/// fields are kept for backward source-compat with existing internal call
/// sites and for read-only access via field projection.
#[non_exhaustive]
pub struct ResolverDeps {
    pub event_bus: EventBus,
    pub tracker: Arc<LifetimeTracker>,
    /// Declared variable registry. Keyed by variable name.
    pub variables: Arc<HashMap<String, Variable>>,
    /// `configurations[]` entries from the merged config.
    pub configurations: Arc<HashMap<String, ShieldConfiguration>>,
    /// Host integrations. All are optional; when missing, the corresponding
    /// resolver kind fails closed with `decision: deny`.
    ///
    /// Note: `kind: human` resolvers default to dispatch through the
    /// canonical-tool-call path with `tool_name = "agent_shield.ask_human"`
    /// (host registers an MCP tool under that name). Setting `provider:`
    /// or `name:` on the resolver opts into synchronous dispatch through
    /// a registered [`HumanResolver`] in [`Self::human_registry`].
    pub agent_resolver: Option<Arc<dyn AgentResolver>>,
    pub delegate_dispatcher: Option<Arc<dyn DelegateDispatcher>>,
    /// Registry of named [`HumanResolver`] implementations. Lookups
    /// fire only when the YAML resolver sets `provider:` or `name:`.
    pub human_registry: HumanRegistry,
    /// Retry bound for `kind: tool` per (turn, variable, tool). §11.10.2
    /// RECOMMENDED default `3`.
    pub tool_retry_limit: u32,
    /// Effective runtime mode (#14). In `Shadow`, side-effecting
    /// resolver kinds (`human` / `tool` / `agent` / `delegate`) are
    /// suppressed: no host hook, no `incident.resolution_needed`,
    /// no loop-tracker increment, variable stays `Unset`. One
    /// `require_approval` audit event records what active would
    /// have done. `kind: expression` (pure) still runs.
    pub mode: crate::shield_primitives::RuntimeMode,
    /// Observability dispatcher for §11.9 / §19.5 audit-log emission
    /// (`ResolverInvoked` events with `agent_shield.resolver.latency_ms`).
    /// Also used for resolver-runtime audit events that bypass the bus
    /// (e.g. the shadow-mode `require_approval` audit, #14).
    ///
    /// **REQUIRED.** §11.9 mandates that every resolver invocation emit
    /// the audit event. Test code that doesn't care about emissions can
    /// pass `ObservabilityDispatcher::new(bus.clone())` (a dispatcher
    /// with zero registered providers — emit becomes a no-op).
    pub observability: Arc<ObservabilityDispatcher>,
}

impl ResolverDeps {
    /// Construct a new `ResolverDeps` with the spec-mandated dependencies.
    /// Optional integrations (`agent_resolver`, `delegate_dispatcher`)
    /// default to `None` and may be attached via the `with_*` builder
    /// methods below.
    ///
    /// `observability` is REQUIRED, not optional: §11.9 mandates audit
    /// emission on every resolver invocation. Compile-time enforcement
    /// that production callers can't construct a non-emitting `ResolverDeps`.
    /// Test code that needs a no-op dispatcher passes
    /// `ObservabilityDispatcher::new(bus.clone())` (no providers attached).
    ///
    /// `mode` defaults to [`RuntimeMode::Active`]; use
    /// [`Self::with_mode`] to switch to `Shadow` (#14).
    ///
    /// `tool_retry_limit` is required because there is no spec-default
    /// constant exposed at this layer (`tool_kind::DEFAULT_TOOL_RETRY_LIMIT`
    /// is the canonical source). Callers that want the spec default pass
    /// `tool_kind::DEFAULT_TOOL_RETRY_LIMIT` explicitly.
    pub fn new(
        event_bus: EventBus,
        tracker: Arc<LifetimeTracker>,
        variables: Arc<HashMap<String, Variable>>,
        configurations: Arc<HashMap<String, ShieldConfiguration>>,
        human_registry: HumanRegistry,
        tool_retry_limit: u32,
        observability: Arc<ObservabilityDispatcher>,
    ) -> Self {
        Self {
            event_bus,
            tracker,
            variables,
            configurations,
            agent_resolver: None,
            delegate_dispatcher: None,
            human_registry,
            tool_retry_limit,
            mode: crate::shield_primitives::RuntimeMode::Active,
            observability,
        }
    }

    /// Attach an [`AgentResolver`] hook for `kind: agent` resolvers.
    pub fn with_agent_resolver(mut self, hook: Arc<dyn AgentResolver>) -> Self {
        self.agent_resolver = Some(hook);
        self
    }

    /// Attach a [`DelegateDispatcher`] hook for `kind: delegate` resolvers.
    pub fn with_delegate_dispatcher(mut self, hook: Arc<dyn DelegateDispatcher>) -> Self {
        self.delegate_dispatcher = Some(hook);
        self
    }

    /// Switch the effective runtime mode (#14). Defaults to
    /// [`RuntimeMode::Active`]; production callers in shadow deployments
    /// pass [`RuntimeMode::Shadow`] here.
    pub fn with_mode(mut self, mode: crate::shield_primitives::RuntimeMode) -> Self {
        self.mode = mode;
        self
    }
}

/// Per-call request to the dispatcher.
pub struct ResolveRequest<'a> {
    /// The variable whose `on_demand_by:` triggered the dispatch. `None`
    /// for ad-hoc invocations (e.g. an inline `kind: expression` that
    /// isn't backed by a declared variable). Variable-bound dispatch is
    /// the common case and the only path that emits
    /// `approval.<variable>.<kind>` events.
    pub variable_name: Option<&'a str>,
    pub resolver: &'a Resolver,
    pub context: &'a ResolverContext<'a>,
}

/// The public dispatcher.
pub struct ResolverDispatcher {
    deps: ResolverDeps,
    tool_loop: ToolLoopTracker,
}

impl ResolverDispatcher {
    pub fn new(deps: ResolverDeps) -> Self {
        let tool_loop = ToolLoopTracker::new();
        // The tool loop tracker is wired to the event bus separately if the
        // host wants automatic turn boundary tracking. Hosts that don't
        // call `begin_turn()` themselves can subscribe via
        // [`Self::wire_turn_boundary_subscription`].
        Self { deps, tool_loop }
    }

    /// Subscribe to `turn.start` events so the tool loop tracker advances
    /// automatically. Returns the subscriber handle for unsubscription.
    /// Hosts that prefer to call [`Self::note_turn_start`] manually can
    /// skip this.
    pub fn wire_turn_boundary_subscription(self: &Arc<Self>) -> super::event_bus::SubscriberHandle {
        use super::event_bus::BusEvent;
        use super::events::EventId;
        let weak = Arc::downgrade(self);
        self.deps.event_bus.subscribe(
            Some(Box::new(|ev: &BusEvent| {
                matches!(
                    ev,
                    BusEvent::Emitted {
                        event_id: EventId::TurnStart,
                        ..
                    }
                )
            })),
            move |_ev: &BusEvent| {
                if let Some(d) = weak.upgrade() {
                    d.tool_loop.begin_turn();
                }
            },
        )
    }

    /// Manually advance the per-tracker turn id. Hosts that don't wire up
    /// the bus subscription call this on every `turn.start`.
    pub fn note_turn_start(&self) {
        self.tool_loop.begin_turn();
    }

    /// Notify the dispatcher that the named tool actually executed. P9's
    /// runtime calls this from the `tool.<name>.success` hook so the
    /// per-(turn, variable, tool) attempt counter resets. Per §11.10.2
    /// this is OPTIONAL; without it, the loop bound counts every
    /// `resolution_needed` emission within a turn.
    pub fn note_tool_called(&self, variable: &str, tool_name: &str) {
        self.tool_loop.note_tool_called(variable, tool_name);
    }

    /// Notify the dispatcher that a tool has run to success. Resets the
    /// per-(turn, *, tool) attempt counter for every variable suspended
    /// on this tool — the runtime typically does not know which variable
    /// suspended at success-recording time, only the tool name.
    pub fn note_tool_succeeded(&self, tool_name: &str) {
        self.tool_loop.note_tool_succeeded(tool_name);
    }

    /// Resolve a single Resolver to a wire envelope.
    ///
    /// Applies fallback, on_allow, set_variables, lifetime, and emits
    /// `approval.<variable>.<outcome>` for the chain's final outcome
    /// (§10.5 / §11.5). When the chain terminates because a `kind: tool`
    /// resolver suspended (signal-and-suspend per §11.10.2), returns a
    /// synthetic `Deny` envelope and does NOT emit an
    /// `approval.<variable>.<outcome>` event — the variable stays
    /// `unset` until the agent calls the named tool and the populator
    /// fills it. The `incident.resolution_needed` event already fired
    /// from inside the tool dispatcher carries the host-visible signal.
    pub fn resolve(&self, request: ResolveRequest<'_>) -> ResolverResponse {
        self.resolve_with_pending(request).response
    }

    /// Variant of [`Self::resolve`] that also surfaces a
    /// [`PendingResolution`] when the chain terminated because a
    /// `kind: tool` (or synthesised `kind: human`) resolver suspended
    /// waiting for the agent to call its tool. Surfaced via
    /// [`crate::guard_policy_runtime::StageVerdict::pending_resolution`].
    pub fn resolve_with_pending(&self, request: ResolveRequest<'_>) -> ResolveOutcome {
        let variable_decl = request
            .variable_name
            .and_then(|n| self.deps.variables.get(n).cloned());

        // §11.9 / §19.5 — capture wall-clock for the resolver-audit
        // event. Hot-path overhead is one syscall (~10ns on x86_64);
        // negligible compared to a real resolver dispatch (network /
        // human input / LLM call).
        let start = std::time::Instant::now();

        let invoker =
            |link: &Resolver| self.invoke_link(link, request.context, request.variable_name);
        let chain_outcome =
            fallback::run_with_fallback(request.resolver, variable_decl.as_ref(), &invoker);

        let resolver_kind = request.resolver.kind_str();
        // Inline resolvers (`variable_name == None`) audit as `<inline>`
        // to match the `set_by = "{kind}:inline"` convention used by
        // `finalize()` (line 506). Distinguishable from any real
        // variable name (no YAML variable can start with `<`).
        let audit_variable = request.variable_name.unwrap_or("<inline>");

        let outcome = match chain_outcome {
            fallback::ChainOutcome::Completed(resp) => {
                self.finalize(&resp, &request, variable_decl.as_ref());
                ResolveOutcome {
                    response: resp,
                    pending: None,
                }
            }
            fallback::ChainOutcome::Suspended {
                request_id,
                tool_name,
                prompt,
                kind,
            } => {
                // §11.10.2: tool suspension is signal-and-suspend. The
                // variable stays `unset`; no approval.<var>.<outcome>
                // event fires. The host runtime sees the suspension via
                // the latched `incident.resolution_needed` event and the
                // returned [`PendingResolution`] side channel.
                let response = ResolverResponse {
                    decision: ResolverDecision::Deny,
                    value: None,
                    set_variables: HashMap::new(),
                    reason: Some(format!(
                        "kind: {kind} resolver suspended pending tool execution \
                         (tool=`{tool_name}`, request_id={request_id})"
                    )),
                };
                let pending = request.variable_name.map(|var| PendingResolution {
                    tool: tool_name,
                    variable: var.to_string(),
                    prompt,
                    request_id,
                    kind,
                });
                ResolveOutcome { response, pending }
            }
            fallback::ChainOutcome::Suppressed { kind, reason } => {
                // Shadow mode (#14): every side-effecting link was
                // suppressed and no fallback expression rescued the
                // gate. Skip finalize so the variable stays `Unset`
                // and no `approval.<var>.<outcome>` event fires; the
                // audit event was emitted at the suppression site.
                let response = ResolverResponse {
                    decision: ResolverDecision::Deny,
                    value: None,
                    set_variables: HashMap::new(),
                    reason: Some(format!(
                        "shadow_mode: kind: {kind} resolver suppressed ({reason})"
                    )),
                };
                ResolveOutcome {
                    response,
                    pending: None,
                }
            }
        };

        // Emit the §11.9 / §19.5 audit event AFTER finalize() has run
        // its side effects (variable writes, approval bus events). The
        // ordering matches existing precedent: structured audit logs
        // observe the post-finalize world. `observability` is a required
        // dependency on `ResolverDeps` (§11.9 mandates emission); test
        // code that doesn't care attaches a dispatcher with zero
        // providers (no-op emit).
        let elapsed_ms = start.elapsed().as_millis().min(u64::MAX as u128) as u64;
        let decision_str = match outcome.response.decision {
            ResolverDecision::Allow => "allow",
            ResolverDecision::Deny => "deny",
            ResolverDecision::Cancelled => "cancelled",
        };
        // `error_kind` plumbing is out of scope for this PR (§19.5
        // bug fix); the chain-outcome layer has already mapped per-
        // link errors through `on_error:` and only surfaces a wire
        // envelope. A future PR can thread error_kind through
        // `fallback::ChainOutcome` if §11.9 audit-log consumers want
        // to disambiguate transport / timeout failures from clean
        // denies.
        let session_id = request.context.effective_session_id();
        emitter::log_resolver_invoked_full(
            &self.deps.observability,
            session_id.as_str(),
            resolver_kind,
            audit_variable,
            decision_str,
            elapsed_ms,
            None,
            None,
            outcome.response.reason.as_deref(),
        );

        outcome
    }

    /// Auto-resolution entry point invoked by the expression evaluator's
    /// [`crate::expressions::eval::ResolverHook`]. Returns `Some(value)`
    /// on `Allow`; `None` on `Deny` / `Cancelled`.
    ///
    /// §9.4 / §11.5: when the target variable declares `key:`, the
    /// runtime evaluates the key against the gating-site context here
    /// and surfaces it through [`ResolverContext::requested_key`]. The
    /// value from a successful resolve is written under that key.
    pub fn auto_resolve(&self, variable_name: &str, ctx: &ResolverContext<'_>) -> Option<Value> {
        self.auto_resolve_with_pending(variable_name, ctx).value
    }

    /// Variant of [`Self::auto_resolve`] that also surfaces a
    /// [`PendingResolution`] when a `kind: tool` (or synthesised
    /// `kind: human`) resolver suspended waiting on the agent. Surfaced
    /// upstream via [`AutoResolveAdapter::take_pending`] so the
    /// per-stage runner can attach it to
    /// [`crate::guard_policy_runtime::StageVerdict::pending_resolution`].
    pub fn auto_resolve_with_pending(
        &self,
        variable_name: &str,
        ctx: &ResolverContext<'_>,
    ) -> AutoResolveOutcome {
        let Some(var) = self.deps.variables.get(variable_name).cloned() else {
            return AutoResolveOutcome::default();
        };
        let Some(resolver) = var.on_demand_by.as_ref() else {
            return AutoResolveOutcome::default();
        };

        // §9.4.4: if the variable declares `key:`, evaluate it now
        // against the gating-site attrs and inject as requested_key
        // into a per-call clone of the context. A `null` key short-
        // circuits to fail-closed: the resolver is not invoked, the
        // gate's read evaluates as `unset`.
        let requested_key: Option<Value> = if let Some(key_expr) = &var.key {
            use crate::expressions::eval::{evaluate_to_value, EvalContext};
            let kctx = EvalContext::from_attrs(&ctx.attrs);
            match evaluate_to_value(key_expr, &kctx) {
                Some(Value::Null) | None => return AutoResolveOutcome::default(),
                Some(v) => Some(v),
            }
        } else {
            None
        };

        let mut owned_ctx_attrs;
        let owned_ctx;
        let dispatch_ctx: &ResolverContext<'_> = if requested_key.is_some() {
            owned_ctx_attrs = ctx.attrs.clone();
            // Hand the requested key to the resolver via the public
            // surface so kind: tool / human / agent / delegate can
            // include it in their wire payloads.
            owned_ctx_attrs.insert(
                "@__requested_key__".into(),
                requested_key.clone().unwrap_or(Value::Null),
            );
            owned_ctx = ResolverContext {
                attrs: owned_ctx_attrs,
                request_context: ctx.request_context.clone(),
                invocation: ctx.invocation,
                reason: ctx.reason.clone(),
                resource: ctx.resource.clone(),
                request_id: ctx.request_id.clone(),
                requested_key: requested_key.clone(),
                session_id: ctx.session_id.clone(),
            };
            &owned_ctx
        } else {
            ctx
        };

        let request = ResolveRequest {
            variable_name: Some(variable_name),
            resolver,
            context: dispatch_ctx,
        };
        let resolver_kind = request.resolver.kind_str();
        let outcome = self.resolve_with_pending(request);
        let resp = outcome.response;
        // Stash the resolved key so finalize() can write under it.
        let value = match resp.decision {
            ResolverDecision::Allow => {
                if let Some(value) = &resp.value {
                    // Re-do the write under the requested key. The
                    // generic finalize() already wrote to the unkeyed
                    // slot via set_variable, which is correct for
                    // non-keyed variables. For keyed variables, finalize
                    // produced a stale unkeyed write — overwrite under
                    // the correct key here and clear the unkeyed slot.
                    if let Some(rk) = requested_key.as_ref() {
                        let set_by = format!("{}:{}", resolver_kind, variable_name);
                        let sid = ctx.effective_session_id();
                        if let Err(e) = self.deps.tracker.set_variable_keyed_in(
                            &sid,
                            variable_name,
                            Some(rk),
                            value.clone(),
                            Some(resolver_kind),
                            Some(&set_by),
                            ResolverOutcome::Allow,
                        ) {
                            log::warn!(
                                target: "agent_shield::resolver_runtime",
                                "keyed resolver write to `{}` rejected: {}",
                                variable_name, e
                            );
                        }
                        self.deps
                            .tracker
                            .invalidate_variable_in(&sid, variable_name);
                    }
                }
                resp.value
            }
            _ => None,
        };
        AutoResolveOutcome {
            value,
            pending: outcome.pending,
        }
    }

    // ── per-link dispatch ───────────────────────────────────────────

    fn invoke_link(
        &self,
        link: &Resolver,
        ctx: &ResolverContext<'_>,
        variable_name: Option<&str>,
    ) -> Result<fallback::LinkOutcome, ResolverRuntimeError> {
        // Shadow mode (#14): suppress side-effecting kinds before the
        // host hook runs. `kind: expression` is pure and runs normally.
        if matches!(
            self.deps.mode,
            crate::shield_primitives::RuntimeMode::Shadow
        ) {
            if let Some(kind) = shadow_suppressible_kind(link) {
                self.emit_shadow_suppression_audit(kind, link, ctx, variable_name);
                return Ok(fallback::LinkOutcome::Suppressed {
                    kind,
                    reason: format!(
                        "shadow_mode: kind: {kind} resolver not invoked (variable={})",
                        variable_name.unwrap_or("<inline>"),
                    ),
                });
            }
        }

        match link {
            Resolver::Expression { .. } => Ok(fallback::LinkOutcome::Completed(
                expression_kind::invoke(link, ctx).expect("expression kind dispatch"),
            )),
            Resolver::Human { .. } => {
                // §11.11 (refactored): `kind: human` is a thin shim over
                // `kind: tool`. Dispatched through the canonical
                // signal-and-suspend machinery with the tool name fixed
                // to the canonical `agent_shield.ask_human`. The agent's
                // LLM is expected to call that MCP tool with the
                // rendered prompt; the tool's `populated_by:` writes the
                // human's response into the variable.
                let var_name = variable_name.ok_or_else(|| ResolverRuntimeError::Other {
                    kind: "human",
                    message: "kind: human requires a target variable".into(),
                })?;
                match human_kind::invoke(
                    link,
                    ctx,
                    var_name,
                    &self.tool_loop,
                    &self.deps.event_bus,
                    self.deps.tool_retry_limit,
                    Some(&self.deps.human_registry),
                )? {
                    DispatchOutcome::Completed(resp) => Ok(fallback::LinkOutcome::Completed(resp)),
                    DispatchOutcome::Resolved(resp) => Ok(fallback::LinkOutcome::Completed(resp)),
                    DispatchOutcome::Suspended {
                        request_id,
                        tool_name,
                        prompt,
                        kind,
                    } => Ok(fallback::LinkOutcome::Suspended {
                        request_id,
                        tool_name,
                        prompt,
                        kind,
                    }),
                }
            }
            Resolver::Agent { .. } => {
                let hook = self.deps.agent_resolver.as_deref();
                agent_kind::invoke(link, ctx, variable_name, hook)
                    .map(fallback::LinkOutcome::Completed)
            }
            Resolver::Delegate { .. } => {
                let hook = self.deps.delegate_dispatcher.as_deref();
                delegate_kind::invoke(link, ctx, variable_name, &self.deps.configurations, hook)
                    .map(fallback::LinkOutcome::Completed)
            }
            Resolver::Tool { .. } => {
                // Tool resolvers can only be variable-bound. Without a
                // variable, the populator path doesn't make sense.
                let var_name = variable_name.ok_or_else(|| ResolverRuntimeError::Other {
                    kind: "tool",
                    message: "kind: tool requires a target variable".into(),
                })?;
                match tool_kind::invoke(
                    link,
                    ctx,
                    var_name,
                    &self.tool_loop,
                    &self.deps.event_bus,
                    self.deps.tool_retry_limit,
                )? {
                    DispatchOutcome::Completed(resp) | DispatchOutcome::Resolved(resp) => {
                        Ok(fallback::LinkOutcome::Completed(resp))
                    }
                    DispatchOutcome::Suspended {
                        request_id,
                        tool_name,
                        prompt,
                        kind,
                    } => Ok(fallback::LinkOutcome::Suspended {
                        request_id,
                        tool_name,
                        prompt,
                        kind,
                    }),
                }
            }
        }
    }

    /// Emit one `require_approval` audit event for a shadow-mode
    /// suppressed link (#14).
    fn emit_shadow_suppression_audit(
        &self,
        kind: &'static str,
        link: &Resolver,
        ctx: &ResolverContext<'_>,
        variable_name: Option<&str>,
    ) {
        let observability = &self.deps.observability;
        use crate::observability::event::{EventType, LogAction, Severity, ShieldLogEvent};
        let prompt_text = match link {
            Resolver::Human { prompt, .. } => prompt.as_deref(),
            Resolver::Tool { prompt, .. } => prompt.as_deref(),
            _ => None,
        };
        let mut ev = ShieldLogEvent::new(
            EventType::ResolverInvoked,
            Severity::Medium,
            "resolver.shadow_suppressed",
        )
        .with_action(LogAction::RequireApproval)
        .with_session_id(ctx.effective_session_id().as_str());
        if let Some(req_id) = ctx.request_id.as_deref() {
            ev = ev.with_correlation_id(req_id);
        }
        if let Some(var) = variable_name {
            ev = ev.with_variable(var);
        }
        ev = ev.with_attribute(
            crate::observability::attributes::KEY_RESOLVER_KIND.to_string(),
            serde_json::Value::String(kind.to_string()),
        );
        if let Some(p) = prompt_text {
            ev = ev.with_attribute(
                "agent_shield.resolver.prompt".to_string(),
                serde_json::Value::String(p.to_string()),
            );
        }
        ev.message = format!(
            "shadow_mode: kind: {kind} resolver suppressed (variable={})",
            variable_name.unwrap_or("<inline>"),
        );
        observability.emit(ev);
    }

    // ── finalization ────────────────────────────────────────────────

    fn finalize(
        &self,
        resp: &ResolverResponse,
        request: &ResolveRequest<'_>,
        variable_decl: Option<&Variable>,
    ) {
        let kind = request.resolver.kind_str();
        let set_by = request
            .variable_name
            .map(|n| format!("{}:{}", kind, n))
            .unwrap_or_else(|| format!("{}:inline", kind));
        let session_id = request.context.effective_session_id();

        match resp.decision {
            ResolverDecision::Allow => {
                if let (Some(var), Some(name)) = (variable_decl, request.variable_name) {
                    // Step 1: write the resolver's value: to the target.
                    if let Some(value) = &resp.value {
                        if let Err(e) = self.deps.tracker.set_variable_in(
                            &session_id,
                            name,
                            value.clone(),
                            Some(kind),
                            Some(&set_by),
                            ResolverOutcome::Allow,
                        ) {
                            log::warn!(
                                target: "agent_shield::resolver_runtime",
                                "resolver value write to `{}` rejected: {}",
                                name, e
                            );
                        }
                    }
                    // Step 2 + 3: set_variables + on_allow.
                    let on_allow_map = match request.resolver {
                        Resolver::Expression { on_allow, .. }
                        | Resolver::Tool { on_allow, .. }
                        | Resolver::Human { on_allow, .. }
                        | Resolver::Delegate { on_allow, .. }
                        | Resolver::Agent { on_allow, .. } => on_allow.as_ref(),
                    };
                    let _ = on_allow::apply_set_variables_and_on_allow(
                        &self.deps.tracker,
                        &self.deps.variables,
                        &resp.set_variables,
                        on_allow_map,
                        resp.value.as_ref(),
                        kind,
                        &set_by,
                        request.context,
                    );
                    // Step 4: emit approval.<var>.allow (§10.5).
                    let _ = var.lifetime.clone(); // (kept for clarity / future use)
                    if let Err(e) = self.deps.event_bus.emit_approval_in(
                        &session_id,
                        name.to_string(),
                        ApprovalEventKind::Allow,
                        None,
                        Some(serde_json::json!({
                            "kind": kind,
                            "set_by": set_by,
                            "value": resp.value.clone().unwrap_or(Value::Null),
                            "reason": resp.reason.clone().unwrap_or_default(),
                        })),
                    ) {
                        log::warn!(
                            target: "agent_shield::resolver_runtime",
                            "approval.{}.allow emission failed: {}", name, e
                        );
                    }
                }
            }
            ResolverDecision::Deny => {
                if let Some(name) = request.variable_name {
                    let reason = resp.reason.clone().unwrap_or_else(|| "denied".into());
                    // Tracker stamps `denied` via the auto-flip subscriber
                    // bound in P3, so we just emit the event and let the
                    // bus-driven flip happen.
                    if let Err(e) = self.deps.event_bus.emit_approval_in(
                        &session_id,
                        name.to_string(),
                        ApprovalEventKind::Deny,
                        None,
                        Some(serde_json::json!({
                            "kind": kind,
                            "set_by": set_by,
                            "reason": reason,
                        })),
                    ) {
                        log::warn!(
                            target: "agent_shield::resolver_runtime",
                            "approval.{}.deny emission failed: {}", name, e
                        );
                    }
                }
            }
            ResolverDecision::Cancelled => {
                if let Some(name) = request.variable_name {
                    let reason = resp.reason.clone().unwrap_or_else(|| "cancelled".into());
                    if let Err(e) = self.deps.event_bus.emit_approval_in(
                        &session_id,
                        name.to_string(),
                        ApprovalEventKind::Cancelled,
                        None,
                        Some(serde_json::json!({
                            "kind": kind,
                            "set_by": set_by,
                            "reason": reason,
                        })),
                    ) {
                        log::warn!(
                            target: "agent_shield::resolver_runtime",
                            "approval.{}.cancelled emission failed: {}", name, e
                        );
                    }
                }
            }
        }
    }
}

impl std::fmt::Debug for ResolverDispatcher {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("ResolverDispatcher")
            .field("variables", &self.deps.variables.len())
            .field("configurations", &self.deps.configurations.len())
            .field("has_agent_resolver", &self.deps.agent_resolver.is_some())
            .field(
                "has_delegate_dispatcher",
                &self.deps.delegate_dispatcher.is_some(),
            )
            .field("tool_retry_limit", &self.deps.tool_retry_limit)
            .field("mode", &self.deps.mode)
            .finish()
    }
}

/// Side-effecting kinds (`human` / `tool` / `agent` / `delegate`)
/// return `Some(kind)`; pure `kind: expression` returns `None` (#14).
fn shadow_suppressible_kind(link: &Resolver) -> Option<&'static str> {
    match link {
        Resolver::Human { .. } => Some("human"),
        Resolver::Tool { .. } => Some("tool"),
        Resolver::Agent { .. } => Some("agent"),
        Resolver::Delegate { .. } => Some("delegate"),
        Resolver::Expression { .. } => None,
    }
}

// ─────────────────────────────────────────────────────────────────────
// Top-level dispatcher tests — focus on cross-module coordination
// (per-kind tests live alongside each module).
// ─────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use crate::events::EventId;
    use crate::variables::{Variable, VariableType};
    use serde_json::json;

    fn build_var(yaml: &str) -> Variable {
        serde_yaml::from_str(yaml).unwrap()
    }

    fn make_deps(vars: Vec<Variable>) -> ResolverDeps {
        let bus = EventBus::new();
        let registry: HashMap<String, Variable> =
            vars.into_iter().map(|v| (v.name.clone(), v)).collect();
        let tracker = LifetimeTracker::new(bus.clone(), registry.clone());
        let observability = ObservabilityDispatcher::new(bus.clone());
        ResolverDeps::new(
            bus,
            tracker,
            Arc::new(registry),
            Arc::new(HashMap::new()),
            crate::resolver_runtime::HumanRegistry::new(),
            tool_kind::DEFAULT_TOOL_RETRY_LIMIT,
            observability,
        )
    }

    #[test]
    fn allow_emits_approval_event() {
        let var = build_var(
            r#"
name: ok
type: boolean
on_demand_by:
  kind: expression
  expression: "true"
"#,
        );
        let deps = make_deps(vec![var]);
        let bus = deps.event_bus.clone();
        let dispatcher = ResolverDispatcher::new(deps);
        let resolver: Resolver =
            serde_yaml::from_str("kind: expression\nexpression: \"true\"").unwrap();
        let ctx = ResolverContext::default();
        let resp = dispatcher.resolve(ResolveRequest {
            variable_name: Some("ok"),
            resolver: &resolver,
            context: &ctx,
        });
        assert_eq!(resp.decision, ResolverDecision::Allow);
        let id = EventId::Approval {
            variable: "ok".into(),
            kind: ApprovalEventKind::Allow,
        };
        assert!(bus.fired_id(&id));
    }

    #[test]
    fn deny_emits_deny_event() {
        let var = build_var(
            r#"
name: nope
type: boolean
on_demand_by:
  kind: expression
  expression: "false"
"#,
        );
        let deps = make_deps(vec![var]);
        let bus = deps.event_bus.clone();
        let dispatcher = ResolverDispatcher::new(deps);
        let resolver: Resolver =
            serde_yaml::from_str("kind: expression\nexpression: \"false\"").unwrap();
        let ctx = ResolverContext::default();
        let resp = dispatcher.resolve(ResolveRequest {
            variable_name: Some("nope"),
            resolver: &resolver,
            context: &ctx,
        });
        assert_eq!(resp.decision, ResolverDecision::Deny);
        let id = EventId::Approval {
            variable: "nope".into(),
            kind: ApprovalEventKind::Deny,
        };
        assert!(bus.fired_id(&id));
    }

    #[test]
    fn cancelled_emits_cancelled_event() {
        let var = build_var(
            r#"
name: aborted
type: boolean
on_demand_by:
  kind: agent
  prompt: "?"
"#,
        );
        let mut deps = make_deps(vec![var]);
        deps.agent_resolver = Some(Arc::new(AgentResolverFn(|_| ResolverResponse {
            decision: ResolverDecision::Cancelled,
            value: None,
            set_variables: HashMap::new(),
            reason: Some("user clicked abort".into()),
        })));
        let bus = deps.event_bus.clone();
        let dispatcher = ResolverDispatcher::new(deps);
        let resolver: Resolver = serde_yaml::from_str("kind: agent\nprompt: \"?\"").unwrap();
        let ctx = ResolverContext::default();
        let resp = dispatcher.resolve(ResolveRequest {
            variable_name: Some("aborted"),
            resolver: &resolver,
            context: &ctx,
        });
        assert_eq!(resp.decision, ResolverDecision::Cancelled);
        let id = EventId::Approval {
            variable: "aborted".into(),
            kind: ApprovalEventKind::Cancelled,
        };
        assert!(bus.fired_id(&id));
    }

    #[test]
    fn allow_writes_variable_value() {
        let var = build_var(
            r#"
name: sum
type: number
on_demand_by:
  kind: expression
  expression: "1 + 2"
"#,
        );
        let deps = make_deps(vec![var]);
        let tracker = deps.tracker.clone();
        let dispatcher = ResolverDispatcher::new(deps);
        let resolver: Resolver =
            serde_yaml::from_str("kind: expression\nexpression: \"1 + 2\"").unwrap();
        let ctx = ResolverContext::default();
        let _ = dispatcher.resolve(ResolveRequest {
            variable_name: Some("sum"),
            resolver: &resolver,
            context: &ctx,
        });
        let st = tracker.read_variable("sum");
        assert_eq!(st.value, json!(3));
    }

    #[test]
    fn allow_applies_on_allow_map() {
        let counter = build_var(
            r#"
name: approval_count
type: number
"#,
        );
        let main = build_var(
            r#"
name: ok
type: boolean
on_demand_by:
  kind: agent
  prompt: "?"
  on_allow:
    approval_count: "approval_count + 1"
"#,
        );
        let mut deps = make_deps(vec![counter, main]);
        deps.tracker
            .set_variable(
                "approval_count",
                json!(0),
                Some("seed"),
                Some("seed"),
                ResolverOutcome::Allow,
            )
            .unwrap();
        deps.agent_resolver = Some(Arc::new(AgentResolverFn(|_| ResolverResponse {
            decision: ResolverDecision::Allow,
            value: Some(json!(true)),
            set_variables: HashMap::new(),
            reason: None,
        })));
        let tracker = deps.tracker.clone();
        let dispatcher = ResolverDispatcher::new(deps);
        // We need to seed approval_count into the eval ctx.attrs so the
        // on_allow expression can see it.
        let mut attrs = HashMap::new();
        attrs.insert("approval_count".into(), json!(0));
        let ctx = ResolverContext::default().with_attrs(attrs);
        let resolver: Resolver = serde_yaml::from_str(
            r#"
kind: agent
prompt: "?"
on_allow:
  approval_count: "approval_count + 1"
"#,
        )
        .unwrap();
        let resp = dispatcher.resolve(ResolveRequest {
            variable_name: Some("ok"),
            resolver: &resolver,
            context: &ctx,
        });
        assert_eq!(resp.decision, ResolverDecision::Allow);
        assert_eq!(tracker.read_variable("approval_count").value, json!(1));
    }

    #[test]
    fn allow_applies_set_variables_from_envelope() {
        let counter = build_var(
            r#"
name: count
type: number
"#,
        );
        let main = build_var(
            r#"
name: ok
type: boolean
on_demand_by:
  kind: agent
  prompt: "?"
"#,
        );
        let mut deps = make_deps(vec![counter, main]);
        deps.agent_resolver = Some(Arc::new(AgentResolverFn(|_| {
            let mut sv = HashMap::new();
            sv.insert("count".into(), json!(7));
            ResolverResponse {
                decision: ResolverDecision::Allow,
                value: Some(json!(true)),
                set_variables: sv,
                reason: None,
            }
        })));
        let tracker = deps.tracker.clone();
        let dispatcher = ResolverDispatcher::new(deps);
        let resolver: Resolver = serde_yaml::from_str("kind: agent\nprompt: \"?\"").unwrap();
        let ctx = ResolverContext::default();
        let _ = dispatcher.resolve(ResolveRequest {
            variable_name: Some("ok"),
            resolver: &resolver,
            context: &ctx,
        });
        assert_eq!(tracker.read_variable("count").value, json!(7));
    }

    #[test]
    fn intermediate_chain_outcomes_do_not_emit_events() {
        // Per §11.6: intermediate deny rescued by allow does NOT fire
        // approval.<var>.deny — only the chain's final outcome does.
        let var = build_var(
            r#"
name: ok
type: boolean
on_demand_by:
  kind: agent
  prompt: "primary"
  fallback:
    kind: expression
    expression: "true"
"#,
        );
        let mut deps = make_deps(vec![var]);
        deps.agent_resolver = Some(Arc::new(AgentResolverFn(|_| ResolverResponse {
            decision: ResolverDecision::Deny,
            value: None,
            set_variables: HashMap::new(),
            reason: Some("primary said no".into()),
        })));
        let bus = deps.event_bus.clone();
        let dispatcher = ResolverDispatcher::new(deps);
        let resolver: Resolver = serde_yaml::from_str(
            r#"
kind: agent
prompt: "primary"
fallback:
  kind: expression
  expression: "true"
"#,
        )
        .unwrap();
        let ctx = ResolverContext::default();
        let resp = dispatcher.resolve(ResolveRequest {
            variable_name: Some("ok"),
            resolver: &resolver,
            context: &ctx,
        });
        assert_eq!(resp.decision, ResolverDecision::Allow);
        // The intermediate deny is NOT observable on the bus.
        let deny_id = EventId::Approval {
            variable: "ok".into(),
            kind: ApprovalEventKind::Deny,
        };
        assert!(!bus.fired_id(&deny_id));
        let allow_id = EventId::Approval {
            variable: "ok".into(),
            kind: ApprovalEventKind::Allow,
        };
        assert!(bus.fired_id(&allow_id));
    }

    #[test]
    fn tool_resolver_signals_and_returns_deny_envelope() {
        let var = build_var(
            r#"
name: recipient
type: string
on_demand_by:
  kind: tool
  name: lookup_recipient
"#,
        );
        let deps = make_deps(vec![var]);
        let bus = deps.event_bus.clone();
        let dispatcher = ResolverDispatcher::new(deps);
        let resolver: Resolver =
            serde_yaml::from_str("kind: tool\nname: lookup_recipient\n").unwrap();
        let ctx = ResolverContext::default();
        let resp = dispatcher.resolve(ResolveRequest {
            variable_name: Some("recipient"),
            resolver: &resolver,
            context: &ctx,
        });
        // Suspension surfaces as a synthesized Deny so the chain can fall
        // through to a declared fallback if any.
        assert_eq!(resp.decision, ResolverDecision::Deny);
        let id = EventId::Incident {
            name: "resolution_needed".into(),
        };
        assert!(bus.fired_id(&id));
    }

    #[test]
    fn tool_suspension_does_not_emit_approval_deny() {
        // §11.10.2 contract: signal-and-suspend leaves the variable
        // `unset`. No `approval.<var>.deny` should fire because the
        // resolver isn't denying — it's waiting for the agent to call
        // the tool. This is critical for spec compliance: if approval.deny
        // fired, the bus subscriber would auto-flip the variable to
        // `denied`, blocking the populator from ever filling it.
        let var = build_var(
            r#"
name: recipient
type: string
on_demand_by:
  kind: tool
  name: lookup_recipient
"#,
        );
        let deps = make_deps(vec![var]);
        let bus = deps.event_bus.clone();
        let tracker = deps.tracker.clone();
        let dispatcher = ResolverDispatcher::new(deps);
        let resolver: Resolver =
            serde_yaml::from_str("kind: tool\nname: lookup_recipient\n").unwrap();
        let ctx = ResolverContext::default();
        let _ = dispatcher.resolve(ResolveRequest {
            variable_name: Some("recipient"),
            resolver: &resolver,
            context: &ctx,
        });
        // The variable MUST remain `unset` (not `denied`).
        let st = tracker.read_variable("recipient");
        assert_eq!(st.status, crate::lifetime_tracker::VarStatus::Unset);
        // approval.recipient.deny MUST NOT fire.
        let deny_id = EventId::Approval {
            variable: "recipient".into(),
            kind: ApprovalEventKind::Deny,
        };
        assert!(!bus.fired_id(&deny_id));
        let cancelled_id = EventId::Approval {
            variable: "recipient".into(),
            kind: ApprovalEventKind::Cancelled,
        };
        assert!(!bus.fired_id(&cancelled_id));
        // incident.resolution_needed MUST fire.
        let inc = EventId::Incident {
            name: "resolution_needed".into(),
        };
        assert!(bus.fired_id(&inc));
    }

    #[test]
    fn tool_suspension_does_not_advance_to_fallback() {
        // §11.6: the fallback chain is invoked only on deny / cancelled
        // / use_fallback errors / null-or-false expression. Tool
        // suspension is none of these. Verify a tool resolver with an
        // expression fallback does NOT fall through.
        let var = build_var(
            r#"
name: r
type: string
on_demand_by:
  kind: tool
  name: lookup
  fallback:
    kind: expression
    expression: "'fallback_value'"
"#,
        );
        let deps = make_deps(vec![var]);
        let dispatcher = ResolverDispatcher::new(deps);
        let resolver: Resolver = serde_yaml::from_str(
            r#"
kind: tool
name: lookup
fallback:
  kind: expression
  expression: "'fallback_value'"
"#,
        )
        .unwrap();
        let ctx = ResolverContext::default();
        let resp = dispatcher.resolve(ResolveRequest {
            variable_name: Some("r"),
            resolver: &resolver,
            context: &ctx,
        });
        // The chain terminated at suspension (Deny shape), NOT at the
        // expression fallback (which would have produced Allow with
        // value 'fallback_value').
        assert_eq!(resp.decision, ResolverDecision::Deny);
        assert!(resp.value.is_none());
    }

    #[test]
    fn approval_payload_includes_resolver_kind() {
        let var = build_var(
            r#"
name: ok
type: boolean
on_demand_by:
  kind: expression
  expression: "true"
"#,
        );
        let deps = make_deps(vec![var]);
        let bus = deps.event_bus.clone();
        let dispatcher = ResolverDispatcher::new(deps);
        let resolver: Resolver =
            serde_yaml::from_str("kind: expression\nexpression: \"true\"").unwrap();
        let ctx = ResolverContext::default();
        let _ = dispatcher.resolve(ResolveRequest {
            variable_name: Some("ok"),
            resolver: &resolver,
            context: &ctx,
        });
        let id = EventId::Approval {
            variable: "ok".into(),
            kind: ApprovalEventKind::Allow,
        };
        let payload = bus.payload_of(&id).expect("approval event payload");
        assert_eq!(payload.get("kind"), Some(&json!("expression")));
    }

    #[test]
    fn human_resolver_suspends_via_canonical_tool_signal() {
        // §11.11 (refactored): `kind: human` always suspends pending the
        // agent calling `agent_shield.ask_human`. The chain returns a
        // synthetic Deny but does NOT fire `approval.<var>.deny` because
        // the variable stays `unset`; the visible signal is
        // `incident.resolution_needed`.
        let var = build_var(
            r#"
name: needs_human
type: boolean
on_demand_by:
  kind: human
  prompt: "ok?"
"#,
        );
        let deps = make_deps(vec![var]);
        let bus = deps.event_bus.clone();
        let dispatcher = ResolverDispatcher::new(deps);
        let resolver: Resolver = serde_yaml::from_str("kind: human\nprompt: \"ok?\"").unwrap();
        let ctx = ResolverContext::default();
        let resp = dispatcher.resolve(ResolveRequest {
            variable_name: Some("needs_human"),
            resolver: &resolver,
            context: &ctx,
        });
        assert_eq!(resp.decision, ResolverDecision::Deny);
        assert!(resp
            .reason
            .as_ref()
            .map(|r| r.contains("agent_shield.ask_human"))
            .unwrap_or(false));
        let incident = EventId::Incident {
            name: "resolution_needed".into(),
        };
        assert!(bus.fired_id(&incident));
        let approval = EventId::Approval {
            variable: "needs_human".into(),
            kind: ApprovalEventKind::Deny,
        };
        assert!(
            !bus.fired_id(&approval),
            "suspension must NOT emit approval.<var>.deny"
        );
    }

    #[test]
    fn delegate_classifier_via_mock_dispatcher() {
        // AACS-style classifier as a mock delegate dispatcher.
        let var = build_var(
            r#"
name: safe_input
type: boolean
on_demand_by:
  kind: delegate
  configuration: aacs
"#,
        );
        let cls_yaml =
            "id: aacs\ntype: classifier\nendpoint: \"https://aacs.invalid\"\nthreshold: 0.5\n";
        let cls: ShieldConfiguration = serde_yaml::from_str(cls_yaml).unwrap();
        let mut configurations = HashMap::new();
        configurations.insert("aacs".into(), cls);

        let bus = EventBus::new();
        let registry: HashMap<String, Variable> =
            std::iter::once((var.name.clone(), var)).collect();
        let tracker = LifetimeTracker::new(bus.clone(), registry.clone());
        let mock = DelegateDispatcherFn(|req: DelegateRequest| {
            // Pretend the classifier returned a score of 0.2 (under
            // threshold) for safe input.
            assert_eq!(req.configuration.id, "aacs");
            let threshold = req.configuration.threshold.unwrap();
            Ok(classifier_score_to_envelope(0.2, threshold, Some("safe")))
        });
        let deps = ResolverDeps::new(
            bus.clone(),
            tracker,
            Arc::new(registry),
            Arc::new(configurations),
            crate::resolver_runtime::HumanRegistry::new(),
            tool_kind::DEFAULT_TOOL_RETRY_LIMIT,
            ObservabilityDispatcher::new(bus.clone()),
        )
        .with_delegate_dispatcher(Arc::new(mock));
        let dispatcher = ResolverDispatcher::new(deps);
        let resolver: Resolver =
            serde_yaml::from_str("kind: delegate\nconfiguration: aacs").unwrap();
        let ctx = ResolverContext::default();
        let resp = dispatcher.resolve(ResolveRequest {
            variable_name: Some("safe_input"),
            resolver: &resolver,
            context: &ctx,
        });
        assert_eq!(resp.decision, ResolverDecision::Allow);
        let id = EventId::Approval {
            variable: "safe_input".into(),
            kind: ApprovalEventKind::Allow,
        };
        assert!(bus.fired_id(&id));
    }

    #[test]
    fn delegate_classifier_above_threshold_denies() {
        let var = build_var(
            r#"
name: harmful
type: boolean
on_demand_by:
  kind: delegate
  configuration: aacs
"#,
        );
        let cls_yaml =
            "id: aacs\ntype: classifier\nendpoint: \"https://aacs.invalid\"\nthreshold: 0.5\n";
        let cls: ShieldConfiguration = serde_yaml::from_str(cls_yaml).unwrap();
        let mut configurations = HashMap::new();
        configurations.insert("aacs".into(), cls);

        let bus = EventBus::new();
        let registry: HashMap<String, Variable> =
            std::iter::once((var.name.clone(), var)).collect();
        let tracker = LifetimeTracker::new(bus.clone(), registry.clone());
        let mock = DelegateDispatcherFn(|_req: DelegateRequest| {
            Ok(classifier_score_to_envelope(0.9, 0.5, Some("hate")))
        });
        let deps = ResolverDeps::new(
            bus.clone(),
            tracker,
            Arc::new(registry),
            Arc::new(configurations),
            crate::resolver_runtime::HumanRegistry::new(),
            tool_kind::DEFAULT_TOOL_RETRY_LIMIT,
            ObservabilityDispatcher::new(bus.clone()),
        )
        .with_delegate_dispatcher(Arc::new(mock));
        let dispatcher = ResolverDispatcher::new(deps);
        let resolver: Resolver =
            serde_yaml::from_str("kind: delegate\nconfiguration: aacs").unwrap();
        let ctx = ResolverContext::default();
        let resp = dispatcher.resolve(ResolveRequest {
            variable_name: Some("harmful"),
            resolver: &resolver,
            context: &ctx,
        });
        assert_eq!(resp.decision, ResolverDecision::Deny);
    }

    #[test]
    fn auto_resolve_returns_value_on_allow() {
        let var = build_var(
            r#"
name: x
type: number
on_demand_by:
  kind: expression
  expression: "42"
"#,
        );
        let deps = make_deps(vec![var]);
        let dispatcher = ResolverDispatcher::new(deps);
        let ctx = ResolverContext::default();
        let v = dispatcher.auto_resolve("x", &ctx);
        assert_eq!(v, Some(json!(42)));
    }

    #[test]
    fn auto_resolve_returns_none_on_deny() {
        let var = build_var(
            r#"
name: x
type: boolean
on_demand_by:
  kind: expression
  expression: "false"
"#,
        );
        let deps = make_deps(vec![var]);
        let dispatcher = ResolverDispatcher::new(deps);
        let ctx = ResolverContext::default();
        let v = dispatcher.auto_resolve("x", &ctx);
        assert_eq!(v, None);
    }

    #[test]
    fn auto_resolve_unknown_variable_returns_none() {
        let deps = make_deps(vec![]);
        let dispatcher = ResolverDispatcher::new(deps);
        let ctx = ResolverContext::default();
        assert_eq!(dispatcher.auto_resolve("nope", &ctx), None);
    }

    #[test]
    fn note_turn_start_resets_tool_loop() {
        let var = build_var(
            r#"
name: r
type: string
on_demand_by:
  kind: tool
  name: lookup
"#,
        );
        let deps = make_deps(vec![var]);
        let dispatcher = ResolverDispatcher::new(deps);
        let resolver: Resolver = serde_yaml::from_str("kind: tool\nname: lookup\n").unwrap();
        let ctx = ResolverContext::default();
        // Fire enough times to exhaust the bound.
        for _ in 0..=DEFAULT_TOOL_RETRY_LIMIT {
            let _ = dispatcher.resolve(ResolveRequest {
                variable_name: Some("r"),
                resolver: &resolver,
                context: &ctx,
            });
        }
        // Confirm subsequent dispatch is suppressed.
        let suppressed = dispatcher.resolve(ResolveRequest {
            variable_name: Some("r"),
            resolver: &resolver,
            context: &ctx,
        });
        // The Cancelled outcome surfaces through finalize as
        // approval.<r>.cancelled. The wire envelope is Cancelled.
        assert_eq!(suppressed.decision, ResolverDecision::Cancelled);

        // Begin a new turn; the next dispatch suspends fresh.
        dispatcher.note_turn_start();
        let resp = dispatcher.resolve(ResolveRequest {
            variable_name: Some("r"),
            resolver: &resolver,
            context: &ctx,
        });
        // Suspension surfaces as Deny.
        assert_eq!(resp.decision, ResolverDecision::Deny);
    }

    #[test]
    fn variable_decl_default_used_on_use_default_error() {
        // Verifies the fallback runner integration: a host resolver errors
        // out / denies, on_error: use_default consults the variable's
        // `default:`. Uses `kind: agent` here since `kind: human` no
        // longer goes through a host trait callback (it's now a thin
        // shim over `kind: tool`'s signal-and-suspend flow).
        let var = build_var(
            r#"
name: with_default
type: number
default: 99
on_demand_by:
  kind: agent
  prompt: "?"
  on_error: use_default
"#,
        );
        let mut deps = make_deps(vec![var]);
        deps.agent_resolver = Some(Arc::new(AgentResolverFn(|_| {
            // Deny → on_error does not apply (errors only). Verify the
            // chain's deny propagates through the bus.
            ResolverResponse {
                decision: ResolverDecision::Deny,
                value: None,
                set_variables: HashMap::new(),
                reason: Some("nope".into()),
            }
        })));
        let bus = deps.event_bus.clone();
        let dispatcher = ResolverDispatcher::new(deps);
        let resolver: Resolver = serde_yaml::from_str(
            r#"
kind: agent
prompt: "?"
on_error: use_default
"#,
        )
        .unwrap();
        let ctx = ResolverContext::default();
        let resp = dispatcher.resolve(ResolveRequest {
            variable_name: Some("with_default"),
            resolver: &resolver,
            context: &ctx,
        });
        assert_eq!(resp.decision, ResolverDecision::Deny);
        let id = EventId::Approval {
            variable: "with_default".into(),
            kind: ApprovalEventKind::Deny,
        };
        assert!(bus.fired_id(&id));
    }

    // Suppress unused-import warnings in the test fixture above.
    #[allow(dead_code)]
    fn _force_imports() -> VariableType {
        VariableType::Boolean
    }
}
