//! Performance-telemetry gating for the perf-instrumentation events
//! added in PR6 (v8 perf-logging Phase 1).
//!
//! Three-state opt-in knob. The default ([`PerfTelemetry::Off`]) emits
//! zero perf events — adopters who don't need perf instrumentation pay
//! no observability cost. Adopters who want to attribute LLM /
//! classifier cost to the triggering policy without being drowned in
//! stage / policy / detection events pick [`PerfTelemetry::External`].
//! Diagnostic deep-dive workloads pick [`PerfTelemetry::Full`].
//!
//! # Wire representation
//!
//! - `Off`      → `0`
//! - `External` → `1`
//! - `Full`     → `2`
//!
//! Used by the FFI layer ([`crate::ffi`]) so the Python and .NET SDKs
//! can pass an integer across the C ABI rather than a stringly-typed
//! value.
//!
//! # Gating rule (applied by stage / policy / detection runners in PR6)
//!
//! | Event family                              | `Off` | `External` | `Full` |
//! |-------------------------------------------|:-----:|:----------:|:------:|
//! | `StageEvaluated`, `PolicyEvaluated`,      |   —   |     —      |   ✔    |
//! | per-detection timing                      |   —   |     —      |   ✔    |
//! | `LlmCalled`, `ClassifierCalled`           |   —   |     ✔      |   ✔    |
//!
//! AC10-Corr: the `LlmCalled` / `ClassifierCalled` events MUST carry
//! the triggering policy name + stage + `evaluate_when[]` index as
//! attributes so adopters at [`PerfTelemetry::External`] can attribute
//! external-call cost back to the policy without needing a parent
//! detection event.

use serde::{Deserialize, Serialize};

/// Perf-telemetry gating knob. See module docs for the gating table.
///
/// Default is [`PerfTelemetry::Off`] — alpha stays opt-in.
#[derive(
    Debug, Default, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize,
)]
#[serde(rename_all = "snake_case")]
pub enum PerfTelemetry {
    /// Emit zero perf-instrumentation events. The default.
    #[default]
    Off,
    /// Emit only `LlmCalled` and `ClassifierCalled` — the predicted
    /// common-case for adopters who want external-call cost signals
    /// without being drowned in stage / policy / detection events.
    External,
    /// Emit every perf event (stage, policy, detection, LLM,
    /// classifier). Diagnostic mode.
    Full,
}

impl PerfTelemetry {
    /// Whether stage / policy / detection-level perf events should
    /// emit at this telemetry level. True only at [`Self::Full`].
    pub const fn emit_stage_events(self) -> bool {
        matches!(self, Self::Full)
    }

    /// Whether LLM-call perf events should emit at this telemetry
    /// level. True at both [`Self::External`] and [`Self::Full`].
    pub const fn emit_llm_events(self) -> bool {
        !matches!(self, Self::Off)
    }

    /// Whether classifier-call perf events should emit at this
    /// telemetry level. True at both [`Self::External`] and
    /// [`Self::Full`].
    pub const fn emit_classifier_events(self) -> bool {
        !matches!(self, Self::Off)
    }

    /// Wire-shape encoding as a `u8` for the FFI layer.
    ///
    /// `Off → 0`, `External → 1`, `Full → 2`.
    pub const fn as_u8(self) -> u8 {
        match self {
            Self::Off => 0,
            Self::External => 1,
            Self::Full => 2,
        }
    }

    /// Wire-shape decoding from a `u8`. Returns `None` for any value
    /// outside `0..=2` so the FFI layer can surface a typed error.
    pub const fn from_u8(v: u8) -> Option<Self> {
        match v {
            0 => Some(Self::Off),
            1 => Some(Self::External),
            2 => Some(Self::Full),
            _ => None,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn default_is_off() {
        assert_eq!(PerfTelemetry::default(), PerfTelemetry::Off);
    }

    #[test]
    fn gating_table_matches_module_docs() {
        // Off
        assert!(!PerfTelemetry::Off.emit_stage_events());
        assert!(!PerfTelemetry::Off.emit_llm_events());
        assert!(!PerfTelemetry::Off.emit_classifier_events());

        // External: LLM + classifier on; stage/policy/detection off
        assert!(!PerfTelemetry::External.emit_stage_events());
        assert!(PerfTelemetry::External.emit_llm_events());
        assert!(PerfTelemetry::External.emit_classifier_events());

        // Full: everything on
        assert!(PerfTelemetry::Full.emit_stage_events());
        assert!(PerfTelemetry::Full.emit_llm_events());
        assert!(PerfTelemetry::Full.emit_classifier_events());
    }

    #[test]
    fn u8_roundtrip_all_three_states() {
        for mode in [
            PerfTelemetry::Off,
            PerfTelemetry::External,
            PerfTelemetry::Full,
        ] {
            assert_eq!(PerfTelemetry::from_u8(mode.as_u8()), Some(mode));
        }
    }

    #[test]
    fn u8_decode_rejects_out_of_range() {
        assert_eq!(PerfTelemetry::from_u8(0), Some(PerfTelemetry::Off));
        assert_eq!(PerfTelemetry::from_u8(1), Some(PerfTelemetry::External));
        assert_eq!(PerfTelemetry::from_u8(2), Some(PerfTelemetry::Full));
        assert_eq!(PerfTelemetry::from_u8(3), None);
        assert_eq!(PerfTelemetry::from_u8(255), None);
    }

    #[test]
    fn serde_json_roundtrip() {
        for mode in [
            PerfTelemetry::Off,
            PerfTelemetry::External,
            PerfTelemetry::Full,
        ] {
            let s = serde_json::to_string(&mode).expect("serialize");
            let back: PerfTelemetry = serde_json::from_str(&s).expect("deserialize");
            assert_eq!(back, mode);
        }
    }

    #[test]
    fn serde_wire_strings_are_snake_case() {
        // Repo convention is snake_case throughout; lock the exact
        // wire strings so config/FFI-adjacent payloads stay stable.
        assert_eq!(
            serde_json::to_string(&PerfTelemetry::Off).unwrap(),
            "\"off\""
        );
        assert_eq!(
            serde_json::to_string(&PerfTelemetry::External).unwrap(),
            "\"external\""
        );
        assert_eq!(
            serde_json::to_string(&PerfTelemetry::Full).unwrap(),
            "\"full\""
        );

        // And the reverse direction — deserialize from the same
        // snake_case strings.
        assert_eq!(
            serde_json::from_str::<PerfTelemetry>("\"off\"").unwrap(),
            PerfTelemetry::Off
        );
        assert_eq!(
            serde_json::from_str::<PerfTelemetry>("\"external\"").unwrap(),
            PerfTelemetry::External
        );
        assert_eq!(
            serde_json::from_str::<PerfTelemetry>("\"full\"").unwrap(),
            PerfTelemetry::Full
        );
    }
}
