//! Information Flow Control: tag-set algebra over a closed tag universe.
//!
//! Implements the free join-semilattice `(2^T, ⊆, ∪, ∅, T)` underlying
//! Agent Shield's IFC enforcement, where `T` is a finite set of tags
//! enumerated once in `ifc.tags` at config-load time. The runtime
//! maintains a single [`TagSet`] per scope (`Eₙ`), unions it with the
//! source's `tags` on every recorded read, and checks
//! `Eₙ ⊆ μ(sink)` at every gated egress.
//!
//! See `docs/information-flow-control.md` for the design and
//! `docs/information-flow-control-proof.md` for the formal proof of
//! compliance. Key correspondences:
//!
//! | Proof notation | Code |
//! |----------------|------|
//! | `L = 2^T`      | [`TagSet`] (a fixed-width bitset over [`TagUniverse`]) |
//! | `λ : S → L`    | per-resource `tags` field (TC-9 enforced at load time) |
//! | `μ : K → L`    | per-resource `clearance` field (TC-7, TC-8 enforced) |
//! | `ν : K → L`    | per-resource `audience` field (TC-8, TC-9 enforced) |
//! | `⊥`            | [`TagSet::EMPTY`] |
//! | `⊤`            | [`TagUniverse::full`] |
//! | `⊑`            | [`TagSet::is_subset`] |
//! | `⊔`            | [`TagSet::union`] |
//!
//! Design notes:
//! - **Closed tag universe.** Authors enumerate every tag in
//!   `ifc.tags`. References from `tags:`, `clearance:`, or
//!   `audience:` resolve against this set; unknown names are
//!   load-time errors with precise paths.
//! - **Fixed-width bitset.** `TagSet` is a `u64` internally — up to
//!   64 distinct tags. All operations are O(1).
//! - **Optional.** When the merged config carries no `ifc:` block,
//!   the runtime uses [`CompiledIfc::default`] which has an empty
//!   universe; every check no-ops.
//! - **Names are stable across SDK boundaries.** Wire / FFI shapes
//!   serialise tag sets as sorted `Vec<String>` of declared names.

use std::collections::HashMap;

use serde::{Deserialize, Serialize};

use crate::errors::{ConfigError, SourceLoc};

// ── TagSet ─────────────────────────────────────────────────────────

/// Maximum number of tags supported by a single `TagSet` instance.
/// Hard-coded to 64 because the internal representation is a `u64`.
/// If a deployment legitimately needs more, the bitset width should
/// be widened to a small `Vec<u64>`; doing so requires no public-API
/// change beyond raising this constant.
pub const MAX_TAGS: usize = 64;

/// A subset of the closed tag universe, represented as a fixed-width
/// bitset. The proof's lattice element type — see module docs for
/// the carrier mapping.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub struct TagSet(u64);

impl TagSet {
    /// `⊥` — the empty tag set. Initial running exposure; default
    /// `tags` for a resource that omits the field; the conservative
    /// default for `default_clearance` and `default_audience`.
    pub const EMPTY: TagSet = TagSet(0);

    /// Construct a tag set by listing bit positions.
    pub fn from_bits(bits: impl IntoIterator<Item = u8>) -> Self {
        let mut s = Self::EMPTY;
        for b in bits {
            assert!((b as usize) < MAX_TAGS, "tag bit out of range");
            s.0 |= 1u64 << b;
        }
        s
    }

    /// `a ⊆ b` — the proof's `⊑` relation.
    pub fn is_subset(self, other: TagSet) -> bool {
        (self.0 & !other.0) == 0
    }

    /// `a ∪ b` — the proof's `⊔` operation.
    pub fn union(self, other: TagSet) -> TagSet {
        TagSet(self.0 | other.0)
    }

    /// `a ∩ b` — not part of the core admit predicate but useful for
    /// audit / diagnostics.
    pub fn intersect(self, other: TagSet) -> TagSet {
        TagSet(self.0 & other.0)
    }

    /// `true` iff this set contains the given bit position.
    pub fn contains(self, bit: u8) -> bool {
        assert!((bit as usize) < MAX_TAGS, "tag bit out of range");
        (self.0 & (1u64 << bit)) != 0
    }

    /// Number of tags in the set (popcount).
    pub fn len(self) -> u32 {
        self.0.count_ones()
    }

    /// `true` iff the set is empty (`⊥`).
    pub fn is_empty(self) -> bool {
        self.0 == 0
    }

    /// Iterator over the bit positions in this set, ascending.
    pub fn iter_bits(self) -> impl Iterator<Item = u8> {
        (0..MAX_TAGS as u8).filter(move |b| self.contains(*b))
    }

    /// Raw u64 representation. Used by the FFI layer to ship a single
    /// scalar across the language boundary; clients on the far side
    /// recombine with the universe to recover names.
    pub fn raw(self) -> u64 {
        self.0
    }

    /// Reconstruct a `TagSet` from its raw u64. Inverse of [`Self::raw`].
    pub fn from_raw(raw: u64) -> Self {
        Self(raw)
    }
}

// ── TagUniverse ────────────────────────────────────────────────────

/// The closed tag universe declared in `ifc.tags`. Maps each declared
/// tag name to a stable bit position assigned at config-load time.
/// Used to resolve YAML names into `TagSet` values and to render
/// `TagSet` back to sorted name lists for audit / FFI.
#[derive(Debug, Clone)]
pub struct TagUniverse {
    /// Tag names indexed by their bit position. `tags[i]` is the
    /// declared name of bit `i`. Empty for the disabled / no-`ifc:`
    /// case.
    tags: Vec<String>,
    /// Reverse map: name → bit position.
    by_name: HashMap<String, u8>,
}

impl Default for TagUniverse {
    /// An empty universe — used when no `ifc:` block was declared.
    fn default() -> Self {
        Self {
            tags: Vec::new(),
            by_name: HashMap::new(),
        }
    }
}

impl TagUniverse {
    /// Construct from a list of tag names. Returns
    /// [`ConfigError::Schema`] on duplicate names, empty names, or
    /// more than [`MAX_TAGS`] entries.
    pub fn from_names(
        names: Vec<String>,
        loc: SourceLoc,
    ) -> std::result::Result<Self, ConfigError> {
        if names.len() > MAX_TAGS {
            return Err(ConfigError::Schema {
                loc,
                message: format!(
                    "ifc.tags: too many tags ({} > maximum {})",
                    names.len(),
                    MAX_TAGS
                ),
            });
        }
        let mut tags = Vec::with_capacity(names.len());
        let mut by_name = HashMap::with_capacity(names.len());
        for (idx, name) in names.into_iter().enumerate() {
            if name.is_empty() {
                return Err(ConfigError::Schema {
                    loc: loc.clone(),
                    message: format!("ifc.tags[{idx}]: tag name must be a non-empty string"),
                });
            }
            if name == "*" {
                return Err(ConfigError::Schema {
                    loc: loc.clone(),
                    message: format!(
                        "ifc.tags[{idx}]: `*` is reserved as wildcard sugar; pick a different tag name"
                    ),
                });
            }
            let bit = idx as u8;
            if by_name.insert(name.clone(), bit).is_some() {
                return Err(ConfigError::Schema {
                    loc: loc.clone(),
                    message: format!("ifc.tags: duplicate tag name `{name}`"),
                });
            }
            tags.push(name);
        }
        Ok(Self { tags, by_name })
    }

    /// `true` iff no tags are declared (the disabled / no-`ifc:` case).
    pub fn is_disabled(&self) -> bool {
        self.tags.is_empty()
    }

    /// Number of declared tags.
    pub fn len(&self) -> usize {
        self.tags.len()
    }

    /// `true` iff no tags are declared. Symmetric with [`Self::is_disabled`]
    /// but reads more naturally on a non-disabled universe.
    pub fn is_empty(&self) -> bool {
        self.tags.is_empty()
    }

    /// Look up a declared tag name. Returns the bit position, or `None`
    /// if the name is not declared.
    pub fn bit_of(&self, name: &str) -> Option<u8> {
        self.by_name.get(name).copied()
    }

    /// Render a `TagSet` back to a sorted list of declared names.
    /// Used for audit events and FFI; output ordering matches the
    /// ascending bit-position order, which equals YAML declaration
    /// order.
    pub fn names_of(&self, set: TagSet) -> Vec<String> {
        set.iter_bits()
            .filter_map(|b| self.tags.get(b as usize).cloned())
            .collect()
    }

    /// `T` — the full universe. Returned by `clearance: ["*"]` etc.
    pub fn full(&self) -> TagSet {
        if self.tags.is_empty() {
            TagSet::EMPTY
        } else {
            // Set the lowest `len()` bits.
            let n = self.tags.len();
            if n >= MAX_TAGS {
                TagSet(u64::MAX)
            } else {
                TagSet((1u64 << n) - 1)
            }
        }
    }

    /// Resolve a YAML tag-list field against the universe. Accepts
    /// the wildcard sugar `["*"]` as `T`, an empty list as `∅`, and
    /// any list of declared names as the corresponding bitset. Unknown
    /// names produce `ConfigError::Schema` with the supplied path.
    pub fn resolve(
        &self,
        names: &[String],
        loc: SourceLoc,
        path: &str,
    ) -> std::result::Result<TagSet, ConfigError> {
        // Wildcard sugar.
        if names.len() == 1 && names[0] == "*" {
            return Ok(self.full());
        }
        let mut set = TagSet::EMPTY;
        for (idx, name) in names.iter().enumerate() {
            if name == "*" {
                return Err(ConfigError::Schema {
                    loc,
                    message: format!("{path}[{idx}]: `*` may only appear as a single-element list"),
                });
            }
            let bit = self.bit_of(name).ok_or_else(|| ConfigError::Schema {
                loc: loc.clone(),
                message: format!("{path}[{idx}]: tag `{name}` is not declared in ifc.tags"),
            })?;
            set.0 |= 1u64 << bit;
        }
        Ok(set)
    }

    /// All declared tag names in declaration / bit-position order.
    pub fn names(&self) -> &[String] {
        &self.tags
    }
}

// ── ScopePolicy ────────────────────────────────────────────────────

/// When the running exposure resets to `⊥`. Per the proof's TC-3,
/// non-`per_session` policies require host capability declaration.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Deserialize, Serialize, Default)]
#[serde(rename_all = "snake_case")]
pub enum ScopePolicy {
    /// Exposure persists for the entire session. Cleared on session
    /// disposal. **Default.** The only scope that is sound without a
    /// host capability declaration, because the LLM's context
    /// persists across turns within a session.
    #[default]
    PerSession,
    /// Exposure cleared on `turn.end`. Requires
    /// `RuntimeBuilder::supports_context_reset(true)` — the host
    /// genuinely tears down LLM context at the boundary.
    PerTurn,
    /// Exposure cleared on `request.end`. Requires
    /// `supports_context_reset` — same rationale as `per_turn`.
    PerRequest,
}

// ── YAML schema ─────────────────────────────────────────────────────

/// Top-level `ifc:` block on the merged config. Compiled into
/// [`CompiledIfc`] at merge time.
#[derive(Debug, Clone, Deserialize, Serialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct IfcSpec {
    /// The closed tag universe. Referenced from every other
    /// `tags:` / `clearance:` / `audience:` field. Required when an
    /// `ifc:` block is declared.
    #[serde(default)]
    pub tags: Vec<String>,
    /// Reset boundary for the running exposure. See [`ScopePolicy`].
    #[serde(default)]
    pub scope: ScopePolicy,
    /// Strict mode (proof TC-7-adjacent). When `true` (default), a
    /// resource that omits its `tags:` field is a load-time error.
    /// When `false`, omitted `tags:` defaults to `∅` with a warning.
    #[serde(default = "default_true")]
    pub strict: bool,
    /// Required to be `true` if the deployment intentionally sets
    /// `default_clearance` to the full universe (admit-all). Absent
    /// the flag, such a configuration is rejected at load time.
    #[serde(default)]
    pub unsafe_default_clearance_top: bool,
    /// `λ` for the user's input prompt. Empty list (`∅`) by default.
    #[serde(default)]
    pub user_input_tags: Vec<String>,
    /// `μ` for the user-output channel. Empty list (`∅`, fail-closed)
    /// by default — only public data leaves to the user unless
    /// explicitly opted in.
    #[serde(default)]
    pub user_output_clearance: Vec<String>,
    /// Default `μ` for resources that omit `clearance:`. Empty list
    /// (`∅`, fail-closed) by default.
    #[serde(default)]
    pub default_clearance: Vec<String>,
    /// Default `ν` for resources that omit `audience:`. Empty list
    /// (`∅` — publicly observable) by default. Conservative for
    /// confidentiality: TC-8 / TC-9 then bite hard, forcing explicit
    /// declarations on any sink that should accept tagged data.
    #[serde(default)]
    pub default_audience: Vec<String>,
}

impl Default for IfcSpec {
    fn default() -> Self {
        Self {
            tags: Vec::new(),
            scope: ScopePolicy::default(),
            strict: true,
            unsafe_default_clearance_top: false,
            user_input_tags: Vec::new(),
            user_output_clearance: Vec::new(),
            default_clearance: Vec::new(),
            default_audience: Vec::new(),
        }
    }
}

fn default_true() -> bool {
    true
}

// ── Compiled config ────────────────────────────────────────────────

/// Compiled IFC config attached to the merged runtime config. All
/// tag references have been resolved against the tag universe; all
/// invariants per the proof's TC-1, TC-7 are enforced; TC-8 / TC-9
/// are enforced separately by `merge_chain` because they require
/// access to all resources.
#[derive(Debug, Clone, Default)]
pub struct CompiledIfc {
    /// The closed tag universe.
    pub universe: TagUniverse,
    /// Reset boundary for the running exposure.
    pub scope: ScopePolicy,
    /// Strict mode (see [`IfcSpec::strict`]).
    pub strict: bool,
    /// Resolved `λ(user_input)`.
    pub user_input_tags: TagSet,
    /// Resolved `μ(user_output)`.
    pub user_output_clearance: TagSet,
    /// Resolved default `μ` for unspecified sink clearances.
    pub default_clearance: TagSet,
    /// Resolved default `ν` for unspecified sink audiences.
    pub default_audience: TagSet,
}

impl CompiledIfc {
    /// Compile an `IfcSpec` against a freshly-built tag universe.
    /// Validates that every named tag refers to a declared entry;
    /// enforces TC-7 (`unsafe_default_clearance_top` required for
    /// admit-all default).
    pub fn from_spec(spec: IfcSpec, loc: SourceLoc) -> std::result::Result<Self, ConfigError> {
        // Empty universe → trivial / disabled IFC.
        if spec.tags.is_empty() {
            // If any of the other fields reference tags, that's an
            // unambiguous misconfig — but we surface that via the
            // resolve calls below, which will fail because the
            // universe has no declared names.
            if !spec.user_input_tags.is_empty()
                || !spec.user_output_clearance.is_empty()
                || !spec.default_clearance.is_empty()
                || !spec.default_audience.is_empty()
            {
                return Err(ConfigError::Schema {
                    loc,
                    message: "ifc: `tags:` is empty but other ifc.* fields reference tags. \
                        Either declare an `ifc.tags` universe or remove the references."
                        .into(),
                });
            }
            return Ok(Self::default());
        }

        let universe = TagUniverse::from_names(spec.tags, loc.clone())?;

        let user_input_tags =
            universe.resolve(&spec.user_input_tags, loc.clone(), "ifc.user_input_tags")?;
        let user_output_clearance = universe.resolve(
            &spec.user_output_clearance,
            loc.clone(),
            "ifc.user_output_clearance",
        )?;
        let default_clearance = universe.resolve(
            &spec.default_clearance,
            loc.clone(),
            "ifc.default_clearance",
        )?;
        let default_audience =
            universe.resolve(&spec.default_audience, loc.clone(), "ifc.default_audience")?;

        // TC-7 enforcement: default_clearance == full universe is
        // unsafe and requires the explicit unsafe flag.
        if default_clearance == universe.full() && !spec.unsafe_default_clearance_top {
            return Err(ConfigError::Schema {
                loc,
                message: "ifc.default_clearance: setting the default sink clearance to admit \
                    all tags is dangerous (proof TC-7). Set \
                    `ifc.unsafe_default_clearance_top: true` to acknowledge."
                    .into(),
            });
        }

        Ok(Self {
            universe,
            scope: spec.scope,
            strict: spec.strict,
            user_input_tags,
            user_output_clearance,
            default_clearance,
            default_audience,
        })
    }

    /// `true` when no tag universe was declared (effectively disabled).
    pub fn is_disabled(&self) -> bool {
        self.universe.is_disabled()
    }

    /// Resolve a YAML `tags: [...]` field against the universe, with
    /// strict-mode handling for omitted fields. `field_path` is used
    /// for error messages.
    pub fn resolve_resource_tags(
        &self,
        names: Option<&[String]>,
        loc: SourceLoc,
        field_path: &str,
    ) -> std::result::Result<TagSet, ConfigError> {
        match names {
            Some(n) => self.universe.resolve(n, loc, field_path),
            None => {
                if self.strict {
                    Err(ConfigError::Schema {
                        loc,
                        message: format!(
                            "{field_path}: missing `tags:` field. In strict mode every \
                            resource must declare its tag set explicitly (use `tags: []` \
                            for known-public sources). Set `ifc.strict: false` to demote \
                            this to a runtime warning."
                        ),
                    })
                } else {
                    log::warn!(
                        target: "agent_shield::ifc",
                        "{field_path}: missing `tags:` field; defaulting to ∅. \
                        Consider enabling `ifc.strict: true` to enforce explicit declarations."
                    );
                    Ok(TagSet::EMPTY)
                }
            }
        }
    }

    /// Resolve a YAML `clearance: [...]` field against the universe.
    /// Falls back to `default_clearance` when absent.
    pub fn resolve_resource_clearance(
        &self,
        names: Option<&[String]>,
        loc: SourceLoc,
        field_path: &str,
    ) -> std::result::Result<TagSet, ConfigError> {
        match names {
            Some(n) => self.universe.resolve(n, loc, field_path),
            None => Ok(self.default_clearance),
        }
    }

    /// Resolve a YAML `audience: [...]` field against the universe.
    /// Falls back to `default_audience` when absent.
    pub fn resolve_resource_audience(
        &self,
        names: Option<&[String]>,
        loc: SourceLoc,
        field_path: &str,
    ) -> std::result::Result<TagSet, ConfigError> {
        match names {
            Some(n) => self.universe.resolve(n, loc, field_path),
            None => Ok(self.default_audience),
        }
    }
}

// ── Tests ──────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    fn loc() -> SourceLoc {
        SourceLoc::default()
    }

    fn universe_4() -> TagUniverse {
        TagUniverse::from_names(
            vec![
                "pii".into(),
                "financial".into(),
                "source_code".into(),
                "internal".into(),
            ],
            loc(),
        )
        .unwrap()
    }

    #[test]
    fn empty_universe_is_disabled() {
        let u = TagUniverse::default();
        assert!(u.is_disabled());
        assert_eq!(u.full(), TagSet::EMPTY);
    }

    #[test]
    fn universe_assigns_bits_in_declaration_order() {
        let u = universe_4();
        assert_eq!(u.bit_of("pii"), Some(0));
        assert_eq!(u.bit_of("financial"), Some(1));
        assert_eq!(u.bit_of("source_code"), Some(2));
        assert_eq!(u.bit_of("internal"), Some(3));
        assert_eq!(u.bit_of("unknown"), None);
    }

    #[test]
    fn rejects_duplicate_tag() {
        let err = TagUniverse::from_names(vec!["pii".into(), "pii".into()], loc()).unwrap_err();
        assert!(err.to_string().contains("duplicate tag name"));
    }

    #[test]
    fn rejects_empty_name() {
        let err = TagUniverse::from_names(vec!["".into()], loc()).unwrap_err();
        assert!(err.to_string().contains("non-empty string"));
    }

    #[test]
    fn rejects_wildcard_as_tag_name() {
        let err = TagUniverse::from_names(vec!["*".into()], loc()).unwrap_err();
        assert!(err.to_string().contains("reserved as wildcard"));
    }

    #[test]
    fn rejects_too_many_tags() {
        let names: Vec<String> = (0..MAX_TAGS + 1).map(|i| format!("t{i}")).collect();
        let err = TagUniverse::from_names(names, loc()).unwrap_err();
        assert!(err.to_string().contains("too many tags"));
    }

    #[test]
    fn full_universe_has_all_bits_set() {
        let u = universe_4();
        assert_eq!(u.full(), TagSet::from_bits(vec![0, 1, 2, 3]));
        assert_eq!(u.full().len(), 4);
    }

    #[test]
    fn resolve_named_tags() {
        let u = universe_4();
        let s = u
            .resolve(&["pii".to_string(), "financial".to_string()], loc(), "test")
            .unwrap();
        assert_eq!(s, TagSet::from_bits(vec![0, 1]));
    }

    #[test]
    fn resolve_wildcard_sugar() {
        let u = universe_4();
        let s = u.resolve(&["*".to_string()], loc(), "test").unwrap();
        assert_eq!(s, u.full());
    }

    #[test]
    fn resolve_unknown_tag_errors() {
        let u = universe_4();
        let err = u
            .resolve(&["sekret".to_string()], loc(), "test")
            .unwrap_err();
        assert!(err.to_string().contains("not declared in ifc.tags"));
    }

    #[test]
    fn resolve_wildcard_with_other_tags_errors() {
        let u = universe_4();
        let err = u
            .resolve(&["*".to_string(), "pii".to_string()], loc(), "test")
            .unwrap_err();
        assert!(err.to_string().contains("single-element list"));
    }

    #[test]
    fn names_of_renders_in_declaration_order() {
        let u = universe_4();
        let s = TagSet::from_bits(vec![3, 0, 1]); // out-of-order construction
        assert_eq!(
            u.names_of(s),
            vec![
                "pii".to_string(),
                "financial".to_string(),
                "internal".to_string()
            ]
        );
    }

    #[test]
    fn tagset_is_subset() {
        let a = TagSet::from_bits(vec![0, 1]);
        let b = TagSet::from_bits(vec![0, 1, 2]);
        assert!(a.is_subset(b));
        assert!(!b.is_subset(a));
        assert!(TagSet::EMPTY.is_subset(a));
        assert!(a.is_subset(a));
    }

    #[test]
    fn tagset_union() {
        let a = TagSet::from_bits(vec![0, 1]);
        let b = TagSet::from_bits(vec![1, 2]);
        assert_eq!(a.union(b), TagSet::from_bits(vec![0, 1, 2]));
    }

    #[test]
    fn tagset_intersect() {
        let a = TagSet::from_bits(vec![0, 1]);
        let b = TagSet::from_bits(vec![1, 2]);
        assert_eq!(a.intersect(b), TagSet::from_bits(vec![1]));
    }

    #[test]
    fn compiled_ifc_default_is_disabled() {
        let c = CompiledIfc::default();
        assert!(c.is_disabled());
        assert_eq!(c.user_input_tags, TagSet::EMPTY);
        assert_eq!(c.default_clearance, TagSet::EMPTY);
    }

    #[test]
    fn compile_minimal_spec() {
        let spec = IfcSpec {
            tags: vec!["pii".into(), "financial".into()],
            ..Default::default()
        };
        let c = CompiledIfc::from_spec(spec, loc()).unwrap();
        assert!(!c.is_disabled());
        assert!(c.strict);
        assert_eq!(c.universe.len(), 2);
        assert_eq!(c.user_input_tags, TagSet::EMPTY);
        assert_eq!(c.default_clearance, TagSet::EMPTY);
        assert_eq!(c.default_audience, TagSet::EMPTY);
    }

    #[test]
    fn compile_resolves_tag_references() {
        let spec = IfcSpec {
            tags: vec!["pii".into(), "internal".into()],
            user_input_tags: vec!["pii".into()],
            user_output_clearance: vec!["internal".into()],
            ..Default::default()
        };
        let c = CompiledIfc::from_spec(spec, loc()).unwrap();
        assert_eq!(c.user_input_tags, TagSet::from_bits(vec![0]));
        assert_eq!(c.user_output_clearance, TagSet::from_bits(vec![1]));
    }

    #[test]
    fn compile_rejects_unknown_tag_in_default() {
        let spec = IfcSpec {
            tags: vec!["pii".into()],
            default_clearance: vec!["secret".into()],
            ..Default::default()
        };
        let err = CompiledIfc::from_spec(spec, loc()).unwrap_err();
        assert!(err.to_string().contains("not declared in ifc.tags"));
    }

    #[test]
    fn compile_rejects_admit_all_default_without_unsafe_flag() {
        let spec = IfcSpec {
            tags: vec!["pii".into(), "internal".into()],
            default_clearance: vec!["*".into()],
            unsafe_default_clearance_top: false,
            ..Default::default()
        };
        let err = CompiledIfc::from_spec(spec, loc()).unwrap_err();
        assert!(err.to_string().contains("unsafe_default_clearance_top"));
    }

    #[test]
    fn compile_admits_admit_all_default_with_unsafe_flag() {
        let spec = IfcSpec {
            tags: vec!["pii".into(), "internal".into()],
            default_clearance: vec!["*".into()],
            unsafe_default_clearance_top: true,
            ..Default::default()
        };
        let c = CompiledIfc::from_spec(spec, loc()).unwrap();
        assert_eq!(c.default_clearance, c.universe.full());
    }

    #[test]
    fn compile_rejects_tag_references_with_empty_universe() {
        let spec = IfcSpec {
            tags: vec![],
            user_input_tags: vec!["pii".into()],
            ..Default::default()
        };
        let err = CompiledIfc::from_spec(spec, loc()).unwrap_err();
        assert!(err.to_string().contains("tags:` is empty"));
    }

    #[test]
    fn resolve_resource_tags_strict_rejects_omitted() {
        let c = CompiledIfc::from_spec(
            IfcSpec {
                tags: vec!["pii".into()],
                strict: true,
                ..Default::default()
            },
            loc(),
        )
        .unwrap();
        let err = c
            .resolve_resource_tags(None, loc(), "resources.tools[0]")
            .unwrap_err();
        assert!(err.to_string().contains("missing `tags:`"));
    }

    #[test]
    fn resolve_resource_tags_lenient_accepts_omitted() {
        let c = CompiledIfc::from_spec(
            IfcSpec {
                tags: vec!["pii".into()],
                strict: false,
                ..Default::default()
            },
            loc(),
        )
        .unwrap();
        let s = c
            .resolve_resource_tags(None, loc(), "resources.tools[0]")
            .unwrap();
        assert_eq!(s, TagSet::EMPTY);
    }

    #[test]
    fn resolve_resource_clearance_falls_back_to_default() {
        let c = CompiledIfc::from_spec(
            IfcSpec {
                tags: vec!["pii".into(), "internal".into()],
                default_clearance: vec!["internal".into()],
                ..Default::default()
            },
            loc(),
        )
        .unwrap();
        let s = c
            .resolve_resource_clearance(None, loc(), "resources.tools[0]")
            .unwrap();
        assert_eq!(s, TagSet::from_bits(vec![1]));
    }
}
