//! Observability subsystem (`spec/SPECIFICATION.md` §19).
//!
//! Public surface:
//!
//! - [`ShieldLogEvent`] — strictly typed log event payload (§19.2).
//! - [`Severity`], [`EventType`], [`Stage`], [`Action`], [`ResourceKind`],
//!   [`ResourceRef`] — the closed enums and value types referenced from
//!   [`ShieldLogEvent`].
//! - [`AgentShieldAttributes`] — typed builder over the
//!   `agent_shield.*` semantic-attribute namespace (§19.3).
//! - [`ObservabilityProvider`] — provider trait (sync).
//! - [`ObservabilityDispatcher`] — fan-out dispatcher that subscribes
//!   to the [`crate::event_bus::EventBus`] and bridges every
//!   [`crate::event_bus::BusEvent`] into the log stream per §19.5.
//! - The `log_*` helpers in [`emitter`] — canonical builders for the
//!   §19.5 events the host runtime triggers manually (gating verdicts,
//!   resolver invocations, load errors, warn-mode surfacing).

pub mod attributes;
pub mod dispatcher;
pub mod emitter;
pub mod event;
pub mod provider;

#[cfg(test)]
pub(crate) mod test_support;

pub use attributes::{
    AgentShieldAttributes, GENAI_SYSTEM_AGENT_SHIELD, KEY_ACTION, KEY_AGENT_ID, KEY_CATEGORY,
    KEY_CONFIG_NAME, KEY_CONFIG_VERSION, KEY_CORRELATION_ID, KEY_EVALUATE_WHEN_INDEX,
    KEY_EVENT_CAUSE, KEY_EVENT_ID, KEY_EVENT_LIFETIME, KEY_EVENT_REFRESHED, KEY_EVENT_TYPE,
    KEY_GENAI_OPERATION_NAME, KEY_GENAI_RESPONSE_FINISH_REASON, KEY_GENAI_SYSTEM, KEY_GUARD_POLICY,
    KEY_GUARD_POLICY_ALLOWED_WHEN_BYPASSED, KEY_GUARD_POLICY_EVALUATE_WHEN_INDEX,
    KEY_GUARD_POLICY_NAME, KEY_GUARD_POLICY_REASON, KEY_LOAD_FILE, KEY_LOAD_MESSAGE, KEY_MESSAGE,
    KEY_REASON, KEY_RESOLVER_DECISION, KEY_RESOLVER_ERROR, KEY_RESOLVER_KIND,
    KEY_RESOLVER_LATENCY_MS, KEY_RESOLVER_VARIABLE, KEY_RESOURCE_KIND, KEY_RESOURCE_NAME,
    KEY_RESOURCE_TOOL_ALIAS, KEY_SESSION_ID, KEY_SEVERITY, KEY_STAGE, KEY_TENANT_ID, KEY_USER_ID,
    KEY_VARIABLE_NAME, KEY_VARIABLE_STATUS, KEY_VARIABLE_VALUE, KNOWN_GENAI_KEYS, KNOWN_KEYS,
};
pub use dispatcher::{bus_event_to_log_event, ObservabilityDispatcher};
pub use emitter::{
    log_classifier_called, log_gating_verdict, log_guard_policy_evaluation, log_llm_called,
    log_load_error, log_policy_evaluated, log_resolver_invoked, log_resolver_invoked_full,
    log_stage_evaluated, log_warning,
};
pub use event::{
    Action, EventType, LogAction, ResourceKind, ResourceRef, Severity, ShieldLogEvent, Stage,
};
pub use provider::ObservabilityProvider;
