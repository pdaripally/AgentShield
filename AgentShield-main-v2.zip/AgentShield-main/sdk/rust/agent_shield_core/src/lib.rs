//! # Agent Shield Core
//!
//! Reference Rust implementation of the Agent Shield
//! unified-resolver / unified-guard-policy contract from
//! `spec/SPECIFICATION.md`.
//!
//! This crate is the canonical core: parser/evaluator, event bus, lifetime
//! tracker, resolver runtime, guard-policy engine, observability dispatcher,
//! and host-facing runtime API. The Python, Node, and .NET SDKs all wrap
//! this core through PyO3, napi-rs, and a C ABI respectively.
//!
//! # Quick Start
//!
//! See `tests/runtime.rs` and `tests/smoke.rs` for end-to-end usage
//! examples against the public API.

#![allow(clippy::result_large_err)]

// ── Module declarations ─────────────────────────────────────────────

pub mod expressions {
    pub mod ast;
    pub mod eval;
    pub mod extensions;
    pub mod parser;
    pub mod tokenizer;

    mod builtins;
}

pub mod clock;
pub mod config;
pub mod configurations;
pub mod constants;
pub mod errors;
pub mod event_bus;
pub mod events;
pub mod ffi;
pub mod guard_policy;
pub mod guard_policy_runtime;
pub mod ifc;
pub mod integrations;
pub mod lifetime;
pub mod lifetime_tracker;
pub mod loader;
pub mod merge;
pub mod metadata;
pub mod objective;
pub mod observability;
pub mod perf_telemetry;
pub mod populator;
pub mod predicates;
pub mod resetter;
pub mod resolver;
pub mod resolver_runtime;
pub mod resources;
pub mod runtime;
pub mod session_id;
pub mod shield_primitives;
pub mod update_policy;
pub mod variables;
pub mod wire_shapes;

pub mod approval;

// ── Crate-root re-exports ───────────────────────────────────────────

pub use configurations::{ConfigOnError, ConfigurationType, HttpMethod, ShieldConfiguration};
pub use constants::{
    expressions::{MAX_PREDICATE_DEPTH, MAX_REGEX_LENGTH},
    loader::MAX_EXTENDS_DEPTH,
    merge::MAX_OBJECT_DEPTH,
    resolver::{DEFAULT_TOOL_RETRY_LIMIT, MAX_CHAIN_DEPTH},
    streaming::{DEFAULT_OVERLAP, DEFAULT_WINDOW_SIZE, LOOKBACK_WINDOW, STREAM_BUFFER_MAX_BYTES},
};
pub use errors::{ConfigError, PromptFileErrorKind, Result as ConfigResult, SourceLoc};
pub use event_bus::{BusEvent, ClearCause, EmitError, EventBus, EventFiredHook, SubscriberHandle};
pub use events::{ApprovalEventKind, EventId, EventIdError, GpEventKind, ToolEventKind};
pub use guard_policy::{
    Action, AppliesTo, ClassifierDetection, DetectionKind, EndpointSelector, EvaluateWhenEntry,
    GuardPolicy, LlmDetection, StageFlavor,
};
pub use guard_policy_runtime::{
    applies_to_matches, apply_prepend_append, apply_redactions, detect, ActivationCache,
    ClassifierCaller, ClassifierVerdict, DetectionDeps, DetectionVerdict, EvalRuntime,
    GuardPolicyDeps, GuardPolicyEngine, GuardPolicyRuntimeError, LlmCaller, LlmDecision,
    LlmResponse, RegexCache, SelectorSubject, Span, StageVerdict, StreamChunkAction,
    StreamChunkResult, StreamingGuard,
};
pub use ifc::{CompiledIfc, IfcSpec, ScopePolicy, TagSet, TagUniverse, MAX_TAGS};
pub use lifetime::{parse_duration, BareLifetime, Lifetime, LifetimeBranch, LifetimeMap};
pub use lifetime_tracker::{
    select_branch, LifetimeTracker, PredicateState, ResolverOutcome, TrackerError, VarStatus,
    VariableState,
};
pub use loader::{load_chain, load_from_path, load_from_paths, load_from_str};
pub use merge::{
    apply_env_mode_override, apply_env_mode_override_from, merge_chain, MergedConfig, ParsedFile,
    StageBlock, ENV_MODE_VAR,
};
pub use metadata::{most_restrictive, AgentShieldVersion, Metadata, RUNTIME_SPEC_VERSION};
pub use objective::{GoalList, Objective, ObjectiveFile, ObjectiveTier};
pub use observability::{
    bus_event_to_log_event, log_gating_verdict, log_guard_policy_evaluation, log_load_error,
    log_resolver_invoked, log_resolver_invoked_full, log_warning, AgentShieldAttributes,
    EventType as ObsEventType, LogAction, ObservabilityDispatcher, ObservabilityProvider,
    ResourceKind as ObsResourceKind, ResourceRef, Severity as ObsSeverity, ShieldLogEvent,
    Stage as ObsStage, KEY_RESOLVER_LATENCY_MS,
};
pub use perf_telemetry::PerfTelemetry;
pub use populator::{
    apply_populator, select_populators, DefaultExtractor, Extractor, ExtractorRegistry, Invocation,
    PopulatorError,
};
pub use predicates::{PredicateBody, PredicateEntry, PredicateFileMap, PredicateMap};
pub use resetter::select_resetters;
pub use resolver::{
    AuditConfig, OnError, Resolver, ResolverChainIter, ResolverDecision, ResolverResponse,
};
pub use resolver_runtime::{
    classifier_bool_to_envelope, classifier_score_to_envelope, interpolate_prompt,
    AgentResolveRequest, AgentResolver, AgentResolverFn, AutoResolveAdapter, AutoResolveOutcome,
    DelegateDispatcher, DelegateDispatcherFn, DelegateRequest, DispatchOutcome, GatedResourceRef,
    InterpolationError, PendingResolution, ResolveOutcome, ResolveRequest, ResolverContext,
    ResolverDeps, ResolverDispatcher, ResolverRuntimeError, ToolLoopTracker, ASK_HUMAN_TOOL_NAME,
};
pub use resources::{
    AgentResource, EndpointResource, LogBlock, OnErrorPolicy, Permission, ResourcesBlock,
    ToolResource,
};
pub use runtime::{
    make_configuration_caller, synthetic_tool_call_id, ConfigurationCaller,
    DefaultDelegateDispatcher, FailClosedLlmCaller, GuardrailsRuntime, GuardrailsSession,
    InvocationTarget, RequestContext, RuntimeBuilder, RuntimeError, StreamingOptions,
    ToolAdmission,
};
pub use session_id::SessionId;
pub use shield_primitives::{
    dispatch_outcome_to_wire, dispatch_stage_verdict, dispatch_tool_verdict, format_block_message,
    format_tool_block_message, resolve_on_block, stage_verdict_from_wire,
    tool_dispatch_outcome_to_wire, DispatchAction, OnBlockOutcome, OnBlockPolicy, RuntimeMode,
    ShieldMode, ToolDispatchAction, ToolStage, ToolVerdictDispatch, VerdictDispatch,
};
pub use update_policy::{apply_update, UpdateError};
pub use variables::{Phase, PopulatorEntry, ResetEntry, ResourceKind, Variable, VariableType};
pub use wire_shapes::{
    parse_classifier_verdict_json, parse_extractor_output_json, parse_llm_response_json,
    parse_resolver_response_json, resolver_decision_str as wire_resolver_decision_str,
    serialize_agent_request_json, serialize_delegate_request_json,
};

/// Re-export of the composable [`config::GuardrailsConfig`] builder
/// at the crate root for ergonomic public use.
pub use config::{CompiledPolicy, GuardrailsConfig, Layer};

#[cfg(feature = "http")]
pub mod classifiers;
