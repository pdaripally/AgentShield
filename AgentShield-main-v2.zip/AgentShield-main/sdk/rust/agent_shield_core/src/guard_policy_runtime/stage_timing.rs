//! Per-stage timing wrapper used by every per-stage runner.
//!
//! Lives behind [`crate::perf_telemetry::PerfTelemetry::Full`] —
//! `Off` and `External` short-circuit the emission entirely, leaving
//! the verdict path byte-identical (AC7 / AC8 in the v8 plan).
//!
//! The helper deliberately owns the gating decision (rather than each
//! stage runner re-checking `PerfTelemetry`) so the §19.x contract
//! lives in exactly one place — adding a fourth telemetry level later
//! is a single-file edit.

use crate::clock::Clock;
use crate::observability::{log_stage_evaluated, ObservabilityDispatcher, Stage};
use crate::perf_telemetry::PerfTelemetry;

use super::StageVerdict;

/// Per-stage timing context captured from the engine's [`GuardPolicyDeps`].
/// Stage runners construct one of these as the first statement of
/// `evaluate(...)`; the [`Drop`]-style [`emit`] call seals it.
///
/// We model it as a plain struct (not a guard with `Drop`) because the
/// stage runner needs to read its own `StageVerdict` *and* the
/// surrounding `session_id` / `correlation_id` to stamp on the
/// `StageEvaluated` event — none of which are easy to thread into a
/// `Drop` impl. Keeping the call explicit also matches the existing
/// `emit_stage_verdict` pattern in [`super::stage_common`].
///
/// [`GuardPolicyDeps`]: super::GuardPolicyDeps
pub struct StageMetrics {
    start: Option<std::time::Instant>,
}

impl StageMetrics {
    /// Capture a start timestamp if (and only if) [`PerfTelemetry`]
    /// gates stage events on (i.e. [`PerfTelemetry::Full`]). At
    /// `Off` / `External` this is a no-op and the helper holds
    /// `None`; the matching [`emit`] call then short-circuits.
    pub fn start(clock: &dyn Clock, perf_telemetry: PerfTelemetry) -> Self {
        let start = if perf_telemetry.emit_stage_events() {
            Some(clock.now())
        } else {
            None
        };
        Self { start }
    }

    /// Seal the timing window and emit a [`crate::observability::EventType::StageEvaluated`]
    /// perf event. Calling this with a [`StageMetrics`] that was
    /// constructed at `Off` / `External` is a no-op (the gating
    /// already decided not to emit).
    ///
    /// The `verdict` argument is currently unused but kept on the
    /// signature so a future revision (e.g. stamping the verdict
    /// outcome onto the perf event for failure-attribution dashboards)
    /// doesn't require touching every stage runner again.
    #[allow(clippy::too_many_arguments)]
    pub fn emit(
        self,
        clock: &dyn Clock,
        dispatcher: &ObservabilityDispatcher,
        session_id: &str,
        correlation_id: &str,
        stage: Stage,
        _verdict: &StageVerdict,
    ) {
        let Some(start) = self.start else {
            return;
        };
        let elapsed_ms = clock.now().duration_since(start).as_millis() as u64;
        log_stage_evaluated(dispatcher, session_id, correlation_id, stage, elapsed_ms);
    }
}

/// Per-stage timing wrapper. The closure receives no arguments and
/// returns a [`StageVerdict`]; this helper measures wall-clock time
/// around the closure and emits a `StageEvaluated` perf event when
/// [`PerfTelemetry::Full`] is active. Stage runners construct one
/// `time_stage` call as the body of their public `evaluate(...)`.
///
/// Keeping the wrapper as a free function (rather than inlining
/// `StageMetrics::start` / `emit` calls per stage runner) means the
/// PR6 gating contract lives in exactly one place — adding new
/// telemetry levels or a fourth correlation field is a single-file
/// edit.
///
/// # Panic behaviour
///
/// If `body()` panics, [`StageMetrics`] is dropped via unwinding
/// without [`StageMetrics::emit`] running, so a panicking stage
/// produces no `StageEvaluated` event. This is **deliberate**, not an
/// oversight — do not "fix" it by adding a `Drop` impl that emits on
/// unwind.
///
/// 1. A `StageEvaluated` emitted at the panic point would record a
///    `KEY_DURATION_MS` of "time-until-crash" mixed into the same
///    histogram bucket as successful completions. Adopters using
///    p50 / p99 for SLO dashboards would see panic-time corrupt the
///    completion-time signal.
/// 2. Stage panics are unrecoverable bugs; the FFI boundary catches
///    the unwind and the `gating_verdict` event already surfaces the
///    failure path. Perf telemetry deliberately reports only on
///    paths that completed.
/// 3. Adding a `Drop` impl would also require restructuring
///    [`StageMetrics`] to own the dispatcher + correlation context
///    (it currently borrows them), which is a non-trivial refactor
///    for a signal that explicitly should not fire on this path.
#[allow(clippy::too_many_arguments)]
pub fn time_stage<F: FnOnce() -> StageVerdict>(
    clock: &dyn Clock,
    dispatcher: &ObservabilityDispatcher,
    perf_telemetry: PerfTelemetry,
    session_id: &str,
    correlation_id: &str,
    stage: Stage,
    body: F,
) -> StageVerdict {
    let metrics = StageMetrics::start(clock, perf_telemetry);
    let verdict = body();
    metrics.emit(
        clock,
        dispatcher,
        session_id,
        correlation_id,
        stage,
        &verdict,
    );
    verdict
}

#[cfg(test)]
mod tests {
    use std::sync::Arc;
    use std::time::Duration;

    use super::*;
    use crate::clock::mock::MockClock;
    use crate::event_bus::EventBus;
    use crate::observability::attributes::{KEY_DURATION_MS, KEY_EVENT_TYPE, KEY_STAGE};
    use crate::observability::test_support::CaptureProvider;
    use crate::observability::EventType;
    use serde_json::Value;

    fn fixtures() -> (
        Arc<ObservabilityDispatcher>,
        Arc<CaptureProvider>,
        MockClock,
    ) {
        let bus = EventBus::new();
        let dispatcher = ObservabilityDispatcher::new(bus);
        let provider = CaptureProvider::new();
        dispatcher.register_provider(provider.clone());
        (dispatcher, provider, MockClock::new())
    }

    fn passing_verdict() -> StageVerdict {
        StageVerdict::allow()
    }

    #[test]
    fn full_telemetry_emits_one_stage_evaluated_event() {
        let (dispatcher, provider, clock) = fixtures();

        let metrics = StageMetrics::start(&clock, PerfTelemetry::Full);
        clock.advance(Duration::from_millis(7));
        metrics.emit(
            &clock,
            &dispatcher,
            "sess-1",
            "corr-1",
            Stage::Input,
            &passing_verdict(),
        );

        let events = provider.events.lock().unwrap();
        let perf: Vec<_> = events
            .iter()
            .filter(|e| matches!(e.event_type, EventType::StageEvaluated))
            .collect();
        assert_eq!(perf.len(), 1, "expected exactly one StageEvaluated event");
        let ev = perf[0];
        assert_eq!(ev.session_id.as_str(), "sess-1");
        assert_eq!(ev.correlation_id.as_str(), "corr-1");
        assert_eq!(
            ev.attributes.get(KEY_DURATION_MS),
            Some(&Value::from(7u64)),
            "KEY_DURATION_MS must equal the MockClock advance value (deterministic)"
        );
        assert_eq!(
            ev.attributes.get(KEY_STAGE).and_then(|v| v.as_str()),
            Some("input")
        );
        assert_eq!(
            ev.attributes.get(KEY_EVENT_TYPE).and_then(|v| v.as_str()),
            Some("stage_evaluated")
        );
    }

    #[test]
    fn external_telemetry_emits_zero_stage_events() {
        let (dispatcher, provider, clock) = fixtures();
        let metrics = StageMetrics::start(&clock, PerfTelemetry::External);
        clock.advance(Duration::from_millis(50));
        metrics.emit(
            &clock,
            &dispatcher,
            "sess-1",
            "corr-1",
            Stage::Input,
            &passing_verdict(),
        );
        let events = provider.events.lock().unwrap();
        assert!(
            !events
                .iter()
                .any(|e| matches!(e.event_type, EventType::StageEvaluated)),
            "External must NOT emit StageEvaluated — only LLM / classifier"
        );
    }

    #[test]
    fn off_telemetry_emits_zero_stage_events() {
        let (dispatcher, provider, clock) = fixtures();
        let metrics = StageMetrics::start(&clock, PerfTelemetry::Off);
        clock.advance(Duration::from_millis(100));
        metrics.emit(
            &clock,
            &dispatcher,
            "",
            "",
            Stage::Output,
            &passing_verdict(),
        );
        let events = provider.events.lock().unwrap();
        assert!(
            !events
                .iter()
                .any(|e| matches!(e.event_type, EventType::StageEvaluated)),
            "Off must emit zero perf events (AC7)"
        );
    }
}
