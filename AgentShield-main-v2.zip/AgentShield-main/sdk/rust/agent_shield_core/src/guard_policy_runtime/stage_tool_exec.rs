//! Stage 3 — `tool_execution_validation` runner (§16).
//!
//! Subject: the proposed call's parameters (`Invocation.params`).
//! `applies_to:` is optional. All detection kinds are accepted; all action
//! modes are accepted (`block` / `redact` / `warn` / `append` / `prepend`).
//!
//! **Stage-3 transforms execute on the transformed invocation** (§16.3 /
//! §12.10 step 5c). The runner mutates `invocation.params` in place; the
//! host runtime (P9) reads the post-call invocation directly.

use std::collections::HashMap;
use std::sync::Mutex;

use crate::guard_policy::Action;
use crate::observability::Stage;
use crate::populator::Invocation;
use crate::resolver_runtime::AutoResolveAdapter;

use super::detection::Span;
use super::evaluate_when::run_evaluate_when;
use super::runtime_hooks::{PredicateMapLookup, SessionScopedEventFired, TrackerStatusLookup};
use super::selector::applies_to_matches;
use super::stage_common::{
    bind_resolved_variables_in, block_verdict, build_allowed_when_deps_with_event_hook,
    build_detection_deps_with_event_hook, emit_stage_verdict, log_outcome_in, ResolverHookHolder,
};
use super::transforms::{apply_invocation_transforms, read_string_at_path};
use super::{bind_invocation_into, EvalRuntime, GuardPolicyEngine, StageVerdict};
use crate::session_id::SessionId;

pub(crate) fn evaluate(
    engine: &GuardPolicyEngine,
    invocation: &mut Invocation,
    ctx: &EvalRuntime<'_>,
) -> StageVerdict {
    super::stage_timing::time_stage(
        engine.deps().clock.as_ref(),
        engine.deps().observability.as_ref(),
        engine.deps().perf_telemetry,
        ctx.session_id,
        ctx.correlation_id,
        Stage::ToolExecution,
        || evaluate_inner(engine, invocation, ctx),
    )
}

fn evaluate_inner(
    engine: &GuardPolicyEngine,
    invocation: &mut Invocation,
    ctx: &EvalRuntime<'_>,
) -> StageVerdict {
    let invocation_hash_before = invocation.canonical_hash();
    let session_id = SessionId::new(ctx.session_id);
    let policies = &engine
        .deps()
        .config
        .tool_execution_validation
        .guard_policies;
    let mut attrs = ctx.build_base_attrs();
    bind_resolved_variables_in(
        &session_id,
        &mut attrs,
        engine.deps().tracker.as_ref(),
        &engine.deps().config.variables,
    );
    bind_invocation_into(&mut attrs, invocation);

    let status_lookup =
        TrackerStatusLookup::new_in(engine.deps().tracker.as_ref(), session_id.clone());
    let pred_lookup = PredicateMapLookup::new(&engine.deps().config.predicates);
    let resolver_holder = ResolverHookHolder {
        adapter: AutoResolveAdapter::new_in(
            engine.deps().resolver.as_ref(),
            attrs.clone(),
            session_id.clone(),
        )
        .with_invocation(invocation.clone()),
        trace: Mutex::new(Vec::new()),
    };
    let resolver_hook: &dyn crate::expressions::eval::ResolverHook = &resolver_holder;
    let event_fired_hook =
        SessionScopedEventFired::new(&engine.deps().event_bus, session_id.clone());
    let subject_kind_owned = match invocation.kind {
        crate::variables::ResourceKind::Tool => {
            let n = invocation.name.clone().unwrap_or_default();
            (0u8, n, String::new(), String::new())
        }
        crate::variables::ResourceKind::Agent => {
            let n = invocation.name.clone().unwrap_or_default();
            (1u8, n, String::new(), String::new())
        }
        crate::variables::ResourceKind::Endpoint => (
            2u8,
            String::new(),
            invocation.method.clone().unwrap_or_default(),
            invocation.uri.clone().unwrap_or_default(),
        ),
    };
    let mut last_action: Option<Action> = None;
    let mut transformed = false;
    let mut bypassed = false;

    for policy in policies {
        let subject_kind = match subject_kind_owned.0 {
            0 => super::SelectorSubject::Tool {
                name: &subject_kind_owned.1,
            },
            1 => super::SelectorSubject::Agent {
                name: &subject_kind_owned.1,
            },
            _ => super::SelectorSubject::Endpoint {
                method: &subject_kind_owned.2,
                uri: &subject_kind_owned.3,
            },
        };
        if !applies_to_matches(policy.applies_to.as_ref(), &subject_kind) {
            continue;
        }
        let active = engine.activation().evaluate_and_emit_in(
            &session_id,
            &policy.name,
            policy.active_if.as_deref(),
            &attrs,
            Some(&pred_lookup as &dyn crate::expressions::eval::PredicateLookup),
            Some(&event_fired_hook as &dyn crate::expressions::eval::EventFiredHook),
            &engine.deps().event_bus,
        );
        if !active {
            continue;
        }

        if policy.evaluate_when.is_empty() {
            let reason = policy
                .reason
                .clone()
                .unwrap_or_else(|| format!("guard policy `{}` blocked", policy.name));
            let v = StageVerdict::block(&policy.name, reason, None)
                .with_pending_resolution(resolver_holder.adapter.take_pending())
                .with_invocation_hashes(
                    invocation_hash_before.clone(),
                    invocation.canonical_hash(),
                );
            let _ = engine
                .deps()
                .event_bus
                .emit_guard_policy_failed_in(&session_id, policy.name.clone());
            emit_stage_verdict(engine, &session_id, Stage::ToolExecution, &v);
            return v;
        }

        // Subject for content detection: a flattened concatenation of
        // every string-valued leaf inside `params` (§16, §12.10). Joining
        // only string VALUES (not keys, not JSON punctuation) prevents
        // false-positive pattern matches against quoted keys, escapes,
        // and structural characters that exist only in the JSON
        // serialization. Path-aware redaction in `build_path_redactions`
        // separately re-scans each string field, so redact-mode still
        // mutates the right field.
        let subject_text = collect_param_string_values(&invocation.params);

        let ddeps = build_detection_deps_with_event_hook(
            engine,
            ctx,
            &attrs,
            Some(&status_lookup),
            Some(&pred_lookup),
            Some(resolver_hook),
            Some(&event_fired_hook as &dyn crate::expressions::eval::EventFiredHook),
            // §16.1 — Stage 3 binds the full canonical + stage-specific
            // template-variable set: `{tool_name}`, `{tool_params}`,
            // `{tool_permission}`, `{tool_description}`, `{variables}`,
            // `{active_guard_policies}`, `{prior_checks_summary}`, plus
            // resource-shape vars for endpoint/agent invocations.
            stage_tool_exec_template_vars(invocation, ctx, engine.deps().config.as_ref()),
            // §16.2 — append the Default-Implementation Runtime Context
            // block to every Stage-3 LLM-detection prompt.
            true,
            Stage::ToolExecution,
        );
        let aw_deps = build_allowed_when_deps_with_event_hook(
            engine,
            &attrs,
            Some(&status_lookup),
            Some(&pred_lookup),
            Some(resolver_hook),
            Some(&event_fired_hook as &dyn crate::expressions::eval::EventFiredHook),
        );
        let outcome = run_evaluate_when(policy, &subject_text, &ddeps, &aw_deps);
        log_outcome_in(&session_id, engine, Stage::ToolExecution, policy, &outcome);

        if outcome.allowed_when_bypass_fired {
            bypassed = true;
        }

        if let Some(b) = &outcome.block {
            let v = block_verdict(policy, b)
                .with_pending_resolution(resolver_holder.adapter.take_pending())
                .with_invocation_hashes(
                    invocation_hash_before.clone(),
                    invocation.canonical_hash(),
                );
            emit_stage_verdict(engine, &session_id, Stage::ToolExecution, &v);
            return v;
        }

        // Apply transforms to the invocation. We need to map redaction
        // spans (which were computed against the JSON-serialized
        // subject) to dotted paths inside the params. For safety and
        // determinism, we re-scan each path's string value with the
        // entry's regex and produce per-path spans there.
        if !outcome.redactions.is_empty() {
            let path_redactions =
                build_path_redactions(invocation, policy, &outcome.redactions_by_entry);
            apply_invocation_transforms(invocation, &path_redactions, &[], &[]);
            // Re-bind invocation attrs after mutation so subsequent
            // policies see the transformed params.
            bind_invocation_into(&mut attrs, invocation);
            transformed = true;
            last_action = Some(Action::Redact);
        }

        if !outcome.appends.is_empty() || !outcome.prepends.is_empty() {
            apply_invocation_transforms(invocation, &[], &outcome.prepends, &outcome.appends);
            bind_invocation_into(&mut attrs, invocation);
            transformed = true;
            if last_action.is_none() {
                last_action = if !outcome.appends.is_empty() {
                    Some(Action::Append)
                } else {
                    Some(Action::Prepend)
                };
            }
        }

        if !outcome.warns.is_empty() && last_action.is_none() {
            last_action = Some(Action::Warn);
        }
    }

    let mut verdict = StageVerdict::allow();
    if transformed {
        verdict.action = last_action;
    } else if let Some(a) = last_action {
        verdict.action = Some(a);
    }
    verdict.bypassed_by_allowed_when = bypassed;
    verdict = verdict.with_invocation_hashes(invocation_hash_before, invocation.canonical_hash());
    emit_stage_verdict(engine, &session_id, Stage::ToolExecution, &verdict);
    verdict
}

/// Build per-path redactions from the per-entry span list. Stage 3
/// redactions can target dotted paths via the entry's `paths:` field.
///
/// Pattern / patterns entries: re-scan each path's string value with
/// the entry's regex (already cached) to produce per-path offsets — the
/// flat span list cannot be mapped back from the joined string-value
/// subject to a specific path, so we recompute against the named field.
///
/// LLM / classifier entries (§12.10 / §16.3): the spans returned by the
/// caller are already content offsets. The entry MUST declare a single
/// `paths:` so the engine knows which string field to mutate; without
/// it (or with multiple paths) the spans cannot be unambiguously
/// applied and we drop them with a warning.
///
/// When `paths:` is omitted on a pattern-based entry we fall back to
/// the §12.10 "object subject" rule and apply to every top-level
/// string field.
fn build_path_redactions(
    invocation: &Invocation,
    policy: &crate::guard_policy::GuardPolicy,
    redactions_by_entry: &[(usize, Vec<(Span, String)>)],
) -> Vec<(String, Vec<(Span, String)>)> {
    use crate::guard_policy::DetectionKind;

    let mut out: Vec<(String, Vec<(Span, String)>)> = Vec::new();

    // Index entry → its captured spans for fast lookup. There can be
    // duplicates if the runner accumulates multiple span batches per
    // entry; concatenate them.
    let mut spans_for: HashMap<usize, Vec<(Span, String)>> = HashMap::new();
    for (idx, spans) in redactions_by_entry {
        spans_for
            .entry(*idx)
            .or_default()
            .extend(spans.iter().cloned());
    }

    for (entry_idx, entry) in policy.evaluate_when.iter().enumerate() {
        if !matches!(entry.action, Some(crate::guard_policy::Action::Redact))
            && policy.action != Some(crate::guard_policy::Action::Redact)
        {
            continue;
        }
        let replacement = entry
            .replacement
            .clone()
            .or_else(|| policy.replacement.clone())
            .unwrap_or_else(|| "[REDACTED]".into());

        match &entry.detection {
            DetectionKind::Pattern(_) | DetectionKind::Patterns(_) => {
                let regexes: Vec<String> = match &entry.detection {
                    DetectionKind::Pattern(p) => vec![p.clone()],
                    DetectionKind::Patterns(ps) => ps.clone(),
                    _ => unreachable!(),
                };
                let target_paths: Vec<String> = if entry.paths.is_empty() {
                    collect_top_level_string_paths(invocation, "tool.params.")
                } else {
                    entry.paths.clone()
                };

                for path in target_paths {
                    let Some(value) = read_string_at_path(&invocation.params, &path) else {
                        continue;
                    };
                    let mut spans: Vec<(Span, String)> = Vec::new();
                    for raw_pat in &regexes {
                        let Ok(rx) = regex::Regex::new(raw_pat) else {
                            continue;
                        };
                        for m in rx.find_iter(value) {
                            // Convert byte offsets to char offsets so
                            // apply_redactions (char-level) can land on
                            // grapheme boundaries in non-ASCII fields.
                            let start_char = value[..m.start()].chars().count();
                            let end_char = start_char + value[m.start()..m.end()].chars().count();
                            spans.push((
                                Span {
                                    start: start_char,
                                    end: end_char,
                                    replacement: None,
                                },
                                replacement.clone(),
                            ));
                        }
                    }
                    if !spans.is_empty() {
                        out.push((path, spans));
                    }
                }
            }
            DetectionKind::Llm(_) | DetectionKind::Classifier(_) => {
                // P6.3: spans came from the caller — cannot be re-derived
                // from a regex. Require an explicit single `paths:` so we
                // know which string field they index into.
                let Some(spans) = spans_for.remove(&entry_idx) else {
                    continue;
                };
                if spans.is_empty() {
                    continue;
                }
                if entry.paths.is_empty() {
                    log::warn!(
                        target: "agent_shield::guard_policy_runtime",
                        "Stage-3 redact entry uses LLM/classifier detection without `paths:` — \
                         {} span(s) cannot be applied; skipping",
                        spans.len()
                    );
                    continue;
                }
                if entry.paths.len() > 1 {
                    log::warn!(
                        target: "agent_shield::guard_policy_runtime",
                        "Stage-3 redact entry uses LLM/classifier detection with {} `paths:` — \
                         spans cannot be unambiguously applied; skipping",
                        entry.paths.len()
                    );
                    continue;
                }
                let path = entry.paths[0].clone();
                if read_string_at_path(&invocation.params, &path).is_none() {
                    continue;
                }
                out.push((path, spans));
            }
            DetectionKind::Expression(_) => continue,
        }
    }

    out
}

fn collect_top_level_string_paths(invocation: &Invocation, root: &str) -> Vec<String> {
    let mut out = Vec::new();
    if let serde_json::Value::Object(map) = &invocation.params {
        for (k, v) in map {
            if v.is_string() {
                out.push(format!("{}{}", root, k));
            }
        }
    }
    out
}

/// Concatenate every string-valued leaf of `params` (recursively) into a
/// single subject string, separated by `\n`. Keys, numbers, booleans,
/// nulls, and JSON structural characters do not appear in the result, so
/// regex / LLM / classifier detectors only see actual string content
/// (§16, §12.10).
fn collect_param_string_values(params: &serde_json::Value) -> String {
    let mut buf = String::new();
    collect_strings_into(params, &mut buf);
    buf
}

fn collect_strings_into(v: &serde_json::Value, buf: &mut String) {
    match v {
        serde_json::Value::String(s) => {
            if !buf.is_empty() {
                buf.push('\n');
            }
            buf.push_str(s);
        }
        serde_json::Value::Array(items) => {
            for item in items {
                collect_strings_into(item, buf);
            }
        }
        serde_json::Value::Object(obj) => {
            for (_k, val) in obj {
                collect_strings_into(val, buf);
            }
        }
        _ => {}
    }
}

/// Stage-3 §16.1 template variables. Built from the active invocation,
/// the per-call [`EvalRuntime`] context (which carries
/// `{active_guard_policies}`, `{variables}`, `{prior_checks_summary}`
/// pre-computed by the session), and the merged config (for
/// `{tool_permission}` / `{tool_description}` lookups in the resources
/// catalog).
///
/// Bindings produced (per spec §16.1, plus resource-kind-specific shape
/// vars for endpoint/agent invocations):
///
/// - `{tool_name}` / `{agent_name}` / `{endpoint_method}` / `{endpoint_uri}`
/// - `{tool_params}`
/// - `{tool_permission}`     (from `resources.tools[].permission`)
/// - `{tool_description}`    (from `resources.tools[].description`)
/// - `{active_guard_policies}` (from EvalRuntime, comma-joined; empty ⇒ `(none)`)
/// - `{variables}`           (from EvalRuntime; JSON object of resolved values)
/// - `{prior_checks_summary}` (from EvalRuntime; plain-English Stage-2 summary)
///
/// Unset bindings remain empty; `render_prompt` scrubs leftover `{...}`
/// tokens to "" per §12.9.2 ¶2.
fn stage_tool_exec_template_vars(
    invocation: &Invocation,
    ctx: &EvalRuntime<'_>,
    config: &crate::merge::MergedConfig,
) -> HashMap<String, String> {
    use crate::variables::ResourceKind;
    let mut m = HashMap::new();
    let params = serde_json::to_string(&invocation.params).unwrap_or_default();
    m.insert("tool_params".into(), params);

    match invocation.kind {
        ResourceKind::Tool => {
            if let Some(n) = &invocation.name {
                m.insert("tool_name".into(), n.clone());
                if let Some(tool) = config.resources.tools.iter().find(|t| &t.name == n) {
                    if let Some(desc) = &tool.description {
                        m.insert("tool_description".into(), desc.clone());
                    }
                    if let Some(perm) = tool.permission {
                        m.insert("tool_permission".into(), permission_label(perm).to_string());
                    }
                }
            }
        }
        ResourceKind::Agent => {
            if let Some(n) = &invocation.name {
                m.insert("agent_name".into(), n.clone());
                if let Some(agent) = config.resources.agents.iter().find(|a| &a.name == n) {
                    if let Some(desc) = &agent.description {
                        m.insert("tool_description".into(), desc.clone());
                    }
                }
            }
        }
        ResourceKind::Endpoint => {
            if let Some(method) = &invocation.method {
                m.insert("endpoint_method".into(), method.clone());
            }
            if let Some(uri) = &invocation.uri {
                m.insert("endpoint_uri".into(), uri.clone());
            }
        }
    }

    // §16.1 — `{active_guard_policies}` defaults to `(none)` when no
    // policy is currently active. The session pre-computes the comma-
    // joined string; we substitute the spec sentinel when it's empty.
    let active = if ctx.active_guard_policies.is_empty() {
        "(none)".to_string()
    } else {
        ctx.active_guard_policies.to_string()
    };
    m.insert("active_guard_policies".into(), active);

    // §16.1 — `{variables}` is JSON of currently-resolved variables.
    // Empty session ⇒ `{}` so the prompt renders valid JSON either way.
    let vars = if ctx.variables_snapshot.is_empty() {
        "{}".to_string()
    } else {
        ctx.variables_snapshot.to_string()
    };
    m.insert("variables".into(), vars);

    m.insert(
        "prior_checks_summary".into(),
        ctx.prior_checks_summary.to_string(),
    );

    m
}

/// Snake-case label for the `permission:` advisory metadata
/// (§13 — `read_only` / `read_write` / `execute` / `destructive`).
fn permission_label(p: crate::resources::Permission) -> &'static str {
    use crate::resources::Permission;
    match p {
        Permission::ReadOnly => "read_only",
        Permission::ReadWrite => "read_write",
        Permission::Execute => "execute",
        Permission::Destructive => "destructive",
    }
}

#[cfg(test)]
mod tests {
    use super::super::tests_support::*;
    use crate::guard_policy::Action;
    use crate::populator::Invocation;
    use serde_json::json;

    #[test]
    fn pattern_block_on_secrets() {
        let h = test_harness(|cfg| {
            cfg.tool_execution_validation
                .guard_policies
                .push(make_policy(
                    "secret",
                    vec![pattern_entry("secret", "(?i)api[_-]?key")],
                    None,
                    Some(Action::Block),
                ));
        });
        let mut inv = Invocation::tool("send_email", json!({"body": "api_key=foo"}));
        let v = h
            .engine
            .evaluate_tool_execution(&mut inv, &h.eval_runtime(""));
        assert!(!v.allowed);
    }

    #[test]
    fn redact_with_paths_mutates_invocation() {
        let h = test_harness(|cfg| {
            let mut p = make_policy(
                "scrub",
                vec![{
                    let mut e = pattern_entry("k", "(?i)api[_-]?key=\\S+");
                    e.action = Some(Action::Redact);
                    e.replacement = Some("[KEY]".into());
                    e.paths = vec!["tool.params.body".into()];
                    e
                }],
                None,
                None,
            );
            p.replacement = Some("[KEY]".into());
            cfg.tool_execution_validation.guard_policies.push(p);
        });
        let mut inv = Invocation::tool("send_email", json!({"body": "api_key=secret here"}));
        let before = inv.canonical_hash();
        let v = h
            .engine
            .evaluate_tool_execution(&mut inv, &h.eval_runtime(""));
        assert!(v.allowed);
        assert_eq!(v.invocation_hash.as_deref(), Some(before.as_str()));
        assert_eq!(
            v.post_validation_invocation_hash.as_deref(),
            Some(inv.canonical_hash().as_str())
        );
        assert_ne!(v.invocation_hash, v.post_validation_invocation_hash);
        assert_eq!(inv.params, json!({"body": "[KEY] here"}));
    }

    #[test]
    fn append_with_paths_mutates_invocation() {
        let h = test_harness(|cfg| {
            cfg.tool_execution_validation
                .guard_policies
                .push(make_policy(
                    "disclaim",
                    vec![{
                        let mut e = expression_entry("disclaimer needed", "false");
                        e.action = Some(Action::Append);
                        e.text = Some("\n--disclaimer--".into());
                        e.paths = vec!["tool.params.body".into()];
                        e
                    }],
                    None,
                    None,
                ));
        });
        let mut inv = Invocation::tool("send_email", json!({"body": "hello"}));
        let v = h
            .engine
            .evaluate_tool_execution(&mut inv, &h.eval_runtime(""));
        assert!(v.allowed);
        assert_eq!(
            inv.params["body"].as_str().unwrap(),
            "hello\n--disclaimer--"
        );
    }

    #[test]
    fn prepend_with_paths_mutates_invocation() {
        let h = test_harness(|cfg| {
            cfg.tool_execution_validation
                .guard_policies
                .push(make_policy(
                    "disclaim",
                    vec![{
                        let mut e = expression_entry("warning needed", "false");
                        e.action = Some(Action::Prepend);
                        e.text = Some("[WARN] ".into());
                        e.paths = vec!["tool.params.body".into()];
                        e
                    }],
                    None,
                    None,
                ));
        });
        let mut inv = Invocation::tool("send_email", json!({"body": "hello"}));
        let v = h
            .engine
            .evaluate_tool_execution(&mut inv, &h.eval_runtime(""));
        assert!(v.allowed);
        assert_eq!(inv.params["body"].as_str().unwrap(), "[WARN] hello");
    }

    #[test]
    fn applies_to_filters_out_other_tools() {
        let h = test_harness(|cfg| {
            cfg.tool_execution_validation
                .guard_policies
                .push(make_policy(
                    "p",
                    vec![pattern_entry("nope", "secret")],
                    Some(applies_to_tools(&["other"])),
                    Some(Action::Block),
                ));
        });
        let mut inv = Invocation::tool("send_email", json!({"body": "secret"}));
        let v = h
            .engine
            .evaluate_tool_execution(&mut inv, &h.eval_runtime(""));
        assert!(v.allowed);
    }

    #[test]
    fn block_short_circuits_subsequent_policies() {
        let h = test_harness(|cfg| {
            cfg.tool_execution_validation
                .guard_policies
                .push(make_policy(
                    "first_block",
                    vec![pattern_entry("blocked", "alpha")],
                    None,
                    Some(Action::Block),
                ));
            cfg.tool_execution_validation
                .guard_policies
                .push(make_policy(
                    "second",
                    vec![pattern_entry("nope", "beta")],
                    None,
                    None,
                ));
        });
        let mut inv = Invocation::tool("t", json!({"body": "alpha and beta"}));
        let v = h
            .engine
            .evaluate_tool_execution(&mut inv, &h.eval_runtime(""));
        assert!(!v.allowed);
        assert_eq!(v.policy.as_deref(), Some("first_block"));
    }

    #[test]
    fn declaration_order_first_policy_wins_block() {
        let h = test_harness(|cfg| {
            cfg.tool_execution_validation
                .guard_policies
                .push(make_policy(
                    "first",
                    vec![pattern_entry("first reason", "x")],
                    None,
                    Some(Action::Block),
                ));
            cfg.tool_execution_validation
                .guard_policies
                .push(make_policy(
                    "second",
                    vec![pattern_entry("second reason", "x")],
                    None,
                    Some(Action::Block),
                ));
        });
        let mut inv = Invocation::tool("t", json!({"body": "x here"}));
        let v = h
            .engine
            .evaluate_tool_execution(&mut inv, &h.eval_runtime(""));
        assert!(!v.allowed);
        assert_eq!(v.reason.as_deref(), Some("first reason"));
        assert_eq!(v.policy.as_deref(), Some("first"));
    }

    #[test]
    fn warn_then_block_in_separate_policies() {
        let h = test_harness(|cfg| {
            cfg.tool_execution_validation
                .guard_policies
                .push(make_policy(
                    "warn_first",
                    vec![pattern_entry("warning", "alpha")],
                    None,
                    Some(Action::Warn),
                ));
            cfg.tool_execution_validation
                .guard_policies
                .push(make_policy(
                    "block_second",
                    vec![pattern_entry("blocked", "alpha")],
                    None,
                    Some(Action::Block),
                ));
        });
        let mut inv = Invocation::tool("t", json!({"body": "alpha"}));
        let v = h
            .engine
            .evaluate_tool_execution(&mut inv, &h.eval_runtime(""));
        // Second policy blocks even though first warned.
        assert!(!v.allowed);
        assert_eq!(v.policy.as_deref(), Some("block_second"));
    }

    #[test]
    fn redact_followed_by_pattern_passes_on_redacted_text() {
        // Stage 3 transforms execute on the transformed invocation
        // (§16.3). After the first policy redacts, a subsequent policy
        // that also matches the redacted text would not match the
        // replacement (which is "[KEY]", not "api_key=...").
        let h = test_harness(|cfg| {
            let mut p1 = make_policy(
                "scrub",
                vec![{
                    let mut e = pattern_entry("k", "(?i)api[_-]?key=\\S+");
                    e.action = Some(Action::Redact);
                    e.replacement = Some("[KEY]".into());
                    e.paths = vec!["tool.params.body".into()];
                    e
                }],
                None,
                None,
            );
            p1.replacement = Some("[KEY]".into());
            cfg.tool_execution_validation.guard_policies.push(p1);
            // Second policy: would block on "secret" string, but we
            // redact api_key=secret to [KEY] so it should pass.
            cfg.tool_execution_validation
                .guard_policies
                .push(make_policy(
                    "later",
                    vec![pattern_entry("never matches now", "api_key=")],
                    None,
                    Some(Action::Block),
                ));
        });
        let mut inv = Invocation::tool("send_email", json!({"body": "api_key=topsecret"}));
        let v = h
            .engine
            .evaluate_tool_execution(&mut inv, &h.eval_runtime(""));
        assert!(v.allowed);
        assert_eq!(inv.params, json!({"body": "[KEY]"}));
    }

    #[test]
    fn agent_resource_kind_matches() {
        let h = test_harness(|cfg| {
            cfg.tool_execution_validation
                .guard_policies
                .push(make_policy(
                    "p",
                    vec![pattern_entry("nope", "secret")],
                    Some(crate::guard_policy::AppliesTo {
                        agents: vec!["sub".into()],
                        ..Default::default()
                    }),
                    Some(Action::Block),
                ));
        });
        let mut inv = Invocation::agent("sub", json!({"body": "secret"}));
        let v = h
            .engine
            .evaluate_tool_execution(&mut inv, &h.eval_runtime(""));
        assert!(!v.allowed);
    }

    // ── §16.1 / §16.2 prompt-enrichment unit tests ──────────────────

    /// Helper that builds a Stage-3 template-vars map from the
    /// invocation + an EvalRuntime, mirroring what the runner does at
    /// the `build_detection_deps` call site.
    fn template_vars_for(
        inv: &Invocation,
        ctx: &super::EvalRuntime<'_>,
        cfg: &crate::merge::MergedConfig,
    ) -> std::collections::HashMap<String, String> {
        super::stage_tool_exec_template_vars(inv, ctx, cfg)
    }

    fn ctx_with(
        active: &str,
        vars: &str,
        prior: &str,
    ) -> (super::EvalRuntime<'static>, &'static str) {
        // Build a leaked-string EvalRuntime so the borrows are 'static
        // for test simplicity. Test-only — never use Box::leak in
        // production paths.
        let active: &'static str = Box::leak(active.to_string().into_boxed_str());
        let vars: &'static str = Box::leak(vars.to_string().into_boxed_str());
        let prior: &'static str = Box::leak(prior.to_string().into_boxed_str());
        (
            super::EvalRuntime {
                session_id: "s",
                correlation_id: "c",
                user_id: None,
                tenant_id: None,
                request_context: serde_json::Value::Null,
                turn_id: 0,
                objective: "",
                forbidden: &[],
                user_input: "",
                active_guard_policies: active,
                variables_snapshot: vars,
                prior_checks_summary: prior,
            },
            "",
        )
    }

    /// §16.1 — `{tool_permission}` and `{tool_description}` come from
    /// the matched `resources.tools[]` entry.
    #[test]
    fn stage3_template_vars_emit_tool_permission_and_description() {
        use crate::resources::{Permission, ResourcesBlock, ToolResource};
        let mut cfg = crate::merge::MergedConfig::default();
        cfg.resources = ResourcesBlock {
            tools: vec![ToolResource {
                name: "send_email".into(),
                description: Some("Send a message".into()),
                permission: Some(Permission::Execute),
                protocol: None,
                on_error: None,
                on_error_log: None,
                tags: None,
                clearance: None,
                audience: None,
            }],
            ..Default::default()
        };
        let inv = Invocation::tool("send_email", json!({"to": "x"}));
        let (ctx, _) = ctx_with("", "", "");
        let m = template_vars_for(&inv, &ctx, &cfg);
        assert_eq!(m.get("tool_name").map(String::as_str), Some("send_email"));
        assert_eq!(
            m.get("tool_description").map(String::as_str),
            Some("Send a message")
        );
        assert_eq!(
            m.get("tool_permission").map(String::as_str),
            Some("execute")
        );
    }

    /// §16.1 — `{tool_params}` is the JSON-serialized invocation params.
    #[test]
    fn stage3_template_vars_emit_tool_params_json() {
        let cfg = crate::merge::MergedConfig::default();
        let inv = Invocation::tool("t", json!({"a": 1, "b": "x"}));
        let (ctx, _) = ctx_with("", "", "");
        let m = template_vars_for(&inv, &ctx, &cfg);
        let params = m.get("tool_params").cloned().unwrap_or_default();
        // Order-tolerant: parse and compare structurally.
        let parsed: serde_json::Value = serde_json::from_str(&params).unwrap();
        assert_eq!(parsed, json!({"a": 1, "b": "x"}));
    }

    /// §16.1 — `{active_guard_policies}` defaults to `(none)` when the
    /// session has no active policies. The session-supplied value
    /// otherwise passes through verbatim.
    #[test]
    fn stage3_template_vars_active_policies_defaults_to_none() {
        let cfg = crate::merge::MergedConfig::default();
        let inv = Invocation::tool("t", json!({}));
        let (ctx, _) = ctx_with("", "{}", "");
        let m = template_vars_for(&inv, &ctx, &cfg);
        assert_eq!(
            m.get("active_guard_policies").map(String::as_str),
            Some("(none)")
        );
    }

    #[test]
    fn stage3_template_vars_active_policies_passes_through_when_set() {
        let cfg = crate::merge::MergedConfig::default();
        let inv = Invocation::tool("t", json!({}));
        let (ctx, _) = ctx_with("a, b", "{}", "Stage-2 policies that passed: x.");
        let m = template_vars_for(&inv, &ctx, &cfg);
        assert_eq!(
            m.get("active_guard_policies").map(String::as_str),
            Some("a, b")
        );
        assert_eq!(
            m.get("prior_checks_summary").map(String::as_str),
            Some("Stage-2 policies that passed: x.")
        );
    }

    /// §16.1 — `{variables}` defaults to the empty JSON object when no
    /// snapshot was supplied.
    #[test]
    fn stage3_template_vars_variables_defaults_to_empty_object() {
        let cfg = crate::merge::MergedConfig::default();
        let inv = Invocation::tool("t", json!({}));
        let (ctx, _) = ctx_with("", "", "");
        let m = template_vars_for(&inv, &ctx, &cfg);
        assert_eq!(m.get("variables").map(String::as_str), Some("{}"));
    }

    /// §16.2 — every Stage-3 LLM detection prompt receives the
    /// canonical Runtime Context block, with substitution applied to
    /// the block itself.
    #[test]
    fn stage3_render_prompt_appends_runtime_context_block() {
        use super::super::detection::{DetectionDeps, RegexCache};
        use std::collections::HashMap;
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let mut extra = HashMap::new();
        extra.insert("tool_name".into(), "wire_transfer".into());
        extra.insert("tool_description".into(), "Move funds".into());
        extra.insert("tool_permission".into(), "destructive".into());
        extra.insert("tool_params".into(), "{\"amount\":1000}".into());
        extra.insert(
            "active_guard_policies".into(),
            "wire_transfer_safety, kyc_check".into(),
        );
        extra.insert("variables".into(), "{\"data_sensitivity\":\"high\"}".into());
        extra.insert(
            "prior_checks_summary".into(),
            "Stage-2 state_validation policies that passed for this call: wire_transfer_safety."
                .into(),
        );
        let deps = DetectionDeps {
            regex_cache: &cache,
            llm_caller: None,
            classifier_caller: None,
            objective: "stay safe",
            forbidden: &[],
            user_input: "send $1000",
            extra_template_vars: extra,
            attrs: &attrs,
            status_lookup: None,
            event_fired: None,
            predicates: None,
            resolver_hook: None,
            append_runtime_context: true,
            clock: None,
            observability: None,
            perf_telemetry: crate::perf_telemetry::PerfTelemetry::Off,
            stage: crate::observability::Stage::Input,
            session_id: "",
            correlation_id: "",
        };
        let rendered = deps.render_prompt("Validate: {user_input}");
        assert!(rendered.starts_with("Validate: send $1000"));
        // §16.2 layout — these markers MUST be present in the appended block.
        assert!(rendered.contains("## Runtime Context"));
        assert!(rendered.contains("Tool: wire_transfer"));
        assert!(rendered.contains("Description: Move funds"));
        assert!(rendered.contains("Permission: destructive"));
        assert!(rendered.contains("Active guard policies: wire_transfer_safety, kyc_check"));
        assert!(rendered.contains("Variables:"));
        assert!(rendered.contains("\"data_sensitivity\":\"high\""));
        assert!(rendered.contains("## Prior Automated Checks"));
        assert!(rendered.contains("Stage-2 state_validation policies"));
    }

    /// §16.2 — non-Stage-3 stages MUST NOT append the Runtime Context
    /// block. (The flag is the gate; this test pins the negative.)
    #[test]
    fn render_prompt_does_not_append_block_when_flag_is_false() {
        use super::super::detection::{DetectionDeps, RegexCache};
        use std::collections::HashMap;
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = DetectionDeps {
            regex_cache: &cache,
            llm_caller: None,
            classifier_caller: None,
            objective: "",
            forbidden: &[],
            user_input: "hi",
            extra_template_vars: HashMap::new(),
            attrs: &attrs,
            status_lookup: None,
            event_fired: None,
            predicates: None,
            resolver_hook: None,
            append_runtime_context: false,
            clock: None,
            observability: None,
            perf_telemetry: crate::perf_telemetry::PerfTelemetry::Off,
            stage: crate::observability::Stage::Input,
            session_id: "",
            correlation_id: "",
        };
        let rendered = deps.render_prompt("Stage 1: {user_input}");
        assert_eq!(rendered, "Stage 1: hi");
        assert!(!rendered.contains("## Runtime Context"));
    }
}
