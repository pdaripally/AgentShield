//! Stage 2 — `state_validation` runner (§15).
//!
//! Subject: the runtime's session state at gate-time. `applies_to:` is
//! REQUIRED on every guard policy. Detection is `expression` only; actions
//! are `block` / `warn` only.
//!
//! Per §12.10 the runtime walks each guard policy whose `applies_to:`
//! matches the current invocation in declaration order. Block short-
//! circuits subsequent policies for this stage.

use std::collections::HashMap;
use std::sync::Mutex;

use crate::guard_policy::Action;
use crate::observability::Stage;
use crate::populator::Invocation;
use crate::resolver_runtime::AutoResolveAdapter;

use super::evaluate_when::run_evaluate_when;
use super::runtime_hooks::{PredicateMapLookup, SessionScopedEventFired, TrackerStatusLookup};
use super::selector::applies_to_matches;
use super::stage_common::{
    block_verdict, build_allowed_when_deps_with_event_hook, build_detection_deps_with_event_hook,
    emit_stage_verdict, log_outcome_in, ResolverHookHolder,
};
use super::{
    bind_invocation_into, invocation_subject, EvalRuntime, GuardPolicyEngine, StageVerdict,
};
use crate::session_id::SessionId;

pub(crate) fn evaluate(
    engine: &GuardPolicyEngine,
    invocation: &Invocation,
    ctx: &EvalRuntime<'_>,
) -> StageVerdict {
    super::stage_timing::time_stage(
        engine.deps().clock.as_ref(),
        engine.deps().observability.as_ref(),
        engine.deps().perf_telemetry,
        ctx.session_id,
        ctx.correlation_id,
        Stage::State,
        || evaluate_inner(engine, invocation, ctx),
    )
}

fn evaluate_inner(
    engine: &GuardPolicyEngine,
    invocation: &Invocation,
    ctx: &EvalRuntime<'_>,
) -> StageVerdict {
    let invocation_hash_before = invocation.canonical_hash();
    let session_id = SessionId::new(ctx.session_id);
    let policies = &engine.deps().config.state_validation.guard_policies;
    let mut attrs = ctx.build_base_attrs();
    super::stage_common::bind_resolved_variables_in(
        &session_id,
        &mut attrs,
        engine.deps().tracker.as_ref(),
        &engine.deps().config.variables,
    );
    bind_invocation_into(&mut attrs, invocation);

    let status_lookup =
        TrackerStatusLookup::new_in(engine.deps().tracker.as_ref(), session_id.clone());
    let pred_lookup = PredicateMapLookup::new(&engine.deps().config.predicates);
    let resolver_holder = ResolverHookHolder {
        adapter: AutoResolveAdapter::new_in(
            engine.deps().resolver.as_ref(),
            attrs.clone(),
            session_id.clone(),
        )
        .with_invocation(invocation.clone()),
        trace: Mutex::new(Vec::new()),
    };
    let resolver_hook: &dyn crate::expressions::eval::ResolverHook = &resolver_holder;
    let event_fired_hook =
        SessionScopedEventFired::new(&engine.deps().event_bus, session_id.clone());
    let subject = invocation_subject(invocation);
    let mut last_action: Option<Action> = None;
    let mut bypassed = false;

    for policy in policies {
        if !applies_to_matches(policy.applies_to.as_ref(), &subject) {
            continue;
        }
        let active = engine.activation().evaluate_and_emit_in(
            &session_id,
            &policy.name,
            policy.active_if.as_deref(),
            &attrs,
            Some(&pred_lookup as &dyn crate::expressions::eval::PredicateLookup),
            Some(&event_fired_hook as &dyn crate::expressions::eval::EventFiredHook),
            &engine.deps().event_bus,
        );
        if !active {
            continue;
        }

        // §12.5 — empty `evaluate_when:` ⇒ always-block-when-active. For
        // Stage 2 this is the canonical lockdown idiom (§15.2 example).
        if policy.evaluate_when.is_empty() {
            let reason = policy
                .reason
                .clone()
                .unwrap_or_else(|| format!("guard policy `{}` blocked", policy.name));
            let v = StageVerdict::block(&policy.name, reason, None)
                .with_pending_resolution(resolver_holder.adapter.take_pending())
                .with_invocation_hashes(
                    invocation_hash_before.clone(),
                    invocation.canonical_hash(),
                );
            let _ = engine
                .deps()
                .event_bus
                .emit_guard_policy_failed_in(&session_id, policy.name.clone());
            emit_stage_verdict(engine, &session_id, Stage::State, &v);
            return v;
        }

        let ddeps = build_detection_deps_with_event_hook(
            engine,
            ctx,
            &attrs,
            Some(&status_lookup),
            Some(&pred_lookup),
            Some(resolver_hook),
            Some(&event_fired_hook as &dyn crate::expressions::eval::EventFiredHook),
            // §12.9.2: Stage 2 has no per-call subject — bind a
            // best-effort `{state_summary}` for prompts that want to
            // include the variable snapshot. P9 will replace this with
            // a richer summary when the tracker exposes one.
            HashMap::new(),
            // Stage 2 does not append the §16.2 Runtime Context block.
            false,
            Stage::State,
        );
        let aw_deps = build_allowed_when_deps_with_event_hook(
            engine,
            &attrs,
            Some(&status_lookup),
            Some(&pred_lookup),
            Some(resolver_hook),
            Some(&event_fired_hook as &dyn crate::expressions::eval::EventFiredHook),
        );
        let outcome = run_evaluate_when(policy, "", &ddeps, &aw_deps);
        log_outcome_in(&session_id, engine, Stage::State, policy, &outcome);

        if outcome.allowed_when_bypass_fired {
            bypassed = true;
        }

        if let Some(b) = &outcome.block {
            let v = block_verdict(policy, b)
                .with_pending_resolution(resolver_holder.adapter.take_pending())
                .with_invocation_hashes(
                    invocation_hash_before.clone(),
                    invocation.canonical_hash(),
                );
            emit_stage_verdict(engine, &session_id, Stage::State, &v);
            return v;
        }

        // Stage 2 only allows block / warn — anything else slips through
        // as a no-op with a load-time error (handled in P1). We still
        // record the warn for the verdict's `action:`.
        if !outcome.warns.is_empty() && last_action.is_none() {
            last_action = Some(Action::Warn);
        }
    }

    let mut verdict = StageVerdict::allow();
    if let Some(a) = last_action {
        verdict.action = Some(a);
    }
    verdict.bypassed_by_allowed_when = bypassed;
    verdict = verdict.with_invocation_hash(invocation_hash_before);
    emit_stage_verdict(engine, &session_id, Stage::State, &verdict);
    verdict
}

#[cfg(test)]
mod tests {
    use super::super::tests_support::*;
    use crate::guard_policy::Action;
    use crate::populator::Invocation;
    use serde_json::json;

    #[test]
    fn empty_state_validation_passes() {
        let h = test_harness(|_| {});
        let inv = Invocation::tool("send_email", json!({}));
        let v = h.engine.evaluate_state(&inv, &h.eval_runtime(""));
        assert!(v.allowed);
    }

    #[test]
    fn applies_to_filters_out_unrelated_tools() {
        let h = test_harness(|cfg| {
            cfg.state_validation.guard_policies.push(make_policy(
                "p",
                vec![expression_entry("nope", "false")],
                Some(applies_to_tools(&["other_tool"])),
                None,
            ));
        });
        let inv = Invocation::tool("send_email", json!({}));
        let v = h.engine.evaluate_state(&inv, &h.eval_runtime(""));
        assert!(v.allowed);
    }

    #[test]
    fn matching_policy_blocks_on_false_expression() {
        let h = test_harness(|cfg| {
            cfg.state_validation.guard_policies.push(make_policy(
                "p",
                vec![expression_entry("must approve", "approved == true")],
                Some(applies_to_tools(&["send_email"])),
                None,
            ));
        });
        let inv = Invocation::tool("send_email", json!({}));
        let v = h.engine.evaluate_state(&inv, &h.eval_runtime(""));
        assert!(!v.allowed);
        assert_eq!(v.action, Some(Action::Block));
        assert_eq!(v.reason.as_deref(), Some("must approve"));
    }

    #[test]
    fn empty_evaluate_when_is_lockdown() {
        let h = test_harness(|cfg| {
            let mut p = make_policy(
                "lockdown",
                vec![],
                Some(applies_to_tools(&["send_email"])),
                None,
            );
            p.reason = Some("incident".into());
            cfg.state_validation.guard_policies.push(p);
        });
        let inv = Invocation::tool("send_email", json!({}));
        let v = h.engine.evaluate_state(&inv, &h.eval_runtime(""));
        assert!(!v.allowed);
        assert_eq!(v.reason.as_deref(), Some("incident"));
    }

    #[test]
    fn warn_keeps_allowed_true() {
        let h = test_harness(|cfg| {
            cfg.state_validation.guard_policies.push(make_policy(
                "p",
                vec![expression_entry("not yet", "kyc == true")],
                Some(applies_to_tools(&["send_email"])),
                Some(Action::Warn),
            ));
        });
        let inv = Invocation::tool("send_email", json!({}));
        let v = h.engine.evaluate_state(&inv, &h.eval_runtime(""));
        assert!(v.allowed);
        assert_eq!(v.action, Some(Action::Warn));
    }

    #[test]
    fn endpoint_selector_matches() {
        let h = test_harness(|cfg| {
            cfg.state_validation.guard_policies.push(make_policy(
                "ep",
                vec![expression_entry("must auth", "false")],
                Some(applies_to_endpoint("/api/v1/payments/{id}", &["POST"])),
                None,
            ));
        });
        let inv = Invocation::endpoint("POST", "/api/v1/payments/42", json!({}));
        let v = h.engine.evaluate_state(&inv, &h.eval_runtime(""));
        assert!(!v.allowed);
    }
}
