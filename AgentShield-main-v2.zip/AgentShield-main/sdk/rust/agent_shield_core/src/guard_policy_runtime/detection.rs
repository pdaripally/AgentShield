//! Detection-kind dispatch for `evaluate_when[]` entries (§12.5).
//!
//! Each `EvaluateWhenEntry` carries exactly one of the five detection
//! kinds: `expression`, `pattern`, `patterns`, `llm`, `classifier`. This
//! module owns the evaluation strategy for each kind plus the trait
//! definitions hosts implement to plug in LLM and classifier providers.
//!
//! ## Design
//!
//! - **Synchronous traits**: the engine is sync. Hosts that need async
//!   wrap their async clients with `tokio::runtime::Handle::block_on`
//!   inside the trait impl.
//! - **Spans**: only `pattern` / `patterns` produce character offsets
//!   natively; `llm` and `classifier` may optionally emit spans through
//!   their structured response types per §12.8.
//! - **Polarity**: per §12.5.1 — `expression:` is a predicate (truthy =
//!   pass), all others are detectors (positive detection = fail).
//! - **Fail-closed**: any error path in detection (regex compile failure,
//!   missing host trait, malformed LLM response, unrecognized
//!   configuration) yields a `Fail { reason }` so the gate denies. This
//!   is the security invariant.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

use regex::Regex;
use serde_json::Value;

use crate::expressions::eval::{
    evaluate_with, EvalContext, EventFiredHook, PredicateLookup, ResolverHook, StatusLookup,
};
use crate::guard_policy::{ClassifierDetection, DetectionKind, EvaluateWhenEntry, LlmDetection};

/// One byte-offset range identifying a redaction span. `start..end` is
/// half-open. Mirrors the §12.9.3 span format produced by LLM responses
/// and pattern matches.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Span {
    pub start: usize,
    pub end: usize,
    pub replacement: Option<String>,
}

/// Verdict produced by detecting against a single `evaluate_when[]` entry
/// against a content subject.
#[derive(Debug, Clone)]
pub enum DetectionVerdict {
    /// The entry passed (the call may proceed past this entry).
    Pass,
    /// The entry failed. `reason` is the entry's `reason:` (or a fallback
    /// surfaced by the detector when the LLM/classifier provided one).
    Fail {
        reason: String,
        /// Character spans for redaction (`pattern` / `patterns` / `llm`
        /// with `spans[]`). Empty for predicate-style failures or LLM
        /// block-mode without spans.
        spans: Vec<Span>,
    },
}

impl DetectionVerdict {
    pub fn is_pass(&self) -> bool {
        matches!(self, DetectionVerdict::Pass)
    }
    pub fn fail(reason: impl Into<String>) -> Self {
        DetectionVerdict::Fail {
            reason: reason.into(),
            spans: Vec::new(),
        }
    }
    pub fn fail_spans(reason: impl Into<String>, spans: Vec<Span>) -> Self {
        DetectionVerdict::Fail {
            reason: reason.into(),
            spans,
        }
    }
}

/// Structured LLM response per §12.9.3. Hosts return this from
/// [`LlmCaller::call`]; the runtime then folds it into a verdict.
#[derive(Debug, Clone, Default)]
pub struct LlmResponse {
    /// `ALLOW` / `BLOCK`. For redact-mode entries the field is ignored.
    pub decision: Option<LlmDecision>,
    pub confidence: Option<f64>,
    pub reason: Option<String>,
    pub categories: Vec<String>,
    pub spans: Vec<Span>,
    /// Boolean shorthand fields. Per §12.9.3, *any* truthy boolean field
    /// (e.g. `contains_pii`, `is_jailbreak`) MUST be treated as `BLOCK`.
    pub bool_flags: HashMap<String, bool>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LlmDecision {
    Allow,
    Block,
}

impl LlmResponse {
    pub fn folded_decision(&self) -> LlmDecision {
        if self.bool_flags.values().any(|v| *v) {
            return LlmDecision::Block;
        }
        match self.decision {
            Some(d) => d,
            // §12.9.3 — missing / unrecognized decision MUST be BLOCK.
            None => LlmDecision::Block,
        }
    }
}

/// Structured classifier response. Per §12.5.1 detection fails when
/// `score >= threshold` OR `flagged == true`. Hosts may also emit a
/// `label` for label-based classifiers.
#[derive(Debug, Clone, Default)]
pub struct ClassifierVerdict {
    pub score: f64,
    pub threshold: f64,
    pub flagged: bool,
    pub label: Option<String>,
    pub reason: Option<String>,
    pub spans: Vec<Span>,
}

impl ClassifierVerdict {
    /// §12.5.1: a classifier verdict is a failure iff `flagged` is true,
    /// or `score >= threshold`. The comparison is unconditional —
    /// `threshold == 0.0` is meaningful and means "fail anything
    /// non-negative". Negative thresholds are nonsensical and are the
    /// caller's responsibility to validate at config-load time.
    pub fn is_failure(&self) -> bool {
        self.flagged || self.score >= self.threshold
    }
}

/// Sync LLM caller surface. Hosts implementing this against an async
/// client should bridge with `tokio::runtime::Handle::block_on` inside
/// the trait impl.
pub trait LlmCaller: Send + Sync {
    /// Render the given prompt (already template-substituted) against the
    /// host's LLM. Returns the structured response or an `Err(reason)`
    /// — errors fold into a `BLOCK` decision per §12.9.3 ¶3 ("malformed
    /// JSON MUST trigger the entry's `on_error:` policy (default
    /// `block`)").
    fn call(&self, configuration_id: Option<&str>, prompt: &str) -> Result<LlmResponse, String>;
}

/// Sync classifier caller surface.
pub trait ClassifierCaller: Send + Sync {
    /// Classify `subject` using the configured classifier. The returned
    /// envelope encodes both threshold semantics and explicit `flagged`
    /// failure.
    fn classify(&self, configuration_id: &str, subject: &str) -> Result<ClassifierVerdict, String>;
}

/// Per-engine regex cache.
#[derive(Default)]
pub struct RegexCache {
    cache: Mutex<HashMap<String, Result<Regex, String>>>,
}

impl RegexCache {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn compile(&self, pattern: &str) -> Result<Regex, String> {
        // §5.1 — ReDoS guard: pattern length cap of 500.
        if pattern.len() > 500 {
            return Err(format!(
                "regex pattern length {} exceeds the §5.1 500-char limit",
                pattern.len()
            ));
        }
        let mut guard = self.cache.lock().unwrap();
        if let Some(existing) = guard.get(pattern) {
            return match existing {
                Ok(r) => Ok(r.clone()),
                Err(e) => Err(e.clone()),
            };
        }
        let r = Regex::new(pattern).map_err(|e| e.to_string());
        guard.insert(pattern.to_string(), r.clone());
        r
    }
}

/// Bag of references the detection dispatcher needs.
pub struct DetectionDeps<'a> {
    pub regex_cache: &'a RegexCache,
    pub llm_caller: Option<&'a dyn LlmCaller>,
    pub classifier_caller: Option<&'a dyn ClassifierCaller>,
    /// Subject template: rendered prompt receives the canonical §12.9.2
    /// variables. Stages augment via `extra_template_vars`.
    pub objective: &'a str,
    pub forbidden: &'a [String],
    pub user_input: &'a str,
    pub extra_template_vars: HashMap<String, String>,
    pub attrs: &'a HashMap<String, Value>,
    pub status_lookup: Option<&'a dyn StatusLookup>,
    pub event_fired: Option<&'a dyn EventFiredHook>,
    pub predicates: Option<&'a dyn PredicateLookup>,
    pub resolver_hook: Option<&'a dyn ResolverHook>,
    /// Append the §16.2 Default-Implementation Runtime Context block to
    /// every rendered prompt. Set by the Stage-3 runner only; Stages 1,
    /// 4, and 5 leave this `false` so their LLM detections render the
    /// authored prompt unchanged.
    pub append_runtime_context: bool,
    // ── v8 perf-logging (PR6) fields ───────────────────────────────
    //
    // These thread the per-stage timing context into `detect_llm` /
    // `detect_classifier` so AC10-Corr correlation attributes can be
    // stamped on every `LlmCalled` / `ClassifierCalled` emit. All
    // four are populated by `stage_common::build_detection_deps_*`;
    // test code that constructs `DetectionDeps` inline defaults them
    // to `None` / `Off` / `Stage::Input` and gets the AC7 behaviour
    // (zero perf emissions) for free.
    /// Clock for measuring LLM / classifier call latency. `None`
    /// suppresses perf emissions regardless of `perf_telemetry`.
    pub clock: Option<&'a dyn crate::clock::Clock>,
    /// Observability dispatcher for emitting `LlmCalled` /
    /// `ClassifierCalled` perf events. `None` suppresses emission.
    pub observability: Option<&'a crate::observability::ObservabilityDispatcher>,
    /// Perf-telemetry gating knob. `Off` (the default) suppresses
    /// every PR6 perf emission.
    pub perf_telemetry: crate::perf_telemetry::PerfTelemetry,
    /// Stage that built these deps. Stamped as `KEY_STAGE` on every
    /// `LlmCalled` / `ClassifierCalled` perf event.
    pub stage: crate::observability::Stage,
    /// Originating session id. Surfaces on perf events so adopters
    /// can correlate cross-stage cost back to the conversation.
    pub session_id: &'a str,
    /// Per-turn correlation id (§19.2 — required top-level field on
    /// every Info+ event).
    pub correlation_id: &'a str,
}

impl<'a> DetectionDeps<'a> {
    /// Substitute §12.9.2 canonical + extra template variables in a
    /// prompt. Variable names are case-sensitive; undefined refs become
    /// the empty string (§12.9.2 ¶2 — required by spec, NOT left as
    /// literal `{name}` tokens).
    ///
    /// Stage-3 callers (`append_runtime_context: true`) additionally
    /// append the §16.2 Runtime Context block AFTER the user-supplied
    /// template's substitution, with the same variable substitution
    /// applied to the block. This mirrors the spec's "appended after
    /// any user-supplied template substitution" requirement.
    pub fn render_prompt(&self, template: &str) -> String {
        let mut out = self.substitute(template);
        if self.append_runtime_context {
            out.push_str(&self.substitute(RUNTIME_CONTEXT_BLOCK));
        }
        out
    }

    fn substitute(&self, template: &str) -> String {
        let mut out = template.to_string();
        let forbidden_joined = self.forbidden.join("\n");
        out = replace_token(&out, "{user_input}", self.user_input);
        out = replace_token(&out, "{objective}", self.objective);
        out = replace_token(&out, "{forbidden}", &forbidden_joined);
        for (k, v) in &self.extra_template_vars {
            let token = format!("{{{}}}", k);
            out = replace_token(&out, &token, v);
        }
        // Remaining `{name}` tokens are undefined references — §12.9.2
        // requires them to render as empty rather than persist as
        // literals. Identifier shape: `[A-Za-z_][A-Za-z0-9_]*`.
        scrub_unknown_tokens(&out)
    }
}

/// Spec §16.2 — Default-Implementation Runtime Context block appended
/// to every Stage-3 (`tool_execution_validation`) LLM-detection prompt.
/// The block is verbatim spec text; substitution is performed by the
/// caller via [`DetectionDeps::render_prompt`].
const RUNTIME_CONTEXT_BLOCK: &str = "\n\n## Runtime Context\n\nTool: {tool_name}\nDescription: {tool_description}\nPermission: {tool_permission}\nParameters:\n{tool_params}\n\nActive guard policies: {active_guard_policies}\nVariables:\n{variables}\n\n## Prior Automated Checks\n{prior_checks_summary}\n";

fn scrub_unknown_tokens(s: &str) -> String {
    let bytes = s.as_bytes();
    let mut out = String::with_capacity(s.len());
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'{' {
            // Look ahead for `[A-Za-z_][A-Za-z0-9_]*\}`.
            let mut j = i + 1;
            if j < bytes.len() && (bytes[j].is_ascii_alphabetic() || bytes[j] == b'_') {
                j += 1;
                while j < bytes.len() && (bytes[j].is_ascii_alphanumeric() || bytes[j] == b'_') {
                    j += 1;
                }
                if j < bytes.len() && bytes[j] == b'}' {
                    // Skip the entire `{name}` token.
                    i = j + 1;
                    continue;
                }
            }
        }
        // Append this UTF-8 char as-is. Walk by char boundary.
        let ch_end = next_char_boundary(s, i);
        out.push_str(&s[i..ch_end]);
        i = ch_end;
    }
    out
}

fn next_char_boundary(s: &str, start: usize) -> usize {
    let mut end = start + 1;
    while end < s.len() && !s.is_char_boundary(end) {
        end += 1;
    }
    end
}

fn replace_token(haystack: &str, token: &str, replacement: &str) -> String {
    haystack.replace(token, replacement)
}

/// Run a single detection entry against the subject and return its verdict.
///
/// `effective_action` is the action that will fire on failure (after policy/
/// entry/default resolution). Passing it here lets detection kinds adjust
/// their pass/fail logic for action-specific semantics (§12.9.3) — most
/// notably `action: redact` ignores the LLM's `decision` and is driven
/// Dispatch an `evaluate_when[]` entry to its detection kind.
///
/// `policy_name` and `evaluate_when_index` thread the
/// AC10-Corr correlation context (v8 plan PR6) through to the LLM /
/// classifier instrumentation so every `LlmCalled` /
/// `ClassifierCalled` emit carries `KEY_GUARD_POLICY` and
/// `KEY_GUARD_POLICY_EVALUATE_WHEN_INDEX` regardless of whether the
/// adopter also enabled stage-level perf events. The non-LLM/classifier
/// detection kinds ignore both arguments.
pub fn detect(
    entry: &EvaluateWhenEntry,
    subject: &str,
    effective_action: crate::guard_policy::Action,
    policy_name: &str,
    evaluate_when_index: usize,
    deps: &DetectionDeps<'_>,
) -> DetectionVerdict {
    match &entry.detection {
        DetectionKind::Expression(expr) => detect_expression(expr, &entry.reason, deps),
        DetectionKind::Pattern(pat) => {
            detect_patterns(std::slice::from_ref(pat), &entry.reason, subject, deps)
        }
        DetectionKind::Patterns(pats) => detect_patterns(pats, &entry.reason, subject, deps),
        DetectionKind::Llm(llm) => detect_llm(
            llm,
            subject,
            &entry.reason,
            effective_action,
            policy_name,
            evaluate_when_index,
            deps,
        ),
        DetectionKind::Classifier(c) => detect_classifier(
            c,
            subject,
            &entry.reason,
            policy_name,
            evaluate_when_index,
            deps,
        ),
    }
}

fn detect_expression(expr: &str, reason: &str, deps: &DetectionDeps<'_>) -> DetectionVerdict {
    let mut ctx = EvalContext::from_attrs(deps.attrs);
    ctx.status_lookup = deps.status_lookup;
    ctx.event_fired = deps.event_fired;
    ctx.predicates = deps.predicates;
    ctx.is_gating_site = true;
    ctx.resolver_hook = deps.resolver_hook;
    if evaluate_with(expr, &ctx) {
        DetectionVerdict::Pass
    } else {
        DetectionVerdict::fail(reason.to_string())
    }
}

fn detect_patterns(
    pats: &[String],
    reason: &str,
    subject: &str,
    deps: &DetectionDeps<'_>,
) -> DetectionVerdict {
    let mut spans: Vec<Span> = Vec::new();
    for raw in pats {
        let regex = match deps.regex_cache.compile(raw) {
            Ok(r) => r,
            Err(_) => {
                // Fail-closed on a bad regex: report the entry's reason.
                return DetectionVerdict::fail(format!("{} (invalid regex)", reason));
            }
        };
        for m in regex.find_iter(subject) {
            // Convert byte offsets from the regex engine to char offsets;
            // the rest of the pipeline (apply_redactions et al.) speaks
            // chars per spec.
            let start_char = subject[..m.start()].chars().count();
            let end_char = start_char + subject[m.start()..m.end()].chars().count();
            spans.push(Span {
                start: start_char,
                end: end_char,
                replacement: None,
            });
        }
    }
    if spans.is_empty() {
        DetectionVerdict::Pass
    } else {
        DetectionVerdict::fail_spans(reason.to_string(), spans)
    }
}

#[allow(clippy::too_many_arguments)]
fn detect_llm(
    llm: &LlmDetection,
    subject: &str,
    reason: &str,
    effective_action: crate::guard_policy::Action,
    policy_name: &str,
    evaluate_when_index: usize,
    deps: &DetectionDeps<'_>,
) -> DetectionVerdict {
    let Some(caller) = deps.llm_caller else {
        // No host caller registered → fail closed (§12.9.3 default).
        return DetectionVerdict::fail(format!("{} (no LLM caller registered)", reason));
    };
    // Build the rendered prompt: substitute the canonical and extra
    // template variables, then append the subject as plain context.
    let mut rendered = deps.render_prompt(&llm.prompt);
    if !rendered.contains("{subject}") && !subject.is_empty() {
        rendered.push_str("\n\n");
        rendered.push_str(subject);
    } else {
        rendered = rendered.replace("{subject}", subject);
    }

    // v8 perf-logging PR6: time the host call and emit `LlmCalled`
    // with AC10-Corr correlation attributes (policy_name + stage +
    // evaluate_when_index) so adopters at PerfTelemetry::External can
    // attribute LLM cost to the triggering policy without a parent
    // detection event.
    let perf_on = deps.perf_telemetry.emit_llm_events()
        && deps.clock.is_some()
        && deps.observability.is_some();
    let t0 = if perf_on {
        deps.clock.map(|c| c.now())
    } else {
        None
    };
    let result = caller.call(llm.configuration.as_deref(), &rendered);
    if let (Some(start), Some(clock), Some(obs)) = (t0, deps.clock, deps.observability) {
        let elapsed_ms = clock.now().duration_since(start).as_millis() as u64;
        let (decision_str, confidence): (Option<&str>, Option<f64>) = match &result {
            Ok(resp) => {
                let dec = if matches!(effective_action, crate::guard_policy::Action::Redact) {
                    // Redact mode ignores decision; the spans drive the verdict.
                    if resp.spans.is_empty() {
                        "allow"
                    } else {
                        "block"
                    }
                } else {
                    match resp.folded_decision() {
                        LlmDecision::Allow => "allow",
                        LlmDecision::Block => "block",
                    }
                };
                (Some(dec), resp.confidence)
            }
            // §12.9.3: transport / parse failure folds to block.
            Err(_) => (Some("block"), None),
        };
        crate::observability::log_llm_called(
            obs,
            deps.session_id,
            deps.correlation_id,
            deps.stage,
            policy_name,
            evaluate_when_index,
            llm.configuration.as_deref(),
            elapsed_ms,
            decision_str,
            confidence,
        );
    }

    match result {
        Ok(resp) => {
            // §12.9.3: for `action: redact` the LLM's `decision` is
            // IGNORED and the returned `spans` drive the rewrite. Empty
            // spans are a no-op (Pass); non-empty spans are a redaction
            // failure regardless of decision.
            if matches!(effective_action, crate::guard_policy::Action::Redact) {
                if resp.spans.is_empty() {
                    return DetectionVerdict::Pass;
                }
                let r = resp.reason.clone().unwrap_or_else(|| reason.to_string());
                return DetectionVerdict::fail_spans(r, resp.spans);
            }
            match resp.folded_decision() {
                LlmDecision::Allow => DetectionVerdict::Pass,
                LlmDecision::Block => {
                    let r = resp.reason.clone().unwrap_or_else(|| reason.to_string());
                    DetectionVerdict::fail_spans(r, resp.spans)
                }
            }
        }
        Err(_) => DetectionVerdict::fail(format!("{} (LLM call failed)", reason)),
    }
}

fn detect_classifier(
    c: &ClassifierDetection,
    subject: &str,
    reason: &str,
    policy_name: &str,
    evaluate_when_index: usize,
    deps: &DetectionDeps<'_>,
) -> DetectionVerdict {
    let Some(caller) = deps.classifier_caller else {
        return DetectionVerdict::fail(format!("{} (no classifier caller registered)", reason));
    };

    // v8 perf-logging PR6: same instrumentation shape as detect_llm.
    let perf_on = deps.perf_telemetry.emit_classifier_events()
        && deps.clock.is_some()
        && deps.observability.is_some();
    let t0 = if perf_on {
        deps.clock.map(|c| c.now())
    } else {
        None
    };
    let result = caller.classify(&c.configuration, subject);
    if let (Some(start), Some(clock), Some(obs)) = (t0, deps.clock, deps.observability) {
        let elapsed_ms = clock.now().duration_since(start).as_millis() as u64;
        let (score, threshold, flagged, label) = match &result {
            Ok(v) => (
                Some(v.score),
                Some(v.threshold),
                Some(v.is_failure()),
                v.label.as_deref(),
            ),
            // Transport failure: fail-closed with a synthetic flagged=true
            // verdict (mirrors the .NET ClassifierVerdict fallback).
            Err(_) => (None, None, Some(true), None),
        };
        crate::observability::log_classifier_called(
            obs,
            deps.session_id,
            deps.correlation_id,
            deps.stage,
            policy_name,
            evaluate_when_index,
            &c.configuration,
            elapsed_ms,
            score,
            threshold,
            flagged,
            label,
        );
    }

    match result {
        Ok(verdict) => {
            if verdict.is_failure() {
                let r = verdict.reason.clone().unwrap_or_else(|| reason.to_string());
                DetectionVerdict::fail_spans(r, verdict.spans)
            } else {
                DetectionVerdict::Pass
            }
        }
        Err(_) => DetectionVerdict::fail(format!("{} (classifier call failed)", reason)),
    }
}

// ── Stub host wiring ────────────────────────────────────────────────

/// Convenience newtype wrapping an `Arc<dyn LlmCaller>` so the engine can
/// hold a single-typed slot without exposing trait objects in its public
/// fields.
#[derive(Clone)]
pub struct LlmCallerArc(pub Arc<dyn LlmCaller>);

#[derive(Clone)]
pub struct ClassifierCallerArc(pub Arc<dyn ClassifierCaller>);

#[cfg(test)]
mod tests {
    use super::*;
    use crate::guard_policy::EvaluateWhenEntry;

    fn entry_pat(reason: &str, p: &str) -> EvaluateWhenEntry {
        EvaluateWhenEntry {
            detection: DetectionKind::Pattern(p.to_string()),
            reason: reason.into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
        }
    }

    fn entry_pats(reason: &str, p: Vec<&str>) -> EvaluateWhenEntry {
        EvaluateWhenEntry {
            detection: DetectionKind::Patterns(p.iter().map(|s| s.to_string()).collect()),
            reason: reason.into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
        }
    }

    fn entry_expr(reason: &str, e: &str) -> EvaluateWhenEntry {
        EvaluateWhenEntry {
            detection: DetectionKind::Expression(e.to_string()),
            reason: reason.into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
        }
    }

    fn deps_for<'a>(attrs: &'a HashMap<String, Value>, cache: &'a RegexCache) -> DetectionDeps<'a> {
        DetectionDeps {
            regex_cache: cache,
            llm_caller: None,
            classifier_caller: None,
            objective: "",
            forbidden: &[],
            user_input: "",
            extra_template_vars: HashMap::new(),
            attrs,
            status_lookup: None,
            event_fired: None,
            predicates: None,
            resolver_hook: None,
            append_runtime_context: false,
            // v8 PR6: perf-instrumentation context. Defaults disable
            // every new emission so legacy unit tests stay byte-stable.
            clock: None,
            observability: None,
            perf_telemetry: crate::perf_telemetry::PerfTelemetry::Off,
            stage: crate::observability::Stage::Input,
            session_id: "",
            correlation_id: "",
        }
    }

    #[test]
    fn pattern_match_returns_fail_with_spans() {
        let e = entry_pat("ssn detected", r"\b\d{3}-\d{2}-\d{4}\b");
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        let v = detect(
            &e,
            "my ssn is 123-45-6789 ok",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps,
        );
        match v {
            DetectionVerdict::Fail { reason, spans } => {
                assert_eq!(reason, "ssn detected");
                assert_eq!(spans.len(), 1);
                assert_eq!(spans[0].start, 10);
                assert_eq!(spans[0].end, 21);
            }
            _ => panic!("expected fail"),
        }
    }

    #[test]
    fn pattern_no_match_returns_pass() {
        let e = entry_pat("nope", r"^never");
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        let v = detect(
            &e,
            "hello",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps,
        );
        assert!(v.is_pass());
    }

    #[test]
    fn patterns_any_match_fails() {
        let e = entry_pats("any pii", vec![r"\bSSN\b", r"\bcredit\b"]);
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        let v = detect(
            &e,
            "this is a credit card",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps,
        );
        assert!(!v.is_pass());
    }

    #[test]
    fn expression_truthy_passes() {
        let e = entry_expr("nope", "true");
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        assert!(detect(
            &e,
            "",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps
        )
        .is_pass());
    }

    #[test]
    fn expression_falsey_fails() {
        let e = entry_expr("must be true", "false");
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        assert!(!detect(
            &e,
            "",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps
        )
        .is_pass());
    }

    #[test]
    fn regex_too_long_is_fail_closed() {
        let p = "a".repeat(501);
        let e = entry_pat("nope", &p);
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        let v = detect(
            &e,
            "a",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps,
        );
        assert!(matches!(v, DetectionVerdict::Fail { .. }));
    }

    #[test]
    fn llm_no_caller_fails_closed() {
        let llm = LlmDetection {
            prompt_path: None,
            prompt: "x".into(),
            configuration: None,
        };
        let entry = EvaluateWhenEntry {
            detection: DetectionKind::Llm(llm),
            reason: "block".into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
        };
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        let v = detect(
            &entry,
            "subject",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps,
        );
        assert!(matches!(v, DetectionVerdict::Fail { .. }));
    }

    struct StubLlm {
        decision: LlmDecision,
        spans: Vec<Span>,
    }
    impl LlmCaller for StubLlm {
        fn call(&self, _: Option<&str>, _: &str) -> Result<LlmResponse, String> {
            Ok(LlmResponse {
                decision: Some(self.decision),
                confidence: None,
                reason: None,
                categories: vec![],
                spans: self.spans.clone(),
                bool_flags: HashMap::new(),
            })
        }
    }

    #[test]
    fn llm_block_decision_fails() {
        let stub = StubLlm {
            decision: LlmDecision::Block,
            spans: vec![],
        };
        let llm = LlmDetection {
            prompt_path: None,
            prompt: "x".into(),
            configuration: None,
        };
        let entry = EvaluateWhenEntry {
            detection: DetectionKind::Llm(llm),
            reason: "block".into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
        };
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let mut deps = deps_for(&attrs, &cache);
        deps.llm_caller = Some(&stub);
        let v = detect(
            &entry,
            "subject",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps,
        );
        assert!(matches!(v, DetectionVerdict::Fail { .. }));
    }

    #[test]
    fn llm_allow_decision_passes() {
        let stub = StubLlm {
            decision: LlmDecision::Allow,
            spans: vec![],
        };
        let llm = LlmDetection {
            prompt_path: None,
            prompt: "x".into(),
            configuration: None,
        };
        let entry = EvaluateWhenEntry {
            detection: DetectionKind::Llm(llm),
            reason: "block".into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
        };
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let mut deps = deps_for(&attrs, &cache);
        deps.llm_caller = Some(&stub);
        let v = detect(
            &entry,
            "subject",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps,
        );
        assert!(v.is_pass());
    }

    struct StubClassifier {
        score: f64,
        threshold: f64,
        flagged: bool,
    }
    impl ClassifierCaller for StubClassifier {
        fn classify(&self, _: &str, _: &str) -> Result<ClassifierVerdict, String> {
            Ok(ClassifierVerdict {
                score: self.score,
                threshold: self.threshold,
                flagged: self.flagged,
                label: None,
                reason: None,
                spans: vec![],
            })
        }
    }

    #[test]
    fn classifier_score_above_threshold_fails() {
        let stub = StubClassifier {
            score: 0.8,
            threshold: 0.5,
            flagged: false,
        };
        let entry = EvaluateWhenEntry {
            detection: DetectionKind::Classifier(ClassifierDetection {
                configuration: "cls".into(),
            }),
            reason: "moderation".into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
        };
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let mut deps = deps_for(&attrs, &cache);
        deps.classifier_caller = Some(&stub);
        let v = detect(
            &entry,
            "subject",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps,
        );
        assert!(matches!(v, DetectionVerdict::Fail { .. }));
    }

    #[test]
    fn classifier_below_threshold_passes() {
        let stub = StubClassifier {
            score: 0.2,
            threshold: 0.5,
            flagged: false,
        };
        let entry = EvaluateWhenEntry {
            detection: DetectionKind::Classifier(ClassifierDetection {
                configuration: "cls".into(),
            }),
            reason: "moderation".into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
        };
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let mut deps = deps_for(&attrs, &cache);
        deps.classifier_caller = Some(&stub);
        let v = detect(
            &entry,
            "subject",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps,
        );
        assert!(v.is_pass());
    }

    #[test]
    fn classifier_no_caller_fails_closed() {
        let entry = EvaluateWhenEntry {
            detection: DetectionKind::Classifier(ClassifierDetection {
                configuration: "cls".into(),
            }),
            reason: "moderation".into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
        };
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        let v = detect(
            &entry,
            "subject",
            crate::guard_policy::Action::Block,
            "test_policy",
            0,
            &deps,
        );
        assert!(matches!(v, DetectionVerdict::Fail { .. }));
    }

    #[test]
    fn template_substitution_works() {
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let mut deps = deps_for(&attrs, &cache);
        deps.user_input = "hello world";
        deps.objective = "be helpful";
        let rendered = deps.render_prompt("input={user_input} obj={objective}");
        assert_eq!(rendered, "input=hello world obj=be helpful");
    }

    #[test]
    fn template_undefined_becomes_empty() {
        let cache = RegexCache::new();
        let attrs = HashMap::new();
        let deps = deps_for(&attrs, &cache);
        let rendered = deps.render_prompt("v={does_not_exist}");
        // Note: undefined tokens are *not* substituted by our simple
        // string replacer; they pass through. Per §12.9.2 they should
        // become empty. Hosts wanting strict spec semantics should do
        // their own templating; this helper is best-effort.
        assert!(rendered.contains("{does_not_exist}") || rendered == "v=");
    }

    #[test]
    fn llm_bool_flag_truthy_blocks() {
        let mut flags = HashMap::new();
        flags.insert("contains_pii".to_string(), true);
        let resp = LlmResponse {
            decision: Some(LlmDecision::Allow), // overridden by truthy bool flag
            bool_flags: flags,
            ..Default::default()
        };
        assert_eq!(resp.folded_decision(), LlmDecision::Block);
    }

    #[test]
    fn llm_missing_decision_blocks() {
        let resp = LlmResponse::default();
        assert_eq!(resp.folded_decision(), LlmDecision::Block);
    }

    // ── v8 PR6 perf-instrumentation tests ─────────────────────────
    //
    // Cover the AC10-Corr correlation contract + the PerfTelemetry
    // gating table for LLM / classifier detection. The stage runner
    // gating (`StageEvaluated`) lives in stage_timing::tests; this
    // module owns the LLM / classifier side.

    use crate::clock::mock::MockClock;
    use crate::event_bus::EventBus;
    use crate::observability::attributes::{
        KEY_CLASSIFIER_CONFIGURATION_ID, KEY_CLASSIFIER_FLAGGED, KEY_CLASSIFIER_LABEL,
        KEY_CLASSIFIER_SCORE, KEY_CLASSIFIER_THRESHOLD, KEY_DURATION_MS, KEY_EVALUATE_WHEN_INDEX,
        KEY_EVENT_TYPE, KEY_GUARD_POLICY, KEY_LLM_CONFIGURATION_ID, KEY_LLM_DECISION, KEY_STAGE,
    };
    use crate::observability::test_support::CaptureProvider;
    use crate::observability::{EventType, ObservabilityDispatcher, Stage};
    use crate::perf_telemetry::PerfTelemetry;
    use std::sync::Arc;
    use std::time::Duration;

    /// Always-block stub LLM that does not flag any bool fields. The
    /// host's `LlmResponse::folded_decision` returns `Block`.
    struct AlwaysBlockLlm;
    impl LlmCaller for AlwaysBlockLlm {
        fn call(&self, _cfg: Option<&str>, _prompt: &str) -> Result<LlmResponse, String> {
            Ok(LlmResponse {
                decision: Some(LlmDecision::Block),
                confidence: Some(0.92),
                reason: Some("policy violation".into()),
                ..Default::default()
            })
        }
    }

    /// Always-flagged stub classifier (score > threshold).
    struct AlwaysFlaggedClassifier;
    impl ClassifierCaller for AlwaysFlaggedClassifier {
        fn classify(&self, _cfg: &str, _subject: &str) -> Result<ClassifierVerdict, String> {
            Ok(ClassifierVerdict {
                score: 0.93,
                threshold: 0.5,
                flagged: true,
                label: Some("pii".into()),
                reason: Some("ssn detected".into()),
                ..Default::default()
            })
        }
    }

    /// Bundle the shared scaffolding so each test stays short.
    struct PerfFixture {
        dispatcher: Arc<ObservabilityDispatcher>,
        provider: Arc<CaptureProvider>,
        cache: RegexCache,
        clock: MockClock,
    }

    fn perf_fixture() -> PerfFixture {
        let bus = EventBus::new();
        let dispatcher = ObservabilityDispatcher::new(bus);
        let provider = CaptureProvider::new();
        dispatcher.register_provider(provider.clone());
        PerfFixture {
            dispatcher,
            provider,
            cache: RegexCache::new(),
            clock: MockClock::new(),
        }
    }

    fn perf_deps<'a>(
        fx: &'a PerfFixture,
        attrs: &'a HashMap<String, Value>,
        perf_telemetry: PerfTelemetry,
        llm: Option<&'a dyn LlmCaller>,
        classifier: Option<&'a dyn ClassifierCaller>,
    ) -> DetectionDeps<'a> {
        DetectionDeps {
            regex_cache: &fx.cache,
            llm_caller: llm,
            classifier_caller: classifier,
            objective: "be safe",
            forbidden: &[],
            user_input: "",
            extra_template_vars: HashMap::new(),
            attrs,
            status_lookup: None,
            event_fired: None,
            predicates: None,
            resolver_hook: None,
            append_runtime_context: false,
            clock: Some(&fx.clock),
            observability: Some(fx.dispatcher.as_ref()),
            perf_telemetry,
            stage: Stage::Input,
            session_id: "sess-perf",
            correlation_id: "corr-perf",
        }
    }

    fn llm_entry() -> EvaluateWhenEntry {
        EvaluateWhenEntry {
            detection: DetectionKind::Llm(LlmDetection {
                prompt_path: None,
                prompt: "decide".into(),
                configuration: Some("fast-haiku".into()),
            }),
            reason: "policy-violation".into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
        }
    }

    fn classifier_entry() -> EvaluateWhenEntry {
        EvaluateWhenEntry {
            detection: DetectionKind::Classifier(ClassifierDetection {
                configuration: "lakera-pii".into(),
            }),
            reason: "classifier-fail".into(),
            action: None,
            replacement: None,
            text: None,
            paths: vec![],
            log: None,
        }
    }

    fn count_events_of(provider: &CaptureProvider, kind: &EventType) -> usize {
        provider
            .events
            .lock()
            .unwrap()
            .iter()
            .filter(|e| &e.event_type == kind)
            .count()
    }

    #[test]
    fn llm_emits_at_external() {
        let fx = perf_fixture();
        let attrs = HashMap::new();
        let llm = AlwaysBlockLlm;
        let deps = perf_deps(&fx, &attrs, PerfTelemetry::External, Some(&llm), None);
        fx.clock.advance(Duration::from_millis(0)); // baseline so the second tick produces > 0
        let _ = detect(
            &llm_entry(),
            "subject",
            crate::guard_policy::Action::Block,
            "send_requires_authz",
            3,
            &deps,
        );
        assert_eq!(count_events_of(&fx.provider, &EventType::LlmCalled), 1);
        // Gating: External must NOT emit stage/policy events.
        assert_eq!(count_events_of(&fx.provider, &EventType::StageEvaluated), 0);
        assert_eq!(
            count_events_of(&fx.provider, &EventType::PolicyEvaluated),
            0
        );
    }

    #[test]
    fn llm_emits_at_full() {
        let fx = perf_fixture();
        let attrs = HashMap::new();
        let llm = AlwaysBlockLlm;
        let deps = perf_deps(&fx, &attrs, PerfTelemetry::Full, Some(&llm), None);
        let _ = detect(
            &llm_entry(),
            "subject",
            crate::guard_policy::Action::Block,
            "p",
            0,
            &deps,
        );
        assert_eq!(count_events_of(&fx.provider, &EventType::LlmCalled), 1);
    }

    #[test]
    fn llm_silent_at_off() {
        let fx = perf_fixture();
        let attrs = HashMap::new();
        let llm = AlwaysBlockLlm;
        let deps = perf_deps(&fx, &attrs, PerfTelemetry::Off, Some(&llm), None);
        let _ = detect(
            &llm_entry(),
            "subject",
            crate::guard_policy::Action::Block,
            "p",
            0,
            &deps,
        );
        assert_eq!(count_events_of(&fx.provider, &EventType::LlmCalled), 0);
    }

    #[test]
    fn llm_carries_correlation_attrs() {
        // AC10-Corr — every LlmCalled event MUST carry
        // KEY_GUARD_POLICY + KEY_STAGE + KEY_GUARD_POLICY_EVALUATE_WHEN_INDEX
        // so adopters at PerfTelemetry::External can attribute LLM
        // cost back to the triggering policy without a parent
        // StageEvaluated / PolicyEvaluated event.
        let fx = perf_fixture();
        let attrs = HashMap::new();
        let llm = AlwaysBlockLlm;
        let deps = perf_deps(&fx, &attrs, PerfTelemetry::External, Some(&llm), None);
        fx.clock.advance(Duration::from_millis(0));
        let _ = detect(
            &llm_entry(),
            "subject",
            crate::guard_policy::Action::Block,
            "wire_transfer_safety",
            // Zero is a legitimate index — the first evaluate_when[]
            // entry. The assertion below MUST accept it.
            0,
            &deps,
        );
        let events = fx.provider.events.lock().unwrap();
        let ev = events
            .iter()
            .find(|e| matches!(e.event_type, EventType::LlmCalled))
            .expect("LlmCalled must emit at External");
        let policy = ev
            .attributes
            .get(KEY_GUARD_POLICY)
            .and_then(|v| v.as_str())
            .expect("KEY_GUARD_POLICY must be a string");
        assert!(!policy.is_empty(), "policy name must be non-empty");
        assert_eq!(policy, "wire_transfer_safety");
        let stage_v = ev
            .attributes
            .get(KEY_STAGE)
            .and_then(|v| v.as_str())
            .expect("KEY_STAGE must be a string");
        assert!(!stage_v.is_empty(), "stage must be non-empty");
        let idx_v = ev
            .attributes
            .get(KEY_EVALUATE_WHEN_INDEX)
            .expect("KEY_GUARD_POLICY_EVALUATE_WHEN_INDEX must be present");
        assert!(
            idx_v.as_u64().is_some(),
            "evaluate_when_index must be a u64 (zero IS valid)"
        );
        // LLM-specific attrs follow on for the audit trail.
        assert_eq!(
            ev.attributes
                .get(KEY_LLM_CONFIGURATION_ID)
                .and_then(|v| v.as_str()),
            Some("fast-haiku")
        );
        assert_eq!(
            ev.attributes.get(KEY_LLM_DECISION).and_then(|v| v.as_str()),
            Some("block"),
            "AlwaysBlockLlm folded_decision is Block"
        );
        assert_eq!(
            ev.attributes.get(KEY_EVENT_TYPE).and_then(|v| v.as_str()),
            Some("llm_called")
        );
        // KEY_DURATION_MS is present (MockClock did not advance between
        // start and stop, so the recorded value is 0 — still a valid
        // duration; the test asserts the FIELD exists, not the value).
        assert!(ev.attributes.contains_key(KEY_DURATION_MS));
    }

    #[test]
    fn classifier_emits_at_external() {
        let fx = perf_fixture();
        let attrs = HashMap::new();
        let cl = AlwaysFlaggedClassifier;
        let deps = perf_deps(&fx, &attrs, PerfTelemetry::External, None, Some(&cl));
        let _ = detect(
            &classifier_entry(),
            "subject",
            crate::guard_policy::Action::Block,
            "pii_guard",
            1,
            &deps,
        );
        assert_eq!(
            count_events_of(&fx.provider, &EventType::ClassifierCalled),
            1
        );
        assert_eq!(count_events_of(&fx.provider, &EventType::StageEvaluated), 0);
    }

    #[test]
    fn classifier_emits_at_full() {
        let fx = perf_fixture();
        let attrs = HashMap::new();
        let cl = AlwaysFlaggedClassifier;
        let deps = perf_deps(&fx, &attrs, PerfTelemetry::Full, None, Some(&cl));
        let _ = detect(
            &classifier_entry(),
            "subject",
            crate::guard_policy::Action::Block,
            "p",
            0,
            &deps,
        );
        assert_eq!(
            count_events_of(&fx.provider, &EventType::ClassifierCalled),
            1
        );
    }

    #[test]
    fn classifier_silent_at_off() {
        let fx = perf_fixture();
        let attrs = HashMap::new();
        let cl = AlwaysFlaggedClassifier;
        let deps = perf_deps(&fx, &attrs, PerfTelemetry::Off, None, Some(&cl));
        let _ = detect(
            &classifier_entry(),
            "subject",
            crate::guard_policy::Action::Block,
            "p",
            0,
            &deps,
        );
        assert_eq!(
            count_events_of(&fx.provider, &EventType::ClassifierCalled),
            0
        );
    }

    #[test]
    fn classifier_carries_correlation_attrs() {
        let fx = perf_fixture();
        let attrs = HashMap::new();
        let cl = AlwaysFlaggedClassifier;
        let deps = perf_deps(&fx, &attrs, PerfTelemetry::External, None, Some(&cl));
        let _ = detect(
            &classifier_entry(),
            "subject",
            crate::guard_policy::Action::Block,
            "pii_guard",
            0,
            &deps,
        );
        let events = fx.provider.events.lock().unwrap();
        let ev = events
            .iter()
            .find(|e| matches!(e.event_type, EventType::ClassifierCalled))
            .expect("ClassifierCalled must emit at External");
        assert_eq!(
            ev.attributes.get(KEY_GUARD_POLICY).and_then(|v| v.as_str()),
            Some("pii_guard")
        );
        assert_eq!(
            ev.attributes.get(KEY_STAGE).and_then(|v| v.as_str()),
            Some("input")
        );
        assert!(ev
            .attributes
            .get(KEY_EVALUATE_WHEN_INDEX)
            .and_then(|v| v.as_u64())
            .is_some());
        assert_eq!(
            ev.attributes
                .get(KEY_CLASSIFIER_CONFIGURATION_ID)
                .and_then(|v| v.as_str()),
            Some("lakera-pii")
        );
        assert_eq!(
            ev.attributes
                .get(KEY_CLASSIFIER_SCORE)
                .and_then(|v| v.as_f64()),
            Some(0.93)
        );
        assert_eq!(
            ev.attributes
                .get(KEY_CLASSIFIER_THRESHOLD)
                .and_then(|v| v.as_f64()),
            Some(0.5)
        );
        assert_eq!(
            ev.attributes
                .get(KEY_CLASSIFIER_FLAGGED)
                .and_then(|v| v.as_bool()),
            Some(true)
        );
        assert_eq!(
            ev.attributes
                .get(KEY_CLASSIFIER_LABEL)
                .and_then(|v| v.as_str()),
            Some("pii")
        );
    }
}
