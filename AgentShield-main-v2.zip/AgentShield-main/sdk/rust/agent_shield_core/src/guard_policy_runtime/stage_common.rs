//! Cross-stage helpers shared by the per-stage runners.
//!
//! Each per-stage runner builds the same family of adapters (status,
//! predicate, resolver, event-fired) before walking its policy list.
//! This module owns the construction so the per-stage files stay focused
//! on the spec rules unique to their stage.

use std::collections::HashMap;
use std::sync::Mutex;

use serde_json::Value;

use crate::expressions::eval::ResolverHook;
use crate::guard_policy::{Action, GuardPolicy};
use crate::lifetime_tracker::{LifetimeTracker, VarStatus};
use crate::observability::{log_gating_verdict, log_guard_policy_evaluation, Stage};
use crate::session_id::SessionId;
use crate::variables::Variable;

use super::detection::{ClassifierCaller, DetectionDeps, LlmCaller};
use super::evaluate_when::{AllowedWhenDeps, BlockedEntry, EvaluationOutcome};
use super::runtime_hooks::{PredicateMapLookup, TrackerStatusLookup};
use super::{EvalRuntime, GuardPolicyEngine, StageVerdict};

/// Build the resolver-hook adapter for a single per-stage call. Lives
/// inside a shared owner that keeps the trait object alive while the
/// stage runner threads `&dyn ResolverHook` into [`DetectionDeps`].
pub struct ResolverHookHolder<'a> {
    pub adapter: crate::resolver_runtime::AutoResolveAdapter<'a>,
    /// Mirror of attribute writes performed on `Allow` resolutions. The
    /// engine doesn't currently re-bind these into the expression
    /// evaluator — the resolver's `set_variables:` landing on the
    /// tracker emits `variable.<name>.changed` events which the
    /// evaluator reads via the StatusLookup adapter.
    #[allow(dead_code)]
    pub trace: Mutex<Vec<(String, Option<Value>)>>,
}

impl<'a> ResolverHook for ResolverHookHolder<'a> {
    fn resolve(&self, var: &str) -> Option<Value> {
        let v = self.adapter.resolve(var);
        self.trace
            .lock()
            .unwrap()
            .push((var.to_string(), v.clone()));
        v
    }
}

/// Build a [`DetectionDeps`] for the active stage. Borrows the engine,
/// the per-call attrs, and an optional `ResolverHook` produced by the
/// caller (so the caller controls lifetime).
#[allow(clippy::too_many_arguments)]
pub fn build_detection_deps<'a>(
    engine: &'a GuardPolicyEngine,
    ctx: &'a EvalRuntime<'_>,
    attrs: &'a HashMap<String, Value>,
    status_lookup: Option<&'a TrackerStatusLookup<'a>>,
    predicates: Option<&'a PredicateMapLookup<'a>>,
    resolver_hook: Option<&'a dyn ResolverHook>,
    extra_template_vars: HashMap<String, String>,
    append_runtime_context: bool,
    stage: Stage,
) -> DetectionDeps<'a> {
    build_detection_deps_with_event_hook(
        engine,
        ctx,
        attrs,
        status_lookup,
        predicates,
        resolver_hook,
        None,
        extra_template_vars,
        append_runtime_context,
        stage,
    )
}

/// Variant of [`build_detection_deps`] that lets the caller plug in a
/// session-scoped [`crate::expressions::eval::EventFiredHook`] (e.g.
/// [`super::runtime_hooks::SessionScopedEventFired`]) so
/// `event.fired(<id>)` calls inside expressions consult only that
/// session's latches. Pass `None` to fall back to the cross-session
/// event bus query (legacy / default-session callers).
///
/// Build a [`DetectionDeps`] that gathers everything a guard-policy
/// detection step needs to evaluate against a session.
///
/// Several arguments are `Option<&'a ...>` rather than `&'a ...` so
/// callers that don't have a particular hook (or are calling from a
/// non-gating site) can pass `None`. Engine internals already do the
/// session-scoped wiring; external callers (a few integration tests)
/// pass `None` and accept the legacy / fail-closed defaults.
///
/// `event_fired` threads a session-scoped `event.fired()` lookup hook
/// (per [`super::runtime_hooks::SessionScopedEventFired`]) so
/// `event.fired(<id>)` calls inside expressions consult only that
/// session's latches. Pass `None` to fall back to the cross-session
/// event bus query (legacy / default-session callers).
#[allow(clippy::too_many_arguments)]
pub fn build_detection_deps_with_event_hook<'a>(
    engine: &'a GuardPolicyEngine,
    ctx: &'a EvalRuntime<'_>,
    attrs: &'a HashMap<String, Value>,
    status_lookup: Option<&'a TrackerStatusLookup<'a>>,
    predicates: Option<&'a PredicateMapLookup<'a>>,
    resolver_hook: Option<&'a dyn ResolverHook>,
    event_fired: Option<&'a dyn crate::expressions::eval::EventFiredHook>,
    extra_template_vars: HashMap<String, String>,
    append_runtime_context: bool,
    stage: Stage,
) -> DetectionDeps<'a> {
    let bus_fallback: Option<&'a dyn crate::expressions::eval::EventFiredHook> =
        Some(&engine.deps().event_bus);
    DetectionDeps {
        regex_cache: engine.regex_cache(),
        llm_caller: engine
            .deps()
            .llm_caller
            .as_deref()
            .map(|c| c as &dyn LlmCaller),
        classifier_caller: engine
            .deps()
            .classifier_caller
            .as_deref()
            .map(|c| c as &dyn ClassifierCaller),
        objective: ctx.objective,
        forbidden: ctx.forbidden,
        user_input: ctx.user_input,
        extra_template_vars,
        attrs,
        status_lookup: status_lookup.map(|s| s as &dyn crate::expressions::eval::StatusLookup),
        event_fired: event_fired.or(bus_fallback),
        predicates: predicates.map(|p| p as &dyn crate::expressions::eval::PredicateLookup),
        resolver_hook,
        append_runtime_context,
        // v8 PR6: thread the perf-telemetry timing context through so
        // detect_llm / detect_classifier and run_evaluate_when can
        // stamp KEY_DURATION_MS + AC10-Corr correlation attributes.
        clock: Some(engine.deps().clock.as_ref()),
        observability: Some(engine.deps().observability.as_ref()),
        perf_telemetry: engine.deps().perf_telemetry,
        stage,
        session_id: ctx.session_id,
        correlation_id: ctx.correlation_id,
    }
}

pub fn build_allowed_when_deps<'a>(
    engine: &'a GuardPolicyEngine,
    attrs: &'a HashMap<String, Value>,
    status_lookup: Option<&'a TrackerStatusLookup<'a>>,
    predicates: Option<&'a PredicateMapLookup<'a>>,
    resolver_hook: Option<&'a dyn ResolverHook>,
) -> AllowedWhenDeps<'a> {
    build_allowed_when_deps_with_event_hook(
        engine,
        attrs,
        status_lookup,
        predicates,
        resolver_hook,
        None,
    )
}

/// Variant of [`build_allowed_when_deps`] that accepts a session-scoped
/// `event_fired` hook. See [`build_detection_deps_with_event_hook`] for
/// rationale.
#[allow(clippy::too_many_arguments)]
pub fn build_allowed_when_deps_with_event_hook<'a>(
    engine: &'a GuardPolicyEngine,
    attrs: &'a HashMap<String, Value>,
    status_lookup: Option<&'a TrackerStatusLookup<'a>>,
    predicates: Option<&'a PredicateMapLookup<'a>>,
    resolver_hook: Option<&'a dyn ResolverHook>,
    event_fired: Option<&'a dyn crate::expressions::eval::EventFiredHook>,
) -> AllowedWhenDeps<'a> {
    let bus_fallback: Option<&'a dyn crate::expressions::eval::EventFiredHook> =
        Some(&engine.deps().event_bus);
    AllowedWhenDeps {
        attrs,
        status_lookup: status_lookup.map(|s| s as &dyn crate::expressions::eval::StatusLookup),
        event_fired: event_fired.or(bus_fallback),
        predicates: predicates.map(|p| p as &dyn crate::expressions::eval::PredicateLookup),
        resolver_hook,
    }
}

/// Helper invoked by every stage runner: emit the standard set of
/// observability events for the outcome of one guard policy evaluation.
pub fn log_outcome(
    engine: &GuardPolicyEngine,
    stage: Stage,
    policy: &GuardPolicy,
    outcome: &EvaluationOutcome,
) {
    log_outcome_in(&SessionId::default(), engine, stage, policy, outcome);
}

/// Session-scoped variant of [`log_outcome`].
pub fn log_outcome_in(
    session_id: &SessionId,
    engine: &GuardPolicyEngine,
    stage: Stage,
    policy: &GuardPolicy,
    outcome: &EvaluationOutcome,
) {
    let bus = &engine.deps().event_bus;
    let obs = engine.deps().observability.as_ref();

    if let Some(b) = &outcome.block {
        log_guard_policy_evaluation(
            obs,
            session_id.as_str(),
            &policy.name,
            stage,
            Some(b.entry_index),
            Some(Action::Block),
            &b.reason,
            false,
        );
        let _ = bus.emit_guard_policy_failed_in(session_id, policy.name.clone());
        return;
    }

    for w in &outcome.warns {
        log_guard_policy_evaluation(
            obs,
            session_id.as_str(),
            &policy.name,
            stage,
            Some(w.entry_index),
            Some(Action::Warn),
            &w.reason,
            false,
        );
    }
    if outcome.allowed_when_bypass_fired {
        for idx in &outcome.bypassed_entries {
            log_guard_policy_evaluation(
                obs,
                session_id.as_str(),
                &policy.name,
                stage,
                Some(*idx),
                None,
                "allowed_when bypass",
                true,
            );
        }
    }
    if !outcome.any_failed
        && outcome.warns.is_empty()
        && outcome.redactions.is_empty()
        && outcome.appends.is_empty()
        && outcome.prepends.is_empty()
    {
        log_guard_policy_evaluation(
            obs,
            session_id.as_str(),
            &policy.name,
            stage,
            None,
            None,
            "",
            false,
        );
    }

    let _ = bus.emit_guard_policy_passed_in(session_id, policy.name.clone());
}

/// Convert the outcome's blocked entry into a [`StageVerdict`].
pub fn block_verdict(policy: &GuardPolicy, blocked: &BlockedEntry) -> StageVerdict {
    StageVerdict::block(
        &policy.name,
        blocked.reason.clone(),
        Some(blocked.entry_index),
    )
}

pub fn emit_stage_verdict(
    engine: &GuardPolicyEngine,
    session_id: &SessionId,
    stage: Stage,
    verdict: &StageVerdict,
) {
    let obs = engine.deps().observability.as_ref();
    if verdict.allowed {
        log_gating_verdict(obs, session_id.as_str(), stage, true, "");
    } else {
        let r = verdict.reason.clone().unwrap_or_default();
        log_gating_verdict(obs, session_id.as_str(), stage, false, &r);
    }
}

/// Bind every declared variable currently `Resolved` in the tracker
/// into `attrs` so bare-name expression references (e.g.
/// `authorized == true`) see the cached value.
///
/// Per spec §3.6.1 / §15: state-stage gating reads variables by their
/// bare names. The expression evaluator's `ResolverHook` only fires
/// for `unset` variables that have an `on_demand_by:` resolver — every
/// other variable's value must already be in `attrs`. This helper is
/// called by each stage runner immediately after [`EvalRuntime::build_base_attrs`].
///
/// **Keyed variables (§9.4).** When a variable declares `key:`, the
/// runtime evaluates that expression against the reader's bound
/// namespace (the attrs map at this call site, which already contains
/// `@tool.*`, `@endpoint.*`, `@agent.*`, `@context.*`). The resolved
/// key is then used to look up the tracker's `(name, key)` slot. A
/// `null` key reads as `unset` per §9.4.2 and the variable is not
/// bound into attrs (subsequent reads fold to null and fail closed).
///
/// The bind preserves existing keys (e.g. `@tool`, `@endpoint`,
/// `@agent`, `@context`) — only resolved variables that are not
/// already present are written.
///
/// Legacy session-blind variant — equivalent to
/// [`bind_resolved_variables_in`] with [`SessionId::default`]. New
/// stage-runner code paths thread an explicit session id.
pub fn bind_resolved_variables(
    attrs: &mut HashMap<String, Value>,
    tracker: &LifetimeTracker,
    variables: &[Variable],
) {
    bind_resolved_variables_in(&SessionId::default(), attrs, tracker, variables);
}

/// Session-scoped variant of [`bind_resolved_variables`].
pub fn bind_resolved_variables_in(
    session_id: &SessionId,
    attrs: &mut HashMap<String, Value>,
    tracker: &LifetimeTracker,
    variables: &[Variable],
) {
    use crate::expressions::eval::{evaluate_to_value, EvalContext};

    for var in variables {
        if attrs.contains_key(&var.name) {
            continue;
        }

        // §9.4: keyed variable lookup. The reader's bound namespace
        // is the same `attrs` map we're populating; evaluate `key:`
        // against it (no auto-resolution, no predicate hooks — `key:`
        // is treated as a pure projection over the runtime namespaces
        // and currently-resolved session vars).
        let key_value: Option<Value> = if let Some(key_expr) = &var.key {
            let key_ctx = EvalContext::from_attrs(attrs);
            evaluate_to_value(key_expr, &key_ctx)
        } else {
            None
        };

        // A `null` key on a keyed variable reads as `unset` per
        // §9.4.2 / §9.4.4. Don't bind anything; subsequent
        // expression reads fold to null.
        if let Some(Value::Null) = key_value {
            continue;
        }

        let st = if var.key.is_some() {
            tracker.read_variable_keyed_in(session_id, &var.name, key_value.as_ref())
        } else {
            tracker.read_variable_in(session_id, &var.name)
        };
        if matches!(st.status, VarStatus::Resolved) {
            attrs.insert(var.name.clone(), st.value);
        }
    }
}
