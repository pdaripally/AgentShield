//! Chunk-aware streaming wrapper for streamed tool and output validation.
//!
//! [`StreamingGuard`] buffers incremental chunks of an output stream
//! (Stage 5) or a streamed tool result (Stage 4), runs the stage's
//! content guard policies on the assembled buffer, and decides whether
//! to emit, replace, or stop the stream.
//!
//! ## Modes
//!
//! - **on_complete** — buffer everything, validate once at `end_stream`.
//!   The strongest guarantee; equivalent to a non-streaming gate. Each
//!   [`StreamingGuard::add_chunk`] returns `Pass` with an empty payload;
//!   host SDKs MUST NOT yield text-bearing chunks to the consumer until
//!   [`StreamingGuard::end_stream`] returns the validated full text.
//! - **windowed** — re-validate every `window_size` bytes. Best-effort
//!   early detection. Holds back `overlap` bytes so violations spanning
//!   the window boundary are still caught at finalization.
//! - **per_chunk** — validate after every chunk.
//!
//! Host SDKs read the configured cadence from [`StreamingGuard::mode`]
//! and schedule emissions accordingly.
//!
//! ## Constants
//!
//! See [`DEFAULT_WINDOW_SIZE`] / [`DEFAULT_OVERLAP`] / [`LOOKBACK_WINDOW`] /
//! [`STREAM_BUFFER_MAX_BYTES`].

use std::sync::Arc;

use serde_json::{json, Value};

use crate::event_bus::EventBus;
use crate::observability::Stage;
use crate::populator::Invocation;
use crate::session_id::SessionId;

use super::{EvalRuntime, GuardPolicyEngine, StageVerdict};

pub use crate::constants::streaming::{
    DEFAULT_OVERLAP, DEFAULT_WINDOW_SIZE, LOOKBACK_WINDOW, STREAM_BUFFER_MAX_BYTES,
};

/// Validation cadence inside a streaming session.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum StreamingTrigger {
    #[default]
    OnComplete,
    Windowed,
    PerChunk,
}

/// What the host should do with the chunk just submitted.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum StreamChunkAction {
    /// Emit the payload as-is (or skip emitting if `payload.is_empty()`).
    Pass,
    /// Replace any prior emission tail with the new payload (used after
    /// a redaction rewrites already-buffered text).
    Replace,
    /// Block the stream — no further chunks accepted.
    Stop,
}

/// Verdict returned for each chunk submission.
#[derive(Debug, Clone)]
pub struct StreamChunkResult {
    pub action: StreamChunkAction,
    pub payload: String,
    pub reason: Option<String>,
}

impl StreamChunkResult {
    pub fn pass(payload: impl Into<String>) -> Self {
        Self {
            action: StreamChunkAction::Pass,
            payload: payload.into(),
            reason: None,
        }
    }
    pub fn buffered() -> Self {
        Self {
            action: StreamChunkAction::Pass,
            payload: String::new(),
            reason: None,
        }
    }
    pub fn replace(payload: impl Into<String>) -> Self {
        Self {
            action: StreamChunkAction::Replace,
            payload: payload.into(),
            reason: None,
        }
    }
    pub fn stop(reason: impl Into<String>) -> Self {
        Self {
            action: StreamChunkAction::Stop,
            payload: String::new(),
            reason: Some(reason.into()),
        }
    }
}

/// Owned form of [`super::EvalRuntime`] used by the streaming session
/// (which lives across multiple chunk submissions and can't borrow).
#[derive(Clone)]
pub struct OwnedEvalRuntime {
    pub session_id: String,
    pub correlation_id: String,
    pub user_id: Option<String>,
    pub tenant_id: Option<String>,
    pub request_context: Value,
    pub turn_id: u64,
    pub objective: String,
    pub forbidden: Vec<String>,
    pub user_input: String,
    pub invocation: Option<Invocation>,
}

impl OwnedEvalRuntime {
    pub fn minimal(session_id: &str, correlation_id: &str) -> Self {
        Self {
            session_id: session_id.into(),
            correlation_id: correlation_id.into(),
            user_id: None,
            tenant_id: None,
            request_context: Value::Null,
            turn_id: 0,
            objective: String::new(),
            forbidden: Vec::new(),
            user_input: String::new(),
            invocation: None,
        }
    }

    pub fn with_invocation(mut self, inv: Invocation) -> Self {
        self.invocation = Some(inv);
        self
    }

    pub(crate) fn as_runtime(&self) -> EvalRuntime<'_> {
        EvalRuntime {
            session_id: &self.session_id,
            correlation_id: &self.correlation_id,
            user_id: self.user_id.as_deref(),
            tenant_id: self.tenant_id.as_deref(),
            request_context: self.request_context.clone(),
            turn_id: self.turn_id,
            objective: &self.objective,
            forbidden: &self.forbidden,
            user_input: &self.user_input,
            active_guard_policies: "",
            variables_snapshot: "",
            prior_checks_summary: "",
        }
    }
}

#[derive(Clone)]
pub(crate) struct StreamIncidentTarget {
    bus: EventBus,
    session_id: SessionId,
}

impl StreamIncidentTarget {
    pub(crate) fn new(bus: EventBus, session_id: SessionId) -> Self {
        Self { bus, session_id }
    }

    fn emit_incident(&self, name: &str, payload: Option<Value>) {
        let full = format!("incident.{name}");
        let _ = self
            .bus
            .emit_incident_in(&self.session_id, &full, None, payload);
    }
}

/// The streaming guard.
pub struct StreamingGuard {
    engine: Arc<GuardPolicyEngine>,
    stage: Stage,
    ctx: OwnedEvalRuntime,
    buffer: String,
    emitted_up_to: usize,
    last_validated_len: usize,
    chunks_received: usize,
    stream_ended: bool,
    trigger: StreamingTrigger,
    window_size: usize,
    overlap: usize,
    incident_target: Option<StreamIncidentTarget>,
    stop_incident_emitted: bool,
}

impl StreamingGuard {
    pub fn new(engine: Arc<GuardPolicyEngine>, stage: Stage, ctx: OwnedEvalRuntime) -> Self {
        Self {
            engine,
            stage,
            ctx,
            buffer: String::new(),
            emitted_up_to: 0,
            last_validated_len: 0,
            chunks_received: 0,
            stream_ended: false,
            trigger: StreamingTrigger::OnComplete,
            window_size: DEFAULT_WINDOW_SIZE,
            overlap: DEFAULT_OVERLAP,
            incident_target: None,
            stop_incident_emitted: false,
        }
    }

    pub fn with_trigger(mut self, t: StreamingTrigger) -> Self {
        self.trigger = t;
        self
    }
    pub fn with_window_size(mut self, n: usize) -> Self {
        self.window_size = n.max(1);
        self
    }
    pub fn with_overlap(mut self, n: usize) -> Self {
        self.overlap = n;
        self
    }
    pub(crate) fn with_incident_target(mut self, target: StreamIncidentTarget) -> Self {
        self.incident_target = Some(target);
        self
    }

    pub fn buffer(&self) -> &str {
        &self.buffer
    }
    pub fn is_ended(&self) -> bool {
        self.stream_ended
    }
    pub fn chunks_received(&self) -> usize {
        self.chunks_received
    }

    /// Validation cadence the host should respect when scheduling
    /// emissions.
    ///
    /// SDKs use this to decide whether to forward upstream chunks to
    /// the customer in real time ([`StreamingTrigger::PerChunk`] /
    /// [`StreamingTrigger::Windowed`]) or to buffer every chunk and
    /// emit only the final validated payload at `end_stream`
    /// ([`StreamingTrigger::OnComplete`]). When the trigger is
    /// `OnComplete`, [`Self::add_chunk`] returns `Pass` with an empty
    /// payload for every push — the consumer is meant to see the
    /// validated text exactly once, when `end_stream` returns.
    pub fn mode(&self) -> StreamingTrigger {
        self.trigger
    }

    /// Submit a chunk. Returns a [`StreamChunkResult`] describing what
    /// the host should do.
    pub fn add_chunk(&mut self, chunk: &str) -> StreamChunkResult {
        if self.stream_ended {
            return StreamChunkResult::stop("stream already ended");
        }
        self.chunks_received += 1;

        // Fail-closed on buffer overflow before appending.
        let prospective = self.buffer.len() + chunk.len();
        if prospective > STREAM_BUFFER_MAX_BYTES {
            self.stream_ended = true;
            self.emit_stop_incident(
                "stream_limit_exceeded",
                Some(json!({
                    "reason": "stream buffer overflow",
                    "limit_bytes": STREAM_BUFFER_MAX_BYTES,
                    "prospective_bytes": prospective,
                })),
            );
            return StreamChunkResult::stop("stream buffer overflow");
        }
        self.buffer.push_str(chunk);

        let should_validate = match self.trigger {
            StreamingTrigger::OnComplete => false,
            StreamingTrigger::PerChunk => true,
            StreamingTrigger::Windowed => {
                self.buffer.len() >= self.last_validated_len + self.window_size
            }
        };

        if should_validate {
            self.validate_and_emit()
        } else {
            StreamChunkResult::buffered()
        }
    }

    /// Signal end of stream. Always validates the full buffer; returns
    /// the un-emitted remainder.
    pub fn end_stream(&mut self) -> StreamChunkResult {
        if self.stream_ended {
            return StreamChunkResult::stop("stream already ended");
        }
        self.stream_ended = true;
        let verdict = self.validate(&self.buffer.clone());
        if !verdict.allowed {
            let reason = verdict.reason.unwrap_or_default();
            self.emit_stop_incident(
                "stream_aborted",
                if reason.is_empty() {
                    None
                } else {
                    Some(json!({ "reason": reason }))
                },
            );
            return StreamChunkResult::stop(reason);
        }
        let validated = verdict
            .redaction
            .clone()
            .unwrap_or_else(|| self.buffer.clone());
        let start = clamp_to_char_boundary(&validated, self.emitted_up_to);
        let remaining = if start < validated.len() {
            validated[start..].to_string()
        } else {
            String::new()
        };
        self.emitted_up_to = validated.len();
        if let Some(reason) = verdict.reason {
            StreamChunkResult {
                action: if remaining.is_empty() {
                    StreamChunkAction::Pass
                } else {
                    StreamChunkAction::Replace
                },
                payload: remaining,
                reason: Some(reason),
            }
        } else {
            StreamChunkResult::pass(remaining)
        }
    }

    // ── Private ─────────────────────────────────────────────────────

    fn emit_stop_incident(&mut self, name: &str, payload: Option<Value>) {
        if self.stop_incident_emitted {
            return;
        }
        self.stop_incident_emitted = true;
        if let Some(target) = &self.incident_target {
            target.emit_incident(name, payload);
        }
    }

    fn validate(&self, text: &str) -> StageVerdict {
        match self.stage {
            Stage::Output => {
                let mut response = text.to_string();
                let r = self.ctx.as_runtime();
                self.engine.evaluate_output(&mut response, &r)
            }
            Stage::PostTool => {
                let inv = self
                    .ctx
                    .invocation
                    .clone()
                    .unwrap_or_else(|| Invocation::tool("(streaming)", Value::Null));
                let mut result: Value = Value::String(text.to_string());
                let r = self.ctx.as_runtime();
                self.engine.evaluate_post_tool(&inv, &mut result, &r)
            }
            _ => {
                // Streaming is only meaningful for Stages 4 / 5.
                StageVerdict::allow()
            }
        }
    }

    fn validate_and_emit(&mut self) -> StreamChunkResult {
        let verdict = self.validate(&self.buffer.clone());
        self.last_validated_len = self.buffer.len();
        if !verdict.allowed {
            self.stream_ended = true;
            let reason = verdict.reason.unwrap_or_default();
            self.emit_stop_incident(
                "stream_aborted",
                if reason.is_empty() {
                    None
                } else {
                    Some(json!({ "reason": reason }))
                },
            );
            return StreamChunkResult::stop(reason);
        }
        let validated = verdict
            .redaction
            .clone()
            .unwrap_or_else(|| self.buffer.clone());

        // If the validator rewrote the buffer (redact), force a Replace
        // so the host emits the new text in place of the prior buffer.
        let was_rewritten = validated != self.buffer;
        if was_rewritten {
            self.buffer = validated.clone();
        }

        // Emit safe range up to (len - overlap) snapped to a natural
        // boundary.
        let raw_end = validated.len().saturating_sub(self.overlap);
        let start = clamp_to_char_boundary(&validated, self.emitted_up_to);
        let end = snap_to_natural_boundary(&validated, raw_end, start);

        if was_rewritten {
            // Emit the *entire* validated buffer as Replace so the host
            // can blow away its prior emission and substitute the fresh
            // version. Conservative but straightforward and correct.
            self.emitted_up_to = validated.len();
            return StreamChunkResult::replace(validated);
        }

        if end > start {
            let payload = validated[start..end].to_string();
            self.emitted_up_to = end;
            StreamChunkResult::pass(payload)
        } else {
            StreamChunkResult::buffered()
        }
    }
}

fn clamp_to_char_boundary(s: &str, byte_offset: usize) -> usize {
    let clamped = byte_offset.min(s.len());
    let mut pos = clamped;
    while pos > 0 && !s.is_char_boundary(pos) {
        pos -= 1;
    }
    pos
}

fn snap_to_natural_boundary(s: &str, byte_offset: usize, min_pos: usize) -> usize {
    let min_pos = clamp_to_char_boundary(s, min_pos);
    let clamped = byte_offset.min(s.len());
    if clamped <= min_pos {
        return min_pos;
    }
    let clamped = clamp_to_char_boundary(s, clamped);
    let search_start =
        clamp_to_char_boundary(s, clamped.saturating_sub(LOOKBACK_WINDOW).max(min_pos));
    if clamped <= search_start {
        return search_start;
    }
    let region = &s.as_bytes()[search_start..clamped];

    let mut best_line: Option<usize> = None;
    let mut best_word: Option<usize> = None;
    for i in (0..region.len()).rev() {
        let b = region[i];
        let abs = search_start + i;
        if b == b'\n' {
            best_line = Some(abs + 1);
            break;
        }
        if best_word.is_none() && b.is_ascii_whitespace() {
            best_word = Some(abs + 1);
        }
    }
    best_line
        .or(best_word)
        .unwrap_or_else(|| clamp_to_char_boundary(s, clamped))
}

#[cfg(test)]
mod tests {
    use super::super::tests_support::*;
    use super::*;
    use crate::guard_policy::Action;

    fn ctx() -> OwnedEvalRuntime {
        OwnedEvalRuntime::minimal("s1", "c1")
    }

    #[test]
    fn on_complete_accumulates_until_end() {
        let h = test_harness(|_| {});
        let mut g = StreamingGuard::new(h.engine.clone(), Stage::Output, ctx());
        let r1 = g.add_chunk("hello ");
        let r2 = g.add_chunk("world");
        assert_eq!(r1.action, StreamChunkAction::Pass);
        assert_eq!(r1.payload, "");
        assert_eq!(r2.payload, "");
        let final_r = g.end_stream();
        assert_eq!(final_r.payload, "hello world");
    }

    #[test]
    fn block_pattern_stops_stream() {
        let h = test_harness(|cfg| {
            cfg.output_validation.guard_policies.push(make_policy(
                "block",
                vec![pattern_entry("forbidden", "FORBIDDEN")],
                None,
                Some(Action::Block),
            ));
        });
        let mut g = StreamingGuard::new(h.engine.clone(), Stage::Output, ctx())
            .with_trigger(StreamingTrigger::PerChunk);
        let _ = g.add_chunk("good ");
        let r = g.add_chunk("FORBIDDEN content");
        assert_eq!(r.action, StreamChunkAction::Stop);
    }

    #[test]
    fn redact_pattern_replaces_buffer() {
        let h = test_harness(|cfg| {
            let mut p = make_policy(
                "ssn",
                vec![{
                    let mut e = pattern_entry("ssn", r"\d{3}-\d{2}-\d{4}");
                    e.action = Some(Action::Redact);
                    e
                }],
                None,
                None,
            );
            p.replacement = Some("[X]".into());
            cfg.output_validation.guard_policies.push(p);
        });
        let mut g = StreamingGuard::new(h.engine.clone(), Stage::Output, ctx())
            .with_trigger(StreamingTrigger::PerChunk);
        let r1 = g.add_chunk("ssn 123-45-6789 here");
        // Validation rewrote the buffer → Replace.
        assert_eq!(r1.action, StreamChunkAction::Replace);
        assert!(r1.payload.contains("[X]"));
    }

    #[test]
    fn windowed_mode_validates_after_window_size() {
        let h = test_harness(|cfg| {
            cfg.output_validation.guard_policies.push(make_policy(
                "block",
                vec![pattern_entry("forbidden", "BAD")],
                None,
                Some(Action::Block),
            ));
        });
        let mut g = StreamingGuard::new(h.engine.clone(), Stage::Output, ctx())
            .with_trigger(StreamingTrigger::Windowed)
            .with_window_size(8);
        // Below window size — buffered.
        let _ = g.add_chunk("ok ");
        // Crosses window — triggers validation; passes.
        let r = g.add_chunk("more text");
        assert_eq!(r.action, StreamChunkAction::Pass);
        // Now add violating content; per-window validation catches it.
        let r2 = g.add_chunk(" plus BAD content here");
        assert_eq!(r2.action, StreamChunkAction::Stop);
    }

    #[test]
    fn end_stream_validates_full_buffer_in_on_complete() {
        let h = test_harness(|cfg| {
            cfg.output_validation.guard_policies.push(make_policy(
                "block",
                vec![pattern_entry("forbidden", "BAD")],
                None,
                Some(Action::Block),
            ));
        });
        let mut g = StreamingGuard::new(h.engine.clone(), Stage::Output, ctx());
        let _ = g.add_chunk("ok ");
        let _ = g.add_chunk("BAD content");
        let r = g.end_stream();
        assert_eq!(r.action, StreamChunkAction::Stop);
    }

    #[test]
    fn buffer_overflow_stops_stream() {
        let h = test_harness(|_| {});
        let mut g = StreamingGuard::new(h.engine.clone(), Stage::Output, ctx());
        let big = "x".repeat(STREAM_BUFFER_MAX_BYTES + 1);
        let r = g.add_chunk(&big);
        assert_eq!(r.action, StreamChunkAction::Stop);
    }

    #[test]
    fn second_chunk_after_end_stops() {
        let h = test_harness(|_| {});
        let mut g = StreamingGuard::new(h.engine.clone(), Stage::Output, ctx());
        let _ = g.add_chunk("hi");
        let _ = g.end_stream();
        let r = g.add_chunk("more");
        assert_eq!(r.action, StreamChunkAction::Stop);
    }

    #[test]
    fn mode_reports_configured_trigger() {
        let h = test_harness(|_| {});
        let default_g = StreamingGuard::new(h.engine.clone(), Stage::Output, ctx());
        assert_eq!(default_g.mode(), StreamingTrigger::OnComplete);

        let per_chunk = StreamingGuard::new(h.engine.clone(), Stage::Output, ctx())
            .with_trigger(StreamingTrigger::PerChunk);
        assert_eq!(per_chunk.mode(), StreamingTrigger::PerChunk);

        let windowed = StreamingGuard::new(h.engine.clone(), Stage::Output, ctx())
            .with_trigger(StreamingTrigger::Windowed);
        assert_eq!(windowed.mode(), StreamingTrigger::Windowed);
    }

    #[test]
    fn snap_to_natural_boundary_picks_newline() {
        let s = "line one\nline two ends";
        let pos = snap_to_natural_boundary(s, s.len(), 0);
        assert!(pos == s.len() || s.as_bytes()[pos.saturating_sub(1)] == b'\n');
    }

    #[test]
    fn post_tool_streaming_passes_through() {
        let h = test_harness(|_| {});
        let mut g = StreamingGuard::new(h.engine.clone(), Stage::PostTool, ctx());
        let _ = g.add_chunk("partial result");
        let r = g.end_stream();
        assert_eq!(r.action, StreamChunkAction::Pass);
        assert_eq!(r.payload, "partial result");
    }
}
