//! Bypass-path tests for the Anthropic adapter (Rust).
//!
//! Covers guarded calls, missing bindings, unguarded dispatch incidents,
//! parameter normalization, and streaming blocks.

use std::sync::{Arc, Mutex};

use agent_shield_core::{
    guard_policy_runtime::streaming::StreamingTrigger, load_from_str, GuardrailsRuntime,
    GuardrailsSession, ObsEventType, ObsStage, ObservabilityProvider, RequestContext,
    RuntimeBuilder, ShieldLogEvent, StreamChunkAction, StreamingOptions,
};
use serde_json::json;

const FIXTURE_YAML: &str = r#"
metadata:
  name: "anthropic-rust-bypass"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Guard Anthropic Rust tool calls."]
  forbidden: ["Leak secrets."]
resources:
  tools:
    - name: "search"
      description: "Web search."
      permission: "read_only"
"#;

const BLOCK_OUTPUT_YAML: &str = r#"
metadata:
  name: "anthropic-rust-stream-block"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["Block confidential output."]
  forbidden: ["Leak secrets."]
resources:
  tools:
    - name: "search"
      description: "Web search."
      permission: "read_only"
output_validation:
  guard_policies:
    - name: "block-confidential"
      evaluate_when:
        - pattern: "CONFIDENTIAL"
          reason: "Output contains confidential marker."
      action: block
"#;

// ─── Helpers ──────────────────────────────────────────────────────

#[derive(Default)]
struct CapturingProvider {
    events: Mutex<Vec<ShieldLogEvent>>,
}

impl ObservabilityProvider for CapturingProvider {
    fn emit(&self, event: ShieldLogEvent) {
        self.events.lock().unwrap().push(event);
    }
}

fn build(provider: Arc<CapturingProvider>) -> Arc<GuardrailsRuntime> {
    build_with(provider, FIXTURE_YAML, None)
}

fn build_with(
    provider: Arc<CapturingProvider>,
    yaml: &str,
    streaming: Option<StreamingOptions>,
) -> Arc<GuardrailsRuntime> {
    let cfg = load_from_str(yaml).expect("parse fixture");
    let builder = RuntimeBuilder::from_config(cfg).register_provider(provider);
    let builder = if let Some(opts) = streaming {
        builder.streaming_window(opts)
    } else {
        builder
    };
    builder.build().expect("build runtime")
}

fn open_session(rt: &Arc<GuardrailsRuntime>) -> GuardrailsSession {
    rt.new_session(RequestContext::new("sess-bypass-ant", "corr-bypass-ant"))
}

// ─── 1. Guarded path: invocation_hash ─────────────────────────────

#[test]
fn guarded_tool_call_produces_invocation_hash() {
    let cap = Arc::new(CapturingProvider::default());
    let rt = build(cap.clone());
    let s = open_session(&rt);
    let _ = s.begin_turn();

    let mut params = json!({"query": "hello"});
    let v3 = s.validate_tool_call("search", &mut params, "ant_rs_001");
    assert!(v3.allowed, "Stage 3 MUST pass with no block policies");
    assert!(
        v3.invocation_hash.is_some(),
        "guarded Stage 3 MUST produce an invocation_hash"
    );

    let mut result = json!({"results": ["r1"]});
    let v4 = s.validate_tool_output("search", &mut result, "ant_rs_001");
    assert!(v4.allowed, "Stage 4 MUST pass when binding is valid");
    assert!(
        v4.invocation_hash.is_some(),
        "guarded Stage 4 MUST preserve invocation_hash"
    );
}

// ─── 2. Stage 4 without Stage 3: fails closed, no hash ────────────

#[test]
fn raw_call_without_stage3_fails_closed_and_has_no_invocation_hash() {
    let cap = Arc::new(CapturingProvider::default());
    let rt = build(cap.clone());
    let s = open_session(&rt);
    let _ = s.begin_turn();

    let mut result = json!({"results": []});
    let v4 = s.validate_tool_output("search", &mut result, "never_stage3_ant_rs");
    assert!(!v4.allowed, "Stage 4 without Stage 3 MUST fail closed");
    assert_eq!(
        v4.policy.as_deref(),
        Some("<binding>"),
        "Binding-miss verdict MUST have policy '<binding>'"
    );
    assert!(
        v4.invocation_hash.is_none(),
        "Binding-miss deny MUST NOT carry an invocation_hash"
    );
}

// ─── 3. Unguarded dispatch emits incident.unguarded_tool_dispatch ──

#[test]
fn unguarded_dispatch_emits_incident() {
    let cap = Arc::new(CapturingProvider::default());
    let rt = build(cap.clone());
    let s = open_session(&rt);
    let _ = s.begin_turn();

    let mut result = json!({"results": []});
    s.validate_tool_output("search", &mut result, "bypass_ant_rs_001");

    let events = cap.events.lock().unwrap();
    let found = events.iter().any(|e| {
        e.event_type == ObsEventType::IncidentEmitted
            && e.event_id.as_deref() == Some("incident.unguarded_tool_dispatch")
    });
    assert!(
        found,
        "Unguarded dispatch MUST emit 'incident.unguarded_tool_dispatch'"
    );
}

// ─── 4. Empty params still bind cleanly ───────────────────────────

#[test]
fn empty_params_still_produce_invocation_hash() {
    let cap = Arc::new(CapturingProvider::default());
    let rt = build(cap.clone());
    let s = open_session(&rt);
    let _ = s.begin_turn();

    let mut params = json!({});
    let v3 = s.validate_tool_call("search", &mut params, "ant_rs_malformed");
    assert!(v3.allowed, "empty params MUST still allow the call");
    assert!(
        v3.invocation_hash.is_some(),
        "empty params MUST still produce an invocation_hash"
    );
}

// ─── 5. Streaming Stage-5 deny emits incident.stream_aborted ───────

#[test]
fn streaming_stage5_block_after_release_emits_stream_aborted() {
    let cap = Arc::new(CapturingProvider::default());
    let rt = build_with(
        cap.clone(),
        BLOCK_OUTPUT_YAML,
        Some(StreamingOptions {
            trigger: StreamingTrigger::PerChunk,
            window_size: 1,
            overlap: 0,
        }),
    );
    let s = open_session(&rt);
    let _ = s.begin_turn();

    let mut guard = s.streaming_session(ObsStage::Output);
    let first = guard.add_chunk("safe release ");
    assert!(matches!(
        first.action,
        StreamChunkAction::Pass | StreamChunkAction::Replace
    ));
    assert!(
        !first.payload.is_empty(),
        "expected the first chunk to be released before deny"
    );

    let second = guard.add_chunk("CONFIDENTIAL data");
    assert_eq!(second.action, StreamChunkAction::Stop);

    let events = cap.events.lock().unwrap();
    let found = events.iter().any(|e| {
        e.event_type == ObsEventType::IncidentEmitted
            && e.event_id.as_deref() == Some("incident.stream_aborted")
    });
    assert!(
        found,
        "streaming deny after release MUST emit incident.stream_aborted"
    );
}
