"""``AgentShieldLiteLLMGuardrail`` — Agent Shield as a LiteLLM Proxy guardrail.

Subclass of :class:`litellm.integrations.custom_guardrail.CustomGuardrail`
that wires the five Agent Shield validation stages into LiteLLM Proxy's
native ``guardrails:`` config block.

Stage map
=========

==============  =================================================  ========================================
Stage           Hook                                               Source data
==============  =================================================  ========================================
1 (Input)       :meth:`async_pre_call_hook`                        last ``role=user`` message
2/3 (Tool call) :meth:`async_post_call_success_hook` / iterator    each ``tool_calls[*]`` on the response
4 (Tool output) :meth:`async_pre_call_hook` (next request)         trailing ``role=tool`` messages
5 (Output)      :meth:`async_post_call_success_hook` / iterator    final ``content`` (no tool_calls)
==============  =================================================  ========================================

All verdict-handling decisions (block / proceed / proceed-with-mutation
+ block-message formatting) are delegated to
:mod:`agent_shield._native` via the existing helpers in
:mod:`agent_shield.adapters._orchestration` — this module owns the
async wiring and the LiteLLM-shape translation, not the policy
decisions.

Configuration is by environment variables so an operator can drop the
package into a stock LiteLLM Proxy image without writing Python:

``AGENT_SHIELD_LITELLM_GUARDRAILS_PATH``
    Path to ``.guardrails.yaml``. Required for the singleton path; the
    module-level :data:`agentshield_guardrail` defers loading until the
    first hook fires so an unconfigured import does not raise.

``AGENT_SHIELD_LITELLM_SESSION_CACHE_SIZE``
    LRU cap for cached sessions. Default 512.

``AGENT_SHIELD_LITELLM_SESSION_TTL_SECONDS``
    Idle TTL for cached sessions. Default 1800 s.

``AGENT_SHIELD_LITELLM_STAGE4_ON_BLOCK``
    ``replace`` (default) — fail-closed by rewriting the tool message
    content with the block string. ``raise`` — raise
    ``HTTPException(400)`` so the proxy returns an error to the client.
"""
from __future__ import annotations


import logging
import os
import uuid
from typing import Any, AsyncIterator, Dict, List, Optional

from agent_shield import Runtime, RuntimeBuilder
from agent_shield.adapters._orchestration import (
    _dispatch_stage,
    _dispatch_tool,
    _format_block_message,
)

from ._messages import (
    is_new_user_turn,
    last_user_content,
    parse_tool_arguments,
    replace_message_content,
    response_choice_count,
    response_content,
    response_tool_calls,
    rewrite_response_as_block,
    rewrite_response_content,
    rewrite_tool_call_arguments,
    rewrite_tool_call_id,
    serialise_tool_arguments,
    trailing_tool_messages,
)
from ._session_cache import SessionCache, _Entry, _safe_end_turn
from ._streaming import (
    AssembledStream,
    drain_stream,
    make_block_chunk,
    make_tool_call_chunk,
    replay_chunks,
)

logger = logging.getLogger("agent_shield.litellm_proxy")


# ── Late import of LiteLLM + FastAPI ────────────────────────────────────

# We import the proxy types lazily so ``agent_shield.integrations.litellm_proxy``
# stays importable in environments that don't have litellm installed
# (e.g. unit tests for unrelated SDK pieces). Real proxy deployments
# always have litellm in the environment.
try:
    from litellm.integrations.custom_guardrail import CustomGuardrail
    from litellm.types.guardrails import GuardrailEventHooks
    _LITELLM_AVAILABLE = True
except ImportError:  # pragma: no cover — only when used outside the proxy
    CustomGuardrail = object  # type: ignore[misc,assignment]
    GuardrailEventHooks = None  # type: ignore[misc,assignment]
    _LITELLM_AVAILABLE = False


try:
    from fastapi import HTTPException
except ImportError:  # pragma: no cover — FastAPI ships with the proxy
    HTTPException = None  # type: ignore[misc,assignment]


# Type alias kept loose so the module imports cleanly without litellm.
UserAPIKeyAuth = Any


__all__ = [
    "AgentShieldLiteLLMGuardrail",
    "make_guardrail",
    "agentshield_guardrail",
]


#: Tokens older than this are considered stale and recoverable. Tracks
#: the worst-case pre_call→post_call latency the integration accepts
#: before assuming the proxy crashed between hooks. Concurrent requests
#: on the same session id within this window are rejected with HTTP 409.
_IN_FLIGHT_TIMEOUT_SECONDS = 300.0


#: Key under which the ``tool_call_id -> tool_name`` map is stored in
#: the per-turn scratch K/V on the underlying ``HookSession``. Used so
#: Stage 4 can look up the tool name for a trailing ``role=tool``
#: message (the OpenAI-Chat shape carries the id but not the name).
_PENDING_TOOL_CALLS_KEY = "litellm.pending_tool_calls"


def _pending_tool_calls(entry: _Entry) -> dict:
    """Read the ``tool_call_id -> tool_name`` map for the entry.

    Returns an empty dict when the scratch slot is unset or no turn
    is open. Always safe to call ``.get`` / ``.keys`` on the result.
    """
    v = entry.hook.turn_kv_get(_PENDING_TOOL_CALLS_KEY)
    return v if isinstance(v, dict) else {}


def _raise_http(status: int, detail: str) -> None:
    """Raise an ``HTTPException`` if FastAPI is available; else generic."""
    if HTTPException is not None:
        raise HTTPException(status_code=status, detail=detail)
    raise RuntimeError(f"[HTTP {status}] {detail}")


# ── Public class ────────────────────────────────────────────────────────


class AgentShieldLiteLLMGuardrail(CustomGuardrail):
    """LiteLLM Proxy guardrail backed by an Agent Shield ``Runtime``.

    Args:
        runtime: Pre-built :class:`agent_shield.Runtime`. Mutually
            exclusive with ``guardrails_path``.
        guardrails_path: Path to a ``.guardrails.yaml`` file. The
            guardrail will build a default :class:`Runtime` from it on
            first use. Mutually exclusive with ``runtime``.
        session_cache_size: LRU cap for cached sessions. Default 512.
        session_ttl_seconds: Idle TTL for cached sessions in seconds.
            Default 1800 (30 min). ``0`` disables TTL eviction.
        stage4_on_block: One of ``"replace"`` (default — rewrite the
            tool message content with the block string and forward to
            the LLM) or ``"raise"`` (return ``HTTP 400`` to the
            client).
        guardrail_name: Identifier surfaced in LiteLLM logs / metrics.
            Defaults to ``"agent_shield"``.
        **kwargs: Forwarded to :class:`CustomGuardrail` (e.g.
            ``event_hook``, ``default_on``, ``violation_message_template``).

    Notes:
        Variables / events / state-machine guardrails only carry across
        LiteLLM calls when the caller threads a stable session id —
        same semantics as the in-process SDK. The session id is
        resolved per request in this order:

        1. ``data["metadata"]["agent_shield_session_id"]``
        2. ``data["litellm_session_id"]``
        3. ``data["user"]``
        4. fresh UUID (no cross-request continuity)
    """

    def __init__(
        self,
        runtime: Optional[Runtime] = None,
        *,
        guardrails_path: Optional[str] = None,
        session_cache_size: int = 512,
        session_ttl_seconds: float = 1800.0,
        stage4_on_block: str = "replace",
        guardrail_name: str = "agent_shield",
        **kwargs: Any,
    ) -> None:
        if not _LITELLM_AVAILABLE:
            raise ImportError(
                "agent_shield.integrations.litellm_proxy requires the "
                "`litellm` package. Install with: "
                "`pip install agent-shield[litellm-proxy]`."
            )
        if runtime is None and guardrails_path is None:
            raise ValueError(
                "AgentShieldLiteLLMGuardrail requires either `runtime=` "
                "or `guardrails_path=`."
            )
        if runtime is not None and guardrails_path is not None:
            raise ValueError(
                "Pass either `runtime=` or `guardrails_path=`, not both."
            )
        if stage4_on_block not in ("replace", "raise"):
            raise ValueError(
                "stage4_on_block must be 'replace' or 'raise', got "
                f"{stage4_on_block!r}"
            )

        # Default to the standard `pre_call` + `post_call` hooks when
        # the operator didn't pin them. The proxy invokes whichever
        # are listed in the proxy config's `mode:` field.
        kwargs.setdefault(
            "supported_event_hooks",
            [
                GuardrailEventHooks.pre_call,
                GuardrailEventHooks.post_call,
            ],
        )
        super().__init__(guardrail_name=guardrail_name, **kwargs)

        self._runtime: Optional[Runtime] = runtime
        self._guardrails_path = guardrails_path
        self._stage4_on_block = stage4_on_block
        self._session_cache_size = session_cache_size
        self._session_ttl_seconds = session_ttl_seconds
        self._sessions: Optional[SessionCache] = None

    # ── runtime lazy-load ────────────────────────────────────────────

    def _ensure_runtime(self) -> Runtime:
        if self._runtime is None:
            if not self._guardrails_path:
                raise RuntimeError(
                    "AgentShieldLiteLLMGuardrail has no runtime configured."
                )
            logger.info(
                "litellm-proxy: building Runtime from %s",
                self._guardrails_path,
            )
            self._runtime = RuntimeBuilder.from_yaml(
                self._guardrails_path,
            ).build()
        return self._runtime

    def _ensure_sessions(self) -> SessionCache:
        if self._sessions is None:
            self._sessions = SessionCache(
                self._ensure_runtime(),
                max_size=self._session_cache_size,
                ttl_seconds=self._session_ttl_seconds,
                in_flight_timeout_seconds=_IN_FLIGHT_TIMEOUT_SECONDS,
            )
        return self._sessions

    # ── LiteLLM hooks ────────────────────────────────────────────────

    async def async_pre_call_hook(
        self,
        user_api_key_dict: UserAPIKeyAuth,
        cache: Any,
        data: dict,
        call_type: Any,
    ) -> Optional[dict]:
        """Stage 1 (new user turn) + Stage 4 (trailing ``role=tool``).

        Returns the (possibly mutated) ``data`` dict for LiteLLM to
        forward upstream. Raises ``HTTPException(400)`` when a block
        fires on input or when the request asks for ``n > 1``
        completions (see :meth:`_reject_multi_choice`).
        """
        # Only gate chat-style traffic — embeddings, image gen, etc.
        # don't carry an OpenAI-Chat ``messages`` array.
        messages = data.get("messages")
        if not isinstance(messages, list) or not messages:
            return data

        # The post-call hook + streaming assembler validate only
        # ``choices[0]``. Allowing ``n > 1`` would silently let
        # unvalidated content in ``choices[1..N]`` through, so we
        # fail closed on the request before the upstream call. A
        # client that needs multiple completions issues them as
        # separate requests — Agent Shield enforces per-request, not
        # per-choice.
        try:
            self._reject_multi_choice(data)
        except _BlockingHTTP as exc:
            _raise_http(exc.status, exc.detail)

        sid = self._resolve_session_id(data)
        async with self._ensure_sessions().acquire(sid) as entry:
            # _begin_in_flight raises 409 if a concurrent request
            # for this session is already in flight. That rejection
            # does NOT own the current in-flight token / turn, so it
            # must NOT call _safe_end_turn / _clear_in_flight (which
            # would clobber the legitimate first request's state).
            # Hoist it out of the cleanup try-block.
            try:
                self._begin_in_flight(entry, data)
            except _BlockingHTTP as exc:
                _raise_http(exc.status, exc.detail)

            try:
                if is_new_user_turn(messages):
                    self._stage1_input(entry, data)
                else:
                    self._stage4_tool_outputs(entry, data)
            except _BlockingHTTP as exc:
                # This hook owned the in-flight cycle (we got past
                # _begin_in_flight). Wind down the turn + token so
                # the next request for this session starts cleanly.
                _safe_end_turn(entry)
                self._clear_in_flight(entry)
                _raise_http(exc.status, exc.detail)
        return data

    async def async_post_call_success_hook(
        self,
        data: dict,
        user_api_key_dict: UserAPIKeyAuth,
        response: Any,
    ) -> Any:
        """Stage 2/3 (tool calls) + Stage 5 (final content)."""
        sid = self._resolve_session_id(data)
        async with self._ensure_sessions().acquire(sid) as entry:
            try:
                # Fail closed on multi-choice responses. The pre_call
                # guard rejects requests with `n > 1`, but post-call-
                # only deployments (operator registered
                # `mode: [post_call]` only) and providers that return
                # more choices than requested can still reach this
                # point. Validation runs against `choices[0]`; any
                # extra choices are rewritten as a single-choice
                # block message rather than silently leaking
                # unvalidated content. A client that needs multiple
                # completions issues separate requests.
                n_choices = response_choice_count(response)
                if n_choices > 1:
                    logger.warning(
                        "litellm-proxy: post-call response has %d "
                        "choices; only choices[0] is validated, "
                        "rewriting as a single-choice block.",
                        n_choices,
                    )
                    self._ensure_turn_open(entry)
                    reason = (
                        f"Agent Shield's LiteLLM Proxy integration "
                        f"does not validate multi-choice responses "
                        f"(saw {n_choices} choices); only choices[0] "
                        "is inspected and forwarding the rest would "
                        "leak unvalidated content. Re-issue with n=1."
                    )
                    return self._return_block(
                        entry, response,
                        _format_block_message_wire(
                            _block_verdict(reason), "block",
                        ),
                    )

                self._ensure_turn_open(entry)
                tool_calls = response_tool_calls(response)
                if tool_calls:
                    rewritten = self._stage_2_3_tool_calls(
                        entry, response, tool_calls,
                    )
                    if rewritten is not None:
                        return rewritten
                    # Allowed (possibly mutated). Stay inside the turn —
                    # tool results will arrive on the next request.
                    return response

                return self._stage5_output(entry, response)
            finally:
                # Whether we blocked, mutated, or passed through, the
                # HTTP request paired with this post_call is over.
                # Clear the in-flight token so the next request for
                # this session can start cleanly.
                self._clear_in_flight(entry)

    async def async_post_call_streaming_iterator_hook(
        self,
        user_api_key_dict: UserAPIKeyAuth,
        response: AsyncIterator[Any],
        request_data: dict,
    ) -> AsyncIterator[Any]:
        """Streaming variant of :meth:`async_post_call_success_hook`.

        Buffers the upstream stream, runs Stage 2/3 + 5, then either
        replays the original chunks or emits a single block chunk.
        """
        sid = self._resolve_session_id(request_data)
        async with self._ensure_sessions().acquire(sid) as entry:
            try:
                self._ensure_turn_open(entry)
                assembled = await drain_stream(response)

                if assembled.saw_extra_choices:
                    # Multi-choice streamed response: same fail-closed
                    # policy as the non-streaming path. Emit a single
                    # block chunk carrying a clear reason.
                    logger.warning(
                        "litellm-proxy: streamed response carried "
                        "multiple choices; only choices[0] is "
                        "validated, emitting block chunk.",
                    )
                    _safe_end_turn(entry)
                    entry.hook.turn_kv_remove(_PENDING_TOOL_CALLS_KEY)
                    reason = (
                        "Agent Shield's LiteLLM Proxy integration "
                        "does not validate multi-choice streamed "
                        "responses; only choices[0] is inspected and "
                        "forwarding the rest would leak unvalidated "
                        "content. Re-issue with n=1."
                    )
                    yield make_block_chunk(
                        assembled.template_chunk,
                        _format_block_message_wire(
                            _block_verdict(reason), "block",
                        ),
                    )
                    return

                verdict = self._streaming_decision(entry, assembled)
                if verdict.replay_original:
                    async for chunk in replay_chunks(
                        assembled.original_chunks,
                    ):
                        yield chunk
                    return

                if verdict.replacement_tool_calls is not None:
                    # Stage 3 mutation: emit a reconstructed tool-call
                    # chunk so the agent sees the mutated arguments.
                    yield make_tool_call_chunk(
                        assembled.template_chunk,
                        verdict.replacement_tool_calls,
                    )
                    return

                replacement = make_block_chunk(
                    assembled.template_chunk,
                    verdict.replacement_message,
                )
                yield replacement
            finally:
                # Whether we replayed, emitted a block chunk, mutated,
                # or were cancelled mid-stream, the HTTP request is
                # over. Clear the in-flight token so the next request
                # for this session can start cleanly.
                self._clear_in_flight(entry)

    async def async_post_call_failure_hook(
        self,
        request_data: dict,
        original_exception: Exception,
        user_api_key_dict: UserAPIKeyAuth,
        traceback_str: Optional[str] = None,
    ) -> None:
        """Clear in-flight state when an upstream call fails.

        LiteLLM invokes this when a chat-completion request errors out
        (timeouts, provider 5xx, etc). Without this hook, the
        in-flight token set by ``pre_call`` would persist until it
        timed out — blocking subsequent requests on the same session
        id with HTTP 409 for up to :data:`_IN_FLIGHT_TIMEOUT_SECONDS`.
        """
        sid = self._resolve_session_id(request_data)
        async with self._ensure_sessions().acquire(sid) as entry:
            logger.info(
                "litellm-proxy: upstream call failed (%s); winding "
                "down in-flight turn for session %r",
                type(original_exception).__name__, sid,
            )
            _safe_end_turn(entry)
            entry.hook.turn_kv_remove(_PENDING_TOOL_CALLS_KEY)
            self._clear_in_flight(entry)

    def _ensure_turn_open(self, entry: _Entry) -> None:
        """Defensive ``begin_turn`` for post-call hooks that fire alone.

        When an operator registers only ``mode: [post_call]`` (i.e. no
        ``pre_call`` step), the post-call hooks would otherwise reach
        into the Session state machine without a turn ever having
        opened. We open one here and log a warning — Stages 2/3 and 5
        still enforce, but per-turn lifetimes that *would* have been
        bound by a Stage 1 pass won't be visible.
        """
        if not entry.hook.turn_is_open():
            logger.warning(
                "litellm-proxy: post-call hook fired without an open "
                "turn (is `pre_call` registered in mode:?). Opening a "
                "fresh turn defensively; per-turn state from a missing "
                "Stage 1 will not be visible.",
            )
            entry.hook.begin_turn()
            # turn-open state is tracked by entry.hook (begin_turn/end_turn)

    # ── Stage handlers ───────────────────────────────────────────────

    def _stage1_input(self, entry: _Entry, data: dict) -> None:
        """Stage 1 — block / allow / mutate the user's input.

        Concurrency: the per-session lock only serialises individual
        hook bodies, not whole turns. The in-flight token logic in
        :meth:`async_pre_call_hook` detects concurrent same-session
        HTTP requests at the hook boundary; this method assumes the
        token has already been set and only cares about
        turn-lifecycle bookkeeping. The history-injection check fires
        at the hook level (in :meth:`async_pre_call_hook`) before
        either stage handler runs.
        """
        if entry.hook.turn_is_open():
            # A previous turn never closed (e.g. upstream timeout or
            # the agent abandoned a previous tool-call loop). End it
            # so we don't leak per_turn state.
            _safe_end_turn(entry)

        user_text = last_user_content(data["messages"])
        entry.hook.begin_turn()
        # turn-open state is tracked by entry.hook (begin_turn/end_turn)
        entry.hook.turn_kv_remove(_PENDING_TOOL_CALLS_KEY)

        verdict = entry.session.validate_input(user_text)
        decision = _dispatch_stage(verdict)
        action = decision["action"]
        kind = action["kind"]
        if kind == "return_blocked":
            logger.warning(
                "litellm-proxy: [Stage 1] input blocked (%s): %s",
                verdict.action, verdict.reason,
            )
            raise _BlockingHTTP(400, action["message"])
        if kind == "proceed_with_mutation":
            mutated = action.get("value")
            if isinstance(mutated, str):
                logger.info(
                    "litellm-proxy: [Stage 1] input mutated before "
                    "forwarding upstream",
                )
                _replace_last_user_content(data["messages"], mutated)


    def _stage4_tool_outputs(self, entry: _Entry, data: dict) -> None:
        """Stage 4 — validate trailing ``role=tool`` messages.

        For each trailing tool message, look up the tool name from
        ``pending_tool_calls`` (populated by the previous request's
        Stage 2/3) and run ``validate_tool_output``. Mutation rewrites
        ``content``; blocks either rewrite or raise per the
        ``stage4_on_block`` policy. Unknown ``tool_call_id`` is a
        fail-closed block.

        When tool messages arrive on a session with no open turn (e.g.
        a proxy restart or LRU eviction between assistant.tool_calls
        and the next request), we **fail closed**: open a fresh turn
        and treat every trailing tool message as if its
        ``tool_call_id`` were unknown. Forwarding tool outputs without
        Stage 4 enforcement would silently bypass `post_tool_validation`
        policies.
        """
        messages = data["messages"]
        if not entry.hook.turn_is_open():
            logger.warning(
                "litellm-proxy: tool messages arrived without an open "
                "turn; Stage 4 cannot correlate by tool_call_id — "
                "failing closed on every trailing role=tool message.",
            )
            entry.hook.begin_turn()
            # turn-open state is tracked by entry.hook (begin_turn/end_turn)
            for idx, msg in trailing_tool_messages(messages):
                tool_call_id = str(msg.get("tool_call_id") or "")
                reason = (
                    f"Tool reply (tool_call_id={tool_call_id!r}) arrived "
                    "without a correlated open turn; blocked by "
                    "Agent Shield Stage 4 (fail-closed)."
                )
                msg_str = _format_block_message_wire(
                    _block_verdict(reason), "block",
                )
                self._apply_stage4_block(messages, idx, msg_str)
            return

        for idx, msg in trailing_tool_messages(messages):
            tool_call_id = str(msg.get("tool_call_id") or "")
            tool_name = _pending_tool_calls(entry).get(tool_call_id)
            if not tool_name:
                logger.warning(
                    "litellm-proxy: [Stage 4] unknown tool_call_id %r "
                    "(known: %s); failing closed",
                    tool_call_id,
                    sorted(_pending_tool_calls(entry).keys()),
                )
                reason = (
                    f"Tool reply references unknown tool_call_id "
                    f"{tool_call_id!r}; blocked by Agent Shield Stage 4."
                )
                msg_str = _format_block_message_wire(
                    _block_verdict(reason), "block",
                )
                self._apply_stage4_block(messages, idx, msg_str)
                continue

            content = _flatten_msg_content(msg.get("content"))
            outcome = entry.session.validate_tool_output(
                tool_name, content, tool_call_id=tool_call_id,
            )
            decision = _dispatch_tool(
                outcome.verdict, tool_name, stage="output",
            )
            kind = decision["action"]["kind"]
            if kind == "blocked":
                logger.warning(
                    "litellm-proxy: [Stage 4] tool output blocked for %r: %s",
                    tool_name, outcome.verdict.reason,
                )
                if decision.get("record_failure"):
                    self._safe_record_tool_failure(
                        entry, tool_name,
                        outcome.verdict.reason or "blocked",
                    )
                block_msg = decision["action"]["message"]
                self._apply_stage4_block(messages, idx, block_msg)
                continue
            # Stage 4 mutation: same dual-shape as Stage 3 — either an
            # explicit `proceed_with_mutation` kind, or a `proceed`
            # with `outcome.result` carrying a redacted value.
            mutated = outcome.result
            if mutated is not None and str(mutated) != content:
                logger.info(
                    "litellm-proxy: [Stage 4] tool output mutated for %r",
                    tool_name,
                )
                replace_message_content(messages, idx, str(mutated))
            # Record success on the resource cycle so subsequent
            # state/lifetime rules see the tool as having completed.
            if decision.get("record_success"):
                effective = (
                    str(mutated) if (mutated is not None and str(mutated) != content)
                    else content
                )
                self._safe_record_tool_success(entry, tool_name, effective)

    def _apply_stage4_block(
        self, messages: List[Dict[str, Any]], idx: int, message: str,
    ) -> None:
        if self._stage4_on_block == "raise":
            raise _BlockingHTTP(400, message)
        replace_message_content(messages, idx, message)

    def _stage_2_3_tool_calls(
        self,
        entry: _Entry,
        response: Any,
        tool_calls: List[Dict[str, Any]],
    ) -> Optional[Any]:
        """Stage 2 + 3 on every tool call in the response.

        Block semantics: drop *all* tool_calls on the response and
        return a single assistant block message. Partial rewrites
        (allowing some calls and not others) are deliberately not
        supported — clients that mix Stage-3 mutation and Stage-3
        blocking on parallel tool calls would otherwise see a
        confusing half-state.

        Mutation semantics: each call's ``function.arguments`` is
        rewritten with the canonical mutated params. Failed
        serialisation is a fail-closed block.

        Returns the rewritten response when a block fired, or ``None``
        when all calls were allowed (possibly with mutation applied in
        place). On allow, populates ``pending_tool_calls`` so the next
        request's Stage 4 can correlate by ``tool_call_id``.
        """
        # Snapshot of what we'll commit to ``pending_tool_calls`` if
        # every call passes. We don't write to ``entry`` until we know
        # the whole response is allowed.
        committed: Dict[str, str] = {}

        # Parallel tool calls (more than one in a single response)
        # are not supported. Each ``validate_tool_call`` emits
        # ``tool.<name>.called`` and caches a §16.0 binding entry on
        # allow. With sequential validation of multiple calls in a
        # single response, an early-admitted call's events would fire
        # even when a later call's block causes the whole response to
        # be dropped, leaving phantom-called events in the session
        # audit log with no per-call rollback in the core API. The
        # OpenAI/LiteLLM agent shape that produces multi-tool
        # responses (e.g. ``tool_choice='auto'`` with
        # ``parallel_tool_calls`` enabled) should be set to single-
        # call mode or run via the in-process SDK, where the host
        # owns the agent loop and can sequence tool execution itself.
        if len(tool_calls) > 1:
            logger.warning(
                "litellm-proxy: response has %d parallel tool calls; "
                "only single-tool-call responses are supported "
                "(see docs/integrations/litellm-proxy.md). Failing "
                "closed.",
                len(tool_calls),
            )
            reason = (
                f"Response contains {len(tool_calls)} parallel tool "
                "calls. Agent Shield's LiteLLM Proxy integration "
                "only validates single-tool-call responses; per-call "
                "rollback for multi-call batches isn't supported by "
                "the underlying §16.0 binding cache. Disable "
                "parallel tool calls on this route, or run "
                "validators in the in-process SDK."
            )
            return self._return_block(
                entry, response,
                _format_block_message_wire(
                    _block_verdict(reason), "block",
                ),
            )

        # Pre-scan: reject duplicate model-supplied tool_call_ids
        # BEFORE invoking validate_tool_call on any of them. Otherwise
        # the first duplicate's validate_tool_call would emit
        # ``tool.<name>.called`` and populate the §16.0 binding cache
        # for a call that we're about to refuse to execute, latching
        # event-driven policies on a phantom invocation.
        seen_ids: Dict[str, str] = {}
        for _index, call in enumerate(tool_calls):
            fn = call.get("function")
            if not isinstance(fn, dict):
                fn = {}
            name = str(fn.get("name") or "")
            raw_id = call.get("id")
            if isinstance(raw_id, str) and raw_id:
                if raw_id in seen_ids:
                    logger.warning(
                        "litellm-proxy: [Stage 2/3] duplicate "
                        "tool_call_id %r in response (first tool=%r, "
                        "second tool=%r); failing closed BEFORE any "
                        "core Stage-3 side effects",
                        raw_id, seen_ids[raw_id], name,
                    )
                    reason = (
                        f"Duplicate tool_call_id {raw_id!r} across "
                        f"response tool_calls (existing tool="
                        f"{seen_ids[raw_id]!r}, new tool={name!r}); "
                        "blocked by Agent Shield Stage 3 — duplicate "
                        "ids would let Stage 4 mis-correlate tool "
                        "outputs."
                    )
                    return self._return_block(
                        entry, response,
                        _format_block_message_wire(
                            _block_verdict(reason), "block",
                        ),
                    )
                seen_ids[raw_id] = name

        for index, call in enumerate(tool_calls):
            fn = call.get("function")
            if not isinstance(fn, dict):
                fn = {}
            name = str(fn.get("name") or "")
            if not name:
                logger.warning(
                    "litellm-proxy: [Stage 2/3] response tool_call %d "
                    "missing function.name; failing closed", index,
                )
                return self._return_block(
                    entry, response,
                    _format_block_message_wire(
                        _block_verdict(
                            "Assistant tool-call is missing a function "
                            "name; blocked by Agent Shield Stage 3.",
                        ),
                        "block",
                    ),
                )

            raw_args = fn.get("arguments")
            params, malformed = parse_tool_arguments(raw_args)
            if malformed:
                # Forwarding a tool call whose arguments JSON we couldn't
                # decode means argument-level policies cannot reliably
                # inspect them — fail closed.
                logger.warning(
                    "litellm-proxy: [Stage 3] malformed tool-call "
                    "arguments for %r; failing closed", name,
                )
                return self._return_block(
                    entry, response,
                    _format_block_message_wire(
                        _block_verdict(
                            f"Stage-3 failed-closed for tool {name}: "
                            "malformed function.arguments JSON.",
                        ),
                        "block",
                    ),
                )

            # tool_call_id is required by the runtime (Section 16.0
            # binding). The OpenAI shape guarantees a non-empty `id`
            # on every tool call, but synthesise a stable per-turn id
            # if the upstream model elided it (matches the adapter
            # convention described in the v0.15 BREAKING change).
            # When synthesised, the id is ALSO written back to the
            # outgoing response so the agent's later role=tool reply
            # carries the same id Stage 4 will correlate against.
            raw_call_id = call.get("id")
            if isinstance(raw_call_id, str) and raw_call_id:
                call_id = raw_call_id
            else:
                call_id = f"agent-shield-litellm-tc-{uuid.uuid4().hex}"
                logger.info(
                    "litellm-proxy: synthesised tool_call_id %r for "
                    "tool %r (upstream omitted id)", call_id, name,
                )
                response = rewrite_tool_call_id(response, index, call_id)

            outcome = entry.session.validate_tool_call(
                name, params, tool_call_id=call_id,
            )
            decision = _dispatch_tool(outcome.verdict, name, stage="call")
            kind = decision["action"]["kind"]

            if kind == "blocked":
                logger.warning(
                    "litellm-proxy: [Stage 2/3] tool call blocked for "
                    "%r: %s", name, outcome.verdict.reason,
                )
                return self._return_block(
                    entry, response, decision["action"]["message"],
                )

            # Reject duplicate tool_call_id across the response. If
            # an attacker / buggy provider emits two tool calls with
            # the same id but different names, ``pending_tool_calls``
            # would collapse them and Stage 4 could validate one
            # tool's output as the other (bypassing per-tool
            # post_tool_validation policies). Fail closed.
            if call_id in committed:
                logger.warning(
                    "litellm-proxy: [Stage 2/3] duplicate tool_call_id "
                    "%r in response (existing tool=%r, new tool=%r); "
                    "failing closed", call_id, committed[call_id], name,
                )
                reason = (
                    f"Duplicate tool_call_id {call_id!r} across "
                    f"response tool_calls (existing tool="
                    f"{committed[call_id]!r}, new tool={name!r}); "
                    "blocked by Agent Shield Stage 3 — duplicate ids "
                    "would let Stage 4 mis-correlate tool outputs."
                )
                return self._return_block(
                    entry, response,
                    _format_block_message_wire(
                        _block_verdict(reason), "block",
                    ),
                )

            # Stage 3 mutation can land on either dispatch kind:
            # `proceed_with_mutation` (explicit) or `proceed` with
            # `outcome.params` differing from the original (the
            # canonical path for `redact` / `replace` actions that
            # don't carry an explicit mutation flag in the wire dict).
            mutated_params = outcome.params
            if (
                mutated_params is not None
                and mutated_params != params
            ):
                encoded = serialise_tool_arguments(mutated_params)
                if encoded is None:
                    return self._return_block(
                        entry, response,
                        _format_block_message_wire(
                            _block_verdict(
                                f"Stage-3 transform failed for tool "
                                f"{name}: mutated params could not be "
                                "serialised.",
                            ),
                            "block",
                        ),
                    )
                response = rewrite_tool_call_arguments(
                    response, index, encoded,
                )
                logger.info(
                    "litellm-proxy: [Stage 3] tool-call %r arguments "
                    "mutated", name,
                )

            committed[call_id] = name

        entry.hook.turn_kv_set(_PENDING_TOOL_CALLS_KEY, dict(committed))
        return None

    def _stage5_output(self, entry: _Entry, response: Any) -> Any:
        """Stage 5 — final assistant content (no tool_calls).

        Always calls ``validate_output``, including for empty
        ``content``. Stage-5 policies that gate on session state or
        variables (rather than on regex matches against the text)
        still need to fire on empty responses; the core decides.
        """
        content = response_content(response)
        if not isinstance(content, str):
            content = "" if content is None else str(content)
        outcome = entry.session.validate_output(content)
        decision = _dispatch_stage(outcome.verdict)
        action = decision["action"]
        kind = action["kind"]
        if kind == "return_blocked":
            logger.warning(
                "litellm-proxy: [Stage 5] output blocked: %s",
                outcome.verdict.reason,
            )
            response = rewrite_response_as_block(
                response, action["message"],
            )
        elif kind == "proceed_with_mutation":
            logger.info(
                "litellm-proxy: [Stage 5] output mutated before delivery",
            )
            response = rewrite_response_content(
                response, outcome.response,
            )
        # End the turn — there are no tool_calls so we're at a final
        # assistant message.
        _safe_end_turn(entry)
        entry.hook.turn_kv_remove(_PENDING_TOOL_CALLS_KEY)
        return response

    def _return_block(
        self, entry: _Entry, response: Any, message: str,
    ) -> Any:
        """Return ``response`` rewritten as a single-choice block message.

        Also closes the in-progress turn — a Stage 2/3 block on the
        assistant response means the agent will not actually execute
        any tools, so there's nothing left for this turn to do.
        """
        _safe_end_turn(entry)
        entry.hook.turn_kv_remove(_PENDING_TOOL_CALLS_KEY)
        return rewrite_response_as_block(response, message)

    # ── In-flight token management ───────────────────────────────────

    @staticmethod
    def _begin_in_flight(entry: _Entry, data: dict) -> None:
        """Open the cross-hook request scope on the Rust HookSession.

        Fails closed with HTTP 409 when a concurrent request is
        already in flight and not yet stale; stale tokens (older
        than the registry's ``in_flight_timeout``) are recovered
        from automatically inside the core. The minted token is
        also persisted into
        ``data["metadata"]["agent_shield_litellm_request_id"]`` so
        downstream tooling can correlate hook phases against a
        single request.
        """
        try:
            token = entry.hook.begin_request()
        except RuntimeError as exc:
            msg = str(exc)
            if "another request is in flight" in msg:
                # Re-raise as the canonical 409 block. The block
                # message preserves the age the Rust core reported.
                reason = (
                    f"Concurrent request already in flight for this "
                    f"session id ({msg}). The LiteLLM Proxy "
                    "integration serialises requests per session id; "
                    "use a distinct session id per concurrent request "
                    "or wait for the previous request to complete."
                )
                raise _BlockingHTTP(409, _format_block_message_wire(
                    _block_verdict(reason), "block",
                )) from exc
            # Unknown failure path — fail closed at the API boundary.
            raise _BlockingHTTP(500, _format_block_message_wire(
                _block_verdict(f"begin_request failed: {msg}"), "block",
            )) from exc

        if isinstance(data, dict):
            meta = data.get("metadata")
            if not isinstance(meta, dict):
                meta = {}
                data["metadata"] = meta
            meta["agent_shield_litellm_request_id"] = str(token)

    @staticmethod
    def _clear_in_flight(entry: _Entry) -> None:
        """Retire whatever request is currently open. Idempotent — the
        Rust ``end_current_request`` returns ``"no_request_open"`` when
        there's nothing to retire (failure-hook double-close path)."""
        try:
            entry.hook.end_current_request()
        except Exception:  # noqa: BLE001 — best-effort
            logger.debug(
                "litellm-proxy: end_current_request raised; ignoring",
                exc_info=True,
            )

    # ── Resource-cycle bookkeeping ───────────────────────────────────

    @staticmethod
    def _safe_record_tool_success(
        entry: _Entry, tool: str, result: Any,
    ) -> None:
        try:
            entry.session.record_tool_success(tool, result)
        except Exception:  # noqa: BLE001 — best-effort accounting
            logger.debug(
                "litellm-proxy: record_tool_success raised", exc_info=True,
            )

    @staticmethod
    def _safe_record_tool_failure(
        entry: _Entry, tool: str, reason: str,
    ) -> None:
        try:
            entry.session.record_tool_failure(tool, reason)
        except Exception:  # noqa: BLE001 — best-effort accounting
            logger.debug(
                "litellm-proxy: record_tool_failure raised", exc_info=True,
            )

    # ── Streaming decision ───────────────────────────────────────────

    def _streaming_decision(
        self, entry: _Entry, assembled: AssembledStream,
    ) -> "_StreamDecision":
        """Run Stage 2/3 / 5 against an assembled stream.

        Returns a small decision record that the iterator hook uses to
        either replay the original chunks or emit a synthetic block /
        mutation chunk. We never run Stages 2/3 *and* 5 on the same
        stream because OpenAI-Chat responses are either a tool-call
        response OR a final content response, never both.

        For Stage 3 *mutation* paths the original chunks would carry
        the un-mutated `function.arguments`, so we cannot replay —
        instead we emit a single replacement chunk reconstructed from
        the (now-mutated) assembled tool_calls.
        """
        if assembled.tool_calls:
            # Snapshot pre-validation argument strings AND ids so we
            # can detect whether Stage 3 mutated args or whether the
            # validator synthesised tool_call_ids (because the upstream
            # model omitted them). Either change means replaying the
            # original chunks would leak the un-mutated / un-id-tagged
            # tool call to the agent.
            pre_args = [
                tc.get("function", {}).get("arguments", "")
                for tc in assembled.tool_calls
            ]
            pre_ids = [tc.get("id") for tc in assembled.tool_calls]
            synthetic = {
                "id": _as_dict_template_id(assembled.template_chunk),
                "choices": [
                    {
                        "index": 0,
                        "message": {
                            "role": "assistant",
                            "content": assembled.content or "",
                            "tool_calls": assembled.tool_calls,
                        },
                        "finish_reason": assembled.finish_reason or "tool_calls",
                    },
                ],
            }
            rewritten = self._stage_2_3_tool_calls(
                entry, synthetic, assembled.tool_calls,
            )
            if rewritten is not None:
                # Block path — content carries the canonical block.
                content = response_content(rewritten)
                return _StreamDecision(
                    replay_original=False,
                    replacement_message=content,
                )
            # Allow path — emit a reconstructed tool-call chunk if
            # either args or ids changed.
            post_calls = synthetic["choices"][0]["message"]["tool_calls"]
            post_args = [
                tc.get("function", {}).get("arguments", "")
                for tc in post_calls
            ]
            post_ids = [tc.get("id") for tc in post_calls]
            if pre_args != post_args or pre_ids != post_ids:
                return _StreamDecision(
                    replay_original=False,
                    replacement_tool_calls=post_calls,
                )
            return _StreamDecision(replay_original=True)

        # Stage 5 path
        synthetic = {
            "id": _as_dict_template_id(assembled.template_chunk),
            "choices": [
                {
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": assembled.content,
                    },
                    "finish_reason": assembled.finish_reason or "stop",
                },
            ],
        }
        rewritten = self._stage5_output(entry, synthetic)
        new_content = response_content(rewritten)
        if new_content == assembled.content:
            return _StreamDecision(replay_original=True)
        return _StreamDecision(
            replay_original=False, replacement_message=new_content,
        )

    # ── Multi-choice gating ──────────────────────────────────────────

    @staticmethod
    def _reject_multi_choice(data: dict) -> None:
        """Fail closed if the request asks for ``n > 1`` completions.

        Both the non-streaming post-call hook and the streaming
        assembler validate ``choices[0]`` only. Letting a request
        with ``n > 1`` through would silently leak unvalidated
        ``choices[1..N]`` past every Agent Shield stage, so we
        surface a clear HTTP 400 instead. A client that needs
        multiple completions issues separate requests; Agent Shield
        enforces per-request, not per-choice.
        """
        n_raw = data.get("n") if isinstance(data, dict) else None
        if n_raw is None:
            return
        try:
            n = int(n_raw)
        except (TypeError, ValueError):
            return
        if n > 1:
            reason = (
                f"Agent Shield's LiteLLM Proxy integration does not "
                f"support `n > 1` (got n={n}); the guardrail only "
                "validates choices[0] and would silently leak "
                "unvalidated content from choices[1..N-1]. Re-issue "
                "the request with `n=1`, or run the validators in the "
                "in-process SDK instead."
            )
            raise _BlockingHTTP(400, _format_block_message_wire(
                _block_verdict(reason), "block",
            ))

    # ── Session-id resolution ────────────────────────────────────────

    @staticmethod
    def _resolve_session_id(data: dict) -> str:
        """Resolve the Agent Shield session id for this LiteLLM request.

        Priority order:
            1. ``data["metadata"]["agent_shield_session_id"]`` — explicit opt-in
            2. ``data["litellm_session_id"]`` — LiteLLM-native
            3. ``data["user"]`` — OpenAI-compatible
            4. Fresh UUID — no cross-request continuity

        When the fallback UUID branch fires we **persist** the
        generated id back into ``data["metadata"]
        ["agent_shield_session_id"]`` so every other hook firing for
        the same LiteLLM HTTP request resolves the same session. The
        ``data`` dict is the same Python object across the request's
        ``pre_call`` → ``post_call`` chain; without this persistence
        Stage 1 would open a turn on one random session id and
        Stages 2/3/5 would run on a different one (orphaning the
        Stage 1 turn and falling through the "no open turn" guard).

        Cross-*request* continuity still requires the caller to thread
        a stable id explicitly — the persisted UUID is intentionally
        scoped to the lifetime of one ``data`` dict.
        """
        if not isinstance(data, dict):
            return f"litellm-proxy-{uuid.uuid4().hex}"
        meta = data.get("metadata")
        if isinstance(meta, dict):
            explicit = meta.get("agent_shield_session_id")
            if isinstance(explicit, str) and explicit:
                return explicit
        for key in ("litellm_session_id", "user"):
            value = data.get(key)
            if isinstance(value, str) and value:
                return value
        # Fallback: mint a UUID and persist it so subsequent hooks for
        # the same request resolve the same session.
        generated = f"litellm-proxy-{uuid.uuid4().hex}"
        if not isinstance(meta, dict):
            meta = {}
            data["metadata"] = meta
        meta["agent_shield_session_id"] = generated
        return generated


# ── Helpers ─────────────────────────────────────────────────────────────


class _BlockingHTTP(Exception):
    """Internal sentinel — converted to ``HTTPException`` at the hook edge."""

    def __init__(self, status: int, detail: str) -> None:
        super().__init__(detail)
        self.status = status
        self.detail = detail



def _flatten_msg_content(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: List[str] = []
        for item in content:
            if isinstance(item, dict):
                text = item.get("text") or item.get("content")
                if isinstance(text, str):
                    parts.append(text)
        return "".join(parts)
    return "" if content is None else str(content)


def _replace_last_user_content(
    messages: List[Dict[str, Any]], new_content: str,
) -> None:
    """Replace the last ``role=user`` message's content in-place.

    Used by the Stage-1 ``proceed_with_mutation`` path so the mutated
    user text is what LiteLLM forwards upstream. Multimodal content
    lists collapse to a single text string; the redacted content from
    the core is plain text.
    """
    for idx in range(len(messages) - 1, -1, -1):
        msg = messages[idx]
        role = msg.get("role") if isinstance(msg, dict) else getattr(msg, "role", None)
        if role == "user":
            if isinstance(msg, dict):
                messages[idx] = {**msg, "content": new_content}
            else:
                # Pydantic / object shape — set the attribute.
                try:
                    msg.content = new_content
                except Exception:  # noqa: BLE001 — best effort
                    logger.debug(
                        "litellm-proxy: could not write mutated content "
                        "back to user message object", exc_info=True,
                    )
            return


def _block_verdict(reason: str) -> Dict[str, Any]:
    """Build the canonical wire-shape dict for an SDK-side block."""
    return {
        "allowed": False,
        "action": "block",
        "reason": reason,
        "policy": None,
        "evaluate_when_index": None,
        "bypassed_by_allowed_when": False,
        "redaction": None,
        "appended": None,
        "prepended": None,
    }


def _format_block_message_wire(wire: Dict[str, Any], default_action: str) -> str:
    """Wrap :func:`_format_block_message` for the SDK-side fail-closed path.

    ``_format_block_message`` accepts a verdict-shaped object; we
    bridge through a tiny shim that exposes the wire dict as attribute
    access so it works without instantiating a full ``StageVerdict``.
    """
    class _Shim:
        action = wire.get("action") or default_action
        reason = wire.get("reason")
        policy = wire.get("policy")
        evaluate_when_index = wire.get("evaluate_when_index")
        bypassed_by_allowed_when = wire.get("bypassed_by_allowed_when", False)
        redaction = wire.get("redaction")
        appended = wire.get("appended")
        prepended = wire.get("prepended")
        allowed = wire.get("allowed", False)

    return _format_block_message(_Shim())


def _as_dict_template_id(template: Any) -> Optional[str]:
    if template is None:
        return None
    if isinstance(template, dict):
        return template.get("id")
    return getattr(template, "id", None)


# ── Stream-decision record ──────────────────────────────────────────────

class _StreamDecision:
    """Tiny record returned by :meth:`_streaming_decision`.

    Attributes:
        replay_original: ``True`` means the buffered chunks should be
            re-emitted as-is (allow path). ``False`` means emit a
            single synthesised replacement chunk.
        replacement_message: Content for the synthesised chunk when
            the replacement is a *content* delta (block message or
            Stage-5 mutation).
        replacement_tool_calls: Tool-call list for the synthesised
            chunk when the replacement carries Stage-3 mutated
            arguments. Mutually exclusive with
            ``replacement_message``.
    """

    __slots__ = (
        "replay_original",
        "replacement_message",
        "replacement_tool_calls",
    )

    def __init__(
        self,
        *,
        replay_original: bool,
        replacement_message: str = "",
        replacement_tool_calls: Optional[List[Dict[str, Any]]] = None,
    ) -> None:
        self.replay_original = replay_original
        self.replacement_message = replacement_message
        self.replacement_tool_calls = replacement_tool_calls


# ── Singleton factory (used by LiteLLM Proxy `callbacks:` entry) ────────


def make_guardrail() -> AgentShieldLiteLLMGuardrail:
    """Build a guardrail from environment variables.

    Reads:
        * ``AGENT_SHIELD_LITELLM_GUARDRAILS_PATH`` — required.
        * ``AGENT_SHIELD_LITELLM_SESSION_CACHE_SIZE`` — int, default 512.
        * ``AGENT_SHIELD_LITELLM_SESSION_TTL_SECONDS`` — float, default 1800.
        * ``AGENT_SHIELD_LITELLM_STAGE4_ON_BLOCK`` — ``replace``/``raise``,
          default ``replace``.
        * ``AGENT_SHIELD_LITELLM_GUARDRAIL_NAME`` — string, default
          ``agent_shield``.

    Raises:
        EnvironmentError: when ``AGENT_SHIELD_LITELLM_GUARDRAILS_PATH``
            is unset.
    """
    path = os.environ.get("AGENT_SHIELD_LITELLM_GUARDRAILS_PATH")
    if not path:
        raise EnvironmentError(
            "AGENT_SHIELD_LITELLM_GUARDRAILS_PATH must be set to the path "
            "of a `.guardrails.yaml` file for the Agent Shield LiteLLM "
            "guardrail.",
        )
    size = int(os.environ.get("AGENT_SHIELD_LITELLM_SESSION_CACHE_SIZE", "512"))
    ttl = float(os.environ.get("AGENT_SHIELD_LITELLM_SESSION_TTL_SECONDS", "1800"))
    on_block = os.environ.get(
        "AGENT_SHIELD_LITELLM_STAGE4_ON_BLOCK", "replace",
    )
    name = os.environ.get(
        "AGENT_SHIELD_LITELLM_GUARDRAIL_NAME", "agent_shield",
    )
    return AgentShieldLiteLLMGuardrail(
        guardrails_path=path,
        session_cache_size=size,
        session_ttl_seconds=ttl,
        stage4_on_block=on_block,
        guardrail_name=name,
    )


class _LazySingleton:
    """Lazy facade so importing the module does not require a config.

    LiteLLM Proxy resolves ``callbacks:`` entries by dotted path. We
    expose a lazy proxy that builds the real guardrail on first
    attribute access — that lets operators import the module via
    ``pip`` without setting the env var until they actually start the
    proxy.
    """

    _instance: Optional[AgentShieldLiteLLMGuardrail] = None

    def __getattr__(self, name: str) -> Any:
        if self._instance is None:
            object.__setattr__(self, "_instance", make_guardrail())
        return getattr(self._instance, name)

    def __repr__(self) -> str:  # pragma: no cover — cosmetic
        target = self._instance
        if target is None:
            return "<agentshield_guardrail (uninitialised)>"
        return f"<agentshield_guardrail wrapping {target!r}>"


#: Module-level lazy singleton — register this in your LiteLLM Proxy
#: ``config.yaml`` like::
#:
#:     guardrails:
#:       - guardrail_name: agent_shield
#:         litellm_params:
#:           guardrail: agent_shield.integrations.litellm_proxy.AgentShieldLiteLLMGuardrail
#:           mode: ["pre_call", "post_call"]
#:           guardrails_path: /etc/agent-shield/guardrails.yaml
#:
#: or, the simpler ``callbacks:`` path::
#:
#:     litellm_settings:
#:       callbacks: ["agent_shield.integrations.litellm_proxy.agentshield_guardrail"]
agentshield_guardrail = _LazySingleton()
