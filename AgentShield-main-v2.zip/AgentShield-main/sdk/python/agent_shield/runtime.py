"""High-level Pythonic wrapper over the native runtime.

The wrapper presents:

* :class:`RuntimeBuilder` — fluent builder, hooks accept either Protocol
  implementations or plain callables.
* :class:`Runtime` — built (immutable) runtime; spawns sessions.
* :class:`Session` — per-conversation session with context-manager
  support.
* :class:`StageVerdict` — typed verdict dataclass returned by every
  ``validate_*`` call.
* :class:`Lifetime` — small helper for the §10.1 lifetime grammar.
* :class:`PerfTelemetry` — three-state opt-in for the v8 perf-logging
  instrumentation.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Mapping, Optional, Union

from .hooks import (
    AgentResolver,
    AgentResolverCallable,
    ClassifierCaller,
    ClassifierCallable,
    ClassifierVerdict,
    DelegateDispatcher,
    DelegateDispatcherCallable,
    DelegateRequest,
    LlmCallable,
    LlmCaller,
    LlmResponse,
    ResolverRequest,
    ResolverResponse,
)
from .observability import (
    ObservabilityProvider,
    ShieldLogEvent,
    make_provider,
)
from .streaming import StreamingGuard
from ._wire import from_wire_dict

if TYPE_CHECKING:
    from .config import CompiledPolicy, GuardrailsConfig

# Native module — guarded so import failure surfaces cleanly.
try:
    from agent_shield import _native  # type: ignore[attr-defined]
except (ImportError, AttributeError) as e:  # pragma: no cover
    raise ImportError(
        "agent_shield native module not available — run "
        "`maturin develop` in sdk/python/ first"
    ) from e


# ── Lifetime helper ─────────────────────────────────────────────────────


@dataclass
class Lifetime:
    """Small helper for the §10.1 lifetime grammar.

    Use the class methods to construct each form, then pass the
    instance (or its serialized form) to :meth:`Session.emit_event`::

        Lifetime.per_session()
        Lifetime.until_event("incident.threat_cleared")
        Lifetime.for_duration("PT5M")
        Lifetime.map(allow="per_call", deny="per_session")

    The runtime accepts either a :class:`Lifetime` instance or a raw
    string / dict matching the YAML grammar.
    """

    payload: Union[str, Dict[str, Any]]

    @classmethod
    def per_call(cls) -> "Lifetime":
        return cls("per_call")

    @classmethod
    def per_turn(cls) -> "Lifetime":
        return cls("per_turn")

    @classmethod
    def per_session(cls) -> "Lifetime":
        return cls("per_session")

    @classmethod
    def per_request(cls) -> "Lifetime":
        return cls("per_request")

    @classmethod
    def for_duration(cls, duration: str) -> "Lifetime":
        return cls({"for": duration})

    @classmethod
    def until_event(cls, *events: str) -> "Lifetime":
        # P12.6: reject the empty case so we surface a clear Python-side
        # ValueError instead of forwarding `[]` to the loader (which
        # rejects empty `until_event` lists).
        if not events:
            raise ValueError(
                "Lifetime.until_event requires at least one event id"
            )
        if len(events) == 1:
            return cls({"until_event": events[0]})
        return cls({"until_event": list(events)})

    @classmethod
    def map(
        cls,
        *,
        allow: Union[str, Dict[str, Any]],
        deny: Union[str, Dict[str, Any]],
        cancelled: Optional[Union[str, Dict[str, Any]]] = None,
    ) -> "Lifetime":
        m: Dict[str, Any] = {"allow": allow, "deny": deny}
        if cancelled is not None:
            m["cancelled"] = cancelled
        return cls(m)

    def to_native(self) -> Union[str, Dict[str, Any]]:
        return self.payload


def _coerce_lifetime(
    lifetime: Optional[Union[Lifetime, str, Dict[str, Any]]],
) -> Optional[Union[str, Dict[str, Any]]]:
    # Thin wrapper around the canonical native parser shared by every
    # SDK (`agent_shield_core::lifetime::parse_lifetime`). The PyO3
    # binding accepts the bare keyword / map / `for:` / `until_event:`
    # shapes directly and returns the canonical Python value.
    if lifetime is None:
        return None
    if isinstance(lifetime, Lifetime):
        lifetime = lifetime.to_native()
    return _native.parse_lifetime(lifetime)


# ── PerfTelemetry (v8 perf-logging Phase 1) ─────────────────────────────


class PerfTelemetry(str, Enum):
    """Gating level for the v8 perf-logging instrumentation (PR5/PR6).

    Default is :attr:`OFF` — zero perf events emit, the legacy event
    stream is byte-identical to the pre-v8 baseline. Pick
    :attr:`EXTERNAL` if you only want LLM + classifier cost signals
    (the predicted common-case ask); pick :attr:`FULL` for the
    complete stage / policy / detection / LLM / classifier event
    stream (diagnostic mode).

    Used by :meth:`RuntimeBuilder.with_perf_telemetry`. The wire
    representation is the snake_case string used at the FFI / spec
    boundary; subclassing :class:`str` makes the enum trivially
    serialisable.
    """

    OFF = "off"
    EXTERNAL = "external"
    FULL = "full"


# ── StageVerdict ─────────────────────────────────────────────────────────


@dataclass
class StageVerdict:
    """Typed verdict returned by every ``validate_*`` call (§14–§18)."""

    allowed: bool
    action: Optional[str] = None
    reason: Optional[str] = None
    policy: Optional[str] = None
    evaluate_when_index: Optional[int] = None
    bypassed_by_allowed_when: bool = False
    redaction: Optional[str] = None
    appended: Optional[str] = None
    prepended: Optional[str] = None
    #: Side-channel description of a deny that was caused by a
    #: ``kind: tool`` (or synthesised ``kind: human``) resolver
    #: suspending while waiting for the agent to call its tool. The
    #: dict shape is ``{"tool", "variable", "prompt", "request_id",
    #: "kind"}``. The host is expected to surface this to the agent's
    #: framework so the agent's LLM calls the named tool with the
    #: rendered prompt; the tool's ``populated_by:`` writes the
    #: response back into the variable, which unblocks the next gate
    #: evaluation. ``None`` for non-deny verdicts and for denies that
    #: did not arise from suspension.
    pending_resolution: Optional[Dict[str, Any]] = None
    #: Canonical SHA-256 hash of the invocation BEFORE policy
    #: evaluation, for invocation-bound stages (§16.0). Hosts SHOULD
    #: compare this against the invocation they actually execute to
    #: detect validate-then-mutate bugs. ``None`` for non-invocation
    #: stages (input / output) and for verdicts emitted before the
    #: branch's ``5ae96a2`` Rust core landed.
    invocation_hash: Optional[str] = None
    #: Canonical hash AFTER policy evaluation. Differs from
    #: ``invocation_hash`` only when a Stage 3 transform intentionally
    #: rewrote the invocation parameters (``redact`` / ``append`` /
    #: ``prepend``). Per spec §16.0 the host MUST execute the
    #: post-validation invocation, not the pre-validation one.
    post_validation_invocation_hash: Optional[str] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "StageVerdict":
        return from_wire_dict(cls, d)

    def __bool__(self) -> bool:  # truthy when the call may proceed.
        return self.allowed


# ── Variable state ──────────────────────────────────────────────────────


@dataclass
class VariableState:
    """Snapshot of a variable's tracker entry (§9.3)."""

    value: Any = None
    status: str = "unset"
    set_at: Optional[str] = None
    expires_at: Optional[str] = None
    deny_reason: Optional[str] = None
    source_kind: Optional[str] = None
    set_by: Optional[str] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "VariableState":
        return from_wire_dict(cls, d)


# ── Resolver bridge helpers ──────────────────────────────────────────────


def _coerce_resolver_response(value: Any) -> Dict[str, Any]:
    """Normalize a hook return value into a wire dict."""
    if isinstance(value, ResolverResponse):
        return value.to_dict()
    if isinstance(value, dict):
        return value
    raise TypeError(
        f"resolver hook returned {type(value).__name__}; "
        f"expected ResolverResponse or dict"
    )


def _wrap_resolver(
    target: Union[AgentResolver, AgentResolverCallable],
    method_name: str,
) -> Callable[[Dict[str, Any]], Dict[str, Any]]:
    """Wrap a resolver Protocol/callable into a ``(dict) -> dict`` bridge."""

    def callable_form(req_dict: Dict[str, Any]) -> Dict[str, Any]:
        request = ResolverRequest.from_dict(req_dict)
        if hasattr(target, method_name) and callable(getattr(target, method_name)):
            response = getattr(target, method_name)(request)
        elif callable(target):
            response = target(request)
        else:
            raise TypeError(
                f"resolver target must implement `{method_name}` or be callable"
            )
        return _coerce_resolver_response(response)

    return callable_form


def _wrap_dispatcher(
    target: Union[DelegateDispatcher, DelegateDispatcherCallable],
) -> Callable[[Dict[str, Any]], Dict[str, Any]]:
    def callable_form(req_dict: Dict[str, Any]) -> Dict[str, Any]:
        request = DelegateRequest.from_dict(req_dict)
        if hasattr(target, "dispatch") and callable(target.dispatch):  # type: ignore[union-attr]
            response = target.dispatch(request)  # type: ignore[union-attr]
        elif callable(target):
            response = target(request)
        else:
            raise TypeError("delegate dispatcher must have `dispatch` or be callable")
        return _coerce_resolver_response(response)

    return callable_form


def _wrap_llm_caller(
    target: Union[LlmCaller, LlmCallable],
) -> Callable[[Optional[str], str], Any]:
    def callable_form(configuration_id: Optional[str], prompt: str) -> Any:
        if hasattr(target, "call") and callable(target.call):  # type: ignore[union-attr]
            out = target.call(configuration_id, prompt)  # type: ignore[union-attr]
        elif callable(target):
            out = target(configuration_id, prompt)
        else:
            raise TypeError("LLM caller must have `call` or be callable")
        if isinstance(out, LlmResponse):
            return out.to_dict()
        return out

    return callable_form


def _wrap_classifier(
    target: Union[ClassifierCaller, ClassifierCallable],
) -> Callable[[str, str], Any]:
    def callable_form(configuration_id: str, subject: str) -> Any:
        if hasattr(target, "classify") and callable(target.classify):  # type: ignore[union-attr]
            out = target.classify(configuration_id, subject)  # type: ignore[union-attr]
        elif callable(target):
            out = target(configuration_id, subject)
        else:
            raise TypeError("classifier caller must have `classify` or be callable")
        if isinstance(out, ClassifierVerdict):
            return out.to_dict()
        return out

    return callable_form


# ── Public per-configuration LLM caller dispatcher ───────────────────────


def make_configuration_caller(
    callers: Mapping[str, Callable[[str], Any]],
    *,
    default: Optional[Callable[[str], Any]] = None,
) -> Callable[[Optional[str], str], Any]:
    """Build an LLM caller that routes by EXACT ``configuration_id`` match.

    The runtime invokes registered LLM callers with the canonical
    ``(configuration_id, prompt)`` signature (see
    :meth:`RuntimeBuilder.register_llm_caller`). When a host wants
    different underlying callers per YAML ``configurations[]`` entry
    (different model, different mocked response, different LLM
    provider) this helper produces the single dispatcher object the
    runtime expects.

    Args:
        callers: Mapping of YAML ``configurations[].id`` to a
            single-argument caller of shape ``(prompt: str) -> str``
            (or any object the runtime accepts). Routing is by exact
            match — no substring hints, no Stage-name aliases.
        default: Fallback caller used when ``configuration_id`` is
            ``None`` or absent from ``callers``. When omitted and an
            unknown id is dispatched, the dispatcher raises
            :class:`RuntimeError`.

    Returns:
        A callable matching the runtime's ``(configuration_id, prompt)
        -> str`` signature, ready to pass to
        :meth:`RuntimeBuilder.register_llm_caller`.

    Prefer the ``configuration_resolver`` kwarg on
    :meth:`agent_shield.adapters._capabilities.LlmCallerFactory.make_caller`
    when you just need to honour YAML-declared ``model:`` /
    ``provider:`` / ``max_tokens:`` selection through the same client;
    use this helper only when the host genuinely needs distinct caller
    objects per configuration id.
    """
    routes: Dict[str, Callable[[str], Any]] = dict(callers)

    def dispatcher(configuration_id: Optional[str], prompt: str) -> Any:
        if configuration_id is not None:
            caller = routes.get(configuration_id)
            if caller is not None:
                return caller(prompt)
        if default is not None:
            return default(prompt)
        # Cross-SDK parity: render the missing id as `null` (matching
        # Rust/.NET/Node) rather than Python's native `None`. Known ids
        # are single-quoted to match Rust/.NET; Node uses double quotes
        # but the structure is otherwise identical.
        id_repr = "null" if configuration_id is None else f"'{configuration_id}'"
        known = ", ".join(f"'{k}'" for k in sorted(routes))
        raise RuntimeError(
            f"no LLM caller registered for configuration_id={id_repr}; "
            f"known ids: [{known}]; no default provided",
        )

    return dispatcher


# ── Public RuntimeBuilder ────────────────────────────────────────────────


class RuntimeBuilder:
    """Fluent builder for :class:`Runtime` (§21).

    Hosts construct one builder per agent, register their hooks, and
    call :meth:`build` to obtain the immutable runtime.
    """

    def __init__(self, native_builder: Any) -> None:
        self._native = native_builder

    # ── Constructors ────────────────────────────────────────────────

    @classmethod
    def from_yaml(cls, path: str) -> "RuntimeBuilder":
        return cls(_native.RuntimeBuilder.from_yaml(str(path)))

    @classmethod
    def from_yaml_chain(cls, paths: List[str]) -> "RuntimeBuilder":
        return cls(_native.RuntimeBuilder.from_yaml_chain([str(p) for p in paths]))

    @classmethod
    def from_yaml_strings(cls, yamls: List[str]) -> "RuntimeBuilder":
        """Load a chain of YAML *strings* (no filesystem access).

        The rightmost string is the leaf; preceding strings are merged
        as ancestors with leaf-wins semantics. ``extends:`` is not
        supported on string inputs — callers building chains in memory
        should curate the order explicitly.
        """
        return cls(_native.RuntimeBuilder.from_yaml_strings([str(y) for y in yamls]))

    @classmethod
    def from_config(
        cls, config: Union[str, List[str], "GuardrailsConfig", "CompiledPolicy"],
    ) -> "RuntimeBuilder":
        """Construct a builder from any supported configuration shape.

        Accepts:

        * a single YAML path (``str`` / ``Path``)
        * a list of YAML paths (chain — leaf last)
        * a :class:`GuardrailsConfig` (composable object model)
        * a :class:`CompiledPolicy` (the materialised, hashable form
          returned by :meth:`GuardrailsConfig.compile`)
        """
        # Local import to avoid a circular import at module load.
        from agent_shield.config import CompiledPolicy, GuardrailsConfig

        if isinstance(config, CompiledPolicy):
            return cls(_native.RuntimeBuilder.from_compiled_policy(config._native_handle))
        if isinstance(config, GuardrailsConfig):
            return cls.from_config(config.compile())
        if isinstance(config, list):
            return cls.from_yaml_chain(config)
        return cls.from_yaml(config)

    # ── Hook registration ───────────────────────────────────────────

    def register_agent_resolver(
        self,
        target: Union[AgentResolver, AgentResolverCallable],
    ) -> "RuntimeBuilder":
        self._native.register_agent_resolver(_wrap_resolver(target, "resolve"))
        return self

    def register_delegate_dispatcher(
        self,
        target: Union[DelegateDispatcher, DelegateDispatcherCallable],
    ) -> "RuntimeBuilder":
        self._native.register_delegate_dispatcher(_wrap_dispatcher(target))
        return self

    def register_llm_caller(
        self,
        target: Union[LlmCaller, LlmCallable],
    ) -> "RuntimeBuilder":
        self._native.register_llm_caller(_wrap_llm_caller(target))
        return self

    def register_classifier_caller(
        self,
        target: Union[ClassifierCaller, ClassifierCallable],
    ) -> "RuntimeBuilder":
        self._native.register_classifier_caller(_wrap_classifier(target))
        return self

    def register_observability_provider(
        self,
        target: Union[ObservabilityProvider, Callable[[ShieldLogEvent], None]],
    ) -> "RuntimeBuilder":
        provider = make_provider(target)

        # Wrap so we deliver a typed dataclass to the host.
        class _Bridge:
            def __init__(self, p: ObservabilityProvider) -> None:
                self._p = p

            def emit(self, event_dict: Dict[str, Any]) -> None:
                self._p.emit(ShieldLogEvent.from_dict(event_dict))

            def shutdown(self) -> None:
                self._p.shutdown()

        self._native.register_observability_provider(_Bridge(provider))
        return self

    def register_extractor(
        self,
        name: str,
        extractor: Callable[[Any], Any],
    ) -> "RuntimeBuilder":
        self._native.register_extractor(name, extractor)
        return self

    def tool_retry_limit(self, n: int) -> "RuntimeBuilder":
        self._native.tool_retry_limit(int(n))
        return self

    def with_mode(self, mode: str) -> "RuntimeBuilder":
        """Set the runtime's effective enforcement mode (#14).

        ``mode`` is ``"active"`` (default) or ``"shadow"``. ``shadow``
        evaluates every validation stage, emits fully populated audit
        events, but never blocks, never invokes side-effecting
        resolvers, and never applies in-place transforms. The
        ``AGENT_SHIELD_MODE`` env var, when set, takes precedence
        over this call.
        """
        self._native.with_mode(str(mode))
        return self

    def with_perf_telemetry(
        self, mode: Union[PerfTelemetry, str],
    ) -> "RuntimeBuilder":
        """Opt into the v8 perf-logging instrumentation (PR5/PR6).

        ``mode`` is a :class:`PerfTelemetry` enum value (recommended)
        or its lower-case wire string (``"off"`` / ``"external"`` /
        ``"full"``). Default — when this method is never called — is
        :attr:`PerfTelemetry.OFF`, which emits zero perf events.

        - :attr:`PerfTelemetry.OFF` — diagnostic events fully
          suppressed; the event stream is byte-identical to the
          pre-v8 baseline.
        - :attr:`PerfTelemetry.EXTERNAL` — only ``llm_called`` and
          ``classifier_called`` events emit. Predicted common-case
          for adopters who want external-service cost signals
          without being drowned by stage / policy / detection events.
        - :attr:`PerfTelemetry.FULL` — every perf event emits
          (stage / policy / detection / LLM / classifier).

        See ``spec/SPECIFICATION.md`` §19 for the per-event gating
        table.
        """
        if isinstance(mode, PerfTelemetry):
            wire = mode.value
        else:
            wire = str(mode).lower()
        self._native.with_perf_telemetry(wire)
        return self

    def supports_context_reset(self, supports: bool = True) -> "RuntimeBuilder":
        """Declare host capability for sub-session IFC scope reset
        (proof TC-3). Required when the merged config declares
        ``ifc.scope: per_turn`` or ``per_request``. Hosts that retain
        LLM context across these boundaries (LangChain memory,
        AutoGen group chats, persistent conversation IDs) MUST NOT
        call this with ``True``.
        """
        self._native.supports_context_reset(bool(supports))
        return self

    # ── Build ───────────────────────────────────────────────────────

    def build(self) -> "Runtime":
        return Runtime(self._native.build())


# ── Public Runtime ───────────────────────────────────────────────────────


class Runtime:
    """Immutable runtime — spawns one :class:`Session` per agent
    conversation."""

    def __init__(self, native_runtime: Any) -> None:
        self._native = native_runtime

    @staticmethod
    def configure_logging(level: Optional[str] = None) -> None:
        """Set up a sensible default logging config for Agent Shield.

        Reads :envvar:`AGENT_SHIELD_LOG_LEVEL` (DEBUG / INFO / WARNING /
        ERROR) when ``level`` is not provided. Idempotent — calling
        twice is harmless. Customer demos are the primary caller.
        """
        import logging
        import os

        resolved = (level or os.getenv("AGENT_SHIELD_LOG_LEVEL", "WARNING")).upper()
        numeric = getattr(logging, resolved, None)
        if not isinstance(numeric, int):
            numeric = logging.WARNING
        logger = logging.getLogger("agent_shield")
        if not logger.handlers:
            handler = logging.StreamHandler()
            handler.setFormatter(
                logging.Formatter("%(asctime)s [%(name)s] %(levelname)s: %(message)s")
            )
            logger.addHandler(handler)
        logger.setLevel(numeric)

    @property
    def metadata_name(self) -> str:
        return self._native.metadata_name()

    @property
    def variable_names(self) -> List[str]:
        return list(self._native.variable_names())

    @property
    def mode(self) -> str:
        """Effective runtime mode (#14): ``"active"`` or ``"shadow"``.

        YAML ``mode:`` with ``AGENT_SHIELD_MODE`` env override. SDK
        orchestrators force ``ShieldMode.MONITOR`` in shadow mode.
        """
        return self._native.mode()

    def llm_configuration(self, configuration_id: str) -> Optional[Dict[str, Any]]:
        """Look up an LLM `configurations[]` entry by id (§6).

        Returns ``None`` when no entry matches *or* when the matching
        entry is not of type ``llm``. Used by adapter LLM-caller
        closures to honour the YAML's per-stage ``model:`` / ``provider:``
        / ``max_tokens:`` selection rather than hard-coding a model.
        """
        cfg = self._native.llm_configuration(configuration_id)
        if cfg is None:
            return None
        # Filter to `type: llm` so callers don't accidentally pick up
        # classifier / a2a / mcp entries that share an id namespace.
        if cfg.get("type") != "llm":
            return None
        return cfg

    def new_session(
        self,
        *,
        session_id: Optional[str] = None,
        correlation_id: Optional[str] = None,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        extensions: Optional[Dict[str, Any]] = None,
        request_context: Optional[Dict[str, Any]] = None,
    ) -> "Session":
        ctx: Dict[str, Any] = dict(request_context or {})
        if session_id is not None:
            ctx["session_id"] = session_id
        if correlation_id is not None:
            ctx["correlation_id"] = correlation_id
        if user_id is not None:
            ctx["user_id"] = user_id
        if tenant_id is not None:
            ctx["tenant_id"] = tenant_id
        if extensions is not None:
            ctx["extensions"] = extensions
        return Session(self._native.new_session(ctx if ctx else None))


# ── Public Session ───────────────────────────────────────────────────────


class Session:
    """Per-conversation gating session (§21).

    Use as a context manager so dangling boundary scopes are closed
    automatically::

        with runtime.new_session(session_id="...") as session:
            session.begin_turn()
            verdict = session.validate_input("user message")
            ...
    """

    def __init__(self, native_session: Any) -> None:
        self._native = native_session
        self._closed = False

    # Context-manager support.
    def __enter__(self) -> "Session":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        # Don't try to call into a partially-collapsed runtime if an
        # exception unwound through us.
        if self._closed:
            return
        try:
            self.end_turn()
        except Exception:  # noqa: BLE001
            pass
        try:
            self.end_request()
        except Exception:  # noqa: BLE001
            pass
        self._closed = True

    # ── Variable ops ────────────────────────────────────────────────

    def set_variable(self, name: str, value: Any) -> None:
        self._native.set_variable(name, value)

    def reset_variable(self, name: str) -> None:
        self._native.reset_variable(name)

    def resolve_variable(self, name: str) -> Optional[Any]:
        return self._native.resolve_variable(name)

    def read_variable(self, name: str) -> Optional[VariableState]:
        d = self._native.read_variable(name)
        if d is None:
            return None
        return VariableState.from_dict(d)

    # ── Event ops ───────────────────────────────────────────────────

    def emit_event(
        self,
        event_id: str,
        *,
        lifetime: Optional[Union[Lifetime, str, Dict[str, Any]]] = None,
        payload: Any = None,
    ) -> None:
        self._native.emit_event(event_id, _coerce_lifetime(lifetime), payload)

    def clear_event(self, event_id: str) -> None:
        self._native.clear_event(event_id)

    def emit_incident(self, name: str, payload: Any = None) -> None:
        self._native.emit_incident(name, payload)

    # ── Boundary ops ────────────────────────────────────────────────

    def begin_turn(self) -> int:
        return int(self._native.begin_turn())

    def end_turn(self) -> None:
        self._native.end_turn()

    def begin_request(self) -> int:
        return int(self._native.begin_request())

    def end_request(self) -> None:
        self._native.end_request()

    @property
    def current_turn_id(self) -> int:
        return int(self._native.current_turn_id())

    @property
    def current_request_id(self) -> int:
        return int(self._native.current_request_id())

    # ── IFC ops (proof: docs/information-flow-control-proof.md) ─────

    @property
    def current_exposure(self) -> List[str]:
        """The session's running IFC exposure as a sorted list of
        declared tag names. Empty list when IFC is disabled (no
        ``ifc:`` block in the merged config) or when exposure is ⊥.
        """
        return list(self._native.current_exposure())

    # ── Stage validation ────────────────────────────────────────────

    def validate_input(self, user_input: str) -> StageVerdict:
        return StageVerdict.from_dict(self._native.validate_input(user_input))

    def validate_tool_call(
        self,
        tool: str,
        params: Optional[Dict[str, Any]] = None,
        *,
        tool_call_id: str,
    ) -> "ToolCallOutcome":
        if not isinstance(tool_call_id, str):
            raise TypeError("tool_call_id must be a str")
        verdict_dict, mutated = self._native.validate_tool_call(
            tool, params or {}, tool_call_id
        )
        return ToolCallOutcome(StageVerdict.from_dict(verdict_dict), mutated)

    def validate_tool_output(
        self,
        tool: str,
        result: Any,
        *,
        tool_call_id: str,
    ) -> "ToolOutputOutcome":
        if not isinstance(tool_call_id, str):
            raise TypeError("tool_call_id must be a str")
        verdict_dict, mutated = self._native.validate_tool_output(
            tool, result, tool_call_id
        )
        return ToolOutputOutcome(StageVerdict.from_dict(verdict_dict), mutated)

    def validate_endpoint_call(
        self,
        method: str,
        uri: str,
        body: Optional[Dict[str, Any]] = None,
        *,
        tool_call_id: str,
    ) -> "EndpointCallOutcome":
        if not isinstance(tool_call_id, str):
            raise TypeError("tool_call_id must be a str")
        verdict_dict, mutated = self._native.validate_endpoint_call(
            method, uri, body or {}, tool_call_id
        )
        return EndpointCallOutcome(StageVerdict.from_dict(verdict_dict), mutated)

    def validate_agent_call(
        self,
        agent: str,
        params: Optional[Dict[str, Any]] = None,
        *,
        tool_call_id: str,
    ) -> "AgentCallOutcome":
        if not isinstance(tool_call_id, str):
            raise TypeError("tool_call_id must be a str")
        verdict_dict, mutated = self._native.validate_agent_call(
            agent, params or {}, tool_call_id
        )
        return AgentCallOutcome(StageVerdict.from_dict(verdict_dict), mutated)

    def validate_output(self, response: str) -> "OutputOutcome":
        verdict_dict, mutated = self._native.validate_output(response)
        return OutputOutcome(StageVerdict.from_dict(verdict_dict), mutated)

    # ── Resource cycle helpers ─────────────────────────────────────

    def record_tool_success(self, tool: str, result: Any) -> None:
        self._native.record_tool_success(tool, result)

    def record_tool_failure(self, tool: str, error: str) -> None:
        self._native.record_tool_failure(tool, error)

    def record_endpoint_success(self, method: str, pattern: str, result: Any) -> None:
        self._native.record_endpoint_success(method, pattern, result)

    def record_endpoint_failure(self, method: str, pattern: str, error: str) -> None:
        self._native.record_endpoint_failure(method, pattern, error)

    def record_agent_success(self, agent: str, result: Any) -> None:
        self._native.record_agent_success(agent, result)

    def record_agent_failure(self, agent: str, error: str) -> None:
        self._native.record_agent_failure(agent, error)

    # ── Streaming ───────────────────────────────────────────────────

    def streaming_session(self, stage: Union[int, str]) -> StreamingGuard:
        """Create a streaming guard for Stage 4 or Stage 5.

        ``stage`` may be ``4`` / ``5`` or ``"post_tool"`` / ``"output"``.
        The returned wrapper exposes the streamed-output validation
        surface. ``incident.stream_aborted`` and
        ``incident.stream_limit_exceeded`` are emitted by the
        core/native dispatcher, not by this Python wrapper.
        """
        return StreamingGuard(self._native.streaming_session(stage))


# ── Stage outcome wrappers ──────────────────────────────────────────────


@dataclass
class ToolCallOutcome:
    """Verdict + (possibly mutated) tool params from Stage 3."""

    verdict: StageVerdict
    params: Dict[str, Any] = field(default_factory=dict)

    def __bool__(self) -> bool:
        return self.verdict.allowed


@dataclass
class ToolOutputOutcome:
    """Verdict + (possibly redacted) tool result from Stage 4."""

    verdict: StageVerdict
    result: Any = None

    def __bool__(self) -> bool:
        return self.verdict.allowed


@dataclass
class EndpointCallOutcome:
    """Verdict + body from Stage 3 endpoint check."""

    verdict: StageVerdict
    body: Any = None

    def __bool__(self) -> bool:
        return self.verdict.allowed


@dataclass
class AgentCallOutcome:
    """Verdict + params from Stage 3 agent call check."""

    verdict: StageVerdict
    params: Any = None

    def __bool__(self) -> bool:
        return self.verdict.allowed


@dataclass
class OutputOutcome:
    """Verdict + (possibly transformed) response text from Stage 5."""

    verdict: StageVerdict
    response: str = ""

    def __bool__(self) -> bool:
        return self.verdict.allowed


__all__ = [
    "RuntimeBuilder",
    "Runtime",
    "Session",
    "StageVerdict",
    "VariableState",
    "Lifetime",
    "ToolCallOutcome",
    "ToolOutputOutcome",
    "EndpointCallOutcome",
    "AgentCallOutcome",
    "OutputOutcome",
]
