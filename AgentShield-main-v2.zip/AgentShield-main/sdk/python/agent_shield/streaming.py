"""Streaming guard wrapper for Stage 4 / Stage 5 streaming validation."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Iterator, Optional

from ._wire import from_wire_dict

# Re-exported here so callers don't need to reach into the native module.


@dataclass
class StreamChunkResult:
    """Verdict returned by every chunk submission.

    ``action`` is one of ``"pass"`` / ``"replace"`` / ``"stop"``.
    ``payload`` is the bytes the host SHOULD emit for this chunk:

    - ``pass`` with empty payload — the chunk is buffered.
    - ``pass`` with a payload — emit the payload as the next chunk.
    - ``replace`` — replace any prior emitted tail with ``payload``.
    - ``stop`` — block the stream; the host MUST stop emitting.
    """

    action: str
    payload: str = ""
    reason: Optional[str] = None

    @classmethod
    def from_dict(cls, d: dict) -> "StreamChunkResult":
        return from_wire_dict(cls, d)

    @property
    def stopped(self) -> bool:
        return self.action == "stop"


class StreamingGuard:
    """Idiomatic Python wrapper over the native ``StreamingGuard``.

    Use as a context manager::

        with session.streaming_session(stage=5) as guard:
            for chunk in upstream:
                result = guard.push(chunk)
                if result.stopped:
                    break
                if result.payload:
                    yield result.payload
            tail = guard.finish()
            if tail.payload:
                yield tail.payload

    The guard also exposes :meth:`process` which yields safe-to-emit
    text given an upstream iterable; it stops at the first ``stop``
    verdict.
    """

    def __init__(self, native_guard: Any) -> None:
        self._native = native_guard
        self._finished = False

    # Context-manager support.
    def __enter__(self) -> "StreamingGuard":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        # If the host didn't call finish() explicitly, do a best-effort
        # flush so the runtime sees end-of-stream. Errors are swallowed
        # because __exit__ runs during exception propagation.
        if not self._finished and not self._native.is_ended:
            try:
                self.finish()
            except Exception:  # noqa: BLE001 — best-effort cleanup
                pass

    def push(self, chunk: str) -> StreamChunkResult:
        """Submit one chunk and return the verdict."""
        d = self._native.push(chunk)
        result = StreamChunkResult.from_dict(d)
        if result.stopped:
            self._finished = True
        return result

    def finish(self) -> StreamChunkResult:
        """Signal end-of-stream. Returns the un-emitted remainder."""
        d = self._native.finish()
        self._finished = True
        return StreamChunkResult.from_dict(d)

    def process(self, chunks: Iterable[str]) -> Iterator[str]:
        """Run an upstream iterator through the guard and yield safe text.

        Yields each ``payload`` from the verdict in turn. A ``stop``
        verdict terminates the iterator.
        """
        for chunk in chunks:
            result = self.push(chunk)
            if result.stopped:
                return
            if result.payload:
                yield result.payload
        tail = self.finish()
        if tail.stopped:
            return
        if tail.payload:
            yield tail.payload

    @property
    def buffer(self) -> str:
        return self._native.buffer

    @property
    def chunks_received(self) -> int:
        return self._native.chunks_received

    @property
    def is_ended(self) -> bool:
        return self._native.is_ended

    @property
    def mode(self) -> str:
        """Validation cadence: ``"on_complete"`` / ``"windowed"`` /
        ``"per_chunk"``.

        SDK adapters use this to decide whether to forward upstream
        chunks to the customer in real time (``per_chunk`` /
        ``windowed``) or to buffer every chunk and emit only the final
        validated payload at :meth:`finish` (``on_complete``). When the
        cadence is ``on_complete`` every :meth:`push` returns
        ``StreamChunkResult(action="pass", payload="")``; the consumer
        MUST NOT see any text-bearing emission until :meth:`finish`
        returns the validated full text.
        """
        return self._native.mode


__all__ = ["StreamChunkResult", "StreamingGuard"]
