"""CrewAI integration for Agent Shield guardrails.

Capability-based adapter that plugs into the framework-agnostic
:class:`~agent_shield.adapters._shield.Shield` orchestrator.

CrewAI tools execute synchronously (``BaseTool._run``) and CrewAI
exposes two distinct guard targets:

* :class:`GuardedAgent` — Stage 1 / Stage 5 helper methods you call
  manually around a CrewAI ``Agent`` (CrewAI agents don't expose a
  generic ``run``/``invoke``).
* :class:`GuardedCrew` — wraps ``Crew.kickoff`` with full Stage 1 +
  Stage 5 enforcement.

Because CrewAI tools are sync, the wrapper sidesteps the orchestrator's
async ``invoke`` flow and uses the sync orchestration helper directly.

**Level 2 — Shield helper** (recommended)::

    from agent_shield import Shield
    import agent_shield.adapters.crewai  # side-effect import

    shield = (
        Shield.from_yaml("guardrails.yaml")
        .with_crewai()
        .with_client(llm)
        .build()
    )
    tools  = shield.protect_tools(tools)
    crew   = shield.guard_crew(crew)
"""
from __future__ import annotations

import logging
import uuid
from typing import Any, AsyncIterator, Callable, Optional

from agent_shield import Runtime, Session

from ._capabilities import (
    AgentBoundary,
    CapabilityReport,
    CoverageLevel,
    FrameworkBundle,
    GuardedInvoke,
    LlmCallerFactory,
    StreamingAdapter,
    StreamingValidator,
    ToolMetadata,
    ToolWrapper,
)
from ._orchestration import (
    _format_block_message,
    check_stage1,
    current_session,
    current_user_input,
    guarded_tool_sync,
)
from ._shield import (
    Shield,
    ShieldBuilder,
    _protect_tools_via_wrapper,
)

logger = logging.getLogger("agent_shield.crewai")


# ---------------------------------------------------------------------------
# Capability 1 — LLM caller factory
# ---------------------------------------------------------------------------


#: Litellm-supported kwargs the adapter forwards from YAML
#: ``configurations[]`` entries when present in cfg. ``api_key`` is
#: deliberately omitted: the spec's YAML schema only allows
#: ``api_key_env`` (an *env var name* indirection, §6.2), and silently
#: forwarding raw keys from a hand-rolled resolver would be an
#: easy-to-miss secrets-in-config foot-gun. Customers who need a
#: per-stage API key should set it via the environment / litellm
#: provider config.
_LITELLM_COMPLETION_KWARGS: tuple[str, ...] = (
    "max_tokens",
    "temperature",
    "top_p",
    "frequency_penalty",
    "presence_penalty",
    "stop",
    "api_base",
)


def _filter_litellm_kwargs(
    cfg: Optional[dict], model: Optional[str],
) -> dict[str, Any]:
    """Build the ``litellm.completion(...)`` kwargs subset from cfg.

    Returns only kwargs whose values are not ``None`` and which appear
    in :data:`_LITELLM_COMPLETION_KWARGS`. When ``model`` is provided
    and ``litellm.get_supported_openai_params`` is available, the
    returned set is intersected with the model's per-provider
    supported-params list so that, e.g., a Gemini deployment doesn't
    receive ``frequency_penalty`` it would error on. Falls back to the
    static list if introspection is unavailable.
    """
    if not cfg:
        return {}

    supported: Optional[set[str]] = None
    if model:
        try:
            import litellm  # local import — only when cfg is non-empty

            params = litellm.get_supported_openai_params(model=model)
            if params:
                supported = set(params)
        except Exception:
            logger.debug(
                "crewai llm caller: litellm.get_supported_openai_params"
                "(model=%r) failed; falling back to the static "
                "kwargs list.",
                model, exc_info=True,
            )
            supported = None

    out: dict[str, Any] = {}
    for key in _LITELLM_COMPLETION_KWARGS:
        value = cfg.get(key)
        if value is None:
            continue
        if supported is not None and key not in supported:
            logger.debug(
                "crewai llm caller: dropping cfg kwarg %r (model %r "
                "does not list it in litellm's supported params).",
                key, model,
            )
            continue
        out[key] = value
    return out


def _build_crewai_llm_override(llm: Any, cfg: Optional[dict]) -> Any:
    """Return a per-call ``crewai.LLM`` clone with cfg overrides applied.

    Uses pydantic v2's ``model_copy(update={...})`` so the customer's
    LLM instance is not mutated across stages. Falls back to the
    original instance if the LLM doesn't expose ``model_copy``
    (defensive — older / forked LLM types).
    """
    if not cfg:
        return llm

    fields = getattr(type(llm), "model_fields", None)
    if not fields:
        return llm

    candidate_keys = (
        "model",
        "max_tokens",
        "temperature",
        "top_p",
        "frequency_penalty",
        "presence_penalty",
        "stop",
        "api_base",
    )
    update: dict[str, Any] = {}
    for key in candidate_keys:
        value = cfg.get(key)
        if value is None:
            continue
        if key in fields:
            update[key] = value

    if not update:
        return llm

    copy = getattr(llm, "model_copy", None)
    if copy is None or not callable(copy):
        logger.debug(
            "crewai llm caller: crewai.LLM lacks model_copy; "
            "skipping cfg overrides for this call.",
        )
        return llm
    try:
        return copy(update=update)
    except Exception:
        logger.debug(
            "crewai llm caller: crewai.LLM.model_copy(update=%r) "
            "raised; falling back to the un-overridden instance.",
            update, exc_info=True,
        )
        return llm


def _bind_langchain_overrides(llm: Any, cfg: Optional[dict]) -> Any:
    """Best-effort ``.bind(...)`` for LangChain ``Runnable`` shapes.

    Mirrors the LangChain adapter's caller (``langchain.py``): forwards
    only ``max_tokens`` and ``temperature``. ``model`` is intentionally
    NOT bound — a pre-constructed ``BaseChatModel`` has the provider's
    API key / endpoint / deployment locked to the model the customer
    chose, and silently swapping the model would bypass that.
    """
    if not cfg:
        return llm
    bind = getattr(llm, "bind", None)
    if bind is None or not callable(bind):
        return llm
    bind_kwargs: dict[str, Any] = {}
    if cfg.get("max_tokens") is not None:
        bind_kwargs["max_tokens"] = cfg["max_tokens"]
    if cfg.get("temperature") is not None:
        bind_kwargs["temperature"] = cfg["temperature"]
    if not bind_kwargs:
        return llm
    try:
        return bind(**bind_kwargs)
    except Exception:
        logger.debug(
            "crewai llm caller: BaseChatModel.bind(%r) raised; "
            "falling back to the un-bound instance.",
            bind_kwargs, exc_info=True,
        )
        return llm


class _LlmCallerFactory(LlmCallerFactory):
    """Adapt a CrewAI-compatible LLM (LLM / string / langchain / callable).

    CrewAI accepts five LLM shapes. The ``configuration_resolver``
    plumbs YAML ``configurations[]`` overrides through where each
    shape allows:

    * ``str`` (litellm model name) — every kwarg in
      :data:`_LITELLM_COMPLETION_KWARGS` (plus ``model``) is forwarded
      to ``litellm.completion``. The kwargs are filtered against
      ``litellm.get_supported_openai_params(model)`` at call time so
      that, e.g., a Gemini model doesn't receive ``presence_penalty``
      it can't honor.
    * ``crewai.LLM`` — per-call ``model_copy(update={...})`` clone
      with cfg overrides applied to the matching pydantic fields
      (``model``, ``max_tokens``, ``temperature``, ``top_p``,
      ``frequency_penalty``, ``presence_penalty``, ``stop``,
      ``api_base``). The customer instance is not mutated.
    * LangChain ``BaseChatModel`` (``.invoke``) — best-effort
      ``.bind(max_tokens=..., temperature=...)``; ``model`` is left
      alone (provider config is bound on the customer's instance).
    * Generic ``.call``-shaped LLM — no-op. The contract on ``.call``
      is a chat-message list only; the model is bound on the customer
      object and there's no provider-agnostic way to override.
    * Plain callable ``llm(prompt)`` — no-op. The callable signature
      is a single string in / string out; there's nowhere to plumb cfg.

    For the no-op shapes the fallback DEBUG log still fires so
    customers can correlate stage routing with their LLM choice.

    ``DEFAULT_FALLBACK_MODEL`` is a documentation marker for the
    diagnostic log; it does not override the customer's bound model.
    """

    #: Documentation marker — used only in fallback DEBUG logs to
    #: correlate stage routing with the customer's LLM choice. For
    #: the ``str``-shaped LLM, the customer-supplied string is the
    #: actual default and this constant is unused at call time.
    DEFAULT_FALLBACK_MODEL = "customer-supplied CrewAI LLM"

    def make_caller(
        self,
        llm: Any,
        *,
        configuration_resolver: Optional[
            Callable[[Optional[str]], Optional[dict]]
        ] = None,
    ) -> Callable[[Optional[str], str], str]:
        fallback_model = self.DEFAULT_FALLBACK_MODEL

        def caller(configuration_id: Optional[str], prompt: str) -> str:
            cfg: Optional[dict] = None
            if configuration_resolver is not None and configuration_id:
                try:
                    cfg = configuration_resolver(configuration_id)
                except Exception:
                    # Resolver lookup must never break the LLM caller —
                    # fall through to the documented fallback path.
                    logger.exception(
                        "crewai llm caller: configuration_resolver "
                        "raised for configuration_id=%r; falling back to "
                        "the customer-supplied LLM (%r).",
                        configuration_id,
                        fallback_model,
                    )
                    cfg = None

            if cfg is None and configuration_id:
                # Only DEBUG-log on the genuine SRE signal — a stage
                # asked for routing and didn't get it. The "no
                # routing requested" case (configuration_id ``None``
                # / ``""``) is a legitimate fallback. Mirrors the
                # OpenAI / Anthropic / SK Python adapters.
                logger.debug(
                    "crewai llm caller: no `configurations[]` entry "
                    "matched configuration_id=%r; invoking the customer-"
                    "supplied LLM without per-call overrides. Declare "
                    "`configurations: - {id: %s, type: llm, model: ..., "
                    "max_tokens: ..., temperature: ...}` in "
                    "`.guardrails.yaml` to forward invocation params "
                    "(model only applies when the customer-supplied LLM "
                    "is a litellm model-name string or a crewai.LLM).",
                    configuration_id,
                    configuration_id or "<unset>",
                )

            try:
                # Use ``BaseLLM`` (not ``LLM``): ``crewai.LLM(model=...)``
                # returns a provider-specific subclass (e.g.
                # ``OpenAICompletion``), not a ``LLM`` instance, so an
                # ``isinstance(llm, LLM)`` check is dead code. Every
                # crewai LLM subclass — including ``LLM`` itself — is a
                # pydantic ``BaseLLM``, which exposes
                # ``model_copy(update={...})`` for per-call overrides.
                from crewai import BaseLLM

                if isinstance(llm, BaseLLM):
                    target = _build_crewai_llm_override(llm, cfg)
                    response = target.call(
                        [{"role": "user", "content": prompt}],
                    )
                    return response if isinstance(response, str) else str(response)
            except ImportError:
                pass

            if isinstance(llm, str):
                from litellm import completion

                resolved_model = (cfg.get("model") if cfg else None) or llm
                completion_kwargs: dict = {
                    "model": resolved_model,
                    "messages": [{"role": "user", "content": prompt}],
                }
                completion_kwargs.update(
                    _filter_litellm_kwargs(cfg, resolved_model),
                )
                response = completion(**completion_kwargs)
                return response.choices[0].message.content or ""

            if hasattr(llm, "call"):
                # ``.call``-shaped LLM (non-crewai.LLM): the contract is
                # a chat-message list only — no per-call kwarg surface,
                # so cfg overrides are a no-op for this shape. The
                # diagnostic DEBUG log above still fires on fallback so
                # customers see stage routing.
                response = llm.call([{"role": "user", "content": prompt}])
                return response if isinstance(response, str) else str(response)

            if hasattr(llm, "invoke"):
                from langchain_core.messages import HumanMessage

                target = _bind_langchain_overrides(llm, cfg)
                response = target.invoke([HumanMessage(content=prompt)])
                return str(getattr(response, "content", response))

            if callable(llm):
                # Bare callable ``llm(prompt) -> str``: the signature has
                # no kwargs surface, so cfg overrides are a no-op for
                # this shape. The diagnostic DEBUG log above still fires.
                response = llm(prompt)
                return response if isinstance(response, str) else str(response)

            raise TypeError(
                f"Cannot create LLM caller from {type(llm).__name__}. "
                f"Expected a CrewAI LLM, a LangChain model, a string model "
                f"name, or a callable."
            )

        return caller


# ---------------------------------------------------------------------------
# Capability 2 — Tool wrapper (sync)
# ---------------------------------------------------------------------------


class _ToolWrapper(ToolWrapper):
    """Wrap a CrewAI ``BaseTool`` with a sync guarded subclass.

    CrewAI tools execute synchronously, so the wrapper bypasses the
    async ``guarded_invoke`` and calls
    :func:`guarded_tool_sync` directly inside ``_run``. The async
    :meth:`invoke` is provided for completeness (it runs the sync
    method straight through).
    """

    def extract(self, tool: Any) -> ToolMetadata:
        return ToolMetadata(
            name=tool.name,
            description=tool.description,
            extras={"args_schema": getattr(tool, "args_schema", None)},
        )

    async def invoke(self, original: Any, params: dict) -> Any:
        return original._run(**params)

    def wrap(
        self,
        original: Any,
        metadata: ToolMetadata,
        guarded_invoke: GuardedInvoke,
    ) -> Any:
        from crewai.tools import BaseTool

        _orig = original
        _name = metadata.name
        _desc = metadata.description

        class _GuardedTool(BaseTool):
            name: str = _name
            description: str = _desc
            model_config = {"arbitrary_types_allowed": True}

            def _run(self, **kwargs: Any) -> Any:
                user_input = current_user_input.get("")

                def _execute(effective_params: dict) -> Any:
                    return _orig._run(**effective_params)

                # §16.0 binding — CrewAI tool boundary has no upstream
                # call id; mint a per-call id so concurrent same-name
                # calls bind correctly through Stage 3 → Stage 4.
                _call_id = uuid.uuid4().hex
                _blocked, output = guarded_tool_sync(
                    _name,
                    kwargs,
                    execute=_execute,
                    user_input=user_input,
                    tool_call_id=_call_id,
                )
                return output

        init_kwargs: dict[str, Any] = {}
        schema = metadata.extras.get("args_schema")
        if schema is not None:
            init_kwargs["args_schema"] = schema
        return _GuardedTool(**init_kwargs)


# ---------------------------------------------------------------------------
# Capability 3 — Agent boundary (drives Crew.kickoff)
# ---------------------------------------------------------------------------


class _AgentBoundary(AgentBoundary):
    """Run a CrewAI ``Crew`` via ``kickoff`` and reshape its result.

    The "agent" parameter here is a CrewAI ``Crew`` (not a CrewAI
    ``Agent``). CrewAI Agents don't have a generic run/invoke surface;
    their orchestrated execution lives at the Crew level.
    """

    async def run(
        self, agent: Any, input_text: str, **kwargs: Any,
    ) -> Any:
        # CrewAI's kickoff is sync — call it directly.
        inputs = kwargs.pop("inputs", None)
        return agent.kickoff(inputs=inputs)

    def extract_output(self, result: Any) -> Optional[str]:
        return str(result) if result else None

    def apply_redaction(self, result: Any, redacted_text: str) -> Any:
        # CrewAI's kickoff returns plain text/CrewOutput; we surface
        # the redacted text directly.
        return redacted_text

    def make_blocked(self, message: str) -> Any:
        return message


# ---------------------------------------------------------------------------
# Capability 4 — Streaming (unsupported)
# ---------------------------------------------------------------------------


class _StreamingAdapter(StreamingAdapter):
    """CrewAI does not expose a streaming kickoff API."""

    async def stream(
        self,
        agent: Any,
        input_text: str,
        validator: StreamingValidator,
        **kwargs: Any,
    ) -> AsyncIterator[Any]:
        raise NotImplementedError(
            "CrewAI does not expose a streaming kickoff API"
        )
        yield  # pragma: no cover — make this a generator function


# ---------------------------------------------------------------------------
# Bundle
# ---------------------------------------------------------------------------


_BUNDLE = FrameworkBundle(
    name="crewai",
    llm_caller_factory=_LlmCallerFactory(),
    tool_wrapper=_ToolWrapper(),
    agent_boundary=_AgentBoundary(),
    streaming_adapter=None,
    capabilities=CapabilityReport(
        framework="crewai",
        streaming_output=CoverageLevel.UNSUPPORTED,
        notes=["CrewAI has no streaming kickoff API"],
    ),
)


# ---------------------------------------------------------------------------
# CrewAI-flavoured GuardedAgent (helpers, not a runner)
# ---------------------------------------------------------------------------


class GuardedAgent:
    """Wraps a CrewAI ``Agent`` with manual Stage 1 / Stage 5 helpers.

    CrewAI agents don't expose a clean ``invoke`` interface — most
    integrations validate at the crew/task level. This wrapper provides
    explicit ``validate_input`` / ``validate_output`` helpers so callers
    can wire them in by hand.
    """

    def __init__(
        self,
        runtime: Runtime,
        agent: Any,
        streaming_config: dict[str, Any] | None = None,
    ) -> None:
        self._runtime = runtime
        self._agent = agent
        self._streaming_config = streaming_config
        self._session: Session = self._runtime.new_session()
        try:
            self._session.begin_turn()
        except Exception:  # noqa: BLE001
            logger.debug("begin_turn raised; continuing", exc_info=True)

    def validate_input(self, user_input: str) -> str | None:
        """Stage 1 input validation (sync). Returns ``None`` if allowed."""
        token = current_session.set(self._session)
        try:
            return check_stage1(self._session, user_input)
        finally:
            current_session.reset(token)

    def validate_output(
        self, output: str, user_input: str = "",
    ) -> tuple[bool, str]:
        """Stage 5 output validation (sync)."""
        outcome = self._session.validate_output(output)
        if not outcome.verdict.allowed:
            logger.warning(
                "[Stage 5] Output blocked (%s): %s",
                outcome.verdict.action, outcome.verdict.reason,
            )
            return False, _format_block_message(outcome.verdict)
        if outcome.response != output:
            logger.info("[Stage 5] Output redacted before delivery")
        return True, outcome.response

    @property
    def agent(self) -> Any:
        return self._agent

    def __getattr__(self, name: str) -> Any:
        return getattr(self._agent, name)

    def reset(self) -> None:
        try:
            self._session.end_turn()
        except Exception:  # noqa: BLE001
            pass
        self._session = self._runtime.new_session()
        try:
            self._session.begin_turn()
        except Exception:  # noqa: BLE001
            pass

    def __repr__(self) -> str:
        return f"GuardedAgent(runtime=..., agent={self._agent!r})"


# ---------------------------------------------------------------------------
# CrewAI-flavoured GuardedCrew (kickoff with Stage 1 + Stage 5)
# ---------------------------------------------------------------------------


class GuardedCrew:
    """Wraps a CrewAI ``Crew`` with Stage 1 + Stage 5 validation."""

    def __init__(self, runtime: Runtime, crew: Any) -> None:
        self._runtime = runtime
        self._crew = crew
        self._session: Session = self._runtime.new_session()

    def kickoff(self, inputs: dict[str, Any] | None = None) -> Any:
        """Run the crew with Stage 1 + Stage 5 validation."""
        session = self._session
        session.begin_turn()
        token = current_session.set(session)
        input_token = current_user_input.set("")
        try:
            user_input = ""
            if inputs:
                for key, value in inputs.items():
                    if isinstance(value, str) and value.strip():
                        verdict = session.validate_input(value)
                        if not verdict.allowed:
                            logger.warning(
                                "[Stage 1] Input '%s' blocked (%s): %s",
                                key, verdict.action, verdict.reason,
                            )
                            return _format_block_message(verdict)
                        user_input = value
                current_user_input.set(user_input)

            result = self._crew.kickoff(inputs=inputs)

            output_text = str(result) if result else ""
            if output_text:
                outcome = session.validate_output(output_text)
                if not outcome.verdict.allowed:
                    logger.warning(
                        "[Stage 5] Output blocked (%s): %s",
                        outcome.verdict.action, outcome.verdict.reason,
                    )
                    return _format_block_message(outcome.verdict)
                if outcome.response != output_text:
                    logger.info("[Stage 5] Output redacted before delivery")
                    return outcome.response

            return result
        finally:
            current_user_input.reset(input_token)
            current_session.reset(token)
            try:
                session.end_turn()
            except Exception:  # noqa: BLE001
                logger.debug("end_turn raised", exc_info=True)

    @property
    def crew(self) -> Any:
        return self._crew

    def __getattr__(self, name: str) -> Any:
        return getattr(self._crew, name)

    def reset(self) -> None:
        self._session = self._runtime.new_session()

    def __repr__(self) -> str:
        return f"GuardedCrew(runtime=..., crew={self._crew!r})"


# ---------------------------------------------------------------------------
# Composition pattern — install with_crewai() and create_crewai_agent().
# ---------------------------------------------------------------------------


def _install() -> None:
    """Monkey-install :meth:`ShieldBuilder.with_crewai`,
    :meth:`Shield.create_crewai_agent`, and :meth:`Shield.guard_crew`."""

    def with_crewai(self: ShieldBuilder) -> ShieldBuilder:
        """Bind this builder to the CrewAI framework bundle."""
        return self._bind_to_bundle(_BUNDLE)

    def create_crewai_agent(
        self: Shield,
        tools: list,
        *,
        role: str = "assistant",
        goal: str = "",
        backstory: str = "",
        llm: Any = None,
        **agent_kwargs: Any,
    ) -> Any:
        """Build a fully guarded CrewAI Agent in one call (Pattern A)."""
        from crewai import Agent

        protected = self.protect_tools(tools)
        agent = Agent(
            role=role,
            goal=goal,
            backstory=backstory,
            tools=protected,
            llm=llm,
            **agent_kwargs,
        )
        # CrewAI's GuardedAgent is a custom helper (not a GuardedRunner) —
        # the base Shield.guard returns a generic runner, so build the
        # CrewAI-flavoured helper directly here.
        ga = GuardedAgent(
            self.runtime, agent, streaming_config=self._streaming_config,
        )
        self._guarded_runners.add(ga)
        return ga

    def guard_crew(self: Shield, crew: Any) -> "GuardedCrew":
        """Wrap a CrewAI Crew with Stages 1 + 5 enforcement."""
        gc = GuardedCrew(self.runtime, crew)
        # GuardedCrew is not a GuardedRunner — track via the same weakset
        # so observability and lifecycle callers still see it.
        self._guarded_runners.add(gc)
        return gc

    ShieldBuilder.with_crewai = with_crewai
    Shield.create_crewai_agent = create_crewai_agent
    Shield.guard_crew = guard_crew


_install()

# Register this bundle as the auto-bind default for new ShieldBuilder instances.
from . import _bundle_registry as _registry  # noqa: E402
_registry.register(_BUNDLE)


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


def make_llm_caller(
    llm: Any,
    configuration_resolver: Optional[
        Callable[[Optional[str]], Optional[dict]]
    ] = None,
) -> Callable[[Optional[str], str], str]:
    """Create an LLM caller from a CrewAI-compatible LLM.

    Pass ``configuration_resolver=runtime.llm_configuration`` to honour
    the YAML's per-stage selection. Forwarded cfg fields depend on the
    LLM shape; see :class:`_LlmCallerFactory` for the per-shape matrix.
    For ``str`` and ``crewai.LLM`` shapes ``model`` / ``max_tokens`` /
    ``temperature`` / ``top_p`` / ``frequency_penalty`` /
    ``presence_penalty`` / ``stop`` / ``api_base`` are honored; for
    LangChain shapes ``max_tokens`` / ``temperature`` are bound
    best-effort; for the ``.call`` / bare-callable shapes the resolver
    is informational and only the diagnostic DEBUG log fires.
    """
    return _BUNDLE.llm_caller_factory.make_caller(
        llm, configuration_resolver=configuration_resolver,
    )


def protect_tools(
    runtime: Runtime,
    tools: list,
    user_input_getter: Optional[Callable[[], str]] = None,
) -> list:
    """Wrap CrewAI tools with Stages 2 + 3 + 4 enforcement."""
    return _protect_tools_via_wrapper(
        runtime, tools, _BUNDLE.tool_wrapper, user_input_getter,
    )


__all__ = [
    "GuardedAgent",
    "GuardedCrew",
    "make_llm_caller",
    "protect_tools",
]
