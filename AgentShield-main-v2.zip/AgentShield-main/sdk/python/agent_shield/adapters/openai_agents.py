"""OpenAI Agents SDK adapter.

This adapter is a small set of capability implementations
(:class:`_LlmCallerFactory`, :class:`_ToolWrapper`, :class:`_AgentBoundary`,
:class:`_StreamingAdapter`) that plug into the framework-agnostic
:class:`~agent_shield.adapters._shield.Shield` orchestrator. Stage
sequencing, ``begin_turn`` / ``end_turn``, redaction, ``record_tool_*``,
``on_block`` policy, and monitor mode all live in the orchestrator.

Three usage levels:

**Level 1 — functions** (full control)::

    runtime = (
        RuntimeBuilder.from_yaml("guardrails.yaml")
        .register_llm_caller(make_llm_caller(client))
        .build()
    )
    protected = protect_tools(runtime, tools)

**Level 2 — Shield helper** (recommended)::

    from agent_shield import Shield
    import agent_shield.adapters.openai_agents  # side-effect import

    shield = (
        Shield.from_yaml("guardrails.yaml")
        .with_openai_agents()
        .with_client(client)
        .build()
    )
    tools  = shield.protect_tools(tools)
    agent  = shield.guard(agent)

**Level 3 — two-liner** (most turnkey)::

    shield = (
        Shield.from_yaml("guardrails.yaml")
        .with_openai_agents()
        .with_client(client)
        .build()
    )
    agent  = shield.create_openai_agents_agent(tools, system_prompt="...")
"""
from __future__ import annotations

import json
import logging
from typing import Any, AsyncIterator, Callable, Optional

from agent_shield import Runtime

from ._capabilities import (
    AgentBoundary,
    CapabilityReport,
    ConfigurationMissingModelError,
    CoverageLevel,
    FrameworkBundle,
    GuardedInvoke,
    LlmCallerFactory,
    StreamingAdapter,
    StreamingValidator,
    ToolMetadata,
    ToolWrapper,
)
from ._shield import (
    GuardedRunner,
    Shield,
    ShieldBuilder,
    _protect_tools_via_wrapper,
)
from ._orchestration import check_stage1

logger = logging.getLogger("agent_shield.openai_agents")


# ---------------------------------------------------------------------------
# Capability 1 — LLM caller factory
# ---------------------------------------------------------------------------


class _LlmCallerFactory(LlmCallerFactory):
    """Adapt an OpenAI client (sync or async) to the runtime caller shape.

    The Rust validation engine invokes LLM callers synchronously, so an
    ``AsyncOpenAI`` client is paired with a sync clone of itself to
    avoid ``asyncio.run()`` inside a running loop.

    When the optional ``configuration_resolver`` is supplied, the
    produced caller looks up the YAML's ``configurations[]`` entry by
    ``configuration_id`` at call time and uses its ``model:`` /
    ``max_tokens:`` fields — so a ``.guardrails.yaml`` like
    ``configurations: [{id: stage3-judge, type: llm, model: gpt-4o}]``
    actually drives ``gpt-4o``.

    Model selection is **strict**: the resolved configuration MUST
    declare ``model:``. When ``model:`` is missing — or no matching
    entry exists — the caller raises
    :class:`ConfigurationMissingModelError` instead of silently
    falling back to a hard-coded SKU. The schema in
    ``spec/schema/guardrails.schema.json`` enforces this at load time,
    so a correctly-built guardrails file never reaches the error
    branch in normal operation.
    """

    def make_caller(
        self,
        client: Any,
        configuration_resolver: Optional[
            Callable[[Optional[str]], Optional[dict]]
        ] = None,
    ) -> Callable[[Optional[str], str], str]:
        sync_client = client
        if "Async" in type(client).__name__:
            import openai  # pragma: no cover — exercised in real demos

            init_kwargs: dict = {"api_key": client.api_key}
            if hasattr(client, "base_url") and client.base_url:
                init_kwargs["base_url"] = str(client.base_url)
            if hasattr(client, "organization") and client.organization:
                init_kwargs["organization"] = client.organization
            if "Azure" in type(client).__name__:
                sync_client = openai.AzureOpenAI(**init_kwargs)
            else:
                sync_client = openai.OpenAI(**init_kwargs)

        def caller(configuration_id: Optional[str], prompt: str) -> str:
            cfg: Optional[dict] = None
            if configuration_resolver is not None and configuration_id:
                try:
                    cfg = configuration_resolver(configuration_id)
                except Exception:
                    # Resolver lookup must never break the LLM caller with
                    # an internal error — surface the missing-model
                    # condition directly so SREs see a load-time-shaped
                    # message rather than a transport failure.
                    logger.exception(
                        "openai_agents llm caller: configuration_resolver "
                        "raised for configuration_id=%r",
                        configuration_id,
                    )
                    cfg = None

            # §6.2 — `model:` is the identifier passed verbatim to the
            # provider SDK. For direct OpenAI it's a model name; for
            # Azure OpenAI it's a deployment name (Azure's OpenAI SDK
            # takes the deployment in the `model=` kwarg). The runtime
            # treats it as opaque.
            if cfg is None or not cfg.get("model"):
                raise ConfigurationMissingModelError(configuration_id)
            model = cfg["model"]

            kwargs: dict = {
                "model": model,
                "messages": [{"role": "user", "content": prompt}],
            }
            if cfg.get("max_tokens") is not None:
                kwargs["max_tokens"] = cfg["max_tokens"]

            response = sync_client.chat.completions.create(**kwargs)
            return response.choices[0].message.content or ""

        return caller


# ---------------------------------------------------------------------------
# Capability 2 — Tool wrapper
# ---------------------------------------------------------------------------


class _ToolWrapper(ToolWrapper):
    """Translate between OpenAI ``FunctionTool`` and the orchestrator shape.

    The OpenAI Agents SDK invokes tools as
    ``on_invoke_tool(ctx, input_json: str) -> str``. The wrapper
    converts that envelope to/from the orchestrator's
    ``(params: dict, user_input: str) -> str`` shape, and re-serialises
    the (possibly Stage-3-mutated) effective params before calling the
    original tool — so redacted/replaced params reach the framework.
    """

    def extract(self, tool: Any) -> ToolMetadata:
        return ToolMetadata(
            name=tool.name,
            description=getattr(tool, "description", tool.name),
            params_schema=getattr(tool, "params_json_schema", {}),
        )

    async def invoke(self, original: Any, params: dict) -> Any:
        # OpenAI's FunctionTool wants a JSON envelope; re-serialise so
        # Stage-3-mutated params reach the framework.
        effective_json = json.dumps(params) if params else "{}"
        return await original.on_invoke_tool(None, effective_json)

    def wrap(
        self,
        original: Any,
        metadata: ToolMetadata,
        guarded_invoke: GuardedInvoke,
    ) -> Any:
        from agents import FunctionTool

        async def _on_invoke(ctx: Any, input_json: str) -> str:
            try:
                params = json.loads(input_json) if input_json else {}
            except json.JSONDecodeError:
                params = {}
            return await guarded_invoke(params, "")

        return FunctionTool(
            name=metadata.name,
            description=metadata.description,
            params_json_schema=metadata.params_schema,
            on_invoke_tool=_on_invoke,
        )


# ---------------------------------------------------------------------------
# Capability 3 — Agent boundary (Stages 1 + 5 around Runner.run)
# ---------------------------------------------------------------------------


class _AgentBoundary(AgentBoundary):
    """Run an OpenAI Agent and reshape its result for redaction / blocking."""

    async def run(
        self, agent: Any, input_text: str, **kwargs: Any,
    ) -> Any:
        from agents import Runner

        return await Runner.run(agent, input_text, **kwargs)

    def extract_output(self, result: Any) -> Optional[str]:
        return getattr(result, "final_output", None)

    def apply_redaction(self, result: Any, redacted_text: str) -> Any:
        result.final_output = redacted_text
        return result

    def make_blocked(self, message: str) -> Any:
        return _BlockedResult(message)


class _BlockedResult:
    """Minimal stand-in for an OpenAI ``RunResult`` in the blocked path."""

    def __init__(self, message: str) -> None:
        self.final_output = message
        self._final_output_override = None

    def __repr__(self) -> str:
        return f"BlockedResult({self.final_output!r})"


# ---------------------------------------------------------------------------
# Capability 4 — Streaming adapter
# ---------------------------------------------------------------------------


class _StreamingAdapter(StreamingAdapter):
    """Drive an OpenAI Agents streaming run with Stage-5 enforcement.

    OpenAI's framework yields plain text deltas, so this adapter yields
    safe payloads per chunk. Stage-1 (input check) and the
    streaming-session pipeline are owned by the orchestrator; this loop
    only does extraction + validator dispatch.
    """

    async def stream(
        self,
        agent: Any,
        input_text: str,
        validator: StreamingValidator,
        **kwargs: Any,
    ) -> AsyncIterator[Any]:
        from agents import Runner

        streamed = Runner.run_streamed(agent, input_text, **kwargs)
        async for event in streamed.stream_events():
            text = _extract_event_text(event)
            if not text:
                continue
            result = validator.push(text)
            if result.payload:
                yield result.payload
            if result.stopped:
                yield validator.make_blocked(
                    result.reason or "Stage 5 streaming guard stopped.",
                )
                return
        tail = validator.finish()
        if tail.stopped:
            yield validator.make_blocked(
                tail.reason or "Stage 5 streaming guard stopped.",
            )
            return
        if tail.payload:
            yield tail.payload


def _extract_event_text(event: Any) -> str:
    """Best-effort extraction of streamed text from an OpenAI Agents event."""
    text = getattr(event, "delta", None)
    if isinstance(text, str):
        return text
    data = getattr(event, "data", None)
    if isinstance(data, str):
        return data
    if hasattr(event, "text"):
        v = event.text
        if isinstance(v, str):
            return v
    return ""


# ---------------------------------------------------------------------------
# Bundle
# ---------------------------------------------------------------------------


class GuardedAgent(GuardedRunner):
    """OpenAI-named wrapper around :class:`GuardedRunner`.

    Preserves the historic ``GuardedAgent(runtime, agent)`` constructor
    by auto-supplying the OpenAI bundle's boundary + streaming adapter
    when callers instantiate it directly instead of going through
    ``Shield.guard(...)``.
    """

    def __init__(
        self,
        runtime: Runtime,
        agent: Any,
        boundary: "AgentBoundary | None" = None,
        streaming: Optional[StreamingAdapter] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            runtime,
            agent,
            boundary if boundary is not None else _BUNDLE.agent_boundary,
            streaming if streaming is not None else _BUNDLE.streaming_adapter,
            **kwargs,
        )


_BUNDLE = FrameworkBundle(
    name="openai_agents",
    llm_caller_factory=_LlmCallerFactory(),
    tool_wrapper=_ToolWrapper(),
    agent_boundary=_AgentBoundary(),
    streaming_adapter=_StreamingAdapter(),
    capabilities=CapabilityReport(
        framework="openai_agents",
        # Streaming chunk-level Stage 5 covers OpenAI text deltas
        # only; tool_call argument deltas are validated post-completion
        # (Stage 2/3/4 fire on the assembled call). Marked partial.
        streaming_output=CoverageLevel.PARTIAL,
    ),
    guarded_runner_cls=GuardedAgent,
)


# ---------------------------------------------------------------------------
# Composition pattern — install with_openai_agents() and
# create_openai_agents_agent() at import time.
# ---------------------------------------------------------------------------


def _install() -> None:
    """Monkey-install :meth:`ShieldBuilder.with_openai_agents`,
    :meth:`Shield.create_openai_agents_agent`,
    :meth:`Shield.as_input_guardrail`, and
    :meth:`Shield.as_output_guardrail`."""

    def with_openai_agents(self: ShieldBuilder) -> ShieldBuilder:
        """Bind this builder to the OpenAI Agents framework bundle."""
        return self._bind_to_bundle(_BUNDLE)

    def create_openai_agents_agent(
        self: Shield,
        tools: list,
        *,
        model: str,
        system_prompt: str = "",
        name: str = "assistant",
        **agent_kwargs: Any,
    ) -> Any:
        """Build a fully guarded OpenAI Agent in one call (Pattern A).

        ``model`` is the *customer agent's* model — the LLM that drives
        the agent's own reasoning loop. It is **required**: a security
        library MUST NOT pick a model on the customer's behalf. It is
        **not** the model used by the AgentShield validation stages
        (those are driven by the ``configurations[]`` block in
        ``.guardrails.yaml`` and resolved per-stage via the runtime).
        """
        from agents import Agent

        protected = self.protect_tools(tools)
        agent = Agent(
            name=name,
            instructions=system_prompt,
            tools=protected,
            model=model,
            **agent_kwargs,
        )
        return self.guard(agent)

    def as_input_guardrail(self: Shield) -> Any:
        """Return an OpenAI Agents SDK ``@input_guardrail``-decorated
        function that runs Stage 1 (input validation) against the
        user's input. The returned object can be passed directly to
        ``Agent(input_guardrails=[...])``::

            from agents import Agent, Runner
            from agent_shield import Shield
            import agent_shield.adapters.openai_agents

            shield = (
                Shield.from_yaml("guardrails.yaml")
                .with_openai_agents()
                .with_client(client)
                .build()
            )
            agent = Agent(
                name="assistant",
                instructions="...",
                tools=[...],
                input_guardrails=[shield.as_input_guardrail()],
                output_guardrails=[shield.as_output_guardrail()],
            )
            # OAI Runner enforces Stage 1 / Stage 5 natively; tripped
            # guardrails raise InputGuardrailTripwireTriggered /
            # OutputGuardrailTripwireTriggered which the host catches.
            result = await Runner.run(agent, "user input")

        This is the most idiomatic OAI Agents SDK integration — it
        doesn't require ``shield.guard(agent)`` wrapping. Use it when
        you want AgentShield to participate in OAI's native guardrail
        contract; use :meth:`guard` when you also want bundle-driven
        tool wrapping (Stages 2/3/4).

        Coverage: Full for Stage 1 (the OAI Runner enforces tripwires
        as gates).
        """
        try:
            from agents import GuardrailFunctionOutput, input_guardrail
        except ImportError as e:
            raise RuntimeError(
                "openai-agents package is not installed. "
                "Install with `pip install openai-agents`."
            ) from e

        runtime = self.runtime

        async def _shield_input_guardrail(_ctx: Any, _agent: Any, user_input: Any) -> Any:
            text = user_input if isinstance(user_input, str) else str(user_input or "")
            with runtime.new_session() as session:
                session.begin_turn()
                blocked_message = check_stage1(session, text)
            return GuardrailFunctionOutput(
                output_info={
                    "guardrail": "agent_shield",
                    "stage": "input",
                    "reason": blocked_message,
                },
                tripwire_triggered=blocked_message is not None,
            )

        return input_guardrail(_shield_input_guardrail)

    def as_output_guardrail(self: Shield) -> Any:
        """Return an OpenAI Agents SDK ``@output_guardrail``-decorated
        function that runs Stage 5 (output validation + redaction)
        against the agent's final output. See :meth:`as_input_guardrail`
        for usage.

        Coverage: Full for Stage 5 trip detection. Note: redactions
        from Stage 5 cannot be applied to the OAI agent's output stream
        because the SDK's guardrail contract only signals tripwire
        (block) — it has no mechanism to mutate the output. Use
        :meth:`guard` (Pattern A) if you need redaction propagation.
        """
        try:
            from agents import GuardrailFunctionOutput, output_guardrail
        except ImportError as e:
            raise RuntimeError(
                "openai-agents package is not installed. "
                "Install with `pip install openai-agents`."
            ) from e

        runtime = self.runtime

        async def _shield_output_guardrail(_ctx: Any, _agent: Any, output: Any) -> Any:
            text = output if isinstance(output, str) else str(output or "")
            tripped = False
            reason: Optional[str] = None
            with runtime.new_session() as session:
                session.begin_turn()
                outcome = session.validate_output(text)
                if not outcome.verdict.allowed and outcome.verdict.action == "block":
                    tripped = True
                    reason = outcome.verdict.reason or "blocked by output_validation"
            return GuardrailFunctionOutput(
                output_info={
                    "guardrail": "agent_shield",
                    "stage": "output",
                    "reason": reason,
                },
                tripwire_triggered=tripped,
            )

        return output_guardrail(_shield_output_guardrail)

    ShieldBuilder.with_openai_agents = with_openai_agents
    Shield.create_openai_agents_agent = create_openai_agents_agent
    Shield.as_input_guardrail = as_input_guardrail
    Shield.as_output_guardrail = as_output_guardrail


_install()

# Register this bundle as the auto-bind default for new ShieldBuilder instances.
from . import _bundle_registry as _registry  # noqa: E402
_registry.register(_BUNDLE)


# ---------------------------------------------------------------------------
# Module-level helpers (Level 1 API)
# ---------------------------------------------------------------------------


def make_llm_caller(
    client: Any,
    configuration_resolver: Optional[
        Callable[[Optional[str]], Optional[dict]]
    ] = None,
) -> Callable[[Optional[str], str], str]:
    """Create an LLM caller from an OpenAI client.

    Module-level shortcut for :meth:`_LlmCallerFactory.make_caller`.
    Pass ``configuration_resolver=runtime.llm_configuration`` to honour
    the YAML's per-stage ``model:`` selection. When the resolver
    returns a configuration without ``model:`` (or no matching entry
    at all), the caller raises
    :class:`ConfigurationMissingModelError` rather than silently
    picking a model on the customer's behalf.
    """
    return _BUNDLE.llm_caller_factory.make_caller(
        client, configuration_resolver=configuration_resolver,
    )


def protect_tools(
    runtime: Runtime,
    tools: list,
    user_input_getter: Optional[Callable[[], str]] = None,
) -> list:
    """Wrap OpenAI Agents tools with Stages 2 + 3 + 4 enforcement.

    Module-level shortcut for callers that want to use the runtime
    builder directly without going through :class:`Shield`.
    """
    return _protect_tools_via_wrapper(
        runtime, tools, _BUNDLE.tool_wrapper, user_input_getter,
    )


__all__ = [
    "GuardedAgent",
    "make_llm_caller",
    "protect_tools",
]
