"""AutoGen integration for Agent Shield guardrails.

Capability-based adapter that plugs into the framework-agnostic
:class:`~agent_shield.adapters._shield.Shield` orchestrator.

**Level 2 — Shield helper** (recommended)::

    from agent_shield import Shield
    import agent_shield.adapters.autogen  # side-effect import

    shield = (
        Shield.from_yaml("guardrails.yaml")
        .with_autogen()
        .with_client(model_client)
        .build()
    )
    tools  = shield.protect_tools(tools)
    agent  = shield.guard(agent)

**Level 3 — two-liner**::

    shield = (
        Shield.from_yaml("guardrails.yaml")
        .with_autogen()
        .with_client(model_client)
        .build()
    )
    agent = shield.create_autogen_agent(model_client, tools, system_message="...")
"""
from __future__ import annotations

import asyncio
import atexit
import concurrent.futures
import logging
from typing import Any, AsyncIterator, Callable, Optional

from agent_shield import Runtime

from ._capabilities import (
    AgentBoundary,
    CapabilityReport,
    CoverageLevel,
    FrameworkBundle,
    GuardedInvoke,
    LlmCallerFactory,
    StreamingAdapter,
    StreamingValidator,
    ToolMetadata,
    ToolWrapper,
)
from ._shield import (
    GuardedRunner,
    Shield,
    ShieldBuilder,
    _protect_tools_via_wrapper,
)

logger = logging.getLogger("agent_shield.autogen")

# Shared thread pool for running async AutoGen callers synchronously.
_AUTOGEN_EXECUTOR = concurrent.futures.ThreadPoolExecutor(max_workers=1)
atexit.register(_AUTOGEN_EXECUTOR.shutdown, wait=False)


# ---------------------------------------------------------------------------
# Capability 1 — LLM caller factory
# ---------------------------------------------------------------------------


class _LlmCallerFactory(LlmCallerFactory):
    """Adapt an AutoGen ``ChatCompletionClient`` to the runtime caller shape.

    Unlike the OpenAI / Anthropic adapters, the model name is **not**
    set per-call here — the AutoGen ``ChatCompletionClient`` is
    constructed by the customer with the model bound at construction
    time (e.g. ``OpenAIChatCompletionClient(model="gpt-4o")``), and
    ``ChatCompletionClient.create(...)`` has no model override.
    ``configuration_resolver`` is therefore used best-effort:
    ``max_tokens`` / ``temperature`` from the YAML
    ``configurations[]`` entry are forwarded via
    ``extra_create_args``. ``DEFAULT_FALLBACK_MODEL`` is a
    documentation marker only.
    """

    #: Documentation marker for the AutoGen customer-supplied client's
    #: expected default. The adapter does NOT enforce this — it
    #: surfaces only in the fallback DEBUG log so customers can
    #: correlate stage routing with their own model choice.
    DEFAULT_FALLBACK_MODEL = "customer-bound ChatCompletionClient"

    def make_caller(
        self,
        model_client: Any,
        *,
        configuration_resolver: Optional[
            Callable[[Optional[str]], Optional[dict]]
        ] = None,
    ) -> Callable[[Optional[str], str], str]:
        from autogen_core.models import UserMessage

        fallback_model = self.DEFAULT_FALLBACK_MODEL

        def caller(configuration_id: Optional[str], prompt: str) -> str:
            cfg: Optional[dict] = None
            if configuration_resolver is not None and configuration_id:
                try:
                    cfg = configuration_resolver(configuration_id)
                except Exception:
                    # Resolver lookup must never break the LLM caller —
                    # fall through to the documented fallback path.
                    logger.exception(
                        "autogen llm caller: configuration_resolver "
                        "raised for configuration_id=%r; falling back to "
                        "the customer's pre-bound ChatCompletionClient "
                        "(%r).",
                        configuration_id,
                        fallback_model,
                    )
                    cfg = None

            extra_create_args: dict = {}
            if cfg is not None:
                if cfg.get("max_tokens") is not None:
                    extra_create_args["max_tokens"] = cfg["max_tokens"]
                if cfg.get("temperature") is not None:
                    extra_create_args["temperature"] = cfg["temperature"]
                # cfg["model"] intentionally NOT applied — see class
                # docstring; AutoGen binds the model at client
                # construction.
            else:
                logger.debug(
                    "autogen llm caller: no `configurations[]` entry "
                    "matched configuration_id=%r; invoking the customer's "
                    "pre-bound ChatCompletionClient without per-call "
                    "overrides. Declare `configurations: - {id: %s, "
                    "type: llm, max_tokens: ..., temperature: ...}` in "
                    "`.guardrails.yaml` to forward invocation params.",
                    configuration_id,
                    configuration_id or "<unset>",
                )

            messages = [UserMessage(content=prompt, source="agent_shield")]

            async def _create() -> Any:
                if extra_create_args:
                    return await model_client.create(
                        messages, extra_create_args=extra_create_args,
                    )
                return await model_client.create(messages)

            future = _AUTOGEN_EXECUTOR.submit(
                lambda: asyncio.run(_create())
            )
            result = future.result()
            return result.content

        return caller


# ---------------------------------------------------------------------------
# Capability 2 — Tool wrapper
# ---------------------------------------------------------------------------


class _ToolWrapper(ToolWrapper):
    """Wrap an AutoGen ``BaseTool`` with a guarded subclass.

    AutoGen tools take a typed ``args`` object (Pydantic-style); the
    wrapper rebuilds the typed object from Stage-3-mutated params via
    ``args.model_validate`` so redactions reach the framework.
    """

    def extract(self, tool: Any) -> ToolMetadata:
        return ToolMetadata(
            name=tool.name,
            description=tool.description,
            extras={
                "args_type": tool._args_type,
                "return_type": getattr(tool, "_return_type", str),
            },
        )

    async def invoke(self, original: Any, params: dict) -> Any:
        # AutoGen tools take a typed args object; rebuild it from
        # params and call run() with a cancellation token of None.
        args_type = original._args_type
        try:
            args = args_type.model_validate(params)
        except Exception:  # noqa: BLE001
            args = args_type(**params)
        output = await original.run(args, None)
        return original.return_value_as_string(output)

    def wrap(
        self,
        original: Any,
        metadata: ToolMetadata,
        guarded_invoke: GuardedInvoke,
    ) -> Any:
        from autogen_core.tools import BaseTool

        class _GuardedTool(BaseTool):
            def __init__(
                self,
                _original: Any = original,
                _metadata: ToolMetadata = metadata,
                _guarded: GuardedInvoke = guarded_invoke,
            ) -> None:
                super().__init__(
                    args_type=_original._args_type,
                    return_type=getattr(_original, "_return_type", str),
                    name=_metadata.name,
                    description=_metadata.description,
                )
                self._original = _original
                self._guarded = _guarded

            async def run(self, args: Any, cancellation_token: Any) -> Any:
                params = args.model_dump() if hasattr(args, "model_dump") else {}
                return await self._guarded(params, "")

        return _GuardedTool()


# ---------------------------------------------------------------------------
# Capability 3 — Agent boundary
# ---------------------------------------------------------------------------


class _AgentBoundary(AgentBoundary):
    """Run an AutoGen agent's ``on_messages`` and reshape its result."""

    async def run(
        self, agent: Any, input_text: str, **kwargs: Any,
    ) -> Any:
        messages = kwargs.pop("messages", None)
        cancellation_token = kwargs.pop("cancellation_token", None)
        if messages is None:
            from autogen_agentchat.messages import TextMessage

            messages = [TextMessage(content=input_text, source="user")]
        return await agent.on_messages(messages, cancellation_token, **kwargs)

    def extract_output(self, result: Any) -> Optional[str]:
        if hasattr(result, "chat_message") and hasattr(result.chat_message, "content"):
            return str(result.chat_message.content)
        return None

    def apply_redaction(self, result: Any, redacted_text: str) -> Any:
        from autogen_agentchat.messages import TextMessage
        from autogen_agentchat.base import Response

        return Response(
            chat_message=TextMessage(
                content=redacted_text,
                source=result.chat_message.source,
            ),
            inner_messages=getattr(result, "inner_messages", None),
        )

    def make_blocked(self, message: str) -> Any:
        from autogen_agentchat.messages import TextMessage
        from autogen_agentchat.base import Response

        return Response(
            chat_message=TextMessage(content=message, source="guarded_agent"),
        )


def _extract_user_input_from_messages(messages: Any) -> str:
    """Find the most recent user/human message text."""
    if not messages:
        return ""
    for msg in reversed(list(messages)):
        if hasattr(msg, "source") and hasattr(msg, "content"):
            src = str(getattr(msg, "source", ""))
            if src.lower() in ("user", "human", "user_proxy"):
                return str(msg.content)
        type_name = type(msg).__name__.lower()
        if "user" in type_name or "human" in type_name:
            content = getattr(msg, "content", "")
            return str(content)
    last = messages[-1] if isinstance(messages, list) else list(messages)[-1]
    return str(getattr(last, "content", ""))


# ---------------------------------------------------------------------------
# Capability 4 — Streaming adapter (AutoGen buffers, yields once)
# ---------------------------------------------------------------------------


class _StreamingAdapter(StreamingAdapter):
    """AutoGen streaming: buffer all safe chunks, emit a single Response."""

    async def stream(
        self,
        agent: Any,
        input_text: str,
        validator: StreamingValidator,
        **kwargs: Any,
    ) -> AsyncIterator[Any]:
        from autogen_agentchat.base import Response
        from autogen_agentchat.messages import TextMessage

        messages = kwargs.pop("messages", None)
        cancellation_token = kwargs.pop("cancellation_token", None)
        if messages is None:
            messages = [TextMessage(content=input_text, source="user")]

        safe_parts: list[str] = []
        last_response: Any = None
        async for chunk in agent.on_messages_stream(
            messages, cancellation_token, **kwargs,
        ):
            if not isinstance(chunk, Response):
                continue
            last_response = chunk
            text_value = chunk.chat_message.content if hasattr(
                chunk.chat_message, "content",
            ) else None
            text = str(text_value) if text_value else ""
            if not text:
                continue
            result = validator.push(text)
            if result.payload:
                safe_parts.append(result.payload)
            if result.stopped:
                yield validator.make_blocked(
                    result.reason or "Stage 5 streaming guard stopped the stream.",
                )
                return

        tail = validator.finish()
        if tail.stopped:
            yield validator.make_blocked(
                tail.reason or "Stage 5 streaming guard stopped the stream.",
            )
            return
        if tail.payload:
            safe_parts.append(tail.payload)

        final_text = "".join(safe_parts)
        if last_response is not None:
            yield validator.apply_redaction(last_response, final_text)
        else:
            yield validator.make_blocked(final_text)


# ---------------------------------------------------------------------------
# Bundle
# ---------------------------------------------------------------------------


class GuardedAgent(GuardedRunner):
    """AutoGen-named guarded runner — adds ``on_messages`` / ``on_messages_stream``."""

    @property
    def name(self) -> str:
        return getattr(self._agent, "name", "guarded_agent")

    @property
    def produced_message_types(self) -> Any:
        return getattr(self._agent, "produced_message_types", [])

    async def on_messages(
        self,
        messages: Any,
        cancellation_token: Any = None,
        **kwargs: Any,
    ) -> Any:
        user_input = _extract_user_input_from_messages(messages)
        return await self.run(
            user_input,
            messages=messages,
            cancellation_token=cancellation_token,
            **kwargs,
        )

    async def on_messages_stream(
        self,
        messages: Any,
        cancellation_token: Any = None,
        **kwargs: Any,
    ):
        user_input = _extract_user_input_from_messages(messages)
        async for emission in self.run_streamed(
            user_input,
            messages=messages,
            cancellation_token=cancellation_token,
            **kwargs,
        ):
            yield emission


_BUNDLE = FrameworkBundle(
    name="autogen",
    llm_caller_factory=_LlmCallerFactory(),
    tool_wrapper=_ToolWrapper(),
    agent_boundary=_AgentBoundary(),
    streaming_adapter=_StreamingAdapter(),
    capabilities=CapabilityReport(
        framework="autogen",
        # Stage 2-4 require the customer's tools to all flow through
        # `protect_tools(...)` — partial because the adapter cannot
        # enforce that on tools added via AutoGen's runtime APIs.
        state_validation=CoverageLevel.PARTIAL,
        tool_authorization=CoverageLevel.PARTIAL,
        tool_execution_validation=CoverageLevel.PARTIAL,
        tool_output_validation=CoverageLevel.PARTIAL,
        # AutoGen's `Response`-based stream emits one final response
        # per tool turn (not chunk-level), so streaming Stage 5 maps
        # to "validate the final response" rather than chunk-level
        # validation. Marked unsupported per the canonical claim.
        streaming_output=CoverageLevel.UNSUPPORTED,
    ),
    guarded_runner_cls=GuardedAgent,
)


# ---------------------------------------------------------------------------
# Composition pattern — install with_autogen() and create_autogen_agent().
# ---------------------------------------------------------------------------


def _install() -> None:
    """Monkey-install :meth:`ShieldBuilder.with_autogen` and
    :meth:`Shield.create_autogen_agent`."""

    def with_autogen(self: ShieldBuilder) -> ShieldBuilder:
        """Bind this builder to the AutoGen framework bundle."""
        return self._bind_to_bundle(_BUNDLE)

    def create_autogen_agent(
        self: Shield,
        model_client: Any,
        tools: list,
        *,
        system_message: str = "",
        name: str = "assistant",
        **agent_kwargs: Any,
    ) -> Any:
        """Build a fully guarded AutoGen agent in one call (Pattern A)."""
        from autogen_agentchat.agents import AssistantAgent

        protected = self.protect_tools(tools)
        agent = AssistantAgent(
            name=name,
            model_client=model_client,
            tools=protected,
            system_message=system_message,
            **agent_kwargs,
        )
        return self.guard(agent)

    ShieldBuilder.with_autogen = with_autogen
    Shield.create_autogen_agent = create_autogen_agent


_install()

# Register this bundle as the auto-bind default for new ShieldBuilder instances.
from . import _bundle_registry as _registry  # noqa: E402
_registry.register(_BUNDLE)


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


def make_llm_caller(
    model_client: Any,
    configuration_resolver: Optional[
        Callable[[Optional[str]], Optional[dict]]
    ] = None,
) -> Callable[[Optional[str], str], str]:
    """Create an LLM caller from an AutoGen ``ChatCompletionClient``.

    Pass ``configuration_resolver=runtime.llm_configuration`` to honour
    the YAML's per-stage ``max_tokens:`` / ``temperature:`` selection
    via ``extra_create_args``. Model selection is left to the
    customer's pre-bound ``ChatCompletionClient`` — see
    :class:`_LlmCallerFactory` for rationale.
    """
    return _BUNDLE.llm_caller_factory.make_caller(
        model_client, configuration_resolver=configuration_resolver,
    )


def protect_tools(
    runtime: Runtime,
    tools: list,
    user_input_getter: Optional[Callable[[], str]] = None,
) -> list:
    """Wrap AutoGen tools with Stages 2 + 3 + 4 enforcement."""
    return _protect_tools_via_wrapper(
        runtime, tools, _BUNDLE.tool_wrapper, user_input_getter,
    )


__all__ = [
    "GuardedAgent",
    "make_llm_caller",
    "protect_tools",
]
