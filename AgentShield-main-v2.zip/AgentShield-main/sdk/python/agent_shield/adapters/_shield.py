"""Framework-agnostic shield orchestrator.

:class:`Shield` is the single class that drives every guarded turn for
every framework. It is parameterised by a :class:`FrameworkBundle` and
delegates only the framework-specific shape translation to the bundle's
four capabilities.

What lives here (framework-neutral):

* Stage sequencing and ``begin_turn`` / ``end_turn`` invariants
* Session resolution and ``ContextVar`` propagation
* :func:`guarded_turn` / :func:`guarded_tool` orchestration
* ``record_tool_success`` / ``record_tool_failure`` bookkeeping
* On-block policy (``raise`` / ``return_verdict`` / ``monitor`` / callable)
* Mode (``enforce`` / ``monitor``)
* Capability report exposure

What does *not* live here:

* How to extract a tool's name/description/schema  (→ ToolWrapper)
* How to read the LLM client's chat completion response  (→ LlmCallerFactory)
* How to invoke the framework's agent and reshape its result
  (→ AgentBoundary)
* How streaming chunks are shaped  (→ StreamingAdapter)
"""
from __future__ import annotations

import logging
import uuid
from enum import Enum
from typing import Any, Awaitable, Callable, Dict, List, Optional, Union

from agent_shield import (
    PerfTelemetry,
    Runtime,
    RuntimeBuilder,
    Session,
)

from ._capabilities import (
    AgentBoundary,
    CapabilityReport,
    FrameworkBundle,
    StreamingAdapter,
    StreamingPushResult,
    ToolMetadata,
    ToolWrapper,
)
from ._orchestration import (
    _dispatch_stage,
    check_stage1,
    current_session,
    current_user_input,
    guarded_tool,
    guarded_turn,
)

logger = logging.getLogger("agent_shield.shield")


# ---------------------------------------------------------------------------
# Mode / on-block policy
# ---------------------------------------------------------------------------


class ShieldMode(str, Enum):
    """Whether the shield enforces blocks or only records them.

    * ``ENFORCE`` — blocked actions short-circuit the run and the
      framework receives a blocked result (or an exception, depending
      on the on-block policy).
    * ``MONITOR`` — every blocked action is logged through observability
      providers but the run proceeds as if the verdict was allowed.
      Used for safe rollout of new policies in production.
    """

    ENFORCE = "enforce"
    MONITOR = "monitor"


OnBlockPolicy = Union[str, Callable[[Any], Any]]
"""Customer-controlled handling of blocked verdicts.

* ``"return_blocked"`` (default) — return the framework's blocked
  result shape (``AgentBoundary.make_blocked``). Preserves the historic
  behaviour of every adapter.
* ``"return_verdict"`` — return the raw :class:`StageVerdict` so the
  caller can branch on it explicitly.
* ``"raise"`` — raise :class:`AgentShieldBlocked` so the caller can
  ``except`` on it.
* callable — invoked as ``policy(verdict_or_message)`` and its return
  value is forwarded to the framework. The orchestrator passes either
  a verdict object or, when only a formatted message is available, the
  message string.
"""


class AgentShieldBlocked(Exception):
    """Raised when ``on_block="raise"`` and a stage verdict denies an action."""

    def __init__(self, verdict: Any, message: str) -> None:
        super().__init__(message)
        self.verdict = verdict
        self.message = message


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _resolve_block(
    policy: OnBlockPolicy,
    *,
    framework_blocked: Any,
    verdict: Any,
    message: str,
) -> Any:
    """Apply the on-block policy and produce the value to return.

    ``framework_blocked`` is the value the AgentBoundary would have
    returned (``make_blocked(message)``); we use it for the default path
    so existing callers see no behavioural change.
    """
    if callable(policy):
        return policy(verdict if verdict is not None else message)
    if policy == "raise":
        raise AgentShieldBlocked(verdict, message)
    if policy == "return_verdict":
        return verdict
    # default
    return framework_blocked


# ---------------------------------------------------------------------------
# Generic guarded runner
# ---------------------------------------------------------------------------


class GuardedRunner:
    """Framework-agnostic wrapper around an agent run.

    Every per-framework ``GuardedAgent`` / ``GuardedRunner`` /
    ``GuardedCrew`` reduces to this class plus an
    :class:`AgentBoundary` from the bundle. Per-framework subclasses
    may add extras (e.g. CrewAI exposes ``kickoff`` in addition to
    ``run``) but the core ``run`` / ``run_streamed`` flow lives here.
    """

    def __init__(
        self,
        runtime: Runtime,
        agent: Any,
        boundary: AgentBoundary,
        streaming: Optional[StreamingAdapter] = None,
        *,
        mode: ShieldMode = ShieldMode.ENFORCE,
        on_block: OnBlockPolicy = "return_blocked",
        streaming_config: Optional[dict] = None,
    ) -> None:
        if boundary is None:
            raise TypeError(
                "GuardedRunner requires an AgentBoundary capability; "
                "this framework adapter does not support agent run wrapping."
            )
        self._runtime = runtime
        self._agent = agent
        self._boundary = boundary
        self._streaming = streaming
        # Shadow mode (#14) forces MONITOR.
        try:
            runtime_mode = runtime.mode
        except AttributeError:
            runtime_mode = "active"
        self._mode = ShieldMode.MONITOR if runtime_mode == "shadow" else mode
        self._on_block = on_block
        self._streaming_config = streaming_config
        self._session: Session = self._runtime.new_session()

    @property
    def agent(self) -> Any:
        """The underlying framework agent."""
        return self._agent

    def with_fresh_session(self) -> "GuardedRunner":
        """Return a NEW :class:`GuardedRunner` bound to a fresh session.

        The original runner — and any in-flight conversation it owns —
        is not mutated. Use this to start a new conversation cleanly
        without the destructive in-place reset footgun.

        Mirrors the Rust ``Shield::with_fresh_session``, .NET
        ``Shield.WithFreshSession``, and Node
        ``GuardedRunner.withFreshSession`` APIs.
        """
        return type(self)(
            self._runtime,
            self._agent,
            self._boundary,
            self._streaming,
            mode=self._mode,
            on_block=self._on_block,
            streaming_config=self._streaming_config,
        )

    async def run(
        self,
        input_text: str,
        *,
        session: Optional[Session] = None,
        **kwargs: Any,
    ) -> Any:
        """Run the agent with Stage 1 + Stage 5 enforcement."""
        sess = session or self._session
        boundary = self._boundary
        mode = self._mode
        on_block = self._on_block

        async def _execute(effective_input: str) -> Any:
            return await boundary.run(self._agent, effective_input, **kwargs)

        if mode is ShieldMode.MONITOR:
            return await _execute_with_monitor(
                sess, input_text, _execute, boundary,
            )

        def _make_blocked_with_policy(message: str) -> Any:
            framework_blocked = boundary.make_blocked(message)
            return _resolve_block(
                on_block,
                framework_blocked=framework_blocked,
                verdict=None,  # guarded_turn folds verdict→message internally
                message=message,
            )

        return await guarded_turn(
            sess,
            input_text,
            execute=_execute,
            extract_output=boundary.extract_output,
            apply_redaction=boundary.apply_redaction,
            make_blocked=_make_blocked_with_policy,
        )

    async def run_streamed(
        self,
        input_text: str,
        *,
        session: Optional[Session] = None,
        **kwargs: Any,
    ):
        """Run the agent with streaming Stage 5 enforcement.

        Emission scheduling honours the streaming guard's configured
        mode (:attr:`StreamingGuard.mode`). When the mode is
        ``on_complete`` the orchestrator pushes every text-bearing
        chunk through the engine for accumulation but emits NOTHING to
        the consumer until ``validator.finish()`` resolves — that final
        call yields a single terminal chunk carrying the
        validated/redacted text (or a block message if Stage 5 stopped
        the buffer). When the mode is ``per_chunk`` or ``windowed`` the
        framework adapter forwards validated chunks in real time.

        Metadata-only chunks (no text content) are always passed
        through promptly because they are not security-relevant.
        """
        if self._streaming is None:
            raise NotImplementedError(
                "streaming is unsupported for this framework "
                "(no StreamingAdapter in bundle)"
            )

        sess = session or self._session
        boundary = self._boundary
        streaming = self._streaming

        sess.begin_turn()
        try:
            # Shadow / Monitor (#14): run Stage 1 for observability but
            # never short-circuit; stream through a monitor validator
            # that pushes chunks to the real Stage-5 streaming guard
            # for audit events but always emits the original chunks.
            if self._mode is ShieldMode.MONITOR:
                sess.validate_input(input_text or "")
                sess_token = current_session.set(sess)
                input_token = current_user_input.set(input_text or "")
                try:
                    # Open the Stage-5 streaming guard; fall back to
                    # no-guard observability only if the runtime
                    # cannot create one. Stream / customer exceptions
                    # propagate normally — we do NOT swallow them.
                    try:
                        guard_cm = sess.streaming_session(stage=5)
                    except Exception:  # noqa: BLE001
                        logger.debug("monitor streaming_session raised", exc_info=True)
                        guard_cm = None
                    if guard_cm is not None:
                        with guard_cm as guard:
                            mon = _MonitorStreamingValidator(boundary, guard)
                            async for emission in streaming.stream(
                                self._agent, input_text, mon, **kwargs,
                            ):
                                yield emission
                            try:
                                mon.finish()
                            except Exception:  # noqa: BLE001
                                pass
                    else:
                        mon = _MonitorStreamingValidator(boundary, None)
                        async for emission in streaming.stream(
                            self._agent, input_text, mon, **kwargs,
                        ):
                            yield emission
                finally:
                    current_user_input.reset(input_token)
                    current_session.reset(sess_token)
                return

            block_msg = check_stage1(sess, input_text)
            if block_msg is not None:
                logger.warning("[Stage 1] Input blocked: %s", block_msg)
                yield boundary.make_blocked(block_msg)
                return

            sess_token = current_session.set(sess)
            input_token = current_user_input.set(input_text or "")
            try:
                with sess.streaming_session(stage=5) as guard:
                    validator = _OrchestratorStreamingValidator(
                        guard, boundary,
                    )
                    async for emission in streaming.stream(
                        self._agent, input_text, validator, **kwargs,
                    ):
                        yield emission
            finally:
                current_user_input.reset(input_token)
                current_session.reset(sess_token)
        finally:
            try:
                sess.end_turn()
            except Exception:  # noqa: BLE001
                logger.debug("end_turn() raised", exc_info=True)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._agent, name)

    def __repr__(self) -> str:
        return (
            f"GuardedRunner(runtime=..., agent={self._agent!r}, "
            f"mode={self._mode.value})"
        )


class _OrchestratorStreamingValidator:
    """Bridges :class:`Session.streaming_session` to the
    :class:`StreamingValidator` Protocol.

    Owned by the orchestrator and passed into
    :meth:`StreamingAdapter.stream`; collapses the
    ``streaming_session`` API plus the bundle's ``AgentBoundary`` into
    the four operations adapters need (``push`` / ``finish`` /
    ``make_blocked`` / ``apply_redaction``).
    """

    def __init__(self, guard: Any, boundary: AgentBoundary) -> None:
        self._guard = guard
        self._boundary = boundary

    @property
    def mode(self) -> str:
        return getattr(self._guard, "mode", "on_complete")

    def push(self, text: str) -> StreamingPushResult:
        result = self._guard.push(text)
        return StreamingPushResult(
            payload=result.payload,
            stopped=result.stopped,
            reason=getattr(result, "reason", None),
        )

    def finish(self) -> StreamingPushResult:
        tail = self._guard.finish()
        return StreamingPushResult(
            payload=tail.payload,
            stopped=tail.stopped,
            reason=getattr(tail, "reason", None),
        )

    def make_blocked(self, message: str) -> Any:
        return self._boundary.make_blocked(message)

    def apply_redaction(self, framework_chunk: Any, text: str) -> Any:
        return self._boundary.apply_redaction(framework_chunk, text)


class _MonitorStreamingValidator:
    """Monitor-mode streaming validator (#14).

    Pushes chunks through the real Stage-5 streaming guard for
    observability, logs a warning when the guard would have blocked
    or redacted, but always emits the ORIGINAL chunk text and never
    reports `stopped`. `finish()` is idempotent: the streaming adapter
    typically calls it at the end of `stream()`, and the orchestrator
    may call it again for tail drain; the second call is a no-op so
    we don't emit a false "stream already ended" warning.
    """

    def __init__(self, boundary: AgentBoundary, guard: Any) -> None:
        self._boundary = boundary
        self._guard = guard  # may be None when caller couldn't open one
        self._finished = False

    @property
    def mode(self) -> str:
        # Per-chunk so the adapter never buffers customer output.
        return "per_chunk"

    def push(self, text: str) -> StreamingPushResult:
        if self._guard is not None:
            try:
                self._guard.push(text)
            except Exception:  # noqa: BLE001 — observability best-effort
                logger.debug("monitor guard.push raised", exc_info=True)
        return StreamingPushResult(payload=text, stopped=False, reason=None)

    def finish(self) -> StreamingPushResult:
        if self._finished:
            return StreamingPushResult(payload=None, stopped=False, reason=None)
        self._finished = True
        if self._guard is not None:
            try:
                self._guard.finish()
            except Exception:  # noqa: BLE001
                logger.debug("monitor guard.finish raised", exc_info=True)
        return StreamingPushResult(payload=None, stopped=False, reason=None)

    def make_blocked(self, message: str) -> Any:
        return self._boundary.make_blocked(message)

    def apply_redaction(self, framework_chunk: Any, text: str) -> Any:
        return self._boundary.apply_redaction(framework_chunk, text)


async def _execute_with_monitor(
    session: Any,
    input_text: str,
    execute: Callable[[str], Any],
    boundary: AgentBoundary,
) -> Any:
    """Monitor-mode equivalent of guarded_turn — record but never block.

    Stage 1 and Stage 5 still run so observability captures them; the
    verdict.allowed value is ignored. Stage-3 redaction is also bypassed
    so monitor-mode never alters customer payloads.
    """
    session.begin_turn()
    try:
        session.validate_input(input_text or "")

        sess_token = current_session.set(session)
        input_token = current_user_input.set(input_text or "")
        try:
            result = await execute(input_text or "")
        finally:
            current_user_input.reset(input_token)
            current_session.reset(sess_token)

        output_text = boundary.extract_output(result)
        if output_text and isinstance(output_text, str):
            session.validate_output(output_text)

        return result
    finally:
        try:
            session.end_turn()
        except Exception:  # noqa: BLE001
            logger.debug("end_turn() raised", exc_info=True)


async def _execute_run_monitor(
    session: Any,
    user_input: str,
    execute: Callable[[], Awaitable[Any]],
) -> Any:
    """Monitor-mode equivalent of :meth:`Shield.run` (Pattern C, no bundle).

    Stage 1 and Stage 5 still run for observability; the core
    observability dispatcher emits structured audit events stamped
    with ``mode: shadow`` + ``enforced: false`` for any subscribed
    provider. The thunk's return value is forwarded verbatim (no
    Stage-5 redaction applied).
    """
    sess_token = current_session.set(session)
    try:
        session.begin_turn()
        try:
            if user_input:
                session.validate_input(user_input)
            raw = await execute()
            text = "" if raw is None else str(raw)
            if text:
                session.validate_output(text)
            return raw
        finally:
            try:
                session.end_turn()
            except Exception:  # noqa: BLE001
                logger.debug("end_turn() raised", exc_info=True)
    finally:
        current_session.reset(sess_token)


# ---------------------------------------------------------------------------
# Generic Shield orchestrator
# ---------------------------------------------------------------------------


class Shield:
    """Framework-agnostic shield orchestrator.

    Construct via the composition pattern::

        Shield.from_yaml(path).with_<framework>().build()

    Each adapter module installs its own ``with_<framework>`` method on
    :class:`ShieldBuilder` and a ``create_<framework>_agent`` factory on
    :class:`Shield` at import time.
    """

    def __init__(
        self,
        runtime: Runtime,
        *,
        bundle: Optional[FrameworkBundle] = None,
        client: Any = None,
        streaming_config: Optional[dict] = None,
        mode: ShieldMode = ShieldMode.ENFORCE,
        on_block: OnBlockPolicy = "return_blocked",
    ) -> None:
        # `bundle` is optional: the framework-agnostic methods
        # (`run`, `protect_tool`, `before_invoke`) work without one.
        # Methods that need a bundle (`guard`, `protect_tools`,
        # `capabilities`) raise a clear error at call time.
        self.runtime = runtime
        self._bundle = bundle
        self._client = client
        self._streaming_config = streaming_config
        # Shadow mode (#14) forces MONITOR regardless of `mode` arg.
        try:
            runtime_mode = runtime.mode
        except AttributeError:
            runtime_mode = "active"
        self._mode = ShieldMode.MONITOR if runtime_mode == "shadow" else mode
        self._on_block = on_block
        # weak to mirror the historic per-adapter behaviour
        import weakref
        self._guarded_runners: weakref.WeakSet = weakref.WeakSet()

    # ── Construction ───────────────────────────────────────────────

    @classmethod
    def from_yaml(cls, path: str, *, auto_bind: bool = True) -> "ShieldBuilder":
        """Start a builder for the given guardrails YAML.

        When exactly one adapter module is imported, the bundle is
        auto-bound and ``.with_<framework>()`` ceremony can be skipped.
        When multiple adapters are imported the auto-bind is ambiguous
        and the call raises
        :class:`~agent_shield.AmbientBundleAmbiguityError`. Pass
        ``auto_bind=False`` to bypass the ambient lookup and bind
        explicitly via ``.with_<framework>()``.
        """
        return ShieldBuilder(path=path, auto_bind=auto_bind)

    @classmethod
    def from_yaml_chain(
        cls, paths: List[str], *, auto_bind: bool = True,
    ) -> "ShieldBuilder":
        b = ShieldBuilder(path=paths[0] if paths else "", auto_bind=auto_bind)
        b._yaml_chain = list(paths)
        return b

    # ── Public surface ─────────────────────────────────────────────

    @property
    def capabilities(self) -> CapabilityReport:
        """The protection profile of this adapter."""
        if self._bundle is None:
            raise RuntimeError(
                "Shield has no capability bundle: call `.with_<framework>()` on "
                "the builder (e.g. `.with_langchain()`, `.with_openai_agents()`, "
                "`.with_anthropic()`) before `.build()` to expose framework "
                "capabilities, or use the framework-agnostic methods "
                "(`run`, `protect_tool`, `before_invoke`) which don't need one."
            )
        return self._bundle.capabilities

    @property
    def mode(self) -> ShieldMode:
        return self._mode

    def protect_tools(
        self,
        tools: list,
        user_input_getter: Optional[Callable[[], str]] = None,
    ) -> list:
        """Wrap framework tools with Stages 2 + 3 + 4 enforcement."""
        if self._bundle is None:
            raise RuntimeError(
                "Shield.protect_tools requires a framework bundle. Call "
                "`.with_<framework>()` on the builder before `.build()`, or "
                "use `Shield.protect_tool(name, params, fn)` which works "
                "without a bundle."
            )
        wrapper = self._bundle.tool_wrapper
        if wrapper is None:
            raise NotImplementedError(
                f"{self._bundle.name} does not support tool wrapping"
            )
        return _protect_tools_via_wrapper(
            self.runtime, tools, wrapper, user_input_getter,
            mode=self._mode,
        )

    def guard(self, agent: Any, **runner_kwargs: Any) -> GuardedRunner:
        """Wrap a framework agent with Stage 1 + Stage 5 enforcement.

        Returns the bundle's ``guarded_runner_cls`` (when set) so
        adapters can ship framework-flavoured runners (LangChain's
        ``ainvoke``/``astream``, AutoGen's ``on_messages``, etc.)
        without subclassing :class:`Shield`. Extra kwargs are forwarded
        to the runner constructor — adapters that need per-run defaults
        (Anthropic's ``tools``/``model``/``system``) accept them via
        ``**runner_kwargs``.
        """
        if self._bundle is None:
            raise RuntimeError(
                "Shield.guard requires a framework bundle. Call "
                "`.with_<framework>()` on the builder before `.build()`."
            )
        runner_cls = self._bundle.guarded_runner_cls or GuardedRunner
        runner = runner_cls(
            self.runtime,
            agent,
            self._bundle.agent_boundary,
            self._bundle.streaming_adapter,
            mode=self._mode,
            on_block=self._on_block,
            streaming_config=self._streaming_config,
            **runner_kwargs,
        )
        self._guarded_runners.add(runner)
        return runner

    async def before_invoke(
        self, user_input: str, *, session: Optional[Session] = None,
    ) -> Optional[str]:
        """Stage 1 only — for adapters whose ``before_invoke`` hook just
        wants a yes/no answer."""
        # Shadow / Monitor (#14): run Stage 1 for observability and
        # always return None (never block) so the caller proceeds.
        if self._mode is ShieldMode.MONITOR:
            sess = session if session is not None else self.runtime.new_session()
            if session is None:
                sess.begin_turn()
            try:
                sess.validate_input(user_input or "")
            finally:
                if session is None:
                    try:
                        sess.end_turn()
                    except Exception:  # noqa: BLE001
                        pass
            return None

        if session is None:
            with self.runtime.new_session() as s:
                s.begin_turn()
                return check_stage1(s, user_input)
        return check_stage1(session, user_input)

    async def run(
        self,
        execute: Callable[[], Awaitable[Any]],
        *,
        user_input: str = "",
        session: Optional[Session] = None,
    ) -> Any:
        """Stage 1 + Stage 5 around an opaque thunk. Mirrors the Node /
        Rust / .NET ``run`` (or ``RunAsync``) entry points.

        Use this when the customer's agent is a black-box callable and
        Pattern A's :meth:`guard` doesn't fit (no framework bundle, or
        the agent's shape doesn't match any installed bundle). The
        thunk runs once; its return value is rendered to a string for
        Stage 5 validation, and the (possibly redacted) result is
        returned to the caller.

        For Stage 2 / 3 / 4 protection of individual tool calls inside
        the thunk, use :meth:`protect_tool` (or ambient session via
        ``current_session``).
        """
        if not callable(execute):
            raise TypeError("Shield.run(execute): execute must be callable")
        sess = session if session is not None else self.runtime.new_session()

        # Shadow / Monitor (#14): record verdicts but never block.
        if self._mode is ShieldMode.MONITOR:
            return await _execute_run_monitor(sess, user_input, execute)

        async def _stage5_pass(raw: Any) -> Any:
            text = "" if raw is None else str(raw)
            if not text:
                return raw
            outcome = sess.validate_output(text)
            decision = _dispatch_stage(outcome.verdict)
            action = decision["action"]
            if action["kind"] == "return_blocked":
                return action["message"]
            if action["kind"] == "proceed_with_mutation":
                return outcome.response if outcome.response is not None else text
            return raw

        token = current_session.set(sess)
        try:
            sess.begin_turn()
            try:
                effective_input = user_input or ""
                if user_input:
                    verdict = sess.validate_input(user_input)
                    decision = _dispatch_stage(
                        verdict,
                        "return_blocked",
                        self._mode.value,
                    )
                    action = decision["action"]
                    if (
                        action["kind"] == "return_blocked"
                        and not decision.get("override_to_proceed", False)
                    ):
                        return action["message"]
                    if action["kind"] == "proceed_with_mutation":
                        effective_input = str(
                            action.get("value") or effective_input,
                        )
                input_token = current_user_input.set(effective_input)
                try:
                    raw = await execute()
                finally:
                    current_user_input.reset(input_token)
                return await _stage5_pass(raw)
            finally:
                try:
                    sess.end_turn()
                except Exception:  # noqa: BLE001
                    pass
        finally:
            current_session.reset(token)

    async def protect_tool(
        self,
        name: str,
        params: Optional[dict],
        execute: Callable[..., Awaitable[Any]],
        *,
        session: Optional[Session] = None,
        tool_call_id: Optional[str] = None,
    ) -> tuple[bool, str]:
        """Stages 2 + 3 + 4 around a single tool call. Mirrors the Node
        / Rust / .NET ``protect_tool`` (or ``ProtectToolAsync``) entry
        points.

        Returns ``(blocked, output)`` — ``blocked`` is True when the
        tool was denied or its result blocked, in which case ``output``
        is the canonical block message; otherwise ``output`` is the
        (possibly redacted) tool result rendered as a string.

        When called from inside a guarded turn (e.g. ambient
        :data:`current_session` is set), the outer turn is reused;
        otherwise a fresh session is allocated for this call.

        Pass *tool_call_id* (the upstream model's tool-call handle, e.g.
        OpenAI ``tool_call.id`` or Anthropic ``tool_use.id``) so §16.0
        Stage 4 binding can find the same canonical invocation
        admitted at Stage 3 under concurrent same-name calls. When
        omitted, a stable per-call id is minted automatically so this
        path never collides with another same-name call.
        """
        if not callable(execute):
            raise TypeError(
                "Shield.protect_tool(name, params, execute): execute must be callable",
            )
        ambient = current_session.get(None)
        own_turn = False
        sess = session
        if sess is None:
            sess = ambient if ambient is not None else self.runtime.new_session()
        if ambient is None:
            sess.begin_turn()
            own_turn = True
        token = current_session.set(sess) if ambient is None else None
        # §16.0 — always pass a tool_call_id so parallel same-name
        # calls bind correctly; honor the customer's id if supplied.
        bound_id = tool_call_id if tool_call_id is not None else uuid.uuid4().hex
        try:
            # Shadow / Monitor (#14): execute the tool unconditionally
            # but still run Stage 3 / Stage 4 for observability AND
            # record success / failure so populator extractors and
            # `tool.<name>.success` / `failure` events fire identically
            # to active.
            if self._mode is ShieldMode.MONITOR:
                eff_params = dict(params or {})
                sess.validate_tool_call(name, eff_params, tool_call_id=bound_id)
                try:
                    raw = await execute(params or {})
                except Exception as exc:  # noqa: BLE001
                    err_text = f"[tool error] {name}: {exc}"
                    sess.validate_tool_output(name, err_text, tool_call_id=bound_id)
                    try:
                        sess.record_tool_failure(name, str(exc))
                    except Exception:  # noqa: BLE001
                        logger.debug("monitor record_tool_failure raised", exc_info=True)
                    return (False, err_text)
                rendered = raw if isinstance(raw, str) else str(raw)
                sess.validate_tool_output(name, raw, tool_call_id=bound_id)
                try:
                    sess.record_tool_success(name, raw)
                except Exception:  # noqa: BLE001
                    logger.debug("monitor record_tool_success raised", exc_info=True)
                return (False, rendered)
            return await guarded_tool(
                name,
                params or {},
                execute,
                session=sess,
                tool_call_id=bound_id,
            )
        finally:
            if own_turn:
                try:
                    sess.end_turn()
                except Exception:  # noqa: BLE001
                    pass
            if token is not None:
                current_session.reset(token)

    def with_fresh_session(self) -> "Shield":
        """Return a NEW :class:`Shield` with the same runtime + bundle
        but no carried-over runner state.

        The new Shield shares the underlying :class:`Runtime` reference
        (so policies, observability providers, and human resolvers are
        still wired up) but starts with an empty
        :attr:`_guarded_runners` set. The original Shield — and the
        runners spawned from it — is not mutated.

        This is the canonical post-build-immutable way to "start a new
        conversation context" for an existing Shield without
        rebuilding the policy graph. Mirrors the Rust
        ``Shield::with_fresh_session``, the .NET
        ``Shield.WithFreshSession``, and the Node
        ``shield.withFreshSession`` APIs.
        """
        return Shield(
            self.runtime,
            bundle=self._bundle,
            client=self._client,
            streaming_config=self._streaming_config,
            mode=self._mode,
            on_block=self._on_block,
        )


# ---------------------------------------------------------------------------
# Tool wrapping (delegates to ToolWrapper for shape translation only)
# ---------------------------------------------------------------------------


def _protect_tools_via_wrapper(
    runtime: Runtime,
    tools: list,
    wrapper: ToolWrapper,
    user_input_getter: Optional[Callable[[], str]] = None,
    *,
    mode: ShieldMode = ShieldMode.ENFORCE,
) -> list:
    """Build a list of guarded tools using ``wrapper`` for shape ops.

    The orchestrator owns Stage 2/3/4 + record_tool_*; the wrapper
    translates between the framework's tool object and the
    ``(params: dict, user_input: str) -> output_text`` shape, and owns
    invocation of the original framework tool via :meth:`ToolWrapper.invoke`.
    """
    out: list = []
    for tool in tools:
        meta = wrapper.extract(tool)

        async def _invoke(
            params: dict,
            user_input: str,
            _orig: Any = tool,
            _meta: ToolMetadata = meta,
            _wrapper: ToolWrapper = wrapper,
            _runtime: Runtime = runtime,
            _input_getter: Optional[Callable[[], str]] = user_input_getter,
            _mode: ShieldMode = mode,
        ) -> str:
            async def _execute(effective_params: dict) -> Any:
                return await _wrapper.invoke(_orig, effective_params)

            text_input = (
                _input_getter() if _input_getter else user_input
            )
            if _mode is ShieldMode.MONITOR:
                # Shadow / Monitor (#14): run Stage 3 / Stage 4 for
                # observability, never block, never mutate `params`.
                # Mirror active's session-resolution: pick up ambient,
                # else open a fresh session + own a turn around it so
                # the validation has a session to log against.
                ambient = current_session.get(None)
                own_turn = False
                if ambient is not None:
                    sess = ambient
                    sess_token = None
                else:
                    sess = _runtime.new_session()
                    sess.begin_turn()
                    own_turn = True
                    sess_token = current_session.set(sess)
                try:
                    eff_params = dict(params or {})
                    # §16.0: mint a per-call id so concurrent same-name
                    # MONITOR calls bind correctly through Stage 3 →
                    # Stage 4 instead of poisoning the no-id slot.
                    _mon_call_id = uuid.uuid4().hex
                    sess.validate_tool_call(_meta.name, eff_params, tool_call_id=_mon_call_id)
                    try:
                        raw = await _execute(params)
                    except Exception as exc:  # noqa: BLE001
                        err_text = f"[tool error] {_meta.name}: {exc}"
                        sess.validate_tool_output(_meta.name, err_text, tool_call_id=_mon_call_id)
                        try:
                            sess.record_tool_failure(_meta.name, str(exc))
                        except Exception:  # noqa: BLE001
                            logger.debug(
                                "monitor record_tool_failure raised",
                                exc_info=True,
                            )
                        return err_text
                    sess.validate_tool_output(_meta.name, raw, tool_call_id=_mon_call_id)
                    try:
                        sess.record_tool_success(_meta.name, raw)
                    except Exception:  # noqa: BLE001
                        logger.debug(
                            "monitor record_tool_success raised",
                            exc_info=True,
                        )
                    return str(raw) if not isinstance(raw, str) else raw
                finally:
                    if own_turn:
                        try:
                            sess.end_turn()
                        except Exception:  # noqa: BLE001
                            pass
                        if sess_token is not None:
                            current_session.reset(sess_token)

            # §16.0 binding: Python framework adapters don't see the
            # upstream model's tool_call.id at the framework-owned tool
            # boundary (the framework calls the wrapper as `tool.run`
            # with no id). Mint a stable per-call UUIDv4 so concurrent
            # same-name calls each carry a unique binding handle and
            # cannot poison each other's Stage 3/Stage 4 binding slot.
            _call_id = uuid.uuid4().hex
            _blocked, output = await guarded_tool(
                _meta.name,
                params,
                execute=_execute,
                user_input=text_input,
                runtime=_runtime,
                tool_call_id=_call_id,
            )
            return output

        guarded = wrapper.wrap(tool, meta, _invoke)
        out.append(guarded)

    logger.info(
        "Protected %d tools: %s",
        len(out), [getattr(t, "name", "?") for t in out],
    )
    return out


# ---------------------------------------------------------------------------
# Generic builder
# ---------------------------------------------------------------------------


class _ConfigurationResolverHolder:
    """Mutable indirection between an LLM-caller closure and the runtime.

    Adapter LLM-caller factories build their caller closure in
    :meth:`ShieldBuilder._bind_caller`, which fires the moment a client
    is wired — typically *before* :meth:`ShieldBuilder.build` produces
    the runtime. The closure therefore can't capture
    ``Runtime.llm_configuration`` directly. This holder is registered
    with the factory at make-caller time and populated in
    :meth:`ShieldBuilder.build` once the runtime exists, so calls to
    ``configuration_resolver(configuration_id)`` start returning the
    real ``configurations[]`` entry as soon as the first stage runs.
    """

    def __init__(self) -> None:
        self._lookup: Optional[Callable[[str], Optional[Dict[str, Any]]]] = None

    def bind(self, runtime: Runtime) -> None:
        self._lookup = runtime.llm_configuration

    def __call__(
        self, configuration_id: Optional[str],
    ) -> Optional[Dict[str, Any]]:
        if self._lookup is None or not configuration_id:
            return None
        try:
            return self._lookup(configuration_id)
        except Exception:
            logger.exception(
                "configuration resolver: lookup failed for configuration_id=%r",
                configuration_id,
            )
            return None


class ShieldBuilder:
    """Framework-agnostic builder for :class:`Shield`.

    Construct via ``Shield.from_yaml(path)``. When exactly one adapter
    module is imported (e.g. ``import agent_shield.adapters.langchain``)
    the bundle is auto-bound and the three-line drop-in works without
    any explicit ``.with_<framework>()`` call. When two or more
    adapters are imported, auto-bind is ambiguous and the constructor
    raises :class:`~agent_shield.AmbientBundleAmbiguityError` — fail-fast
    on the spot rather than silently depending on import order.

    Recover from ambiguity by passing ``auto_bind=False`` (skips the
    ambient lookup) and then calling ``.with_<framework>()`` explicitly
    to pin a specific bundle. Clients passed via ``with_client()``
    before the bundle is set are buffered and (re)bound when the bundle
    becomes available.
    """

    def __init__(
        self,
        path: str = "",
        *,
        auto_bind: bool = True,
    ) -> None:
        # When `auto_bind` is True (the default) we look up the
        # ambient bundle so the three-line drop-in works. When two or
        # more adapters are imported, `active_bundle()` raises
        # `AmbientBundleAmbiguityError` and we let it propagate
        # immediately — silently picking one would silently depend on
        # import order and break fail-closed defaults.
        if auto_bind:
            from . import _bundle_registry

            self._bundle: Optional[FrameworkBundle] = (
                _bundle_registry.active_bundle()
            )
        else:
            self._bundle = None
        self._path = path
        self._yaml_chain: Optional[List[str]] = None
        self._client: Any = None
        # Single LLM caller built from `with_client(client)` + the framework
        # bundle's `make_caller`. Per-stage dispatch is YAML-driven via
        # `configurations: <id>` references; the host's caller receives the
        # `configuration_id` and decides what to do (typically: ignore it
        # and use the same client for every stage). Customers needing
        # different clients per configuration drop down to
        # `RuntimeBuilder.register_llm_caller(my_dispatcher)` directly.
        self._llm_caller: Optional[Callable[[Optional[str], str], str]] = None
        # Mutable holder so the LLM-caller closure (built BEFORE the
        # runtime exists) can look up `configurations[]` entries AFTER
        # `build()` populates it via ``Runtime.llm_configuration``.
        # Without this, adapter factories would have no way to honour
        # YAML-declared per-stage `model:` selections.
        self._configuration_resolver: _ConfigurationResolverHolder = (
            _ConfigurationResolverHolder()
        )
        self._observability_providers: List[Any] = []
        self._streaming_config: Optional[dict] = None
        self._extra_register: List[Callable[[RuntimeBuilder], None]] = []
        self._mode: ShieldMode = ShieldMode.ENFORCE
        self._on_block: OnBlockPolicy = "return_blocked"
        self._consumed: bool = False

    # ── Consume-on-build guard ────────────────────────────────────

    def _check_consumed(self) -> None:
        if self._consumed:
            raise RuntimeError(
                "ShieldBuilder.build() can only be called once. "
                "Call Shield.from_yaml(...) again to create a new builder.",
            )

    # ── Bundle binding (composition pattern) ───────────────────────

    def _bind_to_bundle(self, bundle: FrameworkBundle) -> "ShieldBuilder":
        """Attach a framework bundle and (re)bind the client if set.

        Called by the adapter-installed ``with_<framework>()`` methods.
        Idempotent — calling twice with the same bundle is a no-op.
        """
        self._check_consumed()
        self._bundle = bundle
        self._bind_caller()
        return self

    def _bind_caller(self) -> None:
        if self._bundle is None or self._client is None:
            return
        # Forward the YAML configuration resolver to the factory so the
        # adapter's caller closure can honour per-stage `model:` /
        # `max_tokens:` selections. Older third-party factories that
        # don't accept the kwarg gracefully fall back to the legacy
        # client-only signature.
        try:
            self._llm_caller = self._bundle.llm_caller_factory.make_caller(
                self._client,
                configuration_resolver=self._configuration_resolver,
            )
        except TypeError:
            self._llm_caller = self._bundle.llm_caller_factory.make_caller(
                self._client,
            )

    # ── LLM client wiring ──────────────────────────────────────────

    def with_client(self, client: Any) -> "ShieldBuilder":
        """Set the LLM client used by every validation stage's
        ``evaluate_when[].llm`` invocation. The host's caller receives the
        YAML-declared ``configuration_id`` as its first argument; per-stage
        variation is driven entirely from YAML
        (``configurations: - {id, type: llm, provider, model, api_key_env}``)
        and the per-stage ``configuration:`` references in
        ``input_validation`` / ``state_validation`` /
        ``tool_execution_validation`` / ``post_tool_validation`` /
        ``output_validation``.

        If no bundle has been attached yet (composition pattern), the client
        is buffered and bound when ``with_<framework>()`` is called.
        """
        self._check_consumed()
        self._client = client
        self._bind_caller()
        return self

    # ── Streaming / observability / extension hooks ───────────────

    def with_streaming(self, **kwargs: Any) -> "ShieldBuilder":
        self._check_consumed()
        self._streaming_config = kwargs
        return self

    def with_observability(
        self, provider: Any,
    ) -> "ShieldBuilder":
        """Register a single observability provider. Chain to register more."""
        self._check_consumed()
        self._observability_providers.append(provider)
        return self

    def with_extension(
        self, hook: Callable[[RuntimeBuilder], None],
    ) -> "ShieldBuilder":
        self._check_consumed()
        self._extra_register.append(hook)
        return self

    # ── Host-callback registration ────────────────────────────────
    # These mirror Rust+.NET ShieldBuilder.with_* hooks. They register
    # host implementations for resolver/extractor/observability kinds
    # declared in YAML. Each delegates to the underlying RuntimeBuilder
    # at build() time via the _extra_register hook chain.

    def with_agent_resolver(
        self, resolver: Any,
    ) -> "ShieldBuilder":
        """Register a host implementation for ``kind: agent`` resolvers
        declared in YAML. ``resolver`` is the same shape accepted by
        :meth:`Runtime.register_agent_resolver` — typically an object
        with ``resolve(request) -> ResolverResponse``, or a plain
        callable with that signature.

        Mirrors ``Shield::with_agent_resolver`` in Rust and
        ``ShieldBuilder.WithAgentResolver`` in .NET.
        """
        self._check_consumed()
        self._extra_register.append(
            lambda rb: rb.register_agent_resolver(resolver),
        )
        return self

    # ── Behavioural policy ────────────────────────────────────────

    def with_mode(self, mode: Union[ShieldMode, str]) -> "ShieldBuilder":
        """Set ``"enforce"`` or ``"monitor"``."""
        self._check_consumed()
        if isinstance(mode, str):
            mode = ShieldMode(mode.lower())
        self._mode = mode
        return self

    def with_on_block(self, policy: OnBlockPolicy) -> "ShieldBuilder":
        """Set how blocks should be surfaced (see :data:`OnBlockPolicy`)."""
        self._check_consumed()
        self._on_block = policy
        return self

    def with_perf_telemetry(
        self,
        mode: "Union[PerfTelemetry, str]",
    ) -> "ShieldBuilder":
        """Opt into the v8 perf-logging instrumentation (PR5/PR6).

        Delegates to :meth:`RuntimeBuilder.with_perf_telemetry` when
        the underlying runtime is built. See that method's docstring
        for the gating table; default is :attr:`PerfTelemetry.OFF`
        — zero perf events emit.
        """
        self._check_consumed()
        # Capture the value (not the enum object) so the closure stays
        # picklable / repr-stable regardless of how callers pass the
        # mode in (enum vs string).
        if isinstance(mode, PerfTelemetry):
            wire = mode.value
        else:
            wire = str(mode).lower()
        self._extra_register.append(
            lambda rb: rb.with_perf_telemetry(wire),
        )
        return self

    # ── Build ─────────────────────────────────────────────────────

    def build(self) -> Shield:
        self._check_consumed()
        # A null bundle is allowed: framework-agnostic operations
        # (`Shield.run`, `Shield.protect_tool`, `Shield.before_invoke`)
        # don't need a bundle. Methods that DO need one (`Shield.guard`,
        # `Shield.protect_tools`, `Shield.capabilities`) fail with a
        # clear message at call time. Mirrors the Node SDK's behaviour.
        if self._yaml_chain is not None:
            builder = RuntimeBuilder.from_yaml_chain(self._yaml_chain)
        else:
            builder = RuntimeBuilder.from_yaml(self._path)

        if self._llm_caller is not None:
            builder.register_llm_caller(self._llm_caller)
        for provider in self._observability_providers:
            builder.register_observability_provider(provider)
        for hook in self._extra_register:
            hook(builder)

        rt = builder.build()
        # Now that the runtime exists, fill in the LLM configuration
        # resolver so caller closures resolve `configurations[]` entries
        # at call time. Must happen BEFORE the first stage runs.
        self._configuration_resolver.bind(rt)
        shield = Shield(
            rt,
            bundle=self._bundle,
            client=self._client,
            streaming_config=self._streaming_config,
            mode=self._mode,
            on_block=self._on_block,
        )
        self._consumed = True
        return shield


__all__ = [
    "AgentShieldBlocked",
    "GuardedRunner",
    "OnBlockPolicy",
    "Shield",
    "ShieldBuilder",
    "ShieldMode",
]
