# Python AutoGen adapter mediation

## Mediated paths
- `ShieldBuilder.with_autogen()` installs the bundle; guarded agent execution goes through `sdk/python/agent_shield/adapters/autogen.py:231`.
- AutoGen tool calls are wrapped at `sdk/python/agent_shield/adapters/autogen.py:195`.
- The adapter's buffered stream shim lives at `sdk/python/agent_shield/adapters/autogen.py:293`, but the capability report still marks streaming unsupported.

## Unsupported paths
- Calling the original `BaseTool.run(...)` directly.
- Framework streaming paths beyond the adapter's documented buffered shim.
- Any AutoGen execution path that bypasses `shield.guard(...)` / `shield.protect_tools(...)`.

## Bypass risks
- Registering raw and wrapped AutoGen tools side by side.
- Swapping a wrapped tool back to the raw object after agent construction.
- Assuming the buffered shim upgrades AutoGen to full streaming coverage; it does not.

## Streaming behavior
- Streaming is documented as unsupported for this adapter. The buffered helper is compatibility glue, not a conformance claim, so §18.4 rules 1-5 are not claimed here.

## Unknown tool-call shapes
- Argument validation falls back from `model_validate(...)` to constructor binding in `sdk/python/agent_shield/adapters/autogen.py:184`; truly unknown shapes therefore do not yet emit `incident.unknown_invocation_shape`.

## See also

See [Post-tool limits and dangerous patterns](../../../../../docs/POST_TOOL_LIMITS.md) and the [adapter-mediated path matrix](../../../../../docs/adapter-mediated-paths.md).
