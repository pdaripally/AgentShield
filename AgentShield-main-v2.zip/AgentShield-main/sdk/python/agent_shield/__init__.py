"""Agent Shield — unified-resolver runtime API (Python wrapper).

Quick start::

    from agent_shield import RuntimeBuilder, Lifetime

    runtime = (
        RuntimeBuilder.from_yaml("guardrails.yaml")
        .register_observability_provider(my_provider)
        .build()
    )
    with runtime.new_session(session_id="s-1", correlation_id="c-1") as session:
        session.begin_turn()
        verdict = session.validate_input("user message")
        if verdict:
            ...
"""
from __future__ import annotations

from .hooks import (
    AgentResolver,
    ClassifierCaller,
    ClassifierVerdict,
    DelegateDispatcher,
    DelegateRequest,
    LlmCaller,
    LlmResponse,
    ResolverDecision,
    ResolverRequest,
    ResolverResponse,
)
from .observability import (
    CapturingProvider,
    ObservabilityProvider,
    ShieldLogEvent,
)
from .config import CompiledPolicy, ConfigSource, GuardrailsConfig
from .runtime import (
    AgentCallOutcome,
    EndpointCallOutcome,
    Lifetime,
    OutputOutcome,
    PerfTelemetry,
    Runtime,
    RuntimeBuilder,
    Session,
    StageVerdict,
    ToolCallOutcome,
    ToolOutputOutcome,
    VariableState,
    make_configuration_caller,
)
from .streaming import StreamChunkResult, StreamingGuard


def __getattr__(name: str):
    """Lazily expose the framework-agnostic ``Shield`` / ``ShieldBuilder``.

    Imported lazily so that ``import agent_shield`` does not pull in the
    adapter package unless the customer asks for it.
    """
    if name in (
        "Shield",
        "ShieldBuilder",
        "ShieldMode",
        "AgentShieldBlocked",
        "AdapterStageMutationError",
        "AmbientBundleAmbiguityError",
        "ConfigurationMissingModelError",
    ):
        from .adapters._shield import (  # noqa: WPS433 — lazy by design
            AgentShieldBlocked,
            Shield,
            ShieldBuilder,
            ShieldMode,
        )
        from .adapters._capabilities import (  # noqa: WPS433 — lazy by design
            AdapterStageMutationError,
            AmbientBundleAmbiguityError,
            ConfigurationMissingModelError,
        )
        return {
            "Shield": Shield,
            "ShieldBuilder": ShieldBuilder,
            "ShieldMode": ShieldMode,
            "AgentShieldBlocked": AgentShieldBlocked,
            "AdapterStageMutationError": AdapterStageMutationError,
            "AmbientBundleAmbiguityError": AmbientBundleAmbiguityError,
            "ConfigurationMissingModelError": ConfigurationMissingModelError,
        }[name]
    raise AttributeError(f"module 'agent_shield' has no attribute {name!r}")


__all__ = [
    # Runtime / builder
    "RuntimeBuilder",
    "Runtime",
    "Session",
    # Framework-agnostic shield orchestrator (composition pattern)
    "Shield",
    "ShieldBuilder",
    "ShieldMode",
    "AgentShieldBlocked",
    "AdapterStageMutationError",
    "AmbientBundleAmbiguityError",
    "ConfigurationMissingModelError",
    # Composable configuration
    "GuardrailsConfig",
    "CompiledPolicy",
    "ConfigSource",
    # Verdicts / outcomes
    "StageVerdict",
    "VariableState",
    "ToolCallOutcome",
    "ToolOutputOutcome",
    "EndpointCallOutcome",
    "AgentCallOutcome",
    "OutputOutcome",
    # Lifetime helper
    "Lifetime",
    # Perf-telemetry gating (v8 perf-logging Phase 1)
    "PerfTelemetry",
    # LLM caller dispatch helper
    "make_configuration_caller",
    # Hooks — protocols + envelopes
    "ResolverDecision",
    "ResolverRequest",
    "ResolverResponse",
    "DelegateRequest",
    "AgentResolver",
    "DelegateDispatcher",
    "LlmCaller",
    "LlmResponse",
    "ClassifierCaller",
    "ClassifierVerdict",
    # Observability
    "ObservabilityProvider",
    "CapturingProvider",
    "ShieldLogEvent",
    # Streaming
    "StreamingGuard",
    "StreamChunkResult",
]
