"""v8 perf-logging PR6 — AC10: ShieldLogEvent attribute passthrough.

Verifies that :meth:`ShieldLogEvent.from_dict` survives BOTH:

1. **New ``event_type`` variants** added in v8 PR5 (``stage_evaluated``,
   ``policy_evaluated``, ``llm_called``, ``classifier_called``). The
   Python wrapper stores the ``event_type`` as a plain string, so it
   already round-trips any wire string — old / new / unknown.

2. **Unknown attribute keys** under the open-ended ``agent_shield.*``
   namespace. PR5 added 14 perf attribute keys; future adoptions may
   add more (custom ObservabilityProvider impls, vendor-specific
   metrics). The dataclass MUST preserve unknown keys verbatim
   instead of dropping them on the floor.

Single test, two assertion blocks — the contract is "passthrough at
both layers" per the v8 plan §3 reframing of AC10.
"""
from __future__ import annotations

from agent_shield import ShieldLogEvent


def test_from_dict_survives_new_variants_and_unknown_attributes():
    # ── Assertion 1: New ``EventType`` variants survive ─────────
    #
    # The four wire strings PR5 added. Old SDKs that haven't been
    # updated would still receive these because the Python wrapper
    # stores ``event_type`` as a plain string. The assertion pins
    # that contract.
    for wire in [
        "stage_evaluated",
        "policy_evaluated",
        "llm_called",
        "classifier_called",
        # An unknown future variant — also survives.
        "future_variant_we_havent_invented_yet",
    ]:
        ev = ShieldLogEvent.from_dict({
            "timestamp": "2026-05-21T18:00:00Z",
            "severity": "info",
            "event_type": wire,
            "category": "perf.test",
            "session_id": "sess-1",
            "correlation_id": "corr-1",
            "attributes": {},
        })
        assert ev.event_type == wire, (
            f"event_type {wire!r} must round-trip verbatim"
        )

    # ── Assertion 2: Unknown attribute keys survive ─────────────
    #
    # The runtime stamps ``agent_shield.*`` attributes; adopters may
    # also add their own. ``from_dict`` MUST NOT drop unknown keys.
    payload = {
        "timestamp": "2026-05-21T18:00:00Z",
        "severity": "info",
        "event_type": "llm_called",
        "category": "perf.llm",
        "session_id": "sess-2",
        "correlation_id": "corr-2",
        "attributes": {
            # Known perf attributes added in PR5.
            "agent_shield.duration_ms": 42,
            "agent_shield.stage": "input",
            "agent_shield.guard_policy": "wire_transfer_safety",
            "agent_shield.evaluate_when_index": 0,
            "agent_shield.llm.configuration_id": "fast-haiku",
            "agent_shield.llm.decision": "block",
            "agent_shield.llm.confidence": 0.95,
            # Unknown future attribute that PR6 doesn't define.
            "agent_shield.future.cost_usd_micros": 12345,
            # Adopter-private attribute outside the agent_shield.*
            # namespace (custom ObservabilityProvider impls add these).
            "my_company.tenant_id": "acme",
            "my_company.cost_center": "ai-platform",
        },
    }
    ev = ShieldLogEvent.from_dict(payload)
    # Every input key survives — preserved attribute-by-attribute.
    for key, value in payload["attributes"].items():
        assert ev.attributes.get(key) == value, (
            f"attribute {key!r} did not round-trip: "
            f"got {ev.attributes.get(key)!r}, expected {value!r}"
        )
    # Spot-check the typed-on-top fields populated from the wire
    # shape (so the test fails clearly if from_wire_dict regresses).
    assert ev.event_type == "llm_called"
    assert ev.session_id == "sess-2"
    assert ev.correlation_id == "corr-2"
