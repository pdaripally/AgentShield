"""Tests for the composable :mod:`agent_shield.config` object model."""
from __future__ import annotations

from pathlib import Path

import pytest


REPO_ROOT = Path(__file__).resolve().parent.parent.parent.parent
GLOBAL_FIXTURES = REPO_ROOT / "tests" / "fixtures"
LOCAL_FIXTURES = Path(__file__).resolve().parent / "fixtures_smoke"

MINIMAL = str(GLOBAL_FIXTURES / "smoke" / "minimal.guardrails.yaml")


class TestGuardrailsConfigConstructors:
    """Constructors produce correct initial chains."""

    def test_load_single_path(self):
        from agent_shield import GuardrailsConfig

        cfg = GuardrailsConfig.load(MINIMAL)
        assert len(cfg) == 1
        assert cfg.layers[0].kind == "path"

    def test_from_string(self):
        from agent_shield import GuardrailsConfig

        with open(MINIMAL) as f:
            text = f.read()
        cfg = GuardrailsConfig.from_string(text)
        assert len(cfg) == 1
        assert cfg.layers[0].kind == "string"
        assert cfg.layers[0].source == text

    def test_from_dict(self):
        from agent_shield import GuardrailsConfig

        data = {"metadata": {"name": "x", "version": "0.1.0"}}
        cfg = GuardrailsConfig.from_dict(data)
        assert len(cfg) == 1
        assert cfg.layers[0].kind == "dict"
        assert cfg.layers[0].source == data

    def test_compose_chains_multiple_sources(self):
        from agent_shield import GuardrailsConfig

        cfg = GuardrailsConfig.compose(
            MINIMAL,
            {"agent_metadata": {"mode": "monitor"}},
        )
        assert len(cfg) == 2
        assert cfg.layers[0].kind == "path"
        assert cfg.layers[1].kind == "dict"

    def test_compose_empty_raises(self):
        from agent_shield import GuardrailsConfig

        with pytest.raises(ValueError, match="at least one"):
            GuardrailsConfig.compose()


class TestGuardrailsConfigExtension:
    """Fluent extend / overrides return new instances."""

    def test_extend_returns_new_instance(self):
        from agent_shield import GuardrailsConfig

        cfg = GuardrailsConfig.load(MINIMAL)
        cfg2 = cfg.extend({"agent_metadata": {"mode": "monitor"}})

        assert cfg is not cfg2
        assert len(cfg) == 1
        assert len(cfg2) == 2

    def test_extend_with_path(self):
        from agent_shield import GuardrailsConfig

        cfg = GuardrailsConfig.load(MINIMAL).extend(MINIMAL)
        assert len(cfg) == 2
        assert all(layer.kind == "path" for layer in cfg.layers)

    def test_extend_with_dict(self):
        from agent_shield import GuardrailsConfig

        cfg = GuardrailsConfig.load(MINIMAL).extend(
            {"metadata": {"name": "leaf"}},
        )
        assert cfg.layers[-1].kind == "dict"

    def test_extend_with_yaml_string(self):
        from agent_shield import GuardrailsConfig

        with open(MINIMAL) as f:
            text = f.read()
        cfg = GuardrailsConfig.load(MINIMAL).extend(text)
        assert cfg.layers[-1].kind == "string"

    def test_extend_with_other_config(self):
        from agent_shield import GuardrailsConfig

        a = GuardrailsConfig.load(MINIMAL)
        b = GuardrailsConfig.load(MINIMAL).extend(MINIMAL)
        merged = a.extend(b)
        assert len(merged) == 3

    def test_with_overrides(self):
        from agent_shield import GuardrailsConfig

        cfg = GuardrailsConfig.load(MINIMAL).with_overrides(
            {"metadata": {"description": "monitoring mode"}},
        )
        assert len(cfg) == 2
        assert cfg.layers[-1].kind == "dict"

    def test_with_policy_pack_path(self):
        from agent_shield import GuardrailsConfig

        cfg = GuardrailsConfig.load(MINIMAL).with_policy_pack(MINIMAL)
        assert cfg.layers[-1].kind == "path"

    def test_with_policy_pack_dict(self):
        from agent_shield import GuardrailsConfig

        cfg = GuardrailsConfig.load(MINIMAL).with_policy_pack(
            {"metadata": {"description": "tenant pack"}},
        )
        assert cfg.layers[-1].kind == "dict"


class TestCompiledPolicy:
    """compile() produces a hashable, content-keyed CompiledPolicy."""

    def test_compile_yields_yaml_strings(self):
        from agent_shield import GuardrailsConfig

        cfg = GuardrailsConfig.load(MINIMAL)
        compiled = cfg.compile()
        assert len(compiled.yaml_strings) == 1
        assert "smoke-minimal" in compiled.yaml_strings[0]
        assert len(compiled.digest) == 64  # sha256 hex

    def test_compile_chain_yields_n_strings(self):
        from agent_shield import GuardrailsConfig

        cfg = (
            GuardrailsConfig.load(MINIMAL)
            .extend({"metadata": {"description": "overlay"}})
        )
        compiled = cfg.compile()
        assert len(compiled.yaml_strings) == 2
        assert "overlay" in compiled.yaml_strings[1]

    def test_compile_is_deterministic(self):
        from agent_shield import GuardrailsConfig

        a = GuardrailsConfig.load(MINIMAL).compile()
        b = GuardrailsConfig.load(MINIMAL).compile()
        assert a == b
        assert a.digest == b.digest
        assert hash(a) == hash(b)

    def test_compile_changes_with_layer_change(self):
        from agent_shield import GuardrailsConfig

        a = GuardrailsConfig.load(MINIMAL).compile()
        b = (
            GuardrailsConfig.load(MINIMAL)
            .with_overrides({"metadata": {"description": "different"}})
            .compile()
        )
        assert a != b
        assert a.digest != b.digest

    def test_empty_chain_compile_raises(self):
        from agent_shield import GuardrailsConfig

        with pytest.raises(ValueError, match="no layers"):
            GuardrailsConfig().compile()

    def test_compiled_policy_is_hashable(self):
        from agent_shield import GuardrailsConfig

        compiled = GuardrailsConfig.load(MINIMAL).compile()
        d: dict = {compiled: "cached_runtime"}
        assert d[compiled] == "cached_runtime"


class TestRuntimeBuilderFromConfig:
    """RuntimeBuilder.from_config accepts every supported shape."""

    def test_from_config_with_path(self):
        from agent_shield import RuntimeBuilder

        rt = RuntimeBuilder.from_config(MINIMAL).build()
        assert rt.metadata_name == "smoke-minimal"

    def test_from_config_with_path_list(self):
        from agent_shield import RuntimeBuilder

        rt = RuntimeBuilder.from_config([MINIMAL]).build()
        assert rt.metadata_name == "smoke-minimal"

    def test_from_config_with_guardrails_config(self):
        from agent_shield import GuardrailsConfig, RuntimeBuilder

        cfg = GuardrailsConfig.load(MINIMAL)
        rt = RuntimeBuilder.from_config(cfg).build()
        assert rt.metadata_name == "smoke-minimal"

    def test_from_config_with_compiled_policy(self):
        from agent_shield import GuardrailsConfig, RuntimeBuilder

        compiled = GuardrailsConfig.load(MINIMAL).compile()
        rt = RuntimeBuilder.from_config(compiled).build()
        assert rt.metadata_name == "smoke-minimal"

    def test_from_yaml_strings_chain_via_runtime_builder(self):
        from agent_shield import RuntimeBuilder

        with open(MINIMAL) as f:
            text = f.read()
        rt = RuntimeBuilder.from_yaml_strings([text]).build()
        assert rt.metadata_name == "smoke-minimal"


class TestComposedRuntime:
    """End-to-end: composed config produces a runtime with leaf-wins values."""

    def test_overlay_overrides_metadata_name(self):
        from agent_shield import GuardrailsConfig, RuntimeBuilder

        # Compose: base + leaf overlay that replaces metadata.name.
        base_overlay = {
            "metadata": {
                "name": "leaf-name",
                "version": "0.1.0",
                "agent_shield_version": "2.0",
            },
            "objective": {"goal": ["overlay goal"]},
            "resources": {"tools": []},
        }
        cfg = (
            GuardrailsConfig.load(MINIMAL)
            .with_overrides(base_overlay)
        )
        rt = RuntimeBuilder.from_config(cfg).build()
        # The leaf wins on metadata.name.
        assert rt.metadata_name == "leaf-name"

    def test_compiled_policy_caches_by_digest(self):
        from agent_shield import GuardrailsConfig

        # Multi-tenant SaaS pattern: cache compiled runtimes by digest.
        compiled_a = GuardrailsConfig.load(MINIMAL).compile()
        compiled_b = GuardrailsConfig.load(MINIMAL).compile()
        cache: dict = {}
        cache[compiled_a.digest] = "runtime-A"
        # Identical content → same digest → cache hit.
        assert cache.get(compiled_b.digest) == "runtime-A"
