"""FFI boundary tests for the AgentShield Python SDK (PyO3 layer).

These tests validate correctness at the Python↔Rust FFI boundary:
string marshaling, concurrency, large payloads, and error propagation.
"""
from __future__ import annotations

import concurrent.futures
import json
import threading
from pathlib import Path

import pytest

try:
    import agent_shield._native as _native  # noqa: F401
    from agent_shield import RuntimeBuilder
except ImportError:
    RuntimeBuilder = None  # type: ignore[assignment]
    _native = None  # type: ignore[assignment]


pytestmark = pytest.mark.skipif(
    _native is None,
    reason="agent_shield._native unavailable; run `maturin develop` in sdk/python",
)

REPO_ROOT = Path(__file__).resolve().parent.parent.parent.parent
MINIMAL = str(REPO_ROOT / "tests" / "fixtures" / "smoke" / "minimal.guardrails.yaml")

_STRING_FIXTURE_YAML = """
metadata:
  name: "ffi-string-roundtrip"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["exercise string FFI round-tripping"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "echo"
      description: "Echoes a message back."
      permission: "read_only"
variables:
  - name: "status_text"
    type: "string"
    default: ""
"""


def _build_runtime(path: str = MINIMAL):
    return RuntimeBuilder.from_yaml(path).build()


def _build_string_runtime():
    return RuntimeBuilder.from_yaml_strings([_STRING_FIXTURE_YAML]).build()


def _new_session(runtime, *, session_id: str, correlation_id: str):
    session = runtime.new_session(session_id=session_id, correlation_id=correlation_id)
    session.begin_turn()
    return session


def _authorized_session(runtime, *, session_id: str, correlation_id: str):
    session = _new_session(runtime, session_id=session_id, correlation_id=correlation_id)
    session.set_variable("authorized", True)
    return session


def _deeply_nested_object(depth: int) -> dict[str, object]:
    root: dict[str, object] = {"leaf": "start"}
    cursor = root
    for level in range(depth):
        child: dict[str, object] = {"level": level}
        cursor["next"] = child
        cursor = child
    return root


def test_embedded_nul_byte_in_tool_name_is_catchable():
    session = _authorized_session(_build_runtime(), session_id="ffi-nul", correlation_id="ffi-nul")

    try:
        outcome = session.validate_tool_call("echo\x00ffi", {"msg": "hello"}, tool_call_id="ffi-nul")
    except Exception as exc:
        assert isinstance(exc, Exception)
    else:
        assert isinstance(outcome.verdict.allowed, bool)
        assert isinstance(outcome.params, dict)



def test_four_byte_emoji_round_trips_through_string_variable():
    runtime = _build_string_runtime()
    session = _new_session(runtime, session_id="ffi-emoji", correlation_id="ffi-emoji")

    emoji = "🛡️"
    session.set_variable("status_text", emoji)

    state = session.read_variable("status_text")
    assert state is not None
    assert state.value == emoji
    assert isinstance(state.value, str)



def test_empty_string_input_is_handled_without_null_coercion():
    session = _new_session(_build_runtime(), session_id="ffi-empty", correlation_id="ffi-empty")

    verdict = session.validate_input("")

    assert verdict.allowed is True
    assert verdict.reason is None



def test_large_string_tool_param_returns_consistent_verdict():
    session = _authorized_session(_build_runtime(), session_id="ffi-large-str", correlation_id="ffi-large-str")

    large_value = "x" * (1024 * 1024)
    outcome = session.validate_tool_call("echo", {"msg": large_value}, tool_call_id="ffi-large-str")

    assert outcome.verdict.allowed is True
    assert outcome.params == {"msg": large_value}



def test_deeply_nested_tool_params_do_not_abort_the_process():
    session = _authorized_session(_build_runtime(), session_id="ffi-nested", correlation_id="ffi-nested")
    payload = _deeply_nested_object(256)

    try:
        outcome = session.validate_tool_call("echo", payload, tool_call_id="ffi-nested")
    except Exception as exc:
        assert isinstance(exc, Exception)
    else:
        assert outcome.verdict.allowed is True
        assert isinstance(outcome.params, dict)



def test_shared_runtime_is_thread_safe_for_tool_validation():
    runtime = _build_runtime()
    params = {"msg": "thread-safe 🛡️"}
    barrier = threading.Barrier(4)

    def worker(worker_id: int) -> tuple[int, bool]:
        with runtime.new_session(
            session_id=f"ffi-thread-{worker_id}",
            correlation_id=f"ffi-thread-{worker_id}",
        ) as session:
            session.begin_turn()
            session.set_variable("authorized", True)
            barrier.wait()
            for iteration in range(10_000):
                outcome = session.validate_tool_call(
                    "echo",
                    params,
                    tool_call_id=f"ffi-thread-{worker_id}-{iteration}",
                )
                assert outcome.verdict.allowed is True
                assert outcome.params == params
            return worker_id, True

    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        futures = [executor.submit(worker, worker_id) for worker_id in range(4)]
        results = [future.result() for future in futures]

    assert results == [(0, True), (1, True), (2, True), (3, True)]



def test_large_json_tool_params_round_trip_without_oom():
    session = _authorized_session(_build_runtime(), session_id="ffi-large-json", correlation_id="ffi-large-json")
    tool_params = {
        "payload": "x" * 1_060_000,
        "metadata": {
            "source": "ffi-boundary",
            "empty": "",
            "emoji": "🛡️",
            "flags": [True, False, None],
        },
        "items": [{"index": idx, "label": f"item-{idx}"} for idx in range(32)],
    }

    assert len(json.dumps(tool_params, ensure_ascii=False)) >= 1024 * 1024

    outcome = session.validate_tool_call("echo", tool_params, tool_call_id="ffi-large-json")

    assert outcome.verdict.allowed is True
    assert outcome.params == tool_params
