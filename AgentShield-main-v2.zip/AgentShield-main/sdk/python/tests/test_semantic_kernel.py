"""Tests for the Semantic Kernel adapter."""
from __future__ import annotations

import os

import pytest

# Skip the whole module if SK isn't installed in the test environment.
semantic_kernel = pytest.importorskip("semantic_kernel")

from agent_shield import AdapterStageMutationError, RuntimeBuilder  # noqa: E402 - imported after importorskip to skip cleanly when semantic_kernel is unavailable.
from agent_shield.adapters._capabilities import ToolMetadata  # noqa: E402 - imported after importorskip to skip cleanly when semantic_kernel is unavailable.
from agent_shield.adapters._orchestration import guarded_tool  # noqa: E402 - imported after importorskip to skip cleanly when semantic_kernel is unavailable.
from agent_shield.adapters.semantic_kernel import _ToolWrapper  # type: ignore  # noqa: E402 - imported after importorskip to skip cleanly when semantic_kernel is unavailable.


REPO_ROOT = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "..", ".."),
)
MINIMAL_YAML = os.path.join(
    REPO_ROOT, "tests", "fixtures", "smoke", "minimal.guardrails.yaml",
)


# ---------------------------------------------------------------------------
# Layer 1 — orchestrator behaviour when an adapter raises the typed error
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_guarded_tool_catches_adapter_stage_mutation_error() -> None:
    """A Stage-3 transform failure raised by the adapter must be a
    fail-closed block: the underlying tool body must NOT run, and the
    returned tuple must signal a block with the canonical
    ``[GUARDRAIL ...]`` message."""
    runtime = RuntimeBuilder.from_yaml(MINIMAL_YAML).build()
    session = runtime.new_session()
    session.begin_turn()

    body_called = False

    async def _execute(effective_params: dict) -> str:
        nonlocal body_called
        # Simulate the SK adapter: mutation of the framework's
        # parameter container fails, which the adapter surfaces as a
        # typed error.
        raise AdapterStageMutationError(
            tool_name="echo", cause=RuntimeError("frozen container"),
        )
        body_called = True  # pragma: no cover — unreachable
        return ""

    blocked, output = await guarded_tool(
        "unrelated_tool", {"x": 1}, _execute, session=session,
    )

    assert blocked is True
    assert body_called is False
    # Canonical block message produced by the core formatter.
    assert output.startswith("[GUARDRAIL BLOCK]")
    assert "unrelated_tool" in output
    assert "Stage-3 transform failed" in output
    assert "frozen container" in output


# ---------------------------------------------------------------------------
# Layer 2 — the SK adapter's _execute closure surfaces the typed error
# ---------------------------------------------------------------------------


class _FrozenArgs(dict):
    """A dict-like container whose mutation always raises.

    Models the case where SK's ``KernelArguments`` container rejects a
    Stage-3 transform (e.g. because of a type contract).
    """

    def __setitem__(self, key, value):  # type: ignore[override]
        raise RuntimeError("frozen container — cannot mutate")

    def __delitem__(self, key):  # type: ignore[override]
        raise RuntimeError("frozen container — cannot delete")


class _StubContext:
    def __init__(self, args) -> None:
        self.arguments = args
        self.result = None


class _StubKernelFunction:
    """Mimics the surface the SK adapter touches on a KernelFunction."""

    def __init__(self, name: str) -> None:
        self.name = name
        self.description = name
        self.method = None
        self.metadata = object()  # only used by FunctionResult ctor
        self._invoke_internal = None
        self.body_called = False

    async def original_invoke(self, context) -> None:
        # This stand-in for the user's tool body MUST NOT run when the
        # Stage-3 mutation fails.
        self.body_called = True
        context.result = "ran"


@pytest.mark.asyncio
async def test_sk_adapter_raises_typed_error_on_mutation_failure(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The SK adapter's ``_execute`` must raise
    :class:`AdapterStageMutationError` (not silently fall through) when
    it can't mutate ``context.arguments``."""

    # Stub out the deferred SK import so the test does not depend on a
    # real `KernelFunction.from_method` path.

    class _FakeKernelFunction:
        @staticmethod
        def from_method(method):  # noqa: D401 - test stub
            raise AssertionError("from_method should not be called")

    class _FakeFunctionResult:
        def __init__(self, *, function, value) -> None:
            self.function = function
            self.value = value

        def __str__(self) -> str:  # pragma: no cover — not exercised
            return str(self.value)

    fake_sk_funcs = type(
        "fake_sk_funcs",
        (),
        {
            "FunctionResult": _FakeFunctionResult,
            "KernelFunction": _FakeKernelFunction,
            "KernelArguments": dict,
        },
    )
    import sys

    monkeypatch.setitem(
        sys.modules, "semantic_kernel.functions", fake_sk_funcs,
    )

    stub_fn = _StubKernelFunction("frozen_tool")
    metadata = ToolMetadata(
        name="frozen_tool",
        description="A function whose args container rejects mutation.",
        extras={
            "method": None,  # so wrap() takes the `wrapped = original` branch
            "metadata": None,
            "_invoke_internal": stub_fn.original_invoke,
        },
    )

    # Pull out the SK _execute closure by instrumenting guarded_tool to
    # capture it as it's invoked through the wrap pipeline. We exercise
    # it directly so the test doesn't depend on the runtime YAML loader.
    wrapper = _ToolWrapper()

    # We don't use the bundle-installed `guarded_invoke`; we just need
    # the wrapped function so we can invoke `_invoke_internal` on it.
    def _unused_guarded_invoke(*_args, **_kwargs):  # pragma: no cover
        raise AssertionError("not used in this test")

    wrapped = wrapper.wrap(stub_fn, metadata, _unused_guarded_invoke)

    # Now invoke through guarded_tool by hand-rolling the same call
    # path: we want to confirm the SK closure raises
    # AdapterStageMutationError. The wrap()'s `_guarded_invoke_internal`
    # closure calls `guarded_tool(..., _execute)` internally; we reach
    # the underlying `_execute` via a controlled invocation of
    # `wrapped._invoke_internal` once we set up a session.
    runtime = RuntimeBuilder.from_yaml(MINIMAL_YAML).build()
    session = runtime.new_session()

    # Provide ambient session so guarded_tool inside the wrap closure
    # uses it instead of constructing a new one.
    from agent_shield.adapters._orchestration import current_session

    token = current_session.set(session)
    try:
        session.begin_turn()
        ctx = _StubContext(_FrozenArgs({"x": 1}))
        await wrapped._invoke_internal(ctx)
    finally:
        current_session.reset(token)

    # Body must NOT have been called, and the context.result must hold
    # the canonical block message.
    assert stub_fn.body_called is False
    assert isinstance(ctx.result, _FakeFunctionResult)
    assert isinstance(ctx.result.value, str)
    assert ctx.result.value.startswith("[GUARDRAIL BLOCK]")
    assert "frozen_tool" in ctx.result.value
    assert "Stage-3 transform failed" in ctx.result.value


# ---------------------------------------------------------------------------
# Layer 3 — _LlmCallerFactory plumbs cfg through PromptExecutionSettings
# ---------------------------------------------------------------------------


def test_llm_caller_plumbs_max_tokens_and_temperature_through_settings():
    """Approach A — ``chat_service.get_prompt_execution_settings_class()``
    discovery. A ``configurations[]`` entry declaring
    ``max_tokens: 256`` and (hand-rolled, since the YAML schema rejects
    ``temperature``) ``temperature: 0.7`` must reach the recorded
    ``PromptExecutionSettings`` instance handed to SK's
    ``get_chat_message_contents``.
    """
    from semantic_kernel.connectors.ai.open_ai.prompt_execution_settings.open_ai_prompt_execution_settings import (
        OpenAIChatPromptExecutionSettings,
    )

    from agent_shield.adapters.semantic_kernel import _LlmCallerFactory

    recorded: dict = {}

    class _FakeChatMessageContent:
        def __init__(self, text: str) -> None:
            self._text = text

        def __str__(self) -> str:  # noqa: D401
            return self._text

    class _RecordingChatService:
        """Minimal SK chat-service stand-in that records settings."""

        def get_prompt_execution_settings_class(self):  # noqa: D401
            return OpenAIChatPromptExecutionSettings

        async def get_chat_message_contents(
            self, history, settings=None, **kwargs,
        ):
            recorded["settings"] = settings
            recorded["history"] = history
            recorded["kwargs"] = kwargs
            return [_FakeChatMessageContent("ok")]

    class _FakeKernel:
        def __init__(self, service) -> None:
            self._service = service

        def get_service(self, *args, **kwargs):  # noqa: D401
            return self._service

    chat_service = _RecordingChatService()
    kernel = _FakeKernel(chat_service)

    # Hand-rolled resolver — temperature is not allowed in the YAML
    # schema, but the open dict shape the resolver returns is exactly
    # what the runtime would surface once / if the spec adds the
    # field. Same pattern the Anthropic test uses.
    def resolver(configuration_id):
        assert configuration_id == "stage1-judge"
        return {
            "id": "stage1-judge",
            "type": "llm",
            "model": "gpt-4o",
            "max_tokens": 256,
            "temperature": 0.7,
        }

    factory = _LlmCallerFactory()
    caller = factory.make_caller(kernel, configuration_resolver=resolver)

    out = caller("stage1-judge", "is the input safe?")
    assert out == "ok"

    settings = recorded["settings"]
    assert isinstance(settings, OpenAIChatPromptExecutionSettings)
    assert settings.max_tokens == 256
    assert settings.temperature == 0.7
    assert settings.ai_model_id == "gpt-4o"


def test_llm_caller_falls_back_to_settings_less_call_when_introspection_unavailable():
    """If the chat service doesn't expose
    ``get_prompt_execution_settings_class``, the adapter must invoke
    the historic settings-less call shape — preserving backward
    compatibility with stubs / older SK service stand-ins.
    """
    from agent_shield.adapters.semantic_kernel import _LlmCallerFactory

    recorded: dict = {}

    class _FakeChatMessageContent:
        def __str__(self) -> str:  # noqa: D401
            return "ok"

    class _LegacyChatService:
        # Deliberately *no* ``get_prompt_execution_settings_class``.

        async def get_chat_message_contents(self, history, **kwargs):
            recorded["kwargs"] = kwargs
            return [_FakeChatMessageContent()]

    class _FakeKernel:
        def __init__(self, service) -> None:
            self._service = service

        def get_service(self, *args, **kwargs):
            return self._service

    chat_service = _LegacyChatService()
    kernel = _FakeKernel(chat_service)

    factory = _LlmCallerFactory()
    caller = factory.make_caller(
        kernel,
        configuration_resolver=lambda _id: {
            "id": _id,
            "type": "llm",
            "model": "gpt-4o",
            "max_tokens": 256,
            "temperature": 0.7,
        },
    )

    out = caller("stage1-judge", "prompt")
    assert out == "ok"
    # Settings-less fallback: no ``settings`` kwarg was passed.
    assert "settings" not in recorded["kwargs"]


def test_llm_caller_no_resolver_uses_default_settings_instance():
    """Without a resolver, the adapter still discovers the settings
    class and passes a defaults-only instance — so SK's required
    ``settings`` arg is satisfied and behaviour matches the historic
    no-config call.
    """
    from semantic_kernel.connectors.ai.open_ai.prompt_execution_settings.open_ai_prompt_execution_settings import (
        OpenAIChatPromptExecutionSettings,
    )

    from agent_shield.adapters.semantic_kernel import _LlmCallerFactory

    recorded: dict = {}

    class _FakeChatMessageContent:
        def __str__(self) -> str:
            return "ok"

    class _RecordingChatService:
        def get_prompt_execution_settings_class(self):
            return OpenAIChatPromptExecutionSettings

        async def get_chat_message_contents(
            self, history, settings=None, **kwargs,
        ):
            recorded["settings"] = settings
            return [_FakeChatMessageContent()]

    class _FakeKernel:
        def __init__(self, service):
            self._service = service

        def get_service(self, *args, **kwargs):
            return self._service

    factory = _LlmCallerFactory()
    caller = factory.make_caller(_FakeKernel(_RecordingChatService()))

    caller(None, "prompt")
    settings = recorded["settings"]
    assert isinstance(settings, OpenAIChatPromptExecutionSettings)
    # No cfg applied — fields hold whatever defaults SK ships.
    assert settings.max_tokens is None or isinstance(settings.max_tokens, int)
