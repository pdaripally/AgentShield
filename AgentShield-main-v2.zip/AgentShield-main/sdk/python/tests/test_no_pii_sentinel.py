"""Agent Shield — Python no-PII sentinel test.

## Status: ACTIVE — runs on every CI build.

Originally landed in PR1 (chore/logging-audit-inventory) as a
``pytest.skip(...)``-marked skeleton. PR3 (fix/pii-python-dotnet)
demoted the two Bucket-D log sites this test was designed to catch
and removed the ``pytest.skip(...)`` markers in the same commit, so
the test now transitions red→green atomically per its original
contract.

## What this test verifies

Drives the agent_shield Python SDK through a representative end-to-end
interaction (build runtime → begin_turn → validate_input →
validate_tool_call → record_tool_failure → validate_output → end_turn)
with a ``logging.Handler`` attached at INFO level. After the run,
asserts that no captured log record contains any sensitive sentinel
the test injected.

## Sentinel values

The test feeds these specific strings into the SDK. PII / tool-arg
leakage will manifest as one of these strings appearing in a captured
INFO+ log record:

- ``SENTINEL_PII_USER_INPUT_xZk2``
- ``SENTINEL_PII_TOOL_ARGS_8mNQ``
- ``SENTINEL_PII_TOOL_RESULT_v3pL``
- ``SENTINEL_PII_VAR_VALUE_R7tF``

These tokens are intentionally distinctive so a CI grep can also
catch them: ``Select-String "SENTINEL_PII_"`` in any captured log
output is a hard fail.
"""

from __future__ import annotations

import logging
from typing import Iterator, List

import pytest

# Distinctive low-collision sentinels — same constants as
# sdk/rust/agent_shield_core/tests/no_pii_sentinel.rs.
SENTINEL_USER_INPUT = "SENTINEL_PII_USER_INPUT_xZk2"
SENTINEL_TOOL_ARGS = "SENTINEL_PII_TOOL_ARGS_8mNQ"
SENTINEL_TOOL_RESULT = "SENTINEL_PII_TOOL_RESULT_v3pL"
SENTINEL_VAR_VALUE = "SENTINEL_PII_VAR_VALUE_R7tF"

ALL_SENTINELS = (
    SENTINEL_USER_INPUT,
    SENTINEL_TOOL_ARGS,
    SENTINEL_TOOL_RESULT,
    SENTINEL_VAR_VALUE,
)

MINIMAL_YAML = """
metadata:
  name: "no-pii-sentinel-py"
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["sentinel test"]
  forbidden: ["nothing"]
resources:
  tools:
    - name: "echo"
      description: "Echo tool for the no-PII sentinel test."
      permission: "read_only"
"""


class _CapturingHandler(logging.Handler):
    """Buffer every record at DEBUG or above into a list.

    Capture starts at DEBUG so the swallow-path test can assert both
    halves of the PR3 demotion contract:
      - the type-only warning line stays at WARNING (no PII at info+),
      - the full exception text + traceback remain visible at DEBUG.

    Callers that only care about the info+ half use the
    ``_assert_no_sentinel`` helper, which filters ``[DEBUG]`` lines
    out before asserting absence.
    """

    def __init__(self) -> None:
        super().__init__(level=logging.DEBUG)
        self.records: List[str] = []

    def emit(self, record: logging.LogRecord) -> None:  # noqa: D401
        try:
            self.records.append(self.format(record))
        except Exception:  # pragma: no cover — defensive
            self.records.append(record.getMessage())


@pytest.fixture
def captured_logs() -> Iterator[List[str]]:
    """Attach a capturing handler at DEBUG to the ``agent_shield`` logger tree."""
    handler = _CapturingHandler()
    handler.setFormatter(logging.Formatter("[%(levelname)s] %(name)s: %(message)s"))
    root = logging.getLogger("agent_shield")
    prev_level = root.level
    root.setLevel(logging.DEBUG)
    root.addHandler(handler)
    try:
        yield handler.records
    finally:
        root.removeHandler(handler)
        root.setLevel(prev_level)


def _assert_no_sentinel(captured: List[str]) -> None:
    """PR3 contract's INFO+ half: sentinel never appears at info+/warn/error/critical.

    The capturing handler runs at DEBUG so the swallow-path test can
    separately prove the sentinel IS visible at DEBUG (the
    demoted-not-deleted half of the contract). This helper skips
    ``[DEBUG]`` lines so the info+ assertion stays scoped to its
    intended level.
    """
    for line in captured:
        if line.startswith("[DEBUG]"):
            continue
        for sentinel in ALL_SENTINELS:
            assert sentinel not in line, (
                f"sentinel {sentinel!r} leaked at INFO+ level: {line}"
            )


def test_no_pii_in_info_logs_during_full_turn(captured_logs: List[str]) -> None:
    """End-to-end: drive a full turn, assert no sentinel in INFO+ logs."""
    from agent_shield import RuntimeBuilder

    runtime = RuntimeBuilder.from_yaml_strings([MINIMAL_YAML]).build()
    with runtime.new_session(
        session_id="sess-sentinel", correlation_id="corr-sentinel"
    ) as session:
        session.begin_turn()
        session.validate_input(SENTINEL_USER_INPUT)
        session.validate_tool_call("echo", {"msg": SENTINEL_TOOL_ARGS}, tool_call_id="tc-sentinel")
        session.record_tool_failure("echo", SENTINEL_TOOL_RESULT)
        # ``authorized`` is not declared in MINIMAL_YAML; the call is
        # expected to raise. The assertion that matters is "no sentinel
        # leaked," not "set_variable succeeded." Catch broadly so the
        # test stays robust to runtime error-type changes.
        try:
            session.set_variable("authorized", SENTINEL_VAR_VALUE)
        except Exception:  # noqa: BLE001 — see comment above
            pass
        session.validate_output(f"agent said: {SENTINEL_TOOL_RESULT}")
        session.end_turn()

    _assert_no_sentinel(captured_logs)


@pytest.mark.asyncio
async def test_no_pii_in_info_logs_during_orchestrator_swallow_paths(
    captured_logs: List[str],
) -> None:
    """The async-orchestration ``_orchestration.py`` swallow paths log
    exception text at warning level. Verify the exception message we
    feed in does NOT escape into the captured log.

    PR3 demoted the leaky ``logger.warning("Tool '%s' raised: %s",
    tool_name, exc)`` sites at ``_orchestration.py:401`` / ``:494`` to
    a type-only template at warn + full message at debug. This test
    locks down that contract.

    Drives both ``guarded_tool`` and ``guarded_tool_sync`` with an
    ``execute`` body that raises ``ValueError`` containing every
    sentinel. The warning-level line must stay type-only while the full
    exception text remains debug-only.
    """
    from agent_shield import RuntimeBuilder
    from agent_shield.adapters._orchestration import guarded_tool, guarded_tool_sync

    runtime = RuntimeBuilder.from_yaml_strings([MINIMAL_YAML]).build()
    with runtime.new_session(
        session_id="sess-sentinel-2", correlation_id="corr-sentinel-2"
    ) as session:
        session.begin_turn()

        error_message = " :: ".join(ALL_SENTINELS)

        async def _execute_async(_: dict) -> str:
            raise ValueError(error_message)

        def _execute_sync(_: dict) -> str:
            raise ValueError(error_message)

        blocked_async, output_async = await guarded_tool(
            "echo",
            {"msg": SENTINEL_TOOL_ARGS},
            _execute_async,
            session=session,
        )
        blocked_sync, output_sync = guarded_tool_sync(
            "echo",
            {"msg": SENTINEL_TOOL_ARGS},
            _execute_sync,
            session=session,
        )
        session.end_turn()

    assert blocked_async is False
    assert blocked_sync is False
    expected_error_text = f"[tool error] echo: {error_message}"
    assert output_async == expected_error_text
    assert output_sync == expected_error_text

    warning_lines = [
        line
        for line in captured_logs
        if line.startswith("[WARNING]") and "Tool 'echo' raised" in line
    ]
    assert warning_lines == [
        "[WARNING] agent_shield: Tool 'echo' raised ValueError",
        "[WARNING] agent_shield: Tool 'echo' raised ValueError",
    ]
    _assert_no_sentinel(captured_logs)

    # PR3 demoted-not-deleted contract: the full exception text
    # (which carries the sentinel payload via ``ValueError(error_message)``)
    # must still be visible at DEBUG via the paired
    # ``logger.debug(..., exc_info=True)`` call site. If a future
    # change accidentally drops that debug call, the runtime quietly
    # loses observability and only this assertion catches it.
    debug_lines = [line for line in captured_logs if line.startswith("[DEBUG]")]
    assert any(
        SENTINEL_TOOL_RESULT in line for line in debug_lines
    ), (
        "PR3 contract violation: the full exception text must remain "
        "visible at DEBUG. Either the debug call site at "
        "_orchestration.py:401/494 was removed, or the captured "
        f"logger never received it. Debug lines seen: {debug_lines!r}"
    )
