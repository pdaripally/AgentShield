"""Tests for the :mod:`agent_shield.mcp` sibling integration."""
from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any

import pytest


REPO_ROOT = Path(__file__).resolve().parent.parent.parent.parent
GLOBAL_FIXTURES = REPO_ROOT / "tests" / "fixtures"
LOCAL_FIXTURES = Path(__file__).resolve().parent / "fixtures_smoke"

MINIMAL = str(GLOBAL_FIXTURES / "smoke" / "minimal.guardrails.yaml")
TOOL_ARGS_REDACT = str(LOCAL_FIXTURES / "tool_args_redact.guardrails.yaml")


class TestMCPModuleSurface:
    """Public API of :mod:`agent_shield.mcp`."""

    def test_imports(self):
        from agent_shield import mcp as mcp_module

        for name in (
            "MCPGuardrailBlocked",
            "MCPShield",
            "MCPShieldBuilder",
            "protect_tool",
            "protect_tool_output",
            "shield_server",
        ):
            assert hasattr(mcp_module, name), f"missing {name}"

    def test_capability_report_describes_mcp_profile(self):
        from agent_shield.adapters._capabilities import CoverageLevel
        from agent_shield.mcp import MCPShield

        shield = MCPShield.from_yaml(MINIMAL).build()
        rep = shield.capabilities

        assert rep.framework == "mcp"
        # MCP has no input/output/streaming boundary.
        assert rep.input_validation == CoverageLevel.UNSUPPORTED
        assert rep.output_validation == CoverageLevel.UNSUPPORTED
        assert rep.streaming_output == CoverageLevel.UNSUPPORTED
        # Tool stages are fully covered.
        assert rep.tool_authorization == CoverageLevel.FULL
        assert rep.tool_execution_validation == CoverageLevel.FULL
        assert rep.tool_output_validation == CoverageLevel.FULL


class TestMCPProtectTool:
    """`protect_tool` / `protect_tool_output` Stage 2/3/4 behaviour."""

    def test_protect_tool_blocks_unauthorized(self):
        from agent_shield.mcp import MCPShield, protect_tool

        shield = MCPShield.from_yaml(MINIMAL).build()

        async def _drive() -> tuple[bool, dict, str | None]:
            with shield.runtime.new_session() as session:
                session.begin_turn()
                # echo blocks until authorized
                return await protect_tool(
                    shield.runtime,
                    "echo",
                    {"msg": "hi"},
                    "tc_block",
                    session=session,
                )

        allowed, _params, msg = asyncio.run(_drive())
        assert allowed is False
        assert msg is not None
        assert "GUARDRAIL" in msg

    def test_protect_tool_allows_authorized(self):
        from agent_shield.mcp import MCPShield, protect_tool

        shield = MCPShield.from_yaml(MINIMAL).build()

        async def _drive() -> tuple[bool, dict, str | None]:
            with shield.runtime.new_session() as session:
                session.begin_turn()
                session.set_variable("authorized", True)
                return await protect_tool(
                    shield.runtime,
                    "echo",
                    {"msg": "hi"},
                    "tc_allow",
                    session=session,
                )

        allowed, params, msg = asyncio.run(_drive())
        assert allowed is True
        assert msg is None
        assert params == {"msg": "hi"}

    def test_protect_tool_requires_tool_call_id_section_16_0(self):
        """§16.0 — public MCP surfaces MUST require a non-empty tool_call_id.

        Locks in the Section 16.0 invariant: a regression that loosens
        the runtime guard (e.g. accepts ``None`` or ``""``) would
        re-open the no-id call path the spec forbids.
        """
        from agent_shield.mcp import MCPShield, protect_tool, protect_tool_output

        shield = MCPShield.from_yaml(MINIMAL).build()

        async def _drive_empty_call():
            return await protect_tool(shield.runtime, "echo", {"msg": "hi"}, "")

        async def _drive_empty_output():
            return await protect_tool_output(shield.runtime, "echo", "result", "")

        with pytest.raises(TypeError, match="tool_call_id"):
            asyncio.run(_drive_empty_call())
        with pytest.raises(TypeError, match="tool_call_id"):
            asyncio.run(_drive_empty_output())

    def test_protect_tool_returns_stage3_mutated_params(self):
        from agent_shield.mcp import MCPShield, protect_tool

        shield = MCPShield.from_yaml(TOOL_ARGS_REDACT).build()

        async def _drive() -> tuple[bool, dict, str | None]:
            with shield.runtime.new_session() as session:
                session.begin_turn()
                return await protect_tool(
                    shield.runtime,
                    "echo",
                    {"msg": "ssn is 123-45-6789"},
                    "tc_redact",
                    session=session,
                )

        allowed, params, msg = asyncio.run(_drive())
        assert allowed is True
        # Stage 3 redacted the SSN before we got the params back.
        assert "123-45-6789" not in params.get("msg", "")
        assert "[REDACTED]" in params.get("msg", "")

    def test_protect_tool_output_records_success_on_allow(self):
        from agent_shield.mcp import MCPShield, protect_tool, protect_tool_output

        shield = MCPShield.from_yaml(MINIMAL).build()

        async def _drive() -> tuple[bool, str, str | None]:
            # §16.0 — Stage 4 binds to the Stage 3 admit. Thread the
            # same tool_call_id through both helpers so the canonical
            # invocation cache matches. The minimal fixture requires
            # `authorized == true` for the echo policy to admit, so we
            # set that on the session before the Stage 3 prebind.
            tool_call_id = "tc_minimal"
            with shield.runtime.new_session() as session:
                session.begin_turn()
                session.set_variable("authorized", True)
                await protect_tool(
                    shield.runtime,
                    "echo",
                    {},
                    tool_call_id,
                    session=session,
                )
                return await protect_tool_output(
                    shield.runtime,
                    "echo",
                    "result",
                    tool_call_id,
                    session=session,
                    record=True,
                )

        allowed, output, msg = asyncio.run(_drive())
        assert allowed is True
        assert output == "result"
        assert msg is None


class TestMCPProtectServer:
    """`shield_server` / `protect_server` integration via fakes."""

    def _make_fake_server(self):
        # Mimic FastMCP's ._tool_manager._tools shape with .fn attrs
        class _FakeTool:
            def __init__(self, name, fn):
                self.name = name
                self.fn = fn

        class _FakeToolManager:
            def __init__(self):
                self._tools = {}

        class _FakeServer:
            def __init__(self):
                self._tool_manager = _FakeToolManager()

            def add(self, name, fn):
                self._tool_manager._tools[name] = _FakeTool(name, fn)

        return _FakeServer()

    def test_shield_server_wraps_tools_in_place(self):
        from agent_shield.mcp import shield_server

        server = self._make_fake_server()
        original_called = []

        async def echo(msg: str = "") -> str:
            original_called.append(msg)
            return f"echo: {msg}"

        server.add("echo", echo)
        original_fn = server._tool_manager._tools["echo"].fn

        shield = shield_server(server, MINIMAL, on_block="raise")
        # The tool's fn was replaced by the wrapped callable.
        wrapped_fn = server._tool_manager._tools["echo"].fn
        assert wrapped_fn is not original_fn

        # Authorized happy path: original is invoked.
        from agent_shield.adapters._orchestration import current_session

        async def _drive() -> str:
            with shield.runtime.new_session() as session:
                session.begin_turn()
                session.set_variable("authorized", True)
                tok = current_session.set(session)
                try:
                    return await wrapped_fn(msg="hi")
                finally:
                    current_session.reset(tok)

        out = asyncio.run(_drive())
        assert "echo: hi" in out
        assert original_called == ["hi"]

    def test_shield_server_blocks_unauthorized_via_raise(self):
        from agent_shield.mcp import MCPGuardrailBlocked, shield_server

        server = self._make_fake_server()

        async def echo(msg: str = "") -> str:
            return f"echo: {msg}"

        server.add("echo", echo)
        shield = shield_server(server, MINIMAL, on_block="raise")
        wrapped = server._tool_manager._tools["echo"].fn

        from agent_shield.adapters._orchestration import current_session

        async def _drive() -> Any:
            with shield.runtime.new_session() as session:
                session.begin_turn()
                tok = current_session.set(session)
                try:
                    return await wrapped(msg="hi")
                finally:
                    current_session.reset(tok)

        with pytest.raises(MCPGuardrailBlocked) as exc_info:
            asyncio.run(_drive())
        assert exc_info.value.tool_name == "echo"

    def test_shield_server_blocks_unauthorized_via_return_message(self):
        from agent_shield.mcp import shield_server

        server = self._make_fake_server()

        async def echo(msg: str = "") -> str:
            return f"echo: {msg}"

        server.add("echo", echo)
        shield = shield_server(server, MINIMAL, on_block="return_message")
        wrapped = server._tool_manager._tools["echo"].fn

        from agent_shield.adapters._orchestration import current_session

        async def _drive() -> Any:
            with shield.runtime.new_session() as session:
                session.begin_turn()
                tok = current_session.set(session)
                try:
                    return await wrapped(msg="hi")
                finally:
                    current_session.reset(tok)

        out = asyncio.run(_drive())
        assert "GUARDRAIL" in out

    def test_protect_tools_manual_pair_form(self):
        from agent_shield.mcp import MCPShield

        shield = MCPShield.from_yaml(MINIMAL).build()

        async def echo(msg: str = "") -> str:
            return f"echo: {msg}"

        wrapped = shield.protect_tools(
            [("echo", echo)], on_block="return_message",
        )
        assert len(wrapped) == 1
        name, fn = wrapped[0]
        assert name == "echo"
        assert fn is not echo  # was wrapped

    def test_unsupported_server_shape_errors(self):
        from agent_shield.mcp import MCPShield

        shield = MCPShield.from_yaml(MINIMAL).build()

        class _BadServer:
            pass

        with pytest.raises(TypeError, match="tool registry"):
            shield.protect_server(_BadServer())


class TestMCPBuilder:
    """Builder fluent API."""

    def test_with_observability(self):
        from agent_shield.mcp import MCPShield
        from agent_shield.observability import CapturingProvider

        cap = CapturingProvider()
        shield = (
            MCPShield.from_yaml(MINIMAL)
            .with_observability(cap)
            .build()
        )
        with shield.runtime.new_session() as session:
            session.begin_turn()
            session.end_turn()
        assert len(cap.events) > 0

    def test_yaml_chain(self):
        from agent_shield.mcp import MCPShield

        shield = MCPShield.from_yaml([MINIMAL]).build()
        assert shield.runtime is not None


class TestMCPSessionScope:
    """Session-scope behaviour — connection (default) vs call."""

    def test_default_scope_is_connection(self):
        from agent_shield.mcp import MCPShield

        shield = MCPShield.from_yaml(MINIMAL).build()
        assert shield.session_scope == "connection"
        assert shield.session is not None  # lazily created

    def test_connection_scope_state_spans_calls(self):
        """A variable set on the held session is visible to later calls."""
        from agent_shield.mcp import MCPShield

        shield = MCPShield.from_yaml(MINIMAL).build()
        # Prime the held connection session.
        sess = shield.session
        assert sess is not None
        sess.begin_turn()
        sess.set_variable("authorized", True)

        async def _drive():
            r1 = await shield.protect_tool("echo", {"msg": "first"}, "tc_1")
            r2 = await shield.protect_tool("echo", {"msg": "second"}, "tc_2")
            return r1, r2

        r1, r2 = asyncio.run(_drive())
        # Both calls allowed because the session-scoped `authorized`
        # variable persists across the two calls.
        assert r1[0] is True, r1[2]
        assert r2[0] is True, r2[2]

    def test_call_scope_does_not_share_state(self):
        from agent_shield.mcp import MCPShield

        shield = (
            MCPShield.from_yaml(MINIMAL)
            .with_session_scope("call")
            .build()
        )
        assert shield.session_scope == "call"
        assert shield.session is None  # no held session in call scope

        async def _drive():
            return await shield.protect_tool("echo", {"msg": "hi"}, "tc_per_call")

        allowed, _, msg = asyncio.run(_drive())
        # Per-call sessions can't see authorized=true set elsewhere.
        assert allowed is False
        assert msg is not None and "GUARDRAIL" in msg

    def test_reset_session_drops_held_session(self):
        from agent_shield.mcp import MCPShield

        shield = MCPShield.from_yaml(MINIMAL).build()
        sess1 = shield.session
        assert sess1 is not None
        # Reset drops the held session — the next access creates a
        # new one. Useful for connection-pool reuse / TTL-based reset.
        shield.reset_session()
        assert shield._session is None
        sess2 = shield.session
        assert sess2 is not sess1

    def test_reset_session_noop_in_call_scope(self):
        from agent_shield.mcp import MCPShield

        shield = (
            MCPShield.from_yaml(MINIMAL)
            .with_session_scope("call")
            .build()
        )
        # No held session exists — reset is a safe no-op.
        shield.reset_session()
        assert shield.session is None
