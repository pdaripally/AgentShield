from __future__ import annotations

import json
from pathlib import Path

import pytest

from agent_shield import RuntimeBuilder


REPO_ROOT = Path(__file__).resolve().parents[4]
FIXTURE_PATH = REPO_ROOT / 'tests' / 'parity' / 'invocation_hash_canonicalization.json'
if not FIXTURE_PATH.exists():
    raise FileNotFoundError(f'Missing parity fixture: {FIXTURE_PATH}')
CASES = json.loads(FIXTURE_PATH.read_text())['cases']
if not CASES:
    raise ValueError(f'No cases found in parity fixture: {FIXTURE_PATH}')


def _session(case: dict):
    runtime = RuntimeBuilder.from_yaml(str(REPO_ROOT / case['fixture'])).build()
    session = runtime.new_session()
    session.begin_turn()
    return session


@pytest.mark.parametrize('case', CASES, ids=lambda c: c['name'])
def test_invocation_hash_canonicalization_matches_fixture(case: dict) -> None:
    session = _session(case)
    outcome = session.validate_tool_call(
        case['tool_name'],
        dict(case['params']),
        tool_call_id=case['tool_call_id'],
    )
    expected = case['expected']
    assert outcome.verdict.allowed, case['name']
    assert outcome.verdict.invocation_hash == expected['invocation_hash']
    assert (
        outcome.verdict.post_validation_invocation_hash
        == expected['post_validation_invocation_hash']
    )
    if 'effective_params' in expected:
        assert outcome.params == expected['effective_params']
