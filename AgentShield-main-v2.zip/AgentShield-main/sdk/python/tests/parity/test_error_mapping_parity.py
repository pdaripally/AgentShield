from __future__ import annotations

import asyncio
import json
from pathlib import Path

import pytest

from agent_shield.adapters._shield import AgentShieldBlocked
from agent_shield.mcp import MCPGuardrailBlocked, shield_server


REPO_ROOT = Path(__file__).resolve().parents[4]
FIXTURE_PATH = REPO_ROOT / 'tests' / 'parity' / 'error_mapping_parity.json'
if not FIXTURE_PATH.exists():
    raise FileNotFoundError(f'Missing parity fixture: {FIXTURE_PATH}')
CASES = json.loads(FIXTURE_PATH.read_text())['cases']
if not CASES:
    raise ValueError(f'No cases found in parity fixture: {FIXTURE_PATH}')


def _get_case(name: str) -> dict:
    for case in CASES:
        if case['name'] == name:
            return case
    raise ValueError(f'parity fixture missing case "{name}"')


class _FakeTool:
    def __init__(self, fn):
        self.fn = fn


class _FakeToolManager:
    def __init__(self) -> None:
        self._tools: dict[str, _FakeTool] = {}


class _FakeServer:
    def __init__(self) -> None:
        self._tool_manager = _FakeToolManager()

    def add(self, name: str, fn):
        self._tool_manager._tools[name] = _FakeTool(fn)


def test_shield_blocked_raise_matches_fixture() -> None:
    case = _get_case('shield_blocked_raise')
    exc = AgentShieldBlocked(verdict=None, message='blocked')
    assert type(exc).__name__ == case['expected']['python']


def test_mcp_blocked_raise_matches_fixture() -> None:
    case = _get_case('mcp_blocked_raise')
    server = _FakeServer()

    async def echo(msg: str = '') -> str:
        return f'echo: {msg}'

    server.add('echo', echo)
    shield = shield_server(server, str(REPO_ROOT / case['fixture']), on_block='raise')
    wrapped = server._tool_manager._tools['echo'].fn

    from agent_shield.adapters._orchestration import current_session

    async def _drive():
        with shield.runtime.new_session() as session:
            session.begin_turn()
            token = current_session.set(session)
            try:
                return await wrapped(msg='hi')
            finally:
                current_session.reset(token)

    with pytest.raises(MCPGuardrailBlocked) as exc_info:
        asyncio.run(_drive())
    assert type(exc_info.value).__name__ == case['expected']['python']
