"""SDK-level tests for runtime-wide shadow mode (microsoft/AgentShield#14).

These tests verify the orchestrator auto-fold contract: when a runtime
is loaded with `mode: shadow`, the Python `Shield` and `GuardedRunner`
constructors force `ShieldMode.MONITOR` regardless of what the caller
asked for, and every public entry point (`run`, `protect_tool`,
`before_invoke`, `protect_tools`) runs validations for observability
but never blocks or mutates the caller's flow.
"""
from __future__ import annotations

import asyncio
from typing import Any


from agent_shield import RuntimeBuilder
from agent_shield.adapters._shield import Shield, ShieldMode


SHADOW_INPUT_BLOCK_YAML = """

metadata:
  name: shadow-sdk-input-block
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
resources:
  tools:
    - name: echo
      permission: read_only
input_validation:
  guard_policies:
    - name: block_secret
      evaluate_when:
        - pattern: "(?i)secret"
          reason: "input contained secret"
          action: block
"""

SHADOW_TOOL_REDACT_YAML = """

metadata:
  name: shadow-sdk-tool-redact
  version: "0.1.0"
  agent_shield_version: "2.0"
objective:
  goal: ["test"]
resources:
  tools:
    - name: echo
      permission: read_only
tool_execution_validation:
  guard_policies:
    - name: redact_ssn
      applies_to: { tools: ["echo"] }
      evaluate_when:
        - pattern: '\\d{3}-\\d{2}-\\d{4}'
          reason: ssn
          action: redact
      replacement: "[X]"
"""


def _build_runtime(yaml: str):
    return RuntimeBuilder.from_yaml_strings([yaml]).with_mode("shadow").build()


# ─────────────────────────────────────────────────────────────────────
# Auto-fold: shadow runtime forces ShieldMode.MONITOR even when the
# caller asks for ENFORCE.
# ─────────────────────────────────────────────────────────────────────


def test_shadow_runtime_auto_folds_shield_to_monitor() -> None:
    rt = _build_runtime(SHADOW_INPUT_BLOCK_YAML)
    s = Shield(rt, mode=ShieldMode.ENFORCE)
    assert s.mode is ShieldMode.MONITOR


def test_shadow_runtime_run_does_not_block_on_stage1_deny() -> None:
    rt = _build_runtime(SHADOW_INPUT_BLOCK_YAML)
    s = Shield(rt, mode=ShieldMode.ENFORCE)

    async def _execute() -> str:
        return "ok"

    result = asyncio.run(
        s.run(_execute, user_input="this contains secret stuff"),
    )
    assert result == "ok", (
        "shadow Shield.run must proceed to execute() even when Stage 1 "
        "would have blocked; got %r" % (result,)
    )


def test_shadow_runtime_before_invoke_returns_none_on_block() -> None:
    rt = _build_runtime(SHADOW_INPUT_BLOCK_YAML)
    s = Shield(rt, mode=ShieldMode.ENFORCE)
    out = asyncio.run(s.before_invoke("this is a secret"))
    assert out is None, (
        "shadow Shield.before_invoke must return None so the caller "
        "proceeds, even when Stage 1 would have blocked; got %r" % (out,)
    )


def test_shadow_runtime_protect_tool_does_not_mutate_params() -> None:
    rt = _build_runtime(SHADOW_TOOL_REDACT_YAML)
    s = Shield(rt, mode=ShieldMode.ENFORCE)

    captured: dict[str, Any] = {}

    async def _exec(effective_params: Any) -> str:
        captured["params"] = effective_params
        return "tool ran"

    blocked, output = asyncio.run(
        s.protect_tool("echo", {"msg": "id 123-45-6789"}, _exec),
    )
    assert blocked is False
    assert output == "tool ran"
    assert "123-45-6789" in captured["params"]["msg"], (
        "shadow Shield.protect_tool must pass the ORIGINAL params to "
        "the tool, never the redacted ones; got %r" % (captured["params"],)
    )
