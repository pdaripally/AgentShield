"""Tests for :meth:`Shield.with_fresh_session` and
:meth:`GuardedRunner.with_fresh_session`.

Verifies the post-build immutability contract documented in
``spec/SPECIFICATION.md``:

1. ``with_fresh_session()`` returns a NEW instance (different object
   identity from the original).
2. The original Shield's runner state is unchanged (runners
   previously spawned from it are preserved).
3. The new Shield has a clean slate (no inherited runners; runners
   spawned from it get their own fresh sessions).
4. Both Shields point to the same ``runtime`` reference.

Mirrors the Rust ``with_fresh_session.rs``, .NET
``WithFreshSessionTests.cs``, and Node ``with_fresh_session.test.ts``
suites so the four SDKs stay in lockstep.
"""
from __future__ import annotations

from pathlib import Path

# Importing the LangChain adapter installs the bundle hook on
# ShieldBuilder.with_langchain() so we have a buildable shield.
import agent_shield.adapters.langchain  # noqa: F401
from agent_shield import Shield
from agent_shield.adapters._orchestration import current_user_input
from agent_shield.adapters._shield import GuardedRunner, ShieldMode

REPO_ROOT = Path(__file__).resolve().parent.parent.parent.parent
MINIMAL = str(REPO_ROOT / "tests" / "fixtures" / "smoke" / "minimal.guardrails.yaml")
INPUT_REDACT = str(
    REPO_ROOT / "tests" / "fixtures" / "smoke" / "input-redact.guardrails.yaml"
)


def _build_shield(**kwargs) -> Shield:
    """Build a minimally-configured Shield for the immutability tests."""
    return (
        Shield.from_yaml(MINIMAL, auto_bind=False)
        .with_langchain()
        .build()
    )


# ── Shield.with_fresh_session ─────────────────────────────────────


def test_shield_with_fresh_session_returns_new_instance() -> None:
    original = _build_shield()
    forked = original.with_fresh_session()

    # (1) Different Shield instances.
    assert forked is not original
    # (4) Both Shields share the same runtime.
    assert forked.runtime is original.runtime


def test_shield_with_fresh_session_preserves_config() -> None:
    original = (
        Shield.from_yaml(MINIMAL, auto_bind=False)
        .with_langchain()
        .with_mode(ShieldMode.MONITOR)
        .with_on_block("raise")
        .build()
    )
    forked = original.with_fresh_session()

    assert forked.mode is ShieldMode.MONITOR
    assert forked._on_block == "raise"
    assert forked._bundle is original._bundle
    assert forked._streaming_config == original._streaming_config


def test_shield_with_fresh_session_does_not_mutate_original() -> None:
    original = _build_shield()
    # Force a runner reference into the original to verify the fork
    # does NOT cascade through it. We use the internal weakset
    # directly; calling guard() requires a real agent. Use a class
    # instance because the weakset can't hold bare `object()`s.
    class _Marker:
        pass
    sentinel = _Marker()
    original._guarded_runners.add(sentinel)

    forked = original.with_fresh_session()

    # (2) Original's runner set still contains the sentinel — no
    # destructive cascade.
    assert sentinel in original._guarded_runners
    # (3) Fork starts with a clean slate.
    assert sentinel not in forked._guarded_runners
    assert len(forked._guarded_runners) == 0


def test_shield_with_fresh_session_returns_shield_instance() -> None:
    """``with_fresh_session`` returns a :class:`Shield` (no subclassing
    is supported in the unified-resolver model)."""
    original = _build_shield()
    forked = original.with_fresh_session()
    assert type(forked) is type(original)


# ── GuardedRunner.with_fresh_session ──────────────────────────────


def _stub_boundary():
    class _Stub:
        async def run(self, agent, input_text, **kwargs):
            return {}

        def extract_output(self, result):
            return ""

        def apply_redaction(self, result, redacted):
            return result

        def make_blocked(self, message):
            return message

    return _Stub()


def test_runner_run_passes_stage1_mutated_input() -> None:
    import asyncio

    shield = (
        Shield.from_yaml(INPUT_REDACT, auto_bind=False)
        .with_langchain()
        .build()
    )
    seen = {}

    class _Boundary:
        async def run(self, agent, input_text, **kwargs):
            seen["input"] = input_text
            return {"ok": True}

        def extract_output(self, result):
            return ""

        def apply_redaction(self, result, redacted):
            return result

        def make_blocked(self, message):
            return message

    runner = GuardedRunner(shield.runtime, agent=object(), boundary=_Boundary())
    asyncio.run(runner.run("hello SECRET-ABCD"))
    assert seen["input"] == "hello [INPUT REDACTED]"


def test_shield_run_sets_ambient_stage1_mutated_input() -> None:
    import asyncio

    shield = Shield.from_yaml(INPUT_REDACT, auto_bind=False).build()
    seen = {}

    async def _execute():
        seen["input"] = current_user_input.get()
        return ""

    asyncio.run(shield.run(_execute, user_input="hello SECRET-ABCD"))
    assert seen["input"] == "hello [INPUT REDACTED]"


def test_runner_with_fresh_session_returns_new_runner() -> None:
    shield = _build_shield()
    boundary = _stub_boundary()
    original = GuardedRunner(shield.runtime, agent=object(), boundary=boundary)
    original_session = original._session

    forked = original.with_fresh_session()

    # (1) Different runner instance.
    assert forked is not original
    # (3) Different session.
    assert forked._session is not original._session
    # (4) Same runtime reference.
    assert forked._runtime is original._runtime
    # (2) Original's session reference unchanged.
    assert original._session is original_session
