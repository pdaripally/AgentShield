from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace

from ._integration_json_report import IntegrationJsonReporter, classify_report


class UnknownActionError(Exception):
    pass


def _report(*, when: str, passed: bool = False, failed: bool = False, skipped: bool = False, duration: float = 0.0,
            longreprtext: str | None = None, wasxfail: str | None = None):
    report = SimpleNamespace(
        when=when,
        passed=passed,
        failed=failed,
        skipped=skipped,
        duration=duration,
        longreprtext=longreprtext,
    )
    if wasxfail is not None:
        report.wasxfail = wasxfail
    return report


def _call(exc: BaseException | None = None):
    if exc is None:
        return SimpleNamespace(excinfo=None)
    return SimpleNamespace(excinfo=SimpleNamespace(type=type(exc), value=exc))


def test_classify_report_maps_unknown_action() -> None:
    report = _report(
        when="call",
        failed=True,
        longreprtext="Unknown action verb: do_magic",
    )

    status, detail = classify_report(report, _call(UnknownActionError("Unknown action verb: do_magic")))

    assert status == "unknown_action"
    assert detail == "Unknown action verb: do_magic"


def test_classify_report_maps_xfail() -> None:
    report = _report(
        when="call",
        skipped=True,
        wasxfail="GH-123: known parity gap",
    )

    status, detail = classify_report(report, _call())

    assert status == "xfail"
    assert detail == "GH-123: known parity gap"


def test_reporter_writes_expected_json(tmp_path: Path) -> None:
    output_path = tmp_path / "json_report_output_test.json"

    reporter = IntegrationJsonReporter(str(output_path))
    reporter.register_case(
        "node-1",
        suite="comprehensive-spec",
        case="Explicit allow tool passes",
    )
    reporter.add_duration("node-1", 0.004)
    reporter.apply_report(
        "node-1",
        _report(when="call", passed=True, duration=0.004),
        _call(),
    )

    reporter.write_json()
    payload = json.loads(output_path.read_text(encoding="utf-8"))

    assert payload["sdk"] == "python"
    assert isinstance(payload["sdk_version"], str) and payload["sdk_version"]
    assert isinstance(payload["core_version"], str) and payload["core_version"]
    assert payload["results"] == [
        {
            "suite": "comprehensive-spec",
            "case": "Explicit allow tool passes",
            "status": "pass",
            "duration_ms": 4,
            "error_detail": None,
        }
    ]
    assert payload["timestamp"].endswith("Z")
