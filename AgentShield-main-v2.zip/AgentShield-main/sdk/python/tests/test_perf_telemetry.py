"""v8 perf-logging PR6 — Python SDK surface test.

Verifies that :meth:`agent_shield.RuntimeBuilder.with_perf_telemetry`
round-trips the gating knob into the underlying Rust runtime for all
three modes, accepts both enum and string forms, and that ``Off`` (the
default) emits zero perf events when the runtime evaluates a stage.

The full event catalogue (per-stage, per-policy, AC10-Corr correlation)
is covered by ``sdk/rust/agent_shield_core/tests/perf_telemetry.rs``;
this file just pins the Python wrapper's delegation.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from agent_shield import (
    PerfTelemetry,
    RuntimeBuilder,
    ShieldLogEvent,
)


PERF_EVENT_TYPES = {
    "stage_evaluated",
    "policy_evaluated",
    "llm_called",
    "classifier_called",
}


POLICY_YAML = """
metadata:
  name: perf-test
  version: "1.0.0"
input_validation:
  guard_policies:
    - name: pii_regex
      evaluate_when:
        - pattern: '\\d{3}-\\d{2}-\\d{4}'
          reason: 'SSN detected'
          action: block
output_validation:
  guard_policies:
    - name: secret_in_output
      evaluate_when:
        - pattern: 'sk_live_[A-Za-z0-9]+'
          reason: 'API key leaked'
          action: block
"""


@pytest.fixture()
def policy_path(tmp_path: Path) -> Path:
    p = tmp_path / "perf.guardrails.yaml"
    p.write_text(POLICY_YAML, encoding="utf-8")
    return p


def _build_with_capture(policy_path: Path, mode):
    """Return (runtime, captured_events_list) for the given mode."""
    captured: list[ShieldLogEvent] = []

    def emit(event: ShieldLogEvent) -> None:
        captured.append(event)

    builder = RuntimeBuilder.from_yaml(str(policy_path))
    builder = builder.register_observability_provider(emit)
    if mode is not None:
        builder = builder.with_perf_telemetry(mode)
    runtime = builder.build()
    return runtime, captured


def _count_perf(events) -> int:
    return sum(1 for e in events if e.event_type in PERF_EVENT_TYPES)


def test_perf_telemetry_enum_values_match_wire_strings():
    assert PerfTelemetry.OFF.value == "off"
    assert PerfTelemetry.EXTERNAL.value == "external"
    assert PerfTelemetry.FULL.value == "full"
    # Inheriting `str` keeps the enum trivially JSON-serialisable.
    assert isinstance(PerfTelemetry.OFF, str)


def test_with_perf_telemetry_default_off_emits_no_perf_events(policy_path: Path):
    runtime, captured = _build_with_capture(policy_path, None)
    session = runtime.new_session()
    session.validate_input("hello, world")
    session.validate_output("just a response")
    assert _count_perf(captured) == 0, (
        f"Off (default) must emit zero perf events; saw "
        f"{[e.event_type for e in captured if e.event_type in PERF_EVENT_TYPES]}"
    )


def test_with_perf_telemetry_full_emits_perf_events(policy_path: Path):
    runtime, captured = _build_with_capture(policy_path, PerfTelemetry.FULL)
    session = runtime.new_session()
    session.validate_input("hello, world")
    session.validate_output("just a response")
    assert _count_perf(captured) >= 2, (
        f"Full must emit at least one StageEvaluated and one "
        f"PolicyEvaluated; saw {[e.event_type for e in captured]}"
    )
    # Stage-level + policy-level signals MUST be present (regex
    # detection emits no LLM/classifier events).
    types = {e.event_type for e in captured}
    assert "stage_evaluated" in types
    assert "policy_evaluated" in types


def test_with_perf_telemetry_external_emits_no_stage_or_policy_events(policy_path: Path):
    runtime, captured = _build_with_capture(policy_path, PerfTelemetry.EXTERNAL)
    session = runtime.new_session()
    session.validate_input("hello, world")
    session.validate_output("just a response")
    # External must emit zero stage/policy events. This YAML has no
    # LLM/classifier detection, so the total is zero.
    types = {e.event_type for e in captured}
    assert "stage_evaluated" not in types
    assert "policy_evaluated" not in types


def test_with_perf_telemetry_round_trips_all_three(policy_path: Path):
    # Builder must accept both the enum and the lower-case wire
    # string. Passing in mixed shapes here matches what adopter code
    # might write.
    for mode in [
        PerfTelemetry.OFF,
        PerfTelemetry.EXTERNAL,
        PerfTelemetry.FULL,
        "off",
        "external",
        "full",
        "OFF",  # case-insensitive
        "Full",
    ]:
        builder = RuntimeBuilder.from_yaml(str(policy_path))
        builder = builder.with_perf_telemetry(mode)
        runtime = builder.build()
        # Smoke: build succeeded and produced a real session.
        session = runtime.new_session()
        _ = session.validate_input("hi")


def test_with_perf_telemetry_rejects_unknown_mode(policy_path: Path):
    builder = RuntimeBuilder.from_yaml(str(policy_path))
    with pytest.raises(Exception) as excinfo:
        builder.with_perf_telemetry("loud")
    assert "perf_telemetry" in str(excinfo.value).lower() or "loud" in str(excinfo.value).lower()
